# OMCL notes — 0000926326-18-000010


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-18-000010:notes:1]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of December 31, 2017:

[0000926326-18-000010:notes:2]
|  |  | Number of Shares |
|  |  | (In thousands) |
| Share options outstanding |  | 3,323 |  |
| Non-vested restricted stock awards |  | 749 |  |
| Shares authorized for future issuance |  | 1,398 |  |
| ESPP shares available for future issuance |  | 2,365 |  |
| Total shares reserved for future issuance |  | 7,835 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000926326-18-000010:notes:3]
The pro forma adjustments include the impact of fair value adjustment related to deferred revenue, inventory fair value adjustment, amortization of intangible assets, stock-based compensation expense, interest expense and amortization of deferred issuance cost, and certain classification to conform to the Company's accounting policies.

[0000926326-18-000010:notes:4]
|  | Twelve months ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (in thousands, except per share data) |
| Pro forma net revenues | $ | 716,723 |  |  | $ | 719,799 |  |  | $ | 523,241 |  |
| Pro forma net income (loss) | $ | 20,770 |  |  | $ | (1,044 | ) |  | $ | 2,245 |  |
| Pro forma net income (loss) per share | $ | 0.54 |  |  | $ | (0.03 | ) |  | $ | 0.06 |  |
| Weighted average number of shares | 38,712 |  |  | 36,156 |  |  | 36,699 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-18-000010:notes:5]
Business Combinations

[0000926326-18-000010:notes:6]
2017 Acquisitions

[0000926326-18-000010:notes:7]
On April 12, 2017, the Company completed the acquisition of all of the membership interest of Dixie Drawl, LLC d/b/a InPharmics ("InPharmics"). InPharmics is a technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies. The total consideration for the transaction was $5.0 million, net of cash acquired of $0.3 million. Approximately $0.5 million of the total consideration was classified as a long-term liability for potential settlement of performance obligations. The Company accounted for the acquisition of InPharmics in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition date. The purchase price was preliminary allocated to intangible assets in the amount of $1.9 million, which included developed technology and customer contracts, with the remainder allocated to goodwill. The results of the InPharmics' operations have been included in our consolidated results of operations, and presented as part of the Automation and Analytics segment.

[0000926326-18-000010:notes:8]
2016 Acquisition Activity

[0000926326-18-000010:notes:9]
On January 5, 2016, the Company completed the acquisition of all of the membership interests of Aesynt. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. The total consideration was $271.5 million, net of cash acquired of $8.2 million. The results of Aesynt's operations have been included in our consolidated results of operations as of the time of the acquisition, and presented as part of the Automation and Analytics segment.

[0000926326-18-000010:notes:10]
On December 8, 2016, the Company completed its acquisition of ateb, Inc., and Ateb Canada Ltd. (together, “Ateb”) for $40.7 million of cash consideration, net of $0.9 million cash on hand. The cash consideration, included the repayment of Ateb indebtedness and other adjustments provided for in the Ateb's Securities Purchase Agreement. Ateb is a provider of pharmacy-based patient care and medication synchronization solutions to independent and chain pharmacies. The results of Ateb's operations have been included in our consolidated results of operations as of the time of the acquisition, and presented as part of the Medication Adherence segment.

[0000926326-18-000010:notes:11]
The Company accounted for the acquisitions of Aesynt and Ateb in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition dates, respectively. The following table represents the allocation of the purchase price to the assets acquired and the liabilities assumed by the Company during each acquisition, respectively, reconciled to the purchase price transferred included in the Company's Consolidated Balance Sheet:

[0000926326-18-000010:notes:12]
|  | Aesynt |  | Ateb |  | Total |
|  | (In thousands) |
| Cash | $ | 8,164 |  |  | $ | 902 |  |  | $ | 9,066 |  |
| Accounts receivable | 43,312 |  |  | 7,761 |  |  | 51,073 |  |
| Inventory | 19,021 |  |  | 225 |  |  | 19,246 |  |
| Other current assets | 3,787 |  |  | 1,239 |  |  | 5,026 |  |
| Total current assets | 74,284 |  |  | 10,127 |  |  | 84,411 |  |
| Property and equipment | 10,389 |  |  | 2,447 |  |  | 12,836 |  |
| Intangible assets | 123,700 |  |  | 12,500 |  |  | 136,200 |  |
| Goodwill | 163,599 |  |  | 24,232 |  |  | 187,831 |  |
| Other non-current assets | 968 |  |  | 334 |  |  | 1,302 |  |
| Total assets | 372,940 |  |  | 49,640 |  |  | 422,580 |  |
| Current liabilities | 26,753 |  |  | 4,895 |  |  | 31,648 |  |
| Deferred revenue, net | 25,512 |  |  | 2,776 |  |  | 28,288 |  |
| Non-current deferred tax liabilities | 38,622 |  |  | — |  |  | 38,622 |  |
| Other non-current liabilities | 2,431 |  |  | 367 |  |  | 2,798 |  |
| Total liabilities | 93,318 |  |  | 8,038 |  |  | 101,356 |  |
| Total purchase price | 279,622 |  |  | 41,602 |  |  | 321,224 |  |
| Total purchase price, net of cash received | $ | 271,458 |  |  | $ | 40,700 |  |  | $ | 312,158 |  |

[0000926326-18-000010:notes:13]
The $163.6 million of goodwill arising from the Aesynt acquisition is primarily attributed to sales of future products and services and Aesynt's assembled workforce. The goodwill has been assigned to the Automation and Analytics segment and is not deductible for tax purposes. Since the acquisition, the Company adjusted the preliminary value assigned to goodwill by $1.2 million to reflect measurement period adjustments related to accounts receivable, inventory, and other assets and liabilities (inclusive of deferred taxes) of $1.6 million, $1.1 million and ($3.9) million, respectively.

[0000926326-18-000010:notes:14]
The $24.2 million of goodwill arising from the Ateb acquisition is primarily attributed to sales of future products and services and Ateb's assembled workforce. Since the acquisition, the Company adjusted the preliminary value assigned to goodwill by $3.4 million to reflect adjustments related to accounts receivable, other non-current assets and other accrued liabilities of $0.1 million, $0.7 million and $2.6 million, respectively.

[0000926326-18-000010:notes:15]
Intangible assets eligible for recognition separate from goodwill were those that satisfied either the contractual/legal criterion or the separability criterion in the accounting guidance. The identifiable intangible assets acquired and their estimated useful lives for amortization are as follows:

[0000926326-18-000010:notes:16]
|  | Aesynt |  | Ateb |
|  | Fair value |  | Weightedaverageuseful life |  | Fair value |  | Weightedaverageuseful life |
|  | (In thousands) |  | (In years) |  | (In thousands) |  | (In years) |
| Customer relationships | $ | 58,200 |  |  | 14-16 |  | $ | 8,900 |  |  | 12 |
| Developed technology | 38,800 |  |  | 8 |  | 3,400 |  |  | 5 |
| Backlog | 20,200 |  |  | 1-3 |  | — |  |  | - |
| In-process research and development ("IPR&D") (1) | 3,900 |  |  | - |  | — |  |  | - |
| Non-compete | 1,800 |  |  | 3 |  | 100 |  |  | 1 |
| Trade names | 800 |  |  | 1 |  | 100 |  |  | 1 |
| Total purchased intangible assets | $ | 123,700 |  |  |  |  | $ | 12,500 |  |  |  |

[0000926326-18-000010:notes:17]
(1) The amortization of the in-process R&D assets begins when the in-process R&D projects are complete.

[0000926326-18-000010:notes:18]
Aesynt Acquisition

[0000926326-18-000010:notes:19]
Customer relationships represent the fair value of the underlying relationships and agreements with Aesynt’s customers, acquired developed technology represents the fair value of Aesynt products that have reached technological feasibility and were part of Aesynt’s product offerings at the date of acquisition, backlog represents the fair value of sales order product backlog at the date of acquisition, non-compete intangible asset represents the fair value of non-compete agreements with former key members of Aesynt's management, and trade name represents the fair value of brand and name recognition associated with the marketing of Aesynt’s products and services. In-process research and development ("IPR&D") represents the fair value of incomplete Aesynt research and development projects that had not reached technological feasibility as of the date of acquisition. Incremental costs incurred for those projects are expensed as incurred in research and development.

[0000926326-18-000010:notes:20]
The fair value of Aesynt trade names, acquired developed technology, and acquired IPR&D was determined based on an income approach using the relief-from-royalty method at the royalty rates of 0.5%, 4% to 8% and 12.5%, respectively. The fair value of customer relationships, backlog, and non-compete intangible assets were determined based on an income approach using the discounted cash flow method, at the discounted rates of 13%, 10% and 13%, respectively. The intangible assets, except customer relationship and IPR&D, are being amortized over their estimated useful lives using the straight line method of amortization. The customer relationship intangible asset is being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. In accordance with authoritative guidance, the IPR&D is accounted for as an indefinite-lived intangible asset until completion or abandonment of the associated research and development efforts. IPR&D is tested for impairment during the period it is considered an indefinite lived asset. IPR&D related projects are expected to be completed in two to three years. As of December 31, 2017, none of the IPR&D projects have been completed, and they have progressed as previously estimated.

[0000926326-18-000010:notes:21]
Ateb Acquisition

[0000926326-18-000010:notes:22]
Customer relationships represent the fair value of the underlying relationships and agreements with Ateb’s customers expected to result in future sales, acquired developed technology represents the fair value of Ateb intellectual property incorporated in their products, non-compete intangible asset represents the fair value of non-compete agreements with former key members of Ateb's management, and trade name represents the fair value of brand and name recognition associated with the marketing of Ateb’s products and services.

[0000926326-18-000010:notes:23]
The fair value of Ateb trade names and acquired developed technology was determined based on an income approach using the relief-from-royalty method at the royalty rates of 0.5% and 5% to 6%, respectively. The fair value of customer relationships, and non-compete intangible assets were determined based on an income approach using the discounted cash flow method, both using a 15% discount rate. The intangible assets for non-compete agreements and trade name are being amortized over their estimated useful lives using the straight line method of amortization. The intangible assets for customer relationship and developed technology are being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained.

[0000926326-18-000010:notes:24]
The Company incurred approximately $9.3 million in acquisition-related costs related to the Aesynt acquisition of which $6.4 million and $2.9 million were recognized in the years ended December 31, 2016 and 2015, respectively. These costs are included in selling, general and administrative expenses in the Company's Consolidated Statement of Operations. During the year ended December 31, 2016, the Company incurred and expensed approximately $1.7 million of acquisition-related costs for Ateb.

[0000926326-18-000010:notes:25]
Pro forma financial information

[0000926326-18-000010:notes:26]
The following table presents certain unaudited pro forma information for illustrative purposes only, for the years ended December 31, 2017, December 31, 2016 and December 31, 2015 as if these acquisitions had been acquired on January 1, 2015. The pro forma information is not indicative of what would have occurred had the acquisitions taken place on January 1, 2015. The unaudited pro forma information combines the historical results of the acquisitions with the Company's consolidated historical results and includes certain adjustments reflecting the estimated impact of fair value adjustments for the respective periods. The pro forma adjustments include the impact of fair value adjustment related to deferred revenue, inventory fair value adjustment, amortization of intangible assets, stock-based compensation expense, interest expense and amortization of deferred issuance cost, and certain classification to conform to the Company's accounting policies.


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-18-000010:notes:27]
Net Investment in Sales-Type Leases

[0000926326-18-000010:notes:28]
On a recurring basis, the Company enters into sales-type lease transactions which vary in length from one to five years. The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at December 31, 2017 and December 31, 2016:

[0000926326-18-000010:notes:29]
|  | December 31, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 25,899 |  |  | $ | 33,591 |  |
| Less: unearned interest income portion | (1,695 | ) |  | (2,763 | ) |
| Net investment in sales-type leases | 24,204 |  |  | 30,828 |  |
| Less: short-term portion(1) | (8,769 | ) |  | (10,243 | ) |
| Long-term net investment in sales-type leases | $ | 15,435 |  |  | $ | 20,585 |  |

[0000926326-18-000010:notes:30]
(1) The short-term portion of the net investments in sales-type leases is included in the other current assets on the Consolidated Balance Sheets.

[0000926326-18-000010:notes:31]
The Company evaluates its sales-type leases individually and collectively for impairment. The allowance for credit losses were $0.2 million and $0.3 million as of December 31, 2017 and December 31, 2016, respectively.

[0000926326-18-000010:notes:32]
At December 31, 2017, the future minimum lease payments to be received under sales-type leases are as follows:

[0000926326-18-000010:notes:33]
| Year ended December 31, | (In thousands) |
| 2018 | $ | 8,769 |  |
| 2019 | 6,708 |  |
| 2020 | 4,772 |  |
| 2021 | 2,992 |  |
| 2022 | 2,265 |  |
| Thereafter | 393 |  |
| Total | $ | 25,899 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000926326-18-000010:notes:34]
Cash and Cash Equivalents and Fair Value of Financial Instruments. The Company classifies investments as cash equivalents if their original or remaining contractual maturity is three months or less at the date of purchase. Cash equivalents are carried at amounts that approximate fair value due to the short period of time to maturity. The Company's cash balances are maintained in demand deposit accounts with financial institutions of high credit quality. The Company continuously monitors the credit worthiness of the financial institutions in which it invests. The Company has not experienced any credit losses from its cash investments.


## us-gaap:CommissionsExpensePolicyPolicyTextBlock

[0000926326-18-000010:notes:35]
Commissions

[0000926326-18-000010:notes:36]
Sales commissions are incremental and directly related to customer sales contracts in which revenue is deferred. These commission costs are accrued and recorded in prepaid expenses upon execution of a non-cancelable customer contract and subsequently expensed in the period of revenue recognition.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-18-000010:notes:37]
Commitments and Contingencies

[0000926326-18-000010:notes:38]
Lease commitments

[0000926326-18-000010:notes:39]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. Rent expense was $11.5 million, $9.8 million and $7.0 million for the years ended December 31, 2017, December 31, 2016 and December 31, 2015, respectively.

[0000926326-18-000010:notes:40]
The minimum future payments on non-cancelable operating leases are as follows:

[0000926326-18-000010:notes:41]
| For the year ended December 31, | (In thousands) |
| 2018 | $ | 12,167 |  |
| 2019 | 11,945 |  |
| 2020 | 10,755 |  |
| 2021 | 10,471 |  |
| 2022 | 8,776 |  |
| Thereafter | 26,243 |  |
| Total minimum future lease payments | $ | 80,357 |  |

[0000926326-18-000010:notes:42]
Purchase obligations

[0000926326-18-000010:notes:43]
In the ordinary course of business, we issue purchase orders based on our current manufacturing needs. As of December 31, 2017, the Company had non-cancelable purchase commitments of $58.1 million, which are expected to be paid within the next twelve months.

[0000926326-18-000010:notes:44]
Legal proceedings

[0000926326-18-000010:notes:45]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-18-000010:notes:46]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al. (Case No. CL18-152-1). The complaint seeks monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention and training and, as against the Company and Aesynt, claims of product liability, negligence and breach of implied warranties. The Company and Aesynt have not yet been served with the complaint. The Company intends to defend the lawsuit vigorously.

[0000926326-18-000010:notes:47]
Guarantees

[0000926326-18-000010:notes:48]
As permitted under Delaware law and the Company's certificate of incorporation and bylaws, the Company has agreed to indemnify its directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become its directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that the Company could be required to make under these indemnification agreements. The Company has purchased a directors’ and officers’ liability insurance policy that may enable it to recover a portion of any future payments that it may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-18-000010:notes:49]
Additionally, the Company undertakes indemnification obligations in its ordinary course of business in connection with, among other things, the licensing of its products and the provision of its support services. In the ordinary course of the Company's business, the Company has in the past and may in the future agree to indemnify another party, generally its business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, its gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, the Company attempts to limit the maximum potential amount of future payments that it may be required to make under these indemnification obligations to the amounts paid to it by a customer, but in some cases the obligation may not be so limited. In addition, the Company has in the past and may in the future warrant to its customers that its products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that its software media is free from material defects. Sales contracts for certain of the Company's medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances the Company records have historically been immaterial.

[0000926326-18-000010:notes:50]
From time to time, the Company may also warrant that its professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. The Company generally seeks to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, the Company would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. The Company has not been subject to any significant claims for such losses and has not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of December 31, 2017 and December 31, 2016.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-18-000010:notes:51]
Employee Benefits and Share-Based Compensation

[0000926326-18-000010:notes:52]
Stock purchase plan

[0000926326-18-000010:notes:53]
1997 Employee Stock Purchase Plan

[0000926326-18-000010:notes:54]
The Company has an Employee Stock Purchase Plan ("ESPP"), under which employees can purchase shares of its common stock based on a percentage of their compensation, but not greater than 15% of their earnings; provided, however, an eligible employee's right to purchase shares of the Company's common stock may not accrue at a rate which exceeds $25,000 of the fair market value of such shares for each calendar year in which such rights are outstanding. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-18-000010:notes:55]
There was a total of 2.4 million shares reserved for future issuance under the ESPP as of December 31, 2017.

[0000926326-18-000010:notes:56]
Stock award plans

[0000926326-18-000010:notes:57]
2009 Equity Incentive Plan

[0000926326-18-000010:notes:58]
The 2009 Equity Incentive Plan (“2009 Plan”), as amended, provides for the issuance of incentive stock options, restricted stock awards ("RSAs"), restricted stock unit awards ("RSUs"), performance stock unit awards ("PSUs"), and other stock awards to the Company's employees, directors and consultants. There were 5.5 million shares of common stock reserved for future issuance under the 2009 Plan as of December 31, 2017.

[0000926326-18-000010:notes:59]
Options granted under the 2009 Plan become exercisable over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 36 equal monthly installments thereafter. The exercise prices of the options is the fair market value of common stock on the date of grant. RSUs generally vest over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 12 equal quarterly installments thereafter. Awards of restricted stock to non-employee directors are granted on the date of the annual meeting of stockholders and vest in full on the date of the next annual meeting of stockholders, provided such non-employee director remains a director on such date. The fair value of the awards on the date of issuance is amortized to expense from the date of grant to the date of vesting and are expensed ratably on a straight-line basis over the vesting period. PSUs granted to the Company’s executives might include performance and market conditions. PSUs become eligible for vesting when certain market or performance conditions are met.

[0000926326-18-000010:notes:60]
Share-based compensation expense

[0000926326-18-000010:notes:61]
The following table sets forth the total share-based compensation expense recognized in the Company's Consolidated Statements of Operations:

[0000926326-18-000010:notes:62]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 3,478 |  |  | $ | 2,596 |  |  | $ | 2,111 |  |
| Research and development | 3,590 |  |  | 3,128 |  |  | 2,060 |  |
| Selling, general and administrative | 14,789 |  |  | 13,776 |  |  | 10,750 |  |
| Total share-based compensation expense | $ | 21,857 |  |  | $ | 19,500 |  |  | $ | 14,921 |  |

[0000926326-18-000010:notes:63]
The Company did not capitalize any share-based compensation as inventory as such amounts were not material for the years ended December 31, 2017, December 31, 2016 and December 31, 2015. Income tax benefits realized from share-based compensation were $8.2 million, $5.4 million and $5.0 million, for the years ended December 31, 2017, December 31, 2016 and December 31, 2015, respectively.

[0000926326-18-000010:notes:64]
Stock Options and ESPP Shares

[0000926326-18-000010:notes:65]
The following assumptions were used to value share options and ESPP shares granted pursuant to our equity incentive

[0000926326-18-000010:notes:66]
plans:

[0000926326-18-000010:notes:67]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Stock Option Plans |  |  |  |  |  |
| Risk-free interest rate | 1.9 | % |  | 1.5 | % |  | 1.7 | % |
| Dividend yield | — | % |  | — | % |  | — | % |
| Expected volatility | 29.6 | % |  | 30.6 | % |  | 32.0 | % |
| Expected life (in years) | 4.7 years |  |  | 4.9 years |  |  | 5.0 years |  |

[0000926326-18-000010:notes:68]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Employee Stock Purchase Plan |  |  |  |  |  |
| Risk-free interest rate | 0.52% - 1.39% |  |  | 0.34% - 0.79% |  |  | 0.03% - 0.79% |  |
| Dividend yield | — | % |  | — | % |  | — | % |
| Expected volatility | 25.8% - 32.8% |  |  | 25.8% - 34.8% |  |  | 25.7% - 37.5% |  |
| Expected life (in years) | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |

[0000926326-18-000010:notes:69]
Stock options activity

[0000926326-18-000010:notes:70]
A summary of the stock option activity under the 2009 Plan is presented below:

[0000926326-18-000010:notes:71]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2016 | 3,214 |  |  | $ | 26.06 |  |  | 7.3 |  | $ | 26,331 |  |
| Granted (Awarded) | 1,045 |  |  | $ | 45.13 |  |  |  |  |  |
| Exercised (Released) | (813 | ) |  | $ | 22.28 |  |  |  |  |  |
| Expired | (6 | ) |  | $ | 27.54 |  |  |  |  |  |
| Forfeited | (117 | ) |  | $ | 33.39 |  |  |  |  |  |
| Outstanding at December 31, 2017 | 3,323 |  |  | 32.72 |  |  | 7.6 |  | $ | 53,953 |  |
| Exercisable at December 31, 2017 | 1,350 |  |  | 23.87 |  |  | 5.8 |  | 33,293 |  |
| Vested and expected to vest at December 31, 2017 and thereafter | 3,323 |  |  | 32.72 |  |  | 7.6 |  | $ | 53,953 |  |

[0000926326-18-000010:notes:72]
The weighted-average fair value per share of options granted during 2017, 2016 and 2015 was $13.25, $9.33 and $9.67, respectively. The intrinsic value of options exercised during 2017, 2016 and 2015 was $18.2 million, $5.6 million and $11.3 million, respectively.

[0000926326-18-000010:notes:73]
As of December 31, 2017, total unrecognized compensation cost related to unvested stock options was $18.9 million, which is expected to be recognized over a weighted-average vesting period of 2.9 years. As of December 31, 2016, total unrecognized compensation cost related to unvested stock options was $13.3 million, which is expected to be recognized over a weighted-average vesting period of 3.0 years.

[0000926326-18-000010:notes:74]
Employee Stock Purchase Plan activity

[0000926326-18-000010:notes:75]
For the year ended December 31, 2017, employees purchased 0.5 million shares of common stock under the ESPP and an aggregate of 6.0 million shares were issued under the ESPP as of December 31, 2017.

[0000926326-18-000010:notes:76]
The unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $0.9 million, and is expected to be recognized over a weighted-average period of 1.3 years as of December 31, 2017.

[0000926326-18-000010:notes:77]
Restricted Stock Units and Restricted Stock Awards

[0000926326-18-000010:notes:78]
Summaries of the restricted stock activity under the 2009 Plan are presented below:

[0000926326-18-000010:notes:79]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units |  |  |  |  |  |  |  |
| Non-vested at December 31, 2016 | 505 |  |  | $ | 31.42 |  |  | 1.6 |  | $ | 17,135 |  |
| Granted (Awarded) | 245 |  |  | 45.97 |  |  |  |  |  |
| Vested (Released) | (215 | ) |  | 30.41 |  |  |  |  |  |
| Forfeited | (34 | ) |  | 32.39 |  |  |  |  |  |
| Non-vested at December 31, 2017 | 501 |  |  | 38.90 |  |  | 1.5 |  | $ | 24,293 |  |

[0000926326-18-000010:notes:80]
The weighted-average grant date fair value per share of RSUs granted during 2017, 2016 and 2015 was $45.97, $32.58 and $31.44, respectively. The total fair value of RSUs that vested in 2017, 2016 and 2015 was $6.5 million, $4.8 million and $4.7 million, respectively.

[0000926326-18-000010:notes:81]
As of December 31, 2017, total unrecognized compensation cost related to RSUs was $16.1 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.7 years. As of December 31, 2016, total unrecognized compensation cost related to RSUs was $12.8 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.9 years.

[0000926326-18-000010:notes:82]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards |  |  |  |
| Non-vested at December 31, 2016 | 30 |  |  | $ | 31.57 |  |
| Granted (Awarded) | 23 |  |  | 41.10 |  |
| Vested (Released) | (30 | ) |  | 31.58 |  |
| Non-vested at December 31, 2017 | 23 |  |  | $ | 41.07 |  |

[0000926326-18-000010:notes:83]
The weighted-average grant date fair value per share of RSAs granted during 2017, 2016 and 2015 was $41.10, $31.59 and $36.05, respectively. The total fair value of RSAs that vested in 2017, 2016 and 2015 was $1.0 million, $1.2 million and $1.1 million, respectively.

[0000926326-18-000010:notes:84]
As of December 31, 2017, total unrecognized compensation cost related to RSAs was $0.3 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.4 years. As of December 31, 2016, total unrecognized compensation cost related to RSAs was $0.4 million, which was expected to be recognized over the remaining weighted-average vesting period of 0.4 years.

[0000926326-18-000010:notes:85]
Performance-based Restricted Stock Units

[0000926326-18-000010:notes:86]
In 2011, the Company began incorporating performance-based restricted stock units ("PSUs") as an element of its executive compensation plans. In 2016, the Company granted 122,740 PSUs to its executive officers, all of which became eligible for vesting upon the achievement of a certain level of shareholder return. In 2017, the Company granted 147,830 PSUs to its executive officers, all, none or a portion of which may become eligible for vesting depending on the level of shareholder return for the period from March 1, 2017 through March 1, 2018.

[0000926326-18-000010:notes:87]
The fair value of a PSU award is determined using a Monte Carlo simulation model. The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of each of the other companies in the NASDAQ Healthcare Index (the "Index").

[0000926326-18-000010:notes:88]
For PSUs granted on February 8, 2017, stock price appreciation is calculated based on the trailing 20-day average stock price just prior to the first trading day of March 2017, compared to the trailing 20-day average stock price just prior to the first trading day of March 2018. For PSUs granted on February 4, 2016, stock price appreciation is calculated based on the trailing 20-day average stock price just prior to the first trading day of March 2016, compared to the trailing 20-day average stock price just prior to the first trading day of March 2017.

[0000926326-18-000010:notes:89]
On March 7, 2016, the Compensation Committee confirmed 66.0% as the percentile rank of the Company's 2016 total stockholder return. This resulted in 100% of the 2015 PSUs, or 60,000 shares, as eligible for further time-based vesting. The eligible PSUs will vest as follows: 25% of the eligible shares vested immediately on March 7, 2016 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three-year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service. Of the 60,000 shares eligible for time-based vesting under the 2015 PSUs, 45,000 shares have vested as of December 31, 2017.

[0000926326-18-000010:notes:90]
On March 7, 2017, the Compensation Committee confirmed 71.5% as the percentile rank of the Company's 2017 total stockholder return. This resulted in 100% of the 2016 PSUs, or 122,740 shares, as eligible for further time-based vesting. The eligible PSUs will vest as follows: 25% of the shares vested immediately on March 7, 2017 with the remaining shares vesting on a semi-annual basis period of 36 months commencing on June 15, 2017. Vesting is contingent upon continued service. Of the 122,740 shares eligible for time-based vesting under the 2016 PSUs, 61,375 shares have vested as of December 31, 2017.

[0000926326-18-000010:notes:91]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below:

[0000926326-18-000010:notes:92]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Non-vested at December 31, 2016 | 184 |  |  | $ | 24.89 |  |
| Granted (Awarded) | 148 |  |  | 34.05 |  |
| Vested (Released) | (107 | ) |  | 24.36 |  |
| Non-vested at December 31, 2017 | 225 |  |  | $ | 31.18 |  |

[0000926326-18-000010:notes:93]
The weighted-average grant date fair value per share of PSUs granted during 2017, 2016 and 2015 was $34.05, $24.66 and $29.56, respectively. The total fair value of PSUs that vested in 2017, 2016 and 2015 was $2.6 million, $2.0 million and $1.9 million, respectively.

[0000926326-18-000010:notes:94]
As of December 31, 2017, total unrecognized compensation cost related to PSUs was approximately $2.7 million, which is expected to be recognized over the remaining weighted-average period of 1.2 years. As of December 31, 2016, total unrecognized compensation cost related to PSUs was approximately $1.6 million, which was expected to be recognized over the remaining weighted-average period of 1.2 years.

[0000926326-18-000010:notes:95]
Summary of Shares Reserved for Future Issuance under Equity Incentive Plans

[0000926326-18-000010:notes:96]
401(k) Plan

[0000926326-18-000010:notes:97]
The Company has established a pre-tax savings plan under Section 401(k) of the Internal Revenue Code. The 401(k) Plan allows eligible employees in the United States to voluntarily contribute a portion of their pre-tax salary, subject to a maximum limit specified in the Internal Revenue Code. The Company matches 50% of employee contributions up to $2,500, annually. The Company's contributions under this plan were $3.8 million, $1.9 million and $1.8 million in 2017, 2016 and 2015, respectively.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-18-000010:notes:98]
Principles of consolidation

[0000926326-18-000010:notes:99]
The accompanying Consolidated Financial Statements have been prepared in accordance with U.S. GAAP and include all adjustments necessary for the fair presentation of the Company's consolidated financial position, results of operations and cash flows for the periods presented. The Consolidated Financial Statements include the Company's accounts as well as those of its wholly owned subsidiaries after the elimination of intercompany balances and transactions.


## us-gaap:DebtDisclosureTextBlock

[0000926326-18-000010:notes:100]
Debt and Credit Agreements

[0000926326-18-000010:notes:101]
2016 Senior Secured Credit Facility

[0000926326-18-000010:notes:102]
On January 5, 2016, the Company entered into a $400 million senior secured credit facility pursuant to a credit agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200 million, which was subsequently  increased pursuant to an amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-18-000010:notes:103]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the 2016 Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s consolidated total net leverage ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-18-000010:notes:104]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity as described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-18-000010:notes:105]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement. The Company was in full compliance with all covenants as of December 31, 2017.

[0000926326-18-000010:notes:106]
On January 5, 2016, the Company borrowed the full $200 million under the Term Loan Facility and $55 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses. On December 2, 2016, the Company borrowed an additional $40 million under the Revolver Credit Facility to complete the Ateb acquisition and pay related fees and expenses. During the year ended December 31, 2017, the Company borrowed $59.0 million under the Revolving Credit Facility to pay for the InPharmics acquisition and fund its operations. As of December 31, 2017 the Company has repaid $137.0 million borrowed under these Facilities which includes $102.5 million repaid during the year ended December 31, 2017.

[0000926326-18-000010:notes:107]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement (the "Amended Credit Agreement"). Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

[0000926326-18-000010:notes:108]
On December 26, 2017, the parties entered into another amendment (the "Amendment") to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.

[0000926326-18-000010:notes:109]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs which included an additional $2.1 million of incurred costs in connection with the Amendment signed in December 2017. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $6.3 million, $5.3 million and zero for the years ended December 31, 2017, December 31, 2016 and December 31, 2015, respectively.

[0000926326-18-000010:notes:110]
The components of the Company’s debt obligations as of December 31, 2017 and December 31, 2016 are as follows:

[0000926326-18-000010:notes:111]
|  | December 31, 2016 | Additions/Borrowings | Repayment / Amortization | December 31, 2017 |
|  | (In thousands) |
| Term loan facility | $ | 192,500 |  | $ | — |  | $ | (10,000 | ) | $ | 182,500 |  |
| Revolving credit facility | 68,000 |  | 59,000 |  | (92,500 | ) | 34,500 |  |
| Total debt under the facilities | 260,500 |  | 59,000 |  | (102,500 | ) | 217,000 |  |
| Less: Deferred issuance cost | (6,359 | ) | (2,106 | ) | 1,590 |  | (6,875 | ) |
| Total Debt, net of deferred issuance cost | $ | 254,141 |  | $ | 56,894 |  | $ | (100,910 | ) | $ | 210,125 |  |
| Long term debt, current portion, net of deferred issuance cost | 8,410 |  |  |  | 15,208 |  |
| Long term debt, net of deferred issuance cost | $ | 245,731 |  |  |  | $ | 194,917 |  |

[0000926326-18-000010:notes:112]
As of December 31, 2017, the carrying amount of debt of $217.0 million approximates the comparable fair value of $220.9 million. The Company's debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments, and long-term credit ratings.

[0000926326-18-000010:notes:113]
2013 Credit Agreement

[0000926326-18-000010:notes:114]
In September 2013, the Company entered into a credit agreement (the "2013 Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time party thereto. On January 5, 2016, this 2013 Credit Agreement was replaced by the credit facilities discussed above.


## us-gaap:DebtPolicyTextBlock

[0000926326-18-000010:notes:115]
Debt. The Company has entered into a Credit Agreement which provides for (a) a five-year revolving credit facility and (b) a five-year term loan facility (Facilities). The amount borrowed under these facilities is recorded at its carrying value at December 31, 2017. The fair value at December 31, 2017 approximates the carrying value.


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-18-000010:notes:116]
Deferred Revenue

[0000926326-18-000010:notes:117]
Short-term deferred revenue of $86.1 million and $87.5 million includes deferred revenue from product sales and service contracts, net of deferred cost of sales of $16.9 million and $14.2 million as of December 31, 2017 and December 31, 2016, respectively. The short-term deferred revenues from product sales relate to the delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

[0000926326-18-000010:notes:118]
Long-term deferred revenue includes deferred revenue from the service contracts of $17.2 million and $17.1 million, as of December 31, 2017 and December 31, 2016, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0000926326-18-000010:notes:119]
Foreign currency forward contracts. The Company enters into foreign currency forward contracts to protect its business from the risk that exchange rates may affect the eventual cash flows resulting from intercompany transactions between Omnicell and its foreign subsidiaries. These transactions primarily arise as a result of products manufactured in the United States ("U.S") and sold to foreign subsidiaries in U.S. dollars rather than the subsidiaries' functional currencies. These forward contracts are considered to be financial derivative instruments and are recorded at fair value. Changes in fair values of these financial derivative instruments are either recognized in other comprehensive income or net income depending on whether the derivative has been designated and qualifies as a hedging instrument.

[0000926326-18-000010:notes:120]
Interest rate swap agreements. During 2016, the Company entered into an interest rate swap agreement. The interest rate swap agreement, at its inception, qualified for and were designated as cash flow hedging instrument. In accordance with the Derivatives and Hedging Topic of the Accounting Standards Codification, the Company records its interest rate swaps on its consolidated balance sheet at fair value. The effective portion of changes in fair value are recorded in accumulated other comprehensive loss and are subsequently reclassified into earnings in the period that the hedged forecasted transaction affects earnings. Any ineffective portion is recognized in earnings. Both at inception and on a quarterly basis, the Company performs an effectiveness test.


## us-gaap:EarningsPerShareTextBlock

[0000926326-18-000010:notes:121]
Net Income Per Share

[0000926326-18-000010:notes:122]
Basic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. Diluted net income per share is computed by dividing net income for the period by the weighted-average number of shares, less shares repurchased, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. The anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share.

[0000926326-18-000010:notes:123]
The calculation of basic and diluted net income per share is as follows:

[0000926326-18-000010:notes:124]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands, except per share data) |
| Net income | $ | 20,605 |  |  | $ | 603 |  |  | $ | 30,760 |  |
| Weighted-average shares outstanding — basic | 37,483 |  |  | 36,156 |  |  | 35,857 |  |
| Add: Dilutive effect of employee stock plans | 1,229 |  |  | 708 |  |  | 861 |  |
| Weighted-average shares outstanding — diluted | 38,712 |  |  | 36,864 |  |  | 36,718 |  |
| Net income per share — basic | $ | 0.55 |  |  | $ | 0.02 |  |  | $ | 0.86 |  |
| Net income per share — diluted | $ | 0.53 |  |  | $ | 0.02 |  |  | $ | 0.84 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 501 |  |  | 1,345 |  |  | 555 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-18-000010:notes:125]
The following table represents the fair value hierarchy of the Company’s financial assets measured at fair value as of December 31, 2017:

[0000926326-18-000010:notes:126]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 1,378 |  |  | $ | — |  |  | $ | 1,378 |  |
| Total financial assets | $ | — |  |  | $ | 1,378 |  |  | $ | — |  |  | $ | 1,378 |  |

[0000926326-18-000010:notes:127]
The following table represents the fair value hierarchy of the Company’s financial assets measured at fair value as of December 31, 2016:

[0000926326-18-000010:notes:128]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 1,245 |  |  | $ | — |  |  | $ | 1,245 |  |
| Total financial assets | $ | — |  |  | $ | 1,245 |  |  | $ | — |  |  | $ | 1,245 |  |
| Contingent consideration liability | — |  |  | — |  |  | 2,400 |  |  | 2,400 |  |
| Total financial liabilities | $ | — |  |  | $ | — |  |  | $ | 2,400 |  |  | $ | 2,400 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-18-000010:notes:129]
Cash and Cash Equivalents and Fair Value of Financial Instruments

[0000926326-18-000010:notes:130]
Cash and cash equivalents of $32.4 million and $54.5 million as of December 31, 2017 and December 31, 2016, respectively, consisted of demand deposits only.

[0000926326-18-000010:notes:131]
Fair value hierarchy

[0000926326-18-000010:notes:132]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's interest rate swap contracts and foreign currency contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments. The Company's contingent consideration liability related to the Avantec acquisition and was classified as Level 3 as valuation inputs were unobservable in the market and significant to the instrument’s valuation. The Company determined the final payout amount for the remaining contingent consideration and reduced the liability from $3.0 million to $2.4 million. The reduction of the contingent liability resulted in a gain of $0.6 million which is recorded in the "Interest and other income (expense), net" line in the Consolidated Statement of Operations for the year ended December 31, 2016. During the year ended December 31, 2017, the Company concluded that the final payout had been earned and paid out $2.4 million during the third quarter of 2017.

[0000926326-18-000010:notes:133]
There have been no transfers between fair value measurement levels during the years ended December 31, 2017 and December 31, 2016.

[0000926326-18-000010:notes:134]
Foreign Currency Risk Management

[0000926326-18-000010:notes:135]
The Company operates in foreign countries, which expose it to market risk associated with foreign currency exchange rate fluctuations between the U.S. dollar and various foreign currencies, the most significant of which is the British Pound and the Euro. In order to manage foreign currency risk, at times the Company enters into foreign exchange forward contracts to mitigate risks associated with changes in spot exchange rates of mainly non-functional currency denominated assets or liabilities of the Company's foreign subsidiaries.  In general, the market risk related to these contracts is offset by corresponding gains and losses on the hedged transactions. By working only with major banks and closely monitoring current market conditions, the Company seeks to limit the risk that counterparties to these contracts may be unable to perform. The foreign exchange forward contracts are measured at fair value and reported as other current assets or accrued liabilities on the Consolidated Balance Sheets. The derivative instruments the Company uses to hedge this exposure are not designated as hedges. Any gains or losses on the foreign exchange forward contracts are recognized in earnings as Other Income/Expense in the period incurred in the Consolidated Statements of Operations. The Company does not enter into derivative contracts for trading purposes.

[0000926326-18-000010:notes:136]
At December 31, 2017 and December 31, 2016, the Company had no outstanding foreign exchange forward contracts.

[0000926326-18-000010:notes:137]
Interest Rate Swap Contracts

[0000926326-18-000010:notes:138]
The Company uses interest rate swap agreements to protect the Company against adverse fluctuations in interest rates by reducing its exposure to variability in cash flows relating to interest payments on a portion of its outstanding debt. The Company's interest rate swaps, which are designated as cash flow hedges, involve the receipt of variable amounts from counterparties in exchange for the Company making fixed-rate payments over the life of the agreements. The Company does not hold or issue any derivative financial instruments for speculative trading purposes.

[0000926326-18-000010:notes:139]
During 2016, the Company entered into an interest rate swap agreement with a combined notional amount of $100.0 million with one counter-party that is effective beginning on June 30, 2016 and maturing on April 30, 2019. The swap agreement requires the Company to pay a fixed rate of 0.8% and provides that the Company will receive a variable rate based on the one month LIBOR rate subject to LIBOR floor of 0.0%. Amounts payable by or due to the Company will be net settled with the respective counter-party on the last business day of each month, commencing July 31, 2016.

[0000926326-18-000010:notes:140]
The fair value of the interest rate swap agreements at December 31, 2017 and December 31, 2016 was $1.4 million and $1.2 million, respectively. There were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000926326-18-000010:notes:141]
Foreign currency translation and remeasurement

[0000926326-18-000010:notes:142]
Most of the Company's foreign subsidiaries use the local currency of their respective countries as their functional currency. The Company translates the assets and liabilities of such non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recorded as foreign currency translation adjustments and included in accumulated other comprehensive income (loss) in stockholders’ equity.

[0000926326-18-000010:notes:143]
The Company’s foreign subsidiaries that use the U.S. dollar as their functional currency remeasure monetary assets and liabilities at exchange rates in effect at the end of each period, and non-monetary assets and liabilities at historical rates. Gains and losses from such foreign currency remeasurement are recorded in interest and other income (expense).


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-18-000010:notes:144]
Goodwill and Intangible Assets

[0000926326-18-000010:notes:145]
Goodwill

[0000926326-18-000010:notes:146]
The changes in the carrying amount of goodwill are as follows:

[0000926326-18-000010:notes:147]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2015 | $ | 54,316 |  |  | $ | 93,590 |  |  | $ | 147,906 |  |
| Additions (1) | 163,599 |  |  | 20,832 |  |  | 184,431 |  |
| Adjustments (2) | (2,833 | ) |  | (1,780 | ) |  | (4,613 | ) |
| Net balance as of December 31, 2016 | 215,082 |  |  | 112,642 |  |  | 327,724 |  |
| Additions (3) | 3,113 |  |  | 3,400 |  |  | 6,513 |  |
| Adjustments (2) | 2,656 |  |  | 858 |  |  | 3,514 |  |
| Net balance as of December 31, 2017 | $ | 220,851 |  |  | $ | 116,900 |  |  | $ | 337,751 |  |

[0000926326-18-000010:notes:148]
_________________________________________________

[0000926326-18-000010:notes:149]
(1)  Additions to goodwill as a result of the Aesynt acquisition in January 2016 and Ateb acquisition in December 2016.

[0000926326-18-000010:notes:150]
(2)  Adjustments reflect foreign currency exchange rate fluctuations.

[0000926326-18-000010:notes:151]
(3)  Additions to goodwill in Automation and Analytics segment was a result of the InPharmics acquisition in April 2017. Additions to goodwill in Medication Adherence segment represent adjustments to the preliminary value assigned to goodwill in connection with Ateb acquisition to reflect measurement period adjustments related to accounts receivable, other non-current assets and other liabilities of $0.1 million, $0.7 million and $2.6 million, respectively.

[0000926326-18-000010:notes:152]
Intangible assets, net

[0000926326-18-000010:notes:153]
The carrying amounts of intangible assets and useful lives as of December 31, 2017 were as follows:

[0000926326-18-000010:notes:154]
|  | December 31, 2017 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 133,913 |  |  | $ | (33,526 | ) |  | $ | 65 |  |  | $ | 100,452 |  |  | 1 - 30 |
| Acquired technology | 74,593 |  |  | (21,523 | ) |  | 34 |  |  | 53,104 |  |  | 3 - 20 |
| Backlog | 21,712 |  |  | (17,544 | ) |  | — |  |  | 4,168 |  |  | 1 - 4 |
| Trade names | 8,716 |  |  | (4,719 | ) |  | 6 |  |  | 4,003 |  |  | 1 - 12 |
| Patents | 3,296 |  |  | (1,418 | ) |  | 2 |  |  | 1,880 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (1,300 | ) |  | — |  |  | 600 |  |  | 3 |
| In process technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | - |
| Total intangibles assets, net | $ | 248,030 |  |  | $ | (80,030 | ) |  | $ | 107 |  |  | $ | 168,107 |  |  |  |

[0000926326-18-000010:notes:155]
The carrying amounts of intangible assets and useful lives as of December 31, 2016 were as follows:

[0000926326-18-000010:notes:156]
|  | December 31, 2016 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 133,358 |  |  | $ | (20,930 | ) |  | $ | (596 | ) |  | $ | 111,832 |  |  | 1 - 30 |
| Acquired technology | 73,599 |  |  | (13,287 | ) |  | (159 | ) |  | 60,153 |  |  | 3 - 20 |
| Backlog | 20,550 |  |  | (14,083 | ) |  | — |  |  | 6,467 |  |  | 1 - 3 |
| Trade names | 8,667 |  |  | (3,887 | ) |  | (31 | ) |  | 4,749 |  |  | 1 - 12 |
| Patents | 3,154 |  |  | (1,264 | ) |  | — |  |  | 1,890 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (608 | ) |  | — |  |  | 1,292 |  |  | 3 |
| In-process technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | - |
| Total intangibles assets, net | $ | 245,128 |  |  | $ | (54,059 | ) |  | $ | (786 | ) |  | $ | 190,283 |  |  |  |

[0000926326-18-000010:notes:157]
Amortization expense of intangible assets was $25.6 million, $36.1 million and $6.9 million for the years ended December 31, 2017, December 31, 2016 and December 31, 2015, respectively.

[0000926326-18-000010:notes:158]
The estimated future amortization expenses for intangible assets are as follows:

[0000926326-18-000010:notes:159]
| For the year ended December 31, | (In thousands) |
| 2018 | $ | 23,433 |  |
| 2019 | 17,953 |  |
| 2020 | 16,739 |  |
| 2021 | 15,439 |  |
| 2022 | 13,973 |  |
| Thereafter (excluding in-process technology) | 76,670 |  |
| Total | $ | 164,207 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000926326-18-000010:notes:160]
Goodwill and acquired intangible assets

[0000926326-18-000010:notes:161]
Goodwill. The Company reviews goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. The Company's reporting units are the same as its operating segments, which are Automation and Analytics and Medication Adherence. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. A qualitative assessment includes, among others, consideration of: (i) past, current and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this qualitative assessment indicates that it is more likely than not that impairment exists, or if the Company decides to bypass this option, it proceeds to the quantitative assessment. The quantitative assessment involves a comparison between the estimated fair values of the Company's reporting units with their respective carrying amounts including goodwill. If the carrying value exceeds estimated fair value, the Company will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill allocated to that reporting unit.

[0000926326-18-000010:notes:162]
To determine each reporting unit's fair value under the quantitative approach, the Company uses a combination of income and market approaches, equally weighting the two approaches, such as estimated discounted future cash flows of that reporting unit, multiples of earnings or revenues, and analysis of recent sales or offerings of comparable entities. The Company also considers its market capitalization on the date of the analysis to ensure the reasonableness of the sum of its reporting units’ fair value.

[0000926326-18-000010:notes:163]
The Company performed a quantitative impairment analysis as of October 1, 2017 for its Medication Adherence reporting unit. The Company determined that the fair value of this reporting unit exceeded the carrying value by more than 40%, and thus no impairment was indicated. Additionally, the Company performed a qualitative impairment assessment analysis as of October 1, 2017 for its Automation and Analytics reporting unit taking into consideration past, current and projected future earnings, recent trends and market conditions; and valuation metrics involving similar companies that are publicly-traded. Based on the result of this analysis an impairment does not exist as of December 31, 2017.

[0000926326-18-000010:notes:164]
Intangible assets. In connection with the Company's acquisitions, it generally recognizes assets for customer relationships, backlog, developed technology, and trade names. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets, generally from one to 30 years. Amortization for developed technology and backlog is recognized in cost of revenues, and amortization for customer relationships, non-compete agreements, and trade names is recognized in selling, general and administrative expenses.

[0000926326-18-000010:notes:165]
The Company assesses the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset's carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. The Company's cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of the Company's intangible assets are subjective and are affected by changes to its business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of the Company's assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-18-000010:notes:166]
Income Taxes

[0000926326-18-000010:notes:167]
The following is a geographical breakdown of income (loss) before the provision for (benefit from) income taxes:

[0000926326-18-000010:notes:168]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Domestic | $ | 19,889 |  |  | $ | 1,471 |  |  | $ | 51,089 |  |
| Foreign | (20,768 | ) |  | (3,419 | ) |  | (4,845 | ) |
| Income (loss) before provision for (benefit from) income taxes | $ | (879 | ) |  | $ | (1,948 | ) |  | $ | 46,244 |  |

[0000926326-18-000010:notes:169]
The provision for (benefit from) income taxes consists of the following:

[0000926326-18-000010:notes:170]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Federal | $ | 2,430 |  |  | $ | 6,724 |  |  | $ | 13,840 |  |
| State | 1,852 |  |  | 1,323 |  |  | 2,475 |  |
| Foreign | 745 |  |  | 46 |  |  | 203 |  |
| Total current income taxes | 5,027 |  |  | 8,093 |  |  | 16,518 |  |
| Deferred: |  |  |  |  |  |
| Federal | (16,118 | ) |  | (3,378 | ) |  | 846 |  |
| State | (2,612 | ) |  | (1,802 | ) |  | (379 | ) |
| Foreign | (7,781 | ) |  | (5,464 | ) |  | (1,501 | ) |
| Total deferred income taxes | (26,511 | ) |  | (10,644 | ) |  | (1,034 | ) |
| Total provision for (benefit from) income taxes | $ | (21,484 | ) |  | $ | (2,551 | ) |  | $ | 15,484 |  |

[0000926326-18-000010:notes:171]
The provision for (benefit from) income taxes differs from the amount computed by applying the statutory federal tax rate as follows:

[0000926326-18-000010:notes:172]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| U.S. federal tax provision at statutory rate | $ | (308 | ) |  | $ | (682 | ) |  | $ | 16,181 |  |
| State taxes | 19 |  |  | (311 | ) |  | 1,365 |  |
| Non-deductible expenses | 1,373 |  |  | 1,212 |  |  | 551 |  |
| Acquisition costs | — |  |  | 845 |  |  | 239 |  |
| Share-based compensation expense | 39 |  |  | 1,941 |  |  | 748 |  |
| Research tax credits | (3,233 | ) |  | (2,075 | ) |  | (1,324 | ) |
| Domestic production deduction | (621 | ) |  | (890 | ) |  | (1,133 | ) |
| Gain on investment | — |  |  | — |  |  | (1,205 | ) |
| Tax audit settlement | — |  |  | (2,499 | ) |  | — |  |
| Foreign rate differential | 938 |  |  | (154 | ) |  | 123 |  |
| Stock option tax benefit | (5,926 | ) |  | — |  |  | — |  |
| One-time Impact of the Tax Act | (13,391 | ) |  | — |  |  | — |  |
| Other | (374 | ) |  | 62 |  |  | (61 | ) |
| Total provision for (benefit from) income taxes | $ | (21,484 | ) |  | $ | (2,551 | ) |  | $ | 15,484 |  |

[0000926326-18-000010:notes:173]
Significant components of the Company's deferred tax assets (liabilities) are as follows:

[0000926326-18-000010:notes:174]
|  | December 31, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| Deferred tax assets (liabilities): |  |  |  |
| Deferred revenue | $ | 6,345 |  |  | $ | 5,857 |  |
| Stock compensation | 4,460 |  |  | 6,451 |  |
| Inventory related items | 2,441 |  |  | 2,915 |  |
| Tax credit carry forwards | 9,349 |  |  | 4,871 |  |
| Reserves and accruals | 3,960 |  |  | 4,675 |  |
| Loss carry forwards | 8,643 |  |  | 8,077 |  |
| Other, net | 1,307 |  |  | 847 |  |
| Total net deferred tax assets | 36,505 |  |  | 33,693 |  |
| Intangibles | (36,780 | ) |  | (57,427 | ) |
| Depreciation and amortization | (14,338 | ) |  | (20,071 | ) |
| Prepaid expenses | (4,512 | ) |  | (3,746 | ) |
| Total deferred tax liabilities | (55,630 | ) |  | (81,244 | ) |
| Net deferred tax liabilities | $ | (19,125 | ) |  | $ | (47,551 | ) |

[0000926326-18-000010:notes:175]
Deferred income tax assets (liabilities) are provided for temporary differences that will result in future tax deductions or future taxable income, as well as the future benefit of tax credit carry forwards. The Company recognizes deferred tax assets to the extent that it believes these assets are more likely than not to be realized. In making such a determination, the Company considers all available positive and negative evidence, including future reversals of existing temporary differences, projected future taxable income, tax planning strategies, and results of recent operations. On the basis of this evaluation, as of December 31, 2017, no valuation allowances have been recorded in any jurisdiction.

[0000926326-18-000010:notes:176]
On December 22, 2017, the U.S. government enacted comprehensive tax legislation commonly referred to as the Tax Cuts and Jobs Act (the “Tax Act”). The Tax Act significantly impacts the future ongoing U.S. corporate income tax by, among things, lowering the U.S. corporate income tax rates and implementing a territorial tax system. At December 31, 2017, the Company has not completed the accounting for the tax effects of enactment of the Tax Act; however, the Company made a reasonable estimate of the effects on the existing deferred tax balances and the one-time transition tax. The reduction of the U.S. corporate tax rate required the Company to revalue the U.S. deferred tax assets and liabilities to the newly enacted federal rate of 21%. This resulted in a one-time benefit of $13.4 million in the fourth quarter of 2017. As part of the transition to the new territorial tax system, the Tax Act imposes a one-time tax on a deemed repatriation of historical earnings of foreign subsidiaries. Based on the current evaluation of the Company’s operations, no repatriation tax charge is anticipated as the Company is in an earnings deficit position for foreign subsidiaries. The Company will continue to assess the provision for income taxes as future guidance is issued, but does not currently anticipate significant revisions will be necessary. Any such revisions will be treated in accordance with the measurement period guidance outlined in Staff Accounting Bulletin No. 118.

[0000926326-18-000010:notes:177]
As of December 31, 2017, the Company has $6.6 million of federal net operating loss carryforwards expiring 2038 and $6.1 million of state net operating loss carryforwards expiring at various dates beginning 2023. For income tax purposes, the Company has federal and California research tax credits carryforwards of $2.4 million and $8.8 million, respectively. Federal research tax credit carry forwards from prior years will begin to expire in 2035. California credits are available indefinitely to reduce cash taxes otherwise payable.

[0000926326-18-000010:notes:178]
It is the Company's practice and intention to reinvest the earnings of its non-U.S. subsidiaries in those operations.  As of December 31, 2017, the Company has not made a provision for U.S. federal income, withholding, and state income taxes on the outside basis difference related to certain foreign subsidiaries because earnings are intended to be indefinitely reinvested in operations outside the U.S. At December 31, 2017, the Company has not completed the accounting for the tax effects resulting from the enactment of the Act; however, the Company made a reasonable estimate of the effects.  The Company is continuing to evaluate its plans for reinvestment under the Act, including its plans for reinvestment or repatriation of unremitted foreign earnings. Any revisions will be treated in accordance with the measurement period guidance outlined in Staff Accounting Bulletin No. 118.

[0000926326-18-000010:notes:179]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands and the United Kingdom. With few exceptions, as of December 31, 2017, the Company was no longer subject to U.S., state, and foreign examination for years before 2014, 2013, and 2014, respectively.

[0000926326-18-000010:notes:180]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for the three years ended December 31, 2017 is as follows:

[0000926326-18-000010:notes:181]
|  | (In thousands) |
| Year Ended December 31, 2014 | $ | 8,485 |  |
| Increases related to tax positions taken during a prior period | 37 |  |
| Decreases related to tax positions taken during the prior period | (895 | ) |
| Increases related to tax positions taken during the current period | 1,807 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (284 | ) |
| Year Ended December 31, 2015 | 9,150 |  |
| Increases related to tax positions taken during a prior period | 244 |  |
| Decreases related to tax positions taken during the prior period | (1,980 | ) |
| Increases related to tax positions taken during the current period | 6,724 |  |
| Decreases related to settlements | (2,178 | ) |
| Decreases related to expiration of statute of limitations | (344 | ) |
| Year Ended December 31, 2016 | 11,616 |  |
| Increases related to tax positions taken during a prior period | 503 |  |
| Decreases related to tax positions taken during the prior period | (1,782 | ) |
| Increases related to tax positions taken during the current period | 805 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (401 | ) |
| Year Ended December 31, 2017 | $ | 10,741 |  |

[0000926326-18-000010:notes:182]
As of December 31, 2017 the total amount of gross unrecognized tax benefits, if realized, would decrease the Company's tax expense by approximately $10.7 million. The Company recognizes interest and/or penalties related to uncertain tax positions in operating expenses accruing $0.3 million, $0.5 million, and $0.1 million for fiscal years 2017, 2016, and 2015 respectively. Accrued interest and penalties are included within other long-term liabilities on the consolidated balance sheets. The combined amount of cumulative accrued interest and penalties was approximately $1.4 million, $1.1 million, and $0.6 million as of fiscal years 2017, 2016, and 2015 respectively. The Company does not believe there will be any significant changes in its unrecognized tax positions over the next twelve months.


## us-gaap:IncomeTaxPolicyTextBlock

[0000926326-18-000010:notes:183]
Accounting for income taxes

[0000926326-18-000010:notes:184]
The Company records an income tax provision for (benefit from) the anticipated tax consequences of the reported results of operations. In accordance with U.S. GAAP, the provision for (benefit from) income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, the Company will incur a benefit or detriment on its income tax expense in the period of change. If the Company were to determine that all or part of the net deferred tax assets are not realizable in the future, it will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-18-000010:notes:185]
In accordance with ASC 740, Income Taxes, the Company recognizes the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of U.S. GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company's financial condition and operating results.


## us-gaap:InventoryPolicyTextBlock

[0000926326-18-000010:notes:186]
Inventory

[0000926326-18-000010:notes:187]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value.  Inbound shipping costs are included in cost of inventory. The Company regularly monitors inventory quantities on hand and records write-downs for excess and obsolete inventories based on the Company's estimate of demand for its products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Shipments from suppliers or contract manufacturers before the Company receives them are recorded as in-transit inventory when title and the significant risks and rewards of ownership have passed to the Company.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000926326-18-000010:notes:188]
Property and equipment, net

[0000926326-18-000010:notes:189]
Property and equipment, net is attributed to the geographic location in which it is located.

[0000926326-18-000010:notes:190]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| United States | $ | 34,899 |  |  | $ | 36,497 |  |  | $ | 29,506 |  |
| Rest of world (1) | 7,696 |  |  | 5,514 |  |  | 2,803 |  |
| Total property and equipment, net | $ | 42,595 |  |  | $ | 42,011 |  |  | $ | 32,309 |  |

[0000926326-18-000010:notes:191]
(1)No individual country represented more than 10% of the respective totals.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-18-000010:notes:192]
Recently adopted accounting standards

[0000926326-18-000010:notes:193]
In March 2016, the Financial Accounting Standards Board ("FASB") issued ASU No. 2016-09, Compensation-Stock Compensation (Topic 718). This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. The Company adopted the standard effective January 1, 2017. The impact of adoption was the recording of excess tax benefits within income tax expense, rather than in Additional Paid in Capital of $6.6 million for the year ended December 31, 2017. Additionally, in the first quarter of 2017, the Company recognized the previously unrecognized excess tax benefits using the modified retrospective transition method, which resulted in a cumulative-effect adjustment of $1.6 million to retained earnings.

[0000926326-18-000010:notes:194]
In January 2017, the FASB issued ASU 2017-04, Intangibles-Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment, which simplifies the accounting for goodwill impairment for all entities by requiring impairment charges to be based on the first step in today’s two-step impairment test under ASC 350, “Intangibles-Goodwill and Other.” Under the new guidance, if a reporting unit’s carrying amount exceeds its fair value, an entity will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill allocated to that reporting unit. ASU 2017-04 is effective for annual and interim impairment tests performed in periods beginning after December 15, 2019. Early adoption is permitted for annual and interim goodwill impairment testing dates after January 1, 2017. The Company adopted ASU 2017-04 effective January 1, 2017. The adoption of this authoritative guidance did not have impact on the Company's Consolidated Financial Statements or related disclosures for the periods presented.

[0000926326-18-000010:notes:195]
In January 2017, the FASB issued ASU 2017-01, Business Combinations, which clarifies the definition of a business and provides a screen to determine when a set of assets and activities is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set is not a business. ASU 2017-01 is effective for fiscal years beginning after December 15, 2017, with early adoption permitted. The Company adopted ASU 2017-01 effective January 1, 2017.  The adoption of this authoritative guidance did not have impact on the Company's Consolidated Financial Statements or related disclosures for the periods presented.

[0000926326-18-000010:notes:196]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815), which simplifies the application of the hedge accounting guidance and improves the financial reporting, specifically simplifies designation and measurement for qualifying hedging relationships and the presentation of hedge results. ASU 2017-12 is effective for annual periods beginning after December 15, 2018 and interim periods within those annual periods with early adoption permitted. The Company adopted ASU 2017-12 effective August 1, 2017. The adoption of this authoritative guidance did not have impact on the Company's Consolidated Financial Statements or related disclosures for the periods presented.

[0000926326-18-000010:notes:197]
Recently issued authoritative guidance

[0000926326-18-000010:notes:198]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers ("ASU 2014-09") related to revenue recognition. Under the standard, revenue is recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In addition, the standard requires disclosure of the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The standard will be effective for the Company beginning January 1, 2018.

[0000926326-18-000010:notes:199]
The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method). The Company will adopt the standard using the full retrospective method to adjust each prior reporting period presented in the footnote disclosures to the Consolidated Financial Statements.

[0000926326-18-000010:notes:200]
In preparation for adoption of the standard, the Company has implemented functionality changes in the revenue system and internal controls related to new standard adoption to enable the preparation, and reporting and disclosures of the financial information in accordance with the new standard upon the adoption and in future periods.

[0000926326-18-000010:notes:201]
The most significant impact of the standard relates to accounting for direct incremental contract acquisition costs, such as commission expense, term software license revenue and accounting for contingent revenue.

[0000926326-18-000010:notes:202]
The Company currently records the full commission expense in the consolidated statements of operations when commissions are both earned and revenue is recorded. The new revenue standard requires the Company to recognize incremental costs incurred to obtain a contract on a systematic basis that is consistent with the transfer to the customer of the product and services to which the cost relates, including an estimate of the period of service renewals for the transaction. The allocation of the costs between product and service and the estimation of a customer’s services period are management estimates and are based on the Company's historical experience. The Company will allocate commission costs between product and service revenue elements and recognize those when product revenue is recognized and over the estimated service period of 10 years, respectively. The Company expects that the impact of capitalized commissions will be approximately $19 million to $20 million as of December 31, 2017 will be recognized in sales and marketing expense in future periods.

[0000926326-18-000010:notes:203]
The Company expects to recognize the majority of revenue on term software licenses upon installation of the license rather than ratably over the life of the term license. The adoption of the standard will result in an increase in revenue of less than $2 million in 2016 and 2017 and a decrease in deferred revenue of less than $3 million as of December 31, 2017.

[0000926326-18-000010:notes:204]
The new standard no longer requires deferral of contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price which will result in earlier recognition of revenue. The Company is finalizing the impact on revenue, unbilled accounts receivable and deferred revenue of this adoption adjustment.

[0000926326-18-000010:notes:205]
The Company is currently finalizing the impact on tax expense and deferred taxes of these adoption adjustments.

[0000926326-18-000010:notes:206]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount and timing of cash flows from leases. This new guidance will be effective for us beginning on January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. The Company is currently evaluating the impact ASU 2016-02 will have on its consolidated financial statements.

[0000926326-18-000010:notes:207]
In October 2016, the FASB issued ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which reduces the complexity in the accounting standards by allowing the recognition of current and deferred income taxes for an intra-entity asset transfer, other than inventory, when the transfer occurs. Historically, recognition of the income tax consequence was not recognized until the asset was sold to an outside party.  This amendment should be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  ASU 2016-16 is effective for annual periods beginning after December 15, 2017, including interim reporting periods within those annual reporting periods. The Company does not expect application of the amended guidance to have a material effect on its consolidated financial statements.

[0000926326-18-000010:notes:208]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company's Consolidated Financial Statements through the reporting date.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-18-000010:notes:209]
Organization and Summary of Significant Accounting Policies

[0000926326-18-000010:notes:210]
Business

[0000926326-18-000010:notes:211]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company's major products are automated medication, supply control systems and medication adherence solutions which are sold in its principal market, which is the healthcare industry. The Company's market is primarily located in the United States and Europe. "Omnicell" or the "Company" refer to Omnicell, Inc. and its subsidiaries.

[0000926326-18-000010:notes:212]
On April 12, 2017, the Company completed its acquisition of Dixie Drawl, LLC d/b/a InPharmics ("InPharmics"). On December 8, 2016, the Company completed its acquisition of Ateb, Inc. and Ateb Canada Ltd. (together, “Ateb”). On January 5, 2016, the Company completed its acquisition of Aesynt Holding Cooperatief U.A. (“Aesynt”). On April 30, 2015, the Company acquired the remaining 85% of the issued and outstanding ordinary shares of Avantec Healthcare Limited (“Avantec”) not already held by Omnicell. On April 21, 2015, the Company completed its acquisition of Mach4 Automatisierungstechnik GmbH (“Mach4”). The consolidated financial statements include the results of operations of these recently acquired companies, commencing as of their respective acquisition dates. The significant accounting policies of the acquired businesses have been aligned to conform to the accounting policies of Omnicell.

[0000926326-18-000010:notes:213]
Certain prior year amounts in the Consolidated Statement of Cash Flows have been reclassified to conform to the 2017 presentation with the adoption of Accounting Standards Update ("ASU") 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. Additionally, see "Recently adopted authoritative guidance" section below for the effects of adoption of ASU 2016-09.

[0000926326-18-000010:notes:214]
Use of estimates

[0000926326-18-000010:notes:215]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company's Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company's critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, allowance for doubtful accounts and notes receivable from investment in sales-type leases, inventory valuation, capitalized software development costs, valuation and impairment of goodwill, purchased intangibles and long-lived assets, fair value of assets acquired and liabilities assumed in business combination, share-based compensation and accounting for income taxes.

[0000926326-18-000010:notes:216]
Segment reporting

[0000926326-18-000010:notes:217]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses. See Note 14, Segment and Geographical Information, for additional information on segment reporting.

[0000926326-18-000010:notes:218]
The operating results of the recently acquired InPharmics, Aesynt, Mach4 and Avantec businesses are included in the Company's Automation and Analytics reportable segment. The operating results of the recently acquired Ateb business is included in the Medication Adherence reportable segment.

[0000926326-18-000010:notes:219]
Revenue recognition

[0000926326-18-000010:notes:220]
The Company earns revenues from sales of its medication and medical and surgical supply automation systems along with consumables and related services, which are sold in the healthcare industry, its principal market. Revenues are reported net of discounts and rebates provided to its customers. The Company's customer arrangements typically include one or more of the following deliverables:

[0000926326-18-000010:notes:221]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

[0000926326-18-000010:notes:222]
Software. Additional software applications that enable incremental functionality of its equipment.

[0000926326-18-000010:notes:223]
Installation. Installation of equipment as integrated systems at customers' sites.

[0000926326-18-000010:notes:224]
Post-installation technical support. Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available.

[0000926326-18-000010:notes:225]
Professional services. Other customer services, such as training and consulting.

[0000926326-18-000010:notes:226]
The Company recognizes revenue when the earnings process is complete, based upon its evaluation of whether the following four criteria have been met:

[0000926326-18-000010:notes:227]
Persuasive evidence of an arrangement exists. The Company uses signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, the Company uses a signed services agreement and a statement of work to evidence an arrangement.

[0000926326-18-000010:notes:228]
Delivery has occurred. Equipment and embedded software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that the Company has delivered what a customer ordered. In instances of a customer self-installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, the Company recognizes revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. For existing distributors, where installation of equipment training has been previously provided and the distributor is certified to install the Company's equipment at the end-user customer facility, the Company recognizes revenue from sales of products to the distributor upon shipment assuming all other revenue criteria are met, net of allowance for rights of return or refund. For new distributors, where the Company has not provided installation of equipment training, revenue on the sales of products to the distributor is deferred until the distributor has completed the Distributor Training Program and has been certified to install the Company's equipment at the end-user facility. For the sale of consumable blister cards, the Company recognizes revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from the Company's facilities. Assuming all other revenue criteria are met, the Company recognizes revenue for support services ratably over the related support services contract period. The Company recognizes revenue on training and professional services as they are performed.

[0000926326-18-000010:notes:229]
Fee is fixed or determinable. The Company assesses whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. The Company has established a history of collecting under the original contract without providing concessions on payments, products or services.

[0000926326-18-000010:notes:230]
Collection is probable. The Company assesses the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in the Company's judgment, collection of a fee is not probable, the Company defers revenue recognition until the uncertainty is removed, which generally means revenue is recognized upon the Company's receipt of cash payment assuming all other revenue criteria are met. The Company's historical experience has been that collection from its customers is generally probable.

[0000926326-18-000010:notes:231]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, the Company recognizes revenue for individual delivered items if they have value to the customer on a standalone basis. The Company allocates arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires the Company to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, the Company uses vendor-specific objective evidence ("VSOE") of the selling price. VSOE represents the price charged for a deliverable when it is sold separately, or for a deliverable not yet being sold separately, the price established by management with the relevant authority. The Company considers VSOE to exist when approximately 80% or more of its standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). The Company has established VSOE of the selling price for its post-installation technical support services and professional services. When VSOE of selling price is not available, third-party evidence ("TPE") of selling price for similar products and services is acceptable; however, the Company's offerings and market strategy differ from those of its competitors, such that it cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, the Company uses its best estimates of selling prices ("BESP"). The Company determines BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. The Company regularly reviews and updates its VSOE and BESP information.

[0000926326-18-000010:notes:232]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable on the basis of its estimated selling price. In addition, the amount recognized for any delivered items cannot exceed that which is not contingent upon delivery of any remaining items in the arrangement.

[0000926326-18-000010:notes:233]
The Company also uses the residual method to allocate revenue between the software products that enable incremental equipment functionality, and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0000926326-18-000010:notes:234]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 33% of the lease receivable balance, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.

[0000926326-18-000010:notes:235]
The Company will adopt the ASU 2014-09, Revenue from Contracts with Customers, effective January 1, 2018.  Please refer to “Recently issued authoritative guidance” which is included in Note 1 of this report.

[0000926326-18-000010:notes:236]
Financial Instruments

[0000926326-18-000010:notes:237]
For assets and liabilities measured at fair value, the amounts are based on an expected exit price representing the amount that would be received from the sale of an asset or paid to transfer a liability in a transaction between market participants. The fair value may be based on assumptions that market participants would use in pricing an asset or liability. The authoritative guidance on fair value measurements establishes a consistent framework for measuring fair value on either a recurring or nonrecurring basis whereby inputs used in valuation techniques are assigned a hierarchical level. The following methods were used to estimate the fair value of each class of financial instruments for which it is practical to estimate that value:

[0000926326-18-000010:notes:238]
Interest rate swap agreements. During 2016, the Company entered into an interest rate swap agreement. The interest rate swap agreement, at its inception, qualified for and were designated as cash flow hedging instrument. In accordance with the Derivatives and Hedging Topic of the Accounting Standards Codification, the Company records its interest rate swaps on its consolidated balance sheet at fair value. The effective portion of changes in fair value are recorded in accumulated other comprehensive loss and are subsequently reclassified into earnings in the period that the hedged forecasted transaction affects earnings. Any ineffective portion is recognized in earnings. Both at inception and on a quarterly basis, the Company performs an effectiveness test. For further information regarding these interest rate swap agreements, please refer to Note 4, Cash and Cash Equivalents and Fair Value of Financial Instruments.

[0000926326-18-000010:notes:239]
Allowance for doubtful accounts and notes receivables from investment in sales-types leases

[0000926326-18-000010:notes:240]
The Company maintains an allowance for doubtful accounts for estimated losses resulting from the inability of its customers to make required payments. The Company records a specific allowance based on an analysis of individual past-due balances. Additionally, based on historical write-offs and the Company's collection experience, the Company records an additional allowance based on a percentage of outstanding receivables. The Company performs credit evaluations of its customers' financial condition. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history and a financial review of the customer. Actual collection losses may differ from management's estimates, and such differences could be material to the Company's financial position and results of operations.

[0000926326-18-000010:notes:241]
There were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of December 31, 2017 and December 31, 2016.

[0000926326-18-000010:notes:242]
The retained in-house leases discussed above are considered financing receivables. The Company's credit policies and its evaluation of credit risk and write-off policies are applied alike to trade receivables and the net investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class.

[0000926326-18-000010:notes:243]
Sales of accounts receivable

[0000926326-18-000010:notes:244]
The Company records the sale of its accounts receivables as in accordance with accounting guidance for transfers and servicing of financial assets. The Company transferred non-recourse accounts receivable totaling $40.0 million, $28.7 million and $38.6 million during fiscal year 2017, 2016, and 2015, respectively, which approximated fair value, to leasing companies on a non-recourse basis. Accounts receivable balance included approximately $0.1 million, $0.2 million and $0.8 million due from third-party leasing companies for transferred non-recourse accounts receivable as of December 31, 2017, December 31, 2016 and December 31, 2015, respectively.

[0000926326-18-000010:notes:245]
The Company has a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract with the Company's supplier may be terminated by either the supplier or by the Company without cause and at any time upon delivery of two months' notice. Purchases from this supplier were $64.5 million, $47.9 million and $41.7 million for the years ended December 31, 2017, December 31, 2016 and December 31, 2015, respectively.

[0000926326-18-000010:notes:246]
Property and equipment

[0000926326-18-000010:notes:247]
Property and equipment less accumulated depreciation are stated at historical cost. The Company's expenditures for property and equipment are primarily for computer equipment and software used in the administration of its business, and for leasehold improvements to its leased facilities. The Company also develops molds and dies used in long-term manufacturing arrangements with suppliers and for production automation equipment used in the manufacturing of consumable blister card components. Depreciation and amortization is computed by use of the straight-line method over the estimated useful lives of the assets as stated below:

[0000926326-18-000010:notes:248]
| Computer equipment and related software | 3 - 5 years |
| Leasehold and building improvements | Shorter of the lease term or the estimated useful life |
| Furniture and fixtures | 5 - 7 years |
| Equipment | 3 - 12 years |

[0000926326-18-000010:notes:249]
Depreciation and amortization of property and equipment was $16.2 million, $15.0 million and $12.8 million for the years ended December 31, 2017, December 31, 2016 and December 31, 2015, respectively.

[0000926326-18-000010:notes:250]
The Company capitalizes costs related to computer software developed or obtained for internal use in accordance with ASC 350-40, Internal-Use Software. Software obtained for internal use has generally been enterprise-level business and finance software that the Company customizes to meet its specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred. The Company capitalized $0.4 million and $2.2 million of costs related to the application development of enterprise-level software that was included in property and equipment during the years ended December 31, 2017 and December 31, 2016, respectively.

[0000926326-18-000010:notes:251]
Software development costs

[0000926326-18-000010:notes:252]
The Company capitalizes software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which certain software development costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. The Company establishes feasibility when it completes a working model and amortizes development costs over the estimated lives of the related products ranging from three to five years. The Company capitalized software development costs of $15.0 million and $14.3 million which are included in other assets as of December 31, 2017 and December 31, 2016, respectively. The Company recorded $9.7 million, $7.1 million and $5.8 million to cost of revenues for amortization of capitalized software development costs for the years ended December 31, 2017, December 31, 2016 and December 31, 2015, respectively. All development costs prior to the completion of a working model are recognized as research and development expense.

[0000926326-18-000010:notes:253]
Deferred revenue

[0000926326-18-000010:notes:254]
Deferred revenue arise when customers have been billed and/or have received products and/or services in advance of revenue recognition. The Company's deferred revenue, net, presented as short term consists of (i) unearned revenue on sale of equipment for which installation has not been completed, net of deferred cost of sales for such equipment, and (ii) the current portion of unearned service contracts for which revenue is recognized over their duration. Long-term deferred revenue includes long term portion of unearned service contracts.

[0000926326-18-000010:notes:255]
Business combinations

[0000926326-18-000010:notes:256]
The Company uses the acquisition method of accounting under the authoritative guidance on business combinations. Each acquired company’s operating results are included in the Company's Consolidated Financial Statements starting on the date of acquisition. The purchase price is equivalent to the fair value of consideration transferred. Tangible and identifiable intangible assets acquired and liabilities assumed as of the date of acquisition are recorded at the acquisition date fair value. Goodwill is recognized for the excess of purchase price over the net fair value of assets acquired and liabilities assumed.

[0000926326-18-000010:notes:257]
Amounts allocated to assets and liabilities are based upon fair values. Such valuations require management to make significant estimates and assumptions, especially with respect to the identifiable intangible assets. Management makes estimates of fair value based upon assumptions believed to be reasonable and that of a market participant. These estimates are based on historical experience and information obtained from the management of the acquired companies and the estimates are inherently uncertain. The separately identifiable intangible assets generally include customer relationships, technology, and trade names.

[0000926326-18-000010:notes:258]
The Company assesses the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset's carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. The Company's cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of the Company's intangible assets are subjective and are affected by changes to its business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of the Company's assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition. For the years ended December 31, 2017 and December 31, 2016, there were no events or changes in circumstances to indicate that intangible assets carrying amounts may not be recoverable.

[0000926326-18-000010:notes:259]
Valuation of share-based awards

[0000926326-18-000010:notes:260]
The Company accounts for share-based compensation in accordance with ASC 718, Stock Compensation ("ASC 718"). The Company recognizes compensation expense related to stock-based compensation based on the grant date estimated fair value.

[0000926326-18-000010:notes:261]
The fair value of stock options ("options") on the grant date is estimated using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of its common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on the Company's historical experience of employee stock option exercises, including forfeitures. Expense is recognized on a straight-line basis over the requisite service period.

[0000926326-18-000010:notes:262]
The fair value of Restricted Stock Units ("RSUs") is based on the stock price on the grant date. The fair value of Restricted Stock Awards (“RSAs”) is their intrinsic value, which is the difference between the fair value of the underlying stock at the measurement date and the purchase price. The RSUs and RSAs are subject to a service vesting condition and are recognized on a straight-line basis over the requisite service period.

[0000926326-18-000010:notes:263]
The fair value of PSUs with service and market conditions is estimated using a Monte Carlo simulation model applying multiple awards approach. Expense is recognized when it is probable that the performance condition will be met using the accelerated attribution method over the requisite service period.

[0000926326-18-000010:notes:264]
The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods.

[0000926326-18-000010:notes:265]
Sales commissions are incremental and directly related to customer sales contracts in which revenue is deferred. These commission costs are accrued and recorded in prepaid expenses upon execution of a non-cancelable customer contract and subsequently expensed in the period of revenue recognition. Commission expense was $19.4 million, $22.0 million and $13.7 million for the years ended December 31, 2017, December 31, 2016 and December 31, 2015, respectively.

[0000926326-18-000010:notes:266]
Group Purchasing Organizations

[0000926326-18-000010:notes:267]
The Company contracts with Group Purchasing Organizations (“GPOs”), each of which functions as a purchasing agent on behalf of member hospitals and other healthcare providers, as well as with government entities and agencies.  Pursuant to the terms of GPO agreements, each member contracts directly with Omnicell and can purchase Company’s product at pre-negotiated contract terms and pricing. The account receivable balances are with individual members of the GPOs, and therefore no significant concentration of credit risk exists.  During our fiscal year ended December 31, 2017 sales to members of the ten largest GPOs accounted for approximately 51% of total consolidated revenue.

[0000926326-18-000010:notes:268]
The fees related to GPOs for services provided are recognized as part of Sales, General and Administrative expenses. The Company expensed $7.4 million, $8.4 million and $5.9 million of GPO administrative fees for the years ended December 31, 2017, December 31, 2016 and December 31, 2015, respectively,

[0000926326-18-000010:notes:269]
Shipping costs

[0000926326-18-000010:notes:270]
Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general and administrative expense. Shipping and handling expenses were $13.6 million, $12.1 million and $8.5 million for the years ended December 31, 2017, December 31, 2016 and December 31, 2015, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-18-000010:notes:271]
Restructuring Expenses

[0000926326-18-000010:notes:272]
On February 15, 2017, the Company announced its plan to reduce its workforce by approximately 100 full-time employees and close the Company’s Nashville, Tennessee and Slovenia facilities, which was concluded in fiscal year 2017. The total cost for the plan was $4.2 million, which includes employee severance cost of approximately $3.7 million, and facility-related costs of approximately $0.6 million. At December 31, 2017 the unpaid balance under this plan is $0.4 million related to facilities-related expenses.

[0000926326-18-000010:notes:273]
In the second quarter of 2016, the Company integrated its sales and field organizations in North America to better serve its customers which resulted in a reduction in headcount of 36 employees. Accordingly, the Company incurred approximately $1.7 million of restructuring expenses in the year ended December 31, 2016, based on agreements with terminated employees covering salary and benefit continuation. For the year ended December 31, 2016, the Company made payments of $1.7 million and the restructuring program was concluded.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000926326-18-000010:notes:274]
Revenues

[0000926326-18-000010:notes:275]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | (In thousands) |
| United States | $ | 617,268 |  |  | $ | 591,566 |  |  | $ | 403,375 |  |
| Rest of world (1) | 98,897 |  |  | 101,057 |  |  | 81,184 |  |
| Total revenues | $ | 716,165 |  |  | $ | 692,623 |  |  | $ | 484,559 |  |

[0000926326-18-000010:notes:276]
___________________________________________


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000926326-18-000010:notes:277]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the years ended December 31, 2017 and December 31, 2016:

[0000926326-18-000010:notes:278]
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Balance as of December 31, 2015 | $ | (2,730 | ) |  | $ | — |  |  | $ | (2,730 | ) |
| Other comprehensive income (loss) before reclassifications | (8,034 | ) |  | 1,385 |  |  | (6,649 | ) |
| Amounts reclassified from other comprehensive income (loss) | — |  |  | (140 | ) |  | (140 | ) |
| Net current-period other comprehensive income (loss), net of tax | (8,034 | ) |  | 1,245 |  |  | (6,789 | ) |
| Balance as of December 31, 2016 | (10,764 | ) |  | 1,245 |  |  | (9,519 | ) |
| Other comprehensive income (loss) before reclassifications | 3,810 |  |  | 409 |  |  | 4,219 |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (813 | ) |  | (813 | ) |
| Net current-period other comprehensive income (loss), net of tax | 3,810 |  |  | (404 | ) |  | 3,406 |  |
| Balance as of December 31, 2017 | $ | (6,954 | ) |  | $ | 841 |  |  | $ | (6,113 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-18-000010:notes:279]
Balance sheet details as of December 31, 2017 and December 31, 2016 are presented in the tables below:

[0000926326-18-000010:notes:280]
|  | December 31, |
|  | 2017 |  | 2016 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 22,750 |  |  | $ | 14,322 |  |
| Work in process | 9,818 |  |  | 7,800 |  |
| Finished goods | 63,569 |  |  | 47,175 |  |
| Total inventories | $ | 96,137 |  |  | $ | 69,297 |  |
| Prepaid expenses |  |  |  |
| Prepaid commissions | $ | 15,671 |  |  | $ | 13,176 |  |
| Other prepaid expenses | 20,389 |  |  | 15,470 |  |
| Total prepaid expense | $ | 36,060 |  |  | $ | 28,646 |  |
| Property and equipment: |  |  |  |
| Equipment | $ | 69,550 |  |  | $ | 64,384 |  |
| Furniture and fixtures | 6,534 |  |  | 6,517 |  |
| Leasehold improvements | 10,976 |  |  | 9,778 |  |
| Software | 37,168 |  |  | 35,607 |  |
| Construction in progress | 9,813 |  |  | 7,211 |  |
| Property and equipment, gross | 134,041 |  |  | 123,497 |  |
| Accumulated depreciation and amortization | (91,446 | ) |  | (81,486 | ) |
| Total property and equipment, net | $ | 42,595 |  |  | $ | 42,011 |  |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 38,599 |  |  | $ | 33,233 |  |
| Other assets | 1,242 |  |  | 1,818 |  |
| Total other long term assets, net | $ | 39,841 |  |  | $ | 35,051 |  |
| Accrued liabilities: |  |  |  |
| Advance payments from customers | $ | 7,779 |  |  | $ | 7,030 |  |
| Rebates and lease buyouts | 5,428 |  |  | 4,025 |  |
| Group purchasing organization fees | 3,449 |  |  | 3,737 |  |
| Taxes payable | 9,183 |  |  | 4,003 |  |
| Other accrued liabilities | 9,854 |  |  | 12,400 |  |
| Total accrued liabilities | $ | 35,693 |  |  | $ | 31,195 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-18-000010:notes:281]
The following table summarizes the financial performance of the Company's reporting segments:

[0000926326-18-000010:notes:282]
|  | Year Ended December 31, |
|  | 2017 |  | 2016 |  | 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 590,392 |  |  | $ | 125,773 |  |  | $ | 716,165 |  |  | $ | 593,626 |  |  | $ | 98,997 |  |  | $ | 692,623 |  |  | $ | 390,321 |  |  | $ | 94,238 |  |  | $ | 484,559 |  |
| Cost of revenues | 308,443 |  |  | 85,634 |  |  | 394,077 |  |  | 310,967 |  |  | 67,856 |  |  | 378,823 |  |  | 171,943 |  |  | 64,686 |  |  | 236,629 |  |
| Gross profit | 281,949 |  |  | 40,139 |  |  | 322,088 |  |  | 282,659 |  |  | 31,141 |  |  | 313,800 |  |  | 218,378 |  |  | 29,552 |  |  | 247,930 |  |
| Operating expenses | 193,700 |  |  | 41,735 |  |  | 235,435 |  |  | 198,511 |  |  | 24,843 |  |  | 223,354 |  |  | 114,084 |  |  | 24,258 |  |  | 138,342 |  |
| Income from operations | $ | 88,249 |  |  | $ | (1,596 | ) |  | 86,653 |  |  | $ | 84,148 |  |  | $ | 6,298 |  |  | 90,446 |  |  | $ | 104,294 |  |  | $ | 5,294 |  |  | 109,588 |  |
| Corporate costs |  |  |  |  | 80,899 |  |  |  |  |  |  | 83,965 |  |  |  |  |  |  | 60,956 |  |
| Income from operations |  |  |  |  | $ | 5,754 |  |  |  |  |  |  | $ | 6,481 |  |  |  |  |  |  | $ | 48,632 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000926326-18-000010:notes:283]
SCHEDULE II

[0000926326-18-000010:notes:284]
VALUATION AND QUALIFYING ACCOUNTS

[0000926326-18-000010:notes:285]
|  |  |  | Additions |  |  |  |  |  |  |
|  | Balance atBeginning of Period (1) |  | Charged toCosts and Expenses (2) |  | Debited (credited) toOther Accounts (3) |  | AmountWritten Off (4) |  | Acquisition and translation adjustments (5) |  | Balance atEnd of Period (1) |
|  | (In thousands) |
| Year ended December 31, 2015 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 1,206 |  |  | $ | 453 |  |  | $ | 28 |  |  | $ | (447 | ) |  | $ | — |  |  | $ | 1,240 |  |
| Investment in sales-type leases | 162 |  |  | (99 | ) |  | 106 |  |  | — |  |  | — |  |  | 169 |  |
| Total allowances deducted from assets | $ | 1,368 |  |  | $ | 354 |  |  | $ | 134 |  |  | $ | (447 | ) |  | $ | — |  |  | $ | 1,409 |  |
| Year ended December 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 1,240 |  |  | $ | 727 |  |  | $ | 77 |  |  | $ | (369 | ) |  | $ | 3,121 |  |  | $ | 4,796 |  |
| Investment in sales-type leases | 169 |  |  | 85 |  |  | — |  |  | — |  |  | — |  |  | 254 |  |
| Total allowances deducted from assets | $ | 1,409 |  |  | $ | 812 |  |  | $ | 77 |  |  | $ | (369 | ) |  | $ | 3,121 |  |  | $ | 5,050 |  |
| Year ended December 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 4,796 |  |  | $ | 1,008 |  |  | $ | 3 |  |  | $ | (402 | ) |  | $ | 333 |  |  | $ | 5,738 |  |
| Investment in sales-type leases | 254 |  |  | (62 | ) |  | — |  |  | — |  |  | — |  |  | 192 |  |
| Total allowances deducted from assets | $ | 5,050 |  |  | $ | 946 |  |  | $ | 3 |  |  | $ | (402 | ) |  | $ | 333 |  |  | $ | 5,930 |  |

[0000926326-18-000010:notes:286]
__________________________________________________

[0000926326-18-000010:notes:287]
| (1) | Allowance for doubtful accounts. |

[0000926326-18-000010:notes:288]
| (2) | Represents amounts charged to bad debt expense, increasing the allowance. |

[0000926326-18-000010:notes:289]
| (3) | Represents amounts debited to trade accounts receivable as recoveries, increasing the allowance. |

[0000926326-18-000010:notes:290]
| (4) | Represents amounts written-off from the allowance and trade accounts receivable. |

[0000926326-18-000010:notes:291]
| (5) | Represents primarily purchase price adjustments and minor foreign currency translation adjustments. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-18-000010:notes:292]
Segment and Geographical Information

[0000926326-18-000010:notes:293]
Segment Information

[0000926326-18-000010:notes:294]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses. The two operating segments, which are the same as the Company's two reportable segments, are as follows:

[0000926326-18-000010:notes:295]
Automation and Analytics

[0000926326-18-000010:notes:296]
The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. The Automation and Analytics products are designed to enable the Company's customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, the Company's systems can be tailored to specific customer needs. The financial results of InPharmics acquired in the second quarter of 2017 and Aesynt acquired in the first quarter of 2016 are included in the Automation and Analytics segment.

[0000926326-18-000010:notes:297]
Medication Adherence

[0000926326-18-000010:notes:298]
The Medication Adherence segment includes solutions to assist patients to remain adherent to their medication regimens.   These solutions are comprised of a variety of tools and aids that may be directly used by a pharmacist or a healthcare provider in their direct care for a patient, or the patient themselves, and include software based systems and medication adherence packaging. Software solutions primarily operate on the Patient Management Access Portal (PMAP), a subscription based software system which provides an environment for patient engagement by clinicians. Services running on PMAP include Time My Meds medication synchronization, immunization management, and a number of tools used by clinicians to manage patient engagement workflows. Medication Adherence packaging is designed either for patient use in care environments where there is a caregiver present or for environments where the patient cares for him or herself and includes the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. The financial results of Ateb acquired in the fourth quarter of 2016 are included in the Medication Adherence segment.

[0000926326-18-000010:notes:299]
Significant customers

[0000926326-18-000010:notes:300]
The Company contracts with Group Purchasing Organizations (“GPOs”), each of which functions as a purchasing agent on behalf of member hospitals and other healthcare providers, as well as with government entities and agencies. Pursuant to the terms of GPO agreements, each member contracts directly with Omnicell and can purchase Company’s product at pre-negotiated contract terms and pricing. The account receivable balances are with individual members of the GPOs, and therefore no significant concentration of credit risk exists. During our fiscal year ended December 31, 2017, December 31, 2016 and December 31, 2015 sales to members of the ten largest GPOs accounted for approximately 51.2%, 51.2% and 65.2% of total consolidated revenue, respectively. There were no customers that accounted for more than 10% of the Company's total revenues or accounts receivable balance at and for the years ended December 31, 2017, December 31, 2016 and December 31, 2015.

[0000926326-18-000010:notes:301]
Geographical Information


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-18-000010:notes:302]
Equity Offerings

[0000926326-18-000010:notes:303]
On November 3, 2017, the Company entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC and HSBC Securities (USA) Inc., as its sales agents, pursuant to which the Company may offer and sell from time to time through the sales agents up to $125 million maximum aggregate offering price of the Company’s common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange.

[0000926326-18-000010:notes:304]
For the year ended December 31, 2017, the Company received gross proceeds of $14.7 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.8 million on sales of approximately 294,000 shares of its common stock at an average price of approximately $49.85 per share.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-18-000010:notes:305]
Balance Sheet Components


## us-gaap:TreasuryStockTextBlock

[0000926326-18-000010:notes:306]
Stock Repurchases

[0000926326-18-000010:notes:307]
On August 2, 2016, the Board of Directors (the "Board") of the Company authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of December 31, 2017, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million.

[0000926326-18-000010:notes:308]
The timing, price and volume of repurchases are to be based on market conditions, relevant securities laws and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions or pursuant to a Rule 10b-18 plan, subject to the terms and conditions of that certain Amendment of the Amended Credit Agreement, dated as of December 26, 2017, among the Company, the Lenders party thereto, and Wells Fargo Bank, National Association, as administrative agent. The stock repurchase program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase program at any time. During the years ended December 31, 2017 and 2016, respectively, the Company made no repurchases of its outstanding common stock. During the year ended December 31, 2015, the Company repurchased approximately $50.0 million of shares.
