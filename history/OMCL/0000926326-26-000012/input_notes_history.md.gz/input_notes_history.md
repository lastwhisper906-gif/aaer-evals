# OMCL note change history — 0000926326-25-000031 → 0000926326-26-000012


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2026-05-06):
[0000926326-26-000012:note_history:1]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual

- changed (2026-05-06):
[0000926326-26-000012:note_history:2]
for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters either cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.
  (was, 2025-11-05, similarity 0.8208):
[0000926326-25-000031:note_history:2]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters either cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000926326-26-000012:note_history:3]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2026, the Company had non-cancelable purchase commitments of $172.6 million, of which $133.7 million are expected to be paid within the year ending December 31, 2026.
  (was, 2025-11-05, similarity 0.9747):
[0000926326-25-000031:note_history:3]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2025, the Company had non-cancelable purchase commitments of $135.0 million, of which $82.1 million are expected to be paid within the year ending December 31, 2025.

- added (2026-05-06):
[0000926326-26-000012:note_history:4]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual

- changed (2026-05-06):
[0000926326-26-000012:note_history:5]
for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters either cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.
  (was, 2025-11-05, similarity 0.8208):
[0000926326-25-000031:note_history:5]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters either cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000926326-26-000012:note_history:6]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2026 and December 31, 2025, and the results of operations, comprehensive income (loss), and cash flows for the three months ended March 31, 2026 and 2025. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2025, filed with the SEC on February 26, 2026. The Company’s results of operations, comprehensive income (loss), and cash flows for the three months ended March 31, 2026 are not necessarily indicative of results that may be expected for the year ending December 31, 2026, or for any future period.
  (was, 2025-11-05, similarity 0.8802):
[0000926326-25-000031:note_history:6]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2025 and December 31, 2024, and the results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2025 and 2024, and cash flows for the nine months ended September 30, 2025 and 2024. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2024, filed with the SEC on February 27, 2025. The Company’s results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2025, and cash flows for the nine months ended September 30, 2025 are not necessarily indicative of results that may be expected for the year ending December 31, 2025, or for any future period.

- changed (2026-05-06):
[0000926326-26-000012:note_history:7]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes to Condensed Consolidated Financial Statements. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting estimates are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. Those estimates are revenue recognition, inventory valuation, and accounting for income taxes. As of March 31, 2026, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.
  (was, 2025-11-05, similarity 0.9934):
[0000926326-25-000031:note_history:7]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes to Condensed Consolidated Financial Statements. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting estimates are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. Those estimates are revenue recognition, inventory valuation, and accounting for income taxes. As of September 30, 2025, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

- changed (2026-05-06):
[0000926326-26-000012:note_history:8]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosure (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosures of additional information and disaggregation of certain expenses included in the income statement. The amendments are effective for the Company’s annual periods beginning January 1, 2027, and for interim periods within fiscal years beginning January 1, 2028, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2024-03 will have on its consolidated financial statements.
  (was, 2025-11-05, similarity 0.9286):
[0000926326-25-000031:note_history:8]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosure (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosures of additional information and disaggregation of certain expenses included in the income statement. The amendments are effective for the Company’s annual periods beginning January 1, 2027, and for interim periods within fiscal years beginning January 1, 2028, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2024-03 will have on its consolidated financial statements.

- removed (2026-05-06):
[0000926326-25-000031:note_history:9]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning January 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company plans to adopt ASU 2023-09 on a prospective basis for its fiscal year beginning January 1, 2025. Because the standard only affects disclosure requirements and not recognition or measurement of income taxes, the Company does not expect adoption to have a material impact on its consolidated financial condition, results of operations, or cash flows. The Company is currently evaluating the impact of the required disclosures on its consolidated financial statement disclosures.

- removed (2026-05-06):
[0000926326-25-000031:note_history:10]
In March 2024, the SEC issued final rules under SEC Release No. 33-11275, “The Enhancement and Standardization of Climate-Related Disclosures for Investors,” to require registrants to disclose certain climate-related information, including Scope 1 and Scope 2 greenhouse gas emissions and other climate-related topics, if material, in registration statements and annual reports. In April 2024, the SEC voluntarily stayed its climate disclosure rules as a result of pending legal challenges to facilitate an orderly judicial resolution. In March 2025, the SEC stated that it has ended its defense of the rule. The Company will continue to monitor any developments in the SEC’s rule and related litigation to determine what, if any, impact it will have on its consolidated financial statement disclosures.


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-06):
[0000926326-26-000012:note_history:11]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes | $ | — |  |  | $ | 109 |  |  |  |  |  |
| 2029 Notes | $ | 431 |  |  | $ | 431 |  |  |  |  |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes | $ | — |  |  | $ | 238 |  |  |  |  |  |
| 2029 Notes | $ | 303 |  |  | $ | 303 |  |  |  |  |  |

- removed (2026-05-06):
[0000926326-25-000031:note_history:12]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 91 |  |  | $ | 359 |  |  | $ | 310 |  |  | $ | 1,078 |  |
| 2029 Notes | $ | 431 |  |  | $ | — |  |  | 1,294 |  |  | — |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 199 |  |  | $ | 780 |  |  | $ | 676 |  |  | $ | 2,335 |  |
| 2029 Notes | $ | 300 |  |  | $ | — |  |  | 897 |  |  | — |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000926326-26-000012:note_history:13]
The 2029 Notes consisted of the following balances:
  (was, 2025-11-05, similarity 0.8571):
[0000926326-25-000031:note_history:13]
The 2025 Notes and the 2029 Notes consisted of the following balances:

- added (2026-05-06):
[0000926326-26-000012:note_history:14]
|  | March 31,2026 |  | December 31,2025 |
|  | (In thousands) |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (4,601) |  |  | (4,904) |  |
| Convertible senior notes, net | $ | 167,899 |  |  | $ | 167,596 |  |

- removed (2026-05-06):
[0000926326-25-000031:note_history:15]
|  | September 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| 2025 Notes: |  |  |  |
| Principal amount | $ | — |  |  | $ | 175,000 |  |
| Unamortized debt issuance costs | — |  |  | (676) |  |
| Convertible senior notes, net, current | $ | — |  |  | $ | 174,324 |  |
| 2029 Notes: |  |  |  |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (5,206) |  |  | (6,103) |  |
| Convertible senior notes, net, noncurrent | $ | 167,294 |  |  | $ | 166,397 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000926326-26-000012:note_history:16]
Debt and Credit Agreement
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.
  (was, 2025-11-05, similarity 0.8204):
[0000926326-25-000031:note_history:16]
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit

- changed (2026-05-06):
[0000926326-26-000012:note_history:17]
As of both March 31, 2026 and December 31, 2025, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of March 31, 2026 and December 31, 2025, the Company had no outstanding balance
  (was, 2025-11-05, similarity 0.654):
[0000926326-25-000031:note_history:17]
As of both September 30, 2025 and December 31, 2024, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of September 30, 2025 and December 31, 2024, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of September 30, 2025.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- added (2026-05-06):
[0000926326-26-000012:note_history:18]
under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of March 31, 2026.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- changed (2026-05-06):
[0000926326-26-000012:note_history:19]
On September 25, 2020, Omnicell, Inc. completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “2025 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the 2025 Notes. As referred to in this Note 11, “Omnicell, Inc.” or the “Company” refers only to Omnicell, Inc., excluding its subsidiaries. The 2025 Notes were issued pursuant to an indenture, dated September 25, 2020 (the “2025 Notes Indenture”), between the Company and U.S. Bank National Association, as trustee. Prior to maturity, the 2025 Notes were general senior, unsecured obligations of the Company and bore interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021.
  (was, 2025-11-05, similarity 0.915):
[0000926326-25-000031:note_history:19]
On September 25, 2020, Omnicell, Inc. completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “2025 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the 2025 Notes. As referred to in this Note 11, “Omnicell, Inc.” or the “Company” refers only to Omnicell, Inc., excluding its subsidiaries. Omnicell, Inc. received proceeds from the issuance of the 2025 Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The 2025 Notes were issued pursuant to an indenture, dated September 25, 2020 (the “2025 Notes Indenture”), between the Company and U.S. Bank National Association, as trustee. Prior to maturity, the 2025 Notes were general senior, unsecured obligations of the Company and bore interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021.

- changed (2026-05-06):
[0000926326-26-000012:note_history:20]
In November 2024, the Company repurchased $400.0 million of aggregate principal amount of the 2025 Notes. Subsequently, at maturity on September 15, 2025, the Company repaid the remaining principal balance of $175.0 million and $0.2 million of accrued interest in cash.
  (was, 2025-11-05, similarity 0.7241):
[0000926326-25-000031:note_history:20]
The 2025 Notes matured on September 15, 2025 and the Company repaid the remaining principal balance of $175.0 million and $0.2 million of accrued interest in cash.

- changed (2026-05-06):
[0000926326-26-000012:note_history:21]
During the three months ended March 31, 2026 and December 31, 2025, none of the conditional conversion features of the 2029 Notes were triggered, and therefore, the 2029 Notes are not convertible during the second quarter of 2026, commencing on April 1, 2026, and were not convertible during the first quarter of 2026, commencing on January 1, 2026.
  (was, 2025-11-05, similarity 0.8549):
[0000926326-25-000031:note_history:21]
During the three months ended September 30, 2025 and December 31, 2024, none of the conditional conversion features of the 2029 Notes were triggered, and therefore, the 2029 Notes are not convertible during the fourth quarter of 2025, commencing on October 1, 2025, and were not convertible during the first quarter of 2025, commencing on January 1, 2025.

- changed (2026-05-06):
[0000926326-26-000012:note_history:22]
The initial conversion rate for the 2029 Notes is 17.4662 shares of the Company’s common stock per $1,000 principal amount of the 2029 Notes, which is equivalent to an initial conversion price of approximately $57.25 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the 2029 Notes Indenture. In addition, following certain corporate events that occur prior to the maturity date of the 2029 Notes or if the Company delivers a notice of redemption in respect of the 2029 Notes, the Company will, under certain circumstances, increase the conversion rate of the 2029 Notes for a holder who elects to convert its 2029 Notes (or any portion thereof) in connection
  (was, 2025-11-05, similarity 0.8812):
[0000926326-25-000031:note_history:22]
The initial conversion rate for the 2029 Notes is 17.4662 shares of the Company’s common stock per $1,000 principal amount of the 2029 Notes, which is equivalent to an initial conversion price of approximately $57.25 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the 2029 Notes Indenture. In addition, following certain corporate events that occur prior to the maturity date of the 2029 Notes or if the Company delivers a notice of redemption in respect of the 2029 Notes, the Company will, under certain circumstances, increase the conversion rate of the 2029 Notes for a holder who elects to convert its 2029 Notes (or any portion thereof) in connection with such a corporate event or convert its 2029 Notes called (or deemed called) for redemption during the related redemption period (as defined in the 2029 Notes Indenture), as the case may be.

- added (2026-05-06):
[0000926326-26-000012:note_history:23]
with such a corporate event or convert its 2029 Notes called (or deemed called) for redemption during the related redemption period (as defined in the 2029 Notes Indenture), as the case may be.

- changed (2026-05-06):
[0000926326-26-000012:note_history:24]
If the Company undergoes a fundamental change (as defined in the 2029 Notes Indenture), holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2029 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2026, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2025-11-05, similarity 0.9865):
[0000926326-25-000031:note_history:24]
If the Company undergoes a fundamental change (as defined in the 2029 Notes Indenture), holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2029 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2025, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- changed (2026-05-06):
[0000926326-26-000012:note_history:25]
The debt issuance costs associated with the 2029 Notes are being amortized to interest expense over the term of the 2029 Notes using an effective interest rate of 1.75%. As of March 31, 2026, the remaining life of the 2029 Notes and the related issuance cost accretion is approximately 3.7 years.
  (was, 2025-11-05, similarity 0.9748):
[0000926326-25-000031:note_history:25]
The debt issuance costs associated with the 2029 Notes are being amortized to interest expense over the term of the 2029 Notes using an effective interest rate of 1.75%. As of September 30, 2025, the remaining life of the 2029 Notes and the related issuance cost accretion is approximately 4.2 years.

- changed (2026-05-06):
[0000926326-26-000012:note_history:26]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be approximately 3.0 million shares. As of March 31, 2026, the if-converted value of the 2029 Notes did not exceed the principal amount.
  (was, 2025-11-05, similarity 0.9753):
[0000926326-25-000031:note_history:26]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be approximately 3.0 million shares. As of September 30, 2025, the if-converted value of the 2029 Notes did not exceed the principal amount.

- changed (2026-05-06):
[0000926326-26-000012:note_history:27]
The 2029 Notes consisted of the following balances:
  (was, 2025-11-05, similarity 0.8571):
[0000926326-25-000031:note_history:27]
The 2025 Notes and the 2029 Notes consisted of the following balances:

- added (2026-05-06):
[0000926326-26-000012:note_history:28]
|  | March 31,2026 |  | December 31,2025 |
|  | (In thousands) |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (4,601) |  |  | (4,904) |  |
| Convertible senior notes, net | $ | 167,899 |  |  | $ | 167,596 |  |

- added (2026-05-06):
[0000926326-26-000012:note_history:29]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes | $ | — |  |  | $ | 109 |  |  |  |  |  |
| 2029 Notes | $ | 431 |  |  | $ | 431 |  |  |  |  |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes | $ | — |  |  | $ | 238 |  |  |  |  |  |
| 2029 Notes | $ | 303 |  |  | $ | 303 |  |  |  |  |  |

- added (2026-05-06):
[0000926326-26-000012:note_history:30]
The convertible note hedges related to the 2025 Notes consisted of call options for the Company to purchase, subject to anti-dilution adjustments substantially similar to those applicable to the 2025 Notes, up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2025 Notes at the time of its issuance, at an initial strike price of approximately $97.32 per share. The convertible note hedges related

- changed (2026-05-06):
[0000926326-26-000012:note_history:31]
to the 2029 Notes consisted of call options for the Company to purchase up to, subject to anti-dilution adjustments substantially similar to those applicable to the 2029 Notes, approximately 3.0 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2029 Notes at the time of its issuance, at an initial strike price of approximately $57.25 per share. The convertible note hedges expire upon the maturity of the respective convertible notes, if not earlier exercised or terminated. The cost of the convertible note hedges related to the 2025 Notes and the 2029 Notes was approximately $100.6 million and $40.3 million, respectively, and each was accounted for as an equity instrument, each of which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. In addition, the Company recorded a deferred tax asset of $25.8 million and $10.2 million, respectively, at issuance related to the convertible note hedges for the 2025 Notes and the 2029 Notes. The 2029 Notes convertible note hedges are expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of the 2029 Notes and/or offset any cash payments the Company may be required to make in excess of the principal amount of the converted 2029 Notes.
  (was, 2025-11-05, similarity 0.6709):
[0000926326-25-000031:note_history:31]
The convertible note hedges related to the 2025 Notes consisted of call options for the Company to purchase, subject to anti-dilution adjustments substantially similar to those applicable to the 2025 Notes, up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2025 Notes at the time of its issuance, at an initial strike price of approximately $97.32 per share. The convertible note hedges related to the 2029 Notes consisted of call options for the Company to purchase up to, subject to anti-dilution adjustments substantially similar to those applicable to the 2029 Notes, approximately 3.0 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2029 Notes at the time of its issuance, at an initial strike price of approximately $57.25 per share. The convertible note hedges expire upon the maturity of the respective convertible notes, if not earlier exercised or terminated. The cost of the convertible note hedges related to the 2025 Notes and the 2029 Notes was approximately $100.6 million and $40.3 million, respectively, and each was accounted for as an equity instrument, each of which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. In addition, the Company recorded a deferred tax asset of $25.8 million and $10.2 million, respectively, at issuance related to the convertible note hedges for the 2025 Notes and the 2029 Notes. The 2029 Notes convertible note hedges are expected generally

- changed (2026-05-06):
[0000926326-26-000012:note_history:32]
Separately from the convertible note hedges, in September 2020 and November 2024, the Company entered into warrant transactions to sell to the respective option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock at an initial strike price of approximately $141.56 and approximately 3.0 million shares of its common stock at an initial strike price of approximately $84.82 per share related to the 2025 Notes and the 2029 Notes, respectively. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million and $25.2 million for the issuance of the warrants related to the 2025 Notes and the 2029 Notes, respectively, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock, as measured under the warrants, exceeds the strike price of the warrants.
On September 15, 2025, the convertible note hedges related to the remaining 2025 Notes expired concurrently with the maturity of the 2025 Notes. No settlement was required as the Company’s stock price remained below the strike price at that time. In addition, following maturity of the 2025 Notes, the warrants issued in connection with the 2025 Notes terminate between December 15, 2025 and June 8, 2026.
  (was, 2025-11-05, similarity 0.8523):
[0000926326-25-000031:note_history:32]
Separately from the convertible note hedges, in September 2020 and November 2024, the Company entered into warrant transactions to sell to the respective option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock at an initial strike price of approximately $141.56 and approximately 3.0 million shares of its common stock at an initial strike price of approximately $84.82 per share related to the 2025 Notes and the 2029 Notes, respectively. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million and $25.2 million for the issuance of the warrants related to the 2025 Notes and the 2029 Notes, respectively, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock, as measured under the warrants, exceeds the strike price of the warrants.

- removed (2026-05-06):
[0000926326-25-000031:note_history:33]
Debt and Credit Agreement
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. As referred to in this Note 10, “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023, to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 11, Convertible Senior Notes), expand the Company’s flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

- removed (2026-05-06):
[0000926326-25-000031:note_history:34]
Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

- removed (2026-05-06):
[0000926326-25-000031:note_history:35]
In November 2024, the Company entered into separate, privately negotiated transactions with certain holders of the 2025 Notes to repurchase $400.0 million of aggregate principal amount of the 2025 Notes for approximately $391.0 million of cash. The Company accounted for the partial repurchase of 2025 Notes as a debt extinguishment and recorded a $7.2 million gain on extinguishment, which included a partial write-off of previously deferred debt issuance costs of $1.8 million during the three months ended December 31, 2024.

- removed (2026-05-06):
[0000926326-25-000031:note_history:36]
|  | September 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| 2025 Notes: |  |  |  |
| Principal amount | $ | — |  |  | $ | 175,000 |  |
| Unamortized debt issuance costs | — |  |  | (676) |  |
| Convertible senior notes, net, current | $ | — |  |  | $ | 174,324 |  |
| 2029 Notes: |  |  |  |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (5,206) |  |  | (6,103) |  |
| Convertible senior notes, net, noncurrent | $ | 167,294 |  |  | $ | 166,397 |  |

- removed (2026-05-06):
[0000926326-25-000031:note_history:37]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 91 |  |  | $ | 359 |  |  | $ | 310 |  |  | $ | 1,078 |  |
| 2029 Notes | $ | 431 |  |  | $ | — |  |  | 1,294 |  |  | — |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 199 |  |  | $ | 780 |  |  | $ | 676 |  |  | $ | 2,335 |  |
| 2029 Notes | $ | 300 |  |  | $ | — |  |  | 897 |  |  | — |  |

- removed (2026-05-06):
[0000926326-25-000031:note_history:38]
to reduce the potential dilution to the Company’s common stock upon any conversion of the 2029 Notes and/or offset any cash payments the Company may be required to make in excess of the principal amount of the converted 2029 Notes.

- removed (2026-05-06):
[0000926326-25-000031:note_history:39]
In November 2024, in connection with the partial repurchase of the 2025 Notes, the Company entered into unwind agreements with the existing option counterparties to the convertible note hedges and warrants related to the 2025 Notes to terminate a portion of the existing convertible note hedges and warrants related to the 2025 Notes at a notional amount corresponding to the amount of the 2025 Notes repurchased, resulting in an immaterial gain.
On September 15, 2025, the convertible note hedges related to the remaining 2025 Notes expired concurrently with the maturity of the 2025 Notes. No settlement was required as the Company’s stock price remained below the strike price at that time. In addition, following maturity of the 2025 Notes, the warrants issued in connection with the 2025 Notes will terminate between December 15, 2025 and June 8, 2026.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-06):
[0000926326-26-000012:note_history:40]
|  | March 31,2026 |  | December 31,2025 |
|  | (In thousands) |
| Net carrying amount | 167,899 |  |  | 167,596 |  |
| Fair value | 167,434 |  |  | 185,869 |  |

- removed (2026-05-06):
[0000926326-25-000031:note_history:41]
|  | September 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Net carrying amount: |  |  |  |
| 2025 Notes | — |  |  | 174,324 |  |
| 2029 Notes | 167,294 |  |  | 166,397 |  |
| Total net carrying amount | $ | 167,294 |  |  | $ | 340,721 |  |
| Fair value: |  |  |  |
| 2025 Notes | $ | — |  |  | $ | 167,129 |  |
| 2029 Notes | 159,908 |  |  | 181,320 |  |
| Total fair value | $ | 159,908 |  |  | $ | 348,449 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000926326-26-000012:note_history:42]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 148,662 |  |  | $ | 120,077 |  |  |  |  |  |
| Consumables | 26,138 |  |  | 25,091 |  |  |  |  |  |
| Technical services | 66,923 |  |  | 61,379 |  |  |  |  |  |
| SaaS and Expert Services | 68,157 |  |  | 63,121 |  |  |  |  |  |
| Total revenues | $ | 309,880 |  |  | $ | 269,668 |  |  |  |  |  |
  (was, 2025-11-05, similarity 0.7749):
[0000926326-25-000031:note_history:42]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 152,561 |  |  | $ | 135,672 |  |  | $ | 411,258 |  |  | $ | 381,280 |  |
| Consumables | 24,937 |  |  | 22,689 |  |  | 74,580 |  |  | 66,956 |  |
| Technical services | 67,275 |  |  | 59,583 |  |  | 192,420 |  |  | 177,419 |  |
| SaaS and Expert Services | 65,858 |  |  | 64,476 |  |  | 192,603 |  |  | 179,704 |  |
| Total revenues | $ | 310,631 |  |  | $ | 282,420 |  |  | $ | 870,861 |  |  | $ | 805,359 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000926326-26-000012:note_history:43]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multi-medication adherence packaging and single-dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other non-acute healthcare facilities, and are designed to improve patient engagement and adherence to prescriptions.
  (was, 2025-11-05, similarity 0.8981):
[0000926326-25-000031:note_history:43]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, and are designed to improve patient engagement and adherence to prescriptions.

- changed (2026-05-06):
[0000926326-26-000012:note_history:44]
Technical services. Post-installation technical support and other related services (support and maintenance), including phone and/or web support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.
  (was, 2025-11-05, similarity 0.9837):
[0000926326-25-000031:note_history:44]
Technical services. Post-installation technical support and other related services (support and maintenance), including phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.

- changed (2026-05-06):
[0000926326-26-000012:note_history:45]
Software as a Service (“SaaS”) and Expert Services. Software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.
  (was, 2025-11-05, similarity 0.9909):
[0000926326-25-000031:note_history:45]
Software as a Service (“SaaS”) and Expert Services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000926326-26-000012:note_history:46]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multi-medication adherence packaging and single-dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other non-acute healthcare facilities, and are designed to improve patient engagement and adherence to prescriptions.
  (was, 2025-11-05, similarity 0.8981):
[0000926326-25-000031:note_history:46]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, and are designed to improve patient engagement and adherence to prescriptions.

- changed (2026-05-06):
[0000926326-26-000012:note_history:47]
Technical services. Post-installation technical support and other related services (support and maintenance), including phone and/or web support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.
  (was, 2025-11-05, similarity 0.9837):
[0000926326-25-000031:note_history:47]
Technical services. Post-installation technical support and other related services (support and maintenance), including phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.

- changed (2026-05-06):
[0000926326-26-000012:note_history:48]
Software as a Service (“SaaS”) and Expert Services. Software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.
  (was, 2025-11-05, similarity 0.9909):
[0000926326-25-000031:note_history:48]
Software as a Service (“SaaS”) and Expert Services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.

- changed (2026-05-06):
[0000926326-26-000012:note_history:49]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $1.9 million and $2.2 million for the three months ended March 31, 2026 and 2025, respectively.
  (was, 2025-11-05, similarity 0.9322):
[0000926326-25-000031:note_history:49]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.8 million and $2.5 million for the three months ended September 30, 2025 and 2024, respectively, and $6.6 million and $6.9 million for the nine months ended September 30, 2025 and 2024, respectively.

- changed (2026-05-06):
[0000926326-26-000012:note_history:50]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 148,662 |  |  | $ | 120,077 |  |  |  |  |  |
| Consumables | 26,138 |  |  | 25,091 |  |  |  |  |  |
| Technical services | 66,923 |  |  | 61,379 |  |  |  |  |  |
| SaaS and Expert Services | 68,157 |  |  | 63,121 |  |  |  |  |  |
| Total revenues | $ | 309,880 |  |  | $ | 269,668 |  |  |  |  |  |
  (was, 2025-11-05, similarity 0.7749):
[0000926326-25-000031:note_history:50]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 152,561 |  |  | $ | 135,672 |  |  | $ | 411,258 |  |  | $ | 381,280 |  |
| Consumables | 24,937 |  |  | 22,689 |  |  | 74,580 |  |  | 66,956 |  |
| Technical services | 67,275 |  |  | 59,583 |  |  | 192,420 |  |  | 177,419 |  |
| SaaS and Expert Services | 65,858 |  |  | 64,476 |  |  | 192,603 |  |  | 179,704 |  |
| Total revenues | $ | 310,631 |  |  | $ | 282,420 |  |  | $ | 870,861 |  |  | $ | 805,359 |  |

- changed (2026-05-06):
[0000926326-26-000012:note_history:51]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In thousands) |
| United States | $ | 278,097 |  |  | $ | 249,264 |  |  |  |  |  |
| Rest of world (1) | 31,783 |  |  | 20,404 |  |  |  |  |  |
| Total revenues | $ | 309,880 |  |  | $ | 269,668 |  |  |  |  |  |
  (was, 2025-11-05, similarity 0.695):
[0000926326-25-000031:note_history:51]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  | (In thousands) |
| United States | $ | 278,195 |  |  | $ | 258,177 |  |  | $ | 790,905 |  |  | $ | 731,670 |  |
| Rest of world (1) | 32,436 |  |  | 24,243 |  |  | 79,956 |  |  | 73,689 |  |
| Total revenues | $ | 310,631 |  |  | $ | 282,420 |  |  | $ | 870,861 |  |  | $ | 805,359 |  |

- changed (2026-05-06):
[0000926326-26-000012:note_history:52]
|  | March 31,2026 |  | December 31,2025 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 31,833 |  |  | $ | 28,396 |  |
| Long-term unbilled receivables, net (2) | 2,791 |  |  | 3,521 |  |
| Total contract assets | $ | 34,624 |  |  | $ | 31,917 |  |
| Short-term deferred revenues | $ | 211,889 |  |  | $ | 171,861 |  |
| Long-term deferred revenues | 63,066 |  |  | 63,254 |  |
| Total contract liabilities | $ | 274,955 |  |  | $ | 235,115 |  |
  (was, 2025-11-05, similarity 0.9815):
[0000926326-25-000031:note_history:52]
|  | September 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 46,414 |  |  | $ | 32,917 |  |
| Long-term unbilled receivables, net (2) | 3,355 |  |  | 7,873 |  |
| Total contract assets | $ | 49,769 |  |  | $ | 40,790 |  |
| Short-term deferred revenues | $ | 178,777 |  |  | $ | 141,370 |  |
| Long-term deferred revenues | 66,723 |  |  | 76,123 |  |
| Total contract liabilities | $ | 245,500 |  |  | $ | 217,493 |  |

- changed (2026-05-06):
[0000926326-26-000012:note_history:53]
During the three months ended March 31, 2026, the Company recognized revenues of $63.4 million that were included in the corresponding short-term deferred revenues balance of $171.9 million as of December 31, 2025.
  (was, 2025-11-05, similarity 0.8176):
[0000926326-25-000031:note_history:53]
During the three and nine months ended September 30, 2025, the Company recognized revenues of $20.7 million and $113.5 million, respectively, that were included in the corresponding short-term deferred revenues balance of $141.4 million as of December 31, 2024.

- added (2026-05-06):
[0000926326-26-000012:note_history:54]
Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, but where services have not yet been provided. Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term technical and SaaS and Expert Services contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time. SaaS and Expert Services agreements are generally invoiced periodically on a monthly, quarterly or annual basis over the life of the agreement. In certain circumstances, portions of these agreements may be invoiced lump sum.

- changed (2026-05-06):
[0000926326-26-000012:note_history:55]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and SaaS and Expert Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $382.9 million as of March 31, 2026. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.
  (was, 2025-11-05, similarity 0.993):
[0000926326-25-000031:note_history:55]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and SaaS and Expert Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $379.0 million as of September 30, 2025. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

- changed (2026-05-06):
[0000926326-26-000012:note_history:56]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2026 and 2025. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable and unbilled receivables balance as of March 31, 2026 and December 31, 2025.
  (was, 2025-11-05, similarity 0.827):
[0000926326-25-000031:note_history:56]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2025 and 2024. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable and unbilled receivables balance as of September 30, 2025 and December 31, 2024.

- removed (2026-05-06):
[0000926326-25-000031:note_history:57]
Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, but services have not yet been provided. Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term technical and SaaS and Expert Services contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time. SaaS and Expert Services agreements are generally invoiced periodically on a monthly, quarterly or annual basis over the life of the agreement. In certain circumstances, portions of these agreements may be invoiced lump sum.
