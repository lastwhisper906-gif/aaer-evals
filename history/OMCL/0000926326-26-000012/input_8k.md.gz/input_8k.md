# OMCL 8-K — 0000926326-26-000009 filed 2026-04-28

## item codes, every 8-K on or before 2026-05-06

- 2026-04-28 0000926326-26-000009 — 2.02, 9.01
- 2026-02-05 0000926326-26-000003 — 2.02, 9.01
- 2025-12-08 0001104659-25-119083 — 7.01, 9.01
- 2025-10-30 0000926326-25-000029 — 2.02, 9.01
- 2025-10-06 0000926326-25-000026 — 5.03, 9.01
- 2025-08-25 0001104659-25-082526 — 5.02, 9.01
- 2025-07-31 0000926326-25-000016 — 2.02, 9.01
- 2025-06-05 0001104659-25-056908 — 5.02, 9.01
- 2025-05-23 0001104659-25-052464 — 5.02, 5.07, 9.01
- 2025-05-22 0001104659-25-051854 — 7.01, 9.01
- 2025-05-06 0000926326-25-000006 — 2.02, 9.01
- 2025-03-12 0001104659-25-022797 — 5.02, 7.01, 9.01
- 2025-03-04 0001104659-25-020354 — 5.02, 9.01
- 2025-02-06 0001104659-25-009872 — 2.02, 9.01
- 2024-11-25 0001104659-24-122635 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2024-11-18 0001104659-24-120206 — 1.01, 8.01, 9.01
- 2024-10-30 0000926326-24-000030 — 2.02, 9.01
- 2024-09-25 0001104659-24-102781 — 5.02, 9.01
- 2024-08-01 0000926326-24-000024 — 2.02, 9.01
- 2024-06-04 0000926326-24-000019 — 5.02 — amendment of 0001104659-24-029356
- 2024-05-24 0001104659-24-065130 — 5.02, 5.07, 9.01
- 2024-05-02 0000926326-24-000012 — 2.02, 2.05, 9.01
- 2024-02-29 0001104659-24-029356 — 5.02
- 2024-02-08 0000926326-24-000005 — 2.02, 9.01
- 2024-01-11 0000926326-24-000002 — 5.02, 7.01, 8.01, 9.01
- 2023-11-09 0000926326-23-000043 — 5.02, 9.01
- 2023-11-02 0001104659-23-113604 — 2.02, 2.05, 7.01, 9.01
- 2023-10-16 0000926326-23-000039 — 1.01, 2.03, 9.01
- 2023-10-05 0000926326-23-000037 — 5.02, 9.01
- 2023-08-16 0000926326-23-000035 — 5.02
- 2023-08-10 0000926326-23-000033 — 5.02, 9.01
- 2023-08-03 0000926326-23-000029 — 5.02, 9.01
- 2023-08-01 0000926326-23-000027 — 2.02, 9.01
- 2023-07-11 0000926326-23-000025 — 5.02, 9.01
- 2023-06-26 0000926326-23-000022 — 5.02 — amendment of 0001104659-23-026700
- 2023-05-30 0001104659-23-066011 — 5.02, 9.01
- 2023-05-26 0000926326-23-000020 — 5.02, 5.07, 9.01
- 2023-05-15 0001104659-23-060768 — 5.02, 9.01
- 2023-05-02 0000926326-23-000011 — 2.02, 9.01
- 2023-04-03 0000926326-23-000009 — 1.01, 2.03, 9.01
- 2023-02-28 0001104659-23-026700 — 2.02, 2.05, 5.02, 9.01
- 2022-11-30 0000926326-22-000036 — 2.05
- 2022-11-02 0000926326-22-000031 — 2.02, 9.01
- 2022-10-21 0000926326-22-000029 — 5.03, 9.01
- 2022-09-20 0001104659-22-101566 — 7.01, 9.01
- 2022-09-20 0001104659-22-101360 — 7.01, 9.01
- 2022-08-04 0000926326-22-000025 — 2.02, 8.01, 9.01
- 2022-05-31 0000926326-22-000020 — 5.02, 5.07, 9.01
- 2022-05-24 0000926326-22-000016 — 5.02
- 2022-05-09 0000926326-22-000012 — 8.01
- 2022-04-28 0000926326-22-000009 — 2.02, 9.01
- 2022-03-01 0001104659-22-028681 — 5.02, 8.01, 9.01
- 2022-02-14 0000926326-22-000004 — 2.02, 9.01
- 2022-01-04 0000926326-22-000002 — 7.01, 9.01
- 2021-12-29 0001104659-21-154294 — 7.01, 9.01
- 2021-12-13 0000926326-21-000039 — 8.01
- 2021-12-02 0000926326-21-000037 — 7.01, 9.01
- 2021-11-02 0000926326-21-000031 — 2.02, 9.01
- 2021-09-09 0000926326-21-000028 — 7.01, 9.01
- 2021-07-29 0000926326-21-000024 — 2.02, 9.01
- 2021-07-26 0000926326-21-000022 — 7.01, 9.01
- 2021-07-12 0000926326-21-000019 — 5.02, 9.01
- 2021-05-28 0000926326-21-000015 — 5.07
- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2026-05-06

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-26-000009:8k_2_02:1]
EX-99.1
2
exhibit991q1-26.htm
EX-99.1

[0000926326-26-000009:8k_2_02:2]
Document

[0000926326-26-000009:8k_2_02:3]
Exhibit 99.1

[0000926326-26-000009:8k_2_02:4]
| Contact: |  | Omnicell, Inc. |
| Investor Relations |  | 4220 North Freeway |
| Investor.Relations@omnicell.com |  | Fort Worth, TX 76137 |

[0000926326-26-000009:8k_2_02:5]
Omnicell Announces First Quarter 2026 Financial Results

[0000926326-26-000009:8k_2_02:6]
Omnicell delivers strong first quarter 2026 financial results

[0000926326-26-000009:8k_2_02:7]
Raises full year 2026 non-GAAP EBITDA and non-GAAP EPS guidance

[0000926326-26-000009:8k_2_02:8]
Customer engagement underway for Omnicell Titan XT and OmniSphere

[0000926326-26-000009:8k_2_02:9]
FORT WORTH, Texas -- April 28, 2026 -- Omnicell, Inc. (NASDAQ:OMCL) (“Omnicell,” “we,” “our,” or the “Company”), a leading healthcare technology provider focused on empowering autonomous medication management, today reported financial results for the first quarter ended March 31, 2026.

[0000926326-26-000009:8k_2_02:10]
First quarter results reflected strong execution across the business, supported by demand for Omnicell’s connected device portfolio and solid performance across the Company’s core points of care solutions. We believe that performance during the quarter underscores the durability of Omnicell’s model, supported by disciplined cost management which contributed to improved profitability.

[0000926326-26-000009:8k_2_02:11]
“We delivered a strong start to 2026, driven by solid execution and sustained demand for our points of care solutions,” said Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell. “As care environments continue to become more complex, we see that health systems are prioritizing reliability, efficiency, and standardization in medication workflows. During the quarter, we continued to advance solutions designed to support health systems as they manage increasingly complex medication workflows, optimize the medication supply chain, and improve operational efficiency while enhancing both the caregiver and patient experience.”

[0000926326-26-000009:8k_2_02:12]
“At the same time, we advanced the next phase of our platform evolution,” Lipps added. “Following the introduction of Omnicell Titan XT at ASHP, customer engagement is underway as health systems begin incorporating the platform into longer-term capital planning cycles. OmniSphere continues to mature as our enterprise, system-wide, cloud-native platform, built to enable greater visibility, analytics, and workflow intelligence across medication management. We believe Omnicell Titan XT and OmniSphere represent a meaningful long-term opportunity and provide a strong foundation for enterprise-wide intelligence, workflow optimization, and durable growth as adoption scales over time.”

[0000926326-26-000009:8k_2_02:13]
Financial Results

[0000926326-26-000009:8k_2_02:14]
Total revenues for the first quarter of 2026 were $310 million, up $40 million, or 15%, from the first quarter of 2025. The year-over-year increase in total revenues was driven by strength in our connected devices offerings, as well as increases in technical services, SaaS and Expert Services, and consumables revenues.

[0000926326-26-000009:8k_2_02:15]
Total GAAP net income for the first quarter of 2026 was $11 million, or $0.25 per diluted share. This compares to GAAP net loss of $7 million, or $0.15 per diluted share, for the first quarter of 2025.

[0000926326-26-000009:8k_2_02:16]
Total non-GAAP net income for the first quarter of 2026 was $25 million, or $0.55 per diluted share. This compares to non-GAAP net income of $12 million, or $0.26 per diluted share, for the first quarter of 2025.

[0000926326-26-000009:8k_2_02:17]
Total non-GAAP EBITDA for the first quarter of 2026 was $45 million. This compares to non-GAAP EBITDA of $24 million for the first quarter of 2025.

[0000926326-26-000009:8k_2_02:18]
Balance Sheet

[0000926326-26-000009:8k_2_02:19]
As of March 31, 2026, Omnicell’s balance sheet reflected cash and cash equivalents of $239 million, total debt (net of unamortized debt issuance costs) of $168 million, and total assets of $2.0 billion. Cash flows provided by operating activities in the first quarter of 2026 totaled $55 million. This compares to cash flows provided by operating activities totaling $26 million in the first quarter of 2025.

[0000926326-26-000009:8k_2_02:20]
As of March 31, 2026, the Company had $350 million of availability under its revolving credit facility with no outstanding balance.

[0000926326-26-000009:8k_2_02:21]
Corporate Highlights

[0000926326-26-000009:8k_2_02:22]
•The Omnicell Titan XT Automated Dispensing System and OmniSphere were showcased at the American Organization for Nursing Leadership (AONL) 2026 Annual Meeting, where nursing leaders had the opportunity to explore this next generation technology and how it is expected to minimize the time nurses spend locating medications and enable safer medication administration.

[0000926326-26-000009:8k_2_02:23]
•Omnicell connected with global pharmacy leaders at the 30th EAHP Congress, the annual gathering for the European Association of Hospital Pharmacists to showcase how intelligence-driven solutions are transforming medication and supply management.

[0000926326-26-000009:8k_2_02:24]
•In March 2026, the Company launched the Omnicell Customer Community, a new virtual networking space that provides a forum for customers to collaborate, share insights, and gain peer-to-peer best practices.

[0000926326-26-000009:8k_2_02:25]
2026 Guidance

[0000926326-26-000009:8k_2_02:26]
The table below summarizes Omnicell’s second quarter and updated full year 2026 guidance. Given the strength of our first quarter 2026 profitability performance and ongoing focus on spend discipline, we are increasing our full year 2026 non-GAAP EBITDA and non-GAAP earnings per share guidance ranges.

[0000926326-26-000009:8k_2_02:27]
|  | Q2 2026 |  | 2026 |
| Product Bookings | Not provided |  | $510 million - $560 million |
| Annual Recurring Revenue | Not provided |  | $680 million - $700 million |
| Total Revenues | $307 million - $313 million |  | $1.215 billion - $1.255 billion |
| Product Revenues | $174 million - $177 million |  | $690 million - $710 million |
| Service Revenues | $133 million - $136 million |  | $525 million - $545 million |
| Technical Services Revenues | Not provided |  | $260 million - $270 million |
| SaaS and Expert Service Revenues | Not provided |  | $265 million - $275 million |
| Non-GAAP EBITDA | $37 million - $42 million |  | $153 million - $168 million |
| Non-GAAP Earnings Per Share | $0.40 - $0.48 |  | $1.80 - $2.00 |

[0000926326-26-000009:8k_2_02:28]
The Company does not provide guidance for GAAP net income or GAAP earnings per share, nor a reconciliation of any forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures on a forward-looking basis because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These forward-looking non-GAAP financial measures do not include certain items, which may be significant, including, but not limited to, unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-26-000009:8k_2_02:29]
Omnicell Conference Call Information

[0000926326-26-000009:8k_2_02:30]
Omnicell will hold a conference call today, Tuesday, April 28, 2026, at 8:30 a.m. ET to discuss first quarter 2026 financial results. The conference call can be monitored by dialing (800) 715-9871 in the U.S. or (646) 307-1963 in international locations. The Conference ID is 9381205. A link to the live and archived webcast will also be available on the Investor Relations section of Omnicell’s website at https://ir.omnicell.com/events-and-presentations/.

[0000926326-26-000009:8k_2_02:31]
About Omnicell

[0000926326-26-000009:8k_2_02:32]
Since 1992, Omnicell has been committed to delivering innovative, outcomes-centric pharmacy and nursing solutions for all settings of care. As an intelligent medication management technology company, Omnicell empowers autonomous medication management by unifying automation and AI-enabled intelligence, optimized by expert services, to drive clinical and business outcomes that are helping to improve efficiency and enhance patient safety for healthcare facilities worldwide. Learn more at omnicell.com.

[0000926326-26-000009:8k_2_02:33]
From time to time, Omnicell may use the Company’s investor relations website and other online social media channels, including its LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure (“Reg FD”).

[0000926326-26-000009:8k_2_02:34]
OMNICELL and the Omnicell logo are registered trademarks of Omnicell, Inc. or one of its subsidiaries. This press release may also include the trademarks and service marks of other companies. Such trademarks and service marks are the marks of their respective owners.

[0000926326-26-000009:8k_2_02:35]
Forward-Looking Statements

[0000926326-26-000009:8k_2_02:36]
Such statements include, but are not limited to, Omnicell’s projected product bookings, revenues, including product, service, technical services and SaaS and Expert Services revenues, annual recurring revenue, non-GAAP EBITDA, and non-GAAP earnings per share; expectations regarding our products and services and developing new or enhancing existing products and solutions and the related objectives and expected benefits (and any implied financial impact); the durability of Omnicell’s model; our ability to maintain disciplined cost management; our ability to deliver durable growth, and statements about Omnicell’s strategy, plans, objectives, promise and purpose, vision, goals, opportunities, and market or Company outlook.

[0000926326-26-000009:8k_2_02:37]
Actual results and other events may differ significantly from those contemplated by forward-looking statements due to numerous factors that involve substantial known and unknown risks and uncertainties. These risks and uncertainties include, among other things, (i) unfavorable general economic and market conditions, including the impact and duration of inflationary pressures, (ii) Omnicell’s ability to take advantage of growth opportunities and develop and commercialize new solutions and enhance existing solutions, (iii) reduction in demand in the capital equipment market or reduction in the demand for or adoption of our solutions, systems, or services, (iv) Omnicell’s ability to successfully achieve anticipated growth targets or market adoption, (v) delays in installations of our medication management solutions or our more complex medication packaging systems, (vi) delays, technical challenges and unexpected or greater than anticipated expenses associated with developing new products and services or failing to achieve technological or economic feasibility, obtain regulatory approval or gain market acceptance, (vii) the potential impact of periods of significant volatility due to geopolitical developments, (viii) the risk of increased credit, collection, and operational challenges from providing lease financing options to our customers, (ix) risks related to the incorporation of artificial intelligence technologies, including generative or agentic AI technologies, into our products, services and processes or our vendors offerings, (x) any disruption in Omnicell’s information technology systems and breaches of data security or cyber-attacks on its systems or solutions and any potential adverse legal, reputational, and financial effects that may result from it and/or additional cybersecurity incidents, as well as the effectiveness of business continuity plans during any future cybersecurity incidents, (xi) risks related to failing to maintain expected service levels when providing our SaaS and Expert Services or retaining our SaaS and Expert Services customers, (xii) Omnicell’s ability to meet the demands of, or maintain relationships with, GPOs and its institutional, retail, and specialty pharmacy customers, (xiii) the inability to secure or maintain access to existing and future specialty drugs or pharmacy provider networks for our specialty pharmacy customers, (xiv) continued and increased competition from current and future competitors in the medication management automation solutions market and the medication adherence solutions market, (xv) risks related to Omnicell’s investments in new business strategies or initiatives, including its transition to selling more products and services on a subscription basis, and its ability to acquire companies, businesses or technologies and successfully integrate such acquisitions, (xvi) Omnicell’s substantial debt, (xvii) risks presented by government regulations, legislative changes, fraud and anti-kickback statues, products liability claims, the outcome of legal proceedings, and other legal obligations related to healthcare, privacy, data protection, and information security, and the costs of compliance with, and potential liability associated with, our actual or perceived failure to comply with such obligations, including any potential governmental investigations and enforcement actions, litigation, fines and penalties, exposure to indemnification obligations or other liabilities, and adverse publicity related to the same, (xviii) changes to the 340B Program, (xix) our international operations may subject us to additional risks, including from the impact of tariffs, (xx) covenants in our credit agreement could restrict our business and operations, (xxi) exposure to liquidity and counterparty risk as a result of financial institution and money market fund concentration, (xxii) risks related to climate change, legal, regulatory or market measures to address climate change and related emphasis on ESG matters by various stakeholders, (xxiii)

[0000926326-26-000009:8k_2_02:38]
Use of Non-GAAP Financial Information

[0000926326-26-000009:8k_2_02:39]
This press release contains financial measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP product gross profit, non-GAAP product gross margin, non-GAAP service gross profit, non-GAAP service gross margin, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to revenues, product gross profit, service gross profit, gross profit, operating expenses, income from operations, net income, net income per diluted share, diluted shares, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results and metrics because management considers them to be important supplemental measures of Omnicell’s performance and refers to such measures when analyzing Omnicell’s strategy and operations.

[0000926326-26-000009:8k_2_02:40]
Our non-GAAP product gross profit, non-GAAP product gross margin, non-GAAP service gross profit, non-GAAP service gross margin, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within such period that directly drive operating income in such period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results: non-GAAP product gross profit, non-GAAP product gross margin, non-GAAP service gross profit, non-GAAP service gross margin, non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items a) and b) below; non-GAAP operating expenses, non-GAAP income from operations and non-GAAP operating margin exclude from their GAAP equivalents items a), b), c), e), f), and g) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through g) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents items a), c), d), e), f), and g) below:

[0000926326-26-000009:8k_2_02:41]
a)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as it represents expenses that do not require cash settlement from Omnicell.

[0000926326-26-000009:8k_2_02:42]
b)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-26-000009:8k_2_02:43]
c)Acquisition-related expenses. We excluded from our non-GAAP results the expenses related to recent acquisitions, including amortization of representations and warranties insurance. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of acquisition activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-26-000009:8k_2_02:44]
d)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of revolving credit facilities and convertible senior notes. The costs include underwriting fees, original issue discount, ticking fees, and legal

[0000926326-26-000009:8k_2_02:45]
fees. These non-cash expenses are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-26-000009:8k_2_02:46]
e)Legal and regulatory expenses. We excluded from our non-GAAP results certain non-recurring legal and regulatory expenses, representing settlement amounts, related to certain claims of non-compliance with our government contracts that are outside of the ordinary course of our business. We believe that excluding these amounts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-26-000009:8k_2_02:47]
f)Management severance costs. We excluded from our non-GAAP results the severance expense of certain senior management associated with the restructuring of our senior leadership team. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-26-000009:8k_2_02:48]
g)Executives transition costs. We excluded from our non-GAAP results the transition costs associated with the departure of a certain executive officer, primarily consisting of severance expenses. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-26-000009:8k_2_02:49]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving stock compensation plans or other items.

[0000926326-26-000009:8k_2_02:50]
We believe that the presentation of non-GAAP product gross profit, non-GAAP product gross margin, non-GAAP service gross profit, non-GAAP service gross margin, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0000926326-26-000009:8k_2_02:51]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-26-000009:8k_2_02:52]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-26-000009:8k_2_02:53]
c)These non-GAAP financial measures are employed by management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting.

[0000926326-26-000009:8k_2_02:54]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-26-000009:8k_2_02:55]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-26-000009:8k_2_02:56]
i)While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-26-000009:8k_2_02:57]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-26-000009:8k_2_02:58]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. Additionally, in a period of net loss, GAAP diluted shares are further adjusted for certain shares whose effect would be dilutive in a period of net income. We

[0000926326-26-000009:8k_2_02:59]
believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0000926326-26-000009:8k_2_02:60]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-26-000009:8k_2_02:61]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-26-000009:8k_2_02:62]
a)Omnicell’s equity incentive plans and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-26-000009:8k_2_02:63]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-26-000009:8k_2_02:64]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-26-000009:8k_2_02:65]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release as well as in Omnicell’s other reports filed with or furnished to the SEC.

[0000926326-26-000009:8k_2_02:66]
Omnicell, Inc.

[0000926326-26-000009:8k_2_02:67]
Condensed Consolidated Statements of Operations

[0000926326-26-000009:8k_2_02:68]
(Unaudited, in thousands, except per share data)

[0000926326-26-000009:8k_2_02:69]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 174,800 |  |  | $ | 145,168 |  |  |  |  |  |
| Service revenues | 135,080 |  |  | 124,500 |  |  |  |  |  |
| Total revenues | 309,880 |  |  | 269,668 |  |  |  |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 95,518 |  |  | 85,585 |  |  |  |  |  |
| Cost of service revenues | 73,999 |  |  | 73,147 |  |  |  |  |  |
| Total cost of revenues | 169,517 |  |  | 158,732 |  |  |  |  |  |
| Gross profit | 140,363 |  |  | 110,936 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 21,519 |  |  | 20,526 |  |  |  |  |  |
| Selling, general, and administrative | 101,990 |  |  | 102,029 |  |  |  |  |  |
| Total operating expenses | 123,509 |  |  | 122,555 |  |  |  |  |  |
| Income (loss) from operations | 16,854 |  |  | (11,619) |  |  |  |  |  |
| Interest and other income (expense), net | 51 |  |  | 2,089 |  |  |  |  |  |
| Income (loss) before income taxes | 16,905 |  |  | (9,530) |  |  |  |  |  |
| Provision for (benefit from) income taxes | 5,547 |  |  | (2,507) |  |  |  |  |  |
| Net income (loss) | $ | 11,358 |  |  | $ | (7,023) |  |  |  |  |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.25 |  |  | $ | (0.15) |  |  |  |  |  |
| Diluted | $ | 0.25 |  |  | $ | (0.15) |  |  |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 45,323 |  |  | 46,596 |  |  |  |  |  |
| Diluted | 45,943 |  |  | 46,596 |  |  |  |  |  |

[0000926326-26-000009:8k_2_02:70]
7

[0000926326-26-000009:8k_2_02:71]
Omnicell, Inc.

[0000926326-26-000009:8k_2_02:72]
Condensed Consolidated Balance Sheets

[0000926326-26-000009:8k_2_02:73]
(Unaudited, in thousands)

[0000926326-26-000009:8k_2_02:74]
|  | March 31,2026 |  | December 31,2025 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 239,221 |  |  | $ | 196,520 |  |
| Accounts receivable and unbilled receivables, net | 249,797 |  |  | 216,858 |  |
| Inventories | 99,204 |  |  | 100,905 |  |
| Prepaid expenses | 33,652 |  |  | 33,709 |  |
| Other current assets | 100,429 |  |  | 132,077 |  |
| Total current assets | 722,303 |  |  | 680,069 |  |
| Property and equipment, net | 121,500 |  |  | 120,111 |  |
| Long-term investment in sales-type leases, net | 58,207 |  |  | 60,742 |  |
| Operating lease right-of-use assets | 22,954 |  |  | 24,366 |  |
| Goodwill | 737,287 |  |  | 737,946 |  |
| Intangible assets, net | 165,431 |  |  | 170,105 |  |
| Long-term deferred tax assets | 54,064 |  |  | 58,337 |  |
| Prepaid commissions | 54,812 |  |  | 52,840 |  |
| Other long-term assets | 67,549 |  |  | 70,204 |  |
| Total assets | $ | 2,004,107 |  |  | $ | 1,974,720 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 58,343 |  |  | $ | 43,990 |  |
| Accrued compensation | 46,407 |  |  | 57,172 |  |
| Accrued liabilities | 166,410 |  |  | 203,586 |  |
| Deferred revenues | 211,889 |  |  | 171,861 |  |
| Total current liabilities | 483,049 |  |  | 476,609 |  |
| Long-term deferred revenues | 63,066 |  |  | 63,254 |  |
| Long-term deferred tax liabilities | 638 |  |  | 683 |  |
| Long-term operating lease liabilities | 22,659 |  |  | 24,794 |  |
| Other long-term liabilities | 10,165 |  |  | 9,970 |  |
| Convertible senior notes, net | 167,899 |  |  | 167,596 |  |
| Total liabilities | 747,476 |  |  | 742,906 |  |
| Total stockholders’ equity | 1,256,631 |  |  | 1,231,814 |  |
| Total liabilities and stockholders’ equity | $ | 2,004,107 |  |  | $ | 1,974,720 |  |

[0000926326-26-000009:8k_2_02:75]
Omnicell, Inc.

[0000926326-26-000009:8k_2_02:76]
Condensed Consolidated Statements of Cash Flows

[0000926326-26-000009:8k_2_02:77]
(Unaudited, in thousands)

[0000926326-26-000009:8k_2_02:78]
|  | Three Months Ended March 31, |
|  | 2026 |  | 2025 |
| Operating Activities |  |  |  |
| Net income (loss) | $ | 11,358 |  |  | $ | (7,023) |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |
| Depreciation and amortization | 18,572 |  |  | 19,995 |  |
| Loss on disposal of assets | 122 |  |  | 111 |  |
| Share-based compensation expense | 9,498 |  |  | 10,786 |  |
| Deferred income taxes | 4,228 |  |  | (3,835) |  |
| Amortization of operating lease right-of-use assets | 1,928 |  |  | 1,846 |  |
| Amortization of debt issuance costs | 497 |  |  | 735 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | (33,301) |  |  | 5,545 |  |
| Inventories | 1,701 |  |  | (2,483) |  |
| Prepaid expenses | 57 |  |  | (809) |  |
| Other current assets | (4,866) |  |  | (3,401) |  |
| Investment in sales-type leases | 2,766 |  |  | 84 |  |
| Prepaid commissions | (1,972) |  |  | (3,102) |  |
| Other long-term assets | 1,297 |  |  | 1,650 |  |
| Accounts payable | 16,176 |  |  | 931 |  |
| Accrued compensation | (10,765) |  |  | (14,230) |  |
| Accrued liabilities | (292) |  |  | 1,380 |  |
| Deferred revenues | 40,275 |  |  | 20,184 |  |
| Operating lease liabilities | (2,974) |  |  | (2,804) |  |
| Other long-term liabilities | 195 |  |  | 364 |  |
| Net cash provided by operating activities | 54,500 |  |  | 25,924 |  |
| Investing Activities |  |  |  |
| External-use software development costs | (3,432) |  |  | (4,567) |  |
| Purchases of property and equipment | (12,435) |  |  | (11,172) |  |
| Net cash used in investing activities | (15,867) |  |  | (15,739) |  |
| Financing Activities |  |  |  |
| Proceeds from issuances under stock-based compensation plans | 7,762 |  |  | 8,266 |  |
| Employees’ taxes paid related to restricted stock units | (2,603) |  |  | (2,391) |  |
| Change in customer funds, net | (2,768) |  |  | (1,837) |  |
| Net cash provided by financing activities | 2,391 |  |  | 4,038 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,091) |  |  | 1,565 |  |
| Net increase in cash, cash equivalents, and restricted cash | 39,933 |  |  | 15,788 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 251,032 |  |  | 398,614 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 290,965 |  |  | $ | 414,402 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |
| Cash and cash equivalents | $ | 239,221 |  |  | $ | 386,826 |  |
| Restricted cash included in other current assets | 51,744 |  |  | 27,576 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 290,965 |  |  | $ | 414,402 |  |

[0000926326-26-000009:8k_2_02:79]
9

[0000926326-26-000009:8k_2_02:80]
Omnicell, Inc.

[0000926326-26-000009:8k_2_02:81]
Reconciliation of GAAP to Non-GAAP

[0000926326-26-000009:8k_2_02:82]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-26-000009:8k_2_02:83]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Reconciliation of GAAP product gross profit to non-GAAP product gross profit: |  |  |  |  |  |  |  |
| GAAP product revenues | $ | 174,800 |  |  | $ | 145,168 |  |  |  |  |  |
| GAAP cost of product revenues | 95,518 |  |  | 85,585 |  |  |  |  |  |
| GAAP product gross profit | $ | 79,282 |  |  | $ | 59,583 |  |  |  |  |  |
| GAAP product gross margin | 45.4% |  | 41.0% |  |  |  |  |
| Share-based compensation expense | 541 |  |  | 900 |  |  |  |  |  |
| Amortization of acquired intangibles | 333 |  |  | 349 |  |  |  |  |  |
| Non-GAAP product gross profit | $ | 80,156 |  |  | $ | 60,832 |  |  |  |  |  |
| Non-GAAP product gross margin | 45.9% |  | 41.9% |  |  |  |  |
| Reconciliation of GAAP service gross profit to non-GAAP service gross profit: |  |  |  |  |
| GAAP service revenues | $ | 135,080 |  |  | $ | 124,500 |  |  |  |  |  |
| GAAP cost of service revenues | 73,999 |  |  | 73,147 |  |  |  |  |  |
| GAAP service gross profit | $ | 61,081 |  |  | $ | 51,353 |  |  |  |  |  |
| GAAP service gross margin | 45.2% |  | 41.2% |  |  |  |  |
| Share-based compensation expense | 708 |  |  | 818 |  |  |  |  |  |
| Amortization of acquired intangibles | 309 |  |  | 658 |  |  |  |  |  |
| Non-GAAP service gross profit | $ | 62,098 |  |  | $ | 52,829 |  |  |  |  |  |
| Non-GAAP service gross margin | 46.0% |  | 42.4% |  |  |  |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |
| GAAP gross profit | $ | 140,363 |  |  | $ | 110,936 |  |  |  |  |  |
| GAAP gross margin | 45.3% |  | 41.1% |  |  |  |  |
| Share-based compensation expense | 1,249 |  |  | 1,718 |  |  |  |  |  |
| Amortization of acquired intangibles | 642 |  |  | 1,007 |  |  |  |  |  |
| Non-GAAP gross profit | $ | 142,254 |  |  | $ | 113,661 |  |  |  |  |  |
| Non-GAAP gross margin | 45.9% |  | 42.1% |  |  |  |  |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 123,509 |  |  | $ | 122,555 |  |  |  |  |  |
| GAAP operating expenses % to total revenues | 39.9% |  | 45.4% |  |  |  |  |
| Share-based compensation expense | (8,249) |  |  | (9,068) |  |  |  |  |  |
| Amortization of acquired intangibles | (3,975) |  |  | (4,721) |  |  |  |  |  |
| Acquisition-related expenses | (182) |  |  | (182) |  |  |  |  |  |
| Legal and regulatory expenses | — |  |  | (2,700) |  |  |  |  |  |
| Management severance costs | — |  |  | (562) |  |  |  |  |  |
| Executives transition costs | — |  |  | (968) |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 111,103 |  |  | $ | 104,354 |  |  |  |  |  |
| Non-GAAP operating expenses as a % of total revenues | 35.9% |  | 38.7% |  |  |  |  |

[0000926326-26-000009:8k_2_02:84]
Omnicell, Inc.

[0000926326-26-000009:8k_2_02:85]
Reconciliation of GAAP to Non-GAAP

[0000926326-26-000009:8k_2_02:86]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-26-000009:8k_2_02:87]
|  | Three Months Ended March 31, |  |  |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income from operations: |  |  |  |  |  |  |  |
| GAAP income (loss) from operations | $ | 16,854 |  |  | $ | (11,619) |  |  |  |  |  |
| GAAP operating income (loss) % to total revenues | 5.4% |  | (4.3)% |  |  |  |  |
| Share-based compensation expense | 9,498 |  |  | 10,786 |  |  |  |  |  |
| Amortization of acquired intangibles | 4,617 |  |  | 5,728 |  |  |  |  |  |
| Acquisition-related expenses | 182 |  |  | 182 |  |  |  |  |  |
| Legal and regulatory expenses | — |  |  | 2,700 |  |  |  |  |  |
| Management severance costs | — |  |  | 562 |  |  |  |  |  |
| Executives transition costs | — |  |  | 968 |  |  |  |  |  |
| Non-GAAP income from operations | $ | 31,151 |  |  | $ | 9,307 |  |  |  |  |  |
| Non-GAAP operating margin (non-GAAP operating income as a % of total revenues) | 10.1% |  | 3.5% |  |  |  |  |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |
| GAAP net income (loss) | $ | 11,358 |  |  | $ | (7,023) |  |  |  |  |  |
| Share-based compensation expense | 9,498 |  |  | 10,786 |  |  |  |  |  |
| Amortization of acquired intangibles | 4,617 |  |  | 5,728 |  |  |  |  |  |
| Acquisition-related expenses | 182 |  |  | 182 |  |  |  |  |  |
| Legal and regulatory expenses | — |  |  | 2,700 |  |  |  |  |  |
| Management severance costs | — |  |  | 562 |  |  |  |  |  |
| Executives transition costs | — |  |  | 968 |  |  |  |  |  |
| Amortization of debt issuance costs | 497 |  |  | 735 |  |  |  |  |  |
| Tax effect of the adjustments above (a) | (1,112) |  |  | (2,284) |  |  |  |  |  |
| Non-GAAP net income | $ | 25,040 |  |  | $ | 12,354 |  |  |  |  |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 45,943 |  |  | 46,596 |  |  |  |  |  |
| Shares - diluted non-GAAP | 45,943 |  |  | 47,003 |  |  |  |  |  |
| GAAP net income (loss) per share - diluted | $ | 0.25 |  |  | $ | (0.15) |  |  |  |  |  |
| Share-based compensation expense | 0.21 |  |  | 0.23 |  |  |  |  |  |
| Amortization of acquired intangibles | 0.10 |  |  | 0.12 |  |  |  |  |  |
| Acquisition-related expenses | 0.00 |  |  | 0.00 |  |  |  |  |  |
| Legal and regulatory expenses | — |  |  | 0.06 |  |  |  |  |  |
| Management severance costs | — |  |  | 0.01 |  |  |  |  |  |
| Executives transition costs | — |  |  | 0.02 |  |  |  |  |  |
| Amortization of debt issuance costs | 0.01 |  |  | 0.02 |  |  |  |  |  |
| Tax effect of the adjustments above (a) | (0.02) |  |  | (0.05) |  |  |  |  |  |
| Non-GAAP net income per share - diluted | $ | 0.55 |  |  | $ | 0.26 |  |  |  |  |  |

[0000926326-26-000009:8k_2_02:88]
11

[0000926326-26-000009:8k_2_02:89]
Omnicell, Inc.

[0000926326-26-000009:8k_2_02:90]
Reconciliation of GAAP to Non-GAAP

[0000926326-26-000009:8k_2_02:91]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-26-000009:8k_2_02:92]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Reconciliation of GAAP net income (loss) to non-GAAP EBITDA (b): |
| GAAP net income (loss) | $ | 11,358 |  |  | $ | (7,023) |  |  |  |  |  |
| Share-based compensation expense | 9,498 |  |  | 10,786 |  |  |  |  |  |
| Interest (income) and expense, net | (1,000) |  |  | (2,805) |  |  |  |  |  |
| Depreciation and amortization expense | 18,572 |  |  | 19,995 |  |  |  |  |  |
| Acquisition-related expenses | 182 |  |  | 182 |  |  |  |  |  |
| Legal and regulatory expenses | — |  |  | 2,700 |  |  |  |  |  |
| Management severance costs | — |  |  | 562 |  |  |  |  |  |
| Executives transition costs | — |  |  | 968 |  |  |  |  |  |
| Amortization of debt issuance costs | 497 |  |  | 735 |  |  |  |  |  |
| Provision for (benefit from) income taxes | 5,547 |  |  | (2,507) |  |  |  |  |  |
| Non-GAAP EBITDA | $ | 44,654 |  |  | $ | 23,593 |  |  |  |  |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA as a % of total revenues) | 14.4% |  | 8.7% |  |  |  |  |

[0000926326-26-000009:8k_2_02:93]
______________________________________________

[0000926326-26-000009:8k_2_02:94]
(a)Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2026 and 2025.

[0000926326-26-000009:8k_2_02:95]
(b)Defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments.

[0000926326-26-000009:8k_2_02:96]
Omnicell, Inc.

[0000926326-26-000009:8k_2_02:97]
Reconciliation of GAAP to Non-GAAP

[0000926326-26-000009:8k_2_02:98]
(Unaudited, in thousands)

[0000926326-26-000009:8k_2_02:99]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Reconciliation of GAAP net cash provided by operating activities to non-GAAP free cash flow: |
| GAAP net cash provided by operating activities | $ | 54,500 |  |  | $ | 25,924 |  |  |  |  |  |
| External-use software development costs | (3,432) |  |  | (4,567) |  |  |  |  |  |
| Purchases of property and equipment | (12,435) |  |  | (11,172) |  |  |  |  |  |
| Non-GAAP free cash flow | $ | 38,633 |  |  | $ | 10,185 |  |  |  |  |  |

[0000926326-26-000009:8k_2_02:100]
13
