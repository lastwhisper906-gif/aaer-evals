# OMCL notes — 0000926326-26-000012


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-26-000012:notes:1]
[same as prior period, unchanged from 0000926326-25-000031:notes:1]

[0000926326-26-000012:notes:2]
[same as prior period, unchanged from 0000926326-25-000031:notes:2]

[0000926326-26-000012:notes:3]
[same as prior period, unchanged from 0000926326-25-000031:notes:3]

[0000926326-26-000012:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2026 and December 31, 2025, and the results of operations, comprehensive income (loss), and cash flows for the three months ended March 31, 2026 and 2025. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2025, filed with the SEC on February 26, 2026. The Company’s results of operations, comprehensive income (loss), and cash flows for the three months ended March 31, 2026 are not necessarily indicative of results that may be expected for the year ending December 31, 2026, or for any future period.

[0000926326-26-000012:notes:5]
[same as prior period, unchanged from 0000926326-25-000031:notes:5]

[0000926326-26-000012:notes:6]
[same as prior period, unchanged from 0000926326-25-000031:notes:6]

[0000926326-26-000012:notes:7]
[same as prior period, unchanged from 0000926326-25-000031:notes:7]

[0000926326-26-000012:notes:8]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes to Condensed Consolidated Financial Statements. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting estimates are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. Those estimates are revenue recognition, inventory valuation, and accounting for income taxes. As of March 31, 2026, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-26-000012:notes:9]
[same as prior period, unchanged from 0000926326-25-000031:notes:9]

[0000926326-26-000012:notes:10]
[same as prior period, unchanged from 0000926326-25-000031:notes:10]

[0000926326-26-000012:notes:11]
[same as prior period, unchanged from 0000926326-25-000031:notes:11]

[0000926326-26-000012:notes:12]
[same as prior period, unchanged from 0000926326-25-000031:notes:12]

[0000926326-26-000012:notes:13]
[same as prior period, unchanged from 0000926326-25-000031:notes:13]

[0000926326-26-000012:notes:14]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosure (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosures of additional information and disaggregation of certain expenses included in the income statement. The amendments are effective for the Company’s annual periods beginning January 1, 2027, and for interim periods within fiscal years beginning January 1, 2028, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2024-03 will have on its consolidated financial statements.

[0000926326-26-000012:notes:15]
In September 2025, the FASB issued ASU 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal Use Software, which removes all references to software development project stages, and requires capitalization of software costs to begin when (i) management has authorized and committed to funding the software project, and (ii) it is probable the project will be completed and the software will be used to perform its intended function. The amendments are effective for the Company’s annual periods beginning January 1, 2028, and for interim periods within fiscal years beginning January 1, 2028, with early adoption permitted, and can be applied prospectively, retrospectively, or utilizing a modified transition approach. The Company is currently evaluating the impact ASU 2025-06 will have on its consolidated financial statements.

[0000926326-26-000012:notes:16]
[same as prior period, unchanged from 0000926326-25-000031:notes:18]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-26-000012:notes:17]
[same as prior period, unchanged from 0000926326-25-000031:notes:19]

[0000926326-26-000012:notes:18]
[same as prior period, unchanged from 0000926326-25-000031:notes:20]

[0000926326-26-000012:notes:19]
The CODM is also provided with certain segment assets, primarily those that impact liquidity, such as cash and cash equivalents, accounts receivable and inventories, as well as certain liabilities such as accounts payable and outstanding debt. Assets and liabilities provided to the CODM are consistent with those reported on the Condensed Consolidated Balance Sheets. In addition, the CODM is regularly provided with significant expenses, which are adjusted cost of product and service revenues and adjusted operating expenses. These significant expenses are adjusted for certain non-cash charges and expenses that are unrelated to the Company’s ongoing operations. Adjusted cost of product revenues and adjusted cost of service revenues exclude certain items such as share-based compensation expense and amortization of acquired intangibles. Adjusted operating expenses include research and development, and selling, general and administrative expenses, and exclude certain items such as share-based compensation expense, amortization of acquired intangibles, legal and regulatory expenses, and certain restructuring and severance charges. To align with the significant expenses provided to the CODM for the three months ended March 31, 2026, certain prior-year significant expenses have been recast to conform with current-period presentation. Depreciation and amortization expense for the Company’s single reportable segment was $18.6 million and $20.0 million for the three months ended March 31, 2026 and 2025, respectively.

[0000926326-26-000012:notes:20]
[same as prior period, unchanged from 0000926326-25-000031:notes:22]

[0000926326-26-000012:notes:21]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In thousands) |
| Total revenues | $ | 309,880 |  |  | $ | 269,668 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |
| Adjusted cost of product revenues | (94,644) |  |  | (84,336) |  |  |  |  |  |
| Adjusted cost of service revenues | (72,982) |  |  | (71,671) |  |  |  |  |  |
| Adjusted operating expenses | (111,103) |  |  | (104,354) |  |  |  |  |  |
| Other segment items (1) | (14,297) |  |  | (20,926) |  |  |  |  |  |
| Interest and other income (expense), net | 51 |  |  | 2,089 |  |  |  |  |  |
| Provision for (benefit from) income taxes | 5,547 |  |  | (2,507) |  |  |  |  |  |
| Net income (loss) | $ | 11,358 |  |  | $ | (7,023) |  |  |  |  |  |

[0000926326-26-000012:notes:22]
[same as prior period, unchanged from 0000926326-25-000031:notes:24]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-26-000012:notes:23]
[same as prior period, unchanged from 0000926326-25-000031:notes:25]

[0000926326-26-000012:notes:24]
[same as prior period, unchanged from 0000926326-25-000031:notes:26]

[0000926326-26-000012:notes:25]
[same as prior period, unchanged from 0000926326-25-000031:notes:27]

[0000926326-26-000012:notes:26]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multi-medication adherence packaging and single-dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other non-acute healthcare facilities, and are designed to improve patient engagement and adherence to prescriptions.

[0000926326-26-000012:notes:27]
Technical services. Post-installation technical support and other related services (support and maintenance), including phone and/or web support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.

[0000926326-26-000012:notes:28]
Software as a Service (“SaaS”) and Expert Services. Software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.

[0000926326-26-000012:notes:29]
[same as prior period, unchanged from 0000926326-25-000031:notes:31]

[0000926326-26-000012:notes:30]
[same as prior period, unchanged from 0000926326-25-000031:notes:32]

[0000926326-26-000012:notes:31]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $1.9 million and $2.2 million for the three months ended March 31, 2026 and 2025, respectively.

[0000926326-26-000012:notes:32]
[same as prior period, unchanged from 0000926326-25-000031:notes:34]

[0000926326-26-000012:notes:33]
[same as prior period, unchanged from 0000926326-25-000031:notes:35]

[0000926326-26-000012:notes:34]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 148,662 |  |  | $ | 120,077 |  |  |  |  |  |
| Consumables | 26,138 |  |  | 25,091 |  |  |  |  |  |
| Technical services | 66,923 |  |  | 61,379 |  |  |  |  |  |
| SaaS and Expert Services | 68,157 |  |  | 63,121 |  |  |  |  |  |
| Total revenues | $ | 309,880 |  |  | $ | 269,668 |  |  |  |  |  |

[0000926326-26-000012:notes:35]
[same as prior period, unchanged from 0000926326-25-000031:notes:37]

[0000926326-26-000012:notes:36]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In thousands) |
| United States | $ | 278,097 |  |  | $ | 249,264 |  |  |  |  |  |
| Rest of world (1) | 31,783 |  |  | 20,404 |  |  |  |  |  |
| Total revenues | $ | 309,880 |  |  | $ | 269,668 |  |  |  |  |  |

[0000926326-26-000012:notes:37]
[same as prior period, unchanged from 0000926326-25-000031:notes:39]

[0000926326-26-000012:notes:38]
[same as prior period, unchanged from 0000926326-25-000031:notes:40]

[0000926326-26-000012:notes:39]
[same as prior period, unchanged from 0000926326-25-000031:notes:41]

[0000926326-26-000012:notes:40]
[same as prior period, unchanged from 0000926326-25-000031:notes:42]

[0000926326-26-000012:notes:41]
|  | March 31,2026 |  | December 31,2025 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 31,833 |  |  | $ | 28,396 |  |
| Long-term unbilled receivables, net (2) | 2,791 |  |  | 3,521 |  |
| Total contract assets | $ | 34,624 |  |  | $ | 31,917 |  |
| Short-term deferred revenues | $ | 211,889 |  |  | $ | 171,861 |  |
| Long-term deferred revenues | 63,066 |  |  | 63,254 |  |
| Total contract liabilities | $ | 274,955 |  |  | $ | 235,115 |  |

[0000926326-26-000012:notes:42]
[same as prior period, unchanged from 0000926326-25-000031:notes:44]

[0000926326-26-000012:notes:43]
[same as prior period, unchanged from 0000926326-25-000031:notes:45]

[0000926326-26-000012:notes:44]
[same as prior period, unchanged from 0000926326-25-000031:notes:46]

[0000926326-26-000012:notes:45]
[same as prior period, unchanged from 0000926326-25-000031:notes:47]

[0000926326-26-000012:notes:46]
During the three months ended March 31, 2026, the Company recognized revenues of $63.4 million that were included in the corresponding short-term deferred revenues balance of $171.9 million as of December 31, 2025.

[0000926326-26-000012:notes:47]
Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, but where services have not yet been provided. Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term technical and SaaS and Expert Services contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time. SaaS and Expert Services agreements are generally invoiced periodically on a monthly, quarterly or annual basis over the life of the agreement. In certain circumstances, portions of these agreements may be invoiced lump sum.

[0000926326-26-000012:notes:48]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and SaaS and Expert Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $382.9 million as of March 31, 2026. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

[0000926326-26-000012:notes:49]
[same as prior period, unchanged from 0000926326-25-000031:notes:51]

[0000926326-26-000012:notes:50]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2026 and 2025. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable and unbilled receivables balance as of March 31, 2026 and December 31, 2025.


## us-gaap:EarningsPerShareTextBlock

[0000926326-26-000012:notes:51]
Net Income (Loss) Per Share
Basic net income (loss) per share is computed by dividing net income (loss) for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period, using the treasury stock method for share-based awards and warrants, and the if-converted method for convertible senior notes. Potential common stock includes the effect of outstanding dilutive stock options, restricted

[0000926326-26-000012:notes:52]
stock awards, and restricted stock units, as well as shares the Company could be obligated to issue from its convertible senior notes and warrants, as described in Note 11, Convertible Senior Notes. In the event of the conversion of the Company’s convertible senior notes, the principal portion will be settled in cash with any conversion consideration in excess of the principal portion settled in cash and/or shares of the Company’s common stock at the Company’s option, therefore, only the amounts expected to be settled in excess of the principal portion are considered dilutive in calculating earnings per share under the if-converted method. Any anti-dilutive weighted-average dilutive shares related to stock award plans, convertible senior notes, and warrants are excluded from the computation of the diluted net income per share.

[0000926326-26-000012:notes:53]
[same as prior period, unchanged from 0000926326-25-000031:notes:54]

[0000926326-26-000012:notes:54]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | 11,358 |  |  | $ | (7,023) |  |  |  |  |  |
| Weighted-average shares outstanding – basic | 45,323 |  |  | 46,596 |  |  |  |  |  |
| Effect of dilutive securities from stock award plans | 620 |  |  | — |  |  |  |  |  |
| Weighted-average shares outstanding – diluted | 45,943 |  |  | 46,596 |  |  |  |  |  |
| Net income (loss) per share – basic | $ | 0.25 |  |  | $ | (0.15) |  |  |  |  |  |
| Net income (loss) per share – diluted | $ | 0.25 |  |  | $ | (0.15) |  |  |  |  |  |
| Anti-dilutive weighted-average shares related to stock award plans | 1,699 |  |  | 3,745 |  |  |  |  |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | 6,026 |  |  | 9,622 |  |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-26-000012:notes:55]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $239.2 million and $196.5 million as of March 31, 2026 and December 31, 2025, respectively, consisted of bank accounts and highly-liquid U.S. Government money market funds held in sweep and asset management accounts with financial institutions of high credit quality. As of March 31, 2026, a substantial portion of the Company’s cash and cash equivalents were held with a limited number of financial institutions and money market funds, which may expose the Company to concentration risk in the event of a failure or adverse condition affecting those entities. The Company continuously monitors the credit worthiness of the financial institutions in which it invests. The Company has not experienced any credit losses from its cash equivalents. As of March 31, 2026 and December 31, 2025, cash equivalents were $174.9 million and $148.6 million, respectively, which consisted of money market funds held in sweep and asset management accounts. The Company recorded interest income on its cash and cash equivalents of $1.5 million and $3.6 million for the three months ended March 31, 2026 and 2025, respectively, which is included within interest and other income (expense), net in the Condensed Consolidated Statements of Operations.

[0000926326-26-000012:notes:56]
[same as prior period, unchanged from 0000926326-25-000031:notes:57]

[0000926326-26-000012:notes:57]
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s credit facility is classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company’s convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. Refer to Note 10, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 11, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.

[0000926326-26-000012:notes:58]
[same as prior period, unchanged from 0000926326-25-000031:notes:59]

[0000926326-26-000012:notes:59]
|  | March 31,2026 |  | December 31,2025 |
|  | (In thousands) |
| Net carrying amount | 167,899 |  |  | 167,596 |  |
| Fair value | 167,434 |  |  | 185,869 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-26-000012:notes:60]
[same as prior period, unchanged from 0000926326-25-000031:notes:61]

[0000926326-26-000012:notes:61]
|  | March 31,2026 |  | December 31,2025 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 26,554 |  |  | $ | 26,245 |  |
| Work in process | 1,641 |  |  | 1,321 |  |
| Finished goods | 71,009 |  |  | 73,339 |  |
| Total inventories | $ | 99,204 |  |  | $ | 100,905 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 64,821 |  |  | $ | 101,104 |  |
| Deferred cost of sales | 15,366 |  |  | 10,819 |  |
| Net investment in sales-type leases, current portion | 14,417 |  |  | 14,648 |  |
| Other current assets | 5,825 |  |  | 5,506 |  |
| Total other current assets | $ | 100,429 |  |  | $ | 132,077 |  |
| Other long-term assets: |  |  |  |
| External-use software development costs, net | $ | 53,033 |  |  | $ | 54,197 |  |
| Unbilled receivables, net | 2,791 |  |  | 3,521 |  |
| Other long-term assets | 11,725 |  |  | 12,486 |  |
| Total other long-term assets | $ | 67,549 |  |  | $ | 70,204 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 11,622 |  |  | $ | 11,955 |  |
| Customer fund liabilities | 64,821 |  |  | 101,104 |  |
| Advance payments from customers | 9,281 |  |  | 10,514 |  |
| Rebate liabilities | 46,232 |  |  | 44,722 |  |
| Taxes payable | 5,650 |  |  | 4,017 |  |
| Other accrued liabilities | 28,804 |  |  | 31,274 |  |
| Total accrued liabilities | $ | 166,410 |  |  | $ | 203,586 |  |

[0000926326-26-000012:notes:62]
(1)    Includes restricted cash of $51.7 million and $54.5 million as of March 31, 2026 and December 31, 2025, respectively.

[0000926326-26-000012:notes:63]
The Company capitalizes certain cloud computing arrangement costs that are associated with service contracts, which are amortized using the straight-line method over the term of the arrangement. As of March 31, 2026 and December 31, 2025, capitalized costs associated with cloud computing arrangements, net of accumulated amortization, were $4.1 million and $4.6 million, respectively.

[0000926326-26-000012:notes:64]
[same as prior period, unchanged from 0000926326-25-000031:notes:65]

[0000926326-26-000012:notes:65]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In thousands) |
| Beginning balance | $ | (8,854) |  |  | $ | (17,195) |  |  |  |  |  |
| Other comprehensive income (loss): | (1,788) |  |  | 3,388 |  |  |  |  |  |
| Ending balance | $ | (10,642) |  |  | $ | (13,807) |  |  |  |  |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-26-000012:notes:66]
[same as prior period, unchanged from 0000926326-25-000031:notes:67]

[0000926326-26-000012:notes:67]
|  | March 31,2026 |  | December 31,2025 |
|  | (In thousands) |
| Equipment | $ | 105,465 |  |  | $ | 104,071 |  |
| Furniture and fixtures | 4,970 |  |  | 4,672 |  |
| Leasehold improvements | 19,538 |  |  | 18,606 |  |
| Purchased software and internal-use software development costs | 171,447 |  |  | 165,885 |  |
| Construction in progress | 24,638 |  |  | 23,426 |  |
| Property and equipment, gross | 326,058 |  |  | 316,660 |  |
| Accumulated depreciation and amortization | (204,558) |  |  | (196,549) |  |
| Total property and equipment, net | $ | 121,500 |  |  | $ | 120,111 |  |

[0000926326-26-000012:notes:68]
Depreciation and amortization expense of property and equipment was $9.2 million and $8.6 million for the three months ended March 31, 2026 and 2025, respectively, of which amortization expense related to purchased software and internal-use software development costs was $6.2 million and $5.4 million for the three months ended March 31, 2026 and 2025, respectively.

[0000926326-26-000012:notes:69]
[same as prior period, unchanged from 0000926326-25-000031:notes:70]

[0000926326-26-000012:notes:70]
|  | March 31,2026 |  | December 31,2025 |
|  | (In thousands) |
| United States | $ | 117,779 |  |  | $ | 116,102 |  |
| Rest of world | 3,721 |  |  | 4,009 |  |
| Total property and equipment, net | $ | 121,500 |  |  | $ | 120,111 |  |


## omcl:CapitalizedComputerSoftwareDisclosureTextBlock

[0000926326-26-000012:notes:71]
External-Use Software Development Costs
The carrying amounts of external-use software development costs were as follows:

[0000926326-26-000012:notes:72]
|  | March 31,2026 |  | December 31,2025 |
|  | (In thousands) |
| Gross carrying amount | $ | 270,092 |  |  | $ | 266,523 |  |
| Accumulated amortization | (217,059) |  |  | (212,326) |  |
| External-use software development costs, net (1) | $ | 53,033 |  |  | $ | 54,197 |  |

[0000926326-26-000012:notes:73]
(1)     Included in other long-term assets in the Condensed Consolidated Balance Sheets.

[0000926326-26-000012:notes:74]
The Company recorded $4.7 million and $5.7 million to cost of product revenues for amortization of external-use software development costs for the three months ended March 31, 2026 and 2025, respectively.

[0000926326-26-000012:notes:75]
The estimated future amortization expenses for external-use software development costs were as follows:

[0000926326-26-000012:notes:76]
|  | March 31,2026 |
|  | (In thousands) |
| Remaining nine months of 2026 | $ | 14,453 |  |
| 2027 | 14,503 |  |
| 2028 | 10,647 |  |
| 2029 | 8,020 |  |
| 2030 | 4,157 |  |
| Thereafter | 1,253 |  |
| Total | $ | 53,033 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-26-000012:notes:77]
[same as prior period, unchanged from 0000926326-25-000031:notes:78]

[0000926326-26-000012:notes:78]
[same as prior period, unchanged from 0000926326-25-000031:notes:79]

[0000926326-26-000012:notes:79]
|  |  |  |  |  | (In thousands) |
| Balance as of December 31, 2025 |  |  |  |  | $ | 737,946 |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | (659) |  |
| Balance as of March 31, 2026 |  |  |  |  | $ | 737,287 |  |

[0000926326-26-000012:notes:80]
[same as prior period, unchanged from 0000926326-25-000031:notes:81]

[0000926326-26-000012:notes:81]
[same as prior period, unchanged from 0000926326-25-000031:notes:82]

[0000926326-26-000012:notes:82]
|  | March 31, 2026 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 306,419 |  |  | $ | (152,965) |  |  | $ | (1,344) |  |  | $ | 152,110 |  |  | 10 - 30 |
| Acquired technology | 37,615 |  |  | (24,900) |  |  | — |  |  | 12,715 |  |  | 5 - 20 |
| Patents | 1,656 |  |  | (1,050) |  |  | — |  |  | 606 |  |  | 2 - 20 |
| Total intangible assets, net | $ | 345,690 |  |  | $ | (178,915) |  |  | $ | (1,344) |  |  | $ | 165,431 |  |  |  |

[0000926326-26-000012:notes:83]
|  | December 31, 2025 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 306,419 |  |  | $ | (148,990) |  |  | $ | (1,317) |  |  | $ | 156,112 |  |  | 10 - 30 |
| Acquired technology | 39,715 |  |  | (26,358) |  |  | — |  |  | 13,357 |  |  | 4 - 20 |
| Trade names | 2,400 |  |  | (2,400) |  |  | — |  |  | — |  |  | 5 |
| Patents | 1,656 |  |  | (1,020) |  |  | — |  |  | 636 |  |  | 2 - 20 |
| Total intangible assets, net | $ | 350,190 |  |  | $ | (178,768) |  |  | $ | (1,317) |  |  | $ | 170,105 |  |  |  |

[0000926326-26-000012:notes:84]
[same as prior period, unchanged from 0000926326-25-000031:notes:85]

[0000926326-26-000012:notes:85]
Amortization expense of intangible assets was $4.6 million and $5.8 million for the three months ended March 31, 2026 and 2025, respectively.

[0000926326-26-000012:notes:86]
[same as prior period, unchanged from 0000926326-25-000031:notes:87]

[0000926326-26-000012:notes:87]
|  | March 31,2026 |
|  | (In thousands) |
| Remaining nine months of 2026 | $ | 13,359 |  |
| 2027 | 16,506 |  |
| 2028 | 15,449 |  |
| 2029 | 13,952 |  |
| 2030 | 10,444 |  |
| Thereafter | 95,721 |  |
| Total | $ | 165,431 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-26-000012:notes:88]
Debt and Credit Agreement
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-26-000012:notes:89]
Loans under the Current Revolving Credit Facility bear interest, at Omnicell, Inc.’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility Omnicell, Inc. is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

[0000926326-26-000012:notes:90]
The Second A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Second A&R Credit Agreement contains financial covenants that require the Company to not exceed a maximum consolidated secured net leverage ratio (not to exceed 3.00:1) and maintain a minimum consolidated interest coverage ratio (not to be less than 3.00:1). In addition, the Second A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.

[0000926326-26-000012:notes:91]
Omnicell, Inc.’s obligations under the Second A&R Credit Agreement and, at the election of Omnicell, Inc. and the contracting counterparty, any secured swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the Second A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, Omnicell, Inc. and certain of Omnicell, Inc.’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement.

[0000926326-26-000012:notes:92]
As of both March 31, 2026 and December 31, 2025, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of March 31, 2026 and December 31, 2025, the Company had no outstanding balance

[0000926326-26-000012:notes:93]
under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of March 31, 2026.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-26-000012:notes:94]
On September 25, 2020, Omnicell, Inc. completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “2025 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the 2025 Notes. As referred to in this Note 11, “Omnicell, Inc.” or the “Company” refers only to Omnicell, Inc., excluding its subsidiaries. The 2025 Notes were issued pursuant to an indenture, dated September 25, 2020 (the “2025 Notes Indenture”), between the Company and U.S. Bank National Association, as trustee. Prior to maturity, the 2025 Notes were general senior, unsecured obligations of the Company and bore interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021.

[0000926326-26-000012:notes:95]
In November 2024, the Company repurchased $400.0 million of aggregate principal amount of the 2025 Notes. Subsequently, at maturity on September 15, 2025, the Company repaid the remaining principal balance of $175.0 million and $0.2 million of accrued interest in cash.

[0000926326-26-000012:notes:96]
1.00% Convertible Senior Notes due 2029

[0000926326-26-000012:notes:97]
On November 22, 2024, Omnicell, Inc. completed a private offering of $172.5 million aggregate principal amount of 1.00% Convertible Senior Notes due 2029 (the “2029 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $22.5 million aggregate principal amount of the 2029 Notes. Omnicell, Inc. received proceeds from the issuance of the 2029 Notes of $166.3 million, net of $6.2 million of transaction fees and other debt issuance costs. The 2029 Notes bear interest at a rate of 1.00% per year, payable semiannually in arrears on June 1 and December 1 of each year, beginning on June 1, 2025. The 2029 Notes were issued pursuant to an indenture, dated November 22, 2024 (the “2029 Notes Indenture”), between the Company and U.S. Bank Trust Company, National Association, as trustee. The 2029 Notes are general senior, unsecured obligations of the Company and will mature on December 1, 2029, unless earlier redeemed, purchased, or converted.

[0000926326-26-000012:notes:98]
The 2029 Notes are convertible at any time prior to the close of business on the business day immediately preceding August 1, 2029, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ending on March 31, 2025 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2029 Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the “trading price” (as defined in the 2029 Notes Indenture) per $1,000 principal amount of the 2029 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the 2029 Notes on each such trading day; (iii) if the Company calls such 2029 Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the 2029 Notes called (or deemed called) for redemption; or (iv) upon the occurrence of specified corporate events as set forth in the 2029 Notes Indenture. On or after August 1, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the 2029 Notes may convert all or any portion of their 2029 Notes at any time, regardless of the foregoing conditions.

[0000926326-26-000012:notes:99]
During the three months ended March 31, 2026 and December 31, 2025, none of the conditional conversion features of the 2029 Notes were triggered, and therefore, the 2029 Notes are not convertible during the second quarter of 2026, commencing on April 1, 2026, and were not convertible during the first quarter of 2026, commencing on January 1, 2026.

[0000926326-26-000012:notes:100]
Upon conversion, the Company will pay cash up to the aggregate principal amount of the 2029 Notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination of cash and shares of the Company’s common stock, at the Company’s election, in respect to the remainder, if any, of the Company’s conversion obligation in excess of the aggregate principal amount of the 2029 Notes being converted, in the manner and subject to the terms and conditions provided in the 2029 Notes Indenture.

[0000926326-26-000012:notes:101]
The initial conversion rate for the 2029 Notes is 17.4662 shares of the Company’s common stock per $1,000 principal amount of the 2029 Notes, which is equivalent to an initial conversion price of approximately $57.25 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the 2029 Notes Indenture. In addition, following certain corporate events that occur prior to the maturity date of the 2029 Notes or if the Company delivers a notice of redemption in respect of the 2029 Notes, the Company will, under certain circumstances, increase the conversion rate of the 2029 Notes for a holder who elects to convert its 2029 Notes (or any portion thereof) in connection

[0000926326-26-000012:notes:102]
with such a corporate event or convert its 2029 Notes called (or deemed called) for redemption during the related redemption period (as defined in the 2029 Notes Indenture), as the case may be.

[0000926326-26-000012:notes:103]
If the Company undergoes a fundamental change (as defined in the 2029 Notes Indenture), holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2029 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2026, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-26-000012:notes:104]
The Company may not redeem the 2029 Notes prior to December 6, 2027. The Company may redeem for cash all or any portion of the 2029 Notes, at its option, on or after December 6, 2027, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the 2029 Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. The Company may not redeem less than all of the outstanding 2029 Notes unless at least $100.0 million aggregate principal amount of 2029 Notes are outstanding and not called for redemption as of the time the Company sends the related notice of redemption. No sinking fund is provided for in the 2029 Notes.

[0000926326-26-000012:notes:105]
The debt issuance costs associated with the 2029 Notes are being amortized to interest expense over the term of the 2029 Notes using an effective interest rate of 1.75%. As of March 31, 2026, the remaining life of the 2029 Notes and the related issuance cost accretion is approximately 3.7 years.

[0000926326-26-000012:notes:106]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be approximately 3.0 million shares. As of March 31, 2026, the if-converted value of the 2029 Notes did not exceed the principal amount.

[0000926326-26-000012:notes:107]
The 2029 Notes consisted of the following balances:

[0000926326-26-000012:notes:108]
|  | March 31,2026 |  | December 31,2025 |
|  | (In thousands) |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (4,601) |  |  | (4,904) |  |
| Convertible senior notes, net | $ | 167,899 |  |  | $ | 167,596 |  |

[0000926326-26-000012:notes:109]
The following table summarizes the components of interest expense resulting from the 2025 Notes and the 2029 Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations:

[0000926326-26-000012:notes:110]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes | $ | — |  |  | $ | 109 |  |  |  |  |  |
| 2029 Notes | $ | 431 |  |  | $ | 431 |  |  |  |  |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes | $ | — |  |  | $ | 238 |  |  |  |  |  |
| 2029 Notes | $ | 303 |  |  | $ | 303 |  |  |  |  |  |

[0000926326-26-000012:notes:111]
Convertible Note Hedge and Warrant Transactions

[0000926326-26-000012:notes:112]
In connection with the issuance of the 2025 Notes in September 2020 and the 2029 Notes in November 2024, the Company entered into convertible note hedges and warrants transactions, respectively, with certain initial purchasers of the 2025 Notes and the 2029 Notes or affiliates thereof and certain other financial institutions (the “option counterparties”).

[0000926326-26-000012:notes:113]
The convertible note hedges related to the 2025 Notes consisted of call options for the Company to purchase, subject to anti-dilution adjustments substantially similar to those applicable to the 2025 Notes, up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2025 Notes at the time of its issuance, at an initial strike price of approximately $97.32 per share. The convertible note hedges related

[0000926326-26-000012:notes:114]
to the 2029 Notes consisted of call options for the Company to purchase up to, subject to anti-dilution adjustments substantially similar to those applicable to the 2029 Notes, approximately 3.0 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2029 Notes at the time of its issuance, at an initial strike price of approximately $57.25 per share. The convertible note hedges expire upon the maturity of the respective convertible notes, if not earlier exercised or terminated. The cost of the convertible note hedges related to the 2025 Notes and the 2029 Notes was approximately $100.6 million and $40.3 million, respectively, and each was accounted for as an equity instrument, each of which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. In addition, the Company recorded a deferred tax asset of $25.8 million and $10.2 million, respectively, at issuance related to the convertible note hedges for the 2025 Notes and the 2029 Notes. The 2029 Notes convertible note hedges are expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of the 2029 Notes and/or offset any cash payments the Company may be required to make in excess of the principal amount of the converted 2029 Notes.

[0000926326-26-000012:notes:115]
Separately from the convertible note hedges, in September 2020 and November 2024, the Company entered into warrant transactions to sell to the respective option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock at an initial strike price of approximately $141.56 and approximately 3.0 million shares of its common stock at an initial strike price of approximately $84.82 per share related to the 2025 Notes and the 2029 Notes, respectively. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million and $25.2 million for the issuance of the warrants related to the 2025 Notes and the 2029 Notes, respectively, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock, as measured under the warrants, exceeds the strike price of the warrants.
On September 15, 2025, the convertible note hedges related to the remaining 2025 Notes expired concurrently with the maturity of the 2025 Notes. No settlement was required as the Company’s stock price remained below the strike price at that time. In addition, following maturity of the 2025 Notes, the warrants issued in connection with the 2025 Notes terminate between December 15, 2025 and June 8, 2026.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-26-000012:notes:116]
[same as prior period, unchanged from 0000926326-25-000031:notes:119]

[0000926326-26-000012:notes:117]
[same as prior period, unchanged from 0000926326-25-000031:notes:120]

[0000926326-26-000012:notes:118]
[same as prior period, unchanged from 0000926326-25-000031:notes:121]

[0000926326-26-000012:notes:119]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In thousands) |
| Sales-type lease revenues | $ | 6,300 |  |  | $ | 5,818 |  |  |  |  |  |
| Cost of sales-type lease revenues | (3,773) |  |  | (2,937) |  |  |  |  |  |
| Selling profit on sales-type lease revenues | $ | 2,527 |  |  | $ | 2,881 |  |  |  |  |  |

[0000926326-26-000012:notes:120]
[same as prior period, unchanged from 0000926326-25-000031:notes:123]

[0000926326-26-000012:notes:121]
|  | March 31,2026 |  | December 31,2025 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 85,515 |  |  | $ | 88,372 |  |
| Less: Unearned interest income portion | (12,891) |  |  | (12,982) |  |
| Net investment in sales-type leases | 72,624 |  |  | 75,390 |  |
| Less: Current portion (1) | (14,417) |  |  | (14,648) |  |
| Long-term investment in sales-type leases, net | $ | 58,207 |  |  | $ | 60,742 |  |

[0000926326-26-000012:notes:122]
[same as prior period, unchanged from 0000926326-25-000031:notes:125]

[0000926326-26-000012:notes:123]
[same as prior period, unchanged from 0000926326-25-000031:notes:126]

[0000926326-26-000012:notes:124]
[same as prior period, unchanged from 0000926326-25-000031:notes:127]

[0000926326-26-000012:notes:125]
|  | March 31,2026 |
|  | (In thousands) |
| Remaining nine months of 2026 | $ | 13,234 |  |
| 2027 | 17,670 |  |
| 2028 | 16,571 |  |
| 2029 | 13,933 |  |
| 2030 | 9,656 |  |
| Thereafter | 14,451 |  |
| Total future minimum sales-type lease payments | 85,515 |  |
| Present value adjustment | (12,891) |  |
| Total net investment in sales-type leases | $ | 72,624 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-26-000012:notes:126]
Lessee Leases 
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to twelve years. As of March 31, 2026, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-26-000012:notes:127]
[same as prior period, unchanged from 0000926326-25-000031:notes:130]

[0000926326-26-000012:notes:128]
|  | March 31,2026 |
|  | (In thousands) |
| Remaining nine months of 2026 | $ | 10,115 |  |
| 2027 | 11,737 |  |
| 2028 | 10,034 |  |
| 2029 | 3,255 |  |
| 2030 | 763 |  |
| Thereafter | 1,573 |  |
| Total operating lease payments | 37,477 |  |
| Present value adjustment | (3,196) |  |
| Total operating lease liabilities (1) | $ | 34,281 |  |

[0000926326-26-000012:notes:129]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $11.6 million and $22.7 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-26-000012:notes:130]
Operating lease costs were $2.4 million for both the three months ended March 31, 2026 and 2025. Short-term lease costs and variable lease costs were not material for the three months ended March 31, 2026 and 2025.

[0000926326-26-000012:notes:131]
[same as prior period, unchanged from 0000926326-25-000031:notes:134]

[0000926326-26-000012:notes:132]
|  | Three Months Ended March 31, |
|  | 2026 |  | 2025 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 3,455 |  |  | $ | 3,381 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 820 |  |  | $ | 5,381 |  |

[0000926326-26-000012:notes:133]
[same as prior period, unchanged from 0000926326-25-000031:notes:136]

[0000926326-26-000012:notes:134]
|  | March 31,2026 |  | December 31,2025 |
| Weighted-average remaining lease term, years | 3.3 |  | 3.4 |
| Weighted-average discount rate, % | 5.5 | % |  | 5.5 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-26-000012:notes:135]
Commitments and Contingencies
Purchase Obligations

[0000926326-26-000012:notes:136]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2026, the Company had non-cancelable purchase commitments of $172.6 million, of which $133.7 million are expected to be paid within the year ending December 31, 2026.

[0000926326-26-000012:notes:137]
Legal Proceedings

[0000926326-26-000012:notes:138]
The Company is currently involved in various legal proceedings.

[0000926326-26-000012:notes:139]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual

[0000926326-26-000012:notes:140]
for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters either cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.

[0000926326-26-000012:notes:141]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company’s financial position or results of operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-26-000012:notes:142]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. For the three months ended March 31, 2026 and 2025, the Company recorded income tax expense of $5.5 million and income tax benefit of $2.5 million, respectively, by applying its estimated annual effective tax rate to its year-to-date measure of ordinary income and adjusted for $0.5 million and $0.6 million, respectively, of discrete income tax expense primarily from equity compensation.

[0000926326-26-000012:notes:143]
The effective tax rate for both the three months ended March 31, 2026 and 2025 differed from the statutory rate of 21% primarily due to the unfavorable impact of state taxes, non-deductible compensation and equity charges, partially offset by the favorable impact of the research and development credits and a Foreign-Derived Deduction-Eligible Income (“FDDEI”) benefit deduction.

[0000926326-26-000012:notes:144]
On July 4, 2025, the One Big Beautiful Bill Act (the “OBBBA”) was enacted in the United States, which includes significant tax reform provisions. Included in the OBBBA are provisions that allow for the immediate expensing of domestic United States research and development expenses, immediate expensing of certain capital expenditures, and other changes to the U.S. taxation of profits derived from foreign operations. Key international income tax provisions enacted by OBBBA became effective for the tax year 2026. Notable changes include modifications to the deduction for foreign‑derived income (formerly Foreign‑Derived Intangible Income, now Foreign‑Derived Deduction‑Eligible Income), revisions to the Global Intangible Low-Taxed Income regime (renamed Net Controlled Foreign Corporation (“CFC”) Tested Income), and related changes to the computation of certain international income inclusions. The OBBBA provisions did not have a significant impact on the Company’s results of operations, financial position, and cash flows for the three months ended March 31, 2026.

[0000926326-26-000012:notes:145]
The Organization for Economic Co-Operation and Development (“OECD”) has previously established a global minimum tax framework under its Base Erosion and Profit Shifting (“BEPS”) Pillar Two initiative, which is intended to ensure that in-scope multinational enterprise groups are subject to a minimum effective tax rate of 15% on a jurisdictional basis. In January 2026, the OECD issued additional Administrative Guidance, including the Side-by-Side (“SbS”) package, to further clarify and coordinate the application of the Pillar Two framework with certain domestic minimum tax regimes. These developments did not have an impact on the Company’s provision for income taxes for the three months ended March 31, 2026. The Company continues to monitor the evolving Pillar Two legislation in the jurisdictions in which it operates.

[0000926326-26-000012:notes:146]
As of March 31, 2026 and December 31, 2025, the Company had gross unrecognized tax benefits of $11.5 million and $11.3 million, respectively. The Company recognizes interest and penalties related to uncertain tax positions in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. Accrued interest and penalties are included within other long-term liabilities on the Condensed Consolidated Balance Sheets. As of March 31, 2026 and December 31, 2025, the amount of accrued interest and penalties was $1.3 million and $1.1 million, respectively.

[0000926326-26-000012:notes:147]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examinations by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, France, the United Kingdom and India. With few exceptions, as of March 31, 2026, the Company was no longer subject to federal U.S., state, and foreign tax examinations for years before 2022, 2021, and 2021, respectively.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-26-000012:notes:148]
[same as prior period, unchanged from 0000926326-25-000031:notes:150]

[0000926326-26-000012:notes:149]
[same as prior period, unchanged from 0000926326-25-000031:notes:151]

[0000926326-26-000012:notes:150]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,249 |  |  | $ | 1,718 |  |  |  |  |  |
| Research and development | 733 |  |  | 1,220 |  |  |  |  |  |
| Selling, general, and administrative | 7,516 |  |  | 7,848 |  |  |  |  |  |
| Total share-based compensation expense | $ | 9,498 |  |  | $ | 10,786 |  |  |  |  |  |

[0000926326-26-000012:notes:151]
The Company capitalized approximately $0.6 million and $0.8 million during the three months ended March 31, 2026 and 2025, respectively, of non-cash share-based compensation expense to internal-use and external-use software development costs related to internal labor. The Company did not capitalize any material non-cash share-based compensation expense to inventory during the three months ended March 31, 2026 and 2025.

[0000926326-26-000012:notes:152]
[same as prior period, unchanged from 0000926326-25-000031:notes:154]

[0000926326-26-000012:notes:153]
[same as prior period, unchanged from 0000926326-25-000031:notes:155]

[0000926326-26-000012:notes:154]
|  | Three Months Ended March 31, |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  |  |  |  |
| Expected volatility, % | 47.3% - 58.7% |  | 45.8% - 58.7% |  |  |  |  |
| Risk-free interest rate, % | 3.6% - 4.7% |  | 4.1% - 5.2% |  |  |  |  |
| Dividend yield, % | — | % |  | — | % |  |  |  |  |

[0000926326-26-000012:notes:155]
For the three months ended March 31, 2026 and 2025, employees purchased approximately 312,000 and 335,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $24.64 and $24.57, respectively. As of March 31, 2026, the estimated unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $9.2 million and is expected to be recognized over a weighted-average period of 1.4 years.

[0000926326-26-000012:notes:156]
[same as prior period, unchanged from 0000926326-25-000031:notes:158]

[0000926326-26-000012:notes:157]
[same as prior period, unchanged from 0000926326-25-000031:notes:159]

[0000926326-26-000012:notes:158]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2025 | 1,353 |  |  | $ | 68.10 |  |  | 3.2 |  | $ | 1,787 |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (2) |  |  | 34.20 |  |  |  |  |  |
| Expired | — |  |  | — |  |  |  |  |  |
| Forfeited | (46) |  |  | 78.34 |  |  |  |  |  |
| Outstanding at March 31, 2026 | 1,305 |  |  | $ | 67.80 |  |  | 2.8 |  | $ | 17 |  |
| Exercisable at March 31, 2026 | 1,305 |  |  | $ | 67.80 |  |  | 2.8 |  | $ | 17 |  |
| Vested and expected to vest at March 31, 2026 and thereafter | 1,305 |  |  | $ | 67.80 |  |  | 2.8 |  | $ | 17 |  |

[0000926326-26-000012:notes:159]
[same as prior period, unchanged from 0000926326-25-000031:notes:161]

[0000926326-26-000012:notes:160]
[same as prior period, unchanged from 0000926326-25-000031:notes:162]

[0000926326-26-000012:notes:161]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2025 | 1,661 |  |  | $ | 39.65 |  |  | 1.5 |  | $ | 75,261 |  |
| Granted | 27 |  |  | 45.30 |  |  |  |  |  |
| Vested | (155) |  |  | 48.05 |  |  |  |  |  |
| Forfeited | (51) |  |  | 39.62 |  |  |  |  |  |
| Outstanding and unvested at March 31, 2026 | 1,482 |  |  | $ | 38.78 |  |  | 1.4 |  | $ | 49,454 |  |

[0000926326-26-000012:notes:162]
As of March 31, 2026, total unrecognized compensation cost related to RSUs was $38.0 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.5 years.

[0000926326-26-000012:notes:163]
[same as prior period, unchanged from 0000926326-25-000031:notes:165]

[0000926326-26-000012:notes:164]
[same as prior period, unchanged from 0000926326-25-000031:notes:166]

[0000926326-26-000012:notes:165]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2025 | 294 |  |  | $ | 30.56 |  |
| Granted | — |  |  | — |  |
| Vested | (54) |  |  | 31.23 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at March 31, 2026 | 240 |  |  | $ | 30.41 |  |

[0000926326-26-000012:notes:166]
As of March 31, 2026, total unrecognized compensation cost related to PSUs was approximately $1.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.4 years.

[0000926326-26-000012:notes:167]
[same as prior period, unchanged from 0000926326-25-000031:notes:169]

[0000926326-26-000012:notes:168]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of March 31, 2026:

[0000926326-26-000012:notes:169]
|  | Number of Shares |
|  | (In thousands) |
| Stock options outstanding | 1,305 |  |
| Non-vested restricted stock awards | 1,776 |  |
| Shares authorized for future issuance | 3,948 |  |
| ESPP shares available for future issuance | 1,802 |  |
| Total shares reserved for future issuance | 8,831 |  |

[0000926326-26-000012:notes:170]
[same as prior period, unchanged from 0000926326-25-000031:notes:172]

[0000926326-26-000012:notes:171]
[same as prior period, unchanged from 0000926326-25-000031:notes:173]

[0000926326-26-000012:notes:172]
The 2016 Repurchase Program was completed during the second quarter of 2025. As of March 31, 2026, the 2025 Repurchase Program was substantially completed. During the three months ended March 31, 2026 and 2025, the Company did not repurchase any of its outstanding common stock under the repurchase programs.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000926326-26-000012:notes:173]
During the three months ended March 31, 2026, Nnamdi Njoku, the Company’s Executive Vice President and Chief Operating Officer, adopted a new “Rule 10b5-1 trading arrangement” (as defined in Item 408(a) of Regulation S-K) on February 9, 2026, which is intended to satisfy the Rule 10b5-1(c) affirmative defense. Mr. Njoku’s trading plan is effective from May 15, 2026 until the earlier of: (1) February 16, 2027; or (2) the date on which all of the transactions under the trading plan are completed. The trading plan is intended to let Mr. Njoku sell up to 17,049 shares of common stock, which represents the gross amount of shares that will vest over the duration of the plan (shares that will actually be sold under the plan are net of tax withholding). None of the shares were sold and no other adjustments were made to the trading plan during the three months ended March 31, 2026.

[0000926326-26-000012:notes:174]
In addition, on February 23, 2026, Randall A. Lipps, the Company’s President, Chief Executive Officer, and Chairman of the Board of Directors, terminated a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act, which was previously adopted on March 14, 2025 (the “Prior Plan”). The Prior Plan provided for the sale of certain shares of common stock held by Mr. Lipps as well as the exercise of certain options expiring on February 3, 2026. The Prior Plan would have expired on the earlier of: (1) September 30, 2026; or (2) the date on which all of the transactions under the trading plan are completed. Following termination of the Prior Plan, on February 25, 2026, Mr. Lipps adopted a new “Rule 10b5-1 trading arrangement” (as defined in Item 408(a) of Regulation S-K), which is intended to satisfy the Rule 10b5-1(c) affirmative defense. Mr. Lipps’ new trading plan is effective from May 28, 2026 until the earlier of: (1) March 1, 2027; or (2) the date on which all of the transactions under the trading plan are completed. Mr. Lipps entered into the new trading plan to include certain options that were previously excluded from the Prior Plan. The new trading plan is intended to let Mr. Lipps sell up to 10,000 shares of common stock and exercise and sell up to (a) 134,160 stock options expiring on February 8, 2027 and (b) 153,728 stock options expiring on February 6, 2028. None of the shares were sold, nor any options exercised and no other adjustments were made to the Prior Plan during the three months ended March 31, 2026.
