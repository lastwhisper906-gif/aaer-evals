# OMCL MD&A — 0000926326-26-000012


## mdna

[0000926326-26-000012:mdna:1]
[same as prior period, unchanged from 0000926326-25-000031:mdna:1]

[0000926326-26-000012:mdna:2]
[same as prior period, unchanged from 0000926326-25-000031:mdna:2]

[0000926326-26-000012:mdna:3]
[same as prior period, unchanged from 0000926326-25-000031:mdna:3]

[0000926326-26-000012:mdna:4]
•unfavorable general economic and market conditions, including the potential impact of inflationary pressures;

[0000926326-26-000012:mdna:5]
•our ability to take advantage of growth opportunities and develop and commercialize new solutions and enhance existing solutions;

[0000926326-26-000012:mdna:6]
•reductions in demand in the capital equipment market or reductions in the demand for, or adoption of, our solutions, systems, or services;

[0000926326-26-000012:mdna:7]
•our ability to successfully achieve anticipated growth targets or market adoption;

[0000926326-26-000012:mdna:8]
[same as prior period, unchanged from 0000926326-25-000031:mdna:7]

[0000926326-26-000012:mdna:9]
•delays, technical challenges and unexpected or greater than anticipated expenses associated with developing new products and services or failing to achieve technological or economic feasibility, obtain regulatory approval or gain market acceptance resulting in stopping the development of, or the continued offering of, a product or service;

[0000926326-26-000012:mdna:10]
•periods of significant volatility due to geopolitical developments;

[0000926326-26-000012:mdna:11]
•credit, collection, and operational challenges from providing lease financing options to our customers;

[0000926326-26-000012:mdna:12]
[same as prior period, unchanged from 0000926326-25-000031:mdna:15]

[0000926326-26-000012:mdna:13]
•incorporating artificial intelligence (“AI”) technology into our products, services and processes, and the use of AI by our vendors and competitors;

[0000926326-26-000012:mdna:14]
[same as prior period, unchanged from 0000926326-25-000031:mdna:10]

[0000926326-26-000012:mdna:15]
•meeting the demands of, or maintaining relationships with, GPOs, institutional, retail, and specialty pharmacy customers;

[0000926326-26-000012:mdna:16]
•inability to secure or maintain access to existing and future specialty drugs or pharmacy provider networks for our specialty pharmacy customers;

[0000926326-26-000012:mdna:17]
•continued and increased competition from current and future competitors in the hospital and health system solutions and outpatient pharmacy solutions markets;

[0000926326-26-000012:mdna:18]
•selling more products and services on a subscription basis;

[0000926326-26-000012:mdna:19]
[same as prior period, unchanged from 0000926326-25-000031:mdna:14]

[0000926326-26-000012:mdna:20]
[same as prior period, unchanged from 0000926326-25-000031:mdna:16]

[0000926326-26-000012:mdna:21]
[same as prior period, unchanged from 0000926326-25-000031:mdna:9]

[0000926326-26-000012:mdna:22]
•failure to realize the potential benefits of acquired businesses, or impaired goodwill or other intangible assets in connection with prior acquisitions;

[0000926326-26-000012:mdna:23]
•government regulations, legislative changes, fraud and anti-kickback statutes, products liability claims, the outcome of legal proceedings, and other legal obligations related to healthcare, privacy, data protection, and information security, and the costs of compliance with, and potential liability associated with, our actual or perceived failure to comply with such obligations;

[0000926326-26-000012:mdna:24]
[same as prior period, unchanged from 0000926326-25-000031:mdna:18]

[0000926326-26-000012:mdna:25]
•operating in foreign countries and risks relating to our international supply chain, including the potential impact of political unrest, terrorism, other potential hostilities, threats of terrorism or potential hostilities, or tariffs;

[0000926326-26-000012:mdna:26]
•covenants in our credit agreement could restrict our business and operations;

[0000926326-26-000012:mdna:27]
•financial institution and money market fund concentration;

[0000926326-26-000012:mdna:28]
[same as prior period, unchanged from 0000926326-25-000031:mdna:21]

[0000926326-26-000012:mdna:29]
•catastrophic events may disrupt our business;

[0000926326-26-000012:mdna:30]
[same as prior period, unchanged from 0000926326-25-000031:mdna:22]

[0000926326-26-000012:mdna:31]
[same as prior period, unchanged from 0000926326-25-000031:mdna:23]

[0000926326-26-000012:mdna:32]
•availability and sources of raw materials and components, price fluctuations and an inability to pass increased costs on to our customers, or shortages or interruptions of supply;

[0000926326-26-000012:mdna:33]
[same as prior period, unchanged from 0000926326-25-000031:mdna:25]

[0000926326-26-000012:mdna:34]
[same as prior period, unchanged from 0000926326-25-000031:mdna:12]

[0000926326-26-000012:mdna:35]
•intellectual property infringement or product liability claims against us;

[0000926326-26-000012:mdna:36]
[same as prior period, unchanged from 0000926326-25-000031:mdna:26]

[0000926326-26-000012:mdna:37]
[same as prior period, unchanged from 0000926326-25-000031:mdna:27]

[0000926326-26-000012:mdna:38]
•other factors set forth under “Risk Factors.”

[0000926326-26-000012:mdna:39]
[same as prior period, unchanged from 0000926326-25-000031:mdna:29]

[0000926326-26-000012:mdna:40]
[same as prior period, unchanged from 0000926326-25-000031:mdna:30]

[0000926326-26-000012:mdna:41]
We own various registered and unregistered trademarks and service marks used in our business, some of which appear in this Quarterly Report on Form 10-Q, including Omnicell®. This Quarterly Report on Form 10-Q may also include

[0000926326-26-000012:mdna:42]
the trademarks and service marks of other companies. Such trademarks and service marks are the marks of their respective owners.

[0000926326-26-000012:mdna:43]
[same as prior period, unchanged from 0000926326-25-000031:mdna:32]

[0000926326-26-000012:mdna:44]
[same as prior period, unchanged from 0000926326-25-000031:mdna:33]

[0000926326-26-000012:mdna:45]
Omnicell, a leading healthcare technology provider focused on empowering autonomous medication management, is committed to solving the critical challenges inherent in medication management and elevating the role of clinicians within healthcare as an essential component of care delivery. Omnicell is focused on helping its customers define and deliver a cost-effective medication management strategy designed to equip and empower pharmacists and nurses to focus on patient care rather than administrative tasks, and to drive improved clinical, operational, and financial outcomes across all care settings. We are doing this with an industry-leading medication management infrastructure which includes storage and dispensing automation powered by an intelligence ecosystem. Our comprehensive set of solutions provides the critical foundation for customers to realize the Autonomous Pharmacy, an industry-wide vision defined by pharmacy leaders for improving operational efficiencies and ultimately targeting zero-error medication management alongside 5 other outcomes laid out in the Autonomous Pharmacy framework.

[0000926326-26-000012:mdna:46]
Omnicell solutions are helping healthcare facilities worldwide to uncover cost savings, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry-defined vision of the Autonomous Pharmacy. We sell our hardware, software, and consumable solutions together with related service offerings. Revenues generated in the United States represented 90% and 92% of our total revenues for the three months ended March 31, 2026 and 2025, respectively.

[0000926326-26-000012:mdna:47]
Our business has expanded from a single-point solution to a platform of products and services that will help further advance the industry-defined vision of the Autonomous Pharmacy. This expansion has resulted in larger deal sizes across multiple products, services, and implementations for customers and, we believe, more comprehensive, valuable, and enduring relationships. As our business evolves, we continue to evaluate the metrics and methods we use to measure the success of our business.

[0000926326-26-000012:mdna:48]
[same as prior period, unchanged from 0000926326-25-000031:mdna:37]

[0000926326-26-000012:mdna:49]
In recent years, the U.S. government has advocated for greater restrictions on trade generally. For example, in 2025, the U.S. imposed tariffs on a wide variety of products manufactured in multiple foreign jurisdictions, including China, Mexico, and Malaysia. In response to the ongoing changes in tariffs, several foreign countries have imposed reciprocal tariffs on goods manufactured in the United States. These tariff rates have fluctuated and may continue to fluctuate going forward. In an effort to address these actions, we have implemented various mitigation measures, including dual-sourcing of components and nearshoring manufacturing. While these actions have effectively mitigated some of the impact of these costs, there can be no assurance that we will be able to offset future increased costs or other adverse impacts. Although we continue to work to mitigate the impact of current or potential tariffs, we may incorrectly anticipate outcomes, forgo or pass up business opportunities, or fail to appropriately adapt or manage our business strategies in response to these changes. As a result of these factors, we may experience direct and indirect adverse effects on our business, operating results, cash flow, or financial condition.

[0000926326-26-000012:mdna:50]
In addition, on February 20, 2026, the U.S. Supreme Court struck down certain tariffs imposed under the International Emergency Economic Powers Act (“IEEPA”). Subsequent to this ruling the U.S. Court of International Trade issued an order that directed the U.S. Customs and Border Protection (“CBP”) to formalize a process for refunding IEEPA tariffs. On April 20, 2026, the CBP launched an online portal to submit IEEPA tariff refund requests. Submitted requests are reviewed by the CBP to determine validity prior to the issuance of any refund. As the recoverability and timing of any such refund remains uncertain, we have not recorded any potential benefit as of March 31, 2026.

[0000926326-26-000012:mdna:51]
It is unclear at this time what the ultimate impact this decision will have on our business or future operating results. Effective February 24, 2026, a new 10% tariff for all imports under Section 122 of the Trade Act of 1974 was imposed in response to the Supreme Court’s ruling. These tariffs are expected to remain in effect for 150 days, the maximum period that Section 122 permits without congressional action. However, previous exclusions, such as for the United States-Mexico-Canada Agreement (“USMCA”), remain in place. We continue to monitor these developments and their potential impact on our business and future operating results.

[0000926326-26-000012:mdna:52]
[same as prior period, unchanged from 0000926326-25-000031:mdna:39]

[0000926326-26-000012:mdna:53]
We utilize product bookings and Annual Recurring Revenue (“ARR”), each as further described below, as key performance metrics for our business. We view product bookings as an indicator of the success of certain portions of our

[0000926326-26-000012:mdna:54]
business that generate nonrecurring revenue and we view ARR as an indicator of the success of the portions of our business that generate recurring revenues. The definitions and descriptions included below are relevant to these key performance metrics.

[0000926326-26-000012:mdna:55]
[same as prior period, unchanged from 0000926326-25-000031:mdna:41]

[0000926326-26-000012:mdna:56]
We utilize product bookings as an indicator of the success of certain portions of our business that generate non-recurring revenue. We define product bookings generally as the value of non-cancelable contracts for our connected devices and software licenses. We typically exclude freight revenue and other less significant items ancillary to our products from product bookings. In addition, dependent upon counterparty or credit risk, which is evaluated at the time of contract signing, for a given multi-year subscription contract we may reduce the value of the contractual commitment booked at a given time. Connected devices and software license bookings are recorded as revenue upon customer acceptance of the installation or receipt of goods. As part of most connected device product sales, we generally provide installation planning and consulting, which is typically included in the initial price of the solution.

[0000926326-26-000012:mdna:57]
[same as prior period, unchanged from 0000926326-25-000031:mdna:44]

[0000926326-26-000012:mdna:58]
We consider revenues generated from our consumables, technical services, and SaaS and Expert Services to be recurring revenues. For the portions of our business which generate recurring revenues, we utilize ARR as a key metric to measure our progress in growing our recurring revenue business. We define ARR at a measurement date as the revenue we expect to receive from our customers over the course of the following year for providing them with products or services. ARR includes expected revenue from all customers who are using our products or services at the reported date. For technical services and SaaS and Expert Services, solutions are generally on a contractual basis, typically with contracts for a period of 12 months or more, with a high probability of renewal. Probability of renewal is based on historic renewal experience of the individual revenue streams or management’s best estimates if historical renewal experience is not available. Consumables orders are placed by customers through our Omnicell Storefront online platform or through written or telephonic orders and are sold to a customer base who utilize the consumable product and place recurring orders when customer inventory is depleted. ARR is generally calculated based on revenues received in the most recent quarter and changes to expected revenues where solutions were added to or removed from the install or customer base in the quarter. Revenues from technical services and SaaS and Expert Services are generally recorded ratably over the service term. As part of our SaaS and Expert Services offerings, we provide a range of services to our customers including Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions, which typically are provided over two to seven years. In addition, to help ensure the maximum availability of our systems, our customers typically purchase technical services contracts (support and maintenance) in increments of one to five years. Revenue from consumables are recorded when the product has shipped and title has passed. Our measure of ARR may be different than that used by other companies. Because ARR is based on expected future revenue, it does not represent revenue recognized during a particular reporting period or revenue to be recognized in future reporting periods. ARR should not be viewed as a substitute for revenues.

[0000926326-26-000012:mdna:59]
[same as prior period, unchanged from 0000926326-25-000031:mdna:46]

[0000926326-26-000012:mdna:60]
[same as prior period, unchanged from 0000926326-25-000031:mdna:47]

[0000926326-26-000012:mdna:61]
[same as prior period, unchanged from 0000926326-25-000031:mdna:48]

[0000926326-26-000012:mdna:62]
[same as prior period, unchanged from 0000926326-25-000031:mdna:49]

[0000926326-26-000012:mdna:63]
[same as prior period, unchanged from 0000926326-25-000031:mdna:50]

[0000926326-26-000012:mdna:64]
[same as prior period, unchanged from 0000926326-25-000031:mdna:51]

[0000926326-26-000012:mdna:65]
[same as prior period, unchanged from 0000926326-25-000031:mdna:52]

[0000926326-26-000012:mdna:66]
Our full-time employee headcount was approximately 3,525 as of March 31, 2026.

[0000926326-26-000012:mdna:67]
[same as prior period, unchanged from 0000926326-25-000031:mdna:54]

[0000926326-26-000012:mdna:68]
In 2024, the United States spent $806 billion on prescription drugs, a 10.2% increase from 2023. We believe there are significant challenges facing the practice of pharmacy today. These challenges include, but are not limited to, budget constraints and acute workforce shortages, where 88% of hospitals report technician deficits and 92% report shortages of technicians with sterile compounding expertise. In addition, health systems face rising liability related to drug diversion, with a 61% increase in the average number of investigations per hospital since the beginning of 2023. We also recognize that these challenges may impact the timing of contracting for, or implementation of, our products, solutions, or services. However, we believe that over time these significant challenges facing pharmacists will drive demand for increased automation, visibility, insights, and improved medication management outcomes that our solutions are designed to enable. Because of this, we believe that our solutions are well-positioned to address the evolving needs of healthcare institutions and therefore present opportunities for long-term growth.

[0000926326-26-000012:mdna:69]
In an effort to address these challenges and deliver solutions to help drive positive medication management outcomes, we continue to make significant investments in our research and development efforts to further advance the industry-defined vision of the Autonomous Pharmacy. Furthermore, we believe a combination of dispensing automation and an intelligence ecosystem is needed in every care setting where medications are managed. We are focused on delivering solutions to help our customers realize the industry-defined vision of the Autonomous Pharmacy and driving positive medication management outcomes with superior customer experience in two core market categories through:

[0000926326-26-000012:mdna:70]
•Hospital and Health System Solutions: This category enables the end-to-end medication process across the entire continuum of care. It unifies Central Pharmacy automation, robotics, and IV sterile compounding with Point of Care automated dispensing in Nursing Units and Operating Room/Procedural areas. From the loading dock to the bedside, this is designed to provide for medication safety, availability, and workflow efficiency. This category also supports Consolidated Pharmacy Service Center operations.

[0000926326-26-000012:mdna:71]
•Points of Care.  As a market leader, we anticipate continued expansion into this product market as customers increasingly utilize our dispensing systems in more areas within hospitals and ambulatory care settings. The 2025–2028 healthcare landscape, however, faces significant fiscal headwinds driven by sweeping changes in health policy, specifically the One Big Beautiful Bill Act (“OBBBA”), which is expected to result in a $910 billion Medicaid spending reduction across states. Coupled with rising input costs from tariffs and acute labor shortages, these pressures are likely to further compress operating margins. We believe this financial strain makes the status quo unsustainable, which we anticipate compelling health systems to focus on capital efficiency and operational resilience through accelerated investments in pharmacy modernization, especially automation to address labor shortages and advanced analytics to manage rising costs of drug diversion and non-adherence. As hospitals navigate this liquidity challenge, we expect a critical shift in purchasing behavior from traditional capital expenditures to flexible payment models, such as leasing, subscriptions, and “as-a-service” structures, enabling institutions to adopt essential regulatory compliance and safety technologies while preserving operating cash flow.

[0000926326-26-000012:mdna:72]
•Central Pharmacy.  This market represents the beginning of medication management in acute care settings. Given the current environment, we believe there is a significant opportunity for automation as many health systems aim to eliminate manual, repetitive, and error-prone processes to address acute workforce shortages. With hospitals facing technician shortages and often lacking adequate sterile compounding expertise, we think automating central pharmacy dispensing and compounding is crucial for reallocating limited labor, enhancing patient safety, and enabling compliance with the new interoperability requirements under the Drug Supply Chain Security Act (“DSCSA”). Manual compounding of sterile IV preparations poses safety risks and, when outsourced, can increase costs and supply volatility. Therefore, IV products offer a key opportunity to standardize sterile workflows, offset the resources currently used for managing drug shortages, and reduce the annual cost of non-optimized medication therapy. We expect these products in technology-driven services to become increasingly vital as health systems focus on operational resilience amid severe financial pressures.

[0000926326-26-000012:mdna:73]
•Consolidated Pharmacy Service Center Automation and Robotics.  Health Systems are increasingly realizing savings from a Consolidated Pharmacy Service Center (“CPSC”) model. The CPSC serves as a strategic hub for centralized inventory management and sterile compounding. By implementing industrial-grade robotics and carousels at the CPSC, health systems can achieve economies of scale, streamlining the serialized receiving process required for DSCSA compliance before inventory reaches hospitals. This centralized approach should help preserve margins by optimizing supply chains and reducing waste across the network.

[0000926326-26-000012:mdna:74]
•Outpatient Pharmacy Solutions: Focused on extending care beyond the hospital walls, this category supports outpatient and retail pharmacy growth. It combines Specialty Pharmacy and 340B Third-Party Administrator (“TPA”) services, Medication Adherence technologies (automation and consumables), and the EnlivenHealth platform to help drive better clinical outcomes and medication compliance for clinicians and patients.

[0000926326-26-000012:mdna:75]
•Specialty Pharmacy and 340B Program.  We believe that health systems will continue to accelerate investment in programs to improve patient outcomes by utilizing specialty pharmacies and the federal 340B Drug Pricing Program. The 340B Program allows qualified hospitals to stretch federal resources, a critical capability as the program is on track to exceed $200 billion in gross sales by 2026. In 2024, specialty drugs used for treatment of complex conditions constituted the majority (51.7%) of total prescription expenditures. This sector continues to grow at a higher rate than other drug classes. However, regulatory pressures are intensifying with site-neutral payment cuts. Specialty pharmacies serve as the connection between patients, providers, and payers to streamline access and adherence. We believe a solution designed to help health systems optimize their Health System-Owned Specialty Pharmacy (“HSSP”) and navigate these compliance-complexities will help ensure continuity of care. We believe that a fully optimized specialty pharmacy operation represents one of the largest economic opportunities for hospitals and health systems.

[0000926326-26-000012:mdna:76]
•Institutional Pharmacy.  The U.S. institutional pharmacy industry provides closed-door medication dispensing, clinical support, and medication adherence services for long-term care (“LTC”), correctional, rehabilitation and behavioral health, and hospice facilities. The market size of the institutional pharmacies industry in the U.S. is $24 billion with 1,100 businesses servicing this sector and characterized by a high concentration in national operators. LTC facilities comprise skilled nursing facilities, assisted living communities, senior living centers, and home and community-based care settings. LTC pharmacies typically operate under more stringent regulatory, packaging, and labor requirements than retail pharmacies, which may result in structurally higher operating costs. As a result of projected demographic aging and the increasing complexity of managing chronic disease across LTC populations, we expect market demand to continue to rise. The LTC industry is currently undergoing a transition driven by reimbursement pressures, regulatory expansion, and workforce shortages. Legislative and pricing reforms, including updates to Medicare Part D, have increased financial strain on smaller LTC providers, which we believe will accelerate a shift toward centralized, automation-enabled fulfillment models that are designed to improve efficiency, standardize quality, and support compliance with evolving documentation and oversight requirements. Through our outpatient pharmacy solutions, we also serve adjacent outpatient institutional markets, including correctional facilities’ pharmacy providers. Additionally, we provide pharmacy services to individuals with intellectual and developmental disabilities (“IDD”), a market currently experiencing rising demand due to increased prevalence. IDD pharmacy services require specialized packaging, adherence technologies, and close coordination with caregivers and community-based support organizations.

[0000926326-26-000012:mdna:77]
•Retail.  Total U.S. prescription dispensing revenues across retail, mail-order, long-term care, and specialty pharmacies reached approximately $683 billion in 2024, up 9% from 2023, a surge driven primarily by the rapid adoption of GLP-1 agonists and specialty immunotherapies rather than volume alone. Additionally, the shift of outpatient care from hospitals and physician offices to other more convenient settings, such as retail pharmacies and the home, continues to be a growing trend. New technologies and increased scope of practice for pharmacists appear to be spurring innovation and expansion of the provision of clinical services by retail pharmacies. We believe this development, combined with the move to value-based care, will drive the adoption of our patient engagement offerings. These solutions are intended to help providers (including pharmacists) engage patients in new ways that are expected to improve outcomes, reduce the total cost of care, and lead to more profitable operations.

[0000926326-26-000012:mdna:78]
[same as prior period, unchanged from 0000926326-25-000031:mdna:61]

[0000926326-26-000012:mdna:79]
Our discussion and analysis of our financial condition and results of operations are based on our Condensed Consolidated Financial Statements, which have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions.

[0000926326-26-000012:mdna:80]
[same as prior period, unchanged from 0000926326-25-000031:mdna:64]

[0000926326-26-000012:mdna:81]
[same as prior period, unchanged from 0000926326-25-000031:mdna:65]

[0000926326-26-000012:mdna:82]
[same as prior period, unchanged from 0000926326-25-000031:mdna:66]

[0000926326-26-000012:mdna:83]
[same as prior period, unchanged from 0000926326-25-000031:mdna:67]

[0000926326-26-000012:mdna:84]
There have been no material changes in our critical accounting policies and estimates during the three months ended March 31, 2026 as compared to those disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in our Annual Report on Form 10-K for the year ended December 31, 2025.

[0000926326-26-000012:mdna:85]
[same as prior period, unchanged from 0000926326-25-000031:mdna:69]

[0000926326-26-000012:mdna:86]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-26-000012:mdna:87]
[same as prior period, unchanged from 0000926326-25-000031:mdna:71]

[0000926326-26-000012:mdna:88]
[same as prior period, unchanged from 0000926326-25-000031:mdna:72]

[0000926326-26-000012:mdna:89]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2026 |  | 2025 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 174,800 |  |  | $ | 145,168 |  |  | $ | 29,632 |  |  | 20% |
| Percentage of total revenues | 56% |  | 54% |  |  |  |  |
| Service revenues | 135,080 |  |  | 124,500 |  |  | $ | 10,580 |  |  | 8% |
| Percentage of total revenues | 44% |  | 46% |  |  |  |  |
| Total revenues | $ | 309,880 |  |  | $ | 269,668 |  |  | $ | 40,212 |  |  | 15% |

[0000926326-26-000012:mdna:90]
Product revenues represented 56% and 54% of total revenues for the three months ended March 31, 2026 and 2025, respectively. Product revenues increased by $29.6 million, primarily driven by an increase in revenues from our automated dispensing systems and XTExtend offering, partially offset by a decrease in revenues from robotics, including products related to our Central Pharmacy Dispensing Service and IV Compounding Service offering.

[0000926326-26-000012:mdna:91]
Service revenues represented 44% and 46% of total revenues for the three months ended March 31, 2026 and 2025. Service revenues include revenues from technical services and SaaS and Expert Services offerings. Service revenues increased by $10.6 million due to an increase of $5.5 million in technical services revenues primarily as a result of growth in our installed customer base and the impact of pricing actions, as well as an increase of $5.0 million in SaaS and Expert Services revenues due to continued customer demand, including an increase in revenues from our Specialty Pharmacy Services offering.

[0000926326-26-000012:mdna:92]
Our international sales represented 10% and 8% of total revenues for the three months ended March 31, 2026 and 2025, respectively. In future periods, we expect our revenues to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-26-000012:mdna:93]
Our ability to grow product and service revenues is dependent on our ability to continue to obtain orders from customers, including contract renewals, which may be dependent upon customers’ capital equipment budgets and/or capital equipment approval cycles, our ability to produce quality products and consumables to fulfill customer demand, the volume of implementations we are able to complete, our ability to meet customer needs by providing a quality implementation experience and solutions that meet expected service levels, our ability to develop new or enhance existing solutions, and our flexibility in workforce allocations among customers to complete implementations on a timely basis. The timing of our revenues is primarily dependent on when our customers’ schedules and/or staffing levels allow for implementations.

[0000926326-26-000012:mdna:94]
[same as prior period, unchanged from 0000926326-25-000031:mdna:82]

[0000926326-26-000012:mdna:95]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which account for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product, and overhead costs associated with production; (ii) costs of providing services and installation costs, including

[0000926326-26-000012:mdna:96]
costs of personnel and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, provisions for excess and obsolete inventory, and amortization of software development costs and intangibles.

[0000926326-26-000012:mdna:97]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2026 |  | 2025 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 95,518 |  |  | $ | 85,585 |  |  | $ | 9,933 |  |  | 12% |
| As a percentage of related revenues | 55% |  | 59% |  |  |  |  |
| Cost of service revenues | 73,999 |  |  | 73,147 |  |  | $ | 852 |  |  | 1% |
| As a percentage of related revenues | 55% |  | 59% |  |  |  |  |
| Total cost of revenues | $ | 169,517 |  |  | $ | 158,732 |  |  | $ | 10,785 |  |  | 7% |
| As a percentage of total revenues | 55% |  | 59% |  |  |  |  |
| Gross profit | $ | 140,363 |  |  | $ | 110,936 |  |  | $ | 29,427 |  |  | 27% |
| Gross margin | 45% |  | 41% |  |  |  |  |

[0000926326-26-000012:mdna:98]
Cost of revenues for the three months ended March 31, 2026 compared to the three months ended March 31, 2025 increased by $10.8 million, of which $9.9 million was attributed to the increase in cost of product revenues and $0.9 million was attributed to the increase in cost of service revenues.

[0000926326-26-000012:mdna:99]
The increase in cost of product revenues for the three months ended March 31, 2026 compared to the three months ended March 31, 2025 was driven by an increase in product revenues of $29.6 million for the comparable period. The increase in cost of product revenues has not increased proportionally with the increase in product revenues primarily due to the favorable impact of scale and efficiencies in installations as well as product and customer mix, partially offset by the impact of tariffs during the three months ended March 31, 2026. The increase in cost of service revenues for the three months ended March 31, 2026 compared to the three months ended March 31, 2025 has not increased proportionally with the increase in service revenues primarily due to certain non-recurring costs, including software upgrade expenses, incurred during the three months ended March 31, 2025.

[0000926326-26-000012:mdna:100]
The overall increase in gross margin primarily relates to higher revenues for the three months ended March 31, 2026 compared to the three months ended March 31, 2025, the favorable impact of scale and efficiencies in installations, product and customer mix, and certain non-recurring costs, including software upgrade expenses, incurred during the three months ended March 31, 2025, partially offset by the impact of tariffs. Our gross profit for the three months ended March 31, 2026 was $140.4 million, as compared to $110.9 million for the three months ended March 31, 2025.

[0000926326-26-000012:mdna:101]
[same as prior period, unchanged from 0000926326-25-000031:mdna:95]

[0000926326-26-000012:mdna:102]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2026 |  | 2025 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 21,519 |  |  | $ | 20,526 |  |  | $ | 993 |  |  | 5% |
| As a percentage of total revenues | 7% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 101,990 |  |  | 102,029 |  |  | $ | (39) |  |  | —% |
| As a percentage of total revenues | 33% |  | 38% |  |  |  |  |
| Total operating expenses | $ | 123,509 |  |  | $ | 122,555 |  |  | $ | 954 |  |  | 1% |
| As a percentage of total revenues | 40% |  | 45% |  |  |  |  |
| Interest and other income (expense), net | $ | 51 |  |  | $ | 2,089 |  |  | $ | (2,038) |  |  | (98)% |

[0000926326-26-000012:mdna:103]
34

[0000926326-26-000012:mdna:104]
Research and Development. Research and development expenses increased by $1.0 million for the three months ended March 31, 2026 compared to the three months ended March 31, 2025.

[0000926326-26-000012:mdna:105]
Selling, General, and Administrative. Selling, general, and administrative expenses remained relatively consistent for the three months ended March 31, 2026 compared to the three months ended March 31, 2025, primarily due to an increase of $2.8 million in employee-related expenses and $2.6 million in consulting expenses, offset by a decrease in expenses incurred during the three months ended March 31, 2025 of $2.7 million for legal and regulatory expenses, and $1.5 million in certain restructuring and severance charges.

[0000926326-26-000012:mdna:106]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $2.0 million for the three months ended March 31, 2026 compared to the three months ended March 31, 2025, primarily driven by a $2.4 million decrease in other income and a $0.4 million decrease in other expense. The decrease in other income during the three months ended March 31, 2026 as compared to the three months ended March 31, 2025 is primarily attributable to lower interest income received due to lower cash and cash equivalents balances following the repurchases of our common stock during the second and third quarters of 2025 and maturity of the remaining 2025 Notes in September 2025, as well as lower interest rates.

[0000926326-26-000012:mdna:107]
Provision for (Benefit from) Income Taxes

[0000926326-26-000012:mdna:108]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2026 |  | 2025 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 5,547 |  |  | $ | (2,507) |  |  | $ | 8,054 |  |  | (321)% |

[0000926326-26-000012:mdna:109]
For the three months ended March 31, 2026 and March 31, 2025, we recorded income tax expense of $5.5 million and income tax benefit of $2.5 million, respectively. The change in the income tax expense for the three months ended March 31, 2026 compared to the income tax benefit for the same period in 2025 was primarily due to higher income before income taxes generated during the current period.

[0000926326-26-000012:mdna:110]
[same as prior period, unchanged from 0000926326-25-000031:mdna:108]

[0000926326-26-000012:mdna:111]
[same as prior period, unchanged from 0000926326-25-000031:mdna:109]

[0000926326-26-000012:mdna:112]
We had cash and cash equivalents of $239.2 million at March 31, 2026 compared to $196.5 million at December 31, 2025. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with financial institutions of high credit quality. As of March 31, 2026, a substantial portion of the Company’s cash and cash equivalents were held with a limited number of financial institutions and money market funds, which may expose the Company to concentration risk in the event of a failure or adverse condition affecting those entities.

[0000926326-26-000012:mdna:113]
Our cash position and working capital at March 31, 2026 and December 31, 2025 were as follows:

[0000926326-26-000012:mdna:114]
|  | March 31,2026 |  | December 31,2025 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 239,221 |  |  | $ | 196,520 |  |
| Working capital | $ | 239,254 |  |  | $ | 203,460 |  |

[0000926326-26-000012:mdna:115]
Our ratio of current assets to current liabilities was 1.5:1 at March 31, 2026 and 1.4:1 at December 31, 2025.

[0000926326-26-000012:mdna:116]
[same as prior period, unchanged from 0000926326-25-000031:mdna:114]

[0000926326-26-000012:mdna:117]
Revolving Credit Facility

[0000926326-26-000012:mdna:118]
On October 10, 2023, Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0

[0000926326-26-000012:mdna:119]
million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-26-000012:mdna:120]
As of March 31, 2026, we had $350.0 million of funds available under the Current Revolving Credit Facility. As of March 31, 2026, there was no outstanding balance under the Current Revolving Credit Facility and we were in full compliance with all covenants.

[0000926326-26-000012:mdna:121]
Refer to Note 10, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-26-000012:mdna:122]
[same as prior period, unchanged from 0000926326-25-000031:mdna:123]

[0000926326-26-000012:mdna:123]
[same as prior period, unchanged from 0000926326-25-000031:mdna:124]

[0000926326-26-000012:mdna:124]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the growth of our business.

[0000926326-26-000012:mdna:125]
[same as prior period, unchanged from 0000926326-25-000031:mdna:129]

[0000926326-26-000012:mdna:126]
[same as prior period, unchanged from 0000926326-25-000031:mdna:130]

[0000926326-26-000012:mdna:127]
|  | Three Months Ended March 31, |
|  | 2026 |  | 2025 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 54,500 |  |  | $ | 25,924 |  |
| Investing activities | (15,867) |  |  | (15,739) |  |
| Financing activities | 2,391 |  |  | 4,038 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,091) |  |  | 1,565 |  |
| Net increase in cash, cash equivalents, and restricted cash | $ | 39,933 |  |  | $ | 15,788 |  |

[0000926326-26-000012:mdna:128]
[same as prior period, unchanged from 0000926326-25-000031:mdna:132]

[0000926326-26-000012:mdna:129]
[same as prior period, unchanged from 0000926326-25-000031:mdna:133]

[0000926326-26-000012:mdna:130]
Net cash provided by operating activities was $54.5 million for the three months ended March 31, 2026, primarily consisting of operating inflows of $46.2 million and favorable working capital movements of $8.3 million. Operating inflows consisted of net income of $11.4 million, adjusted for non-cash items of $34.8 million, which consisted primarily of depreciation and amortization expense of $18.6 million and share-based compensation expense of $9.5 million. The favorable working capital was primarily due to an increase in deferred revenues of $40.3 million, driven primarily by an increase in billings for certain technical services, SaaS and Expert Services, and connected devices offerings, and an increase in accounts payable of $16.2 million primarily due to an increase in inventory spend and timing of payments. These cash inflows were partially offset by an increase in accounts receivable and unbilled receivables of $33.3 million primarily due to the timing of billings, shipments, and collections and a decrease in accrued compensation of $10.8 million primarily due to the timing of employee bonuses and commissions, as well as ESPP purchases.

[0000926326-26-000012:mdna:131]
Net cash provided by operating activities was $25.9 million for the three months ended March 31, 2025, primarily consisting of operating inflows of $22.6 million and favorable working capital movements of $3.3 million. Operating inflows consisted of a net loss of $7.0 million, adjusted for non-cash items of $29.6 million, which consisted primarily of depreciation and amortization expense of $20.0 million and share-based compensation expense of $10.8 million. The favorable working

[0000926326-26-000012:mdna:132]
capital was primarily due to an increase in deferred revenues of $20.2 million, driven primarily by an increase in billings for certain technical service and SaaS and Expert Services offerings, and a decrease in accounts receivable and unbilled receivables of $5.5 million, primarily due to the timing of billings, shipments, and collections. The cash inflows were partially offset by a decrease in accrued compensation of $14.2 million, primarily due to the timing of bonus payments, as well as ESPP purchases.

[0000926326-26-000012:mdna:133]
[same as prior period, unchanged from 0000926326-25-000031:mdna:137]

[0000926326-26-000012:mdna:134]
Net cash used in investing activities was $15.9 million for the three months ended March 31, 2026, which consisted primarily of capital expenditures of $12.4 million for property and equipment.

[0000926326-26-000012:mdna:135]
Net cash used in investing activities was $15.7 million for the three months ended March 31, 2025, which consisted primarily of capital expenditures of $11.2 million for property and equipment.

[0000926326-26-000012:mdna:136]
[same as prior period, unchanged from 0000926326-25-000031:mdna:140]

[0000926326-26-000012:mdna:137]
Net cash provided by financing activities was $2.4 million for the three months ended March 31, 2026, primarily due to $7.8 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-26-000012:mdna:138]
Net cash provided by financing activities was $4.0 million for the three months ended March 31, 2025, primarily due to $8.3 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-26-000012:mdna:139]
[same as prior period, unchanged from 0000926326-25-000031:mdna:143]

[0000926326-26-000012:mdna:140]
There have been no significant changes during the three months ended March 31, 2026 to the contractual obligations disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2025.

[0000926326-26-000012:mdna:141]
Contractual obligations as of March 31, 2026 were as follows:

[0000926326-26-000012:mdna:142]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2026 |  | 2027-2028 |  | 2029-2030 |  | 2031 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 37,477 |  |  | $ | 10,115 |  |  | $ | 21,771 |  |  | $ | 4,018 |  |  | $ | 1,573 |  |
| Purchase obligations (2) | $ | 172,632 |  |  | 133,707 |  |  | 38,925 |  |  | — |  |  | — |  |
| Convertible senior notes (3) | $ | 179,405 |  |  | 1,725 |  |  | 3,450 |  |  | 174,230 |  |  | — |  |
| Total (4) | $ | 389,514 |  |  | $ | 145,547 |  |  | $ | 64,146 |  |  | $ | 178,248 |  |  | $ | 1,573 |  |

[0000926326-26-000012:mdna:143]
[same as prior period, unchanged from 0000926326-25-000031:mdna:147]

[0000926326-26-000012:mdna:144]
[same as prior period, unchanged from 0000926326-25-000031:mdna:148]

[0000926326-26-000012:mdna:145]
[same as prior period, unchanged from 0000926326-25-000031:mdna:149]

[0000926326-26-000012:mdna:146]
[same as prior period, unchanged from 0000926326-25-000031:mdna:150]

[0000926326-26-000012:mdna:147]
(4)Refer to Note 14, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.
