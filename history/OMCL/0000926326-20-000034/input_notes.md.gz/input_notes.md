# OMCL notes — 0000926326-20-000034


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-20-000034:notes:1]
[same as prior period, unchanged from 0000926326-20-000023:notes:1]

[0000926326-20-000034:notes:2]
[same as prior period, unchanged from 0000926326-20-000023:notes:2]

[0000926326-20-000034:notes:3]
[same as prior period, unchanged from 0000926326-20-000023:notes:3]

[0000926326-20-000034:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2020 and December 31, 2019, the results of operations and comprehensive income for the three and nine months ended September 30, 2020 and 2019, and cash flows for the nine months ended September 30, 2020 and 2019. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2019 filed with the SEC on February 26, 2020, except as discussed in the sections entitled “Allowance for Credit Losses” and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2020 and cash flows for the nine months ended September 30, 2020 are not necessarily indicative of results that may be expected for the year ending December 31, 2020, or for any future period.

[0000926326-20-000034:notes:5]
[same as prior period, unchanged from 0000926326-20-000023:notes:5]

[0000926326-20-000034:notes:6]
[same as prior period, unchanged from 0000926326-20-000023:notes:6]

[0000926326-20-000034:notes:7]
[same as prior period, unchanged from 0000926326-20-000023:notes:7]

[0000926326-20-000034:notes:8]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of product revenues for the three and nine months ended September 30, 2019 in Note 2, Revenues. This change was not deemed material and was included to conform with current-period classification and presentation.

[0000926326-20-000034:notes:9]
[same as prior period, unchanged from 0000926326-20-000023:notes:9]

[0000926326-20-000034:notes:10]
[same as prior period, unchanged from 0000926326-20-000023:notes:10]

[0000926326-20-000034:notes:11]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. As of September 30, 2020, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities. Given the ongoing uncertainty surrounding the COVID-19 pandemic, events or circumstances may arise that could result in a change in estimates, judgments, or revisions to the carrying value of the Company’s assets or liabilities.

[0000926326-20-000034:notes:12]
[same as prior period, unchanged from 0000926326-20-000023:notes:12]

[0000926326-20-000034:notes:13]
[same as prior period, unchanged from 0000926326-20-000023:notes:13]

[0000926326-20-000034:notes:14]
[same as prior period, unchanged from 0000926326-20-000023:notes:14]

[0000926326-20-000034:notes:15]
[same as prior period, unchanged from 0000926326-20-000023:notes:15]

[0000926326-20-000034:notes:16]
[same as prior period, unchanged from 0000926326-20-000023:notes:16]

[0000926326-20-000034:notes:17]
[same as prior period, unchanged from 0000926326-20-000023:notes:17]

[0000926326-20-000034:notes:18]
|  | September 30,2020 |  | December 31,2019 |
|  | (In thousands) |
| Allowance for credit losses: |  |  |  |
| Accounts receivable and unbilled receivables | $ | 3,839 |  |  | $ | 3,227 |  |
| Long-term unbilled receivables (1) | 30 |  |  | — |  |
| Net investment in sales-type leases (2) | 269 |  |  | 225 |  |

[0000926326-20-000034:notes:19]
[same as prior period, unchanged from 0000926326-20-000023:notes:19]

[0000926326-20-000034:notes:20]
(1)    Included in other long-term assets in the Condensed Consolidated Balance Sheets.

[0000926326-20-000034:notes:21]
(2)    Includes both current and long-term portions presented in other current assets and long-term investment in sales-type leases, net, respectively.

[0000926326-20-000034:notes:22]
Changes in the allowances were not significant for the three and nine months ended September 30, 2020 and 2019.

[0000926326-20-000034:notes:23]
[same as prior period, unchanged from 0000926326-20-000023:notes:23]

[0000926326-20-000034:notes:24]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). The Company adopted ASU 2018-15 on January 1, 2020 on a prospective basis. The adoption of this guidance did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000926326-20-000034:notes:25]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans, and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans, and held-to-maturity debt securities, the standard replaced the current “incurred loss” approach with an “expected loss” model. Entities are required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. The Company adopted the new standard on January 1, 2020 using the modified retrospective transition method, which resulted in the recognition of an immaterial cumulative-effect adjustment to retained earnings.

[0000926326-20-000034:notes:26]
[same as prior period, unchanged from 0000926326-20-000023:notes:26]

[0000926326-20-000034:notes:27]
In August 2020, the FASB issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves

[0000926326-20-000034:notes:28]
disclosures for convertible instruments and earnings per share guidance. This update permits the use of either the modified retrospective or fully retrospective method of transition. ASU 2020-06 will be effective for the Company beginning January 1, 2022. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. The Company is currently evaluating the impact ASU 2020-06 will have on its Condensed Consolidated Financial Statements.

[0000926326-20-000034:notes:29]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-20-000034:notes:30]
[same as prior period, unchanged from 0000926326-20-000023:notes:28]

[0000926326-20-000034:notes:31]
[same as prior period, unchanged from 0000926326-20-000023:notes:29]

[0000926326-20-000034:notes:32]
[same as prior period, unchanged from 0000926326-20-000023:notes:30]

[0000926326-20-000034:notes:33]
[same as prior period, unchanged from 0000926326-20-000023:notes:31]

[0000926326-20-000034:notes:34]
[same as prior period, unchanged from 0000926326-20-000023:notes:32]

[0000926326-20-000034:notes:35]
[same as prior period, unchanged from 0000926326-20-000023:notes:33]

[0000926326-20-000034:notes:36]
[same as prior period, unchanged from 0000926326-20-000023:notes:34]

[0000926326-20-000034:notes:37]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.3 million and $2.8 million for the three months ended September 30, 2020 and 2019, respectively, and $6.9 million and $7.6 million for the nine months ended September 30, 2020 and 2019, respectively.

[0000926326-20-000034:notes:38]
[same as prior period, unchanged from 0000926326-20-000023:notes:36]

[0000926326-20-000034:notes:39]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and nine months ended September 30, 2020 and 2019:

[0000926326-20-000034:notes:40]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |
| Hardware and software | $ | 130,046 |  |  | $ | 142,424 |  |  | $ | 389,398 |  |  | $ | 394,243 |  |
| Consumables | 16,840 |  |  | 22,204 |  |  | 58,173 |  |  | 67,706 |  |
| Other | 4,451 |  |  | 3,860 |  |  | 12,781 |  |  | 10,528 |  |
| Total product revenues | $ | 151,337 |  |  | $ | 168,488 |  |  | $ | 460,352 |  |  | $ | 472,477 |  |

[0000926326-20-000034:notes:41]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2020 and 2019:

[0000926326-20-000034:notes:42]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |
| United States | $ | 193,639 |  |  | $ | 206,709 |  |  | $ | 579,425 |  |  | $ | 582,540 |  |
| Rest of world (1) | 20,060 |  |  | 22,096 |  |  | 63,581 |  |  | 66,195 |  |
| Total revenues | $ | 213,699 |  |  | $ | 228,805 |  |  | $ | 643,006 |  |  | $ | 648,735 |  |

[0000926326-20-000034:notes:43]
(1)    No individual country represented more than 10% of total revenues.

[0000926326-20-000034:notes:44]
[same as prior period, unchanged from 0000926326-20-000023:notes:42]

[0000926326-20-000034:notes:45]
[same as prior period, unchanged from 0000926326-20-000023:notes:43]

[0000926326-20-000034:notes:46]
|  | September 30,2020 |  | December 31,2019 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 8,344 |  |  | $ | 11,707 |  |
| Long-term unbilled receivables, net (2) | 15,379 |  |  | 12,260 |  |
| Total contract assets | $ | 23,723 |  |  | $ | 23,967 |  |
| Short-term deferred revenues, net | $ | 101,641 |  |  | $ | 90,894 |  |
| Long-term deferred revenues | 5,163 |  |  | 7,083 |  |
| Total contract liabilities | $ | 106,804 |  |  | $ | 97,977 |  |

[0000926326-20-000034:notes:47]
(1)    Included in accounts receivable and unbilled receivables in the Condensed Consolidated Balance Sheets.

[0000926326-20-000034:notes:48]
(2)    Included in other long-term assets in the Condensed Consolidated Balance Sheets.

[0000926326-20-000034:notes:49]
[same as prior period, unchanged from 0000926326-20-000023:notes:47]

[0000926326-20-000034:notes:50]
Short-term deferred revenues of $101.6 million and $90.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $24.2 million and $13.1 million, as of September 30, 2020 and December 31, 2019, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and nine months ended September 30, 2020, the Company recognized revenues of $13.2 million and $77.5 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $104.0 million as of December 31, 2019.

[0000926326-20-000034:notes:51]
Long-term deferred revenues include deferred revenues from service contracts of $5.2 million and $7.1 million as of September 30, 2020 and December 31, 2019, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-20-000034:notes:52]
[same as prior period, unchanged from 0000926326-20-000023:notes:50]

[0000926326-20-000034:notes:53]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2020 and 2019. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of September 30, 2020 and December 31, 2019.


## us-gaap:EarningsPerShareTextBlock

[0000926326-20-000034:notes:54]
Net Income Per ShareBasic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period, using the treasury stock method. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units, as well as shares the Company could be obligated to issue from its convertible senior notes and warrants, as described in Note 9, Convertible Senior Notes. Any anti-dilutive weighted-average dilutive shares related to stock award plans, convertible senior notes, and warrants are excluded from the computation of the diluted net income per share. 
The basic and diluted net income per share calculations for the three and nine months ended September 30, 2020 and 2019 were as follows:

[0000926326-20-000034:notes:55]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands, except per share data) |
| Net income | $ | 8,805 |  |  | $ | 19,983 |  |  | $ | 15,817 |  |  | $ | 39,243 |  |
| Weighted-average shares outstanding - basic | 42,802 |  |  | 41,771 |  |  | 42,606 |  |  | 41,283 |  |
| Effect of dilutive securities from stock award plans | 889 |  |  | 1,281 |  |  | 1,045 |  |  | 1,513 |  |
| Effect of dilutive convertible senior notes and warrants | — |  |  | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 43,691 |  |  | 43,052 |  |  | 43,651 |  |  | 42,796 |  |
| Net income per share - basic | $ | 0.21 |  |  | $ | 0.48 |  |  | $ | 0.37 |  |  | $ | 0.95 |  |
| Net income per share - diluted | $ | 0.20 |  |  | $ | 0.46 |  |  | $ | 0.36 |  |  | $ | 0.92 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 2,328 |  |  | 1,060 |  |  | 2,076 |  |  | 832 |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | 11,816 |  |  | — |  |  | 11,816 |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-20-000034:notes:56]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $629.2 million and $127.2 million as of September 30, 2020 and December 31, 2019, respectively, consisted of bank accounts with major financial institutions.

[0000926326-20-000034:notes:57]
[same as prior period, unchanged from 0000926326-20-000023:notes:55]

[0000926326-20-000034:notes:58]
The Company measures its financial instruments at fair value. The Company’s cash and cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's interest rate swap contracts and credit facilities are classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company's convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. As of September 30, 2020, the fair value of the convertible senior notes was $592.2 million, compared to their carrying value of $462.1 million, which is net of unamortized discount and debt issuance costs and excludes amounts classified within additional paid-in capital. Refer to Note 8, Debt and Credit Agreements, for further information regarding the Company’s credit facilities and Note 9, Convertible Senior Notes for further information regarding the Company’s convertible senior notes.

[0000926326-20-000034:notes:59]
[same as prior period, unchanged from 0000926326-20-000023:notes:57]

[0000926326-20-000034:notes:60]
[same as prior period, unchanged from 0000926326-20-000023:notes:58]

[0000926326-20-000034:notes:61]
[same as prior period, unchanged from 0000926326-20-000023:notes:59]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-20-000034:notes:62]
Balance Sheet Components
Balance sheet details as of September 30, 2020 and December 31, 2019 are presented in the tables below:

[0000926326-20-000034:notes:63]
|  | September 30,2020 |  | December 31,2019 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 29,994 |  |  | $ | 31,331 |  |
| Work in process | 7,057 |  |  | 7,620 |  |
| Finished goods | 66,050 |  |  | 69,060 |  |
| Total inventories | $ | 103,101 |  |  | $ | 108,011 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net | $ | 93,929 |  |  | $ | 85,070 |  |
| Unbilled receivables, net | 15,379 |  |  | 12,260 |  |
| Deferred debt issuance costs | 4,527 |  |  | 4,700 |  |
| Other assets | 1,877 |  |  | 1,006 |  |
| Total other long-term assets | $ | 115,712 |  |  | $ | 103,036 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 10,633 |  |  | $ | 10,058 |  |
| Advance payments from customers | 6,277 |  |  | 4,006 |  |
| Rebates and lease buyouts | 21,346 |  |  | 14,911 |  |
| Group purchasing organization fees | 4,211 |  |  | 5,934 |  |
| Taxes payable | 3,105 |  |  | 3,744 |  |
| Other accrued liabilities | 13,682 |  |  | 16,914 |  |
| Total accrued liabilities | $ | 59,254 |  |  | $ | 55,567 |  |

[0000926326-20-000034:notes:64]
The following tables summarize the changes in accumulated balances of other comprehensive income (loss) for the three and nine months ended September 30, 2020 and 2019:

[0000926326-20-000034:notes:65]
|  | Three Months Ended September 30, |
|  | 2020 |  | 2019 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (13,689) |  |  | $ | — |  |  | $ | (13,689) |  |  | $ | (11,576) |  |  | $ | — |  |  | $ | (11,576) |  |
| Other comprehensive income (loss) before reclassifications | 3,510 |  |  | — |  |  | 3,510 |  |  | (2,825) |  |  | — |  |  | (2,825) |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net current-period other comprehensive income (loss), net of tax | 3,510 |  |  | — |  |  | 3,510 |  |  | (2,825) |  |  | — |  |  | (2,825) |  |
| Ending balance | $ | (10,179) |  |  | $ | — |  |  | $ | (10,179) |  |  | $ | (14,401) |  |  | $ | — |  |  | $ | (14,401) |  |

[0000926326-20-000034:notes:66]
|  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (9,446) |  |  | $ | — |  |  | $ | (9,446) |  |  | $ | (11,274) |  |  | $ | 420 |  |  | $ | (10,854) |  |
| Other comprehensive income (loss) before reclassifications | (733) |  |  | — |  |  | (733) |  |  | (3,127) |  |  | 148 |  |  | (2,979) |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | — |  |  | — |  |  | — |  |  | (568) |  |  | (568) |  |
| Net current-period other comprehensive income (loss), net of tax | (733) |  |  | — |  |  | (733) |  |  | (3,127) |  |  | (420) |  |  | (3,547) |  |
| Ending balance | $ | (10,179) |  |  | $ | — |  |  | $ | (10,179) |  |  | $ | (14,401) |  |  | $ | — |  |  | $ | (14,401) |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-20-000034:notes:67]
Property and Equipment 
The following table represents the property and equipment balances as of September 30, 2020 and December 31, 2019:

[0000926326-20-000034:notes:68]
|  | September 30,2020 |  | December 31,2019 |
|  | (In thousands) |
| Equipment | $ | 100,221 |  |  | $ | 88,569 |  |
| Furniture and fixtures | 8,382 |  |  | 7,925 |  |
| Leasehold improvements | 20,695 |  |  | 18,979 |  |
| Software | 51,751 |  |  | 48,309 |  |
| Construction in progress | 6,028 |  |  | 6,179 |  |
| Property and equipment, gross | 187,077 |  |  | 169,961 |  |
| Accumulated depreciation and amortization | (129,518) |  |  | (115,715) |  |
| Total property and equipment, net | $ | 57,559 |  |  | $ | 54,246 |  |

[0000926326-20-000034:notes:69]
Depreciation and amortization expense of property and equipment was $4.6 million and $4.5 million for the three months ended September 30, 2020 and 2019, respectively, and $13.6 million and $12.9 million for the nine months ended September 30, 2020 and 2019, respectively.

[0000926326-20-000034:notes:70]
The geographic location of the Company's property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of September 30, 2020 and December 31, 2019:

[0000926326-20-000034:notes:71]
|  | September 30,2020 |  | December 31,2019 |
|  | (In thousands) |
| United States | $ | 51,467 |  |  | $ | 48,769 |  |
| Rest of world (1) | 6,092 |  |  | 5,477 |  |
| Total property and equipment, net | $ | 57,559 |  |  | $ | 54,246 |  |

[0000926326-20-000034:notes:72]
(1)    No individual country represented more than 10% of total property and equipment, net.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-20-000034:notes:73]
[same as prior period, unchanged from 0000926326-20-000023:notes:71]

[0000926326-20-000034:notes:74]
[same as prior period, unchanged from 0000926326-20-000023:notes:72]

[0000926326-20-000034:notes:75]
|  | December 31,2019 |  | Additions |  | Foreign currency exchange rate fluctuations |  | September 30,2020 |
|  | (In thousands) |
| Goodwill | $ | 336,539 |  |  | $ | — |  |  | $ | (83) |  |  | $ | 336,456 |  |

[0000926326-20-000034:notes:76]
[same as prior period, unchanged from 0000926326-20-000023:notes:74]

[0000926326-20-000034:notes:77]
The carrying amounts and useful lives of intangible assets as of September 30, 2020 and December 31, 2019 were as follows:

[0000926326-20-000034:notes:78]
|  | September 30, 2020 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 134,889 |  |  | $ | (60,964) |  |  | $ | (1,088) |  |  | $ | 72,837 |  |  | 10 - 30 |
| Acquired technology | 77,029 |  |  | (42,008) |  |  | 6 |  |  | 35,027 |  |  | 5 - 20 |
| Backlog | 1,150 |  |  | (1,006) |  |  | — |  |  | 144 |  |  | 4 |
| Trade names | 7,650 |  |  | (5,603) |  |  | 15 |  |  | 2,062 |  |  | 6 - 12 |
| Patents | 3,217 |  |  | (1,701) |  |  | 1 |  |  | 1,517 |  |  | 2 - 20 |
| Total intangibles assets, net | $ | 223,935 |  |  | $ | (111,282) |  |  | $ | (1,066) |  |  | $ | 111,587 |  |  |  |

[0000926326-20-000034:notes:79]
|  | December 31, 2019 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 135,234 |  |  | $ | (54,860) |  |  | $ | (1,058) |  |  | $ | 79,316 |  |  | 10 - 30 |
| Acquired technology | 77,142 |  |  | (36,194) |  |  | 5 |  |  | 40,953 |  |  | 3 - 20 |
| Backlog | 1,150 |  |  | (791) |  |  | — |  |  | 359 |  |  | 4 |
| Trade names | 7,650 |  |  | (5,037) |  |  | 11 |  |  | 2,624 |  |  | 6 - 12 |
| Patents | 3,217 |  |  | (1,603) |  |  | 1 |  |  | 1,615 |  |  | 2 - 20 |
| Total intangibles assets, net | $ | 224,393 |  |  | $ | (98,485) |  |  | $ | (1,041) |  |  | $ | 124,867 |  |  |  |

[0000926326-20-000034:notes:80]
(1)    The differences in gross carrying amounts between periods are primarily due to the write-off of certain fully amortized intangible assets.

[0000926326-20-000034:notes:81]
Amortization expense of intangible assets was $4.4 million and $4.6 million for the three months ended September 30, 2020 and 2019, respectively, and $13.3 million and $14.1 million for the nine months ended September 30, 2020 and 2019, respectively.

[0000926326-20-000034:notes:82]
[same as prior period, unchanged from 0000926326-20-000023:notes:80]

[0000926326-20-000034:notes:83]
|  | September 30,2020 |
|  | (In thousands) |
| Remaining three months of 2020 | $ | 4,280 |  |
| 2021 | 16,109 |  |
| 2022 | 14,814 |  |
| 2023 | 13,718 |  |
| 2024 | 7,959 |  |
| Thereafter | 54,707 |  |
| Total | $ | 111,587 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-20-000034:notes:84]
Debt and Credit Agreements
2016 Senior Credit Facility

[0000926326-20-000034:notes:85]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Prior Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Prior Term Loan Facility” and together with the Prior Revolving Credit Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Prior Credit Agreement had an expiration date of January 5, 2021, upon which date all remaining outstanding borrowings were due and payable.

[0000926326-20-000034:notes:86]
Loans under the Prior Facilities bore interest, at the Company’s option, at a rate equal to either (a) LIBOR, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Prior Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Prior Credit Agreement). Undrawn commitments under the Prior Revolving Credit Facility were subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Prior Revolving Credit Facility.

[0000926326-20-000034:notes:87]
On each of April 11, 2017 and December 26, 2017, the parties entered into amendments to the Prior Credit Agreement. Under these amendments, the Prior Revolving Credit Facility was increased from $200.0 million to $315.0 million, and certain other modifications were made. In connection with the December 2017 amendment, the Company incurred and capitalized an additional $2.1 million of debt issuance costs.

[0000926326-20-000034:notes:88]
2019 Revolving Credit Facility

[0000926326-20-000034:notes:89]
On November 15, 2019, the Company refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-20-000034:notes:90]
On November 15, 2019, the $80.0 million outstanding term loan balance under the Prior Facilities was transferred to the Current Revolving Credit Facility.

[0000926326-20-000034:notes:91]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) LIBOR, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate,

[0000926326-20-000034:notes:92]
(ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. The applicable margin for and certain other terms of any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

[0000926326-20-000034:notes:93]
On September 22, 2020, the parties entered into an amendment (the “Amendment”) to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions as described in Note 9, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020 and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

[0000926326-20-000034:notes:94]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of September 30, 2020.

[0000926326-20-000034:notes:95]
The refinancing of the Prior Credit Agreement was evaluated in accordance with Accounting Standards Codification (“ASC”) 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the A&R Credit Agreement.

[0000926326-20-000034:notes:96]
In connection with the A&R Credit Agreement on November 15, 2019, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. In connection with the Amendment on September 22, 2020, the Company incurred and capitalized an additional $0.6 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs for credit agreements was approximately $0.2 million and $0.6 million for the three months ended September 30, 2020 and 2019, respectively, and approximately $0.7 million and $1.7 million for the nine months ended September 30, 2020 and 2019, respectively.

[0000926326-20-000034:notes:97]
Interest expense (exclusive of fees and debt issuance cost amortization) was approximately $0.3 million and $0.8 million for the three months ended September 30, 2020 and 2019, and approximately $0.5 million and $3.0 million for the nine months ended September 30, 2020 and 2019, respectively.

[0000926326-20-000034:notes:98]
The following table represents changes in the carrying amount of the Company’s debt obligations:

[0000926326-20-000034:notes:99]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | 150,000 |  |
| Repayments | (200,000) |  |
| Balance as of September 30, 2020 | $ | — |  |

[0000926326-20-000034:notes:100]
The following table represents changes in the balance of the Company's deferred debt issuance costs:

[0000926326-20-000034:notes:101]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | 550 |  |
| Amortization | (723) |  |
| Balance as of September 30, 2020 | $ | 4,527 |  |

[0000926326-20-000034:notes:102]
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-20-000034:notes:103]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased or converted.

[0000926326-20-000034:notes:104]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ending on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

[0000926326-20-000034:notes:105]
Upon conversion, the Company may satisfy its conversion obligation by paying or delivering, as the case may be, cash, shares of its common stock, or a combination of cash and shares of its common stock, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

[0000926326-20-000034:notes:106]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal

[0000926326-20-000034:notes:107]
amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2020, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-20-000034:notes:108]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

[0000926326-20-000034:notes:109]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. Accordingly, at issuance the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represents the debt discount, which the Company will amortize to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions. As of September 30, 2020, the remaining life of the Notes and the related debt discount and issuance cost accretion is approximately 5.0 years.

[0000926326-20-000034:notes:110]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 8.1 million shares.

[0000926326-20-000034:notes:111]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2020:

[0000926326-20-000034:notes:112]
|  | September 30,2020 |
|  | (In thousands) |
| Liability: |  |
| Principal amount | $ | 575,000 |  |
| Unamortized discount | (100,261) |  |
| Unamortized debt issuance costs | (12,624) |  |
| Convertible senior notes, liability component | $ | 462,115 |  |
| Equity: |  |
| Embedded conversion option | $ | 100,510 |  |
| Debt issuance costs | (2,680) |  |
| Deferred tax impact | (25,098) |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |

[0000926326-20-000034:notes:113]
(1)    Included in additional paid-in capital in the Condensed Consolidated Balance Sheets.

[0000926326-20-000034:notes:114]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2020:

[0000926326-20-000034:notes:115]
|  | Three and Nine Months EndedSeptember 30, 2020 |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 20 |  |  |  |  |  |  |  |
| Amortization of discount | $ | 249 |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 31 |  |  |  |  |  |  |  |

[0000926326-20-000034:notes:116]
Convertible Note Hedge and Warrant Transactions

[0000926326-20-000034:notes:117]
In connection with the issuance of the Notes, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

[0000926326-20-000034:notes:118]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.
Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid in capital in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000926326-20-000034:notes:119]
Lessor Leases
Sales-Type Leases

[0000926326-20-000034:notes:120]
On a recurring basis, the Company enters into multi-year, sales-type lease agreements, with the majority varying in length from one to five years. The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 66% of the lease receivable balance, are retained in-house.

[0000926326-20-000034:notes:121]
The following table presents the Company’s income recognized from sales-type leases for the three and nine months ended September 30, 2020 and 2019:

[0000926326-20-000034:notes:122]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 6,033 |  |  | $ | 9,017 |  |  | $ | 19,037 |  |  | $ | 33,833 |  |
| Cost of sales-type lease revenues | (2,486) |  |  | (3,409) |  |  | (7,710) |  |  | (13,804) |  |
| Selling profit on sales-type lease revenues | $ | 3,547 |  |  | $ | 5,608 |  |  | $ | 11,327 |  |  | $ | 20,029 |  |
| Interest income on sales-type lease receivables | $ | 450 |  |  | $ | 527 |  |  | $ | 1,437 |  |  | $ | 1,335 |  |

[0000926326-20-000034:notes:123]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at September 30, 2020 and December 31, 2019:

[0000926326-20-000034:notes:124]
|  | September 30,2020 |  | December 31,2019 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 35,837 |  |  | $ | 32,360 |  |
| Less: Unearned interest income portion | (3,044) |  |  | (2,840) |  |
| Net investment in sales-type leases | 32,793 |  |  | 29,520 |  |
| Less: Current portion (1) | (10,283) |  |  | (9,770) |  |
| Long-term investment in sales-type leases, net | $ | 22,510 |  |  | $ | 19,750 |  |

[0000926326-20-000034:notes:125]
(1)    The current portion of the net investment in sales-type leases is included in other current assets in the Condensed Consolidated Balance Sheets.

[0000926326-20-000034:notes:126]
The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value.

[0000926326-20-000034:notes:127]
The maturity schedule of future minimum lease payments under sales-type leases retained in-house and the reconciliation to the net investment in sales-type leases reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-20-000034:notes:128]
|  | September 30,2020 |
|  | (In thousands) |
| Remaining three months of 2020 | $ | 4,654 |  |
| 2021 | 9,714 |  |
| 2022 | 8,867 |  |
| 2023 | 6,698 |  |
| 2024 | 3,904 |  |
| Thereafter | 2,000 |  |
| Total future minimum sales-type lease payments | 35,837 |  |
| Present value adjustment | (3,044) |  |
| Total net investment in sales-type leases | $ | 32,793 |  |

[0000926326-20-000034:notes:129]
Operating Leases

[0000926326-20-000034:notes:130]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of ASC 842, Leases, on January 1, 2019. These agreements in place prior to January 1, 2019 will continue to be treated as operating leases, however any new leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with ASC 842. The operating lease arrangements generally have initial terms of one to seven years.

[0000926326-20-000034:notes:131]
The following table represents the Company’s income recognized from operating leases for the three and nine months ended September 30, 2020 and 2019:

[0000926326-20-000034:notes:132]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |
| Rental income | $ | 2,863 |  |  | $ | 2,896 |  |  | $ | 8,864 |  |  | $ | 9,548 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-20-000034:notes:133]
Lessee Leases The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to 12 years. As of September 30, 2020, the Company did not have any additional material operating leases that were entered into, but not yet commenced. 
The maturity schedule of future minimum lease payments under operating leases and the reconciliation to the operating lease liabilities reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-20-000034:notes:134]
|  | September 30,2020 |
|  | (In thousands) |
| Remaining three months of 2020 | $ | 3,488 |  |
| 2021 | 13,667 |  |
| 2022 | 12,386 |  |
| 2023 | 8,761 |  |
| 2024 | 8,143 |  |
| Thereafter | 20,206 |  |
| Total operating lease payments | 66,651 |  |
| Present value adjustment | (11,653) |  |
| Total operating lease liabilities (1) | $ | 54,998 |  |

[0000926326-20-000034:notes:135]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $10.6 million and $44.4 million, respectively. The short-term portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-20-000034:notes:136]
Operating lease costs were $3.5 million and $3.7 million for the three months ended September 30, 2020 and 2019, respectively, and $10.5 million and $11.0 million for the nine months ended September 30, 2020 and 2019, respectively. Short-term lease costs and variable lease costs were immaterial for the three and nine months ended September 30, 2020 and 2019.

[0000926326-20-000034:notes:137]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the nine months ended September 30, 2020 and 2019:

[0000926326-20-000034:notes:138]
|  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 10,543 |  |  | $ | 11,023 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 1,559 |  |  | $ | 957 |  |

[0000926326-20-000034:notes:139]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of September 30, 2020 and December 31, 2019:

[0000926326-20-000034:notes:140]
|  | September 30,2020 |  | December 31,2019 |
| Weighted-average remaining lease term, years | 5.9 |  | 6.4 |
| Weighted-average discount rate, % | 6.4 | % |  | 6.4 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-20-000034:notes:141]
Commitments and Contingencies
Purchase Obligations

[0000926326-20-000034:notes:142]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2020, the Company had non-cancelable purchase commitments of $66.4 million, of which $49.3 million are expected to be paid within the year ending December 31, 2020.

[0000926326-20-000034:notes:143]
Legal Proceedings

[0000926326-20-000034:notes:144]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

[0000926326-20-000034:notes:145]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its former subsidiaries, Aesynt Incorporated (“Aesynt”), which, through a series of mergers, has been merged into the Company, in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint sought monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, retention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice. On August 21, 2019, a new lawsuit was filed against the Company and Aesynt, in the Circuit Court for the County of Albemarle, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Aesynt Incorporated, et al., Case No CL19-1301. The complaint sought monetary recovery of damages based upon claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. On August 25, 2020, the Company and Aesynt filed a motion to dismiss for failure of the plaintiff to serve the complaint within one year of its filing date. On September 30, 2020, the Court dismissed the complaint with prejudice.

[0000926326-20-000034:notes:146]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the complaint on October 28, 2020. A status conference is currently set for November 5, 2020. The Company intends to defend the lawsuit vigorously.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-20-000034:notes:147]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 30.1% and 24.6% for the nine months ended September 30, 2020 and 2019, respectively. The Company’s effective tax rate for the nine months ended September 30, 2020 was based on best estimates, which may fluctuate through the remainder of the year due to the volatility and uncertainty of global economic conditions in connection with the COVID-19 pandemic.

[0000926326-20-000034:notes:148]
Due to continuing global operational centralization activities and legal entity rationalization, the Company recognized gain on the sale of certain intellectual property rights by Aesynt B.V. to Omnicell, Inc., which resulted in a tax expense, net of tax benefit, of $9.6 million during the nine months ended September 30, 2019. In March 2020, Aesynt B.V. subsequently merged with and into Aesynt Holding B.V., with Aesynt Holding B.V. surviving and changing its name to Omnicell B.V. Due to continuing global operational centralization activities in the third quarter of 2020, the Company recognized a gain on Omnicell Limited transferring its shares in Omnicell GmbH to Omnicell International, LLC, which resulted in a discrete tax expense of $0.5 million during the nine months ended September 30, 2020. The Company also recognized a discrete tax benefit related to equity compensation in the amount of $4.2 million and $8.1 million for the nine months ended September 30, 2020 and 2019, respectively.

[0000926326-20-000034:notes:149]
[same as prior period, unchanged from 0000926326-20-000023:notes:130]

[0000926326-20-000034:notes:150]
On March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was signed into law in response to the COVID-19 pandemic. The CARES Act, among other provisions, includes provisions related to refundable payroll tax credits, deferment of the employer portion of certain payroll taxes, net operating losses carryback periods, alternative minimum tax credit refunds, modification to net interest expense deduction limitation, and technical amendments to

[0000926326-20-000034:notes:151]
tax depreciation methods for qualified improvement property placed in service after December 31, 2017. The provisions of the CARES Act did not have a material impact on the Company’s income taxes.

[0000926326-20-000034:notes:152]
As of September 30, 2020 and December 31, 2019, the Company had gross unrecognized tax benefits of $17.6 million and $16.8 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. As of September 30, 2020 and December 31, 2019, the amount of accrued interest and penalties was $1.2 million and $1.0 million, respectively.

[0000926326-20-000034:notes:153]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of September 30, 2020, the Company was no longer subject to United States, state, and foreign examination for years before 2016, 2015, and 2015, respectively.

[0000926326-20-000034:notes:154]
[same as prior period, unchanged from 0000926326-20-000023:notes:134]


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-20-000034:notes:155]
[same as prior period, unchanged from 0000926326-20-000023:notes:135]

[0000926326-20-000034:notes:156]
[same as prior period, unchanged from 0000926326-20-000023:notes:136]

[0000926326-20-000034:notes:157]
[same as prior period, unchanged from 0000926326-20-000023:notes:137]

[0000926326-20-000034:notes:158]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2020 and 2019:

[0000926326-20-000034:notes:159]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,758 |  |  | $ | 1,316 |  |  | $ | 5,658 |  |  | $ | 4,194 |  |
| Research and development | 1,577 |  |  | 1,652 |  |  | 5,199 |  |  | 4,938 |  |
| Selling, general, and administrative | 7,689 |  |  | 5,537 |  |  | 22,177 |  |  | 16,043 |  |
| Total share-based compensation expense | $ | 11,024 |  |  | $ | 8,505 |  |  | $ | 33,034 |  |  | $ | 25,175 |  |

[0000926326-20-000034:notes:160]
[same as prior period, unchanged from 0000926326-20-000023:notes:140]

[0000926326-20-000034:notes:161]
The following assumptions were used to value stock options and Employee Stock Purchase Plan (“ESPP”) shares granted pursuant to the Company’s equity incentive plans for the three and nine months ended September 30, 2020 and 2019:

[0000926326-20-000034:notes:162]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Stock options |  |  |  |  |  |  |  |
| Expected life, years | 4.7 |  | 4.3 |  | 4.7 |  | 4.4 |
| Expected volatility, % | 41.2 | % |  | 34.7 | % |  | 39.0 | % |  | 33.7 | % |
| Risk-free interest rate, % | 0.3 | % |  | 1.6 | % |  | 0.7 | % |  | 2.1 | % |
| Estimated forfeiture rate, % | 5.7 | % |  | 7.2 | % |  | 5.7 | % |  | 7.2 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-20-000034:notes:163]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Employee stock purchase plan shares |  |  |  |  |  |  |  |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Expected volatility, % | 30.4% - 53.5% |  | 28.9% - 39.9% |  | 30.4% - 53.5% |  | 28.2% - 39.9% |
| Risk-free interest rate, % | 0.1% - 2.7% |  | 1.4% - 2.7% |  | 0.1% - 2.7% |  | 1.3% - 2.7% |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-20-000034:notes:164]
[same as prior period, unchanged from 0000926326-20-000023:notes:144]

[0000926326-20-000034:notes:165]
The following table summarizes the share option activity under the Company’s equity incentive plans during the nine months ended September 30, 2020:

[0000926326-20-000034:notes:166]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2019 | 3,902 |  |  | $ | 52.75 |  |  | 7.7 |  | $ | 113,198 |  |
| Granted | 1,065 |  |  | 75.92 |  |  |  |  |  |
| Exercised | (446) |  |  | 38.10 |  |  |  |  |  |
| Expired | (11) |  |  | 59.08 |  |  |  |  |  |
| Forfeited | (356) |  |  | 65.84 |  |  |  |  |  |
| Outstanding at September 30, 2020 | 4,154 |  |  | $ | 59.12 |  |  | 7.6 |  | $ | 72,331 |  |
| Exercisable at September 30, 2020 | 1,763 |  |  | $ | 43.38 |  |  | 6.0 |  | $ | 55,936 |  |
| Vested and expected to vest at September 30, 2020 and thereafter | 3,973 |  |  | $ | 58.49 |  |  | 7.5 |  | $ | 71,456 |  |

[0000926326-20-000034:notes:167]
The weighted-average fair value per share of options granted during the three months ended September 30, 2020 and 2019 was $23.75 and $21.59, respectively, and the weighted-average fair value per share of options granted during the nine months ended September 30, 2020 and 2019 was $25.30 and $23.41, respectively. The intrinsic value of options exercised during the three months ended September 30, 2020 and 2019 was $4.1 million and $2.7 million, respectively, and during the nine months ended September 30, 2020 and 2019 was $16.5 million and $27.0 million, respectively.

[0000926326-20-000034:notes:168]
As of September 30, 2020, total unrecognized compensation cost related to unvested stock options was $50.4 million, which is expected to be recognized over a weighted-average vesting period of 2.9 years.

[0000926326-20-000034:notes:169]
[same as prior period, unchanged from 0000926326-20-000023:notes:149]

[0000926326-20-000034:notes:170]
For the nine months ended September 30, 2020 and 2019, employees purchased approximately 333,000 and 374,000 shares of common stock, respectively, under the ESPP at weighted average prices of $48.77 and $41.44, respectively. As of September 30, 2020, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $6.2 million and is expected to be recognized over a weighted-average period of 1.5 years.

[0000926326-20-000034:notes:171]
[same as prior period, unchanged from 0000926326-20-000023:notes:151]

[0000926326-20-000034:notes:172]
Summaries of the restricted stock activity under the Company’s 2009 Equity Incentive Plan, as amended (the “2009 Plan”) are presented below for the nine months ended September 30, 2020:

[0000926326-20-000034:notes:173]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted stock units |  |  |  |  |  |  |  |
| Outstanding at December 31, 2019 | 544 |  |  | $ | 66.65 |  |  | 1.6 |  | $ | 44,492 |  |
| Granted (Awarded) | 285 |  |  | 72.10 |  |  |  |  |  |
| Vested (Released) | (107) |  |  | 56.60 |  |  |  |  |  |
| Forfeited | (104) |  |  | 66.12 |  |  |  |  |  |
| Outstanding and unvested at September 30, 2020 | 618 |  |  | $ | 71.00 |  |  | 1.6 |  | $ | 46,114 |  |

[0000926326-20-000034:notes:174]
As of September 30, 2020, total unrecognized compensation cost related to RSUs was $40.3 million, which is expected to be recognized over the remaining weighted-average vesting period of 3.1 years.

[0000926326-20-000034:notes:175]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted stock awards |  |  |  |
| Outstanding at December 31, 2019 | 17 |  |  | $ | 81.92 |  |
| Granted (Awarded) | 21 |  |  | 68.11 |  |
| Vested (Released) | (17) |  |  | 81.92 |  |
| Outstanding and unvested at September 30, 2020 | 21 |  |  | $ | 68.11 |  |

[0000926326-20-000034:notes:176]
As of September 30, 2020, total unrecognized compensation cost related to RSAs was $0.9 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.6 years.

[0000926326-20-000034:notes:177]
[same as prior period, unchanged from 0000926326-20-000023:notes:157]

[0000926326-20-000034:notes:178]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below for the nine months ended September 30, 2020:

[0000926326-20-000034:notes:179]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2019 | 134 |  |  | $ | 55.82 |  |
| Granted | 63 |  |  | 82.41 |  |
| Vested | (44) |  |  | 54.25 |  |
| Forfeited | (5) |  |  | 81.72 |  |
| Outstanding and unvested at September 30, 2020 | 148 |  |  | $ | 66.69 |  |

[0000926326-20-000034:notes:180]
As of September 30, 2020, total unrecognized compensation cost related to PSUs was approximately $4.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.2 years.

[0000926326-20-000034:notes:181]
[same as prior period, unchanged from 0000926326-20-000023:notes:161]

[0000926326-20-000034:notes:182]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of September 30, 2020:

[0000926326-20-000034:notes:183]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 4,154 |  |
| Non-vested restricted stock awards | 787 |  |
| Shares authorized for future issuance | 1,553 |  |
| ESPP shares available for future issuance | 1,206 |  |
| Total shares reserved for future issuance | 7,700 |  |

[0000926326-20-000034:notes:184]
[same as prior period, unchanged from 0000926326-20-000023:notes:164]

[0000926326-20-000034:notes:185]
On August 2, 2016, the Company's Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of September 30, 2020, the maximum dollar value of shares that may yet be purchased under the 2014 Repurchase Program and the 2016 Repurchase Program was $54.9 million. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase programs at any time.

[0000926326-20-000034:notes:186]
On September 17, 2020, the Board authorized a one-time stock repurchase transaction providing for the repurchase of up to $75.0 million of the Company’s common stock in privately negotiated transactions concurrently with the issuance of the Notes, described in Note 9, Convertible Senior Notes. In September 2020, the Company repurchased 749,300 shares of its common stock from purchasers of the Notes in the offering in privately negotiated transactions effected through one of the initial purchasers or its affiliate at an average price of $70.78 per share for an aggregate purchase price of approximately $53.0 million. There will be no further repurchases under this one-time authorization.

[0000926326-20-000034:notes:187]
During the three and nine months ended September 30, 2020 and 2019, the Company did not repurchase any of its outstanding common stock including under the 2014 Repurchase Program and the 2016 Repurchase Program, other than the separately-authorized one-time stock repurchase concurrent with the offering of the Notes in September 2020.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-20-000034:notes:188]
[same as prior period, unchanged from 0000926326-20-000023:notes:166]

[0000926326-20-000034:notes:189]
For the three and nine months ended September 30, 2020 and the three months ended September 30, 2019, the Company did not sell any of its common stock under the Distribution Agreement.

[0000926326-20-000034:notes:190]
For the nine months ended September 30, 2019, the Company received gross proceeds of $38.5 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 460,000 shares of its common stock at an average price of approximately $83.81 per share.

[0000926326-20-000034:notes:191]
As of September 30, 2020, the Company had an aggregate of $31.5 million available to be offered under the Distribution Agreement. The registration statement under which the shares that may be sold pursuant to the Distribution Agreement are registered will expire on November 3, 2020.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-20-000034:notes:192]
Restructuring ExpensesIn the first quarter of 2020, the Company announced a company-wide organizational realignment initiative in order to more effectively align its organizational infrastructure and operations with the strategic vision of the autonomous pharmacy. In the second quarter of 2020, the Company continued its organizational realignment initiative, as well as initiated a restructuring plan to help mitigate the adverse impact of the COVID-19 pandemic on its business and financial results. During the nine 
months ended September 30, 2020, the Company incurred and accrued $10.0 million of employee severance costs and related expenses. As of September 30, 2020, the unpaid balance related to this restructuring plan was $1.0 million.

[0000926326-20-000034:notes:193]
The following table summarizes the total restructuring expense recognized in the Company’s Condensed Consolidated Statements of Operations for the nine months ended September 30, 2020:

[0000926326-20-000034:notes:194]
|  |  |  | Nine Months EndedSeptember 30, 2020 |
|  |  |  |  | (In thousands) |
| Cost of product and service revenues |  |  |  |  | $ | 2,564 |  |  |  |
| Research and development |  |  |  |  | 3,716 |  |  |  |
| Selling, general, and administrative |  |  |  |  | 3,681 |  |  |  |
| Total restructuring expense |  |  |  |  | $ | 9,961 |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0000926326-20-000034:notes:195]
Subsequent Events On October 1, 2020, the Company completed the acquisition of the 340B Link Business of Pharmaceutical Strategies Group, LLC pursuant to the terms and conditions of the Equity Purchase Agreement, dated August 11, 2020, as amended, by and among the Company, PSGH, LLC, BW Apothecary Holdings, LLC, the sellers identified therein and the sellers’ representative (the “Purchase Agreement”). The purchase price was $225.0 million, subject to certain adjustments as provided for in the Purchase Agreement. The acquisition was funded with proceeds from the issuance of the Notes. Refer to Note 9, Convertible Senior Notes, for further information regarding the issuance of the Notes. The Company is in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation.
