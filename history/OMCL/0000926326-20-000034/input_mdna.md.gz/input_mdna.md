# OMCL MD&A — 0000926326-20-000034


## mdna

[0000926326-20-000034:mdna:1]
[same as prior period, unchanged from 0000926326-20-000023:mdna:1]

[0000926326-20-000034:mdna:2]
[same as prior period, unchanged from 0000926326-20-000023:mdna:2]

[0000926326-20-000034:mdna:3]
[same as prior period, unchanged from 0000926326-20-000023:mdna:3]

[0000926326-20-000034:mdna:4]
[same as prior period, unchanged from 0000926326-20-000023:mdna:4]

[0000926326-20-000034:mdna:5]
[same as prior period, unchanged from 0000926326-20-000023:mdna:5]

[0000926326-20-000034:mdna:6]
[same as prior period, unchanged from 0000926326-20-000023:mdna:6]

[0000926326-20-000034:mdna:7]
[same as prior period, unchanged from 0000926326-20-000023:mdna:7]

[0000926326-20-000034:mdna:8]
[same as prior period, unchanged from 0000926326-20-000023:mdna:8]

[0000926326-20-000034:mdna:9]
[same as prior period, unchanged from 0000926326-20-000023:mdna:9]

[0000926326-20-000034:mdna:10]
[same as prior period, unchanged from 0000926326-20-000023:mdna:10]

[0000926326-20-000034:mdna:11]
[same as prior period, unchanged from 0000926326-20-000023:mdna:11]

[0000926326-20-000034:mdna:12]
[same as prior period, unchanged from 0000926326-20-000023:mdna:12]

[0000926326-20-000034:mdna:13]
[same as prior period, unchanged from 0000926326-20-000023:mdna:13]

[0000926326-20-000034:mdna:14]
[same as prior period, unchanged from 0000926326-20-000023:mdna:14]

[0000926326-20-000034:mdna:15]
[same as prior period, unchanged from 0000926326-20-000023:mdna:15]

[0000926326-20-000034:mdna:16]
[same as prior period, unchanged from 0000926326-20-000023:mdna:16]

[0000926326-20-000034:mdna:17]
•the outcome of any legal proceedings to which we are a party;

[0000926326-20-000034:mdna:18]
[same as prior period, unchanged from 0000926326-20-000023:mdna:18]

[0000926326-20-000034:mdna:19]
•our expected uses for the remaining proceeds from the offering of our convertible notes;

[0000926326-20-000034:mdna:20]
•our ability to protect our intellectual property and operate our business without infringing, misappropriating or otherwise violating the intellectual property rights of others;

[0000926326-20-000034:mdna:21]
[same as prior period, unchanged from 0000926326-20-000023:mdna:20]

[0000926326-20-000034:mdna:22]
[same as prior period, unchanged from 0000926326-20-000023:mdna:21]

[0000926326-20-000034:mdna:23]
[same as prior period, unchanged from 0000926326-20-000023:mdna:22]

[0000926326-20-000034:mdna:24]
[same as prior period, unchanged from 0000926326-20-000023:mdna:23]

[0000926326-20-000034:mdna:25]
[same as prior period, unchanged from 0000926326-20-000023:mdna:24]

[0000926326-20-000034:mdna:26]
We own various trademarks and service marks used in our business, including the following registered and unregistered marks which appear in this report: Omnicell®, the Omnicell logo, Ateb®, InPharmics®, Aesynt®, Performance CenterTM, and EnlivenHealthTM. This report also includes the trademarks and service marks of other companies. All other trademarks and service marks used in this report are the marks of their respective holders.

[0000926326-20-000034:mdna:27]
[same as prior period, unchanged from 0000926326-20-000023:mdna:26]

[0000926326-20-000034:mdna:28]
[same as prior period, unchanged from 0000926326-20-000023:mdna:27]

[0000926326-20-000034:mdna:29]
[same as prior period, unchanged from 0000926326-20-000023:mdna:28]

[0000926326-20-000034:mdna:30]
Approximately 7,000 facilities worldwide use our automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. Approximately 50,000 institutional and retail pharmacies across North America and the United Kingdom leverage our innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 91% and 90% of our total revenues for the three months ended September 30, 2020 and 2019, respectively, and 90% of our total revenues for both the nine months ended September 30, 2020 and 2019.

[0000926326-20-000034:mdna:31]
Over the past several years, our business has expanded from a single-point solution to a platform of products and services that will help to further advance the vision of the autonomous pharmacy. This has resulted in larger deal sizes across multiple products, services, and implementations for customers and, we believe, more comprehensive, valuable, and enduring relationships.

[0000926326-20-000034:mdna:32]
We utilize product bookings as an indicator of the success of our business. Product bookings consist of all firm orders, as evidenced generally by a non-cancelable contract and purchase order for equipment and software products, and by a purchase order for consumables. Equipment and software product bookings are generally installable within twelve months of booking, and, other than sales based on subscription services, are generally recorded as revenue upon customer receipts of goods or acceptance of the installation.

[0000926326-20-000034:mdna:33]
In addition to product solution sales, we provide services to our customers. We provide installation planning and consulting as part of most product sales which is generally included in the initial price of the solution. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in increments of one to five years. As a result of the growth of our installed base of customers, our service revenues have also grown.

[0000926326-20-000034:mdna:34]
Our full-time headcount was approximately 2,670 and 2,700 on September 30, 2020 and December 31, 2019, respectively.

[0000926326-20-000034:mdna:35]
[same as prior period, unchanged from 0000926326-20-000023:mdna:35]

[0000926326-20-000034:mdna:36]
[same as prior period, unchanged from 0000926326-20-000023:mdna:36]

[0000926326-20-000034:mdna:37]
[same as prior period, unchanged from 0000926326-20-000023:mdna:37]

[0000926326-20-000034:mdna:38]
[same as prior period, unchanged from 0000926326-20-000023:mdna:38]

[0000926326-20-000034:mdna:39]
We are committed to being the care provider’s most trusted partner and executing on the vision of the autonomous pharmacy by delivering automation, intelligence, and services designed to transform the pharmacy care delivery model, helping to dramatically improve outcomes and lower costs for our healthcare partners. We believe there are significant challenges in pharmacy including, but not limited to, medication errors, drug shortages, medication loss due to drug diversion, significant medication waste and expiration costs, a high level of manual steps in the medication management automation process, complexity around compliance requirements, high pharmacy employee turnover rates, hospitalizations from adverse drug events in outpatient settings, high variability in outcomes, and limited inventory visibility. We believe that these significant challenges in pharmacy drive the demand for our solutions and represent large market opportunities in three product categories:

[0000926326-20-000034:mdna:40]
•Point of Care.  As a market leader, we expect to continue expansion of this product category as customers increase use of our dispensing systems in more areas within their hospitals. In addition, we are early in the replacement cycle of our XT Series automated dispensing systems which we believe is a significant market opportunity and we expect to continue to focus on further penetrating markets through competitive conversion.

[0000926326-20-000034:mdna:41]
We believe our current portfolio within the Point of Care market and new innovation and services will continue to drive improved outcomes and lower costs for our customers.

[0000926326-20-000034:mdna:42]
[same as prior period, unchanged from 0000926326-20-000023:mdna:41]

[0000926326-20-000034:mdna:43]
•Retail, Institutional, and Payer.  We believe the Retail, Institutional, and Payer market represents a large opportunity as the majority of drugs are distributed in the non-acute sector. New technology is leading to innovation at traditional retail providers, which combined with the move to value-based care results, we believe will incentivize the market to adopt solutions to help providers and payers engage patients in new ways that lower the total cost of care. We believe adoption of our EnlivenHealth (formerly Population Health Solutions) portfolio of software products and services, along with medication adherence packaging, will increase adherence performance rates, increase prescription volume for our customers and reduce hospital and emergency room visits due to improved adherence.

[0000926326-20-000034:mdna:44]
[same as prior period, unchanged from 0000926326-20-000023:mdna:43]

[0000926326-20-000034:mdna:45]
Coronavirus (COVID-19) Update

[0000926326-20-000034:mdna:46]
Keeping in mind our role in the healthcare industry, we are continuing to closely monitor the COVID-19 pandemic. Our top priorities remain protecting the health and well-being of our customers, their patients, and our employees, while maintaining business continuity to meet the needs of our customers. In order to operate in a safe manner, we continue to follow the health and safety guidelines of the U.S. Centers for Disease Control and Prevention and local and state public health departments in each of the regions where we operate. Our manufacturing and distribution facilities have remained open due to our qualification as an essential business and to date, we have not experienced disruptions in our manufacturing activities. The vast majority of our non-manufacturing and non-customer facing personnel continue to work from home. In addition, to minimize the need for on-site visits, we are providing remote service and installation options, training programs, and product demonstrations for our customers, leveraging technology to enable our sales team to operate in a remote sales environment. Although we have not experienced disruptions in our supply chain to date, we cannot predict how long the pandemic and measures intended to contain the spread of COVID-19 will continue.

[0000926326-20-000034:mdna:47]
As a result of the pandemic, health systems have faced increased costs, decreased revenues and cash flow challenges due to cancelled or postponed elective procedures and other reduced demand. We believe these financial pressures led our customers to delay or defer purchasing decisions and/or implementation of our solutions during the first half of 2020, which resulted in delayed implementations and lower product bookings compared to management’s expectations prior to the COVID-19 outbreak. In the third quarter of 2020, we began to see our customers returning to more normal business operations, with increases in elective surgeries and hospital admissions as well as spending returning to pre-pandemic purchasing patterns consistent with long-term strategic investments. This enabled us to resume implementations that were delayed in the first half of the year, providing more visibility into product bookings for the fourth quarter of 2020. As a result, we now expect product bookings for 2020 to return to levels consistent with management’s expectations prior to the pandemic.

[0000926326-20-000034:mdna:48]
In response to the COVID-19 pandemic, we have implemented and continue to focus on cost reduction initiatives in all aspects of our business and remain mindful of the uncertainty related to the pandemic.

[0000926326-20-000034:mdna:49]
While our fiscal year 2020 results will be impacted by the challenges and opportunities brought on by the COVID-19 pandemic, we remain confident in the overall health of our business, in our ability to navigate through these unusual times, and in our ability to continue to execute on our long-term strategy, as we believe our customers and potential customers are increasingly embracing the vision of a fully autonomous pharmacy. However, the full impact of the COVID-19 pandemic and related containment measures cannot be predicted and to date, the COVID-19 pandemic and related containment measures have adversely affected and may continue to adversely affect, perhaps materially, our business, results of operations, financial condition, and liquidity.

[0000926326-20-000034:mdna:50]
Acquisitions

[0000926326-20-000034:mdna:51]
On October 1, 2020, we completed the acquisition of the 340B Link business (the “340B Link Business”) of Pharmaceutical Strategies Group, LLC pursuant to the terms and conditions of the Equity Purchase Agreement, dated August 11, 2020, as amended, by and among the Company, PSGH, LLC, BW Apothecary Holdings, LLC, the sellers identified therein and the seller’s representative (the “Purchase Agreement”). The purchase price was $225.0 million, subject to certain adjustments as provided for in the Purchase Agreement. The acquisition adds to our portfolio a comprehensive and differentiated suite of software-enabled services and solutions used by certain eligible hospitals, health systems, clinics, and entities to manage compliance and capture 340B drug cost savings on outpatient prescriptions filled through the eligible entity’s pharmacy or a contracted pharmacy partner. We will record the purchase of the 340B Link Business using the business combination method of accounting and will recognize the assets acquired and liabilities assumed at their fair values as of the date of the acquisition. The results of the operations of the 340B Link business will be included in our consolidated results of operations beginning October 1, 2020. We are currently evaluating the fair values of the consideration transferred, assets acquired and liabilities assumed and will commence our purchase price allocation in the fourth quarter of 2020.

[0000926326-20-000034:mdna:52]
[same as prior period, unchanged from 0000926326-20-000023:mdna:53]

[0000926326-20-000034:mdna:53]
[same as prior period, unchanged from 0000926326-20-000023:mdna:54]

[0000926326-20-000034:mdna:54]
[same as prior period, unchanged from 0000926326-20-000023:mdna:55]

[0000926326-20-000034:mdna:55]
[same as prior period, unchanged from 0000926326-20-000023:mdna:56]

[0000926326-20-000034:mdna:56]
[same as prior period, unchanged from 0000926326-20-000023:mdna:57]

[0000926326-20-000034:mdna:57]
[same as prior period, unchanged from 0000926326-20-000023:mdna:58]

[0000926326-20-000034:mdna:58]
[same as prior period, unchanged from 0000926326-20-000023:mdna:59]

[0000926326-20-000034:mdna:59]
[same as prior period, unchanged from 0000926326-20-000023:mdna:60]

[0000926326-20-000034:mdna:60]
[same as prior period, unchanged from 0000926326-20-000023:mdna:61]

[0000926326-20-000034:mdna:61]
•Convertible senior notes;

[0000926326-20-000034:mdna:62]
[same as prior period, unchanged from 0000926326-20-000023:mdna:62]

[0000926326-20-000034:mdna:63]
[same as prior period, unchanged from 0000926326-20-000023:mdna:63]

[0000926326-20-000034:mdna:64]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the nine months ended September 30, 2020 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2019, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements and the issuance of the convertible senior notes as discussed in Note 9, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-20-000034:mdna:65]
[same as prior period, unchanged from 0000926326-20-000023:mdna:65]

[0000926326-20-000034:mdna:66]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-20-000034:mdna:67]
[same as prior period, unchanged from 0000926326-20-000023:mdna:67]

[0000926326-20-000034:mdna:68]
[same as prior period, unchanged from 0000926326-20-000023:mdna:68]

[0000926326-20-000034:mdna:69]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 151,337 |  |  | $ | 168,488 |  |  | $ | (17,151) |  |  | (10)% |
| Percentage of total revenues | 71% |  | 74% |  |  |  |  |
| Services and other revenues | 62,362 |  |  | 60,317 |  |  | 2,045 |  |  | 3% |
| Percentage of total revenues | 29% |  | 26% |  |  |  |  |
| Total revenues | $ | 213,699 |  |  | $ | 228,805 |  |  | $ | (15,106) |  |  | (7)% |

[0000926326-20-000034:mdna:70]
Product revenues represented 71% and 74% of total revenues for the three months ended September 30, 2020 and 2019, respectively. Product revenues decreased by $17.2 million, primarily due to the impact of the COVID-19 pandemic as health systems have continued to focus resources on COVID-19 essential activities during the third quarter of 2020.

[0000926326-20-000034:mdna:71]
Services and other revenues represented 29% and 26% of total revenues for the three months ended September 30, 2020 and 2019, respectively. Services and other revenues include revenues from service and maintenance contracts, and rentals of automation systems. Services and other revenues increased by $2.0 million, primarily due to an increase in our installed customer base.

[0000926326-20-000034:mdna:72]
Our international sales represented 9% and 10% of total revenues for the three months ended September 30, 2020 and 2019, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-20-000034:mdna:73]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 460,352 |  |  | $ | 472,477 |  |  | $ | (12,125) |  |  | (3)% |
| Percentage of total revenues | 72% |  | 73% |  |  |  |  |
| Services and other revenues | 182,654 |  |  | 176,258 |  |  | 6,396 |  |  | 4% |
| Percentage of total revenues | 28% |  | 27% |  |  |  |  |
| Total revenues | $ | 643,006 |  |  | $ | 648,735 |  |  | $ | (5,729) |  |  | (1)% |

[0000926326-20-000034:mdna:74]
Product revenues represented 72% and 73% of total revenues for the nine months ended September 30, 2020 and 2019, respectively. Product revenues decreased by $12.1 million, primarily due to the impact of the COVID-19 pandemic as health systems have been focusing resources on COVID-19 essential activities during the second and third quarters of 2020.

[0000926326-20-000034:mdna:75]
Services and other revenues represented 28% and 27% of total revenues for the nine months ended September 30, 2020 and 2019, respectively. Services and other revenues include revenues from service and maintenance contracts, and rentals of automation systems. Services and other revenues increased by $6.4 million, primarily due to an increase in our installed customer base.

[0000926326-20-000034:mdna:76]
Our international sales represented 10% of total revenues for both the nine months ended September 30, 2020 and 2019, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-20-000034:mdna:77]
[same as prior period, unchanged from 0000926326-20-000023:mdna:77]

[0000926326-20-000034:mdna:78]
The effects of the COVID-19 pandemic have had an adverse impact on our revenues for the three and nine months ended September 30, 2020. During the first half of 2020, we experienced delays in implementations and lower product bookings compared to management’s expectations prior to the COVID-19 outbreak. In the third quarter of 2020, we began to

[0000926326-20-000034:mdna:79]
see our customers returning to more normal business operations, with increases in elective surgeries and hospital admissions as well as spending returning to pre-pandemic purchasing patterns consistent with long-term strategic investments. This enabled us to resume implementations that were delayed in the first half of the year, providing more visibility into product bookings for the fourth quarter of 2020 and fiscal year 2021. As a result, we now expect product bookings for 2020 to return to levels consistent with management’s expectations prior to the pandemic. Based on management's current expectations, we believe revenues will increase sequentially through the fourth quarter of 2020. Future developments with respect to the COVID-19 pandemic remain uncertain and may impact future periods.

[0000926326-20-000034:mdna:80]
[same as prior period, unchanged from 0000926326-20-000023:mdna:79]

[0000926326-20-000034:mdna:81]
[same as prior period, unchanged from 0000926326-20-000023:mdna:80]

[0000926326-20-000034:mdna:82]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 86,689 |  |  | $ | 86,695 |  |  | $ | (6) |  |  | —% |
| As a percentage of related revenues | 57% |  | 51% |  |  |  |  |
| Cost of services and other revenues | 30,219 |  |  | 29,963 |  |  | 256 |  |  | 1% |
| As a percentage of related revenues | 48% |  | 50% |  |  |  |  |
| Total cost of revenues | $ | 116,908 |  |  | $ | 116,658 |  |  | $ | 250 |  |  | —% |
| As a percentage of total revenues | 55% |  | 51% |  |  |  |  |
| Gross profit | $ | 96,791 |  |  | $ | 112,147 |  |  | $ | (15,356) |  |  | (14)% |
| Gross margin | 45% |  | 49% |  |  |  |  |

[0000926326-20-000034:mdna:83]
Cost of revenues for the three months ended September 30, 2020 compared to the three months ended September 30, 2019 increased by $0.3 million, primarily due to the increase in cost of services and other revenues of $0.3 million while the cost of product revenues remained consistent. The cost of product revenues is reflective of investments made to drive the customer experience and support expected annual revenue levels which were impacted by the COVID-19 pandemic. The cost of product revenues remained consistent while product revenues decreased by $17.2 million for the three months ended September 30, 2020 compared to the three months ended September 30, 2019 primarily due to certain fixed costs, such as labor and overhead, which have not decreased proportionally with the decrease in product revenues for the three months ended September 30, 2020, partially offset by cost-saving initiatives. The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $2.0 million for the three months ended September 30, 2020 compared to the three months ended September 30, 2019, as well as a change in the mix of services with higher margins.

[0000926326-20-000034:mdna:84]
The overall decrease in gross margin primarily relates to lower revenues due to the impact of the COVID-19 pandemic, partially offset by lower costs associated with cost-saving initiatives. Our gross profit for the three months ended September 30, 2020 was $96.8 million, as compared to $112.1 million for the three months ended September 30, 2019.

[0000926326-20-000034:mdna:85]
36

[0000926326-20-000034:mdna:86]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 262,740 |  |  | $ | 250,089 |  |  | $ | 12,651 |  |  | 5% |
| As a percentage of related revenues | 57% |  | 53% |  |  |  |  |
| Cost of services and other revenues | 90,628 |  |  | 85,337 |  |  | 5,291 |  |  | 6% |
| As a percentage of related revenues | 50% |  | 48% |  |  |  |  |
| Total cost of revenues | $ | 353,368 |  |  | $ | 335,426 |  |  | $ | 17,942 |  |  | 5% |
| As a percentage of total revenues | 55% |  | 52% |  |  |  |  |
| Gross profit | $ | 289,638 |  |  | $ | 313,309 |  |  | $ | (23,671) |  |  | (8)% |
| Gross margin | 45% |  | 48% |  |  |  |  |

[0000926326-20-000034:mdna:87]
Cost of revenues for the nine months ended September 30, 2020 compared to the nine months ended September 30, 2019 increased by $17.9 million, of which $12.7 million was attributed to the increase in cost of product revenues and $5.3 million was attributed to the increase in cost of services and other revenues. The increase in cost of product revenues is reflective of investments made to drive the customer experience and support expected annual revenue levels which were impacted by the COVID-19 pandemic. While product revenues decreased by $12.1 million for the nine months ended September 30, 2020, cost of product revenues increased by $12.7 million primarily driven by certain fixed costs, such as labor and overhead. The increase in cost of product revenues was also driven by an increase in employee-related expenses related to restructuring initiatives, partially offset by cost-saving initiatives. The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $6.4 million for the nine months ended September 30, 2020 compared to the nine months ended September 30, 2019, as well as additional investments in our service business to support new product offerings.

[0000926326-20-000034:mdna:88]
The overall decrease in gross margin primarily relates to lower revenues during the nine months ended September 30, 2020 due to the impact of the COVID-19 pandemic, employee-related expenses related to restructuring initiatives, and additional investments in our service business, partially offset by lower costs associated with cost-saving initiatives. Our gross profit for the nine months ended September 30, 2020 was $289.6 million, as compared to $313.3 million for the nine months ended September 30, 2019.

[0000926326-20-000034:mdna:89]
The effects of the COVID-19 pandemic have had an adverse impact on our cost of revenues and gross margins for the three and nine months ended September 30, 2020. We continue to expect to incur additional costs related to the COVID-19 pandemic including, but not limited to, the purchase of personal protective equipment for our customer-facing and manufacturing personnel. Future developments with respect to the COVID-19 pandemic remain uncertain and may impact future periods.

[0000926326-20-000034:mdna:90]
[same as prior period, unchanged from 0000926326-20-000023:mdna:89]

[0000926326-20-000034:mdna:91]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 15,197 |  |  | $ | 16,625 |  |  | $ | (1,428) |  |  | (9)% |
| As a percentage of total revenues | 7% |  | 7% |  |  |  |  |
| Selling, general, and administrative | 71,442 |  |  | 70,876 |  |  | 566 |  |  | 1% |
| As a percentage of total revenues | 33% |  | 31% |  |  |  |  |
| Total operating expenses | $ | 86,639 |  |  | $ | 87,501 |  |  | $ | (862) |  |  | (1)% |
| As a percentage of total revenues | 41% |  | 38% |  |  |  |  |
| Interest and other income (expense), net | $ | 809 |  |  | $ | (1,168) |  |  | $ | 1,977 |  |  | (169)% |

[0000926326-20-000034:mdna:92]
Research and Development. Research and development expenses decreased by $1.4 million for the three months ended September 30, 2020 compared to the three months ended September 30, 2019. The decrease was primarily attributed to a decrease of $1.4 million in consulting expenses and a decrease of $1.1 million in employee-related expenses, partially offset by various increases due to the timing of projects. The decrease in employee-related expenses is primarily due to the decrease in headcount as a result of the restructuring activity during the first and second quarters of 2020.

[0000926326-20-000034:mdna:93]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $0.6 million for the three months ended September 30, 2020 compared to the three months ended September 30, 2019. The increase was primarily due to an increase of $5.1 million in employee-related expenses primarily related to increased headcount and an increase of $3.1 million in acquisition-related expenses, partially offset by approximately $7.2 million of certain cost savings, including reduced travel costs, and lower commission and bonus expenses attributable to lower bookings in the first half of 2020 and lower revenues.

[0000926326-20-000034:mdna:94]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $2.0 million for the three months ended September 30, 2020 compared to the three months ended September 30, 2019, primarily driven by a $1.4 million decrease in other expenses and a $0.6 million increase in other income. The decrease in other expenses was primarily due to lower interest expense as a result of lower outstanding debt balance during the three months ended September 30, 2020 as compared to the three months ended September 30, 2019 as well as favorable foreign currency fluctuations during the period.

[0000926326-20-000034:mdna:95]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 54,679 |  |  | $ | 49,551 |  |  | $ | 5,128 |  |  | 10% |
| As a percentage of total revenues | 9% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 219,647 |  |  | 207,588 |  |  | 12,059 |  |  | 6% |
| As a percentage of total revenues | 34% |  | 32% |  |  |  |  |
| Total operating expenses | $ | 274,326 |  |  | $ | 257,139 |  |  | $ | 17,187 |  |  | 7% |
| As a percentage of total revenues | 43% |  | 40% |  |  |  |  |
| Interest and other income (expense), net | $ | 161 |  |  | $ | (4,207) |  |  | $ | 4,368 |  |  | (104)% |

[0000926326-20-000034:mdna:96]
Research and Development. Research and development expenses increased by $5.1 million for the nine months ended September 30, 2020 compared to the nine months ended September 30, 2019. The increase was primarily attributed to an increase of $3.7 million in employee-related expenses related to restructuring initiatives during the first and second quarters of 2020 as well as an increase of $0.7 million in other employee-related expenses in the research and development function. The increased spend is a result of our continued investments into automation, intelligence, and the cloud data platform.

[0000926326-20-000034:mdna:97]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $12.1 million for the nine months ended September 30, 2020 compared to the nine months ended September 30, 2019, primarily due to overall growth of operations and increase in overall headcount. The increase was primarily due to an increase of $18.0 million in employee-related expenses primarily related to increased headcount, an increase of $3.7 million in employee-related expenses related to restructuring initiatives, and an increase of $3.1 million in acquisition-related expenses, partially offset by approximately $14.2 million of certain cost savings, including reduced travel costs, and lower commission and bonus expenses attributable to lower bookings in the first half of 2020 and lower revenues.

[0000926326-20-000034:mdna:98]
In response to the COVID-19 pandemic, we have implemented and continue to focus on cost reduction initiatives in all aspects of our business and remain mindful of the uncertainty related to the pandemic.

[0000926326-20-000034:mdna:99]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $4.4 million for the nine months ended September 30, 2020 compared to the nine months ended September 30, 2019, primarily driven by a $3.3 million decrease in other expenses and a $1.1 million increase in other income. The decrease in other expenses was primarily due to lower interest expense as a result of lower outstanding debt balance during the nine months ended September 30, 2020 as compared to the nine months ended September 30, 2019 as well as favorable foreign currency fluctuations during the period. The increase in other income was primarily attributable to benefits from certain arrangements outside of our normal course of business.

[0000926326-20-000034:mdna:100]
[same as prior period, unchanged from 0000926326-20-000023:mdna:100]

[0000926326-20-000034:mdna:101]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 2,156 |  |  | $ | 3,495 |  |  | $ | (1,339) |  |  | (38)% |

[0000926326-20-000034:mdna:102]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (344) |  |  | $ | 12,720 |  |  | $ | (13,064) |  |  | (103)% |

[0000926326-20-000034:mdna:103]
Our annual effective tax rate before discrete items was 30.1% and 24.6% for the nine months ended September 30, 2020 and 2019, respectively. The increase in the estimated annual effective tax rate for the nine months ended September 30, 2020 compared to the same period in 2019 was primarily due an increase in non-deductible compensation and equity charges and a decrease in foreign derived intangible income (“FDII”) benefit, partially offset by an increase in research and development credits.

[0000926326-20-000034:mdna:104]
Provision for income taxes for the nine months ended September 30, 2020 included net discrete income tax benefit of $5.0 million, primarily due to a $4.2 million tax benefit from equity compensation.

[0000926326-20-000034:mdna:105]
Provision for income taxes for the nine months ended September 30, 2019 included net discrete income tax benefit of $0.1 million. The net discrete income tax benefit was primarily related to an $8.1 million tax benefit from equity compensation, offset by income tax expense of $9.6 million on the sale of certain intellectual property rights by Aesynt B.V. to Omnicell, Inc. in the first quarter of 2019. In March 2020, Aesynt B.V. subsequently merged with and into Aesynt Holding B.V., with Aesynt Holding B.V. surviving and changing its name to Omnicell B.V.

[0000926326-20-000034:mdna:106]
Refer to Note 13, Income Taxes, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report for more details.

[0000926326-20-000034:mdna:107]
[same as prior period, unchanged from 0000926326-20-000023:mdna:107]

[0000926326-20-000034:mdna:108]
We had cash and cash equivalents of $629.2 million at September 30, 2020 compared to $127.2 million at December 31, 2019. All of our cash and cash equivalents are invested in bank accounts with major financial institutions.

[0000926326-20-000034:mdna:109]
Our cash position and working capital at September 30, 2020 and December 31, 2019 were as follows:

[0000926326-20-000034:mdna:110]
|  | September 30,2020 |  | December 31,2019 |
|  | (In thousands) |
| Cash | $ | 629,171 |  |  | $ | 127,210 |  |
| Working Capital | $ | 729,528 |  |  | $ | 246,242 |  |

[0000926326-20-000034:mdna:111]
Our ratio of current assets to current liabilities was 4.1:1 and 2.0:1 at September 30, 2020 and December 31, 2019, respectively.

[0000926326-20-000034:mdna:112]
[same as prior period, unchanged from 0000926326-20-000023:mdna:112]

[0000926326-20-000034:mdna:113]
Credit Facilities

[0000926326-20-000034:mdna:114]
On January 5, 2016, we entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association, as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for a $200.0 million term loan facility (the “Prior Term Loan Facility”), and prior to the amendment discussed below, a $200.0 million revolving credit facility (the “Prior Revolving Credit Facility” and together with the Prior Term Loan Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million.

[0000926326-20-000034:mdna:115]
On April 11, 2017 and December 26, 2017, we entered into amendments to the Prior Credit Agreement. Under these amendments, the Prior Revolving Credit Facility was increased from $200.0 million to $315.0 million and certain other modifications were made.

[0000926326-20-000034:mdna:116]
On November 15, 2019, we refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (as subsequently amended, as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. On November 15, 2019, the $80.0 million outstanding term loan balance under the Prior Facilities was transferred to the Current Revolving Credit Facility.

[0000926326-20-000034:mdna:117]
On September 22, 2020, the parties entered into an amendment (the “Amendment”) to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions described below, expand our flexibility to repurchase our common stock and make other restricted payments and replace the total net leverage covenant with a new secured net leverage covenant that requires us to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020 and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

[0000926326-20-000034:mdna:118]
As of September 30, 2020, there was no outstanding balance for the Current Revolving Credit Facility and we were in full compliance with all covenants. Refer to Note 8, Debt and Credit Agreements, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-20-000034:mdna:119]
Convertible Senior Notes

[0000926326-20-000034:mdna:120]
On September 25, 2020, we completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. We received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased or converted. Refer to Note 9, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-20-000034:mdna:121]
We used approximately $49.3 million of the net proceeds from the offering to pay the cost of the convertible note hedge transactions (partially offset by proceeds to the Company from the sale of the warrant transactions), approximately $53.0 million of the net proceeds to repurchase shares of our common stock from purchasers of the Notes, and $150.0 million of the net proceeds to pay down outstanding borrowings under the Current Revolving Credit Facility. We intend to use the remainder of the net proceeds from this offering for working capital and other general corporate purposes, which may include potential acquisitions, strategic transactions, and potential future repurchases of our common stock.

[0000926326-20-000034:mdna:122]
[same as prior period, unchanged from 0000926326-20-000023:mdna:118]

[0000926326-20-000034:mdna:123]
[same as prior period, unchanged from 0000926326-20-000023:mdna:119]

[0000926326-20-000034:mdna:124]
For the three and nine months ended September 30, 2020 and the three months ended September 30, 2019, we did not sell any of our common stock under the Distribution Agreement.

[0000926326-20-000034:mdna:125]
For the nine months ended September 30, 2019, we received gross proceeds of $38.5 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 460,000 shares of our common stock at an average price of approximately $83.81 per share.

[0000926326-20-000034:mdna:126]
As of September 30, 2020, we had an aggregate of $31.5 million available to be offered under the Distribution Agreement. The registration statement under which the shares that may be sold pursuant to the Distribution Agreement are registered will expire on November 3, 2020.

[0000926326-20-000034:mdna:127]
[same as prior period, unchanged from 0000926326-20-000023:mdna:124]

[0000926326-20-000034:mdna:128]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, and other contractual obligations. We also expect a continued use of cash for potential acquisitions and acquisition-related activities, as well as repurchases of our common stock.

[0000926326-20-000034:mdna:129]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of September 30, 2020, which may result in additional use of cash. Refer to “Stock Repurchase Program” under Note 14, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. In September 2020, we repurchased 749,300 shares of our common stock from purchasers of the Notes in the offering in privately negotiated transactions effected through one of the initial purchasers or its affiliate at an average price of $70.78 per share for an aggregate purchase price of approximately $53.0 million. The repurchases were made concurrently with the issuance of the Notes. The repurchases were separately authorized by the Board of Directors, and did not impact the total remaining for future purchases under the previously authorized stock purchase programs. There were no stock repurchases during the three and nine months ended September 30, 2020 and 2019 including under our stock repurchase programs, other than the separately-authorized one-time stock repurchase concurrent with the offering of the Notes in September 2020.

[0000926326-20-000034:mdna:130]
Based on our current business plan and revenue backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-20-000034:mdna:131]
We believe that our current financial position and resources will allow us to manage the anticipated impact of the COVID-19 pandemic on our business for the foreseeable future, including any potential changes in timing of revenue recognition or potential extensions in customer payments. However, COVID-19 and related measures to contain its impact have caused material disruptions in both national and global financial markets and economies. The future impact of COVID-19 and these containment measures cannot be predicted with certainty and may increase our borrowing costs and other costs of capital and otherwise adversely affect our business, results of operations, financial condition, and liquidity, and we cannot assure that we will have access to external financing at times and on terms we consider acceptable, or at all, or that we will not experience other liquidity issues going forward.

[0000926326-20-000034:mdna:132]
[same as prior period, unchanged from 0000926326-20-000023:mdna:130]

[0000926326-20-000034:mdna:133]
[same as prior period, unchanged from 0000926326-20-000023:mdna:131]

[0000926326-20-000034:mdna:134]
|  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 109,422 |  |  | $ | 110,188 |  |
| Investing activities | (43,174) |  |  | (46,761) |  |
| Financing activities | 435,870 |  |  | 7,045 |  |
| Effect of exchange rate changes on cash and cash equivalents | (157) |  |  | (387) |  |
| Net increase in cash and cash equivalents | $ | 501,961 |  |  | $ | 70,085 |  |

[0000926326-20-000034:mdna:135]
[same as prior period, unchanged from 0000926326-20-000023:mdna:133]

[0000926326-20-000034:mdna:136]
[same as prior period, unchanged from 0000926326-20-000023:mdna:134]

[0000926326-20-000034:mdna:137]
Net cash provided by operating activities was $109.4 million for the nine months ended September 30, 2020, primarily consisting of net income of $15.8 million adjusted for non-cash items of $82.0 million and changes in assets and liabilities of

[0000926326-20-000034:mdna:138]
$11.6 million. The non-cash items primarily consisted of depreciation and amortization expense of $43.9 million, share-based compensation expense of $33.0 million, amortization of operating lease right-of-use assets of $7.7 million, amortization of debt issuance costs of $0.8 million, amortization of discount on convertible senior notes of $0.2 million, and a change in deferred income taxes of $3.6 million. Changes in assets and liabilities include cash inflows from (i) a decrease in accounts receivable and unbilled receivables of $29.7 million primarily due to timing of collections and a decrease in billings due to timing of shipments, (ii) an increase in deferred revenues of $8.8 million primarily due to the timing of shipments in order to meet customers’ implementation schedules and recognition of revenues for product requiring installation, (iii) an increase in other long-term liabilities of $8.1 million primarily due to the deferral of certain payroll taxes due to the CARES Act, (iv) a decrease in inventories of $4.6 million primarily due to timing of shipments and a focus on supply chain efficiencies, (v) an increase in accrued liabilities of $3.3 million, and (vi) a decrease in prepaid commissions of $2.2 million. These cash inflows were partially offset by (i) a decrease in accounts payable of $8.7 million primarily due to an overall decrease in spending, as well as timing of payments, (ii) a decrease in accrued compensation of $8.4 million primarily due to timing of employee stock plan purchases, as well as a decrease in accrued commissions, (iii) a decrease in operating lease liabilities of $7.8 million, (iv) an increase in other current assets of $6.6 million, (v) an increase in prepaid expenses of $6.3 million, (vi) an increase in other long-term assets of $4.0 million, and (vii) an increase in investment in sales-type leases of $3.3 million.

[0000926326-20-000034:mdna:139]
Net cash provided by operating activities was $110.2 million for the nine months ended September 30, 2019, primarily consisting of net income of $39.2 million adjusted for non-cash items of $78.8 million, offset by changes in assets and liabilities of $7.8 million. The non-cash items primarily consisted of depreciation and amortization expense of $39.5 million, share-based compensation expense of $25.2 million, amortization of operating lease right-of-use assets of $7.9 million, amortization of debt issuance costs of $1.7 million, and a change in deferred income taxes of $4.0 million. Changes in assets and liabilities include cash outflows from (i) a decrease in accrued compensation of $8.2 million primarily due to a decrease in accrued commissions and restructuring expenses, as well as timing of payroll, (ii) a decrease in operating lease liabilities of $7.9 million, (iii) an increase in accounts receivable and unbilled receivables of $7.7 million primarily due to an increase in billings, (iv) an increase in inventories of $7.0 million for inventory buildup in support of forecasted sales of new and existing products, (v) an increase in investment in sales-type leases of $5.1 million, and (vi) an increase in prepaid expenses of $1.3 million. These cash outflows were partially offset by (i) an increase in accounts payable of $10.3 million, (ii) an increase in accrued liabilities of $5.3 million, (iii) an increase in other long-term liabilities of $4.1 million, (iv) a decrease in other long-term assets of $3.9 million, (v) an increase in deferred revenues of $3.9 million, (vi) a decrease in other current assets of $1.0 million, and (vii) a decrease in prepaid commissions of $0.9 million.

[0000926326-20-000034:mdna:140]
[same as prior period, unchanged from 0000926326-20-000023:mdna:137]

[0000926326-20-000034:mdna:141]
Net cash used in investing activities was $43.2 million for the nine months ended September 30, 2020, which consisted of capital expenditures of $17.3 million for property and equipment, and $25.9 million for costs of software development for external use.

[0000926326-20-000034:mdna:142]
Net cash used in investing activities was $46.8 million for the nine months ended September 30, 2019, which consisted of capital expenditures of $12.6 million for property and equipment, and $34.1 million for costs of software development for external use.

[0000926326-20-000034:mdna:143]
[same as prior period, unchanged from 0000926326-20-000023:mdna:140]

[0000926326-20-000034:mdna:144]
Net cash provided by financing activities was $435.9 million for the nine months ended September 30, 2020, primarily due to proceeds of $559.7 million from the issuance of the Notes net of issuance costs, proceeds of approximately $51.3 million from the sale of warrants in connection with the issuance of the Notes, $150.0 million of proceeds under the Current Revolving Credit Facility, $33.2 million in proceeds from employee stock option exercises and employee stock plan purchases, partially offset by repayments of $200.0 million of the Current Revolving Credit Facility, approximately $100.6 million for the purchase of the convertible note hedge in connection with the issuance of the Notes, $53.0 million for repurchases of our stock, $4.1 million in employees’ taxes paid related to restricted stock unit vesting, and payments for debt issuance costs related to the Current Revolving Credit Facility of $0.6 million.

[0000926326-20-000034:mdna:145]
Net cash provided by financing activities was $7.0 million for the nine months ended September 30, 2019, primarily due to proceeds of $37.8 million from sales of our common stock under the Distribution Agreement and $35.0 million in proceeds from employee stock option exercises and employee stock plan purchases, partially offset by the repayment of $60.0 million of the Prior Facilities and $5.8 million in employees’ taxes paid related to restricted stock unit vesting.

[0000926326-20-000034:mdna:146]
[same as prior period, unchanged from 0000926326-20-000023:mdna:143]

[0000926326-20-000034:mdna:147]
With the exception of the issuance of the convertible senior notes in September 2020, there have been no significant changes during the nine months ended September 30, 2020 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2019.

[0000926326-20-000034:mdna:148]
Contractual obligations as of September 30, 2020 were as follows:

[0000926326-20-000034:mdna:149]
|  | Payments due by period |
|  | Total |  | Remainder of 2020 |  | 2021 - 2022 |  | 2023 - 2024 |  | 2025 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 66,651 |  |  | $ | 3,488 |  |  | $ | 26,053 |  |  | $ | 16,904 |  |  | $ | 20,206 |  |
| Purchase obligations (2) | 66,397 |  |  | 49,283 |  |  | 14,851 |  |  | 2,110 |  |  | 153 |  |
| Convertible senior notes (3) | 582,148 |  |  | — |  |  | 2,835 |  |  | 2,875 |  |  | 576,438 |  |
| Total (4) | $ | 715,196 |  |  | $ | 52,771 |  |  | $ | 43,739 |  |  | $ | 21,889 |  |  | $ | 596,797 |  |

[0000926326-20-000034:mdna:150]
[same as prior period, unchanged from 0000926326-20-000023:mdna:147]

[0000926326-20-000034:mdna:151]
(1)Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 11, Lessee Leases, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-20-000034:mdna:152]
[same as prior period, unchanged from 0000926326-20-000023:mdna:149]

[0000926326-20-000034:mdna:153]
(3)We issued convertible senior notes in September 2020 that are due in September 2025. The obligations presented above include both principal and interest for these notes. Although these notes mature in 2025, they may be converted into cash and shares of our common stock prior to maturity if certain conditions are met. Any conversion prior to maturity can result in repayment of the principal amounts sooner than the scheduled repayment as indicated in the table above. Refer to Note 9, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-20-000034:mdna:154]
(4)Refer to Note 12, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-20-000034:mdna:155]
[same as prior period, unchanged from 0000926326-20-000023:mdna:151]

[0000926326-20-000034:mdna:156]
As of September 30, 2020, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Exchange Act and the instructions thereto.
