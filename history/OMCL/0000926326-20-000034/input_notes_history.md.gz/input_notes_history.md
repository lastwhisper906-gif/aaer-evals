# OMCL note change history — 0000926326-20-000023 → 0000926326-20-000034


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-10-30):
[0000926326-20-000034:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2020, the Company had non-cancelable purchase commitments of $66.4 million, of which $49.3 million are expected to be paid within the year ending December 31, 2020.
  (was, 2020-07-31, similarity 0.9765):
[0000926326-20-000023:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2020, the Company had non-cancelable purchase commitments of $66.3 million, of which $64.7 million are expected to be paid within the year ending December 31, 2020.

- changed (2020-10-30):
[0000926326-20-000034:note_history:2]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.
  (was, 2020-07-31, similarity 0.8682):
[0000926326-20-000023:note_history:2]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows

- changed (2020-10-30):
[0000926326-20-000034:note_history:3]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its former subsidiaries, Aesynt Incorporated (“Aesynt”), which, through a series of mergers, has been merged into the Company, in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint sought monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, retention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice. On August 21, 2019, a new lawsuit was filed against the Company and Aesynt, in the Circuit Court for the County of Albemarle, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Aesynt Incorporated, et al., Case No CL19-1301. The complaint sought monetary recovery of damages based upon claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. On August 25, 2020, the Company and Aesynt filed a motion to dismiss for failure of the plaintiff to serve the complaint within one year of its filing date. On September 30, 2020, the Court dismissed the complaint with prejudice.
  (was, 2020-07-31, similarity 0.915):
[0000926326-20-000023:note_history:3]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its former subsidiaries, Aesynt Incorporated (“Aesynt”), which, through a series of mergers, has been merged into the Company, in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint sought monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice. On August 21, 2019, a new lawsuit was filed against the Company and Aesynt, in the Circuit Court for the County of Albemarle, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Aesynt Incorporated, et al., Case No CL19-1301. The complaint seeks monetary recovery of damages based upon claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not been served with the complaint. The Company intends to defend the lawsuit vigorously.

- added (2020-10-30):
[0000926326-20-000034:note_history:4]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the complaint on October 28, 2020. A status conference is currently set for November 5, 2020. The Company intends to defend the lawsuit vigorously.

- removed (2020-10-30):
[0000926326-20-000023:note_history:5]
or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

- removed (2020-10-30):
[0000926326-20-000023:note_history:6]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (a class action lawsuit filed against a customer of the Company, the customer’s parent company, and two vendors of medication dispensing systems, one of which is the Company, seeking statutory damages and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of the Illinois Biometric Information Privacy Act (“BIPA”) and of negligence by the defendants from which the Company was subsequently dismissed without prejudice) (“Mazya Action”), together with claims for reimbursement and unjust enrichment relating to the defense of the Mazya Action in the form of attorneys’ fees and other related costs. The Company has not responded to the complaint. On February 12, 2019, the Court stayed the action pending the outcome of the Mazya Action and administratively closed the case. On October 15, 2019, the plaintiffs filed a notice advising the Court of the dismissal of the Company from the Mazya Action and requesting that the Court lift the stay in the case and set dates for filing a responsive pleading by the Company and initial discovery and scheduling matters. By order dated November 13, 2019, the Court (i) lifted the stay in the case, (ii) set a case management conference for February 5, 2020, and (iii) ordered the parties to file a joint case management statement by January 29, 2020. The parties subsequently reached a settlement of the case in principle and the Court, after notice of the parties, continued the case management conference until April 29, 2020. The parties entered into a written settlement agreement on April 9, 2020. Since the conditions precedent in the settlement agreement to dismissing the case had not yet been fulfilled, the Court, upon the petition of the parties, again continued the case management conference until May 27, 2020. Upon fulfillment of the conditions precedent to finalizing the settlement, the plaintiffs filed a notice of dismissal with prejudice on May 4, 2020, thereby finally terminating the action.

- removed (2020-10-30):
[0000926326-20-000023:note_history:7]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of BIPA, and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the Mazya Action. The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The motion to dismiss is fully-briefed. The hearing on the Company’s motion to dismiss was previously set for March 16, 2020, was continued to May 27, 2020, and then was subsequently continued again to September 2, 2020. The Company intends to defend the lawsuit vigorously.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-10-30):
[0000926326-20-000034:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2020 and December 31, 2019, the results of operations and comprehensive income for the three and nine months ended September 30, 2020 and 2019, and cash flows for the nine months ended September 30, 2020 and 2019. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2019 filed with the SEC on February 26, 2020, except as discussed in the sections entitled “Allowance for Credit Losses” and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2020 and cash flows for the nine months ended September 30, 2020 are not necessarily indicative of results that may be expected for the year ending December 31, 2020, or for any future period.
  (was, 2020-07-31, similarity 0.8097):
[0000926326-20-000023:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2020 and December 31, 2019, the results of operations and comprehensive income (loss) for the three and six months ended June 30, 2020 and 2019, and cash flows for the six months ended June 30, 2020 and 2019. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2019 filed with the SEC on February 26, 2020, except as discussed in the sections entitled “Allowance for Credit Losses” and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income (loss) for the three and six months ended June 30, 2020 and cash flows for the six months ended June 30, 2020 are not necessarily indicative of results that may be expected for the year ending December 31, 2020, or for any future period.

- changed (2020-10-30):
[0000926326-20-000034:note_history:9]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of product revenues for the three and nine months ended September 30, 2019 in Note 2, Revenues. This change was not deemed material and was included to conform with current-period classification and presentation.
  (was, 2020-07-31, similarity 0.871):
[0000926326-20-000023:note_history:9]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of product revenues for the three and six months ended June 30, 2019 in Note 2, Revenues, of the Notes to Condensed Consolidated Financial Statements. This change was not deemed material and was included to conform with current-period classification and presentation.

- changed (2020-10-30):
[0000926326-20-000034:note_history:10]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. As of September 30, 2020, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities. Given the ongoing uncertainty surrounding the COVID-19 pandemic, events or circumstances may arise that could result in a change in estimates, judgments, or revisions to the carrying value of the Company’s assets or liabilities.
  (was, 2020-07-31, similarity 0.9891):
[0000926326-20-000023:note_history:10]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. As of June 30, 2020, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities. Given the ongoing uncertainty surrounding the COVID-19 pandemic, events or circumstances may arise that could result in a change in estimates, judgments, or revisions to the carrying value of the Company’s assets or liabilities.

- changed (2020-10-30):
[0000926326-20-000034:note_history:11]
|  | September 30,2020 |  | December 31,2019 |
|  | (In thousands) |
| Allowance for credit losses: |  |  |  |
| Accounts receivable and unbilled receivables | $ | 3,839 |  |  | $ | 3,227 |  |
| Long-term unbilled receivables (1) | 30 |  |  | — |  |
| Net investment in sales-type leases (2) | 269 |  |  | 225 |  |
  (was, 2020-07-31, similarity 0.9324):
[0000926326-20-000023:note_history:11]
|  | June 30,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Allowance for credit losses: |  |  |  |
| Accounts receivable and unbilled receivables | $ | 3,204 |  |  | $ | 3,227 |  |
| Long-term unbilled receivables (1) | 33 |  |  | — |  |
| Net investment in sales-type leases (2) | 248 |  |  | 225 |  |

- changed (2020-10-30):
[0000926326-20-000034:note_history:12]
Changes in the allowances were not significant for the three and nine months ended September 30, 2020 and 2019.
  (was, 2020-07-31, similarity 0.8426):
[0000926326-20-000023:note_history:12]
Changes in the allowances for credit losses were not significant for the three and six months ended June 30, 2020 and 2019.

- added (2020-10-30):
[0000926326-20-000034:note_history:13]
In August 2020, the FASB issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves

- added (2020-10-30):
[0000926326-20-000034:note_history:14]
disclosures for convertible instruments and earnings per share guidance. This update permits the use of either the modified retrospective or fully retrospective method of transition. ASU 2020-06 will be effective for the Company beginning January 1, 2022. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. The Company is currently evaluating the impact ASU 2020-06 will have on its Condensed Consolidated Financial Statements.

- changed (2020-10-30):
[0000926326-20-000034:note_history:15]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.
  (was, 2020-07-31, similarity 0.985):
[0000926326-20-000023:note_history:15]
There was no recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.


## omcl:ScheduleOfDebtIssuanceCostsNetTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-30):
[0000926326-20-000034:note_history:16]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | 550 |  |
| Amortization | (723) |  |
| Balance as of September 30, 2020 | $ | 4,527 |  |
  (was, 2020-07-31, similarity 0.9553):
[0000926326-20-000023:note_history:16]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | — |  |
| Amortization | (482) |  |
| Balance as of June 30, 2020 | $ | 4,218 |  |


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-10-30):
[0000926326-20-000034:note_history:17]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2020:

- added (2020-10-30):
[0000926326-20-000034:note_history:18]
|  | Three and Nine Months EndedSeptember 30, 2020 |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 20 |  |  |  |  |  |  |  |
| Amortization of discount | $ | 249 |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 31 |  |  |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-10-30):
[0000926326-20-000034:note_history:19]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2020:

- added (2020-10-30):
[0000926326-20-000034:note_history:20]
|  | September 30,2020 |
|  | (In thousands) |
| Liability: |  |
| Principal amount | $ | 575,000 |  |
| Unamortized discount | (100,261) |  |
| Unamortized debt issuance costs | (12,624) |  |
| Convertible senior notes, liability component | $ | 462,115 |  |
| Equity: |  |
| Embedded conversion option | $ | 100,510 |  |
| Debt issuance costs | (2,680) |  |
| Deferred tax impact | (25,098) |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |

- added (2020-10-30):
[0000926326-20-000034:note_history:21]
_________________________________________________
(1)    Included in additional paid-in capital in the Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-30):
[0000926326-20-000034:note_history:22]
On November 15, 2019, the Company refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.
  (was, 2020-07-31, similarity 0.9772):
[0000926326-20-000023:note_history:22]
On November 15, 2019, the Company refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

- added (2020-10-30):
[0000926326-20-000034:note_history:23]
On September 22, 2020, the parties entered into an amendment (the “Amendment”) to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions as described in Note 9, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020 and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

- added (2020-10-30):
[0000926326-20-000034:note_history:24]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of September 30, 2020.

- added (2020-10-30):
[0000926326-20-000034:note_history:25]
In connection with the A&R Credit Agreement on November 15, 2019, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. In connection with the Amendment on September 22, 2020, the Company incurred and capitalized an additional $0.6 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs for credit agreements was approximately $0.2 million and $0.6 million for the three months ended September 30, 2020 and 2019, respectively, and approximately $0.7 million and $1.7 million for the nine months ended September 30, 2020 and 2019, respectively.

- added (2020-10-30):
[0000926326-20-000034:note_history:26]
Interest expense (exclusive of fees and debt issuance cost amortization) was approximately $0.3 million and $0.8 million for the three months ended September 30, 2020 and 2019, and approximately $0.5 million and $3.0 million for the nine months ended September 30, 2020 and 2019, respectively.

- changed (2020-10-30):
[0000926326-20-000034:note_history:27]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | 150,000 |  |
| Repayments | (200,000) |  |
| Balance as of September 30, 2020 | $ | — |  |
  (was, 2020-07-31, similarity 0.9644):
[0000926326-20-000023:note_history:27]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | — |  |
| Repayments | (50,000) |  |
| Balance as of June 30, 2020 | $ | — |  |

- changed (2020-10-30):
[0000926326-20-000034:note_history:28]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | 550 |  |
| Amortization | (723) |  |
| Balance as of September 30, 2020 | $ | 4,527 |  |
  (was, 2020-07-31, similarity 0.9553):
[0000926326-20-000023:note_history:28]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | — |  |
| Amortization | (482) |  |
| Balance as of June 30, 2020 | $ | 4,218 |  |

- added (2020-10-30):
[0000926326-20-000034:note_history:29]
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- added (2020-10-30):
[0000926326-20-000034:note_history:30]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased or converted.

- added (2020-10-30):
[0000926326-20-000034:note_history:31]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ending on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

- added (2020-10-30):
[0000926326-20-000034:note_history:32]
Upon conversion, the Company may satisfy its conversion obligation by paying or delivering, as the case may be, cash, shares of its common stock, or a combination of cash and shares of its common stock, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

- added (2020-10-30):
[0000926326-20-000034:note_history:33]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal

- added (2020-10-30):
[0000926326-20-000034:note_history:34]
amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2020, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- added (2020-10-30):
[0000926326-20-000034:note_history:35]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

- added (2020-10-30):
[0000926326-20-000034:note_history:36]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. Accordingly, at issuance the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represents the debt discount, which the Company will amortize to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions. As of September 30, 2020, the remaining life of the Notes and the related debt discount and issuance cost accretion is approximately 5.0 years.

- added (2020-10-30):
[0000926326-20-000034:note_history:37]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 8.1 million shares.

- added (2020-10-30):
[0000926326-20-000034:note_history:38]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2020:

- added (2020-10-30):
[0000926326-20-000034:note_history:39]
|  | September 30,2020 |
|  | (In thousands) |
| Liability: |  |
| Principal amount | $ | 575,000 |  |
| Unamortized discount | (100,261) |  |
| Unamortized debt issuance costs | (12,624) |  |
| Convertible senior notes, liability component | $ | 462,115 |  |
| Equity: |  |
| Embedded conversion option | $ | 100,510 |  |
| Debt issuance costs | (2,680) |  |
| Deferred tax impact | (25,098) |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |

- added (2020-10-30):
[0000926326-20-000034:note_history:40]
_________________________________________________

- added (2020-10-30):
[0000926326-20-000034:note_history:41]
(1)    Included in additional paid-in capital in the Condensed Consolidated Balance Sheets.

- added (2020-10-30):
[0000926326-20-000034:note_history:42]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2020:

- added (2020-10-30):
[0000926326-20-000034:note_history:43]
|  | Three and Nine Months EndedSeptember 30, 2020 |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 20 |  |  |  |  |  |  |  |
| Amortization of discount | $ | 249 |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 31 |  |  |  |  |  |  |  |

- added (2020-10-30):
[0000926326-20-000034:note_history:44]
Convertible Note Hedge and Warrant Transactions

- added (2020-10-30):
[0000926326-20-000034:note_history:45]
In connection with the issuance of the Notes, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

- added (2020-10-30):
[0000926326-20-000034:note_history:46]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.
Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid in capital in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.

- removed (2020-10-30):
[0000926326-20-000023:note_history:47]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total net leverage ratio and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of June 30, 2020.

- removed (2020-10-30):
[0000926326-20-000023:note_history:48]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs was approximately $0.2 million and $0.6 million for the three months ended June 30, 2020 and 2019, respectively, and approximately $0.5 million and $1.1 million for the six months ended June 30, 2020 and 2019, respectively.

- removed (2020-10-30):
[0000926326-20-000023:note_history:49]
Interest expense (exclusive of fees and debt issuance cost amortization) was approximately $0.9 million for the three months ended June 30, 2019, and approximately $0.2 million and $2.2 million for the six months ended June 30, 2020 and 2019, respectively. No interest expense was incurred during the three months ended June 30, 2020 as there was no outstanding balance under the Current Revolving Credit Facility during the three months ended June 30, 2020.


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-10-30):
[0000926326-20-000034:note_history:50]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-30):
[0000926326-20-000034:note_history:51]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | 150,000 |  |
| Repayments | (200,000) |  |
| Balance as of September 30, 2020 | $ | — |  |
  (was, 2020-07-31, similarity 0.9644):
[0000926326-20-000023:note_history:51]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | — |  |
| Repayments | (50,000) |  |
| Balance as of June 30, 2020 | $ | — |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-10-30):
[0000926326-20-000034:note_history:52]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.3 million and $2.8 million for the three months ended September 30, 2020 and 2019, respectively, and $6.9 million and $7.6 million for the nine months ended September 30, 2020 and 2019, respectively.
  (was, 2020-07-31, similarity 0.9434):
[0000926326-20-000023:note_history:52]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $1.7 million and $2.6 million for the three months ended June 30, 2020 and 2019, respectively, and $4.6 million and $4.8 million for the six months ended June 30, 2020 and 2019, respectively.

- changed (2020-10-30):
[0000926326-20-000034:note_history:53]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and nine months ended September 30, 2020 and 2019:
  (was, 2020-07-31, similarity 0.9448):
[0000926326-20-000023:note_history:53]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and six months ended June 30, 2020 and 2019:

- changed (2020-10-30):
[0000926326-20-000034:note_history:54]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |
| Hardware and software | $ | 130,046 |  |  | $ | 142,424 |  |  | $ | 389,398 |  |  | $ | 394,243 |  |
| Consumables | 16,840 |  |  | 22,204 |  |  | 58,173 |  |  | 67,706 |  |
| Other | 4,451 |  |  | 3,860 |  |  | 12,781 |  |  | 10,528 |  |
| Total product revenues | $ | 151,337 |  |  | $ | 168,488 |  |  | $ | 460,352 |  |  | $ | 472,477 |  |
  (was, 2020-07-31, similarity 0.8624):
[0000926326-20-000023:note_history:54]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |  |  |  |  |  |  |
| Hardware and software | $ | 116,919 |  |  | $ | 133,005 |  |  | $ | 259,352 |  |  | $ | 251,819 |  |
| Consumables | 18,063 |  |  | 21,795 |  |  | 41,333 |  |  | 45,502 |  |
| Other | 3,960 |  |  | 3,579 |  |  | 8,330 |  |  | 6,668 |  |
| Total product revenues | $ | 138,942 |  |  | $ | 158,379 |  |  | $ | 309,015 |  |  | $ | 303,989 |  |

- changed (2020-10-30):
[0000926326-20-000034:note_history:55]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2020 and 2019:
  (was, 2020-07-31, similarity 0.9581):
[0000926326-20-000023:note_history:55]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2020 and 2019:

- changed (2020-10-30):
[0000926326-20-000034:note_history:56]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |
| United States | $ | 193,639 |  |  | $ | 206,709 |  |  | $ | 579,425 |  |  | $ | 582,540 |  |
| Rest of world (1) | 20,060 |  |  | 22,096 |  |  | 63,581 |  |  | 66,195 |  |
| Total revenues | $ | 213,699 |  |  | $ | 228,805 |  |  | $ | 643,006 |  |  | $ | 648,735 |  |
  (was, 2020-07-31, similarity 0.8793):
[0000926326-20-000023:note_history:56]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |  |  |  |  |  |  |
| United States | $ | 178,052 |  |  | $ | 195,811 |  |  | $ | 385,786 |  |  | $ | 375,831 |  |
| Rest of world (1) | 21,569 |  |  | 21,602 |  |  | 43,521 |  |  | 44,099 |  |
| Total revenues | $ | 199,621 |  |  | $ | 217,413 |  |  | $ | 429,307 |  |  | $ | 419,930 |  |

- changed (2020-10-30):
[0000926326-20-000034:note_history:57]
|  | September 30,2020 |  | December 31,2019 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 8,344 |  |  | $ | 11,707 |  |
| Long-term unbilled receivables, net (2) | 15,379 |  |  | 12,260 |  |
| Total contract assets | $ | 23,723 |  |  | $ | 23,967 |  |
| Short-term deferred revenues, net | $ | 101,641 |  |  | $ | 90,894 |  |
| Long-term deferred revenues | 5,163 |  |  | 7,083 |  |
| Total contract liabilities | $ | 106,804 |  |  | $ | 97,977 |  |
  (was, 2020-07-31, similarity 0.9779):
[0000926326-20-000023:note_history:57]
|  | June 30,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Short-term unbilled receivables, net (1) | $ | 9,602 |  |  | $ | 11,707 |  |
| Long-term unbilled receivables, net (2) | 16,132 |  |  | 12,260 |  |
| Total contract assets | $ | 25,734 |  |  | $ | 23,967 |  |
| Short-term deferred revenues, net | $ | 107,940 |  |  | $ | 90,894 |  |
| Long-term deferred revenues | 6,101 |  |  | 7,083 |  |
| Total contract liabilities | $ | 114,041 |  |  | $ | 97,977 |  |

- changed (2020-10-30):
[0000926326-20-000034:note_history:58]
Short-term deferred revenues of $101.6 million and $90.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $24.2 million and $13.1 million, as of September 30, 2020 and December 31, 2019, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and nine months ended September 30, 2020, the Company recognized revenues of $13.2 million and $77.5 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $104.0 million as of December 31, 2019.
  (was, 2020-07-31, similarity 0.9535):
[0000926326-20-000023:note_history:58]
Short-term deferred revenues of $107.9 million and $90.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $19.6 million and $13.1 million, as of June 30, 2020 and December 31, 2019, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and six months ended June 30, 2020, the Company recognized revenues of $20.9 million and $64.3 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $104.0 million as of December 31, 2019.

- added (2020-10-30):
[0000926326-20-000034:note_history:59]
Long-term deferred revenues include deferred revenues from service contracts of $5.2 million and $7.1 million as of September 30, 2020 and December 31, 2019, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

- changed (2020-10-30):
[0000926326-20-000034:note_history:60]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2020 and 2019. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of September 30, 2020 and December 31, 2019.
  (was, 2020-07-31, similarity 0.8526):
[0000926326-20-000023:note_history:60]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2020 and 2019. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of June 30, 2020 and December 31, 2019.

- removed (2020-10-30):
[0000926326-20-000023:note_history:61]
Long-term deferred revenues include deferred revenues from service contracts of $6.1 million and $7.1 million as of June 30, 2020 and December 31, 2019, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-10-30):
[0000926326-20-000034:note_history:62]
Subsequent Events On October 1, 2020, the Company completed the acquisition of the 340B Link Business of Pharmaceutical Strategies Group, LLC pursuant to the terms and conditions of the Equity Purchase Agreement, dated August 11, 2020, as amended, by and among the Company, PSGH, LLC, BW Apothecary Holdings, LLC, the sellers identified therein and the sellers’ representative (the “Purchase Agreement”). The purchase price was $225.0 million, subject to certain adjustments as provided for in the Purchase Agreement. The acquisition was funded with proceeds from the issuance of the Notes. Refer to Note 9, Convertible Senior Notes, for further information regarding the issuance of the Notes. The Company is in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation.
