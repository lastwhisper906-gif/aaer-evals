# OMCL 8-K — 0000926326-20-000032 filed 2020-10-27

## item codes, every 8-K on or before 2020-10-30

- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2020-10-30

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-20-000032:8k_2_02:1]
EX-99.1
7
exhibit991q3-20.htm
EX-99.1

[0000926326-20-000032:8k_2_02:2]
Document

[0000926326-20-000032:8k_2_02:3]
Exhibit 99.1

[0000926326-20-000032:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664 |  | Mountain View, CA 94043 |
| Peter.Kuipers@Omnicell.com |  |  |

[0000926326-20-000032:8k_2_02:5]
Omnicell Reports Third Quarter 2020 Results

[0000926326-20-000032:8k_2_02:6]
GAAP and non-GAAP revenues of $213.7 million

[0000926326-20-000032:8k_2_02:7]
GAAP net income per diluted share of $0.20

[0000926326-20-000032:8k_2_02:8]
Non-GAAP net income per diluted share of $0.60

[0000926326-20-000032:8k_2_02:9]
MOUNTAIN VIEW, Calif. -- October 27, 2020 -- Omnicell, Inc. (NASDAQ:OMCL), a leading provider of medication management solutions and adherence tools for healthcare systems and pharmacies, today announced results for its third quarter ended September 30, 2020.

[0000926326-20-000032:8k_2_02:10]
GAAP Results

[0000926326-20-000032:8k_2_02:11]
GAAP revenues for the third quarter of 2020 were $213.7 million, down $15.1 million, or 6.6% from the third quarter of 2019. GAAP revenues for the nine months ended September 30, 2020 were $643.0 million, down $5.7 million, or 0.9% from the nine months ended September 30, 2019.

[0000926326-20-000032:8k_2_02:12]
Third quarter 2020 GAAP net income was $8.8 million, or $0.20 per diluted share. This compares to GAAP net income of $20.0 million, or $0.46 per diluted share, for the third quarter of 2019.

[0000926326-20-000032:8k_2_02:13]
GAAP net income for the nine months ended September 30, 2020 was $15.8 million, or $0.36 per diluted share. This compares to GAAP net income of $39.2 million, or $0.92 per diluted share, for the nine months ended September 30, 2019.

[0000926326-20-000032:8k_2_02:14]
Non-GAAP Results

[0000926326-20-000032:8k_2_02:15]
Non-GAAP revenues for the third quarter of 2020 were $213.7 million, down $15.1 million, or 6.6%, from the third quarter of 2019. Non-GAAP revenues for the nine months ended September 30, 2020 were $643.0 million, down $5.7 million, or 0.9%, from the nine months ended September 30, 2019.

[0000926326-20-000032:8k_2_02:16]
Non-GAAP net income for the third quarter of 2020 was $26.2 million, or $0.60 per diluted share. This compares to non-GAAP net income of $32.7 million, or $0.76 per diluted share, for the third quarter of 2019.

[0000926326-20-000032:8k_2_02:17]
Non-GAAP net income for the nine months ended September 30, 2020 was $71.1 million, or $1.63 per diluted share. This compares to non-GAAP net income of $87.2 million, or $2.04 per diluted share, for the nine months ended September 30, 2019.

[0000926326-20-000032:8k_2_02:18]
Non-GAAP net income for each period excludes, when applicable, the effect of share-based compensation expense, amortization expense of acquired intangible assets, acquisition-related expenses, restructuring and severance-related expenses, tax restructuring benefits and expenses, amortization of debt issuance costs, and amortization of discount on convertible senior notes.

[0000926326-20-000032:8k_2_02:19]
“We are pleased with the solid financial performance this quarter, which exceeded the high end of our guidance ranges,” said Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell. “We continued to increase new customer wins and bookings, particularly with the top 300 U.S. health systems, as our customers embrace the vision of the autonomous pharmacy. We believe this renewed momentum underscores the critical importance of Omnicell’s solutions, and we remain confident we are well-positioned to continue executing on our strategy and drive significant long-term value for shareholders, healthcare partners, and patients.”

[0000926326-20-000032:8k_2_02:20]
2020 Guidance

[0000926326-20-000032:8k_2_02:21]
For the fourth quarter of 2020, the Company expects non-GAAP total revenues to be between $238 million and $244 million. The Company expects non-GAAP product revenues to be between $165 million and $170 million, and non-GAAP service revenues to be between $73 million and $74 million. The Company expects fourth quarter 2020 non-GAAP earnings to be between $0.72 and $0.77 per share.

[0000926326-20-000032:8k_2_02:22]
For the full year 2020, the Company expects product bookings to be between $865 million and $900 million. The Company expects non-GAAP total revenues to be between $881 million and $887 million. The Company expects non-GAAP product revenues to be between $626 million and $631 million, and non-GAAP service revenues to be between $255 million and $256 million. The Company expects 2020 non-GAAP earnings to be between $2.35 and $2.40 per share.

[0000926326-20-000032:8k_2_02:23]
The table below summarizes Omnicell's 2020 guidance outlined above.

[0000926326-20-000032:8k_2_02:24]
|  | Q4'20 | 2020 |
| Product Bookings | Not provided | $865 million - $900 million |
| Non-GAAP Total Revenues | $238 million - $244 million | $881 million - $887 million |
| Non-GAAP Product Revenues | $165 million - $170 million | $626 million - $631 million |
| Non-GAAP Service Revenues | $73 million - $74 million | $255 million - $256 million |
| Non-GAAP EPS | $0.72 - $0.77 | $2.35 - $2.40 |

[0000926326-20-000032:8k_2_02:25]
Given the COVID-19 dynamics and momentum we have experienced in the business, we have decided to accelerate our planning process for 2021. As a result, we are now able to provide our preliminary full year revenue guidance. The Company expects 2021 preliminary non-GAAP total revenues to range between $1.015 billion and $1.045 billion.

[0000926326-20-000032:8k_2_02:26]
While we are aware of the recent increase in COVID-19 cases in the United States, we believe, in speaking with our customers, that they are well prepared and believe they will continue to resume more normal business conditions. However, our bookings and revenue in future periods could be impacted if hospitals need to materially change their operations in order to address a continued increase in COVID-19 cases.

[0000926326-20-000032:8k_2_02:27]
Coronavirus (COVID-19) and Operations Update

[0000926326-20-000032:8k_2_02:28]
Keeping in mind our role in the healthcare industry, we are continuing to closely monitor the COVID-19 pandemic. Our top priorities remain protecting the health and well-being of our customers, their patients, and our employees, while maintaining business continuity to meet the needs of our customers. In order to operate in a safe manner, we continue to follow the health and safety guidelines of the U.S. Centers for Disease Control and Prevention and local and state public health departments in each of the regions where we operate. Our manufacturing and distribution facilities have remained open due to our qualification as an essential business and to date, we have not experienced disruptions in our manufacturing activities. The vast majority of our non-manufacturing and non-customer facing personnel continue to work from home. In addition, to minimize the need for on-site visits, we are providing remote service and installation options, training programs, and product demonstrations for our customers, leveraging technology to enable our sales team to operate in a remote sales environment. Although we have not experienced disruptions in our supply chain to date, we cannot predict how long the pandemic and measures intended to contain the spread of COVID-19 will continue.

[0000926326-20-000032:8k_2_02:29]
As a result of the pandemic, health systems have faced increased costs, decreased revenues and cash flow challenges due to cancelled or postponed elective procedures and other reduced demand. We believe these financial pressures led our customers to delay or defer purchasing decisions and/or implementation of our solutions during the first half of 2020, which resulted in delayed implementations and lower product bookings compared to management’s expectations prior to the COVID-19 outbreak. In the third quarter of 2020, we began to see our customers returning to more normal business operations, with increases in elective surgeries and hospital admissions as well as spending returning to pre-pandemic purchasing patterns consistent with long-term strategic investments. This enabled us to resume implementations that were delayed in the first half of the year, providing more visibility into product bookings for the fourth quarter of 2020. As a result, we now expect product bookings for 2020 to return to levels consistent with management’s expectations prior to the pandemic.

[0000926326-20-000032:8k_2_02:30]
In response to the COVID-19 pandemic, we have implemented and continue to focus on cost reduction initiatives in all aspects of our business and remain mindful of the uncertainty related to the pandemic.

[0000926326-20-000032:8k_2_02:31]
While our fiscal year 2020 results will be impacted by the challenges and opportunities brought on by the COVID-19 pandemic, we remain confident in the overall health of our business, in our ability to navigate through these unusual times, and in our ability to continue to execute on our long-term strategy, as we believe our customers and potential customers are increasingly embracing the vision of a fully autonomous pharmacy. However, the full impact of the COVID-19 pandemic and related

[0000926326-20-000032:8k_2_02:32]
containment measures cannot be predicted and to date, the COVID-19 pandemic and related containment measures have adversely affected and may continue to adversely affect, perhaps materially, our business, results of operations, financial condition, and liquidity.

[0000926326-20-000032:8k_2_02:33]
Omnicell continues to deliver innovation that supports the autonomous pharmacy, an industry movement to leverage automation, intelligence, and technology-enabled services designed to achieve zero-error medication management. During this quarter, the Company accelerated the shift to cloud-based services with the launch of Omnicell One, a predictive intelligence solution that provides visibility and comprehensive data analytics to drive medication supply chain optimization opportunities. The Company also completed the acquisition of Pharmacy Strategies Group’s 340B Link business, adding a comprehensive suite of software-enabled services to help manage compliance with the 340B drug pricing program and the associated eligible drug cost savings. These solutions will support health system partners in managing an increasingly complex pharmacy supply chain.

[0000926326-20-000032:8k_2_02:34]
Omnicell Conference Call Information

[0000926326-20-000032:8k_2_02:35]
Omnicell will hold a conference call today, Tuesday, October 27, 2020 at 1:30 p.m. PT to discuss third quarter 2020 financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 7580519. Internet users can access the conference call at http://ir.omnicell.com/communications/events-presentations. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on November 24, 2020. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 7580519.

[0000926326-20-000032:8k_2_02:36]
About Omnicell

[0000926326-20-000032:8k_2_02:37]
Since 1992, Omnicell has been committed to transforming the pharmacy care delivery model to dramatically improve outcomes and lower costs. Through the vision of the autonomous pharmacy, a combination of automation, intelligence, and technology-enabled services, powered by a cloud data platform, Omnicell supports more efficient ways to manage medications across all care settings.

[0000926326-20-000032:8k_2_02:38]
Approximately 7,000 facilities worldwide use Omnicell automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. Approximately 50,000 institutional and retail pharmacies across North America and the United Kingdom leverage Omnicell's innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-20-000032:8k_2_02:39]
To learn more, visit www.omnicell.com. From time to time, Omnicell may use the Company's investor relations site and other online social media channels, including its Twitter handle www.twitter.com/omnicell, LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure ("FD").

[0000926326-20-000032:8k_2_02:40]
Omnicell and the Omnicell logo are registered trademarks of Omnicell, Inc. in the United States and other countries.

[0000926326-20-000032:8k_2_02:41]
Forward-Looking Statements

[0000926326-20-000032:8k_2_02:42]
products and services, including competitive conversions, and growth in the overall demand for medication management and supply chain solutions and medication adherence solutions generally, (vii) risks presented by the transition to selling more products and services on a subscription basis, (viii) potential of increasing competition, (ix) potential regulatory changes, (x) Omnicell's ability to improve sales productivity to grow product bookings, and (xi) Omnicell's ability to acquire companies, businesses, or technologies and successfully integrate such acquisitions. These and other risks and uncertainties are described more fully in Omnicell’s most recent filings with the Securities and Exchange Commission (“SEC”). Prospective investors are cautioned not to place undue reliance on forward-looking statements. All forward-looking statements contained in this press release speak only as of the date on which they were made. Omnicell undertakes no obligation to update such statements to reflect events that occur or circumstances that exist after the date on which they were made.

[0000926326-20-000032:8k_2_02:43]
Use of Non-GAAP Financial Information

[0000926326-20-000032:8k_2_02:44]
This press release contains financial measures that are not calculated in accordance with GAAP. Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, non-GAAP net income per diluted share, adjusted EBITDA, and non-GAAP free cash flow. These non-GAAP results should not be considered as an alternative to revenues, gross profit, operating expenses, net income, net income per diluted share, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-20-000032:8k_2_02:45]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, non-GAAP net income per diluted share, and adjusted EBITDA are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-20-000032:8k_2_02:46]
a)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-20-000032:8k_2_02:47]
b)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-20-000032:8k_2_02:48]
c)Acquisition-related expenses. We excluded from our non-GAAP results the expenses which are related to recent acquisitions. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition-related expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance, and the financial results of less acquisitive peer companies.

[0000926326-20-000032:8k_2_02:49]
d)Severance and other related expenses. We excluded from our non-GAAP results the expenses which are related to restructuring events. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance, and the financial results of peer companies.

[0000926326-20-000032:8k_2_02:50]
e)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of term loan and revolving credit facilities, as well as the issuance of convertible senior notes. The costs include underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-20-000032:8k_2_02:51]
f)Amortization of discount on convertible senior notes. We excluded from our non-GAAP results the amortization of the imputed discount on our convertible senior notes. Under GAAP, certain convertible debt instruments that may be settled in cash upon conversion are required to be bifurcated into separate liability and equity components in a manner that reflects the issuer's assumed non-convertible debt borrowing rate. For GAAP purposes, we are required to recognize the imputed interest expense on the difference between our assumed non-convertible debt borrowing rate and the coupon rate on our convertible senior notes. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-20-000032:8k_2_02:52]
g)Tax impact from intellectual property (“IP”) restructuring. We excluded from our non-GAAP results the tax impacts related to IP restructuring. These impacts are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these impacts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies.

[0000926326-20-000032:8k_2_02:53]
h)IP and legal entities restructuring costs. We excluded from our non-GAAP results the expenses which are related to IP and legal entities restructuring events, such as legal and tax consulting costs. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies.

[0000926326-20-000032:8k_2_02:54]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans or other items.

[0000926326-20-000032:8k_2_02:55]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-20-000032:8k_2_02:56]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-20-000032:8k_2_02:57]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-20-000032:8k_2_02:58]
c)These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting.

[0000926326-20-000032:8k_2_02:59]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-20-000032:8k_2_02:60]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-20-000032:8k_2_02:61]
i)While share-based compensation calculated in accordance with Accounting Standard Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-20-000032:8k_2_02:62]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-20-000032:8k_2_02:63]
Our adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 share-based compensation expense, as well as certain non-GAAP adjustments.

[0000926326-20-000032:8k_2_02:64]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-20-000032:8k_2_02:65]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in

[0000926326-20-000032:8k_2_02:66]
isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-20-000032:8k_2_02:67]
a)Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-20-000032:8k_2_02:68]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-20-000032:8k_2_02:69]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-20-000032:8k_2_02:70]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-20-000032:8k_2_02:71]
Our 2020 guidance for non-GAAP earnings per share, non-GAAP total revenues, non-GAAP product revenues, and non-GAAP service revenues, as well as our 2021 preliminary guidance for non-GAAP total revenues, and certain projections to be discussed in the conference call noted above, exclude “certain items,” which include but are not limited to: unusual gains and losses; costs associated with future restructurings; acquisition-related expenses; and certain tax and litigation outcomes. We do not provide a reconciliation of forward-looking non-GAAP guidance to the comparable GAAP measures as these items are inherently uncertain and difficult to estimate, and cannot be predicted without unreasonable effort. We believe such a reconciliation would imply a degree of precision that could be confusing to investors. These items may also have a material impact on GAAP earnings per share, total revenues, product revenues, and service revenues in future periods.

[0000926326-20-000032:8k_2_02:72]
6

[0000926326-20-000032:8k_2_02:73]
Omnicell, Inc.

[0000926326-20-000032:8k_2_02:74]
Condensed Consolidated Statements of Operations

[0000926326-20-000032:8k_2_02:75]
(Unaudited, in thousands, except per share data)

[0000926326-20-000032:8k_2_02:76]
|  | Three Months Ended September 30, |  |  |  | Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 151,337 |  |  | $ | 168,488 |  |  | $ | 460,352 |  |  | $ | 472,477 |  |
| Services and other revenues | 62,362 |  |  | 60,317 |  |  | 182,654 |  |  | 176,258 |  |
| Total revenues | 213,699 |  |  | 228,805 |  |  | 643,006 |  |  | 648,735 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 86,689 |  |  | 86,695 |  |  | 262,740 |  |  | 250,089 |  |
| Cost of services and other revenues | 30,219 |  |  | 29,963 |  |  | 90,628 |  |  | 85,337 |  |
| Total cost of revenues | 116,908 |  |  | 116,658 |  |  | 353,368 |  |  | 335,426 |  |
| Gross profit | 96,791 |  |  | 112,147 |  |  | 289,638 |  |  | 313,309 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 15,197 |  |  | 16,625 |  |  | 54,679 |  |  | 49,551 |  |
| Selling, general, and administrative | 71,442 |  |  | 70,876 |  |  | 219,647 |  |  | 207,588 |  |
| Total operating expenses | 86,639 |  |  | 87,501 |  |  | 274,326 |  |  | 257,139 |  |
| Income from operations | 10,152 |  |  | 24,646 |  |  | 15,312 |  |  | 56,170 |  |
| Interest and other income (expense), net | 809 |  |  | (1,168) |  |  | 161 |  |  | (4,207) |  |
| Income before provision for income taxes | 10,961 |  |  | 23,478 |  |  | 15,473 |  |  | 51,963 |  |
| Provision for (benefit from) income taxes | 2,156 |  |  | 3,495 |  |  | (344) |  |  | 12,720 |  |
| Net income | $ | 8,805 |  |  | $ | 19,983 |  |  | $ | 15,817 |  |  | $ | 39,243 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.21 |  |  | $ | 0.48 |  |  | $ | 0.37 |  |  | $ | 0.95 |  |
| Diluted | $ | 0.20 |  |  | $ | 0.46 |  |  | $ | 0.36 |  |  | $ | 0.92 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 42,802 |  |  | 41,771 |  |  | 42,606 |  |  | 41,283 |  |
| Diluted | 43,691 |  |  | 43,052 |  |  | 43,651 |  |  | 42,796 |  |

[0000926326-20-000032:8k_2_02:77]
Omnicell, Inc.

[0000926326-20-000032:8k_2_02:78]
Condensed Consolidated Balance Sheets

[0000926326-20-000032:8k_2_02:79]
(Unaudited, in thousands)

[0000926326-20-000032:8k_2_02:80]
|  | September 30,2020 |  | December 31,2019 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 629,171 |  |  | $ | 127,210 |  |
| Accounts receivable and unbilled receivables, net | 188,102 |  |  | 218,362 |  |
| Inventories | 103,101 |  |  | 108,011 |  |
| Prepaid expenses | 20,399 |  |  | 14,478 |  |
| Other current assets | 22,631 |  |  | 15,177 |  |
| Total current assets | 963,404 |  |  | 483,238 |  |
| Property and equipment, net | 57,559 |  |  | 54,246 |  |
| Long-term investment in sales-type leases, net | 22,510 |  |  | 19,750 |  |
| Operating lease right-of-use assets | 50,415 |  |  | 56,130 |  |
| Goodwill | 336,456 |  |  | 336,539 |  |
| Intangible assets, net | 111,587 |  |  | 124,867 |  |
| Long-term deferred tax assets | 14,985 |  |  | 14,142 |  |
| Prepaid commissions | 46,649 |  |  | 48,862 |  |
| Other long-term assets | 115,712 |  |  | 103,036 |  |
| Total assets | $ | 1,719,277 |  |  | $ | 1,240,810 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 37,203 |  |  | $ | 46,380 |  |
| Accrued compensation | 35,778 |  |  | 44,155 |  |
| Accrued liabilities | 59,254 |  |  | 55,567 |  |
| Deferred revenues, net | 101,641 |  |  | 90,894 |  |
| Total current liabilities | 233,876 |  |  | 236,996 |  |
| Long-term deferred revenues | 5,163 |  |  | 7,083 |  |
| Long-term deferred tax liabilities | 35,584 |  |  | 39,090 |  |
| Long-term operating lease liabilities | 44,365 |  |  | 50,669 |  |
| Other long-term liabilities | 19,775 |  |  | 11,718 |  |
| Revolving credit facility | — |  |  | 50,000 |  |
| Convertible senior notes, net | 462,115 |  |  | — |  |
| Total liabilities | 800,878 |  |  | 395,556 |  |
| Total stockholders’ equity | 918,399 |  |  | 845,254 |  |
| Total liabilities and stockholders’ equity | $ | 1,719,277 |  |  | $ | 1,240,810 |  |

[0000926326-20-000032:8k_2_02:81]
8

[0000926326-20-000032:8k_2_02:82]
Omnicell, Inc.

[0000926326-20-000032:8k_2_02:83]
Condensed Consolidated Statements of Cash Flows

[0000926326-20-000032:8k_2_02:84]
(Unaudited, in thousands)

[0000926326-20-000032:8k_2_02:85]
|  | Nine Months Ended September 30, |  |  |
|  | 2020 |  | 2019 |
| Operating Activities |  |  |  |
| Net income | $ | 15,817 |  |  | $ | 39,243 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 43,903 |  |  | 39,525 |  |
| Loss on disposal of property and equipment | — |  |  | 436 |  |
| Share-based compensation expense | 33,034 |  |  | 25,175 |  |
| Deferred income taxes | (3,643) |  |  | 4,023 |  |
| Amortization of operating lease right-of-use assets | 7,692 |  |  | 7,917 |  |
| Amortization of debt issuance costs | 754 |  |  | 1,718 |  |
| Amortization of discount on convertible senior notes | 249 |  |  | — |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | 29,653 |  |  | (7,716) |  |
| Inventories | 4,570 |  |  | (7,015) |  |
| Prepaid expenses | (6,272) |  |  | (1,341) |  |
| Other current assets | (6,617) |  |  | 974 |  |
| Investment in sales-type leases | (3,273) |  |  | (5,120) |  |
| Prepaid commissions | 2,213 |  |  | 909 |  |
| Other long-term assets | (4,023) |  |  | 3,944 |  |
| Accounts payable | (8,659) |  |  | 10,316 |  |
| Accrued compensation | (8,377) |  |  | (8,161) |  |
| Accrued liabilities | 3,281 |  |  | 5,262 |  |
| Deferred revenues | 8,827 |  |  | 3,900 |  |
| Operating lease liabilities | (7,764) |  |  | (7,887) |  |
| Other long-term liabilities | 8,057 |  |  | 4,086 |  |
| Net cash provided by operating activities | 109,422 |  |  | 110,188 |  |
| Investing Activities |  |  |  |
| Software development for external use | (25,909) |  |  | (34,129) |  |
| Purchases of property and equipment | (17,265) |  |  | (12,632) |  |
| Net cash used in investing activities | (43,174) |  |  | (46,761) |  |
| Financing Activities |  |  |  |
| Proceeds from revolving credit facility | 150,000 |  |  | — |  |
| Repayment of debt and revolving credit facility | (200,000) |  |  | (60,000) |  |
| Payments for debt issuance costs for revolving credit facility | (550) |  |  | — |  |
| Proceeds from issuance of convertible senior notes, net of issuance costs | 559,665 |  |  | — |  |
| Purchase of convertible note hedge | (100,625) |  |  | — |  |
| Proceeds from sale of warrants | 51,290 |  |  | — |  |
| At the market equity offering, net of offering costs | — |  |  | 37,806 |  |
| Proceeds from issuances under stock-based compensation plans | 33,226 |  |  | 35,029 |  |
| Employees’ taxes paid related to restricted stock units | (4,101) |  |  | (5,790) |  |
| Stock repurchases | (53,035) |  |  | — |  |
| Net cash provided by financing activities | 435,870 |  |  | 7,045 |  |
| Effect of exchange rate changes on cash and cash equivalents | (157) |  |  | (387) |  |
| Net increase in cash and cash equivalents | 501,961 |  |  | 70,085 |  |
| Cash and cash equivalents at beginning of period | 127,210 |  |  | 67,192 |  |
| Cash and cash equivalents at end of period | $ | 629,171 |  |  | $ | 137,277 |  |

[0000926326-20-000032:8k_2_02:86]
Omnicell, Inc.

[0000926326-20-000032:8k_2_02:87]
Reconciliation of GAAP to Non-GAAP

[0000926326-20-000032:8k_2_02:88]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-20-000032:8k_2_02:89]
|  | Three Months Ended September 30, |  |  |  |  |  | Nine Months Ended September 30, |  |  |
|  | 2020 |  |  |  | 2019 |  | 2020 |  | 2019 |
| Reconciliation of GAAP revenues to non-GAAP revenues: |  |  |  |  |  |  |  |  |  |
| GAAP revenues | $ | 213,699 |  |  |  |  | $ | 228,805 |  |  | $ | 643,006 |  |  | $ | 648,735 |  |
| Non-GAAP revenues | $ | 213,699 |  |  |  |  | $ | 228,805 |  |  | $ | 643,006 |  |  | $ | 648,735 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |  |  |  |
| GAAP gross profit | $ | 96,791 |  |  |  |  | $ | 112,147 |  |  | $ | 289,638 |  |  | $ | 313,309 |  |
| GAAP gross margin | 45.3% |  |  |  | 49.0% |  | 45.0% |  | 48.3% |
| Share-based compensation expense | 1,758 |  |  |  |  | 1,316 |  |  | 5,658 |  |  | 4,194 |  |
| Amortization of acquired intangibles | 2,032 |  |  |  |  | 2,037 |  |  | 6,100 |  |  | 6,147 |  |
| Severance and other expenses | — |  |  |  |  | — |  |  | 2,564 |  |  | — |  |
| Non-GAAP gross profit | $ | 100,581 |  |  |  |  | $ | 115,500 |  |  | $ | 303,960 |  |  | $ | 323,650 |  |
| Non-GAAP gross margin | 47.1% |  |  |  | 50.5% |  | 47.3% |  | 49.9% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |  |  |  |  |  |
| GAAP operating expenses | $ | 86,639 |  |  |  |  | $ | 87,501 |  |  | $ | 274,326 |  |  | $ | 257,139 |  |
| GAAP operating expenses % to total revenues | 40.5% |  |  |  | 38.2% |  | 42.7% |  | 39.6% |
| Share-based compensation expense | (9,266) |  |  |  |  | (7,189) |  |  | (27,376) |  |  | (20,981) |  |
| Amortization of acquired intangibles | (2,336) |  |  |  |  | (2,545) |  |  | (7,056) |  |  | (7,891) |  |
| Acquisition-related expenses | (3,121) |  |  |  |  | — |  |  | (3,121) |  |  | — |  |
| Severance and other expenses | (84) |  |  |  |  | (194) |  |  | (8,272) |  |  | (920) |  |
| Non-GAAP operating expenses | $ | 71,832 |  |  |  |  | $ | 77,573 |  |  | $ | 228,501 |  |  | $ | 227,347 |  |
| Non-GAAP operating expenses % to total non-GAAP revenues | 33.6% |  |  |  | 33.9% |  | 35.5% |  | 35.0% |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |  |  |  |  |  |  |  |  |  |
| GAAP income from operations | $ | 10,152 |  |  |  |  | $ | 24,646 |  |  | $ | 15,312 |  |  | $ | 56,170 |  |
| GAAP operating income % to total revenues | 4.8% |  |  |  | 10.8% |  | 2.4% |  | 8.7% |
| Share-based compensation expense | 11,024 |  |  |  |  | 8,505 |  |  | 33,034 |  |  | 25,175 |  |
| Amortization of acquired intangibles | 4,368 |  |  |  |  | 4,582 |  |  | 13,156 |  |  | 14,038 |  |
| Acquisition-related expenses | 3,121 |  |  |  |  | — |  |  | 3,121 |  |  | — |  |
| Severance and other expenses | 84 |  |  |  |  | 194 |  |  | 10,836 |  |  | 920 |  |
| Non-GAAP income from operations | $ | 28,749 |  |  |  |  | $ | 37,927 |  |  | $ | 75,459 |  |  | $ | 96,303 |  |
| Non-GAAP operating income % to total non-GAAP revenues | 13.5% |  |  |  | 16.6% |  | 11.7% |  | 14.8% |

[0000926326-20-000032:8k_2_02:90]
10

[0000926326-20-000032:8k_2_02:91]
Omnicell, Inc.

[0000926326-20-000032:8k_2_02:92]
Reconciliation of GAAP to Non-GAAP

[0000926326-20-000032:8k_2_02:93]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-20-000032:8k_2_02:94]
|  | Three Months Ended September 30, |  |  |  |  |  | Nine Months Ended September 30, |  |  |
|  | 2020 |  |  |  | 2019 |  | 2020 |  | 2019 |
| Reconciliation of GAAP net income to non-GAAP net income: |  |  |  |  |  |  |  |  |  |
| GAAP net income | $ | 8,805 |  |  |  |  | $ | 19,983 |  |  | $ | 15,817 |  |  | $ | 39,243 |  |
| Tax impact of IP restructuring | — |  |  |  |  | — |  |  | — |  |  | 9,624 |  |
| Share-based compensation expense | 11,024 |  |  |  |  | 8,505 |  |  | 33,034 |  |  | 25,175 |  |
| Amortization of acquired intangibles | 4,368 |  |  |  |  | 4,582 |  |  | 13,156 |  |  | 14,038 |  |
| Acquisition-related expenses | 3,121 |  |  |  |  | — |  |  | 3,121 |  |  | — |  |
| Severance and other expenses (a) | 84 |  |  |  |  | 194 |  |  | 10,836 |  |  | 921 |  |
| Amortization of debt issuance costs | 272 |  |  |  |  | 573 |  |  | 754 |  |  | 1,718 |  |
| Amortization of discount on convertible senior notes | 249 |  |  |  |  | — |  |  | 249 |  |  | — |  |
| Tax effect of the adjustments above (b) | (1,700) |  |  |  |  | (1,123) |  |  | (5,905) |  |  | (3,501) |  |
| Non-GAAP net income | $ | 26,223 |  |  |  |  | $ | 32,714 |  |  | $ | 71,062 |  |  | $ | 87,218 |  |
| Reconciliation of GAAP net income per share - diluted to non-GAAP net income per share - diluted: |  |  |  |  |  |  |  |  |  |
| Shares - diluted GAAP | 43,691 |  |  |  |  | 43,052 |  |  | 43,651 |  |  | 42,796 |  |
| Shares - diluted Non-GAAP | 43,691 |  |  |  |  | 43,052 |  |  | 43,651 |  |  | 42,796 |  |
| GAAP net income per share - diluted | $ | 0.20 |  |  |  |  | $ | 0.46 |  |  | $ | 0.36 |  |  | $ | 0.92 |  |
| Tax impact of IP restructuring | — |  |  |  |  | — |  |  | — |  |  | 0.22 |  |
| Share-based compensation expense | 0.25 |  |  |  |  | 0.20 |  |  | 0.76 |  |  | 0.59 |  |
| Amortization of acquired intangibles | 0.10 |  |  |  |  | 0.11 |  |  | 0.30 |  |  | 0.33 |  |
| Acquisition-related expenses | 0.07 |  |  |  |  | — |  |  | 0.07 |  |  | — |  |
| Severance and other expenses | 0.00 |  |  |  |  | 0.01 |  |  | 0.25 |  |  | 0.02 |  |
| Amortization of debt issuance costs | 0.01 |  |  |  |  | 0.01 |  |  | 0.02 |  |  | 0.04 |  |
| Amortization of discount on convertible senior notes | 0.01 |  |  |  |  | — |  |  | 0.01 |  |  | — |  |
| Tax effect of the adjustments above (b) | (0.04) |  |  |  |  | (0.03) |  |  | (0.14) |  |  | (0.08) |  |
| Non-GAAP net income per share - diluted | $ | 0.60 |  |  |  |  | $ | 0.76 |  |  | $ | 1.63 |  |  | $ | 2.04 |  |
| Reconciliation of GAAP net income to non-GAAP Adjusted EBITDA(c): |  |  |  |  |  |  |  |  |  |
| GAAP net income | $ | 8,805 |  |  |  |  | $ | 19,983 |  |  | $ | 15,817 |  |  | $ | 39,243 |  |
| Share-based compensation expense | 11,024 |  |  |  |  | 8,505 |  |  | 33,034 |  |  | 25,175 |  |
| Interest (income) and expense, net | 380 |  |  |  |  | 572 |  |  | 442 |  |  | 1,965 |  |
| Depreciation and amortization expense | 15,124 |  |  |  |  | 13,651 |  |  | 43,903 |  |  | 39,525 |  |
| Acquisition-related expenses | 3,121 |  |  |  |  | — |  |  | 3,121 |  |  | — |  |
| Severance and other expenses | 84 |  |  |  |  | 194 |  |  | 10,836 |  |  | 921 |  |
| Amortization of debt issuance costs | 272 |  |  |  |  | 573 |  |  | 754 |  |  | 1,718 |  |
| Amortization of discount on convertible senior notes | 249 |  |  |  |  | — |  |  | 249 |  |  | — |  |
| Income tax expense (benefit) | 2,156 |  |  |  |  | 3,495 |  |  | (344) |  |  | 12,720 |  |
| Non-GAAP adjusted EBITDA | $ | 41,215 |  |  |  |  | $ | 46,973 |  |  | $ | 107,812 |  |  | $ | 121,267 |  |

[0000926326-20-000032:8k_2_02:95]
(a)For the three months ended September 30, 2020 and 2019, other expenses include $0.1 million and $0.2 million of IP and legal entities restructuring costs, respectively. For both the nine months ended September 30, 2020 and 2019, other expenses include $0.9 million of IP and legal entities restructuring costs.

[0000926326-20-000032:8k_2_02:96]
(b)Tax effects calculated for all adjustments except tax benefits and expenses, and share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2020 and 2019.

[0000926326-20-000032:8k_2_02:97]
(c)Defined as earnings before interest income and expense, taxes, depreciation and amortization, share-based compensation, as well as excluding certain non-GAAP adjustments.

[0000926326-20-000032:8k_2_02:98]
Omnicell, Inc.

[0000926326-20-000032:8k_2_02:99]
Reconciliation of GAAP to Non-GAAP

[0000926326-20-000032:8k_2_02:100]
(Unaudited, in thousands)

[0000926326-20-000032:8k_2_02:101]
|  | Three Months Ended September 30, |  |  |  |  |  | Nine Months Ended September 30, |  |  |
|  | 2020 |  |  |  | 2019 |  | 2020 |  | 2019 |
| Reconciliation of GAAP net cash provided by operating activities to non-GAAP free cash flow: |  |  |  |  |  |  |  |  |  |
| GAAP net cash provided by operating activities | $ | 36,687 |  |  |  |  | $ | 56,428 |  |  | $ | 109,422 |  |  | $ | 110,188 |  |
| Software development for external use | (5,907) |  |  |  |  | (11,548) |  |  | (25,909) |  |  | (34,129) |  |
| Purchases of property and equipment | (4,054) |  |  |  |  | (3,263) |  |  | (17,265) |  |  | (12,632) |  |
| Non-GAAP free cash flow | $ | 26,726 |  |  |  |  | $ | 41,617 |  |  | $ | 66,248 |  |  | $ | 63,427 |  |

[0000926326-20-000032:8k_2_02:102]
12
