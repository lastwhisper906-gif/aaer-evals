# OMCL MD&A — 0000926326-16-000057


## mdna

[0000926326-16-000057:mdna:1]
[same as prior period, unchanged from 0000926326-15-000035:mdna:1]

[0000926326-16-000057:mdna:2]
[same as prior period, unchanged from 0000926326-15-000035:mdna:2]

[0000926326-16-000057:mdna:3]
[same as prior period, unchanged from 0000926326-15-000035:mdna:3]

[0000926326-16-000057:mdna:4]
| • | our expectations regarding our future product bookings; |

[0000926326-16-000057:mdna:5]
| • | the extent and timing of future revenues, including the amounts of our current backlog; |

[0000926326-16-000057:mdna:6]
[same as prior period, unchanged from 0000926326-15-000035:mdna:6]

[0000926326-16-000057:mdna:7]
[same as prior period, unchanged from 0000926326-15-000035:mdna:7]

[0000926326-16-000057:mdna:8]
[same as prior period, unchanged from 0000926326-15-000035:mdna:8]

[0000926326-16-000057:mdna:9]
[same as prior period, unchanged from 0000926326-15-000035:mdna:9]

[0000926326-16-000057:mdna:10]
[same as prior period, unchanged from 0000926326-15-000035:mdna:10]

[0000926326-16-000057:mdna:11]
[same as prior period, unchanged from 0000926326-15-000035:mdna:11]

[0000926326-16-000057:mdna:12]
[same as prior period, unchanged from 0000926326-15-000035:mdna:12]

[0000926326-16-000057:mdna:13]
[same as prior period, unchanged from 0000926326-15-000035:mdna:13]

[0000926326-16-000057:mdna:14]
[same as prior period, unchanged from 0000926326-15-000035:mdna:14]

[0000926326-16-000057:mdna:15]
[same as prior period, unchanged from 0000926326-15-000035:mdna:15]

[0000926326-16-000057:mdna:16]
We are a leading provider of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum; from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home. Over 4,000 customers worldwide have used our Omnicell Automation and Analytics supply chain and analytics solutions to help enable them to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety. The recent acquisition of Aesynt Coöperatief U.A. (“Aesynt”) discussed below adds distinct product capabilities, particularly in central pharmacy and IV robotics, creating the broadest medication management product portfolio in the industry.

[0000926326-16-000057:mdna:17]
Omnicell Medication Adherence solutions, including our MTS Medication Technologies, SureMed and Surgichem brands, provide innovative medication adherence packaging solutions designed to help reduce costly hospital readmissions. In addition, these solutions help enable approximately 7,000 institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-16-000057:mdna:18]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 84% of total revenue in the first quarter ended March 31, 2016. We expect our revenues from international

[0000926326-16-000057:mdna:19]
operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-16-000057:mdna:20]
On January 5, 2016, we completed the acquisition of all of the membership interests of Aesynt. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. Adding these solution sets to the Omnicell portfolio is intended to give the combined companies one of the most complete medication management offering in the industry. We are now able to support customers who desire a centralized cartfill or nurse server medication distribution model all the way to fully decentralized dispensing and various combinations along that continuum. We are also able to offer solutions for I.V. preparations, including oncology drugs, which is an area where our combined customers have expressed significant interest. Looking across the entire medication distribution model, Aesynt’s new Enterprise Medication Manager software products give the customer the power to optimize the pharmacy supply chain with tools that help manage their inventory, reduce risks of stock outs, and minimize the cost of expiring medications. In addition, Aesynt has an experienced and skilled workforce whose expertise complements our capabilities. Integrating our two product development groups is expected to lead to innovation and the opportunity to help accelerate innovation. Finally, Aesynt has over 1,200 hospital customers with limited overlap to Omnicell’s existing install base, which will drive a significant increase to our customer install base.

[0000926326-16-000057:mdna:21]
[same as prior period, unchanged from 0000926326-15-000035:mdna:19]

[0000926326-16-000057:mdna:22]
We have managed our business as two operating segments, Automation and Analytics and Medication Adherence.

[0000926326-16-000057:mdna:23]
[same as prior period, unchanged from 0000926326-15-000035:mdna:21]

[0000926326-16-000057:mdna:24]
The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. Our Automation and Analytics products are designed to enable our customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, our systems can be tailored to specific customer needs. Our acquired companies in the last two years Aesynt, Mach4, and Avantec are included in the Automation and Analytics segment.

[0000926326-16-000057:mdna:25]
[same as prior period, unchanged from 0000926326-15-000035:mdna:23]

[0000926326-16-000057:mdna:26]
The Medication Adherence segment primarily includes the design, manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand names MTS, Surgichem, SureMed and Omnicell. MTS products consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care and correctional facilities or retail pharmacies serving patients in their local communities. Similarly, Surgichem is a provider of medication adherence packaging systems and solutions to the United Kingdom community and home care markets.

[0000926326-16-000057:mdna:27]
For further description of our operating segments, refer to Note 13, Segment and Geographical Information, of the Notes to Consolidated Financial Statements in this quarterly report.

[0000926326-16-000057:mdna:28]
[same as prior period, unchanged from 0000926326-15-000035:mdna:25]

[0000926326-16-000057:mdna:29]
[same as prior period, unchanged from 0000926326-15-000035:mdna:26]

[0000926326-16-000057:mdna:30]
[same as prior period, unchanged from 0000926326-15-000035:mdna:27]

[0000926326-16-000057:mdna:31]
27

[0000926326-16-000057:mdna:32]
| • | Deliver our solutions to new markets. Areas of healthcare where work is done manually may benefit from our existing solutions. These areas include hospitals that continue to employ manual operations, healthcare segments of the U.S. market outside hospitals and markets outside the United States. We weigh the cost of entering these new markets against the expected benefits and focus on the markets that we believe are most likely to adopt our products. |

[0000926326-16-000057:mdna:33]
[same as prior period, unchanged from 0000926326-15-000035:mdna:29]

[0000926326-16-000057:mdna:34]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, we began shipping a refresh of our product line in 2011, which we market as G4. The G4 refresh included multiple new products and an upgrade product that allowed existing customers to augment their installations to obtain the most current technology that we provide. The G4 product is updated regularly every 12-18 months with new software enhancements. Since its introduction in 2011, there have been five major software releases. The G4 product refresh has been a key contributor to our growth, with approximately 79% of our automation and analytics installed base ordering upgrades to their existing systems since the announcement of G4. In addition to enhanced capabilities, we have focused on attaining the highest quality and service measurements for G4 in the industry, while marketing the solution to new and existing customers. Our research and development efforts today are designed to bring new products to market beyond the G4 product line that we believe will meet customer needs in years to come.

[0000926326-16-000057:mdna:35]
Consistent with our strategy to enter new markets, we have made investments in our selling, general and administrative expenses to expand our sales team and market to new customers. Our international efforts have focused primarily on five markets: the United Kingdom, Germany, and France, where we sell the full range of our products through primarily a direct sales team; Middle Eastern countries of the Arabian Peninsula where new healthcare facility construction is taking place, and in China where we launched a Mandarin version of our automated dispensing systems. We have also expanded our sales efforts to healthcare customers outside of acute care hospitals in the United States which has allowed us to sell our automated dispensing solutions and medication adherence products into these markets.

[0000926326-16-000057:mdna:36]
Expansion of our solutions through acquisitions and partnerships include our acquisition of MTS in 2012, our acquisition of Surgichem in August 2014, our acquisitions of Mach4 and Avantec in April 2015, and our acquisition of Aesynt in January 2016. Surgichem is a provider of medication adherence products in the United Kingdom. Mach4 is a provider of automated medication management systems to retail and hospital pharmacy customers primarily in Europe, with additional installations in China, the Middle East and Latin America. Avantec develops medication and supply automation products that complement our solutions for configurations suited to the United Kingdom marketplace, and has been the exclusive United Kingdom distributor for our medication and supply automation solutions since 2005. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-16-000057:mdna:37]
We believe that the success of our three leg strategy of differentiated products, expansion into new markets and acquisition and partnership in future periods will be based on, among other factors:

[0000926326-16-000057:mdna:38]
[same as prior period, unchanged from 0000926326-15-000035:mdna:35]

[0000926326-16-000057:mdna:39]
| • | Our expectation that the environment of increased patient safety awareness, increased regulatory control, increased demand for innovative products that improve the care experience and increased need for workflow efficiency through the adoption of technology in the healthcare industry will make our solutions a priority in the capital budgets of healthcare facilities and systems; and |

[0000926326-16-000057:mdna:40]
[same as prior period, unchanged from 0000926326-15-000035:mdna:37]

[0000926326-16-000057:mdna:41]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced by a contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are installable within twelve months and generally recorded

[0000926326-16-000057:mdna:42]
28

[0000926326-16-000057:mdna:43]
as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month.

[0000926326-16-000057:mdna:44]
In addition to product solution sales, we provide services to our customers.  Our healthcare customers expect a high degree of partnership involvement from their technology suppliers throughout their ownership of the products. We provide extensive installation planning and consulting as part of every product sale and included in the initial price of the solution. Our customers' medication control systems are mission critical to their success and our customers require these systems to be functional at all times. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in one, two or five year increments.  As a result of the growth of our installed base of customers, our service revenues have also grown. We strive to provide the best service possible, as measured by third-party rating agencies and by our own surveys, to assure our customers continue to seek service maintenance from us. Our liabilities include current and long-term deferred revenues of $129.1 million and $87.3 million as of March 31, 2016 and December 31, 2015, respectively. The current deferred revenue of $92.3 million includes deferred revenue from product sales and service contracts, net of deferred cost of sales of $19.0 million as of March 31, 2016. The current deferred revenues from product sales relate to the delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. The long-term deferred revenue of $17.8 million as of March 31, 2016 includes deferred revenue from service contracts in excess of twelve months.

[0000926326-16-000057:mdna:45]
The growth in our Automation and Analytics revenue for the three months ended March 31, 2016 was driven primarily by the expansion through the Aesynt acquisition.  To a lesser extent but of equal importance, revenue growth was also driven by our growth in the number of our customer installations. Installed customers in the United States grew to 2,875 hospitals as of March 31, 2016 from 1,955 hospitals as of March 31, 2015, driven mostly by the acquisition of Aesynt. In addition, our success in upgrading installed customers to newer G4 technology, which is in line with our strategy of striving to deliver differentiated innovation in our solutions further attributed to the increase in revenue. Our larger installed base has provided growth opportunities for follow on sales and increased service contracts and, as a result, our service revenues have also grown for the three months ended March 31, 2016.  Medication Adherence revenue has remained relatively consistent as the population of patients living in nursing homes, primarily in the United States market, has remained relatively constant over the past year.

[0000926326-16-000057:mdna:46]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but for our focus to remain on improving healthcare with solutions that help change practices in ways that improve patient and provider outcomes. We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue. In 2016, we also intend to manage our business to operating profit margins similar to those achieved in 2015.

[0000926326-16-000057:mdna:47]
[same as prior period, unchanged from 0000926326-15-000035:mdna:48]

[0000926326-16-000057:mdna:48]
[same as prior period, unchanged from 0000926326-15-000035:mdna:49]

[0000926326-16-000057:mdna:49]
[same as prior period, unchanged from 0000926326-15-000035:mdna:50]

[0000926326-16-000057:mdna:50]
[same as prior period, unchanged from 0000926326-15-000035:mdna:51]

[0000926326-16-000057:mdna:51]
[same as prior period, unchanged from 0000926326-15-000035:mdna:52]

[0000926326-16-000057:mdna:52]
| • | Business combinations; |

[0000926326-16-000057:mdna:53]
[same as prior period, unchanged from 0000926326-15-000035:mdna:54]

[0000926326-16-000057:mdna:54]
[same as prior period, unchanged from 0000926326-15-000035:mdna:55]

[0000926326-16-000057:mdna:55]
There have been no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the three months ended March 31, 2016 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2015. Concurrent with our acquisition of Aesynt in January 2016, certain accounting policies of Aesynt were aligned to conform to the accounting policies of Omnicell.

[0000926326-16-000057:mdna:56]
Recently adopted and issued authoritative guidance

[0000926326-16-000057:mdna:57]
Refer to Note 1, Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently adopted and  issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial positions and cash flows.

[0000926326-16-000057:mdna:58]
[same as prior period, unchanged from 0000926326-15-000035:mdna:60]

[0000926326-16-000057:mdna:59]
[same as prior period, unchanged from 0000926326-15-000035:mdna:61]

[0000926326-16-000057:mdna:60]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 127,895 |  |  | $ | 94,109 |  |  | 33,786 |  |  | 36 | % |
| Percentage of total revenues | 75 | % |  | 81 | % |  |  |  |  |
| Service and other revenues | 43,109 |  |  | 22,112 |  |  | 20,997 |  |  | 95 | % |
| Percentage of total revenues | 25 | % |  | 19 | % |  |  |  |  |
| Total revenues | $ | 171,004 |  |  | $ | 116,221 |  |  | $ | 54,783 |  |  | 47 | % |

[0000926326-16-000057:mdna:61]
Product revenues represented 75% and 81% of total revenues for the three months ended March 31, 2016 and March 31, 2015, respectively. Product revenues increased due to increased sales for Automation and Analytics segment of $35.3 million, partially offset by the decrease of $1.5 million in our Medication Adherence segment. The increase in our Automation and Analytics segment was attributed to the acquired companies, Aesynt, Mach4 and Avantec which were not in the results of operations in the three months ended March 31, 2015, which contributed approximately $30.0 million to the increase in the product revenue compared to three months ended March 31, 2015, and to larger orders received from our customers. The decrease in Medication Adherence segment was attributed to lower sales in the consumable and equipment product sales compared to the three months ended March 31, 2015.

[0000926326-16-000057:mdna:62]
Service and other revenues represented 25% and 19% of total revenues for the three months ended March 31, 2016 and March 31, 2015, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues increased primarily due to an increase from our Automation and Analytics segment of $20.8 million attributed to the acquired companies Aesynt, Mach4 and Avantec, and higher service renewal fees driven mainly by an increase in installed customer base.  The acquired companies contributed $19.8 million to the increase in service revenue of Automation and Analytics segment for the three months ended March 31, 2016 compared to the three months ended March 31, 2015.  Service and other revenues from Medication Adherence segment increased by $0.2 million for the three months ended March 31, 2016 compared to the same period last year.

[0000926326-16-000057:mdna:63]
Our international sales represented 16% of total revenues for both the three months ended March 31, 2016 and March 31, 2015, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-16-000057:mdna:64]
We anticipate our revenues will continue to increase in 2016 compared to the same periods in 2015 as we fulfill our existing orders and based on our growth in bookings in 2015 and in the first three months of 2016, some of which will be recognized as revenue in 2016. Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-16-000057:mdna:65]
[same as prior period, unchanged from 0000926326-15-000035:mdna:71]

[0000926326-16-000057:mdna:66]
[same as prior period, unchanged from 0000926326-15-000035:mdna:56]

[0000926326-16-000057:mdna:67]
[same as prior period, unchanged from 0000926326-15-000035:mdna:72]

[0000926326-16-000057:mdna:68]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 148,945 |  |  | $ | 92,779 |  |  | $ | 56,166 |  |  | 61 | % |
| Percentage of total revenues | 87 | % |  | 80 | % |  |  |  |  |
| Medication Adherence | 22,059 |  |  | 23,442 |  |  | (1,383 | ) |  | (6 | )% |
| Percentage of total revenues | 13 | % |  | 20 | % |  |  |  |  |
| Total revenues | $ | 171,004 |  |  | $ | 116,221 |  |  | $ | 54,783 |  |  | 47 | % |

[0000926326-16-000057:mdna:69]
The increase in Automation and Analytics revenues for the three months ended March 31, 2016 in comparison to the three months ended March 31, 2015 was due to an increase in product revenue which contributed $35.3 million to the increase, and service and other revenues of $20.8 million. The increase in product and service revenue was primarily due to the acquired companies Aesynt, Mach4 and Avantec which accounted for $30.1 million and $19.8 million of the increase in product and service revenue, respectively. Larger deal sizes primarily due to customer conversions also contributed to the increase in product revenue in the three months ended March 31, 2016.

[0000926326-16-000057:mdna:70]
Medication Adherence revenues decreased  $1.4 million for the three months ended March 31, 2016 in comparison to the three months ended March 31, 2015 primarily due to the decrease in the product revenues, particularly in the consumable and equipment product sales.

[0000926326-16-000057:mdna:71]
[same as prior period, unchanged from 0000926326-15-000035:mdna:81]

[0000926326-16-000057:mdna:72]
[same as prior period, unchanged from 0000926326-15-000035:mdna:82]

[0000926326-16-000057:mdna:73]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 77,207 |  |  | $ | 38,852 |  |  | $ | 38,355 |  |  | 99 | % |
| As a percentage of related revenues | 52 | % |  | 42 | % |  |  |  |  |
| Medication Adherence | 13,852 |  |  | 15,684 |  |  | (1,832 | ) |  | (12 | )% |
| As a percentage of related revenues | 63 | % |  | 67 | % |  |  |  |  |
| Total cost of revenues | $ | 91,059 |  |  | $ | 54,536 |  |  | $ | 36,523 |  |  | 67 | % |
| As a percentage of total revenues | 53 | % |  | 47 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 71,738 |  |  | $ | 53,927 |  |  | $ | 17,811 |  |  | 33 | % |
| Automation and Analytics gross margin | 48 | % |  | 58 | % |  |  |  |  |
| Medication Adherence | 8,207 |  |  | 7,758 |  |  | 449 |  |  | 6 | % |
| Medication Adherence gross margin | 37 | % |  | 33 | % |  |  |  |  |
| Total gross profit | $ | 79,945 |  |  | $ | 61,685 |  |  | $ | 18,260 |  |  | 30 | % |
| Total gross margin | 47 | % |  | 53 | % |  |  |  |  |

[0000926326-16-000057:mdna:74]
[same as prior period, unchanged from 0000926326-15-000035:mdna:86]

[0000926326-16-000057:mdna:75]
Cost of Revenues. The increase in cost of revenues for the three months ended March 31, 2016 compared to the three months ended March 31, 2015 was $38.4 million, $28.5 million of which was attributable to product costs and $9.8 million attributable to service costs. Of the $28.5 million increase in product costs, the acquired companies Aesynt, Mach4 and Avantec contributed $24.4 million. The product costs incurred by the acquired companies includes the amortization expense for developed technology, backlog and inventory step-up fair value adjustment of $4.9 million resulting from the purchase accounting. Cost of service revenues increased by $9.9 million primarily due to an increase in costs related to the acquired companies Aesynt, Mach4 and Avantec.

[0000926326-16-000057:mdna:76]
Gross profit for the three months ended March 31, 2016 increased compared to the three months ended March 31, 2015 as a result of increased revenue, partially offset by product mix from a higher volume sales of low margin products, and lower gross margins from the acquired companies Aesynt, Mach4 and Avantec, primarily due to fair value adjustments related to deferred revenue, inventory step-up, and amortization of developed technology and backlog intangible assets.

[0000926326-16-000057:mdna:77]
[same as prior period, unchanged from 0000926326-15-000035:mdna:90]

[0000926326-16-000057:mdna:78]
Cost of Revenues. Cost of revenues decreased by $1.8 million in the three months ended March 31, 2016 compared to the three months ended March 31, 2015. $2.0 million of the decrease was attributable to product costs which was partially offset by increase in cost of revenues of $0.2 million attributable to service costs. The decrease in the three months ended March 31, 2016 of cost of revenue is primarily due to lower volume of revenues and product mix.

[0000926326-16-000057:mdna:79]
Gross profit increased due to changes in our product mix, partially offset by higher manufacturing cost and higher cost of service.

[0000926326-16-000057:mdna:80]
[same as prior period, unchanged from 0000926326-15-000035:mdna:93]

[0000926326-16-000057:mdna:81]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 13,838 |  |  | $ | 8,019 |  |  | $ | 5,819 |  |  | 73 | % |
| As a percentage of total revenues | 8 | % |  | 7 | % |  |  |  |  |
| Selling, general and administrative | 64,255 |  |  | 43,287 |  |  | 20,968 |  |  | 48 | % |
| As a percentage of total revenues | 38 | % |  | 37 | % |  |  |  |  |
| Total operating expenses | $ | 78,093 |  |  | $ | 51,306 |  |  | $ | 26,787 |  |  | 52 | % |
| As a percentage of total revenues | 46 | % |  | 44 | % |  |  |  |  |
| Income from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 19,533 |  |  | $ | 25,338 |  |  | $ | (5,805 | ) |  | (23 | )% |
| Operating margin | 13 | % |  | 27 | % |  |  |  |  |
| Medication Adherence | 2,596 |  |  | 1,417 |  |  | 1,179 |  |  | 83 | % |
| Operating margin | 12 | % |  | 6 | % |  |  |  |  |
| Corporate Expenses | 20,277 |  |  | 16,376 |  |  | 3,901 |  |  | 24 | % |
| Total income from operations | $ | 1,852 |  |  | $ | 10,379 |  |  | $ | (8,527 | ) |  | (82 | )% |
| Total operating margin | 1 | % |  | 9 | % |  |  |  |  |

[0000926326-16-000057:mdna:82]
Research and Development. The increase in research and development expenses of $5.8 million for the three months ended March 31, 2016 compared to three months ended March 31, 2015 was primarily driven by an increase in research and development expenses of $6.4 million in our Automation and Analytics segment, partially offset by a decrease in our Medication Adherence segment research and development expenses of $0.6 million due to lower employee related expenses. The increase in Automation and Analytics segment is attributed to the acquired companies which accounted for $4.2 million of the increase, $0.8 million of higher employees related expenses, and $0.4 million of higher tools and equipment expenses.

[0000926326-16-000057:mdna:83]
Selling, General and Administrative.  The increase in selling, general and administrative expenses for the three months ended March 31, 2016 compared to the three months ended March 31, 2015 was primarily due to increases from our Automation and Analytics segment of $17.2 million and corporate expenses of $3.9 million, partially offset by decreases in Medication Adherence segment of $0.2 million. The increase in our Automation and Analytics segment was attributable to the

[0000926326-16-000057:mdna:84]
acquired companies which accounted for $21.7 million of the increase, partially offset by lower marketing and sales expenses. The increase in the corporate expenses was mainly related to the acquisition related expenses.

[0000926326-16-000057:mdna:85]
Operating Income. Operating income from our Automation and Analytics segment decreased by $5.8 million due to a higher research and development and selling, general and administrative costs of $23.6 million, partially offset by higher gross margin of $17.8 million.

[0000926326-16-000057:mdna:86]
Operating income from our Medication Adherence segment increased due to lower research and development and selling, general and administrative costs and higher gross profit due to product mix, partially off-set by higher manufacturing costs, higher cost of service.

[0000926326-16-000057:mdna:87]
[same as prior period, unchanged from 0000926326-15-000035:mdna:108]

[0000926326-16-000057:mdna:88]
|  | Three months ended |
|  |  |  |  |  | Change in |
|  | March 31, 2016 |  | March 31, 2015 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 59 |  |  | $ | 3,544 |  |  | $ | (3,485 | ) |  | (98 | )% |

[0000926326-16-000057:mdna:89]
Our annual effective tax rate before discrete items was 37.0% and 38.6% for the three months ended March 31, 2016 and March 31, 2015, respectively. The decrease in the estimated annual effective tax rate for the three months ended March 31, 2016 compared to the same period in 2015 was primarily due to a full year inclusion of the Federal research & development tax credit (which was permanently reinstated on December 18, 2015), offset by an increase in non-deductible equity charges.

[0000926326-16-000057:mdna:90]
[same as prior period, unchanged from 0000926326-15-000035:mdna:112]

[0000926326-16-000057:mdna:91]
[same as prior period, unchanged from 0000926326-15-000035:mdna:113]

[0000926326-16-000057:mdna:92]
We had cash and cash equivalents of $53.5 million at March 31, 2016, compared to $82.2 million at December 31, 2015. All of our cash and cash equivalents are invested in demand deposits and money market funds.

[0000926326-16-000057:mdna:93]
Our cash position and working capital at March 31, 2016 and December 31, 2015 were as follows:

[0000926326-16-000057:mdna:94]
|  | March 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Cash | $ | 43,369 |  |  | $ | 72,103 |  |
| Cash equivalents | 10,118 |  |  | 10,114 |  |
| Total | $ | 53,487 |  |  | $ | 82,217 |  |
| Working Capital | $ | 110,662 |  |  | $ | 139,498 |  |

[0000926326-16-000057:mdna:95]
Our ratio of current assets to current liabilities was 1.6:1 at March 31, 2016 compared to 2.1:1 at December 31, 2015.

[0000926326-16-000057:mdna:96]
On January 5, 2016, we entered into a $400 million secured credit facility pursuant to a credit agreement, by and among us, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as sole lead arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200 million term loan facility (the “Term Loan Facility”) and a $200 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). At the closing of the Aesynt Acquisition, we borrowed $255 million in secured debt under the Credit Agreement, consisting of $200 million of term loans and $55 million of revolving loans to complete the acquisition of Aesynt and to pay related fees and expenses. In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes. The Credit Agreement replaces our existing Credit Agreement, dated as of September 25, 2013, by and among the Company, the lenders from time to time party thereto and Wells Fargo Bank, National Association, as administrative agent, as amended.

[0000926326-16-000057:mdna:97]
[same as prior period, unchanged from 0000926326-15-000035:mdna:84]

[0000926326-16-000057:mdna:98]
Loans under the Facilities bear interest, at our option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on our Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on our Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-16-000057:mdna:99]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us and our subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Credit Agreement also includes financial covenants requiring us not to exceed a maximum consolidated total leverage ratio of 3.00:1 (subject to certain exceptions) and to maintain a minimum fixed charge coverage ratio of 1.50:1.

[0000926326-16-000057:mdna:100]
As of March 31, 2016, the outstanding balance from the facilities was $236.5 million, including accrued interest of $1.5 million. We were in full compliance with all covenants.

[0000926326-16-000057:mdna:101]
[same as prior period, unchanged from 0000926326-15-000035:mdna:124]

[0000926326-16-000057:mdna:102]
[same as prior period, unchanged from 0000926326-15-000035:mdna:125]

[0000926326-16-000057:mdna:103]
Our 2014 Stock Repurchase Program had a total of $4.9 million remaining for future repurchases as of March 31, 2016.

[0000926326-16-000057:mdna:104]
In accordance with the Avantec share purchase agreement, we may pay out a potential earn-out payment of $3.0 million payable after December 31, 2016, based on future bookings. The fair value of these earn-out payments as of March 31, 2016 was $2.9 million. Pursuant to the terms of the agreement we also held back $1.8 million from the purchase consideration towards any future indemnification claims that we may make by fourth quarter of 2016. We will be making payments under the credit facilities for next five years. Refer to below, Contractual Obligations table for details on the payments for the credit facilities.

[0000926326-16-000057:mdna:105]
Based on our current business plan and revenue backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under the Facilities will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-16-000057:mdna:106]
[same as prior period, unchanged from 0000926326-15-000035:mdna:129]

[0000926326-16-000057:mdna:107]
[same as prior period, unchanged from 0000926326-15-000035:mdna:130]

[0000926326-16-000057:mdna:108]
|  | Three Months Ended |
|  | March 31, 2016 |  | March 31, 2015 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 21,787 |  |  | $ | 11,314 |  |
| Investing activities | (279,863 | ) |  | (4,108 | ) |
| Financing activities | 229,046 |  |  | 6,575 |  |
| Effect of exchange rate changes on cash and cash equivalents | 300 |  |  | (116 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | (28,730 | ) |  | $ | 13,665 |  |

[0000926326-16-000057:mdna:109]
[same as prior period, unchanged from 0000926326-15-000035:mdna:132]

[0000926326-16-000057:mdna:110]
[same as prior period, unchanged from 0000926326-15-000035:mdna:133]

[0000926326-16-000057:mdna:111]
Net cash provided by operating activities was $21.8 million for the three months ended March 31, 2016, primarily as a result of $0.4 million in net loss adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $14.5 million, share-based compensation expense of $3.9 million and deferred income taxes of $1.0 million. The cash inflow attributed to changes in assets and liabilities includes an increase in the deferred revenue of $12.7 million due to timing of orders and revenue being recognized for installed product, an increase in accrued liabilities of $4.5 million due to timing of payments to employees related liabilities, a decrease in the prepaid expenses of $2.0 million primarily due to prepaid income taxes of $1.8 million, an increase in the accounts payables of $1.6 million due to timing of payments, and decreases in other current assets of $0.3 million. These amounts were partially offset by increases in long-term investment in sales-type leases of $8.9 million due to two significant lease transactions entered into during the quarter, an increase in inventories of $5.4 million to support forecasted sales, an increase in accounts receivable of $1.2 million due to increased product shipments late in the quarter, and decreased in the other-long term liabilities by $2.7 million.

[0000926326-16-000057:mdna:112]
Net cash provided by operating activities was $11.3 million for the three months ended March 31, 2015, primarily as a result of $6.3 million in net income adjusted for non-cash items, including depreciation and amortization expense of $5.7 million and share-based compensation expense of $3.7 million, and an increase in accrued liabilities of $2.7 million. These amounts were partially offset by an increase in accounts receivable of $5.6 million, an increase in inventories of $1.9 million, a decrease in deferred gross profit of $4.2 million and a decrease in deferred service revenue of $2.3 million.

[0000926326-16-000057:mdna:113]
[same as prior period, unchanged from 0000926326-15-000035:mdna:137]

[0000926326-16-000057:mdna:114]
Net cash used in investing activities was $279.9 million for the three months ended March 31, 2016, $271.5 million of which was attributable to the acquisition of Aesynt, and capital expenditures related to purchases of property and equipment and software development of software costs for external use and purchases of intangibles of $4.3 million and $4.1 million, respectively.

[0000926326-16-000057:mdna:115]
Net cash used in investing activities was $4.1 million for the three months ended March 31, 2015, primarily due to payments of $1.1 million for property and equipment and $3.0 million to develop software for external use.

[0000926326-16-000057:mdna:116]
[same as prior period, unchanged from 0000926326-15-000035:mdna:140]

[0000926326-16-000057:mdna:117]
Net cash provided by financing activities was $229.0 million for the three months ended March 31, 2016 as a result of proceeds from term loan and revolving credit facilities of $247.1 million net of deferred issuance cost of $7.9 million, $5.1 million in proceeds from employee stock option exercises and employee stock plan purchases, and $0.2 million in excess tax benefits from employee stock plans.  The increase in cash provided from financing activities was partially offset by repayment of $20.0 million of the revolving credit facility, and payment of contingent consideration of $3.0 million related to the Avantec acquisition.

[0000926326-16-000057:mdna:118]
Net cash provided by financing activities was $6.6 million for the three months ended March 31, 2015 as a result of $6.2 million in proceeds from employee stock option exercises and $1.2 million in excess tax benefits from employee stock plans, offset by $0.8 million in employees' taxes paid related to restricted stock units.

[0000926326-16-000057:mdna:119]
[same as prior period, unchanged from 0000926326-15-000035:mdna:143]

[0000926326-16-000057:mdna:120]
There have been no significant changes during the three months ended March 31, 2016 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2015.

[0000926326-16-000057:mdna:121]
We had $329.2 million in contractual commitments to third parties for non-cancelable operating leases, commitments to contract manufacturers and suppliers,other purchase commitments and term loan and revolving credit facility as of March 31, 2016 as follows:

[0000926326-16-000057:mdna:122]
|  | Payments due by period |
|  | Total |  | Remainder of 2016 |  | 2017 and 2018 |  | 2019 and 2020 |  | 2021 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 55,286 |  |  | $ | 7,996 |  |  | $ | 20,361 |  |  | $ | 16,059 |  |  | $ | 10,870 |  |
| Purchase obligations (2) | 38,937 |  |  | 38,937 |  |  | — |  |  | — |  |  | — |  |
| Term loan facility | 200,000 |  |  | 7,500 |  |  | $ | 27,500 |  |  | $ | 47,500 |  |  | $ | 117,500 |  |
| Revolving credit facility | 35,000 |  |  | — |  |  | — |  |  | — |  |  | 35,000 |  |
| Total (3) | $ | 329,223 |  |  | $ | 54,433 |  |  | $ | 47,861 |  |  | $ | 63,559 |  |  | $ | 163,370 |  |

[0000926326-16-000057:mdna:123]
[same as prior period, unchanged from 0000926326-15-000035:mdna:147]

[0000926326-16-000057:mdna:124]
[same as prior period, unchanged from 0000926326-15-000035:mdna:148]

[0000926326-16-000057:mdna:125]
[same as prior period, unchanged from 0000926326-15-000035:mdna:149]

[0000926326-16-000057:mdna:126]
| (3) | We have recorded $9.9 million for uncertain tax positions under long-term liabilities as of March 31, 2016 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, $9.9 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-16-000057:mdna:127]
Refer to Note 10, Commitments, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-16-000057:mdna:128]
[same as prior period, unchanged from 0000926326-15-000035:mdna:152]

[0000926326-16-000057:mdna:129]
As of March 31, 2016, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
