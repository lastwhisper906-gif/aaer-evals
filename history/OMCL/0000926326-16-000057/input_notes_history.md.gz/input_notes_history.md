# OMCL note change history — 0000926326-15-000035 → 0000926326-16-000057


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2016-05-06):
[0000926326-16-000057:note_history:1]
Commitments and Contingencies

- added (2016-05-06):
[0000926326-16-000057:note_history:2]
Lease commitments

- added (2016-05-06):
[0000926326-16-000057:note_history:3]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment.  At March 31, 2016, the minimum future payments on non-cancelable operating leases were as follows:

- added (2016-05-06):
[0000926326-16-000057:note_history:4]
|  | (In thousands) |
| Remaining nine months of 2016 | $ | 7,996 |  |
| 2017 | 10,441 |  |
| 2018 | 9,921 |  |
| 2019 | 9,802 |  |
| 2020 | 6,256 |  |
| Thereafter | 10,870 |  |
| Total minimum future lease payments | $ | 55,286 |  |

- added (2016-05-06):
[0000926326-16-000057:note_history:5]
Purchase obligations

- added (2016-05-06):
[0000926326-16-000057:note_history:6]
During the course of the business, the Company issues purchase orders based on its current manufacturing needs.  At March 31, 2016, the Company had non-cancelable purchase commitments of $38.9 million, which are expected to be paid within the next twelve months.

- added (2016-05-06):
[0000926326-16-000057:note_history:7]
Legal Proceedings

- added (2016-05-06):
[0000926326-16-000057:note_history:8]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

- added (2016-05-06):
[0000926326-16-000057:note_history:9]
The Company’s pending legal proceeding as of March 31, 2016 was as follows:

- added (2016-05-06):
[0000926326-16-000057:note_history:10]
On September 12, 2014, MV Circuit Design, Inc., an Ohio company ("MV Circuit"), brought an action to correct the inventorship of certain patents owned by the Company, as well as related state-law claims against the Company in the Northern District of Ohio (Case No. 1:14-cv-02028-DAP) regarding allegations of fraud in the filing and prosecution of U.S. Patent Nos. 8,180,485, 8,773,270, 8,812,153, PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505 (the “Action”). On November 14, 2014, the Company filed a Motion to Dismiss the Action. MV Circuit responded on January 29, 2015, and the Company replied in support of its Motion to Dismiss on February 17, 2015. On March 24, 2015, the Court issued an Order granting in part and denying in part the Motion to Dismiss. Specifically, the Court granted the Company's Motion to Dismiss with respect to Counts 4, 5, and 6 (declaratory judgments regarding PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505) and count 13 (civil conspiracy). The Court denied the Company's Motion to Dismiss with respect to Count 9 (fraud), Count 7 (fraudulent concealment) and Count 8 (negligent misrepresentation). The Company filed an Answer to the Complaint on April 8, 2015. Following an initial Case Management Conference on April 22, 2015, the Court ordered MV Circuit and the Company to make a limited initial production of documents. The parties completed this initial document production and have held further conference calls with the Court to report on their settlement negotiations.  During a conference call held on February 11, 2016, the Court set a deadline of March 14, 2016 for the parties to either file notification of settlement or a proposed litigation schedule. The parties have requested three extensions of the March 14th deadline, with the current deadline requested for June 10, 2016.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0000926326-16-000057:note_history:11]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication, supply control systems and medication adherence solutions which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States and Europe. "Omnicell" "our", "us", "we" or the "Company" collectively refer to Omnicell, Inc. and its subsidiaries.
  (was, 2015-11-06, similarity 0.9354):
[0000926326-15-000035:note_history:11]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication, supply control systems and medication adherence solutions which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States and Canada. "Omnicell," "our," "us," "we," or the "Company" collectively refer to Omnicell, Inc. and its subsidiaries.

- changed (2016-05-06):
[0000926326-16-000057:note_history:12]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2016 and December 31, 2015, the results of their operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2016 and March 31, 2015. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2015 filed with the SEC on February 26, 2016. The Company's results of operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2016 are not necessarily indicative of results that may be expected for the year ending December 31, 2016, or for any future period.
  (was, 2015-11-06, similarity 0.7574):
[0000926326-15-000035:note_history:12]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2015 and December 31, 2014, the results of their operations, comprehensive income and cash flows for the three and nine months ended September 30, 2015 and September 30, 2014. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in our annual report on Form 10-K for the year ended December 31, 2014 filed with the SEC on March 30, 2015. Our results of operations, comprehensive income and cash flows for the three and nine months ended September 30, 2015 are not necessarily indicative of results that may be expected for the year ending December 31, 2015, or for any future period.

- added (2016-05-06):
[0000926326-16-000057:note_history:13]
On January 5, 2016, the Company completed the acquisition of all of the membership interests of Aesynt Holding Coöperatief U.A. ("Aesynt"). The significant accounting policies of Aesynt have been aligned to conform to those accounting policies of Omnicell, and the consolidated financial statements include the results of operations of Aesynt commencing as of the acquisition date.

- added (2016-05-06):
[0000926326-16-000057:note_history:14]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company's Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company's critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, accounts receivable and notes receivable (investment in sales-type leases), capitalized software development costs, valuation of goodwill and purchased intangibles and long-lived assets, fair value of assets acquired and liabilities assumed in business combinations, and accounting for income taxes.

- added (2016-05-06):
[0000926326-16-000057:note_history:15]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level.  Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

- added (2016-05-06):
[0000926326-16-000057:note_history:16]
The operating results of the recently acquired Aesynt business is included in the Company's Automation and Analytics reporting segment.

- added (2016-05-06):
[0000926326-16-000057:note_history:17]
Financial instruments that may potentially subject the Company to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of the Company's accounts receivable are derived from sales to customers for commercial applications. The Company performs ongoing credit evaluations of its customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. The Company maintains reserves for potential credit losses. The Company's products are broadly distributed and there were no customers that accounted for more than 10% of its accounts receivable as of March 31, 2016 and December 31, 2015. The Company believes that it has no significant concentrations of credit risk as of March 31, 2016.

- added (2016-05-06):
[0000926326-16-000057:note_history:18]
Recently adopted authoritative guidance

- changed (2016-05-06):
[0000926326-16-000057:note_history:19]
In July 2015, the FASB issued ASU No. 2015-11, Simplifying the Measurement of Inventory. The new guidance changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. It applies to entities that measure inventory using a method other than last-in, first-out (LIFO) and the retail inventory method (RIM). The new guidance is effective for fiscal years beginning after December 15, 2016. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three months ended March 31, 2016.
  (was, 2015-11-06, similarity 0.6948):
[0000926326-15-000035:note_history:19]
In July 2015, the FASB issued ASU No. 2015-11, Simplifying the Measurement of Inventory. The new guidance changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. It applies to entities that measure inventory using a method other than last-in, first-out (LIFO) and the retail inventory method (RIM). The new guidance will be effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years and should be applied prospectively. Early adoption is permitted as of the beginning of an interim or annual reporting period. We are currently evaluating the impact of the adoption of this accounting standard update on our consolidated financial position or results of operations.

- added (2016-05-06):
[0000926326-16-000057:note_history:20]
In September 2015, the FASB issued ASU No. 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments ("ASU 2015-16"). This ASU requires adjustments to provisional amounts that are identified during the measurement period of a business combination to be recognized in the reporting period in which the adjustment amounts are determined. An acquirer is no longer required to revise comparative information for prior periods as if the accounting for the business combination had been completed as of the acquisition date. The provisions of ASU 2015-16 are effective for reporting periods beginning after December 15, 2015. The adoption of this accounting standard update did not have any impact on the Company's consolidated financial position or results of operations for the three months ended March 31, 2016.

- added (2016-05-06):
[0000926326-16-000057:note_history:21]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted for any entity in any interim or annual period. If an entity early adopts the amendments in an interim period, any adjustments are reflected as of the beginning of the fiscal year that includes that interim period. An entity that elects early adoption must adopt all of the amendments in the same period. The Company is currently in the process of evaluating the impact of the adoption of ASU 2016-09 on its consolidated financial statements.

- removed (2016-05-06):
[0000926326-15-000035:note_history:22]
On April 21, 2015, we completed the acquisition of Mach4 Automatisierungstechnik GmbH (“Mach4”), a privately held German limited liability company with registered office in Bochum, Germany. On April 30, 2015, we acquired the remaining 85% of the issued and outstanding ordinary shares of Avantec Healthcare Limited (“Avantec”) not already held by Omnicell. The consolidated financial statements include the results of operations of Mach4 and Avantec commencing as of their respective acquisition dates.

- removed (2016-05-06):
[0000926326-15-000035:note_history:23]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in our Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, accounts receivable and notes receivable (net investment in sales-type leases), valuation of goodwill, purchased intangibles and long-lived assets, and accounting for income taxes.

- removed (2016-05-06):
[0000926326-15-000035:note_history:24]
As previously disclosed, since the first quarter of 2015, we modified the segment presentation to reflect the changes in how our Chief Operating Decision Maker (“CODM”) reviews the segments and the overall business. See Note 14, Segment Information, for additional information on our segment reporting change.

- removed (2016-05-06):
[0000926326-15-000035:note_history:25]
Our CODM is our Chief Executive Officer. With the increase in completed acquisitions in the last two years, our CODM changed how the financial information was reviewed to exclude general corporate-level costs that are not specific to either of the reporting segments when evaluating the operating results of each segment. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

- removed (2016-05-06):
[0000926326-15-000035:note_history:26]
The historical information presented has been retrospectively adjusted to reflect the modified segment reporting. Our CODM allocates resources and evaluates the performance of our segments using information about its revenues, gross profit and income from operations, excluding certain costs which are managed separately at the corporate level. We enhanced our segment reporting structure to match our operating structure based on how our CODM views the business and allocates resources, beginning in the first quarter of 2015.

- removed (2016-05-06):
[0000926326-15-000035:note_history:27]
Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there were no customers that accounted for more than 10% of our accounts receivable as of September 30, 2015 and December 31, 2014. We believe that we have no significant concentrations of credit risk as of September 30, 2015.

- removed (2016-05-06):
[0000926326-15-000035:note_history:28]
Significant accounting policies

- removed (2016-05-06):
[0000926326-15-000035:note_history:29]
There have been no material changes in our significant accounting policies for the three and nine months ended September 30, 2015, as compared to the significant accounting policies described in our annual report on Form 10-K for the year ended December 31, 2014.

- removed (2016-05-06):
[0000926326-15-000035:note_history:30]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers. Under the new guidance, an entity is required to recognize an amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The original effective date for the ASU would have required the Company to adopt the standard beginning in its first quarter of fiscal year 2017. In July 2015, the FASB voted to amend ASU No. 2014-09 by approving a one-year deferral of the effective date as well as providing the option to early adopt the standard on the original effective date. Accordingly, we may adopt the standard in its first quarter of fiscal year 2018. The new revenue guidance may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. We are currently evaluating the impact of the adoption of this accounting standard update on our consolidated financial position or results of operations.

- removed (2016-05-06):
[0000926326-15-000035:note_history:31]
In September 2015, the FASB issued ASU No. 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments. This ASU requires adjustments to provisional amounts that are identified during the measurement period of a business combination to be recognized in the reporting period in which the adjustment amounts are determined. Acquirers are no longer required to revise comparative information for prior periods as if the accounting for the business combination had been completed as of the acquisition date. The provisions of ASU 2015-16 are effective for reporting periods beginning after December 15, 2015. We are currently evaluating the impact of the adoption of this accounting standard update on our consolidated financial position or results of operations.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2016-05-06):
[0000926326-16-000057:note_history:32]
Debt

- added (2016-05-06):
[0000926326-16-000057:note_history:33]
On January 5, 2016, the Company entered into a $400 million senior secured credit facility pursuant to a credit agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200 million (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

- added (2016-05-06):
[0000926326-16-000057:note_history:34]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the 2016 Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

- added (2016-05-06):
[0000926326-16-000057:note_history:35]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

- added (2016-05-06):
[0000926326-16-000057:note_history:36]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio.  The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.  The Company was in full compliance with all covenants as of March 31, 2016.

- added (2016-05-06):
[0000926326-16-000057:note_history:37]
On January 5, 2016, the Company borrowed the full $200 million under the Term Loan Facility and $55 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses. In connection with these Facilities, the Company incurred $7.9 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021.

- added (2016-05-06):
[0000926326-16-000057:note_history:38]
The components of the Company’s debt obligations as of March 31, 2016 and December 31, 2015 are as follows:

- added (2016-05-06):
[0000926326-16-000057:note_history:39]
|  | December 31, 2015 | Additions | Repayment/amortization | March 31, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | — |  | $ | 200,000 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (20,000 | ) | 235,000 |  |
| Less: Deferred issuance cost |  | (7,949 | ) | 397 |  | (7,552 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (19,603 | ) | 227,448 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 219,038 |  |

- added (2016-05-06):
[0000926326-16-000057:note_history:40]
(1) The fair value of total debt under the facilities approximates the book value as of March 31, 2016.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2016-05-06):
[0000926326-16-000057:note_history:41]
The components of the Company’s debt obligations as of March 31, 2016 and December 31, 2015 are as follows:

- added (2016-05-06):
[0000926326-16-000057:note_history:42]
|  | December 31, 2015 | Additions | Repayment/amortization | March 31, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | — |  | $ | 200,000 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (20,000 | ) | 235,000 |  |
| Less: Deferred issuance cost |  | (7,949 | ) | 397 |  | (7,552 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (19,603 | ) | 227,448 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 219,038 |  |

- added (2016-05-06):
[0000926326-16-000057:note_history:43]
(1) The fair value of total debt under the facilities approximates the book value as of March 31, 2016.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2016-05-06):
[0000926326-16-000057:note_history:44]
During the second quarter of 2016, the Company integrated its Sales and Field teams in North America to better serve its customers which resulted in a reduction in headcount of 34 employees. Accordingly, the Company will accrue approximately $1.5 million of restructuring charges in the second quarter ending June 30, 2016, based on agreements with terminated employees covering salary and benefit continuation.

- removed (2016-05-06):
[0000926326-15-000035:note_history:45]
On October 29, 2015, we entered into a securities purchase agreement (the “Securities Purchase Agreement”) with Aesynt Holding, L.P., Aesynt, Ltd. (together with Aesynt Holding, L.P., the “Sellers”) and Aesynt Coöperatief U.A. (“Aesynt”).  Pursuant to the terms and conditions of the Securities Purchase Agreement, we will acquire from the Sellers, and the Sellers will sell to Omnicell, all of the outstanding interests of Aesynt on the closing date (such acquisition, the “Aesynt Acquisition”). Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, IV sterile preparation robotics and software, including software related to medication management. The contemplated total aggregate consideration is $275.0 million, in cash, plus cash on hand at signing minus indebtedness at close, or approximately $217.5 million, subject to certain adjustments at closing as provided for in the Securities Purchase Agreement. The closing of the acquisition is subject to certain closing conditions, including the expiration or termination of the applicable waiting period under the Hart-Scott-Rodino Antitrust Improvement Act ("HSR") of 1976, as amended.

- removed (2016-05-06):
[0000926326-15-000035:note_history:46]
In connection with the Securities Purchase Agreement, we entered into a commitment letter with Wells Fargo Bank, National Association (“Wells Fargo Bank”) and Wells Fargo Securities, LLC (“Wells Fargo Securities” and, together with Wells Fargo Bank, the “Commitment Parties”) on October 29, 2015, pursuant to which Wells Fargo Bank has committed to provide $300.0 million of senior secured credit facilities consisting of (a) a $200.0 million term loan facility, and (b) a $100.0 million revolving credit facility (collectively, the “Senior Credit Facilities”), a portion of which, together with our existing cash on hand, would be used to (i) refinance the loans under our existing senior secured credit facility, if any, and Aesynt’s existing senior secured credit facility, (ii) pay the purchase price for the Aesynt Acquisition, and (iii) pay any fees and expenses incurred in connection with any of the foregoing. The commitment to provide the loans under the Senior Credit Facilities is subject to certain conditions, including the negotiation of definitive documentation for the Senior Credit Facilities and other customary closing conditions.
