# OMCL 8-K — 0000926326-16-000054 filed 2016-04-28

## item codes, every 8-K on or before 2016-05-06

- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2016-05-06

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-16-000054:8k_2_02:1]
EX-99.1
2
exhibit991q116.htm
EXHIBIT 99.1

[0000926326-16-000054:8k_2_02:2]
Exhibit

[0000926326-16-000054:8k_2_02:3]
Exhibit 99.1

[0000926326-16-000054:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6180 |  | Mountain View, CA 94043 |
| Peter.kuipers@omnicell.com |  |  |

[0000926326-16-000054:8k_2_02:5]
Omnicell Achieves Record Revenue in the First Quarter 2016

[0000926326-16-000054:8k_2_02:6]
Record GAAP revenue of $171.0 million representing 47% year over year growth

[0000926326-16-000054:8k_2_02:7]
Non-GAAP diluted EPS of $0.35 representing 21% year over year growth

[0000926326-16-000054:8k_2_02:8]
Completion of the Aesynt Acquisition

[0000926326-16-000054:8k_2_02:9]
MOUNTAIN VIEW, Calif. -- April 28, 2016 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its first quarter ended March 31, 2016.

[0000926326-16-000054:8k_2_02:10]
GAAP results: Revenue for the first quarter of 2016 was $171.0 million, up $40.7 million or 31.2% from the fourth quarter of 2015, and up $54.8 million or 47.1% from the first quarter of 2015.

[0000926326-16-000054:8k_2_02:11]
First quarter 2016 net loss as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $(0.4) million, or $(0.01) per diluted share. This compares to GAAP net income of $7.7 million, or $0.21 per diluted share, for the fourth quarter of 2015, and GAAP net income of $6.3 million, or $0.17 per diluted share, for the first quarter of 2015.  Omnicell completed its acquisition of Aesynt Holding Coöperatief U.A. ("Aesynt') on January 5, 2016 and its results of operations are included in Omnicell's Condensed Consolidated Statement of Operations as of that date.

[0000926326-16-000054:8k_2_02:12]
Non-GAAP results: Non-GAAP revenue for the first quarter of 2016 was $173.7 million, up $43.4 million or 33.3% from the fourth quarter of 2015, and up $57.4 million or 49.4% from the first quarter of 2015.

[0000926326-16-000054:8k_2_02:13]
Non-GAAP net income for the first quarter of 2016 was $12.9 million, or $0.35 per diluted share, excluding $3.9 million of stock-based compensation expense, $5.7 million, net of tax effect of $3.5 million, of intangible assets amortization expense, $1.4 million, net of tax effect of $0.9 million of acquisition related expenses for Aesynt acquisition, and $0.6 million, net of tax effect of $0.3 million of inventory fair value adjustments.  Non-GAAP net income includes the effect of a deferred revenue fair value adjustment of $1.7 million, net of tax effect of $1.0 million. This compares to fourth quarter 2015 non-GAAP net income of $14.4 million, or $0.40 per diluted share, which excluded $3.7 million of stock-based compensation expense, $1.2 million, net of tax effect of $0.7 million, of intangible assets amortization expense, and $2.0 million, net of tax effect of $0.9 million, for acquisition related expenses for the Aesynt acquisition. Non-GAAP net income for the first quarter of 2015 was $10.8 million, or $0.29 per diluted share, which excluded $3.7 million of stock-based compensation expense and $0.8 million, net of tax effect of $0.4 million, of amortization expense for all intangible assets associated with past acquisitions.

[0000926326-16-000054:8k_2_02:14]
"Omnicell’s first quarter of 2016 was marked by record revenues and the completion of our acquisition of Aesynt,” said Randall Lipps, President, CEO and Chairman. “I am pleased to report continued momentum with a strong contribution from new customer orders as we begin to realize the strength that our expanded portfolio can deliver. The company is well positioned to take advantage of the great opportunities ahead."

[0000926326-16-000054:8k_2_02:15]
Second quarter 2016 Guidance

[0000926326-16-000054:8k_2_02:16]
For the second quarter of 2016, the company expects Non-GAAP revenue to be between $168 million and $175 million and Non-GAAP EPS to be between $0.30 and $0.34 per share.

[0000926326-16-000054:8k_2_02:17]
The above guidance is inclusive of the Aesynt acquisition.

[0000926326-16-000054:8k_2_02:18]
Reporting Segments

[0000926326-16-000054:8k_2_02:19]
Omnicell evaluates its reportable segments in accordance with the authoritative guidance on segment reporting. The company's Chief Executive Officer is the company's Chief Operating Decision Maker ("CODM") pursuant to the guidance. The CODM allocates resources to the segments based on their business prospects, competitive factors, revenue and operating results.  Omnicell has the following reportable segments: Automation & Analytics, and Medication Adherence. The financial results of the Aesynt acquisition acquired in Q1 2016 are included in the Automation & Analytics reportable segment.

[0000926326-16-000054:8k_2_02:20]
Certain corporate-level costs which include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses are excluded from the reportable segment financial results.

[0000926326-16-000054:8k_2_02:21]
Omnicell Conference Call Information

[0000926326-16-000054:8k_2_02:22]
Omnicell will hold a conference call today, Thursday, April 28, 2016 at 1:30 p.m. PT to discuss first quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 96241728. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on May 28, 2016. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 96241728.

[0000926326-16-000054:8k_2_02:23]
About Omnicell

[0000926326-16-000054:8k_2_02:24]
Since 1992, Omnicell (NASDAQ: OMCL) has been creating new efficiencies to improve patient care, anywhere it is delivered. Omnicell is a leading supplier of comprehensive automation and business analytics software for patient-centric medication and supply management across the entire health care continuum--from the acute care hospital setting, to post-acute skilled nursing and long-term care facilities, to the patient's home.

[0000926326-16-000054:8k_2_02:25]
Over 4,000 customers worldwide have utilized Omnicell automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence and improve patient safety. The recent acquisition of Aesynt adds distinct capabilities, particularly in central pharmacy and IV robotics, creating the broadest medication management product portfolio in the industry.

[0000926326-16-000054:8k_2_02:26]
The Omnicell SureMed solution provides innovative medication adherence packaging to help reduce costly hospital readmissions. In addition, these solutions enable approximately 7,000 institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-16-000054:8k_2_02:27]
For more information about Omnicell, please visit www.omnicell.com.

[0000926326-16-000054:8k_2_02:28]
Forward-Looking Statements

[0000926326-16-000054:8k_2_02:29]
Use of Non-GAAP Financial Information

[0000926326-16-000054:8k_2_02:30]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-16-000054:8k_2_02:31]
Our non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-16-000054:8k_2_02:32]
a)  Stock-based compensation expense impact of Accounting Standards Codification (ASC) 718. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-16-000054:8k_2_02:33]
b) Intangible assets amortization from business acquisitions. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-16-000054:8k_2_02:34]
c) Amortization of debt issuance cost. Debt issuance cost represents costs associated with the issuance of new Term Loan and Revolving Line of Credit facilities. The cost includes underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-16-000054:8k_2_02:35]
d) Acquisition accounting impact related to deferred revenue. In connection with our acquisition of Aesynt, business combination rules require us to account for the fair values of arrangements for which acceptance has not been obtained, and post installation support has not been provided in our purchase accounting. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0000926326-16-000054:8k_2_02:36]
e) Inventory fair value adjustments. In connection with our acquisition of Aesynt, business combination rules require us to account for the fair values of inventory acquired in our purchase accounting. The non-GAAP adjustment to our Cost of Revenues is intended to include the impact of such adjustment. We believe the adjustment is useful as a measure of the ongoing performance of our business.

[0000926326-16-000054:8k_2_02:37]
f) Acquisitions related expenses. We excluded from our non-GAAP results the expenses which are related to the recent acquisitions. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition related expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of less acquisitive peer companies. Further, these expenses are not considered by management to reflect the core performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-16-000054:8k_2_02:38]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans.

[0000926326-16-000054:8k_2_02:39]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-16-000054:8k_2_02:40]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0000926326-16-000054:8k_2_02:41]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0000926326-16-000054:8k_2_02:42]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0000926326-16-000054:8k_2_02:43]
4

[0000926326-16-000054:8k_2_02:44]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-16-000054:8k_2_02:45]
Set forth below are additional reasons why share-based compensation expense related to ASC 718 is excluded from our non-GAAP financial measures:

[0000926326-16-000054:8k_2_02:46]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-16-000054:8k_2_02:47]
ii)  We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-16-000054:8k_2_02:48]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as excluding certain non-GAAP adjustments.

[0000926326-16-000054:8k_2_02:49]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-16-000054:8k_2_02:50]
·  Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-16-000054:8k_2_02:51]
·  Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-16-000054:8k_2_02:52]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-16-000054:8k_2_02:53]
Omnicell, Inc.

[0000926326-16-000054:8k_2_02:54]
Condensed Consolidated Statements of Operations

[0000926326-16-000054:8k_2_02:55]
(Unaudited, in thousands, except per share data)

[0000926326-16-000054:8k_2_02:56]
|  | Three Months Ended |
|  | March 31, 2016 |  | December 31, 2015 |  | March 31, 2015 |
| Revenues: |  |  |  |  |  |
| Product | $ | 127,895 |  |  | $ | 104,193 |  |  | $ | 94,109 |  |
| Services and other revenues | 43,109 |  |  | 26,123 |  |  | 22,112 |  |
| Total revenues | 171,004 |  |  | 130,316 |  |  | 116,221 |  |
| Cost of revenues: |  |  |  |  |  |
| Cost of product revenues | 71,918 |  |  | 55,099 |  |  | 45,416 |  |
| Cost of services and other revenues | 19,141 |  |  | 10,137 |  |  | 9,120 |  |
| Total cost of revenues | 91,059 |  |  | 65,236 |  |  | 54,536 |  |
| Gross profit | 79,945 |  |  | 65,080 |  |  | 61,685 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 13,838 |  |  | 9,219 |  |  | 8,019 |  |
| Selling, general and administrative | 64,255 |  |  | 43,891 |  |  | 43,287 |  |
| Total operating expenses | 78,093 |  |  | 53,110 |  |  | 51,306 |  |
| Income from operations | 1,852 |  |  | 11,970 |  |  | 10,379 |  |
| Interest and other income (expense), net | (2,171 | ) |  | (753 | ) |  | (517 | ) |
| Income before provision for income taxes | (319 | ) |  | 11,217 |  |  | 9,862 |  |
| Provision for income taxes | 59 |  |  | 3,562 |  |  | 3,544 |  |
| Net (loss) income | $ | (378 | ) |  | $ | 7,655 |  |  | $ | 6,318 |  |
| Net (loss) income per share: |  |  |  |  |  |
| Basic | $ | (0.01 | ) |  | $ | 0.22 |  |  | $ | 0.18 |  |
| Diluted | $ | (0.01 | ) |  | $ | 0.21 |  |  | $ | 0.17 |  |
| Weighted average shares outstanding: |  |  |  |  |  |
| Basic | 35,740 |  |  | 35,482 |  |  | 36,024 |  |
| Diluted | 35,740 |  |  | 36,172 |  |  | 36,914 |  |

[0000926326-16-000054:8k_2_02:57]
6

[0000926326-16-000054:8k_2_02:58]
Omnicell, Inc.

[0000926326-16-000054:8k_2_02:59]
Condensed Consolidated Balance Sheets

[0000926326-16-000054:8k_2_02:60]
(Unaudited, in thousands)

[0000926326-16-000054:8k_2_02:61]
|  | March 31, 2016 |  | December 31, 2015 |
| ASSETS |
| Current assets: |  |  |  |  |
| Cash and cash equivalents | $ | 53,487 |  |  | $ | 82,217 |  |
| Accounts receivable, net | 153,199 |  |  | 107,957 |  |
| Inventories | 71,914 |  |  | 46,594 |  |
| Prepaid expenses | 21,855 |  |  | 19,586 |  |
| Other current assets | 9,853 |  |  | 7,774 |  |
| Total current assets | 310,308 |  |  | 264,128 |  |
| Property and equipment, net | 42,208 |  |  | 32,309 |  |
| Long-term investment in sales-type leases, net | 21,037 |  |  | 14,484 |  |
| Goodwill | 312,511 |  |  | 147,906 |  |
| Intangible assets, net | 206,261 |  |  | 89,665 |  |
| Long-term deferred tax assets | 2,638 |  |  | 2,361 |  |
| Other long-term assets | 28,809 |  |  | 27,894 |  |
| Total assets | $ | 923,772 |  |  | $ | 578,747 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |
| Accounts payable | $ | 32,142 |  |  | $ | 22,646 |  |
| Accrued compensation | 31,918 |  |  | 18,195 |  |
| Accrued liabilities | 34,903 |  |  | 30,133 |  |
| Long-term debt, current portion, net | 8,410 |  |  | — |  |
| Deferred revenue, net | 92,273 |  |  | 53,656 |  |
| Total current liabilities | 199,646 |  |  | 124,630 |  |
| Long-term deferred revenue | 17,820 |  |  | 17,975 |  |
| Long-term deferred tax liabilities | 64,984 |  |  | 21,822 |  |
| Other long-term liabilities | 11,771 |  |  | 11,932 |  |
| Long-term debt, net | 219,046 |  |  | — |  |
| Total liabilities | 513,267 |  |  | 176,359 |  |
| Total stockholders’ equity | 410,505 |  |  | 402,388 |  |
| Total liabilities and stockholders’ equity | $ | 923,772 |  |  | $ | 578,747 |  |

[0000926326-16-000054:8k_2_02:62]
Omnicell, Inc.

[0000926326-16-000054:8k_2_02:63]
Condensed Consolidated Statements of Cash Flows

[0000926326-16-000054:8k_2_02:64]
(Unaudited, in thousands)

[0000926326-16-000054:8k_2_02:65]
|  | Three months ended March 31, |
|  | 2016 |  | 2015 |
| Operating Activities |  |  |  |
| Net (loss) income | $ | (378 | ) |  | $ | 6,318 |  |
| Adjustments to reconcile net (loss) income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 14,473 |  |  | 5,711 |  |
| Loss on disposal of fixed assets | 13 |  |  | 4 |  |
| Provision for receivable allowance | 92 |  |  | 281 |  |
| Share-based compensation expense | 3,891 |  |  | 3,665 |  |
| Income tax benefits from employee stock plans | 164 |  |  | 822 |  |
| Excess tax benefits from employee stock plans | (220 | ) |  | (1,151 | ) |
| Provision for excess and obsolete inventories | 248 |  |  | 270 |  |
| Deferred income taxes | (1,042 | ) |  | 361 |  |
| Amortization of debt financing fees | 397 |  |  | — |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (1,162 | ) |  | (5,631 | ) |
| Inventories | (5,361 | ) |  | (1,906 | ) |
| Prepaid expenses | 1,983 |  |  | 6,707 |  |
| Other current assets | 324 |  |  | 1,124 |  |
| Investment in sales-type leases, net | (8,928 | ) |  | 285 |  |
| Other long-term assets | 1,232 |  |  | (85 | ) |
| Accounts payable | 1,568 |  |  | 2,200 |  |
| Accrued compensation | 4,114 |  |  | (2,810 | ) |
| Accrued liabilities | 417 |  |  | 2,718 |  |
| Deferred revenue | 12,663 |  |  | (6,557 | ) |
| Other long-term liabilities | (2,701 | ) |  | (1,012 | ) |
| Net cash provided by operating activities | 21,787 |  |  | 11,314 |  |
| Investing Activities |  |  |  |
| Purchases of intangible assets, intellectual property and patents | (1,074 | ) |  | (103 | ) |
| Software development for external use | (3,070 | ) |  | (2,957 | ) |
| Purchases of property and equipment | (4,261 | ) |  | (1,048 | ) |
| Business acquisition, net of cash acquired | (271,458 | ) |  | — |  |
| Net cash used in investing activities | (279,863 | ) |  | (4,108 | ) |
| Financing Activities |  |  |  |
| Proceeds from debt, net | 247,059 |  |  | — |  |
| Repayment of debt under revolving credit facility | (20,000 | ) |  | — |  |
| Payment for contingent consideration | (3,000 | ) |  | — |  |
| Proceeds from issuances under stock-based compensation plans | 5,149 |  |  | 6,224 |  |
| Employees' taxes paid related to restricted stock units | (382 | ) |  | (800 | ) |
| Excess tax benefits from employee stock plans | 220 |  |  | 1,151 |  |
| Net cash provided by financing activities | 229,046 |  |  | 6,575 |  |
| Effect of exchange rate changes on cash and cash equivalents | 300 |  |  | (116 | ) |
| Net (decrease) increase in cash and cash equivalents | (28,730 | ) |  | 13,665 |  |
| Cash and cash equivalents at beginning of period | 82,217 |  |  | 125,888 |  |
| Cash and cash equivalents at end of period | $ | 53,487 |  |  | $ | 139,553 |  |

[0000926326-16-000054:8k_2_02:66]
8

[0000926326-16-000054:8k_2_02:67]
Omnicell, Inc.

[0000926326-16-000054:8k_2_02:68]
Reconciliation of GAAP to Non-GAAP

[0000926326-16-000054:8k_2_02:69]
(Unaudited, in thousands, except per share data)

[0000926326-16-000054:8k_2_02:70]
|  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  |  | March 31, 2016 |  | December 31, 2015 |  | March 31, 2015 |
| Reconciliation of GAAP net (loss) income to non-GAAP net income: |  |  |
| GAAP net (loss) income | $ | (378 | ) |  | $ | 7,655 |  |  | $ | 6,318 |  |
| Adjustments: |  |  |  |  |  |
|  | Share-based compensation expense | 3,891 |  |  | 3,654 |  |  | 3,665 |  |
|  | Amortization of acquired intangibles | 9,159 |  |  | 1,901 |  |  | 1,231 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | — |  |  | — |  |
|  | Inventory fair value adjustments | 921 |  |  | — |  |  | — |  |
|  | Acquisitions related expenses | 2,349 |  |  | 2,898 |  |  | — |  |
|  | Tax effect of the adjustments above(a) | (5,735 | ) |  | (1,665 | ) |  | (443 | ) |
| Non-GAAP net income | $ | 12,870 |  |  | $ | 14,443 |  |  | $ | 10,771 |  |
| Reconciliation of GAAP revenue to non-GAAP revenue: |  |  |
| Revenues |  | $ | 171,004 |  |  | $ | 130,316 |  |  | $ | 116,221 |  |
|  |  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | — |  |  | — |  |
| Non-GAAP revenue | $ | 173,667 |  |  | $ | 130,316 |  |  | $ | 116,221 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |
| GAAP gross profit | $ | 79,945 |  |  | $ | 65,080 |  |  | $ | 61,685 |  |
| GAAP gross margin | 46.8% |  | 49.9% |  | 53.1% |
|  |  | Share-based compensation expense | 549 |  |  | 481 |  |  | 517 |  |
|  |  | Amortization of acquired intangibles | 5,211 |  |  | 547 |  |  | 368 |  |
|  |  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | $ | — |  |  | $ | — |  |
|  |  | Inventory fair value adjustments | 921 |  |  | $ | — |  |  | $ | — |  |
| Non-GAAP gross profit | $ | 89,289 |  |  | $ | 66,108 |  |  | $ | 62,570 |  |
| Non-GAAP gross margin | 51.4% |  | 50.7% |  | 53.8% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |
| GAAP operating expenses | $ | 78,093 |  |  | $ | 53,110 |  |  | $ | 51,306 |  |
|  | GAAP operating expenses % to total revenue | 45.7% |  | 40.8% |  | 44.1% |
|  | Share-based compensation expense | (3,342 | ) |  | (3,173 | ) |  | (3,148 | ) |
|  | Amortization of acquired intangibles | (3,948 | ) |  | (1,354 | ) |  | (863 | ) |
|  | Acquisitions related expenses | (2,349 | ) |  | (2,898 | ) |  | — |  |
| Non-GAAP operating expenses | $ | 68,454 |  |  | $ | 45,685 |  |  | $ | 47,295 |  |
| Non-GAAP operating expenses % to total revenue | 40.0% |  | 35.1% |  | 40.7% |

[0000926326-16-000054:8k_2_02:71]
|  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  |  | March 31, 2016 |  | December 31, 2015 |  | March 31, 2015 |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |
| GAAP income from operations | $ | 1,852 |  |  | $ | 11,970 |  |  | $ | 10,379 |  |
|  | GAAP operating income % to total revenue | 1.1% |  | 9.2% |  | 8.9% |
|  | Share-based compensation expense | 3,891 |  |  | 3,654 |  |  | 3,665 |  |
|  | Amortization of acquired intangibles | 9,159 |  |  | 1,901 |  |  | 1,231 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | — |  |  | — |  |
|  | Inventory fair value adjustments | 921 |  |  | — |  |  | — |  |
|  | Acquisitions related expenses | 2,349 |  |  | 2,898 |  |  | — |  |
| Non-GAAP income from operations | $ | 20,835 |  |  | $ | 20,423 |  |  | $ | 15,275 |  |
| Non-GAAP operating income % to total Non-GAAP revenue | 12.0% |  | 15.7% |  | 13.1% |
| Reconciliation of GAAP net (loss) income per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 35,740 |  |  | 36,172 |  |  | 36,914 |  |
| Shares - diluted Non-GAAP | 36,307 |  |  | 36,172 |  |  | 36,914 |  |
| GAAP net (loss) income per share - diluted | $ | (0.01 | ) |  | $ | 0.21 |  |  | $ | 0.17 |  |
| Adjustments: |  |  |  |  |  |
|  | Share-based compensation expense | 0.11 |  |  | 0.11 |  |  | 0.10 |  |
|  | Amortization of acquired intangibles | 0.25 |  |  | 0.05 |  |  | 0.03 |  |
|  | Acquisition accounting impact related to deferred revenue | 0.07 |  |  | — |  |  | — |  |
|  | Inventory fair value adjustments | 0.03 |  |  | — |  |  | — |  |
|  | Acquisitions related expenses | 0.06 |  |  | 0.08 |  |  | — |  |
|  | Tax effect of the adjustments above(a) | (0.16 | ) |  | (0.05 | ) |  | (0.01 | ) |
| Non-GAAP net income per share - diluted | $ | 0.35 |  |  | $ | 0.40 |  |  | $ | 0.29 |  |
| Reconciliation of GAAP net income to non-GAAP Adjusted EBITDA: |  |  |
| GAAP net (loss) income | $ | (378 | ) |  | $ | 7,655 |  |  | $ | 6,318 |  |
| Add back: |  |  |  |  |  |
|  | Share-based compensation expense | 3,891 |  |  | 3,654 |  |  | 3,665 |  |
|  | Interest (income) and expense, net | 1,747 |  |  | 89 |  |  | 99 |  |
|  | Depreciation and amortization expense | 14,473 |  |  | 7,182 |  |  | 5,711 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | — |  |  | — |  |
|  | Inventory fair value adjustments | 921 |  |  | — |  |  | — |  |
|  | Acquisitions related expenses | 2,349 |  |  | 2,898 |  |  | — |  |
|  | Income tax expense | 59 |  |  | 3,562 |  |  | 3,544 |  |
| Non-GAAP Adjusted EBITDA (b) | $ | 25,725 |  |  | $ | 25,040 |  |  | $ | 19,337 |  |

[0000926326-16-000054:8k_2_02:72]
____________________________________________

[0000926326-16-000054:8k_2_02:73]
| (a) | Tax effects calculated for all adjustments except share based compensation expense, using estimated annual effective tax rate of 38% for fiscal year 2016. |

[0000926326-16-000054:8k_2_02:74]
| (b) | Defined as earnings before interest income and expense, taxes, depreciation and amortization, share-based compensation expense, as well as excluding certain non-GAAP adjustments. |

[0000926326-16-000054:8k_2_02:75]
10

[0000926326-16-000054:8k_2_02:76]
Omnicell, Inc.

[0000926326-16-000054:8k_2_02:77]
Segmented Information

[0000926326-16-000054:8k_2_02:78]
(Unaudited, in thousands, except for percentages)

[0000926326-16-000054:8k_2_02:79]
|  | Three Months Ended March 31, 2016 |  | Three Months Ended March 31, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 148,945 |  |  | $ | 22,059 |  |  | $ | 171,004 |  |  | $ | 92,779 |  |  | $ | 23,442 |  |  | $ | 116,221 |  |
| Cost of revenues | 77,207 |  |  | 13,852 |  |  | 91,059 |  |  | 38,852 |  |  | 15,684 |  |  | 54,536 |  |
| Gross profit | 71,738 |  |  | 8,207 |  |  | 79,945 |  |  | 53,927 |  |  | 7,758 |  |  | 61,685 |  |
| Gross margin % | 48.2% |  | 37.2% |  | 46.8% |  | 58.1% |  | 33.1% |  | 53.1% |
| Operating expenses | 52,205 |  |  | 5,611 |  |  | 57,816 |  |  | 28,589 |  |  | 6,341 |  |  | 34,930 |  |
| Income from segment operations | $ | 19,533 |  |  | $ | 2,596 |  |  | 22,129 |  |  | $ | 25,338 |  |  | $ | 1,417 |  |  | 26,755 |  |
| Operating margin % | 13.1% |  | 11.8% |  | 12.9% |  | 27.3% |  | 6.0% |  | 23.0% |
| Corporate costs |  |  |  |  | 20,277 |  |  |  |  |  |  | 16,376 |  |
| Income from operations |  |  |  |  | $ | 1,852 |  |  |  |  |  |  | $ | 10,379 |  |

[0000926326-16-000054:8k_2_02:80]
11

[0000926326-16-000054:8k_2_02:81]
Omnicell, Inc.

[0000926326-16-000054:8k_2_02:82]
Segment Information - Non-GAAP Gross Margin and Non-GAAP Operating Margin

[0000926326-16-000054:8k_2_02:83]
(Unaudited, in thousands, except for percentages)

[0000926326-16-000054:8k_2_02:84]
|  | Three Months Ended March 31, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 148,945 |  |  |  |  | $ | 22,059 |  |  |  |  | $ | 171,004 |  |  |  |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.8% |  | — |  |  | —% |  | 2,663 |  |  | 1.6% |
| Non-GAAP Revenues | $ | 151,608 |  |  |  |  | 22,059 |  |  |  |  | $ | 173,667 |  |  |  |
| GAAP Gross profit | $ | 71,738 |  |  | 48.2% |  | $ | 8,207 |  |  | 37.2% |  | $ | 79,945 |  |  | 46.8% |
| Stock-based compensation expense | 460 |  |  | 0.3% |  | 89 |  |  | 0.4% |  | 549 |  |  | 0.3% |
| Amortization expense of acquired intangible assets | 4,879 |  |  | 3.3% |  | 332 |  |  | 1.5% |  | 5,211 |  |  | 3.0% |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.8% |  | — |  |  | —% |  | 2,663 |  |  | 1.6% |
| Inventory fair value adjustments | 921 |  |  | 0.6% |  | — |  |  | —% |  | 921 |  |  | 0.5% |
| Non-GAAP Gross profit | $ | 80,661 |  |  | 54.2% |  | $ | 8,628 |  |  | 39.1% |  | $ | 89,289 |  |  | 52.2% |
| GAAP Operating income | $ | 19,533 |  |  | 13.1% |  | $ | 2,596 |  |  | 11.8% |  | $ | 22,129 |  |  | 12.9% |
| Stock-based compensation expense | 1,623 |  |  | 1.1% |  | 201 |  |  | 0.9% |  | 1,824 |  |  | 1.1% |
| Amortization expense of acquired intangible assets | 7,829 |  |  | 5.3% |  | 1,330 |  |  | 6.0% |  | 9,159 |  |  | 5.4% |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.8% |  | — |  |  | —% |  | 2,663 |  |  | 1.6% |
| Inventory fair value adjustments | 921 |  |  | 0.6% |  | — |  |  | —% |  | 921 |  |  | 0.5% |
| Acquisitions related expenses | 1,757 |  |  | 1.2% |  | — |  |  | —% |  | 1,757 |  |  | 1.0% |
| Non-GAAP Operating income | $ | 34,326 |  |  | 23.0% |  | $ | 4,127 |  |  | 18.7% |  | $ | 38,453 |  |  | 22.5% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 20,277 |  |  | 11.9% |
| Stock-based compensation expense |  |  |  |  |  |  |  |  | 2,067 |  |  | 1.2% |
| Acquisition-related expenses |  |  |  |  |  |  |  |  | 592 |  |  | 0.3% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 17,618 |  |  | 10.3% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  | $ | 20,835 |  |  | 12.2% |

[0000926326-16-000054:8k_2_02:85]
|  | Three Months Ended March 31, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 92,779 |  |  |  |  | $ | 23,442 |  |  |  |  | $ | 116,221 |  |  |  |
| GAAP Gross profit | $ | 53,927 |  |  | 58.1% |  | $ | 7,758 |  |  | 33.1% |  | $ | 61,685 |  |  | 53.1% |
| Stock-based compensation expense | 351 |  |  | 0.4% |  | 166 |  |  | 0.7% |  | 517 |  |  | 0.4% |
| Amortization expense of acquired intangibleassets | 35 |  |  | 0.0% |  | 333 |  |  | 1.4% |  | 368 |  |  | 0.3% |
| Non-GAAP Gross profit | $ | 54,313 |  |  | 58.5% |  | $ | 8,257 |  |  | 35.2% |  | $ | 62,570 |  |  | 53.8% |
| GAAP Operating income | $ | 25,338 |  |  | 27.3% |  | $ | 1,417 |  |  | 6.0% |  | $ | 26,755 |  |  | 23.0% |
| Stock-based compensation expense | 1,443 |  |  | 1.6% |  | 256 |  |  | 1.1% |  | 1,699 |  |  | 1.5% |
| Amortization expense of acquired intangibleassets | 147 |  |  | 0.2% |  | 1,084 |  |  | 4.6% |  | 1,231 |  |  | 1.1% |
| Non-GAAP Operating income | $ | 26,928 |  |  | 29.0% |  | $ | 2,757 |  |  | 11.8% |  | $ | 29,685 |  |  | 25.5% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 16,376 |  |  | 14.1% |
| Stock-based compensation expense |  |  |  |  |  |  |  |  | 1,966 |  |  | 1.7% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 14,410 |  |  | 12.4% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  | $ | 15,275 |  |  | 13.1% |

[0000926326-16-000054:8k_2_02:86]
13
