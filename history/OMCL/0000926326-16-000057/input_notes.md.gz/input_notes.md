# OMCL notes — 0000926326-16-000057


## omcl:ScheduleofLongTermNetInvestmentinSaleTypeLeasesTableTextBlock

[0000926326-16-000057:notes:1]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at March 31, 2016 and December 31, 2015:

[0000926326-16-000057:notes:2]
|  | March 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Minimum lease payments to be received, net | $ | 32,541 |  |  | $ | 22,255 |  |
| Less: Unearned interest income portion | (2,470 | ) |  | (1,014 | ) |
| Investment in sales-type leases, net | 30,071 |  |  | 21,241 |  |
| Less: Short-term investment in sales-type leases, net(1) | (9,034 | ) |  | (6,757 | ) |
| Long-term investment in sales-type leases, net | $ | 21,037 |  |  | $ | 14,484 |  |

[0000926326-16-000057:notes:3]
(1) The short-term portion of the net investments in sales-type leases are included in the Other current assets on the Condensed Consolidated Balance Sheets.


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-16-000057:notes:4]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of March 31, 2016:

[0000926326-16-000057:notes:5]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 2,976 |  |
| Non-vested restricted share awards | 767 |  |
| Shares authorized for future issuance | 3,017 |  |
| ESPP shares available for future issuance | 3,053 |  |
| Total shares reserved for future issuance | 9,813 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-16-000057:notes:6]
[same as prior period, unchanged from 0000926326-15-000035:notes:6]

[0000926326-16-000057:notes:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2016 and December 31, 2015, the results of their operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2016 and March 31, 2015. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2015 filed with the SEC on February 26, 2016. The Company's results of operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2016 are not necessarily indicative of results that may be expected for the year ending December 31, 2016, or for any future period.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000926326-16-000057:notes:8]
The pro forma adjustments include the impact of fair value adjustment related to deferred revenue, inventory fair value adjustment, amortization of intangible assets, stock-based compensation expense, interest expense and amortization of deferred issuance cost, and certain classification to conform to Omnicell's accounting policies.

[0000926326-16-000057:notes:9]
|  | Three months ended March 31, |
|  | 2016 |  | 2015 |
|  | (In thousands, except per share data) |
| Pro forma net revenues | $ | 171,004 |  | $ | 159,614 |  |
| Pro forma net income (loss) | $ | (378 | ) | $ | (119 | ) |
| Pro forma net income per share basic | $ | (0.01 | ) | $ | 0.00 |  |
| Pro forma net income per share diluted | $ | (0.01 | ) | $ | 0.00 |  |


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-16-000057:notes:10]
Investment in Sales-Type Leases, Net

[0000926326-16-000057:notes:11]
On recurring basis, we enter into sales-type lease transactions which vary in length from one to five years. The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at March 31, 2016 and December 31, 2015:

[0000926326-16-000057:notes:12]
The Company evaluates its sales-type leases individually and collectively for impairment.  The allowance for credit losses were $0.3 million and $0.2 million as of March 31, 2016 and of December 31, 2015, respectively.

[0000926326-16-000057:notes:13]
At March 31, 2016, the future minimum lease payments under sales-type leases are as follows:

[0000926326-16-000057:notes:14]
|  | March 31, 2016 |
|  | (In thousands) |
| Remaining nine months of 2016 | $ | 7,253 |  |
| 2017 | 9,126 |  |
| 2018 | 7,328 |  |
| 2019 | 5,032 |  |
| 2020 | 3,200 |  |
| Thereafter | 602 |  |
| Total | $ | 32,541 |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-16-000057:notes:15]
Commitments and Contingencies

[0000926326-16-000057:notes:16]
Lease commitments

[0000926326-16-000057:notes:17]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment.  At March 31, 2016, the minimum future payments on non-cancelable operating leases were as follows:

[0000926326-16-000057:notes:18]
|  | (In thousands) |
| Remaining nine months of 2016 | $ | 7,996 |  |
| 2017 | 10,441 |  |
| 2018 | 9,921 |  |
| 2019 | 9,802 |  |
| 2020 | 6,256 |  |
| Thereafter | 10,870 |  |
| Total minimum future lease payments | $ | 55,286 |  |

[0000926326-16-000057:notes:19]
Purchase obligations

[0000926326-16-000057:notes:20]
During the course of the business, the Company issues purchase orders based on its current manufacturing needs.  At March 31, 2016, the Company had non-cancelable purchase commitments of $38.9 million, which are expected to be paid within the next twelve months.

[0000926326-16-000057:notes:21]
Legal Proceedings

[0000926326-16-000057:notes:22]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-16-000057:notes:23]
The Company’s pending legal proceeding as of March 31, 2016 was as follows:

[0000926326-16-000057:notes:24]
On September 12, 2014, MV Circuit Design, Inc., an Ohio company ("MV Circuit"), brought an action to correct the inventorship of certain patents owned by the Company, as well as related state-law claims against the Company in the Northern District of Ohio (Case No. 1:14-cv-02028-DAP) regarding allegations of fraud in the filing and prosecution of U.S. Patent Nos. 8,180,485, 8,773,270, 8,812,153, PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505 (the “Action”). On November 14, 2014, the Company filed a Motion to Dismiss the Action. MV Circuit responded on January 29, 2015, and the Company replied in support of its Motion to Dismiss on February 17, 2015. On March 24, 2015, the Court issued an Order granting in part and denying in part the Motion to Dismiss. Specifically, the Court granted the Company's Motion to Dismiss with respect to Counts 4, 5, and 6 (declaratory judgments regarding PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505) and count 13 (civil conspiracy). The Court denied the Company's Motion to Dismiss with respect to Count 9 (fraud), Count 7 (fraudulent concealment) and Count 8 (negligent misrepresentation). The Company filed an Answer to the Complaint on April 8, 2015. Following an initial Case Management Conference on April 22, 2015, the Court ordered MV Circuit and the Company to make a limited initial production of documents. The parties completed this initial document production and have held further conference calls with the Court to report on their settlement negotiations.  During a conference call held on February 11, 2016, the Court set a deadline of March 14, 2016 for the parties to either file notification of settlement or a proposed litigation schedule. The parties have requested three extensions of the March 14th deadline, with the current deadline requested for June 10, 2016.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-16-000057:notes:25]
[same as prior period, unchanged from 0000926326-15-000035:notes:22]

[0000926326-16-000057:notes:26]
[same as prior period, unchanged from 0000926326-15-000035:notes:23]


## us-gaap:DebtDisclosureTextBlock

[0000926326-16-000057:notes:27]
Debt

[0000926326-16-000057:notes:28]
On January 5, 2016, the Company entered into a $400 million senior secured credit facility pursuant to a credit agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200 million (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-16-000057:notes:29]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the 2016 Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-16-000057:notes:30]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-16-000057:notes:31]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio.  The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.  The Company was in full compliance with all covenants as of March 31, 2016.

[0000926326-16-000057:notes:32]
On January 5, 2016, the Company borrowed the full $200 million under the Term Loan Facility and $55 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses. In connection with these Facilities, the Company incurred $7.9 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021.

[0000926326-16-000057:notes:33]
The components of the Company’s debt obligations as of March 31, 2016 and December 31, 2015 are as follows:

[0000926326-16-000057:notes:34]
|  | December 31, 2015 | Additions | Repayment/amortization | March 31, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | — |  | $ | 200,000 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (20,000 | ) | 235,000 |  |
| Less: Deferred issuance cost |  | (7,949 | ) | 397 |  | (7,552 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (19,603 | ) | 227,448 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 219,038 |  |

[0000926326-16-000057:notes:35]
(1) The fair value of total debt under the facilities approximates the book value as of March 31, 2016.


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-16-000057:notes:36]
Deferred revenue

[0000926326-16-000057:notes:37]
The Short-term deferred revenue includes deferred revenue from product sales and service contracts, net of deferred cost of sales of $19.0 million and $15.7 million as of March 31, 2016 and December 31, 2015, respectively. The short-term deferred revenues from product sales relate to the delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

[0000926326-16-000057:notes:38]
The Long-term deferred revenue includes deferred revenue from the service contracts of $17.8 million and $18.0 million, as of March 31, 2016 and December 31, 2015, respectively.


## us-gaap:EarningsPerShareTextBlock

[0000926326-16-000057:notes:39]
Net Income (Loss) Per Share

[0000926326-16-000057:notes:40]
Basic net income (loss) per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. Diluted net income per share is computed by dividing net income for the period by the weighted-average number of shares, less shares repurchased, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. The anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share because their effect would have been anti-dilutive.

[0000926326-16-000057:notes:41]
The calculation of basic and diluted net income (loss) per share is as follows:

[0000926326-16-000057:notes:42]
|  | Three months ended March 31, |
|  | 2016 |  | 2015 |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | (378 | ) |  | $ | 6,318 |  |
| Weighted-average shares outstanding — basic | 35,740 |  |  | 36,024 |  |
| Effect of dilutive securities from stock award plans | — |  |  | 890 |  |
| Weighted-average shares outstanding — diluted | $ | 35,740 |  |  | $ | 36,914 |  |
| Net income (loss) per share — basic | $ | (0.01 | ) |  | $ | 0.18 |  |
| Net income (loss) per share — diluted | $ | (0.01 | ) |  | $ | 0.17 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 2,045 |  |  | 484 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-16-000057:notes:43]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of March 31, 2016:

[0000926326-16-000057:notes:44]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Money market fund | $ | 10,118 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,118 |  |
| Forward contracts | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Total financial assets | $ | 10,118 |  |  | $ | 8 |  |  | $ | — |  |  | $ | 10,126 |  |
| Contingent consideration liability(1) | $ | — |  |  | $ | — |  |  | $ | 2,867 |  |  | $ | 2,867 |  |
| Total financial liabilities | $ | — |  |  | $ | — |  |  | $ | 2,867 |  |  | $ | 2,867 |  |

[0000926326-16-000057:notes:45]
(1) The significant unobservable inputs used in the fair value measurement of the contingent consideration classified as Level 3 above are the achievement of booking targets and the discount rate.

[0000926326-16-000057:notes:46]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of December 31, 2015:

[0000926326-16-000057:notes:47]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Money market fund | $ | 10,114 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,114 |  |
| Forward contracts | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Total financial assets | $ | 10,114 |  |  | $ | 32 |  |  | $ | — |  |  | $ | 10,146 |  |
| Contingent consideration liability(1) | $ | — |  |  | $ | — |  |  | $ | 5,823 |  |  | $ | 5,823 |  |
| Total financial liabilities | $ | — |  |  | $ | — |  |  | $ | 5,823 |  |  | $ | 5,823 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000926326-16-000057:notes:48]
The cash and cash equivalents at March 31, 2016 and December 31, 2015 were as follows:

[0000926326-16-000057:notes:49]
|  | March 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Cash | $ | 43,369 |  |  | $ | 72,103 |  |
| Money market fund | 10,118 |  |  | 10,114 |  |
| Total cash and cash equivalents | $ | 53,487 |  |  | $ | 82,217 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-16-000057:notes:50]
[same as prior period, unchanged from 0000926326-15-000035:notes:42]

[0000926326-16-000057:notes:51]
Cash and cash equivalents as of March 31, 2016 and December 31, 2015 include cash and money market funds, which have original maturities of three months or less.  Due to the short duration to maturity, the carrying value of such financial instruments approximates the estimated fair value.

[0000926326-16-000057:notes:52]
[same as prior period, unchanged from 0000926326-15-000035:notes:44]

[0000926326-16-000057:notes:53]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's foreign currency contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments. The Company's contingent consideration liability is classified as Level 3 as valuation inputs are unobservable in the market and significant to the instrument’s valuation.

[0000926326-16-000057:notes:54]
Net investment in sales-type leases. The carrying amount of the Company's sales-type lease receivables is a reasonable estimate of fair value as the unearned interest income is immaterial.

[0000926326-16-000057:notes:55]
[same as prior period, unchanged from 0000926326-15-000035:notes:48]

[0000926326-16-000057:notes:56]
The Company operates in foreign countries, which exposes it to market risk associated with foreign currency exchange rate fluctuations between the U.S. dollar and various foreign currencies, the most significant of which is the British Pound and Euro. In order to manage foreign currency risk, the Company enters into foreign exchange forward contracts to mitigate risks associated with changes in spot exchange rates of mainly non-functional currency denominated assets or liabilities of its foreign subsidiaries.  In general, the market risk related to these contracts is offset by corresponding gains and losses on the hedged transactions. By working only with major banks and closely monitoring current market conditions, the Company seeks to limit the risk that counterparties to these contracts may be unable to perform. The foreign exchange forward contracts are measured at fair value and reported as other current assets or accrued liabilities on the Condensed Consolidated Balance Sheets. The derivative instruments the Company uses to hedge this exposure are not designated as hedges. Any gains or losses on the foreign exchange forward contracts are recognized in earnings as Other Income/Expense in the period incurred in the Condensed Consolidated Statements of Operations. The Company does not enter into derivative contracts for trading purposes.

[0000926326-16-000057:notes:57]
The aggregate notional amounts of the Company's outstanding foreign exchange contracts as of March 31, 2016 and December 31, 2015 were $0.3 million and $0.4 million, respectively. The aggregate fair values of these outstanding foreign exchange contracts as of March 31, 2016 and December 31, 2015 were less than $0.1 million.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-16-000057:notes:58]
[same as prior period, unchanged from 0000926326-15-000035:notes:51]

[0000926326-16-000057:notes:59]
[same as prior period, unchanged from 0000926326-15-000035:notes:52]

[0000926326-16-000057:notes:60]
[same as prior period, unchanged from 0000926326-15-000035:notes:53]

[0000926326-16-000057:notes:61]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2015 | $ | 54,316 |  |  | $ | 93,590 |  |  | $ | 147,906 |  |
| Goodwill acquired | 164,824 |  |  |  |  | 164,824 |  |
| Foreign currency exchange rate fluctuations | 77 |  |  | (296 | ) |  | (219 | ) |
| Net balance as of March 31, 2016 | $ | 219,217 |  |  | $ | 93,294 |  |  | $ | 312,511 |  |

[0000926326-16-000057:notes:62]
[same as prior period, unchanged from 0000926326-15-000035:notes:55]

[0000926326-16-000057:notes:63]
The carrying amounts of intangibles assets as of March 31, 2016 and December 31, 2015 are as follows:

[0000926326-16-000057:notes:64]
|  | March 31, 2016 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 126,338 |  |  | $ | (11,656 | ) |  | $ | (818 | ) |  | $ | 113,864 |  |  | 5 - 30 |
| Acquired technology | 70,041 |  |  | (7,850 | ) |  | 173 |  |  | 62,364 |  |  | 3 - 20 |
| In-process Technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | - |
| Trade names | 8,542 |  |  | (2,672 | ) |  | 36 |  |  | 5,906 |  |  | 1 - 12 |
| Patents | 2,042 |  |  | (407 | ) |  | — |  |  | 1,635 |  |  | 2 - 20 |
| Backlog | 20,615 |  |  | (3,653 | ) |  | (20 | ) |  | 16,942 |  |  | 1 - 3 |
| Non-compete agreements | 1,800 |  |  | (150 | ) |  |  |  | 1,650 |  |  | 3 |
| Total intangibles assets, net | $ | 233,278 |  |  | $ | (26,388 | ) |  | $ | (629 | ) |  | $ | 206,261 |  |  |  |

[0000926326-16-000057:notes:65]
|  | December 31, 2015 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 69,554 |  |  | $ | (11,315 | ) |  | $ | (719 | ) |  | $ | 57,520 |  |  | 5 - 30 |
| Acquired technology | 30,870 |  |  | (6,088 | ) |  | 59 |  |  | 24,841 |  |  | 3 - 20 |
| Trade names | 8,052 |  |  | (2,551 | ) |  | (14 | ) |  | 5,487 |  |  | 1 - 12 |
| Patents | 1,960 |  |  | (384 | ) |  | — |  |  | 1,576 |  |  | 2 - 20 |
| Backlog | 415 |  |  | (163 | ) |  | (11 | ) |  | 241 |  |  | 2 |
| Total intangibles assets, net | $ | 110,851 |  |  | $ | (20,501 | ) |  | $ | (685 | ) |  | $ | 89,665 |  |  |  |

[0000926326-16-000057:notes:66]
Amortization expense of intangible assets was $9.2 million and $1.3 million for the three months ended March 31, 2016 and March 31, 2015, respectively.

[0000926326-16-000057:notes:67]
The estimated future amortization expenses for amortizable intangible assets are as follows:

[0000926326-16-000057:notes:68]
|  | March 31, 2016 |
|  | (In thousands) |
| Remaining nine months of 2016 | $ | 27,031 |  |
| 2017 | 22,834 |  |
| 2018 | 21,221 |  |
| 2019 | 16,143 |  |
| 2020 | 15,138 |  |
| Thereafter | 99,994 |  |
| Total | $ | 202,361 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-16-000057:notes:69]
[same as prior period, unchanged from 0000926326-15-000035:notes:63]

[0000926326-16-000057:notes:70]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 37.0% and 38.6% for the three months ended March 31, 2016 and 2015, respectively. The 2016 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction and the Federal Research & Development credit, which was permanently reinstated on December 18, 2015. The 2015 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.

[0000926326-16-000057:notes:71]
As of March 31, 2016 and December 31, 2015, the Company had gross unrecognized tax benefits of $9.9 million and $7.2 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in operating expense. As of March 31, 2016 and December 31, 2015, the amount of accrued interest and penalties was $1.0 million and $0.2 million, respectively.

[0000926326-16-000057:notes:72]
As of March 31, 2016, calendar years 2011 and thereafter are open and subject to potential examination in one or more jurisdictions.  However, because all of the net operating loss and research credit carryforwards that may be used in future years are subject to adjustment, if and when utilized, our federal and California tax years remain open from 1996 and 1992, respectively. The Company is currently under examination by the Internal Revenue Service for the 2011 through 2013 tax years.

[0000926326-16-000057:notes:73]
Although the Company believes it has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. It is not possible at this time to reasonably estimate changes in the unrecognized tax benefits within the next twelve months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000926326-16-000057:notes:74]
Property and equipment, net

[0000926326-16-000057:notes:75]
|  | March 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| United States | $ | 38,880 |  |  | $ | 29,506 |  |
| Rest of world (1) | 3,328 |  |  | 2,803 |  |
| Total property and equipment, net | $ | 42,208 |  |  | $ | 32,309 |  |

[0000926326-16-000057:notes:76]
_________________________________________________

[0000926326-16-000057:notes:77]
(1)    No individual country represented more than 10% of the respective totals.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000926326-16-000057:notes:78]
[same as prior period, unchanged from 0000926326-15-000035:notes:70]

[0000926326-16-000057:notes:79]
2016 Acquisition

[0000926326-16-000057:notes:80]
On January 5, 2016, the Company completed the acquisition of all of the membership interests of Aesynt pursuant to the Securities Purchase Agreement for total cash consideration of $271.5 million, net of cash on hand at signing of $8.2 million. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management.

[0000926326-16-000057:notes:81]
The Company accounted for the purchase of Aesynt in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition date.      The following table represents the preliminary estimated allocation of the purchase price to the assets acquired and the liabilities assumed by the Company, reconciled to the purchase price transferred included in the Company's Condensed Consolidated Balance Sheet:

[0000926326-16-000057:notes:82]
|  | (In thousands) |
| Cash | $ | 8,164 |  |
| Accounts receivable | 44,895 |  |
| Inventory | 20,111 |  |
| Other current assets | 4,381 |  |
| Total current assets | 77,551 |  |
| Property and equipment | 10,389 |  |
| Intangible assets | 123,700 |  |
| Goodwill | 164,824 |  |
| Other non-current assets | 968 |  |
| Total assets | 377,432 |  |
| Current liabilities | 25,821 |  |
| Deferred revenue, net | 25,631 |  |
| Non-current deferred tax liabilities | 43,927 |  |
| Other non-current liabilities | 2,431 |  |
| Total liabilities | 97,810 |  |
| Total purchase price | 279,622 |  |
| Total purchase price, net of cash received | $ | 271,458 |  |

[0000926326-16-000057:notes:83]
The goodwill arising from this acquisition is primarily attributed to sales of future products and services and the assembled workforce of Aesynt. The Aesynt acquisition would create the broadest product portfolio in the industry with significant offerings in automated dispensing systems, central pharmacy robotics, IV robotics and enterprise analytics. Goodwill has been assigned to the Automation & Analytics segment and is not deductible for tax purposes. Goodwill is not being amortized but is reviewed annually for impairment or more frequently if impairment indicators arise, in accordance with authoritative guidance.

[0000926326-16-000057:notes:84]
Identifiable intangible assets (preliminary) acquired and their respective estimated remaining useful lives over which each asset will be amortized areas are as follows:

[0000926326-16-000057:notes:85]
|  | Fair value |  | Weightedaverageuseful life |
|  | (In thousands) |  | (In years) |
| Customer relationships | $ | 58,200 |  |  | 14-16 |
| Developed technology | 38,800 |  |  | 8 |
| Backlog | 20,200 |  |  | 1-3 |
| In-process R&D (1) | 3,900 |  |  | - |
| Non-compete | 1,800 |  |  | 3 |
| Trade names | 800 |  |  | 1 |
| Total purchased intangible assets | $ | 123,700 |  |  |  |

[0000926326-16-000057:notes:86]
(1) The amortization of the IPR&D assets begin when the IPR&D projects are complete.

[0000926326-16-000057:notes:87]
Customer relationships represent the fair value of the underlying relationships and agreements with Aesynt’s customers, acquired developed technology represents the fair value of Aesynt products that have reached technological feasibility and were part of Aesynt’s product offerings at the date of acquisition, backlog represents the fair value of sales order backlog at the date of acquisition, non-compete intangible asset represents the fair value of non-compete agreements with former key members of Aesynt's management, and trade name represents the fair value of brand and name recognition associated with the marketing of Aesynt’s products and services. In-process research and development ("IPR&D") represents the fair value of incomplete Aesynt R&D projects that had not reached technological feasibility as of the date of acquisition. Incremental costs incurred for those projects are expensed as incurred in R&D.

[0000926326-16-000057:notes:88]
The fair value of trade names, acquired developed technology, and acquired IPR&D was determined based on an income approach using the relief-from-royalty method at the royalty rates of 0.5%, 4%-8% and 12.5%, respectively. The fair value of customer relationships, backlog, and non-compete intangible assets was determined based on an income approach using the discounted cash flow method, at the discounted rates of 13%, 10% and 13%, respectively. The intangible assets, except customer relationship and IPR&D, are being amortized over their estimated useful lives using the straight line method of amortization. The customer relationship intangible asset is being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. In accordance with authoritative guidance, the IPR&D is accounted for as an indefinite-lived intangible asset until completion or abandonment of the associated research and development efforts. IPR&D is tested for impairment during the period it is considered an indefinite lived asset. IPR&D related projects are expected to be completed in two to three years.

[0000926326-16-000057:notes:89]
The Company incurred approximately $5.2 million in acquisition-related costs related to the Aesynt acquisition of which $2.9 million and $2.3 million was recognized in three months ended December 31, 2015 and March 31, 2016, respectively. These costs are included in selling, general and administrative expenses in the Company's Condensed Consolidated Statement of Operations.

[0000926326-16-000057:notes:90]
Aesynt generated revenue of $43.2 million and losses from operations of $9.5 million since the acquisition date through March 31, 2016.

[0000926326-16-000057:notes:91]
Pro forma financial information for 2016 and 2015 acquisitions

[0000926326-16-000057:notes:92]
The following table presents certain unaudited pro forma information for illustrative purposes only, for the first quarter of fiscal 2016 and 2015 as if Aesynt had been acquired on January 1, 2015. The pro forma information is not indicative of what would have occurred had the acquisitions taken place on January 1, 2015. The unaudited pro forma information combines the historical results of the acquisitions with the Company's consolidated historical results and includes certain adjustments reflecting the estimated impact of fair value adjustments for the respective periods. The pro forma adjustments include the impact of fair value adjustment related to deferred revenue, inventory fair value adjustment, amortization of intangible assets, stock-based compensation expense, interest expense and amortization of deferred issuance cost, and certain classification to conform to Omnicell's accounting policies.

[0000926326-16-000057:notes:93]
2015 Acquisitions

[0000926326-16-000057:notes:94]
On April 21, 2015, the Company completed the acquisition of Mach4 Automatisierungstechnik GmbH ("Mach4"), a privately held German limited liability company with its registered office in Bochum, Germany pursuant to a share purchase agreement (the “Mach4 Agreement”), under which Omnicell International, Inc., a wholly-owned subsidiary of Omnicell Inc., purchased the entire issued share capital of Mach4. Pursuant to the terms of Mach4 Agreement, the Company paid approximately $17.3 million in cash, of which $2.7 million was placed in an escrow fund to be distributed to Mach4's former stockholders within 18 months after the closing date of the transaction, subject to indemnification and other claims the Company may make.

[0000926326-16-000057:notes:95]
On April 30, 2015, the Company completed the acquisition of Avantec Healthcare Limited ("Avantec"), the privately-held distributor of Omnicell’s products in the United Kingdom, pursuant to a share purchase agreement (the "Avantec Agreement"), wherein the Company acquired the remaining 85% of issued and outstanding ordinary shares of Avantec was not previously owned by the Company. Pursuant to the terms of the Avantec Agreement, the Company agreed to pay $12.0 million in cash and potential earn-out payments of up to $3.0 million payable after December 31, 2015 and an additional $3.0 million payable after December 31, 2016, based on future bookings. The fair value of these potential earn-out payments as of the acquisition date was $5.6 million. Pursuant to the terms of the Avantec Agreement, the Company retained $1.8 million of the purchase consideration to be held for settlement of any future indemnification claims within an 18 month period that the Company may make following the closing of the transaction. The fair value of the contingent consideration liability related to Avantec is revalued at each reporting date or more frequently if circumstances dictate. Changes in the fair value of this obligation are recorded as income or expense within other expense in our condensed consolidated statements of operation. The significant unobservable inputs used in the fair value measurement of the contingent consideration are the achievement of booking targets and the discount rate. Significant increases or decreases in any of those inputs in isolation would result in a significantly lower or higher fair value measurement. During the three months ended March 31, 2016, the Company paid a $3.0 million earn-out payment which was due after December 31, 2015 based on the achievement of certain metrics set forth in the Avantec Agreement.

[0000926326-16-000057:notes:96]
The Company accounted for the acquisitions above in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the respective acquisition dates. The purchase price allocations are subject to certain post-closing working capital adjustments for the acquired current assets and current liabilities of both acquisitions at their respective acquisition dates. The total consideration and the allocation of consideration to the individual net assets is preliminary, as there are remaining uncertainties to be resolved, including the settlement of the final net working capital adjustment for each.

[0000926326-16-000057:notes:97]
The following table represents the preliminary estimated allocation of the purchase price to the assets acquired and the liabilities assumed by the Company as part of each acquisition:

[0000926326-16-000057:notes:98]
|  | Mach4 |  | Avantec |  | Total |
|  | (In thousands) |
| Cash | $ | 397 |  |  | $ | 3,392 |  |  | $ | 3,789 |  |
| Accounts receivable | 3,743 |  |  | 3,607 |  |  | 7,350 |  |
| Inventory | 3,580 |  |  | 1,428 |  |  | 5,008 |  |
| Deferred tax assets and other current assets | 368 |  |  | 89 |  |  | 457 |  |
| Total current assets | 8,088 |  |  | 8,516 |  |  | 16,604 |  |
| Property and equipment | 463 |  |  | — |  |  | 463 |  |
| Intangibles | 7,710 |  |  | 6,341 |  |  | 14,051 |  |
| Goodwill | 10,591 |  |  | 15,606 |  |  | 26,197 |  |
| Other non-current assets | 52 |  |  | — |  |  | 52 |  |
| Total assets | 26,904 |  |  | 30,463 |  |  | 57,367 |  |
| Current liabilities | 3,684 |  |  | 4,125 |  |  | 7,809 |  |
| Non-current deferred tax liabilities | 2,564 |  |  | 1,269 |  |  | 3,833 |  |
| Deferred service revenue and gross profit | 2,314 |  |  | 928 |  |  | 3,242 |  |
| Other non-current liabilities | 1,056 |  |  | — |  |  | 1,056 |  |
| Total purchase price | 17,286 |  |  | 24,141 |  |  | 41,427 |  |
| Total purchase price, net of cash received | $ | 16,889 |  |  | $ | 20,749 |  |  | $ | 37,638 |  |

[0000926326-16-000057:notes:99]
[same as prior period, unchanged from 0000926326-15-000035:notes:86]

[0000926326-16-000057:notes:100]
|  | Mach4 |  | Avantec |
|  | Fair value |  | Weightedaverageuseful life |  | Fair value |  | Weightedaverageuseful life |
|  | (In thousands) |  | (In years) |  | (In thousands) |  | (In years) |
| Developed technology | $ | 3,290 |  |  | 8 |  | $ | — |  |  | — |
| Trade name | 850 |  |  | 6 |  | 92 |  |  | 2 |
| Customer relationships | 3,570 |  |  | 10 |  | 5,834 |  |  | 12 |
| Backlog | — |  |  | — |  | 415 |  |  | 2 |
| Total purchased intangible assets | $ | 7,710 |  |  |  |  | $ | 6,341 |  |  |  |

[0000926326-16-000057:notes:101]
Total revenues for Mach4 and Avantec recorded in the first quarter of 2016 were $3.8 million and $2.9 million, respectively. Total operating loss for Mach4 in the first quarter of 2016 was $1.7 million and total operating income for Avantec in the first quarter of 2016 was $0.8 million.

[0000926326-16-000057:notes:102]
Pro forma results of operations for these acquisitions have not been presented because they are not material to the consolidated results of operations, either individually or in aggregate.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-16-000057:notes:103]
Recently issued authoritative guidance

[0000926326-16-000057:notes:104]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted for any entity in any interim or annual period. If an entity early adopts the amendments in an interim period, any adjustments are reflected as of the beginning of the fiscal year that includes that interim period. An entity that elects early adoption must adopt all of the amendments in the same period. The Company is currently in the process of evaluating the impact of the adoption of ASU 2016-09 on its consolidated financial statements.

[0000926326-16-000057:notes:105]
There was no other recently issued authoritative guidance that has a material impact on our Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0000926326-16-000057:notes:106]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards ("RSA") |  |  |  |
| Outstanding at December 31, 2015 | 31 |  |  | $ | 35.98 |  |
| Granted | — |  |  | — |  |
| Vested | — |  |  | — |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at March 31, 2016 | 31 |  |  | $ | 35.98 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-16-000057:notes:107]
[same as prior period, unchanged from 0000926326-15-000035:notes:100]

[0000926326-16-000057:notes:108]
[same as prior period, unchanged from 0000926326-15-000035:notes:101]

[0000926326-16-000057:notes:109]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication, supply control systems and medication adherence solutions which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States and Europe. "Omnicell" "our", "us", "we" or the "Company" collectively refer to Omnicell, Inc. and its subsidiaries.

[0000926326-16-000057:notes:110]
On January 5, 2016, the Company completed the acquisition of all of the membership interests of Aesynt Holding Coöperatief U.A. ("Aesynt"). The significant accounting policies of Aesynt have been aligned to conform to those accounting policies of Omnicell, and the consolidated financial statements include the results of operations of Aesynt commencing as of the acquisition date.

[0000926326-16-000057:notes:111]
[same as prior period, unchanged from 0000926326-15-000035:notes:103]

[0000926326-16-000057:notes:112]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company's Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company's critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, accounts receivable and notes receivable (investment in sales-type leases), capitalized software development costs, valuation of goodwill and purchased intangibles and long-lived assets, fair value of assets acquired and liabilities assumed in business combinations, and accounting for income taxes.

[0000926326-16-000057:notes:113]
[same as prior period, unchanged from 0000926326-15-000035:notes:105]

[0000926326-16-000057:notes:114]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level.  Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

[0000926326-16-000057:notes:115]
The operating results of the recently acquired Aesynt business is included in the Company's Automation and Analytics reporting segment.

[0000926326-16-000057:notes:116]
[same as prior period, unchanged from 0000926326-15-000035:notes:109]

[0000926326-16-000057:notes:117]
Financial instruments that may potentially subject the Company to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of the Company's accounts receivable are derived from sales to customers for commercial applications. The Company performs ongoing credit evaluations of its customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. The Company maintains reserves for potential credit losses. The Company's products are broadly distributed and there were no customers that accounted for more than 10% of its accounts receivable as of March 31, 2016 and December 31, 2015. The Company believes that it has no significant concentrations of credit risk as of March 31, 2016.

[0000926326-16-000057:notes:118]
Recently adopted authoritative guidance

[0000926326-16-000057:notes:119]
In July 2015, the FASB issued ASU No. 2015-11, Simplifying the Measurement of Inventory. The new guidance changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. It applies to entities that measure inventory using a method other than last-in, first-out (LIFO) and the retail inventory method (RIM). The new guidance is effective for fiscal years beginning after December 15, 2016. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three months ended March 31, 2016.

[0000926326-16-000057:notes:120]
In September 2015, the FASB issued ASU No. 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments ("ASU 2015-16"). This ASU requires adjustments to provisional amounts that are identified during the measurement period of a business combination to be recognized in the reporting period in which the adjustment amounts are determined. An acquirer is no longer required to revise comparative information for prior periods as if the accounting for the business combination had been completed as of the acquisition date. The provisions of ASU 2015-16 are effective for reporting periods beginning after December 15, 2015. The adoption of this accounting standard update did not have any impact on the Company's consolidated financial position or results of operations for the three months ended March 31, 2016.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000926326-16-000057:notes:121]
Revenues

[0000926326-16-000057:notes:122]
|  | Three months ended |
|  | March 31, 2016 |  | March 31, 2015 |
|  | (In thousands) |
| United States | $ | 143,493 |  |  | $ | 97,823 |  |
| Rest of world (1) | 27,511 |  |  | 18,398 |  |
| Total revenues | $ | 171,004 |  |  | $ | 116,221 |  |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-16-000057:notes:123]
|  | March 31, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 17,623 |  |  | $ | 11,582 |  |
| Work in process | 7,062 |  |  | 1,653 |  |
| Finished goods | 47,229 |  |  | 33,359 |  |
| Total inventories | $ | 71,914 |  |  | $ | 46,594 |  |
| Property and equipment: |  |  |  |
| Equipment | $ | 68,335 |  |  | $ | 43,533 |  |
| Furniture and fixtures | 8,314 |  |  | 5,897 |  |
| Leasehold improvements | 14,955 |  |  | 9,063 |  |
| Software | 35,399 |  |  | 30,693 |  |
| Construction in progress | 5,408 |  |  | 3,651 |  |
| Property and equipment, gross | 132,411 |  |  | 92,837 |  |
| Accumulated depreciation and amortization | (90,203 | ) |  | (60,528 | ) |
| Total property and equipment, net | $ | 42,208 |  |  | $ | 32,309 |  |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 27,130 |  |  | $ | 26,011 |  |
| Other assets | 1,679 |  |  | 1,883 |  |
| Total other long term assets, net | $ | 28,809 |  |  | $ | 27,894 |  |
| Accrued liabilities: |  |  |  |
| Advance payments from customers | $ | 7,443 |  |  | $ | 8,327 |  |
| Rebates and lease buyouts | 4,384 |  |  | 4,702 |  |
| Group purchasing organization fees | 2,493 |  |  | 2,983 |  |
| Taxes payable | 2,722 |  |  | 2,768 |  |
| Other accrued liabilities | 17,861 |  |  | 11,353 |  |
| Total accrued liabilities | $ | 34,903 |  |  | $ | 30,133 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0000926326-16-000057:notes:124]
The following table sets forth the total share-based compensation expense recognized in the Company's Condensed Consolidated Statements of Operations:

[0000926326-16-000057:notes:125]
|  | Three months ended |
|  | March 31, 2016 |  | March 31, 2015 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 549 |  |  | $ | 517 |  |
| Research and development | 641 |  |  | 434 |  |
| Selling, general and administrative | 2,701 |  |  | 2,714 |  |
| Total share-based compensation expense | $ | 3,891 |  |  | $ | 3,665 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0000926326-16-000057:notes:126]
Summaries of restricted stock activity under the 2009 Plan are presented below:

[0000926326-16-000057:notes:127]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units ("RSU") |  |  |  |  |  |  |  |
| Outstanding at December 31, 2015 | 417 |  |  | $ | 28.49 |  |  | 1.6 |  |  |
| Granted | 90 |  |  | 27.77 |  |  |  |  |  |
| Vested | (23 | ) |  | 25.76 |  |  |  |  |  |
| Forfeited | (7 | ) |  | 28.42 |  |  |  |  |  |
| Outstanding and unvested at March 31, 2016 | 477 |  |  | $ | 28.49 |  |  | 1.5 |  | $ | 13,292 |  |
| Expected to vest after March 31, 2016 | 419 |  |  | $ | 28.39 |  |  | 1.4 |  | $ | 11,677 |  |


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0000926326-16-000057:notes:128]
The following table represents the preliminary estimated allocation of the purchase price to the assets acquired and the liabilities assumed by the Company, reconciled to the purchase price transferred included in the Company's Condensed Consolidated Balance Sheet:


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-16-000057:notes:129]
The following table summarizes the financial performance of the Company's reportable segments, including a reconciliation of income from segment operations to income from total operations:

[0000926326-16-000057:notes:130]
|  | Three months ended |
|  | March 31, 2016 |  | March 31, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 148,945 |  |  | $ | 22,059 |  |  | $ | 171,004 |  |  | $ | 92,779 |  |  | $ | 23,442 |  |  | $ | 116,221 |  |
| Cost of revenues | 77,207 |  |  | 13,852 |  |  | 91,059 |  |  | 38,852 |  |  | 15,684 |  |  | 54,536 |  |
| Gross profit | 71,738 |  |  | 8,207 |  |  | 79,945 |  |  | 53,927 |  |  | 7,758 |  |  | 61,685 |  |
| Operating expenses | 52,205 |  |  | 5,611 |  |  | 57,816 |  |  | 28,589 |  |  | 6,341 |  |  | 34,930 |  |
| Income from segment operations | $ | 19,533 |  |  | $ | 2,596 |  |  | $ | 22,129 |  |  | $ | 25,338 |  |  | $ | 1,417 |  |  | $ | 26,755 |  |
| Corporate costs |  |  |  |  | 20,277 |  |  |  |  |  |  | 16,376 |  |
| Income from operations |  |  |  |  | $ | 1,852 |  |  |  |  |  |  | $ | 10,379 |  |

[0000926326-16-000057:notes:131]
________________________________________________


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000926326-16-000057:notes:132]
A summary of the stock options activity under the 2009 Plan is presented below:

[0000926326-16-000057:notes:133]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value(1) |
|  | (In thousands, except per share data) |
| Stock Options |  |  |  |  |  |  |  |
| Outstanding at December 31, 2015 | 2,688 |  |  | $ | 22.89 |  |  | 6.9 |  |  |
| Granted | 376 |  |  | 27.75 |  |  |  |  |  |
| Exercised | (49 | ) |  | 13.48 |  |  |  |  |  |
| Expired | (1 | ) |  | 19.96 |  |  |  |  |  |
| Forfeited | (38 | ) |  | 28.51 |  |  |  |  |  |
| Outstanding at March 31, 2016 | 2,976 |  |  | $ | 23.59 |  |  | 7.0 |  | $ | 15,891 |  |
| Exercisable at March 31, 2016 | 1,478 |  |  | $ | 18.53 |  |  | 5.0 |  | $ | 14,329 |  |
| Vested and expected to vest at March 31, 2016 and thereafter | 2,790 |  |  | $ | 23.23 |  |  | 6.9 |  | $ | 15,806 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0000926326-16-000057:notes:134]
The following weighted average assumptions are used to value stock options and Employee Stock Purchase Plan ("ESPP") shares issued pursuant to the Company's equity incentive plans for the three months ended March 31, 2016 and March 31, 2015:

[0000926326-16-000057:notes:135]
|  | Three months ended |
|  | March 31, 2016 |  | March 31, 2015 |
|  | (In thousands, except percentages) |
| Stock Option Plans |  |  |  |
| Expected life, years | 4.92 |  |  | 5.04 |  |
| Expected volatility, % | 32.6 | % |  | 33.2 | % |
| Risk free interest rate, % | 1.40 | % |  | 1.66 | % |
| Estimated forfeiture rate % | 8.6 | % |  | 2.5 | % |
| Dividend yield, % | — | % |  | — | % |

[0000926326-16-000057:notes:136]
|  | Three months ended |
|  | March 31, 2016 |  | March 31, 2015 |
|  | (In thousands, except percentages) |
| Employee Stock Purchase Plan |  |  |  |
| Expected life, years | 0.5-2.0 |  |  | 0.5-2.0 |  |
| Expected volatility, % | 25.79-34.79% |  |  | 28.52-37.53% |  |
| Risk free interest rate, % | 0.26-0.79% |  |  | 0.03-0.53% |  |
| Dividend yield, % | — | % |  | — | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-16-000057:notes:137]
[same as prior period, unchanged from 0000926326-15-000035:notes:129]

[0000926326-16-000057:notes:138]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations.  Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level.  Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.  The two operating segments, which are the same as the Company's two reportable segments, are as follows:

[0000926326-16-000057:notes:139]
[same as prior period, unchanged from 0000926326-15-000035:notes:133]

[0000926326-16-000057:notes:140]
The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. The Automation and Analytics products are designed to enable the Company's customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, the Company's systems can be tailored to specific customer needs. The financial results of Aesynt acquired in the first quarter of 2016 are included in the Automation and Analytics segment.

[0000926326-16-000057:notes:141]
[same as prior period, unchanged from 0000926326-15-000035:notes:135]

[0000926326-16-000057:notes:142]
The Medication Adherence segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand names MTS Medication Technologies ("MTS"), Surgichem Limited ("Surgichem"), and under the Omnicell and SureMed brands. MTS products consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care, and correctional facilities or retail pharmacies serving patients in their local communities.

[0000926326-16-000057:notes:143]
[same as prior period, unchanged from 0000926326-15-000035:notes:137]

[0000926326-16-000057:notes:144]
There were no customers that accounted for more than 10% of our total revenues for the three months ended March 31, 2016 and March 31, 2015.

[0000926326-16-000057:notes:145]
Geographical Information

[0000926326-16-000057:notes:146]
Property and equipment, net is attributed to the geographic location in which it is located.


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0000926326-16-000057:notes:147]
A summary of the performance-based restricted stock activity under the Plan is presented below:

[0000926326-16-000057:notes:148]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Performance-based Restricted Stock Units ("PSU") |  |  |  |
| Outstanding at December 31, 2015 | 151 |  |  | $ | 23.33 |  |
| Granted | 123 |  |  | 24.66 |  |
| Vested | (15 | ) |  | 29.56 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at March 31, 2016 | 259 |  |  | $ | 23.60 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-16-000057:notes:149]
[same as prior period, unchanged from 0000926326-15-000035:notes:141]

[0000926326-16-000057:notes:150]
[same as prior period, unchanged from 0000926326-15-000035:notes:142]

[0000926326-16-000057:notes:151]
For a detailed explanation of the Company's stock plans and subsequent changes, please refer to Note 11, Employee Benefits and Stock-Based Compensation, of its Annual Report on Form 10-K for the year ended December 31, 2015, filed with the SEC on February 26, 2016.

[0000926326-16-000057:notes:152]
[same as prior period, unchanged from 0000926326-15-000035:notes:144]

[0000926326-16-000057:notes:153]
[same as prior period, unchanged from 0000926326-15-000035:notes:146]

[0000926326-16-000057:notes:154]
The weighted-average fair value per share of options granted during the three months ended March 31, 2016, was $8.51, and the weighted-average fair value per share of options granted during the months ended March 31, 2015 was $9.82. The intrinsic value of options exercised during the three months ended March 31, 2016 and March 31, 2015 was $0.7 million and $2.4 million, respectively.

[0000926326-16-000057:notes:155]
As of March 31, 2016, total unrecognized compensation cost related to unvested stock options was $11.3 million, which is expected to be recognized over a weighted-average vesting period of 3.1 years.

[0000926326-16-000057:notes:156]
[same as prior period, unchanged from 0000926326-15-000035:notes:149]

[0000926326-16-000057:notes:157]
The weighted-average grant date fair value per share of RSU granted during the three months ended March 31, 2016  and March 31, 2015 was $27.77 and $33.97, respectively.

[0000926326-16-000057:notes:158]
As of March 31, 2016, total unrecognized compensation expense related to RSUs was $10.7 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.8 years.

[0000926326-16-000057:notes:159]
As of March 31, 2016, total unrecognized compensation cost related to RSAs was $0.1 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.2 years.

[0000926326-16-000057:notes:160]
[same as prior period, unchanged from 0000926326-15-000035:notes:154]

[0000926326-16-000057:notes:161]
The weighted-average grant date fair value per share of PSUs granted during the three months ended March 31, 2016 and March 31, 2015 was $24.66 and $29.56, respectively. As of March 31, 2016, total unrecognized compensation cost related to PSUs was approximately $3.2 million, which is expected to be recognized over the remaining weighted-average period of 1.5 years.

[0000926326-16-000057:notes:162]
Employee Stock Purchase Plan activity

[0000926326-16-000057:notes:163]
As of March 31, 2016, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $7.1 million and is expected to be recognized over a weighted-average period of two years.

[0000926326-16-000057:notes:164]
[same as prior period, unchanged from 0000926326-15-000035:notes:159]

[0000926326-16-000057:notes:165]
During the three month period ended March 31 2016 and March 31, 2015, the Company did not repurchase any common stock outstanding.


## us-gaap:SubsequentEventsTextBlock

[0000926326-16-000057:notes:166]
Subsequent Events

[0000926326-16-000057:notes:167]
During the second quarter of 2016, the Company integrated its Sales and Field teams in North America to better serve its customers which resulted in a reduction in headcount of 34 employees. Accordingly, the Company will accrue approximately $1.5 million of restructuring charges in the second quarter ending June 30, 2016, based on agreements with terminated employees covering salary and benefit continuation.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-16-000057:notes:168]
[same as prior period, unchanged from 0000926326-15-000035:notes:163]
