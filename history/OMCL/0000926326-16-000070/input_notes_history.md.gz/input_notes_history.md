# OMCL note change history — 0000926326-16-000057 → 0000926326-16-000070


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0000926326-16-000070:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment.  At June 30, 2016, the minimum future payments on non-cancelable operating leases were as follows:
  (was, 2016-05-06, similarity 0.983):
[0000926326-16-000057:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment.  At March 31, 2016, the minimum future payments on non-cancelable operating leases were as follows:

- changed (2016-08-05):
[0000926326-16-000070:note_history:2]
|  | (In thousands) |
| Remaining six months of 2016 | $ | 5,343 |  |
| 2017 | 10,549 |  |
| 2018 | 10,141 |  |
| 2019 | 9,897 |  |
| 2020 | 6,270 |  |
| Thereafter | 10,711 |  |
| Total minimum future lease payments | $ | 52,911 |  |
  (was, 2016-05-06, similarity 0.9861):
[0000926326-16-000057:note_history:2]
|  | (In thousands) |
| Remaining nine months of 2016 | $ | 7,996 |  |
| 2017 | 10,441 |  |
| 2018 | 9,921 |  |
| 2019 | 9,802 |  |
| 2020 | 6,256 |  |
| Thereafter | 10,870 |  |
| Total minimum future lease payments | $ | 55,286 |  |

- changed (2016-08-05):
[0000926326-16-000070:note_history:3]
During the course of the business, the Company issues purchase orders based on its current manufacturing needs.  At June 30, 2016, the Company had non-cancelable purchase commitments of $39.6 million, which are expected to be paid within the next twelve months.
  (was, 2016-05-06, similarity 0.9821):
[0000926326-16-000057:note_history:3]
During the course of the business, the Company issues purchase orders based on its current manufacturing needs.  At March 31, 2016, the Company had non-cancelable purchase commitments of $38.9 million, which are expected to be paid within the next twelve months.

- changed (2016-08-05):
[0000926326-16-000070:note_history:4]
The Company’s legal proceeding as of June 30, 2016 was as follows:
  (was, 2016-05-06, similarity 0.8702):
[0000926326-16-000057:note_history:4]
The Company’s pending legal proceeding as of March 31, 2016 was as follows:

- added (2016-08-05):
[0000926326-16-000070:note_history:5]
On September 12, 2014, MV Circuit Design, Inc., an Ohio company ("MV Circuit"), brought an action to correct the inventorship of certain patents owned by the Company, as well as related state-law claims against the Company in the Northern District of Ohio (Case No. 1:14-cv-02028-DAP) regarding allegations of fraud in the filing and prosecution of U.S. Patent Nos. 8,180,485, 8,773,270, 8,812,153, PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505 (the “Action”). On November 14, 2014, the Company filed a Motion to Dismiss the Action.  On March 24, 2015, the Court issued an Order granting in part and denying in part the Motion to Dismiss. Specifically, the Court granted the Company's Motion to Dismiss with respect to Counts 4, 5, and 6 (declaratory judgments regarding PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505) and count 13 (civil conspiracy). Following an initial Case Management Conference on April 22, 2015, the Court ordered the parties to conduct limited discovery and actively discuss settlement options. On May 17, 2016 the parties reached a settlement agreement in which MV Circuit would dismiss the remaining claims and Omnicell would assign certain patents related to mobile medical cart to MV Circuit.  Omnicell has retained or secured all rights to continue to develop, manufacture, produce, market, license and sell all of its mobile cart product lines, including our SavvyTM mobile medication workstation.   On June 1, 2016, the Court dismissed the case with prejudice.

- removed (2016-08-05):
[0000926326-16-000057:note_history:6]
On September 12, 2014, MV Circuit Design, Inc., an Ohio company ("MV Circuit"), brought an action to correct the inventorship of certain patents owned by the Company, as well as related state-law claims against the Company in the Northern District of Ohio (Case No. 1:14-cv-02028-DAP) regarding allegations of fraud in the filing and prosecution of U.S. Patent Nos. 8,180,485, 8,773,270, 8,812,153, PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505 (the “Action”). On November 14, 2014, the Company filed a Motion to Dismiss the Action. MV Circuit responded on January 29, 2015, and the Company replied in support of its Motion to Dismiss on February 17, 2015. On March 24, 2015, the Court issued an Order granting in part and denying in part the Motion to Dismiss. Specifically, the Court granted the Company's Motion to Dismiss with respect to Counts 4, 5, and 6 (declaratory judgments regarding PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505) and count 13 (civil conspiracy). The Court denied the Company's Motion to Dismiss with respect to Count 9 (fraud), Count 7 (fraudulent concealment) and Count 8 (negligent misrepresentation). The Company filed an Answer to the Complaint on April 8, 2015. Following an initial Case Management Conference on April 22, 2015, the Court ordered MV Circuit and the Company to make a limited initial production of documents. The parties completed this initial document production and have held further conference calls with the Court to report on their settlement negotiations.  During a conference call held on February 11, 2016, the Court set a deadline of March 14, 2016 for the parties to either file notification of settlement or a proposed litigation schedule. The parties have requested three extensions of the March 14th deadline, with the current deadline requested for June 10, 2016.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0000926326-16-000070:note_history:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2016 and December 31, 2015, the results of its operations, comprehensive income (loss) and cash flows for the three and six months ended June 30, 2016 and June 30, 2015. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2015 filed with the SEC on February 26, 2016. The Company's results of operations, comprehensive income (loss) and cash flows for the three and six months ended June 30, 2016 are not necessarily indicative of results that may be expected for the year ending December 31, 2016, or for any future period.
  (was, 2016-05-06, similarity 0.8727):
[0000926326-16-000057:note_history:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2016 and December 31, 2015, the results of their operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2016 and March 31, 2015. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2015 filed with the SEC on February 26, 2016. The Company's results of operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2016 are not necessarily indicative of results that may be expected for the year ending December 31, 2016, or for any future period.

- changed (2016-08-05):
[0000926326-16-000070:note_history:8]
On January 5, 2016, the Company completed the acquisition of all of the membership interests of Aesynt Holding Coöperatief U.A. ("Aesynt"). The significant accounting policies of Aesynt have been aligned to conform to such accounting policies of Omnicell, and the consolidated financial statements include the results of operations of Aesynt commencing as of the acquisition date.
  (was, 2016-05-06, similarity 0.988):
[0000926326-16-000057:note_history:8]
On January 5, 2016, the Company completed the acquisition of all of the membership interests of Aesynt Holding Coöperatief U.A. ("Aesynt"). The significant accounting policies of Aesynt have been aligned to conform to those accounting policies of Omnicell, and the consolidated financial statements include the results of operations of Aesynt commencing as of the acquisition date.

- changed (2016-08-05):
[0000926326-16-000070:note_history:9]
Segment reporting
  (was, 2016-05-06, similarity 0.8293):
[0000926326-16-000057:note_history:9]
Segment reporting change

- changed (2016-08-05):
[0000926326-16-000070:note_history:10]
The operating results of the recently acquired Aesynt business are included in the Company's Automation and Analytics reportable segment.
  (was, 2016-05-06, similarity 0.9559):
[0000926326-16-000057:note_history:10]
The operating results of the recently acquired Aesynt business is included in the Company's Automation and Analytics reporting segment.

- changed (2016-08-05):
[0000926326-16-000070:note_history:11]
Financial instruments that may potentially subject the Company to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of the Company's accounts receivable are derived from sales to customers for commercial applications. The Company performs ongoing credit evaluations of its customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. The Company maintains reserves for potential credit losses. The Company's products are broadly distributed and there were no customers that accounted for more than 10% of its accounts receivable as of June 30, 2016 and December 31, 2015. The Company believes that it has no significant concentrations of credit risk as of June 30, 2016.
  (was, 2016-05-06, similarity 0.9902):
[0000926326-16-000057:note_history:11]
Financial instruments that may potentially subject the Company to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of the Company's accounts receivable are derived from sales to customers for commercial applications. The Company performs ongoing credit evaluations of its customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. The Company maintains reserves for potential credit losses. The Company's products are broadly distributed and there were no customers that accounted for more than 10% of its accounts receivable as of March 31, 2016 and December 31, 2015. The Company believes that it has no significant concentrations of credit risk as of March 31, 2016.

- added (2016-08-05):
[0000926326-16-000070:note_history:12]
Interest rate swap agreements

- added (2016-08-05):
[0000926326-16-000070:note_history:13]
During the second quarter of 2016, the Company entered into interest rate swap agreements. The interest rate swap agreements, at their inception, qualified for and were designated as cash flow hedging instruments. In accordance with the Derivatives and Hedging Topic of the Accounting Standards Codification ("ASC"), the Company records its interest rate swaps on its condensed consolidated balance sheet at fair value. The effective portion of changes in fair value are recorded in accumulated other comprehensive loss and are subsequently reclassified into earnings in the period that the hedged forecasted transaction affects earnings. Any ineffective portion is recognized in earnings. Both at inception and on a quarterly basis, the Company performs an effectiveness test. For further information regarding these interest rate swap agreements, please refer to  Note 4, "Derivative Financial Instruments" below.

- added (2016-08-05):
[0000926326-16-000070:note_history:14]
In April 2015, the Financial Accounting Standards Board ("FASB") issued ASU 2015-05-Intangibles-Goodwill and Other-Internal-Use Software- Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The Company adopted ASU 2015-05 on a prospective basis beginning on January 1, 2016. The impact of ASU 2015-05 did not have a material impact on the Company's consolidated financial position or results of operations for the three and six months ended June 30, 2016.

- changed (2016-08-05):
[0000926326-16-000070:note_history:15]
In July 2015, the FASB issued ASU No. 2015-11, Simplifying the Measurement of Inventory. This ASU changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. It applies to entities that measure inventory using a method other than last-in, first-out (LIFO) and the retail inventory method (RIM). The guidance is effective for fiscal years beginning after December 15, 2016. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three and six months ended June 30, 2016.
  (was, 2016-05-06, similarity 0.9575):
[0000926326-16-000057:note_history:15]
In July 2015, the FASB issued ASU No. 2015-11, Simplifying the Measurement of Inventory. The new guidance changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. It applies to entities that measure inventory using a method other than last-in, first-out (LIFO) and the retail inventory method (RIM). The new guidance is effective for fiscal years beginning after December 15, 2016. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three months ended March 31, 2016.

- changed (2016-08-05):
[0000926326-16-000070:note_history:16]
In September 2015, the FASB issued ASU No. 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments. This ASU requires adjustments to provisional amounts that are identified during the measurement period of a business combination to be recognized in the reporting period in which the adjustment amounts are determined. An acquirer is no longer required to revise comparative information for prior periods as if the accounting for the business combination had been completed as of the acquisition date. The provisions of ASU 2015-16 are effective for reporting periods beginning after December 15, 2015. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three and six months ended June 30, 2016.
  (was, 2016-05-06, similarity 0.9552):
[0000926326-16-000057:note_history:16]
In September 2015, the FASB issued ASU No. 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments ("ASU 2015-16"). This ASU requires adjustments to provisional amounts that are identified during the measurement period of a business combination to be recognized in the reporting period in which the adjustment amounts are determined. An acquirer is no longer required to revise comparative information for prior periods as if the accounting for the business combination had been completed as of the acquisition date. The provisions of ASU 2015-16 are effective for reporting periods beginning after December 15, 2015. The adoption of this accounting standard update did not have any impact on the Company's consolidated financial position or results of operations for the three months ended March 31, 2016.

- changed (2016-08-05):
[0000926326-16-000070:note_history:17]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted for any entity in any interim or annual period. If an entity early adopts the amendments in an interim period, any adjustments are reflected as of the beginning of the fiscal year that includes that interim period. An entity that elects early adoption must adopt all of the amendments in the same period. The Company is currently in the process of evaluating the impact of the early adoption of ASU 2016-09 on its consolidated financial statements.
  (was, 2016-05-06, similarity 0.997):
[0000926326-16-000057:note_history:17]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted for any entity in any interim or annual period. If an entity early adopts the amendments in an interim period, any adjustments are reflected as of the beginning of the fiscal year that includes that interim period. An entity that elects early adoption must adopt all of the amendments in the same period. The Company is currently in the process of evaluating the impact of the adoption of ASU 2016-09 on its consolidated financial statements.

- changed (2016-08-05):
[0000926326-16-000070:note_history:18]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company's Condensed Consolidated Financial Statements through the reporting date.
  (was, 2016-05-06, similarity 0.8743):
[0000926326-16-000057:note_history:18]
There was no other recently issued authoritative guidance that has a material impact on our Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0000926326-16-000070:note_history:19]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio.  The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.  The Company was in full compliance with all covenants as of June 30, 2016.
  (was, 2016-05-06, similarity 0.9963):
[0000926326-16-000057:note_history:19]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio.  The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.  The Company was in full compliance with all covenants as of March 31, 2016.

- changed (2016-08-05):
[0000926326-16-000070:note_history:20]
The components of the Company’s debt obligations as of June 30, 2016 and December 31, 2015 are as follows:
  (was, 2016-05-06, similarity 0.9534):
[0000926326-16-000057:note_history:20]
The components of the Company’s debt obligations as of March 31, 2016 and December 31, 2015 are as follows:

- added (2016-08-05):
[0000926326-16-000070:note_history:21]
|  | December 31, 2015 | Borrowings | Repayment/Amortization | June 30, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | (2,500 | ) | $ | 197,500 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (22,500 | ) | 232,500 |  |
| Less: Deferred issuance cost | — |  | (7,949 | ) | 795 |  | (7,154 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (21,705 | ) | 225,346 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 216,936 |  |

- changed (2016-08-05):
[0000926326-16-000070:note_history:22]
(1) The fair value of total debt under the facilities approximates the book value as of June 30, 2016.
  (was, 2016-05-06, similarity 0.9534):
[0000926326-16-000057:note_history:22]
(1) The fair value of total debt under the facilities approximates the book value as of March 31, 2016.

- removed (2016-08-05):
[0000926326-16-000057:note_history:23]
|  | December 31, 2015 | Additions | Repayment/amortization | March 31, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | — |  | $ | 200,000 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (20,000 | ) | 235,000 |  |
| Less: Deferred issuance cost |  | (7,949 | ) | 397 |  | (7,552 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (19,603 | ) | 227,448 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 219,038 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0000926326-16-000070:note_history:24]
The components of the Company’s debt obligations as of June 30, 2016 and December 31, 2015 are as follows:
  (was, 2016-05-06, similarity 0.9534):
[0000926326-16-000057:note_history:24]
The components of the Company’s debt obligations as of March 31, 2016 and December 31, 2015 are as follows:

- added (2016-08-05):
[0000926326-16-000070:note_history:25]
|  | December 31, 2015 | Borrowings | Repayment/Amortization | June 30, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | (2,500 | ) | $ | 197,500 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (22,500 | ) | 232,500 |  |
| Less: Deferred issuance cost | — |  | (7,949 | ) | 795 |  | (7,154 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (21,705 | ) | 225,346 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 216,936 |  |

- changed (2016-08-05):
[0000926326-16-000070:note_history:26]
(1) The fair value of total debt under the facilities approximates the book value as of June 30, 2016.
  (was, 2016-05-06, similarity 0.9534):
[0000926326-16-000057:note_history:26]
(1) The fair value of total debt under the facilities approximates the book value as of March 31, 2016.

- removed (2016-08-05):
[0000926326-16-000057:note_history:27]
|  | December 31, 2015 | Additions | Repayment/amortization | March 31, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | — |  | $ | 200,000 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (20,000 | ) | 235,000 |  |
| Less: Deferred issuance cost |  | (7,949 | ) | 397 |  | (7,552 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (19,603 | ) | 227,448 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 219,038 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2016-08-05):
[0000926326-16-000070:note_history:28]
On August 2, 2016, the Board of Directors (the "Board") of Omnicell, Inc. (the “Company”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”).

- added (2016-08-05):
[0000926326-16-000070:note_history:29]
The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of June 30, 2016, the maximum dollar value of shares that may yet be purchased under the 2014 Repurchase Program was $4.9 million.

- added (2016-08-05):
[0000926326-16-000070:note_history:30]
The timing, price and volume of repurchases are to be based on market conditions, relevant securities laws and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions or pursuant to a Rule 10b-18 plan, subject to the terms and conditions of that certain Credit Agreement, dated as of January 5, 2016, among the Company, the Lenders party thereto, and Wells Fargo Bank, National Association, as administrative agent. The stock repurchase program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase program at any time.

- removed (2016-08-05):
[0000926326-16-000057:note_history:31]
During the second quarter of 2016, the Company integrated its Sales and Field teams in North America to better serve its customers which resulted in a reduction in headcount of 34 employees. Accordingly, the Company will accrue approximately $1.5 million of restructuring charges in the second quarter ending June 30, 2016, based on agreements with terminated employees covering salary and benefit continuation.
