# OMCL notes — 0000926326-16-000070


## omcl:ScheduleofLongTermNetInvestmentinSaleTypeLeasesTableTextBlock

[0000926326-16-000070:notes:1]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at June 30, 2016 and December 31, 2015:

[0000926326-16-000070:notes:2]
|  | June 30, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Minimum lease payments to be received, net | $ | 30,273 |  |  | $ | 22,255 |  |
| Less: Unearned interest income portion | (2,638 | ) |  | (1,014 | ) |
| Investment in sales-type leases, net | 27,635 |  |  | 21,241 |  |
| Less: Short-term investment in sales-type leases, net(1) | (7,924 | ) |  | (6,757 | ) |
| Long-term investment in sales-type leases, net | $ | 19,711 |  |  | $ | 14,484 |  |

[0000926326-16-000070:notes:3]
(1) The short-term portion of the net investments in sales-type leases are included in Other current assets on the Condensed Consolidated Balance Sheets.


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-16-000070:notes:4]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of June 30, 2016:

[0000926326-16-000070:notes:5]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 2,826 |  |
| Non-vested restricted share awards | 682 |  |
| Shares authorized for future issuance | 2,904 |  |
| ESPP shares available for future issuance | 3,053 |  |
| Total shares reserved for future issuance | 9,465 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-16-000070:notes:6]
[same as prior period, unchanged from 0000926326-16-000057:notes:6]

[0000926326-16-000070:notes:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2016 and December 31, 2015, the results of its operations, comprehensive income (loss) and cash flows for the three and six months ended June 30, 2016 and June 30, 2015. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2015 filed with the SEC on February 26, 2016. The Company's results of operations, comprehensive income (loss) and cash flows for the three and six months ended June 30, 2016 are not necessarily indicative of results that may be expected for the year ending December 31, 2016, or for any future period.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000926326-16-000070:notes:8]
The following table presents certain unaudited pro forma information for illustrative purposes only, for the six months ended June 30, 2016 and 2015 as if Aesynt had been acquired on January 1, 2015. The pro forma information is not indicative of what would have occurred had the acquisitions taken place on January 1, 2015. The unaudited pro forma information combines the historical results of the acquisitions with the Company's consolidated historical results and includes certain adjustments reflecting the estimated impact of fair value adjustments for the respective periods. The pro forma adjustments include the impact of fair value adjustment related to deferred revenue, inventory fair value adjustment, amortization of intangible assets, stock-based compensation expense, interest expense and amortization of deferred issuance cost, and certain classification to conform to Omnicell's accounting policies.

[0000926326-16-000070:notes:9]
|  | Six months ended June 30, |
|  | 2016 |  | 2015 |
|  | (In thousands, except per share data) |
| Pro forma net revenues | $ | 343,911 |  | $ | 318,464 |  |
| Pro forma net loss | $ | (1,537 | ) | $ | (764 | ) |
| Pro forma net loss per share basic | $ | (0.04 | ) | $ | (0.02 | ) |
| Pro forma net loss per share diluted | $ | (0.04 | ) | $ | (0.02 | ) |


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-16-000070:notes:10]
[same as prior period, unchanged from 0000926326-16-000057:notes:10]

[0000926326-16-000070:notes:11]
On a recurring basis, we enter into sales-type lease transactions which vary in length from one to five years. The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at June 30, 2016 and December 31, 2015:

[0000926326-16-000070:notes:12]
The Company evaluates its sales-type leases individually and collectively for impairment.  The allowance for credit losses were $0.3 million and $0.2 million as of June 30, 2016 and of December 31, 2015, respectively.

[0000926326-16-000070:notes:13]
At June 30, 2016, the future minimum lease payments under sales-type leases are as follows:

[0000926326-16-000070:notes:14]
|  | June 30, 2016 |
|  | (In thousands) |
| Remaining six months of 2016 | $ | 4,677 |  |
| 2017 | 8,340 |  |
| 2018 | 6,712 |  |
| 2019 | 4,933 |  |
| 2020 | 3,080 |  |
| Thereafter | 2,531 |  |
| Total | $ | 30,273 |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-16-000070:notes:15]
Commitments and Contingencies

[0000926326-16-000070:notes:16]
Lease commitments

[0000926326-16-000070:notes:17]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment.  At June 30, 2016, the minimum future payments on non-cancelable operating leases were as follows:

[0000926326-16-000070:notes:18]
|  | (In thousands) |
| Remaining six months of 2016 | $ | 5,343 |  |
| 2017 | 10,549 |  |
| 2018 | 10,141 |  |
| 2019 | 9,897 |  |
| 2020 | 6,270 |  |
| Thereafter | 10,711 |  |
| Total minimum future lease payments | $ | 52,911 |  |

[0000926326-16-000070:notes:19]
Purchase obligations

[0000926326-16-000070:notes:20]
During the course of the business, the Company issues purchase orders based on its current manufacturing needs.  At June 30, 2016, the Company had non-cancelable purchase commitments of $39.6 million, which are expected to be paid within the next twelve months.

[0000926326-16-000070:notes:21]
Legal Proceedings

[0000926326-16-000070:notes:22]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-16-000070:notes:23]
The Company’s legal proceeding as of June 30, 2016 was as follows:

[0000926326-16-000070:notes:24]
On September 12, 2014, MV Circuit Design, Inc., an Ohio company ("MV Circuit"), brought an action to correct the inventorship of certain patents owned by the Company, as well as related state-law claims against the Company in the Northern District of Ohio (Case No. 1:14-cv-02028-DAP) regarding allegations of fraud in the filing and prosecution of U.S. Patent Nos. 8,180,485, 8,773,270, 8,812,153, PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505 (the “Action”). On November 14, 2014, the Company filed a Motion to Dismiss the Action.  On March 24, 2015, the Court issued an Order granting in part and denying in part the Motion to Dismiss. Specifically, the Court granted the Company's Motion to Dismiss with respect to Counts 4, 5, and 6 (declaratory judgments regarding PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505) and count 13 (civil conspiracy). Following an initial Case Management Conference on April 22, 2015, the Court ordered the parties to conduct limited discovery and actively discuss settlement options. On May 17, 2016 the parties reached a settlement agreement in which MV Circuit would dismiss the remaining claims and Omnicell would assign certain patents related to mobile medical cart to MV Circuit.  Omnicell has retained or secured all rights to continue to develop, manufacture, produce, market, license and sell all of its mobile cart product lines, including our SavvyTM mobile medication workstation.   On June 1, 2016, the Court dismissed the case with prejudice.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-16-000070:notes:25]
[same as prior period, unchanged from 0000926326-16-000057:notes:25]

[0000926326-16-000070:notes:26]
[same as prior period, unchanged from 0000926326-16-000057:notes:26]


## us-gaap:DebtDisclosureTextBlock

[0000926326-16-000070:notes:27]
Debt

[0000926326-16-000070:notes:28]
On January 5, 2016, the Company entered into a $400 million senior secured credit facility pursuant to a credit agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200 million (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-16-000070:notes:29]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the 2016 Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-16-000070:notes:30]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-16-000070:notes:31]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio.  The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.  The Company was in full compliance with all covenants as of June 30, 2016.

[0000926326-16-000070:notes:32]
On January 5, 2016, the Company borrowed the full $200 million under the Term Loan Facility and $55 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses. In connection with these Facilities, the Company incurred $7.9 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021.

[0000926326-16-000070:notes:33]
The components of the Company’s debt obligations as of June 30, 2016 and December 31, 2015 are as follows:

[0000926326-16-000070:notes:34]
|  | December 31, 2015 | Borrowings | Repayment/Amortization | June 30, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | (2,500 | ) | $ | 197,500 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (22,500 | ) | 232,500 |  |
| Less: Deferred issuance cost | — |  | (7,949 | ) | 795 |  | (7,154 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (21,705 | ) | 225,346 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 216,936 |  |

[0000926326-16-000070:notes:35]
(1) The fair value of total debt under the facilities approximates the book value as of June 30, 2016.


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-16-000070:notes:36]
[same as prior period, unchanged from 0000926326-16-000057:notes:36]

[0000926326-16-000070:notes:37]
Short-term deferred revenue includes deferred revenue from product sales and service contracts, net of deferred cost of sales of $17.9 million and $15.7 million as of June 30, 2016 and December 31, 2015, respectively. The short-term deferred revenues from product sales relate to the delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

[0000926326-16-000070:notes:38]
Long-term deferred revenue includes deferred revenue from the service contracts of $17.5 million and $18.0 million, as of June 30, 2016 and December 31, 2015, respectively.


## us-gaap:EarningsPerShareTextBlock

[0000926326-16-000070:notes:39]
[same as prior period, unchanged from 0000926326-16-000057:notes:39]

[0000926326-16-000070:notes:40]
Basic net income (loss) per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. Diluted net income per share is computed by dividing net income for the period by the weighted-average number of shares, less shares repurchased, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. The anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net loss per share because their effect would have been anti-dilutive.

[0000926326-16-000070:notes:41]
The calculation of basic and diluted net (loss) income  per share is as follows:

[0000926326-16-000070:notes:42]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (In thousands, except per share data) |
| Net (loss) income | $ | (1,159 | ) |  | $ | 8,751 |  |  | $ | (1,537 | ) |  | $ | 15,069 |  |
| Weighted-average shares outstanding — basic | 35,987 |  |  | 36,120 |  |  | 35,864 |  |  | 36,072 |  |
| Effect of dilutive securities from stock award plans | — |  |  | 910 |  |  | — |  |  | 915 |  |
| Weighted-average shares outstanding — diluted | $ | 35,987 |  |  | $ | 37,030 |  |  | 35,864 |  |  | 36,987 |  |
| Net (loss) income per share — basic | $ | (0.03 | ) |  | $ | 0.24 |  |  | $ | (0.04 | ) |  | $ | 0.42 |  |
| Net (loss) income per share — diluted | $ | (0.03 | ) |  | $ | 0.24 |  |  | $ | (0.04 | ) |  | $ | 0.41 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 1,961 |  |  | 377 |  |  | 2,037 |  |  | 356 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-16-000070:notes:43]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of June 30, 2016:

[0000926326-16-000070:notes:44]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Money market fund | $ | 10,126 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,126 |  |
| Forward contracts | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total financial assets | $ | 10,126 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 10,132 |  |
| Contingent consideration liability(1) | — |  |  | — |  |  | 2,913 |  |  | 2,913 |  |
| Total financial liabilities | $ | — |  |  | $ | — |  |  | $ | 2,913 |  |  | $ | 2,913 |  |

[0000926326-16-000070:notes:45]
(1) The significant unobservable inputs used in the fair value measurement of the contingent consideration related to the Avantec acquisition classified as Level 3 above are the achievement of booking targets and the discount rate.

[0000926326-16-000070:notes:46]
[same as prior period, unchanged from 0000926326-16-000057:notes:46]

[0000926326-16-000070:notes:47]
[same as prior period, unchanged from 0000926326-16-000057:notes:47]

[0000926326-16-000070:notes:48]
[same as prior period, unchanged from 0000926326-16-000057:notes:45]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000926326-16-000070:notes:49]
The cash and cash equivalents at June 30, 2016 and December 31, 2015 were as follows:

[0000926326-16-000070:notes:50]
|  | June 30, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Cash | $ | 30,903 |  |  | $ | 72,103 |  |
| Money market fund | 10,126 |  |  | 10,114 |  |
| Total cash and cash equivalents | $ | 41,029 |  |  | $ | 82,217 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-16-000070:notes:51]
[same as prior period, unchanged from 0000926326-16-000057:notes:50]

[0000926326-16-000070:notes:52]
Cash and cash equivalents as of June 30, 2016 and December 31, 2015 include cash and money market funds, which have original maturities of three months or less.  Due to the short duration to maturity, the carrying value of such financial instruments approximates the estimated fair value.

[0000926326-16-000070:notes:53]
[same as prior period, unchanged from 0000926326-16-000057:notes:52]

[0000926326-16-000070:notes:54]
[same as prior period, unchanged from 0000926326-16-000057:notes:53]

[0000926326-16-000070:notes:55]
[same as prior period, unchanged from 0000926326-16-000057:notes:54]

[0000926326-16-000070:notes:56]
[same as prior period, unchanged from 0000926326-16-000057:notes:55]

[0000926326-16-000070:notes:57]
[same as prior period, unchanged from 0000926326-16-000057:notes:56]

[0000926326-16-000070:notes:58]
The aggregate notional amounts of the Company's outstanding foreign exchange contracts as of June 30, 2016 and December 31, 2015 were $0.1 million and $0.4 million, respectively. The aggregate fair values of these outstanding foreign exchange contracts as of June 30, 2016 and December 31, 2015 were less than $0.1 million.

[0000926326-16-000070:notes:59]
Interest Rate Swaps

[0000926326-16-000070:notes:60]
The Company uses interest rate swap agreement to protect the Company against adverse fluctuations in interest rates by reducing its exposure to variability in cash flows relating to interest payments on a portion of its outstanding debt. The Company's interest rate swaps, which are designated as cash flow hedges, involve the receipt of variable amounts from counterparties in exchange for the Company making fixed-rate payments over the life of the agreements. The Company does not hold or issue any derivative financial instruments for speculative trading purposes.

[0000926326-16-000070:notes:61]
During the second quarter of 2016, the Company entered into interest rate swap agreement with a combined notional amount of $100.0 million with one counter party that are effective beginning on June 30, 2016 and maturing on April 30, 2019. The swap agreement requires the Company to pay a fixed rate of 0.8% and provides that the Company will receive a variable rate based on the one month LIBOR rate subject to LIBOR floor of 0.0%. Amounts payable by or due to the Company will be net settled with the respective counterparties on the last business day of each month, commencing July 31, 2016.

[0000926326-16-000070:notes:62]
The fair value of the interest rate swap agreements at June 30, 2016 were zero and there were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-16-000070:notes:63]
[same as prior period, unchanged from 0000926326-16-000057:notes:58]

[0000926326-16-000070:notes:64]
[same as prior period, unchanged from 0000926326-16-000057:notes:59]

[0000926326-16-000070:notes:65]
[same as prior period, unchanged from 0000926326-16-000057:notes:60]

[0000926326-16-000070:notes:66]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2015 | $ | 54,316 |  |  | $ | 93,590 |  |  | $ | 147,906 |  |
| Goodwill acquired | 165,618 |  |  | — |  |  | 165,618 |  |
| Foreign currency exchange rate fluctuations | (1,282 | ) |  | (1,072 | ) |  | (2,354 | ) |
| Net balance as of June 30, 2016 | $ | 218,652 |  |  | $ | 92,518 |  |  | $ | 311,170 |  |

[0000926326-16-000070:notes:67]
[same as prior period, unchanged from 0000926326-16-000057:notes:62]

[0000926326-16-000070:notes:68]
The carrying amounts of intangibles assets as of June 30, 2016 and December 31, 2015 are as follows:

[0000926326-16-000070:notes:69]
|  | June 30, 2016 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 125,520 |  |  | $ | (14,880 | ) |  | $ | (725 | ) |  | $ | 109,915 |  |  | 1 - 30 |
| Acquired technology | 70,247 |  |  | (9,665 | ) |  | (71 | ) |  | 60,511 |  |  | 3 - 20 |
| Backlog | 20,588 |  |  | (7,138 | ) |  | (10 | ) |  | 13,440 |  |  | 1 - 3 |
| Trade names | 8,587 |  |  | (3,089 | ) |  | (17 | ) |  | 5,481 |  |  | 1 - 12 |
| Patents | 2,153 |  |  | (425 | ) |  | — |  |  | 1,728 |  |  | 2 - 20 |
| Non-compete agreements | 1,800 |  |  | (300 | ) |  | — |  |  | 1,500 |  |  | 3 |
| In-process Technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | - |
| Total intangibles assets, net | $ | 232,795 |  |  | $ | (35,497 | ) |  | $ | (823 | ) |  | $ | 196,475 |  |  |  |

[0000926326-16-000070:notes:70]
[same as prior period, unchanged from 0000926326-16-000057:notes:65]

[0000926326-16-000070:notes:71]
Amortization expense of intangible assets was $9.1 million and $1.8 million for the three months ended June 30, 2016 and June 30, 2015, respectively. Amortization expense of intangible assets was $18.3 million and $3.1 million for the six months ended June 30, 2016 and June 30, 2015, respectively.

[0000926326-16-000070:notes:72]
[same as prior period, unchanged from 0000926326-16-000057:notes:67]

[0000926326-16-000070:notes:73]
|  | June 30, 2016 |
|  | (In thousands) |
| Remaining six months of 2016 | $ | 26,962 |  |
| 2017 | 22,813 |  |
| 2018 | 21,231 |  |
| 2019 | 16,151 |  |
| 2020 | 15,146 |  |
| Thereafter | 90,272 |  |
| Total | $ | 192,575 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-16-000070:notes:74]
[same as prior period, unchanged from 0000926326-16-000057:notes:69]

[0000926326-16-000070:notes:75]
The Company provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 38.3% and 38.5% for the six months ended June 30, 2016 and 2015, respectively. The 2016 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction and the Federal Research & Development credit, which was permanently reinstated on December 18, 2015. The 2015 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.

[0000926326-16-000070:notes:76]
For the six months ended June 2015, the Company had recorded a gain of $3.4 million attributable to the increase in the fair value of Omnicell's 15% minority interest in Avantec which was revalued in conjunction with our purchase of the remaining 85% of Avantec shares. This gain was treated as a discrete item and excluded from profit-before-tax in calculating the annual effective tax rate for the six months ended June 30, 2015.

[0000926326-16-000070:notes:77]
As of June 30, 2016 and December 31, 2015, the Company had gross unrecognized tax benefits of $10.1 million and $7.2 million, respectively. The increase is largely due to unrecognized tax benefits recorded as part of the acquisition of Aesynt. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in operating expense. As of June 30, 2016 and December 31, 2015, the amount of accrued interest and penalties was $1.1 million and $0.2 million, respectively. The increase is attributable to the interest related to Aesynt's reserves.

[0000926326-16-000070:notes:78]
As of June 30, 2016, calendar years 2011 and thereafter are open and subject to potential examination in one or more jurisdictions.  However, because all of the net operating loss and research credit carryforwards that may be used in future years are subject to adjustment, if and when utilized, the Company's federal and California tax years remain open from 1996 and 1992, respectively. The Company is currently under examination by the Internal Revenue Service for the 2011 through 2014 tax years.

[0000926326-16-000070:notes:79]
[same as prior period, unchanged from 0000926326-16-000057:notes:73]


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000926326-16-000070:notes:80]
[same as prior period, unchanged from 0000926326-16-000057:notes:74]

[0000926326-16-000070:notes:81]
|  | June 30, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| United States | $ | 36,727 |  |  | $ | 29,506 |  |
| Rest of world (1) | 3,776 |  |  | 2,803 |  |
| Total property and equipment, net | $ | 40,503 |  |  | $ | 32,309 |  |

[0000926326-16-000070:notes:82]
[same as prior period, unchanged from 0000926326-16-000057:notes:76]

[0000926326-16-000070:notes:83]
[same as prior period, unchanged from 0000926326-16-000057:notes:77]


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000926326-16-000070:notes:84]
[same as prior period, unchanged from 0000926326-16-000057:notes:78]

[0000926326-16-000070:notes:85]
[same as prior period, unchanged from 0000926326-16-000057:notes:79]

[0000926326-16-000070:notes:86]
On January 5, 2016, the Company completed the acquisition of all of the membership interests of Aesynt pursuant to a securities purchase agreement by and among the Company and Aesynt Holding Coöperatief U.A. for total cash consideration of $271.5 million, net of cash on hand at signing of $8.2 million. Aesynt is a provider of automated medication management systems, including central pharmacy dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management.

[0000926326-16-000070:notes:87]
[same as prior period, unchanged from 0000926326-16-000057:notes:81]

[0000926326-16-000070:notes:88]
|  | (In thousands) |
| Cash | $ | 8,164 |  |
| Accounts receivable | 44,412 |  |
| Inventory | 20,111 |  |
| Other current assets | 4,381 |  |
| Total current assets | 77,068 |  |
| Property and equipment | 10,389 |  |
| Intangible assets | 123,700 |  |
| Goodwill | 165,618 |  |
| Other non-current assets | 968 |  |
| Total assets | 377,743 |  |
| Current liabilities | 26,132 |  |
| Deferred revenue, net | 25,631 |  |
| Non-current deferred tax liabilities | 43,927 |  |
| Other non-current liabilities | 2,431 |  |
| Total liabilities | 98,121 |  |
| Total purchase price | 279,622 |  |
| Total purchase price, net of cash received | $ | 271,458 |  |

[0000926326-16-000070:notes:89]
The goodwill arising from this acquisition is primarily attributed to sales of future products and services and the assembled workforce of Aesynt. The Aesynt acquisition created the broadest product portfolio in the industry with significant offerings in automated dispensing systems, central pharmacy robotics, IV robotics and enterprise analytics. Goodwill has been assigned to the Automation & Analytics segment and is not deductible for tax purposes. Goodwill is not being amortized but is reviewed annually for impairment or more frequently if impairment indicators arise, in accordance with authoritative guidance.  During the three months ended June 30, 2016 the Company adjusted the preliminary value assigned to goodwill by $0.8 million to reflect measurement period adjustments related to account receivable and current liabilities of $0.5 million and $0.3 million, respectively.

[0000926326-16-000070:notes:90]
[same as prior period, unchanged from 0000926326-16-000057:notes:84]

[0000926326-16-000070:notes:91]
|  | Fair value |  | Weightedaverageuseful life |
|  | (In thousands) |  | (In years) |
| Customer relationships | $ | 58,200 |  |  | 14-16 |
| Developed technology | 38,800 |  |  | 8 |
| Backlog | 20,200 |  |  | 1-3 |
| In-process research and development ("IPR&D") (1) | 3,900 |  |  | - |
| Non-compete | 1,800 |  |  | 3 |
| Trade names | 800 |  |  | 1 |
| Total purchased intangible assets | $ | 123,700 |  |  |  |

[0000926326-16-000070:notes:92]
(1) The amortization of the in-process R&D assets begin when the in-process R&D projects are complete.

[0000926326-16-000070:notes:93]
Customer relationships represent the fair value of the underlying relationships and agreements with Aesynt’s customers, acquired developed technology represents the fair value of Aesynt products that have reached technological feasibility and were part of Aesynt’s product offerings at the date of acquisition, backlog represents the fair value of sales order backlog at the date of acquisition, non-compete intangible asset represents the fair value of non-compete agreements with former key members of Aesynt's management, and trade name represents the fair value of brand and name recognition associated with the marketing of Aesynt’s products and services. In-process research and development ("IPR&D") represents the fair value of incomplete Aesynt research and development projects that had not reached technological feasibility as of the date of acquisition. Incremental costs incurred for those projects are expensed as incurred in research and development.

[0000926326-16-000070:notes:94]
The fair value of trade names, acquired developed technology, and acquired IPR&D was determined based on an income approach using the relief-from-royalty method at the royalty rates of 0.5%, 4% to 8% and 12.5%, respectively. The fair value of customer relationships, backlog, and non-compete intangible assets were determined based on an income approach using the discounted cash flow method, at the discounted rates of 13%, 10% and 13%, respectively. The intangible assets, except customer relationship and IPR&D, are being amortized over their estimated useful lives using the straight line method of amortization. The customer relationship intangible asset is being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. In accordance with authoritative guidance, the IPR&D is accounted for as an indefinite-lived intangible asset until completion or abandonment of the associated research and development efforts. IPR&D is tested for impairment during the period it is considered an indefinite lived asset. IPR&D related projects are expected to be completed in two to three years. As of June 30, 2016, none of the IPR&D projects has been completed, and they have progressed as previously estimated.

[0000926326-16-000070:notes:95]
The Company incurred approximately $8.0 million in acquisition-related costs related to the Aesynt acquisition of which $2.9 million and $5.1 million was recognized in three and six months ended December 31, 2015 and June 30, 2016, respectively. These costs are included in selling, general and administrative expenses in the Company's Condensed Consolidated Statement of Operations.

[0000926326-16-000070:notes:96]
Revenues and losses from operations since the acquisition date through June 30, 2016 for Aesynt were $82.0 million and $(20.2) million, respectively.  Losses from operations includes the amortization of intangible assets of $14.0 million for the period presented.

[0000926326-16-000070:notes:97]
[same as prior period, unchanged from 0000926326-16-000057:notes:91]

[0000926326-16-000070:notes:98]
[same as prior period, unchanged from 0000926326-16-000057:notes:93]

[0000926326-16-000070:notes:99]
On April 21, 2015, the Company completed the acquisition of Mach4 Automatisierungstechnik GmbH ("Mach4"), a privately held German limited liability company with its registered office in Bochum, Germany, pursuant to a share purchase agreement (the “Mach4 Agreement”), under which Omnicell International, Inc., a wholly-owned subsidiary of Omnicell Inc., purchased the entire issued share capital of Mach4. Pursuant to the terms of Mach4 Agreement, the Company paid approximately $17.3 million in cash, of which $2.7 million was placed in an escrow fund to be distributed to Mach4's former stockholders within 18 months after the closing date of the transaction, subject to indemnification and other claims the Company may make.

[0000926326-16-000070:notes:100]
On April 30, 2015, the Company completed the acquisition of Avantec Healthcare Limited ("Avantec"), the privately-held distributor of Omnicell’s products in the United Kingdom, pursuant to a share purchase agreement (the "Avantec Agreement"), wherein the Company acquired the remaining 85% of issued and outstanding ordinary shares of Avantec not previously owned by the Company. Pursuant to the terms of the Avantec Agreement, the Company agreed to pay $12.0 million in cash and potential earn-out payments of up to $3.0 million payable after December 31, 2015 and an additional $3.0 million payable after December 31, 2016, based on future bookings. The fair value of these potential earn-out payments as of the acquisition date was $5.6 million. Pursuant to the terms of the Avantec Agreement, the Company retained $1.8 million of the purchase consideration to be held for settlement of any future indemnification claims within the 18 month period following the closing of the transaction that the Company may make following the closing of the transaction. The fair value of the contingent consideration liability related to Avantec is revalued at each reporting date or more frequently if circumstances dictate. Changes in the fair value of this obligation are recorded as income or expense within other expense in our condensed consolidated statements of operation. The significant unobservable inputs used in the fair value measurement of the contingent consideration are the achievement of booking targets and the discount rate. Significant increases or decreases in any of those inputs in isolation would result in a significantly lower or higher fair value measurement. During the three months ended March 31, 2016, the Company paid a $3.0 million earn-out payment which was due after December 31, 2015 based on the achievement of certain metrics set forth in the Avantec Agreement.

[0000926326-16-000070:notes:101]
[same as prior period, unchanged from 0000926326-16-000057:notes:96]

[0000926326-16-000070:notes:102]
The following table represents the allocation of the purchase price to the assets acquired and the liabilities assumed by the Company as part of each 2015 acquisition:

[0000926326-16-000070:notes:103]
[same as prior period, unchanged from 0000926326-16-000057:notes:98]

[0000926326-16-000070:notes:104]
[same as prior period, unchanged from 0000926326-16-000057:notes:99]

[0000926326-16-000070:notes:105]
[same as prior period, unchanged from 0000926326-16-000057:notes:100]

[0000926326-16-000070:notes:106]
Total revenues for Mach4 and Avantec for the six months ended June 30, 2016 were $9.8 million and $5.1 million, respectively.  For the corresponding period, total operating losses for Mach4 was $3.0 million and total operating income for Avantec was $0.9 million. The operating loses/income for these entities included the amortization of intangible asset of $0.8 million and $0.5 million for Mach4 and Avantec, respectively.

[0000926326-16-000070:notes:107]
[same as prior period, unchanged from 0000926326-16-000057:notes:102]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-16-000070:notes:108]
Recently adopted authoritative guidance

[0000926326-16-000070:notes:109]
In April 2015, the Financial Accounting Standards Board ("FASB") issued ASU 2015-05-Intangibles-Goodwill and Other-Internal-Use Software- Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The Company adopted ASU 2015-05 on a prospective basis beginning on January 1, 2016. The impact of ASU 2015-05 did not have a material impact on the Company's consolidated financial position or results of operations for the three and six months ended June 30, 2016.

[0000926326-16-000070:notes:110]
In July 2015, the FASB issued ASU No. 2015-11, Simplifying the Measurement of Inventory. This ASU changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. It applies to entities that measure inventory using a method other than last-in, first-out (LIFO) and the retail inventory method (RIM). The guidance is effective for fiscal years beginning after December 15, 2016. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three and six months ended June 30, 2016.

[0000926326-16-000070:notes:111]
In September 2015, the FASB issued ASU No. 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments. This ASU requires adjustments to provisional amounts that are identified during the measurement period of a business combination to be recognized in the reporting period in which the adjustment amounts are determined. An acquirer is no longer required to revise comparative information for prior periods as if the accounting for the business combination had been completed as of the acquisition date. The provisions of ASU 2015-16 are effective for reporting periods beginning after December 15, 2015. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three and six months ended June 30, 2016.

[0000926326-16-000070:notes:112]
Recently issued authoritative guidance

[0000926326-16-000070:notes:113]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted for any entity in any interim or annual period. If an entity early adopts the amendments in an interim period, any adjustments are reflected as of the beginning of the fiscal year that includes that interim period. An entity that elects early adoption must adopt all of the amendments in the same period. The Company is currently in the process of evaluating the impact of the early adoption of ASU 2016-09 on its consolidated financial statements.

[0000926326-16-000070:notes:114]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company's Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0000926326-16-000070:notes:115]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards ("RSAs") |  |  |  |
| Outstanding at December 31, 2015 | 31 |  |  | $ | 35.97 |  |
| Granted | 35 |  |  | 31.59 |  |
| Vested | (31 | ) |  | 36.03 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at June 30, 2016 | 35 |  |  | $ | 31.56 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-16-000070:notes:116]
[same as prior period, unchanged from 0000926326-16-000057:notes:107]

[0000926326-16-000070:notes:117]
[same as prior period, unchanged from 0000926326-16-000057:notes:108]

[0000926326-16-000070:notes:118]
[same as prior period, unchanged from 0000926326-16-000057:notes:109]

[0000926326-16-000070:notes:119]
On January 5, 2016, the Company completed the acquisition of all of the membership interests of Aesynt Holding Coöperatief U.A. ("Aesynt"). The significant accounting policies of Aesynt have been aligned to conform to such accounting policies of Omnicell, and the consolidated financial statements include the results of operations of Aesynt commencing as of the acquisition date.

[0000926326-16-000070:notes:120]
[same as prior period, unchanged from 0000926326-16-000057:notes:111]

[0000926326-16-000070:notes:121]
[same as prior period, unchanged from 0000926326-16-000057:notes:112]

[0000926326-16-000070:notes:122]
Segment reporting

[0000926326-16-000070:notes:123]
[same as prior period, unchanged from 0000926326-16-000057:notes:114]

[0000926326-16-000070:notes:124]
The operating results of the recently acquired Aesynt business are included in the Company's Automation and Analytics reportable segment.

[0000926326-16-000070:notes:125]
[same as prior period, unchanged from 0000926326-16-000057:notes:116]

[0000926326-16-000070:notes:126]
Financial instruments that may potentially subject the Company to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of the Company's accounts receivable are derived from sales to customers for commercial applications. The Company performs ongoing credit evaluations of its customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. The Company maintains reserves for potential credit losses. The Company's products are broadly distributed and there were no customers that accounted for more than 10% of its accounts receivable as of June 30, 2016 and December 31, 2015. The Company believes that it has no significant concentrations of credit risk as of June 30, 2016.

[0000926326-16-000070:notes:127]
Interest rate swap agreements

[0000926326-16-000070:notes:128]
During the second quarter of 2016, the Company entered into interest rate swap agreements. The interest rate swap agreements, at their inception, qualified for and were designated as cash flow hedging instruments. In accordance with the Derivatives and Hedging Topic of the Accounting Standards Codification ("ASC"), the Company records its interest rate swaps on its condensed consolidated balance sheet at fair value. The effective portion of changes in fair value are recorded in accumulated other comprehensive loss and are subsequently reclassified into earnings in the period that the hedged forecasted transaction affects earnings. Any ineffective portion is recognized in earnings. Both at inception and on a quarterly basis, the Company performs an effectiveness test. For further information regarding these interest rate swap agreements, please refer to  Note 4, "Derivative Financial Instruments" below.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-16-000070:notes:129]
Restructuring Expenses

[0000926326-16-000070:notes:130]
During the second quarter of 2016, the Company integrated its Sales and Field organizations in North America to better serve its customers which resulted in a reduction in headcount of 36 employees. Accordingly, the Company incurred approximately $1.7 million of restructuring expenses in the second quarter ending June 30, 2016, based on agreements with terminated employees covering salary and benefit continuation. As of the June 30, 2016 the restructuring program has been concluded.  The Company had paid approximately $1.2 million, the remaining amount of $0.5 million is expected to be paid in the third quarter of 2016.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000926326-16-000070:notes:131]
[same as prior period, unchanged from 0000926326-16-000057:notes:121]

[0000926326-16-000070:notes:132]
|  | Three months ended |
|  | June 30, 2016 |  | June 30, 2015 |
|  | (In thousands) |
| United States | $ | 145,988 |  |  | $ | 95,147 |  |
| Rest of world (1) | 26,919 |  |  | 17,641 |  |
| Total revenues | $ | 172,907 |  |  | $ | 112,788 |  |

[0000926326-16-000070:notes:133]
|  | Six months ended |
|  | June 30, 2016 |  | June 30, 2015 |
|  | (In thousands) |
| United States | $ | 289,481 |  |  | $ | 192,970 |  |
| Rest of world (1) | 54,430 |  |  | 36,039 |  |
| Total revenues | $ | 343,911 |  |  | $ | 229,009 |  |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-16-000070:notes:134]
|  | June 30, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 18,342 |  |  | $ | 11,582 |  |
| Work in process | 6,611 |  |  | 1,653 |  |
| Finished goods | 48,767 |  |  | 33,359 |  |
| Total inventories | $ | 73,720 |  |  | $ | 46,594 |  |
| Property and equipment: |  |  |  |
| Equipment | $ | 55,625 |  |  | $ | 43,533 |  |
| Furniture and fixtures | 5,938 |  |  | 5,897 |  |
| Leasehold improvements | 9,502 |  |  | 9,063 |  |
| Software | 33,508 |  |  | 30,693 |  |
| Construction in progress | 5,931 |  |  | 3,651 |  |
| Property and equipment, gross | 110,504 |  |  | 92,837 |  |
| Accumulated depreciation and amortization | (70,001 | ) |  | (60,528 | ) |
| Total property and equipment, net | $ | 40,503 |  |  | $ | 32,309 |  |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 29,206 |  |  | $ | 26,011 |  |
| Other assets | 1,527 |  |  | 1,883 |  |
| Total other long term assets, net | $ | 30,733 |  |  | $ | 27,894 |  |
| Accrued liabilities: |  |  |  |
| Advance payments from customers | $ | 7,631 |  |  | $ | 8,327 |  |
| Rebates and lease buyouts | 4,163 |  |  | 4,702 |  |
| Group purchasing organization fees | 2,855 |  |  | 2,983 |  |
| Taxes payable | 3,617 |  |  | 2,768 |  |
| Other accrued liabilities | 14,408 |  |  | 11,353 |  |
| Total accrued liabilities | $ | 32,674 |  |  | $ | 30,133 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0000926326-16-000070:notes:135]
[same as prior period, unchanged from 0000926326-16-000057:notes:124]

[0000926326-16-000070:notes:136]
|  | Three months ended | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 | June 30, 2016 |  | June 30, 2015 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 644 |  |  | $ | 532 |  | $ | 1,193 |  |  | $ | 1,049 |  |
| Research and development | 801 |  |  | 451 |  | 1,442 |  |  | 885 |  |
| Selling, general and administrative | 4,050 |  |  | 2,653 |  | 6,751 |  |  | 5,367 |  |
| Total share-based compensation expense | $ | 5,495 |  |  | $ | 3,636 |  | $ | 9,386 |  |  | $ | 7,301 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0000926326-16-000070:notes:137]
The following table summarizes the restricted stock activity under the Company’s equity incentive plans during the six months ended June 30, 2016:

[0000926326-16-000070:notes:138]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units ("RSUs") |  |  |  |  |  |  |  |
| Outstanding at December 31, 2015 | 417 |  |  | $ | 28.49 |  |  | 1.6 |  |  |
| Granted | 104 |  |  | 28.09 |  |  |  |  |  |
| Vested | (78 | ) |  | 25.57 |  |  |  |  |  |
| Forfeited | (17 | ) |  | 27.54 |  |  |  |  |  |
| Outstanding and unvested at June 30, 2016 | 426 |  |  | $ | 28.97 |  |  | 1.43 |  | $ | 14,567 |  |


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0000926326-16-000070:notes:139]
[same as prior period, unchanged from 0000926326-16-000057:notes:128]


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-16-000070:notes:140]
[same as prior period, unchanged from 0000926326-16-000057:notes:129]

[0000926326-16-000070:notes:141]
|  | Three months ended |
|  | June 30, 2016 |  | June 30, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 148,660 |  |  | $ | 24,247 |  |  | $ | 172,907 |  |  | $ | 88,701 |  |  | $ | 24,087 |  |  | $ | 112,788 |  |
| Cost of revenues | 78,366 |  |  | 16,524 |  |  | 94,890 |  |  | 39,403 |  |  | 15,923 |  |  | 55,326 |  |
| Gross profit | 70,294 |  |  | 7,723 |  |  | 78,017 |  |  | 49,298 |  |  | 8,164 |  |  | 57,462 |  |
| Operating expenses | 49,780 |  |  | 5,771 |  |  | 55,551 |  |  | 25,978 |  |  | 5,910 |  |  | 31,888 |  |
| Income from segment operations | $ | 20,514 |  |  | $ | 1,952 |  |  | $ | 22,466 |  |  | $ | 23,320 |  |  | $ | 2,254 |  |  | $ | 25,574 |  |
| Corporate costs |  |  |  |  | 22,584 |  |  |  |  |  |  | 13,150 |  |
| (Loss) Income from operations |  |  |  |  | $ | (118 | ) |  |  |  |  |  | $ | 12,424 |  |

[0000926326-16-000070:notes:142]
|  | Six months ended |
|  | June 30, 2016 |  | June 30, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 297,605 |  |  | $ | 46,306 |  |  | $ | 343,911 |  |  | $ | 181,480 |  |  | $ | 47,529 |  |  | $ | 229,009 |  |
| Cost of revenues | 155,573 |  |  | 30,376 |  |  | 185,949 |  |  | 78,255 |  |  | 31,607 |  |  | 109,862 |  |
| Gross profit | 142,032 |  |  | 15,930 |  |  | 157,962 |  |  | 103,225 |  |  | 15,922 |  |  | 119,147 |  |
| Operating expenses | 101,985 |  |  | 11,382 |  |  | 113,367 |  |  | 54,567 |  |  | 12,251 |  |  | 66,818 |  |
| Income from segment operations | $ | 40,047 |  |  | $ | 4,548 |  |  | $ | 44,595 |  |  | $ | 48,658 |  |  | $ | 3,671 |  |  | $ | 52,329 |  |
| Corporate costs |  |  |  |  | 42,861 |  |  |  |  |  |  | 29,526 |  |
| Income from operations |  |  |  |  | $ | 1,734 |  |  |  |  |  |  | $ | 22,803 |  |

[0000926326-16-000070:notes:143]
[same as prior period, unchanged from 0000926326-16-000057:notes:131]


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000926326-16-000070:notes:144]
The following table summarizes the share option activity under the Company’s equity incentive plans during the six months ended June 30, 2016:

[0000926326-16-000070:notes:145]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value(1) |
|  | (In thousands, except per share data) |
| Stock Options |  |  |  |  |  |  |  |
| Outstanding at December 31, 2015 | 2,688 |  |  | $ | 22.89 |  |  | 6.9 |  |  |
| Granted | 443 |  |  | 28.14 |  |  |  |  |  |
| Exercised | (228 | ) |  | 18.22 |  |  |  |  |  |
| Expired | (4 | ) |  | 27.58 |  |  |  |  |  |
| Forfeited | (73 | ) |  | 28.68 |  |  |  |  |  |
| Outstanding at June 30, 2016 | 2,826 |  |  | $ | 23.94 |  |  | 7.04 |  | $ | 29,422 |  |
| Exercisable at June 30, 2016 | 1,391 |  |  | $ | 18.85 |  |  | 5.11 |  | $ | 21,400 |  |
| Vested and expected to vest at June 30, 2016 and thereafter | 2,660 |  |  | $ | 23.61 |  |  | 6.91 |  | $ | 28,558 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0000926326-16-000070:notes:146]
The following weighted average assumptions are used to value stock options and Employee Stock Purchase Plan ("ESPP") shares issued pursuant to the Company's equity incentive plans for the three and six months ended June 30, 2016 and June 30, 2015:

[0000926326-16-000070:notes:147]
|  | Three months ended |  | Six months ended |
|  | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
|  | (In thousands, except percentages) |
| Stock Option Plans |  |  |  |  |  |  |  |
| Expected life, years | 4.92 |  |  | 5.04 |  |  | 4.92 |  |  | 5.04 |  |
| Expected volatility, % | 31.5 | % |  | 29.3 | % |  | 32.0 | % |  | 32.2 | % |
| Risk free interest rate, % | 1.41 | % |  | 1.51 | % |  | 1.40 | % |  | 1.58 | % |
| Estimated forfeiture rate % | 8.6 | % |  | 2.5 | % |  | 8.6 | % |  | 2.5 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-16-000070:notes:148]
|  | Three months ended |  | Six Months Ended |
|  | June 30, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
|  | (In thousands, except percentages) |
| Employee Stock Purchase Plan |  |  |  |  |  |  |  |
| Expected life, years | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |
| Expected volatility, % | 25.79-34.79% |  |  | 28.52-37.53% |  |  | 25.79-34.79% |  |  | 23.75-35.67% |  |
| Risk free interest rate, % | 0.26-0.79% |  |  | 0.03-0.72% |  |  | 0.26-0.79% |  |  | 0.03-0.72% |  |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-16-000070:notes:149]
[same as prior period, unchanged from 0000926326-16-000057:notes:137]

[0000926326-16-000070:notes:150]
[same as prior period, unchanged from 0000926326-16-000057:notes:138]

[0000926326-16-000070:notes:151]
[same as prior period, unchanged from 0000926326-16-000057:notes:139]

[0000926326-16-000070:notes:152]
[same as prior period, unchanged from 0000926326-16-000057:notes:140]

[0000926326-16-000070:notes:153]
[same as prior period, unchanged from 0000926326-16-000057:notes:141]

[0000926326-16-000070:notes:154]
[same as prior period, unchanged from 0000926326-16-000057:notes:142]

[0000926326-16-000070:notes:155]
[same as prior period, unchanged from 0000926326-16-000057:notes:143]

[0000926326-16-000070:notes:156]
There were no customers that accounted for more than 10% of our total revenues for the three and six months ended June 30, 2016 and June 30, 2015

[0000926326-16-000070:notes:157]
[same as prior period, unchanged from 0000926326-16-000057:notes:145]

[0000926326-16-000070:notes:158]
[same as prior period, unchanged from 0000926326-16-000057:notes:146]


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0000926326-16-000070:notes:159]
The following table summarizes the performance-based restricted stock activity under the Company’s equity incentive plans during the six months ended June 30, 2016:

[0000926326-16-000070:notes:160]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Performance-based Restricted Stock Units ("PSUs") |  |  |  |
| Outstanding at December 31, 2015 | 151 |  |  | $ | 23.33 |  |
| Granted | 122 |  |  | 24.66 |  |
| Vested | (52 | ) |  | 23.04 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at June 30, 2016 | 221 |  |  | $ | 24.13 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-16-000070:notes:161]
[same as prior period, unchanged from 0000926326-16-000057:notes:149]

[0000926326-16-000070:notes:162]
[same as prior period, unchanged from 0000926326-16-000057:notes:150]

[0000926326-16-000070:notes:163]
[same as prior period, unchanged from 0000926326-16-000057:notes:151]

[0000926326-16-000070:notes:164]
[same as prior period, unchanged from 0000926326-16-000057:notes:152]

[0000926326-16-000070:notes:165]
[same as prior period, unchanged from 0000926326-16-000057:notes:153]

[0000926326-16-000070:notes:166]
The weighted-average fair value per share of options granted during the three and six months ended June 30, 2016, was $9.03 and $8.59, respectively, and the weighted-average fair value per share of options granted during the three and six months ended June 30, 2015 was $10.09 and $10.61, respectively. The intrinsic value of options exercised during the three and six months ended June 30, 2016 was $2.2 million and $2.9 million, respectively. The intrinsic value of options exercised during the three and six months ended June 30, 2015 was $4.3 million and $6.7 million, respectively.

[0000926326-16-000070:notes:167]
As of June 30, 2016, total unrecognized compensation cost related to unvested stock options was $10.7 million, which is expected to be recognized over a weighted-average vesting period of 2.95 years.

[0000926326-16-000070:notes:168]
[same as prior period, unchanged from 0000926326-16-000057:notes:156]

[0000926326-16-000070:notes:169]
The weighted-average grant date fair value per share of RSU granted during the six months ended June 30, 2016 and June 30, 2015 was $28.09 and $34.19, respectively.

[0000926326-16-000070:notes:170]
As of June 30, 2016, total unrecognized compensation expense related to RSUs was $9.9 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.7 years.

[0000926326-16-000070:notes:171]
As of June 30, 2016, total unrecognized compensation cost related to RSAs was $0.9 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.91 years.

[0000926326-16-000070:notes:172]
[same as prior period, unchanged from 0000926326-16-000057:notes:160]

[0000926326-16-000070:notes:173]
The weighted-average grant date fair value per share of PSUs granted during the six months ended June 30, 2016 and June 30, 2015 was $24.66 and $29.56, respectively. As of June 30, 2016, total unrecognized compensation cost related to PSUs was $2.6 million, which is expected to be recognized over the remaining weighted-average period of 1.5 year

[0000926326-16-000070:notes:174]
[same as prior period, unchanged from 0000926326-16-000057:notes:162]

[0000926326-16-000070:notes:175]
As of June 30, 2016, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $4.9 million and is expected to be recognized over a weighted-average period of two years.

[0000926326-16-000070:notes:176]
[same as prior period, unchanged from 0000926326-16-000057:notes:164]

[0000926326-16-000070:notes:177]
During the three and six months period ended June 30, 2016, the Company did not repurchase any of its outstanding common stock. The Company repurchased approximately 680,000 shares under its stock repurchase programs for $25.02 million during six months ended June 30, 2015.


## us-gaap:SubsequentEventsTextBlock

[0000926326-16-000070:notes:178]
Subsequent Events

[0000926326-16-000070:notes:179]
On August 2, 2016, the Board of Directors (the "Board") of Omnicell, Inc. (the “Company”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”).

[0000926326-16-000070:notes:180]
The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of June 30, 2016, the maximum dollar value of shares that may yet be purchased under the 2014 Repurchase Program was $4.9 million.

[0000926326-16-000070:notes:181]
The timing, price and volume of repurchases are to be based on market conditions, relevant securities laws and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions or pursuant to a Rule 10b-18 plan, subject to the terms and conditions of that certain Credit Agreement, dated as of January 5, 2016, among the Company, the Lenders party thereto, and Wells Fargo Bank, National Association, as administrative agent. The stock repurchase program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase program at any time.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-16-000070:notes:182]
[same as prior period, unchanged from 0000926326-16-000057:notes:168]
