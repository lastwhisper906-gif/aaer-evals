# OMCL 8-K — 0000926326-16-000066 filed 2016-07-28

## item codes, every 8-K on or before 2016-08-05

- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2016-08-05

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-16-000066:8k_2_02:1]
EX-99.1
2
exhibit991q216.htm
EXHIBIT 99.1

[0000926326-16-000066:8k_2_02:2]
Exhibit

[0000926326-16-000066:8k_2_02:3]
Exhibit 99.1

[0000926326-16-000066:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6180 |  | Mountain View, CA 94043 |
| Peter.kuipers@omnicell.com |  |  |

[0000926326-16-000066:8k_2_02:5]
Omnicell Achieves Record Revenue in the Second Quarter 2016

[0000926326-16-000066:8k_2_02:6]
Record GAAP revenue of $172.9 million representing 53% year over year growth

[0000926326-16-000066:8k_2_02:7]
Record Non-GAAP revenue of $175.6 million representing 56% year over year growth

[0000926326-16-000066:8k_2_02:8]
Integration of Aesynt progressing as planned and well received by our customers

[0000926326-16-000066:8k_2_02:9]
MOUNTAIN VIEW, Calif. -- July 28, 2016 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its second quarter ended June 30, 2016.

[0000926326-16-000066:8k_2_02:10]
GAAP results: Revenue for the second quarter of 2016 was $172.9 million, up $1.9 million, or 1.1% from the first quarter of 2016, and up $60.1 million or 53.3% from the second quarter of 2015. Revenue for the six months ended June 30, 2016 was $343.9 million, up $114.9 million or 50.2% from the six months ended June 30, 2015.

[0000926326-16-000066:8k_2_02:11]
Second quarter 2016 net loss as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $(1.2) million, or $(0.03) per diluted share. This compares to GAAP net loss of $(0.4) million, or $(0.01) per diluted share, for the first quarter of 2016, and GAAP net income of $8.8 million, or $0.24 per diluted share, for the second quarter of 2015.

[0000926326-16-000066:8k_2_02:12]
GAAP net loss for the six months ended June 30, 2016 was $(1.5) million, or $(0.04) per diluted share. GAAP net income for the six months ended June 30, 2015 was $15.1 million, or $0.41 per diluted share, which included a $3.4 million gain on business combination of an equity investment.

[0000926326-16-000066:8k_2_02:13]
Non-GAAP results: Non-GAAP revenue for the second quarter of 2016 was $175.6 million, up $1.9 million, or 1.1% from the first quarter of 2016, and up $62.8 million or 55.7% from the second quarter of 2015.

[0000926326-16-000066:8k_2_02:14]
Non-GAAP net income for the second quarter of 2016 was $13.9 million, or $0.38 per diluted share, excluding $5.5 million of stock-based compensation expense, $5.6 million, net of tax effect of $3.5 million, of intangible assets amortization expense, $1.7 million, net of tax effect of $1.0 million, of acquisition related expenses for the Aesynt acquisition, and $0.6 million, net of tax effect of $0.3 million, of inventory fair value adjustments. Non-GAAP net income includes the effect of a deferred revenue fair value adjustment of $1.7 million, net of tax effect of $1.0 million. This compares to non-GAAP net income for the first quarter 2016 of $12.9 million, or $0.35 per diluted share, excluding $3.9 million of stock-based compensation expense, $5.7 million, net of tax effect of $3.5 million, of intangible assets amortization expense, $1.4 million, net of tax effect of $0.9 million, of acquisition related expenses for the Aesynt acquisition, and $0.6 million, net of tax effect of $0.3 million, of inventory fair value adjustments. Non-GAAP net income for the first quarter of 2016 also includes the effect of a deferred revenue fair value adjustment of $1.7 million, net of tax effect of $1.0 million. Non-GAAP net income for the second quarter of 2015 was $10.3 million, or $0.28 per diluted share, which excluded $3.6 million of stock-based compensation expense and $1.3 million, net of tax effect of $0.5 million, of amortization expense for all intangible assets associated with past acquisitions. Non-GAAP net income for the second quarter also excludes a $3.4 million gain on an equity investment in Avantec Healthcare Ltd.

[0000926326-16-000066:8k_2_02:15]
1

[0000926326-16-000066:8k_2_02:16]
Non-GAAP net income for the six months ended June 30, 2016 was $26.7 million, or $0.73 per diluted share, excluding $9.4 million of stock-based compensation expense, $11.3 million, net of tax effect of $6.9 million, of intangible assets amortization expense, $3.2 million, net of tax effect of $1.9 million, of acquisition related expenses for the Aesynt acquisition, and $1.1 million, net of tax effect of 0.7 million, of inventory fair value adjustments. Non-GAAP net income includes the effect of a deferred revenue fair value adjustment of $3.3 million, net of tax effect of $2.0 million. This compares to non-GAAP net income of $21.0 million, or $0.57 per diluted share for the six months ended June 30, 2015, which excludes $7.3 million of stock-based compensation expense and $2.1 million, net of tax effect of $0.9 million of amortization expense for intangible assets associated with past acquisitions. Non-GAAP net income for the six months ended June 30, 2015 also excludes a $3.4 million gain on an equity investment in Avantec Healthcare Ltd.

[0000926326-16-000066:8k_2_02:17]
“Once again, Omnicell’s second quarter was marked by record revenues bolstered by the strength of our expanded portfolio that delivers our customers unmatched innovation and flexibility,” said Randall Lipps, President, CEO and Chairman.  “I am pleased that we have completed the first phase of the Aesynt integration and are seeing health systems, both existing and new customers, assessing their needs for improved efficiency and safety, evaluating our breath of solutions, and choosing Omnicell.”

[0000926326-16-000066:8k_2_02:18]
Third Quarter 2016 Guidance

[0000926326-16-000066:8k_2_02:19]
For the third quarter of 2016, the company expects Non-GAAP revenue to be between $176 million and $183 million and Non-GAAP EPS to be between $0.38 and $0.42 per share.

[0000926326-16-000066:8k_2_02:20]
For full year 2016, the Company is re-confirming its 2016 total year guidance which remains unchanged. The Company expects Product bookings to be between $540 million and $560 million. The Company now expects 2016 Non-GAAP revenue to be at the higher end of the range of $695 million to $715 million. The Company expects 2016 Non-GAAP EPS to be between $1.50 and $1.60 per share.

[0000926326-16-000066:8k_2_02:21]
Omnicell Conference Call Information

[0000926326-16-000066:8k_2_02:22]
Omnicell will hold a conference call today, Thursday, July 28, 2016 at 1:30 p.m. PT to discuss second quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 49810388. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on August 26, 2016. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 49810388.

[0000926326-16-000066:8k_2_02:23]
About Omnicell

[0000926326-16-000066:8k_2_02:24]
Since 1992, Omnicell (OMCL) has been creating innovative solutions to improve patient care, anywhere it is delivered. Omnicell is a leading supplier of comprehensive automation and business analytics software for medication and supply management across the entire health care continuum—from the acute care hospital setting, to post-acute skilled nursing and long-term care facilities, to the patient's home.

[0000926326-16-000066:8k_2_02:25]
Over 4,000 customers worldwide use Omnicell automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence and improve patient safety. The recent acquisition of Aesynt adds distinct capabilities, particularly in central pharmacy and IV robotics, creating the broadest medication management product portfolio in the industry.

[0000926326-16-000066:8k_2_02:26]
The Omnicell SureMed solution provides innovative medication adherence packaging to help reduce costly hospital readmissions. In addition, these solutions help enable approximately 7,000 institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-16-000066:8k_2_02:27]
For more information about Omnicell, please visit www.omnicell.com.

[0000926326-16-000066:8k_2_02:28]
Forward-Looking Statements

[0000926326-16-000066:8k_2_02:29]
occurrence of many events outside Omnicell’s control and are subject to various risk factors that could cause actual results to differ materially from those expressed or implied in any forward-looking statement. Such statements include, but are not limited to Omnicell’s momentum, pipeline and new sales opportunities, profit and revenue growth, and the success of Omnicell’s strategy for growth, including differentiated products, expansion into new markets and targeted acquisitions. Risks that contribute to the uncertain nature of the forward-looking statements include our ability to take advantage of the growth opportunities in medication management across the spectrum of healthcare settings from long term care to home care, unfavorable general economic and market conditions, risks to growth and acceptance of our products and services, including competitive conversions, and to growth of the clinical automation and workflow automation market generally, the potential of increasing competition, potential regulatory changes, the ability of the company to improve sales productivity to grow product bookings, to develop new products and to acquire and successfully integrate companies, such as Aesynt. These and other risks and uncertainties are described more fully in Omnicell’s most recent filings with the Securities and Exchange Commission. Prospective investors are cautioned not to place undue reliance on forward-looking statements. All forward-looking statements contained in this press release speak only as of the date on which they were made. Omnicell undertakes no obligation to update such statements to reflect events that occur or circumstances that exist after the date on which they were made.

[0000926326-16-000066:8k_2_02:30]
Use of Non-GAAP Financial Information

[0000926326-16-000066:8k_2_02:31]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-16-000066:8k_2_02:32]
3

[0000926326-16-000066:8k_2_02:33]
Our non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-16-000066:8k_2_02:34]
a)  Stock-based compensation expense impact of Accounting Standards Codification (ASC) 718. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-16-000066:8k_2_02:35]
b) Intangible assets amortization from business acquisitions. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-16-000066:8k_2_02:36]
c) Amortization of debt issuance cost. Debt issuance cost represents costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The cost includes underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-16-000066:8k_2_02:37]
d) Acquisition accounting impact related to deferred revenue. In connection with our acquisition of Aesynt, business combination rules require us to account for the fair values of arrangements for which acceptance has not been obtained, and post installation support has not been provided in our purchase accounting. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0000926326-16-000066:8k_2_02:38]
e) Inventory fair value adjustments. In connection with our acquisition of Aesynt, business combination rules require us to account for the fair values of inventory acquired in our purchase accounting. The non-GAAP adjustment to our Cost of Revenues is intended to include the impact of such adjustment. We believe the adjustment is useful as a measure of the ongoing performance of our business.

[0000926326-16-000066:8k_2_02:39]
f) Acquisitions related expenses. We excluded from our non-GAAP results the expenses which are related to the recent acquisitions. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition related expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of less acquisitive peer companies. Further, these expenses are not considered by management to reflect the core performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-16-000066:8k_2_02:40]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans.

[0000926326-16-000066:8k_2_02:41]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-16-000066:8k_2_02:42]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0000926326-16-000066:8k_2_02:43]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0000926326-16-000066:8k_2_02:44]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0000926326-16-000066:8k_2_02:45]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-16-000066:8k_2_02:46]
Set forth below are additional reasons why share-based compensation expense related to ASC 718 is excluded from our non-GAAP financial measures:

[0000926326-16-000066:8k_2_02:47]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-16-000066:8k_2_02:48]
ii)  We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-16-000066:8k_2_02:49]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as excluding certain non-GAAP adjustments.

[0000926326-16-000066:8k_2_02:50]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-16-000066:8k_2_02:51]
·  Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-16-000066:8k_2_02:52]
·  Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-16-000066:8k_2_02:53]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-16-000066:8k_2_02:54]
Omnicell, Inc.

[0000926326-16-000066:8k_2_02:55]
Condensed Consolidated Statements of Operations

[0000926326-16-000066:8k_2_02:56]
(Unaudited, in thousands, except per share data)

[0000926326-16-000066:8k_2_02:57]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2016 |  | March 31, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product | $ | 130,674 |  |  | $ | 127,895 |  |  | $ | 89,154 |  |  | $ | 258,569 |  |  | $ | 183,263 |  |
| Services and other revenues | 42,233 |  |  | 43,109 |  |  | 23,634 |  |  | 85,342 |  |  | 45,746 |  |
| Total revenues | 172,907 |  |  | 171,004 |  |  | 112,788 |  |  | 343,911 |  |  | 229,009 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 76,306 |  |  | 71,918 |  |  | 46,203 |  |  | 148,224 |  |  | 91,619 |  |
| Cost of services and other revenues | 18,584 |  |  | 19,141 |  |  | 9,123 |  |  | 37,725 |  |  | 18,243 |  |
| Total cost of revenues | 94,890 |  |  | 91,059 |  |  | 55,326 |  |  | 185,949 |  |  | 109,862 |  |
| Gross profit | 78,017 |  |  | 79,945 |  |  | 57,462 |  |  | 157,962 |  |  | 119,147 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 13,794 |  |  | 13,838 |  |  | 8,746 |  |  | 27,632 |  |  | 16,765 |  |
| Selling, general and administrative | 64,341 |  |  | 64,255 |  |  | 39,735 |  |  | 128,596 |  |  | 83,022 |  |
| Gain on business combination | — |  |  | — |  |  | (3,443 | ) |  |  |  | (3,443 | ) |
| Total operating expenses | 78,135 |  |  | 78,093 |  |  | 45,038 |  |  | 156,228 |  |  | 96,344 |  |
| (Loss) income from operations | (118 | ) |  | 1,852 |  |  | 12,424 |  |  | 1,734 |  |  | 22,803 |  |
| Interest and other income (expense), net | (1,881 | ) |  | (2,171 | ) |  | (472 | ) |  | (4,052 | ) |  | (989 | ) |
| (Loss) income before provision for income taxes | (1,999 | ) |  | (319 | ) |  | 11,952 |  |  | (2,318 | ) |  | 21,814 |  |
| (Benefit) provision for income taxes | (840 | ) |  | 59 |  |  | 3,201 |  |  | (781 | ) |  | 6,745 |  |
| Net (loss) income | $ | (1,159 | ) |  | $ | (378 | ) |  | $ | 8,751 |  |  | $ | (1,537 | ) |  | $ | 15,069 |  |
| Net (loss) income per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.03 | ) |  | $ | (0.01 | ) |  | $ | 0.24 |  |  | $ | (0.04 | ) |  | $ | 0.42 |  |
| Diluted | $ | (0.03 | ) |  | $ | (0.01 | ) |  | $ | 0.24 |  |  | $ | (0.04 | ) |  | $ | 0.41 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic | 35,987 |  |  | 35,740 |  |  | 36,120 |  |  | 35,864 |  |  | 36,072 |  |
| Diluted | 35,987 |  |  | 35,740 |  |  | 37,030 |  |  | 35,864 |  |  | 36,987 |  |

[0000926326-16-000066:8k_2_02:58]
6

[0000926326-16-000066:8k_2_02:59]
Omnicell, Inc.

[0000926326-16-000066:8k_2_02:60]
Condensed Consolidated Balance Sheets

[0000926326-16-000066:8k_2_02:61]
(Unaudited, in thousands)

[0000926326-16-000066:8k_2_02:62]
|  | June 30, 2016 |  | December 31, 2015 |
| ASSETS |
| Current assets: |  |  |  |  |
| Cash and cash equivalents | $ | 41,029 |  |  | $ | 82,217 |  |
| Accounts receivable, net | 159,453 |  |  | 107,957 |  |
| Inventories | 73,720 |  |  | 46,594 |  |
| Prepaid expenses | 28,690 |  |  | 19,586 |  |
| Other current assets | 9,024 |  |  | 7,774 |  |
| Total current assets | 311,916 |  |  | 264,128 |  |
| Property and equipment, net | 40,503 |  |  | 32,309 |  |
| Long-term investment in sales-type leases, net | 19,711 |  |  | 14,484 |  |
| Goodwill | 311,170 |  |  | 147,906 |  |
| Intangible assets, net | 196,475 |  |  | 89,665 |  |
| Long-term deferred tax assets | 2,920 |  |  | 2,361 |  |
| Other long-term assets | 30,733 |  |  | 27,894 |  |
| Total assets | $ | 913,428 |  |  | $ | 578,747 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |
| Accounts payable | $ | 37,365 |  |  | $ | 22,646 |  |
| Accrued compensation | 28,014 |  |  | 18,195 |  |
| Accrued liabilities | 32,674 |  |  | 30,133 |  |
| Long-term debt, current portion, net | 8,410 |  |  | — |  |
| Deferred revenue, net | 84,852 |  |  | 53,656 |  |
| Total current liabilities | 191,315 |  |  | 124,630 |  |
| Long-term, deferred revenue | 17,473 |  |  | 17,975 |  |
| Long-term deferred tax liabilities | 62,431 |  |  | 21,822 |  |
| Other long-term liabilities | 12,074 |  |  | 11,932 |  |
| Long-term debt, net | 216,936 |  |  | — |  |
| Total liabilities | 500,229 |  |  | 176,359 |  |
| Total stockholders’ equity | 413,199 |  |  | 402,388 |  |
| Total liabilities and stockholders’ equity | $ | 913,428 |  |  | $ | 578,747 |  |

[0000926326-16-000066:8k_2_02:63]
Omnicell, Inc.

[0000926326-16-000066:8k_2_02:64]
Condensed Consolidated Statements of Cash Flows

[0000926326-16-000066:8k_2_02:65]
(Unaudited, in thousands)

[0000926326-16-000066:8k_2_02:66]
|  | Six months ended June 30, |
|  | 2016 |  | 2015 |
| Operating Activities |  |  |  |
| Net (loss) income | $ | (1,537 | ) |  | $ | 15,069 |  |
| Adjustments to reconcile net (loss) income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 29,197 |  |  | 11,977 |  |
| Loss (gain) on disposal of fixed assets | 1 |  |  | (5 | ) |
| Gain on business combination | — |  |  | (3,443 | ) |
| Provision for receivable allowance | 364 |  |  | 480 |  |
| Share-based compensation expense | 9,386 |  |  | 7,301 |  |
| Income tax benefits from employee stock plans | 681 |  |  | 3,087 |  |
| Excess tax benefits from employee stock plans | (934 | ) |  | (3,159 | ) |
| Provision for excess and obsolete inventories | 850 |  |  | 168 |  |
| Deferred income taxes | (3,877 | ) |  | (1,717 | ) |
| Amortization of debt financing fees | 795 |  |  | — |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | (8,139 | ) |  | (27,676 | ) |
| Inventories | (7,769 | ) |  | (9,633 | ) |
| Prepaid expenses | (4,852 | ) |  | 8,234 |  |
| Other current assets | 78 |  |  | 1,507 |  |
| Investment in sales-type leases | (6,558 | ) |  | 353 |  |
| Other long-term assets | 1,019 |  |  | 64 |  |
| Accounts payable | 6,736 |  |  | 1,364 |  |
| Accrued compensation | 210 |  |  | (1,654 | ) |
| Accrued liabilities | (2,195 | ) |  | 5,752 |  |
| Deferred revenue | 4,895 |  |  | 3,116 |  |
| Other long-term liabilities | (2,398 | ) |  | (995 | ) |
| Net cash provided by operating activities | 15,953 |  |  | 10,190 |  |
| Investing Activities |  |  |  |
| Purchases of intangible assets, intellectual property and patents | (1,185 | ) |  | (225 | ) |
| Software development for external use | (6,681 | ) |  | (6,127 | ) |
| Purchases of property and equipment | (5,938 | ) |  | (3,764 | ) |
| Business acquisition, net of cash acquired | (271,458 | ) |  | (23,625 | ) |
| Net cash used in investing activities | (285,262 | ) |  | (33,741 | ) |
| Financing Activities |  |  |  |
| Proceeds from debt, net | 247,051 |  |  | — |  |
| Repayment of debt and revolving credit facility | (22,500 | ) |  | — |  |
| Payment for contingent consideration | (3,000 | ) |  | — |  |
| Proceeds from issuances under stock-based compensation plans | 8,639 |  |  | 9,432 |  |
| Employees' taxes paid related to restricted stock units | (1,563 | ) |  | (2,046 | ) |
| Excess tax benefits from employee stock plans | 934 |  |  | 3,159 |  |
| Common stock repurchases | — |  |  | (25,021 | ) |
| Net cash provided by (used in) financing activities | 229,561 |  |  | (14,476 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (1,440 | ) |  | 167 |  |
| Net decrease in cash and cash equivalents | (41,188 | ) |  | (37,860 | ) |
| Cash and cash equivalents at beginning of period | 82,217 |  |  | 125,888 |  |
| Cash and cash equivalents at end of period | $ | 41,029 |  |  | $ | 88,028 |  |

[0000926326-16-000066:8k_2_02:67]
8

[0000926326-16-000066:8k_2_02:68]
Omnicell, Inc.

[0000926326-16-000066:8k_2_02:69]
Reconciliation of GAAP to Non-GAAP

[0000926326-16-000066:8k_2_02:70]
(Unaudited, in thousands, except per share data)

[0000926326-16-000066:8k_2_02:71]
|  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  |  | June 30, 2016 |  | March 31, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| Reconciliation of GAAP net (loss) income to non-GAAP net income: |  |  |  |  |  |  |
| GAAP net (loss) income | $ | (1,159 | ) |  | $ | (378 | ) |  | $ | 8,751 |  |  | $ | (1,537 | ) |  | $ | 15,069 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
|  | Share-based compensation expense | 5,495 |  |  | 3,891 |  |  | 3,636 |  |  | 9,386 |  |  | 7,301 |  |
|  | Amortization of acquired intangibles | 9,052 |  |  | 9,159 |  |  | 1,810 |  |  | 18,211 |  |  | 3,041 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 5,326 |  |  | — |  |
|  | Inventory fair value adjustments | 920 |  |  | 921 |  |  | — |  |  | 1,841 |  |  | — |  |
|  | Acquisitions related expenses* | 2,749 |  |  | 2,349 |  |  | — |  |  | 5,098 |  |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | (3,443 | ) |  | — |  |  | (3,443 | ) |
|  | Tax effect of the adjustments above(a) | (5,846 | ) |  | (5,735 | ) |  | (485 | ) |  | (11,581 | ) |  | (928 | ) |
| Non-GAAP net income | $ | 13,874 |  |  | $ | 12,870 |  |  | $ | 10,269 |  |  | $ | 26,744 |  |  | $ | 21,040 |  |
| Reconciliation of GAAP revenue to non-GAAP revenue: |  |  |  |  |  |  |
| Revenues |  | $ | 172,907 |  |  | $ | 171,004 |  |  | $ | 112,788 |  |  | $ | 343,911 |  |  | $ | 229,009 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 5,326 |  |  | — |  |
| Non-GAAP revenue | $ | 175,570 |  |  | $ | 173,667 |  |  | $ | 112,788 |  |  | $ | 349,237 |  |  | $ | 229,009 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |
| GAAP gross profit | $ | 78,017 |  |  | $ | 79,945 |  |  | $ | 57,462 |  |  | $ | 157,962 |  |  | $ | 119,147 |  |
| GAAP gross margin | 45.1% |  | 46.8% |  | 50.9% |  | 45.9% |  | 52.0% |
|  | Share-based compensation expense | 644 |  |  | 549 |  |  | 532 |  |  | 1,193 |  |  | 1,049 |  |
|  | Amortization of acquired intangibles | 5,214 |  |  | 5,211 |  |  | 531 |  |  | 10,425 |  |  | 899 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 5,326 |  |  | — |  |
|  | Inventory fair value adjustments | 920 |  |  | 921 |  |  | — |  |  | 1,841 |  |  | — |  |
|  | Acquisitions related expenses | 227 |  |  | — |  |  | — |  |  | 227 |  |  | — |  |
| Non-GAAP gross profit | $ | 87,685 |  |  | $ | 89,289 |  |  | $ | 58,525 |  |  | $ | 176,974 |  |  | $ | 121,095 |  |
| Non-GAAP gross margin | 49.9% |  | 51.4% |  | 51.9% |  | 50.7% |  | 52.9% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 78,135 |  |  | $ | 78,093 |  |  | $ | 45,038 |  |  | $ | 156,228 |  |  | $ | 96,344 |  |
|  | GAAP operating expenses % to total revenue | 45.2% |  | 45.7% |  | 39.9% |  | 45.4% |  | 42.1% |
|  | Share-based compensation expense | (4,851 | ) |  | (3,342 | ) |  | (3,104 | ) |  | (8,193 | ) |  | (6,252 | ) |
|  | Amortization of acquired intangibles | (3,838 | ) |  | (3,948 | ) |  | (1,279 | ) |  | (7,786 | ) |  | (2,142 | ) |
|  | Acquisitions related expenses | (1,727 | ) |  | (2,349 | ) |  | — |  |  | (4,076 | ) |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | 3,443 |  |  | — |  |  | 3,443 |  |
| Non-GAAP operating expenses | $ | 67,719 |  |  | $ | 68,454 |  |  | $ | 44,098 |  |  | $ | 136,173 |  |  | $ | 91,393 |  |
| Non-GAAP operating expenses % to total revenue | 38.6% |  | 40.0% |  | 39.1% |  | 39.0% |  | 39.9% |

[0000926326-16-000066:8k_2_02:72]
|  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  |  | June 30, 2016 |  | March 31, 2016 |  | June 30, 2015 |  | June 30, 2016 |  | June 30, 2015 |
| Reconciliation of GAAP (loss) income from operations to non-GAAP income from operations: |  |  |  |  |
| GAAP (loss) income from operations | $ | (118 | ) |  | $ | 1,852 |  |  | $ | 12,424 |  |  | $ | 1,734 |  |  | $ | 22,803 |  |
|  | GAAP operating income % to total revenue | (0.1)% |  | 1.1% |  | 11.0% |  | 0.5% |  | 10.0% |
|  | Share-based compensation expense | 5,495 |  |  | 3,891 |  |  | 3,636 |  |  | 9,386 |  |  | 7,301 |  |
|  | Amortization of acquired intangibles | 9,052 |  |  | 9,159 |  |  | 1,810 |  |  | 18,211 |  |  | 3,041 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 5,326 |  |  | — |  |
|  | Inventory fair value adjustments | 920 |  |  | 921 |  |  | — |  |  | 1,841 |  |  | — |  |
|  | Acquisitions related expenses | 1,954 |  |  | 2,349 |  |  | — |  |  | 4,303 |  |  | — |  |
| Gain on business combination | — |  |  | — |  |  | (3,443 | ) |  | — |  |  | (3,443 | ) |
| Non-GAAP income from operations | $ | 19,966 |  |  | $ | 20,835 |  |  | $ | 14,427 |  |  | $ | 40,801 |  |  | $ | 29,702 |  |
| Non-GAAP operating income % to total Non-GAAP revenue | 11.4% |  | 12.0% |  | 12.8% |  | 11.7% |  | 13.0% |
| Reconciliation of GAAP net (loss) income per share - diluted to non-GAAP net income per share - diluted: |  |  |
| Shares - diluted GAAP | 35,987 |  |  | 35,740 |  |  | 37,030 |  |  | 35,864 |  |  | 36,987 |  |
| Shares - diluted Non-GAAP | 36,649 |  |  | 36,307 |  |  | 37,030 |  |  | 36,488 |  |  | 36,987 |  |
| GAAP net (loss) income per share - diluted | $ | (0.03 | ) |  | $ | (0.01 | ) |  | $ | 0.24 |  |  | $ | (0.04 | ) |  | $ | 0.41 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
|  | Share-based compensation expense | 0.15 |  |  | 0.11 |  |  | 0.10 |  |  | 0.26 |  |  | 0.20 |  |
|  | Amortization of acquired intangibles | 0.25 |  |  | 0.25 |  |  | 0.05 |  |  | 0.50 |  |  | 0.08 |  |
|  | Acquisition accounting impact related to deferred revenue | 0.07 |  |  | 0.07 |  |  | — |  |  | 0.15 |  |  | — |  |
|  | Inventory fair value adjustments | 0.03 |  |  | 0.03 |  |  | — |  |  | 0.05 |  |  | — |  |
|  | Acquisitions related expenses | 0.08 |  |  | 0.06 |  |  | — |  |  | 0.14 |  |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | (0.10 | ) |  | — |  |  | (0.10 | ) |
|  | Tax effect of the adjustments above(a) | (0.17 | ) |  | (0.16 | ) |  | (0.01 | ) |  | (0.33 | ) |  | (0.02 | ) |
| Non-GAAP net income per share - diluted | $ | 0.38 |  |  | $ | 0.35 |  |  | $ | 0.28 |  |  | $ | 0.73 |  |  | $ | 0.57 |  |
| Reconciliation of GAAP net (loss) income to non-GAAP Adjusted EBITDA: |  |  |  |  |  |  |
| GAAP net (loss) income | $ | (1,159 | ) |  | $ | (378 | ) |  | $ | 8,751 |  |  | $ | (1,537 | ) |  | $ | 15,069 |  |
| Add back: |  |  |  |  |  |  |  |  |  |
|  | Share-based compensation expense | 5,495 |  |  | 3,891 |  |  | 3,636 |  |  | 9,386 |  |  | 7,301 |  |
|  | Interest (income) and expense, net | 1,348 |  |  | 1,747 |  |  | 84 |  |  | 3,095 |  |  | 183 |  |
|  | Depreciation and amortization expense | 14,724 |  |  | 14,473 |  |  | 6,264 |  |  | 29,197 |  |  | 11,975 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 5,326 |  |  | — |  |
|  | Inventory fair value adjustments | 920 |  |  | 921 |  |  | — |  |  | 1,841 |  |  | — |  |
|  | Acquisitions related expenses* | 2,749 |  |  | 2,349 |  |  | — |  |  | 5,098 |  |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | (3,443 | ) |  | — |  |  | (3,443 | ) |
|  | Income tax expense | (840 | ) |  | 59 |  |  | 3,201 |  |  | (781 | ) |  | 6,745 |  |
| Non-GAAP Adjusted EBITDA (b) | $ | 25,900 |  |  | $ | 25,725 |  |  | $ | 18,493 |  |  | $ | 51,625 |  |  | $ | 37,830 |  |

[0000926326-16-000066:8k_2_02:73]
___________________________________________

[0000926326-16-000066:8k_2_02:74]
*          Included in the Acquisitions related expenses are severance expenses related to the restructuring of $1.7 million for three and six months ended June 30, 2016.

[0000926326-16-000066:8k_2_02:75]
| (a) | Tax effects calculated for all adjustments except share based compensation expense, using the estimated annual effective tax rate of 38% for fiscal year 2016. |

[0000926326-16-000066:8k_2_02:76]
| (b) | Defined as earnings before interest income and expense, taxes, depreciation and amortization, share-based compensation expense, as well as excluding certain non-GAAP adjustments. |

[0000926326-16-000066:8k_2_02:77]
10

[0000926326-16-000066:8k_2_02:78]
Omnicell, Inc.

[0000926326-16-000066:8k_2_02:79]
Segmented Information

[0000926326-16-000066:8k_2_02:80]
(Unaudited, in thousands, except for percentages)

[0000926326-16-000066:8k_2_02:81]
|  | Three months ended June 30, 2016 |  | Three Months Ended June 30, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 148,660 |  |  | $ | 24,247 |  |  | $ | 172,907 |  |  | $ | 88,701 |  |  | $ | 24,087 |  |  | $ | 112,788 |  |
| Cost of revenues | 78,366 |  |  | 16,524 |  |  | 94,890 |  |  | 39,403 |  |  | 15,923 |  |  | 55,326 |  |
| Gross profit | 70,294 |  |  | 7,723 |  |  | 78,017 |  |  | 49,298 |  |  | 8,164 |  |  | 57,462 |  |
| Gross margin % | 47.3% |  | 31.9% |  | 45.1% |  | 55.6% |  | 33.9% |  | 50.9% |
| Operating expenses | 49,780 |  |  | 5,771 |  |  | 55,551 |  |  | 25,978 |  |  | 5,910 |  |  | 31,888 |  |
| Income from segment operations | $ | 20,514 |  |  | $ | 1,952 |  |  | 22,466 |  |  | $ | 23,320 |  |  | $ | 2,254 |  |  | 25,574 |  |
| Operating margin % | 13.8% |  | 8.1% |  | 13.0% |  | 26.3% |  | 9.4% |  | 22.7% |
| Corporate costs |  |  |  |  | 22,584 |  |  |  |  |  |  | 13,150 |  |
| Loss (income) from operations |  |  |  |  | $ | (118 | ) |  |  |  |  |  | $ | 12,424 |  |

[0000926326-16-000066:8k_2_02:82]
11

[0000926326-16-000066:8k_2_02:83]
Omnicell, Inc.

[0000926326-16-000066:8k_2_02:84]
Segmented Information

[0000926326-16-000066:8k_2_02:85]
(Unaudited, in thousands, except for percentages)

[0000926326-16-000066:8k_2_02:86]
|  | Six months ended June 30, 2016 |  | Six months ended June 30, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 297,605 |  |  | $ | 46,306 |  |  | $ | 343,911 |  |  | $ | 181,480 |  |  | $ | 47,529 |  |  | $ | 229,009 |  |
| Cost of revenues | 155,573 |  |  | 30,376 |  |  | 185,949 |  |  | 78,255 |  |  | 31,607 |  |  | 109,862 |  |
| Gross profit | 142,032 |  |  | 15,930 |  |  | 157,962 |  |  | 103,225 |  |  | 15,922 |  |  | 119,147 |  |
| Gross margin % | 47.7% |  | 34.4% |  | 45.9% |  | 56.9% |  | 33.5% |  | 52.0% |
| Operating expenses | 101,985 |  |  | 11,382 |  |  | 113,367 |  |  | 54,567 |  |  | 12,251 |  |  | 66,818 |  |
| Income from segment operations | $ | 40,047 |  |  | $ | 4,548 |  |  | $ | 44,595 |  |  | $ | 48,658 |  |  | $ | 3,671 |  |  | 52,329 |  |
| Operating margin % | 13.5% |  | 9.8% |  | 13.0% |  | 26.8% |  | 7.7% |  | 22.9% |
| Corporate costs |  |  |  |  | 42,861 |  |  |  |  |  |  | 29,526 |  |
| Income from operations |  |  |  |  | $ | 1,734 |  |  |  |  |  |  | $ | 22,803 |  |

[0000926326-16-000066:8k_2_02:87]
Omnicell, Inc.

[0000926326-16-000066:8k_2_02:88]
Segment Information - Non-GAAP Gross Margin and Non-GAAP Operating Margin

[0000926326-16-000066:8k_2_02:89]
(Unaudited, in thousands, except for percentages)

[0000926326-16-000066:8k_2_02:90]
|  | Three months ended June 30, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 148,660 |  |  |  |  | $ | 24,247 |  |  |  |  | $ | 172,907 |  |  |  |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.8% |  | — |  |  | —% |  | 2,663 |  |  | 1.5% |
| Non-GAAP Revenues | $ | 151,323 |  |  |  |  | 24,247 |  |  |  |  | $ | 175,570 |  |  |  |
| GAAP Gross profit | $ | 70,294 |  |  | 47.3% |  | $ | 7,723 |  |  | 31.9% |  | $ | 78,017 |  |  | 45.1% |
| Stock-based compensation expense | 561 |  |  | 0.4% |  | 83 |  |  | 0.3% |  | 644 |  |  | 0.4% |
| Amortization expense of acquired intangible assets | 4,882 |  |  | 3.3% |  | 332 |  |  | 1.4% |  | 5,214 |  |  | 3.0% |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.8% |  | — |  |  | —% |  | 2,663 |  |  | 1.5% |
| Inventory fair value adjustments | 920 |  |  | 0.6% |  | — |  |  | —% |  | 920 |  |  | 0.5% |
| Acquisitions related expenses | 227 |  |  | 0.2% |  | — |  |  | —% |  | 227 |  |  | 0.1% |
| Non-GAAP Gross profit | $ | 79,547 |  |  | 53.5% |  | $ | 8,138 |  |  | 33.6% |  | $ | 87,685 |  |  | 50.7% |
| GAAP Operating income | $ | 20,514 |  |  | 13.8% |  | $ | 1,952 |  |  | 8.1% |  | $ | 22,466 |  |  | 13.0% |
| Stock-based compensation expense | 2,042 |  |  | 1.4% |  | 240 |  |  | 1.0% |  | 2,282 |  |  | 1.3% |
| Amortization expense of acquired intangible assets | 7,739 |  |  | 5.2% |  | 1,313 |  |  | 5.4% |  | 9,052 |  |  | 5.2% |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.8% |  | — |  |  | —% |  | 2,663 |  |  | 1.5% |
| Inventory fair value adjustments | 920 |  |  | 0.6% |  | — |  |  | —% |  | 920 |  |  | 0.5% |
| Acquisitions related expenses | 1,849 |  |  | 1.2% |  | 56 |  |  | 0.2% |  | 1,905 |  |  | 1.1% |
| Non-GAAP Operating income | $ | 35,727 |  |  | 24.0% |  | $ | 3,561 |  |  | 14.7% |  | $ | 39,288 |  |  | 22.7% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 22,584 |  |  | 13.1% |
| Stock-based compensation expense |  |  |  |  |  |  |  |  | 3,213 |  |  | 1.9% |
| Acquisition-related expenses |  |  |  |  |  |  |  |  | 49 |  |  | —% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 19,322 |  |  | 11.2% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  | $ | 19,966 |  |  | 11.4% |

[0000926326-16-000066:8k_2_02:91]
13

[0000926326-16-000066:8k_2_02:92]
Omnicell, Inc.

[0000926326-16-000066:8k_2_02:93]
Segment Information - Non-GAAP Gross Margin and Non-GAAP Operating Margin

[0000926326-16-000066:8k_2_02:94]
(Unaudited, in thousands, except for percentages)

[0000926326-16-000066:8k_2_02:95]
|  | Three Months Ended June 30, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 88,701 |  |  |  |  | $ | 24,087 |  |  |  |  | $ | 112,788 |  |  |  |
| GAAP Gross profit | $ | 49,298 |  |  | 55.6% |  | $ | 8,164 |  |  | 33.9% |  | $ | 57,462 |  |  | 50.9% |
| Stock-based compensation expense | 370 |  |  | 0.4% |  | 162 |  |  | 0.7% |  | 532 |  |  | 0.5% |
| Amortization expense of acquired intangibleassets | 199 |  |  | 0.2% |  | 332 |  |  | 1.4% |  | 531 |  |  | 0.5% |
| Non-GAAP Gross profit | $ | 49,867 |  |  | 56.2% |  | $ | 8,658 |  |  | 35.9% |  | $ | 58,525 |  |  | 51.9% |
| GAAP Operating income | $ | 23,320 |  |  | 26.3% |  | $ | 2,254 |  |  | 9.4% |  | $ | 25,574 |  |  | 22.7% |
| Stock-based compensation expense | 1,207 |  |  | 1.4% |  | 377 |  |  | 1.6% |  | 1,584 |  |  | 1.4% |
| Amortization expense of acquired intangibleassets | 724 |  |  | 0.8% |  | 1,086 |  |  | 4.5% |  | 1,810 |  |  | 1.6% |
| Gain on business combination | (3,443 | ) |  | (3.9)% |  | $ | 0 |  |  | —% |  | (3,443 | ) |  | (3.1)% |
| Non-GAAP Operating income | $ | 21,808 |  |  | 24.6% |  | $ | 3,717 |  |  | 15.4% |  | $ | 25,525 |  |  | 22.6% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 13,150 |  |  | 11.7% |
| Stock-based compensation expense |  |  |  |  |  |  |  |  | 2,052 |  |  | 1.8% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 11,098 |  |  | 9.8% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  | $ | 14,427 |  |  | 12.8% |
