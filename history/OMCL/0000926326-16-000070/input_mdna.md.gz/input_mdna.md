# OMCL MD&A — 0000926326-16-000070


## mdna

[0000926326-16-000070:mdna:1]
[same as prior period, unchanged from 0000926326-16-000057:mdna:1]

[0000926326-16-000070:mdna:2]
[same as prior period, unchanged from 0000926326-16-000057:mdna:2]

[0000926326-16-000070:mdna:3]
This quarterly report on Form 10-Q contains forward-looking statements. The forward-looking statements are contained principally in the sections entitled “Risk Factors” and “Management's Discussion and Analysis of Financial Condition and Results of Operations.” These statements involve known and unknown risks, uncertainties and other factors which may cause our actual results, performance or achievements to be materially different from any future results,

[0000926326-16-000070:mdna:4]
performances or achievements expressed or implied by the forward-looking statements. Forward-looking statements include, but are not limited to, statements about:

[0000926326-16-000070:mdna:5]
[same as prior period, unchanged from 0000926326-16-000057:mdna:4]

[0000926326-16-000070:mdna:6]
[same as prior period, unchanged from 0000926326-16-000057:mdna:5]

[0000926326-16-000070:mdna:7]
[same as prior period, unchanged from 0000926326-16-000057:mdna:6]

[0000926326-16-000070:mdna:8]
[same as prior period, unchanged from 0000926326-16-000057:mdna:7]

[0000926326-16-000070:mdna:9]
[same as prior period, unchanged from 0000926326-16-000057:mdna:8]

[0000926326-16-000070:mdna:10]
[same as prior period, unchanged from 0000926326-16-000057:mdna:9]

[0000926326-16-000070:mdna:11]
[same as prior period, unchanged from 0000926326-16-000057:mdna:10]

[0000926326-16-000070:mdna:12]
[same as prior period, unchanged from 0000926326-16-000057:mdna:11]

[0000926326-16-000070:mdna:13]
[same as prior period, unchanged from 0000926326-16-000057:mdna:12]

[0000926326-16-000070:mdna:14]
[same as prior period, unchanged from 0000926326-16-000057:mdna:13]

[0000926326-16-000070:mdna:15]
[same as prior period, unchanged from 0000926326-16-000057:mdna:14]

[0000926326-16-000070:mdna:16]
[same as prior period, unchanged from 0000926326-16-000057:mdna:15]

[0000926326-16-000070:mdna:17]
We are a leading provider of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum; from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home. Over 4,000 customers worldwide have used our Omnicell Automation and Analytics supply chain and analytics solutions to help enable them to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety. The recent acquisition of Aesynt discussed below adds distinct product capabilities, particularly in central pharmacy and I.V. robotics.

[0000926326-16-000070:mdna:18]
[same as prior period, unchanged from 0000926326-16-000057:mdna:17]

[0000926326-16-000070:mdna:19]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 84% of total revenue for both the three and six months ended June 30, 2016. We expect our revenues from international operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-16-000070:mdna:20]
On January 5, 2016, we completed the acquisition of all of the membership interests of Aesynt. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. Adding these solution sets to the Omnicell portfolio is intended to give the combined companies one of the most complete medication management offering in the industry. We are now able to support customers who desire a centralized

[0000926326-16-000070:mdna:21]
cartfill or nurse server medication distribution model all the way to fully decentralized dispensing and various combinations along that continuum. We are also able to offer solutions for I.V. preparations, including oncology drugs, which is an area where our combined customers have expressed significant interest. Looking across the entire medication distribution model, Aesynt’s new Enterprise Medication Manager software products give the customer the power to optimize the pharmacy supply chain with tools that help manage their inventory, reduce risks of stock outs, and minimize the cost of expiring medications. In addition, Aesynt has an experienced and skilled workforce whose expertise complements our capabilities. Integrating our two product development groups is expected to lead to innovation and the opportunity to help accelerate innovation. Finally, Aesynt has over 1,200 hospital customers with limited overlap to Omnicell’s existing install base, which we expect will drive a significant increase to our customer install base.

[0000926326-16-000070:mdna:22]
[same as prior period, unchanged from 0000926326-16-000057:mdna:21]

[0000926326-16-000070:mdna:23]
We manage our business as two operating segments, Automation and Analytics and Medication Adherence:

[0000926326-16-000070:mdna:24]
[same as prior period, unchanged from 0000926326-16-000057:mdna:23]

[0000926326-16-000070:mdna:25]
[same as prior period, unchanged from 0000926326-16-000057:mdna:24]

[0000926326-16-000070:mdna:26]
[same as prior period, unchanged from 0000926326-16-000057:mdna:25]

[0000926326-16-000070:mdna:27]
[same as prior period, unchanged from 0000926326-16-000057:mdna:26]

[0000926326-16-000070:mdna:28]
For further description of our operating segments, refer to Note 13, Segment Information, of the Notes to Consolidated Financial Statements in this quarterly report.

[0000926326-16-000070:mdna:29]
[same as prior period, unchanged from 0000926326-16-000057:mdna:28]

[0000926326-16-000070:mdna:30]
[same as prior period, unchanged from 0000926326-16-000057:mdna:29]

[0000926326-16-000070:mdna:31]
[same as prior period, unchanged from 0000926326-16-000057:mdna:30]

[0000926326-16-000070:mdna:32]
[same as prior period, unchanged from 0000926326-16-000057:mdna:32]

[0000926326-16-000070:mdna:33]
| • | Expansion of our solutions through acquisitions and partnerships. Our acquisitions have generally been focused on automation of manual workflows or data analytics, which is the enhancement of data for our customers’ decision-making processes. We believe that expansion of our product lines through acquisition and |

[0000926326-16-000070:mdna:34]
partnerships to meet our customers changing and evolving expectations is a key component to our historical and future success.

[0000926326-16-000070:mdna:35]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, we began shipping a refresh of our product line in 2011, which we market as G4. The G4 refresh included multiple new products and an upgrade product that allowed existing customers to augment their installations to obtain the most current technology that we provide. The G4 product is updated regularly every 6 to18 months with new software enhancements. Since its introduction in 2011, there have been five major software releases. The G4 product refresh has been a key contributor to our growth, with approximately 81% of our automation and analytics installed base ordering upgrades to their existing systems since the announcement of G4. In addition to enhanced capabilities, we have focused on attaining the highest quality and service measurements for G4 in the industry, while marketing the solution to new and existing customers. Our research and development efforts today are designed to bring new products to market beyond the G4 product line that we believe will meet customer needs in years to come.

[0000926326-16-000070:mdna:36]
[same as prior period, unchanged from 0000926326-16-000057:mdna:35]

[0000926326-16-000070:mdna:37]
Expansion of our solutions through acquisitions and partnerships include our acquisition of MTS in 2012, our acquisition of Surgichem in August 2014, our acquisitions of Mach4 and Avantec in April 2015, and our acquisition of Aesynt in January 2016. Surgichem is a provider of medication adherence products in the United Kingdom. Mach4 is a provider of automated medication management systems to retail and hospital pharmacy customers primarily in Europe, with additional installations in China, the Middle East and Latin America. Avantec develops medication and supply automation products that complement our solutions for configurations suited to the United Kingdom marketplace, and had been the exclusive United Kingdom distributor for our medication and supply automation solutions since 2005. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-16-000070:mdna:38]
[same as prior period, unchanged from 0000926326-16-000057:mdna:37]

[0000926326-16-000070:mdna:39]
[same as prior period, unchanged from 0000926326-16-000057:mdna:38]

[0000926326-16-000070:mdna:40]
[same as prior period, unchanged from 0000926326-16-000057:mdna:39]

[0000926326-16-000070:mdna:41]
[same as prior period, unchanged from 0000926326-16-000057:mdna:40]

[0000926326-16-000070:mdna:42]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced by a contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are installable within twelve months and generally recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month.

[0000926326-16-000070:mdna:43]
In addition to product solution sales, we provide services to our customers.  Our healthcare customers expect a high degree of partnership involvement from their technology suppliers throughout their ownership of the products. We provide extensive installation planning and consulting as part of every product sale and included in the initial price of the solution. Our customers' medication control systems are mission critical to their success and our customers require these systems to be functional at all times. To help assure the maximum availability of our systems, our customers typically purchase maintenance

[0000926326-16-000070:mdna:44]
and support contracts in one, two or five year increments.  As a result of the growth of our installed base of customers, our service revenues have also grown. We strive to provide the best service possible, as measured by third-party rating agencies and by our own surveys, to assure our customers continue to seek service maintenance from us. Our liabilities include current and long-term deferred revenues of $120.3 million and $87.3 million as of June 30, 2016 and December 31, 2015, respectively. The current deferred revenue of $84.9 million includes deferred revenue from product sales and service contracts, net of deferred cost of sales of $17.9 million as of June 30, 2016. The current deferred revenues from product sales relate to the delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. The long-term deferred revenue of $17.5 million as of June 30, 2016 includes deferred revenue from service contracts in excess of twelve months.

[0000926326-16-000070:mdna:45]
The growth in our Automation and Analytics revenue for the three months ended June 30, 2016 was driven primarily by the expansion through the Aesynt acquisition. To a lesser extent but of equal importance, revenue growth was also driven by our growth in the number of our customer installations. Installed customers in the United States grew to 2,889 hospitals as of June 30, 2016 from 1,975 hospitals as of June 30, 2015, driven primarily by the acquisition of Aesynt. In addition, our success in upgrading installed customers to newer G4 technology, which is in line with our strategy of striving to deliver differentiated innovation in our solutions further attributed to the increase in revenue. Our larger installed base has provided growth opportunities for follow on sales and increased service contracts and, as a result, our service revenues have also grown for the three and six months ended June 30, 2016.  Medication Adherence revenue has remained relatively consistent as the population of patients living in nursing homes, primarily in the United States market, has remained relatively constant over the past year.

[0000926326-16-000070:mdna:46]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but for our focus to remain on improving healthcare with solutions that help change practices in ways that improve patient and provider outcomes. We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue.

[0000926326-16-000070:mdna:47]
[same as prior period, unchanged from 0000926326-16-000057:mdna:47]

[0000926326-16-000070:mdna:48]
[same as prior period, unchanged from 0000926326-16-000057:mdna:48]

[0000926326-16-000070:mdna:49]
[same as prior period, unchanged from 0000926326-16-000057:mdna:49]

[0000926326-16-000070:mdna:50]
[same as prior period, unchanged from 0000926326-16-000057:mdna:50]

[0000926326-16-000070:mdna:51]
| • | Inventory valuation; |

[0000926326-16-000070:mdna:52]
| • | Capitalized software development cost; |

[0000926326-16-000070:mdna:53]
[same as prior period, unchanged from 0000926326-16-000057:mdna:51]

[0000926326-16-000070:mdna:54]
[same as prior period, unchanged from 0000926326-16-000057:mdna:52]

[0000926326-16-000070:mdna:55]
[same as prior period, unchanged from 0000926326-16-000057:mdna:53]

[0000926326-16-000070:mdna:56]
[same as prior period, unchanged from 0000926326-16-000057:mdna:54]

[0000926326-16-000070:mdna:57]
There have been no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the six months ended June 30, 2016 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2015. Concurrent with our acquisition of Aesynt in January 2016, certain accounting policies of Aesynt were aligned to conform to the accounting policies of Omnicell.

[0000926326-16-000070:mdna:58]
[same as prior period, unchanged from 0000926326-16-000057:mdna:56]

[0000926326-16-000070:mdna:59]
[same as prior period, unchanged from 0000926326-16-000057:mdna:57]

[0000926326-16-000070:mdna:60]
[same as prior period, unchanged from 0000926326-16-000057:mdna:58]

[0000926326-16-000070:mdna:61]
[same as prior period, unchanged from 0000926326-16-000057:mdna:59]

[0000926326-16-000070:mdna:62]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 130,674 |  |  | $ | 89,154 |  |  | $ | 41,520 |  |  | 47 | % |
| Percentage of total revenues | 76 | % |  | 79 | % |  |  |  |  |
| Service and other revenues | 42,233 |  |  | 23,634 |  |  | 18,599 |  |  | 79 | % |
| Percentage of total revenues | 24 | % |  | 21 | % |  |  |  |  |
| Total revenues | $ | 172,907 |  |  | $ | 112,788 |  |  | $ | 60,119 |  |  | 53 | % |

[0000926326-16-000070:mdna:63]
Product revenues represented 76% and 79% of total revenues for the three months ended June 30, 2016 and June 30, 2015, respectively. Product revenues increased due to increased sales for Automation and Analytics segment of $41.3 million, and increased sales for Medication Adherence segment of $0.2 million. The recently acquired companies, Aesynt, Mach4 and Avantec, contributed $25.4 million to the product revenue increase in the Automation and Analytics segment.  The remaining increase in this segment was attributed to customer conversions, larger orders received from our existing customers, and higher implementations. The increase in Medication Adherence segment was attributed to higher sales in the consumable product sales compared to the three months ended June 30, 2015.

[0000926326-16-000070:mdna:64]
Service and other revenues represented 24% and 21% of total revenues for the three months ended June 30, 2016 and June 30, 2015, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues increased primarily due to an increase from our Automation and Analytics segment of $18.6 million attributed to the acquired companies Aesynt, Mach4 and Avantec, and higher service renewal fees driven mainly by an increase in installed customer base. The acquired companies contributed $17.4 million to the increase in service revenue of Automation and Analytics segment for the three months ended June 30, 2016 compared to the three months ended June 30, 2015.  Service and other revenues from Medication Adherence segment remained flat for the three months ended June 30, 2016 compared to the same period last year.

[0000926326-16-000070:mdna:65]
Our international sales represented 16% of total revenues for both the three months ended June 30, 2016 and June 30, 2015, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-16-000070:mdna:66]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $258,569 |  | $183,263 |  | $ | 75,306 |  |  | 41 | % |
| Percentage of total revenues | 75 | % |  | 80 | % |  |  |  |  |
| Service and other revenues | 85,342 |  |  | 45,746 |  |  | 39,596 |  |  | 87 | % |
| Percentage of total revenues | 25 | % |  | 20 | % |  |  |  |  |
| Total revenues | $ | 343,911 |  |  | $ | 229,009 |  |  | $ | 114,902 |  |  | 50 | % |

[0000926326-16-000070:mdna:67]
Product revenues represented 75% and 80% of total revenues for the six months ended June 30, 2016 and June 30, 2015, respectively. Product revenues increased due to increased sales for our Automation and Analytics segment of $76.7 million, partially offset by decrease in revenues from our Medication Adherence segment of $1.4 million. The acquired companies Aesynt, Mach4 and Avantec contributed approximately $55.5 million to the Automation and Analytics segment for the six months ended June 30, 2016.  The remaining increase in the Automation and Analytics segment was attributed to customer conversions, larger orders received from our existing customers, and higher implementations and lease renewals.

[0000926326-16-000070:mdna:68]
Service and other revenues represented 25% and 20% of total revenues for the six months ended June 30, 2016 and June 30, 2015, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues primarily increased due to an increase from our Automation and Analytics segment of $39.5 million. The acquired companies, Aesynt, Mach4 and Avantec contributed approximately $37.1 million to the increase of service revenue of Automation and Analytics segment for the three months ended June 30, 2016.

[0000926326-16-000070:mdna:69]
32

[0000926326-16-000070:mdna:70]
Our international sales represented 16% of total revenues for both the six months ended June 30, 2016 and June 30, 2015, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-16-000070:mdna:71]
We anticipate our revenues will continue to increase in 2016 compared to the same periods in 2015 as we fulfill our existing orders and based on our growth in bookings in 2015 and in the first six months of 2016, some of which will be recognized as revenue in 2016. Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-16-000070:mdna:72]
[same as prior period, unchanged from 0000926326-16-000057:mdna:65]

[0000926326-16-000070:mdna:73]
[same as prior period, unchanged from 0000926326-16-000057:mdna:67]

[0000926326-16-000070:mdna:74]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 148,660 |  |  | $ | 88,701 |  |  | $ | 59,959 |  |  | 68 | % |
| Percentage of total revenues | 86 | % |  | 79 | % |  |  |  |  |
| Medication Adherence | 24,247 |  |  | 24,087 |  |  | 160 |  |  | 1 | % |
| Percentage of total revenues | 14 | % |  | 21 | % |  |  |  |  |
| Total revenues | $ | 172,907 |  |  | $ | 112,788 |  |  | $ | 60,119 |  |  | 53 | % |

[0000926326-16-000070:mdna:75]
The increase in Automation and Analytics revenues for the three months ended June 30, 2016 in comparison to the three months ended June 30, 2015 was due to an increase in both product revenue and service revenues which contributed $41.3 million and $18.7 million to the increase, respectively. The increase in product and service revenue was primarily due to the recently acquired companies, Aesynt, Mach4 and Avantec, which contributed $25.4 million and $17.4 million of the increase in product and service revenue, respectively. The increases in product revenue in the three months ended June 30, 2016 were also attributed to the larger deal sizes primarily due to customer conversions, higher implementations, and higher lease renewals.

[0000926326-16-000070:mdna:76]
Medication Adherence revenues remained flat for the three months ended June 30, 2016 in comparison to the three months ended June 30, 2015.  While consumable product revenue increased quarter over quarter, the increase was offset by a decrease in the equipment sales primarily due to the timing of installations.

[0000926326-16-000070:mdna:77]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 297,605 |  |  | $ | 181,480 |  |  | $ | 116,125 |  |  | 64 | % |
| Percentage of total revenues | 87 | % |  | 79 | % |  |  |  |  |
| Medication Adherence | 46,306 |  |  | 47,529 |  |  | (1,223 | ) |  | (3 | )% |
| Percentage of total revenues | 13 | % |  | 21 | % |  |  |  |  |
| Total revenues | $ | 343,911 |  |  | $ | 229,009 |  |  | $ | 114,902 |  |  | 50 | % |

[0000926326-16-000070:mdna:78]
The increase in Automation and Analytics revenues for the six months ended June 30, 2016 in comparison to the six months ended June 30, 2015 was due to an increase in product revenues of $76.7 million primarily due to the recently acquired companies Aesynt, Mach4 and Avantec which contributed $55.5 million to the product revenue for the six month ended June 30, 2016. The increases in product revenues were also attributed to the larger deal sizes primarily due to customer conversions, higher implementations and higher lease renewals. The increase in service revenue was primarily due to the recently acquired companies, Aesynt, Mach4 and Avantec, which contributed for $37.1 million.

[0000926326-16-000070:mdna:79]
[same as prior period, unchanged from 0000926326-16-000057:mdna:97]

[0000926326-16-000070:mdna:80]
Medication Adherence revenues decreased for the six months ended June 30, 2016 in comparison to the six months ended June 30, 2015, primarily due to lower product revenues of $1.4 million as result of lower consumables sales.

[0000926326-16-000070:mdna:81]
[same as prior period, unchanged from 0000926326-16-000057:mdna:71]

[0000926326-16-000070:mdna:82]
[same as prior period, unchanged from 0000926326-16-000057:mdna:72]

[0000926326-16-000070:mdna:83]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 78,366 |  |  | $ | 39,403 |  |  | $ | 38,963 |  |  | 99 | % |
| As a percentage of related revenues | 53 | % |  | 44 | % |  |  |  |  |
| Medication Adherence | 16,524 |  |  | 15,923 |  |  | 601 |  |  | 4 | % |
| As a percentage of related revenues | 68 | % |  | 66 | % |  |  |  |  |
| Total cost of revenues | $ | 94,890 |  |  | $ | 55,326 |  |  | $ | 39,564 |  |  | 72 | % |
| As a percentage of total revenues | 55 | % |  | 49 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 70,294 |  |  | $ | 49,298 |  |  | $ | 20,996 |  |  | 43 | % |
| Automation and Analytics gross margin | 47 | % |  | 55 | % |  |  |  |  |
| Medication Adherence | 7,723 |  |  | 8,164 |  |  | (441 | ) |  | (5 | )% |
| Medication Adherence gross margin | 32 | % |  | 35 | % |  |  |  |  |
| Total gross profit | $ | 78,017 |  |  | $ | 57,462 |  |  | $ | 20,555 |  |  | 36 | % |
| Total gross margin | 45 | % |  | 51 | % |  |  |  |  |

[0000926326-16-000070:mdna:84]
34

[0000926326-16-000070:mdna:85]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 155,573 |  |  | $ | 78,255 |  |  | $ | 77,318 |  |  | 99 | % |
| As a percentage of related revenues | 52 | % |  | 43 | % |  |  |  |  |
| Medication Adherence | 30,376 |  |  | 31,607 |  |  | (1,231 | ) |  | (4 | )% |
| As a percentage of related revenues | 63 | % |  | 67 | % |  |  |  |  |
| Total cost of revenues | $ | 185,949 |  |  | $ | 109,862 |  |  | $ | 76,087 |  |  | 69 | % |
| As a percentage of total revenues | 53 | % |  | 48 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 142,032 |  |  | $ | 103,225 |  |  | $ | 38,807 |  |  | 38 | % |
| Automation and Analytics gross margin | 48 | % |  | 57 | % |  |  |  |  |
| Medication Adherence | 15,930 |  |  | 15,922 |  |  | 8 |  |  | — | % |
| Medication Adherence gross margin | 37 | % |  | 33 | % |  |  |  |  |
| Total gross profit | $ | 157,962 |  |  | $ | 119,147 |  |  | $ | 38,815 |  |  | 33 | % |
| Total gross margin | 47 | % |  | 52 | % |  |  |  |  |

[0000926326-16-000070:mdna:86]
[same as prior period, unchanged from 0000926326-16-000057:mdna:74]

[0000926326-16-000070:mdna:87]
Cost of Revenues. The cost of revenues for the three months ended June 30, 2016 compared to the three months ended June 30, 2015 increased by $39.0 million, of which $29.6 million is attributed the increase in product costs and $9.3 million is attributed to the increase in service costs. Of the $29.6 million increase in product costs, the acquired companies Aesynt, Mach4 and Avantec contributed $20.8 million. The product costs incurred by the acquired companies includes the amortization expense for developed technology of $1.4 million, amortization of backlog of $3.4 million, and inventory step-up fair value adjustment of $0.9 million resulting from the purchase accounting. The remaining increase in the product costs is attributed to product mix and decrease in revenues from lease renewals. Cost of service revenues increased by $9.3 million primarily due to costs related to the acquired companies Aesynt, Mach4 and Avantec, which contributed $8.8 million to the increase in cost of service revenue.

[0000926326-16-000070:mdna:88]
The increase in cost of revenues for the six months ended June 30, 2016 compared to the six months ended June 30, 2015 was $77.3 million, $58.1 million of which is attributed to the increase in product costs and $19.2 million is attributed to the increase in service costs. The recently acquired companies, Aesynt, Mach4 and Avantec, contributed $45.2 million to the increase in product costs.  The remaining increase in product cost is attributed to different mixture of customers, products and overall growth in product sales, and higher product installation costs as result of with higher revenue.  Cost of service revenues for six months ended June 30, 2016 increased by $19.2, of this increase $18.8 million was primarily due to an increase in costs related to the acquired companies Aesynt, Mach4 and Avantec.

[0000926326-16-000070:mdna:89]
Gross profit for the three and six months ended June 30, 2016 decreased compared to the three and six months ended June 30, 2015 as a result of product mix from a higher volume sales of low margin products, and lower gross margins from the acquired companies Aesynt, Mach4 and Avantec primarily due to fair value adjustments related to deferred revenue, inventory step-up, and amortization of developed technology and backlog intangible assets.

[0000926326-16-000070:mdna:90]
[same as prior period, unchanged from 0000926326-16-000057:mdna:77]

[0000926326-16-000070:mdna:91]
Cost of Revenues. Cost of revenues increased by $0.6 million in the three months ended June 30, 2016 compared to the three months ended June 30, 2015, primarily due to the increase in product cost as result of the product mix.  For the six months ended June 30, 2016 compared to the six months ended June 30, 2015, cost of revenue decreased by $1.2 million.  The decrease was due to the decrease of $1.5 million attributable to product costs as result of change in product mix, partially offset by an increase in service related costs of $0.3 million.

[0000926326-16-000070:mdna:92]
Gross profit for the six months ended June 30, 2016 increased compared to the six months ended June 30, 2015 primarily due to changes in our product mix, partially offset by higher manufacturing cost and higher cost of service.

[0000926326-16-000070:mdna:93]
[same as prior period, unchanged from 0000926326-16-000057:mdna:80]

[0000926326-16-000070:mdna:94]
35

[0000926326-16-000070:mdna:95]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 13,794 |  |  | $ | 8,746 |  |  | $ | 5,048 |  |  | 58 | % |
| As a percentage of total revenues | 8 | % |  | 8 | % |  |  |  |  |
| Selling, general and administrative | 64,341 |  |  | 39,735 |  |  | 24,606 |  |  | 62 | % |
| As a percentage of total revenues | 37 | % |  | 35 | % |  |  |  |  |
| Gain on business combination | — |  |  | (3,443 | ) |  | 3,443 |  |  | (100 | )% |
| As a percentage of total revenues |  |  | (3 | )% |  |  |  |  |
| Total operating expenses | $ | 78,135 |  |  | $ | 45,038 |  |  | $ | 33,097 |  |  | 73 | % |
| As a percentage of total revenues | 45 | % |  | 40 | % |  |  |  |  |
| Income (loss) from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 20,514 |  |  | $ | 23,320 |  |  | $ | (2,806 | ) |  | (12 | )% |
| Operating margin | 14 | % |  | 21 | % |  |  |  |  |
| Medication Adherence | 1,952 |  |  | 2,254 |  |  | (302 | ) |  | (13 | )% |
| Operating margin | 9 | % |  | 2 | % |  |  |  |  |
| Corporate Expenses | 22,584 |  |  | 13,150 |  |  | 9,434 |  |  | 72 | % |
| Total (loss) income from operations | $ | (118 | ) |  | $ | 12,424 |  |  | $ | (12,542 | ) |  | (101 | )% |
| Total operating margin | (0.1 | )% |  | 11 | % |  |  |  |  |

[0000926326-16-000070:mdna:96]
Research and Development. The increase in research and development expenses of $5.0 million for the three months ended June 30, 2016 compared to three months ended June 30, 2015 was primarily driven by an increase in research and development expenses of $5.1 million in our Automation and Analytics segment, partially offset by a decrease in our Medication Adherence segment research and development expenses of $0.1 million due to lower employee related expenses. The increase in Automation and Analytics segment is attributed to the acquired companies which accounted for $4.2 million of the increase, $0.6 million of higher employees related expenses, and $0.5 million of higher capitalized software amortization expense.

[0000926326-16-000070:mdna:97]
Selling, General and Administrative.  The increase in selling, general and administrative expenses for the three months ended June 30, 2016 compared to the three months ended June 30, 2015 was primarily due to increases from our Automation and Analytics segment of $15.3 million and corporate expenses of $9.3 million. The increase in our Automation and Analytics segment was primarily attributable to the acquired companies which accounted for $12.3 million of the increase.  The increase in share-based compensation expenses of $1.5 million, and restructuring related charges of approximately $1.2 million also contributed to the increase in selling, general and administrative expenses for the periods presented. The increase in corporate expenses was mainly related to higher share-based compensation expenses of $1.2 million, and increase in employee related expenses of $1.9 million due to increase in employee headcount.

[0000926326-16-000070:mdna:98]
Operating Income (loss). Operating income from our Automation and Analytics segment decreased by $2.8 million due to a higher research and development and selling, general and administrative costs of $23.8 million, partially offset by higher gross margin of $21.0 million.  Operating income from our Medication Adherence segment decreased by $(0.3) million due to higher manufacturing costs, higher cost of service, partially off-set by lower research and development.

[0000926326-16-000070:mdna:99]
Corporate expense. The increase in corporate expenses for the three months ended June 30, 2016 compared to the three months ended June 30, 2015 was primarily attributable to the acquired companies which accounted for $7.3 million of the increase.

[0000926326-16-000070:mdna:100]
36

[0000926326-16-000070:mdna:101]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 27,632 |  |  | $ | 16,765 |  |  | $ | 10,867 |  |  | 65 | % |
| As a percentage of total revenues | 8 | % |  | 7 | % |  |  |  |  |
| Selling, general and administrative | 128,596 |  |  | 83,022 |  |  | 45,574 |  |  | 55 | % |
| As a percentage of total revenues | 37 | % |  | 36 | % |  |  |  |  |
| Gain on business combination | — |  |  | (3,443 | ) |  | 3,443 |  |  | (100 | )% |
| As a percentage of total revenues | — | % |  | (2 | )% |  |  |  |  |
| Total operating expenses | $ | 156,228 |  |  | $ | 96,344 |  |  | $ | 59,884 |  |  | 62 | % |
| As a percentage of total revenues | 46 | % |  | 42 | % |  |  |  |  |
| Income from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 40,047 |  |  | $ | 48,658 |  |  | $ | (8,611 | ) |  | (18 | )% |
| Operating margin | 12 | % |  | 21 | % |  |  |  |  |
| Medication Adherence | 4,548 |  |  | 3,671 |  |  | 877 |  |  | 24 | % |
| Operating margin | 1 | % |  | 2 | % |  |  |  |  |
| Corporate Expenses | 42,861 |  |  | 29,526 |  |  | 13,335 |  |  | 45 | % |
| Total income from operations | $ | 1,734 |  |  | $ | 22,803 |  |  | $ | (21,069 | ) |  | (92 | )% |
| Total operating margin | 1 | % |  | 10 | % |  |  |  |  |

[0000926326-16-000070:mdna:102]
Research and Development. The increase in research and development expenses of $10.9 million for the six months ended June 30, 2016 compared to six months ended June 30, 2015 was driven by an increase in research and development expenses of $11.5 million in our Automation and Analytics segment, partially offset by a decrease in our Medication Adherence segment research and development expenses of $0.7 million primarily due to lower capitalized software related expenses. The increase in Automation and Analytics segment is attributed to the acquired companies which accounted for $8.3 million of the increase, $1.4 million of higher employees related expenses, lower capitalized software cost of $1.0 million driven by post-feasibility beta testing phase, and $0.5 million of higher consulting expenses.

[0000926326-16-000070:mdna:103]
Selling, General and Administrative.  The increase in selling, general and administrative expenses for the six months ended June 30, 2016 compared to the six months ended June 30, 2015 was primarily due to increases from our Automation and Analytics segment of $32.5 million and corporate expenses of $13.2 million, partially offset by decreases in Medication Adherence segment of $0.1 million. The increase in our Automation and Analytics segment was primarily attributable to the acquired companies which accounted for $26.6 million of the increase.  The remaining increase is due primarily to employee related expenses, including commissions and salaries. The increase in the corporate expenses was mainly related to the acquisition related expenses of $5.1 million, restructuring charges of $0.6 million, and stock based compensation expenses of approximately $1.5 million.

[0000926326-16-000070:mdna:104]
Operating Income. Operating income for six months ended June 30, 2016 from our Automation and Analytics segment decreased by $8.6 million due to a higher research and development and selling, general and administrative costs of $44.0 million, partially offset by higher gross margin of $38.8 million.

[0000926326-16-000070:mdna:105]
[same as prior period, unchanged from 0000926326-16-000057:mdna:86]

[0000926326-16-000070:mdna:106]
Corporate expense. The increase in corporate expenses for the six months ended June 30, 2016 compared to the six months ended June 30, 2015 was primarily attributable to the acquired companies which accounted for $14.7 million of the increase.

[0000926326-16-000070:mdna:107]
[same as prior period, unchanged from 0000926326-16-000057:mdna:87]

[0000926326-16-000070:mdna:108]
37

[0000926326-16-000070:mdna:109]
|  | Three months ended |
|  |  |  |  |  | Change in |
|  | June 30, 2016 |  | June 30, 2015 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision (benefit) for income taxes | $ | (840 | ) |  | $ | 3,201 |  |  | $ | (4,041 | ) |  | (126 | )% |

[0000926326-16-000070:mdna:110]
|  | Six months ended |
|  |  |  |  |  | Change in |
|  | June 30, 2016 |  | June 30, 2015 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision (benefit) for income taxes | $ | (781 | ) |  | $ | 6,745 |  |  | $ | (7,526 | ) |  | (112 | )% |

[0000926326-16-000070:mdna:111]
Our annual effective tax rate before discrete items was 38.3% and 38.5% for the six months ended June 30, 2016 and June 30, 2015, respectively. The decrease in the estimated annual effective tax rate for the six months ended June 30, 2016 compared to the same period in 2015 was primarily due to a full year inclusion of the Federal research & development tax credit (which was permanently reinstated on December 18, 2015), offset by an increase in non-deductible equity charges and non-deductible expenses.

[0000926326-16-000070:mdna:112]
[same as prior period, unchanged from 0000926326-16-000057:mdna:90]

[0000926326-16-000070:mdna:113]
[same as prior period, unchanged from 0000926326-16-000057:mdna:91]

[0000926326-16-000070:mdna:114]
We had cash and cash equivalents of $41.0 million at June 30, 2016, compared to $82.2 million at December 31, 2015. All of our cash and cash equivalents are invested in demand deposits and money market funds.

[0000926326-16-000070:mdna:115]
Our cash position and working capital at June 30, 2016 and December 31, 2015 were as follows:

[0000926326-16-000070:mdna:116]
|  | June 30, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Cash | $ | 30,903 |  |  | $ | 72,103 |  |
| Cash equivalents | 10,126 |  |  | 10,114 |  |
| Total | $ | 41,029 |  |  | $ | 82,217 |  |
| Working Capital | $ | 120,601 |  |  | $ | 139,498 |  |

[0000926326-16-000070:mdna:117]
Our ratio of current assets to current liabilities was 1.6:1 at June 30, 2016 compared to 2.1:1 at December 31, 2015.

[0000926326-16-000070:mdna:118]
On January 5, 2016, we entered into a $400 million secured credit facility pursuant to a credit agreement, by and among us, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as sole lead arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200 million term loan facility (the “Term Loan Facility”) and a $200 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). At the closing of the Aesynt Acquisition, we borrowed $255 million in secured debt under the Credit Agreement, consisting of $200 million of term loans and $55 million of revolving loans to complete the acquisition of Aesynt and to pay related fees and expenses. In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes. The Credit Agreement replaces our existing Credit Agreement, dated as of September 25, 2013, by and among the Company, the lenders from time to time party thereto and Wells Fargo Bank, National Association, as administrative agent, as amended.

[0000926326-16-000070:mdna:119]
Loans under the Facilities bear interest, at our option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement). Undrawn commitments under the

[0000926326-16-000070:mdna:120]
38

[0000926326-16-000070:mdna:121]
Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on our Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on our Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-16-000070:mdna:122]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us and our subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Credit Agreement also includes financial covenants requiring us not to exceed a maximum consolidated total leverage ratio of 3.00:1 (subject to certain exceptions) and to maintain a minimum fixed charge coverage ratio of 1.50:1.

[0000926326-16-000070:mdna:123]
As of June 30, 2016, the outstanding balance from the facilities was $232.5 million. We were in full compliance with all covenants.

[0000926326-16-000070:mdna:124]
[same as prior period, unchanged from 0000926326-16-000057:mdna:101]

[0000926326-16-000070:mdna:125]
[same as prior period, unchanged from 0000926326-16-000057:mdna:102]

[0000926326-16-000070:mdna:126]
Our 2014 Stock Repurchase Program had a total of $4.9 million remaining for future repurchases as of June 30, 2016.

[0000926326-16-000070:mdna:127]
In accordance with the Avantec share purchase agreement, we may pay out a potential earn-out payment of $3.0 million payable after December 31, 2016, based on future bookings. The fair value of this earn-out payment as of June 30, 2016 was $2.9 million. Pursuant to the terms of the agreement, we also held back $1.8 million from the purchase consideration towards any future indemnification claims that we may make by fourth quarter of 2016.

[0000926326-16-000070:mdna:128]
We will be making payments under the credit facilities for next five years. Refer to below, Contractual Obligations table for details on the payments for the credit facilities.

[0000926326-16-000070:mdna:129]
[same as prior period, unchanged from 0000926326-16-000057:mdna:105]

[0000926326-16-000070:mdna:130]
[same as prior period, unchanged from 0000926326-16-000057:mdna:106]

[0000926326-16-000070:mdna:131]
[same as prior period, unchanged from 0000926326-16-000057:mdna:107]

[0000926326-16-000070:mdna:132]
|  | Six months ended |
|  | June 30, 2016 |  | June 30, 2015 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 15,953 |  |  | $ | 10,190 |  |
| Investing activities | (285,262 | ) |  | (33,741 | ) |
| Financing activities | 229,561 |  |  | (14,476 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (1,440 | ) |  | 167 |  |
| Net decrease in cash and cash equivalents | $ | (41,188 | ) |  | $ | (37,860 | ) |

[0000926326-16-000070:mdna:133]
[same as prior period, unchanged from 0000926326-16-000057:mdna:109]

[0000926326-16-000070:mdna:134]
[same as prior period, unchanged from 0000926326-16-000057:mdna:110]

[0000926326-16-000070:mdna:135]
Net cash provided by operating activities was $16.0 million for the six months ended June 30, 2016, primarily as a result of $1.5 million in net loss adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $29.2 million, share-based compensation expense of $9.4 million and deferred income taxes of $3.9 million. The cash outflow attributed to changes in assets and liabilities includes an increase in

[0000926326-16-000070:mdna:136]
accounts receivable of $8.1 million due to increased product shipments late in the quarter, an increase in inventories of $7.8 million to support forecasted sales, increases in long-term investment in sales-type leases of $6.6 million due to two significant lease transactions entered into during the year, increases in prepaid expenses by $4.9 million mainly due to decrease in prepaid commissions and prepaid income taxes, a decrease in accrued liabilities of $2.2 million due to timing of payments to employees related liabilities and decreased in the other-long term liabilities by $2.4 million. These amounts were partially offset by an increase in the accounts payables of $6.7 million due to timing of payments, an increase in the deferred revenue of $4.9 million due to timing of orders and revenue being recognized for installed product, and decreases in other long-term assets of $1.0 million.

[0000926326-16-000070:mdna:137]
Net cash provided by operating activities was $10.2 million for the six months ended June 30, 2015, primarily as a result of $15.1 million in net income adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $12.0 million, share-based compensation expense, net of tax of $7.2 million and $3.4 million from our investment gain. This was offset by $19.6 million cash outflow from changes in assets and liabilities resulting primarily from an increase in accounts receivable of $27.7 million, due to increased product shipments late in the quarter, an increase in inventories of $9.6 million to support forecasted sales and from the acquisition of Mach4 and Avantec, a decrease in deferred service revenue of $2.9 million primarily due to the timing of service contracts renewals and a slight decrease in product sales and $1.7 million decrease in accrued compensation due to lower sales commissions. These amounts were partially offset by a decrease in the prepaid expenses of $8.2 million primarily due to commissions driven by higher bookings in the fourth quarter of 2014 compared to the current year to date period, an increase in deferred gross profit of $6.0 million due to timing of orders, shipments, and revenue being recognized for installed product, an increase in accrued liabilities of $5.8 million due to potential earn-out and contingent payments related to the Avantec Acquisition, a $1.4 million increase trade accounts payable due to growth in our business activities and a decrease in other assets of $1.5 million.

[0000926326-16-000070:mdna:138]
[same as prior period, unchanged from 0000926326-16-000057:mdna:113]

[0000926326-16-000070:mdna:139]
Net cash used in investing activities was $285.3 million for the six months ended June 30, 2016, $271.5 million of which was attributable to the acquisition of Aesynt. Capital expenditures related to purchases of property and equipment, software development costs for external use and, purchases of intangibles contributed $5.9 million and $6.7 million, and $1.2 million, respectively.

[0000926326-16-000070:mdna:140]
Net cash used in investing activities was $33.7 million for the six months ended June 30, 2015, primarily attributable to the acquisitions of Mach4 and Avantec in the amount of $23.7 million, purchases of property and equipment of $3.8 million and $6.1 million, respectively, for development of software for external use.

[0000926326-16-000070:mdna:141]
[same as prior period, unchanged from 0000926326-16-000057:mdna:116]

[0000926326-16-000070:mdna:142]
Net cash provided by financing activities was $229.6 million for the six months ended June 30, 2016 as a result of proceeds from term loan and revolving credit facilities of $247.1 million net of deferred issuance cost of $7.9 million, $8.6 million in proceeds from employee stock option exercises and employee stock plan purchases, and $0.9 million in excess tax benefits from employee stock plans.  The increase in cash provided from financing activities was partially offset by repayment of $22.5 million of the credit facilities, payment of contingent consideration of $3.0 million related to the Avantec acquisition, and $1.6 million in employees' taxes paid related to restricted stock units.

[0000926326-16-000070:mdna:143]
Net cash used by financing activities was $14.5 million for the six months ended June 30, 2015 as a result of $25.0 million in cash used for stock repurchases under our 2012 and 2014 Stock Repurchase Programs and $2.0 million in employees' taxes paid related to restricted stock units, partially offset by $9.4 million in proceeds from employee stock option exercises and employee stock plan purchases and $3.1 million in excess tax benefits from employee stock plans.

[0000926326-16-000070:mdna:144]
[same as prior period, unchanged from 0000926326-16-000057:mdna:119]

[0000926326-16-000070:mdna:145]
There have been no significant changes during the six months ended June 30, 2016 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2015.

[0000926326-16-000070:mdna:146]
We had $325.0 million in contractual commitments to third parties for non-cancelable operating leases, commitments to contract manufacturers and suppliers,other purchase commitments and term loan and revolving credit facility as of June 30, 2016 as follows:

[0000926326-16-000070:mdna:147]
40

[0000926326-16-000070:mdna:148]
|  | Payments due by period |
|  | Total |  | Remainder of 2016 |  | 2017 and 2018 |  | 2019 and 2020 |  | 2021 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 52,911 |  |  | $ | 5,343 |  |  | $ | 20,690 |  |  | $ | 16,167 |  |  | $ | 10,711 |  |
| Purchase obligations (2) | 39,633 |  |  | 39,633 |  |  | — |  |  | — |  |  | — |  |
| Term loan facility | 197,500 |  |  | 5,000 |  |  | 27,500 |  |  | 47,500 |  |  | 117,500 |  |
| Revolving credit facility | 35,000 |  |  | — |  |  | — |  |  | — |  |  | 35,000 |  |
| Total (3) | $ | 325,044 |  |  | $ | 49,976 |  |  | $ | 48,190 |  |  | $ | 63,667 |  |  | $ | 163,211 |  |

[0000926326-16-000070:mdna:149]
[same as prior period, unchanged from 0000926326-16-000057:mdna:123]

[0000926326-16-000070:mdna:150]
[same as prior period, unchanged from 0000926326-16-000057:mdna:124]

[0000926326-16-000070:mdna:151]
[same as prior period, unchanged from 0000926326-16-000057:mdna:125]

[0000926326-16-000070:mdna:152]
| (3) | We have recorded $10.1 million for uncertain tax positions under long-term liabilities as of June 30, 2016 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, $10.1 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-16-000070:mdna:153]
[same as prior period, unchanged from 0000926326-16-000057:mdna:127]

[0000926326-16-000070:mdna:154]
[same as prior period, unchanged from 0000926326-16-000057:mdna:128]

[0000926326-16-000070:mdna:155]
As of June 30, 2016, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
