# OMCL MD&A — 0000926326-19-000033


## mdna

[0000926326-19-000033:mdna:1]
[same as prior period, unchanged from 0000926326-19-000025:mdna:1]

[0000926326-19-000033:mdna:2]
[same as prior period, unchanged from 0000926326-19-000025:mdna:2]

[0000926326-19-000033:mdna:3]
[same as prior period, unchanged from 0000926326-19-000025:mdna:3]

[0000926326-19-000033:mdna:4]
[same as prior period, unchanged from 0000926326-19-000025:mdna:4]

[0000926326-19-000033:mdna:5]
[same as prior period, unchanged from 0000926326-19-000025:mdna:5]

[0000926326-19-000033:mdna:6]
[same as prior period, unchanged from 0000926326-19-000025:mdna:6]

[0000926326-19-000033:mdna:7]
[same as prior period, unchanged from 0000926326-19-000025:mdna:7]

[0000926326-19-000033:mdna:8]
[same as prior period, unchanged from 0000926326-19-000025:mdna:8]

[0000926326-19-000033:mdna:9]
[same as prior period, unchanged from 0000926326-19-000025:mdna:9]

[0000926326-19-000033:mdna:10]
[same as prior period, unchanged from 0000926326-19-000025:mdna:10]

[0000926326-19-000033:mdna:11]
[same as prior period, unchanged from 0000926326-19-000025:mdna:11]

[0000926326-19-000033:mdna:12]
[same as prior period, unchanged from 0000926326-19-000025:mdna:12]

[0000926326-19-000033:mdna:13]
[same as prior period, unchanged from 0000926326-19-000025:mdna:13]

[0000926326-19-000033:mdna:14]
[same as prior period, unchanged from 0000926326-19-000025:mdna:14]

[0000926326-19-000033:mdna:15]
[same as prior period, unchanged from 0000926326-19-000025:mdna:15]

[0000926326-19-000033:mdna:16]
[same as prior period, unchanged from 0000926326-19-000025:mdna:16]

[0000926326-19-000033:mdna:17]
[same as prior period, unchanged from 0000926326-19-000025:mdna:17]

[0000926326-19-000033:mdna:18]
[same as prior period, unchanged from 0000926326-19-000025:mdna:18]

[0000926326-19-000033:mdna:19]
[same as prior period, unchanged from 0000926326-19-000025:mdna:19]

[0000926326-19-000033:mdna:20]
[same as prior period, unchanged from 0000926326-19-000025:mdna:20]

[0000926326-19-000033:mdna:21]
[same as prior period, unchanged from 0000926326-19-000025:mdna:22]

[0000926326-19-000033:mdna:22]
[same as prior period, unchanged from 0000926326-19-000025:mdna:23]

[0000926326-19-000033:mdna:23]
[same as prior period, unchanged from 0000926326-19-000025:mdna:24]

[0000926326-19-000033:mdna:24]
[same as prior period, unchanged from 0000926326-19-000025:mdna:25]

[0000926326-19-000033:mdna:25]
[same as prior period, unchanged from 0000926326-19-000025:mdna:26]

[0000926326-19-000033:mdna:26]
We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 90% and 88% of our total revenues for the three months ended September 30, 2019 and 2018, respectively, and 90% and 87% of our total revenues for the nine months ended September 30, 2019 and 2018, respectively. We have not in the past sold, and have no future plans to sell, our products, either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, or those subject to economic sanctions and export controls.

[0000926326-19-000033:mdna:27]
[same as prior period, unchanged from 0000926326-19-000025:mdna:28]

[0000926326-19-000033:mdna:28]
[same as prior period, unchanged from 0000926326-19-000025:mdna:29]

[0000926326-19-000033:mdna:29]
[same as prior period, unchanged from 0000926326-19-000025:mdna:30]

[0000926326-19-000033:mdna:30]
The healthcare market is experiencing a period of substantive change. In recent years, healthcare providers and facilities have faced increased spending on medication management, rising pharmaceutical costs, and substantial increases in healthcare administration. These factors, combined with continuing consolidation in the healthcare industry, have increased the need for the efficient delivery of healthcare in order to control costs and improve patient safety, and have elevated the strategic

[0000926326-19-000033:mdna:31]
importance of medication management across the continuum of care. Furthermore, the adoption of electronic healthcare records, new regulatory constraints, and changes in reimbursement arrangements have caused healthcare institutions to re-examine their operating structures, re-prioritize their investments, and seek efficiencies. We believe the evolving operating environments of our customers create challenges for any supplier, but also afford opportunities for suppliers that are able to partner with customers to help them meet the changing demands. We have invested, and intend to continue to invest in the strategies that we believe have generated, and will continue to generate, our revenue and earnings growth, while supporting initiatives and needs of our customers. These strategies include:

[0000926326-19-000033:mdna:32]
[same as prior period, unchanged from 0000926326-19-000025:mdna:33]

[0000926326-19-000033:mdna:33]
[same as prior period, unchanged from 0000926326-19-000025:mdna:34]

[0000926326-19-000033:mdna:34]
[same as prior period, unchanged from 0000926326-19-000025:mdna:35]

[0000926326-19-000033:mdna:35]
[same as prior period, unchanged from 0000926326-19-000025:mdna:36]

[0000926326-19-000033:mdna:36]
[same as prior period, unchanged from 0000926326-19-000025:mdna:37]

[0000926326-19-000033:mdna:37]
[same as prior period, unchanged from 0000926326-19-000025:mdna:38]

[0000926326-19-000033:mdna:38]
Our full-time headcount was approximately 2,630 and 2,480 on September 30, 2019 and December 31, 2018, respectively.

[0000926326-19-000033:mdna:39]
[same as prior period, unchanged from 0000926326-19-000025:mdna:40]

[0000926326-19-000033:mdna:40]
Our discussion and analysis of our financial condition and results of operations are based on our Condensed Consolidated Financial Statements, which have been prepared in accordance with United States Generally Accepted Accounting Principles (“U.S. GAAP”). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting periods. We regularly

[0000926326-19-000033:mdna:41]
review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions.

[0000926326-19-000033:mdna:42]
[same as prior period, unchanged from 0000926326-19-000025:mdna:42]

[0000926326-19-000033:mdna:43]
[same as prior period, unchanged from 0000926326-19-000025:mdna:43]

[0000926326-19-000033:mdna:44]
[same as prior period, unchanged from 0000926326-19-000025:mdna:44]

[0000926326-19-000033:mdna:45]
[same as prior period, unchanged from 0000926326-19-000025:mdna:45]

[0000926326-19-000033:mdna:46]
[same as prior period, unchanged from 0000926326-19-000025:mdna:46]

[0000926326-19-000033:mdna:47]
[same as prior period, unchanged from 0000926326-19-000025:mdna:47]

[0000926326-19-000033:mdna:48]
[same as prior period, unchanged from 0000926326-19-000025:mdna:48]

[0000926326-19-000033:mdna:49]
[same as prior period, unchanged from 0000926326-19-000025:mdna:49]

[0000926326-19-000033:mdna:50]
[same as prior period, unchanged from 0000926326-19-000025:mdna:50]

[0000926326-19-000033:mdna:51]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the nine months ended September 30, 2019 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2018, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-19-000033:mdna:52]
[same as prior period, unchanged from 0000926326-19-000025:mdna:52]

[0000926326-19-000033:mdna:53]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-19-000033:mdna:54]
[same as prior period, unchanged from 0000926326-19-000025:mdna:54]

[0000926326-19-000033:mdna:55]
[same as prior period, unchanged from 0000926326-19-000025:mdna:55]

[0000926326-19-000033:mdna:56]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 168,488 |  |  | $ | 149,709 |  |  | $ | 18,779 |  |  | 13% |
| Percentage of total revenues | 74% |  | 73% |  |  |  |  |
| Services and other revenues | 60,317 |  |  | 54,558 |  |  | 5,759 |  |  | 11% |
| Percentage of total revenues | 26% |  | 27% |  |  |  |  |
| Total revenues | $ | 228,805 |  |  | $ | 204,267 |  |  | $ | 24,538 |  |  | 12% |

[0000926326-19-000033:mdna:57]
Product revenues represented 74% and 73% of total revenues for the three months ended September 30, 2019 and 2018, respectively. Product revenues increased by $18.8 million, primarily due to an increase in our Automated Dispensing Cabinet business, driven primarily by the growth of XT series products, partially offset by a decrease in sales of Performance Center, primarily due to a large installation during the three months ended September 30, 2018.

[0000926326-19-000033:mdna:58]
Services and other revenues represented 26% and 27% of total revenues for the three months ended September 30, 2019 and 2018, respectively. Services and other revenues include revenues from service and maintenance contracts, and rentals of automation systems. Services and other revenues increased by $5.8 million, primarily due to higher service renewal fees, driven mainly by an increase in our installed customer base, as well as an increase in revenues from Population Health Solutions.

[0000926326-19-000033:mdna:59]
Our international sales represented 10% and 12% of total revenues for the three months ended September 30, 2019 and 2018, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-19-000033:mdna:60]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 472,477 |  |  | $ | 415,004 |  |  | $ | 57,473 |  |  | 14% |
| Percentage of total revenues | 73% |  | 72% |  |  |  |  |
| Services and other revenues | 176,258 |  |  | 160,555 |  |  | 15,703 |  |  | 10% |
| Percentage of total revenues | 27% |  | 28% |  |  |  |  |
| Total revenues | $ | 648,735 |  |  | $ | 575,559 |  |  | $ | 73,176 |  |  | 13% |

[0000926326-19-000033:mdna:61]
Product revenues represented 73% and 72% of total revenues for the nine months ended September 30, 2019 and 2018, respectively. Product revenues increased by $57.5 million, primarily due to an increase in our Automated Dispensing Cabinet business, driven primarily by the growth of XT series products, partially offset by a decrease in sales of Performance Center, primarily due to a large installation during the nine months ended September 30, 2018.

[0000926326-19-000033:mdna:62]
Services and other revenues represented 27% and 28% of total revenues for the nine months ended September 30, 2019 and 2018, respectively. Services and other revenues include revenues from service and maintenance contracts, and rentals of automation systems. Services and other revenues increased by $15.7 million, primarily due to higher service renewal fees, driven mainly by an increase in our installed customer base, as well as an increase in revenues from Population Health Solutions.

[0000926326-19-000033:mdna:63]
Our international sales represented 10% and 13% of total revenues for the nine months ended September 30, 2019 and 2018, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-19-000033:mdna:64]
[same as prior period, unchanged from 0000926326-19-000025:mdna:64]

[0000926326-19-000033:mdna:65]
[same as prior period, unchanged from 0000926326-19-000025:mdna:65]

[0000926326-19-000033:mdna:66]
[same as prior period, unchanged from 0000926326-19-000025:mdna:66]

[0000926326-19-000033:mdna:67]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 86,695 |  |  | $ | 79,149 |  |  | $ | 7,546 |  |  | 10% |
| As a percentage of related revenues | 51% |  | 53% |  |  |  |  |
| Cost of services and other revenues | 29,963 |  |  | 26,209 |  |  | 3,754 |  |  | 14% |
| As a percentage of related revenues | 50% |  | 48% |  |  |  |  |
| Total cost of revenues | $ | 116,658 |  |  | $ | 105,358 |  |  | $ | 11,300 |  |  | 11% |
| As a percentage of total revenues | 51% |  | 52% |  |  |  |  |
| Gross profit | $ | 112,147 |  |  | $ | 98,909 |  |  | $ | 13,238 |  |  | 13% |
| Gross margin | 49% |  | 48% |  |  |  |  |

[0000926326-19-000033:mdna:68]
Cost of revenues for the three months ended September 30, 2019 compared to the three months ended September 30, 2018 increased by $11.3 million, of which $7.5 million was attributed to the increase in cost of product revenues and $3.8 million was attributed to the increase in cost of services and other revenues. The increase in cost of product revenues is primarily driven by the increase in product revenues of $18.8 million for the three months ended September 30, 2019 compared to the three months ended September 30, 2018, partially offset by sales of product portfolios with higher margins as well as lower costs associated with the XT series manufacturing ramp up and economies of scale. The increase in cost of services and other revenues is primarily driven by increase in services and other revenues of $5.8 million for the three months ended September 30, 2019 compared to the three months ended September 30, 2018, as well as product mix with lower margins.

[0000926326-19-000033:mdna:69]
The overall increase in gross margin primarily relates to lower costs associated with the XT series manufacturing ramp up and economies of scale. Our gross profit for the three months ended September 30, 2019 was $112.1 million, as compared to $98.9 million for the three months ended September 30, 2018.

[0000926326-19-000033:mdna:70]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 250,089 |  |  | $ | 229,642 |  |  | $ | 20,447 |  |  | 9% |
| As a percentage of related revenues | 53% |  | 55% |  |  |  |  |
| Cost of services and other revenues | 85,337 |  |  | 75,770 |  |  | 9,567 |  |  | 13% |
| As a percentage of related revenues | 48% |  | 47% |  |  |  |  |
| Total cost of revenues | $ | 335,426 |  |  | $ | 305,412 |  |  | $ | 30,014 |  |  | 10% |
| As a percentage of total revenues | 52% |  | 53% |  |  |  |  |
| Gross profit | $ | 313,309 |  |  | $ | 270,147 |  |  | $ | 43,162 |  |  | 16% |
| Gross margin | 48% |  | 47% |  |  |  |  |

[0000926326-19-000033:mdna:71]
Cost of revenues for the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018 increased by $30.0 million, of which $20.4 million was attributed to the increase in cost of product revenues and $9.6 million was attributed to the increase in cost of services and other revenues. The increase in cost of product revenues is primarily driven by the increase in product revenues of $57.5 million for the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018, partially offset by sales of product portfolios with higher margins as well as lower costs associated with the XT series manufacturing ramp up and economies of scale. The increase in cost of services and other revenues is primarily driven by the increase in services and other revenues of $15.7 million for the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018, as well as product mix with lower margins.

[0000926326-19-000033:mdna:72]
34

[0000926326-19-000033:mdna:73]
The overall increase in gross margin primarily relates to lower costs associated with the XT series manufacturing ramp up and economies of scale. Our gross profit for the nine months ended September 30, 2019 was $313.3 million, as compared to $270.1 million for the nine months ended September 30, 2018.

[0000926326-19-000033:mdna:74]
[same as prior period, unchanged from 0000926326-19-000025:mdna:74]

[0000926326-19-000033:mdna:75]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 16,625 |  |  | $ | 15,805 |  |  | $ | 820 |  |  | 5% |
| As a percentage of total revenues | 7% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 70,876 |  |  | 65,609 |  |  | 5,267 |  |  | 8% |
| As a percentage of total revenues | 31% |  | 32% |  |  |  |  |
| Total operating expenses | $ | 87,501 |  |  | $ | 81,414 |  |  | $ | 6,087 |  |  | 7% |
| As a percentage of total revenues | 38% |  | 40% |  |  |  |  |
| Interest and other income (expense), net | $ | (1,168 | ) |  | $ | (2,837 | ) |  | $ | 1,669 |  |  | (59)% |

[0000926326-19-000033:mdna:76]
Research and Development. Research and development expenses increased by $0.8 million for the three months ended September 30, 2019 compared to the three months ended September 30, 2018. The increase was primarily attributed to increased spend on consulting expenses, as well as a higher headcount in the research and development function. This increase was partially offset by several research and development projects reaching capitalization stage during the three months ended September 30, 2019, decreasing research and development expenses, as we are allocating additional resources to software projects.

[0000926326-19-000033:mdna:77]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $5.3 million for the three months ended September 30, 2019 compared to the three months ended September 30, 2018, primarily due to growth of operations, substantially attributed to higher consulting and employee-related expenses, as well as higher commissions incurred in connection with increased revenues.

[0000926326-19-000033:mdna:78]
Interest and Other Income (Expense), Net. Interest and other income (expense), net decreased by $1.7 million for the three months ended September 30, 2019 compared to the three months ended September 30, 2018, primarily driven by a $0.7 million increase in other income and a $1.0 million decrease in other expenses. The increase in other income is primarily attributable to higher interest income received due to higher cash balances. The decrease in other expenses is primarily due to lower interest expense as a result of significant debt repayments during the year ended December 31, 2018 and nine months ended September 30, 2019, as well as favorable foreign currency fluctuations during the period.

[0000926326-19-000033:mdna:79]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 49,551 |  |  | $ | 47,854 |  |  | $ | 1,697 |  |  | 4% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 207,588 |  |  | 196,831 |  |  | 10,757 |  |  | 5% |
| As a percentage of total revenues | 32% |  | 34% |  |  |  |  |
| Total operating expenses | $ | 257,139 |  |  | $ | 244,685 |  |  | $ | 12,454 |  |  | 5% |
| As a percentage of total revenues | 40% |  | 43% |  |  |  |  |
| Interest and other income (expense), net | $ | (4,207 | ) |  | $ | (6,462 | ) |  | $ | 2,255 |  |  | (35)% |

[0000926326-19-000033:mdna:80]
Research and Development. Research and development expenses increased by $1.7 million for the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018. The increase was primarily attributed to increased spend on consulting expenses, as well as a higher headcount in the research and development function. This increase was partially offset by several research and development projects reaching capitalization stage during the nine months ended September 30, 2019, decreasing research and development expenses, as we are allocating additional resources to software projects.

[0000926326-19-000033:mdna:81]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $10.8 million for the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018, primarily due to growth of operations, substantially attributed to higher consulting and employee-related expenses, as well as higher commissions incurred in connection with increased revenues.

[0000926326-19-000033:mdna:82]
Interest and Other Income (Expense), Net. Interest and other income (expense), net decreased by $2.3 million for the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018, primarily driven by a $3.7 million decrease in other expenses and a $1.4 million decrease in other income. The decrease in other expenses is primarily due to lower interest expense as a result of significant debt repayments during the year ended December 31, 2018 and nine months ended September 30, 2019, as well as favorable foreign currency fluctuations during the period. The decrease in other income is primarily due to the $2.5 million contingent gain recognized during the nine months ended September 30, 2018 related to a settlement agreement associated with the Ateb acquisition, partially offset by higher interest income received due to higher cash balances.

[0000926326-19-000033:mdna:83]
[same as prior period, unchanged from 0000926326-19-000025:mdna:85]

[0000926326-19-000033:mdna:84]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 3,495 |  |  | $ | 1,030 |  |  | $ | 2,465 |  |  | 239% |

[0000926326-19-000033:mdna:85]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 12,720 |  |  | $ | (3,936 | ) |  | $ | 16,656 |  |  | (423)% |

[0000926326-19-000033:mdna:86]
Our annual effective tax rate before discrete items was 24.6% and 19.0% for the nine months ended September 30, 2019 and 2018, respectively. The increase in the estimated annual effective tax rate for the nine months ended September 30, 2019 compared to the same period in 2018 was primarily due to state income taxes, non-deductible equity charges, and research and development credits.

[0000926326-19-000033:mdna:87]
Provision for income taxes for the nine months ended September 30, 2019 included net discrete income tax benefit of $0.1 million. The net discrete income tax benefit was primarily related to a $8.1 million tax benefit from equity compensation, partially offset by income tax expense of $9.6 million recognized on the sale of certain intellectual property rights by Aesynt Holdings Coöperatief U.A. to Omnicell, Inc. in the first quarter of 2019.

[0000926326-19-000033:mdna:88]
Provision for income taxes for the nine months ended September 30, 2018 included net discrete income tax benefit of $7.6 million. The net discrete income tax benefit was primarily related to a recognized benefit of $4.2 million associated with making a check-the-box election to treat Aesynt Holdings Coöperatief U.A. as a U.S. disregarded entity beginning the first quarter of 2018 as well as a discrete income tax benefit of $4.8 million related to equity compensation.

[0000926326-19-000033:mdna:89]
[same as prior period, unchanged from 0000926326-19-000025:mdna:91]

[0000926326-19-000033:mdna:90]
[same as prior period, unchanged from 0000926326-19-000025:mdna:92]

[0000926326-19-000033:mdna:91]
We had cash and cash equivalents of $137.3 million at September 30, 2019 compared to $67.2 million at December 31, 2018. All of our cash and cash equivalents are invested in bank accounts with major financial institutions.

[0000926326-19-000033:mdna:92]
Our cash position and working capital at September 30, 2019 and December 31, 2018 were as follows:

[0000926326-19-000033:mdna:93]
|  | September 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Cash | $ | 137,277 |  |  | $ | 67,192 |  |
| Working capital | $ | 248,909 |  |  | $ | 192,554 |  |

[0000926326-19-000033:mdna:94]
Our ratio of current assets to current liabilities was 2.1:1 at September 30, 2019 and 1.9:1 at December 31, 2018.

[0000926326-19-000033:mdna:95]
[same as prior period, unchanged from 0000926326-19-000025:mdna:97]

[0000926326-19-000033:mdna:96]
[same as prior period, unchanged from 0000926326-19-000025:mdna:98]

[0000926326-19-000033:mdna:97]
On January 5, 2016, we entered into a $400.0 million secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200.0 million term loan facility (the “Term Loan Facility”), and prior to the amendment discussed below, a $200.0 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million.

[0000926326-19-000033:mdna:98]
On December 26, 2017 and April 11, 2017, we entered into amendments to the Credit Agreement. Under these amendments, the Revolving Credit Facility was increased from $200.0 million to $315.0 million and certain other modifications were made. Refer to Note 8, Debt and Credit Agreements, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes, including acquisitions.

[0000926326-19-000033:mdna:99]
As of September 30, 2019, the outstanding balance from the Facilities was $80.0 million and we were in compliance with all covenants.

[0000926326-19-000033:mdna:100]
[same as prior period, unchanged from 0000926326-19-000025:mdna:102]

[0000926326-19-000033:mdna:101]
On November 3, 2017, we entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC and HSBC Securities (USA) Inc., as our sales agents, pursuant to which we may offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of our common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange. We intend to use the net proceeds from the sale, if any, of common stock in the offering for general corporate purposes, which may include, without limitation, the acquisition of complementary businesses, the repayment of outstanding indebtedness, capital expenditures, and working capital.

[0000926326-19-000033:mdna:102]
For the three months ended September 30, 2019, we did not sell any of our common stock under the Distribution Agreement.

[0000926326-19-000033:mdna:103]
For the nine months ended September 30, 2019, we received gross proceeds of $38.5 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 460,000 shares of our common stock at an average price of approximately $83.81 per share.

[0000926326-19-000033:mdna:104]
For the three and nine months ended September 30, 2018, we did not sell any of our common stock under the Distribution Agreement.

[0000926326-19-000033:mdna:105]
As of September 30, 2019, we had an aggregate of $31.5 million available to be offered under the Distribution Agreement.

[0000926326-19-000033:mdna:106]
[same as prior period, unchanged from 0000926326-19-000025:mdna:109]

[0000926326-19-000033:mdna:107]
[same as prior period, unchanged from 0000926326-19-000025:mdna:110]

[0000926326-19-000033:mdna:108]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of September 30, 2019, which may result in additional use of cash. See “Stock Repurchase Program” under Note 13, Employee Benefits and

[0000926326-19-000033:mdna:109]
Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. There were no stock repurchases during the nine months ended September 30, 2019 and 2018.

[0000926326-19-000033:mdna:110]
[same as prior period, unchanged from 0000926326-19-000025:mdna:112]

[0000926326-19-000033:mdna:111]
[same as prior period, unchanged from 0000926326-19-000025:mdna:113]

[0000926326-19-000033:mdna:112]
[same as prior period, unchanged from 0000926326-19-000025:mdna:114]

[0000926326-19-000033:mdna:113]
|  | Nine months ended September 30, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 110,188 |  |  | $ | 56,514 |  |
| Investing activities | (46,761 | ) |  | (41,472 | ) |
| Financing activities | 7,045 |  |  | (2,919 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (387 | ) |  | (373 | ) |
| Net increase in cash and cash equivalents | $ | 70,085 |  |  | $ | 11,750 |  |

[0000926326-19-000033:mdna:114]
[same as prior period, unchanged from 0000926326-19-000025:mdna:116]

[0000926326-19-000033:mdna:115]
[same as prior period, unchanged from 0000926326-19-000025:mdna:117]

[0000926326-19-000033:mdna:116]
Net cash provided by operating activities was $110.2 million for the nine months ended September 30, 2019, primarily consisting of net income of $39.2 million adjusted for non-cash items of $78.8 million, offset by changes in assets and liabilities of $7.8 million. The non-cash items primarily consisted of depreciation and amortization expense of $39.5 million, share-based compensation expense of $25.2 million, amortization of operating lease right-of-use asset amortization of $7.9 million, debt financing fees of $1.7 million, and the change in deferred income taxes of $4.0 million. Changes in assets and liabilities include cash outflows from (i) a decrease in accrued compensation of $8.2 million primarily due to a decrease in accrued commissions and restructuring expenses, as well as timing of payroll, (ii) a decrease in operating lease liabilities of $7.9 million, (iii) an increase in accounts receivable and unbilled receivables of $7.7 million primarily due to an increase in billings, (iv) an increase in inventories of $7.0 million for inventory buildup in support of forecasted sales of new and existing products, (v) an increase in investment in sales-type leases of $5.1 million, and (vi) an increase in prepaid expenses of $1.3 million. These cash outflows were partially offset by (i) an increase in accounts payable of $10.3 million, (ii) an increase in accrued liabilities of $5.3 million, (iii) an increase in other long-term liabilities of $4.1 million, (iv) a decrease in other long-term assets of $3.9 million, (v) an increase in deferred revenues of $3.9 million, (vi) a decrease in other current assets of $1.0 million, and (vii) a decrease in prepaid commissions of $0.9 million.

[0000926326-19-000033:mdna:117]
Net cash provided by operating activities was $56.5 million for the nine months ended September 30, 2018, primarily consisting of net income of $22.9 million adjusted for non-cash items of $51.3 million, offset by changes in assets and liabilities of $17.7 million. The non-cash items primarily consisted of depreciation and amortization expense of $37.5 million, share-based compensation expense of $20.9 million, amortization of debt financing fees of $1.7 million, and the change in deferred income taxes of $8.8 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $16.2 million primarily due to an increase in billings, (ii) a decrease in accounts payable of $8.4 million, primarily due to the timing of payments, (iii) an increase in other long-term assets of $6.2 million as a result of the increase in unbilled receivables, (iv) an increase in inventories of $5.3 million due to inventory buildup in support of forecasted sales, (v) an increase in investment in sales-type leases of $1.7 million, and (vi) a decrease in other long-term liabilities of $1.0 million. These cash outflows were partially offset by (i) an increase in deferred revenues of $9.0 million due to timing of orders and revenues being recognized for installed product, (ii) an increase in accrued compensation of $5.7 million, (iii) a decrease in other current assets of $3.1 million, (iv) an increase in accrued liabilities of $1.5 million, (v) a decrease in prepaid commissions of $1.0 million, and (vi) a decrease in prepaid expenses of $0.8 million.

[0000926326-19-000033:mdna:118]
[same as prior period, unchanged from 0000926326-19-000025:mdna:121]

[0000926326-19-000033:mdna:119]
Net cash used in investing activities was $46.8 million for the nine months ended September 30, 2019, which consisted of capital expenditures of $12.6 million for property and equipment, and $34.1 million for costs of software development for external use.

[0000926326-19-000033:mdna:120]
Net cash used in investing activities was $41.5 million for the nine months ended September 30, 2018, which consisted of capital expenditures of $19.3 million for property and equipment and $22.2 million for costs of software development for external use.

[0000926326-19-000033:mdna:121]
[same as prior period, unchanged from 0000926326-19-000025:mdna:124]

[0000926326-19-000033:mdna:122]
Net cash provided by financing activities was $7.0 million for the nine months ended September 30, 2019, primarily due to proceeds of $37.8 million from sales of our common stock under the Distribution Agreement and $35.0 million in proceeds from employee stock option exercises and employee stock plan purchases, partially offset by the repayment of $60.0 million of the Facilities and $5.8 million in employees’ taxes paid related to restricted stock unit vesting.

[0000926326-19-000033:mdna:123]
Net cash used in financing activities was $2.9 million for the nine months ended September 30, 2018, primarily due to the repayment of $27.0 million of the Facilities and $3.6 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $27.7 million of proceeds from employee stock option exercises and employee stock plan purchases.

[0000926326-19-000033:mdna:124]
[same as prior period, unchanged from 0000926326-19-000025:mdna:127]

[0000926326-19-000033:mdna:125]
There have been no significant changes during the nine months ended September 30, 2019 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2018.

[0000926326-19-000033:mdna:126]
Contractual obligations as of September 30, 2019 were as follows:

[0000926326-19-000033:mdna:127]
|  | Payments due by period |
|  | Total |  | Remainder of 2019 |  | 2020 - 2021 |  | 2022 - 2023 |  | 2024 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 78,023 |  |  | $ | 3,655 |  |  | $ | 26,542 |  |  | $ | 20,241 |  |  | $ | 27,585 |  |
| Purchase obligations (2) | 75,289 |  |  | 57,104 |  |  | 17,633 |  |  | 331 |  |  | 221 |  |
| Term loan facility (3) | 80,000 |  |  | — |  |  | 80,000 |  |  | — |  |  | — |  |
| Total (4) (5) | $ | 233,312 |  |  | $ | 60,759 |  |  | $ | 124,175 |  |  | $ | 20,572 |  |  | $ | 27,806 |  |

[0000926326-19-000033:mdna:128]
[same as prior period, unchanged from 0000926326-19-000025:mdna:131]

[0000926326-19-000033:mdna:129]
| (1) | Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 10, Lessee Leases, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. |

[0000926326-19-000033:mdna:130]
[same as prior period, unchanged from 0000926326-19-000025:mdna:133]

[0000926326-19-000033:mdna:131]
[same as prior period, unchanged from 0000926326-19-000025:mdna:134]

[0000926326-19-000033:mdna:132]
| (4) | We have recorded $10.1 million for uncertain tax positions under long-term liabilities as of September 30, 2019 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $10.1 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-19-000033:mdna:133]
| (5) | Refer to Note 11, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. |

[0000926326-19-000033:mdna:134]
[same as prior period, unchanged from 0000926326-19-000025:mdna:137]

[0000926326-19-000033:mdna:135]
As of September 30, 2019, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
