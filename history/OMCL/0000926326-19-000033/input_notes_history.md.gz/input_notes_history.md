# OMCL note change history — 0000926326-19-000025 → 0000926326-19-000033


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-11-01):
[0000926326-19-000033:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2019, the Company had non-cancelable purchase commitments of $75.3 million, of which $57.1 million are expected to be paid within the year ending December 31, 2019.
  (was, 2019-08-02, similarity 0.9203):
[0000926326-19-000025:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2019, the Company had non-cancelable purchase commitments of $61.3 million, of which $53.9 million are expected to be paid within the year ended December 31, 2019.

- added (2019-11-01):
[0000926326-19-000033:note_history:2]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint seeks monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice. On August 21, 2019, a new lawsuit was filed against the Company and Aesynt, in the Circuit Court for the County of Albemarle, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Aesynt Incorporated, et al., Case No CL19-1301. The complaint seeks monetary recovery of damages based upon claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not been served with the complaint. The Company intends to defend the lawsuit vigorously.

- added (2019-11-01):
[0000926326-19-000033:note_history:3]
On June 6, 2018, a class action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint sought class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint was held in

- changed (2019-11-01):
[0000926326-19-000033:note_history:4]
abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The Illinois Supreme Court issued its decision in that case on January 25, 2019. On April 10, 2019, subsequent to the court’s issuance of an order granting the plaintiff leave to file an amended complaint, the plaintiff filed an amended complaint adding a second named plaintiff and an affiliate of the Company’s customer as an additional defendant and, in addition to making other modifications to the complaint, removing the separate cause of action directed to negligence. The court established a deadline of May 13, 2019 for the defendants to answer or otherwise respond to the amended complaint. On May 10, 2019, defendants Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, and Northwestern Memorial Hospital removed the case to the United States District Court for the Northern District of Illinois, Eastern Division. Subsequently, on May 17, 2019, the Company and the other defendants in the case each filed a motion to dismiss the complaint for failure to state a cause of action upon which relief could be granted. On June 14, 2019, plaintiffs filed a motion to remand the case to state court. The Court then entered an order, on June 19, 2019, denying plaintiffs’ motion to remand, granting defendants’ motions to dismiss with respect to the additionally-named plaintiff, and continuing the motions to dismiss with respect to the originally-named plaintiff. On July 2, 2019, the Court entered an order remanding the case to state court and denying the defendants’ motions to dismiss without prejudice to renewal of the motions in state court. On September 5, 2019, plaintiff filed a motion to voluntarily dismiss the Company from the case without prejudice. The motion was granted by order of the Court dated October 10, 2019 and, as a result, the Company has been finally dismissed from the case without prejudice to plaintiff refiling the action.
  (was, 2019-08-02, similarity 0.644):
[0000926326-19-000025:note_history:4]
On June 6, 2018, a class action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint sought class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint was held in abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The Illinois Supreme Court issued its decision in that case on January 25, 2019. On April 10, 2019, subsequent to the court’s issuance of an order granting the plaintiff leave to file an amended complaint, the plaintiff filed an amended complaint adding a second named plaintiff and an affiliate of the Company’s customer as an additional defendant and, in addition to making other modifications to the complaint, removing the separate cause of action directed to negligence. The court established a deadline of May 13, 2019 for the defendants to answer or otherwise respond to the amended complaint. On May 10, 2019, defendants Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, and Northwestern Memorial Hospital removed the case to the United States District Court for the Northern District of Illinois, Eastern Division. Subsequently, on May 17, 2019, the Company and the other defendants in the case each filed a motion to dismiss the complaint for failure to state a cause of action upon which relief could be granted. On June 14, 2019, plaintiffs filed a motion to remand the case to state court. The Court then entered an order, on June 19, 2019, denying plaintiffs’ motion to remand, granting defendants’ motions to dismiss with respect to the additionally-named plaintiff, and continuing the motions to dismiss with respect to the originally-named plaintiff. On July 2, 2019, the Court entered an order remanding the case to state court and denying the defendants’ motions to dismiss without prejudice to renewal of the motions in state court. The Company intends to defend the lawsuit vigorously.

- changed (2019-11-01):
[0000926326-19-000033:note_history:5]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, the Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (“Mazya Action”), disclosed above, together with claims for reimbursement and unjust enrichment relating to the defense of the Mazya Action in the form of attorneys’ fees and other related costs. The Company has not responded to the complaint. On February 12, 2019, the court stayed the action pending the outcome of the Mazya Action and administratively closed the case. On October 15, 2019, the plaintiffs filed a notice advising the Court of the dismissal of the Company from the Mazya Action and requesting that the Court lift the stay in the case and set dates for filing a responsive pleading by the Company and initial discovery and scheduling matters. The Company intends to defend the lawsuit vigorously.
  (was, 2019-08-02, similarity 0.8174):
[0000926326-19-000025:note_history:5]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, the Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (“Underlying Action”), disclosed above, together with claims for reimbursement and unjust enrichment relating to the defense of the Underlying Action in the form of attorneys’ fees and other related costs. The Company has not responded to the complaint. On February 12, 2019, the court stayed the action pending the outcome of the Underlying Action and administratively closed the case. The Company intends to defend the lawsuit vigorously.

- changed (2019-11-01):
[0000926326-19-000033:note_history:6]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of BIPA, and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the Mazya Action. The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The Court has scheduled a case status conference for November 7, 2019 at which time the Company intends to present its motion to dismiss to the Court. The Company intends to defend the lawsuit vigorously.
  (was, 2019-08-02, similarity 0.6411):
[0000926326-19-000025:note_history:6]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of BIPA, and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. The Company must file a response to the complaint by August 14, 2019. The Court has scheduled a case management conference for October 3, 2019. The Company intends to defend the lawsuit vigorously.

- changed (2019-11-01):
[0000926326-19-000033:note_history:7]
On July 18, 2019, a putative class action lawsuit was filed against the Company and certain of its officers in the U.S. District Court for the Northern District of California. The complaint, captioned Bursick v. Omnicell, Inc. et al., Case No. 3:19-cv-04150, alleges that the defendants violated federal securities laws by making materially false and misleading statements beginning in October 2018 regarding revenue recognition, customer concerns about implementation issues, and a purported need to write off inventory. The plaintiff seeks unspecified monetary damages and other relief. On October 24, 2019, Frank Bursick was appointed Lead Plaintiff. The Court ordered Lead Plaintiff to file an amended complaint by November 28, 2019 and the Company to respond to the amended complaint by January 2, 2020. The Company intends to defend the lawsuit vigorously.
  (was, 2019-08-02, similarity 0.7901):
[0000926326-19-000025:note_history:7]
On July 18, 2019, a putative class action lawsuit was filed against the Company and certain of its officers in the U.S. District Court for the Northern District of California. The complaint, captioned Bursick v. Omnicell, Inc. et al., Case No. 3:19-cv-04150, alleges that the defendants violated federal securities laws by making materially false and misleading statements beginning in October 2018 regarding revenue recognition, customer concerns about implementation issues, and a purported need to write off inventory. The plaintiff seeks unspecified monetary damages and other relief. The Company intends to defend the lawsuit vigorously.

- added (2019-11-01):
[0000926326-19-000033:note_history:8]
In August 2019, the Company received a letter from the Denver office of the SEC seeking information related to the Company’s accounting processes and procedures. The Company responded and is fully cooperating with the SEC.

- removed (2019-11-01):
[0000926326-19-000025:note_history:9]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint seeks monetary recovery of compensatory and punitive damages in addition to

- removed (2019-11-01):
[0000926326-19-000025:note_history:10]
certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-11-01):
[0000926326-19-000033:note_history:11]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2019 and December 31, 2018, the results of operations and comprehensive income for the three and nine months ended September 30, 2019 and 2018, and cash flows for the nine months ended September 30, 2019 and 2018. Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States Generally Accepted Accounting Principles (“U.S. GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2018 filed with the SEC on February 27, 2019, except as discussed in the sections entitled “Lessor Leases”, “Lessee Leases”, and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2019 and cash flows for the nine months ended September 30, 2019 are not necessarily indicative of results that may be expected for the year ending December 31, 2019, or for any future period.
  (was, 2019-08-02, similarity 0.8407):
[0000926326-19-000025:note_history:11]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2019 and December 31, 2018, the results of operations and comprehensive income for the three and six months ended June 30, 2019 and 2018, and cash flows for the six months ended June 30, 2019 and 2018. Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States Generally Accepted Accounting Principles (“U.S. GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2018 filed with the SEC on February 27, 2019, except as discussed in the sections entitled “Lessor Leases”, “Lessee Leases”, and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and six months ended June 30, 2019 and cash flows for the six months ended June 30, 2019 are not necessarily indicative of results that may be expected for the year ending December 31, 2019, or for any future period.

- changed (2019-11-01):
[0000926326-19-000033:note_history:12]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance also requires significant additional disclosures about the amount and timing of cash flows from leases. The Company adopted this new guidance on January 1, 2019. In July 2018, the FASB issued amendments in ASU 2018-11, which provide a transition election to not restate comparative periods for the effects of applying the new standard. This transition election permits entities to change the date of initial application to the beginning of the year of adoption and to recognize the effects of applying the new standard as a cumulative-effect adjustment to the opening balance of retained earnings. The Company has elected this transition approach as well as elected the package of practical expedients permitted under the transition guidance within the new standard, which will allow the Company to carry forward the historical lease classification of contracts entered into prior to January 1, 2019. As a result of electing the package of practical expedients described above, existing leases and related initial direct costs have not been reassessed prior to the effective date, and therefore, adoption of the lease standard did not have an impact on the Company’s previously reported consolidated financial statements.
  (was, 2019-08-02, similarity 0.9966):
[0000926326-19-000025:note_history:12]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance also requires significant additional disclosures about the amount and timing of cash flows from leases. The Company adopted this new guidance on January 1, 2019. In July 2018, the FASB issued amendments in ASU 2018-11, which provide a transition election to not restate comparative periods for the effects of applying the new standard. This transition election permits entities to change the date of initial application to the beginning of the year of adoption and to recognize the effects of applying the new standard as a cumulative-effect adjustment to the opening balance of retained earnings. The Company has elected this transition approach as well as elected the package of practical expedients permitted under the transition guidance within the new standard, which will allow the Company to carry forward the historical lease classification of contracts entered into prior to January 1, 2019. As a result of electing the package of practical expedients described above, existing leases and related initial direct costs have not been reassessed prior to the effective date, and therefore, adoption of the lease standard did not have an impact on the Company’s previously reported consolidated statements.

- changed (2019-11-01):
[0000926326-19-000033:note_history:13]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly
  (was, 2019-08-02, similarity 0.8553):
[0000926326-19-000025:note_history:13]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects.” ASU 2018-02 is effective for the Company beginning January 1, 2019. The adoption of

- changed (2019-11-01):
[0000926326-19-000033:note_history:14]
referred to as “stranded tax effects.” ASU 2018-02 is effective for the Company beginning January 1, 2019. The adoption of this guidance did not have a material effect on the Company’s consolidated financial statements and therefore no adjustment to retained earnings was made.
  (was, 2019-08-02, similarity 0.7299):
[0000926326-19-000025:note_history:14]
this guidance did not have a material effect on the Company’s consolidated financial statements and therefore no adjustment to retained earnings was made.

- changed (2019-11-01):
[0000926326-19-000033:note_history:15]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). ASU 2018-15 will be effective for the Company beginning January 1, 2020. The Company anticipates adopting ASU 2018-15 prospectively and does not expect the standard to have a material impact on its consolidated financial statements.
  (was, 2019-08-02, similarity 0.9031):
[0000926326-19-000025:note_history:15]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). ASU 2018-15 will be effective for the Company beginning January 1, 2020. The Company is currently evaluating the impact ASU 2018-15 will have on its consolidated financial statements.

- changed (2019-11-01):
[0000926326-19-000033:note_history:16]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments-Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans, and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans and held-to-maturity debt securities, the standard will replace the current “incurred loss” approach with an “expected loss” model. Entities will be required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. ASU 2016-13 will be effective for the Company beginning January 1, 2020. The Company is in the process of evaluating the appropriate changes to necessary processes and controls to support the adoption of the new standard. The Company is currently evaluating the impact ASU 2016-13 will have on its consolidated financial statements.
  (was, 2019-08-02, similarity 0.9274):
[0000926326-19-000025:note_history:16]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments-Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans, and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans and held-to-maturity debt securities, the standard will replace the current “incurred loss” approach with an “expected loss” model. Entities will be required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. ASU 2016-13 will be effective for the Company beginning January 1, 2020. The Company is currently evaluating the impact ASU 2016-13 will have on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-11-01):
[0000926326-19-000033:note_history:17]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $0.8 million and $1.9 million for the three months ended September 30, 2019 and 2018, respectively, and approximately $3.0 million and $5.7 million for the nine months ended September 30, 2019 and 2018, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million for both the three months ended September 30, 2019 and 2018, and approximately $1.7 million for both the nine months ended September 30, 2019 and 2018. The Company was in compliance with all covenants as of September 30, 2019 and December 31, 2018.

- changed (2019-11-01):
[0000926326-19-000033:note_history:18]
During the nine months ended September 30, 2019, the Company repaid $60.0 million under these Facilities.
  (was, 2019-08-02, similarity 0.914):
[0000926326-19-000025:note_history:18]
During the six months ended June 30, 2019, the Company repaid $60.0 million under these Facilities.

- changed (2019-11-01):
[0000926326-19-000033:note_history:19]
The components of the Company’s debt obligations as of September 30, 2019 and December 31, 2018 were as follows:
  (was, 2019-08-02, similarity 0.9447):
[0000926326-19-000025:note_history:19]
The components of the Company’s debt obligations as of June 30, 2019 and December 31, 2018 were as follows:

- changed (2019-11-01):
[0000926326-19-000033:note_history:20]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (60,000 | ) |  | $ | 80,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (60,000 | ) |  | 80,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 1,718 |  |  | (2,865 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (58,282 | ) |  | $ | 77,135 |  |
  (was, 2019-08-02, similarity 0.9863):
[0000926326-19-000025:note_history:20]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | June 30, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (60,000 | ) |  | $ | 80,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (60,000 | ) |  | 80,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 1,145 |  |  | (3,438 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (58,855 | ) |  | $ | 76,562 |  |

- changed (2019-11-01):
[0000926326-19-000033:note_history:21]
As of September 30, 2019, the carrying amount of debt of $80.0 million approximates the comparable fair value of $79.9 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as
  (was, 2019-08-02, similarity 0.7807):
[0000926326-19-000025:note_history:21]
As of June 30, 2019, the carrying amount of debt of $80.0 million approximates the comparable fair value of $80.2 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of June 30, 2019 as compared to December 31, 2018.

- added (2019-11-01):
[0000926326-19-000033:note_history:22]
interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of September 30, 2019 as compared to December 31, 2018.

- removed (2019-11-01):
[0000926326-19-000025:note_history:23]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $0.9 million and $1.9 million for the three months ended June 30, 2019 and 2018, respectively, and approximately $2.2 million and $3.8 million for the six months ended June 30, 2019 and 2018, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million and $0.6 million for the three months ended June 30, 2019 and 2018, respectively, and approximately $1.1 million and $1.1 million for the six months ended June 30, 2019 and 2018, respectively. The Company was in compliance with all covenants as of June 30, 2019 and December 31, 2018.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-01):
[0000926326-19-000033:note_history:24]
The components of the Company’s debt obligations as of September 30, 2019 and December 31, 2018 were as follows:
  (was, 2019-08-02, similarity 0.9447):
[0000926326-19-000025:note_history:24]
The components of the Company’s debt obligations as of June 30, 2019 and December 31, 2018 were as follows:

- changed (2019-11-01):
[0000926326-19-000033:note_history:25]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (60,000 | ) |  | $ | 80,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (60,000 | ) |  | 80,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 1,718 |  |  | (2,865 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (58,282 | ) |  | $ | 77,135 |  |
  (was, 2019-08-02, similarity 0.9863):
[0000926326-19-000025:note_history:25]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | June 30, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (60,000 | ) |  | $ | 80,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (60,000 | ) |  | 80,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 1,145 |  |  | (3,438 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (58,855 | ) |  | $ | 76,562 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-11-01):
[0000926326-19-000033:note_history:26]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.8 million and $2.2 million for the three months ended September 30, 2019 and 2018, respectively, and $7.6 million and $6.2 million for the nine months ended September 30, 2019 and 2018, respectively.
  (was, 2019-08-02, similarity 0.9434):
[0000926326-19-000025:note_history:26]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.6 million and $2.1 million for the three months ended June 30, 2019 and 2018, respectively, and $4.8 million and $4.0 million for the six months ended June 30, 2019 and 2018, respectively.

- changed (2019-11-01):
[0000926326-19-000033:note_history:27]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and nine months ended September 30, 2019 and 2018:
  (was, 2019-08-02, similarity 0.9448):
[0000926326-19-000025:note_history:27]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and six months ended June 30, 2019 and 2018:

- changed (2019-11-01):
[0000926326-19-000033:note_history:28]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Hardware and software | $ | 144,305 |  |  | $ | 125,733 |  |  | $ | 399,548 |  |  | $ | 345,215 |  |
| Consumables | 19,875 |  |  | 19,848 |  |  | 60,378 |  |  | 58,956 |  |
| Other | 4,308 |  |  | 4,128 |  |  | 12,551 |  |  | 10,833 |  |
| Total product revenues | $ | 168,488 |  |  | $ | 149,709 |  |  | $ | 472,477 |  |  | $ | 415,004 |  |
  (was, 2019-08-02, similarity 0.8934):
[0000926326-19-000025:note_history:28]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Hardware and software | $ | 135,022 |  |  | $ | 112,031 |  |  | $ | 255,243 |  |  | $ | 219,482 |  |
| Consumables | 19,416 |  |  | 19,670 |  |  | 40,503 |  |  | 39,108 |  |
| Other | 3,941 |  |  | 2,935 |  |  | 8,243 |  |  | 6,705 |  |
| Total product revenues | $ | 158,379 |  |  | $ | 134,636 |  |  | $ | 303,989 |  |  | $ | 265,295 |  |

- changed (2019-11-01):
[0000926326-19-000033:note_history:29]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2019 and 2018:
  (was, 2019-08-02, similarity 0.9581):
[0000926326-19-000025:note_history:29]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2019 and 2018:

- changed (2019-11-01):
[0000926326-19-000033:note_history:30]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| United States | $ | 206,709 |  |  | $ | 180,635 |  |  | $ | 582,540 |  |  | $ | 502,481 |  |
| Rest of world (1) | 22,096 |  |  | 23,632 |  |  | 66,195 |  |  | 73,078 |  |
| Total revenues | $ | 228,805 |  |  | $ | 204,267 |  |  | $ | 648,735 |  |  | $ | 575,559 |  |
  (was, 2019-08-02, similarity 0.8752):
[0000926326-19-000025:note_history:30]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| United States | $ | 195,811 |  |  | $ | 163,645 |  |  | $ | 375,831 |  |  | $ | 321,847 |  |
| Rest of world (1) | 21,602 |  |  | 25,028 |  |  | 44,099 |  |  | 49,445 |  |
| Total revenues | $ | 217,413 |  |  | $ | 188,673 |  |  | $ | 419,930 |  |  | $ | 371,292 |  |

- changed (2019-11-01):
[0000926326-19-000033:note_history:31]
|  | September 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 15,524 |  |  | $ | 9,191 |  |
| Long-term unbilled receivables - included in other long-term assets | 12,794 |  |  | 16,481 |  |
| Total contract assets | $ | 28,318 |  |  | $ | 25,672 |  |
| Short-term deferred revenues, net | $ | 88,205 |  |  | $ | 81,835 |  |
| Long-term deferred revenues | 7,979 |  |  | 10,582 |  |
| Total contract liabilities | $ | 96,184 |  |  | $ | 92,417 |  |
  (was, 2019-08-02, similarity 0.986):
[0000926326-19-000025:note_history:31]
|  | June 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 10,667 |  |  | $ | 9,191 |  |
| Long-term unbilled receivables - included in other long-term assets | 13,630 |  |  | 16,481 |  |
| Total contract assets | $ | 24,297 |  |  | $ | 25,672 |  |
| Short-term deferred revenues, net | $ | 83,012 |  |  | $ | 81,835 |  |
| Long-term deferred revenues | 9,658 |  |  | 10,582 |  |
| Total contract liabilities | $ | 92,670 |  |  | $ | 92,417 |  |

- changed (2019-11-01):
[0000926326-19-000033:note_history:32]
Short-term deferred revenues of $88.2 million and $81.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales, of $14.3 million and $11.1 million as of September 30, 2019 and December 31, 2018, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and nine months ended September 30, 2019, the Company recognized revenues of $4.8 million and $69.8 million that were included in the corresponding gross short-term deferred revenues balance of $92.9 million as of December 31, 2018.
  (was, 2019-08-02, similarity 0.6984):
[0000926326-19-000025:note_history:32]
Short-term deferred revenues of $83.0 million and $81.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales, of $12.0 million and $11.1 million as of June 30, 2019 and December 31, 2018, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and six months ended June 30, 2019, the Company recognized revenues of $25.7 million and $65.0 million that were included in the corresponding gross short-term deferred revenues balance of $92.9 million as of December 31, 2018.

- added (2019-11-01):
[0000926326-19-000033:note_history:33]
Long-term deferred revenues include deferred revenues from service contracts of $8.0 million and $10.6 million as of September 30, 2019 and December 31, 2018, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

- changed (2019-11-01):
[0000926326-19-000033:note_history:34]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2019 and 2018. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable as of September 30, 2019 and December 31, 2018.
  (was, 2019-08-02, similarity 0.8483):
[0000926326-19-000025:note_history:34]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2019 and 2018. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable as of June 30, 2019 and December 31, 2018.

- removed (2019-11-01):
[0000926326-19-000025:note_history:35]
Long-term deferred revenues include deferred revenues from service contracts of $9.7 million and $10.6 million as of June 30, 2019 and December 31, 2018, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.


## us-gaap:RevenueRecognitionMultipleDeliverableArrangementsTableTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2019-11-01):
[0000926326-19-000025:note_history:36]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and six months ended June 30, 2019 and 2018:

- removed (2019-11-01):
[0000926326-19-000025:note_history:37]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Hardware and software | $ | 135,022 |  |  | $ | 112,031 |  |  | $ | 255,243 |  |  | $ | 219,482 |  |
| Consumables | 19,416 |  |  | 19,670 |  |  | 40,503 |  |  | 39,108 |  |
| Other | 3,941 |  |  | 2,935 |  |  | 8,243 |  |  | 6,705 |  |
| Total product revenues | $ | 158,379 |  |  | $ | 134,636 |  |  | $ | 303,989 |  |  | $ | 265,295 |  |
