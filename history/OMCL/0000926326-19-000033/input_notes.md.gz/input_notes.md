# OMCL notes — 0000926326-19-000033


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-19-000033:notes:1]
[same as prior period, unchanged from 0000926326-19-000025:notes:1]

[0000926326-19-000033:notes:2]
[same as prior period, unchanged from 0000926326-19-000025:notes:2]

[0000926326-19-000033:notes:3]
[same as prior period, unchanged from 0000926326-19-000025:notes:3]

[0000926326-19-000033:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2019 and December 31, 2018, the results of operations and comprehensive income for the three and nine months ended September 30, 2019 and 2018, and cash flows for the nine months ended September 30, 2019 and 2018. Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States Generally Accepted Accounting Principles (“U.S. GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2018 filed with the SEC on February 27, 2019, except as discussed in the sections entitled “Lessor Leases”, “Lessee Leases”, and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2019 and cash flows for the nine months ended September 30, 2019 are not necessarily indicative of results that may be expected for the year ending December 31, 2019, or for any future period.

[0000926326-19-000033:notes:5]
[same as prior period, unchanged from 0000926326-19-000025:notes:5]

[0000926326-19-000033:notes:6]
[same as prior period, unchanged from 0000926326-19-000025:notes:6]

[0000926326-19-000033:notes:7]
[same as prior period, unchanged from 0000926326-19-000025:notes:7]

[0000926326-19-000033:notes:8]
[same as prior period, unchanged from 0000926326-19-000025:notes:8]

[0000926326-19-000033:notes:9]
[same as prior period, unchanged from 0000926326-19-000025:notes:9]

[0000926326-19-000033:notes:10]
[same as prior period, unchanged from 0000926326-19-000025:notes:10]

[0000926326-19-000033:notes:11]
[same as prior period, unchanged from 0000926326-19-000025:notes:11]

[0000926326-19-000033:notes:12]
[same as prior period, unchanged from 0000926326-19-000025:notes:12]

[0000926326-19-000033:notes:13]
[same as prior period, unchanged from 0000926326-19-000025:notes:13]

[0000926326-19-000033:notes:14]
[same as prior period, unchanged from 0000926326-19-000025:notes:14]

[0000926326-19-000033:notes:15]
[same as prior period, unchanged from 0000926326-19-000025:notes:15]

[0000926326-19-000033:notes:16]
[same as prior period, unchanged from 0000926326-19-000025:notes:16]

[0000926326-19-000033:notes:17]
The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 54% of the lease receivable balance, are retained in-house.

[0000926326-19-000033:notes:18]
[same as prior period, unchanged from 0000926326-19-000025:notes:18]

[0000926326-19-000033:notes:19]
[same as prior period, unchanged from 0000926326-19-000025:notes:19]

[0000926326-19-000033:notes:20]
[same as prior period, unchanged from 0000926326-19-000025:notes:20]

[0000926326-19-000033:notes:21]
[same as prior period, unchanged from 0000926326-19-000025:notes:21]

[0000926326-19-000033:notes:22]
[same as prior period, unchanged from 0000926326-19-000025:notes:22]

[0000926326-19-000033:notes:23]
[same as prior period, unchanged from 0000926326-19-000025:notes:23]

[0000926326-19-000033:notes:24]
[same as prior period, unchanged from 0000926326-19-000025:notes:24]

[0000926326-19-000033:notes:25]
[same as prior period, unchanged from 0000926326-19-000025:notes:25]

[0000926326-19-000033:notes:26]
The Company’s operating lease agreements do not contain any material residual value guarantees, restrictions, or restriction covenants.

[0000926326-19-000033:notes:27]
[same as prior period, unchanged from 0000926326-19-000025:notes:27]

[0000926326-19-000033:notes:28]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance also requires significant additional disclosures about the amount and timing of cash flows from leases. The Company adopted this new guidance on January 1, 2019. In July 2018, the FASB issued amendments in ASU 2018-11, which provide a transition election to not restate comparative periods for the effects of applying the new standard. This transition election permits entities to change the date of initial application to the beginning of the year of adoption and to recognize the effects of applying the new standard as a cumulative-effect adjustment to the opening balance of retained earnings. The Company has elected this transition approach as well as elected the package of practical expedients permitted under the transition guidance within the new standard, which will allow the Company to carry forward the historical lease classification of contracts entered into prior to January 1, 2019. As a result of electing the package of practical expedients described above, existing leases and related initial direct costs have not been reassessed prior to the effective date, and therefore, adoption of the lease standard did not have an impact on the Company’s previously reported consolidated financial statements.

[0000926326-19-000033:notes:29]
[same as prior period, unchanged from 0000926326-19-000025:notes:29]

[0000926326-19-000033:notes:30]
[same as prior period, unchanged from 0000926326-19-000025:notes:30]

[0000926326-19-000033:notes:31]
[same as prior period, unchanged from 0000926326-19-000025:notes:31]

[0000926326-19-000033:notes:32]
[same as prior period, unchanged from 0000926326-19-000025:notes:32]

[0000926326-19-000033:notes:33]
[same as prior period, unchanged from 0000926326-19-000025:notes:33]

[0000926326-19-000033:notes:34]
[same as prior period, unchanged from 0000926326-19-000025:notes:34]

[0000926326-19-000033:notes:35]
[same as prior period, unchanged from 0000926326-19-000025:notes:35]

[0000926326-19-000033:notes:36]
[same as prior period, unchanged from 0000926326-19-000025:notes:36]

[0000926326-19-000033:notes:37]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly

[0000926326-19-000033:notes:38]
referred to as “stranded tax effects.” ASU 2018-02 is effective for the Company beginning January 1, 2019. The adoption of this guidance did not have a material effect on the Company’s consolidated financial statements and therefore no adjustment to retained earnings was made.

[0000926326-19-000033:notes:39]
[same as prior period, unchanged from 0000926326-19-000025:notes:39]

[0000926326-19-000033:notes:40]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). ASU 2018-15 will be effective for the Company beginning January 1, 2020. The Company anticipates adopting ASU 2018-15 prospectively and does not expect the standard to have a material impact on its consolidated financial statements.

[0000926326-19-000033:notes:41]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments-Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans, and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans and held-to-maturity debt securities, the standard will replace the current “incurred loss” approach with an “expected loss” model. Entities will be required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. ASU 2016-13 will be effective for the Company beginning January 1, 2020. The Company is in the process of evaluating the appropriate changes to necessary processes and controls to support the adoption of the new standard. The Company is currently evaluating the impact ASU 2016-13 will have on its consolidated financial statements.

[0000926326-19-000033:notes:42]
[same as prior period, unchanged from 0000926326-19-000025:notes:42]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-19-000033:notes:43]
[same as prior period, unchanged from 0000926326-19-000025:notes:43]

[0000926326-19-000033:notes:44]
[same as prior period, unchanged from 0000926326-19-000025:notes:44]

[0000926326-19-000033:notes:45]
[same as prior period, unchanged from 0000926326-19-000025:notes:45]

[0000926326-19-000033:notes:46]
[same as prior period, unchanged from 0000926326-19-000025:notes:46]

[0000926326-19-000033:notes:47]
[same as prior period, unchanged from 0000926326-19-000025:notes:47]

[0000926326-19-000033:notes:48]
[same as prior period, unchanged from 0000926326-19-000025:notes:48]

[0000926326-19-000033:notes:49]
[same as prior period, unchanged from 0000926326-19-000025:notes:49]

[0000926326-19-000033:notes:50]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.8 million and $2.2 million for the three months ended September 30, 2019 and 2018, respectively, and $7.6 million and $6.2 million for the nine months ended September 30, 2019 and 2018, respectively.

[0000926326-19-000033:notes:51]
[same as prior period, unchanged from 0000926326-19-000025:notes:51]

[0000926326-19-000033:notes:52]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and nine months ended September 30, 2019 and 2018:

[0000926326-19-000033:notes:53]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Hardware and software | $ | 144,305 |  |  | $ | 125,733 |  |  | $ | 399,548 |  |  | $ | 345,215 |  |
| Consumables | 19,875 |  |  | 19,848 |  |  | 60,378 |  |  | 58,956 |  |
| Other | 4,308 |  |  | 4,128 |  |  | 12,551 |  |  | 10,833 |  |
| Total product revenues | $ | 168,488 |  |  | $ | 149,709 |  |  | $ | 472,477 |  |  | $ | 415,004 |  |

[0000926326-19-000033:notes:54]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2019 and 2018:

[0000926326-19-000033:notes:55]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| United States | $ | 206,709 |  |  | $ | 180,635 |  |  | $ | 582,540 |  |  | $ | 502,481 |  |
| Rest of world (1) | 22,096 |  |  | 23,632 |  |  | 66,195 |  |  | 73,078 |  |
| Total revenues | $ | 228,805 |  |  | $ | 204,267 |  |  | $ | 648,735 |  |  | $ | 575,559 |  |

[0000926326-19-000033:notes:56]
[same as prior period, unchanged from 0000926326-19-000025:notes:56]

[0000926326-19-000033:notes:57]
[same as prior period, unchanged from 0000926326-19-000025:notes:57]

[0000926326-19-000033:notes:58]
[same as prior period, unchanged from 0000926326-19-000025:notes:58]

[0000926326-19-000033:notes:59]
|  | September 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 15,524 |  |  | $ | 9,191 |  |
| Long-term unbilled receivables - included in other long-term assets | 12,794 |  |  | 16,481 |  |
| Total contract assets | $ | 28,318 |  |  | $ | 25,672 |  |
| Short-term deferred revenues, net | $ | 88,205 |  |  | $ | 81,835 |  |
| Long-term deferred revenues | 7,979 |  |  | 10,582 |  |
| Total contract liabilities | $ | 96,184 |  |  | $ | 92,417 |  |

[0000926326-19-000033:notes:60]
[same as prior period, unchanged from 0000926326-19-000025:notes:60]

[0000926326-19-000033:notes:61]
Short-term deferred revenues of $88.2 million and $81.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales, of $14.3 million and $11.1 million as of September 30, 2019 and December 31, 2018, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and nine months ended September 30, 2019, the Company recognized revenues of $4.8 million and $69.8 million that were included in the corresponding gross short-term deferred revenues balance of $92.9 million as of December 31, 2018.

[0000926326-19-000033:notes:62]
Long-term deferred revenues include deferred revenues from service contracts of $8.0 million and $10.6 million as of September 30, 2019 and December 31, 2018, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-19-000033:notes:63]
[same as prior period, unchanged from 0000926326-19-000025:notes:63]

[0000926326-19-000033:notes:64]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2019 and 2018. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable as of September 30, 2019 and December 31, 2018.


## us-gaap:EarningsPerShareTextBlock

[0000926326-19-000033:notes:65]
[same as prior period, unchanged from 0000926326-19-000025:notes:65]

[0000926326-19-000033:notes:66]
The basic and diluted net income per share calculations for the three and nine months ended September 30, 2019 and 2018 were as follows:

[0000926326-19-000033:notes:67]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands, except per share data) |
| Net income | $ | 19,983 |  |  | $ | 13,628 |  |  | $ | 39,243 |  |  | $ | 22,936 |  |
| Weighted-average shares outstanding — basic | 41,771 |  |  | 39,432 |  |  | 41,283 |  |  | 39,015 |  |
| Effect of dilutive securities from stock award plans | 1,281 |  |  | 1,428 |  |  | 1,513 |  |  | 1,222 |  |
| Weighted-average shares outstanding — diluted | 43,052 |  |  | 40,860 |  |  | 42,796 |  |  | 40,237 |  |
| Net income per share - basic | $ | 0.48 |  |  | $ | 0.35 |  |  | $ | 0.95 |  |  | $ | 0.59 |  |
| Net income per share - diluted | $ | 0.46 |  |  | $ | 0.33 |  |  | $ | 0.92 |  |  | $ | 0.57 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 1,060 |  |  | 673 |  |  | 832 |  |  | 1,176 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-19-000033:notes:68]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $137.3 million and $67.2 million as of September 30, 2019 and December 31, 2018, respectively, consisted of bank accounts with major financial institutions.

[0000926326-19-000033:notes:69]
[same as prior period, unchanged from 0000926326-19-000025:notes:69]

[0000926326-19-000033:notes:70]
[same as prior period, unchanged from 0000926326-19-000025:notes:70]

[0000926326-19-000033:notes:71]
[same as prior period, unchanged from 0000926326-19-000025:notes:71]

[0000926326-19-000033:notes:72]
[same as prior period, unchanged from 0000926326-19-000025:notes:72]

[0000926326-19-000033:notes:73]
[same as prior period, unchanged from 0000926326-19-000025:notes:73]

[0000926326-19-000033:notes:74]
[same as prior period, unchanged from 0000926326-19-000025:notes:74]

[0000926326-19-000033:notes:75]
[same as prior period, unchanged from 0000926326-19-000025:notes:75]

[0000926326-19-000033:notes:76]
[same as prior period, unchanged from 0000926326-19-000025:notes:76]

[0000926326-19-000033:notes:77]
[same as prior period, unchanged from 0000926326-19-000025:notes:77]

[0000926326-19-000033:notes:78]
[same as prior period, unchanged from 0000926326-19-000025:notes:78]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-19-000033:notes:79]
Balance Sheet Components
Balance sheet details as of September 30, 2019 and December 31, 2018 are presented in the tables below:

[0000926326-19-000033:notes:80]
|  | September 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 31,780 |  |  | $ | 32,511 |  |
| Work in process | 8,720 |  |  | 8,726 |  |
| Finished goods | 65,313 |  |  | 59,631 |  |
| Total inventories | $ | 105,813 |  |  | $ | 100,868 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net | $ | 78,409 |  |  | $ | 56,819 |  |
| Unbilled receivables | 12,794 |  |  | 16,481 |  |
| Other assets | 1,056 |  |  | 1,313 |  |
| Total other long-term assets, net | $ | 92,259 |  |  | $ | 74,613 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 10,281 |  |  | $ | — |  |
| Advance payments from customers | 4,865 |  |  | 8,993 |  |
| Rebates and lease buyouts | 17,551 |  |  | 11,076 |  |
| Group purchasing organization fees | 5,423 |  |  | 4,455 |  |
| Taxes payable | 3,556 |  |  | 5,885 |  |
| Other accrued liabilities | 16,341 |  |  | 12,638 |  |
| Total accrued liabilities | $ | 58,017 |  |  | $ | 43,047 |  |

[0000926326-19-000033:notes:81]
The following tables summarize the changes in accumulated balances of other comprehensive income (loss) for the three and nine months ended September 30, 2019 and 2018:

[0000926326-19-000033:notes:82]
|  | Three months ended September 30, |
|  | 2019 |  | 2018 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (11,576 | ) |  | $ | — |  |  | $ | (11,576 | ) |  | $ | (8,896 | ) |  | $ | 953 |  |  | $ | (7,943 | ) |
| Other comprehensive income (loss) before reclassifications | (2,825 | ) |  | — |  |  | (2,825 | ) |  | (907 | ) |  | 90 |  |  | (817 | ) |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | — |  |  | — |  |  | — |  |  | (324 | ) |  | (324 | ) |
| Net current-period other comprehensive income (loss), net of tax | (2,825 | ) |  | — |  |  | (2,825 | ) |  | (907 | ) |  | (234 | ) |  | (1,141 | ) |
| Ending balance | $ | (14,401 | ) |  | $ | — |  |  | $ | (14,401 | ) |  | $ | (9,803 | ) |  | $ | 719 |  |  | $ | (9,084 | ) |

[0000926326-19-000033:notes:83]
|  | Nine months ended September 30, |
|  | 2019 |  | 2018 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (11,274 | ) |  | $ | 420 |  |  | $ | (10,854 | ) |  | $ | (6,954 | ) |  | $ | 841 |  |  | $ | (6,113 | ) |
| Other comprehensive income (loss) before reclassifications | (3,127 | ) |  | 148 |  |  | (2,979 | ) |  | (2,849 | ) |  | 686 |  |  | (2,163 | ) |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (568 | ) |  | (568 | ) |  | — |  |  | (808 | ) |  | (808 | ) |
| Net current-period other comprehensive income (loss), net of tax | (3,127 | ) |  | (420 | ) |  | (3,547 | ) |  | (2,849 | ) |  | (122 | ) |  | (2,971 | ) |
| Ending balance | $ | (14,401 | ) |  | $ | — |  |  | $ | (14,401 | ) |  | $ | (9,803 | ) |  | $ | 719 |  |  | $ | (9,084 | ) |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-19-000033:notes:84]
Property and Equipment 
The following table represents the property and equipment balances as of September 30, 2019 and December 31, 2018:

[0000926326-19-000033:notes:85]
|  | September 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Equipment | $ | 83,233 |  |  | $ | 75,417 |  |
| Furniture and fixtures | 8,521 |  |  | 7,844 |  |
| Leasehold improvements | 18,205 |  |  | 16,274 |  |
| Software | 47,756 |  |  | 42,048 |  |
| Construction in progress | 8,406 |  |  | 10,706 |  |
| Property and equipment, gross | 166,121 |  |  | 152,289 |  |
| Accumulated depreciation and amortization | (111,244 | ) |  | (100,789 | ) |
| Total property and equipment, net | $ | 54,877 |  |  | $ | 51,500 |  |

[0000926326-19-000033:notes:86]
Depreciation and amortization expense of property and equipment was $4.5 million and $3.7 million for the three months ended September 30, 2019 and 2018, respectively. Depreciation and amortization expense of property and equipment was $12.9 million and $11.0 million for the nine months ended September 30, 2019 and 2018, respectively.

[0000926326-19-000033:notes:87]
The geographic location of the Company's property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of September 30, 2019 and December 31, 2018:

[0000926326-19-000033:notes:88]
|  | September 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| United States | $ | 49,235 |  |  | $ | 44,684 |  |
| Rest of world (1) | 5,642 |  |  | 6,816 |  |
| Total property and equipment, net | $ | 54,877 |  |  | $ | 51,500 |  |

[0000926326-19-000033:notes:89]
[same as prior period, unchanged from 0000926326-19-000025:notes:89]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-19-000033:notes:90]
[same as prior period, unchanged from 0000926326-19-000025:notes:90]

[0000926326-19-000033:notes:91]
[same as prior period, unchanged from 0000926326-19-000025:notes:91]

[0000926326-19-000033:notes:92]
|  | December 31, 2018 |  | Additions |  | Foreign currency exchange rate fluctuations |  | September 30, 2019 |
|  | (In thousands) |
| Goodwill | $ | 335,887 |  |  | $ | — |  |  | $ | (1,371 | ) |  | $ | 334,516 |  |

[0000926326-19-000033:notes:93]
[same as prior period, unchanged from 0000926326-19-000025:notes:93]

[0000926326-19-000033:notes:94]
The carrying amounts and useful lives of intangible assets as of September 30, 2019 and December 31, 2018 were as follows:

[0000926326-19-000033:notes:95]
|  | September 30, 2019 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 135,234 |  |  | $ | (52,357 | ) |  | $ | (1,480 | ) |  | $ | 81,397 |  |  | 1 - 30 |
| Acquired technology | 77,142 |  |  | (34,213 | ) |  | (28 | ) |  | 42,901 |  |  | 3 - 20 |
| Backlog | 1,150 |  |  | (719 | ) |  | — |  |  | 431 |  |  | 4 |
| Trade names | 7,650 |  |  | (4,868 | ) |  | 6 |  |  | 2,788 |  |  | 1 - 12 |
| Patents | 3,217 |  |  | (1,571 | ) |  | — |  |  | 1,646 |  |  | 2 - 20 |
| Total intangibles assets, net | $ | 224,393 |  |  | $ | (93,728 | ) |  | $ | (1,502 | ) |  | $ | 129,163 |  |  |  |

[0000926326-19-000033:notes:96]
[same as prior period, unchanged from 0000926326-19-000025:notes:96]

[0000926326-19-000033:notes:97]
[same as prior period, unchanged from 0000926326-19-000025:notes:97]

[0000926326-19-000033:notes:98]
Amortization expense of intangible assets was $4.6 million and $5.8 million for the three months ended September 30, 2019 and 2018, respectively. Amortization expense of intangible assets was $14.1 million and $17.8 million for the nine months ended September 30, 2019 and 2018, respectively.

[0000926326-19-000033:notes:99]
[same as prior period, unchanged from 0000926326-19-000025:notes:99]

[0000926326-19-000033:notes:100]
|  | September 30, 2019 |
|  | (In thousands) |
| Remaining three months of 2019 | $ | 4,539 |  |
| 2020 | 17,457 |  |
| 2021 | 16,125 |  |
| 2022 | 14,780 |  |
| 2023 | 13,634 |  |
| Thereafter | 62,628 |  |
| Total | $ | 129,163 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-19-000033:notes:101]
Debt and Credit Agreements
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-19-000033:notes:102]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s consolidated total net leverage ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-19-000033:notes:103]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is

[0000926326-19-000033:notes:104]
required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain permitted asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-19-000033:notes:105]
The Credit Agreement contains customary representations and warranties, and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Company’s obligations under the Credit Agreement, and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender), are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.

[0000926326-19-000033:notes:106]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement (the “Amended Credit Agreement”). Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant, and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

[0000926326-19-000033:notes:107]
On December 26, 2017, the parties entered into an amendment (the “Amendment”) to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million, and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.

[0000926326-19-000033:notes:108]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $0.8 million and $1.9 million for the three months ended September 30, 2019 and 2018, respectively, and approximately $3.0 million and $5.7 million for the nine months ended September 30, 2019 and 2018, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million for both the three months ended September 30, 2019 and 2018, and approximately $1.7 million for both the nine months ended September 30, 2019 and 2018. The Company was in compliance with all covenants as of September 30, 2019 and December 31, 2018.

[0000926326-19-000033:notes:109]
During the nine months ended September 30, 2019, the Company repaid $60.0 million under these Facilities.

[0000926326-19-000033:notes:110]
The components of the Company’s debt obligations as of September 30, 2019 and December 31, 2018 were as follows:

[0000926326-19-000033:notes:111]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (60,000 | ) |  | $ | 80,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (60,000 | ) |  | 80,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 1,718 |  |  | (2,865 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (58,282 | ) |  | $ | 77,135 |  |

[0000926326-19-000033:notes:112]
As of September 30, 2019, the carrying amount of debt of $80.0 million approximates the comparable fair value of $79.9 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as

[0000926326-19-000033:notes:113]
interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of September 30, 2019 as compared to December 31, 2018.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-19-000033:notes:114]
[same as prior period, unchanged from 0000926326-19-000025:notes:113]

[0000926326-19-000033:notes:115]
On a recurring basis, the Company enters into multi-year, sales-type lease agreements, with the majority varying in length from one to five years. The following table presents the Company’s income recognized from sales-type leases for the three and nine months ended September 30, 2019 and 2018:

[0000926326-19-000033:notes:116]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 9,017 |  |  | $ | 11,438 |  |  | $ | 33,833 |  |  | $ | 28,828 |  |
| Interest income on sales-type lease receivables | $ | 527 |  |  | $ | 315 |  |  | $ | 1,335 |  |  | $ | 896 |  |

[0000926326-19-000033:notes:117]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at September 30, 2019 and December 31, 2018:

[0000926326-19-000033:notes:118]
|  | September 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 34,057 |  |  | $ | 28,295 |  |
| Less: Unearned interest income portion | (3,116 | ) |  | (2,477 | ) |
| Net investment in sales-type leases | 30,941 |  |  | 25,818 |  |
| Less: Current portion (1) | (9,447 | ) |  | (8,736 | ) |
| Long-term net investment in sales-type leases | $ | 21,494 |  |  | $ | 17,082 |  |

[0000926326-19-000033:notes:119]
[same as prior period, unchanged from 0000926326-19-000025:notes:118]

[0000926326-19-000033:notes:120]
[same as prior period, unchanged from 0000926326-19-000025:notes:119]

[0000926326-19-000033:notes:121]
The Company evaluates its sales-type leases individually and collectively for impairment. The allowance for credit losses was $0.2 million as of both September 30, 2019 and December 31, 2018.

[0000926326-19-000033:notes:122]
[same as prior period, unchanged from 0000926326-19-000025:notes:121]

[0000926326-19-000033:notes:123]
|  | September 30, 2019 |
|  | (In thousands) |
| Remaining three months of 2019 | $ | 4,111 |  |
| 2020 | 9,677 |  |
| 2021 | 7,304 |  |
| 2022 | 6,599 |  |
| 2023 | 4,585 |  |
| Thereafter | 1,781 |  |
| Total future minimum sales-type lease payments | 34,057 |  |
| Present value adjustment | (3,116 | ) |
| Total net investment in sales-type leases | $ | 30,941 |  |

[0000926326-19-000033:notes:124]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of the new lease accounting standard. These agreements in place prior to January 1, 2019 will continue to be treated as operating leases, however any new leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with the new lease accounting standard. The operating lease arrangements generally have initial terms of one to seven years. The following table represents the Company’s income recognized from operating leases for the three and nine months ended September 30, 2019 and 2018:

[0000926326-19-000033:notes:125]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Rental income | $ | 2,896 |  |  | $ | 2,999 |  |  | $ | 9,548 |  |  | $ | 8,800 |  |

[0000926326-19-000033:notes:126]
The net carrying value of the leased equipment under operating leases was $2.3 million and $2.6 million, which includes accumulated depreciation of $1.5 million and $1.2 million, as of September 30, 2019 and December 31, 2018, respectively. Depreciation expense of the leased equipment for both the three months ended September 30, 2019 and 2018 was $0.2 million, and depreciation expense of the leased equipment for the nine months ended September 30, 2019 and 2018 was $0.5 million and $0.3 million, respectively.

[0000926326-19-000033:notes:127]
[same as prior period, unchanged from 0000926326-19-000025:notes:127]

[0000926326-19-000033:notes:128]
|  | September 30, 2019 |
|  | (In thousands) |
| Remaining three months of 2019 | $ | 3,072 |  |
| 2020 | 9,986 |  |
| 2021 | 6,908 |  |
| 2022 | 4,941 |  |
| 2023 | 2,914 |  |
| Thereafter | 1,229 |  |
| Total future minimum operating lease payments | $ | 29,050 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-19-000033:notes:129]
Lessee Leases 
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to 12 years. As of September 30, 2019, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-19-000033:notes:130]
[same as prior period, unchanged from 0000926326-19-000025:notes:130]

[0000926326-19-000033:notes:131]
|  | September 30, 2019 |
|  | (In thousands) |
| Remaining three months of 2019 | $ | 3,655 |  |
| 2020 | 13,576 |  |
| 2021 | 12,966 |  |
| 2022 | 11,832 |  |
| 2023 | 8,409 |  |
| Thereafter | 27,585 |  |
| Total operating lease payments | 78,023 |  |
| Present value adjustment | (15,004 | ) |
| Total operating lease liabilities (1) | $ | 63,019 |  |

[0000926326-19-000033:notes:132]
| (1) | Amount consists of a current and long-term portion of operating lease liabilities of $10.3 million and $52.7 million, respectively. The short-term portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets. |

[0000926326-19-000033:notes:133]
[same as prior period, unchanged from 0000926326-19-000025:notes:133]

[0000926326-19-000033:notes:134]
[same as prior period, unchanged from 0000926326-19-000025:notes:134]

[0000926326-19-000033:notes:135]
Operating lease costs were $3.7 million and $11.0 million for the three and nine months ended September 30, 2019, respectively. Short-term lease costs and variable lease costs were immaterial for the three and nine months ended September 30, 2019.

[0000926326-19-000033:notes:136]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the nine months ended September 30, 2019:

[0000926326-19-000033:notes:137]
|  | Nine months ended September 30, 2019 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 11,023 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 957 |  |

[0000926326-19-000033:notes:138]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of September 30, 2019:

[0000926326-19-000033:notes:139]
|  | September 30, 2019 |
| Weighted-average remaining lease term, years | 6.6 |  |
| Weighted-average discount rate, % | 6.4 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-19-000033:notes:140]
Commitments and Contingencies
Purchase Obligations

[0000926326-19-000033:notes:141]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2019, the Company had non-cancelable purchase commitments of $75.3 million, of which $57.1 million are expected to be paid within the year ending December 31, 2019.

[0000926326-19-000033:notes:142]
Legal Proceedings

[0000926326-19-000033:notes:143]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

[0000926326-19-000033:notes:144]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint seeks monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice. On August 21, 2019, a new lawsuit was filed against the Company and Aesynt, in the Circuit Court for the County of Albemarle, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Aesynt Incorporated, et al., Case No CL19-1301. The complaint seeks monetary recovery of damages based upon claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not been served with the complaint. The Company intends to defend the lawsuit vigorously.

[0000926326-19-000033:notes:145]
On June 6, 2018, a class action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint sought class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint was held in

[0000926326-19-000033:notes:146]
abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The Illinois Supreme Court issued its decision in that case on January 25, 2019. On April 10, 2019, subsequent to the court’s issuance of an order granting the plaintiff leave to file an amended complaint, the plaintiff filed an amended complaint adding a second named plaintiff and an affiliate of the Company’s customer as an additional defendant and, in addition to making other modifications to the complaint, removing the separate cause of action directed to negligence. The court established a deadline of May 13, 2019 for the defendants to answer or otherwise respond to the amended complaint. On May 10, 2019, defendants Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, and Northwestern Memorial Hospital removed the case to the United States District Court for the Northern District of Illinois, Eastern Division. Subsequently, on May 17, 2019, the Company and the other defendants in the case each filed a motion to dismiss the complaint for failure to state a cause of action upon which relief could be granted. On June 14, 2019, plaintiffs filed a motion to remand the case to state court. The Court then entered an order, on June 19, 2019, denying plaintiffs’ motion to remand, granting defendants’ motions to dismiss with respect to the additionally-named plaintiff, and continuing the motions to dismiss with respect to the originally-named plaintiff. On July 2, 2019, the Court entered an order remanding the case to state court and denying the defendants’ motions to dismiss without prejudice to renewal of the motions in state court. On September 5, 2019, plaintiff filed a motion to voluntarily dismiss the Company from the case without prejudice. The motion was granted by order of the Court dated October 10, 2019 and, as a result, the Company has been finally dismissed from the case without prejudice to plaintiff refiling the action.

[0000926326-19-000033:notes:147]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, the Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (“Mazya Action”), disclosed above, together with claims for reimbursement and unjust enrichment relating to the defense of the Mazya Action in the form of attorneys’ fees and other related costs. The Company has not responded to the complaint. On February 12, 2019, the court stayed the action pending the outcome of the Mazya Action and administratively closed the case. On October 15, 2019, the plaintiffs filed a notice advising the Court of the dismissal of the Company from the Mazya Action and requesting that the Court lift the stay in the case and set dates for filing a responsive pleading by the Company and initial discovery and scheduling matters. The Company intends to defend the lawsuit vigorously.

[0000926326-19-000033:notes:148]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of BIPA, and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the Mazya Action. The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The Court has scheduled a case status conference for November 7, 2019 at which time the Company intends to present its motion to dismiss to the Court. The Company intends to defend the lawsuit vigorously.

[0000926326-19-000033:notes:149]
On July 18, 2019, a putative class action lawsuit was filed against the Company and certain of its officers in the U.S. District Court for the Northern District of California. The complaint, captioned Bursick v. Omnicell, Inc. et al., Case No. 3:19-cv-04150, alleges that the defendants violated federal securities laws by making materially false and misleading statements beginning in October 2018 regarding revenue recognition, customer concerns about implementation issues, and a purported need to write off inventory. The plaintiff seeks unspecified monetary damages and other relief. On October 24, 2019, Frank Bursick was appointed Lead Plaintiff. The Court ordered Lead Plaintiff to file an amended complaint by November 28, 2019 and the Company to respond to the amended complaint by January 2, 2020. The Company intends to defend the lawsuit vigorously.

[0000926326-19-000033:notes:150]
In August 2019, the Company received a letter from the Denver office of the SEC seeking information related to the Company’s accounting processes and procedures. The Company responded and is fully cooperating with the SEC.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-19-000033:notes:151]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 24.6% and 19.0% for the nine months ended September 30, 2019 and 2018, respectively.

[0000926326-19-000033:notes:152]
As a result of global operational centralization activities during the nine months ended September 30, 2018, the Company recognized $4.2 million of a discrete tax benefit associated with making a check-the-box election to treat Aesynt

[0000926326-19-000033:notes:153]
Holding Coöperatief U.A. (Netherlands) as a U.S. disregarded entity beginning in the first quarter of 2018. Due to continuing global operational centralization activities during the first quarter of 2019, the Company recognized gain on the sale of certain intellectual property rights by Aesynt Holding Coöperatief U.A. to Omnicell, Inc., which resulted in a discrete tax expense in the amount of $9.6 million during the nine months ended September 30, 2019. The Company also recognized a discrete tax benefit related to equity compensation in the amount of $8.1 million and $4.8 million for the nine months ended September 30, 2019 and September 30, 2018, respectively.

[0000926326-19-000033:notes:154]
[same as prior period, unchanged from 0000926326-19-000025:notes:152]

[0000926326-19-000033:notes:155]
As of September 30, 2019 and December 31, 2018, the Company had gross unrecognized tax benefits of $14.0 million and $10.0 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in Interest and other income (expense), net in the Condensed Consolidated Statements of Operations. As of September 30, 2019 and December 31, 2018, the amount of accrued interest and penalties was $1.7 million and $1.4 million, respectively.

[0000926326-19-000033:notes:156]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of September 30, 2019, the Company is no longer subject to United States, state, and foreign examination for years before 2015, 2014, and 2014, respectively.

[0000926326-19-000033:notes:157]
[same as prior period, unchanged from 0000926326-19-000025:notes:155]


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-19-000033:notes:158]
[same as prior period, unchanged from 0000926326-19-000025:notes:156]

[0000926326-19-000033:notes:159]
[same as prior period, unchanged from 0000926326-19-000025:notes:157]

[0000926326-19-000033:notes:160]
[same as prior period, unchanged from 0000926326-19-000025:notes:158]

[0000926326-19-000033:notes:161]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2019 and 2018:

[0000926326-19-000033:notes:162]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,316 |  |  | $ | 1,150 |  |  | $ | 4,194 |  |  | $ | 3,346 |  |
| Research and development | 1,652 |  |  | 1,397 |  |  | 4,938 |  |  | 4,068 |  |
| Selling, general, and administrative | 5,537 |  |  | 4,538 |  |  | 16,043 |  |  | 13,437 |  |
| Total share-based compensation expense | $ | 8,505 |  |  | $ | 7,085 |  |  | $ | 25,175 |  |  | $ | 20,851 |  |

[0000926326-19-000033:notes:163]
In the first quarter of 2019, the Company modified the terms of its stock options by extending the post-employment exercise period for certain employees. The Company recorded share-based compensation expense related to this modification of approximately $0.2 million on the stock options modification date. As of September 30, 2019, share-based compensation expense related to unvested stock options impacted by the modification was approximately $0.7 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.9 years.

[0000926326-19-000033:notes:164]
[same as prior period, unchanged from 0000926326-19-000025:notes:162]

[0000926326-19-000033:notes:165]
The following assumptions were used to value stock options and Employee Stock Purchase Plan (“ESPP”) shares granted pursuant to the Company’s equity incentive plans for the three and nine months ended September 30, 2019 and 2018:

[0000926326-19-000033:notes:166]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Stock options |  |  |  |  |  |  |  |
| Expected life, years | 4.3 |  |  | 4.8 |  |  | 4.4 |  |  | 4.8 |  |
| Expected volatility, % | 34.7 | % |  | 30.4 | % |  | 33.7 | % |  | 31.1 | % |
| Risk-free interest rate, % | 1.6 | % |  | 2.8 | % |  | 2.1 | % |  | 2.7 | % |
| Estimated forfeiture rate, % | 7.2 | % |  | 6.9 | % |  | 7.2 | % |  | 6.9 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-19-000033:notes:167]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Employee stock purchase plan shares |  |  |  |  |  |  |  |
| Expected life, years | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |
| Expected volatility, % | 28.9% - 39.9% |  |  | 28.1% - 33.8% |  |  | 28.2% - 39.9% |  |  | 27.7% - 33.8% |  |
| Risk-free interest rate, % | 1.4% - 2.7% |  |  | 0.8% - 2.7% |  |  | 1.3% - 2.7% |  |  | 0.7% - 2.7% |  |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-19-000033:notes:168]
[same as prior period, unchanged from 0000926326-19-000025:notes:166]

[0000926326-19-000033:notes:169]
The following table summarizes the share option activity under the Company’s equity incentive plans during the nine months ended September 30, 2019:

[0000926326-19-000033:notes:170]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2018 | 3,748 |  |  | $ | 41.27 |  |  | 7.6 |  | $ | 78,365 |  |
| Granted | 687 |  |  | 75.49 |  |  |  |  |  |
| Exercised | (597 | ) |  | 32.66 |  |  |  |  |  |
| Expired | (9 | ) |  | 37.08 |  |  |  |  |  |
| Forfeited | (234 | ) |  | 47.23 |  |  |  |  |  |
| Outstanding at September 30, 2019 | 3,595 |  |  | $ | 48.86 |  |  | 7.7 |  | $ | 87,453 |  |
| Exercisable at September 30, 2019 | 1,470 |  |  | $ | 33.91 |  |  | 6.3 |  | $ | 56,377 |  |
| Vested and expected to vest at September 30, 2019 and thereafter | 3,401 |  |  | $ | 48.07 |  |  | 7.7 |  | $ | 85,235 |  |

[0000926326-19-000033:notes:171]
The weighted-average fair value per share of options granted during the three months ended September 30, 2019 and 2018 was $21.59 and $12.49, respectively, and the weighted-average fair value per share of options granted during the nine months ended September 30, 2019 and 2018 was $23.41 and $15.02, respectively. The intrinsic value of options exercised during the three months ended September 30, 2019 and 2018 was $2.7 million and $8.2 million, respectively, and the intrinsic value of options exercised during the nine months ended September 30, 2019 and 2018 was $27.0 million and $16.7 million, respectively.

[0000926326-19-000033:notes:172]
As of September 30, 2019, total unrecognized compensation cost related to unvested stock options was $33.5 million, which is expected to be recognized over a weighted-average vesting period of 2.7 years.

[0000926326-19-000033:notes:173]
[same as prior period, unchanged from 0000926326-19-000025:notes:171]

[0000926326-19-000033:notes:174]
For the nine months ended September 30, 2019 and 2018, employees purchased approximately 374,000 and 452,038 shares of common stock, respectively, under the ESPP at weighted average prices of $41.44 and $29.69, respectively. As of September 30, 2019, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $2.6 million and is expected to be recognized over a weighted-average period of 1.5 years.

[0000926326-19-000033:notes:175]
[same as prior period, unchanged from 0000926326-19-000025:notes:174]

[0000926326-19-000033:notes:176]
Summaries of the restricted stock activity under the Company’s 2009 Equity Incentive Plan, as amended (the “2009 Plan”) are presented below for the nine months ended September 30, 2019:

[0000926326-19-000033:notes:177]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted stock units |  |  |  |  |  |  |  |
| Outstanding at December 31, 2018 | 538 |  |  | $ | 51.52 |  |  | 1.6 |  | $ | 32,935 |  |
| Granted (Awarded) | 77 |  |  | 77.48 |  |  |  |  |  |
| Vested (Released) | (120 | ) |  | 40.87 |  |  |  |  |  |
| Forfeited | (49 | ) |  | 47.21 |  |  |  |  |  |
| Outstanding and unvested at September 30, 2019 | 446 |  |  | $ | 59.39 |  |  | 1.3 |  | $ | 32,199 |  |

[0000926326-19-000033:notes:178]
As of September 30, 2019, total unrecognized compensation cost related to RSUs was $21.0 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.6 years.

[0000926326-19-000033:notes:179]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted stock awards |  |  |  |
| Outstanding at December 31, 2018 | 21 |  |  | $ | 46.60 |  |
| Granted (Awarded) | 17 |  |  | 81.86 |  |
| Vested (Released) | (21 | ) |  | 46.96 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at September 30, 2019 | 17 |  |  | $ | 81.92 |  |

[0000926326-19-000033:notes:180]
As of September 30, 2019, total unrecognized compensation cost related to RSAs was $0.8 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.6 years.

[0000926326-19-000033:notes:181]
[same as prior period, unchanged from 0000926326-19-000025:notes:180]

[0000926326-19-000033:notes:182]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below for the nine months ended September 30, 2019:

[0000926326-19-000033:notes:183]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2018 | 197 |  |  | $ | 34.83 |  |
| Granted | 71 |  |  | 73.38 |  |
| Vested | (68 | ) |  | 35.74 |  |
| Forfeited | (33 | ) |  | 33.84 |  |
| Outstanding and unvested at September 30, 2019 | 167 |  |  | $ | 51.07 |  |

[0000926326-19-000033:notes:184]
As of September 30, 2019, total unrecognized compensation cost related to PSUs was approximately $4.0 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.3 years.

[0000926326-19-000033:notes:185]
[same as prior period, unchanged from 0000926326-19-000025:notes:184]

[0000926326-19-000033:notes:186]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of September 30, 2019:

[0000926326-19-000033:notes:187]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 3,595 |  |
| Non-vested restricted share awards | 630 |  |
| Shares authorized for future issuance | 3,672 |  |
| ESPP shares available for future issuance | 1,539 |  |
| Total shares reserved for future issuance | 9,436 |  |

[0000926326-19-000033:notes:188]
[same as prior period, unchanged from 0000926326-19-000025:notes:187]

[0000926326-19-000033:notes:189]
On August 2, 2016, the Company's Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of September 30, 2019, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase programs at any time. 
During the three and nine months ended September 30, 2019 and 2018, the Company did not repurchase any of its outstanding common stock.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-19-000033:notes:190]
[same as prior period, unchanged from 0000926326-19-000025:notes:189]

[0000926326-19-000033:notes:191]
For the three months ended September 30, 2019, the Company did not sell any of its common stock under the Distribution Agreement.

[0000926326-19-000033:notes:192]
For the nine months ended September 30, 2019, the Company received gross proceeds of $38.5 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 460,000 shares of its common stock at an average price of approximately $83.81 per share.

[0000926326-19-000033:notes:193]
For the three and nine months ended September 30, 2018, the Company did not sell any of its common stock under the Distribution Agreement.

[0000926326-19-000033:notes:194]
As of September 30, 2019, the Company had an aggregate of $31.5 million available to be offered under the Distribution Agreement.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-19-000033:notes:195]
Restructuring Expenses
In the fourth quarter of 2018, the Company announced a company-wide organizational realignment initiative in order to align its organizational infrastructure for future expected growth. During the year ended December 31, 2018, the Company incurred and accrued for $1.3 million of restructuring expenses, which includes severance and consulting-related expenses. As of September 30, 2019, there was no unpaid balance related to this restructuring plan.

[0000926326-19-000033:notes:196]
On March 2, 2018, the Company initiated the realignment of its Automation and Analytics commercial group in North America and France. During the nine months ended September 30, 2018, the Company accrued and paid out $3.0 million of employee severance cost and related expenses. As of December 31, 2018, there was no unpaid balance related to this restructuring program.
