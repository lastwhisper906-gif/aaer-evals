# OMCL MD&A — 0000926326-24-000008


## mdna

[0000926326-24-000008:mdna:1]
ITEM 7.    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000926326-24-000008:mdna:2]
The following discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes to Consolidated Financial Statements in this Annual Report on Form 10-K. This discussion and analysis may contain forward-looking statements based upon our current expectations and assumptions that involve risks and uncertainties.

[0000926326-24-000008:mdna:3]
Our actual results and the timing of selected events could differ materially from those anticipated in these forward-looking statements as a result of several factors, including those set forth under Item 1A, “Risk Factors,” and elsewhere in this Annual Report on Form 10-K. Unless otherwise stated, references in this Annual Report to particular years or quarters refer to our fiscal year and the associated quarters of those fiscal years.

[0000926326-24-000008:mdna:4]
We have elected to omit discussion of the earliest of the three years covered by the Consolidated Financial Statements presented. Such omitted discussion can be found under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” located in our Annual Report on Form 10-K for the fiscal year ended December 31, 2022, filed with the SEC on March 1, 2023, for reference to discussion of the fiscal year ended December 31, 2021, the earliest of the three fiscal years presented.

[0000926326-24-000008:mdna:5]
OVERVIEW

[0000926326-24-000008:mdna:6]
Our Business

[0000926326-24-000008:mdna:7]
Omnicell, a leader in transforming the pharmacy care delivery model, is committed to solving the critical challenges inherent in medication management and elevating the role of clinicians within healthcare as an essential component of care delivery. Omnicell is focused on helping its customers to define and deliver a cost effective medication management strategy that is designed to equip and empower pharmacists and nurses to focus on patient care rather than administrative tasks, and to drive improved clinical, operational, and financial outcomes across all care settings. We are doing this with an industry-leading medication management infrastructure which includes robotics, smart devices, intelligent software, and expert services. This comprehensive set of solutions provides the critical foundation for customers to realize the industry vision of the Autonomous Pharmacy, a vision defined by pharmacy leaders for improving operational efficiencies and ultimately targeting zero-error medication management.

[0000926326-24-000008:mdna:8]
Omnicell solutions are helping healthcare facilities worldwide to reduce costs, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry vision of the Autonomous Pharmacy. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 88% of our total revenues for the year ended December 31, 2023.

[0000926326-24-000008:mdna:9]
Over the past several years, our business has expanded from a single-point solution to a platform of products and services that will help to further advance the industry vision of the Autonomous Pharmacy. This expansion has resulted in larger deal sizes across multiple products, services, and implementations for customers and, we believe, more comprehensive, valuable, and enduring relationships. As our business evolves, we continue to evaluate the metrics and methods we use to measure the success of our business.

[0000926326-24-000008:mdna:10]
We utilize bookings as an indicator of the success of our business. We define bookings generally as: (i) the value of non-cancelable contracts for our connected devices, software products, and Advanced Services (although, for those Advanced Services contracts without a minimum commitment, bookings only include the amount of revenue that has been recognized once the services have been provided); and (ii) for our consumables, the value of orders placed through our Omnicell Storefront online platform or through written or telephonic orders. We typically exclude technical services and other less significant items ancillary to our products and services, such as freight revenue from bookings. In addition, dependent upon counterparty or credit risk, which is evaluated at the time of contract signing, for a given multi-year subscription contract we may reduce the portion of the contractual commitment booked at a given time. As noted, the portfolio of products, solutions and services we offer has evolved. As a result, the ordering process for certain of our solutions has also evolved. For example, orders for certain solutions may not include a purchase order. Connected devices and software license bookings are recorded as revenue upon customer acceptance of the installation or receipt of goods. Revenues from Advanced Services bookings are recorded over the contractual term. Bookings decreased by 19%, from $1.054 billion in 2022 to $854 million in 2023, primarily driven by lower-than-expected orders for our Advanced Services, particularly our technology-enabled services, which include Central Pharmacy Dispensing Service and IV Compounding Service.

[0000926326-24-000008:mdna:11]
We generally provide installation planning and consulting as part of most connected device product sales, which is typically included in the initial price of the solution. To help ensure the maximum availability of our systems, our customers typically purchase technical services contracts (maintenance and support) in increments of one to five years. In addition to connected device product sales, we provide a range of services to our customers. We also provide Advanced Services such as Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions, which typically are provided over 2-7 years.

[0000926326-24-000008:mdna:12]
The following table summarizes each revenue category:

[0000926326-24-000008:mdna:13]
| Revenue Category |  | Revenue Type |  | Income Statement Classification |  | Included in Bookings |
| Connected devices, software licenses, and other |  | Nonrecurring |  | Product |  | Yes (1) |
| Consumables |  | Recurring |  | Product |  | Yes |
| Technical services |  | Recurring |  | Service |  | No |
| Advanced Services (2) (3) |  | Recurring |  | Service |  | Yes |

[0000926326-24-000008:mdna:14]
_________________________________________________

[0000926326-24-000008:mdna:15]
(1)    Certain other insignificant revenue streams ancillary to our products and services, such as freight revenue, are not included in bookings.

[0000926326-24-000008:mdna:16]
(2)    Includes Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions.

[0000926326-24-000008:mdna:17]
(3)    For those Advanced Services contracts without a minimum commitment, bookings only include the amount of revenue that has been recognized once the services have been provided.

[0000926326-24-000008:mdna:18]
Our full-time employee headcount was approximately 3,650 on December 31, 2023, a decrease of approximately 580 employees since December 31, 2022. The decrease in employee headcount reflects the impact of restructuring initiatives announced in November 2022 and November 2023.

[0000926326-24-000008:mdna:19]
Operating Segments

[0000926326-24-000008:mdna:20]
We manage our operations as a single segment for the purposes of assessing performance and making operating decisions. Our Chief Operating Decision Maker (“CODM”) is our Chief Executive Officer. The CODM allocates resources and evaluates the performance of Omnicell at the consolidated level using information about our revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of Omnicell as one operating segment, which is the same as our reporting segment.

[0000926326-24-000008:mdna:21]
Business Strategy

[0000926326-24-000008:mdna:22]
The U.S. spent a total of $634 billion on prescription drugs in 2022, an increase of 9% compared to 2021, and prescription drugs impact the vast majority of patients in virtually all settings of care. We believe there are significant challenges facing the practice of pharmacy today including, but not limited to, budget constraints, increased healthcare worker turnover rates, labor shortages, drug shortages, drug diversion, manual and error-prone processes, complex compliance requirements, and limited inventory visibility. Each of these challenges may lead to poor medication management outcomes including, but not limited to, medication errors, adverse drug events, lack of patient adherence, and medication waste. We also recognize that these challenges may impact the timing of contracting for, or implementing, our products, solutions, or services. However, we believe that over time these significant challenges to the practice of pharmacy will drive demand for increased automation, visibility, insights, and improved medication management outcomes that our solutions are designed to enable. Because of this, we believe that our solutions are well-positioned to address the evolving needs of healthcare institutions and therefore present opportunities for long-term growth.

[0000926326-24-000008:mdna:23]
In an effort to address these challenges and deliver solutions to help drive positive medication management outcomes, we continue to make significant investments in our research and development efforts to further advance the industry vision of the Autonomous Pharmacy. Furthermore, we believe a combination of robotics, smart devices, intelligent software, and expert services is needed in every care setting where medications are managed. We are focused on delivering solutions to help our customers realize the industry vision of the Autonomous Pharmacy and drive positive medication management outcomes with outstanding customer experience through a mature channel in four market categories:

[0000926326-24-000008:mdna:24]
•Point of Care.  As a market leader, we expect to continue expansion into this product market as customers increase the use of our dispensing systems in more areas within their hospitals and increasingly in ambulatory care settings. However, we recognize that the current macroeconomic environment, with significant labor constraints, may impact our customers’ considerations in the near term when they are determining whether to implement new workflows that may affect those same stressed labor pools. As we are largely through the replacement cycle of our previous generation of automated dispensing systems, we are seeing demand moderate. We continue to invest in next-generation point of care enhancements and solutions and believe that customers will upgrade their current installed base over time as we deliver these new solutions to market. We also believe there is an opportunity for us to expand this offering and define a new standard for dispensing systems in ambulatory settings. We believe our current solutions within the Point of Care market and new innovation and services will continue to help customers drive improved clinical and financial outcomes.

[0000926326-24-000008:mdna:25]
•Central Pharmacy and IV Compounding.  This market represents the beginning of the medication management process in acute care settings, and we believe it is a significant automation opportunity for high volumes of manual, repetitive, and error-prone processes that are often common in pharmacies today. Manual medication dispensing processes are usually labor intensive, error-prone, and may lead to excess medication waste and expirations for our healthcare partners. Automating the central pharmacy dispensing process should enable customers to reallocate pharmacy labor, enhance dispensing accuracy and patient safety, and reduce medication waste and expirations. Likewise, the manual compounding of sterile IV preparations can be error-prone and create significant patient safety risks, and outsourcing sterile IV compounding could lead to increased medication costs and lack of access to needed medications as a result of being unable to source medications when they are required. As a result, we believe IV automation provides a significant opportunity to enhance patient safety and reduce costs. We anticipate that these technology-enabled services will become more critical as health systems continue to face labor shortages, increased financial pressure, and supply chain disruptions.

[0000926326-24-000008:mdna:26]
•Specialty Pharmacy and 340B Program.  We believe that health systems will continue to invest in programs that are intended to improve patient outcomes and drive cost savings by utilizing specialty pharmacies and the federal 340B Drug Pricing Program (the “340B Program”). The 340B Program allows qualifying hospitals and health systems to stretch federal resources and expand patient access to healthcare by requiring manufacturers participating in Medicaid to sell outpatient drugs at discounted prices to eligible healthcare organizations and covered entities. Specialty drugs are used for treatment of complex conditions and often require intensive patient management and specialized workflows for dispensing and care coordination. Specialty medications are projected to account for nearly 60% of U.S. total spending on medications, with total spending projected to be approximately $420 billion in 2025. Specialty pharmacies serve as the connection between patients, prescribing physicians, and payers and work to streamline access and adherence to these specialty drugs. We believe a solution that is designed to help health systems start or optimize their specialty pharmacy programs and the related pharmaceutical aspects of patient care will help ensure continuity of care and should contribute to the revenue and profitability of those organizations. We believe that a fully optimized specialty pharmacy operation represents one of the largest economic opportunities for hospitals and health systems.

[0000926326-24-000008:mdna:27]
50

[0000926326-24-000008:mdna:28]
•Retail, Institutional, and Payer.  We believe the Retail, Institutional, and Payer market represents a significant opportunity as healthcare evolves. Retail drug prescriptions represent 85% of all prescription drugs dispensed in the U.S., growing at a rate of 1.7% annually through 2022. Additionally, the COVID-19 pandemic accelerated the shift of outpatient care from hospitals and physician offices to other, more convenient settings, such as retail pharmacies and the home (including through telehealth technologies). New technologies and increased scope of practice for pharmacists appear to be spurring innovation and expansion of the provision of clinical services by retail pharmacies, which, combined with the move to value-based care, we believe will drive the adoption of our patient engagement solutions, that are intended to help providers (including pharmacists) and payers engage patients in new ways that are expected to improve outcomes, reduce the total cost of care, and lead to more profitable operations. Because of the complexity of relationships between payers and providers, as well as the large number of retail pharmacies, including a significant number of independent pharmacies, we believe a network of established relationships between payers, providers and pharmacies will continue to be important.

[0000926326-24-000008:mdna:29]
Ransomware Incident

[0000926326-24-000008:mdna:30]
Further information with respect to the ransomware incident we experienced in May 2022 may be found under the headings “Ongoing Mitigation Efforts” and “Impact of Recent Cyber Incident” in Part I, Item 1C of this Annual Report on Form 10-K. Such information is incorporated herein by reference.

[0000926326-24-000008:mdna:31]
Acquisitions

[0000926326-24-000008:mdna:32]
On January 10, 2022, we completed the acquisition of Hub and Spoke Innovations Limited (“Hub and Spoke Innovations”), pursuant to the terms and conditions of the Share Purchase Agreement, dated January 10, 2022, by and among Omnicell Limited (a wholly-owned subsidiary of the Company), Hub and Spoke Innovations Limited, and certain beneficial stockholders specified therein for a base purchase price of £2.5 million (approximately $3.4 million based on the exchange rate in effect at the acquisition date), prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The Hub and Spoke Innovations acquisition is expected to complement Omnicell’s total solution technology portfolio for retail pharmacy in the United Kingdom to help pharmacies improve workflows, offer patients 24/7 access to their medications and provide enhanced patient care. The results of the operations of Hub and Spoke Innovations have been included in our consolidated results of operations beginning January 10, 2022.

[0000926326-24-000008:mdna:33]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000926326-24-000008:mdna:34]
Our discussion and analysis of our financial condition and results of operations are based on our Consolidated Financial Statements, which have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0000926326-24-000008:mdna:35]
Revenue Recognition

[0000926326-24-000008:mdna:36]
We earn revenues from sales of our products and related services, which are sold in the healthcare industry, our principal market.

[0000926326-24-000008:mdna:37]
Prior to recognizing revenue, we identify the contract, performance obligations, and transaction price, and allocate the transaction price to the performance obligations. All identified contracts meet the following required criteria:

[0000926326-24-000008:mdna:38]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of our contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via our online portal, phone, or a purchase order.

[0000926326-24-000008:mdna:39]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following our standard business process and terms.

[0000926326-24-000008:mdna:40]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 to 60 days from shipment of tangible product or services performed for

[0000926326-24-000008:mdna:41]
customers in the United States. Where a written contract does not exist, our standard payment terms are net 30 day terms.

[0000926326-24-000008:mdna:42]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract). Our agreements are an exchange of cash for a combination of products and services which result in changes in the amount of our future cash flows.

[0000926326-24-000008:mdna:43]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. We perform a credit check for all significant customers or transactions and where collectability is not probable, payment in full or a substantial down payment prior to shipment is typically required to help ensure the full agreed upon contract price will be collected.

[0000926326-24-000008:mdna:44]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, we combine the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify our performance obligations, we consider all products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, we consider an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of our sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, software products, support and maintenance, and professional services.

[0000926326-24-000008:mdna:45]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of our commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

[0000926326-24-000008:mdna:46]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price we charge for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual technical services contracts, our products and services are not generally sold separately. We use an amount discounted from the list price as a best estimated selling price.

[0000926326-24-000008:mdna:47]
We recognize revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services, including Advanced Services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as we provide a stand-ready service for the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to our unsatisfied performance obligations for which invoicing has occurred is recorded as deferred revenues, net of deferred cost of goods sold.

[0000926326-24-000008:mdna:48]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

[0000926326-24-000008:mdna:49]
From time to time, we enter into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. Our change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

[0000926326-24-000008:mdna:50]
In the normal course of business, we typically do not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. We establish provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to our Consolidated Financial Statements for any periods presented.

[0000926326-24-000008:mdna:51]
Lessor Leases

[0000926326-24-000008:mdna:52]
We determine if an arrangement is or contains a lease at inception. The transaction price is allocated to separate performance obligations, generally consisting of a combination of hardware systems, software products, support and maintenance, and professional services, proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price we charge for the good or service when selling it separately in similar

[0000926326-24-000008:mdna:53]
circumstances to similar customers. Other than for the renewal of annual technical services contracts, our products and services are not generally sold separately. We use an amount discounted from the list price as a best estimated selling price.

[0000926326-24-000008:mdna:54]
Sales-Type Leases

[0000926326-24-000008:mdna:55]
We enter into non-cancelable sales-type lease arrangements, most of which do not have an option to extend the lease term. At the end of the lease term, the customer must either return the equipment or negotiate a new agreement, resulting in a new purchase or lease transaction. Failure of the customer to either return the equipment or negotiate a new agreement results in the contract becoming a month-to-month rental. Certain sales-type leases automatically renew for successive one-year periods at the end of each lease term without written notice from the customer. Our sales-type lease agreements do not contain any material residual value guarantees.

[0000926326-24-000008:mdna:56]
For sales-type leases, we recognize revenues for our hardware and software products, net of lease execution costs, post-installation product maintenance, professional services associated with Advanced Services offerings, and technical support, at the net present value of the lease payment stream upon customer acceptance. We recognize service revenues associated with sales-type leases ratably over the term of the agreement in service revenues in the Consolidated Statements of Operations. We recognize interest income from sales-type leases using the effective interest method. Both hardware and software revenues, and interest income from sales-types leases are recorded in product revenues in the Consolidated Statements of Operations.

[0000926326-24-000008:mdna:57]
We optimize cash flows by selling a majority of our sales-type leases, other than those relating to U.S. government hospitals and Advanced Services products, including Central Pharmacy Dispensing Service and IV Compounding Service, to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold.

[0000926326-24-000008:mdna:58]
Allowance for Credit Losses

[0000926326-24-000008:mdna:59]
We are exposed to credit losses primarily through sales of our products and services, as well as our sales-type leasing arrangements. We perform credit evaluations of our customers’ financial condition in order to assess each customer’s ability to pay. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, and a financial review of the customer. We continue to monitor customers’ creditworthiness on an ongoing basis.

[0000926326-24-000008:mdna:60]
We maintain an allowance for credit losses for accounts receivable, unbilled receivables, and net investment in sales-type leases based on expected credit losses resulting from the inability of our customers to make required payments. The allowance for credit losses is measured using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. We also record a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. Actual collection losses may differ from management’s estimates, and such differences could be material to our financial position and results of operations.

[0000926326-24-000008:mdna:61]
Inventory

[0000926326-24-000008:mdna:62]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. Inbound shipping costs are included in cost of inventory. We regularly monitor inventory quantities on hand and record write-downs for excess and obsolete inventories based on our estimate of demand for our products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Shipments from suppliers or contract manufacturers before we receive them are recorded as in-transit inventory when title and the significant risks and rewards of ownership have passed to us.

[0000926326-24-000008:mdna:63]
Internal-Use Software Development Costs

[0000926326-24-000008:mdna:64]
We capitalize costs related to computer software developed or obtained for internal-use in accordance with Accounting Standards Codification (“ASC”) 350-40, Internal-Use Software. Software developed or obtained for internal-use includes certain costs for the development of our subscription and cloud-based offerings sold to our customers, as well as enterprise-level business and finance software that we customize to meet our specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred.

[0000926326-24-000008:mdna:65]
External-Use Software Development Costs

[0000926326-24-000008:mdna:66]
We capitalize certain software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which those costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. We establish technological feasibility when we complete a detail program design or a working model. We amortize development costs over the estimated lives of the related products, which is generally five years. All development costs prior to the completion of a detail program design or a working model are recognized as research and development expense.

[0000926326-24-000008:mdna:67]
Lessee Leases

[0000926326-24-000008:mdna:68]
We determine if an arrangement is or contains a lease at inception. Operating lease right-of-use assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. As most of our lease contracts do not provide an implicit rate, we use our incremental borrowing rate based on information available at the commencement date in determining the present value of the lease payments. Lease expense is recognized on a straight-line basis over the lease term. We do not recognize a right-of-use asset and a lease liability for leases with an initial term of twelve months or less. We elected the practical expedient to not separate lease components from nonlease components and applied that practical expedient to all material classes of leased assets.

[0000926326-24-000008:mdna:69]
Many of our operating leases include an option to extend the lease. The specific terms and conditions of the extension options vary from lease to lease, but are consistent with standard industry practices in each area that we operate. We review each of our lease options at a time required by the terms of the lease contract, and notify the lessor if we choose to exercise the lease renewal option. Until we are reasonably certain that we will extend the lease contract, the renewal option periods will not be recognized as right-of-use assets or lease liabilities.

[0000926326-24-000008:mdna:70]
Certain leases include provisions for early termination, which allow the contract parties to terminate their obligations under the lease contract. The terms and conditions of the termination options vary by contract. When we have made a decision to exercise an early termination option, the right-of-use assets and associated lease liabilities are remeasured in accordance with the present value of the remaining cash flows under the lease contract.

[0000926326-24-000008:mdna:71]
Certain building lease agreements include rental payments subject to change annually based on fluctuations in various indexes (i.e., Consumer Price Index (“CPI”), Retail Price Index, and other international indexes). Certain data center lease agreements include rental payments subject to change based on usage and CPI fluctuations. The changes based on usage and indexes are treated as variable lease costs and recognized in the period in which the obligation for those payments was incurred.

[0000926326-24-000008:mdna:72]
Business Combinations

[0000926326-24-000008:mdna:73]
We use the acquisition method of accounting under ASC 805, Business Combinations. Each acquired company’s operating results are included in our Consolidated Financial Statements starting on the acquisition date. The purchase price is equivalent to the fair value of consideration transferred. Tangible and identifiable intangible assets acquired and liabilities assumed as of the acquisition date are recorded at the acquisition date fair value. Goodwill is recognized for the excess of purchase price over the net fair value of assets acquired and liabilities assumed.

[0000926326-24-000008:mdna:74]
Amounts allocated to assets and liabilities are based upon fair values. Such valuations require management to make significant estimates and assumptions, especially with respect to the identifiable intangible assets. Management makes estimates of fair value based upon assumptions believed to be reasonable and that of a market participant. These estimates are based on available historical information as well as future expectations, and the estimates are inherently uncertain. The separately identifiable intangible assets generally include customer relationships, acquired technology, backlog, trade names, and non-compete agreements.

[0000926326-24-000008:mdna:75]
Goodwill and Acquired Intangible Assets

[0000926326-24-000008:mdna:76]
Goodwill

[0000926326-24-000008:mdna:77]
We assess goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. This assessment is also performed whenever there is a change in circumstances that indicates the carrying value of goodwill may be impaired. We have one reporting unit, which is the same as our operating segment. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. A qualitative assessment includes, among others, consideration of: (i) past, current, and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this qualitative assessment indicates that it is more likely than not that impairment exists, or if we decide to bypass this option, we proceed to the quantitative assessment. The quantitative assessment involves a comparison

[0000926326-24-000008:mdna:78]
between the estimated fair value of our reporting unit with its carrying amount including goodwill. If the carrying value exceeds estimated fair value, we will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill.

[0000926326-24-000008:mdna:79]
To determine the reporting unit’s fair value under the quantitative approach, we use a combination of income and market approaches, such as estimated discounted future cash flows of the reporting unit, multiples of earnings or revenues, and analysis of recent sales or offerings of comparable entities. We also consider our market capitalization on the date of the analysis to ensure the reasonableness of our reporting unit’s fair value.

[0000926326-24-000008:mdna:80]
Intangible Assets

[0000926326-24-000008:mdna:81]
In connection with our acquisitions, we generally recognize assets for customer relationships, acquired technology, backlog, trade names, and non-compete agreements. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets. Amortization for acquired technology and backlog is recognized in cost of revenues, and amortization for customer relationships, trade names, non-compete agreements, and patents is recognized in selling, general, and administrative expenses.

[0000926326-24-000008:mdna:82]
We assess the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset’s carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. Our cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of our intangible assets are subjective and are affected by changes to our business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of our assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0000926326-24-000008:mdna:83]
Valuation of Share-Based Compensation

[0000926326-24-000008:mdna:84]
We account for share-based compensation in accordance with ASC 718, Stock Compensation. We recognize compensation expense related to share-based compensation based on the grant date estimated fair value.

[0000926326-24-000008:mdna:85]
The fair value of stock options (“options”) on the grant date is estimated using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of our common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on our historical experience of employee stock option exercises, including forfeitures. Expense is recognized on a straight-line basis over the requisite service period.

[0000926326-24-000008:mdna:86]
The fair value of restricted stock units (“RSUs”) and restricted stock awards (“RSAs”) is based on the stock price on the grant date. The RSUs and RSAs are subject to a service vesting condition and are recognized on a straight-line basis over the requisite service period.

[0000926326-24-000008:mdna:87]
The fair value of performance-based stock unit awards (“PSUs”) with service and market conditions is estimated using a Monte Carlo simulation model applying a multiple awards approach. Expense is recognized when it is probable that the performance condition will be met using the accelerated attribution method over the requisite service period.

[0000926326-24-000008:mdna:88]
Forfeiture rates are estimated based on our historical experience with equity awards that were granted and forfeited prior to vesting. The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods.

[0000926326-24-000008:mdna:89]
Accounting for Income Taxes

[0000926326-24-000008:mdna:90]
We record an income tax provision for (benefit from) the anticipated tax consequences of the reported results of operations. In accordance with ASC 740, Income Taxes, the provision for (benefit from) income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, we will incur a benefit or detriment on our income tax expense in the period of enactment. If we were to

[0000926326-24-000008:mdna:91]
determine that all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-24-000008:mdna:92]
In accordance with ASC 740, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of ASC 740 and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.

[0000926326-24-000008:mdna:93]
Recently Issued Authoritative Guidance

[0000926326-24-000008:mdna:94]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Consolidated Financial Statements in this Annual Report on Form 10-K for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-24-000008:mdna:95]
RESULTS OF OPERATIONS

[0000926326-24-000008:mdna:96]
Total Revenues

[0000926326-24-000008:mdna:97]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2023 |  | 2022 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Product revenues | $ | 708,561 |  |  | $ | 903,222 |  |  | $ | (194,661) |  |  | (22)% |  |  |  |  |  |  |
| Percentage of total revenues | 62% |  | 70% |  |  |  |  |  |  |  |  |  |  |
| Services and other revenues | 438,551 |  |  | 392,725 |  |  | 45,826 |  |  | 12% |  |  |  |  |  |  |
| Percentage of total revenues | 38% |  | 30% |  |  |  |  |  |  |  |  |  |  |
| Total revenues | $ | 1,147,112 |  |  | $ | 1,295,947 |  |  | $ | (148,835) |  |  | (11)% |  |  |  |  |  |  |

[0000926326-24-000008:mdna:98]
Product revenues represented 62% and 70% of total revenues for the years ended December 31, 2023 and 2022, respectively. Product revenues decreased by $194.7 million, primarily due to lower volumes from our automated dispensing systems business primarily as a result of ongoing health systems’ capital budget and labor constraints, partially offset by an increase of $9.7 million in revenues from consumables.

[0000926326-24-000008:mdna:99]
Services and other revenues represented 38% and 30% of total revenues for the years ended December 31, 2023 and 2022, respectively. Services and other revenues include revenues from technical services and Advanced Services offerings. Services and other revenues increased by $45.8 million, primarily due to an increase of $26.7 million in Advanced Services revenues due to continued customer demand and an increase of $19.1 million in technical services revenues as a result of growth in our installed customer base as well as the impact of pricing actions.

[0000926326-24-000008:mdna:100]
Our international sales represented 12% and 10% of total revenues for both of the years ended December 31, 2023 and 2022, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-24-000008:mdna:101]
Our ability to grow revenues is dependent on our ability to continue to obtain orders from customers, which may be dependent upon customers’ capital equipment budgets and/or capital equipment approval cycles, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, our ability to develop new or enhance existing solutions, and our flexibility in workforce allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules and/or staffing levels allow for installations.

[0000926326-24-000008:mdna:102]
Cost of Revenues and Gross Profit

[0000926326-24-000008:mdna:103]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which account for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product, and overhead costs associated with production; (ii) costs of providing services and installation costs, including costs of personnel and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, provisions for excess and obsolete inventory, and amortization of software development costs and intangibles.

[0000926326-24-000008:mdna:104]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2023 |  | 2022 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 414,106 |  |  | $ | 493,626 |  |  | $ | (79,520) |  |  | (16)% |  |  |  |  |  |  |
| As a percentage of related revenues | 58% |  | 55% |  |  |  |  |  |  |  |  |  |  |
| Cost of services and other revenues | 236,166 |  |  | 213,334 |  |  | 22,832 |  |  | 11% |  |  |  |  |  |  |
| As a percentage of related revenues | 54% |  | 54% |  |  |  |  |  |  |  |  |  |  |
| Total cost of revenues | $ | 650,272 |  |  | $ | 706,960 |  |  | $ | (56,688) |  |  | (8)% |  |  |  |  |  |  |
| As a percentage of total revenues | 57% |  | 55% |  |  |  |  |  |  |  |  |  |  |
| Gross profit | $ | 496,840 |  |  | $ | 588,987 |  |  | $ | (92,147) |  |  | (16)% |  |  |  |  |  |  |
| Gross margin | 43% |  | 45% |  |  |  |  |  |  |  |  |  |  |

[0000926326-24-000008:mdna:105]
Cost of revenues for the year ended December 31, 2023 compared to the year ended December 31, 2022 decreased by $56.7 million, primarily driven by a $79.5 million decrease in cost of product revenues, partially offset by a $22.8 million increase in cost of services and other revenues.

[0000926326-24-000008:mdna:106]
The decrease in cost of product revenues was primarily driven by the decrease in product revenues of $194.7 million for the year ended December 31, 2023 compared to the year ended December 31, 2022. The decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues for the year ended December 31, 2023, primarily due to certain fixed costs, such as labor and overhead. In addition, the decrease in cost of product revenues was also driven by lower inventory-related costs as pricing for semiconductors, steel, freight, and other costs has decreased from the prior period, as well as the impact from restructuring activities. The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $45.8 million for the year ended December 31, 2023 compared to the year ended December 31, 2022.

[0000926326-24-000008:mdna:107]
The overall decrease in gross margin primarily relates to lower product revenues for the year ended December 31, 2023 compared to the year ended December 31, 2022 whereas the decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues, primarily due to certain fixed costs, such as labor and overhead. The decrease is partially offset by lower inventory-related costs and the impact from restructuring activities. Our gross profit for the year ended December 31, 2023 was $496.8 million, as compared to $589.0 million for the year ended December 31, 2022.

[0000926326-24-000008:mdna:108]
Operating Expenses and Interest and Other Income (Expense), Net

[0000926326-24-000008:mdna:109]
|  | Year Ended December 31, |  | Change in |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | $ |  | % |  |  |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 97,115 |  |  | $ | 104,969 |  |  | $ | (7,854) |  |  | (7)% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 434,593 |  |  | 486,341 |  |  | (51,748) |  |  | (11)% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 38% |  | 38% |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 531,708 |  |  | $ | 591,310 |  |  | $ | (59,602) |  |  | (10)% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 46% |  | 46% |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense), net | $ | 14,760 |  |  | $ | (130) |  |  | $ | 14,890 |  |  | (11454)% |  |  |  |  |  |  |  |  |

[0000926326-24-000008:mdna:110]
Research and Development. Research and development expenses decreased by $7.9 million for the year ended December 31, 2023 compared to the year ended December 31, 2022. The decrease was primarily attributed to a decrease of $5.4 million in consulting expenses, a decrease in employee-related expenses of $4.8 million, and other decreases from cost saving initiatives, partially offset by an increase of $4.3 million due to the timing of capitalized software projects.

[0000926326-24-000008:mdna:111]
Selling, General, and Administrative. Selling, general, and administrative expenses decreased by $51.7 million for the year ended December 31, 2023 compared to the year ended December 31, 2022. The decrease was primarily due to a decrease

[0000926326-24-000008:mdna:112]
of $21.9 million in employee-related expenses, including the impact of restructuring activities, a decrease of $9.8 million in consulting expenses, a decrease of $7.3 million in commissions expenses, a decrease of $6.0 million in freight out, and a decrease of $4.8 million in travel expenses. The decrease is also driven by a decrease of $2.8 million of ransomware-related expenses, net of insurance recoveries, related to the ransomware incident we experienced in May 2022. The decrease is partially offset by an increase of $2.2 million in executive transition costs incurred during the year ended December 31, 2023, and an impairment of certain long-lived assets of $1.0 million during the year ended December 31, 2023.

[0000926326-24-000008:mdna:113]
Interest and Other Income (Expense), Net. Interest and other income (expense), net, changed by $14.9 million for the year ended December 31, 2023 compared to the year ended December 31, 2022, primarily driven by a $14.6 million increase in other income. The increase in other income during the year ended December 31, 2023 compared to the year ended December 31, 2022 is primarily attributable to higher interest income received due to higher interest rates and higher cash and cash equivalents balances.

[0000926326-24-000008:mdna:114]
Provision for (Benefit from) Income Taxes

[0000926326-24-000008:mdna:115]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2023 |  | 2022 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 263 |  |  | $ | (8,101) |  |  | $ | 8,364 |  |  | (103)% |  |  |  |  |  |  |
| Effective tax rate on earnings | (1)% |  | 330% |  |  |  |  |  |  |  |  |  |  |

[0000926326-24-000008:mdna:116]
We recorded a provision for income taxes of $0.3 million on a loss before taxes of $20.1 million, which resulted in a negative effective tax rate of 1% for the year ended December 31, 2023, compared to an income tax benefit of $8.1 million on a loss before taxes of $2.5 million, which resulted in an effective tax rate of 330% for the year ended December 31, 2022. The 2023 annual effective tax rate differed from the statutory tax rate of 21%, primarily due to an unfavorable impact of non-deductible equity compensation charges partially offset by a favorable impact of research and development credits, and foreign-derived intangible income (“FDII”) deduction.

[0000926326-24-000008:mdna:117]
Refer to Note 17, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-24-000008:mdna:118]
LIQUIDITY AND CAPITAL RESOURCES

[0000926326-24-000008:mdna:119]
We had cash and cash equivalents of $468.0 million at December 31, 2023, compared to $330.4 million at December 31, 2022. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with financial institutions of high credit quality.

[0000926326-24-000008:mdna:120]
Our cash position and working capital at December 31, 2023 and 2022 were as follows:

[0000926326-24-000008:mdna:121]
|  | December 31, |
|  | 2023 |  | 2022 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 467,972 |  |  | $ | 330,362 |  |
| Working capital | $ | 559,779 |  |  | $ | 453,366 |  |

[0000926326-24-000008:mdna:122]
Our ratio of current assets to current liabilities was 2.5:1 and 2.1:1 at December 31, 2023 and 2022, respectively.

[0000926326-24-000008:mdna:123]
Sources of Cash

[0000926326-24-000008:mdna:124]
Revolving Credit Facility

[0000926326-24-000008:mdna:125]
On November 15, 2019, we entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.

[0000926326-24-000008:mdna:126]
On September 22, 2020 and March 29, 2023, we entered into amendments to the Prior A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge

[0000926326-24-000008:mdna:127]
transactions, as described in Note 11, Convertible Senior Notes, expand our flexibility to repurchase our common stock and make other restricted payments, and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-24-000008:mdna:128]
On October 10, 2023, we entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-24-000008:mdna:129]
As of December 31, 2023, we had $350.0 million of funds available under the Current Revolving Credit Facility and as of December 31, 2022, we had $500.0 million of funds available under the Prior Revolving Credit Facility. As of December 31, 2023 and 2022, there was no outstanding balance under the Prior or Current Revolving Credit Facility and we were in full compliance with all covenants.

[0000926326-24-000008:mdna:130]
Refer to Note 10, Debt and Credit Agreement, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-24-000008:mdna:131]
Uses of Cash

[0000926326-24-000008:mdna:132]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, and other contractual obligations. We also expect a continued use of cash for potential acquisitions and acquisition-related activities, as well as repurchases of our common stock. In addition, we may also use a portion of our cash, as we consider various options related to our outstanding debt.

[0000926326-24-000008:mdna:133]
The 2016 Repurchase Program has a total of $2.7 million remaining for future repurchases as of December 31, 2023, which may result in additional use of cash. During the year ended December 31, 2022, we repurchased approximately 389,300 shares of our common stock under the repurchase programs at an average price of $134.11 per share for an aggregate purchase price of approximately $52.2 million. There were no stock repurchases during the year ended December 31, 2023. Refer to Note 16, Stock Repurchase Programs, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-24-000008:mdna:134]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-24-000008:mdna:135]
Cash Flows

[0000926326-24-000008:mdna:136]
The following table summarizes, for the periods indicated, selected items in our Consolidated Statements of Cash Flows:

[0000926326-24-000008:mdna:137]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |  |  |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 181,094 |  |  | $ | 77,781 |  |  |  |
| Investing activities | (55,016) |  |  | (58,669) |  |  |  |
| Financing activities | 23,420 |  |  | (20,953) |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,354) |  |  | (944) |  |  |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 148,144 |  |  | $ | (2,785) |  |  |  |

[0000926326-24-000008:mdna:138]
Operating Activities

[0000926326-24-000008:mdna:139]
We expect cash from our operating activities to fluctuate in future periods as a result of a number of factors, including the timing of our billings and collections, our operating results, and the timing of other liability payments.

[0000926326-24-000008:mdna:140]
Net cash provided by operating activities was $181.1 million for the year ended December 31, 2023, primarily consisting of net loss of $20.4 million adjusted for non-cash items of $157.8 million and changes in assets and liabilities of $43.7 million. The non-cash items primarily consisted of depreciation and amortization expense of $87.3 million, share-based compensation expense of $55.3 million, impairment and abandonment of operating lease right-of-use assets related to facilities of $10.0 million, amortization of operating lease right-of-use assets of $8.2 million, amortization of debt issuance costs of $4.4 million, and a change in deferred income taxes of $11.0 million. Changes in assets and liabilities include cash inflows from (i) a decrease in accounts receivable and unbilled receivables of $49.2 million primarily due to the timing of billings, shipments, and collections, as well as the impacts of lower revenues, (ii) a decrease in inventories of $38.0 million primarily due to management of inventory levels to align with the current forecasted demand, (iii) an increase in deferred revenues of $24.1 million primarily due to an increase in billings for certain technical service and Advanced Service offerings, (iv) a decrease in prepaid commissions of $7.1 million, (v) a decrease in other long-term assets of $2.1 million, and (vi) a decrease in prepaid expenses of $1.1 million. These cash inflows were partially offset by (i) a decrease in accrued compensation of $21.5 million primarily due to a decrease in the accrual for restructuring initiatives, lower commissions, as well as timing of ESPP purchases, (ii) a decrease in accounts payables of $17.5 million primarily due to an overall decrease in spending, as well as timing of payments, (iii) a decrease in operating lease liabilities of $10.9 million, (iv) an increase in investment in sales-type leases of $10.4 million primarily due to the acceptance of certain Advanced Services products under sales-type lease arrangements, (v) a decrease in accrued liabilities of $10.3 million, and (vi) an increase in other current assets of $6.8 million.

[0000926326-24-000008:mdna:141]
Net cash provided by operating activities was $77.8 million for the year ended December 31, 2022, primarily consisting of net income of $5.6 million adjusted for non-cash items of $145.6 million, offset by changes in assets and liabilities of $73.5 million. The non-cash items primarily consisted of depreciation and amortization expense of $86.9 million, share-based compensation expense of $68.2 million, amortization of operating lease right-of-use assets of $12.2 million, impairment and abandonment of operating lease right-of-use assets related to facilities of $9.4 million, amortization of debt issuance costs of $4.2 million, and a change in deferred income taxes of $37.3 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $60.4 million primarily due to an increase in billings driven by overall business growth and the timing of shipments as well as collections, (ii) an increase in inventories of $30.1 million primarily to support forecasted sales, including advanced purchases of certain components, such as semiconductors, as well as higher costs of inventory and timing of shipments, (iii) an increase in investment in sales-type leases of $15.4 million primarily due to the increase in sales-type lease revenues associated with certain Advanced Services products, (iv) a decrease in operating lease liabilities of $13.8 million, (v) a decrease in accounts payables of $7.8 million primarily due to an overall decrease in spending during the fourth quarter of 2022, including inventory spending, as well as timing of payments, and (vi) an increase in prepaid expenses of $4.7 million. These cash outflows were partially offset by (i) an increase in deferred revenues of $24.5 million primarily due to an increase in billings for certain service and subscription offerings, (ii) an increase in accrued liabilities of $16.7 million primarily due to an increase in taxes payable and an increase in general liabilities, (iii) a decrease in other current assets of $6.4 million, (iv) a decrease in other long-term assets of $5.0 million, (v) a decrease in prepaid commissions of $4.3 million, and (vi) an increase in accrued compensation of $2.4 million.

[0000926326-24-000008:mdna:142]
Investing Activities

[0000926326-24-000008:mdna:143]
Net cash used in investing activities was $55.0 million for the year ended December 31, 2023, which consisted of capital expenditures of $41.5 million for property and equipment and $13.5 million for external-use software development costs.

[0000926326-24-000008:mdna:144]
Net cash used in investing activities was $58.7 million for the year ended December 31, 2022, which consisted of capital expenditures of $47.5 million for property and equipment, $13.2 million for external-use software development costs, and $3.4 million consideration paid for the acquisition of Hub and Spoke Innovations, net of cash acquired, partially offset by purchase price adjustments from business acquisitions of $5.5 million.

[0000926326-24-000008:mdna:145]
Financing Activities

[0000926326-24-000008:mdna:146]
Net cash provided by financing activities was $23.4 million for the year ended December 31, 2023, primarily due to $23.2 million in proceeds from employee stock option exercises and ESPP purchases and a net change in the customer funds balances of $10.5 million, partially offset by $7.4 million in employees’ taxes paid related to restricted stock unit vesting and $3.0 million in payments for debt issuance costs.

[0000926326-24-000008:mdna:147]
Net cash used in financing activities was $21.0 million for the year ended December 31, 2022, primarily due to $52.2 million for repurchases of our stock and $13.5 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $40.2 million in proceeds from employee stock option exercises and ESPP purchases and a net change in the customer funds balances of $4.6 million.

[0000926326-24-000008:mdna:148]
Contractual Obligations

[0000926326-24-000008:mdna:149]
Contractual obligations as of December 31, 2023 were as follows:

[0000926326-24-000008:mdna:150]
|  | Payments Due By Period |
|  | Total |  | 2024 |  | 2025 - 2026 |  | 2027 - 2028 |  | 2029 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 50,600 |  |  | $ | 12,722 |  |  | $ | 20,324 |  |  | $ | 15,720 |  |  | $ | 1,834 |  |
| Purchase obligations (2) | 93,901 |  |  | 84,215 |  |  | 9,621 |  |  | 65 |  |  | — |  |
| Convertible senior notes (3) | 577,876 |  |  | 1,438 |  |  | 576,438 |  |  | — |  |  | — |  |
| Total (4) | $ | 722,377 |  |  | $ | 98,375 |  |  | $ | 606,383 |  |  | $ | 15,785 |  |  | $ | 1,834 |  |

[0000926326-24-000008:mdna:151]
_________________________________________________

[0000926326-24-000008:mdna:152]
(1)Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 13, Lessee Leases, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-24-000008:mdna:153]
(2)We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. The amounts under such contracts are included in the table above because we believe that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials.

[0000926326-24-000008:mdna:154]
(3)We issued convertible senior notes in September 2020 that are due in September 2025. The obligations presented above include both principal and interest for these notes. Although these notes mature in 2025, they may be converted into cash and shares of our common stock prior to maturity if certain conditions are met. Any conversion prior to maturity can result in repayment of the principal amounts sooner than the scheduled repayment as indicated in the table above. Refer to Note 11, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-24-000008:mdna:155]
(4)Refer to Note 14, Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.
