# OMCL 8-K — 0000926326-24-000005 filed 2024-02-08

## item codes, every 8-K on or before 2024-02-28

- 2024-02-08 0000926326-24-000005 — 2.02, 9.01
- 2024-01-11 0000926326-24-000002 — 5.02, 7.01, 8.01, 9.01
- 2023-11-09 0000926326-23-000043 — 5.02, 9.01
- 2023-11-02 0001104659-23-113604 — 2.02, 2.05, 7.01, 9.01
- 2023-10-16 0000926326-23-000039 — 1.01, 2.03, 9.01
- 2023-10-05 0000926326-23-000037 — 5.02, 9.01
- 2023-08-16 0000926326-23-000035 — 5.02
- 2023-08-10 0000926326-23-000033 — 5.02, 9.01
- 2023-08-03 0000926326-23-000029 — 5.02, 9.01
- 2023-08-01 0000926326-23-000027 — 2.02, 9.01
- 2023-07-11 0000926326-23-000025 — 5.02, 9.01
- 2023-06-26 0000926326-23-000022 — 5.02 — amendment of 0001104659-23-026700
- 2023-05-30 0001104659-23-066011 — 5.02, 9.01
- 2023-05-26 0000926326-23-000020 — 5.02, 5.07, 9.01
- 2023-05-15 0001104659-23-060768 — 5.02, 9.01
- 2023-05-02 0000926326-23-000011 — 2.02, 9.01
- 2023-04-03 0000926326-23-000009 — 1.01, 2.03, 9.01
- 2023-02-28 0001104659-23-026700 — 2.02, 2.05, 5.02, 9.01
- 2022-11-30 0000926326-22-000036 — 2.05
- 2022-11-02 0000926326-22-000031 — 2.02, 9.01
- 2022-10-21 0000926326-22-000029 — 5.03, 9.01
- 2022-09-20 0001104659-22-101566 — 7.01, 9.01
- 2022-09-20 0001104659-22-101360 — 7.01, 9.01
- 2022-08-04 0000926326-22-000025 — 2.02, 8.01, 9.01
- 2022-05-31 0000926326-22-000020 — 5.02, 5.07, 9.01
- 2022-05-24 0000926326-22-000016 — 5.02
- 2022-05-09 0000926326-22-000012 — 8.01
- 2022-04-28 0000926326-22-000009 — 2.02, 9.01
- 2022-03-01 0001104659-22-028681 — 5.02, 8.01, 9.01
- 2022-02-14 0000926326-22-000004 — 2.02, 9.01
- 2022-01-04 0000926326-22-000002 — 7.01, 9.01
- 2021-12-29 0001104659-21-154294 — 7.01, 9.01
- 2021-12-13 0000926326-21-000039 — 8.01
- 2021-12-02 0000926326-21-000037 — 7.01, 9.01
- 2021-11-02 0000926326-21-000031 — 2.02, 9.01
- 2021-09-09 0000926326-21-000028 — 7.01, 9.01
- 2021-07-29 0000926326-21-000024 — 2.02, 9.01
- 2021-07-26 0000926326-21-000022 — 7.01, 9.01
- 2021-07-12 0000926326-21-000019 — 5.02, 9.01
- 2021-05-28 0000926326-21-000015 — 5.07
- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2024-02-28

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-24-000005:8k_2_02:1]
EX-99.1
2
exhibit991q4-23.htm
EX-99.1

[0000926326-24-000005:8k_2_02:2]
Document

[0000926326-24-000005:8k_2_02:3]
Exhibit 99.1

[0000926326-24-000005:8k_2_02:4]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Senior Vice President, Investor Relations |  | 4220 North Freeway |
| 650-435-3318 |  | Fort Worth, TX 76137 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0000926326-24-000005:8k_2_02:5]
Omnicell Announces Fiscal Year and Fourth Quarter 2023 Results

[0000926326-24-000005:8k_2_02:6]
Full Year 2023 GAAP Revenues of $1.147 billion

[0000926326-24-000005:8k_2_02:7]
Full Year 2023 GAAP net loss of $20 million and GAAP net loss per diluted share of $0.45

[0000926326-24-000005:8k_2_02:8]
Full Year 2023 Non-GAAP EBITDA of $138 million and Non-GAAP net income per diluted share of $1.91

[0000926326-24-000005:8k_2_02:9]
Full Year 2023 Net Cash Provided by Operating Activities of $181 million

[0000926326-24-000005:8k_2_02:10]
Full Year 2023 Non-GAAP Free Cash Flow of $126 million

[0000926326-24-000005:8k_2_02:11]
FORT WORTH, Texas. -- February 8, 2024 -- Omnicell, Inc. (NASDAQ:OMCL) (“Omnicell,” “we,” “our,” “us,” “management,” or the “Company”), a leader in transforming the pharmacy care delivery model, today announced results for its fiscal year and fourth quarter ended December 31, 2023.

[0000926326-24-000005:8k_2_02:12]
Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell, said, “Our team delivered 2023 financial results that were generally in line with what we originally anticipated for the year. We are enthusiastic about our robust innovation pipeline, particularly around our XT fleet of connected devices. We believe the Company is uniquely positioned to capture incremental market share as hospital cost pressures are expected to alleviate and as the macroeconomic environment is anticipated to improve. However, we recognize we have work to do to strengthen our performance and accelerate profitability. To that end, we are undertaking a holistic review of our business to determine how we can best optimize our investments in an effort to deliver strong returns for our stockholders. We remain confident in Omnicell’s long-term opportunities as we work to transform the pharmacy care delivery model and ultimately help enable healthcare providers to deliver better outcomes around patient safety and overall efficiencies.”

[0000926326-24-000005:8k_2_02:13]
Financial Results

[0000926326-24-000005:8k_2_02:14]
Total GAAP revenues for the fourth quarter of 2023 were $259 million, down $39 million, or 13%, from the fourth quarter of 2022. Total GAAP revenues for the year ended December 31, 2023 were $1.147 billion, down $149 million, or 11%, from the year ended December 31, 2022. The quarter-over-quarter and year-over-year decrease in total GAAP revenues reflects lower Point of Care revenues primarily as a result of ongoing healthcare systems’ capital budget and labor constraints.

[0000926326-24-000005:8k_2_02:15]
Total GAAP net loss for the fourth quarter 2023 was $14 million, or $0.32 per diluted share. This compares to GAAP net loss of $28 million, or $0.64 per diluted share, for the fourth quarter of 2022. Total GAAP net loss for the year ended December 31, 2023 was $20 million, or $0.45 per diluted share. This compares to GAAP net income of $6 million, or $0.12 per diluted share, for the year ended December 31, 2022.

[0000926326-24-000005:8k_2_02:16]
Total non-GAAP net income for both the fourth quarter of 2023 and the fourth quarter of 2022 was $15 million, or $0.33 per diluted share. Total non-GAAP net income for the year ended December 31, 2023 was $87 million, or $1.91 per diluted share. This compares to non-GAAP net income of $136 million, or $3.00 per diluted share, for the year ended December 31, 2022.

[0000926326-24-000005:8k_2_02:17]
Total non-GAAP EBITDA for the fourth quarter of 2023 was $24 million. This compares to non-GAAP EBITDA of $26 million for the fourth quarter of 2022. Total non-GAAP EBITDA for the year ended December 31, 2023 was $138 million. This compares to non-GAAP EBITDA of $193 million for the year ended December 31, 2022.

[0000926326-24-000005:8k_2_02:18]
Bookings and Backlog

[0000926326-24-000005:8k_2_02:19]
Total bookings (1) for the year ended December 31, 2023 were $854 million compared to $1.054 billion for the year ended December 31, 2022, or a decrease of 19% year-over-year, primarily driven by lower-than-expected orders for our Advanced Services, particularly our technology-enabled services, which include Central Pharmacy Dispensing Service and IV Compounding Service.

[0000926326-24-000005:8k_2_02:20]
Total backlog (2) for the years ended December 31, 2023 and 2022 was as follows:

[0000926326-24-000005:8k_2_02:21]
|  | December 31, |
|  | 2023 |  | 2022 |
|  | (In thousands) |
| Total backlog | $ | 1,142,686 |  |  | $ | 1,215,462 |  |
| By type: |  |  |  |
| Product backlog | $ | 610,832 |  |  | $ | 796,967 |  |
| Advanced Services backlog (3) | $ | 531,854 |  |  | $ | 418,495 |  |
| By duration and type: |  |  |  |
| Short-term product backlog | $ | 377,936 |  |  | $ | 503,303 |  |
| Long-term product backlog | $ | 232,896 |  |  | $ | 293,664 |  |
| Short-term Advanced Services backlog (3) | $ | 72,455 |  |  | $ | 49,567 |  |
| Long-term Advanced Services backlog (3) | $ | 459,399 |  |  | $ | 368,928 |  |

[0000926326-24-000005:8k_2_02:22]
_________________________________________________

[0000926326-24-000005:8k_2_02:23]
(1)    We define bookings generally as: (i) the value of non-cancelable contracts for our connected devices, software products, and Advanced Services (although, for those Advanced Services contracts without a minimum commitment, bookings only include the amount of revenue that has been recognized once the services have been provided); and (ii) for our consumables, the value of orders placed through our Omnicell Storefront online platform or through written or telephonic orders. We typically exclude technical services and other less significant items ancillary to our products and services, such as freight revenue from bookings. In addition, dependent upon counterparty or credit risk, which is evaluated at the time of contract signing, for a given multi-year subscription contract we may reduce the portion of the contractual commitment booked at a given time. We utilize bookings as an indicator of the success of our business.

[0000926326-24-000005:8k_2_02:24]
(2)    Backlog is the dollar amount of bookings that have not yet been recognized as revenue. Bookings for those Advanced Services contracts without a minimum commitment are not included in backlog. In addition, dependent upon counterparty or credit risk, which is evaluated at the time of contract signing, for a given multi-year subscription contract we may reduce the portion of the contractual commitment booked at a given time, and these excluded amounts are not included in backlog. A majority of our connected devices and software license products are installable and recognized as revenues within twelve months of booking. Larger or more complex implementations such as software-enable connected devices for Central Pharmacy, including but not limited to our Central Pharmacy Dispensing Service and IV Compounding Service, are often installed and recognized as revenue between 12 and 24 months after booking. Service revenues from Advanced Services are recorded over the contractual term. A majority of our connected devices and software license products are installable and recognized as revenues within twelve months of booking, while service revenues from Advanced Services are recorded over the contractual term. We consider backlog that is expected to be converted to revenues in more than twelve months to be long-term backlog. We believe a majority of long-term product backlog will be convertible into revenues in 12-24 months. Long-term Advanced Services backlog typically represents multi-year subscription agreements (usually with contractual terms of 2-7 years, some of which have not yet been implemented) that will be converted to revenue ratably over the contractual term. Due to industry practice that allows customers to change order configurations with limited advance notice prior to shipment and as customer installation schedules may change, backlog as of any particular date may not necessarily indicate the timing of future revenue. However, we do believe that backlog is an indication of a customer’s willingness to install our solutions and revenue we expect to generate over time.

[0000926326-24-000005:8k_2_02:25]
(3)    Includes only the value of Advanced Services non-cancelable contracts with minimum commitments.

[0000926326-24-000005:8k_2_02:26]
Balance Sheet

[0000926326-24-000005:8k_2_02:27]
As of December 31, 2023, Omnicell’s balance sheet reflected cash and cash equivalents of $468 million, total debt (net of unamortized debt issuance costs) of $570 million, and total assets of $2.23 billion. Cash flows provided by operating activities in the fourth quarter of 2023 totaled $38 million. This compares to cash flows provided by operating activities totaling $82 million in the fourth quarter of 2022.

[0000926326-24-000005:8k_2_02:28]
As of December 31, 2023, the Company had $350 million of availability under its revolving credit facility with no outstanding balance.

[0000926326-24-000005:8k_2_02:29]
2024 Guidance

[0000926326-24-000005:8k_2_02:30]
For the full year 2024, the Company expects bookings to be between $750 million and $875 million. The Company expects full year 2024 total revenues to be between $1.045 billion and $1.120 billion. The Company expects full year 2024 product revenues to be between $605 million and $650 million, and full year 2024 service revenues to be between $440 million and $470 million. The Company expects full year 2024 technical services revenues to be between $220 million and $235 million, and full year 2024 Advanced Services revenues to be between $220 million and $235 million. The Company expects full year 2024 non-GAAP EBITDA to be between $90 million and $120 million. The Company expects full year 2024 non-GAAP earnings per share to be between $0.90 and $1.40 per share.

[0000926326-24-000005:8k_2_02:31]
For the first quarter of 2024, the Company expects total revenues to be between $232 million and $242 million. The Company expects first quarter 2024 product revenues to be between $128 million and $133 million, and first quarter 2024 service revenues to be between $104 million and $109 million. The Company expects first quarter 2024 non-GAAP EBITDA to be between ($2) million and $4 million. The Company expects first quarter 2024 non-GAAP earnings per share to be between a net loss of ($0.10) and breakeven per share.

[0000926326-24-000005:8k_2_02:32]
The table below summarizes Omnicell’s 2024 guidance outlined above.

[0000926326-24-000005:8k_2_02:33]
|  | Q1 2024 |  | 2024 |
| Bookings | Not provided |  | $750 million - $875 million |
| Total Revenues | $232 million - $242 million |  | $1.045 billion - $1.120 billion |
| Product Revenues | $128 million - $133 million |  | $605 million - $650 million |
| Service Revenues | $104 million - $109 million |  | $440 million - $470 million |
| Technical Services Revenues | Not provided |  | $220 million - $235 million |
| Advanced Services Revenues | Not provided |  | $220 million - $235 million |
| Non-GAAP EBITDA | ($2) million - $4 million |  | $90 million - $120 million |
| Non-GAAP Earnings Per Share | ($0.10) - $0.00 |  | $0.90 - $1.40 |

[0000926326-24-000005:8k_2_02:34]
The Company does not provide guidance for GAAP net income or GAAP earnings per share, nor a reconciliation of these forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures on a forward-looking basis because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These forward-looking non-GAAP financial measures do not include certain items, which may be significant, including, but not limited to, unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-24-000005:8k_2_02:35]
Omnicell Conference Call Information

[0000926326-24-000005:8k_2_02:36]
Omnicell will hold a conference call today, Thursday, February 8, 2024 at 8:30 a.m. ET to discuss fourth quarter and year end 2023 financial results. The conference call can be monitored by dialing (888) 550-5424 in the U.S. or (646) 960-0819 in international locations. The Conference ID is 9581556. A link to the live and archived webcast will also be available on the Investor Relations section of Omnicell’s website at https://ir.omnicell.com/events-and-presentations.

[0000926326-24-000005:8k_2_02:37]
________________________________________________

[0000926326-24-000005:8k_2_02:38]
About Omnicell

[0000926326-24-000005:8k_2_02:39]
Since 1992, Omnicell has been committed to transforming pharmacy care through outcomes-centric innovation designed to optimize clinical and business outcomes across all settings of care. Through a comprehensive portfolio of robotics, smart devices, intelligent software, and expert services, Omnicell solutions are helping healthcare facilities worldwide to reduce costs, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry vision of the Autonomous Pharmacy. To learn more, visit omnicell.com.

[0000926326-24-000005:8k_2_02:40]
From time to time, Omnicell may use the Company’s investor relations website and other online social media channels, including its Twitter handle www.twitter.com/omnicell, LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure (“Reg FD”).

[0000926326-24-000005:8k_2_02:41]
OMNICELL and the Omnicell logo are registered trademarks of Omnicell, Inc. or one of its subsidiaries.

[0000926326-24-000005:8k_2_02:42]
Forward-Looking Statements

[0000926326-24-000005:8k_2_02:43]
Use of Non-GAAP Financial Information

[0000926326-24-000005:8k_2_02:44]
This press release contains financial measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to revenues, gross profit, operating expenses, income from operations, net income, net income per diluted share, diluted shares, net cash provided by operating activities, or any

[0000926326-24-000005:8k_2_02:45]
4

[0000926326-24-000005:8k_2_02:46]
other performance measure derived in accordance with GAAP. We present these non-GAAP results and metrics because management considers them to be important supplemental measures of Omnicell’s performance and refers to such measures when analyzing Omnicell’s strategy and operations.

[0000926326-24-000005:8k_2_02:47]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within such period that directly drive operating income in such period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results: non-GAAP revenues excludes from its GAAP equivalent item a) below; non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items a), b), c), f), and g) below; non-GAAP operating expenses excludes from its GAAP equivalents items b), c), d), e), f), g), i), j) and k) below; non-GAAP income from operations and non-GAAP operating margin exclude from their GAAP equivalents items a), b), c), d), e), f), g), i), j) and k) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through k) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents items a), b), d), e), f), g), h), i), j) and k) below:

[0000926326-24-000005:8k_2_02:48]
a)Acquisition accounting impact related to deferred revenues. In connection with the acquisition of FDS Amplicare, we recorded a fair value adjustment to acquired deferred revenues as part of the purchase accounting in accordance with GAAP. The adjustment represents revenues that would have been recognized in the normal course of business by FDS Amplicare if the acquisition had not occurred, but was not recognized due to GAAP purchase accounting requirements. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0000926326-24-000005:8k_2_02:49]
b)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as it represents expenses that do not require cash settlement from Omnicell.

[0000926326-24-000005:8k_2_02:50]
c)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-24-000005:8k_2_02:51]
d)Acquisition-related expenses. We excluded from our non-GAAP results the expenses related to recent acquisitions, including amortization of representations and warranties insurance. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of acquisition activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of less acquisitive peer companies.

[0000926326-24-000005:8k_2_02:52]
e)Impairment and abandonment of operating lease right-of-use and other assets related to facilities. We excluded from our non-GAAP results the impairment and abandonment of certain operating lease right-of-use assets, as well as property and equipment, incurred in connection with restructuring activities for optimization of certain leased facilities. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-24-000005:8k_2_02:53]
f)Ransomware-related expenses, net of insurance recoveries. We excluded from our non-GAAP results the net expenses related to the previously disclosed ransomware incident identified by the Company on May 4, 2022. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, and are presented net of expected insurance recoveries. These expenses are unrelated to our ongoing operations and would not have otherwise been incurred by us in the normal course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-24-000005:8k_2_02:54]
g)Severance-related expenses. We excluded from our non-GAAP results the expenses related to restructuring events, partially offset by reversals of previously recognized severance expenses in subsequent periods. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful

[0000926326-24-000005:8k_2_02:55]
comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-24-000005:8k_2_02:56]
h)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of term loan and revolving credit facilities, as well as the issuance of convertible senior notes. The costs include underwriting fees, original issue discount, ticking fees, and legal fees. These non-cash expenses are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-24-000005:8k_2_02:57]
i)Executive transition costs. We excluded from our non-GAAP results the executives transition costs associated with the departure of certain executive officers, primarily consisting of severance expenses. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-24-000005:8k_2_02:58]
j)Impairment of certain long-lived assets. We excluded from our non-GAAP results the impairment charges of long-lived assets related to the anticipated reorganization of certain product lines. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-24-000005:8k_2_02:59]
k)Certain litigation costs. We excluded non-recurring charges and benefits, including litigation expenses and settlements, related to litigation matters that are outside of the ordinary course of our business or that are not representative of those that we historically have incurred. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-24-000005:8k_2_02:60]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving stock compensation plans or other items.

[0000926326-24-000005:8k_2_02:61]
We believe that the presentation of non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0000926326-24-000005:8k_2_02:62]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-24-000005:8k_2_02:63]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-24-000005:8k_2_02:64]
c)These non-GAAP financial measures are employed by management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting.

[0000926326-24-000005:8k_2_02:65]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-24-000005:8k_2_02:66]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-24-000005:8k_2_02:67]
i)While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-24-000005:8k_2_02:68]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-24-000005:8k_2_02:69]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0000926326-24-000005:8k_2_02:70]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-24-000005:8k_2_02:71]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-24-000005:8k_2_02:72]
a)Omnicell’s equity incentive plans and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-24-000005:8k_2_02:73]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-24-000005:8k_2_02:74]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-24-000005:8k_2_02:75]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release as well as in Omnicell’s other reports filed with or furnished to the SEC.

[0000926326-24-000005:8k_2_02:76]
Omnicell, Inc.

[0000926326-24-000005:8k_2_02:77]
Condensed Consolidated Statements of Operations

[0000926326-24-000005:8k_2_02:78]
(Unaudited, in thousands, except per share data)

[0000926326-24-000005:8k_2_02:79]
|  | Three Months Ended December 31, |  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 145,655 |  |  | $ | 196,976 |  |  | $ | 708,561 |  |  | $ | 903,222 |  |
| Services and other revenues | 113,192 |  |  | 100,698 |  |  | 438,551 |  |  | 392,725 |  |
| Total revenues | 258,847 |  |  | 297,674 |  |  | 1,147,112 |  |  | 1,295,947 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 90,306 |  |  | 119,451 |  |  | 414,106 |  |  | 493,626 |  |
| Cost of services and other revenues | 63,137 |  |  | 56,470 |  |  | 236,166 |  |  | 213,334 |  |
| Total cost of revenues | 153,443 |  |  | 175,921 |  |  | 650,272 |  |  | 706,960 |  |
| Gross profit | 105,404 |  |  | 121,753 |  |  | 496,840 |  |  | 588,987 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 26,819 |  |  | 28,413 |  |  | 97,115 |  |  | 104,969 |  |
| Selling, general, and administrative | 101,950 |  |  | 131,697 |  |  | 434,593 |  |  | 486,341 |  |
| Total operating expenses | 128,769 |  |  | 160,110 |  |  | 531,708 |  |  | 591,310 |  |
| Loss from operations | (23,365) |  |  | (38,357) |  |  | (34,868) |  |  | (2,323) |  |
| Interest and other income (expense), net | 4,848 |  |  | 2,843 |  |  | 14,760 |  |  | (130) |  |
| Loss before income taxes | (18,517) |  |  | (35,514) |  |  | (20,108) |  |  | (2,453) |  |
| Provision for (benefit from) income taxes | (4,142) |  |  | (7,106) |  |  | 263 |  |  | (8,101) |  |
| Net income (loss) | $ | (14,375) |  |  | $ | (28,408) |  |  | $ | (20,371) |  |  | $ | 5,648 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.32) |  |  | $ | (0.64) |  |  | $ | (0.45) |  |  | $ | 0.13 |  |
| Diluted | $ | (0.32) |  |  | $ | (0.64) |  |  | $ | (0.45) |  |  | $ | 0.12 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 45,495 |  |  | 44,678 |  |  | 45,212 |  |  | 44,398 |  |
| Diluted | 45,495 |  |  | 44,678 |  |  | 45,212 |  |  | 45,891 |  |

[0000926326-24-000005:8k_2_02:80]
8

[0000926326-24-000005:8k_2_02:81]
Omnicell, Inc.

[0000926326-24-000005:8k_2_02:82]
Condensed Consolidated Balance Sheets

[0000926326-24-000005:8k_2_02:83]
(Unaudited, in thousands)

[0000926326-24-000005:8k_2_02:84]
|  | December 31, |
|  | 2023 |  | 2022 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 467,972 |  |  | $ | 330,362 |  |
| Accounts receivable and unbilled receivables, net | 252,025 |  |  | 299,469 |  |
| Inventories | 110,099 |  |  | 147,549 |  |
| Prepaid expenses | 25,966 |  |  | 27,070 |  |
| Other current assets | 71,509 |  |  | 77,362 |  |
| Total current assets | 927,571 |  |  | 881,812 |  |
| Property and equipment, net | 108,601 |  |  | 93,961 |  |
| Long-term investment in sales-type leases, net | 42,954 |  |  | 32,924 |  |
| Operating lease right-of-use assets | 24,988 |  |  | 38,052 |  |
| Goodwill | 735,810 |  |  | 734,274 |  |
| Intangible assets, net | 211,173 |  |  | 242,906 |  |
| Long-term deferred tax assets | 32,901 |  |  | 22,329 |  |
| Prepaid commissions | 52,414 |  |  | 59,483 |  |
| Other long-term assets | 90,466 |  |  | 105,017 |  |
| Total assets | $ | 2,226,878 |  |  | $ | 2,210,758 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 45,028 |  |  | $ | 63,389 |  |
| Accrued compensation | 51,754 |  |  | 73,455 |  |
| Accrued liabilities | 149,276 |  |  | 172,655 |  |
| Deferred revenues, net | 121,734 |  |  | 118,947 |  |
| Total current liabilities | 367,792 |  |  | 428,446 |  |
| Long-term deferred revenues | 58,622 |  |  | 37,385 |  |
| Long-term deferred tax liabilities | 1,620 |  |  | 2,095 |  |
| Long-term operating lease liabilities | 33,910 |  |  | 39,405 |  |
| Other long-term liabilities | 6,318 |  |  | 6,719 |  |
| Convertible senior notes, net | 569,662 |  |  | 566,571 |  |
| Total liabilities | 1,037,924 |  |  | 1,080,621 |  |
| Total stockholders’ equity | 1,188,954 |  |  | 1,130,137 |  |
| Total liabilities and stockholders’ equity | $ | 2,226,878 |  |  | $ | 2,210,758 |  |

[0000926326-24-000005:8k_2_02:85]
Omnicell, Inc.

[0000926326-24-000005:8k_2_02:86]
Condensed Consolidated Statements of Cash Flows

[0000926326-24-000005:8k_2_02:87]
(Unaudited, in thousands)

[0000926326-24-000005:8k_2_02:88]
|  | Year Ended December 31, |
|  | 2023 |  | 2022 |
| Operating Activities |  |  |  |
| Net income (loss) | $ | (20,371) |  |  | $ | 5,648 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 87,319 |  |  | 86,931 |  |
| Loss on disposal of property and equipment | 2,572 |  |  | 678 |  |
| Share-based compensation expense | 55,300 |  |  | 68,247 |  |
| Deferred income taxes | (11,047) |  |  | (37,316) |  |
| Amortization of operating lease right-of-use assets | 8,239 |  |  | 12,238 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | 9,998 |  |  | 9,382 |  |
| Impairment of internal-use and external-use software development costs, net | — |  |  | 1,275 |  |
| Impairment of certain long-lived assets | 1,014 |  |  | — |  |
| Amortization of debt issuance costs | 4,397 |  |  | 4,164 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | 49,150 |  |  | (60,357) |  |
| Inventories | 38,016 |  |  | (30,115) |  |
| Prepaid expenses | 1,149 |  |  | (4,671) |  |
| Other current assets | (6,821) |  |  | 6,360 |  |
| Investment in sales-type leases | (10,411) |  |  | (15,354) |  |
| Prepaid commissions | 7,069 |  |  | 4,312 |  |
| Other long-term assets | 2,111 |  |  | 5,027 |  |
| Accounts payable | (17,525) |  |  | (7,754) |  |
| Accrued compensation | (21,461) |  |  | 2,446 |  |
| Accrued liabilities | (10,343) |  |  | 16,651 |  |
| Deferred revenues | 24,058 |  |  | 24,469 |  |
| Operating lease liabilities | (10,918) |  |  | (13,781) |  |
| Other long-term liabilities | (401) |  |  | (699) |  |
| Net cash provided by operating activities | 181,094 |  |  | 77,781 |  |
| Investing Activities |  |  |  |
| External-use software development costs | (13,542) |  |  | (13,204) |  |
| Purchases of property and equipment | (41,474) |  |  | (47,536) |  |
| Business acquisition, net of cash acquired | — |  |  | (3,392) |  |
| Purchase price adjustments from business acquisitions | — |  |  | 5,463 |  |
| Net cash used in investing activities | (55,016) |  |  | (58,669) |  |
| Financing Activities |  |  |  |
| Payments for debt issuance costs for revolving credit facility | (2,967) |  |  | — |  |
| Proceeds from issuances under stock-based compensation plans | 23,216 |  |  | 40,182 |  |
| Employees’ taxes paid related to restricted stock units | (7,366) |  |  | (13,506) |  |
| Stock repurchases | — |  |  | (52,210) |  |
| Change in customer funds, net | 10,537 |  |  | 4,581 |  |
| Net cash provided by (used in) financing activities | 23,420 |  |  | (20,953) |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,354) |  |  | (944) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | 148,144 |  |  | (2,785) |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 352,835 |  |  | 355,620 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 500,979 |  |  | $ | 352,835 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |  |  |  |
| Cash and cash equivalents | $ | 467,972 |  |  | $ | 330,362 |  |
| Restricted cash included in other current assets | 33,007 |  |  | 22,473 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 500,979 |  |  | $ | 352,835 |  |

[0000926326-24-000005:8k_2_02:89]
10

[0000926326-24-000005:8k_2_02:90]
Omnicell, Inc.

[0000926326-24-000005:8k_2_02:91]
Reconciliation of GAAP to Non-GAAP

[0000926326-24-000005:8k_2_02:92]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-24-000005:8k_2_02:93]
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Reconciliation of GAAP revenues to non-GAAP revenues: |  |  |  |  |  |
| GAAP revenues | $ | 258,847 |  |  | $ | 297,674 |  |  | $ | 1,147,112 |  |  | $ | 1,295,947 |  |
|  | Acquisition accounting impact related to deferred revenues | — |  |  | 40 |  |  | — |  |  | 903 |  |
| Non-GAAP revenues | $ | 258,847 |  |  | $ | 297,714 |  |  | $ | 1,147,112 |  |  | $ | 1,296,850 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit | $ | 105,404 |  |  | $ | 121,753 |  |  | $ | 496,840 |  |  | $ | 588,987 |  |
| GAAP gross margin | 40.7% |  | 40.9% |  | 43.3% |  | 45.4% |
|  | Share-based compensation expense | 1,799 |  |  | 2,460 |  |  | 8,288 |  |  | 9,067 |  |
|  | Amortization of acquired intangibles | 2,607 |  |  | 3,115 |  |  | 11,165 |  |  | 13,204 |  |
|  | Acquisition accounting impact related to deferred revenues | — |  |  | 40 |  |  | — |  |  | 903 |  |
|  | Ransomware-related expenses, net of insurance recoveries | — |  |  | — |  |  | — |  |  | 317 |  |
|  | Severance-related expenses, net of reversals | 2,987 |  |  | 7,418 |  |  | 3,089 |  |  | 8,018 |  |
| Non-GAAP gross profit | $ | 112,797 |  |  | $ | 134,786 |  |  | $ | 519,382 |  |  | $ | 620,496 |  |
| Non-GAAP gross margin | 43.6% |  | 45.3% |  | 45.3% |  | 47.8% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 128,769 |  |  | $ | 160,110 |  |  | $ | 531,708 |  |  | $ | 591,310 |  |
| GAAP operating expenses % to total revenues | 49.7% |  | 53.8% |  | 46.4% |  | 45.6% |
|  | Share-based compensation expense | (10,388) |  |  | (15,056) |  |  | (47,012) |  |  | (59,180) |  |
|  | Amortization of acquired intangibles | (5,007) |  |  | (5,319) |  |  | (20,409) |  |  | (21,873) |  |
|  | Acquisition-related expenses | (244) |  |  | (246) |  |  | (982) |  |  | (2,155) |  |
|  | Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) | (1,587) |  |  | (3,992) |  |  | (10,007) |  |  | (9,382) |  |
|  | Impairment of certain long-lived assets | (1,610) |  |  | — |  |  | (1,610) |  |  | — |  |
|  | Ransomware-related expenses, net of insurance recoveries | 624 |  |  | (73) |  |  | 808 |  |  | (2,157) |  |
|  | Executive transition costs | — |  |  | — |  |  | (2,189) |  |  | — |  |
|  | Severance-related, net of reversals, and other expenses (b) | (7,098) |  |  | (11,364) |  |  | (12,450) |  |  | (16,785) |  |
| Non-GAAP operating expenses | $ | 103,459 |  |  | $ | 124,060 |  |  | $ | 437,857 |  |  | $ | 479,778 |  |
| Non-GAAP operating expenses as a % of total non-GAAP revenues | 40.0% |  | 41.7% |  | 38.2% |  | 37.0% |
| Reconciliation of GAAP loss from operations to non-GAAP income from operations: |
| GAAP loss from operations | $ | (23,365) |  |  | $ | (38,357) |  |  | $ | (34,868) |  |  | $ | (2,323) |  |
| GAAP operating loss % to total revenues | (9.0)% |  | (12.9)% |  | (3.0)% |  | (0.2)% |
|  | Share-based compensation expense | 12,187 |  |  | 17,516 |  |  | 55,300 |  |  | 68,247 |  |
|  | Amortization of acquired intangibles | 7,614 |  |  | 8,434 |  |  | 31,574 |  |  | 35,077 |  |
|  | Acquisition accounting impact related to deferred revenues | — |  |  | 40 |  |  | — |  |  | 903 |  |
|  | Acquisition-related expenses | 244 |  |  | 246 |  |  | 982 |  |  | 2,155 |  |
|  | Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) | 1,587 |  |  | 3,992 |  |  | 10,007 |  |  | 9,382 |  |
|  | Impairment of certain long-lived assets | 1,610 |  |  | — |  |  | 1,610 |  |  | — |  |
|  | Ransomware-related expenses, net of insurance recoveries | (624) |  |  | 73 |  |  | (808) |  |  | 2,474 |  |
|  | Executive transition costs | — |  |  | — |  |  | 2,189 |  |  | — |  |
|  | Severance-related, net of reversals, and other expenses (b) | 10,085 |  |  | 18,782 |  |  | 15,539 |  |  | 24,803 |  |
| Non-GAAP income from operations | $ | 9,338 |  |  | $ | 10,726 |  |  | $ | 81,525 |  |  | $ | 140,718 |  |
| Non-GAAP operating margin (non-GAAP operating income as a % of total non-GAAP revenues) | 3.6% |  | 3.6% |  | 7.1% |  | 10.9% |

[0000926326-24-000005:8k_2_02:94]
Omnicell, Inc.

[0000926326-24-000005:8k_2_02:95]
Reconciliation of GAAP to Non-GAAP

[0000926326-24-000005:8k_2_02:96]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-24-000005:8k_2_02:97]
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |  |  |  |  |  |
| GAAP net income (loss) | $ | (14,375) |  |  | $ | (28,408) |  |  | $ | (20,371) |  |  | $ | 5,648 |  |
|  | Share-based compensation expense | 12,187 |  |  | 17,516 |  |  | 55,300 |  |  | 68,247 |  |
|  | Amortization of acquired intangibles | 7,614 |  |  | 8,434 |  |  | 31,574 |  |  | 35,077 |  |
|  | Acquisition accounting impact related to deferred revenues | — |  |  | 40 |  |  | — |  |  | 903 |  |
|  | Acquisition-related expenses | 244 |  |  | 246 |  |  | 982 |  |  | 2,155 |  |
|  | Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) | 1,587 |  |  | 3,992 |  |  | 10,007 |  |  | 9,382 |  |
|  | Impairment of certain long-lived assets | 1,610 |  |  | — |  |  | 1,610 |  |  | — |  |
|  | Ransomware-related expenses, net of insurance recoveries | (624) |  |  | 73 |  |  | (808) |  |  | 2,474 |  |
|  | Executive transition costs | — |  |  | — |  |  | 2,189 |  |  | — |  |
|  | Severance-related, net of reversals, and other expenses (b) | 10,085 |  |  | 18,782 |  |  | 15,539 |  |  | 24,803 |  |
|  | Amortization of debt issuance costs | 1,258 |  |  | 1,043 |  |  | 4,397 |  |  | 4,164 |  |
|  | Tax effect of the adjustments above (c) | (4,573) |  |  | (6,848) |  |  | (13,754) |  |  | (16,582) |  |
| Non-GAAP net income | $ | 15,013 |  |  | $ | 14,870 |  |  | $ | 86,665 |  |  | $ | 136,271 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |  |  |
| Shares - diluted GAAP | 45,495 |  |  | 44,678 |  |  | 45,212 |  |  | 45,891 |  |
| Shares - diluted non-GAAP (d) | 45,532 |  |  | 44,993 |  |  | 45,439 |  |  | 45,417 |  |
| GAAP net income (loss) per share - diluted | $ | (0.32) |  |  | $ | (0.64) |  |  | $ | (0.45) |  |  | $ | 0.12 |  |
|  | Share-based compensation expense | 0.26 |  |  | 0.39 |  |  | 1.22 |  |  | 1.51 |  |
|  | Amortization of acquired intangibles | 0.17 |  |  | 0.19 |  |  | 0.69 |  |  | 0.77 |  |
|  | Acquisition accounting impact related to deferred revenues | — |  |  | 0.00 |  |  | — |  |  | 0.02 |  |
|  | Acquisition-related expenses | 0.01 |  |  | 0.01 |  |  | 0.02 |  |  | 0.05 |  |
|  | Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) | 0.03 |  |  | 0.09 |  |  | 0.22 |  |  | 0.21 |  |
|  | Impairment of certain long-lived assets | 0.04 |  |  | — |  |  | 0.04 |  |  | — |  |
|  | Ransomware-related expenses, net of insurance recoveries | (0.01) |  |  | 0.00 |  |  | (0.02) |  |  | 0.05 |  |
|  | Executive transition costs | — |  |  | — |  |  | 0.05 |  |  | — |  |
|  | Severance-related, net of reversals, and other expenses (b) | 0.22 |  |  | 0.42 |  |  | 0.34 |  |  | 0.55 |  |
|  | Amortization of debt issuance costs | 0.03 |  |  | 0.02 |  |  | 0.10 |  |  | 0.09 |  |
|  | Non-GAAP dilutive shares impact from convertible note hedge transaction (d) | — |  |  | — |  |  | — |  |  | 0.00 |  |
|  | Tax effect of the adjustments above (c) | (0.10) |  |  | (0.15) |  |  | (0.30) |  |  | (0.37) |  |
| Non-GAAP net income per share - diluted | $ | 0.33 |  |  | $ | 0.33 |  |  | $ | 1.91 |  |  | $ | 3.00 |  |

[0000926326-24-000005:8k_2_02:98]
12

[0000926326-24-000005:8k_2_02:99]
| Omnicell, Inc. |
| Reconciliation of GAAP to Non-GAAP |
| (Unaudited, in thousands, except per share data and percentage) |
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Reconciliation of GAAP net income (loss) to non-GAAP EBITDA (e): |  |  |  |  |  |
| GAAP net income (loss) | $ | (14,375) |  |  | $ | (28,408) |  |  | $ | (20,371) |  |  | $ | 5,648 |  |
|  | Share-based compensation expense | 12,187 |  |  | 17,516 |  |  | 55,300 |  |  | 68,247 |  |
|  | Interest (income) and expense, net | (5,811) |  |  | (2,410) |  |  | (18,542) |  |  | (3,721) |  |
|  | Depreciation and amortization expense | 21,723 |  |  | 22,088 |  |  | 87,319 |  |  | 86,931 |  |
|  | Acquisition accounting impact related to deferred revenues | — |  |  | 40 |  |  | — |  |  | 903 |  |
|  | Acquisition-related expenses | 244 |  |  | 246 |  |  | 982 |  |  | 2,155 |  |
|  | Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) | 1,587 |  |  | 3,992 |  |  | 10,007 |  |  | 9,382 |  |
|  | Impairment of certain long-lived assets | 1,610 |  |  | — |  |  | 1,610 |  |  | — |  |
|  | Ransomware-related expenses, net of insurance recoveries | (624) |  |  | 73 |  |  | (808) |  |  | 2,474 |  |
|  | Executive transition costs | — |  |  | — |  |  | 2,189 |  |  | — |  |
|  | Severance-related, net of reversals, and other expenses (b) | 10,085 |  |  | 18,782 |  |  | 15,539 |  |  | 24,803 |  |
|  | Amortization of debt issuance costs | 1,258 |  |  | 1,043 |  |  | 4,397 |  |  | 4,164 |  |
|  | Provision for (benefit from) income taxes | (4,142) |  |  | (7,106) |  |  | 263 |  |  | (8,101) |  |
| Non-GAAP EBITDA | $ | 23,742 |  |  | $ | 25,856 |  |  | $ | 137,885 |  |  | $ | 192,885 |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA as a % of total non-GAAP revenues) | 9.2% |  | 8.7% |  | 12.0% |  | 14.9% |
| Reconciliation of GAAP net cash provided by operating activities to non-GAAP free cash flow: |  |
| GAAP net cash provided by operating activities | $ | 38,414 |  |  | $ | 82,153 |  |  | $ | 181,094 |  |  | $ | 77,781 |  |
|  | External-use software development costs | (3,302) |  |  | (3,556) |  |  | (13,542) |  |  | (13,204) |  |
|  | Purchases of property and equipment | (9,070) |  |  | (13,675) |  |  | (41,474) |  |  | (47,536) |  |
| Non-GAAP free cash flow | $ | 26,042 |  |  | $ | 64,922 |  |  | $ | 126,078 |  |  | $ | 17,041 |  |

[0000926326-24-000005:8k_2_02:100]
_________________________________________________

[0000926326-24-000005:8k_2_02:101]
(a)For the year ended December 31, 2023, impairment charges of other assets were approximately $0.6 million related to property and equipment in connection with restructuring activities for optimization of certain leased facilities.

[0000926326-24-000005:8k_2_02:102]
(b)For the three months and year ended December 31, 2022, other expenses included approximately $1.3 million and $2.0 million of certain litigation costs, respectively.

[0000926326-24-000005:8k_2_02:103]
(c)Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2023 and 2022.

[0000926326-24-000005:8k_2_02:104]
(d)For the year ended December 31, 2022, non-GAAP diluted shares exclude approximately 0.5 million shares related to the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction.

[0000926326-24-000005:8k_2_02:105]
(e)Defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments.
