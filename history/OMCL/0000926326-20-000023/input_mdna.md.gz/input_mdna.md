# OMCL MD&A — 0000926326-20-000023


## mdna

[0000926326-20-000023:mdna:1]
[same as prior period, unchanged from 0000926326-20-000014:mdna:1]

[0000926326-20-000023:mdna:2]
[same as prior period, unchanged from 0000926326-20-000014:mdna:2]

[0000926326-20-000023:mdna:3]
•our expectations about the continuing impact of the ongoing global novel coronavirus (COVID-19) pandemic (including efforts to contain the spread of the pandemic) on our workforce and operations, as well as the continuing impacts on our customers and suppliers, and the anticipated continuing effects of the pandemic and associated containment measures on our business, financial condition, liquidity, and results of operations;

[0000926326-20-000023:mdna:4]
[same as prior period, unchanged from 0000926326-20-000014:mdna:4]

[0000926326-20-000023:mdna:5]
[same as prior period, unchanged from 0000926326-20-000014:mdna:5]

[0000926326-20-000023:mdna:6]
[same as prior period, unchanged from 0000926326-20-000014:mdna:6]

[0000926326-20-000023:mdna:7]
[same as prior period, unchanged from 0000926326-20-000014:mdna:7]

[0000926326-20-000023:mdna:8]
[same as prior period, unchanged from 0000926326-20-000014:mdna:8]

[0000926326-20-000023:mdna:9]
[same as prior period, unchanged from 0000926326-20-000014:mdna:9]

[0000926326-20-000023:mdna:10]
[same as prior period, unchanged from 0000926326-20-000014:mdna:10]

[0000926326-20-000023:mdna:11]
[same as prior period, unchanged from 0000926326-20-000014:mdna:11]

[0000926326-20-000023:mdna:12]
[same as prior period, unchanged from 0000926326-20-000014:mdna:12]

[0000926326-20-000023:mdna:13]
[same as prior period, unchanged from 0000926326-20-000014:mdna:13]

[0000926326-20-000023:mdna:14]
[same as prior period, unchanged from 0000926326-20-000014:mdna:14]

[0000926326-20-000023:mdna:15]
[same as prior period, unchanged from 0000926326-20-000014:mdna:15]

[0000926326-20-000023:mdna:16]
[same as prior period, unchanged from 0000926326-20-000014:mdna:16]

[0000926326-20-000023:mdna:17]
•the outcome of any legal proceedings to which we are a party;

[0000926326-20-000023:mdna:18]
[same as prior period, unchanged from 0000926326-20-000014:mdna:18]

[0000926326-20-000023:mdna:19]
[same as prior period, unchanged from 0000926326-20-000014:mdna:19]

[0000926326-20-000023:mdna:20]
[same as prior period, unchanged from 0000926326-20-000014:mdna:20]

[0000926326-20-000023:mdna:21]
[same as prior period, unchanged from 0000926326-20-000014:mdna:21]

[0000926326-20-000023:mdna:22]
[same as prior period, unchanged from 0000926326-20-000014:mdna:22]

[0000926326-20-000023:mdna:23]
[same as prior period, unchanged from 0000926326-20-000014:mdna:23]

[0000926326-20-000023:mdna:24]
[same as prior period, unchanged from 0000926326-20-000014:mdna:24]

[0000926326-20-000023:mdna:25]
[same as prior period, unchanged from 0000926326-20-000014:mdna:25]

[0000926326-20-000023:mdna:26]
[same as prior period, unchanged from 0000926326-20-000014:mdna:26]

[0000926326-20-000023:mdna:27]
[same as prior period, unchanged from 0000926326-20-000014:mdna:27]

[0000926326-20-000023:mdna:28]
[same as prior period, unchanged from 0000926326-20-000014:mdna:28]

[0000926326-20-000023:mdna:29]
Over 6,000 facilities worldwide use our automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 40,000 institutional and retail pharmacies across North America and the United Kingdom leverage our innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 89% and 90% of our total revenues for the three months ended June 30, 2020 and 2019, respectively, and 90% and 89% of our total revenues for the six months ended June 30, 2020 and 2019, respectively.

[0000926326-20-000023:mdna:30]
[same as prior period, unchanged from 0000926326-20-000014:mdna:30]

[0000926326-20-000023:mdna:31]
We utilize product bookings as an indicator of the success of our business. Product bookings consist of all firm orders, as evidenced generally by a non-cancelable contract and purchase order for equipment and software products, and by a purchase order for consumables. Equipment and software product bookings are generally installable within twelve months of booking,

[0000926326-20-000023:mdna:32]
and other than sales based on subscription services, generally recorded as revenue upon customer receipts of goods or acceptance of the installation.

[0000926326-20-000023:mdna:33]
In addition to product solution sales, we provide services to our customers. We provide installation planning and consulting as part of most product sales which is included in the initial price of the solution. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in increments of one to five years. As a result of the growth of our installed base of customers, our service revenues have also grown.

[0000926326-20-000023:mdna:34]
Our full-time headcount was approximately 2,780 and 2,700 on June 30, 2020 and December 31, 2019, respectively.

[0000926326-20-000023:mdna:35]
[same as prior period, unchanged from 0000926326-20-000014:mdna:35]

[0000926326-20-000023:mdna:36]
[same as prior period, unchanged from 0000926326-20-000014:mdna:36]

[0000926326-20-000023:mdna:37]
[same as prior period, unchanged from 0000926326-20-000014:mdna:37]

[0000926326-20-000023:mdna:38]
[same as prior period, unchanged from 0000926326-20-000014:mdna:38]

[0000926326-20-000023:mdna:39]
[same as prior period, unchanged from 0000926326-20-000014:mdna:39]

[0000926326-20-000023:mdna:40]
[same as prior period, unchanged from 0000926326-20-000014:mdna:40]

[0000926326-20-000023:mdna:41]
[same as prior period, unchanged from 0000926326-20-000014:mdna:41]

[0000926326-20-000023:mdna:42]
[same as prior period, unchanged from 0000926326-20-000014:mdna:42]

[0000926326-20-000023:mdna:43]
[same as prior period, unchanged from 0000926326-20-000014:mdna:43]

[0000926326-20-000023:mdna:44]
[same as prior period, unchanged from 0000926326-20-000014:mdna:44]

[0000926326-20-000023:mdna:45]
In March 2020, the COVID-19 outbreak was declared a global pandemic by the World Health Organization and a U.S national emergency. Efforts to contain the spread of COVID-19 continue, with the implementation of travel restrictions, shelter-in-place orders, business closures and suspensions, cancelled events, and social distancing. Countries and territories are in varying stages of restrictions and re-opening in response to the COVID-19 pandemic, and certain jurisdictions have begun re-opening only to return to restrictions due to increasing levels of COVID-19 cases.

[0000926326-20-000023:mdna:46]
Keeping in mind our role in the healthcare industry, we are continuing to closely monitor the COVID-19 pandemic. Our top priorities remain protecting the health and well-being of our customers, their patients, and our employees, while maintaining business continuity to meet the needs of our customers. In order to operate in a safe manner, we are following the health and safety guidelines of the U.S. Centers for Disease Control and Prevention, and local and state public health departments in each of the regions where we operate. All of our manufacturing, distribution, and other facilities are operating under these guidelines. Our manufacturing and distribution facilities have remained open due to our qualification as an essential business and to date, we have not experienced disruptions in our manufacturing activities. In addition to increased cleaning and disinfection processes at our manufacturing facilities, we continue to adhere to alternative scheduling procedures to enhance social distancing protocols. We have also procured and distributed personal protective equipment (“PPE”) to our customer-facing and manufacturing personnel consistent with guidelines we developed to help ensure proper distribution and use of such PPE. The vast majority of our non-manufacturing and non-customer facing personnel have transitioned to a work from home environment.

[0000926326-20-000023:mdna:47]
To support the needs of our customers on the frontline of the pandemic, during the first quarter of 2020, we launched a Rapid Response program to fast-track production and deployment of our XT Series automated dispensing systems to our customers. We streamlined our ordering and installation processes with preconfigured XT Series medication and supply dispensing systems designed to offer our customers flexibility and maximum emergency impact. We believe these models have ample capacity and flexibility to meet a wide variety of needs of our customers, while maintaining security, safety, and workflow efficiency. In addition, to minimize the need for on-site visits and respect social distancing protocols, we are providing remote service options, training programs, and product demonstrations for our customers, leveraging technology to enable our sales team to operate in a remote sales environment, as well as providing our customers with options to self-install certain automation products.

[0000926326-20-000023:mdna:48]
From a supply chain perspective, we are working closely with our vendors to help ensure we are able to source key components and maintain appropriate inventory levels to meet customer demand. Although we have not experienced disruptions in our supply chain to date, we cannot predict how long the pandemic and measures intended to contain the spread of COVID-19 will continue and what effect COVID-19 and the associated containment measures will have on our suppliers and vendors, in particular for any of our suppliers and vendors that may not qualify as essential businesses and suffer more significant disruptions to their business operations.

[0000926326-20-000023:mdna:49]
Health systems, particularly in areas experiencing higher levels of COVID-19 cases, continue to face increased costs due to large surge expenditures to cover COVID-19 caseload and increasing prices for needed equipment, decreased revenue due to cancelled or postponed elective procedures and other reduced demand, as well as cash flow challenges. We believe these financial pressures have led our customers to delay or defer purchasing decisions and/or implementation of our solutions and expect that our customers may continue such delays and deferrals for the near to medium-term future. Moreover, the COVID-19 pandemic and measures to contain its impact have caused material disruptions in both national and global financial markets and economies. During the second quarter of 2020, we continued to see some delays in product bookings and expect to see lower product bookings and revenues during the fiscal year 2020 compared to management’s expectations prior to the COVID-19 outbreak. Additionally, our ability to access hospitals in order to perform implementations of capital equipment has been delayed in some cases, as many hospitals are consumed with treating sick patients. While the environment continues to change rapidly, we are beginning to see more positive indicators for our business in terms of both product bookings and revenues. In many regions, elective surgeries have resumed, and we have been able to resume some on-site sales activities in regions less impacted by COVID-19. Additionally, the overall level of system implementations has also been increasing. Based on management's current expectations, we believe that the product bookings and revenues in the second quarter of 2020 represent the lowest quarter of 2020, and we expect that product bookings and revenues will increase sequentially through the third and fourth quarters of 2020. In response to the COVID-19 pandemic, we have implemented and continue to focus on cost reduction initiatives in all aspects of our business, including, but not limited to, reduced travel costs, decreases certain in employee-related expenses, negotiating discounts with vendors, and delayed hiring and capital expenditures. Furthermore, during the second quarter of 2020, in addition to continuing our previously announced organizational realignment initiative to further align our organizational infrastructure and operations with the strategic vision of the autonomous pharmacy, we initiated a restructuring plan to help mitigate the adverse impact of the COVID-19 pandemic on our business and financial results.

[0000926326-20-000023:mdna:50]
In addition, on March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was signed into law in response to the COVID-19 pandemic, and provides tax relief to businesses. The CARES Act includes deferral of certain payroll taxes, relief for retaining employees, and certain other provisions. Although the provisions of the CARES Act did not have a material impact on our income taxes, we are currently benefiting from the deferral of certain payroll taxes through the end of fiscal year 2020.

[0000926326-20-000023:mdna:51]
While our fiscal year 2020 results will be impacted by the challenges and opportunities brought on by the COVID-19 pandemic, we remain confident in the overall health of our business, in our ability to navigate through these unusual times, and

[0000926326-20-000023:mdna:52]
in our ability to continue to execute on our long-term strategy, as we believe our customers and potential customers are increasingly embracing the vision of a fully autonomous pharmacy. However, the full impact of the COVID-19 pandemic and related containment measures cannot be predicted and to date, the COVID-19 pandemic and related containment measures have adversely affected and we expect they may continue to adversely affect, perhaps materially, our business, results of operations, financial condition, and liquidity.

[0000926326-20-000023:mdna:53]
[same as prior period, unchanged from 0000926326-20-000014:mdna:53]

[0000926326-20-000023:mdna:54]
[same as prior period, unchanged from 0000926326-20-000014:mdna:54]

[0000926326-20-000023:mdna:55]
[same as prior period, unchanged from 0000926326-20-000014:mdna:55]

[0000926326-20-000023:mdna:56]
[same as prior period, unchanged from 0000926326-20-000014:mdna:56]

[0000926326-20-000023:mdna:57]
[same as prior period, unchanged from 0000926326-20-000014:mdna:57]

[0000926326-20-000023:mdna:58]
[same as prior period, unchanged from 0000926326-20-000014:mdna:58]

[0000926326-20-000023:mdna:59]
[same as prior period, unchanged from 0000926326-20-000014:mdna:59]

[0000926326-20-000023:mdna:60]
[same as prior period, unchanged from 0000926326-20-000014:mdna:60]

[0000926326-20-000023:mdna:61]
[same as prior period, unchanged from 0000926326-20-000014:mdna:61]

[0000926326-20-000023:mdna:62]
[same as prior period, unchanged from 0000926326-20-000014:mdna:62]

[0000926326-20-000023:mdna:63]
[same as prior period, unchanged from 0000926326-20-000014:mdna:63]

[0000926326-20-000023:mdna:64]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the six months ended June 30, 2020 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2019, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-20-000023:mdna:65]
[same as prior period, unchanged from 0000926326-20-000014:mdna:65]

[0000926326-20-000023:mdna:66]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-20-000023:mdna:67]
[same as prior period, unchanged from 0000926326-20-000014:mdna:67]

[0000926326-20-000023:mdna:68]
[same as prior period, unchanged from 0000926326-20-000014:mdna:68]

[0000926326-20-000023:mdna:69]
|  | Three Months Ended June 30, |  |  |  |  |  |  |
|  |  |  |  |  | Change in |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |  |  |  |  |  |  |
| Product revenues | $ | 138,942 |  |  | $ | 158,379 |  |  | $ | (19,437) |  |  | (12)% |
| Percentage of total revenues | 70% |  | 73% |  |  |  |  |
| Services and other revenues | 60,679 |  |  | 59,034 |  |  | 1,645 |  |  | 3% |
| Percentage of total revenues | 30% |  | 27% |  |  |  |  |
| Total revenues | $ | 199,621 |  |  | $ | 217,413 |  |  | $ | (17,792) |  |  | (8)% |

[0000926326-20-000023:mdna:70]
Product revenues represented 70% and 73% of total revenues for the three months ended June 30, 2020 and 2019, respectively. Product revenues decreased by $19.4 million, primarily due to the impact of the COVID-19 pandemic as health systems have been focusing resources on COVID-19 essential activities during the second quarter of 2020.

[0000926326-20-000023:mdna:71]
Services and other revenues represented 30% and 27% of total revenues for the three months ended June 30, 2020 and 2019, respectively. Services and other revenues include revenues from service and maintenance contracts, and rentals of automation systems. Services and other revenues increased by $1.6 million, primarily due to an increase in our installed customer base for our XT Series automated dispensing systems and IV solutions.

[0000926326-20-000023:mdna:72]
Our international sales represented 11% and 10% of total revenues for the three months ended June 30, 2020 and 2019, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-20-000023:mdna:73]
|  | Six Months Ended June 30, |  |  |  |  |  |  |
|  |  |  |  |  | Change in |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |  |  |  |  |  |  |
| Product revenues | $ | 309,015 |  |  | $ | 303,989 |  |  | $ | 5,026 |  |  | 2% |
| Percentage of total revenues | 72% |  | 72% |  |  |  |  |
| Services and other revenues | 120,292 |  |  | 115,941 |  |  | 4,351 |  |  | 4% |
| Percentage of total revenues | 28% |  | 28% |  |  |  |  |
| Total revenues | $ | 429,307 |  |  | $ | 419,930 |  |  | $ | 9,377 |  |  | 2% |

[0000926326-20-000023:mdna:74]
Product revenues represented 72% of total revenues for both the six months ended June 30, 2020 and 2019. Product revenues increased by $5.0 million, primarily due to the growth of XT Series automated dispensing systems as a result of increased XT Series upgrades from the previous generation of product, competitive conversions, and other add-on equipment, partially offset by lower revenues due to the impact of the COVID-19 pandemic as health systems have been focusing resources on COVID-19 essential activities during the second quarter of 2020.

[0000926326-20-000023:mdna:75]
Services and other revenues represented 28% of total revenues for both the six months ended June 30, 2020 and 2019. Services and other revenues include revenues from service and maintenance contracts, and rentals of automation systems. Services and other revenues increased by $4.4 million, primarily due to an increase in our installed customer base for our XT Series automated dispensing systems and IV solutions.

[0000926326-20-000023:mdna:76]
Our international sales represented 10% and 11% of total revenues for the six months ended June 30, 2020 and 2019, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-20-000023:mdna:77]
Our ability to continue to grow revenues is dependent on our ability to continue to obtain orders from customers, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-20-000023:mdna:78]
The effects of the COVID-19 pandemic have had an adverse impact on our revenues for the three months ended June 30, 2020. The pandemic continues to create uncertainties related to delays in installations and potential reductions in hospitals’ capital and overall spending in the near to medium-term future, and depending on the severity and duration of the COVID-19 pandemic and related containment measures, potentially into the longer-term. During the second quarter of 2020, we continued to see some delays in product bookings and expect to see lower product bookings and revenues during the fiscal year 2020 compared to management’s expectations prior to the COVID-19 outbreak. While the environment continues to change rapidly and there are uncertainties related to delays in installations and potential reductions in hospitals’ capital and overall spending, we are beginning to see more positive indicators for our business in terms of both product bookings and revenues. In many regions, elective surgeries have resumed, and we have been able to resume some on-site sales activities in regions less impacted by COVID-19. Additionally, the overall level of system implementations has also been increasing. Based on management's current expectations, we believe that the product bookings and revenues in the second quarter of 2020 represent the lowest quarter of 2020, and we expect that product bookings and revenues will increase sequentially through the third and fourth quarters of 2020. We cannot estimate the full extent to which the COVID-19 pandemic will impact our revenues in future periods.

[0000926326-20-000023:mdna:79]
[same as prior period, unchanged from 0000926326-20-000014:mdna:76]

[0000926326-20-000023:mdna:80]
[same as prior period, unchanged from 0000926326-20-000014:mdna:77]

[0000926326-20-000023:mdna:81]
|  | Three Months Ended June 30, |  |  |  |  |  |  |
|  |  |  |  |  | Change in |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |  |  |  |  |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 85,779 |  |  | $ | 84,583 |  |  | $ | 1,196 |  |  | 1% |
| As a percentage of related revenues | 62% |  | 53% |  |  |  |  |
| Cost of services and other revenues | 30,617 |  |  | 28,785 |  |  | 1,832 |  |  | 6% |
| As a percentage of related revenues | 50% |  | 49% |  |  |  |  |
| Total cost of revenues | $ | 116,396 |  |  | $ | 113,368 |  |  | $ | 3,028 |  |  | 3% |
| As a percentage of total revenues | 58% |  | 52% |  |  |  |  |
| Gross profit | $ | 83,225 |  |  | $ | 104,045 |  |  | $ | (20,820) |  |  | (20)% |
| Gross margin | 42% |  | 48% |  |  |  |  |

[0000926326-20-000023:mdna:82]
Cost of revenues for the three months ended June 30, 2020 compared to the three months ended June 30, 2019 increased by $3.0 million, of which $1.2 million was attributed to the increase in cost of product revenues and $1.8 million was attributed to the increase in cost of services and other revenues. The increase in cost of product revenues was primarily driven by certain fixed costs, such as labor and overhead, which have not decreased proportionally with the decrease in product revenues for the three months ended June 30, 2020, as well as an increase in employee-related expenses related to restructuring initiatives, partially offset by cost-saving initiatives. The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $1.6 million for the three months ended June 30, 2020 compared to the three months ended June 30, 2019, as well as additional investments in our service business to support new product offerings.

[0000926326-20-000023:mdna:83]
The overall decrease in gross margin primarily relates to lower revenues due to the impact of the COVID-19 pandemic and employee-related expenses related to restructuring initiatives, partially offset by lower costs associated with cost-saving initiatives. Our gross profit for the three months ended June 30, 2020 was $83.2 million, as compared to $104.0 million for the three months ended June 30, 2019.

[0000926326-20-000023:mdna:84]
33

[0000926326-20-000023:mdna:85]
|  | Six Months Ended June 30, |  |  |  |  |  |  |
|  |  |  |  |  | Change in |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |  |  |  |  |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 176,051 |  |  | $ | 163,394 |  |  | $ | 12,657 |  |  | 8% |
| As a percentage of related revenues | 57% |  | 54% |  |  |  |  |
| Cost of services and other revenues | 60,409 |  |  | 55,374 |  |  | 5,035 |  |  | 9% |
| As a percentage of related revenues | 50% |  | 48% |  |  |  |  |
| Total cost of revenues | $ | 236,460 |  |  | $ | 218,768 |  |  | $ | 17,692 |  |  | 8% |
| As a percentage of total revenues | 55% |  | 52% |  |  |  |  |
| Gross profit | $ | 192,847 |  |  | $ | 201,162 |  |  | $ | (8,315) |  |  | (4)% |
| Gross margin | 45% |  | 48% |  |  |  |  |

[0000926326-20-000023:mdna:86]
Cost of revenues for the six months ended June 30, 2020 compared to the six months ended June 30, 2019 increased by $17.7 million, of which $12.7 million was attributed to the increase in cost of product revenues and $5.0 million was attributed to the increase in cost of services and other revenues. The increase in cost of product revenues is reflective of investments made to support expected annual revenue levels which were impacted by the COVID-19 pandemic. While product revenues increased by $5.0 million for the six months ended June 30, 2020, cost of product revenues increased by $12.7 million primarily driven by certain fixed costs, such as labor and overhead. The increase in cost of product revenues was also driven by an increase in employee-related expenses related to restructuring initiatives, partially offset by cost-saving initiatives. The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $4.4 million for the six months ended June 30, 2020 compared to the six months ended June 30, 2019, as well as additional investments in our service business to support new product offerings.

[0000926326-20-000023:mdna:87]
The overall decrease in gross margin primarily relates to lower revenues during the three months ended June 30, 2020 due to the impact of the COVID-19 pandemic, employee-related expenses related to restructuring initiatives, and additional investments in our service business, partially offset by lower costs associated with cost-saving initiatives. Our gross profit for the six months ended June 30, 2020 was $192.8 million, as compared to $201.2 million for the six months ended June 30, 2019.

[0000926326-20-000023:mdna:88]
The effects of the COVID-19 pandemic have had an adverse impact on our cost of revenues and gross margins for the three months ended June 30, 2020. We continue to expect to incur additional costs related to the COVID-19 pandemic including, but not limited to, additional compensation for certain essential employees and the purchase of personal protective equipment for our customer-facing and manufacturing personnel. However, the full impact the COVID-19 pandemic will have on gross margins cannot be estimated.

[0000926326-20-000023:mdna:89]
[same as prior period, unchanged from 0000926326-20-000014:mdna:82]

[0000926326-20-000023:mdna:90]
|  | Three Months Ended June 30, |  |  |  |  |  |  |
|  |  |  |  |  | Change in |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 20,830 |  |  | $ | 16,848 |  |  | $ | 3,982 |  |  | 24% |
| As a percentage of total revenues | 10% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 69,386 |  |  | 68,434 |  |  | 952 |  |  | 1% |
| As a percentage of total revenues | 35% |  | 31% |  |  |  |  |
| Total operating expenses | $ | 90,216 |  |  | $ | 85,282 |  |  | $ | 4,934 |  |  | 6% |
| As a percentage of total revenues | 45% |  | 39% |  |  |  |  |
| Interest and other income (expense), net | $ | 174 |  |  | $ | (1,629) |  |  | $ | 1,803 |  |  | (111)% |

[0000926326-20-000023:mdna:91]
Research and Development. Research and development expenses increased by $4.0 million for the three months ended June 30, 2020 compared to the three months ended June 30, 2019. The increase was primarily attributed to an increase of $2.9

[0000926326-20-000023:mdna:92]
million in employee-related expenses related to restructuring initiatives, as well as an increase of $0.7 million in other employee-related expenses in the research and development function.

[0000926326-20-000023:mdna:93]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $1.0 million for the three months ended June 30, 2020 compared to the three months ended June 30, 2019, primarily due to overall growth of operations and increase in overall headcount. The increase was primarily due to an increase of $4.0 million in employee-related expenses primarily related to increased headcount and an increase of $0.9 million of employee-related expenses related to restructuring initiatives, partially offset by certain cost savings, including reduced travel costs, and lower commission expenses attributable to lower bookings and revenues.

[0000926326-20-000023:mdna:94]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $1.8 million for the three months ended June 30, 2020 compared to the three months ended June 30, 2019, primarily driven by a $1.8 million decrease in other expenses as other income remained consistent period over period. The decrease in other expenses was primarily due to lower interest expense as a result of lower outstanding debt balance during the three months ended June 30, 2020 as compared to the three months ended June 30, 2019 as well as favorable foreign currency fluctuations during the period.

[0000926326-20-000023:mdna:95]
|  | Six Months Ended June 30, |  |  |  |  |  |  |
|  |  |  |  |  | Change in |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 39,482 |  |  | $ | 32,926 |  |  | $ | 6,556 |  |  | 20% |
| As a percentage of total revenues | 9% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 148,205 |  |  | 136,712 |  |  | 11,493 |  |  | 8% |
| As a percentage of total revenues | 35% |  | 33% |  |  |  |  |
| Total operating expenses | $ | 187,687 |  |  | $ | 169,638 |  |  | $ | 18,049 |  |  | 11% |
| As a percentage of total revenues | 44% |  | 40% |  |  |  |  |
| Interest and other income (expense), net | $ | (648) |  |  | $ | (3,039) |  |  | $ | 2,391 |  |  | (79)% |

[0000926326-20-000023:mdna:96]
Research and Development. Research and development expenses increased by $6.6 million for the six months ended June 30, 2020 compared to the six months ended June 30, 2019. The increase was primarily attributed to an increase of $3.7 million in employee-related expenses related to restructuring initiatives, as well as an increase of $1.8 million in other employee-related expenses in the research and development function. The increased spend is a result of our continued investments into automation, intelligence, and the cloud data platform.

[0000926326-20-000023:mdna:97]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $11.5 million for the six months ended June 30, 2020 compared to the six months ended June 30, 2019, primarily due to overall growth of operations and increase in overall headcount. The increase was primarily due to an increase of $10.5 million in employee-related expenses primarily related to increased headcount, an increase of $3.7 million in employee-related expenses related to restructuring initiatives, and an increase of $1.5 million in consulting expenses, partially offset by certain cost savings, including reduced travel costs, and lower commission expenses attributable to lower bookings and revenues.

[0000926326-20-000023:mdna:98]
[same as prior period, unchanged from 0000926326-20-000014:mdna:86]

[0000926326-20-000023:mdna:99]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $2.4 million for the six months ended June 30, 2020 compared to the six months ended June 30, 2019, primarily driven by a $1.9 million decrease in other expenses and a $0.5 million increase in other income. The decrease in other expenses was primarily due to lower interest expense as a result of lower outstanding debt balance during the six months ended June 30, 2020 as compared to the six months ended June 30, 2019. The increase in other income was primarily attributable to rebates and benefits from certain arrangements outside of our normal course of business.

[0000926326-20-000023:mdna:100]
[same as prior period, unchanged from 0000926326-20-000014:mdna:88]

[0000926326-20-000023:mdna:101]
|  | Three Months Ended June 30, |  |  |  |  |  |  |
|  |  |  |  |  | Change in |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |  |  |  |  |  |  |
| Provision for (benefit from) income taxes | $ | (2,518) |  |  | $ | 1,158 |  |  | $ | (3,676) |  |  | (317)% |

[0000926326-20-000023:mdna:102]
|  | Six Months Ended June 30, |  |  |  |  |  |  |
|  |  |  |  |  | Change in |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |
|  | (Dollars in thousands) |  |  |  |  |  |  |
| Provision for (benefit from) income taxes | $ | (2,500) |  |  | $ | 9,225 |  |  | $ | (11,725) |  |  | (127)% |

[0000926326-20-000023:mdna:103]
Our annual effective tax rate before discrete items was 28.0% and 24.8% for the six months ended June 30, 2020 and 2019, respectively. The increase in the estimated annual effective tax rate for the six months ended June 30, 2020 compared to the same period in 2019 was primarily due to state income taxes and non-deductible equity charges, partially offset by an increase in research and development credits.

[0000926326-20-000023:mdna:104]
Provision for income taxes for the six months ended June 30, 2020 included net discrete income tax benefit of $3.8 million, primarily due to a $3.3 million tax benefit from equity compensation.

[0000926326-20-000023:mdna:105]
Provision for income taxes for the six months ended June 30, 2019 included net discrete income tax expense of $2.2 million. The net discrete income tax expense is primarily related to recognized gain on the sale of certain intellectual property rights by Aesynt B.V. to Omnicell, Inc. in the first quarter of 2019, offset by a discrete income tax benefit of $7.0 million related to equity compensation. In March 2020, Aesynt B.V. subsequently merged with and into Aesynt Holding B.V., with Aesynt Holding B.V. surviving and changing its name to Omnicell B.V.

[0000926326-20-000023:mdna:106]
[same as prior period, unchanged from 0000926326-20-000014:mdna:94]

[0000926326-20-000023:mdna:107]
[same as prior period, unchanged from 0000926326-20-000014:mdna:95]

[0000926326-20-000023:mdna:108]
We had cash and cash equivalents of $133.6 million at June 30, 2020 compared to $127.2 million at December 31, 2019. All of our cash and cash equivalents are invested in bank accounts with major financial institutions.

[0000926326-20-000023:mdna:109]
Our cash position and working capital at June 30, 2020 and December 31, 2019 were as follows:

[0000926326-20-000023:mdna:110]
|  | June 30,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Cash | $ | 133,583 |  |  | $ | 127,210 |  |
| Working Capital | $ | 228,602 |  |  | $ | 246,242 |  |

[0000926326-20-000023:mdna:111]
Our ratio of current assets to current liabilities was 2.0:1 at both June 30, 2020 and December 31, 2019.

[0000926326-20-000023:mdna:112]
[same as prior period, unchanged from 0000926326-20-000014:mdna:100]

[0000926326-20-000023:mdna:113]
[same as prior period, unchanged from 0000926326-20-000014:mdna:101]

[0000926326-20-000023:mdna:114]
On January 5, 2016, we entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association, as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for a $200.0 million term loan facility (the “Prior Term Loan Facility”), and prior to the amendment discussed below, a $200.0 million revolving credit facility (the “Prior Revolving Credit Facility” and together with the Prior Term Loan Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million.

[0000926326-20-000023:mdna:115]
On April 11, 2017 and December 26, 2017, we entered into amendments to the Prior Credit Agreement. Under these amendments, the Prior Revolving Credit Facility was increased from $200.0 million to $315.0 million and certain other modifications were made.

[0000926326-20-000023:mdna:116]
On November 15, 2019, we refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. On November 15, 2019, the $80.0 million outstanding term loan balance under the Prior Facilities was transferred to the Current Revolving Credit Facility.

[0000926326-20-000023:mdna:117]
As of June 30, 2020, there was no outstanding loan balance for the Current Revolving Credit Facility and we were in full compliance with all covenants. Refer to Note 8, Debt and Credit Agreements, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-20-000023:mdna:118]
[same as prior period, unchanged from 0000926326-20-000014:mdna:106]

[0000926326-20-000023:mdna:119]
[same as prior period, unchanged from 0000926326-20-000014:mdna:107]

[0000926326-20-000023:mdna:120]
For the three and six months ended June 30, 2020, we did not sell any of our common stock under the Distribution Agreement.

[0000926326-20-000023:mdna:121]
For the three months ended June 30, 2019, we received gross proceeds of $17.9 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.3 million on sales of approximately 217,000 shares of our common stock at an average price of approximately $82.51 per share.

[0000926326-20-000023:mdna:122]
For the six months ended June 30, 2019, we received gross proceeds of $38.5 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 460,000 shares of our common stock at an average price of approximately $83.81 per share.

[0000926326-20-000023:mdna:123]
As of June 30, 2020, we had an aggregate of $31.5 million available to be offered under the Distribution Agreement.

[0000926326-20-000023:mdna:124]
[same as prior period, unchanged from 0000926326-20-000014:mdna:111]

[0000926326-20-000023:mdna:125]
[same as prior period, unchanged from 0000926326-20-000014:mdna:112]

[0000926326-20-000023:mdna:126]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of June 30, 2020, which may result in additional use of cash. Refer to “Stock Repurchase Program” under Note 13, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. There were no stock repurchases during the six months ended June 30, 2020 and 2019.

[0000926326-20-000023:mdna:127]
Based on our current business plan and revenue backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-20-000023:mdna:128]
We believe that our current financial position and resources will allow us to manage the anticipated impact of the COVID-19 pandemic on our business for the foreseeable future, including any potential changes in timing of revenue recognition or potential extensions in customer payments. However, COVID-19 and related measures to contain its impact have caused material disruptions in both national and global financial markets and economies. The future impact of COVID-19 and these containment measures cannot be predicted with certainty and may increase our borrowing costs and other costs of capital and otherwise adversely affect our business, results of operations, financial condition, and liquidity, and we cannot assure that

[0000926326-20-000023:mdna:129]
we will have access to external financing at times and on terms we consider acceptable, or at all, or that we will not experience other liquidity issues going forward.

[0000926326-20-000023:mdna:130]
[same as prior period, unchanged from 0000926326-20-000014:mdna:116]

[0000926326-20-000023:mdna:131]
[same as prior period, unchanged from 0000926326-20-000014:mdna:117]

[0000926326-20-000023:mdna:132]
|  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |
|  | (In thousands) |  |  |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 72,735 |  |  | $ | 53,760 |  |
| Investing activities | (33,213) |  |  | (31,950) |  |
| Financing activities | (32,308) |  |  | (1,583) |  |
| Effect of exchange rate changes on cash and cash equivalents | (841) |  |  | 63 |  |
| Net increase in cash and cash equivalents | $ | 6,373 |  |  | $ | 20,290 |  |

[0000926326-20-000023:mdna:133]
[same as prior period, unchanged from 0000926326-20-000014:mdna:119]

[0000926326-20-000023:mdna:134]
[same as prior period, unchanged from 0000926326-20-000014:mdna:120]

[0000926326-20-000023:mdna:135]
Net cash provided by operating activities was $72.7 million for the six months ended June 30, 2020, primarily consisting of net income of $7.0 million adjusted for non-cash items of $47.0 million and changes in assets and liabilities of $18.7 million. The non-cash items primarily consisted of depreciation and amortization expense of $28.8 million, share-based compensation expense of $22.0 million, amortization of operating lease right-of-use assets of $5.2 million, amortization of debt issuance costs of $0.5 million, and a change in deferred income taxes of $9.4 million. Changes in assets and liabilities include cash inflows from (i) a decrease in accounts receivable and unbilled receivables of $28.2 million primarily due to an increase in collections and a decrease in billings due to timing of shipments, (ii) an increase in deferred revenues of $16.3 million primarily due to the timing of shipments in order to meet customers’ implementation schedules and recognition of revenues for product requiring installation, (iii) an increase in other long-term liabilities of $4.4 million, (iv) a decrease in prepaid commissions of $4.0 million, and (v) a decrease in prepaid expenses of $1.2 million. These cash inflows were partially offset by (i) a decrease in accounts payable of $11.3 million primarily due to an overall decrease in spending, as well as timing of payments, (ii) an increase in inventories of $7.3 million to support forecasted sales, (iii) a decrease in operating lease liabilities of $5.2 million, (iv) an increase in other long-term assets of $4.6 million, (v) a decrease in accrued compensation of $3.1 million, (vi) a decrease in accrued liabilities of $2.8 million, and (vii) an increase in investment in sales-type leases of $1.4 million.

[0000926326-20-000023:mdna:136]
Net cash provided by operating activities was $53.8 million for the six months ended June 30, 2019, primarily consisting of net income of $19.3 million adjusted for non-cash items of $53.1 million, offset by changes in assets and liabilities of $18.6 million. The non-cash items primarily consisted of depreciation and amortization expense of $25.9 million, share-based compensation expense of $16.7 million, amortization of operating lease right-of-use assets of $5.2 million, amortization of debt issuance costs of $1.1 million, and a change in deferred income taxes of $3.8 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $9.2 million primarily due to an increase in billings, (ii) a decrease in accrued compensation of $8.0 million primarily due to a decrease in accrued commissions and restructuring expenses, as well as timing of payroll, (iii) a decrease in operating lease liabilities of $5.3 million, (iv) an increase in inventories of $4.5 million for inventory buildup in support of forecasted sales of new and existing products, and (v) an increase in investment in sales-type leases of $4.4 million. These cash outflows were partially offset by (i) an increase in other long-term liabilities of $3.9 million, (ii) a decrease in other long-term assets of $3.1 million, (iii) an increase in accounts payable of $2.1 million, (iv) an increase in accrued liabilities of $1.8 million, (v) a decrease in prepaid commissions of $1.5 million, and (vi) a decrease in prepaid expenses of $1.0 million.

[0000926326-20-000023:mdna:137]
[same as prior period, unchanged from 0000926326-20-000014:mdna:124]

[0000926326-20-000023:mdna:138]
Net cash used in investing activities was $33.2 million for the six months ended June 30, 2020, which consisted of capital expenditures of $13.2 million for property and equipment, and $20.0 million for costs of software development for external use.

[0000926326-20-000023:mdna:139]
Net cash used in investing activities was $32.0 million for the six months ended June 30, 2019, which consisted of capital expenditures of $9.4 million for property and equipment, and $22.6 million for costs of software development for external use.

[0000926326-20-000023:mdna:140]
[same as prior period, unchanged from 0000926326-20-000014:mdna:127]

[0000926326-20-000023:mdna:141]
Net cash used in financing activities was $32.3 million for the six months ended June 30, 2020, primarily due to the repayment of $50.0 million of the Current Revolving Credit Facility and $3.5 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $21.2 million in proceeds from employee stock option exercises and employee stock plan purchases.

[0000926326-20-000023:mdna:142]
Net cash used in financing activities was $1.6 million for the six months ended June 30, 2019, primarily due to the repayment of $60.0 million of the Prior Facilities and $4.7 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $25.3 million in proceeds from employee stock option exercises and employee stock plan purchases, and $37.8 million of proceeds from sales of our common stock under the Distribution Agreement.

[0000926326-20-000023:mdna:143]
[same as prior period, unchanged from 0000926326-20-000014:mdna:130]

[0000926326-20-000023:mdna:144]
There have been no significant changes during the six months ended June 30, 2020 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2019.

[0000926326-20-000023:mdna:145]
Contractual obligations as of June 30, 2020 were as follows:

[0000926326-20-000023:mdna:146]
|  | Payments due by period |  |  |  |  |  |  |  |  |
|  | Total |  | Remainder of 2020 |  | 2021 - 2022 |  | 2023 - 2024 |  | 2025 and thereafter |
|  | (In thousands) |  |  |  |  |  |  |  |  |
| Operating leases (1) | $ | 69,647 |  |  | $ | 6,890 |  |  | $ | 25,868 |  |  | $ | 16,719 |  |  | $ | 20,170 |  |
| Purchase obligations (2) | 66,313 |  |  | 64,679 |  |  | 848 |  |  | 689 |  |  | 97 |  |
| Total (3) | $ | 135,960 |  |  | $ | 71,569 |  |  | $ | 26,716 |  |  | $ | 17,408 |  |  | $ | 20,267 |  |

[0000926326-20-000023:mdna:147]
[same as prior period, unchanged from 0000926326-20-000014:mdna:134]

[0000926326-20-000023:mdna:148]
[same as prior period, unchanged from 0000926326-20-000014:mdna:135]

[0000926326-20-000023:mdna:149]
[same as prior period, unchanged from 0000926326-20-000014:mdna:136]

[0000926326-20-000023:mdna:150]
(3)Refer to Note 11, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-20-000023:mdna:151]
[same as prior period, unchanged from 0000926326-20-000014:mdna:138]

[0000926326-20-000023:mdna:152]
As of June 30, 2020, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Exchange Act and the instructions thereto.
