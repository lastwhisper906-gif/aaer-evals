# OMCL note change history — 0000926326-20-000014 → 0000926326-20-000023


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000926326-20-000023:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2020, the Company had non-cancelable purchase commitments of $66.3 million, of which $64.7 million are expected to be paid within the year ending December 31, 2020.
  (was, 2020-05-08, similarity 0.9836):
[0000926326-20-000014:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2020, the Company had non-cancelable purchase commitments of $91.7 million, of which $90.2 million are expected to be paid within the year ending December 31, 2020.

- changed (2020-07-31):
[0000926326-20-000023:note_history:2]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows
  (was, 2020-05-08, similarity 0.8682):
[0000926326-20-000014:note_history:2]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

- added (2020-07-31):
[0000926326-20-000023:note_history:3]
or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

- added (2020-07-31):
[0000926326-20-000023:note_history:4]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of BIPA, and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the Mazya Action. The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The motion to dismiss is fully-briefed. The hearing on the Company’s motion to dismiss was previously set for March 16, 2020, was continued to May 27, 2020, and then was subsequently continued again to September 2, 2020. The Company intends to defend the lawsuit vigorously.

- removed (2020-07-31):
[0000926326-20-000014:note_history:5]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of BIPA, and certain declaratory, injunctive, and other relief based on

- removed (2020-07-31):
[0000926326-20-000014:note_history:6]
causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the Mazya Action. The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The motion to dismiss is fully-briefed. The hearing on the Company’s motion to dismiss was previously set for March 16, 2020, but has been continued to May 27, 2020. The Company intends to defend the lawsuit vigorously.

- removed (2020-07-31):
[0000926326-20-000014:note_history:7]
In August 2019, the Company received a letter from the Denver office of the SEC seeking information related to the Company’s accounting processes and procedures. The Company responded and fully cooperated with the SEC. On February 12, 2020, the Company received a letter from the SEC confirming that it has concluded its investigation and that the SEC does not intend to recommend any enforcement action against the Company.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000926326-20-000023:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2020 and December 31, 2019, the results of operations and comprehensive income (loss) for the three and six months ended June 30, 2020 and 2019, and cash flows for the six months ended June 30, 2020 and 2019. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2019 filed with the SEC on February 26, 2020, except as discussed in the sections entitled “Allowance for Credit Losses” and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income (loss) for the three and six months ended June 30, 2020 and cash flows for the six months ended June 30, 2020 are not necessarily indicative of results that may be expected for the year ending December 31, 2020, or for any future period.
  (was, 2020-05-08, similarity 0.8263):
[0000926326-20-000014:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2020 and December 31, 2019, the results of operations and comprehensive income for the three months ended March 31, 2020 and 2019, and cash flows for the three months ended March 31, 2020 and 2019. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2019 filed with the SEC on February 26, 2020, except as discussed in the sections entitled “Allowance for Credit Losses” and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three months ended March 31, 2020 and cash flows for the three months ended March 31, 2020 are not necessarily indicative of results that may be expected for the year ending December 31, 2020, or for any future period.

- changed (2020-07-31):
[0000926326-20-000023:note_history:9]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of product revenues for the three and six months ended June 30, 2019 in Note 2, Revenues, of the Notes to Condensed Consolidated Financial Statements. This change was not deemed material and was included to conform with current-period classification and presentation.
  (was, 2020-05-08, similarity 0.9518):
[0000926326-20-000014:note_history:9]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of product revenues for the three months ended March 31, 2019 in Note 2, Revenues, of the Notes to Condensed Consolidated Financial Statements. This change was not deemed material and was included to conform with current-period classification and presentation.

- changed (2020-07-31):
[0000926326-20-000023:note_history:10]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. As of June 30, 2020, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities. Given the ongoing uncertainty surrounding the COVID-19 pandemic, events or circumstances may arise that could result in a change in estimates, judgments, or revisions to the carrying value of the Company’s assets or liabilities.
  (was, 2020-05-08, similarity 0.607):
[0000926326-20-000014:note_history:10]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases; operating lease right-of-use assets and liabilities; inventory valuation; capitalized software development costs; impairment of goodwill and purchased intangibles; share-based compensation; and accounting for income taxes. As of March 31, 2020, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities. Given the uncertainty surrounding the COVID-19 pandemic, events or circumstances may arise that could result in a change in estimates, judgments, or revisions to the carrying value of the Company’s assets or liabilities.

- added (2020-07-31):
[0000926326-20-000023:note_history:11]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.

- changed (2020-07-31):
[0000926326-20-000023:note_history:12]
|  | June 30,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Allowance for credit losses: |  |  |  |
| Accounts receivable and unbilled receivables | $ | 3,204 |  |  | $ | 3,227 |  |
| Long-term unbilled receivables (1) | 33 |  |  | — |  |
| Net investment in sales-type leases (2) | 248 |  |  | 225 |  |
  (was, 2020-05-08, similarity 0.8167):
[0000926326-20-000014:note_history:12]
|  | March 31,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Allowance for credit losses: |  |  |  |  |
| Accounts receivable and unbilled receivables |  | $ | 3,869 |  |  | $ | 3,227 |  |
| Long-term unbilled receivables (1) | 33 |  |  | — |  |
| Net investment in sales-type leases (2) | 247 |  |  | 225 |  |

- changed (2020-07-31):
[0000926326-20-000023:note_history:13]
Changes in the allowances for credit losses were not significant for the three and six months ended June 30, 2020 and 2019.
  (was, 2020-05-08, similarity 0.9231):
[0000926326-20-000014:note_history:13]
Changes in the allowances for credit losses were not significant for the three months ended March 31, 2020 and 2019.

- changed (2020-07-31):
[0000926326-20-000023:note_history:14]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). The Company adopted ASU 2018-15 on January 1, 2020 on a prospective basis. The adoption of this guidance did not have a material impact on the Company’s Condensed Consolidated Financial Statements.
  (was, 2020-05-08, similarity 0.9347):
[0000926326-20-000014:note_history:14]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). The Company adopted ASU 2018-15 on January 1, 2020 on a prospective basis. The adoption of this guidance did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

- removed (2020-07-31):
[0000926326-20-000014:note_history:15]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM

- removed (2020-07-31):
[0000926326-20-000014:note_history:16]
allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.


## omcl:ScheduleOfDebtIssuanceCostsNetTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000926326-20-000023:note_history:17]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | — |  |
| Amortization | (482) |  |
| Balance as of June 30, 2020 | $ | 4,218 |  |
  (was, 2020-05-08, similarity 0.9686):
[0000926326-20-000014:note_history:17]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | — |  |
| Amortization | (241) |  |
| Balance as of March 31, 2020 | $ | 4,459 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000926326-20-000023:note_history:18]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Prior Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Prior Term Loan Facility” and together with the Prior Revolving Credit Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Prior Credit Agreement had an expiration date of January 5, 2021, upon which date all remaining outstanding borrowings were due and payable.
  (was, 2020-05-08, similarity 0.8687):
[0000926326-20-000014:note_history:18]
as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Prior Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Prior Term Loan Facility” and together with the Prior Revolving Credit Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Prior Credit Agreement had an expiration date of January 5, 2021, upon which date all remaining outstanding borrowings were due and payable.

- added (2020-07-31):
[0000926326-20-000023:note_history:19]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) LIBOR, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate,

- changed (2020-07-31):
[0000926326-20-000023:note_history:20]
(ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. The applicable margin for and certain other terms of any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.
  (was, 2020-05-08, similarity 0.8054):
[0000926326-20-000014:note_history:20]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) LIBOR, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. The applicable margin for and certain other terms of any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

- changed (2020-07-31):
[0000926326-20-000023:note_history:21]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total net leverage ratio and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of June 30, 2020.
  (was, 2020-05-08, similarity 0.9588):
[0000926326-20-000014:note_history:21]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total net leverage ratio and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and

- changed (2020-07-31):
[0000926326-20-000023:note_history:22]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs was approximately $0.2 million and $0.6 million for the three months ended June 30, 2020 and 2019, respectively, and approximately $0.5 million and $1.1 million for the six months ended June 30, 2020 and 2019, respectively.
  (was, 2020-05-08, similarity 0.8774):
[0000926326-20-000014:note_history:22]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs was approximately $0.2 million and $0.6 million for the three months ended March 31, 2020 and 2019, respectively.

- added (2020-07-31):
[0000926326-20-000023:note_history:23]
Interest expense (exclusive of fees and debt issuance cost amortization) was approximately $0.9 million for the three months ended June 30, 2019, and approximately $0.2 million and $2.2 million for the six months ended June 30, 2020 and 2019, respectively. No interest expense was incurred during the three months ended June 30, 2020 as there was no outstanding balance under the Current Revolving Credit Facility during the three months ended June 30, 2020.

- changed (2020-07-31):
[0000926326-20-000023:note_history:24]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | — |  |
| Repayments | (50,000) |  |
| Balance as of June 30, 2020 | $ | — |  |
  (was, 2020-05-08, similarity 0.9751):
[0000926326-20-000014:note_history:24]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | — |  |
| Repayments | (50,000) |  |
| Balance as of March 31, 2020 | $ | — |  |

- changed (2020-07-31):
[0000926326-20-000023:note_history:25]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | — |  |
| Amortization | (482) |  |
| Balance as of June 30, 2020 | $ | 4,218 |  |
  (was, 2020-05-08, similarity 0.9686):
[0000926326-20-000014:note_history:25]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | — |  |
| Amortization | (241) |  |
| Balance as of March 31, 2020 | $ | 4,459 |  |

- removed (2020-07-31):
[0000926326-20-000014:note_history:26]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association

- removed (2020-07-31):
[0000926326-20-000014:note_history:27]
reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of March 31, 2020.

- removed (2020-07-31):
[0000926326-20-000014:note_history:28]
Interest expense (exclusive of fees and debt issuance cost amortization) was approximately $0.2 million and $1.3 million for the three months ended March 31, 2020 and 2019, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000926326-20-000023:note_history:29]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | — |  |
| Repayments | (50,000) |  |
| Balance as of June 30, 2020 | $ | — |  |
  (was, 2020-05-08, similarity 0.9751):
[0000926326-20-000014:note_history:29]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | — |  |
| Repayments | (50,000) |  |
| Balance as of March 31, 2020 | $ | — |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000926326-20-000023:note_history:30]
Software. On premise or cloud-based subscription solutions that improve medication management and adherence outcomes or enable incremental functionality of the Company’s equipment.
  (was, 2020-05-08, similarity 0.6):
[0000926326-20-000014:note_history:30]
Software. Additional software applications that enable incremental functionality of the Company’s equipment or services.

- changed (2020-07-31):
[0000926326-20-000023:note_history:31]
Professional services. Other customer services, such as technology-enabled services, training, and consulting.
  (was, 2020-05-08, similarity 0.8421):
[0000926326-20-000014:note_history:31]
Professional services. Other customer services, such as training and consulting.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000926326-20-000023:note_history:32]
Software. On premise or cloud-based subscription solutions that improve medication management and adherence outcomes or enable incremental functionality of the Company’s equipment.
  (was, 2020-05-08, similarity 0.6):
[0000926326-20-000014:note_history:32]
Software. Additional software applications that enable incremental functionality of the Company’s equipment or services.

- changed (2020-07-31):
[0000926326-20-000023:note_history:33]
Professional services. Other customer services, such as technology-enabled services, training, and consulting.
  (was, 2020-05-08, similarity 0.8421):
[0000926326-20-000014:note_history:33]
Professional services. Other customer services, such as training and consulting.

- changed (2020-07-31):
[0000926326-20-000023:note_history:34]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $1.7 million and $2.6 million for the three months ended June 30, 2020 and 2019, respectively, and $4.6 million and $4.8 million for the six months ended June 30, 2020 and 2019, respectively.
  (was, 2020-05-08, similarity 0.9054):
[0000926326-20-000014:note_history:34]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.9 million and $2.2 million for the three months ended March 31, 2020 and 2019, respectively.

- changed (2020-07-31):
[0000926326-20-000023:note_history:35]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and six months ended June 30, 2020 and 2019:
  (was, 2020-05-08, similarity 0.9386):
[0000926326-20-000014:note_history:35]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three months ended March 31, 2020 and 2019:

- changed (2020-07-31):
[0000926326-20-000023:note_history:36]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |  |  |  |  |  |  |
| Hardware and software | $ | 116,919 |  |  | $ | 133,005 |  |  | $ | 259,352 |  |  | $ | 251,819 |  |
| Consumables | 18,063 |  |  | 21,795 |  |  | 41,333 |  |  | 45,502 |  |
| Other | 3,960 |  |  | 3,579 |  |  | 8,330 |  |  | 6,668 |  |
| Total product revenues | $ | 138,942 |  |  | $ | 158,379 |  |  | $ | 309,015 |  |  | $ | 303,989 |  |
  (was, 2020-05-08, similarity 0.6354):
[0000926326-20-000014:note_history:36]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | (In thousands) |  |  |  |  |  |  |
| Hardware and software | $ | 142,433 |  |  | $ | 118,814 |  |  |  |  |  |
| Consumables | 23,270 |  |  | 23,707 |  |  |  |  |  |
| Other | 4,370 |  |  | 3,089 |  |  |  |  |  |
| Total product revenues | $ | 170,073 |  |  | $ | 145,610 |  |  |  |  |  |

- changed (2020-07-31):
[0000926326-20-000023:note_history:37]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2020 and 2019:
  (was, 2020-05-08, similarity 0.9539):
[0000926326-20-000014:note_history:37]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2020 and 2019:

- changed (2020-07-31):
[0000926326-20-000023:note_history:38]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |  |  |  |  |  |  |
| United States | $ | 178,052 |  |  | $ | 195,811 |  |  | $ | 385,786 |  |  | $ | 375,831 |  |
| Rest of world (1) | 21,569 |  |  | 21,602 |  |  | 43,521 |  |  | 44,099 |  |
| Total revenues | $ | 199,621 |  |  | $ | 217,413 |  |  | $ | 429,307 |  |  | $ | 419,930 |  |
  (was, 2020-05-08, similarity 0.7057):
[0000926326-20-000014:note_history:38]
|  | Three Months Ended March 31, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
|  | (In thousands) |  |  |  |  |  |  |
| United States | $ | 207,734 |  |  | $ | 180,020 |  |  |  |  |  |
| Rest of world (1) | 21,952 |  |  | 22,497 |  |  |  |  |  |
| Total revenues | $ | 229,686 |  |  | $ | 202,517 |  |  |  |  |  |

- changed (2020-07-31):
[0000926326-20-000023:note_history:39]
|  | June 30,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Short-term unbilled receivables, net (1) | $ | 9,602 |  |  | $ | 11,707 |  |
| Long-term unbilled receivables, net (2) | 16,132 |  |  | 12,260 |  |
| Total contract assets | $ | 25,734 |  |  | $ | 23,967 |  |
| Short-term deferred revenues, net | $ | 107,940 |  |  | $ | 90,894 |  |
| Long-term deferred revenues | 6,101 |  |  | 7,083 |  |
| Total contract liabilities | $ | 114,041 |  |  | $ | 97,977 |  |
  (was, 2020-05-08, similarity 0.8082):
[0000926326-20-000014:note_history:39]
|  | March 31,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Short-term unbilled receivables, net (1) | $ | 10,048 |  |  | $ | 11,707 |  |
| Long-term unbilled receivables, net (2) | 14,338 |  |  | 12,260 |  |
| Total contract assets |  | $ | 24,386 |  |  | $ | 23,967 |  |
| Short-term deferred revenues, net |  | $ | 108,602 |  |  | $ | 90,894 |  |
| Long-term deferred revenues |  | 6,019 |  |  | 7,083 |  |
| Total contract liabilities |  | $ | 114,621 |  |  | $ | 97,977 |  |

- changed (2020-07-31):
[0000926326-20-000023:note_history:40]
Short-term deferred revenues of $107.9 million and $90.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $19.6 million and $13.1 million, as of June 30, 2020 and December 31, 2019, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and six months ended June 30, 2020, the Company recognized revenues of $20.9 million and $64.3 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $104.0 million as of December 31, 2019.
  (was, 2020-05-08, similarity 0.7725):
[0000926326-20-000014:note_history:40]
Short-term deferred revenues of $108.6 million and $90.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $15.4 million and $13.1 million, as of March 31, 2020 and December 31, 2019, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three months ended March 31, 2020, the Company recognized revenues of $43.4 million that were included in the corresponding gross short-term deferred revenues balance of $104.0 million as of December 31, 2019.

- changed (2020-07-31):
[0000926326-20-000023:note_history:41]
Long-term deferred revenues include deferred revenues from service contracts of $6.1 million and $7.1 million as of June 30, 2020 and December 31, 2019, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.
  (was, 2020-05-08, similarity 0.9864):
[0000926326-20-000014:note_history:41]
Long-term deferred revenues include deferred revenues from service contracts of $6.0 million and $7.1 million as of March 31, 2020 and December 31, 2019, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

- changed (2020-07-31):
[0000926326-20-000023:note_history:42]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2020 and 2019. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of June 30, 2020 and December 31, 2019.
  (was, 2020-05-08, similarity 0.9048):
[0000926326-20-000014:note_history:42]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2020 and 2019. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2020 and December 31, 2019.
