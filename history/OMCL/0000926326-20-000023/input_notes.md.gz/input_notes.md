# OMCL notes — 0000926326-20-000023


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-20-000023:notes:1]
[same as prior period, unchanged from 0000926326-20-000014:notes:1]

[0000926326-20-000023:notes:2]
[same as prior period, unchanged from 0000926326-20-000014:notes:2]

[0000926326-20-000023:notes:3]
[same as prior period, unchanged from 0000926326-20-000014:notes:3]

[0000926326-20-000023:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2020 and December 31, 2019, the results of operations and comprehensive income (loss) for the three and six months ended June 30, 2020 and 2019, and cash flows for the six months ended June 30, 2020 and 2019. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2019 filed with the SEC on February 26, 2020, except as discussed in the sections entitled “Allowance for Credit Losses” and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income (loss) for the three and six months ended June 30, 2020 and cash flows for the six months ended June 30, 2020 are not necessarily indicative of results that may be expected for the year ending December 31, 2020, or for any future period.

[0000926326-20-000023:notes:5]
[same as prior period, unchanged from 0000926326-20-000014:notes:5]

[0000926326-20-000023:notes:6]
[same as prior period, unchanged from 0000926326-20-000014:notes:6]

[0000926326-20-000023:notes:7]
[same as prior period, unchanged from 0000926326-20-000014:notes:7]

[0000926326-20-000023:notes:8]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of product revenues for the three and six months ended June 30, 2019 in Note 2, Revenues, of the Notes to Condensed Consolidated Financial Statements. This change was not deemed material and was included to conform with current-period classification and presentation.

[0000926326-20-000023:notes:9]
[same as prior period, unchanged from 0000926326-20-000014:notes:9]

[0000926326-20-000023:notes:10]
[same as prior period, unchanged from 0000926326-20-000014:notes:10]

[0000926326-20-000023:notes:11]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. As of June 30, 2020, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities. Given the ongoing uncertainty surrounding the COVID-19 pandemic, events or circumstances may arise that could result in a change in estimates, judgments, or revisions to the carrying value of the Company’s assets or liabilities.

[0000926326-20-000023:notes:12]
[same as prior period, unchanged from 0000926326-20-000014:notes:12]

[0000926326-20-000023:notes:13]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.

[0000926326-20-000023:notes:14]
[same as prior period, unchanged from 0000926326-20-000014:notes:15]

[0000926326-20-000023:notes:15]
[same as prior period, unchanged from 0000926326-20-000014:notes:16]

[0000926326-20-000023:notes:16]
[same as prior period, unchanged from 0000926326-20-000014:notes:17]

[0000926326-20-000023:notes:17]
[same as prior period, unchanged from 0000926326-20-000014:notes:18]

[0000926326-20-000023:notes:18]
|  | June 30,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Allowance for credit losses: |  |  |  |
| Accounts receivable and unbilled receivables | $ | 3,204 |  |  | $ | 3,227 |  |
| Long-term unbilled receivables (1) | 33 |  |  | — |  |
| Net investment in sales-type leases (2) | 248 |  |  | 225 |  |

[0000926326-20-000023:notes:19]
[same as prior period, unchanged from 0000926326-20-000014:notes:20]

[0000926326-20-000023:notes:20]
[same as prior period, unchanged from 0000926326-20-000014:notes:21]

[0000926326-20-000023:notes:21]
[same as prior period, unchanged from 0000926326-20-000014:notes:22]

[0000926326-20-000023:notes:22]
Changes in the allowances for credit losses were not significant for the three and six months ended June 30, 2020 and 2019.

[0000926326-20-000023:notes:23]
[same as prior period, unchanged from 0000926326-20-000014:notes:24]

[0000926326-20-000023:notes:24]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). The Company adopted ASU 2018-15 on January 1, 2020 on a prospective basis. The adoption of this guidance did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000926326-20-000023:notes:25]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans, and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans, and held-to-maturity debt securities, the standard replaced the current “incurred loss” approach with an “expected loss” model. Entities are required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. The Company adopted the new standard on January 1, 2020 using the modified retrospective transition method, which resulted in the recognition of an immaterial cumulative-effect adjustment to retained earnings.

[0000926326-20-000023:notes:26]
[same as prior period, unchanged from 0000926326-20-000014:notes:27]

[0000926326-20-000023:notes:27]
[same as prior period, unchanged from 0000926326-20-000014:notes:28]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-20-000023:notes:28]
[same as prior period, unchanged from 0000926326-20-000014:notes:29]

[0000926326-20-000023:notes:29]
[same as prior period, unchanged from 0000926326-20-000014:notes:30]

[0000926326-20-000023:notes:30]
[same as prior period, unchanged from 0000926326-20-000014:notes:31]

[0000926326-20-000023:notes:31]
Software. On premise or cloud-based subscription solutions that improve medication management and adherence outcomes or enable incremental functionality of the Company’s equipment.

[0000926326-20-000023:notes:32]
[same as prior period, unchanged from 0000926326-20-000014:notes:33]

[0000926326-20-000023:notes:33]
[same as prior period, unchanged from 0000926326-20-000014:notes:34]

[0000926326-20-000023:notes:34]
Professional services. Other customer services, such as technology-enabled services, training, and consulting.

[0000926326-20-000023:notes:35]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $1.7 million and $2.6 million for the three months ended June 30, 2020 and 2019, respectively, and $4.6 million and $4.8 million for the six months ended June 30, 2020 and 2019, respectively.

[0000926326-20-000023:notes:36]
[same as prior period, unchanged from 0000926326-20-000014:notes:37]

[0000926326-20-000023:notes:37]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and six months ended June 30, 2020 and 2019:

[0000926326-20-000023:notes:38]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |  |  |  |  |  |  |
| Hardware and software | $ | 116,919 |  |  | $ | 133,005 |  |  | $ | 259,352 |  |  | $ | 251,819 |  |
| Consumables | 18,063 |  |  | 21,795 |  |  | 41,333 |  |  | 45,502 |  |
| Other | 3,960 |  |  | 3,579 |  |  | 8,330 |  |  | 6,668 |  |
| Total product revenues | $ | 138,942 |  |  | $ | 158,379 |  |  | $ | 309,015 |  |  | $ | 303,989 |  |

[0000926326-20-000023:notes:39]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2020 and 2019:

[0000926326-20-000023:notes:40]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |  |  |  |  |  |  |
| United States | $ | 178,052 |  |  | $ | 195,811 |  |  | $ | 385,786 |  |  | $ | 375,831 |  |
| Rest of world (1) | 21,569 |  |  | 21,602 |  |  | 43,521 |  |  | 44,099 |  |
| Total revenues | $ | 199,621 |  |  | $ | 217,413 |  |  | $ | 429,307 |  |  | $ | 419,930 |  |

[0000926326-20-000023:notes:41]
[same as prior period, unchanged from 0000926326-20-000014:notes:42]

[0000926326-20-000023:notes:42]
[same as prior period, unchanged from 0000926326-20-000014:notes:43]

[0000926326-20-000023:notes:43]
[same as prior period, unchanged from 0000926326-20-000014:notes:44]

[0000926326-20-000023:notes:44]
|  | June 30,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Short-term unbilled receivables, net (1) | $ | 9,602 |  |  | $ | 11,707 |  |
| Long-term unbilled receivables, net (2) | 16,132 |  |  | 12,260 |  |
| Total contract assets | $ | 25,734 |  |  | $ | 23,967 |  |
| Short-term deferred revenues, net | $ | 107,940 |  |  | $ | 90,894 |  |
| Long-term deferred revenues | 6,101 |  |  | 7,083 |  |
| Total contract liabilities | $ | 114,041 |  |  | $ | 97,977 |  |

[0000926326-20-000023:notes:45]
[same as prior period, unchanged from 0000926326-20-000014:notes:46]

[0000926326-20-000023:notes:46]
[same as prior period, unchanged from 0000926326-20-000014:notes:47]

[0000926326-20-000023:notes:47]
[same as prior period, unchanged from 0000926326-20-000014:notes:48]

[0000926326-20-000023:notes:48]
Short-term deferred revenues of $107.9 million and $90.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $19.6 million and $13.1 million, as of June 30, 2020 and December 31, 2019, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and six months ended June 30, 2020, the Company recognized revenues of $20.9 million and $64.3 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $104.0 million as of December 31, 2019.

[0000926326-20-000023:notes:49]
Long-term deferred revenues include deferred revenues from service contracts of $6.1 million and $7.1 million as of June 30, 2020 and December 31, 2019, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-20-000023:notes:50]
[same as prior period, unchanged from 0000926326-20-000014:notes:51]

[0000926326-20-000023:notes:51]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2020 and 2019. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of June 30, 2020 and December 31, 2019.


## us-gaap:EarningsPerShareTextBlock

[0000926326-20-000023:notes:52]
Net Income (Loss) Per ShareBasic net income (loss) per share is computed by dividing net income (loss) for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units computed using the treasury stock method. Any anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share. 
The basic and diluted net income (loss) per share calculations for the three and six months ended June 30, 2020 and 2019 were as follows:

[0000926326-20-000023:notes:53]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands, except per share data) |  |  |  |  |  |  |
| Net income (loss) | $ | (4,299) |  |  | $ | 15,976 |  |  | $ | 7,012 |  |  | $ | 19,260 |  |
| Weighted-average shares outstanding — basic | 42,659 |  |  | 41,371 |  |  | 42,509 |  |  | 41,033 |  |
| Effect of dilutive securities from stock award plans | — |  |  | 1,574 |  |  | 1,107 |  |  | 1,613 |  |
| Weighted-average shares outstanding — diluted | 42,659 |  |  | 42,945 |  |  | 43,616 |  |  | 42,646 |  |
| Net income (loss) per share - basic | $ | (0.10) |  |  | $ | 0.39 |  |  | $ | 0.16 |  |  | $ | 0.47 |  |
| Net income (loss) per share - diluted | $ | (0.10) |  |  | $ | 0.37 |  |  | $ | 0.16 |  |  | $ | 0.45 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 4,931 |  |  | 741 |  |  | 1,929 |  |  | 748 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-20-000023:notes:54]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $133.6 million and $127.2 million as of June 30, 2020 and December 31, 2019, respectively, consisted of bank accounts with major financial institutions.

[0000926326-20-000023:notes:55]
[same as prior period, unchanged from 0000926326-20-000014:notes:56]

[0000926326-20-000023:notes:56]
[same as prior period, unchanged from 0000926326-20-000014:notes:57]

[0000926326-20-000023:notes:57]
[same as prior period, unchanged from 0000926326-20-000014:notes:58]

[0000926326-20-000023:notes:58]
[same as prior period, unchanged from 0000926326-20-000014:notes:59]

[0000926326-20-000023:notes:59]
[same as prior period, unchanged from 0000926326-20-000014:notes:60]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-20-000023:notes:60]
Balance Sheet Components
Balance sheet details as of June 30, 2020 and December 31, 2019 are presented in the tables below:

[0000926326-20-000023:notes:61]
|  | June 30,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Inventories: |  |  |  |
| Raw materials | $ | 32,101 |  |  | $ | 31,331 |  |
| Work in process | 7,833 |  |  | 7,620 |  |
| Finished goods | 74,311 |  |  | 69,060 |  |
| Total inventories | $ | 114,245 |  |  | $ | 108,011 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net | $ | 94,166 |  |  | $ | 85,070 |  |
| Unbilled receivables, net | 16,132 |  |  | 12,260 |  |
| Deferred debt issuance costs | 4,218 |  |  | 4,700 |  |
| Other assets | 1,681 |  |  | 1,006 |  |
| Total other long-term assets | $ | 116,197 |  |  | $ | 103,036 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 10,463 |  |  | $ | 10,058 |  |
| Advance payments from customers | 4,651 |  |  | 4,006 |  |
| Rebates and lease buyouts | 18,690 |  |  | 14,911 |  |
| Group purchasing organization fees | 4,250 |  |  | 5,934 |  |
| Taxes payable | 2,963 |  |  | 3,744 |  |
| Other accrued liabilities | 11,962 |  |  | 16,914 |  |
| Total accrued liabilities | $ | 52,979 |  |  | $ | 55,567 |  |

[0000926326-20-000023:notes:62]
The following tables summarize the changes in accumulated balances of other comprehensive income (loss) for the three and six months ended June 30, 2020 and 2019:

[0000926326-20-000023:notes:63]
|  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |  |
|  | 2020 |  |  |  |  |  | 2019 |  |  |  |  |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |  |  |  |  |  |  |  |  |  |  |
| Beginning balance | $ | (14,140) |  |  | $ | — |  |  | $ | (14,140) |  |  | $ | (10,605) |  |  | $ | 103 |  |  | $ | (10,502) |  |
| Other comprehensive income (loss) before reclassifications | 451 |  |  | — |  |  | 451 |  |  | (971) |  |  | 48 |  |  | (923) |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | — |  |  | — |  |  | — |  |  | (151) |  |  | (151) |  |
| Net current-period other comprehensive income (loss), net of tax | 451 |  |  | — |  |  | 451 |  |  | (971) |  |  | (103) |  |  | (1,074) |  |
| Ending balance | $ | (13,689) |  |  | $ | — |  |  | $ | (13,689) |  |  | $ | (11,576) |  |  | $ | — |  |  | $ | (11,576) |  |

[0000926326-20-000023:notes:64]
|  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |  |
|  | 2020 |  |  |  |  |  | 2019 |  |  |  |  |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |  |  |  |  |  |  |  |  |  |  |
| Beginning balance | $ | (9,446) |  |  | $ | — |  |  | $ | (9,446) |  |  | $ | (11,274) |  |  | $ | 420 |  |  | $ | (10,854) |  |
| Other comprehensive income (loss) before reclassifications | (4,243) |  |  | — |  |  | (4,243) |  |  | (302) |  |  | 148 |  |  | (154) |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | — |  |  | — |  |  | — |  |  | (568) |  |  | (568) |  |
| Net current-period other comprehensive income (loss), net of tax | (4,243) |  |  | — |  |  | (4,243) |  |  | (302) |  |  | (420) |  |  | (722) |  |
| Ending balance | $ | (13,689) |  |  | $ | — |  |  | $ | (13,689) |  |  | $ | (11,576) |  |  | $ | — |  |  | $ | (11,576) |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-20-000023:notes:65]
Property and Equipment 
The following table represents the property and equipment balances as of June 30, 2020 and December 31, 2019:

[0000926326-20-000023:notes:66]
|  | June 30,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Equipment | $ | 98,691 |  |  | $ | 88,569 |  |
| Furniture and fixtures | 7,878 |  |  | 7,925 |  |
| Leasehold improvements | 19,839 |  |  | 18,979 |  |
| Software | 49,424 |  |  | 48,309 |  |
| Construction in progress | 6,428 |  |  | 6,179 |  |
| Property and equipment, gross | 182,260 |  |  | 169,961 |  |
| Accumulated depreciation and amortization | (124,394) |  |  | (115,715) |  |
| Total property and equipment, net | $ | 57,866 |  |  | $ | 54,246 |  |

[0000926326-20-000023:notes:67]
Depreciation and amortization expense of property and equipment was $4.7 million and $4.4 million for the three months ended June 30, 2020 and 2019, respectively, and $9.0 million and $8.4 million for the six months ended June 30, 2020 and 2019, respectively.

[0000926326-20-000023:notes:68]
The geographic location of the Company's property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of June 30, 2020 and December 31, 2019:

[0000926326-20-000023:notes:69]
|  | June 30,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| United States | $ | 51,811 |  |  | $ | 48,769 |  |
| Rest of world (1) | 6,055 |  |  | 5,477 |  |
| Total property and equipment, net | $ | 57,866 |  |  | $ | 54,246 |  |

[0000926326-20-000023:notes:70]
[same as prior period, unchanged from 0000926326-20-000014:notes:70]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-20-000023:notes:71]
[same as prior period, unchanged from 0000926326-20-000014:notes:71]

[0000926326-20-000023:notes:72]
[same as prior period, unchanged from 0000926326-20-000014:notes:72]

[0000926326-20-000023:notes:73]
|  | December 31,2019 |  | Additions |  | Foreign currency exchange rate fluctuations |  | June 30,2020 |
|  | (In thousands) |  |  |  |  |  |  |
| Goodwill | $ | 336,539 |  |  | $ | — |  |  | $ | (1,505) |  |  | $ | 335,034 |  |

[0000926326-20-000023:notes:74]
[same as prior period, unchanged from 0000926326-20-000014:notes:74]

[0000926326-20-000023:notes:75]
The carrying amounts and useful lives of intangible assets as of June 30, 2020 and December 31, 2019 were as follows:

[0000926326-20-000023:notes:76]
|  | June 30, 2020 |  |  |  |  |  |  |  |  |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 134,889 |  |  | $ | (58,871) |  |  | $ | (1,360) |  |  | $ | 74,658 |  |  | 10 - 30 |
| Acquired technology | 77,029 |  |  | (40,033) |  |  | 5 |  |  | 37,001 |  |  | 5 - 20 |
| Backlog | 1,150 |  |  | (934) |  |  | — |  |  | 216 |  |  | 4 |
| Trade names | 7,650 |  |  | (5,374) |  |  | 10 |  |  | 2,286 |  |  | 6 - 12 |
| Patents | 3,217 |  |  | (1,669) |  |  | 1 |  |  | 1,549 |  |  | 2 - 20 |
| Total intangibles assets, net | $ | 223,935 |  |  | $ | (106,881) |  |  | $ | (1,344) |  |  | $ | 115,710 |  |  |  |

[0000926326-20-000023:notes:77]
[same as prior period, unchanged from 0000926326-20-000014:notes:77]

[0000926326-20-000023:notes:78]
[same as prior period, unchanged from 0000926326-20-000014:notes:78]

[0000926326-20-000023:notes:79]
Amortization expense of intangible assets was $4.4 million and $4.7 million for the three months ended June 30, 2020 and 2019, respectively, and $8.9 million and $9.5 million for the six months ended June 30, 2020 and 2019, respectively.

[0000926326-20-000023:notes:80]
[same as prior period, unchanged from 0000926326-20-000014:notes:80]

[0000926326-20-000023:notes:81]
|  | June 30,2020 |
|  | (In thousands) |
| Remaining six months of 2020 | $ | 8,592 |  |
| 2021 | 16,120 |  |
| 2022 | 14,770 |  |
| 2023 | 13,675 |  |
| 2024 | 7,916 |  |
| Thereafter | 54,637 |  |
| Total | $ | 115,710 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-20-000023:notes:82]
Debt and Credit Agreements
2016 Senior Credit Facility

[0000926326-20-000023:notes:83]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Prior Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Prior Term Loan Facility” and together with the Prior Revolving Credit Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Prior Credit Agreement had an expiration date of January 5, 2021, upon which date all remaining outstanding borrowings were due and payable.

[0000926326-20-000023:notes:84]
Loans under the Prior Facilities bore interest, at the Company’s option, at a rate equal to either (a) LIBOR, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Prior Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Prior Credit Agreement). Undrawn commitments under the Prior Revolving Credit Facility were subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Prior Revolving Credit Facility.

[0000926326-20-000023:notes:85]
On each of April 11, 2017 and December 26, 2017, the parties entered into amendments to the Prior Credit Agreement. Under these amendments, the Prior Revolving Credit Facility was increased from $200.0 million to $315.0 million, and certain other modifications were made. In connection with the December 2017 amendment, the Company incurred and capitalized an additional $2.1 million of debt issuance costs.

[0000926326-20-000023:notes:86]
2019 Revolving Credit Facility

[0000926326-20-000023:notes:87]
On November 15, 2019, the Company refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-20-000023:notes:88]
On November 15, 2019, the $80.0 million outstanding term loan balance under the Prior Facilities was transferred to the Current Revolving Credit Facility.

[0000926326-20-000023:notes:89]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) LIBOR, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate,

[0000926326-20-000023:notes:90]
(ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. The applicable margin for and certain other terms of any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

[0000926326-20-000023:notes:91]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total net leverage ratio and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of June 30, 2020.

[0000926326-20-000023:notes:92]
The refinancing of the Prior Credit Agreement was evaluated in accordance with Accounting Standards Codification (“ASC”) 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the A&R Credit Agreement.

[0000926326-20-000023:notes:93]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs was approximately $0.2 million and $0.6 million for the three months ended June 30, 2020 and 2019, respectively, and approximately $0.5 million and $1.1 million for the six months ended June 30, 2020 and 2019, respectively.

[0000926326-20-000023:notes:94]
Interest expense (exclusive of fees and debt issuance cost amortization) was approximately $0.9 million for the three months ended June 30, 2019, and approximately $0.2 million and $2.2 million for the six months ended June 30, 2020 and 2019, respectively. No interest expense was incurred during the three months ended June 30, 2020 as there was no outstanding balance under the Current Revolving Credit Facility during the three months ended June 30, 2020.

[0000926326-20-000023:notes:95]
The following table represents changes in the carrying amount of the Company’s debt obligations:

[0000926326-20-000023:notes:96]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | — |  |
| Repayments | (50,000) |  |
| Balance as of June 30, 2020 | $ | — |  |

[0000926326-20-000023:notes:97]
The following table represents changes in the balance of the Company's deferred debt issuance costs:

[0000926326-20-000023:notes:98]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | — |  |
| Amortization | (482) |  |
| Balance as of June 30, 2020 | $ | 4,218 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-20-000023:notes:99]
[same as prior period, unchanged from 0000926326-20-000014:notes:100]

[0000926326-20-000023:notes:100]
[same as prior period, unchanged from 0000926326-20-000014:notes:101]

[0000926326-20-000023:notes:101]
The following table presents the Company’s income recognized from sales-type leases for the three and six months ended June 30, 2020 and 2019:

[0000926326-20-000023:notes:102]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |  |  |  |  |  |  |
| Sales-type lease revenues | $ | 6,612 |  |  | $ | 13,309 |  |  | $ | 13,004 |  |  | $ | 24,816 |  |
| Cost of sales-type lease revenues | (2,655) |  |  | (5,575) |  |  | (5,224) |  |  | (10,395) |  |
| Selling profit on sales-type lease revenues | $ | 3,957 |  |  | $ | 7,734 |  |  | $ | 7,780 |  |  | $ | 14,421 |  |
| Interest income on sales-type lease receivables | $ | 526 |  |  | $ | 399 |  |  | $ | 987 |  |  | $ | 808 |  |

[0000926326-20-000023:notes:103]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at June 30, 2020 and December 31, 2019:

[0000926326-20-000023:notes:104]
|  | June 30,2020 |  | December 31,2019 |
|  | (In thousands) |  |  |
| Net minimum lease payments to be received | $ | 33,750 |  |  | $ | 32,360 |  |
| Less: Unearned interest income portion | (2,855) |  |  | (2,840) |  |
| Net investment in sales-type leases | 30,895 |  |  | 29,520 |  |
| Less: Current portion (1) | (9,934) |  |  | (9,770) |  |
| Long-term investment in sales-type leases, net | $ | 20,961 |  |  | $ | 19,750 |  |

[0000926326-20-000023:notes:105]
[same as prior period, unchanged from 0000926326-20-000014:notes:106]

[0000926326-20-000023:notes:106]
[same as prior period, unchanged from 0000926326-20-000014:notes:107]

[0000926326-20-000023:notes:107]
[same as prior period, unchanged from 0000926326-20-000014:notes:108]

[0000926326-20-000023:notes:108]
|  | June 30,2020 |
|  | (In thousands) |
| Remaining six months of 2020 | $ | 6,838 |  |
| 2021 | 8,769 |  |
| 2022 | 8,005 |  |
| 2023 | 5,802 |  |
| 2024 | 3,031 |  |
| Thereafter | 1,305 |  |
| Total future minimum sales-type lease payments | 33,750 |  |
| Present value adjustment | (2,855) |  |
| Total net investment in sales-type leases | $ | 30,895 |  |

[0000926326-20-000023:notes:109]
[same as prior period, unchanged from 0000926326-20-000014:notes:110]

[0000926326-20-000023:notes:110]
[same as prior period, unchanged from 0000926326-20-000014:notes:111]

[0000926326-20-000023:notes:111]
The following table represents the Company’s income recognized from operating leases for the three and six months ended June 30, 2020 and 2019:

[0000926326-20-000023:notes:112]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |  |  |  |  |  |  |
| Rental income | $ | 3,024 |  |  | $ | 3,365 |  |  | $ | 6,001 |  |  | $ | 6,652 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-20-000023:notes:113]
Lessee Leases The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to 12 years. As of June 30, 2020, the Company did not have any additional material operating leases that were entered into, but not yet commenced. 
The maturity schedule of future minimum lease payments under operating leases and the reconciliation to the operating lease liabilities reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-20-000023:notes:114]
|  | June 30,2020 |
|  | (In thousands) |
| Remaining six months of 2020 | $ | 6,890 |  |
| 2021 | 13,572 |  |
| 2022 | 12,296 |  |
| 2023 | 8,660 |  |
| 2024 | 8,059 |  |
| Thereafter | 20,170 |  |
| Total operating lease payments | 69,647 |  |
| Present value adjustment | (12,494) |  |
| Total operating lease liabilities (1) | $ | 57,153 |  |

[0000926326-20-000023:notes:115]
(1) Amount consists of a current and long-term portion of operating lease liabilities of $10.5 million and $46.7 million, respectively. The short-term portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-20-000023:notes:116]
Operating lease costs were $3.4 million and $3.6 million for the three months ended June 30, 2020 and 2019, respectively, and $7.0 million and $7.3 million for the six months ended June 30, 2020 and 2019, respectively. Short-term lease costs and variable lease costs were immaterial for the three and six months ended June 30, 2020 and 2019.

[0000926326-20-000023:notes:117]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the six months ended June 30, 2020 and 2019:

[0000926326-20-000023:notes:118]
|  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |
|  | (In thousands) |  |  |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 7,067 |  |  | $ | 7,391 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 1,335 |  |  | $ | 557 |  |

[0000926326-20-000023:notes:119]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of June 30, 2020 and December 31, 2019:

[0000926326-20-000023:notes:120]
|  | June 30,2020 |  | December 31,2019 |
| Weighted-average remaining lease term, years | 6.1 |  | 6.4 |
| Weighted-average discount rate, % | 6.4 | % |  | 6.4 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-20-000023:notes:121]
Commitments and Contingencies
Purchase Obligations

[0000926326-20-000023:notes:122]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2020, the Company had non-cancelable purchase commitments of $66.3 million, of which $64.7 million are expected to be paid within the year ending December 31, 2020.

[0000926326-20-000023:notes:123]
Legal Proceedings

[0000926326-20-000023:notes:124]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows

[0000926326-20-000023:notes:125]
or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

[0000926326-20-000023:notes:126]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its former subsidiaries, Aesynt Incorporated (“Aesynt”), which, through a series of mergers, has been merged into the Company, in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint sought monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice. On August 21, 2019, a new lawsuit was filed against the Company and Aesynt, in the Circuit Court for the County of Albemarle, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Aesynt Incorporated, et al., Case No CL19-1301. The complaint seeks monetary recovery of damages based upon claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not been served with the complaint. The Company intends to defend the lawsuit vigorously.

[0000926326-20-000023:notes:127]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (a class action lawsuit filed against a customer of the Company, the customer’s parent company, and two vendors of medication dispensing systems, one of which is the Company, seeking statutory damages and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of the Illinois Biometric Information Privacy Act (“BIPA”) and of negligence by the defendants from which the Company was subsequently dismissed without prejudice) (“Mazya Action”), together with claims for reimbursement and unjust enrichment relating to the defense of the Mazya Action in the form of attorneys’ fees and other related costs. The Company has not responded to the complaint. On February 12, 2019, the Court stayed the action pending the outcome of the Mazya Action and administratively closed the case. On October 15, 2019, the plaintiffs filed a notice advising the Court of the dismissal of the Company from the Mazya Action and requesting that the Court lift the stay in the case and set dates for filing a responsive pleading by the Company and initial discovery and scheduling matters. By order dated November 13, 2019, the Court (i) lifted the stay in the case, (ii) set a case management conference for February 5, 2020, and (iii) ordered the parties to file a joint case management statement by January 29, 2020. The parties subsequently reached a settlement of the case in principle and the Court, after notice of the parties, continued the case management conference until April 29, 2020. The parties entered into a written settlement agreement on April 9, 2020. Since the conditions precedent in the settlement agreement to dismissing the case had not yet been fulfilled, the Court, upon the petition of the parties, again continued the case management conference until May 27, 2020. Upon fulfillment of the conditions precedent to finalizing the settlement, the plaintiffs filed a notice of dismissal with prejudice on May 4, 2020, thereby finally terminating the action.

[0000926326-20-000023:notes:128]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of BIPA, and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the Mazya Action. The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The motion to dismiss is fully-briefed. The hearing on the Company’s motion to dismiss was previously set for March 16, 2020, was continued to May 27, 2020, and then was subsequently continued again to September 2, 2020. The Company intends to defend the lawsuit vigorously.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-20-000023:notes:129]
Income Taxes The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 28.0% and 24.8% for the six months ended June 30, 2020 and 2019, respectively. The Company’s effective tax rate for the six months ended June 30, 2020 was based on best estimates, which may fluctuate through the remainder of the year due to the volatility and uncertainty of global economic conditions in connection with the COVID-19 pandemic.
Due to continuing global operational centralization activities and legal entity rationalization, the Company recognized gain on the sale of certain intellectual property rights by Aesynt B.V. to Omnicell, Inc., which resulted in a tax expense, net of tax benefit, of $9.6 million during the six months ended June 30, 2019. In March 2020, Aesynt B.V. subsequently merged with and into Aesynt Holding B.V., with Aesynt Holding B.V. surviving and changing its name to Omnicell B.V. The Company did not recognize a gain or loss from such activities during the six months ended June 30, 2020. The Company also recognized a discrete tax benefit related to equity compensation in the amount of $3.3 million and $7.0 million for the six months ended June 30, 2020 and 2019, respectively.

[0000926326-20-000023:notes:130]
The 2020 annual effective tax rate before discrete items differed from the statutory rate of 21% primarily due to the unfavorable impact of state income taxes, non-deductible compensation and equity charges, and non-deductible expenses, partially offset by the favorable impact of research and development credits and foreign derived intangible income (“FDII”) benefit deduction. The 2019 annual effective tax rate before discrete items differed from the statutory rate of 21% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and non-deductible expenses, partially offset by the favorable impact of research and development credits, foreign rate differential, and FDII benefit deduction.

[0000926326-20-000023:notes:131]
On March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was signed into law in response to the COVID-19 pandemic. The CARES Act, among other provisions, includes provisions related to refundable payroll tax credits, deferment of the employer portion of certain payroll taxes, net operation losses carryback periods, alternative minimum tax credit refunds, modification to net interest expense deduction limitation, and technical amendments to tax depreciation methods for qualified improvement property placed in service after December 31, 2017. The provisions of the CARES Act did not have a material impact on the Company’s income taxes.

[0000926326-20-000023:notes:132]
As of June 30, 2020 and December 31, 2019, the Company had gross unrecognized tax benefits of $17.3 million and $16.8 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. As of June 30, 2020 and December 31, 2019, the amount of accrued interest and penalties was $1.1 million and $1.0 million, respectively.

[0000926326-20-000023:notes:133]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of June 30, 2020, the Company was no longer subject to United States, state, and foreign examination for years before 2016, 2015, and 2015, respectively.

[0000926326-20-000023:notes:134]
[same as prior period, unchanged from 0000926326-20-000014:notes:138]


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-20-000023:notes:135]
[same as prior period, unchanged from 0000926326-20-000014:notes:139]

[0000926326-20-000023:notes:136]
[same as prior period, unchanged from 0000926326-20-000014:notes:140]

[0000926326-20-000023:notes:137]
[same as prior period, unchanged from 0000926326-20-000014:notes:141]

[0000926326-20-000023:notes:138]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2020 and 2019:

[0000926326-20-000023:notes:139]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |  |  |  |  |  |  |
| Cost of product and service revenues | $ | 2,130 |  |  | $ | 1,416 |  |  | $ | 3,900 |  |  | $ | 2,878 |  |
| Research and development | 1,854 |  |  | 1,584 |  |  | 3,622 |  |  | 3,286 |  |
| Selling, general, and administrative | 7,367 |  |  | 5,260 |  |  | 14,488 |  |  | 10,506 |  |
| Total share-based compensation expense | $ | 11,351 |  |  | $ | 8,260 |  |  | $ | 22,010 |  |  | $ | 16,670 |  |

[0000926326-20-000023:notes:140]
[same as prior period, unchanged from 0000926326-20-000014:notes:144]

[0000926326-20-000023:notes:141]
The following assumptions were used to value stock options and Employee Stock Purchase Plan (“ESPP”) shares granted pursuant to the Company’s equity incentive plans for the three and six months ended June 30, 2020 and 2019:

[0000926326-20-000023:notes:142]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Stock options |  |  |  |  |  |  |  |
| Expected life, years | 4.7 |  | 4.3 |  | 4.7 |  | 4.4 |
| Expected volatility, % | 42.2 | % |  | 33.2 | % |  | 37.9 | % |  | 33.2 | % |
| Risk-free interest rate, % | 0.5 | % |  | 2.1 | % |  | 0.9 | % |  | 2.3 | % |
| Estimated forfeiture rate, % | 5.7 | % |  | 7.2 | % |  | 5.7 | % |  | 7.2 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-20-000023:notes:143]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Employee stock purchase plan shares |  |  |  |  |  |  |  |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Expected volatility, % | 30.4% - 39.9% |  | 28.2% - 38.4% |  | 30.4% - 39.9% |  | 28.2% - 38.4% |
| Risk-free interest rate, % | 1.4% - 2.7% |  | 1.3% - 2.7% |  | 1.4% - 2.7% |  | 1.3% - 2.7% |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-20-000023:notes:144]
[same as prior period, unchanged from 0000926326-20-000014:notes:148]

[0000926326-20-000023:notes:145]
The following table summarizes the share option activity under the Company’s equity incentive plans during the six months ended June 30, 2020:

[0000926326-20-000023:notes:146]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |  |  |  |  |  |  |
| Outstanding at December 31, 2019 | 3,902 |  |  | $ | 52.75 |  |  | 7.7 |  | $ | 113,198 |  |
| Granted | 674 |  |  | 80.63 |  |  |  |  |  |
| Exercised | (315) |  |  | 37.28 |  |  |  |  |  |
| Expired | (7) |  |  | 56.83 |  |  |  |  |  |
| Forfeited | (126) |  |  | 62.61 |  |  |  |  |  |
| Outstanding at June 30, 2020 | 4,128 |  |  | $ | 58.17 |  |  | 7.4 |  | $ | 65,499 |  |
| Exercisable at June 30, 2020 | 1,699 |  |  | $ | 41.50 |  |  | 6.0 |  | $ | 50,644 |  |
| Vested and expected to vest at June 30, 2020 and thereafter | 3,945 |  |  | $ | 57.46 |  |  | 7.3 |  | $ | 64,859 |  |

[0000926326-20-000023:notes:147]
The weighted-average fair value per share of options granted during the three months ended June 30, 2020 and 2019 was $26.03 and $24.40, respectively, and the weighted-average fair value per share of options granted during the six months ended June 30, 2020 and 2019 was $26.21 and $24.20, respectively. The intrinsic value of options exercised during the three months ended June 30, 2020 and 2019 was $2.5 million and $7.2 million, respectively, and during the six months ended June 30, 2020 and 2019 was $12.4 million and $24.3 million, respectively.

[0000926326-20-000023:notes:148]
As of June 30, 2020, total unrecognized compensation cost related to unvested stock options was $47.4 million, which is expected to be recognized over a weighted-average vesting period of 2.8 years.

[0000926326-20-000023:notes:149]
[same as prior period, unchanged from 0000926326-20-000014:notes:153]

[0000926326-20-000023:notes:150]
For the six months ended June 30, 2020 and 2019, employees purchased approximately 217,000 and 210,000 shares of common stock, respectively, under the ESPP at weighted average prices of $43.51 and $40.20, respectively. As of June 30, 2020, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $5.5 million and is expected to be recognized over a weighted-average period of 1.2 years.

[0000926326-20-000023:notes:151]
[same as prior period, unchanged from 0000926326-20-000014:notes:155]

[0000926326-20-000023:notes:152]
Summaries of the restricted stock activity under the Company’s 2009 Equity Incentive Plan, as amended (the “2009 Plan”) are presented below for the six months ended June 30, 2020:

[0000926326-20-000023:notes:153]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |  |  |  |  |  |  |
| Restricted stock units |  |  |  |  |  |  |  |
| Outstanding at December 31, 2019 | 544 |  |  | $ | 66.65 |  |  | 1.6 |  | $ | 44,492 |  |
| Granted (Awarded) | 89 |  |  | 81.25 |  |  |  |  |  |
| Vested (Released) | (81) |  |  | 56.57 |  |  |  |  |  |
| Forfeited | (41) |  |  | 63.67 |  |  |  |  |  |
| Outstanding and unvested at June 30, 2020 | 511 |  |  | $ | 71.03 |  |  | 1.5 |  | $ | 36,062 |  |

[0000926326-20-000023:notes:154]
As of June 30, 2020, total unrecognized compensation cost related to RSUs was $32.5 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.9 years.

[0000926326-20-000023:notes:155]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |  |  |
| Restricted stock awards |  |  |  |
| Outstanding at December 31, 2019 | 17 |  |  | $ | 81.92 |  |
| Granted (Awarded) | 21 |  |  | 68.11 |  |
| Vested (Released) | (17) |  |  | 81.92 |  |
| Outstanding and unvested at June 30, 2020 | 21 |  |  | $ | 68.11 |  |

[0000926326-20-000023:notes:156]
As of June 30, 2020, total unrecognized compensation cost related to RSAs was $1.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.9 years.

[0000926326-20-000023:notes:157]
[same as prior period, unchanged from 0000926326-20-000014:notes:161]

[0000926326-20-000023:notes:158]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below for the six months ended June 30, 2020:

[0000926326-20-000023:notes:159]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |  |  |
| Outstanding at December 31, 2019 | 134 |  |  | $ | 55.82 |  |
| Granted | 63 |  |  | 82.41 |  |
| Vested | (44) |  |  | 54.25 |  |
| Forfeited | (5) |  |  | 81.72 |  |
| Outstanding and unvested at June 30, 2020 | 148 |  |  | $ | 66.69 |  |

[0000926326-20-000023:notes:160]
As of June 30, 2020, total unrecognized compensation cost related to PSUs was approximately $5.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.4 years.

[0000926326-20-000023:notes:161]
[same as prior period, unchanged from 0000926326-20-000014:notes:165]

[0000926326-20-000023:notes:162]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of June 30, 2020:

[0000926326-20-000023:notes:163]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 4,128 |  |
| Non-vested restricted stock awards | 680 |  |
| Shares authorized for future issuance | 2,029 |  |
| ESPP shares available for future issuance | 1,322 |  |
| Total shares reserved for future issuance | 8,159 |  |

[0000926326-20-000023:notes:164]
[same as prior period, unchanged from 0000926326-20-000014:notes:168]

[0000926326-20-000023:notes:165]
On August 2, 2016, the Company's Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014. As of June 30, 2020, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase programs at any time.
During the three and six months ended June 30, 2020 and 2019, the Company did not repurchase any of its outstanding common stock.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-20-000023:notes:166]
[same as prior period, unchanged from 0000926326-20-000014:notes:170]

[0000926326-20-000023:notes:167]
For the three and six months ended June 30, 2020, the Company did not sell any of its common stock under the Distribution Agreement.

[0000926326-20-000023:notes:168]
For the three months ended June 30, 2019, the Company received gross proceeds of $17.9 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.3 million on sales of approximately 217,000 shares of its common stock at an average price of approximately $82.51 per share.

[0000926326-20-000023:notes:169]
For the six months ended June 30, 2019, the Company received gross proceeds of $38.5 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 460,000 shares of its common stock at an average price of approximately $83.81 per share.

[0000926326-20-000023:notes:170]
As of June 30, 2020, the Company had an aggregate of $31.5 million available to be offered under the Distribution Agreement.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-20-000023:notes:171]
Restructuring ExpensesIn the first quarter of 2020, the Company announced a company-wide organizational realignment initiative in order to more effectively align its organizational infrastructure and operations with the strategic vision of the autonomous pharmacy. In the second quarter of 2020, the Company continued its organizational realignment initiative, as well as initiated a restructuring plan to help mitigate the adverse impact of the COVID-19 pandemic on its business and financial results. During the three and six months ended June 30, 2020, the Company incurred and accrued $6.4 million and $10.0 million, respectively, of employee severance costs and related expenses. As of June 30, 2020, the unpaid balance related to this restructuring plan was $6.6 million.
The following table summarizes the total restructuring expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2020:

[0000926326-20-000023:notes:172]
|  | Three Months Ended June 30, 2020 |  |  |  | Six Months Ended June 30, 2020 |  |  |
|  | (In thousands) |  |  |  |  |  |  |
| Cost of product and service revenues | $ | 2,489 |  |  |  |  | $ | 2,564 |  |  |  |
| Research and development | 2,918 |  |  |  |  | 3,716 |  |  |  |
| Selling, general, and administrative | 949 |  |  |  |  | 3,681 |  |  |  |
| Total restructuring expense | $ | 6,356 |  |  |  |  | $ | 9,961 |  |  |  |
