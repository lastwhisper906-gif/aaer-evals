# OMCL 8-K — 0000926326-20-000021 filed 2020-07-28

## item codes, every 8-K on or before 2020-07-31

- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2020-07-31

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-20-000021:8k_2_02:1]
EX-99.1
2
exhibit991q2-20.htm
EX-99.1

[0000926326-20-000021:8k_2_02:2]
Document

[0000926326-20-000021:8k_2_02:3]
Exhibit 99.1

[0000926326-20-000021:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664 |  | Mountain View, CA 94043 |
| Peter.Kuipers@Omnicell.com |  |  |

[0000926326-20-000021:8k_2_02:5]
Omnicell Reports Second Quarter 2020 Results

[0000926326-20-000021:8k_2_02:6]
GAAP revenues of $199.6 million and net loss per diluted share of $0.10

[0000926326-20-000021:8k_2_02:7]
Non-GAAP revenues $199.6 million and net income per diluted share of $0.37

[0000926326-20-000021:8k_2_02:8]
Omnicell’s Response to Coronavirus (COVID-19)

[0000926326-20-000021:8k_2_02:9]
MOUNTAIN VIEW, Calif. -- July 28, 2020 -- Omnicell, Inc. (NASDAQ:OMCL), a leading provider of medication management solutions and adherence tools for healthcare systems and pharmacies, today announced results for its second quarter ended June 30, 2020.

[0000926326-20-000021:8k_2_02:10]
GAAP Results

[0000926326-20-000021:8k_2_02:11]
GAAP revenues for the second quarter of 2020 were $199.6 million, down $17.8 million, or 8.2% from the second quarter of 2019. GAAP revenues for the six months ended June 30, 2020 were $429.3 million, up $9.4 million, or 2.2% from the six months ended June 30, 2019.

[0000926326-20-000021:8k_2_02:12]
Second quarter 2020 GAAP net loss was $4.3 million, or $0.10 per diluted share. This compares to GAAP net income of $16.0 million, or $0.37 per diluted share, for the second quarter of 2019.

[0000926326-20-000021:8k_2_02:13]
GAAP net income for the six months ended June 30, 2020 was $7.0 million, or $0.16 per diluted share. This compares to GAAP net income of $19.3 million, or $0.45 per diluted share, for the six months ended June 30, 2019.

[0000926326-20-000021:8k_2_02:14]
Non-GAAP Results

[0000926326-20-000021:8k_2_02:15]
Non-GAAP revenues for the second quarter of 2020 were $199.6 million, down $17.8 million, or 8.2%, from the second quarter of 2019. Non-GAAP revenues for the six months ended June 30, 2020 were $429.3 million, up $9.4 million, or 2.2%, from the six months ended June 30, 2019.

[0000926326-20-000021:8k_2_02:16]
Non-GAAP net income for the second quarter of 2020 was $15.9 million, or $0.37 per diluted share. This compares to non-GAAP net income of $28.7 million, or $0.67 per diluted share, for the second quarter of 2019.

[0000926326-20-000021:8k_2_02:17]
Non-GAAP net income for the six months ended June 30, 2020 was $44.8 million, or $1.03 per diluted share. This compares to non-GAAP net income of $54.5 million, or $1.28 per diluted share, for the six months ended June 30, 2019.

[0000926326-20-000021:8k_2_02:18]
Non-GAAP net income for each period excludes, when applicable, the effect of share-based compensation expense, amortization expense of acquired intangible assets, acquisition-related expenses, restructuring and severance-related expenses, tax restructuring benefits and expenses, and amortization of debt issuance costs.

[0000926326-20-000021:8k_2_02:19]
Omnicell’s Response to Coronavirus (COVID-19)

[0000926326-20-000021:8k_2_02:20]
Keeping in mind our role in the healthcare industry, we are continuing to closely monitor the COVID-19 pandemic. Our top priorities remain protecting the health and well-being of our customers, their patients, and our employees, while maintaining business continuity to meet the needs of our customers. Our manufacturing and distribution facilities have remained open due to our qualification as an essential business and to date, we have not experienced disruptions in our manufacturing activities. The vast majority of our non-manufacturing and non-customer facing personnel have transitioned to a work from home

[0000926326-20-000021:8k_2_02:21]
environment. In addition, our supply chain and implementation capacity is fully available and we have experienced no shortages.

[0000926326-20-000021:8k_2_02:22]
To support the needs of our customers on the frontline of the pandemic, during the first quarter of 2020, we launched a Rapid Response program to fast-track production and deployment of our XT Series automated dispensing systems to our customers. We streamlined our ordering and installation processes with preconfigured XT Series medication and supply dispensing systems designed to offer our customers flexibility and maximum emergency impact. In addition, to minimize the need for on-site visits and respect social distancing protocols, we are providing remote service options, training programs, and product demonstrations for our customers, leveraging technology to enable our sales team to operate in a remote sales environment, as well as providing our customers with options to self-install certain automation products.

[0000926326-20-000021:8k_2_02:23]
During the second quarter of 2020, we continued to see some delays in product bookings and expect to see lower product bookings and revenues during the fiscal year 2020 compared to management’s expectations prior to the COVID-19 outbreak. Additionally, our ability to access hospitals in order to perform implementations of capital equipment has been delayed in some cases, as many hospitals are consumed with treating sick patients. While the environment continues to change rapidly, we are beginning to see more positive indicators for our business in terms of both product bookings and revenues. In many regions, elective surgeries have resumed, and we have been able to resume some on-site sales activities in regions less impacted by COVID-19. Additionally, the overall level of system implementations has also been increasing. Based on management's current expectations, we believe that the product bookings and revenues in the second quarter of 2020 represent the lowest quarter of 2020, and we expect that product bookings and revenues will increase sequentially through the third and fourth quarters of 2020. Although there are some encouraging signs for our business medium-term, we believe hospital spending and access for implementations will continue to be disrupted in the near- to medium-term and it is not possible to predict how long this pattern will continue.

[0000926326-20-000021:8k_2_02:24]
While our fiscal year 2020 results will be impacted by the challenges and opportunities brought on by the COVID-19 pandemic, we remain confident in the overall health of our business, in our ability to navigate through these unusual times, and in our ability to continue to execute on our long-term strategy, as we believe our customers and potential customers are increasingly embracing the vision of a fully autonomous pharmacy. However, the full impact of the COVID-19 pandemic and related containment measures cannot be predicted and to date, the COVID-19 pandemic and related containment measures have adversely affected and we expect they may continue to adversely affect, perhaps materially, our business, results of operations, financial condition, and liquidity.

[0000926326-20-000021:8k_2_02:25]
“We continue to deliver on the journey to the fully autonomous pharmacy through innovative, new solutions like Omnicell One – announced earlier this month – that combine technology and intelligence designed to help our healthcare partners navigate a rapidly changing landscape and deliver safe, high-quality patient care,” said Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell.

[0000926326-20-000021:8k_2_02:26]
2020 Guidance

[0000926326-20-000021:8k_2_02:27]
For the third quarter of 2020, the Company expects non-GAAP total revenues to be between $204 million and $212 million. The Company expects non-GAAP product revenues to be between $143 million and $149 million, and non-GAAP service revenues to be between $61 million and $63 million. The Company expects third quarter 2020 non-GAAP earnings to be between $0.44 and $0.52 per share.

[0000926326-20-000021:8k_2_02:28]
The table below summarizes Omnicell's third quarter 2020 guidance outlined above.

[0000926326-20-000021:8k_2_02:29]
|  | Q3'20 |  |
| Product Bookings | Not provided |  |
| Non-GAAP Total Revenues | $204 million - $212 million |  |
| Non-GAAP Product Revenues | $143 million - $149 million |  |
| Non-GAAP Service Revenues | $61 million - $63 million |  |
| Non-GAAP EPS | $0.44 - $0.52 |  |

[0000926326-20-000021:8k_2_02:30]
As a result of the uncertainty surrounding the COVID-19 pandemic, including due to the uncertain scope, duration, and impact of the pandemic and uncertain timing of global recovery and economic normalization, the Company withdrew its previously issued full year 2020 financial guidance that was provided on February 6, 2020, and remains unable to provide full year 2020 guidance at this time. These forward-looking measures and their underlying assumptions involve significant risks and uncertainties, including those described below, and actual results may vary significantly from these current forward-looking measures.

[0000926326-20-000021:8k_2_02:31]
Omnicell Conference Call Information

[0000926326-20-000021:8k_2_02:32]
Omnicell will hold a conference call today, Tuesday, July 28, 2020 at 1:30 p.m. PT to discuss second quarter 2020 financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 2686514. Internet users can access the conference call at http://ir.omnicell.com/communications/events-presentations. A replay of the call will be available today at approximately 5:00 p.m. PT and will be available until 11:59 p.m. PT on August 29, 2020. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 2686514.

[0000926326-20-000021:8k_2_02:33]
About Omnicell

[0000926326-20-000021:8k_2_02:34]
Since 1992, Omnicell has been committed to transforming the pharmacy care delivery model to dramatically improve outcomes and lower costs. Through the vision of the autonomous pharmacy, a combination of automation, intelligence, and expert services, powered by a cloud data platform, Omnicell supports more efficient ways to manage medications across all care settings.

[0000926326-20-000021:8k_2_02:35]
Over 6,000 facilities worldwide use Omnicell automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 40,000 institutional and retail pharmacies across North America and the United Kingdom leverage Omnicell's innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-20-000021:8k_2_02:36]
To learn more, visit www.omnicell.com. From time to time, Omnicell may use the Company's investor relations site and other online social media channels, including its Twitter handle www.twitter.com/omnicell, LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure ("FD").

[0000926326-20-000021:8k_2_02:37]
Omnicell and the Omnicell logo are registered trademarks of Omnicell, Inc. in the United States and other countries.

[0000926326-20-000021:8k_2_02:38]
Forward-Looking Statements

[0000926326-20-000021:8k_2_02:39]
Use of Non-GAAP Financial Information

[0000926326-20-000021:8k_2_02:40]
This press release contains financial measures that are not calculated in accordance with GAAP. Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, non-GAAP net income per diluted share, adjusted EBITDA, and non-GAAP free cash flow. These non-GAAP results should not be considered as an alternative to revenues, gross profit, operating expenses, net income, net income per diluted share, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-20-000021:8k_2_02:41]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, non-GAAP net income per diluted share, and adjusted EBITDA are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-20-000021:8k_2_02:42]
a)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-20-000021:8k_2_02:43]
b)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-20-000021:8k_2_02:44]
c)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The costs include underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-20-000021:8k_2_02:45]
d)Severance and other related expenses. We excluded from our non-GAAP results the expenses which are related to restructuring events. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies.

[0000926326-20-000021:8k_2_02:46]
e)Tax impact from intellectual property (“IP”) restructuring. We excluded from our non-GAAP results the tax impacts related to IP restructuring. These impacts are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these impacts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies.

[0000926326-20-000021:8k_2_02:47]
f)IP and legal entities restructuring costs. We excluded from our non-GAAP results the expenses which are related to IP and legal entities restructuring events, such as legal and tax consulting costs. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies.

[0000926326-20-000021:8k_2_02:48]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans or other items.

[0000926326-20-000021:8k_2_02:49]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-20-000021:8k_2_02:50]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-20-000021:8k_2_02:51]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-20-000021:8k_2_02:52]
c)These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting.

[0000926326-20-000021:8k_2_02:53]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-20-000021:8k_2_02:54]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-20-000021:8k_2_02:55]
i)While share-based compensation calculated in accordance with Accounting Standard Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-20-000021:8k_2_02:56]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-20-000021:8k_2_02:57]
Our adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 share-based compensation expense, as well as certain non-GAAP adjustments.

[0000926326-20-000021:8k_2_02:58]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-20-000021:8k_2_02:59]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-20-000021:8k_2_02:60]
a)Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-20-000021:8k_2_02:61]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-20-000021:8k_2_02:62]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-20-000021:8k_2_02:63]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-20-000021:8k_2_02:64]
Our third quarter 2020 guidance for non-GAAP earnings per share, non-GAAP total revenues, non-GAAP product revenues, and non-GAAP service revenues, as well as certain projections to be discussed in the conference call noted above, exclude “certain items,” which include but are not limited to: unusual gains and losses; costs associated with future restructurings; acquisition-related expenses; and certain tax and litigation outcomes. We do not provide a reconciliation of forward-looking non-GAAP guidance to the comparable GAAP measures as these items are inherently uncertain and difficult to estimate, and

[0000926326-20-000021:8k_2_02:65]
cannot be predicted without unreasonable effort. We believe such a reconciliation would imply a degree of precision that could be confusing to investors. These items may also have a material impact on GAAP earnings per share, total revenues, product revenues, and service revenues in future periods.

[0000926326-20-000021:8k_2_02:66]
6

[0000926326-20-000021:8k_2_02:67]
Omnicell, Inc.

[0000926326-20-000021:8k_2_02:68]
Condensed Consolidated Statements of Operations

[0000926326-20-000021:8k_2_02:69]
(Unaudited, in thousands, except per share data)

[0000926326-20-000021:8k_2_02:70]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 138,942 |  |  | $ | 158,379 |  |  | $ | 309,015 |  |  | $ | 303,989 |  |
| Services and other revenues | 60,679 |  |  | 59,034 |  |  | 120,292 |  |  | 115,941 |  |
| Total revenues | 199,621 |  |  | 217,413 |  |  | 429,307 |  |  | 419,930 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 85,779 |  |  | 84,583 |  |  | 176,051 |  |  | 163,394 |  |
| Cost of services and other revenues | 30,617 |  |  | 28,785 |  |  | 60,409 |  |  | 55,374 |  |
| Total cost of revenues | 116,396 |  |  | 113,368 |  |  | 236,460 |  |  | 218,768 |  |
| Gross profit | 83,225 |  |  | 104,045 |  |  | 192,847 |  |  | 201,162 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 20,830 |  |  | 16,848 |  |  | 39,482 |  |  | 32,926 |  |
| Selling, general, and administrative | 69,386 |  |  | 68,434 |  |  | 148,205 |  |  | 136,712 |  |
| Total operating expenses | 90,216 |  |  | 85,282 |  |  | 187,687 |  |  | 169,638 |  |
| Income (loss) from operations | (6,991) |  |  | 18,763 |  |  | 5,160 |  |  | 31,524 |  |
| Interest and other income (expense), net | 174 |  |  | (1,629) |  |  | (648) |  |  | (3,039) |  |
| Income (loss) before provision for income taxes | (6,817) |  |  | 17,134 |  |  | 4,512 |  |  | 28,485 |  |
| Provision for (benefit from) income taxes | (2,518) |  |  | 1,158 |  |  | (2,500) |  |  | 9,225 |  |
| Net income (loss) | $ | (4,299) |  |  | $ | 15,976 |  |  | $ | 7,012 |  |  | $ | 19,260 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.10) |  |  | $ | 0.39 |  |  | $ | 0.16 |  |  | $ | 0.47 |  |
| Diluted | $ | (0.10) |  |  | $ | 0.37 |  |  | $ | 0.16 |  |  | $ | 0.45 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 42,659 |  |  | 41,371 |  |  | 42,509 |  |  | 41,033 |  |
| Diluted | 42,659 |  |  | 42,945 |  |  | 43,616 |  |  | 42,646 |  |

[0000926326-20-000021:8k_2_02:71]
7

[0000926326-20-000021:8k_2_02:72]
Omnicell, Inc.

[0000926326-20-000021:8k_2_02:73]
Condensed Consolidated Balance Sheets

[0000926326-20-000021:8k_2_02:74]
(Unaudited, in thousands)

[0000926326-20-000021:8k_2_02:75]
|  | June 30,2020 |  | December 31,2019 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 133,583 |  |  | $ | 127,210 |  |
| Accounts receivable and unbilled receivables, net | 188,918 |  |  | 218,362 |  |
| Inventories | 114,245 |  |  | 108,011 |  |
| Prepaid expenses | 13,297 |  |  | 14,478 |  |
| Other current assets | 15,122 |  |  | 15,177 |  |
| Total current assets | 465,165 |  |  | 483,238 |  |
| Property and equipment, net | 57,866 |  |  | 54,246 |  |
| Long-term investment in sales-type leases, net | 20,961 |  |  | 19,750 |  |
| Operating lease right-of-use assets | 52,537 |  |  | 56,130 |  |
| Goodwill | 335,034 |  |  | 336,539 |  |
| Intangible assets, net | 115,710 |  |  | 124,867 |  |
| Long-term deferred tax assets | 14,154 |  |  | 14,142 |  |
| Prepaid commissions | 44,822 |  |  | 48,862 |  |
| Other long-term assets | 116,197 |  |  | 103,036 |  |
| Total assets | $ | 1,222,446 |  |  | $ | 1,240,810 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 34,587 |  |  | $ | 46,380 |  |
| Accrued compensation | 41,057 |  |  | 44,155 |  |
| Accrued liabilities | 52,979 |  |  | 55,567 |  |
| Deferred revenues, net | 107,940 |  |  | 90,894 |  |
| Total current liabilities | 236,563 |  |  | 236,996 |  |
| Long-term deferred revenues | 6,101 |  |  | 7,083 |  |
| Long-term deferred tax liabilities | 29,561 |  |  | 39,090 |  |
| Long-term operating lease liabilities | 46,690 |  |  | 50,669 |  |
| Other long-term liabilities | 16,070 |  |  | 11,718 |  |
| Long-term debt | — |  |  | 50,000 |  |
| Total liabilities | 334,985 |  |  | 395,556 |  |
| Total stockholders’ equity | 887,461 |  |  | 845,254 |  |
| Total liabilities and stockholders’ equity | $ | 1,222,446 |  |  | $ | 1,240,810 |  |

[0000926326-20-000021:8k_2_02:76]
Omnicell, Inc.

[0000926326-20-000021:8k_2_02:77]
Condensed Consolidated Statements of Cash Flows

[0000926326-20-000021:8k_2_02:78]
(Unaudited, in thousands)

[0000926326-20-000021:8k_2_02:79]
|  | Six Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |
| Operating Activities |  |  |  |
| Net income | $ | 7,012 |  |  | $ | 19,260 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 28,779 |  |  | 25,874 |  |
| Loss on disposal of property and equipment | — |  |  | 399 |  |
| Share-based compensation expense | 22,010 |  |  | 16,670 |  |
| Deferred income taxes | (9,409) |  |  | 3,810 |  |
| Amortization of operating lease right-of-use assets | 5,157 |  |  | 5,226 |  |
| Amortization of debt issuance costs | 482 |  |  | 1,145 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | 28,236 |  |  | (9,244) |  |
| Inventories | (7,271) |  |  | (4,466) |  |
| Prepaid expenses | 1,181 |  |  | 1,021 |  |
| Other current assets | 219 |  |  | (830) |  |
| Investment in sales-type leases | (1,375) |  |  | (4,412) |  |
| Prepaid commissions | 4,040 |  |  | 1,536 |  |
| Other long-term assets | (4,580) |  |  | 3,061 |  |
| Accounts payable | (11,254) |  |  | 2,066 |  |
| Accrued compensation | (3,098) |  |  | (8,041) |  |
| Accrued liabilities | (2,824) |  |  | 1,810 |  |
| Deferred revenues | 16,264 |  |  | 253 |  |
| Operating lease liabilities | (5,186) |  |  | (5,269) |  |
| Other long-term liabilities | 4,352 |  |  | 3,891 |  |
| Net cash provided by operating activities | 72,735 |  |  | 53,760 |  |
| Investing Activities |  |  |  |
| Software development for external use | (20,002) |  |  | (22,581) |  |
| Purchases of property and equipment | (13,211) |  |  | (9,369) |  |
| Net cash used in investing activities | (33,213) |  |  | (31,950) |  |
| Financing Activities |  |  |  |
| Repayment of debt and revolving credit facility | (50,000) |  |  | (60,000) |  |
| At the market equity offering, net of offering costs | — |  |  | 37,806 |  |
| Proceeds from issuances under stock-based compensation plans | 21,162 |  |  | 25,333 |  |
| Employees’ taxes paid related to restricted stock units | (3,470) |  |  | (4,722) |  |
| Net cash used in financing activities | (32,308) |  |  | (1,583) |  |
| Effect of exchange rate changes on cash and cash equivalents | (841) |  |  | 63 |  |
| Net increase in cash and cash equivalents | 6,373 |  |  | 20,290 |  |
| Cash and cash equivalents at beginning of period | 127,210 |  |  | 67,192 |  |
| Cash and cash equivalents at end of period | $ | 133,583 |  |  | $ | 87,482 |  |

[0000926326-20-000021:8k_2_02:80]
9

[0000926326-20-000021:8k_2_02:81]
Omnicell, Inc.

[0000926326-20-000021:8k_2_02:82]
Reconciliation of GAAP to Non-GAAP

[0000926326-20-000021:8k_2_02:83]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-20-000021:8k_2_02:84]
|  | Three Months Ended June 30, |  |  |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  |  |  | 2019 |  | 2020 |  | 2019 |
| Reconciliation of GAAP revenues to non-GAAP revenues: |  |  |  |  |  |  |  |  |  |
| GAAP revenues | $ | 199,621 |  |  |  |  | $ | 217,413 |  |  | $ | 429,307 |  |  | $ | 419,930 |  |
| Non-GAAP revenues | $ | 199,621 |  |  |  |  | $ | 217,413 |  |  | $ | 429,307 |  |  | $ | 419,930 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |  |  |  |
| GAAP gross profit | $ | 83,225 |  |  |  |  | $ | 104,045 |  |  | $ | 192,847 |  |  | $ | 201,162 |  |
| GAAP gross margin | 41.7% |  |  |  | 47.9% |  | 44.9% |  | 47.9% |
| Share-based compensation expense | 2,130 |  |  |  |  | 1,416 |  |  | 3,900 |  |  | 2,878 |  |
| Amortization of acquired intangibles | 2,033 |  |  |  |  | 2,044 |  |  | 4,068 |  |  | 4,110 |  |
| Severance and other expenses | 2,489 |  |  |  |  | — |  |  | 2,564 |  |  | — |  |
| Non-GAAP gross profit | $ | 89,877 |  |  |  |  | $ | 107,505 |  |  | $ | 203,379 |  |  | $ | 208,150 |  |
| Non-GAAP gross margin | 45.0% |  |  |  | 49.4% |  | 47.4% |  | 49.6% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |  |  |  |  |  |
| GAAP operating expenses | $ | 90,216 |  |  |  |  | $ | 85,282 |  |  | $ | 187,687 |  |  | $ | 169,638 |  |
| GAAP operating expenses % to total revenues | 45.2% |  |  |  | 39.2% |  | 43.7% |  | 40.4% |
| Share-based compensation expense | (9,221) |  |  |  |  | (6,844) |  |  | (18,110) |  |  | (13,792) |  |
| Amortization of acquired intangibles | (2,325) |  |  |  |  | (2,630) |  |  | (4,720) |  |  | (5,346) |  |
| Severance and other expenses | (4,162) |  |  |  |  | (440) |  |  | (8,188) |  |  | (726) |  |
| Non-GAAP operating expenses | $ | 74,508 |  |  |  |  | $ | 75,368 |  |  | $ | 156,669 |  |  | $ | 149,774 |  |
| Non-GAAP operating expenses % to total non-GAAP revenues | 37.3% |  |  |  | 34.7% |  | 36.5% |  | 35.7% |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income from operations: |  |  |  |  |  |  |  |  |  |
| GAAP income (loss) from operations | $ | (6,991) |  |  |  |  | $ | 18,763 |  |  | $ | 5,160 |  |  | $ | 31,524 |  |
| GAAP operating income (loss) % to total revenues | (3.5)% |  |  |  | 8.6% |  | 1.2% |  | 7.5% |
| Share-based compensation expense | 11,351 |  |  |  |  | 8,260 |  |  | 22,010 |  |  | 16,670 |  |
| Amortization of acquired intangibles | 4,358 |  |  |  |  | 4,674 |  |  | 8,788 |  |  | 9,456 |  |
| Severance and other expenses | 6,651 |  |  |  |  | 440 |  |  | 10,752 |  |  | 726 |  |
| Non-GAAP income from operations | $ | 15,369 |  |  |  |  | $ | 32,137 |  |  | $ | 46,710 |  |  | $ | 58,376 |  |
| Non-GAAP operating income % to total non-GAAP revenues | 7.7% |  |  |  | 14.8% |  | 10.9% |  | 13.9% |

[0000926326-20-000021:8k_2_02:85]
Omnicell, Inc.

[0000926326-20-000021:8k_2_02:86]
Reconciliation of GAAP to Non-GAAP

[0000926326-20-000021:8k_2_02:87]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-20-000021:8k_2_02:88]
|  | Three Months Ended June 30, |  |  |  |  |  | Six Months Ended June 30, |  |  |
|  | 2020 |  |  |  | 2019 |  | 2020 |  | 2019 |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) | $ | (4,299) |  |  |  |  | $ | 15,976 |  |  | $ | 7,012 |  |  | $ | 19,260 |  |
| Tax impact of IP restructuring | — |  |  |  |  | — |  |  | — |  |  | 9,624 |  |
| Share-based compensation expense | 11,351 |  |  |  |  | 8,260 |  |  | 22,010 |  |  | 16,670 |  |
| Amortization of acquired intangibles | 4,358 |  |  |  |  | 4,674 |  |  | 8,788 |  |  | 9,456 |  |
| Severance and other expenses (a) | 6,892 |  |  |  |  | 1,013 |  |  | 11,234 |  |  | 1,872 |  |
| Tax effect of the adjustments above (b) | (2,363) |  |  |  |  | (1,194) |  |  | (4,205) |  |  | (2,378) |  |
| Non-GAAP net income | $ | 15,939 |  |  |  |  | $ | 28,729 |  |  | $ | 44,839 |  |  | $ | 54,504 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |  |  |  |  |  |  |  |  |  |
| Shares - diluted GAAP | 42,659 |  |  |  |  | 42,945 |  |  | 43,616 |  |  | 42,646 |  |
| Shares - diluted Non-GAAP | 43,589 |  |  |  |  | 42,945 |  |  | 43,616 |  |  | 42,646 |  |
| GAAP net income (loss) per share - diluted | $ | (0.10) |  |  |  |  | $ | 0.37 |  |  | $ | 0.16 |  |  | $ | 0.45 |  |
| Tax impact of IP restructuring | — |  |  |  |  | — |  |  | — |  |  | 0.23 |  |
| Share-based compensation expense | 0.26 |  |  |  |  | 0.19 |  |  | 0.50 |  |  | 0.39 |  |
| Amortization of acquired intangibles | 0.10 |  |  |  |  | 0.11 |  |  | 0.20 |  |  | 0.22 |  |
| Severance and other expenses | 0.16 |  |  |  |  | 0.03 |  |  | 0.27 |  |  | 0.05 |  |
| Tax effect of the adjustments above (b) | (0.05) |  |  |  |  | (0.03) |  |  | (0.10) |  |  | (0.06) |  |
| Non-GAAP net income per share - diluted | $ | 0.37 |  |  |  |  | $ | 0.67 |  |  | $ | 1.03 |  |  | $ | 1.28 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP Adjusted EBITDA(c): |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) | $ | (4,299) |  |  |  |  | $ | 15,976 |  |  | $ | 7,012 |  |  | $ | 19,260 |  |
| Share-based compensation expense | 11,351 |  |  |  |  | 8,260 |  |  | 22,010 |  |  | 16,670 |  |
| Interest (income) and expense, net | 76 |  |  |  |  | 687 |  |  | 62 |  |  | 1,393 |  |
| Depreciation and amortization expense | 14,736 |  |  |  |  | 13,237 |  |  | 28,779 |  |  | 25,874 |  |
| Severance and other expenses | 6,892 |  |  |  |  | 1,013 |  |  | 11,234 |  |  | 1,872 |  |
| Income tax expense (benefit) | (2,518) |  |  |  |  | 1,158 |  |  | (2,500) |  |  | 9,225 |  |
| Non-GAAP adjusted EBITDA | $ | 26,238 |  |  |  |  | $ | 40,331 |  |  | $ | 66,597 |  |  | $ | 74,294 |  |
| Reconciliation of GAAP net cash provided by operating activities to non-GAAP free cash flow: |  |  |  |  |  |  |  |  |  |
| GAAP net cash provided by operating activities | $ | 47,504 |  |  |  |  | $ | 27,263 |  |  | $ | 72,735 |  |  | $ | 53,760 |  |
| Software development for external use | (9,400) |  |  |  |  | (10,864) |  |  | (20,002) |  |  | (22,581) |  |
| Purchases of property and equipment | (10,038) |  |  |  |  | (4,389) |  |  | (13,211) |  |  | (9,369) |  |
| Non-GAAP free cash flow | $ | 28,066 |  |  |  |  | $ | 12,010 |  |  | $ | 39,522 |  |  | $ | 21,810 |  |

[0000926326-20-000021:8k_2_02:89]
(a)For the three months ended June 30, 2020 and 2019, other expenses include $0.2 million and $0.6 million of amortization of debt issuance costs, respectively, and $0.3 million and $0.4 million of IP and legal entities restructuring costs, respectively. For the six months ended June 30, 2020 and 2019, other expenses include $0.5 million and $1.1 million of amortization of debt issuance costs, respectively, and $0.8 million and $0.7 million of IP and legal entities restructuring costs, respectively.

[0000926326-20-000021:8k_2_02:90]
(b)Tax effects calculated for all adjustments except tax benefits and expenses, and share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2020 and 2019.

[0000926326-20-000021:8k_2_02:91]
(c)Defined as earnings before interest income and expense, taxes, depreciation and amortization, share-based compensation, as well as excluding certain non-GAAP adjustments.

[0000926326-20-000021:8k_2_02:92]
11
