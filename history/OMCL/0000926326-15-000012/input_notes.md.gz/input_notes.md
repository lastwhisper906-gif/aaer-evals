# OMCL notes — 0000926326-15-000012


## omcl:ScheduleofLongTermNetInvestmentinSaleTypeLeasesTableTextBlock

[0000926326-15-000012:notes:1]
Net investment in sales-type leases consist of the following components:

[0000926326-15-000012:notes:2]
|  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 17,616 |  |  | $ | 18,172 |  |
| Less: unearned interest income portion | (1,131 | ) |  | (1,455 | ) |
| Net investment in sales-type leases | 16,485 |  |  | 16,717 |  |
| Less: short-term portion | (5,637 | ) |  | (5,232 | ) |
| Long-term net investment in sales-type leases | $ | 10,848 |  |  | $ | 11,485 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000926326-15-000012:notes:3]
Accrued Liabilities

[0000926326-15-000012:notes:4]
Accrued liabilities consist of the following:

[0000926326-15-000012:notes:5]
|  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| Rebates and lease buyouts | $ | 6,512 |  |  | $ | 1,699 |  |
| Advance payments from customers | 4,834 |  |  | 4,971 |  |
| Group purchasing organization fees | 3,475 |  |  | 2,324 |  |
| Technology license purchase obligation | — |  |  | 1,500 |  |
| Taxes payable | 2,181 |  |  | 1,664 |  |
| Other accrued liabilities | 2,297 |  |  | 1,588 |  |
| Total accrued liabilities | $ | 19,299 |  |  | $ | 13,746 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-15-000012:notes:6]
Business Combinations

[0000926326-15-000012:notes:7]
2014 Acquisition Activity

[0000926326-15-000012:notes:8]
On August 22, 2014, we completed our acquisition of Surgichem, a wholly-owned subsidiary of Bupa Care Homes (CFG) Plc ("Bupa"). In exchange for all of the voting equity interests of the acquired company, we paid a total purchase price of $20.7 million in cash, net of $0.2 million of cash acquired. This acquisition will assist U.K. healthcare professionals and caregivers seeking to improve patient outcomes, reduce medication errors and lower costs by effectively managing compliance to prescribed medication regimes in their mission to extend patient health and satisfaction through convenient, effective medication adherence solutions. Surgichem is being integrated with Omnicell’s existing U.K. business, MTS, a leading supplier of medication adherence packaging solutions.

[0000926326-15-000012:notes:9]
The following table presents the purchase price allocation included in our Consolidated Balance Sheets:

[0000926326-15-000012:notes:10]
|  | (In thousands) |
| Cash | $ | 153 |  |
| Accounts receivable | 2,462 |  |
| Inventory | 2,190 |  |
| Deferred tax assets and other current assets | 361 |  |
| Total current assets | $ | 5,166 |  |
| Property and equipment | 164 |  |
| Intangibles | 5,730 |  |
| Goodwill | 12,112 |  |
| Total assets | $ | 23,172 |  |
| Current liabilities | 1,191 |  |
| Long-term deferred tax liabilities | 1,104 |  |
| Total purchase price | $ | 20,877 |  |

[0000926326-15-000012:notes:11]
Acquired intangible assets. The fair value of $5.4 million for acquired customer relationships was determined based on an income approach using the discounted cash flow method. The fair value of $0.3 million for the trade name was determined using the relief-from-royalty approach. Customer relationships are amortized over their estimated useful lives of 18 years and the trade name is amortized over its estimated useful life of approximately 1 year.

[0000926326-15-000012:notes:12]
Goodwill. The purchase price allocation resulted in goodwill of $12.1 million, which represents sales of future products and services and the assembled workforce of Surgichem. We believe the acquisition enhances Omnicell’s offerings and diversifies its revenue mix providing a more robust product and service solution to its current customers while expanding Omnicell’s international presence. We considered these factors as supporting the amount of goodwill recorded.

[0000926326-15-000012:notes:13]
The amortization of intangible assets and goodwill is not deductible for tax purposes.

[0000926326-15-000012:notes:14]
We incurred approximately $1.1 million in acquisition-related costs related to the Surgichem acquisition, offset by a $0.5 million expense reimbursement from Bupa for the year ended December 31, 2014. These costs are included in selling, general and administrative expenses in our Consolidated Statement of Operations.

[0000926326-15-000012:notes:15]
Surgichem generated revenue of $4.6 million and losses from operations of $0.1 million since the acquisition date for the year ended December 31, 2014. The total revenues of Surgichem were $13.3 million (including $4.6 million mentioned above) and $11.9 million for the years ended December 31, 2014 and December 31, 2013, respectively. Results of operations for Surgichem have been included as a part of our Medication Adherence segment, and supplemental pro forma results of operations for the prior periods have not been presented, as the effect of the acquisition was not material to our consolidated financial results.

[0000926326-15-000012:notes:16]
2012 Acquisition Activity

[0000926326-15-000012:notes:17]
On May 21, 2012, we completed our acquisition of MedPak Holdings, Inc. ("MedPak") pursuant to an Agreement and Plan of Merger ("Merger Agreement") under which Mercury Acquisition Corp, a newly formed Omnicell subsidiary, was merged with and into MedPak, with MedPak surviving the merger as a wholly-owned subsidiary of Omnicell. MedPak is the parent company of MTS, a worldwide provider of medication adherence packaging systems. Pursuant to the terms of the Merger Agreement, we paid $156.3 million in cash, net of $2.0 million cash acquired.

[0000926326-15-000012:notes:18]
The objective of the acquisition was to primarily align Omnicell with the long term trends of the healthcare market to manage the health of patients across the continuum of care. Omnicell and MTS bring capabilities to each other that strengthen the product lines and expand the medication management coverage of both companies.

[0000926326-15-000012:notes:19]
|  | (In thousands) |
| Cash | $ | 2,000 |  |
| Accounts receivable | 7,403 |  |
| Inventory | 11,726 |  |
| Deferred tax assets and other current assets | 2,894 |  |
| Total current assets | $ | 24,023 |  |
| Property and equipment | 9,807 |  |
| Intangible assets | 83,900 |  |
| Goodwill | 82,800 |  |
| Other long-term assets | 308 |  |
| Total assets | $ | 200,838 |  |
| Current liabilities | (7,917 | ) |
| Long-term deferred tax liabilities | (33,386 | ) |
| Other long-term liabilities | (1,223 | ) |
| Total purchase price | $ | 158,312 |  |

[0000926326-15-000012:notes:20]
Identifiable intangible assets. Acquired technology relates to MTS’ products across all of its product lines that have reached technological feasibility, primarily the OnDemand technology. Trade names are primarily related to the MTS and OnDemand brand names. Customer relationships represent existing contracted relationships with pharmacies, institutional care facilities and others. Acquired technology, customer relationships, and trade names are amortized on a straight-line basis over their estimated useful lives, which range from 12 to 30 years.

[0000926326-15-000012:notes:21]
The estimated fair values of the acquired technology, trade names and customer relationships were primarily determined using either the relief-from-royalty or excess earnings methods. The interest rates utilized to discount net cash flows to their present values were determined after consideration of the overall enterprise rate of return and the relative risk and importance of the assets to the generation of future cash flows.

[0000926326-15-000012:notes:22]
The historical tax bases of the acquired assets and assumed liabilities, along with the tax attributes of the MTS companies, will carry over for income tax purposes. As the transaction was a cash-for-stock transaction, there is no tax basis in the acquired intangible assets. Accordingly, the acquisition accounting includes the establishment of net deferred tax liabilities of $33.4 million, resulting from book tax basis differences related to the intangible assets acquired, as well as to the step up in the value of fixed assets and inventory to their estimated fair values at the time of acquisition.

[0000926326-15-000012:notes:23]
The following represents the details of the acquired intangible assets:

[0000926326-15-000012:notes:24]
|  | Intangible AssetsAcquired |  | Useful Life(Years) |
|  | (In thousands, except for years) |
| Trade name | $ | 6,800 |  |  | 12 |
| Customer relationships | 50,500 |  |  | 28 to 30 |
| Acquired technology | 26,600 |  |  | 20 |
| Intangibles acquired | $ | 83,900 |  |  |  |

[0000926326-15-000012:notes:25]
Goodwill. The purchase price allocation resulted in goodwill of $82.8 million. We believe the MTS acquisition enhances our offerings and diversifies our revenue mix, providing a more robust product and service solution to our current customers while expanding Omnicell’s international presence. We considered these factors as supporting the amount of goodwill recorded.

[0000926326-15-000012:notes:26]
We incurred approximately $3.2 million in acquisition-related costs for the year ended December 31, 2013. These costs are included in selling, general and administrative expenses in our Consolidated Statement of Operations.

[0000926326-15-000012:notes:27]
MTS generated revenue of $47.2 million and net income of $2.9 million since the acquisition date for the year ended December 31, 2012. Results of operations for MTS have been included as a part of our Medication Adherence segment, and supplemental pro forma results of operations for the prior periods have not been presented, as the effect of the acquisition was not material to our consolidated financial results.


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-15-000012:notes:28]
Net Investment in Sales-Type Leases

[0000926326-15-000012:notes:29]
The terms of our sales-type leases are generally up to five years in length. Sales-type lease receivables are collateralized by the underlying equipment. Net investment in sales-type leases consist of the following components:

[0000926326-15-000012:notes:30]
We evaluate our sales-type leases individually and collectively for impairment, and recorded a collective allowance for credit losses of $0.2 million and $0.2 million as of December 31, 2014 and December 31, 2013, respectively.

[0000926326-15-000012:notes:31]
The minimum lease payments under sales-type leases are as follows:

[0000926326-15-000012:notes:32]
|  | December 31, 2014 |
|  | (In thousands) |
| 2015 | $ | 6,188 |  |
| 2016 | 4,832 |  |
| 2017 | 3,803 |  |
| 2018 | 2,174 |  |
| 2019 | 619 |  |
| Total | $ | 17,616 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000926326-15-000012:notes:33]
Cash equivalents. We classify investments as cash equivalents if their original or remaining contractual maturity is three months or less at the date of purchase. Cash equivalents are carried at amounts that approximate fair value due to the short period of time to maturity. Our cash equivalents are maintained in demand deposit accounts with financial institutions of high credit quality, and are invested in institutional money market funds, short-term bank time deposits and similar short duration instruments with fixed maturities. We continuously monitor the creditworthiness of the financial institutions and institutional money market funds in which we invest. We have not experienced any credit losses from our cash investments.


## us-gaap:CommissionsExpensePolicyPolicyTextBlock

[0000926326-15-000012:notes:34]
Commissions

[0000926326-15-000012:notes:35]
Sales commissions are incremental and directly related to customer sales contracts in which revenue is deferred. These commission costs are accrued and recorded in prepaid expenses upon execution of a non-cancelable customer contract and subsequently expensed in the period of revenue recognition.


## us-gaap:CommitmentsDisclosureTextBlock

[0000926326-15-000012:notes:36]
Commitments

[0000926326-15-000012:notes:37]
Lease commitments

[0000926326-15-000012:notes:38]
We lease our buildings under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. Rent expense was $6.8 million, $6.9 million and $5.7 million for the years ended December 31, 2014, December 31, 2013 and December 31, 2012, respectively.

[0000926326-15-000012:notes:39]
The minimum future payments on non-cancelable operating leases are as follows:

[0000926326-15-000012:notes:40]
|  | December 31, 2014 |
|  | (In thousands) |
| 2015 | $ | 5,637 |  |
| 2016 | 5,590 |  |
| 2017 | 4,873 |  |
| 2018 | 4,711 |  |
| 2019 | 4,836 |  |
| Thereafter | 12,991 |  |
| Total minimum future lease payments | $ | 38,638 |  |

[0000926326-15-000012:notes:41]
Purchase obligations

[0000926326-15-000012:notes:42]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. Our purchase obligations to our contract manufacturers and suppliers within the next year were $9.3 million as of December 31, 2014.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-15-000012:notes:43]
Principles of consolidation

[0000926326-15-000012:notes:44]
The accompanying Consolidated Financial Statements have been prepared in accordance with U.S. GAAP and include all adjustments necessary for the fair presentation of the Company's consolidated financial position, results of operations and cash flows for the periods presented. The Consolidated Financial Statements include the accounts of the Company and its subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation. The results of companies acquired during the year are included in the Consolidated Financial Statements from the effective date of acquisition.


## us-gaap:DebtDisclosureTextBlock

[0000926326-15-000012:notes:45]
Credit Agreement

[0000926326-15-000012:notes:46]
In September 2013, we entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time party thereto. The Credit Agreement provides for a $75 million revolving credit facility with a $10 million letter of credit sub-limit. Loans under the Credit Agreement mature on September 25, 2018. The Credit Agreement permits us to request one or more increases in the aggregate commitments provided that such increases do not exceed $25 million in the aggregate. We expect to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. Our obligations under the Credit Agreement are guaranteed by certain of our domestic subsidiaries and secured by substantially all of our and the subsidiary guarantors’ assets. We have not yet drawn any funds under the credit facility to date.

[0000926326-15-000012:notes:47]
Amounts drawn under the Credit Agreement bear interest, at our election, at a Eurodollar rate plus a margin of 1.75% per annum, or an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.75%. We are required to pay a commitment fee of 0.25% per annum on the aggregate undrawn amount of the commitments under the credit facility.

[0000926326-15-000012:notes:48]
On November 5, 2014, we entered into Amendment Number One (“Amendment”) to the Credit Agreement. The Amendment increases the amount of our common stock that may be repurchased by us in open market transactions authorized by our Board of Directors, together with any repurchases of our common stock from any consultants, employees, officers or directors of the Company or any of our subsidiaries following the death, disability, retirement or termination of employment of such employees, officers or directors, from $25 million to $50 million per year.

[0000926326-15-000012:notes:49]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each quarter. We were in full compliance with all covenants as of December 31, 2014.


## us-gaap:DebtPolicyTextBlock

[0000926326-15-000012:notes:50]
Debt. Our debt includes a $75 million revolving credit facility. Borrowings under our revolving credit facility would be recognized at cost plus accrued interest based upon stated interest rates. We have not yet drawn any funds under the credit facility to date.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000926326-15-000012:notes:51]
Deferred gross profit consists of the following:

[0000926326-15-000012:notes:52]
|  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| Sales of medication and supply dispensing systems including packaging equipment (1) | $ | 36,947 |  |  | $ | 29,040 |  |
| Less: cost of revenues, excluding installation costs | (8,389 | ) |  | (9,083 | ) |
| Total deferred gross profit | $ | 28,558 |  |  | $ | 19,957 |  |

[0000926326-15-000012:notes:53]
_________________________________________________

[0000926326-15-000012:notes:54]
| (1) | Delivered and invoiced, pending installation. |


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-15-000012:notes:55]
Deferred Gross Profit


## us-gaap:EarningsPerShareTextBlock

[0000926326-15-000012:notes:56]
Net Income Per Share

[0000926326-15-000012:notes:57]
Basic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted-average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Since the impact is anti-dilutive, these shares were excluded from the calculations of diluted net income per share.

[0000926326-15-000012:notes:58]
The calculation of basic and diluted net income per share is as follows:

[0000926326-15-000012:notes:59]
|  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2012 |
|  | (In thousands, except per share data) |
| Net income | $ | 30,518 |  |  | $ | 23,979 |  |  | $ | 16,178 |  |
| Weighted-average shares outstanding — basic | 35,650 |  |  | 34,736 |  |  | 33,307 |  |
| Add: Dilutive effect of employee stock plans | 972 |  |  | 1,041 |  |  | 906 |  |
| Weighted-average shares outstanding — diluted | 36,622 |  |  | 35,777 |  |  | 34,213 |  |
| Net income per share — basic | $ | 0.86 |  |  | $ | 0.69 |  |  | $ | 0.49 |  |
| Net income per share — diluted | $ | 0.83 |  |  | $ | 0.67 |  |  | $ | 0.47 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 640 |  |  | 850 |  |  | 2,149 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000926326-15-000012:notes:60]
The following table summarizes our assets measured at fair value on a recurring basis using Level 1 inputs within the fair value hierarchy:

[0000926326-15-000012:notes:61]
|  | December 31,2014 |  | December 31,2013 |
|  | (In thousands) |
| Cash | $ | 61,311 |  |  | $ | 38,823 |  |
| Cash equivalents | 64,577 |  |  | 65,708 |  |
| Total cash and cash equivalents | $ | 125,888 |  |  | $ | 104,531 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-15-000012:notes:62]
Fair Value Measurements

[0000926326-15-000012:notes:63]
For assets and liabilities measured at fair value, such amounts are based on an expected exit price representing the amount that would be received from the sale of an asset or paid to transfer a liability in a transaction between market participants. As such, fair value may be based on assumptions that market participants would use in pricing an asset or liability. The authoritative guidance on fair value measurements establishes a consistent framework for measuring fair value on either a recurring or nonrecurring basis whereby inputs used in valuation techniques are assigned a hierarchical level. The following methods were used to estimate the fair value of each class of financial instruments for which it is practical to estimate that value:

[0000926326-15-000012:notes:64]
| • | Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets. |

[0000926326-15-000012:notes:65]
| • | Level 2: Observable inputs that reflect quoted prices for identical assets or liabilities in markets that are not active, quoted prices for similar assets or liabilities in active markets, inputs other than quoted prices that are observable for the assets or liabilities, or inputs that are derived principally from or corroborated by observable market data by correlation or other means. |

[0000926326-15-000012:notes:66]
| • | Level 3: Unobservable inputs reflecting our own assumptions incorporated in valuation techniques used to determine fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available. |

[0000926326-15-000012:notes:67]
Assets Measured at Fair Value on a Recurring Basis

[0000926326-15-000012:notes:68]
Cash equivalents. Cash equivalents consist of money market funds that are classified as Level 1, and have an original maturity of three months or less, and therefore the carrying amount is a reasonable estimate of fair value due to the short duration to maturity.

[0000926326-15-000012:notes:69]
There have been no transfers between fair value measurement levels during 2014 and 2013. The following table summarizes our assets measured at fair value on a recurring basis using Level 1 inputs within the fair value hierarchy:

[0000926326-15-000012:notes:70]
Net investment in sales-type leases. The carrying amount of our sales-type lease receivables is a reasonable estimate of fair value as the unearned interest income is immaterial.

[0000926326-15-000012:notes:71]
Assets and liabilities measured and recorded at fair value on a nonrecurring basis

[0000926326-15-000012:notes:72]
See Note 2, Business Combinations, for the fair value of intangible assets acquired that were calculated using an income approach valuation technique based on Level 3 unobservable inputs.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000926326-15-000012:notes:73]
Foreign currency forward contracts. We enter into foreign currency forward contracts to protect our business from the risk that exchange rates may affect the eventual cash flows resulting from intercompany transactions between Omnicell and our foreign subsidiaries. These transactions primarily arise as a result of products manufactured in the United States and sold to foreign subsidiaries in U.S. dollars rather than the subsidiaries' functional currencies. These forward contracts are considered to be financial derivative instruments and are recorded at fair value. Changes in fair values of these financial derivative instruments are either recognized in other comprehensive income or net income depending on whether the derivative has been designated and qualifies as a hedging instrument. We had no foreign currency forward contracts which qualify for hedge accounting as of December 31, 2014 and December 31, 2013, and had no foreign currency forward contracts as of December 31, 2014.

[0000926326-15-000012:notes:74]
Foreign currency translation

[0000926326-15-000012:notes:75]
We translate the assets and liabilities of our non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recorded as foreign currency translation adjustments and included in accumulated other comprehensive income in stockholders’ equity.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-15-000012:notes:76]
Goodwill and Intangible Assets

[0000926326-15-000012:notes:77]
Goodwill

[0000926326-15-000012:notes:78]
The changes in the carrying amount of goodwill are as follows:

[0000926326-15-000012:notes:79]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2012 | $ | 28,543 |  |  | $ | 82,864 |  |  | $ | 111,407 |  |
| Additions | — |  |  | — |  |  | — |  |
| Adjustments (1) | — |  |  | (64 | ) |  | (64 | ) |
| Net balance as of December 31, 2013 | $ | 28,543 |  |  | $ | 82,800 |  |  | $ | 111,343 |  |
| Additions (2) | — |  |  | 12,112 |  |  | 12,112 |  |
| Adjustments (3) | — |  |  | (735 | ) |  | (735 | ) |
| Net balance as of December 31, 2014 | $ | 28,543 |  |  | $ | 94,177 |  |  | $ | 122,720 |  |

[0000926326-15-000012:notes:80]
| (1) | Goodwill includes an immaterial adjustment related to the MTS acquisition in May 2012. |

[0000926326-15-000012:notes:81]
| (2) | Additions to goodwill as a result of the Surgichem acquisition in August 2014, including a $0.1 million adjustment to the purchase price in the fourth quarter of 2014. |

[0000926326-15-000012:notes:82]
| (3) | Adjustments reflect foreign currency exchange rate fluctuations. |

[0000926326-15-000012:notes:83]
Effective in the first quarter of 2014, we modified our segment reporting structure to match our new operating structure. Our reporting units for goodwill are the same as our reportable operating segments. See Note 17, Segment Information, for information regarding the changes related to segment information.

[0000926326-15-000012:notes:84]
Intangible assets, net

[0000926326-15-000012:notes:85]
|  | December 31, 2014 |  | December 31, 2013 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Useful Life(Years) |  | Gross CarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | Useful Life(Years) |
|  | (In thousands, except for years) |  |  |
| Customer relationships | $ | 60,150 |  |  | $ | (7,919 | ) |  | $ | 52,231 |  |  | 5 - 30 |  | $ | 54,730 |  |  | $ | (5,236 | ) |  | $ | 49,494 |  |  | 5 - 30 |
| Acquired technology | 27,580 |  |  | (4,068 | ) |  | 23,512 |  |  | 3 - 20 |  | 27,580 |  |  | (2,598 | ) |  | 24,982 |  |  | 3 - 20 |
| Trade names | 7,110 |  |  | (1,576 | ) |  | 5,534 |  |  | 1 - 12 |  | 6,890 |  |  | (1,003 | ) |  | 5,887 |  |  | 3 - 12 |
| Patents | 1,655 |  |  | (265 | ) |  | 1,390 |  |  | 20 |  | 1,493 |  |  | (254 | ) |  | 1,239 |  |  | 20 |
| Non-compete agreements | — |  |  | — |  |  | — |  |  | — |  | 60 |  |  | (60 | ) |  | — |  |  | 3 |
| Total intangibles assets, net | $ | 96,495 |  |  | $ | (13,828 | ) |  | $ | 82,667 |  |  |  |  | $ | 90,753 |  |  | $ | (9,151 | ) |  | $ | 81,602 |  |  |  |

[0000926326-15-000012:notes:86]
We capitalized third-party costs associated with internally-developed patents of $0.3 million, $0.4 million and $0.4 million as of December 31, 2014, December 31, 2013 and December 31, 2012, respectively.

[0000926326-15-000012:notes:87]
Amortization expense of intangible assets was $4.6 million, $4.3 million and $2.9 million for the years ended December 31, 2014, December 31, 2013 and December 31, 2012, respectively.

[0000926326-15-000012:notes:88]
Total future amortization expense for intangible assets is as follows:

[0000926326-15-000012:notes:89]
|  | December 31, 2014 |
|  | (In thousands) |
| 2015 | $ | 4,679 |  |
| 2016 | 4,354 |  |
| 2017 | 4,267 |  |
| 2018 | 4,113 |  |
| 2019 | 4,063 |  |
| Thereafter | 61,191 |  |
| Total | $ | 82,667 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000926326-15-000012:notes:90]
Goodwill and intangible assets

[0000926326-15-000012:notes:91]
Goodwill. We review goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. Our reporting units are the same as our operating segments, which are Automation and Analytics and Medication Adherence. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. This initial assessment includes, among others, consideration of: (i) past, current and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this initial qualitative assessment indicates that it is more likely than not that impairment exists, or if we decide to bypass this option, we proceed to a two-step impairment test. The first step ("Step 1") involves a comparison between the estimated fair values of our reporting units with their respective carrying amounts including goodwill. The methods for estimating reporting unit values include asset and liability fair values and other valuation techniques, such as discounted cash flows and multiples of earnings or revenues. If the carrying value exceeds estimated fair value, there is an indication of potential impairment, and the second step is performed to measure the amount of impairment. The second step involves calculating an implied fair value of goodwill by measuring the excess of the estimated fair value of the reporting units over the aggregate estimated fair values of the individual assets less liabilities. If the carrying value of goodwill exceeds the implied fair value of goodwill, an impairment charge is recorded for the excess.

[0000926326-15-000012:notes:92]
To determine each reporting units’ fair value in the second step, we would use the income approach which is based on the estimated discounted future cash flows of that reporting unit. The estimated fair value of each reporting unit under the income approach is corroborated with the market approach, which measures the value of a business through an analysis of recent sales or offerings of a comparable entity. We also consider our market capitalization on the date of the analysis to ensure the reasonableness of the sum of our reporting units’ estimated fair value.

[0000926326-15-000012:notes:93]
Intangible assets. In connection with our acquisitions, we generally recognize assets for customer relationships, technology and trade names. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets, generally from 1 to 30 years. Amortization for technology is recognized in cost of product revenues, and amortization for customer relationships and trade names is recognized in selling, general and administrative expenses.

[0000926326-15-000012:notes:94]
We assess the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset's carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. Our cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of our intangible assets are subjective and are affected by changes to our business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of our assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-15-000012:notes:95]
Income Taxes

[0000926326-15-000012:notes:96]
The following is a geographical breakdown of income before the provision for income taxes:

[0000926326-15-000012:notes:97]
|  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2012 |
|  | (In thousands) |
| Domestic | $ | 48,327 |  |  | $ | 34,678 |  |  | $ | 25,794 |  |
| Foreign | 177 |  |  | 351 |  |  | 1,281 |  |
| Income before provision for income taxes | $ | 48,504 |  |  | $ | 35,029 |  |  | $ | 27,075 |  |

[0000926326-15-000012:notes:98]
The provision for income taxes consists of the following:

[0000926326-15-000012:notes:99]
|  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2012 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Federal | $ | 14,063 |  |  | $ | 8,218 |  |  | $ | 7,181 |  |
| State | 2,274 |  |  | 1,621 |  |  | 1,006 |  |
| Foreign | 192 |  |  | 447 |  |  | 154 |  |
| Total current income taxes | 16,529 |  |  | 10,286 |  |  | 8,341 |  |
| Deferred: |  |  |  |  |  |
| Federal | 1,603 |  |  | 1,287 |  |  | 2,169 |  |
| State | 84 |  |  | (263 | ) |  | 651 |  |
| Foreign | (230 | ) |  | (260 | ) |  | (264 | ) |
| Total deferred income taxes | 1,457 |  |  | 764 |  |  | 2,556 |  |
| Total provision for income taxes | $ | 17,986 |  |  | $ | 11,050 |  |  | $ | 10,897 |  |

[0000926326-15-000012:notes:100]
The provision for income taxes differs from the amount computed by applying the statutory federal tax rate as follows:

[0000926326-15-000012:notes:101]
|  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2012 |
|  | (In thousands) |
| U.S. federal tax provision at statutory rate | $ | 16,998 |  |  | $ | 12,260 |  |  | $ | 9,476 |  |
| State taxes | 1,533 |  |  | 883 |  |  | 1,077 |  |
| Non-deductible expenses | 809 |  |  | 297 |  |  | 530 |  |
| Acquisition costs | 229 |  |  | — |  |  | 431 |  |
| Share-based compensation expense | 461 |  |  | 407 |  |  | 403 |  |
| Research tax credits | (818 | ) |  | (1,430 | ) |  | — |  |
| Domestic production deduction | (1,127 | ) |  | (816 | ) |  | (601 | ) |
| Other | (99 | ) |  | (551 | ) |  | (419 | ) |
| Total provision for income taxes | $ | 17,986 |  |  | $ | 11,050 |  |  | $ | 10,897 |  |

[0000926326-15-000012:notes:102]
Significant components of our deferred tax assets (liabilities) are as follows:

[0000926326-15-000012:notes:103]
|  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| Deferred tax assets (liabilities): |  |  |  |
| Deferred revenue | $ | 12,639 |  |  | $ | 11,074 |  |
| Stock compensation | 6,287 |  |  | 7,447 |  |
| Inventory related items | 2,713 |  |  | 2,947 |  |
| Tax credit carry forwards | 2,168 |  |  | 3,160 |  |
| Reserves and accruals | 327 |  |  | — |  |
| Loss carry forwards | 12 |  |  | 64 |  |
| Other, net | — |  |  | 5 |  |
| Subtotal | 24,146 |  |  | 24,697 |  |
| Less: valuation allowance | — |  |  | (39 | ) |
| Total net deferred tax assets | 24,146 |  |  | 24,658 |  |
| Intangibles | (26,485 | ) |  | (26,604 | ) |
| Depreciation and amortization | (14,331 | ) |  | (12,077 | ) |
| Reserves and accruals | — |  |  | (353 | ) |
| Other, net | (194 | ) |  | — |  |
| Total deferred tax liabilities | (41,010 | ) |  | (39,034 | ) |
| Net deferred tax liabilities | $ | (16,864 | ) |  | $ | (14,376 | ) |

[0000926326-15-000012:notes:104]
Deferred income tax assets (liabilities) are provided for temporary differences that will result in future tax deductions or future taxable income, as well as the future benefit of tax credit carry forwards. We recognize deferred tax assets to the extent that we believe these assets are more likely than not to be realized. In making such a determination, we consider all available positive and negative evidence, including future reversals of existing temporary differences, projected future taxable income, tax planning strategies, and results of recent operations. On the basis of this evaluation, as of December 31, 2014, no valuation allowances have been recorded in any jurisdiction.

[0000926326-15-000012:notes:105]
As of December 31, 2014, we have an immaterial amount of state net operating loss carryforwards available for income tax purposes. For income tax purposes, we have California research tax credits carryforwards of $7.9 million. Federal research tax credit carryforwards from prior years have been utilized or have expired. California credits are available indefinitely to reduce cash taxes otherwise payable. Pursuant to the requirements of ASC 718, we do not include unrealized stock option attributes as components of our gross deferred tax assets. The tax-effected amounts of gross unrealized net operating loss and business tax credit carryforwards excluded under ASC 718 for the year ended December 31, 2014 are immaterial.

[0000926326-15-000012:notes:106]
In general, it is the practice and intention to reinvest the earnings of our non-U.S. subsidiaries in those operations.  As of December 31, 2014, we have not made a provision for U.S. federal income and state income taxes on accumulated and current earnings of $0.8 million related to our foreign subsidiaries because these earnings are intended to be indefinitely reinvested in operations outside the United States. If we expect to distribute those earnings in the form of dividends or otherwise, we would be subject to U.S. and state income taxes reported as a component of income tax expense, in the amount of $0.3 million. This amount may be reduced by any foreign tax credits available at the time of repatriation.

[0000926326-15-000012:notes:107]
We file income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, we are subject to examination by taxing authorities, including major jurisdiction as the United States, California and United Kingdom and Germany. In 2012, we concluded audits by IRS and California Franchise Tax Board for years 2008 and 2009. However, all of the net operating loss and research credit carryforwards that may be used in future years are subject to adjustment, if and when utilized. As such our federal and California tax years remain open from 1996 and 1992, respectively. In late 2014, we were contacted by the IRS for a limited scope audit for tax years 2011 and 2012. At this time, we do not believe results of this audit will have a material impact on our financial statements.

[0000926326-15-000012:notes:108]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, is as follows:

[0000926326-15-000012:notes:109]
|  | (In thousands) |
| Year Ended December 31, 2011 | $ | 5,796 |  |
| Increases related to tax positions taken during a prior period | 43 |  |
| Increases related to tax positions related to MTS | 1,066 |  |
| Decreases related to tax positions taken during the prior period | — |  |
| Increases related to tax positions taken during the current period | 422 |  |
| Decreases related to settlements | (33 | ) |
| Decreases related to expiration of statute of limitations | (379 | ) |
| Year Ended December 31, 2012 | $ | 6,915 |  |
| Increases related to tax positions taken during a prior period | 406 |  |
| Decreases related to tax positions taken during the prior period | (79 | ) |
| Increases related to tax positions taken during the current period | 764 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (32 | ) |
| Year Ended December 31, 2013 | $ | 7,974 |  |
| Increases related to tax positions taken during a prior period | 63 |  |
| Decreases related to tax positions taken during the prior period | (89 | ) |
| Increases related to tax positions taken during the current period | 801 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (264 | ) |
| Year Ended December 31, 2014 | $ | 8,485 |  |

[0000926326-15-000012:notes:110]
As of December 31, 2014, the total amount of gross unrecognized tax benefits, if realized, would affect our tax expense by approximately $7.3 million. We recognize interest and/or penalties related to uncertain tax positions in operating expenses, which for 2014 was immaterial. We do not believe there will be any material changes in our unrecognized tax positions over the next twelve months.


## us-gaap:IncomeTaxPolicyTextBlock

[0000926326-15-000012:notes:111]
Accounting for income taxes

[0000926326-15-000012:notes:112]
We record an income tax provision for the anticipated tax consequences of the reported results of operations. In accordance with U.S. GAAP, the provision for income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, we will incur a benefit or detriment on our income tax expense in the period of change. If we were to determine that all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-15-000012:notes:113]
In accordance with ASC 740, Income Taxes, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of U.S. GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.


## us-gaap:InventoryDisclosureTextBlock

[0000926326-15-000012:notes:114]
Inventories

[0000926326-15-000012:notes:115]
Inventories consist of the following components:

[0000926326-15-000012:notes:116]
|  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| Raw materials | $ | 8,254 |  |  | $ | 10,765 |  |
| Work in process | 64 |  |  | 534 |  |
| Finished goods | 23,236 |  |  | 20,158 |  |
| Total inventories, net | $ | 31,554 |  |  | $ | 31,457 |  |

[0000926326-15-000012:notes:117]
Dependence on suppliers

[0000926326-15-000012:notes:118]
We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract with our supplier may be terminated by either the supplier or by us without cause and at any time upon delivery of two months' notice. Purchases from this supplier were $34.5 million, $29.2 million and $23.8 million for the years ended December 31, 2014, December 31, 2013 and December 31, 2012, respectively.


## us-gaap:InventoryPolicyTextBlock

[0000926326-15-000012:notes:119]
Inventory

[0000926326-15-000012:notes:120]
Inventories are stated at the lower of cost (utilizing standard costs, applying the first-in, first-out method) or market. Cost elements included in inventory are direct labor and materials plus applied overhead. We routinely assess on-hand inventory for timely identification and measurement of obsolete, slow-moving or otherwise impaired inventory. We write down our inventory for estimated obsolescence, excess or unmarketable quantities equal to the difference between the cost of the inventory and its estimated market value based on assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than we projected, additional inventory write-downs may be required.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-15-000012:notes:121]
Recently adopted accounting standards

[0000926326-15-000012:notes:122]
In July 2013, the FASB issued Accounting Standards Update No. 2013-11, Income Taxes: Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists ("ASU 2013-11"). ASU 2013-11 requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except as follows: to the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. We adopted the amendments in ASU 2013-11 in the first quarter of 2014. This update did not have a significant impact on our financial position, operating results or cash flows.

[0000926326-15-000012:notes:123]
Recently issued authoritative guidance

[0000926326-15-000012:notes:124]
In May 2014, the FASB issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers, that requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers, and will replace most existing revenue recognition guidance in U.S. GAAP. The new standard is effective for us in the first quarter of 2017, and early adoption is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are evaluating the effect that the standard will have on our Consolidated Financial Statements and related disclosures.

[0000926326-15-000012:notes:125]
There was no other recently issued authoritative guidance that has a material impact on our Consolidated Financial Statements through the reporting date.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0000926326-15-000012:notes:126]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards |  |  |  |
| Outstanding at December 31, 2013 | 52 |  |  | $ | 18.43 |  |
| Granted | 38 |  |  | 26.42 |  |
| Vested | (54 | ) |  | 18.68 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at December 31, 2014 | 36 |  |  | $ | 26.47 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-15-000012:notes:127]
Summary of Significant Accounting Policies

[0000926326-15-000012:notes:128]
Business

[0000926326-15-000012:notes:129]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication, supply control systems and medication adherence solutions which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States and Canada. "Omnicell," "our," "us," "we," or the "Company" collectively refer to Omnicell, Inc. and its subsidiaries.

[0000926326-15-000012:notes:130]
Use of estimates

[0000926326-15-000012:notes:131]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in our Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, valuation of goodwill, purchased intangibles and long-lived assets, and accounting for income taxes.

[0000926326-15-000012:notes:132]
Segment reporting change

[0000926326-15-000012:notes:133]
We modified our segment reporting structure to match our operating structure based on how our Chief Operating Decision Maker (“CODM”) views the business and allocates resources, beginning in the first quarter of 2014. The CODM function is our Chief Executive Officer. Retrospective adjustments of prior period financial information have been made to conform to the current period presentation. This change does not impact previously reported Consolidated Financial Statements of the Company. See Note 17, Segment Information, for additional information on our segment reporting change.

[0000926326-15-000012:notes:134]
Revenue recognition

[0000926326-15-000012:notes:135]
We earn revenues from sales of our medication and medical and surgical supply automation systems along with consumables and related services, which are sold in the healthcare industry, our principal market. Revenues related to consumable products are reported net of discounts provided to our customers. Our customer arrangements typically include one or more of the following deliverables:

[0000926326-15-000012:notes:136]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

[0000926326-15-000012:notes:137]
Software. Additional software applications that enable incremental functionality of our equipment.

[0000926326-15-000012:notes:138]
Installation. Installation of equipment as integrated systems at customers' sites.

[0000926326-15-000012:notes:139]
Post-installation technical support. Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available.

[0000926326-15-000012:notes:140]
Professional services. Other customer services, such as training and consulting.

[0000926326-15-000012:notes:141]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

[0000926326-15-000012:notes:142]
Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement.

[0000926326-15-000012:notes:143]
Delivery has occurred. Equipment and embedded software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. For existing distributors, where installation of equipment training has been previously provided and the distributor is certified to install our equipment at the end-user customer facility, we recognize revenue from sales of products to the distributor upon shipment assuming all other revenue criteria are met since we do not allow for rights of return or refund. For new distributors, where we have not provided installation of equipment training, revenue on the sales of products to the distributor is deferred until the distributor has completed the Distributor Training Program and has been certified to install our equipment at the end-user facility. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period. We recognize revenue on training and professional services as they are performed.

[0000926326-15-000012:notes:144]
Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services.

[0000926326-15-000012:notes:145]
Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable.

[0000926326-15-000012:notes:146]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. We allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of the selling price. VSOE represents the price charged for a deliverable when it is sold separately, or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of the selling price for our post-installation technical support services and professional services. When VSOE of selling price is not available, third-party evidence ("TPE") of selling price for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE and BESP information.

[0000926326-15-000012:notes:147]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable on the basis of its estimated selling price. In addition, the amount recognized for any delivered items cannot exceed that which is not contingent upon delivery of any remaining items in the arrangement.

[0000926326-15-000012:notes:148]
We also use the residual method to allocate revenue between the software products that enable incremental equipment functionality, and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0000926326-15-000012:notes:149]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.

[0000926326-15-000012:notes:150]
Financial Instruments

[0000926326-15-000012:notes:151]
Marketable securities. Our marketable securities and investments are classified as available-for-sale, and unrealized gains and losses, net of tax, are included in accumulated other comprehensive income.

[0000926326-15-000012:notes:152]
Equity investments. We make equity investments in privately-held companies whose businesses are complementary to our business. The investment in which we hold less than 20% of the voting stock outstanding and do not exert significant influence is accounted for under the cost method of accounting. The cost amount of this investment was $0.4 million as of December 31, 2014 and December 31, 2013, and was no longer realizable as of December 31, 2014 and therefore considered impaired as discussed in Note 9, Other Assets. We invested $0.9 million to purchase 15% of our United Kingdom automation and analytics products distributor’s outstanding equity. We record this investment under the equity method of accounting as we have the right to appoint a member to this company's board of directors as well as certain other voting rights and, therefore, we believe we have the ability to exert significant influence over this distributor's operations. Our proportionate equity share of the income of this distributor, recognized in interest and other income, net was immaterial for the years ended December 31, 2014, December 31, 2013 and December 31, 2012. Our equity investments are included in other long-term assets. We assess the recoverability of these investments by reviewing various indicators for other-than-temporary impairment.

[0000926326-15-000012:notes:153]
Accounts receivable and notes receivable (net investment in sales-type leases)

[0000926326-15-000012:notes:154]
We actively manage our accounts receivable to minimize credit risk. We typically sell to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer's impaired ability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position. There were no significant customers that accounted for more than 10% of our accounts receivable as of December 31, 2014 and December 31, 2013.

[0000926326-15-000012:notes:155]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

[0000926326-15-000012:notes:156]
The retained in-house leases discussed above are considered financing receivables. Our credit policies and evaluation of credit risk and write-off policies are applied alike to trade receivables and the net investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class. Financing receivables which are reserved are generally transferred to cash-basis accounting so that revenue is recognized only as cash is received. However, the cash basis accounts continue to accrue interest.

[0000926326-15-000012:notes:157]
Sales of accounts receivable

[0000926326-15-000012:notes:158]
We record the sale of our accounts receivables as "true sales" in accordance with accounting guidance for transfers and servicing of financial assets. We transferred non-recourse accounts receivable totaling $62.0 million, $41.3 million and $60.9 million as of December 31, 2014, December 31, 2013 and December 31, 2012, respectively, which approximated fair value, to leasing companies on a non-recourse basis. Accounts receivable included approximately $1.1 million, $0.1 million and $0.7 million due from third-party leasing companies for transferred non-recourse accounts receivable as of December 31, 2014, December 31, 2013 and December 31, 2012, respectively.

[0000926326-15-000012:notes:159]
Property and equipment

[0000926326-15-000012:notes:160]
Property and equipment less accumulated depreciation are stated at historical cost. Our expenditures for property and equipment are for computer equipment and software used in the administration of our business, and for leasehold improvements to our leased facilities. We also develop molds and dies used in long-term manufacturing arrangements with suppliers and for production automation equipment used in the manufacturing of consumable blister card components. Depreciation and amortization of property and equipment are provided over their estimated useful lives, using the straight-line method, as follows:

[0000926326-15-000012:notes:161]
| Computer equipment and related software | 3 - 5 years |
| Leasehold and building improvements | Shorter of the lease term or the estimated useful life |
| Furniture and fixtures | 5 - 7 years |
| Equipment | 3 - 12 years |

[0000926326-15-000012:notes:162]
We capitalize costs related to computer software developed or obtained for internal use in accordance with ASC 350-40, Internal-Use Software. Software obtained for internal use has generally been enterprise-level business and finance software that we customize to meet our specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred. We capitalized $3.9 million and $4.8 million of costs related to the application development of enterprise-level software that was included in property and equipment during the years ended December 31, 2014 and December 31, 2013, respectively.

[0000926326-15-000012:notes:163]
Software development costs

[0000926326-15-000012:notes:164]
We capitalize software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which certain software development costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. We establish feasibility when we complete a working model and amortize development costs over the estimated lives of the related products ranging from three to five years. We capitalized software development costs of $10.4 million and $7.8 million which are included in other assets as of December 31, 2014 and December 31, 2013, respectively. We recorded $4.4 million, $3.2 million and $2.3 million to cost of revenues for amortization of capitalized software development costs for the years ended December 31, 2014, December 31, 2013 and December 31, 2012, respectively. All development costs prior to the completion of a working model are recognized as research and development expense.

[0000926326-15-000012:notes:165]
We use the acquisition method of accounting under the authoritative guidance on business combinations. Each acquired company’s operating results are included in our Consolidated Financial Statements starting on the date of acquisition. The purchase price is equivalent to the fair value of consideration transferred. Tangible and identifiable intangible assets acquired and liabilities assumed as of the date of acquisition are recorded at the acquisition date fair value. Goodwill is recognized for the excess of purchase price over the net fair value of assets acquired and liabilities assumed.

[0000926326-15-000012:notes:166]
Amounts allocated to assets and liabilities are based upon fair values. Such valuations require management to make significant estimates and assumptions, especially with respect to the identifiable intangible assets. Management makes estimates of fair value based upon assumptions believed to be reasonable and that of a market participant. These estimates are based on historical experience and information obtained from the management of the acquired companies and the estimates are inherently uncertain. The separately identifiable intangible assets generally include customer relationships, technology, and trade names.

[0000926326-15-000012:notes:167]
Valuation of share-based awards

[0000926326-15-000012:notes:168]
We account for share-based compensation in accordance with ASC 718, Stock Compensation ("ASC 718"). We recognize compensation expense related to stock-based compensation, including the awarding of employee stock awards and restricted stock units, based on the grant date estimated fair value. We amortize the fair value of the employee stock awards on a straight-line basis over the requisite service period of the award, which is generally the vesting period. We estimate the fair value of stock-based compensation awards using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of our common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on our historical experience of employee stock option exercises, including forfeitures. The valuation assumptions we use in estimating the fair value of employee share-based awards may change in future periods. We calculate our pool of excess tax benefits available within additional paid-in capital in accordance with the provisions of ASC 718.

[0000926326-15-000012:notes:169]
Deferred service revenue and deferred gross profit

[0000926326-15-000012:notes:170]
Deferred service revenue and deferred gross profit arise when customers have been billed and/or have received products and/or services in advance of revenue recognition. Our deferred gross profit, classified as a current liability, consists primarily of unearned revenue on sale of equipment for which installation has not been completed, net of deferred cost of sales for such equipment and the unearned revenue for software licenses. Our deferred service revenue, separated into current and long-term liabilities, consists of the unearned portion of service contracts for which revenue is recognized over their duration.

[0000926326-15-000012:notes:171]
Shipping costs

[0000926326-15-000012:notes:172]
Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general and administrative expense. Shipping and handling expenses were $7.4 million, $6.1 million and $4.1 million for the years ended December 31, 2014, December 31, 2013 and December 31, 2012, respectively.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000926326-15-000012:notes:173]
Other Assets

[0000926326-15-000012:notes:174]
Other assets consist of the following:

[0000926326-15-000012:notes:175]
|  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| Capitalized software development costs, net of accumulated amortization of $14,918 and $10,547, respectively, and accumulated impairment (1) | $ | 19,643 |  |  | $ | 13,660 |  |
| Technology license | 1,678 |  |  | 2,350 |  |
| Long-term deposits | 860 |  |  | 682 |  |
| Other long-term assets (2) | 1,092 |  |  | 1,245 |  |
| Total other long-term assets | $ | 23,273 |  |  | $ | 17,937 |  |

[0000926326-15-000012:notes:176]
| (1) | In the first quarter of 2013, we reorganized our management team as part of the continuing integration of MTS, including the software development department within the Medication Adherence segment. At this time, $1.8 million was capitalized as software development costs associated with a software solution that was intended to assist pharmacies in manual packaging of prescriptions. Our management team reassessed the viability of this project and the net realizable value of the capitalized costs in light of their decision to change the related product road map and redesign this product based on evolving market demands. As part of this redesign process, new functionality and capabilities were needed to be added to the product before commercialization. This redesign was intended to provide a more robust global platform providing larger scalability and significant functionality not contained in the then-current beta version. We determined we could no longer support the technological feasibility of this project in conjunction with our software capitalization policy. Therefore, we abandoned the project and wrote off its net book value of $1.8 million, equating to $0.03 per diluted share, net of tax, which was recorded as an expense of research and development in our Consolidated Statements of Operations. |

[0000926326-15-000012:notes:177]
| (2) | Other long-term assets primarily include our equity investments. In the fourth quarter of 2014, we determined our equity investment accounted for under the cost method of accounting is no longer considered realizable, and therefore wrote off its net book value of $0.4 million as a non-operating expense in our Consolidated Statements of Operations. |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-15-000012:notes:178]
Property and Equipment

[0000926326-15-000012:notes:179]
Property and equipment consist of the following assets:

[0000926326-15-000012:notes:180]
|  | December 31, 2014 |  | December 31, 2013 |
|  | (In thousands) |
| Equipment | $ | 42,829 |  |  | $ | 40,180 |  |
| Furniture and fixtures | 5,689 |  |  | 5,260 |  |
| Leasehold improvements | 8,701 |  |  | 7,394 |  |
| Purchased software | 28,920 |  |  | 20,199 |  |
| Construction in progress | 1,538 |  |  | 2,649 |  |
|  | 87,677 |  |  | 75,682 |  |
| Accumulated depreciation and amortization | (51,499 | ) |  | (40,428 | ) |
| Total property and equipment, net | $ | 36,178 |  |  | $ | 35,254 |  |

[0000926326-15-000012:notes:181]
Depreciation and amortization of property and equipment was $11.3 million, $10.9 million and $8.0 million for the years ended December 31, 2014, December 31, 2013 and December 31, 2012, respectively.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000926326-15-000012:notes:182]
Depreciation and amortization of property and equipment are provided over their estimated useful lives, using the straight-line method, as follows:


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000926326-15-000012:notes:183]
Geographical Information

[0000926326-15-000012:notes:184]
|  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2012 |
|  | (In thousands) |
| United States | $ | 394,234 |  |  | $ | 334,412 |  |  | $ | 287,716 |  |
| Foreign countries (1) | 46,666 |  |  | 46,173 |  |  | 26,311 |  |
| Total revenues | $ | 440,900 |  |  | $ | 380,585 |  |  | $ | 314,027 |  |

[0000926326-15-000012:notes:185]
| (1) | No individual country represented more than 10% of the respective totals. |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0000926326-15-000012:notes:186]
The following table sets forth the total share-based compensation expense recognized in our Consolidated Statements of Income:

[0000926326-15-000012:notes:187]
|  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2012 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,456 |  |  | $ | 1,241 |  |  | $ | 1,011 |  |
| Research and development | 1,655 |  |  | 1,359 |  |  | 889 |  |
| Selling, general and administrative | 9,674 |  |  | 8,551 |  |  | 7,314 |  |
| Total share-based compensation expense | $ | 12,785 |  |  | $ | 11,151 |  |  | $ | 9,214 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0000926326-15-000012:notes:188]
A summary of the restricted stock activity under the 2009 Plan is presented below:

[0000926326-15-000012:notes:189]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units |  |  |  |  |  |  |  |
| Outstanding at December 31, 2013 | 362 |  |  | $ | 17.15 |  |  | 2.5 |  |  |
| Granted | 238 |  |  | 28.88 |  |  |  |  |  |
| Vested | (181 | ) |  | 17.51 |  |  |  |  |  |
| Forfeited | (20 | ) |  | 16.50 |  |  |  |  |  |
| Outstanding and unvested at December 31, 2014 | 399 |  |  | $ | 24.00 |  |  | 1.5 |  | $ | 13,190 |  |
| Expected to vest at December 31, 2014 | 387 |  |  |  |  | 1.5 |  | $ | 12,807 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-15-000012:notes:190]
The following table summarizes the financial performance of our reporting segments:

[0000926326-15-000012:notes:191]
|  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2012 |
|  | Automation andAnalytics |  | MedicationAdherence (1) |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence (2) |  | Total |
|  | (In thousands) |
| Revenues | $ | 354,095 |  |  | $ | 86,805 |  |  | $ | 440,900 |  |  | $ | 302,917 |  |  | $ | 77,668 |  |  | $ | 380,585 |  |  | $ | 260,160 |  |  | $ | 53,867 |  |  | $ | 314,027 |  |
| Cost of revenues | 151,327 |  |  | 55,713 |  |  | 207,040 |  |  | 129,314 |  |  | 47,872 |  |  | 177,186 |  |  | 111,599 |  |  | 31,840 |  |  | 143,439 |  |
| Gross profit | 202,768 |  |  | 31,092 |  |  | 233,860 |  |  | 173,603 |  |  | 29,796 |  |  | 203,399 |  |  | 148,561 |  |  | 22,027 |  |  | 170,588 |  |
| Operating expenses | 155,156 |  |  | 29,121 |  |  | 184,277 |  |  | 140,087 |  |  | 28,013 |  |  | 168,100 |  |  | 127,467 |  |  | 15,995 |  |  | 143,462 |  |
| Income from operations | $ | 47,612 |  |  | $ | 1,971 |  |  | $ | 49,583 |  |  | $ | 33,516 |  |  | $ | 1,783 |  |  | $ | 35,299 |  |  | $ | 21,094 |  |  | $ | 6,032 |  |  | $ | 27,126 |  |

[0000926326-15-000012:notes:192]
| (1) | Includes Surgichem results as of August 2014. |

[0000926326-15-000012:notes:193]
| (2) | Includes MTS results as of May 2012. |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000926326-15-000012:notes:194]
A summary of the stock option activity under the 2009 Plan is presented below:

[0000926326-15-000012:notes:195]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value(1) |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2013 | 3,143 |  |  | $ | 15.82 |  |  | 5.6 |  |  |
| Granted | 641 |  |  | 28.11 |  |  |  |  |  |
| Exercised | (1,007 | ) |  | 14.74 |  |  |  |  |  |
| Expired | (12 | ) |  | 19.88 |  |  |  |  |  |
| Forfeited | (93 | ) |  | 19.97 |  |  |  |  |  |
| Outstanding at December 31, 2014 | 2,672 |  |  | $ | 19.02 |  |  | 6.5 |  | $ | 37,692 |  |
| Exercisable at December 31, 2014 | 1,514 |  |  | $ | 15.66 |  |  | 4.7 |  | $ | 26,447 |  |
| Vested and expected to vest at December 31, 2014 | 2,640 |  |  | $ | 18.92 |  |  | 6.4 |  | $ | 37,481 |  |

[0000926326-15-000012:notes:196]
| (1) | Intrinsic value is calculated as the difference between the market value or closing price of our common stock as of the last trading day of the year as reported by the NASDAQ Global Select Market, and the exercise price of the option. |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0000926326-15-000012:notes:197]
The following assumptions were used to estimate the fair value of share-based awards:

[0000926326-15-000012:notes:198]
|  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2012 |
| Stock Option Plans |  |  |  |  |  |
| Risk-free interest rate (1) | 1.6 | % |  | 1.2 | % |  | 0.9 | % |
| Dividend yield | — | % |  | — | % |  | — | % |
| Expected volatility (2) | 34.9 | % |  | 43.1 | % |  | 45.8 | % |
| Expected life (3) | 4.8 years |  |  | 5.3 years |  |  | 5.2 years |  |

[0000926326-15-000012:notes:199]
|  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2012 |
| Employee Stock Purchase Plan |  |  |  |  |  |
| Risk-free interest rate (1) | 0.2 | % |  | 0.2 | % |  | 0.2 | % |
| Dividend yield | — | % |  | — | % |  | — | % |
| Expected volatility (2) | 33.2 | % |  | 35.1 | % |  | 38.5 | % |
| Expected life (3) | 0.5 - 2 years |  |  | 0.5 - 2 years |  |  | 0.5 - 2 years |  |

[0000926326-15-000012:notes:200]
| (1) | The risk-free interest rate for both stock options and the ESPP is based on the zero-coupon U.S. Treasury rate curve in effect at the time of the option grant or at the beginning of the ESPP offering period. |

[0000926326-15-000012:notes:201]
| (2) | Expected volatility for both stock options and the ESPP reflects a combination of historical and market-based implied volatility consistent with ASC 718 and SEC Staff Accounting Bulletin 107. We determined that the combination of historical and market-based implied volatility provides a more accurate reflection of our market conditions and is more representative of future stock price trends than employing solely historical volatility. |

[0000926326-15-000012:notes:202]
| (3) | Represents the period of time that options granted are expected to be outstanding, which is derived from historical data on employee exercise and post-vesting employment termination behavior. |


## us-gaap:ScheduleOfTreasuryStockByClassTextBlock

[0000926326-15-000012:notes:203]
The following table summarizes our stock repurchases:

[0000926326-15-000012:notes:204]
|  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2012 |
|  | (In thousands, except per share data) |
| Total number of shares repurchased | 884 |  |  | 885 |  |  | 898 |  |
| Dollar amount of shares repurchased | $ | 24,091 |  |  | $ | 20,962 |  |  | $ | 12,363 |  |
| Average price paid per share | $ | 27.24 |  |  | $ | 23.70 |  |  | $ | 13.76 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000926326-15-000012:notes:205]
SCHEDULE II

[0000926326-15-000012:notes:206]
VALUATION AND QUALIFYING ACCOUNTS

[0000926326-15-000012:notes:207]
|  |  |  | Additions |  |  |  |  |
|  | Balance atBeginning of Period (1) |  | Charged toCosts and Expenses (2) |  | Credited toOther Accounts (3) |  | AmountWritten Off (4) |  | Balance atEnd of Period (1) |
|  | (In thousands) |
| Year ended December 31, 2012 |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 443 |  |  | $ | 316 |  |  | $ | (57 | ) |  | $ | 20 |  |  | $ | 722 |  |
| Investment in sales-type leases | 284 |  |  | 425 |  |  | — |  |  | (102 | ) |  | 607 |  |
| Total allowances deducted from assets | $ | 727 |  |  | $ | 741 |  |  | $ | (57 | ) |  | $ | (82 | ) |  | $ | 1,329 |  |
| Year ended December 31, 2013 |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 722 |  |  | $ | 195 |  |  | $ | (67 | ) |  | $ | (360 | ) |  | $ | 490 |  |
| Investment in sales-type leases | 607 |  |  | 49 |  |  | — |  |  | (489 | ) |  | 167 |  |
| Total allowances deducted from assets | $ | 1,329 |  |  | $ | 244 |  |  | $ | (67 | ) |  | $ | (849 | ) |  | $ | 657 |  |
| Year ended December 31, 2014 |  |  |  |  |  |  |  |  |  |
| Accounts receivable | $ | 490 |  |  | $ | 941 |  |  | $ | (60 | ) |  | $ | (165 | ) |  | $ | 1,206 |  |
| Investment in sales-type leases | 167 |  |  | — |  |  | (5 | ) |  | — |  |  | 162 |  |
| Total allowances deducted from assets | $ | 657 |  |  | $ | 941 |  |  | $ | (65 | ) |  | $ | (165 | ) |  | $ | 1,368 |  |

[0000926326-15-000012:notes:208]
__________________________________________________

[0000926326-15-000012:notes:209]
| (1) | Allowance for doubtful accounts. |

[0000926326-15-000012:notes:210]
| (2) | Represents amounts charged to bad debt expense. |

[0000926326-15-000012:notes:211]
| (3) | Represents amounts credited to bad debt expense. |

[0000926326-15-000012:notes:212]
| (4) | Represents amounts written-off, net of recoveries. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-15-000012:notes:213]
Segment Information

[0000926326-15-000012:notes:214]
In the first quarter of 2014, we began to manage our business according to two product segments because many of our Acute Care and Non-Acute Care customers were converging to provide services across the continuum of care. We modified our segment reporting structure to match our operating structure based on how our CODM views the business and allocates resources. The two operating segments, which are the same as our reporting segments, are as follows:

[0000926326-15-000012:notes:215]
Automation and Analytics

[0000926326-15-000012:notes:216]
The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. Our Automation and Analytics products are designed to enable our customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, our systems can be tailored to specific customer needs.

[0000926326-15-000012:notes:217]
Medication Adherence

[0000926326-15-000012:notes:218]
The Medication Adherence segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand name of MTS, Surgichem, and under the Omnicell brand, and dispensing systems sold under the Omnicell brand. MTS products consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care, and correctional facilities or retail pharmacies serving patients in their local communities.

[0000926326-15-000012:notes:219]
The historical information presented has been retrospectively adjusted to reflect the new segment reporting. Our CODM allocates resources and evaluates the performance of our segments using information about its revenues, gross profit and income from operations. Except for goodwill, as discussed in Note 8, our assets are not discretely identified or allocated by segment.

[0000926326-15-000012:notes:220]
Significant customers

[0000926326-15-000012:notes:221]
There were no significant customers that accounted for more than 10% of our total revenues in 2014, 2013 and 2012.


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0000926326-15-000012:notes:222]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below:

[0000926326-15-000012:notes:223]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Unvested at December 31, 2013 | 225 |  |  | $ | 13.32 |  |
| Granted | 158 |  |  | 20.94 |  |
| Vested | (114 | ) |  | 13.32 |  |
| Cancelled | (36 | ) |  | 16.73 |  |
| Unvested at December 31, 2014 | 233 |  |  | $ | 17.96 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-15-000012:notes:224]
Employee Benefits and Share-Based Compensation

[0000926326-15-000012:notes:225]
Stock purchase plan

[0000926326-15-000012:notes:226]
1997 Employee Stock Purchase Plan

[0000926326-15-000012:notes:227]
We have an Employee Stock Purchase Plan ("ESPP"), under which employees can purchase shares of our common stock based on a percentage of their compensation, but not greater than 15% of their earnings; provided, however, an eligible employees' right to purchase shares of our common stock may not accrue at a rate which exceeds $25,000 of the fair market value of such shares for each calendar year in which such rights are outstanding. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-15-000012:notes:228]
At our 2009 Annual Meeting of Stockholders ("2009 Annual Meeting"), the stockholders approved an amendment to the ESPP, which added 2.6 million shares to the reserve for future issuance. There was a total of 0.6 million shares reserved for future issuance under the ESPP as of December 31, 2014. For the year ended December 31, 2014, 0.5 million shares of common stock were purchased under the ESPP and an aggregate of 4.7 million shares were issued under the ESPP as of December 31, 2014.

[0000926326-15-000012:notes:229]
The unrecognized compensation cost related to the shares to be purchased under our ESPP was approximately $1.8 million, and is expected to be recognized over a weighted-average period of 0.7 years as of December 31, 2014.

[0000926326-15-000012:notes:230]
Stock award plans

[0000926326-15-000012:notes:231]
2009 Equity Incentive Plan

[0000926326-15-000012:notes:232]
On May 19, 2009, at our 2009 Annual Meeting, our stockholders approved the Omnicell, Inc. 2009 Equity Incentive Plan ("2009 Plan") which authorized 2.1 million shares to be issued. The 2009 Plan provides for the issuance of incentive stock options, non-statutory stock options, stock appreciation rights, restricted stock awards, restricted stock unit awards, performance stock awards, performance cash awards and other stock awards to our employees, directors and consultants.

[0000926326-15-000012:notes:233]
The 2009 Plan succeeded the 1999 Equity Incentive Plan, the 2003 Equity Incentive Plan and the 2004 Equity Incentive Plan (collectively, the "Prior Plans"). No additional awards will be granted under any of the Prior Plans; however, all outstanding stock awards granted under the Prior Plans continue to be subject to the terms and conditions as set forth in the agreements evidencing such stock awards. For purposes of determining future common shares available for grant, for each share granted as a full-value award, including restricted stock awards ("RSAs"), restricted stock unit awards ("RSUs") and performance stock awards, the shares available for issuance were reduced by 1.4 shares for each share granted. Equity awards granted as options and stock appreciation rights reduce the shares available for issuance by one share.

[0000926326-15-000012:notes:234]
On December 16, 2010, at a Special Meeting of Stockholders, our stockholders approved an amendment to increase the number of shares of common stock authorized for issuance under the 2009 Plan by 2.6 million shares and to provide that the number of common stock shares available for issuance under the 2009 Plan be reduced by 1.8 shares for each share granted as a full-value award granted on and after October 1, 2010. For each share granted as a full-value award granted prior to October 1, 2010, future shares available for grants under the 2009 Plan were reduced by 1.4 shares. Awards granted as stock options and stock appreciation rights continue to reduce the number of shares available for issuance under the 2009 Plan on a one-for-one basis. At our 2013 Annual Meeting of Stockholders, our stockholders approved an amendment to the 2009 Plan to increase the number of shares of common stock authorized for issuance by 2.5 million shares. There were 1.8 million shares of common stock reserved for future issuance under the 2009 Plan as of December 31, 2014.

[0000926326-15-000012:notes:235]
Options granted under the 2009 Plan generally become exercisable over periods of up to 4 years, generally with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 36 equal monthly installments thereafter; however our Board of Directors may impose different vesting terms at its discretion on any award. Options under the 2009 Plan generally expire 10 years from the date of grant. We also grant both restricted stock and restricted stock units to participants under the 2009 Plan. The Board of Directors determines the award amount, the vesting provisions and the expiration period (not to exceed ten years) for each grant. Grants of restricted stock to non-employee directors are granted on the date of our annual meeting of stockholders and vest in full on the date of our next annual meeting of stockholders, provided such non-employee director remains a director on such date. The fair value of the stock on the date of issuance is amortized to expense from the date of grant to the date of vesting. RSUs granted to employees generally vest over a period of four years and are expensed ratably on a straight-line basis over the vesting period. We consider the dilutive impact of options, restricted stock and restricted stock units in our diluted net income per share calculation.

[0000926326-15-000012:notes:236]
The 2009 Plan provides that our Board of Directors shall administer the 2009 Plan unless and until the Board of Directors delegates administration to a committee. Our Board of Directors has delegated administration of the 2009 Plan to the Compensation Committee of the Board and the 2009 Plan is generally administered by such committee. The Board of Directors may suspend or terminate the 2009 Plan at any time. The Board of Directors may also amend the 2009 Plan at any time or from time to time. However, no amendment will be effective unless approved by our stockholders after its adoption by the Board of Directors to the extent stockholder approval is necessary to satisfy the applicable listing requirements of NASDAQ.

[0000926326-15-000012:notes:237]
Performance-based restricted stock units

[0000926326-15-000012:notes:238]
In 2011, we began incorporating performance-based restricted stock units ("PSUs") as an element of our executive compensation plans. In 2012, we granted 125,000 PSUs to our executive officers, of which 62,500 PSUs became eligible for vesting upon the achievement of a certain level of shareholder return for 2012. In 2013, we granted 137,500 PSUs to our executive officers all of which became eligible for vesting upon the achievement of a certain level of shareholder return for the period from January 1, 2013 through February 28, 2014. In 2014, we granted 132,500 PSUs to our executive officers, all, none or a portion of which may become eligible for vesting depending on the level of shareholder return for 2014 and eligible for further time-based vesting based on the ranking of our total shareholder return.

[0000926326-15-000012:notes:239]
The fair value of a PSU award is the average of trial-specific values of the award over each of one million Monte Carlo trials. Each trial-specific value is the market value of the award at the end of the one-year performance period discounted back to the grant date. The market value of the award for each trial at the end of the performance period is the product of (a) the per share value of Omnicell stock at the end of the performance period and (b) the number of shares that vest. The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of each of the other companies in the NASDAQ Healthcare Index (the "Index").

[0000926326-15-000012:notes:240]
Vesting for the PSUs is based both on the percentile placement of our total stockholder return among the companies listed in the Index and time-based vesting. We calculate total stockholder return based on the one year annualized rates of return reflecting price appreciation plus reinvestment of dividends. For PSUs granted on February 4, 2014, stock price appreciation is calculated based on the trailing 20-day average stock price from the first trading day of March 2014, compared to the trailing 20-day average stock price from the first trading day of March 2015. For PSUs granted in 2013, stock price appreciation is calculated based on the average closing prices of the applicable company’s common stock for the 20 trading days ended on the last trading day of 2012 as compared to the average closing prices of the common stock for the 20 trading days preceding the first trading day of March 2014. For PSUs granted in 2012, stock price appreciation is calculated based on the average closing prices of the applicable company's common stock for the 20 trading days ending on the last trading day of 2011 as compared to the average closing prices for the 20 trading days ended on the last trading day of 2012.

[0000926326-15-000012:notes:241]
On January 17, 2012, the Compensation Committee confirmed 76.3% as the percentile rank of our 2011 total stockholder return. This resulted in 120% of the 2011 PSUs, or 120,000 shares, becoming eligible for further time-based vesting. The eligible PSUs vest as follows: 25% of the eligible awards for the first year vested on January 17, 2012 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three-year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service. Of the 120,000 shares eligible for time-based vesting under the 2011 PSUs, 30,000 shares vested during the year ended December 31, 2014.

[0000926326-15-000012:notes:242]
On January 22, 2013, the Compensation Committee confirmed 35.3% as the percentile rank of our 2012 total stockholder return. This resulted in 50% of the 2012 PSUs, or 62,500 shares, as eligible for further time-based vesting. The eligible PSUs vest as follows: 25% of the eligible shares vested immediately on January 22, 2013 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three-year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service. Of the 62,500 shares eligible for time-based vesting under the 2012 PSUs, 15,600 shares vested during the year ended December 31, 2014.

[0000926326-15-000012:notes:243]
On March 20, 2014, the Compensation Committee confirmed 63.9% as the percentile rank of our 2013 total stockholder return. This resulted in 100% of the 2013 PSUs, or 137,500 shares, as eligible for further time-based vesting. The eligible performance based restricted stock unit awards will vest as follows: 25% of the eligible shares vested immediately on March 20, 2014 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three-year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service. Of the 137,500 shares eligible for time-based vesting under the 2013 PSUs, 68,750 shares vested during the year ended December 31, 2014.

[0000926326-15-000012:notes:244]
On February 5, 2014, the Compensation Committee approved PSUs of 132,500 shares. If the minimum performance threshold is met as determined by the Compensation Committee in 2015, the eligible performance-based restricted stock unit awards will vest as follows: 25% of the eligible shares will vest immediately, with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service.

[0000926326-15-000012:notes:245]
The fair value of each option grant is estimated on the date of grant using the Black-Scholes-Merton option-pricing model. The fair value of shares issued under the employee stock purchase plans is estimated on the date of issuance using the Black-Scholes-Merton model.

[0000926326-15-000012:notes:246]
Share-based compensation expense

[0000926326-15-000012:notes:247]
We account for share-based awards granted to employees and directors, including employee stock option awards, restricted stock, PSUs and RSUs issued pursuant to the 2009 Plan and employee stock purchases made under our ESPP using the estimate grant date fair value method of accounting in accordance with ASC 718, Stock Compensation. We value options and ESPP shares using the Black-Scholes-Merton option-pricing model. Restricted stock and time-based RSUs are valued at the grant date fair value of the underlying common shares. The PSUs are valued using the Monte Carlo simulation model.

[0000926326-15-000012:notes:248]
We did not capitalize any share-based compensation as inventory as such amounts were not material for the years ended December 31, 2014, December 31, 2013 and December 31, 2012. Income tax benefits realized from share-based compensation were $4.5 million, $2.4 million and $2.6 million, for the years ended December 31, 2014, December 31, 2013 and December 31, 2012, respectively.

[0000926326-15-000012:notes:249]
Stock options activity

[0000926326-15-000012:notes:250]
The weighted-average fair value per share of options granted during 2014, 2013 and 2012 was $9.12, $8.09 and $6.13, respectively. The intrinsic value of options exercised during 2014, 2013 and 2012 was $14.1 million, $14.0 million and $2.8 million, respectively.

[0000926326-15-000012:notes:251]
As of December 31, 2014, total unrecognized compensation cost related to unvested stock options was $8.8 million, which is expected to be recognized over a weighted-average vesting period of 2.8 years.

[0000926326-15-000012:notes:252]
Restricted stock activity

[0000926326-15-000012:notes:253]
The weighted-average grant date fair value per share of RSUs granted during 2014, 2013 and 2012 was $28.88, $19.87 and $14.58, respectively. The total fair value of RSUs that vested in 2014, 2013 and 2012 was $3.2 million, $4.4 million and $2.3 million, respectively.

[0000926326-15-000012:notes:254]
As of December 31, 2014, total unrecognized compensation cost related to RSUs was $8.7 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.6 years.

[0000926326-15-000012:notes:255]
The weighted-average grant date fair value per share of RSAs granted during 2014, 2013 and 2012 was $26.42, $18.20 and $14.19, respectively. The total fair value of RSAs that vested in 2014, 2013 and 2012 was $1.0 million, $1.1 million and $1.1 million, respectively.

[0000926326-15-000012:notes:256]
As of December 31, 2014, total unrecognized compensation cost related to RSAs was $0.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.5 years.

[0000926326-15-000012:notes:257]
Performance-based restricted stock units activity

[0000926326-15-000012:notes:258]
The weighted-average grant date fair value per share of PSUs granted during 2014, 2013 and 2012 was $20.94, $14.68 and $10.94, respectively. The total fair value of PSUs that vested in 2014, 2013 and 2012 was $1.5 million, $0.7 million and $0.7 million, respectively.

[0000926326-15-000012:notes:259]
As of December 31, 2014, total unrecognized compensation cost related to PSUs was approximately $2.0 million, which is expected to be recognized over the remaining weighted-average period of 1.2 years.

[0000926326-15-000012:notes:260]
401(k) Plan

[0000926326-15-000012:notes:261]
We have established a 401(k) tax-deferred savings plan ("Omnicell Plan"), whereby eligible employees may contribute a percentage of their eligible compensation, but not greater than 75% of their earnings, up to the maximum as required by law. On January 1, 2009, we began matching 401(k) contributions, up to a maximum of 3% of employee contributions, not to exceed $1,000 for the year. In the first quarter of 2013, the MTS 401(k) tax-deferred savings plan was merged with the Omnicell Plan. On January 1, 2014, the Omnicell Plan was changed to match 50% of employee contributions up to $1,500, with no limit to employee contributions as long as such contributions do not exceed 75% of their earnings. Effective January 1, 2015, we will begin to match 50% of employee contributions up to $2,000, with the same limitations on employee contributions as of January 1, 2014.

[0000926326-15-000012:notes:262]
Our contributions under the Omnicell Plan were $1.3 million, $1.1 million and $0.8 million in 2014, 2013 and 2012, respectively.

[0000926326-15-000012:notes:263]
Preferred Stock

[0000926326-15-000012:notes:264]
There were 5.0 million preferred shares authorized, and no preferred shares issued or outstanding as of December 31, 2014 and December 31, 2013.


## us-gaap:SubsequentEventsTextBlock

[0000926326-15-000012:notes:265]
Subsequent Events

[0000926326-15-000012:notes:266]
On February 26, 2015, Omnicell International, Inc., a wholly-owned subsidiary of Omnicell, Inc. entered into an agreement with Apotheka Imedisa 2001 S.A., Holger Wallat, Dirk Rolf Beils and Peter Jansen (collectively, the “Selling Shareholders”) for the purchase of the entire registered share capital of Mach 4 Automatisierungstechnik GmbH (“Mach4”) (the “Share Purchase Agreement”). Mach4 is a provider of automated medication management systems to retail and hospital pharmacy customers primarily in Europe, with additional installations in China, the Middle East and Latin America. The contemplated total aggregate consideration is $18.0 million in cash, minus existing debt and subject to certain adjustments provided for in the Share Purchase Agreement. The closing of the acquisition is subject to certain closing conditions.

[0000926326-15-000012:notes:267]
On February 27, 2015, the Company received a notice from an Omnicell employee alleging, among other matters, the existence of a "side letter" arrangement with an Omnicell customer for certain discounts and Omnicell products that were to be provided at no cost, but which were not reflected in the final invoices paid by the customer. Following the receipt of this notice, the Company commenced an internal investigation into these allegations. This investigation was concluded on March 25, 2015. Based on the results of the investigation, the Company has determined that effective internal control over financial reporting was maintained in all material respects and that there are no changes required to be made to the Company’s Consolidated Financial Statements.

[0000926326-15-000012:notes:268]
On March 19, 2015, a putative class action lawsuit was filed against the Company and two executive officers in the U.S. District Court for the Northern District of California, captioned Nelson v. Omnicell, Inc., et al., Case No. 3:15-cv-01280-HSG. The complaint purports to assert claims on behalf of a class of purchasers of the Company’s stock between May 2, 2014 and March 2, 2015. It alleges that defendants violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934 by purportedly making false and misleading statements regarding the existence of a “side letter” arrangement and the adequacy of internal controls that allegedly resulted in false and misleading financial statements. The Company and the individual defendants have not yet been served with the Complaint. The Company believes that the claims have no merit and will defend the lawsuit vigorously.


## us-gaap:TreasuryStockTextBlock

[0000926326-15-000012:notes:269]
Stock Repurchases

[0000926326-15-000012:notes:270]
In August 2012, our Board of Directors authorized a program to repurchase up to $50.0 million of common stock, of which approximately $45.1 million had been repurchased as of December 31, 2014. In November 2014, our Board of Directors authorized a program to repurchase up to $50.0 million of common stock. We expect to begin repurchasing shares under the 2014 Stock Repurchase Program upon the completion of the 2012 Stock Repurchase Program. Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of December 31, 2014, and neither program has an expiration date.
