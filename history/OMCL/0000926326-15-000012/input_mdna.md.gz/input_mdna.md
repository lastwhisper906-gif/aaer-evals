# OMCL MD&A — 0000926326-15-000012


## mdna

[0000926326-15-000012:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000926326-15-000012:mdna:2]
The following discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related notes in this annual report. This discussion may contain forward-looking statements based upon current expectations that involve risks and uncertainties. Our actual results and the timing of selected events could differ materially from those anticipated in these forward-looking statements as a result of several factors, including those set forth under Item 1A "Risk Factors" and elsewhere in this annual report. Unless otherwise stated, references in this report to particular years or quarters refer to our fiscal year and the associated quarters of those fiscal years.

[0000926326-15-000012:mdna:3]
OVERVIEW

[0000926326-15-000012:mdna:4]
Our Business

[0000926326-15-000012:mdna:5]
We are a leading provider of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum, from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home. Our Omnicell Automation and Analytic customers worldwide utilize our medication automation, supply chain and analytics solutions to help enable them to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety.

[0000926326-15-000012:mdna:6]
Omnicell Medication Adherence solutions, including the MTS and Surgichem brands, provide innovative medication adherence packaging solutions that can help reduce costly hospital readmissions and enable institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-15-000012:mdna:7]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 89% of our total revenues in 2014 and we expect our revenues from international operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-15-000012:mdna:8]
Operating Segments

[0000926326-15-000012:mdna:9]
In the first quarter of 2014, we began to manage our business according to two product segments as many of our Acute Care and Non-Acute Care customers are converging to provide services across the continuum of care. These customers seek Automation and Analytics products that function across the various facilities they manage, and we find ourselves providing solutions across multiple types of care environments. These customers are also interested in obtaining higher levels of adherence to prescribed medication regimens that our blister card products can help provide. Our business has evolved to be managed more on a product basis and it has become more difficult to determine whether a customer is a hospital or a blend of hospitals and non-acute care facilities.

[0000926326-15-000012:mdna:10]
We modified our segment reporting structure to match our new operating structure in the first quarter of 2014. The two operating segments which are the same as our reporting segments are Automation and Analytics and Medication Adherence. As our business evolves, we will continue to assess our operating units which could result in future modifications to our current operating segments. For further description of our operating segments, Note 17, Segment Information, of the Notes to Consolidated Financial Statements in this annual report.

[0000926326-15-000012:mdna:11]
Strategy

[0000926326-15-000012:mdna:12]
The healthcare market is experiencing a period of substantive change. The adoption of electronic healthcare records, new regulatory constraints, and changes in the reimbursement structure have caused healthcare institutions to re-examine their operating structures, re-prioritize their investments, and seek efficiencies. We believe our customers’ evolving operating environment creates challenges for any supplier, but also affords opportunities for suppliers that are able to partner with customers to help them meet the changing demands. We have and intend to continue to invest in the strategies which we believe have generated and will continue to generate our revenue and earnings growth, while supporting our customers’ initiatives and needs. These strategies include:

[0000926326-15-000012:mdna:13]
| • | Development of differentiated products. We invest in the development of products that we believe bring patient safety and workflow efficiency to our customers’ operations that they cannot get from other competing solutions. These differentiators may be as small as how a transaction operates or information provided on a report or as large as the entire automation of a workflow that would otherwise be completed manually. We intend to continue our |

[0000926326-15-000012:mdna:14]
35

[0000926326-15-000012:mdna:15]
focus on differentiating our products, and we carefully assess our investments regularly as we strive to ensure those investments provide the solutions most valuable to our customers.

[0000926326-15-000012:mdna:16]
| • | Deliver our solutions to new markets. Areas of healthcare where work is done manually may benefit from our existing solutions. These areas include hospitals that continue to utilize manual operations, healthcare segments of the U.S. market outside hospitals and markets outside the United States. We weigh the cost of entering these new markets against the expected benefits and focus on the markets that we believe are most likely to adopt our products. |

[0000926326-15-000012:mdna:17]
| • | Expansion of our solutions through acquisitions and partnerships. Our acquisitions have generally been focused on automation of manual workflows or data analytics, which is the enhancement of data for our customers’ decision-making processes. We believe that expansion of our product lines through acquisition and partnerships to meet our customers changing and evolving expectations is a key component to our historical and future success. |

[0000926326-15-000012:mdna:18]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, we began shipping a refresh of our product line in 2011, which we market as G4. The G4 refresh included multiple new products and an upgrade product that allowed existing customers to augment their installations to obtain the most current technology that we provide. The G4 product refresh has been a key contributor to our growth, with 61% of our automation and analytics installed base ordering upgrades to their existing systems since the announcement of G4. In addition to enhanced capabilities, we have focused on attaining the highest quality and service measurements for G4 in the industry, while marketing the solution to new and existing customers. Our research and development efforts today are designed to bring new products to market beyond the G4 product line that we believe will meet customer needs in years to come.

[0000926326-15-000012:mdna:19]
Consistent with our strategy to enter new markets, we have made investments in our selling, general and administrative expenses to expand our sales team and market to new customers. Our international efforts have focused primarily on four markets: the United Kingdom where we sell medication adherence products through a direct sales team and automation and analytics products through a distributor, Germany where we sell medication adherence products through a direct sales team, Middle Eastern countries of the Arabian Peninsula where new healthcare facility construction is taking place, and in China, where we launched a Mandarin version of our automated dispensing systems in 2011. In the third quarter of 2012, we purchased 15% of our United Kingdom automation and analytics products distributor’s outstanding equity for approximately $0.9 million in cash to accelerate the adoption of medication and supply automation. In connection with the investment, we have the right, under certain circumstances, to appoint a member to this company's board of directors as well as certain other voting rights and, therefore, we believe we have the ability to exert significant influence over this distributor's operations. Our proportionate equity share of the income of this distributor, recognized in interest and other income, net, was immaterial for the years ended December 31, 2014, December 31, 2013 and December 31, 2012. We have also expanded our sales efforts to medication adherence customers in the United States which has allowed us to sell our automated dispensing solutions and other products to this market.

[0000926326-15-000012:mdna:20]
Expansion of our solutions through acquisitions and partnerships include our acquisition of MTS in 2012 and our acquisition of Surgichem in August 2014. Surgichem is a provider of medication adherence products in the United Kingdom. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-15-000012:mdna:21]
We believe that the success of our three leg strategy of differentiated products, expansion into new markets, and acquisition and partnership in future periods will be based on, among other factors:

[0000926326-15-000012:mdna:22]
| • | Our expectation that the overall market demand for healthcare services will increase as the population grows, life expectancies continue to increase and the quality and availability of healthcare services increases; |

[0000926326-15-000012:mdna:23]
| • | Our expectation that the environment of increased patient safety awareness, increased regulatory control, increased demand for innovative products that improve the care experience and increased need for workflow efficiency through the adoption of technology in the healthcare industry will make our solutions a priority in the capital budgets of healthcare facilities; and |

[0000926326-15-000012:mdna:24]
| • | Our belief that healthcare customers will continue to value a consultative customer experience from their suppliers. |

[0000926326-15-000012:mdna:25]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced by a contract and purchase order for equipment and software, and by a

[0000926326-15-000012:mdna:26]
36

[0000926326-15-000012:mdna:27]
purchase order for consumables. Equipment and software bookings are installable within twelve months and generally recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month. Product bookings increased 11%, from $327.8 million in 2013 to $364.0 million in 2014, driven by the success of our growth strategies in differentiated products and new markets and, to a lesser extent, by the partial year of contribution from the acquisition of Surgichem.

[0000926326-15-000012:mdna:28]
In addition to product solution sales, we provide services to our customers.  Our healthcare customers expect a high degree of partnership involvement from their technology suppliers throughout their ownership of the products. We provide extensive installation planning and consulting as part of every product sale and included in the initial price of the solution. Our customers' medication control systems are mission critical to their success and our customers require these systems to be functional at all times. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in one, two or five year increments.  As a result of the growth of our installed base of customers, our service revenues have also grown. We strive to provide the best service possible, as measured by third-party rating agencies and by our own surveys, to assure our customers continue to seek service maintenance from us. Our liabilities include current and long-term deferred service revenue of $45.5 million and $40.4 million as of December 31, 2014 and December 31, 2013, respectively. Our deferred service revenue will be amortized to service revenue as the service contracts are executed.

[0000926326-15-000012:mdna:29]
The growth in our Automation and Analytics revenue was driven primarily by our success in consistently growing the number of our customer installations for the year ended December 31, 2014. Installed customers in the United States grew from 1,806 hospitals as of December 31, 2013 to 1,935 hospitals as of December 31, 2014. To a lesser extent, but of equal importance, revenue growth was also driven by our success in upgrading installed customers to newer G4 technology, which is in line with our strategy of striving to deliver differentiated innovation in our solutions. Our larger installed base has provided growth opportunities and, as a result, our service revenues have also grown for the year ended December 31, 2014.

[0000926326-15-000012:mdna:30]
The growth in our Medication Adherence revenue was driven primarily by increased sales of our OnDemand medication packaging systems in the United States market and increased adoption of multi-medication adherence solutions used by patients in assisted living or home care in Europe for the year ended December 31, 2014. This growth is in line with our strategy to deliver solutions to markets outside the United States. On a geographic basis, the United States market did not contribute to, nor erode, the growth in our Medication Adherence business as the population of patients living in nursing homes in the United States has remained relatively constant over the past year.

[0000926326-15-000012:mdna:31]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but for our focus to remain on improving healthcare with solutions that help change the practices in ways that improve patient and provider outcomes. We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue. In 2015, we also intend to manage our business to operating profit margins similar to those achieved in 2014. Our full-time headcount of 1,236 on December 31, 2014, which is an increase of 102 from December 31, 2013, is dedicated to bringing our strategies to bear in all the markets we participate in.

[0000926326-15-000012:mdna:32]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000926326-15-000012:mdna:33]
Our discussion and analysis of our financial condition and results of operations are based on our Consolidated Financial Statements, which have been prepared in accordance with United States Generally Accepted Accounting Principles ("U.S. GAAP"). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0000926326-15-000012:mdna:34]
Revenue recognition

[0000926326-15-000012:mdna:35]
We earn revenues from sales of our medication and medical and surgical supply automation systems along with consumables and related services that are sold in the healthcare industry, our principal market. Revenues related to consumable products are reported net of discounts provided to our customers. Our customer arrangements typically include one or more of the following deliverables:

[0000926326-15-000012:mdna:36]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

[0000926326-15-000012:mdna:37]
37

[0000926326-15-000012:mdna:38]
Software. Additional software applications that enable incremental functionality of our equipment.

[0000926326-15-000012:mdna:39]
Installation. Installation of equipment as integrated systems at customers' sites.

[0000926326-15-000012:mdna:40]
Post-installation technical support. Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available.

[0000926326-15-000012:mdna:41]
Professional services. Other customer services, such as training and consulting.

[0000926326-15-000012:mdna:42]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

[0000926326-15-000012:mdna:43]
Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement.

[0000926326-15-000012:mdna:44]
Delivery has occurred. Equipment and embedded software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. For existing distributors, where installation of equipment training has been previously provided and the distributor is certified to install our equipment at the end-user customer facility, we recognize revenue from sales of products to the distributor upon shipment assuming all other revenue criteria are met, since we do not allow for rights of return or refund. For new distributors, where we have not provided installation of equipment training, revenue on the sales of products to the distributor is deferred until the distributor has completed the Distributor Training Program and has been certified to install our equipment at the end-user facility. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period. We recognize revenue on training and professional services as they are performed.

[0000926326-15-000012:mdna:45]
Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services.

[0000926326-15-000012:mdna:46]
Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable.

[0000926326-15-000012:mdna:47]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. We allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of the selling price. VSOE represents the price charged for a deliverable when it is sold separately, or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of the selling price for our post-installation technical support services and professional services. When VSOE of selling price is not available, third-party evidence ("TPE") of selling price for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE and BESP information.

[0000926326-15-000012:mdna:48]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable (an "Element") on the basis of its estimated selling price. In addition, the amount recognized for any delivered Elements cannot exceed that which is contingent upon delivery of any remaining Elements in the arrangement.

[0000926326-15-000012:mdna:49]
We also use the residual method to allocate revenue between the software products that enable incremental equipment functionality, and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as

[0000926326-15-000012:mdna:50]
38

[0000926326-15-000012:mdna:51]
these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0000926326-15-000012:mdna:52]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income on these leases is recognized as a component of product revenue using the interest method.

[0000926326-15-000012:mdna:53]
Accounts receivable and notes receivable (net investment in sales-type leases)

[0000926326-15-000012:mdna:54]
We actively manage our accounts receivable to minimize credit risk. We typically sell our products to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer's impaired ability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position.

[0000926326-15-000012:mdna:55]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

[0000926326-15-000012:mdna:56]
The retained in-house leases discussed above are considered financing receivables. Our credit policies and evaluation of credit risk and write-off policies are applied alike to trade receivables and the net investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class. Financing receivables which are reserved are generally transferred to cash-basis accounting so that revenue is recognized only as cash is received. However, the cash basis accounts continue to accrue interest.

[0000926326-15-000012:mdna:57]
Valuation and impairment of goodwill, intangible assets and other long-lived assets

[0000926326-15-000012:mdna:58]
Business combination valuations. When we acquire businesses, we allocate the purchase price to tangible assets and liabilities and identifiable intangible assets acquired. Any residual purchase price is recorded as goodwill. The allocation of the purchase price requires management to make significant estimates in determining the fair values of assets acquired and liabilities assumed, especially with respect to intangible assets. These estimates are based on information obtained from management of the acquired companies and historical experience. These estimates can include, but are not limited to:

[0000926326-15-000012:mdna:59]
| • | cash flows that an asset is expected to generate in the future; |

[0000926326-15-000012:mdna:60]
| • | the acquired company’s brand and competitive position, as well as assumptions about the period of time the acquired brand will continue to be used in the combined company’s product portfolio; |

[0000926326-15-000012:mdna:61]
| • | cost savings expected to be derived from acquiring an asset; and |

[0000926326-15-000012:mdna:62]
| • | discount rates. |

[0000926326-15-000012:mdna:63]
These estimates are inherently uncertain and unpredictable, and if different estimates were used, the purchase price for the acquisition could be allocated to the acquired assets and liabilities differently from the allocation that we have made. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates, and if such events occur we may be required to record a charge against the value ascribed to an acquired asset or an increase in the amounts recorded for assumed liabilities.

[0000926326-15-000012:mdna:64]
Goodwill impairment. We review goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. Our reporting units are the same as our operating segments, which are Automation and Analytics and Medication Adherence. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. This initial assessment includes, among others, consideration of: (i) past, current and projected future

[0000926326-15-000012:mdna:65]
earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this initial qualitative assessment indicates that it is more likely than not that impairment exists, or if we decide to bypass this option, we proceed to a two-step impairment test. The first step ("Step 1") involves a comparison between the estimated fair values of our reporting units with their respective carrying amounts including goodwill. The methods for estimating reporting unit values include asset and liability fair values and other valuation techniques, such as discounted cash flows and multiples of earnings or revenues. If the carrying value exceeds estimated fair value, there is an indication of potential impairment, and the second step is performed to measure the amount of impairment. The second step involves calculating an implied fair value of goodwill by measuring the excess of the estimated fair value of the reporting units over the aggregate estimated fair values of the individual assets less liabilities. If the carrying value of goodwill exceeds the implied fair value of goodwill, an impairment charge is recorded for the excess.

[0000926326-15-000012:mdna:66]
The process of estimating the fair value and carrying value of our reporting units’ equity requires significant judgment at many points during the analysis. Various assets and liabilities are not specifically allocated to an individual reporting unit, and therefore, we apply judgment to allocate the assets and liabilities, and this allocation affects the carrying value of the respective reporting units. Applying the income approach requires that we make a number of important estimates and assumptions. We estimate the future cash flows of each reporting unit based on historical and forecasted revenue and operating costs. This involves further estimates, such as estimates of future revenue and expense growth rates. In addition, we apply a discount rate to the estimated future cash flows for the purpose of the valuation. This discount rate is based on the estimated weighted-average cost of capital for each reporting unit and may change from year to year. Changes in these key estimates and assumptions, or in other assumptions used in this process, could materially affect our impairment analysis for a given year.

[0000926326-15-000012:mdna:67]
Based on a Step 1 impairment analysis performed as of October 1, 2014, we determined that it was more likely than not that the fair value of each of our reporting units exceeded the carrying value by approximately 25%, and thus no impairment in our reporting units.

[0000926326-15-000012:mdna:68]
Intangible assets and other long-lived assets. We assess the impairment of identifiable intangible assets and other long-lived assets whenever events or changes in circumstances indicate that an asset's carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. Our cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of our intangible assets and other long-lived assets are subjective and are affected by changes to our business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of our assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0000926326-15-000012:mdna:69]
Inventory

[0000926326-15-000012:mdna:70]
Inventories are stated at the lower of cost (utilizing standard costs), applying the first-in, first-out method, or market. We routinely assess our on-hand inventory for timely identification and measurement of obsolete, slow-moving or otherwise impaired inventory. We write down inventory for estimated obsolescence, excess or unmarketable quantities equal to the difference between the cost of the inventory and its estimated market value based on assumptions about future demand and market conditions, or lower of cost or market. If actual future demand or market conditions are less favorable than we projected, additional inventory write-downs may be required.

[0000926326-15-000012:mdna:71]
Valuation of share-based awards

[0000926326-15-000012:mdna:72]
We account for share-based compensation in accordance with ASC 718, Stock Compensation ("ASC 718"). We recognize compensation expense related to stock-compensation, including the awarding of employee stock options and restricted stock units, based on the grant date estimated fair value. We amortize the fair value of the employee stock options on a straight-line basis over the requisite service period of the award, which is generally the vesting period. We estimate the fair value of stock-based compensation awards using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of our common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on our historical experience of employee stock option exercises, including forfeitures. The valuation assumptions we use in estimating the fair value of employee share-based awards may change in future periods. We calculate our pool of excess tax benefits available within additional paid-in capital in accordance with the provisions of ASC 718.

[0000926326-15-000012:mdna:73]
Accounting for income taxes

[0000926326-15-000012:mdna:74]
40

[0000926326-15-000012:mdna:75]
We record an income tax provision for the anticipated tax consequences of the reported results of operations. In accordance with ASC 740, Income Taxes ("ASC 740"), the provision for income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities, and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, we will incur a benefit or detriment on our income tax expense in the period of change. If we were to determine that all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-15-000012:mdna:76]
In accordance with ASC 740, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of ASC 740 and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.

[0000926326-15-000012:mdna:77]
Recently issued authoritative guidance

[0000926326-15-000012:mdna:78]
Refer to Note 1, Summary of Significant Accounting Policies, of the Notes to Consolidated Financial Statements in this annual report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial positions and cash flows.

[0000926326-15-000012:mdna:79]
RESULTS OF OPERATIONS

[0000926326-15-000012:mdna:80]
Total Revenues

[0000926326-15-000012:mdna:81]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2014 |  | $ |  | % |  | 2013 |  | $ |  | % |  | 2012 |
|  | (Dollars in thousands) |
| Product revenues | $ | 360,344 |  |  | $ | 53,155 |  |  | 17 | % |  | $ | 307,189 |  |  | $ | 59,535 |  |  | 24 | % |  | $ | 247,654 |  |
| Percentage of total revenues | 82 | % |  |  |  |  |  | 81 | % |  |  |  |  |  | 79 | % |
| Service and other revenues | 80,556 |  |  | 7,160 |  |  | 10 | % |  | 73,396 |  |  | 7,023 |  |  | 11 | % |  | 66,373 |  |
| Percentage of total revenues | 18 | % |  |  |  |  |  | 19 | % |  |  |  |  |  | 21 | % |
| Total revenues | $ | 440,900 |  |  | $ | 60,315 |  |  | 16 | % |  | $ | 380,585 |  |  | $ | 66,558 |  |  | 21 | % |  | $ | 314,027 |  |

[0000926326-15-000012:mdna:82]
2014 compared to 2013:

[0000926326-15-000012:mdna:83]
Product revenues represented 82%, 81% and 79% of total revenues for the years ended 2014, 2013 and 2012, respectively. Product revenues increased due to increased sales for both our Automation and Analytics segment of $44.0 million and Medication Adherence segment of $9.1 million. Service and other revenues represented 18%, 19% and 21% of total revenues for the years ended 2014, 2013 and 2012, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues primarily increased due to an increase from our Automation and Analytics segment of $7.1 million.

[0000926326-15-000012:mdna:84]
Our international sales represented 11%, 12% and 8% of total revenues for the years ended 2014, 2013 and 2012, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-15-000012:mdna:85]
We anticipate our revenues will continue to increase in 2015 compared to 2014, as we fulfill our existing orders, and based on our growth in bookings in 2014, some of which will be recognized as revenue in 2015. Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-15-000012:mdna:86]
2013 compared to 2012:

[0000926326-15-000012:mdna:87]
41

[0000926326-15-000012:mdna:88]
Product revenues increased due to increased sales for both Automation and Analytics segment of $35.3 million and Medication Adherence segment of $24.2 million, of which $29.2 million was from our MTS operations. Service and other revenues increased primarily as a result of an expansion in our installed base of automation systems and a resulting increase in the number of support service contracts within our Automation and Analytics segment.

[0000926326-15-000012:mdna:89]
Financial Information by Segment

[0000926326-15-000012:mdna:90]
Revenues

[0000926326-15-000012:mdna:91]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2014 |  | $ |  | % |  | 2013 |  | $ |  | % |  | 2012 |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 354,095 |  |  | $ | 51,178 |  |  | 17 | % |  | $ | 302,917 |  |  | $ | 42,757 |  |  | 16 | % |  | $ | 260,160 |  |
| Percentage of total revenues | 80 | % |  |  |  |  |  | 80 | % |  |  |  |  |  | 83 | % |
| Medication Adherence | 86,805 |  |  | 9,137 |  |  | 12 | % |  | 77,668 |  |  | 23,801 |  |  | 44 | % |  | 53,867 |  |
| Percentage of total revenues | 20 | % |  |  |  |  |  | 20 | % |  |  |  |  |  | 17 | % |
| Total revenues | $ | 440,900 |  |  | $ | 60,315 |  |  | 16 | % |  | $ | 380,585 |  |  | $ | 66,558 |  |  | 21 | % |  | $ | 314,027 |  |

[0000926326-15-000012:mdna:92]
2014 compared to 2013:

[0000926326-15-000012:mdna:93]
Automation and Analytics revenues increased due to an increase in product revenues of $44.0 million primarily due to the increase of $40.3 million in Medical Automation Cabinets sales and of $7.4 million in Supply Cabinets and Supply Management software sales, partially offset by a decrease of $3.7 million in revenue related to our leasing business. Service and other revenues increased by $7.1 million due to higher service renewal fees driven primarily by an increase in installed base customers and new customers.

[0000926326-15-000012:mdna:94]
Medication Adherence revenues increased due to an increase in product revenues of $9.1 million primarily as a result of an increase in sales of OnDemand medication packaging systems in the United States and an increase in the adoption of our multi-medication consumable products by patients in Europe, and includes $4.6 million in revenue from our Surgichem operations since its acquisition in August 2014. Service and other revenues remained relatively flat compared to the prior year.

[0000926326-15-000012:mdna:95]
2013 compared to 2012:

[0000926326-15-000012:mdna:96]
Automation and Analytics revenues increased due to an increase in product revenues of $35.3 million primarily as a result of increased customers' receptivity to our products due to product differentiation and entrance into new markets, coupled with an increase in service revenues of $7.4 million due to an increase in the number of support service contracts as a result of the expansion in our installed base customers.

[0000926326-15-000012:mdna:97]
Increased Medication Adherence revenues were primarily driven by an increase of $29.2 million in product revenues related to the MTS acquisition in May of 2012, partially offset by a slight decline in other product revenues. Service and other revenues remained relatively flat compared to the prior year.

[0000926326-15-000012:mdna:98]
42

[0000926326-15-000012:mdna:99]
Cost of revenues and Gross profit

[0000926326-15-000012:mdna:100]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2014 |  | $ |  | % |  | 2013 |  | $ |  | % |  | 2012 |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 151,327 |  |  | $ | 22,013 |  |  | 17 | % |  | $ | 129,314 |  |  | $ | 17,715 |  |  | 16 | % |  | $ | 111,599 |  |
| As a percentage of related revenues | 43 | % |  |  |  |  |  | 43 | % |  |  |  |  |  | 43 | % |
| Medication Adherence | 55,713 |  |  | 7,841 |  |  | 16 | % |  | 47,872 |  |  | 16,032 |  |  | 50 | % |  | 31,840 |  |
| As a percentage of related revenues | 64 | % |  |  |  |  |  | 62 | % |  |  |  |  |  | 59 | % |
| Total cost of revenues | $ | 207,040 |  |  | $ | 29,854 |  |  | 17 | % |  | $ | 177,186 |  |  | $ | 33,747 |  |  | 24 | % |  | $ | 143,439 |  |
| As a percentage of total revenues | 47 | % |  |  |  |  |  | 47 | % |  |  |  |  |  | 46 | % |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 202,768 |  |  | $ | 29,165 |  |  | 17 | % |  | $ | 173,603 |  |  | $ | 25,042 |  |  | 17 | % |  | $ | 148,561 |  |
| Automation and Analytics gross margin | 57 | % |  |  |  |  |  | 57 | % |  |  |  |  |  | 57 | % |
| Medication Adherence | 31,092 |  |  | 1,296 |  |  | 4 | % |  | 29,796 |  |  | 7,769 |  |  | 35 | % |  | 22,027 |  |
| Medication Adherence gross margin | 36 | % |  |  |  |  |  | 38 | % |  |  |  |  |  | 41 | % |
| Total gross profit | $ | 233,860 |  |  | $ | 30,461 |  |  | 15 | % |  | $ | 203,399 |  |  | $ | 32,811 |  |  | 19 | % |  | $ | 170,588 |  |
| Total gross margin | 53 | % |  |  |  |  |  | 53 | % |  |  |  |  |  | 54 | % |

[0000926326-15-000012:mdna:101]
2014 compared to 2013:

[0000926326-15-000012:mdna:102]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which accounts for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site, and include costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory and amortization of software development costs.

[0000926326-15-000012:mdna:103]
Automation and Analytics

[0000926326-15-000012:mdna:104]
Cost of revenues increased due to an increase in product costs of $20.8 million as a result of an increase of $16.4 million attributed to a different mixture of customers, products and overall growth in product sales, and an increase of $2.9 million in product installation costs. Cost of service revenues increased by $1.2 million due to an increase in salaries and wages as support headcount increased, in addition to an increase in expenses related to the refurbishment of returned materials.

[0000926326-15-000012:mdna:105]
Gross profit increased due to an increase in product and service revenues while gross margin remained consistent as cost of sales as a percentage of revenues remained consistent with the prior year.

[0000926326-15-000012:mdna:106]
Medication Adherence

[0000926326-15-000012:mdna:107]
Cost of revenues increased due to an increase in product costs of $7.6 million primarily driven by an increase in product sales and the inclusion of costs from our Surgichem operations. Consistent with the related revenues, cost of service sales remained relatively flat compared to the prior year.

[0000926326-15-000012:mdna:108]
Gross profit increased due to an increase in product revenues and the inclusion of Surgichem operations, and gross margin slightly decreased as cost of sales as a percentage of revenues slightly increased driven by higher product costs.

[0000926326-15-000012:mdna:109]
We do not anticipate any significant fluctuations in gross profit and gross margin beyond normal fluctuations caused by changes in product mix for our Automation and Analytics and Medication Adherence segments during 2015.

[0000926326-15-000012:mdna:110]
2013 compared to 2012:

[0000926326-15-000012:mdna:111]
Automation and Analytics

[0000926326-15-000012:mdna:112]
Cost of revenues increased due to an increase in product costs of $17.8 million as a result of increased revenues and unfavorable changes in product mix. Cost of service sales remained relatively flat compared to the prior year.

[0000926326-15-000012:mdna:113]
43

[0000926326-15-000012:mdna:114]
Gross profit increased due to an increase in product and service revenues while gross margin remained consistent as cost of sales as a percentage of revenues remained overall consistent with the prior year.

[0000926326-15-000012:mdna:115]
Medication Adherence

[0000926326-15-000012:mdna:116]
Cost of revenues increased due to an increase in product costs of $14.9 million and service costs of $1.2 million primarily driven by an increase in product sales and the inclusion of costs from our MTS operations.

[0000926326-15-000012:mdna:117]
Gross profit increased due to an increase in product revenues and the inclusion of MTS operations, and gross margin slightly decreased as cost of sales as a percentage of revenues slightly increased driven primarily by higher product costs.

[0000926326-15-000012:mdna:118]
Operating expenses and Income from operations

[0000926326-15-000012:mdna:119]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2014 |  | $ |  | % |  | 2013 |  | $ |  | % |  | 2012 |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 27,802 |  |  | $ | (1,303 | ) |  | (4 | )% |  | $ | 29,105 |  |  | $ | 5,379 |  |  | 23 | % |  | $ | 23,726 |  |
| As a percentage of total revenues | 6 | % |  |  |  |  |  | 8 | % |  |  |  |  |  | 8 | % |
| Selling, general and administrative | 156,475 |  |  | 17,480 |  |  | 13 | % |  | 138,995 |  |  | 19,259 |  |  | 16 | % |  | 119,736 |  |
| As a percentage of total revenues | 35 | % |  |  |  |  |  | 37 | % |  |  |  |  |  | 38 | % |
| Total operating expenses | $ | 184,277 |  |  | $ | 16,177 |  |  | 10 | % |  | $ | 168,100 |  |  | $ | 24,638 |  |  | 17 | % |  | $ | 143,462 |  |
| As a percentage of total revenues | 42 | % |  |  |  |  |  | 44 | % |  |  |  |  |  | 46 | % |
| Income from operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 47,612 |  |  | $ | 14,096 |  |  | 42 | % |  | $ | 33,516 |  |  | $ | 12,422 |  |  | 59 | % |  | $ | 21,094 |  |
| Operating margin | 13 | % |  |  |  |  |  | 11 | % |  |  |  |  |  | 8 | % |
| Medication Adherence | 1,971 |  |  | 188 |  |  | 11 | % |  | 1,783 |  |  | (4,249 | ) |  | (70 | )% |  | 6,032 |  |
| Operating margin | 2 | % |  |  |  |  |  | 2 | % |  |  |  |  |  | 11 | % |
| Total income from operations | $ | 49,583 |  |  | $ | 14,284 |  |  | 40 | % |  | $ | 35,299 |  |  | $ | 8,173 |  |  | 30 | % |  | $ | 27,126 |  |
| Total operating margin | 11 | % |  |  |  |  |  | 9 | % |  |  |  |  |  | 9 | % |

[0000926326-15-000012:mdna:120]
2014 compared to 2013:

[0000926326-15-000012:mdna:121]
Research and development expenses decreased in our Automation and Analytics and Medication Adherence segments, primarily due to an increase of $3.2 million in the capitalization of software development costs in 2014 compared to 2013, partially offset by increased expenses of $2.7 million to further enhance our Pharmacy and Supply automation products. In our Medication Adherence segment, research and development decreased primarily due to the write-off of $1.8 million of capitalized software development costs in 2013 which did not recur in 2014, partially offset by an increase of $1.0 million in expenses to bring new medication adherence products to market, such as our M5000 packaging system.

[0000926326-15-000012:mdna:122]
We expect research and development expenses to increase in 2015 as we continue to invest in new products and services, and increase as a percentage of total revenues from 6% to approximately 8%. The amount of research and development expenses can fluctuate based on the amount of prototype expenses for hardware and/or the amount of capitalized software development costs.

[0000926326-15-000012:mdna:123]
Selling, general and administrative expenses increased due to increases from our Automation and Analytics segment of $15.6 million and Medication Adherence segment of $1.9 million. The increase from our Automation and Analytics segment was attributed to increases in salaries and wages of $4.0 million due to an increase in headcount, commission expenses of $1.5 million, facilities and infrastructure costs of $1.5 million, shipping costs of $1.5 million, GPO fees of $1.5 million and bad debt expense of $1.0 million with the remainder consisting of individually insignificant administrative expenses. The increase from our Medication Adherence segment was primarily the result of $1.0 million from the inclusion of Surgichem operations, with the remainder incurred from clinical studies and an increase in headcount specifically within our marketing and international businesses.

[0000926326-15-000012:mdna:124]
We anticipate selling, general and administrative expenses as a percentage of total revenues to be stable throughout 2015, however this estimate could be impacted by ongoing business development activities and external macro-economic factors.

[0000926326-15-000012:mdna:125]
44

[0000926326-15-000012:mdna:126]
Income from our Automation and Analytics operations increased due to an increase in product and service revenues while operating margin increased as a result of lower cost of sales and operating expenses compared to the overall growth of revenues.

[0000926326-15-000012:mdna:127]
Income from our Medication Adherence operations slightly increased due to an increase in product revenues and the inclusion of Surgichem operations, and operating margin remained consistent with the prior year as product costs increased which offset the relative growth in product sales.

[0000926326-15-000012:mdna:128]
2013 compared to 2012:

[0000926326-15-000012:mdna:129]
Research and development expenses increased primarily due to an increase from our Medication Adherence segment of $4.6 million, and includes (i) a write-off of $1.8 million related to capitalized software development costs as discussed in Note 9, Other Assets, of the Notes to Consolidated Financial Statements included in this annual report; (ii) expenses of $0.3 million related to a management reorganization within our Medication Adherence segment in the first quarter of 2013; and (iii) the inclusion of MTS headcount, consulting and other related activities for a full year in 2013 as compared to the prior year. Research and development expenses attributed to our Automation and Analytics segment were relatively flat compared to the prior year.

[0000926326-15-000012:mdna:130]
Selling, general and administrative expenses increased due to an increase from our Automation and Analytics segment of $11.8 million driven by headcount-related expenses including commissions of $5.0 million, facility and depreciation expenses of $2.9 million for our new corporate headquarters and manufacturing buildings occupied in late 2012, and consulting and professional fees of $1.8 million. Selling, general and administrative expenses increased by $7.4 million from our Medication Adherence segment due to the inclusion of MTS general and administrative expenses for a full year in 2013 as compared to the prior year.

[0000926326-15-000012:mdna:131]
Income from our Automation and Analytics operations increased due to an increase in product and service revenues while operating margin increased as a result of lower cost of sales and operating expenses compared to the overall growth of revenues.

[0000926326-15-000012:mdna:132]
Income from our Medication Adherence operations decreased due to higher product costs and operating expenses as evidenced by the overall decline in operating margin, which was primarily due to the inclusion of MTS operations.

[0000926326-15-000012:mdna:133]
Provision for income taxes

[0000926326-15-000012:mdna:134]
|  |  |  | Change in |  |  |  | Change in |  |  |
|  | 2014 |  | $ |  | % |  | 2013 |  | $ |  | % |  | 2012 |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 17,986 |  |  | $ | 6,936 |  |  | 63 | % |  | $ | 11,050 |  |  | $ | 153 |  |  | 1 | % |  | $ | 10,897 |  |
| Effective tax rate on earnings | 37 | % |  |  |  |  |  | 32 | % |  |  |  |  |  | 40 | % |

[0000926326-15-000012:mdna:135]
Our effective tax rate was approximately 37%, 32% and 40% in 2014, 2013 and 2012, respectively.

[0000926326-15-000012:mdna:136]
2014 compared to 2013:

[0000926326-15-000012:mdna:137]
We recorded a provision for income taxes of $18.0 million and an effective tax rate of 37% for the year ended December 31, 2014, compared to $11.1 million and an effective tax rate of 32% for the year ended December 31, 2013. The 2014 annual effective tax rate differed from the statutory tax rate of 35%, primarily due to the unfavorable impact of state income taxes, non-deductible equity charges under ASC 740-718, and other non-deductible expenditures, including non-deductible acquisition costs, all of which were partially offset by the domestic production activities deduction and the federal research tax credit, which was reinstated in December 2014, retroactive to the beginning of the year. The increase in the annual effective tax rate as compared to 2013 was primarily due to non-deductible transaction costs incurred as a result of the  Surgichem acquisition, combined with the absence of the impact of the 2013 tax rate reduction in the U.K., as well as reinstatement of the federal research credit in January 2013, retroactive to 2012.

[0000926326-15-000012:mdna:138]
2013 compared to 2012:

[0000926326-15-000012:mdna:139]
We recorded a provision for income taxes of approximately $11.1 million and an effective tax rate of 32% for the year ended December 31, 2013, compared to $10.9 million and an effective tax rate of 40% for the year ended December 31, 2012. The 2013 annual effective tax rate differed from the statutory tax rate of 35% primarily due to the favorable impact of Section 199 domestic production activity deduction, as well as the reinstatement of the federal research credit in January 2013, retroactive to 2012, which included two years of federal research credits within the 2013 results. The decrease in the annual effective tax rate as compared to 2012 was primarily due to the aforementioned reinstatement of the federal research and

[0000926326-15-000012:mdna:140]
development credit, a favorable mix in our domestic sales which decreased state apportionment factors in certain states, and the absence of non-deductible transaction costs in 2013 that were incurred in 2012 as a result of the MTS acquisition.

[0000926326-15-000012:mdna:141]
Refer to Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this annual report for further discussion about the factors affecting our ability to realize deferred tax assets.

[0000926326-15-000012:mdna:142]
LIQUIDITY AND CAPITAL RESOURCES

[0000926326-15-000012:mdna:143]
Sources of Cash

[0000926326-15-000012:mdna:144]
We entered into a Credit Agreement with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time which provides for a $75 million revolving credit facility to be used for general corporate purposes, including future acquisitions. The Credit Agreement permits us to request one or more increases in the aggregate commitment provided such increases do not exceed $25 million in the aggregate.

[0000926326-15-000012:mdna:145]
On November 5, 2014, we entered into Amendment Number One (the “Amendment”) to the Credit Agreement. The Amendment increases the amount of our common stock that may be repurchased by us in open market transactions authorized by our Board of Directors, together with any repurchases of our common stock from any consultants, employees, officers or directors of the Company or any of our subsidiaries following the death, disability, retirement or termination of employment of such employees, officers or directors, from $25 million to $50 million per year. The Credit Agreement contains customary affirmative and negative covenants, and financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each quarter. For additional details, please refer to Note 18, Credit Agreement, of the Notes to Consolidated Financial Statements included in this annual report.

[0000926326-15-000012:mdna:146]
As of December 31, 2014, we were in full compliance with all covenants, and there was no outstanding balance on the credit facility.

[0000926326-15-000012:mdna:147]
Uses of Cash

[0000926326-15-000012:mdna:148]
Our future uses of cash are expected to be primarily for working capital, capital expenditures and other contractual obligations. We also expect a continued use of cash for potential acquisition and acquisition assessment activities.

[0000926326-15-000012:mdna:149]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of December 31, 2014, which may result in additional use of cash. See Note 15, Stock Repurchases, of the Notes to Consolidated Financial Statements included in this annual report. We had cash and cash equivalents of $125.9 million and $104.5 million as of December 31, 2014 and December 31, 2013, respectively.

[0000926326-15-000012:mdna:150]
Based on our current business plan and revenue backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under our $75 million Credit Agreement, will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-15-000012:mdna:151]
Cash Flows

[0000926326-15-000012:mdna:152]
The following table summarizes, for the periods indicated, selected items in our Consolidated Statements of Cash Flows:

[0000926326-15-000012:mdna:153]
|  | Year Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2012 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 65,163 |  |  | $ | 55,263 |  |  | $ | 39,484 |  |
| Investing activities | (43,325 | ) |  | (20,452 | ) |  | (168,711 | ) |
| Financing activities | (206 | ) |  | 7,374 |  |  | (232 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (275 | ) |  | 33 |  |  | 10 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 21,357 |  |  | $ | 42,218 |  |  | $ | (129,449 | ) |

[0000926326-15-000012:mdna:154]
46

[0000926326-15-000012:mdna:155]
Operating activities

[0000926326-15-000012:mdna:156]
We expect cash from our operating activities to fluctuate in future periods as a result of a number of factors, including the timing of our billings and collections, our operating results and the timing of other liability payments.

[0000926326-15-000012:mdna:157]
Net cash provided by operating activities was $65.2 million for 2014, primarily as a result of $30.5 million in net income adjusted for non-cash items, including depreciation and amortization expense of $20.3 million and share-based compensation expense of $12.8 million, an increase in deferred gross profit of $8.6 million, an increase in accrued liabilities of $5.5 million and an increase in deferred service revenue of $5.1 million. These amounts were partially offset by an increase in accounts receivable, net of $22.8 million.

[0000926326-15-000012:mdna:158]
Net cash provided by operating activities was $55.3 million for 2013, primarily as a result of $24.0 million in net income adjusted for non-cash items, including depreciation and amortization expense of $18.4 million and share-based compensation expense of $11.2 million.

[0000926326-15-000012:mdna:159]
Net cash provided by operating activities was $39.5 million for 2012, primarily as a result of $16.2 million in net income adjusted for non-cash items, including depreciation and amortization expense of $13.3 million and share-based compensation expense of $9.2 million.

[0000926326-15-000012:mdna:160]
Investing activities

[0000926326-15-000012:mdna:161]
Net cash used in investing activities was $43.3 million for 2014, primarily due to payments of $20.7 million for the acquisition of Surgichem, $11.9 million for property and equipment and $10.4 million to develop software for external use.

[0000926326-15-000012:mdna:162]
Net cash used in investing activities was $20.5 million for 2013 and was due to payments of $12.3 million for property and equipment and $7.8 million to develop software for external use.

[0000926326-15-000012:mdna:163]
Net cash used in investing activities was $168.7 million for 2012 and was primarily due to payments of $156.3 million for the acquisition of MTS Medication Technologies, Inc. and $15.1 million for property and equipment.

[0000926326-15-000012:mdna:164]
Financing activities

[0000926326-15-000012:mdna:165]
Net cash used in financing activities was $0.2 million for 2014 as a result of $24.1 million in repurchases of our common stock, partially offset by $21.8 million in net proceeds from sales of common stock through employee stock plans.

[0000926326-15-000012:mdna:166]
Net cash provided by financing activities was $7.4 million for 2013 as a result of $26.9 million in net proceeds from sales of common stock through employee stock plans, partially offset by $21.0 million in repurchases of our common stock.

[0000926326-15-000012:mdna:167]
Net cash used in financing activities was $0.2 million for 2012 as a result of $12.4 million in repurchases of our common stock, partially offset by $10.2 million in net proceeds from sales of common stock through employee stock plans.

[0000926326-15-000012:mdna:168]
Contractual Obligations

[0000926326-15-000012:mdna:169]
We had $48.0 million in contractual commitments to third parties for non-cancelable operating leases, commitments to contract manufacturers and suppliers and other purchase commitments as of December 31, 2014 as follows:

[0000926326-15-000012:mdna:170]
|  | Payments Due by Period |
|  | Total |  | 2015 |  | 2016 and 2017 |  | 2018 and 2019 |  | 2020 and Thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 38,638 |  |  | $ | 5,637 |  |  | $ | 10,463 |  |  | $ | 9,547 |  |  | $ | 12,991 |  |
| Purchase obligations (2) | 9,325 |  |  | 9,325 |  |  | — |  |  | — |  |  | — |  |
| Total (3) | $ | 47,963 |  |  | $ | 14,962 |  |  | $ | 10,463 |  |  | $ | 9,547 |  |  | $ | 12,991 |  |

[0000926326-15-000012:mdna:171]
_________________________________________________

[0000926326-15-000012:mdna:172]
| (1) | Commitments under operating leases relate primarily to leasehold property and office equipment. Rent expense was $6.8 million, $6.9 million and $5.7 million for the years ended December 31, 2014, December 31, 2013 and December 31, 2012, respectively. |

[0000926326-15-000012:mdna:173]
| (2) | We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are |

[0000926326-15-000012:mdna:174]
47

[0000926326-15-000012:mdna:175]
enforceable and legally binding. The amounts under such contracts are included in the table above because we believe that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials.

[0000926326-15-000012:mdna:176]
| (3) | We have recorded $5.9 million for uncertain tax positions under long-term liabilities as of December 31, 2014 in accordance with the authoritative guidance summarized in the section entitled "Critical Accounting Policies and Estimates" above. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, $5.9 million in uncertain tax position liabilities have not been included in the table above. See Note 14, Income Taxes, of the Notes to Consolidated Financial Statements included in this annual report. |

[0000926326-15-000012:mdna:177]
See Note 12, Commitments, of the Notes to Consolidated Financial Statements included in this annual report.

[0000926326-15-000012:mdna:178]
Off-Balance Sheet Arrangements

[0000926326-15-000012:mdna:179]
As of December 31, 2014, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
