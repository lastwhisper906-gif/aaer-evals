# OMCL 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: no heading matched.


## item_9a

[0000926326-15-000012:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0000926326-15-000012:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000926326-15-000012:item_9a:3]
Our management, with the participation of our principal executive officer and principal financial officer, evaluated the effectiveness of our disclosure controls and procedures (as such term is defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended, or the Exchange Act) as of the end of the period covered by this annual report. These disclosure controls and procedures are designed to ensure that the information required to be disclosed by us in this annual report was (i) recorded, processed, summarized and reported within the time periods specified in the SEC's rules and regulations and (ii) accumulated and communicated to our management, including our principal executive officer and principal financial officer, to allow timely decisions regarding required disclosure.

[0000926326-15-000012:item_9a:4]
Based on such evaluation, our principal executive officer and principal financial officer have concluded that our disclosure controls and procedures were effective at the reasonable assurance level as of December 31, 2014.

[0000926326-15-000012:item_9a:5]
Management's Report on Internal Control Over Financial Reporting

[0000926326-15-000012:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act). Our internal control system is designed to provide reasonable assurance regarding the preparation and fair presentation of financial statements for external purposes in accordance with U.S. generally accepted accounting principles. All internal control systems, no matter how well designed, have inherent limitations and can provide only reasonable assurance that the objectives of the internal control system are met.

[0000926326-15-000012:item_9a:7]
Under the supervision and with the participation of our management, including our principal executive officer and principal financial officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting as of December 31, 2014 using the criteria for effective internal control over financial reporting as described in "Internal Control—Integrated Framework," issued by the Committee of Sponsoring Organization of the Treadway Commission (2013 framework) (the COSO Criteria). Based on this assessment, management concluded that our internal control over financial reporting was effective as of December 31, 2014.

[0000926326-15-000012:item_9a:8]
Our independent registered public accounting firm, Deloitte & Touche LLP, has issued its attestation report on our internal control over financial reporting as of December 31, 2014, which is included in Part IV, Item 15 of this annual report.

[0000926326-15-000012:item_9a:9]
Changes in Internal Control Over Financial Reporting

[0000926326-15-000012:item_9a:10]
There have been no changes in our internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting during the year ended December 31, 2014.
