# OMCL 8-K — 0000926326-14-000037 filed 2014-10-30

## item codes, every 8-K on or before 2015-03-30

- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2015-03-30

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-14-000037:8k_2_02:1]
EX-99.1
2
exhibit991q314.htm
EXHIBIT

[0000926326-14-000037:8k_2_02:2]
Exhibit991Q314

[0000926326-14-000037:8k_2_02:3]
Exhibit 99.1

[0000926326-14-000037:8k_2_02:4]
| Contact: |  |  |
| Rob Seim |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6478 |  | Mountain View, CA 94043 |
| rob.seim@omnicell.com |  |  |

[0000926326-14-000037:8k_2_02:5]
Omnicell Announces Third Quarter 2014 Results

[0000926326-14-000037:8k_2_02:6]
MOUNTAIN VIEW, Calif. — October 30, 2014— Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its third quarter ended September 30, 2014.

[0000926326-14-000037:8k_2_02:7]
GAAP results: Revenue for the third quarter of 2014 was $112.5 million, up $7.5 million or 7.1% from the second quarter of 2014, and up $18.5 million or 19.7% from the third quarter of 2013. Revenue for the nine months ended September 30, 2014 was $319.4 million, up $44.5 million or 16.2% from the nine months ended September 30, 2013.

[0000926326-14-000037:8k_2_02:8]
GAAP net income for the third quarter of 2014 was $7.3 million, or $0.20 per diluted share. This compares to GAAP net income of $7.8 million, or $0.21 per diluted share, for the second quarter of 2014, and GAAP net income of $7.8 million, or $0.21 per diluted share, for the third quarter of 2013.

[0000926326-14-000037:8k_2_02:9]
GAAP net income for the nine months ended September 30, 2014 was $21.3 million, or $0.58 per diluted share. This compares to GAAP net income of $17.2 million, or $0.48 per diluted share, for the nine months ended September 30, 2013.

[0000926326-14-000037:8k_2_02:10]
Non-GAAP results: Non-GAAP net income for the third quarter of 2014 was $11.1 million, or $0.30 per diluted share, excluding $3.2 million of stock-based compensation expense and $1.1 million ($0.6 million net of $0.5 million tax effect) of amortization expense for all intangible assets associated with our business acquisitions. This compares to non-GAAP net income of $11.3 million, or $0.31 per diluted share, for the third quarter of 2013. Non-GAAP net income for the third quarter of 2013 excluded $2.8 million of stock-based compensation expense and $1.1 million ($0.8 million net of $0.3 million tax effect) of amortization expense for all intangible assets associated with our business acquisitions. Third quarter 2014 results compare to non-GAAP net income of $11.2 million, or $0.30 per diluted share, for the second quarter of 2014. Non-GAAP net income for the second quarter of 2014 excludes $2.7 million of stock-based compensation expense and $1.0 million ($0.6 million net of $0.4 million tax effect) of amortization expense for all intangible assets associated with our business acquisitions.

[0000926326-14-000037:8k_2_02:11]
Non-GAAP net income for the nine months ended September 30, 2014 was $31.9 million, or $0.87 per diluted share, excluding $8.6 million of stock-based compensation expense and $3.2 million ($2.0 million net of $1.2 million tax effect) of amortization expense for all intangible assets associated with our business acquisitions. This compares to non-GAAP net income of $28.1 million, or $0.79 per diluted share, for the nine months ended September 30, 2013. Non-GAAP net income for the nine months ended September 30, 2013 excluded $8.4 million of stock-based compensation expense, $3.2 million ($2.1 million net of $1.1 million tax effect) of amortization expense for all intangible assets associated with our business acquisitions, and $0.7 million ($0.4 million net of the $0.3 million tax effect) of non-recurring reorganization costs related to our Medication Adherence segment.

[0000926326-14-000037:8k_2_02:12]
“Omnicell completed another strong quarter marked by record revenues, completion of our acquisition of UK medication adherence packaging leader Surgichem, and continued momentum in winning new customers, such as the 1100-bed, three-hospital Wake Forest Baptist Medical Center,” said Randall Lipps, Omnicell President, Chairman and CEO.

[0000926326-14-000037:8k_2_02:13]
“Along with quarterly revenues up 20% over last year, I am pleased to report that we remain on track for our 2014 profit and growth projections,” Mr. Lipps added.

[0000926326-14-000037:8k_2_02:14]
Omnicell Conference Call Information

[0000926326-14-000037:8k_2_02:15]
Omnicell will hold a conference call today, Thursday, October 30, 2014 at 1:30 p.m. PT to discuss third quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 22016852. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on November 30, 2014. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 22016852.

[0000926326-14-000037:8k_2_02:16]
About Omnicell

[0000926326-14-000037:8k_2_02:17]
Since 1992, Omnicell (NASDAQ: OMCL) has been creating new efficiencies to improve patient care, anywhere it is delivered. Omnicell is a leading supplier of comprehensive automation and business analytics software for patient-centric medication and supply management across the entire health care continuum-from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home.

[0000926326-14-000037:8k_2_02:18]
More than 3,000 customers worldwide have utilized Omnicell Automation and Analytics solutions to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety. Omnicell Medication Adherence solutions, including its MTS Medication Technologies brand, provide innovative medication adherence packaging solutions to help reduce costly hospital readmissions. In addition, these solutions enable approximately 6,000 institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-14-000037:8k_2_02:19]
For more information about Omnicell, please visit www.omnicell.com.

[0000926326-14-000037:8k_2_02:20]
Forward-Looking Statements

[0000926326-14-000037:8k_2_02:21]
Use of Non-GAAP Financial Information

[0000926326-14-000037:8k_2_02:22]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-14-000037:8k_2_02:23]
Our non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-14-000037:8k_2_02:24]
a)  Stock-based compensation expense impact of Accounting Standards Codification (ASC) 718. We recognize equity plan-related compensation expenses, which represent the fair value of all share-based payments to employees, including grants of employee stock options, as required under ASC 718, “Stock Compensation” as non-GAAP adjustments in each period.

[0000926326-14-000037:8k_2_02:25]
b)  Reorganization costs. During the nine months ended September 30, 2013, we recorded $0.7 million ($0.4 million net of $0.3 million tax effect) of reorganization costs related to our Medication Adherence segment. This charge is not expected to be recurring and, as such, the financial impact is excluded from our non-GAAP results.

[0000926326-14-000037:8k_2_02:26]
c)  Intangible assets amortization from business acquisitions. We excluded from our non-GAAP results the amortization expense of certain intangible assets associated with our business acquisitions. This impacts third quarter 2014 non-GAAP results by $1.1 million ($0.6 million  net of $0.5 million tax effect), second quarter 2014 non-GAAP results by $1.0 million ($0.6 million  net of $0.4 million tax effect), and third quarter 2013 non-GAAP results by $1.1 million ($0.8 million net of $0.3 million tax effect). These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-14-000037:8k_2_02:27]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing are largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock option grants.

[0000926326-14-000037:8k_2_02:28]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-14-000037:8k_2_02:29]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0000926326-14-000037:8k_2_02:30]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0000926326-14-000037:8k_2_02:31]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0000926326-14-000037:8k_2_02:32]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-14-000037:8k_2_02:33]
Set forth below are additional reasons why share-based compensation expense related to ASC 718 is excluded from our non-GAAP financial measures:

[0000926326-14-000037:8k_2_02:34]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results; and

[0000926326-14-000037:8k_2_02:35]
ii)  We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-14-000037:8k_2_02:36]
We define adjusted EBITDA as GAAP net income excluding: (i) ASC 718 stock compensation expense; (ii) interest (income) and  expense, net; (iii) depreciation and amortization; (iv) provision for income taxes; and (v) other unusual and non-recurring costs and expenses.

[0000926326-14-000037:8k_2_02:37]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-14-000037:8k_2_02:38]
• Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718; and

[0000926326-14-000037:8k_2_02:39]
• Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-14-000037:8k_2_02:40]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-14-000037:8k_2_02:41]
Omnicell, Inc.

[0000926326-14-000037:8k_2_02:42]
Condensed Consolidated Statements of Operations

[0000926326-14-000037:8k_2_02:43]
(Unaudited, in thousands, except per share data)

[0000926326-14-000037:8k_2_02:44]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 30, 2014 |  | June 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Revenues: |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 92,229 |  |  | $ | 85,244 |  |  | $ | 75,508 |  |  | $ | 260,053 |  |  | $ | 220,325 |  |
| Services and other revenues |  | 20,314 |  |  | 19,808 |  |  | 18,531 |  |  | 59,306 |  |  | 54,510 |  |
| Total revenue |  | 112,543 |  |  | 105,052 |  |  | 94,039 |  |  | 319,359 |  |  | 274,835 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues |  | 44,510 |  |  | 41,003 |  |  | 33,977 |  |  | 124,413 |  |  | 103,810 |  |
| Cost of services and other revenues |  | 8,487 |  |  | 8,009 |  |  | 8,022 |  |  | 24,865 |  |  | 24,250 |  |
| Total cost of revenues |  | 52,997 |  |  | 49,012 |  |  | 41,999 |  |  | 149,278 |  |  | 128,060 |  |
| Gross profit |  | 59,546 |  |  | 56,040 |  |  | 52,040 |  |  | 170,081 |  |  | 146,775 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 7,078 |  |  | 6,471 |  |  | 6,561 |  |  | 19,670 |  |  | 21,665 |  |
| Selling, general and administrative |  | 38,871 |  |  | 37,011 |  |  | 34,762 |  |  | 114,302 |  |  | 100,866 |  |
| Total operating expenses |  | 45,949 |  |  | 43,482 |  |  | 41,323 |  |  | 133,972 |  |  | 122,531 |  |
| Income from operations |  | 13,597 |  |  | 12,558 |  |  | 10,717 |  |  | 36,109 |  |  | 24,244 |  |
| Interest and other income (expense), net |  | (706 | ) |  | (40 | ) |  | 25 |  |  | (1,003 | ) |  | (134 | ) |
| Income before provision for income taxes |  | 12,891 |  |  | 12,518 |  |  | 10,742 |  |  | 35,106 |  |  | 24,110 |  |
| Provision for income taxes |  | 5,591 |  |  | 4,729 |  |  | 2,987 |  |  | 13,824 |  |  | 6,954 |  |
| Net income |  | $ | 7,300 |  |  | $ | 7,789 |  |  | $ | 7,755 |  |  | $ | 21,282 |  |  | $ | 17,156 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.20 |  |  | $ | 0.22 |  |  | $ | 0.22 |  |  | $ | 0.60 |  |  | $ | 0.50 |  |
| Diluted |  | $ | 0.20 |  |  | $ | 0.21 |  |  | $ | 0.21 |  |  | $ | 0.58 |  |  | $ | 0.48 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 35,994 |  |  | 35,661 |  |  | 35,133 |  |  | 35,634 |  |  | 34,499 |  |
| Diluted |  | 36,832 |  |  | 36,618 |  |  | 36,190 |  |  | 36,617 |  |  | 35,466 |  |

[0000926326-14-000037:8k_2_02:45]
Omnicell, Inc.

[0000926326-14-000037:8k_2_02:46]
Condensed Consolidated Balance Sheets

[0000926326-14-000037:8k_2_02:47]
(Unaudited, in thousands)

[0000926326-14-000037:8k_2_02:48]
|  |  | September 30, 2014 |  | December 31, 2013 |  |
| ASSETS |  |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 104,187 |  |  | $ | 104,531 |  |  |
| Accounts receivable, net |  | 95,167 |  |  | 58,597 |  |  |
| Inventories |  | 31,847 |  |  | 31,457 |  |  |
| Prepaid expenses |  | 18,221 |  |  | 18,883 |  |  |
| Deferred tax assets |  | 12,684 |  |  | 12,635 |  |  |
| Other current assets |  | 6,262 |  |  | 7,675 |  |  |
| Total current assets |  | 268,368 |  |  | 233,778 |  |  |
| Property and equipment, net |  | 37,688 |  |  | 35,254 |  |  |
| Non-current net investment in sales-type leases |  | 10,823 |  |  | 11,485 |  |  |
| Goodwill |  | 123,090 |  |  | 111,343 |  |  |
| Intangible assets, net |  | 84,075 |  |  | 81,602 |  |  |
| Non-current deferred tax assets |  | 975 |  |  | 1,102 |  |  |
| Other assets |  | 22,294 |  |  | 17,937 |  |  |
| Total assets |  | $ | 547,313 |  |  | $ | 492,501 |  |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 23,202 |  |  | $ | 16,471 |  |  |
| Accrued compensation |  | 13,071 |  |  | 19,604 |  |  |
| Accrued liabilities |  | 17,073 |  |  | 13,746 |  |  |
| Deferred service revenue |  | 22,672 |  |  | 22,626 |  |  |
| Deferred gross profit |  | 35,542 |  |  | 19,957 |  |  |
| Total current liabilities |  | 111,560 |  |  | 92,404 |  |  |
| Non-current deferred service revenue |  | 20,368 |  |  | 17,763 |  |  |
| Non-current deferred tax liabilities |  | 30,471 |  |  | 28,162 |  |  |
| Other long-term liabilities |  | 6,013 |  |  | 5,175 |  |  |
| Total liabilities |  | 168,412 |  |  | 143,504 |  |  |
| Commitments and Contingencies (Note 10 and Note 11) |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |
| Total stockholders’ equity |  | 378,901 |  |  | 348,997 |  |  |
| Total liabilities and stockholders’ equity |  | $ | 547,313 |  |  | $ | 492,501 |  |  |

[0000926326-14-000037:8k_2_02:49]
Omnicell, Inc.

[0000926326-14-000037:8k_2_02:50]
Reconciliation of GAAP to Non-GAAP

[0000926326-14-000037:8k_2_02:51]
(Unaudited, in thousands, except per share data)

[0000926326-14-000037:8k_2_02:52]
|  |  | Three Months Ended |
|  |  | September 30, 2014 |  | June 30, 2014 |  | September 30, 2013 |
|  |  | Net Income |  | Net Income per Share-Diluted |  | Net Income |  | Net Income per Share-Diluted |  | Net Income |  | Net Income per Share-Diluted |
| GAAP |  | $ | 7,300 |  |  | $ | 0.20 |  |  | $ | 7,789 |  |  | $ | 0.21 |  |  | $ | 7,755 |  |  | $ | 0.21 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets acquired by acquisition |  | 1,146 |  |  |  |  | 1,048 |  |  |  |  | 1,060 |  |  |  |
| Subtotal pretax adjustments |  | 1,146 |  |  |  |  | 1,048 |  |  |  |  | 1,060 |  |  |  |
| Income tax effect of non-GAAP adjustments (a) |  | (497 | ) |  |  |  | (395 | ) |  |  |  | (295 | ) |  |  |
| Subtotal after-tax adjustments |  | 649 |  |  |  |  | 653 |  |  |  |  | 765 |  |  |  |
| ASC 718 share-based compensation adjustment (b): |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 441 |  |  |  |  | 264 |  |  |  |  | 325 |  |  |  |
| Operating expenses |  | 2,720 |  |  |  |  | 2,456 |  |  |  |  | 2,485 |  |  |  |
| Subtotal ASC 718 share-based compensation adjustments |  | 3,161 |  |  |  |  | 2,720 |  |  |  |  | 2,810 |  |  |  |
| Total non-GAAP adjustments |  | 3,810 |  |  | 0.10 |  |  | 3,373 |  |  | 0.09 |  |  | 3,575 |  |  | 0.10 |  |
| Non-GAAP |  | $ | 11,110 |  |  | $ | 0.30 |  |  | $ | 11,162 |  |  | $ | 0.30 |  |  | $ | 11,330 |  |  | $ | 0.31 |  |

[0000926326-14-000037:8k_2_02:53]
____________________________________________

[0000926326-14-000037:8k_2_02:54]
(a) Tax effect amounts are calculated using the effective tax rates for the respective periods presented.

[0000926326-14-000037:8k_2_02:55]
(b) This adjustment reflects the accounting impact of non-cash stock-based compensation expense for the periods shown.

[0000926326-14-000037:8k_2_02:56]
Omnicell, Inc.

[0000926326-14-000037:8k_2_02:57]
Reconciliation of GAAP to Non-GAAP

[0000926326-14-000037:8k_2_02:58]
(Unaudited, in thousands, except per share data)

[0000926326-14-000037:8k_2_02:59]
|  |  | Nine Months Ended |
|  |  | September 30, 2014 |  | September 30, 2013 |
|  |  | Net Income |  | Net Income per Share-Diluted |  | Net Income |  | Net Income per Share-Diluted |
| GAAP |  | $ | 21,282 |  |  | $ | 0.58 |  |  | $ | 17,156 |  |  | $ | 0.48 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |
| Reorganization costs (a) |  | — |  |  |  |  | 732 |  |  |  |
| Amortization of intangible assets acquired by acquisition |  | 3,241 |  |  |  |  | 3,180 |  |  |  |
| Subtotal pretax adjustments |  | 3,241 |  |  |  |  | 3,912 |  |  |  |
| Income tax effect of non-GAAP adjustments (b) |  | (1,270 | ) |  |  |  | (1,395 | ) |  |  |
| Subtotal after-tax adjustments |  | 1,971 |  |  |  |  | 2,517 |  |  |  |
| ASC 718 share-based compensation adjustment (c): |  |  |  |  |  |  |  |  |
| Gross profit |  | 973 |  |  |  |  | 954 |  |  |  |
| Operating expenses |  | 7,637 |  |  |  |  | 7,469 |  |  |  |
| Subtotal 718 share-based compensation adjustment (c) |  | 8,610 |  |  |  |  | 8,423 |  |  |  |
| Total non-GAAP adjustments |  | 10,581 |  |  | 0.29 |  |  | 10,940 |  |  | 0.31 |  |
| Non-GAAP |  | $ | 31,863 |  |  | $ | 0.87 |  |  | $ | 28,096 |  |  | $ | 0.79 |  |

[0000926326-14-000037:8k_2_02:60]
____________________________________________

[0000926326-14-000037:8k_2_02:61]
(a)  Non-recurring reorganization costs related to our Medication Adherence segment.

[0000926326-14-000037:8k_2_02:62]
(b) Tax effect amounts are calculated using the effective tax rates for the respective periods presented.

[0000926326-14-000037:8k_2_02:63]
(c) This adjustment reflects the accounting impact of non-cash stock-based compensation expense for the periods shown.

[0000926326-14-000037:8k_2_02:64]
Omnicell, Inc.

[0000926326-14-000037:8k_2_02:65]
Calculation of Adjusted EBITDA (1)

[0000926326-14-000037:8k_2_02:66]
(Unaudited, in thousands)

[0000926326-14-000037:8k_2_02:67]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 30, 2014 |  | June 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| GAAP net income |  | $ | 7,300 |  |  | $ | 7,789 |  |  | $ | 7,755 |  |  | $ | 21,282 |  |  | $ | 17,156 |  |
| Add back: |  |  |  |  |  |  |  |  |  |  |
| ASC 718 stock compensation expense |  | 3,161 |  |  | 2,720 |  |  | 2,810 |  |  | 8,610 |  |  | 8,423 |  |
| Reorganization costs |  | — |  |  | — |  |  | — |  |  | — |  |  | 732 |  |
| Interest (income) and expense, net |  | 55 |  |  | (32 | ) |  | (14 | ) |  | 21 |  |  | 85 |  |
| Depreciation and amortization expense |  | 5,314 |  |  | 4,779 |  |  | 4,488 |  |  | 14,705 |  |  | 13,732 |  |
| Income tax expense |  | 5,591 |  |  | 4,729 |  |  | 2,987 |  |  | 13,824 |  |  | 6,954 |  |
| Non-GAAP adjusted EBITDA (1) |  | $ | 21,421 |  |  | $ | 19,985 |  |  | $ | 18,026 |  |  | $ | 58,442 |  |  | $ | 47,082 |  |

[0000926326-14-000037:8k_2_02:68]
____________________________________________

[0000926326-14-000037:8k_2_02:69]
| (1) | Defined as GAAP net income excluding: (i) ASC 718 stock compensation expense, (ii) unusual and non-recurring costs and expenses, (iii) interest (income) and expense, net, (iv) depreciation and amortization, and (v) provision for income taxes. |
