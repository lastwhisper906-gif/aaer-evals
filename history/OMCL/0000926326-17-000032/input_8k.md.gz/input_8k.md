# OMCL 8-K — 0000926326-17-000026 filed 2017-07-27

## item codes, every 8-K on or before 2017-08-04

- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2017-08-04

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-17-000026:8k_2_02:1]
EX-99.1
2
exhibit991q217.htm
EXHIBIT 99.1

[0000926326-17-000026:8k_2_02:2]
Exhibit

[0000926326-17-000026:8k_2_02:3]
Exhibit 99.1

[0000926326-17-000026:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6180 |  | Mountain View, CA 94043 |
| Peter.kuipers@omnicell.com |  |  |

[0000926326-17-000026:8k_2_02:5]
Omnicell Achieves Record Revenue in the Second Quarter 2017

[0000926326-17-000026:8k_2_02:6]
GAAP revenue of $180.9 million and GAAP net income per diluted share of $0.02

[0000926326-17-000026:8k_2_02:7]
Non-GAAP revenue of $181.2 million and non-GAAP net income per diluted share of $0.31

[0000926326-17-000026:8k_2_02:8]
MOUNTAIN VIEW, Calif. -- July 27, 2017 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its second quarter ended June 30, 2017.

[0000926326-17-000026:8k_2_02:9]
GAAP results: Revenue for the second quarter of 2017 was $180.9 million, up $30.3 million, or 20.1% from the first quarter of 2017, and up $8.0 million, or 4.6% from the second quarter of 2016. Revenue for the six months ended June 30, 2017 was $331.4 million, down $12.5 million, or 3.63% from the six months ended June 30, 2016.

[0000926326-17-000026:8k_2_02:10]
Second quarter 2017 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $0.8 million, or $0.02 per diluted share. This compares to GAAP net loss of $10.8 million, or $0.29 per diluted share, for the first quarter of 2017, and GAAP net loss of $1.2 million, or $0.03 per diluted share, for the second quarter of 2016.

[0000926326-17-000026:8k_2_02:11]
GAAP net loss for the six months ended June 30, 2017 was $9.9 million, or $0.27 per diluted share. GAAP net loss was $1.5 million, or $0.04 per diluted share, for the six months ended June 30, 2016.

[0000926326-17-000026:8k_2_02:12]
Non-GAAP results: Non-GAAP revenue for the second quarter of 2017 was $181.2 million, up $30.3 million, or 20.1% from the first quarter of 2017, and up $5.6 million, or 3.2% from the second quarter of 2016. Non-GAAP revenue for the six months ended June 30, 2017 was $332.1 million, down $17.2 million, or 4.9% from the six months ended June 30, 2016.

[0000926326-17-000026:8k_2_02:13]
Non-GAAP net income for the second quarter of 2017 was $11.7 million, or $0.31 per diluted share. This compares to non-GAAP net income of $2.1 million, or $0.06 per diluted share, first quarter of 2017 and $13.9 million, or $0.38 per diluted share, for the second quarter of 2016.

[0000926326-17-000026:8k_2_02:14]
Non-GAAP net income for the six months ended June 30, 2017 was $13.8 million, or $0.36 per diluted share. This compares to non-GAAP net income of $26.7 million, or $0.73 per diluted share for the six months ended June 30, 2016.

[0000926326-17-000026:8k_2_02:15]
Non-GAAP net income for each period presented excludes, when applicable, the effect of stock-based compensation expense, amortization expense of acquired intangible assets, acquisition related expenses, fair value adjustments related to business acquisitions, severance and integration-related expenses, and amortization of debt issuance cost.

[0000926326-17-000026:8k_2_02:16]
“Omnicell completed a strong second quarter marked by record revenues and earnings results ahead of expectations,” said Randall Lipps, Omnicell president, CEO and chairman. “We are proud of the company’s financial performance and our strategic execution aimed at supporting health systems in achieving their patient safety, operational and financial goals."

[0000926326-17-000026:8k_2_02:17]
1

[0000926326-17-000026:8k_2_02:18]
“I am particularly pleased by the momentum and broad adoption of our recent innovations, including the XT series,” he added. “I believe we are positioned well for continued success in the future."

[0000926326-17-000026:8k_2_02:19]
2017 Guidance:

[0000926326-17-000026:8k_2_02:20]
For the third quarter of 2017, the Company expects both GAAP and non-GAAP revenue to be between $188 million and $194 million, and non-GAAP earnings to be between $0.38 and $0.45 per share.

[0000926326-17-000026:8k_2_02:21]
For the year 2017, the Company expects product bookings to be between $570 million and $590 million. The Company expects both GAAP and non-GAAP revenue to be between $720 million and $740 million, and non-GAAP earnings to be between $1.22 and $1.34 per share.

[0000926326-17-000026:8k_2_02:22]
Omnicell Conference Call Information

[0000926326-17-000026:8k_2_02:23]
Omnicell will hold a conference call today, Thursday, July 27, 2017 at 1:30 p.m. PT to discuss second quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 36566159. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on August 25, 2017. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 36566159.

[0000926326-17-000026:8k_2_02:24]
About Omnicell

[0000926326-17-000026:8k_2_02:25]
Since 1992, Omnicell (NASDAQ: OMCL) has been inspired to create safer and more efficient ways to manage medications and supplies across all care settings. As a leader in medication and supply dispensing automation, central pharmacy automation, IV robotics, analytics software, and medication adherence and packaging systems, Omnicell is focused on improving care across the entire healthcare continuum-from the acute care hospital setting, to post-acute skilled nursing and long-term care facilities, to the patient’s home.

[0000926326-17-000026:8k_2_02:26]
Over 4,000 customers worldwide use Omnicell® automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence and improve patient safety.

[0000926326-17-000026:8k_2_02:27]
Omnicell’s innovative medication adherence solutions, used by over 32,000 institutional and retail pharmacies in North America and the United Kingdom, are designed to improve patient adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-17-000026:8k_2_02:28]
Recent Omnicell acquisitions, including Ateb, add distinct capabilities, particularly in central pharmacy, IV robotics, and pharmacy software, creating the broadest medication management product portfolio in the industry.

[0000926326-17-000026:8k_2_02:29]
For more information about Omnicell, Inc. please visit www.omnicell.com.

[0000926326-17-000026:8k_2_02:30]
Forward-Looking Statements

[0000926326-17-000026:8k_2_02:31]
Use of Non-GAAP Financial Information

[0000926326-17-000026:8k_2_02:32]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles. Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-17-000026:8k_2_02:33]
Our non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-17-000026:8k_2_02:34]
a)  Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-17-000026:8k_2_02:35]
b) Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-17-000026:8k_2_02:36]
c) Amortization of debt issuance cost. Debt issuance cost represents costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The cost includes underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-17-000026:8k_2_02:37]
d) Acquisition accounting impact related to deferred revenue. In connection with recent acquisitions, business combination rules require us to account for the fair values of arrangements for which acceptance has not been obtained, and post installation support has not been provided in our purchase accounting. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our

[0000926326-17-000026:8k_2_02:38]
business.

[0000926326-17-000026:8k_2_02:39]
e) Inventory fair value adjustments. In connection with acquisition of Aesynt, business combination rules require us to account for the fair values of inventory acquired in our purchase accounting. The non-GAAP adjustment to the cost of revenues is intended to include the impact of such adjustment. We believe the adjustment is useful as a measure of the ongoing performance of our business.

[0000926326-17-000026:8k_2_02:40]
f) Acquisition related expenses. We excluded from the non-GAAP results the expenses which are related to the recent acquisitions. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition related expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of less acquisitive peer companies.

[0000926326-17-000026:8k_2_02:41]
g) Severance and other related expenses. We excluded from our non-GAAP results the expenses which are related to the restructuring and integrations related events. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of less acquisitive peer companies.

[0000926326-17-000026:8k_2_02:42]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans.

[0000926326-17-000026:8k_2_02:43]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-17-000026:8k_2_02:44]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0000926326-17-000026:8k_2_02:45]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0000926326-17-000026:8k_2_02:46]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0000926326-17-000026:8k_2_02:47]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-17-000026:8k_2_02:48]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-17-000026:8k_2_02:49]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-17-000026:8k_2_02:50]
ii) We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-17-000026:8k_2_02:51]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as certain non-GAAP adjustments.

[0000926326-17-000026:8k_2_02:52]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-17-000026:8k_2_02:53]
| • | Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718. |

[0000926326-17-000026:8k_2_02:54]
| • | Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure. |

[0000926326-17-000026:8k_2_02:55]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-17-000026:8k_2_02:56]
With respect to the Company’s expectations under “Guidance” above, and regarding certain projections discussed on today’s teleconference, reconciliation of non-GAAP earnings ranges per share guidance for the remainder of 2017, to the closest corresponding GAAP measures is not available without unreasonable efforts as we are unable to predict with reasonable certainty the matters we would allocate to “certain items,” including unusual gains and losses, costs associated with future restructurings, acquisition-related expenses and litigation outcomes. These items are uncertain, complex, depend on various factors, have low visibility and could have a material impact on GAAP EPS in future periods.

[0000926326-17-000026:8k_2_02:57]
5

[0000926326-17-000026:8k_2_02:58]
Omnicell, Inc.

[0000926326-17-000026:8k_2_02:59]
Condensed Consolidated Statements of Operations

[0000926326-17-000026:8k_2_02:60]
(Unaudited, in thousands, except per share data)

[0000926326-17-000026:8k_2_02:61]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2017 |  | March 31, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product | $ | 128,056 |  |  | $ | 98,930 |  |  | $ | 130,674 |  |  | $ | 226,986 |  |  | $ | 258,569 |  |
| Services and other revenues | 52,829 |  |  | 51,624 |  |  | 42,233 |  |  | 104,453 |  |  | 85,342 |  |
| Total revenues | 180,885 |  |  | 150,554 |  |  | 172,907 |  |  | 331,439 |  |  | 343,911 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 81,738 |  |  | 63,588 |  |  | 76,306 |  |  | 145,326 |  |  | 148,224 |  |
| Cost of services and other revenues | 21,172 |  |  | 22,774 |  |  | 18,584 |  |  | 43,946 |  |  | 37,725 |  |
| Total cost of revenues | 102,910 |  |  | 86,362 |  |  | 94,890 |  |  | 189,272 |  |  | 185,949 |  |
| Gross profit | 77,975 |  |  | 64,192 |  |  | 78,017 |  |  | 142,167 |  |  | 157,962 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 16,911 |  |  | 16,803 |  |  | 13,794 |  |  | 33,714 |  |  | 27,632 |  |
| Selling, general and administrative | 63,468 |  |  | 64,625 |  |  | 64,341 |  |  | 128,093 |  |  | 128,596 |  |
| Total operating expenses | 80,379 |  |  | 81,428 |  |  | 78,135 |  |  | 161,807 |  |  | 156,228 |  |
| Income (loss) from operations | (2,404 | ) |  | (17,236 | ) |  | (118 | ) |  | (19,640 | ) |  | 1,734 |  |
| Interest and other income (expense), net | 196 |  |  | (2,456 | ) |  | (1,881 | ) |  | (2,260 | ) |  | (4,052 | ) |
| Loss before provision for income taxes | (2,208 | ) |  | (19,692 | ) |  | (1,999 | ) |  | (21,900 | ) |  | (2,318 | ) |
| Benefit for income taxes | (3,045 | ) |  | (8,938 | ) |  | (840 | ) |  | (11,983 | ) |  | (781 | ) |
| Net income (loss) | $ | 837 |  |  | $ | (10,754 | ) |  | $ | (1,159 | ) |  | $ | (9,917 | ) |  | $ | (1,537 | ) |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.02 |  |  | $ | (0.29 | ) |  | $ | (0.03 | ) |  | $ | (0.27 | ) |  | $ | (0.04 | ) |
| Diluted | $ | 0.02 |  |  | $ | (0.29 | ) |  | $ | (0.03 | ) |  | $ | (0.27 | ) |  | $ | (0.04 | ) |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic | 37,250 |  |  | 36,840 |  |  | 35,987 |  |  | 37,046 |  |  | 35,864 |  |
| Diluted | 38,370 |  |  | 36,840 |  |  | 35,987 |  |  | 37,046 |  |  | 35,864 |  |

[0000926326-17-000026:8k_2_02:62]
6

[0000926326-17-000026:8k_2_02:63]
Omnicell, Inc.

[0000926326-17-000026:8k_2_02:64]
Condensed Consolidated Balance Sheets

[0000926326-17-000026:8k_2_02:65]
(Unaudited, in thousands)

[0000926326-17-000026:8k_2_02:66]
|  | June 30, 2017 |  | December 31, 2016 |
| ASSETS |
| Current assets: |  |  |  |  |
| Cash and cash equivalents | $ | 26,936 |  |  | $ | 54,488 |  |
| Accounts receivable, net | 151,010 |  |  | 150,303 |  |
| Inventories | 81,523 |  |  | 69,297 |  |
| Prepaid expenses | 26,001 |  |  | 28,646 |  |
| Other current assets | 10,511 |  |  | 12,674 |  |
| Total current assets | 295,981 |  |  | 315,408 |  |
| Property and equipment, net | 40,713 |  |  | 42,011 |  |
| Long-term investment in sales-type leases, net | 17,424 |  |  | 20,585 |  |
| Goodwill | 332,996 |  |  | 327,724 |  |
| Intangible assets, net | 180,206 |  |  | 190,283 |  |
| Long-term deferred tax assets | 5,627 |  |  | 4,041 |  |
| Other long-term assets | 36,954 |  |  | 35,051 |  |
| Total assets | $ | 909,901 |  |  | $ | 935,103 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |
| Accounts payable | $ | 53,287 |  |  | $ | 27,069 |  |
| Accrued compensation | 31,251 |  |  | 26,722 |  |
| Accrued liabilities | 30,894 |  |  | 31,195 |  |
| Long-term debt, current portion, net | 10,910 |  |  | 8,410 |  |
| Deferred revenue, net | 85,370 |  |  | 87,516 |  |
| Total current liabilities | 211,712 |  |  | 180,912 |  |
| Long-term, deferred revenue | 16,332 |  |  | 17,051 |  |
| Long-term deferred tax liabilities | 38,950 |  |  | 51,592 |  |
| Other long-term liabilities | 9,879 |  |  | 8,210 |  |
| Long-term debt, net | 183,526 |  |  | 245,731 |  |
| Total liabilities | 460,399 |  |  | 503,496 |  |
| Total stockholders’ equity | 449,502 |  |  | 431,607 |  |
| Total liabilities and stockholders’ equity | $ | 909,901 |  |  | $ | 935,103 |  |

[0000926326-17-000026:8k_2_02:67]
Omnicell, Inc.

[0000926326-17-000026:8k_2_02:68]
Condensed Consolidated Statements of Cash Flows

[0000926326-17-000026:8k_2_02:69]
(Unaudited, in thousands)

[0000926326-17-000026:8k_2_02:70]
|  | Six months ended June 30, |
|  | 2017 |  | 2016 |
| Operating Activities |  |  |  |
| Net loss | $ | (9,917 | ) |  | $ | (1,537 | ) |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 25,942 |  |  | 29,197 |  |
| (Gain) loss on disposal of fixed assets | 79 |  |  | 1 |  |
| Share-based compensation expense | 11,056 |  |  | 9,386 |  |
| Income tax benefits from employee stock plans | 11 |  |  | 681 |  |
| Deferred income taxes | (12,646 | ) |  | (3,877 | ) |
| Amortization of debt financing fees | 795 |  |  | 795 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | (770 | ) |  | (7,775 | ) |
| Inventories | (12,226 | ) |  | (6,919 | ) |
| Prepaid expenses | 2,645 |  |  | (4,852 | ) |
| Other current assets | 202 |  |  | 78 |  |
| Investment in sales-type leases | 5,482 |  |  | (6,558 | ) |
| Other long-term assets | (34 | ) |  | 1,019 |  |
| Accounts payable | 23,357 |  |  | 6,736 |  |
| Accrued compensation | 4,529 |  |  | 210 |  |
| Accrued liabilities | 2,165 |  |  | (2,195 | ) |
| Deferred revenue | (2,865 | ) |  | 4,895 |  |
| Other long-term liabilities | 1,119 |  |  | (2,398 | ) |
| Net cash provided by operating activities | 38,924 |  |  | 16,887 |  |
| Investing Activities |  |  |  |
| Purchases of intangible assets, intellectual property and patents | (160 | ) |  | (1,185 | ) |
| Software development for external use | (6,748 | ) |  | (6,681 | ) |
| Purchases of property and equipment | (6,493 | ) |  | (5,938 | ) |
| Business acquisition, net of cash acquired | (4,446 | ) |  | (271,458 | ) |
| Net cash used in investing activities | (17,847 | ) |  | (285,262 | ) |
| Financing Activities |  |  |  |
| Proceeds from debt | 10,000 |  |  | 247,051 |  |
| Repayment of debt and revolving credit facility | (70,500 | ) |  | (22,500 | ) |
| Payment for contingent consideration | — |  |  | (3,000 | ) |
| Proceeds from issuances under stock-based compensation plans | 15,783 |  |  | 8,639 |  |
| Employees' taxes paid related to restricted stock units | (2,638 | ) |  | (1,563 | ) |
| Net cash provided by (used in) financing activities | (47,355 | ) |  | 228,627 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,274 | ) |  | (1,440 | ) |
| Net decrease in cash and cash equivalents | (27,552 | ) |  | (41,188 | ) |
| Cash and cash equivalents at beginning of period | 54,488 |  |  | 82,217 |  |
| Cash and cash equivalents at end of period | $ | 26,936 |  |  | $ | 41,029 |  |

[0000926326-17-000026:8k_2_02:71]
8

[0000926326-17-000026:8k_2_02:72]
Omnicell, Inc.

[0000926326-17-000026:8k_2_02:73]
Reconciliation of GAAP to Non-GAAP

[0000926326-17-000026:8k_2_02:74]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-17-000026:8k_2_02:75]
|  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  |  | June 30, 2017 |  | March 31, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| Reconciliation of GAAP revenue to non-GAAP revenue: |  |  |  |  |  |  |
| GAAP revenue |  | $ | 180,885 |  |  | $ | 150,554 |  |  | $ | 172,907 |  |  | $ | 331,439 |  |  | $ | 343,911 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 626 |  |  | 5,326 |  |
| Non-GAAP revenue | $ | 181,198 |  |  | $ | 150,867 |  |  | $ | 175,570 |  |  | $ | 332,065 |  |  | $ | 349,237 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |
| GAAP gross profit | $ | 77,975 |  |  | $ | 64,192 |  |  | $ | 78,017 |  |  | $ | 142,167 |  |  | $ | 157,962 |  |
| GAAP gross margin | 43.1% |  | 42.6% |  | 45.1% |  | 42.9% |  | 45.9% |
|  | Share-based compensation expense | 864 |  |  | 982 |  |  | 644 |  |  | 1,846 |  |  | 1,193 |  |
|  | Amortization of acquired intangibles | 2,848 |  |  | 2,837 |  |  | 5,214 |  |  | 5,685 |  |  | 10,425 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 626 |  |  | 5,326 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 920 |  |  | — |  |  | 1,841 |  |
|  | Acquisitions related expenses | — |  |  | — |  |  | 28 |  |  | — |  |  | 28 |  |
|  | Severance and other expenses* | — |  |  | 1,697 |  |  | 199 |  |  | 1,697 |  |  | 199 |  |
| Non-GAAP gross profit | $ | 82,000 |  |  | $ | 70,021 |  |  | $ | 87,685 |  |  | $ | 152,021 |  |  | $ | 176,974 |  |
| Non-GAAP gross margin | 45.3% |  | 46.4% |  | 49.9% |  | 45.8% |  | 50.7% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 80,379 |  |  | $ | 81,428 |  |  | $ | 78,135 |  |  | $ | 161,807 |  |  | $ | 156,228 |  |
| GAAP operating expenses % to total revenue |  | 44.4% |  | 54.1% |  | 45.2% |  | 48.8% |  | 45.4% |
|  | Share-based compensation expense | (4,681 | ) |  | (4,529 | ) |  | (4,851 | ) |  | (9,210 | ) |  | (8,193 | ) |
|  | Amortization of acquired intangibles | (3,626 | ) |  | (3,653 | ) |  | (3,838 | ) |  | (7,279 | ) |  | (7,786 | ) |
|  | Acquisitions related expenses | — |  |  | (126 | ) |  | (223 | ) |  | (126 | ) |  | (2,572 | ) |
|  | Severance and other expenses* | (970 | ) |  | (2,332 | ) |  | (1,504 | ) |  | (3,302 | ) |  | (1,504 | ) |
| Non-GAAP operating expenses | $ | 71,102 |  |  | $ | 70,788 |  |  | $ | 67,719 |  |  | $ | 141,890 |  |  | $ | 136,173 |  |
| Non-GAAP operating expenses % to total revenue | 39.2% |  | 46.9% |  | 38.6% |  | 42.7% |  | 39.0% |

[0000926326-17-000026:8k_2_02:76]
* Other expenses include relocation charge of $102, depreciation adjustment related to purchase price allocation from acquisition of $243, integration consulting of $126 and restructuring rent expense of $485 for the three months ended June 30, 2017. Other expenses include relocation charge of $322 and depreciation adjustment related to purchase price allocation from acquisition of $508 for the six months ended June 30, 2017.

[0000926326-17-000026:8k_2_02:77]
|  |  |  |  |  |  | Three Months Ended |  | Six months ended |
|  |  |  |  |  |  | June 30, 2017 |  | March 31, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income (loss) from operations: |  |  |  |  |
| GAAP income (loss) from operations | $ | (2,404 | ) |  | $ | (17,236 | ) |  | $ | (118 | ) |  | $ | (19,640 | ) |  | $ | 1,734 |  |
| GAAP operating income (loss) % to total revenue |  | (1.3)% |  | (11.4)% |  | (0.1)% |  | (5.9)% |  | 0.5% |
|  | Share-based compensation expense | 5,545 |  |  | 5,511 |  |  | 5,495 |  |  | 11,056 |  |  | 9,386 |  |
|  | Amortization of acquired intangibles | 6,474 |  |  | 6,490 |  |  | 9,052 |  |  | 12,964 |  |  | 18,211 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 626 |  |  | 5,326 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 920 |  |  | — |  |  | 1,841 |  |
|  | Acquisitions related expenses | — |  |  | 126 |  |  | 251 |  |  | 126 |  |  | 2,600 |  |
|  | Severance and other expenses | 970 |  |  | 4,029 |  |  | 1,703 |  |  | 4,999 |  |  | 1,703 |  |
| Non-GAAP income (loss) from operations | $ | 10,898 |  |  | $ | (767 | ) |  | $ | 19,966 |  |  | $ | 10,131 |  |  | $ | 40,801 |  |
| Non-GAAP operating income (loss) % to total Non-GAAP revenue | 6.0% |  | (0.5)% |  | 11.4% |  | 3.1% |  | 11.7% |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |  |  |  |  |  |  |
| GAAP net income (loss) | $ | 837 |  |  | $ | (10,754 | ) |  | $ | (1,159 | ) |  | $ | (9,917 | ) |  | $ | (1,537 | ) |
|  | Share-based compensation expense | 5,545 |  |  | 5,511 |  |  | 5,495 |  |  | 11,056 |  |  | 9,386 |  |
|  | Amortization of acquired intangibles | 6,474 |  |  | 6,490 |  |  | 9,052 |  |  | 12,964 |  |  | 18,211 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 626 |  |  | 5,326 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 920 |  |  | — |  |  | 1,841 |  |
|  | Acquisitions related expenses | 397 |  |  | 523 |  |  | 1,046 |  |  | 920 |  |  | 3,395 |  |
|  | Severance and other expenses | 970 |  |  | 4,029 |  |  | 1,703 |  |  | 4,999 |  |  | 1,703 |  |
|  | Tax effect of the adjustments above(a) | (2,817 | ) |  | (4,019 | ) |  | (5,846 | ) |  | (6,836 | ) |  | (11,581 | ) |
| Non-GAAP net income | $ | 11,719 |  |  | $ | 2,093 |  |  | $ | 13,874 |  |  | $ | 13,812 |  |  | $ | 26,744 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 38,370 |  |  | 36,840 |  |  | 35,987 |  |  | 37,046 |  |  | 35,864 |  |
| Shares - diluted Non-GAAP | 38,370 |  |  | 37,782 |  |  | 36,649 |  |  | 38,103 |  |  | 36,488 |  |
| GAAP net income (loss) per share - diluted | $ | 0.02 |  |  | $ | (0.29 | ) |  | $ | (0.03 | ) |  | $ | (0.27 | ) |  | $ | (0.04 | ) |
|  | Share-based compensation expense | 0.14 |  |  | 0.15 |  |  | 0.15 |  |  | 0.29 |  |  | 0.26 |  |
|  | Amortization of acquired intangibles | 0.17 |  |  | 0.17 |  |  | 0.25 |  |  | 0.34 |  |  | 0.50 |  |
|  | Acquisition accounting impact related to deferred revenue | 0.01 |  |  | 0.01 |  |  | 0.07 |  |  | 0.02 |  |  | 0.15 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 0.03 |  |  | — |  |  | 0.05 |  |
|  | Acquisitions related expenses | 0.01 |  |  | 0.01 |  |  | 0.03 |  |  | 0.02 |  |  | 0.09 |  |
|  | Severance and other expenses | 0.02 |  |  | 0.11 |  |  | 0.05 |  |  | 0.14 |  |  | 0.05 |  |
|  | Tax effect of the adjustments above(a) | (0.06 | ) |  | (0.10 | ) |  | (0.17 | ) |  | (0.18 | ) |  | (0.33 | ) |
| Non-GAAP net income per share - diluted | $ | 0.31 |  |  | $ | 0.06 |  |  | $ | 0.38 |  |  | $ | 0.36 |  |  | $ | 0.73 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | — |  |  |  |
| Reconciliation of GAAP net income (loss) to non-GAAP Adjusted EBITDA(b): |  |  |  |  |  |  |
| GAAP net income (loss) | $ | 837 |  |  | $ | (10,754 | ) |  | $ | (1,159 | ) |  | $ | (9,917 | ) |  | $ | (1,537 | ) |
|  | Share-based compensation expense | 5,545 |  |  | 5,511 |  |  | 5,495 |  |  | 11,056 |  |  | 9,386 |  |
|  | Interest (income) and expense, net | 1,311 |  |  | 1,432 |  |  | 1,348 |  |  | 2,743 |  |  | 3,095 |  |
|  | Depreciation and amortization expense | 13,494 |  |  | 12,448 |  |  | 14,724 |  |  | 25,942 |  |  | 29,197 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 626 |  |  | 5,326 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 920 |  |  | — |  |  | 1,841 |  |
|  | Acquisitions related expenses | 397 |  |  | 523 |  |  | 1,046 |  |  | 920 |  |  | 3,395 |  |
|  | Severance expense | 728 |  |  | 3,765 |  |  | 1,703 |  |  | 4,493 |  |  | 1,703 |  |
|  | Income tax expense | (3,045 | ) |  | (8,938 | ) |  | (840 | ) |  | (11,983 | ) |  | (781 | ) |
| Non-GAAP Adjusted EBITDA | $ | 19,580 |  |  | $ | 4,300 |  |  | $ | 25,900 |  |  | $ | 23,880 |  |  | $ | 51,625 |  |

[0000926326-17-000026:8k_2_02:78]
(a) Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 35% for fiscal year 2017 and 38% for fiscal year 2016.

[0000926326-17-000026:8k_2_02:79]
(b) Defined as earnings before interest income and expense, taxes, depreciation and amortization, as well as excluding certain non-GAAP adjustments.

[0000926326-17-000026:8k_2_02:80]
10

[0000926326-17-000026:8k_2_02:81]
Omnicell, Inc.

[0000926326-17-000026:8k_2_02:82]
Segmented Information

[0000926326-17-000026:8k_2_02:83]
(Unaudited, in thousands, except for percentages)

[0000926326-17-000026:8k_2_02:84]
|  | Three Months Ended June 30, 2017 |  | Three Months Ended June 30, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 148,427 |  |  | $ | 32,458 |  |  | $ | 180,885 |  |  | $ | 148,660 |  |  | $ | 24,247 |  |  | $ | 172,907 |  |
| Cost of revenues | 80,716 |  |  | 22,194 |  |  | 102,910 |  |  | 78,366 |  |  | 16,524 |  |  | 94,890 |  |
| Gross profit | 67,711 |  |  | 10,264 |  |  | 77,975 |  |  | 70,294 |  |  | 7,723 |  |  | 78,017 |  |
| Gross margin % | 45.6% |  | 31.6% |  | 43.1% |  | 47.3% |  | 31.9% |  | 45.1% |
| Operating expenses | 49,054 |  |  | 10,099 |  |  | 59,153 |  |  | 49,780 |  |  | 5,771 |  |  | 55,551 |  |
| Income from segment operations | $ | 18,657 |  |  | $ | 165 |  |  | $ | 18,822 |  |  | $ | 20,514 |  |  | $ | 1,952 |  |  | $ | 22,466 |  |
| Operating margin % | 12.6% |  | 0.5% |  | 10.4% |  | 13.8% |  | 8.1% |  | 13.0% |
| Corporate costs |  |  |  |  | 21,226 |  |  |  |  |  |  | 22,584 |  |
| Loss from operations |  |  |  |  | $ | (2,404 | ) |  |  |  |  |  | $ | (118 | ) |

[0000926326-17-000026:8k_2_02:85]
11

[0000926326-17-000026:8k_2_02:86]
Omnicell, Inc.

[0000926326-17-000026:8k_2_02:87]
Segmented Information

[0000926326-17-000026:8k_2_02:88]
(Unaudited, in thousands, except for percentages)

[0000926326-17-000026:8k_2_02:89]
|  | Six Months Ended June 30, 2017 |  | Six Months Ended June 30, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 272,598 |  |  | $ | 58,841 |  |  | $ | 331,439 |  |  | $ | 297,605 |  |  | $ | 46,306 |  |  | $ | 343,911 |  |
| Cost of revenues | 149,477 |  |  | 39,795 |  |  | 189,272 |  |  | 155,573 |  |  | 30,376 |  |  | 185,949 |  |
| Gross profit | 123,121 |  |  | 19,046 |  |  | 142,167 |  |  | 142,032 |  |  | 15,930 |  |  | 157,962 |  |
| Gross margin % | 45.2% |  | 32.4% |  | 42.9% |  | 47.7% |  | 34.4% |  | 45.9% |
| Operating expenses | 99,801 |  |  | 21,295 |  |  | 121,096 |  |  | 101,985 |  |  | 11,382 |  |  | 113,367 |  |
| Income (loss) from segment operations | $ | 23,320 |  |  | $ | (2,249 | ) |  | $ | 21,071 |  |  | $ | 40,047 |  |  | $ | 4,548 |  |  | $ | 44,595 |  |
| Operating margin % | 8.6% |  | (3.8)% |  | 6.4% |  | 13.5% |  | 9.8% |  | 13.0% |
| Corporate costs |  |  |  |  | 40,711 |  |  |  |  |  |  | 42,861 |  |
| Income (loss) from operations |  |  |  |  | $ | (19,640 | ) |  |  |  |  |  | $ | 1,734 |  |

[0000926326-17-000026:8k_2_02:90]
Omnicell, Inc.

[0000926326-17-000026:8k_2_02:91]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-17-000026:8k_2_02:92]
(Unaudited, in thousands, except for percentages)

[0000926326-17-000026:8k_2_02:93]
|  | Three Months Ended June 30, 2017 |  |  |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 148,427 |  |  |  |  |  |  | $ | 32,458 |  |  |  |  |  |  | $ | 180,885 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenue | — |  |  | —% |  | —% |  | 313 |  |  | 1.0% |  | 1.0% |  | 313 |  |  | 0.2% |  | 0.2% |
| Non-GAAP Revenues | $ | 148,427 |  |  |  |  |  |  | $ | 32,771 |  |  |  |  |  |  | $ | 181,198 |  |  |  |  |  |
| GAAP Gross profit | $ | 67,711 |  |  | 45.6% |  | 45.6% |  | $ | 10,264 |  |  | 31.6% |  | 31.3% |  | $ | 77,975 |  |  | 43.1% |  | 43.0% |
| Share-based compensation expense | 736 |  |  | 0.5% |  | 0.5% |  | 128 |  |  | 0.4% |  | 0.4% |  | 864 |  |  | 0.5% |  | 0.5% |
| Amortization expense of acquired intangible assets | 2,228 |  |  | 1.5% |  | 1.5% |  | 620 |  |  | 1.9% |  | 1.9% |  | 2,848 |  |  | 1.6% |  | 1.6% |
| Acquisition accounting impact related to deferred revenue | — |  |  | —% |  | —% |  | 313 |  |  | 1.0% |  | 1.0% |  | 313 |  |  | 0.2% |  | 0.2% |
| Non-GAAP Gross profit | $ | 70,675 |  |  | 47.6% |  | 47.6% |  | $ | 11,325 |  |  | 34.9% |  | 34.6% |  | $ | 82,000 |  |  | 45.3% |  | 45.3% |
| GAAP Operating income | $ | 18,657 |  |  | 12.6% |  | 12.6% |  | $ | 165 |  |  | 0.5% |  | 0.5% |  | $ | 18,822 |  |  | 10.4% |  | 10.4% |
| Share-based compensation expense | 2,275 |  |  | 1.5% |  | 1.5% |  | 354 |  |  | 1.1% |  | 1.1% |  | 2,629 |  |  | 1.5% |  | 1.5% |
| Amortization expense of acquired intangible assets | 4,545 |  |  | 3.1% |  | 3.1% |  | 1,929 |  |  | 5.9% |  | 5.9% |  | 6,474 |  |  | 3.6% |  | 3.6% |
| Acquisition accounting impact related to deferred revenue | — |  |  | —% |  | —% |  | 313 |  |  | 1.0% |  | 1.0% |  | 313 |  |  | 0.2% |  | 0.2% |
| Severance and other expenses | 610 |  |  | 0.4% |  | 0.4% |  | — |  |  | —% |  | —% |  | 610 |  |  | 0.3% |  | 0.3% |
| Non-GAAP Operating income | $ | 26,087 |  |  | 17.6% |  | 17.6% |  | $ | 2,761 |  |  | 8.5% |  | 8.4% |  | $ | 28,848 |  |  | 15.9% |  | 15.9% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 21,226 |  |  | 11.7% |  | 11.7% |
| Share-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (2,916 | ) |  | (1.6)% |  | (1.6)% |
| Acquisition-related expenses |  |  |  |  |  |  |  |  |  |  |  |  | 0 |  |  | —% |  | —% |
| Severance and other expenses |  |  |  |  |  |  |  |  |  |  |  |  | (360 | ) |  | (0.2)% |  | (0.2)% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 17,950 |  |  | 9.9% |  | 9.9% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 10,898 |  |  | 6.0% |  | 6.0% |

[0000926326-17-000026:8k_2_02:94]
13

[0000926326-17-000026:8k_2_02:95]
Omnicell, Inc.

[0000926326-17-000026:8k_2_02:96]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-17-000026:8k_2_02:97]
(Unaudited, in thousands, except for percentages)

[0000926326-17-000026:8k_2_02:98]
|  | Three Months Ended June 30, 2016 |  |  |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 148,660 |  |  |  |  |  |  | $ | 24,247 |  |  |  |  |  |  | $ | 172,907 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.8 | % |  | 1.8 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.5 | % |  | 1.5 | % |
| Non-GAAP Revenues | $ | 151,323 |  |  |  |  |  |  | $ | 24,247 |  |  |  |  |  |  | $ | 175,570 |  |  |  |  |  |
| GAAP Gross profit | $ | 70,294 |  |  | 47.3 | % |  | 46.5 | % |  | $ | 7,723 |  |  | 31.9 | % |  | 31.9 | % |  | $ | 78,017 |  |  | 45.1 | % |  | 44.4 | % |
| Stock-based compensation expense | 561 |  |  | 0.4 | % |  | 0.4 | % |  | 83 |  |  | 0.3 | % |  | 0.3 | % |  | 644 |  |  | 0.4 | % |  | 0.4 | % |
| Amortization expense of acquired intangible assets | 4,882 |  |  | 3.3 | % |  | 3.2 | % |  | 332 |  |  | 1.4 | % |  | 1.4 | % |  | 5,214 |  |  | 3.0 | % |  | 3.0 | % |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.8 | % |  | 1.8 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.5 | % |  | 1.5 | % |
| Inventory fair value adjustments | 920 |  |  | 0.6 | % |  | 0.6 | % |  | — |  |  | — | % |  | — | % |  | 920 |  |  | 0.5 | % |  | 0.5 | % |
| Acquisitions related expenses | 28 |  |  | — | % |  | — | % |  | — |  |  | — | % |  | — | % |  | 28 |  |  | — | % |  | — | % |
| Severance expenses | 199 |  |  | 0.1 | % |  | 0.1 | % |  |  |  |  |  |  |  | 199 |  |  | 0.1 | % |  | 0.1 | % |
| Non-GAAP Gross profit | $ | 79,547 |  |  | 53.5 | % |  | 52.6 | % |  | $ | 8,138 |  |  | 33.6 | % |  | 33.6 | % |  | $ | 87,685 |  |  | 50.7 | % |  | 49.9 | % |
| GAAP Operating income | $ | 20,514 |  |  | 13.8 | % |  | 13.6 | % |  | $ | 1,952 |  |  | 8.1 | % |  | 8.1 | % |  | $ | 22,466 |  |  | 13.0 | % |  | 12.8 | % |
| Stock-based compensation expense | 2,042 |  |  | 1.4 | % |  | 1.3 | % |  | 240 |  |  | 1.0 | % |  | 1.0 | % |  | 2,282 |  |  | 1.3 | % |  | 1.3 | % |
| Amortization expense of acquired intangible assets | 7,739 |  |  | 5.2 | % |  | 5.1 | % |  | 1,313 |  |  | 5.4 | % |  | 5.4 | % |  | 9,052 |  |  | 5.2 | % |  | 5.2 | % |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.8 | % |  | 1.8 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.5 | % |  | 1.5 | % |
| Inventory fair value adjustments | 920 |  |  | 0.6 | % |  | 0.6 | % |  | — |  |  | — | % |  | — | % |  | 920 |  |  | 0.5 | % |  | 0.5 | % |
| Acquisitions related expenses | 259 |  |  | 0.2 | % |  | 0.2 | % |  | — |  |  | — | % |  | — | % |  | 259 |  |  | 0.1 | % |  | 0.1 | % |
| Severance expenses | 1,590 |  |  | 1.1 | % |  | 1.1 | % |  | 56 |  |  | 0.2 | % |  | 0.2 | % |  | 1,646 |  |  | 1.0 | % |  | 0.9 | % |
| Non-GAAP Operating income | $ | 35,727 |  |  | 24.0 | % |  | 23.6 | % |  | $ | 3,561 |  |  | 14.7 | % |  | 14.7 | % |  | $ | 39,288 |  |  | 22.7 | % |  | 22.4 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 22,584 |  |  | 13.1 | % |  | 12.9 | % |
| Stock-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | 3,213 |  |  | 1.9 | % |  | 1.8 | % |
| Acquisition related expenses |  |  |  |  |  |  |  |  |  |  |  |  | (8 | ) |  | — | % |  | — | % |
| Severance expenses |  |  |  |  |  |  |  |  |  |  |  |  | 57 |  |  | — | % |  | — | % |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 19,322 |  |  | 11.2 | % |  | 11.0 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 19,966 |  |  | 11.4 | % |  | 11.4 | % |
