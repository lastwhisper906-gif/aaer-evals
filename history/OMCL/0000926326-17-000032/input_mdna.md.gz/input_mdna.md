# OMCL MD&A — 0000926326-17-000032


## mdna

[0000926326-17-000032:mdna:1]
[same as prior period, unchanged from 0001628280-17-005045:mdna:1]

[0000926326-17-000032:mdna:2]
[same as prior period, unchanged from 0001628280-17-005045:mdna:2]

[0000926326-17-000032:mdna:3]
[same as prior period, unchanged from 0001628280-17-005045:mdna:3]

[0000926326-17-000032:mdna:4]
[same as prior period, unchanged from 0001628280-17-005045:mdna:4]

[0000926326-17-000032:mdna:5]
[same as prior period, unchanged from 0001628280-17-005045:mdna:5]

[0000926326-17-000032:mdna:6]
[same as prior period, unchanged from 0001628280-17-005045:mdna:6]

[0000926326-17-000032:mdna:7]
[same as prior period, unchanged from 0001628280-17-005045:mdna:7]

[0000926326-17-000032:mdna:8]
[same as prior period, unchanged from 0001628280-17-005045:mdna:8]

[0000926326-17-000032:mdna:9]
[same as prior period, unchanged from 0001628280-17-005045:mdna:9]

[0000926326-17-000032:mdna:10]
[same as prior period, unchanged from 0001628280-17-005045:mdna:10]

[0000926326-17-000032:mdna:11]
[same as prior period, unchanged from 0001628280-17-005045:mdna:11]

[0000926326-17-000032:mdna:12]
[same as prior period, unchanged from 0001628280-17-005045:mdna:29]

[0000926326-17-000032:mdna:13]
[same as prior period, unchanged from 0001628280-17-005045:mdna:12]

[0000926326-17-000032:mdna:14]
[same as prior period, unchanged from 0001628280-17-005045:mdna:13]

[0000926326-17-000032:mdna:15]
[same as prior period, unchanged from 0001628280-17-005045:mdna:14]

[0000926326-17-000032:mdna:16]
[same as prior period, unchanged from 0001628280-17-005045:mdna:15]

[0000926326-17-000032:mdna:17]
[same as prior period, unchanged from 0001628280-17-005045:mdna:16]

[0000926326-17-000032:mdna:18]
[same as prior period, unchanged from 0001628280-17-005045:mdna:17]

[0000926326-17-000032:mdna:19]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 85% and 84% of total revenue for the three months ended June 30, 2017 and 2016, respectively, and 86% and 84% of total revenue for the six months ended June 30, 2017 and 2016. We expect our revenues from international operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-17-000032:mdna:20]
[same as prior period, unchanged from 0001628280-17-005045:mdna:19]

[0000926326-17-000032:mdna:21]
[same as prior period, unchanged from 0001628280-17-005045:mdna:20]

[0000926326-17-000032:mdna:22]
[same as prior period, unchanged from 0001628280-17-005045:mdna:21]

[0000926326-17-000032:mdna:23]
[same as prior period, unchanged from 0001628280-17-005045:mdna:22]

[0000926326-17-000032:mdna:24]
[same as prior period, unchanged from 0001628280-17-005045:mdna:23]

[0000926326-17-000032:mdna:25]
The Medication Adherence segment includes the development, manufacturing and selling of consumable medication blister cards, packaging equipment, pharmacy-based patient care software solutions including a medication synchronization platform, and ancillary products and services.  These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand name MTS, SureMed, Ateb, and the Omnicell brands. MTS products consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care and correctional facilities, or retail pharmacies serving patients in their local communities. Recently acquired Ateb is a provider of pharmacy-based patient care solutions and medication synchronization to independent and chain pharmacies.

[0000926326-17-000032:mdna:26]
[same as prior period, unchanged from 0001628280-17-005045:mdna:25]

[0000926326-17-000032:mdna:27]
[same as prior period, unchanged from 0001628280-17-005045:mdna:26]

[0000926326-17-000032:mdna:28]
[same as prior period, unchanged from 0001628280-17-005045:mdna:27]

[0000926326-17-000032:mdna:29]
| • | Development of differentiated solutions. We invest in the development of products that we believe bring patient safety and workflow efficiency to our customers’ operations that they cannot get from other competing solutions. These differentiators may be as small as how a transaction operates or information provided on a report or as large as the entire automation of a workflow that would otherwise be completed manually. We intend to continue our focus on differentiating our products, and we carefully assess our investments regularly as we strive to ensure those investments provide the solutions most valuable to our customers. |

[0000926326-17-000032:mdna:30]
[same as prior period, unchanged from 0001628280-17-005045:mdna:31]

[0000926326-17-000032:mdna:31]
[same as prior period, unchanged from 0001628280-17-005045:mdna:32]

[0000926326-17-000032:mdna:32]
[same as prior period, unchanged from 0001628280-17-005045:mdna:33]

[0000926326-17-000032:mdna:33]
[same as prior period, unchanged from 0001628280-17-005045:mdna:34]

[0000926326-17-000032:mdna:34]
[same as prior period, unchanged from 0001628280-17-005045:mdna:49]

[0000926326-17-000032:mdna:35]
[same as prior period, unchanged from 0001628280-17-005045:mdna:35]

[0000926326-17-000032:mdna:36]
[same as prior period, unchanged from 0001628280-17-005045:mdna:36]

[0000926326-17-000032:mdna:37]
[same as prior period, unchanged from 0001628280-17-005045:mdna:37]

[0000926326-17-000032:mdna:38]
[same as prior period, unchanged from 0001628280-17-005045:mdna:38]

[0000926326-17-000032:mdna:39]
[same as prior period, unchanged from 0001628280-17-005045:mdna:40]

[0000926326-17-000032:mdna:40]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced by a contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are installable within twelve months and, other than subscription based sales, generally are recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month.

[0000926326-17-000032:mdna:41]
[same as prior period, unchanged from 0001628280-17-005045:mdna:42]

[0000926326-17-000032:mdna:42]
[same as prior period, unchanged from 0001628280-17-005045:mdna:43]

[0000926326-17-000032:mdna:43]
On February 15, 2017, we announced our intention to create Centers of Excellence (“COE”) for product development, engineering and manufacturing, with the Point of Use COE located at our facilities in California, the Robotics and Central Pharmacy COE located at our facilities near Pittsburgh, Pennsylvania, and the Medication Adherence Consumables COE located at our facilities in St. Petersburg, Florida. As part of this initiative, we reduced our workforce by approximately 100 full-time employees, or about 4% of the total headcount, closed our Nashville, Tennessee facility, and plan to close our Slovenia facilities in the second part of 2017. Our full-time headcount was approximately 2,345 and 2,444 on June 30, 2017 on December 31, 2016, respectively.

[0000926326-17-000032:mdna:44]
[same as prior period, unchanged from 0001628280-17-005045:mdna:45]

[0000926326-17-000032:mdna:45]
On January 5, 2016, we completed the acquisition of all of the membership interests of Aesynt. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. The purchase price consideration was $271.5 million, net of cash acquired of $8.2 million. The results of Aesynt's operations have been included in our consolidated results of operations since January 6, 2016, and presented as part of the Automation and Analytics segment.

[0000926326-17-000032:mdna:46]
[same as prior period, unchanged from 0001628280-17-005045:mdna:47]

[0000926326-17-000032:mdna:47]
On April 12, 2017, we completed the acquisition of InPharmics, a technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies. The purchase price consideration was $5.0 million, net of cash acquired of $0.3 million. The results of InPharmics' operations have been included in our consolidated results of operations beginning April 13, 2017, and presented as part of the Automation and Analytics segment.

[0000926326-17-000032:mdna:48]
[same as prior period, unchanged from 0001628280-17-005045:mdna:50]

[0000926326-17-000032:mdna:49]
[same as prior period, unchanged from 0001628280-17-005045:mdna:51]

[0000926326-17-000032:mdna:50]
[same as prior period, unchanged from 0001628280-17-005045:mdna:52]

[0000926326-17-000032:mdna:51]
[same as prior period, unchanged from 0001628280-17-005045:mdna:53]

[0000926326-17-000032:mdna:52]
[same as prior period, unchanged from 0001628280-17-005045:mdna:54]

[0000926326-17-000032:mdna:53]
[same as prior period, unchanged from 0001628280-17-005045:mdna:55]

[0000926326-17-000032:mdna:54]
[same as prior period, unchanged from 0001628280-17-005045:mdna:56]

[0000926326-17-000032:mdna:55]
[same as prior period, unchanged from 0001628280-17-005045:mdna:57]

[0000926326-17-000032:mdna:56]
[same as prior period, unchanged from 0001628280-17-005045:mdna:58]

[0000926326-17-000032:mdna:57]
[same as prior period, unchanged from 0001628280-17-005045:mdna:59]

[0000926326-17-000032:mdna:58]
There have been no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the six months ended June 30, 2017 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2016.

[0000926326-17-000032:mdna:59]
[same as prior period, unchanged from 0001628280-17-005045:mdna:61]

[0000926326-17-000032:mdna:60]
[same as prior period, unchanged from 0001628280-17-005045:mdna:62]

[0000926326-17-000032:mdna:61]
29

[0000926326-17-000032:mdna:62]
[same as prior period, unchanged from 0001628280-17-005045:mdna:63]

[0000926326-17-000032:mdna:63]
[same as prior period, unchanged from 0001628280-17-005045:mdna:64]

[0000926326-17-000032:mdna:64]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 128,056 |  |  | $ | 130,674 |  |  | $ | (2,618 | ) |  | (2 | )% |
| Percentage of total revenues | 71 | % |  | 76 | % |  |  |  |  |
| Service and other revenues | 52,829 |  |  | 42,233 |  |  | 10,596 |  |  | 25 | % |
| Percentage of total revenues | 29 | % |  | 24 | % |  |  |  |  |
| Total revenues | $ | 180,885 |  |  | $ | 172,907 |  |  | $ | 7,978 |  |  | 5 | % |

[0000926326-17-000032:mdna:65]
Product revenues represented 71% and 76% of total revenues for the three months ended June 30, 2017 and June 30, 2016, respectively. Product revenues decreased by $2.6 million due to decreased sales for the Automation and Analytics segment of $5.8 million, offset by increased sales for the Medication Adherence segment of $3.1 million. The decrease in the Automation and Analytics segment was attributed to slower conversion of bookings and backlog into revenue as result of the introduction of the XT series products in the fourth quarter of 2016. The increase in the Medication Adherence segment was attributed to higher completed installations compared to the three months ended June 30, 2016, primarily due to the introduction of VBM product series in the fourth quarter of 2016.

[0000926326-17-000032:mdna:66]
Service and other revenues represented 29% and 24% of total revenues for the three months ended June 30, 2017 and June 30, 2016, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues increased by $10.6 million primarily due to an increase from our Automation and Analytics segment of $5.5 million attributed to higher service renewal fees, driven mainly by an increase in our installed customer base. Service and other revenues from the Medication Adherence segment increased $5.1 million, primarily attributed to Ateb, acquired in the fourth quarter of 2016, which contributed $5.4 million to the service revenue during the three months ended June 30, 2017.

[0000926326-17-000032:mdna:67]
Our international sales represented 15% and 16% of total revenues for the three months ended June 30, 2017 and 2016, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-17-000032:mdna:68]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 226,986 |  |  | $ | 258,569 |  |  | $ | (31,583 | ) |  | (12 | )% |
| Percentage of total revenues | 68 | % |  | 75 | % |  |  |  |  |
| Service and other revenues | 104,453 |  |  | 85,342 |  |  | 19,111 |  |  | 22 | % |
| Percentage of total revenues | 32 | % |  | 25 | % |  |  |  |  |
| Total revenues | $ | 331,439 |  |  | $ | 343,911 |  |  | $ | (12,472 | ) |  | (4 | )% |

[0000926326-17-000032:mdna:69]
Product revenues represented 68% and 75% of total revenues for the six months ended June 30, 2017 and June 30, 2016, respectively. Product revenues decreased by $31.6 million due to decreased sales for the Automation and Analytics segment of $33.9 million, partially offset by increased sales for the Medication Adherence segment of $2.3 million. The decrease in the Automation and Analytics segment was attributed to slower conversion of bookings and backlog into revenue as a result of the introduction of the XT series products in the fourth quarter of 2016. The increase in the Medication Adherence segment was attributed to higher machine sales compared to the six months ended June 30, 2016, primarily due to the introduction of VBM product series in the fourth quarter of 2016.

[0000926326-17-000032:mdna:70]
Service and other revenues represented 32% and 25% of total revenues for the six months ended June 30, 2017 and June 30, 2016, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues increased by $19.1 million primarily due to an increase from our Automation and Analytics segment of $8.9 million attributed to higher service renewal fees driven mainly by an increase in our installed customer base. Service and other revenues from the Medication Adherence segment increased $10.2 million, primarily

[0000926326-17-000032:mdna:71]
attributed to Ateb, acquired in the fourth quarter of 2016, which contributed $10.5 million to the service revenue during the six months ended June 30, 2017.

[0000926326-17-000032:mdna:72]
Our international sales represented 14% and 16% of total revenues for the six months ended June 30, 2017 and 2016, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. The decrease in international sales was primarily related to the recently acquired companies, Aesynt and Ateb, which have a higher market presence in United States compared to international markets. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-17-000032:mdna:73]
[same as prior period, unchanged from 0001628280-17-005045:mdna:70]

[0000926326-17-000032:mdna:74]
[same as prior period, unchanged from 0001628280-17-005045:mdna:71]

[0000926326-17-000032:mdna:75]
[same as prior period, unchanged from 0001628280-17-005045:mdna:72]

[0000926326-17-000032:mdna:76]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 148,427 |  |  | $ | 148,660 |  |  | $ | (233 | ) |  | (0.2 | )% |
| Percentage of total revenues | 82 | % |  | 86 | % |  |  |  |  |
| Medication Adherence | 32,458 |  |  | 24,247 |  |  | 8,211 |  |  | 34 | % |
| Percentage of total revenues | 18 | % |  | 14 | % |  |  |  |  |
| Total revenues | $ | 180,885 |  |  | $ | 172,907 |  |  | $ | 7,978 |  |  | 5 | % |

[0000926326-17-000032:mdna:77]
The $0.2 million decrease in Automation and Analytics revenues for the three months ended June 30, 2017 in comparison to the three months ended June 30, 2016 was due to a decrease in product revenue of $5.8 million, partially offset by an increase in service revenues of $5.5 million. The decrease in the Automation and Analytics segment was attributed to slower conversion of bookings and backlog into revenue as result of the introduction of the XT series products in the fourth quarter of 2016. While we have experienced larger deal sizes, the administrative process of converting our existing bookings of G4 products into XT series products has decelerated revenue recognition during the three months ended June 30, 2017 compared to the three months ended June 30, 2016. The service revenue increase of $5.5 million was primarily attributed to higher service renewal fees driven mainly by an increase in installed customer base.

[0000926326-17-000032:mdna:78]
Medication Adherence revenues increased by $8.2 million for the three months ended June 30, 2017 in comparison to the three months ended June 30, 2016. The increase in revenue was due to an increase in product revenue of $3.1 million and an increase in service revenue of $5.1 million. The product revenue increase of $3.1 million was attributed primarily to the introduction of the VBM product series in the fourth quarter of 2016. The service revenue increase of $5.1 million was primarily attributed to Ateb, acquired in the fourth quarter of 2016, which contributed $5.4 million to the service revenue during the three months ended June 30, 2017.

[0000926326-17-000032:mdna:79]
31

[0000926326-17-000032:mdna:80]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 272,598 |  |  | $ | 297,605 |  |  | $ | (25,007 | ) |  | (8 | )% |
| Percentage of total revenues | 82 | % |  | 87 | % |  |  |  |  |
| Medication Adherence | 58,841 |  |  | 46,306 |  |  | 12,535 |  |  | 27 | % |
| Percentage of total revenues | 18 | % |  | 13 | % |  |  |  |  |
| Total revenues | $ | 331,439 |  |  | $ | 343,911 |  |  | $ | (12,472 | ) |  | (4 | )% |

[0000926326-17-000032:mdna:81]
The $25.0 million decrease in Automation and Analytics revenues for the six months ended June 30, 2017 in comparison to the six months ended June 30, 2016 was due to a decrease in product revenue of $33.9 million, partially offset by an increase in service revenues of $8.9 million. The decrease in the Automation and Analytics segment was attributed to slower conversion of bookings and backlog into revenue as result of the introduction of the XT series products in the fourth quarter of 2016. While we have experienced larger deal sizes, the administrative process of converting our existing bookings of G4 products into XT series products has decelerated revenue recognition during the six months ended June 30, 2017 compared to the six months ended June 30, 2016. Service revenue increase of $8.9 million was primarily attributed to higher service renewal fees driven mainly by an increase in installed customer base.

[0000926326-17-000032:mdna:82]
Medication Adherence revenues increased by $12.5 million for the six months ended June 30, 2017 in comparison to the six months ended June 30, 2016. The increase in revenue was comprised of an increase in product revenue of $2.3 million and increase in service revenue of $10.2 million. Product revenue increase of $2.3 million was attributed primarily to the introduction of the VBM product series in the fourth quarter of 2016. The service revenue increase of $10.2 million was primarily attributed to Ateb, acquired in the fourth quarter of 2016, which contributed $10.5 million to the service revenue during the six months ended June 30, 2017.

[0000926326-17-000032:mdna:83]
[same as prior period, unchanged from 0001628280-17-005045:mdna:76]

[0000926326-17-000032:mdna:84]
[same as prior period, unchanged from 0001628280-17-005045:mdna:77]

[0000926326-17-000032:mdna:85]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 80,716 |  |  | $ | 78,366 |  |  | $ | 2,350 |  |  | 3 | % |
| As a percentage of related revenues | 54 | % |  | 53 | % |  |  |  |  |
| Medication Adherence | 22,194 |  |  | 16,524 |  |  | 5,670 |  |  | 34 | % |
| As a percentage of related revenues | 68 | % |  | 68 | % |  |  |  |  |
| Total cost of revenues | $ | 102,910 |  |  | $ | 94,890 |  |  | $ | 8,020 |  |  | 8 | % |
| As a percentage of total revenues | 57 | % |  | 55 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 67,711 |  |  | $ | 70,294 |  |  | $ | (2,583 | ) |  | (4 | )% |
| Automation and Analytics gross margin | 46 | % |  | 47 | % |  |  |  |  |
| Medication Adherence | 10,264 |  |  | 7,723 |  |  | 2,541 |  |  | 33 | % |
| Medication Adherence gross margin | 32 | % |  | 32 | % |  |  |  |  |
| Total gross profit | $ | 77,975 |  |  | $ | 78,017 |  |  | $ | (42 | ) |  | — | % |
| Total gross margin | 43 | % |  | 45 | % |  |  |  |  |

[0000926326-17-000032:mdna:86]
32

[0000926326-17-000032:mdna:87]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 149,477 |  |  | $ | 155,573 |  |  | $ | (6,096 | ) |  | (4 | )% |
| As a percentage of related revenues | 55 | % |  | 52 | % |  |  |  |  |
| Medication Adherence | 39,795 |  |  | 30,376 |  |  | 9,419 |  |  | 31 | % |
| As a percentage of related revenues | 68 | % |  | 66 | % |  |  |  |  |
| Total cost of revenues | $ | 189,272 |  |  | $ | 185,949 |  |  | $ | 3,323 |  |  | 2 | % |
| As a percentage of total revenues | 57 | % |  | 54 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 123,121 |  |  | $ | 142,032 |  |  | $ | (18,911 | ) |  | (13 | )% |
| Automation and Analytics gross margin | 45 | % |  | 48 | % |  |  |  |  |
| Medication Adherence | 19,046 |  |  | 15,930 |  |  | 3,116 |  |  | 20 | % |
| Medication Adherence gross margin | 32 | % |  | 34 | % |  |  |  |  |
| Total gross profit | $ | 142,167 |  |  | $ | 157,962 |  |  | $ | (15,795 | ) |  | (10 | )% |
| Total gross margin | 43 | % |  | 46 | % |  |  |  |  |

[0000926326-17-000032:mdna:88]
Cost of Revenues. Cost of revenues for the three months ended June 30, 2017 compared to the three months ended June 30, 2016 increased by $8.0 million, of which $2.4 million was attributed to the increase of cost of revenue in our Automation and Analytics segment and $5.7 million was attributed to the increase of cost of revenue in our Medication Adherence segment. The increase of the cost of revenue in the Automation and Analytics segment was primarily attributed to the XT series manufacturing ramp up, including addressing quality concerns, partially offset by lower amortization expenses of acquired technology and integration related expenses related to the Aesynt acquisition. The increase of the cost of revenue in the Medication Adherence segment was attributed to Ateb, acquired in the fourth quarter of 2016, which contributed $2.9 million to the increase, and of 13% in product revenue.

[0000926326-17-000032:mdna:89]
Cost of revenues for the six months ended June 30, 2017 compared to the six months ended June 30, 2016 increased by $3.3 million, $6.1 million of which was attributed to the decrease in cost of revenue in our Automation and Analytics segment, partially offset by $9.4 million of increased cost of revenue in our Medication Adherence segment. The decrease of the cost of revenue in the Automation and Analytics segment was attributed to a decrease of $33.9 million in product revenue, partially offset by severance expense of $1.3 million recognized during the six months ended June 30, 2017 in connection with the restructuring plan. The increase of the cost of revenue in the Medication Adherence segment was mainly attributed to Ateb, which contributed $6.0 million to the increase, and increased equipment sales including VBM medication packaging products.

[0000926326-17-000032:mdna:90]
Gross Profit. Gross profit for the three months ended June 30, 2017 was consistent with the three months ended June 30, 2016 as a result of a decrease in gross profit for the Automation and Analytics segment of $2.6 million as result of increased cost to ramp up manufacturing of the XT series product, offset by an increase in gross profit for the Medication Adherence segment of $2.5 million as a result of the Ateb acquisition.

[0000926326-17-000032:mdna:91]
Gross profit for the six months ended June 30, 2017 decreased by $15.8 million compared to the six months ended June 30, 2016 primarily due to the decrease in sales as part of the XT series product introduction, partially offset by approximately $6.2 million of gross profit from the recently acquired Ateb.

[0000926326-17-000032:mdna:92]
[same as prior period, unchanged from 0001628280-17-005045:mdna:113]

[0000926326-17-000032:mdna:93]
[same as prior period, unchanged from 0001628280-17-005045:mdna:82]

[0000926326-17-000032:mdna:94]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 16,911 |  |  | $ | 13,794 |  |  | $ | 3,117 |  |  | 23 | % |
| As a percentage of total revenues | 9 | % |  | 8 | % |  |  |  |  |
| Selling, general and administrative | 63,468 |  |  | 64,341 |  |  | (873 | ) |  | (1 | )% |
| As a percentage of total revenues | 35 | % |  | 37 | % |  |  |  |  |
| Total operating expenses | $ | 80,379 |  |  | $ | 78,135 |  |  | $ | 2,244 |  |  | 3 | % |
| As a percentage of total revenues | 44 | % |  | 45 | % |  |  |  |  |
| Income (loss) from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 18,657 |  |  | $ | 20,514 |  |  | $ | (1,857 | ) |  | (9 | )% |
| Operating margin | 13 | % |  | 14 | % |  |  |  |  |
| Medication Adherence | 165 |  |  | 1,952 |  |  | (1,787 | ) |  | (92 | )% |
| Operating margin | 1 | % |  | 8 | % |  |  |  |  |
| Corporate Expenses | 21,226 |  |  | 22,584 |  |  | (1,358 | ) |  | (6 | )% |
| Total income (loss) from operations | $ | (2,404 | ) |  | $ | (118 | ) |  | $ | (2,286 | ) |  | 1,937 | % |
| Total operating margin | (1 | )% |  | (0.1 | )% |  |  |  |  |

[0000926326-17-000032:mdna:95]
Research and Development. The $3.1 million increase in research and development expenses for the three months ended June 30, 2017 compared to three months ended June 30, 2016 was primarily driven by an increase in research and development expenses of $2.0 million in our Medication Adherence segment as result of the Ateb acquisition which contributed $1.7 million to the increase. The remaining increase of $0.8 million is attributed to restructuring charges of $0.5 million recorded during the three months ended June 30, 2017 in our Automation and Analytics segment.

[0000926326-17-000032:mdna:96]
Selling, General and Administrative.  The $0.9 million decrease in selling, general and administrative expenses for the three months ended June 30, 2017 compared to the three months ended June 30, 2016 was primarily due to the decrease in corporate related expenses of $1.7 million as a result of headcount reduction and lower acquisition related expenses, a decrease of $1.5 million in our Automation and Analytics segment due to lower amortization expenses from the acquired intangible assets, partially offset by an increase of $2.3 million in our Medication Adherence segment primarily due to the Ateb acquisition, which contributed $2.1 million to the increase.

[0000926326-17-000032:mdna:97]
Operating Income (Loss). Operating income from our Automation and Analytics segment decreased by $1.9 million due to the lower gross margin of $2.6 million, partially offset by lower research and development and selling, general and administrative costs of $0.7 million. Operating income from our Medication Adherence segment decreased by $1.8 million due to higher research and development and selling, general and administrative costs of attributed to Ateb, which accounted for $3.9 million of the increase, partially offset by higher gross margin of $2.5 million.

[0000926326-17-000032:mdna:98]
[same as prior period, unchanged from 0001628280-17-005045:mdna:128]

[0000926326-17-000032:mdna:99]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 33,714 |  |  | $ | 27,632 |  |  | $ | 6,082 |  |  | 22 | % |
| As a percentage of total revenues | 10 | % |  | 8 | % |  |  |  |  |
| Selling, general and administrative | 128,093 |  |  | 128,596 |  |  | (503 | ) |  | (0.4 | )% |
| As a percentage of total revenues | 39 | % |  | 37 | % |  |  |  |  |
| Total operating expenses | $ | 161,807 |  |  | $ | 156,228 |  |  | $ | 5,579 |  |  | 4 | % |
| As a percentage of total revenues | 49 | % |  | 45 | % |  |  |  |  |
| Income (loss) from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 23,320 |  |  | $ | 40,047 |  |  | $ | (16,727 | ) |  | (42 | )% |
| Operating margin | 9 | % |  | 13 | % |  |  |  |  |
| Medication Adherence | (2,249 | ) |  | 4,548 |  |  | (6,797 | ) |  | (149 | )% |
| Operating margin | (4 | )% |  | 10 | % |  |  |  |  |
| Corporate Expenses | 40,711 |  |  | 42,861 |  |  | (2,150 | ) |  | (5 | )% |
| Total income (loss) from operations | $ | (19,640 | ) |  | $ | 1,734 |  |  | $ | (21,374 | ) |  | (1,233 | )% |
| Total operating margin | (6 | )% |  | 1 | % |  |  |  |  |

[0000926326-17-000032:mdna:100]
Research and Development. Research and development expenses increased by $6.1 million for the six months ended June 30, 2017 compared to the six months ended June 30, 2016. The increase was primarily driven by an increase of $3.4 million in our Medication Adherence segment, mainly due to the acquisition of Ateb in the fourth quarter of 2016, which accounted for $2.7 million of this segment's increase, and an increase of $2.0 million for the Automation and Analytics segment research and development expenses, primarily due to restructuring expenses.

[0000926326-17-000032:mdna:101]
Selling, General and Administrative.  Selling, general and administrative expenses decreased by $0.5 million for the six months ended June 30, 2017 compared to the six months ended June 30, 2016. The decrease was due to a $4.1 million decrease from our Automation and Analytics segment, and a decrease of $2.8 million in our corporate expenses, partially offset by an increase of $6.5 million in our Medication Adherence segment. The decrease in our Automation and Analytics segment was mainly due to lower amortization expense related to intangible assets and restructuring expenses as most restructuring activities related to this segment were concluded during the six months ended June 30, 2016. The decrease in our corporate expenses was mainly due to lower integration and acquisition related cost as well as an overall reduction in cost as part of cost saving initiatives. The increase in the Medication Adherence segment is attributed to Ateb, acquired in the fourth quarter of 2016, which contributed $5.7 million.

[0000926326-17-000032:mdna:102]
Operating Income (Loss). Operating income from our Automation and Analytics segment decreased by $16.7 million due to the lower gross margin of $19.0 million, partially offset by selling, general and administrative costs. Operating income from our Medication Adherence segment decreased by $6.8 million due to increased research and development and selling, general and administrative costs of $8.4 million attributed to Ateb, partially offset by higher gross margin of $3.1 million.

[0000926326-17-000032:mdna:103]
35

[0000926326-17-000032:mdna:104]
[same as prior period, unchanged from 0001628280-17-005045:mdna:87]

[0000926326-17-000032:mdna:105]
|  | Three months ended |
|  |  |  |  |  | Change in |
|  | June 30, 2017 |  | June 30, 2016 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (3,045 | ) |  | $ | (840 | ) |  | $ | (2,205 | ) |  | 263 | % |

[0000926326-17-000032:mdna:106]
|  | Six months ended |
|  |  |  |  |  | Change in |
|  | June 30, 2017 |  | June 30, 2016 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (11,983 | ) |  | $ | (781 | ) |  | $ | (11,202 | ) |  | 1,434 | % |

[0000926326-17-000032:mdna:107]
Our annual effective tax rate before discrete items was 41.1% and 38.3% for the six months ended June 30, 2017 and 2016, respectively. The increase in the estimated annual effective tax rate for the six months ended June 30, 2017 compared to the same period in 2016 was primarily due to changes in the mix of earnings with differing statutory rates and non-deductible equity charges offset by an increase in the Research & Development credits. Additionally, the Company adopted ASU 2016-09 effective January 1, 2017 and is now recognizing all excess tax benefits and tax deficiencies as income tax expense or benefit. An income tax benefit of approximately $0.8 million and $2.6 million was recognized in the first quarter of 2017 and for the six months ended June 30, 2017, respectively, as a result of the adoption of ASU 2016-09.

[0000926326-17-000032:mdna:108]
[same as prior period, unchanged from 0001628280-17-005045:mdna:91]

[0000926326-17-000032:mdna:109]
Our cash position and working capital at June 30, 2017 and December 31, 2016 were as follows:

[0000926326-17-000032:mdna:110]
|  | June 30, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 26,936 |  |  | $ | 54,488 |  |
| Working Capital | $ | 84,269 |  |  | $ | 134,496 |  |

[0000926326-17-000032:mdna:111]
All of our cash and cash equivalents for these periods were invested in bank demand deposits. Our ratio of current assets to current liabilities was 1.4:1 at June 30, 2017 compared to 1.7:1 at December 31, 2016.

[0000926326-17-000032:mdna:112]
[same as prior period, unchanged from 0001628280-17-005045:mdna:95]

[0000926326-17-000032:mdna:113]
On January 5, 2016, we entered into a $400 million secured credit facility pursuant to a credit agreement, by and among us, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as sole lead arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200 million term loan facility (the “Term Loan Facility”) and a $200 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes, including acquisitions. The Credit Agreement replaced our Credit Agreement, dated September 25, 2013, by and among the Company, the lenders from time to time party thereto and Wells Fargo Bank, National Association, as administrative agent, as amended.

[0000926326-17-000032:mdna:114]
Loans under the Facilities bear interest, at our option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on our Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit

[0000926326-17-000032:mdna:115]
participation fee ranging from 1.50% to 2.25% per annum based on our Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-17-000032:mdna:116]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us and our subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Credit Agreement also includes financial covenants requiring us not to exceed a maximum consolidated total leverage ratio of 3.00:1 (subject to certain exceptions) and to maintain a minimum fixed charge coverage ratio of 1.50:1.

[0000926326-17-000032:mdna:117]
As of June 30, 2017, the outstanding balance from the facilities (before netting deferred issuance cost) was $200.0 million. We were in full compliance with all covenants.

[0000926326-17-000032:mdna:118]
[same as prior period, unchanged from 0001628280-17-005045:mdna:100]

[0000926326-17-000032:mdna:119]
[same as prior period, unchanged from 0001628280-17-005045:mdna:101]

[0000926326-17-000032:mdna:120]
In accordance with the 2015 Avantec share purchase agreement, we agreed to make potential earn-out payments based on the achievement of bookings targets. Payments earned and paid during the year ended December 31, 2016 were $3.0 million and payments earned by but not yet paid to sellers as of June 30, 2017 were $2.4 million.

[0000926326-17-000032:mdna:121]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of June 30, 2017, which may result in additional use of cash.  See "Stock Repurchase Program" under Note 12. Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-17-000032:mdna:122]
[same as prior period, unchanged from 0001628280-17-005045:mdna:104]

[0000926326-17-000032:mdna:123]
[same as prior period, unchanged from 0001628280-17-005045:mdna:105]

[0000926326-17-000032:mdna:124]
The following table summarizes, for the periods indicated, selected items in our Condensed Consolidated Statements of Cash Flows (as adjusted for adoption of ASU 2016-09):

[0000926326-17-000032:mdna:125]
|  | Six months ended |
|  | June 30, 2017 |  | June 30, 2016 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 38,924 |  |  | $ | 16,887 |  |
| Investing activities | (17,847 | ) |  | (285,262 | ) |
| Financing activities | (47,355 | ) |  | 228,627 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,274 | ) |  | (1,440 | ) |
| Net decrease in cash and cash equivalents | $ | (27,552 | ) |  | $ | (41,188 | ) |

[0000926326-17-000032:mdna:126]
[same as prior period, unchanged from 0001628280-17-005045:mdna:108]

[0000926326-17-000032:mdna:127]
[same as prior period, unchanged from 0001628280-17-005045:mdna:109]

[0000926326-17-000032:mdna:128]
Net cash provided by operating activities was $38.9 million for the six months ended June 30, 2017, primarily as a result of the net loss of $9.9 million adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $25.9 million, and share-based compensation expense of $11.1 million and $0.8 million of amortization of debt financing fees. The net cash inflow which was contributed to changes in assets and liabilities include (i) an increase in accounts receivable of $0.8 million due to timing of collections, (ii) an increase in accounts payable of $23.4 million primarily due to the increase in inventory and timing of payments, (iii) an increase in

[0000926326-17-000032:mdna:129]
37

[0000926326-17-000032:mdna:130]
accrued compensation of $4.5 million as a result of employee bonus accrual, (iv) a decrease in deferred revenue of $2.9 million due to the timing of orders and revenue being recognized for installed product, and (v) a decrease in the net investment in sales-type leases of $5.5 million. These inflows were partially offset by a decrease in deferred income tax liabilities of $12.6 million and an increase in inventories of $12.2 million for inventory buildup in support of forecasted sales, particularly for the XT series.

[0000926326-17-000032:mdna:131]
Net cash provided by operating activities was $16.9 million for the six months ended June 30, 2016, primarily as a result of $1.5 million in net loss adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $29.2 million, share-based compensation expense of $9.4 million and $0.8 million of amortization of debt financing fees. The cash inflow attributable to changes in assets and liabilities includes (i) an increase in deferred revenue of $4.9 million due to timing of orders and revenue being recognized for installed product, (ii) an increase in accounts payables of $6.7 million due to the timing of payments, and (iii) decreases in other long term assets of $1.0 million and in other current assets of $0.1 million. These amounts were partially offset by an increase in inventories of $6.9 million to support forecasted sales, increases in long-term investment in sales-type leases of $6.6 million due to two significant lease transactions entered into during the quarter, an increase  in prepaid expenses of $4.9 million primarily due to prepaid income taxes, a decrease in the other-long term liabilities of $2.4 million, an increase in accounts receivable of $7.8 million due to increased product shipments late in the quarter, a decrease in deferred income taxes of $3.9 million and a decrease in accrued liabilities including compensation of $2.0 million due to timing of payments of employee-related liabilities.

[0000926326-17-000032:mdna:132]
[same as prior period, unchanged from 0001628280-17-005045:mdna:112]

[0000926326-17-000032:mdna:133]
Net cash used in investing activities was $17.8 million for the six months ended June 30, 2017, which consisted of capital expenditures of $6.5 million for property and equipment, $6.9 million for costs of software development mainly related to the Performance Center offering and purchase of intangibles, and $4.4 million attributable to the acquisition of InPharmics.

[0000926326-17-000032:mdna:134]
Net cash used in investing activities was $285.3 million for the six months ended June 30, 2016, $271.5 million of which was attributable to the acquisition of Aesynt, together with capital expenditures of $5.9 million for property and equipment and $7.9 million for costs of software development for external use and for purchases of intangibles.

[0000926326-17-000032:mdna:135]
[same as prior period, unchanged from 0001628280-17-005045:mdna:116]

[0000926326-17-000032:mdna:136]
Net cash used in financing activities was $47.4 million for the six months ended June 30, 2017, primarily from the repayment of $70.5 million of the credit facilities and $2.6 million in employees' taxes paid related to restricted stock unit vesting, partially offset by $15.8 million in proceeds from employee stock option exercises and employee stock plan purchases, and $10.0 million proceeds from term loan and revolving credit facilities.

[0000926326-17-000032:mdna:137]
Net cash provided by financing activities was $228.6 million for the six months ended June 30, 2016 as a result of proceeds from term loan and revolving credit facilities of $247.1 million, net of deferred issuance cost of $7.9 million, and $8.6 million in proceeds from employee stock option exercises and employee stock plan purchases. The increase in cash provided from financing activities was partially offset by repayment of $22.5 million of the revolving credit facility, payment of contingent consideration of $3.0 million related to the Avantec acquisition and $1.6 million in employees' taxes paid related to restricted stock units

[0000926326-17-000032:mdna:138]
[same as prior period, unchanged from 0001628280-17-005045:mdna:119]

[0000926326-17-000032:mdna:139]
There have been no significant changes during the six months ended June 30, 2017 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2016.

[0000926326-17-000032:mdna:140]
We had $344.3 million in contractual commitments to third parties for non-cancelable operating leases, commitments to contract manufacturers and suppliers, other purchase commitments and term loan and revolving credit facility as of June 30, 2017 as follows:

[0000926326-17-000032:mdna:141]
|  | Payments due by period |
|  | Total |  | Remainder of 2017 |  | 2018 and 2019 |  | 2020 and 2021 |  | Thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 83,447 |  |  | $ | 6,387 |  |  | $ | 24,661 |  |  | $ | 21,279 |  |  | $ | 31,120 |  |
| Purchase obligations (2) | 60,900 |  |  | 55,348 |  |  | 3,911 |  |  | 1,344 |  |  | 297 |  |
| Term loan facility (3) | 187,500 |  |  | 5,000 |  |  | 37,500 |  |  | 145,000 |  |  | — |  |
| Revolving credit facility (3) | 12,500 |  |  | — |  |  | — |  |  | 12,500 |  |  | — |  |
| Total (4) | $ | 344,347 |  |  | $ | 66,735 |  |  | $ | 66,072 |  |  | $ | 180,123 |  |  | $ | 31,417 |  |

[0000926326-17-000032:mdna:142]
[same as prior period, unchanged from 0001628280-17-005045:mdna:123]

[0000926326-17-000032:mdna:143]
[same as prior period, unchanged from 0001628280-17-005045:mdna:124]

[0000926326-17-000032:mdna:144]
[same as prior period, unchanged from 0001628280-17-005045:mdna:125]

[0000926326-17-000032:mdna:145]
| (3) | Amounts shown for term loan and revolving credit facility are principal repayments only. Due to use of interest rate swaps, the cash interest expense is partly variable and partly fixed, and is not reflected in the above table. Refer to Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this quarterly report. |

[0000926326-17-000032:mdna:146]
| (4) | We have recorded $7.0 million for uncertain tax positions under long-term liabilities as of June 30, 2017 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $7.0 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-17-000032:mdna:147]
[same as prior period, unchanged from 0001628280-17-005045:mdna:129]

[0000926326-17-000032:mdna:148]
As of June 30, 2017, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
