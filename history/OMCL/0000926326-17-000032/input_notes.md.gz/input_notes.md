# OMCL notes — 0000926326-17-000032


## omcl:ScheduleofLongTermNetInvestmentinSaleTypeLeasesTableTextBlock

[0000926326-17-000032:notes:1]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at June 30, 2017 and December 31, 2016:

[0000926326-17-000032:notes:2]
|  | June 30, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 27,553 |  |  | $ | 33,591 |  |
| Less: Unearned interest income portion | (2,206 | ) |  | (2,763 | ) |
| Net investment in sales-type leases | 25,347 |  |  | 30,828 |  |
| Less: Short-term portion(1) | (7,923 | ) |  | (10,243 | ) |
| Long-term net investment in sales-type leases | $ | 17,424 |  |  | $ | 20,585 |  |

[0000926326-17-000032:notes:3]
[same as prior period, unchanged from 0001628280-17-005045:notes:3]


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-17-000032:notes:4]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of June 30, 2017:

[0000926326-17-000032:notes:5]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 3,141 |  |
| Non-vested restricted share awards | 749 |  |
| Shares authorized for future issuance | 2,310 |  |
| ESPP shares available for future issuance | 2,572 |  |
| Total shares reserved for future issuance | 8,772 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-17-000032:notes:6]
[same as prior period, unchanged from 0001628280-17-005045:notes:6]

[0000926326-17-000032:notes:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2017 and December 31, 2016, the results of its operations, comprehensive income (loss) and cash flows for the three and six months ended June 30, 2017 and June 30, 2016. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2016 filed with the SEC on February 28, 2017. The Company's results of operations, comprehensive income (loss) and cash flows for the three and six months ended June 30, 2017 are not necessarily indicative of results that may be expected for the year ending December 31, 2017, or for any future period.


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-17-000032:notes:8]
[same as prior period, unchanged from 0001628280-17-005045:notes:8]

[0000926326-17-000032:notes:9]
On a recurring basis, we enter into sales-type lease transactions which vary in length from one to five years. The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at June 30, 2017 and December 31, 2016:

[0000926326-17-000032:notes:10]
The Company evaluates its sales-type leases individually and collectively for impairment.  The allowance for credit losses were $0.2 million and $0.3 million as of June 30, 2017 and of December 31, 2016, respectively.

[0000926326-17-000032:notes:11]
At June 30, 2017, the future minimum lease payments under sales-type leases are as follows:

[0000926326-17-000032:notes:12]
|  | June 30, 2017 |
|  | (In thousands) |
| Remaining six months of 2017 | $ | 4,967 |  |
| 2018 | 7,911 |  |
| 2019 | 5,915 |  |
| 2020 | 4,404 |  |
| 2021 | 2,647 |  |
| Thereafter | 1,709 |  |
| Total | $ | 27,553 |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-17-000032:notes:13]
Commitments and Contingencies

[0000926326-17-000032:notes:14]
Lease commitments

[0000926326-17-000032:notes:15]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At June 30, 2017, the minimum future payments on non-cancelable operating leases were as follows:

[0000926326-17-000032:notes:16]
|  | (In thousands) |
| Remaining six months of 2017 | $ | 6,387 |  |
| 2018 | 12,411 |  |
| 2019 | 12,250 |  |
| 2020 | 10,979 |  |
| 2021 | 10,300 |  |
| Thereafter | 31,120 |  |
| Total minimum future lease payments | $ | 83,447 |  |

[0000926326-17-000032:notes:17]
Purchase obligations

[0000926326-17-000032:notes:18]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At June 30, 2017, the Company had non-cancelable purchase commitments of $60.9 million, which are expected to be paid within the next twelve months.

[0000926326-17-000032:notes:19]
Legal Proceedings

[0000926326-17-000032:notes:20]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-17-000032:notes:21]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company's financial position or results of operations.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-17-000032:notes:22]
[same as prior period, unchanged from 0001628280-17-005045:notes:22]

[0000926326-17-000032:notes:23]
[same as prior period, unchanged from 0001628280-17-005045:notes:23]


## us-gaap:DebtDisclosureTextBlock

[0000926326-17-000032:notes:24]
Debt

[0000926326-17-000032:notes:25]
On January 5, 2016, the Company entered into a $400 million senior secured credit facility pursuant to a credit agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200 million (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-17-000032:notes:26]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the 2016 Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-17-000032:notes:27]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-17-000032:notes:28]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.

[0000926326-17-000032:notes:29]
On January 5, 2016, the Company borrowed the full $200.0 million under the Term Loan Facility and $55.0 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses. On December 2, 2016, the Company borrowed $40.0 million under the Revolving Credit Facility to complete the Ateb acquisition and pay related fees and expenses. On April 3, 2017, the Company borrowed an additional $10.0 million under the Revolving Credit Facility to pay for the InPhamics acquisition and fund its operations. As of June 30, 2017 the Company has repaid $105.0 million borrowed under these Facilities, which includes $70.5 million repaid during the six months ended June 30, 2017.

[0000926326-17-000032:notes:30]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement. Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

[0000926326-17-000032:notes:31]
In connection with these Facilities, the Company incurred $7.9 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.5 million and $1.2 million for the three months ended June 30, 2017 and 2016, respectively. Interest expense (exclusive of fees and issuance cost amortization) was approximately $3.0 million and $2.8 million for the six months ended June 30, 2017 and 2016, respectively. The Company was in full compliance with all covenants as of June 30, 2017 and December 31, 2016.

[0000926326-17-000032:notes:32]
The components of the Company’s debt obligations for the six months ended June 30, 2017 are as follows:

[0000926326-17-000032:notes:33]
|  | December 31, 2016 |  | Borrowings |  | Repayment / Amortization |  | June 30, 2017 |
|  | (In thousands) |
| Term loan facility | $ | 192,500 |  |  | $ | — |  |  | $ | (5,000 | ) |  | $ | 187,500 |  |
| Revolving credit facility | 68,000 |  |  | 10,000 |  |  | (65,500 | ) |  | 12,500 |  |
| Total debt under the facilities | 260,500 |  |  | 10,000 |  |  | (70,500 | ) |  | 200,000 |  |
| Less: Deferred issuance cost | (6,359 | ) |  | — |  |  | 795 |  |  | (5,564 | ) |
| Total Debt, net of deferred issuance cost | $ | 254,141 |  |  | $ | 10,000 |  |  | $ | (69,705 | ) |  | $ | 194,436 |  |
| Long term debt, current portion, net of deferred issuance cost | 8,410 |  |  |  |  |  |  | 10,910 |  |
| Long term debt, net of deferred issuance cost | $ | 245,731 |  |  |  |  |  |  | $ | 183,526 |  |

[0000926326-17-000032:notes:34]
As of June 30, 2017, the carrying amount of debt of $200.0 million approximates the comparable fair value of $200.9 million. The Company's debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments, and long-term credit ratings.


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-17-000032:notes:35]
[same as prior period, unchanged from 0001628280-17-005045:notes:35]

[0000926326-17-000032:notes:36]
Short-term deferred revenue includes deferred revenue from product sales and service contracts, net of deferred cost of sales of $13.9 million and $14.2 million as of June 30, 2017 and December 31, 2016, respectively. The short-term deferred revenues from product sales relate to the delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

[0000926326-17-000032:notes:37]
Long-term deferred revenue includes deferred revenue from service contracts of $16.3 million and $17.1 million, as of June 30, 2017 and December 31, 2016, respectively.


## us-gaap:EarningsPerShareTextBlock

[0000926326-17-000032:notes:38]
Net Income (Loss) Per Share

[0000926326-17-000032:notes:39]
Basic net income (loss) per share is computed by dividing net income (loss) for the period by the weighted-average number of shares outstanding during the period, less shares repurchased. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Any anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share.

[0000926326-17-000032:notes:40]
The basic and diluted net income (loss) per share calculation for the three and six months ended June 30, 2017 and 2016 is as follows:

[0000926326-17-000032:notes:41]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | 837 |  |  | $ | (1,159 | ) |  | $ | (9,917 | ) |  | $ | (1,537 | ) |
| Weighted-average shares outstanding — basic | 37,250 |  |  | 35,987 |  |  | 37,046 |  |  | 35,864 |  |
| Effect of dilutive securities from stock award plans | 1,120 |  |  | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding — diluted | $ | 38,370 |  |  | $ | 35,987 |  |  | $ | 37,046 |  |  | 35,864 |  |
| Net income (loss) per share - basic | $ | 0.02 |  |  | $ | (0.03 | ) |  | $ | (0.27 | ) |  | $ | (0.04 | ) |
| Net income (loss) per share - diluted | $ | 0.02 |  |  | $ | (0.03 | ) |  | $ | (0.27 | ) |  | $ | (0.04 | ) |
| Anti-dilutive weighted-average shares related to stock award plans | 2,121 |  |  | 1,961 |  |  | 4,039 |  |  | 2,037 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-17-000032:notes:42]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of June 30, 2017:

[0000926326-17-000032:notes:43]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 1,274 |  |  | $ | — |  |  | $ | 1,274 |  |
| Total financial assets | $ | — |  |  | $ | 1,274 |  |  | $ | — |  |  | $ | 1,274 |  |
| Contingent consideration liability | $ | — |  |  | $ | — |  |  | $ | 2,400 |  |  | $ | 2,400 |  |
| Total financial liabilities | $ | — |  |  | $ | — |  |  | $ | 2,400 |  |  | $ | 2,400 |  |

[0000926326-17-000032:notes:44]
There have been no transfers between fair value measurement levels during the six months ended June 30, 2017 and June 30, 2016.

[0000926326-17-000032:notes:45]
[same as prior period, unchanged from 0001628280-17-005045:notes:45]

[0000926326-17-000032:notes:46]
[same as prior period, unchanged from 0001628280-17-005045:notes:46]


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-17-000032:notes:47]
[same as prior period, unchanged from 0001628280-17-005045:notes:47]

[0000926326-17-000032:notes:48]
Cash and cash equivalents of $26.9 million and $54.5 million as of June 30, 2017 and December 31, 2016, respectively, consisted of demand deposits only.

[0000926326-17-000032:notes:49]
[same as prior period, unchanged from 0001628280-17-005045:notes:49]

[0000926326-17-000032:notes:50]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's foreign currency contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments. In accordance with the 2015 Avantec share purchase agreement, the Company agreed to make potential earn-out payments of $3.0 million based on the achievement of bookings targets. The Company has concluded that as of June 30, 2017 only $2.4 million of the total potential earn out payment has been earned and will be paid out. The Company's contingent consideration liability is classified within Level 3, as original valuation inputs, which include the achievement of booking targets and the discount rate, were unobservable in the market and significant to the instrument's valuation.

[0000926326-17-000032:notes:51]
[same as prior period, unchanged from 0001628280-17-005045:notes:51]

[0000926326-17-000032:notes:52]
[same as prior period, unchanged from 0001628280-17-005045:notes:52]

[0000926326-17-000032:notes:53]
[same as prior period, unchanged from 0001628280-17-005045:notes:53]

[0000926326-17-000032:notes:54]
During 2016, the Company entered into an interest rate swap agreement with a combined notional amount of $100.0 million with one counter-party that became effective on June 30, 2016 and is maturing on April 30, 2019. The swap agreement requires the Company to pay a fixed rate of 0.8% and provides that the Company will receive a variable rate based on the one month LIBOR rate subject to a LIBOR floor of 0.0%. Amounts payable by or due to the Company will be net settled with the respective counter-party on the last business day of each month, commencing July 31, 2016.

[0000926326-17-000032:notes:55]
The fair value of the interest rate swap agreements at June 30, 2017 and December 31, 2016 was $1.3 million and $1.2 million, respectively. There were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.


## us-gaap:FiniteLivedAndIndefiniteLivedIntangibleAssetsAcquiredAsPartOfBusinessCombinationTableTextBlock

[0000926326-17-000032:notes:56]
[same as prior period, unchanged from 0001628280-17-005045:notes:56]

[0000926326-17-000032:notes:57]
[same as prior period, unchanged from 0001628280-17-005045:notes:57]

[0000926326-17-000032:notes:58]
[same as prior period, unchanged from 0001628280-17-005045:notes:58]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-17-000032:notes:59]
[same as prior period, unchanged from 0001628280-17-005045:notes:59]

[0000926326-17-000032:notes:60]
[same as prior period, unchanged from 0001628280-17-005045:notes:60]

[0000926326-17-000032:notes:61]
[same as prior period, unchanged from 0001628280-17-005045:notes:61]

[0000926326-17-000032:notes:62]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2016 | $ | 215,082 |  |  | $ | 112,642 |  |  | $ | 327,724 |  |
| Goodwill acquired | 3,113 |  |  | 63 |  |  | 3,176 |  |
| Foreign currency exchange rate fluctuations | 1,592 |  |  | 504 |  |  | 2,096 |  |
| Net balance as of June 30, 2017 | $ | 219,787 |  |  | $ | 113,209 |  |  | $ | 332,996 |  |

[0000926326-17-000032:notes:63]
Goodwill acquired in the Automation and Analytics segment represents the value assigned to goodwill as part of the InPharmics acquisition. Goodwill acquired in the Medication Adherence segment represents adjustments to the preliminary value assigned to goodwill in connection with Ateb acquisition to reflect measurement period adjustments related to accounts receivable.

[0000926326-17-000032:notes:64]
[same as prior period, unchanged from 0001628280-17-005045:notes:63]

[0000926326-17-000032:notes:65]
The carrying amounts of intangibles assets as of June 30, 2017 and December 31, 2016 are as follows:

[0000926326-17-000032:notes:66]
|  | June 30, 2017 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 132,744 |  |  | $ | (27,182 | ) |  | $ | 459 |  |  | $ | 106,021 |  |  | 1 - 30 |
| Acquired technology | 74,188 |  |  | (17,346 | ) |  | 158 |  |  | 57,000 |  |  | 3 - 20 |
| Backlog | 21,689 |  |  | (15,689 | ) |  | — |  |  | 6,000 |  |  | 1 - 5 |
| Trade names | 8,619 |  |  | (4,272 | ) |  | 29 |  |  | 4,376 |  |  | 1 - 12 |
| Patents | 3,226 |  |  | (1,283 | ) |  | 24 |  |  | 1,967 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (958 | ) |  | — |  |  | 942 |  |  | 3 |
| In-process technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | — |
| Total intangibles assets, net | $ | 246,266 |  |  | $ | (66,730 | ) |  | $ | 670 |  |  | $ | 180,206 |  |  |  |

[0000926326-17-000032:notes:67]
[same as prior period, unchanged from 0001628280-17-005045:notes:66]

[0000926326-17-000032:notes:68]
Amortization expense of intangible assets was $6.8 million and $9.1 million for the three months ended June 30, 2017 and 2016, respectively. Amortization expense of intangible assets was $13.0 million and $18.3 million for the six months ended June 30, 2017 and 2016, respectively.

[0000926326-17-000032:notes:69]
[same as prior period, unchanged from 0001628280-17-005045:notes:68]

[0000926326-17-000032:notes:70]
|  | June 30, 2017 |
|  | (In thousands) |
| Remaining six months of 2017 | $ | 12,514 |  |
| 2018 | 23,293 |  |
| 2019 | 17,828 |  |
| 2020 | 16,624 |  |
| 2021 | 15,053 |  |
| Thereafter (excluding in-process technology) | 90,994 |  |
| Total | $ | 176,306 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-17-000032:notes:71]
[same as prior period, unchanged from 0001628280-17-005045:notes:70]

[0000926326-17-000032:notes:72]
The Company provides for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 41.1% and 38.3% for the six months ended June 30, 2017 and 2016, respectively.

[0000926326-17-000032:notes:73]
The 2017 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, foreign rate differential, and non-deductible equity charges, which were partially offset by the domestic production activities deduction and the Research & Development credits. The 2016 annual effective tax rate differed from the statutory rate of 35% primarily due to the favorable impact of the IRS settlement and release of tax reserves, the domestic production activities deduction, Research & Development credits and a calculated benefit in state income taxes, offset by unfavorable items such as non-deductible transaction costs related to the Aesynt transaction, and non-deductible equity charges under ASC 740-718.

[0000926326-17-000032:notes:74]
As of June 30, 2017 and December 31, 2016, the Company had gross unrecognized tax benefits of $7.0 million and $6.5 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in operating expense. As of June 30, 2017 and December 31, 2016, the amount of accrued interest and penalties was $1.1 million and $0.7 million, respectively.

[0000926326-17-000032:notes:75]
As of June 30, 2017, calendar years 2011 and thereafter are open and subject to potential examination in one or more jurisdictions. However, our research credit carryforwards that may be used in future years are subject to adjustment, if and when utilized. As such our federal and California tax years remain open from 2015 and 1992, respectively.  During fiscal 2016, the Internal Revenue Service and the Company settled all outstanding items related to the audit of the Company's federal income tax returns for the fiscal year ended December 31, 2014.

[0000926326-17-000032:notes:76]
[same as prior period, unchanged from 0001628280-17-005045:notes:75]


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000926326-17-000032:notes:77]
[same as prior period, unchanged from 0001628280-17-005045:notes:76]

[0000926326-17-000032:notes:78]
|  | June 30, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| United States | $ | 35,041 |  |  | $ | 36,497 |  |
| Rest of world (1) | 5,672 |  |  | 5,514 |  |
| Total property and equipment, net | $ | 40,713 |  |  | $ | 42,011 |  |

[0000926326-17-000032:notes:79]
[same as prior period, unchanged from 0001628280-17-005045:notes:78]

[0000926326-17-000032:notes:80]
[same as prior period, unchanged from 0001628280-17-005045:notes:79]


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000926326-17-000032:notes:81]
[same as prior period, unchanged from 0001628280-17-005045:notes:80]

[0000926326-17-000032:notes:82]
2017 Acquisitions

[0000926326-17-000032:notes:83]
On April 12, 2017, the Company completed the acquisition of all of the membership interest of Dixie Drawl, LLC d/b/a InPharmics ("InPharmics") pursuant to InPharmics' Member Interest Purchase Agreement. InPharmics is a technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies. The total consideration for the transaction was $5.0 million, net of cash on hand at signing of $0.3 million. Approximately $0.5 million of the total consideration was classified as a long-term liability for potential settlement of performance obligations. The Company accounted for the acquisition of InPharmics in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition date. The purchase price was preliminary allocated to intangible assets in the amount of $1.9 million, which included developed technology and customer contracts, with the remainder allocated to goodwill. The results of the InPharmics' operations have been included in our consolidated results of operations, and presented as part of the Automation and Analytics segment.

[0000926326-17-000032:notes:84]
2016 Acquisitions

[0000926326-17-000032:notes:85]
On January 5, 2016, the Company completed the acquisition of all of the membership interests of Aesynt pursuant to the Aesynt Securities Purchase Agreement. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics, and software, including software related to medication management. The total consideration was $271.5 million, net of cash on hand at signing of $8.2 million. The results of Aesynt's operations have been included in the Company's consolidated results of operations as of the time of the acquisition, and presented as part of the Automation & Analytics segment.

[0000926326-17-000032:notes:86]
On December 8, 2016, the Company completed its acquisition of ateb, Inc., and Ateb Canada Ltd. (together, “Ateb”) pursuant to Ateb's Securities Purchase Agreement for $40.7 million of cash consideration, net of $0.9 million cash on hand. The cash consideration, included the repayment of Ateb indebtedness and other adjustments provided for in the Ateb's Securities Purchase Agreement.  Ateb is a provider of pharmacy-based patient care solutions and the medication synchronization solutions leader to independent and chain pharmacies. The results of Ateb's operations have been included in the Company's consolidated results of operations as of the time of the acquisition, and presented as part of the Medication Adherence segment.

[0000926326-17-000032:notes:87]
[same as prior period, unchanged from 0001628280-17-005045:notes:83]

[0000926326-17-000032:notes:88]
[same as prior period, unchanged from 0001628280-17-005045:notes:84]

[0000926326-17-000032:notes:89]
|  | Aesynt |  | Ateb(preliminary) |  | Total |
|  | (in thousands) |
| Cash | $ | 8,164 |  |  | $ | 902 |  |  | $ | 9,066 |  |
| Accounts receivable | 43,312 |  |  | 7,842 |  |  | 51,154 |  |
| Inventory | 19,021 |  |  | 225 |  |  | 19,246 |  |
| Other current assets | 3,787 |  |  | 1,239 |  |  | 5,026 |  |
| Total current assets | 74,284 |  |  | 10,208 |  |  | 84,492 |  |
| Property and equipment | 10,389 |  |  | 2,447 |  |  | 12,836 |  |
| Intangibles | 123,700 |  |  | 12,500 |  |  | 136,200 |  |
| Goodwill | 163,599 |  |  | 20,895 |  |  | 184,494 |  |
| Other non-current assets | 968 |  |  | 1,009 |  |  | 1,977 |  |
| Total assets | 372,940 |  |  | 47,059 |  |  | 419,999 |  |
| Current liabilities | 26,753 |  |  | 2,314 |  |  | 29,067 |  |
| Deferred revenue | 25,512 |  |  | 2,776 |  |  | 28,288 |  |
| Non-current deferred tax liabilities | 38,622 |  |  | — |  |  | 38,622 |  |
| Other non-current liabilities | 2,431 |  |  | 367 |  |  | 2,798 |  |
| Total liabilities | 93,318 |  |  | 5,457 |  |  | 98,775 |  |
| Total purchase price | $ | 279,622 |  |  | $ | 41,602 |  |  | $ | 321,224 |  |
| Total purchase price, net of cash received | $ | 271,458 |  |  | $ | 40,700 |  |  | $ | 312,158 |  |

[0000926326-17-000032:notes:90]
[same as prior period, unchanged from 0001628280-17-005045:notes:86]

[0000926326-17-000032:notes:91]
The $20.9 million of goodwill arising from the Ateb acquisition is primarily attributed to sales of future products and services and Ateb's assembled workforce.

[0000926326-17-000032:notes:92]
[same as prior period, unchanged from 0001628280-17-005045:notes:88]

[0000926326-17-000032:notes:93]
[same as prior period, unchanged from 0001628280-17-005045:notes:89]

[0000926326-17-000032:notes:94]
[same as prior period, unchanged from 0001628280-17-005045:notes:90]

[0000926326-17-000032:notes:95]
The fair value of trade names, acquired developed technology, and acquired IPR&D was determined based on an income approach using the relief-from-royalty method at the royalty rates of 0.5%, 4% to 8% and 12.5%, respectively. The fair value of customer relationships, backlog, and non-compete intangible assets were determined based on an income approach using the discounted cash flow method, at the discounted rates of 13%, 10% and13%, respectively. The intangible assets, except customer relationship and IPR&D, are being amortized over their estimated useful lives using the straight line method of amortization. The customer relationship intangible asset is being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. In accordance with authoritative guidance, the IPR&D is accounted for as an indefinite-lived intangible asset until completion or abandonment of the associated research and development efforts. IPR&D is tested for impairment during the period it is considered an indefinite lived asset. IPR&D related projects are expected to be completed in two to three years. As of June 30, 2017, none of the IPR&D projects have been completed, and they have progressed as previously estimated.

[0000926326-17-000032:notes:96]
[same as prior period, unchanged from 0001628280-17-005045:notes:92]

[0000926326-17-000032:notes:97]
[same as prior period, unchanged from 0001628280-17-005045:notes:93]

[0000926326-17-000032:notes:98]
[same as prior period, unchanged from 0001628280-17-005045:notes:94]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-17-000032:notes:99]
Recently adopted authoritative guidance

[0000926326-17-000032:notes:100]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. The Company adopted the standard effective January 1, 2017.  The impact of adoption was the recording of excess tax benefits within income tax expense, rather than in Additional Paid in Capital of $0.8 million and $2.6 million for the three and six months ended June 30, 2017, respectively.  Additionally, in the first quarter of 2017, the Company recognized the previously unrecognized excess tax benefits using the modified retrospective transition method, which resulted in a cumulative-effect adjustment of $1.6 million to retained earnings.

[0000926326-17-000032:notes:101]
In January 2017, the FASB issued ASU 2017-04, Intangibles-Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment, which simplifies the accounting for goodwill impairment for all entities by requiring impairment charges to be based on the first step in today’s two-step impairment test under ASC 350, “Intangibles-Goodwill and Other.” Under the new guidance, if a reporting unit’s carrying amount exceeds its fair value, an entity will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill allocated to that reporting unit. The standard eliminates the current ASC 350 requirement to calculate a goodwill impairment charge using Step 2. ASU 2017-14 is effective for annual and interim impairment tests performed in periods beginning after December 15, 2019. Early adoption is permitted for annual and interim goodwill impairment testing dates after January 1, 2017. The Company adopted ASU 2017-04 effective January 1, 2017. The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the period presented.

[0000926326-17-000032:notes:102]
In January 2017, the FASB issued ASU 2017-01, Business Combinations, which clarifies the definition of a business and provides a screen to determine when a set of assets and activities is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set is not a business. This screen reduces the number of transactions that need to be further evaluated. ASU 2017-01 is effective for fiscal years beginning after December 15, 2017, with early adoption permitted.  The Company adopted ASU 2017-01 effective January 1, 2017.  The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the period presented.

[0000926326-17-000032:notes:103]
Recently issued authoritative guidance

[0000926326-17-000032:notes:104]
In May 2014, the FASB issued ASU 2014-09-Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, accordingly, it is possible more judgment and estimates may be required within the revenue recognition process than is required under existing U.S. GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. The FASB has recently issued several amendments to ASU 2014-09, including clarification on accounting for licenses of intellectual property and identifying performance obligations. ASU 2014-09 will be effective for the Company beginning January 1, 2018.

[0000926326-17-000032:notes:105]
The two permitted transition methods under ASU 2014-09 are the full retrospective method, in which case ASU 2014-09 would be applied to each prior reporting period presented and the cumulative effect of applying ASU 2014-09 would be recognized at the earliest period shown, or the modified retrospective method, in which case the cumulative effect of applying ASU 2014-09 would be recognized at the date of initial application. While the Company currently expects to apply the full retrospective method, the Company is continuing to evaluate the availability of information and resources necessary and may decide the benefit of applying the full retrospective method is not significant enough to support the cost.

[0000926326-17-000032:notes:106]
Currently, the Company is in the process of reviewing its historical contracts to quantify the impact on its consolidated financial statements. The most significant impact of the standard relates to accounting for term software license revenue, contingent income, and commission expense.  Specifically, under the standard the Company expects to recognize revenue on term software licenses upon installation of the license rather than ratably over the life of the term license.  Additionally, the standard no longer requires deferral of contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price which will result in earlier recognition of revenue.  Finally, the standard requires expense to be recognized for incremental costs incurred to obtain a contract, primarily commission expense, on a systematic basis that is consistent with the transfer to the customer of the product and services to which the cost relates.  Rather than recognize commission expense at the time of recognizing the related product revenue, the new standard will require commission expense to be recognized consistent with the timing of product and service revenue, including an estimate of the period of service renewals for the transaction.  The company is also in the process of assessing the appropriate changes to its business processes and upgrading its systems and controls to support recognition and disclosure under ASU 2014-09. The Company expects to complete its assessment process within the next two quarters of 2017.

[0000926326-17-000032:notes:107]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company's Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0000926326-17-000032:notes:108]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards ("RSAs") |  |  |  |
| Outstanding at December 31, 2016 | 30 |  |  | $ | 31.57 |  |
| Granted | 24 |  |  | 41.10 |  |
| Vested | (30 | ) |  | 31.58 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at June 30, 2017 | 24 |  |  | $ | 41.03 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-17-000032:notes:109]
[same as prior period, unchanged from 0001628280-17-005045:notes:104]

[0000926326-17-000032:notes:110]
[same as prior period, unchanged from 0001628280-17-005045:notes:105]

[0000926326-17-000032:notes:111]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication, supply control systems and medication adherence solutions which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States and Europe. "Omnicell", "our", "us", "we" or the "Company" collectively refer to Omnicell, Inc. and its subsidiaries.

[0000926326-17-000032:notes:112]
[same as prior period, unchanged from 0001628280-17-005045:notes:107]

[0000926326-17-000032:notes:113]
Additionally, see "Recently adopted authoritative guidance" for the effects of first quarter adoption of ASU 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting.

[0000926326-17-000032:notes:114]
[same as prior period, unchanged from 0001628280-17-005045:notes:109]

[0000926326-17-000032:notes:115]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company's Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company's critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, accounts receivable and notes receivable from investment in sales-type leases, inventory valuation, capitalized software development costs, valuation and impairment of goodwill, purchased intangibles and long-lived assets, fair value of assets acquired and liabilities assumed in business combination, share-based compensation, and accounting for income taxes.

[0000926326-17-000032:notes:116]
[same as prior period, unchanged from 0001628280-17-005045:notes:111]

[0000926326-17-000032:notes:117]
[same as prior period, unchanged from 0001628280-17-005045:notes:112]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-17-000032:notes:118]
[same as prior period, unchanged from 0001628280-17-005045:notes:113]

[0000926326-17-000032:notes:119]
On February 15, 2017, the Company announced its plan to reduce its workforce by approximately 100 full-time employees and close the Company’s Nashville, Tennessee and Slovenia facilities.  The plan is expected to be completed in fiscal year 2017. The estimated total cost for the plan is $4.9 million, which includes estimated employee severance cost of approximately $3.8 million, and facility-related costs of approximately $1.1 million.

[0000926326-17-000032:notes:120]
During the six months ended June 30, 2017, the Company accrued $3.8 million of severance and related expenses, and paid out $3.1 million.  The remaining unpaid balance of $0.7 million accrued severance and related expenses as of June 30, 2017 is presented as a component of accrued compensation in the Condensed Consolidated Balance Sheet.

[0000926326-17-000032:notes:121]
There were $0.6 million of facility-related costs incurred during the six months ended June 30, 2017, of which $0.1 million was paid out. The remaining unpaid balance of $0.5 million accrued facilities-related expenses as of June 30, 2017 is presented as a component of accrued liabilities in the Condensed Consolidated Balance Sheet.

[0000926326-17-000032:notes:122]
The following table summarizes the restructuring expense recorded in each reportable segment and income statement classification for the three months and six months ended June 30, 2017.

[0000926326-17-000032:notes:123]
|  | Three months ended |  | Six months ended |
|  | June 30, 2017 |  | June 30, 2017 |
|  | Automation and Analytics |  | Medication Adherence |  | Corporate |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Corporate |  | Total |
|  | (in thousands) |
| Cost of revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,266 |  |  | $ | 431 |  |  | $ | — |  |  | $ | 1,697 |  |
| Research and development | 485 |  |  | — |  |  | 102 |  |  | 587 |  |  | 1,491 |  |  | 62 |  |  | 102 |  |  | 1,655 |  |
| Selling, general and administrative | — |  |  | — |  |  | 16 |  |  | 16 |  |  | 480 |  |  | 103 |  |  | 433 |  |  | 1,016 |  |
| Restructuring and related expense | $ | 485 |  |  | $ | — |  |  | $ | 118 |  |  | $ | 603 |  |  | $ | 3,237 |  |  | $ | 596 |  |  | $ | 535 |  |  | $ | 4,368 |  |

[0000926326-17-000032:notes:124]
During the second quarter of 2016, the Company integrated its Sales and Field organizations in North America to better serve its customers which resulted in a reduction in headcount of 36 employees. Accordingly, the Company incurred approximately $1.7 million of restructuring expenses in the second quarter ending June 30, 2016, based on agreements with terminated employees covering salary and benefit continuation. As of June 30, 2016 the restructuring program has been concluded.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000926326-17-000032:notes:125]
[same as prior period, unchanged from 0001628280-17-005045:notes:117]

[0000926326-17-000032:notes:126]
|  | Three months ended |
|  | June 30, 2017 |  | June 30, 2016 |
|  | (In thousands) |
| United States | $ | 153,285 |  |  | $ | 145,988 |  |
| Rest of world (1) | 27,600 |  |  | 26,919 |  |
| Total revenues | $ | 180,885 |  |  | $ | 172,907 |  |

[0000926326-17-000032:notes:127]
|  | Six months ended |
|  | June 30, 2017 |  | June 30, 2016 |
|  | (In thousands) |
| United States | $ | 285,565 |  |  | $ | 289,481 |  |
| Rest of world (1) | 45,874 |  |  | 54,430 |  |
| Total revenues | $ | 331,439 |  |  | $ | 343,911 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000926326-17-000032:notes:128]
The following tables summarize the changes in accumulated balances of other comprehensive income (loss) for the three and six months ended June 30, 2017 and 2016:

[0000926326-17-000032:notes:129]
|  | Three months ended June 30, |
|  | 2017 |  | 2016 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (9,841 | ) |  | $ | 1,427 |  |  | $ | (8,414 | ) |  | $ | (3,057 | ) |  | $ | — |  |  | $ | (3,057 | ) |
| Other comprehensive income (loss) before reclassifications | 1,076 |  |  | (100 | ) |  | 976 |  |  | (4,467 | ) |  | — |  |  | (4,467 | ) |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (53 | ) |  | (53 | ) |  | — |  |  | — |  |  | — |  |
| Net current-period other comprehensive income (loss), net of tax | 1,076 |  |  | (153 | ) |  | 923 |  |  | (4,467 | ) |  | — |  |  | (4,467 | ) |
| Ending balance | $ | (8,765 | ) |  | $ | 1,274 |  |  | $ | (7,491 | ) |  | $ | (7,524 | ) |  | $ | — |  |  | $ | (7,524 | ) |

[0000926326-17-000032:notes:130]
|  | Six months ended June 30, |
|  | 2017 |  | 2016 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |  |  |  |  |  |  |
| Beginning balance | $ | (10,764 | ) |  | $ | 1,245 |  |  | $ | (9,519 | ) |  | $ | (2,730 | ) |  | $ | — |  |  | $ | (2,730 | ) |
| Other comprehensive income (loss) before reclassifications | 1,999 |  |  | 76 |  |  | 2,075 |  |  | (4,794 | ) |  | — |  |  | (4,794 | ) |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (47 | ) |  | (47 | ) |  | — |  |  | — |  |  | — |  |
| Net current-period other comprehensive income (loss), net of tax | 1,999 |  |  | 29 |  |  | 2,028 |  |  | (4,794 | ) |  | — |  |  | (4,794 | ) |
| Ending balance | $ | (8,765 | ) |  | $ | 1,274 |  |  | $ | (7,491 | ) |  | $ | (7,524 | ) |  | $ | — |  |  | $ | (7,524 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-17-000032:notes:131]
Balance sheet details as of June 30, 2017 and December 31, 2016 are presented in the tables below:

[0000926326-17-000032:notes:132]
|  | June 30, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 16,959 |  |  | $ | 14,322 |  |
| Work in process | 7,834 |  |  | 7,800 |  |
| Finished goods | 56,730 |  |  | 47,175 |  |
| Total inventories | $ | 81,523 |  |  | $ | 69,297 |  |
| Prepaid expense |  |  |  |
| Prepaid commissions | $ | 10,658 |  |  | $ | 13,176 |  |
| Other prepaid expenses | 15,343 |  |  | 15,470 |  |
| Total prepaid expense | $ | 26,001 |  |  | $ | 28,646 |  |
| Property and equipment: |  |  |  |
| Equipment | $ | 67,561 |  |  | $ | 64,384 |  |
| Furniture and fixtures | 6,666 |  |  | 6,517 |  |
| Leasehold improvements | 9,436 |  |  | 9,778 |  |
| Software | 36,712 |  |  | 35,607 |  |
| Construction in progress | 9,287 |  |  | 7,211 |  |
| Property and equipment, gross | 129,662 |  |  | 123,497 |  |
| Accumulated depreciation and amortization | (88,949 | ) |  | (81,486 | ) |
| Total property and equipment, net | $ | 40,713 |  |  | $ | 42,011 |  |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 35,461 |  |  | $ | 33,233 |  |
| Other assets | 1,493 |  |  | 1,818 |  |
| Total other long term assets, net | $ | 36,954 |  |  | $ | 35,051 |  |

[0000926326-17-000032:notes:133]
|  | June 30, 2017 |  | December 31, 2016 |
| Accrued liabilities: |  |  |  |
| Advance payments from customers | $ | 8,588 |  |  | $ | 7,030 |  |
| Rebates and lease buyouts | 5,359 |  |  | 4,025 |  |
| Group purchasing organization fees | 3,068 |  |  | 3,737 |  |
| Taxes payable | 3,818 |  |  | 4,003 |  |
| Other accrued liabilities | 10,061 |  |  | 12,400 |  |
| Total accrued liabilities | $ | 30,894 |  |  | $ | 31,195 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0000926326-17-000032:notes:134]
[same as prior period, unchanged from 0001628280-17-005045:notes:125]

[0000926326-17-000032:notes:135]
|  | Three months ended |  | Six months ended |
|  | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 845 |  |  | $ | 644 |  |  | $ | 1,827 |  |  | $ | 1,193 |  |
| Research and development | 810 |  |  | 801 |  |  | 1,707 |  |  | 1,442 |  |
| Selling, general and administrative | 3,890 |  |  | 4,050 |  |  | 7,522 |  |  | 6,751 |  |
| Total share-based compensation expense | $ | 5,545 |  |  | $ | 5,495 |  |  | $ | 11,056 |  |  | $ | 9,386 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0000926326-17-000032:notes:136]
The following table summarizes the restricted stock activity under the Company’s equity incentive plans during the six months ended June 30, 2017:

[0000926326-17-000032:notes:137]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units ("RSUs") |  |  |  |  |  |  |  |
| Outstanding at December 31, 2016 | 505 |  |  | $ | 31.42 |  |  | 1.6 |  | $ | 17,135 |  |
| Granted | 86 |  |  | 37.21 |  |  |  |  |  |
| Vested | (96 | ) |  | 28.88 |  |  |  |  |  |
| Forfeited | (11 | ) |  | 32.17 |  |  |  |  |  |
| Outstanding and unvested at June 30, 2017 | 484 |  |  | $ | 32.93 |  |  | 1.4 |  | $ | 20,901 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-17-000032:notes:138]
The following tables summarize the financial performance of the Company's reportable segments, including a reconciliation of income from segment operations to income from total operations:

[0000926326-17-000032:notes:139]
|  | Three months ended |
|  | June 30, 2017 |  | June 30, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 148,427 |  |  | $ | 32,458 |  |  | $ | 180,885 |  |  | $ | 148,660 |  |  | $ | 24,247 |  |  | $ | 172,907 |  |
| Cost of revenues | 80,716 |  |  | 22,194 |  |  | 102,910 |  |  | 78,366 |  |  | 16,524 |  |  | 94,890 |  |
| Gross profit | 67,711 |  |  | 10,264 |  |  | 77,975 |  |  | 70,294 |  |  | 7,723 |  |  | 78,017 |  |
| Operating expenses | 49,054 |  |  | 10,099 |  |  | 59,153 |  |  | 49,780 |  |  | 5,771 |  |  | 55,551 |  |
| Income (loss) from segment operations | $ | 18,657 |  |  | $ | 165 |  |  | $ | 18,822 |  |  | $ | 20,514 |  |  | $ | 1,952 |  |  | $ | 22,466 |  |
| Corporate costs |  |  |  |  | 21,226 |  |  |  |  |  |  | 22,584 |  |
| Income (loss) from operations |  |  |  |  | $ | (2,404 | ) |  |  |  |  |  | $ | (118 | ) |

[0000926326-17-000032:notes:140]
|  | Six months ended |
|  | June 30, 2017 |  | June 30, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 272,598 |  |  | $ | 58,841 |  |  | $ | 331,439 |  |  | $ | 297,605 |  |  | $ | 46,306 |  |  | $ | 343,911 |  |
| Cost of revenues | 149,477 |  |  | 39,795 |  |  | 189,272 |  |  | 155,573 |  |  | 30,376 |  |  | 185,949 |  |
| Gross profit | 123,121 |  |  | 19,046 |  |  | 142,167 |  |  | 142,032 |  |  | 15,930 |  |  | 157,962 |  |
| Operating expenses | 99,801 |  |  | 21,295 |  |  | 121,096 |  |  | 101,985 |  |  | 11,382 |  |  | 113,367 |  |
| Income (loss) from segment operations | $ | 23,320 |  |  | $ | (2,249 | ) |  | $ | 21,071 |  |  | $ | 40,047 |  |  | $ | 4,548 |  |  | $ | 44,595 |  |
| Corporate costs |  |  |  |  | 40,711 |  |  |  |  |  |  | 42,861 |  |
| Income (loss) from operations |  |  |  |  | $ | (19,640 | ) |  |  |  |  |  | $ | 1,734 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000926326-17-000032:notes:141]
The following table summarizes the share option activity under the Company’s equity incentive plans during the six months ended June 30, 2017:

[0000926326-17-000032:notes:142]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Stock Options |  |  |  |  |  |  |  |
| Outstanding at December 31, 2016 | 3,214 |  |  | $ | 26.06 |  |  | 7.3 |  | $ | 26,331 |  |
| Granted | 409 |  |  | 37.21 |  |  |  |  |  |
| Exercised | (423 | ) |  | 21.69 |  |  |  |  |  |
| Expired | (3 | ) |  | 24.36 |  |  |  |  |  |
| Forfeited | (56 | ) |  | 32.14 |  |  |  |  |  |
| Outstanding at June 30, 2017 | 3,141 |  |  | $ | 27.99 |  |  | 7.4 |  | $ | 47,445 |  |
| Exercisable at June 30, 2017 | 1,382 |  |  | $ | 21.61 |  |  | 5.6 |  | $ | 29,696 |  |
| Vested and expected to vest at June 30, 2017 and thereafter | 2,985 |  |  | $ | 27.66 |  |  | 7.3 |  | $ | 46,078 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0000926326-17-000032:notes:143]
|  | Three months ended |  | Six months ended |
|  | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| Employee Stock Purchase Plan |  |  |  |  |  |  |  |
| Expected life, years | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |
| Expected volatility, % | 25.8-32.8% |  |  | 25.8-34.8% |  |  | 25.8-32.8% |  |  | 25.8-34.8% |  |
| Risk free interest rate, % | 0.52-1.31% |  |  | 0.26-0.79% |  |  | 0.52-1.31% |  |  | 0.26-0.79% |  |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0000926326-17-000032:notes:144]
The following weighted average assumptions are used to value stock options and Employee Stock Purchase Plan ("ESPP") shares issued pursuant to the Company's equity incentive plans for the three and six months ended June 30, 2017 and 2016:

[0000926326-17-000032:notes:145]
|  | Three months ended |  | Six months ended |
|  | June 30, 2017 |  | June 30, 2016 |  | June 30, 2017 |  | June 30, 2016 |
| Stock Option Plans |  |  |  |  |  |  |  |
| Expected life, years | 4.67 |  |  | 4.92 |  |  | 4.67 |  |  | 4.92 |  |
| Expected volatility, % | 28.3 | % |  | 31.5 | % |  | 29.7 | % |  | 32.0 | % |
| Risk free interest rate, % | 1.78 | % |  | 1.41 | % |  | 1.84 | % |  | 1.40 | % |
| Estimated forfeiture rate % | 7.7 | % |  | 8.6 | % |  | 7.7 | % |  | 8.6 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-17-000032:notes:146]
[same as prior period, unchanged from 0001628280-17-005045:notes:136]

[0000926326-17-000032:notes:147]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.  The two operating segments, which are the same as the Company's two reportable segments, are as follows:

[0000926326-17-000032:notes:148]
[same as prior period, unchanged from 0001628280-17-005045:notes:138]

[0000926326-17-000032:notes:149]
[same as prior period, unchanged from 0001628280-17-005045:notes:139]

[0000926326-17-000032:notes:150]
[same as prior period, unchanged from 0001628280-17-005045:notes:140]

[0000926326-17-000032:notes:151]
[same as prior period, unchanged from 0001628280-17-005045:notes:141]

[0000926326-17-000032:notes:152]
[same as prior period, unchanged from 0001628280-17-005045:notes:142]

[0000926326-17-000032:notes:153]
There were no customers that accounted for more than 10% of our total revenues for the three and six months ended June 30, 2017 and 2016. Also, there were no customers that accounted for more than 10% of our accounts receivable as of June 30, 2017 and December 31, 2016.

[0000926326-17-000032:notes:154]
[same as prior period, unchanged from 0001628280-17-005045:notes:144]

[0000926326-17-000032:notes:155]
[same as prior period, unchanged from 0001628280-17-005045:notes:145]


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0000926326-17-000032:notes:156]
The following table summarizes the performance-based restricted stock activity under the Company’s equity incentive plans during the six months ended June 30, 2017:

[0000926326-17-000032:notes:157]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Performance-based Restricted Stock Units ("PSUs") |  |  |  |
| Outstanding at December 31, 2016 | 184 |  |  | $ | 24.89 |  |
| Granted | 126 |  |  | 32.37 |  |
| Vested | (69 | ) |  | 24.43 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at June 30, 2017 | 241 |  |  | $ | 28.94 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-17-000032:notes:158]
[same as prior period, unchanged from 0001628280-17-005045:notes:148]

[0000926326-17-000032:notes:159]
[same as prior period, unchanged from 0001628280-17-005045:notes:149]

[0000926326-17-000032:notes:160]
For a detailed explanation of the Company's stock plans and subsequent changes, please refer to Note 11, Employee Benefits and Stock-Based Compensation, of the Company's Annual Report on Form 10-K for the year ended December 31, 2016 filed with the SEC on February 28, 2017.

[0000926326-17-000032:notes:161]
[same as prior period, unchanged from 0001628280-17-005045:notes:151]

[0000926326-17-000032:notes:162]
[same as prior period, unchanged from 0001628280-17-005045:notes:152]

[0000926326-17-000032:notes:163]
The weighted-average fair value per share of options granted during the three months ended June 30, 2017 and 2016 was $11.31 and $9.03, respectively, and the weighted-average fair value per share of options granted during the six months ended June 30, 2017 and 2016 was $10.92 and $8.59, respectively. The intrinsic value of options exercised during the three months ended June 30, 2017 and 2016 was $4.9 million and $2.2 million, respectively, and the intrinsic value of options exercised during the six months ended June 30, 2017 and 2016 was $7.8 million and $2.9 million, respectively,

[0000926326-17-000032:notes:164]
As of June 30, 2017, total unrecognized compensation cost related to unvested stock options was $14.3 million, which is expected to be recognized over a weighted-average vesting period of 2.9 years.

[0000926326-17-000032:notes:165]
[same as prior period, unchanged from 0001628280-17-005045:notes:155]

[0000926326-17-000032:notes:166]
The weighted-average grant date fair value per share of RSUs granted during the six months ended June 30, 2017 and June 30, 2016 was $37.21 and $28.09, respectively.

[0000926326-17-000032:notes:167]
As of June 30, 2017, total unrecognized compensation expense related to RSUs was $12.8 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.6 years.

[0000926326-17-000032:notes:168]
As of June 30, 2017, total unrecognized compensation cost related to RSAs was $0.8 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.89 years.

[0000926326-17-000032:notes:169]
[same as prior period, unchanged from 0001628280-17-005045:notes:159]

[0000926326-17-000032:notes:170]
The weighted-average grant date fair value per share of PSUs granted during the six months ended June 30, 2017 and 2016 was $32.37 and $24.66, respectively. As of June 30, 2017, total unrecognized compensation cost related to PSUs was $3.5 million, which is expected to be recognized over the remaining weighted-average period of 1.5 years.

[0000926326-17-000032:notes:171]
[same as prior period, unchanged from 0001628280-17-005045:notes:161]

[0000926326-17-000032:notes:172]
For the six months ending June 30, 2017 and 2016, purchases under the ESPP were approximately 259,000 and 198,000 shares at weighted average prices of $25.51 and $22.74, respectively. As of June 30, 2017, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $1.9 million and is expected to be recognized over a weighted-average period of 1.3 years.

[0000926326-17-000032:notes:173]
[same as prior period, unchanged from 0001628280-17-005045:notes:163]

[0000926326-17-000032:notes:174]
[same as prior period, unchanged from 0001628280-17-005045:notes:164]

[0000926326-17-000032:notes:175]
On August 2, 2016, the Company's Board of Directors (the "Board") authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of June 30, 2017, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase program at any time.

[0000926326-17-000032:notes:176]
During the three and six months period ended June 30, 2017 and 2016, the Company did not repurchase any of its outstanding common stock.


## us-gaap:SubsequentEventsTextBlock

[0000926326-17-000032:notes:177]
Subsequent Event

[0000926326-17-000032:notes:178]
On  July 7, 2017 and July 31, 2017, the Company borrowed $15.0 million and $12.0 million, respectively, under the Revolving Credit Facility to fund its operations.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-17-000032:notes:179]
[same as prior period, unchanged from 0001628280-17-005045:notes:169]
