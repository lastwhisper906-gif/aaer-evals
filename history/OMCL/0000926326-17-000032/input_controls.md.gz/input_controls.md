# OMCL 10-Q controls and the auditor's report


## item_4_controls

[0000926326-17-000032:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000926326-17-000032:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000926326-17-000032:item_4_controls:3]
Our management, with the participation of our principal executive officer and principal financial officer, evaluated the effectiveness of our disclosure controls and procedures (as such term is defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended, or the Exchange Act) as of the end of the period covered by this report. These disclosure controls and procedures are designed to ensure that the information required to be disclosed by us in this report was (i) recorded, processed, summarized and reported within the time periods specified in the SEC's rules and regulations and (ii) accumulated and communicated to our management, including our principal executive officer and principal financial officer, to allow timely decisions regarding required disclosure.

[0000926326-17-000032:item_4_controls:4]
Based on such evaluation, our principal executive officer and principal financial officer have concluded that our disclosure controls and procedures were effective at the reasonable assurance level as of the end of the period covered by this report.

[0000926326-17-000032:item_4_controls:5]
Limitations on Effectiveness of Controls

[0000926326-17-000032:item_4_controls:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act). Our internal control system is designed to provide reasonable assurance regarding the preparation and fair presentation of financial statements for external purposes in accordance with U.S. GAAP. All internal control systems, no matter how well designed, have inherent limitations and can provide only reasonable assurance that the objectives of the internal control system are met.

[0000926326-17-000032:item_4_controls:7]
Changes in Internal Control Over Financial Reporting

[0000926326-17-000032:item_4_controls:8]
There have been no changes in our internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting during the three months ended June 30, 2017.

[0000926326-17-000032:item_4_controls:9]
40
