# OMCL notes — 0000926326-13-000010


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000926326-13-000010:notes:1]
The following table summarizes the credit losses and recorded investment in sales-type leases, excluding unearned interest, as of March 31, 2013 and December 31, 2012 (in thousands):

[0000926326-13-000010:notes:2]
|  | Allowance for Credit Losses |  | Recorded Investmentin Sales-type Leases Gross |  | Recorded Investmentin Sales-type Leases Net |
| Credit loss disclosure for March 31, 2013: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | 59 |  |  | $ | 59 |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 131 |  |  | 18,484 |  |  | 18,353 |  |
| Ending balances: March 31, 2013 | $ | 190 |  |  | $ | 18,543 |  |  | $ | 18,353 |  |
| Credit loss disclosure for December 31, 2012: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | 489 |  |  | $ | 489 |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 118 |  |  | 18,578 |  |  | 18,460 |  |
| Ending balances: December 31, 2012 | $ | 607 |  |  | $ | 19,067 |  |  | $ | 18,460 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-13-000010:notes:3]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of March 31, 2013, the results of their operations and comprehensive income for the three months ended March 31, 2013 and 2012 and their cash flows for the three months ended March 31, 2013 and 2012. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2012.

[0000926326-13-000010:notes:4]
Our results of operations, comprehensive income and cash flows for the three months ended March 31, 2013 are not necessarily indicative of results that may be expected for the year ending December 31, 2013, or for any future period.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-13-000010:notes:5]
[same as prior period, unchanged from 0001445305-12-003598:notes:8]

[0000926326-13-000010:notes:6]
MTS Medication Technologies, Inc.

[0000926326-13-000010:notes:7]
On May 21, 2012, we completed our acquisition of MedPak Holdings, Inc. ("MedPak") pursuant to an Agreement and Plan of Merger (the "Merger Agreement") under which Mercury Acquisition Corp, a newly formed Omnicell subsidiary, was merged with and into MedPak, with MedPak surviving the merger as a wholly-owned subsidiary of Omnicell. MedPak is the parent company of MTS Medication Technologies, Inc. ("MTS").

[0000926326-13-000010:notes:8]
[same as prior period, unchanged from 0001445305-12-003598:notes:12]

[0000926326-13-000010:notes:9]
We are accounting for the transaction under the acquisition method of accounting in accordance with the provisions of FASB ASC Topic 805, Business Combinations. Under the acquisition method, the estimated fair value of the consideration transferred to purchase the acquired company is allocated to the assets acquired and the liabilities assumed based on their fair values. We have made significant estimates and assumptions in determining the allocation of the acquisition consideration.

[0000926326-13-000010:notes:10]
Pursuant to the terms of the Merger Agreement, we paid approximately $158.3 million in cash after adjustments provided for in the Merger Agreement, of which approximately $13.5 million was placed in an escrow fund, which will be distributed to MedPak's stockholders (subject to claims that we may make against the escrow fund for indemnification and other claims following the closing). The revised acquisition consideration of $158.3 million is comprised entirely of cash at closing.

[0000926326-13-000010:notes:11]
At date of acquisition, we also recorded a $1.8 million liability based on expected additional working capital adjustments. In October 2012, a portion of the escrow fund set aside for the working capital adjustment was disbursed, with Omnicell receiving $0.3 million and MedPak's former stockholders receiving the remainder. As of December 31, 2012, the working capital adjustment was reversed, with a resulting reduction in goodwill of $1.8 million and a corresponding reduction in accrued liabilities. Accounts receivable acquired were recorded at their estimated fair value, comprised of total contractual obligations due of $7.6 million, of which $0.2 million was not expected to be collected. Based on an acquisition date valuation, the preliminary estimated fair values of acquired inventory and property and equipment exceeded their historical carrying values. We recorded a preliminary step-up to the estimated fair value of acquired inventory in the amount of $1.6 million, which resulted in subsequent related charges of $1.6 million to cost of product revenues.

[0000926326-13-000010:notes:12]
In the fourth quarter of 2012, subsequent to the initial acquisition price allocation, we revised our preliminary determination of the fair value of fixed assets and intangible assets acquired from MTS, resulting in a decrease in the carrying value of acquired fixed assets of $1.3 million, and increase in the carrying value of intangibles of $0.4 million and a net increase in recorded goodwill of $0.9 million. During the first quarter of 2013, we reduced goodwill by $0.1 million due to an adjustment in stockholder's equity.

[0000926326-13-000010:notes:13]
The total revised acquisition price was approximately $158.3 million and, except for the fair value of acquired other non-current liabilities which is still preliminary pending the completion of an analysis of potential contingent payroll tax withholding obligations, the allocation is comprised of the following (in thousands ):

[0000926326-13-000010:notes:14]
|  |  | Fair value acquired |  |  |
| Cash including restricted cash |  | $ | 2,000 |  |  |
| Accounts receivable |  | 7,403 |  |  |
| Inventory |  | 11,726 |  |  |
| Deferred tax assets and other current assets |  | 2,894 |  |  |
| Total current assets |  | 24,023 |  |  |
| Property and equipment |  | 9,807 |  |  |
| Intangible assets |  | 83,900 |  |  |
| Goodwill |  | 82,800 |  |  |
| Other non-current assets |  | 308 |  |  |
| Total assets |  | 200,838 |  |  |
| Current liabilities |  | (7,917 | ) |  |
| Non-current deferred tax liabilities |  | (33,386 | ) |  |
| Other non-current liabilities |  | (1,223 | ) |  |
| Net assets acquired |  | $ | 158,312 |  |  |
| Cash consideration, fair value |  | $ | 158,312 |  |  |

[0000926326-13-000010:notes:15]
[same as prior period, unchanged from 0001445305-12-003598:notes:18]

[0000926326-13-000010:notes:16]
[same as prior period, unchanged from 0001445305-12-003598:notes:19]

[0000926326-13-000010:notes:17]
For income tax purposes, the historical tax bases of the acquired assets and assumed liabilities, along with the tax attributes of the MTS companies, will carry over. Because the transaction was a cash-for-stock transaction, there is no tax basis in the newly acquired intangible assets. Accordingly, the acquisition accounting includes the establishment of net deferred tax liabilities of $33.4 million, resulting from book tax basis differences related to the intangible assets acquired, as well as to the step up in the value of fixed assets and inventory to their estimated fair values at the time of acquisition.

[0000926326-13-000010:notes:18]
[same as prior period, unchanged from 0001445305-12-003598:notes:22]

[0000926326-13-000010:notes:19]
|  |  | Fair value acquired |  |  | Useful Life (years) |  | First year amortization expense |  |  |
| Trade name |  | $ | 6,800 |  |  | 12 |  | $ | 567 |  |  |
| Customer relationships |  | 50,500 |  |  | 28 to 30 |  | 1,707 |  |  |
| Acquired technology |  | 26,600 |  |  | 20 |  | 1,330 |  |  |
| Intangibles acquired |  | $ | 83,900 |  |  |  |  | $ | 3,604 |  |  |
| Weighted average life of intangibles |  |  |  | 25.14 |  |  |  |

[0000926326-13-000010:notes:20]
Goodwill. Approximately $82.8 million has been allocated to goodwill. Goodwill represents the excess of the fair value of the consideration transferred over the fair value of the underlying net tangible and identifiable intangible assets on the acquisition date. In accordance with ASC Topic 350, Intangibles - Goodwill and Other, goodwill will not be amortized, but instead will be tested for impairment at least annually or more frequently if certain indicators are present. We believe the MTS acquisition enhances our offerings and diversifies our revenue mix, providing a more robust product and service solution to our current customers while expanding Omnicell’s international presence. We consider these factors as supporting the amount of goodwill recorded.

[0000926326-13-000010:notes:21]
For three months ended March 31, 2013, we did not incur any acquisition-related costs in connection with the MTS acquisition.

[0000926326-13-000010:notes:22]
During the three months ended March 31, 2013, the acquired MTS operations (consolidated since the May 21, 2012 acquisition date) generated revenue of approximately $18.4 million and a net loss of $1.0 million.

[0000926326-13-000010:notes:23]
The following represents unaudited pro forma revenue and net income as if MTS had been included in our consolidated results from January 1, 2012 (in thousands):

[0000926326-13-000010:notes:24]
|  | Three Months Ended March 31, |  |
|  | 2013 |  | 2012 |  |
| Revenues | $ | 87,110 |  |  | $ | 83,066 |  |  |
| Net income | $ | 3,385 |  |  | $ | 2,485 |  |  |

[0000926326-13-000010:notes:25]
The pro forma unaudited condensed consolidated operating results presented above were calculated after applying Omnicell's accounting policies and by adding together the historical operating statements of MTS and Omnicell, with certain adjustments, assuming an acquisition date of January 1, 2011. Based on the estimated fair values and useful lives determined from the allocation of total MTS acquisition consideration, MTS historical depreciation and amortization expense was replaced with acquisition-accounting depreciation and amortization expense. Also reflected is the interest expense elimination effect of MTS on its debt (since it would have been paid off at acquisition) and the elimination of certain management fees to an affiliated party, offset in part by interest income foregone by Omnicell, by no longer having the acquisition consideration available as interest-bearing cash, cash equivalents and short-term investments.

[0000926326-13-000010:notes:26]
The pro forma operating results do not include actual direct acquisition-related expenses incurred by MTS and Omnicell as such amounts are considered nonrecurring. The total of all adjustments were tax effected using an estimated federal and state effective income tax rate.

[0000926326-13-000010:notes:27]
[same as prior period, unchanged from 0001445305-12-003598:notes:28]


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0000926326-13-000010:notes:28]
[same as prior period, unchanged from 0001445305-12-003598:notes:29]

[0000926326-13-000010:notes:29]
Cash and cash equivalents and short-term investments consist of the following significant investment asset classes, with disclosure of amortized cost, gross unrealized gains and losses, and fair value as of March 31, 2013 and December 31, 2012 (in thousands):

[0000926326-13-000010:notes:30]
|  | March 31, 2013 |  |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | Short-termInvestments |  | SecurityClassification |
| Cash | $ | 29,449 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,449 |  |  | $ | 29,449 |  |  | $ | — |  |  | N/A |
| Money market funds | 40,368 |  |  | — |  |  | — |  |  | 40,368 |  |  | 40,368 |  |  | — |  |  | Available for sale |
| Total cash, cash equivalents and short-term investments | $ | 69,817 |  |  | $ | — |  |  | $ | — |  |  | $ | 69,817 |  |  | $ | 69,817 |  |  | $ | — |  |  |  |

[0000926326-13-000010:notes:31]
| c | December 31, 2012 |  |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | Short-termInvestments |  | SecurityClassification |
| Cash | $ | 23,422 |  |  | $ | — |  |  | $ | — |  |  | $ | 23,422 |  |  | $ | 23,422 |  |  | $ | — |  |  | N/A |
| Money market funds | 38,892 |  |  | — |  |  | 1 |  |  | 38,891 |  |  | 38,891 |  |  | — |  |  | Available for sale |
| Total cash, cash equivalents and short-term investments | $ | 62,314 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 62,313 |  |  | $ | 62,313 |  |  | $ | — |  |  |  |

[0000926326-13-000010:notes:32]
[same as prior period, unchanged from 0001445305-12-003598:notes:33]

[0000926326-13-000010:notes:33]
[same as prior period, unchanged from 0001445305-12-003598:notes:35]

[0000926326-13-000010:notes:34]
|  | Quoted Prices in ActiveMarkets for IdenticalInstruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant UnobservableInputs(Level 3) |  | Total FairValue |
| At March 31, 2013 |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 40,368 |  |  | $ | — |  |  | — |  |  | $ | 40,368 |  |
| Total | $ | 40,368 |  |  | $ | — |  |  | — |  |  | $ | 40,368 |  |
| At December 31, 2012 |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 38,891 |  |  | — |  |  | — |  |  | $ | 38,891 |  |
| Non U.S. Government securities | — |  |  | $ | — |  |  | — |  |  | — |  |
| Total | $ | 38,891 |  |  | $ | — |  |  | $ | — |  |  | $ | 38,891 |  |

[0000926326-13-000010:notes:35]
[same as prior period, unchanged from 0001445305-12-003598:notes:37]


## us-gaap:CommitmentsDisclosureTextBlock

[0000926326-13-000010:notes:36]
[same as prior period, unchanged from 0001445305-12-003598:notes:38]

[0000926326-13-000010:notes:37]
At March 31, 2013, the minimum payments under our operating leases for each of the five succeeding fiscal years were as follows (in thousands):

[0000926326-13-000010:notes:38]
| 2013 (remaining nine months) | $ | 4,256 |  |
| 2014 | 5,433 |  |
| 2015 | 5,204 |  |
| 2016 | 4,907 |  |
| 2017 | 4,215 |  |
| 2018 | 1,003 |  |
| Thereafter | 19,289 |  |
| Total | $ | 44,307 |  |

[0000926326-13-000010:notes:39]
In October 2011, we entered into a lease agreement for approximately 100,000 square feet of office space. Pursuant to the lease agreement, the landlord constructed a single, three-story building of rentable space in Mountain View, California which we now lease and which serves as our headquarters. The term of the lease agreement, which commenced in November 2012, is for a period of 10 years, with a base lease commitment of approximately $40.0 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term.

[0000926326-13-000010:notes:40]
In March 2012, we entered into a lease agreement for approximately 46,000 square feet of manufacturing, distribution and office space located in Milpitas, California which commenced in October, 2012. The term of the lease agreement is for a period of 60 months, with a base lease commitment of approximately $1.8 million and a single 60 month extension option.

[0000926326-13-000010:notes:41]
In connection with the acquisition of MTS, we assumed responsibility for 132,500 square feet of manufacturing, warehousing and office space in St. Petersburg, Florida. The remaining term of the original twelve year lease agreement, which expires in September 2016 and at the time of the MTS acquisition, has  a base lease commitment of approximately $3.9 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term.

[0000926326-13-000010:notes:42]
In Leeds, United Kingdom, we lease an office and distribution center of approximately 16,500 square feet. The remaining term of the original ten year lease agreement is through June 8, 2021, with no extension options. The base lease commitment at the time of the MTS acquisition, converted from British Pounds at the conversion rate then in effect, was approximately $1.2 million.

[0000926326-13-000010:notes:43]
We also have smaller rented offices in Strongsville, Ohio, the United Arab Emirates, the People's Republic of China and the Federal Republic of Germany.

[0000926326-13-000010:notes:44]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. Our near-term commitments to our contract manufacturers and suppliers totaled $6.9 million as of March 31, 2013.

[0000926326-13-000010:notes:45]
At March 31, 2013, we have recorded $3.8 million for uncertain tax positions under long term liabilities in accordance with GAAP, summarized under Note 1, “Organization and Summary of Significant Accounting Policies.” As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, we do not present this in a commitments table.


## us-gaap:DerivativesPolicyTextBlock

[0000926326-13-000010:notes:46]
Currency forward contracts. From time to time we enter into foreign currency forward contracts to protect our business from the risk that exchange rates may affect the eventual cash flows resulting from intercompany transactions between Omnicell and our foreign subsidiaries. These transactions primarily arise as a result of products manufactured in the U.S. and sold to foreign subsidiaries in U.S. dollars rather than the subsidiaries' functional currencies. These forward contracts are considered to be financial derivative instruments and are recorded at fair value in the balance sheet. Changes in fair values of these financial derivative instruments are either recognized in other comprehensive income (a component of stockholders' equity) or net income depending on whether the derivative has been designated and qualifies as a highly effective hedging instrument. At March 31, 2013 and December 31, 2012, we had no foreign currency forward contracts which qualify for hedge accounting.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000926326-13-000010:notes:47]
[same as prior period, unchanged from 0001445305-12-003598:notes:54]

[0000926326-13-000010:notes:48]
[same as prior period, unchanged from 0001445305-12-003598:notes:55]

[0000926326-13-000010:notes:49]
Description of Share-Based Plans

[0000926326-13-000010:notes:50]
Equity Incentive Plan. On May 19, 2009, at our 2009 Annual Meeting of Stockholders (the "2009 Annual Meeting") our stockholders approved the Omnicell, Inc. 2009 Equity Incentive Plan (the "2009 Plan") which authorized 2,100,000 shares to be issued. The 2009 Plan provides for the issuance of incentive stock options, non-statutory stock options, stock appreciation rights, restricted stock awards, restricted stock unit awards, performance stock awards, performance cash awards and other stock awards to our employees, directors and consultants.

[0000926326-13-000010:notes:51]
The 2009 Plan succeeded the 1999 Equity Incentive Plan, as amended, the 2003 Equity Incentive Plan, as amended, and the 2004 Equity Incentive Plan (collectively, the "Prior Plans"). No additional awards will be granted under any of the Prior Plans; however, all outstanding stock awards granted under the Prior Plans continue to be subject to the terms and conditions as set forth in the agreements evidencing such stock awards. For purposes of determining future common shares available for grant, for each share granted as a full-value award, including restricted stock and restricted stock units ("RSUs") performance stock awards, the shares available for grant were reduced by 1.4 shares. Equity awards granted as stock options and stock appreciation rights reduce the shares available for grant by one share.

[0000926326-13-000010:notes:52]
On December 16, 2010, at a Special Meeting of Stockholders, our stockholders approved an amendment to increase the number of shares of common stock authorized for issuance under the 2009 Plan by 2,600,000 shares and to provide that the number of common stock shares available for issuance under the 2009 Plan be reduced by 1.8 shares for each share granted as a full-value award granted on and after October 1, 2010. For each share granted as a full-value award granted prior to October 1, 2010, future shares available for grants under the 2009 Plan were reduced by 1.4 shares. Awards granted as stock options and stock appreciation rights continue to reduce the number of shares available for issuance under the 2009 Plan on a one-for-one basis.

[0000926326-13-000010:notes:53]
Options granted under the 2009 Plan generally become exercisable over periods of up to 4 years, generally with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 36 equal monthly installments thereafter; however our board of directors may impose different vesting terms at its discretion on any award. Options under the 2009 Plan generally expire 10 years from the date of grant. We also grant both restricted stock and restricted stock units to participants under the 2009 Plan. The Board of Directors determines the award amount, the vesting provisions and the expiration period (not to exceed ten years) for each grant. Grants of restricted stock to non-employee directors are granted on the date of our annual meeting of stockholders and vest in full on the date of our next annual meeting of stockholders, provided such non-employee director remains a director on such date. The fair value of the stock on the date of issuance is amortized to expense from the date of grant to the date of vesting. RSUs granted to employees generally vest over a period of four years and are expensed ratably on a straight-line basis over the vesting period. We consider the dilutive impact of options, restricted stock and restricted stock units in our diluted net income per share calculation.

[0000926326-13-000010:notes:54]
The Board of Directors shall administer the 2009 Plan unless and until the board of directors delegates administration to a committee. Our board of directors has delegated administration of the 2009 Plan to the compensation committee of the board and the 2009 Plan is generally administered by such committee. The Board of Directors may suspend or terminate the 2009 Plan at any time. The Board of Directors may also amend the 2009 Plan at any time or from time to time. However, no amendment will be effective unless approved by our stockholders after its adoption by the board of directors to the extent stockholder approval is necessary to satisfy the applicable listing requirements of NASDAQ.

[0000926326-13-000010:notes:55]
If we sell, lease or dispose of all or substantially all of our assets, or we are acquired pursuant to a merger or consolidation, then the surviving entity may assume or substitute all outstanding awards under the 2009 Plan. If the surviving entity does not assume or substitute these awards, then generally the stock awards will immediately and fully vest.

[0000926326-13-000010:notes:56]
At March 31, 2013, a total of 1,107,858 shares of common stock were reserved for future issuance under the 2009 Plan. At March 31, 2013, $7.0 million of total unrecognized compensation cost related to non-vested stock options was expected to be recognized over a weighted average period of 2.8 years.

[0000926326-13-000010:notes:57]
A summary of aggregate option activity for the three months ended March 31, 2013 is presented below:

[0000926326-13-000010:notes:58]
| Options: |  | Number of Shares |  | Weighted- Average Exercise Price |
|  |  | (in thousands) |  |  |
| Outstanding at December 31, 2012 |  | 4,470 |  |  | $ | 14.06 |  |
| Granted |  | 204 |  |  | $ | 17.06 |  |
| Exercised |  | (470 | ) |  | $ | 10.67 |  |
| Forfeited |  | (12 | ) |  | $ | 14.26 |  |
| Expired |  | (23 | ) |  | $ | 22.44 |  |
| Outstanding at March 31, 2013 |  | 4,169 |  |  | $ | 14.54 |  |
| Exercisable at March 31, 2013 |  | 2,971 |  |  | $ | 14.44 |  |

[0000926326-13-000010:notes:59]
[same as prior period, unchanged from 0001445305-12-003598:notes:59]

[0000926326-13-000010:notes:60]
The non-employee members of our Board of Directors are granted restricted stock on the day of our annual meeting of stockholders and such shares of restricted stock vest on the date of the subsequent year’s annual meeting of stockholders, provided such non-employee director remains a director on such date. Restricted stock units (“RSUs”) are granted to certain of our employees and generally vest over a period of four years and are expensed ratably on a straight-line basis over the vesting period. The fair value of both restricted stock and RSUs granted pursuant to our stock option plans is the product of the number of shares granted and the grant date fair value of our common stock. Our unrecognized compensation cost related to non-vested restricted stock at March 31, 2013 was approximately $0.1 million and is expected to be recognized over a weighted-average period of 0.1 years. Expected future compensation expense relating to RSUs outstanding on March 31, 2013 is $5.7 million over a weighted-average period of 2.3 years.

[0000926326-13-000010:notes:61]
A summary of activity of both restricted stock and RSUs for the three months ended March 31, 2013 is presented below:

[0000926326-13-000010:notes:62]
|  | Restricted Stock |  | Restricted Stock Units |
|  |  |  | Weighted - |  |  |  | Weighted - |
|  | Number ofShares |  | AverageGrant DateFair Value PerShare |  | Number ofShares |  | AverageGrant DateFair Value PerShare |
|  | (in thousands) |  |  |  | (in thousands) |  |  |
| Non-vested, December 31, 2012 | 58 |  |  | $ | 14.19 |  |  | 389 |  |  | $ | 14.09 |  |
| Granted | 3 |  |  | $ | 14.87 |  |  | 94 |  |  | $ | 17.45 |  |
| Vested | — |  |  | $ | — |  |  | (15 | ) |  | $ | 12.79 |  |
| Forfeited | — |  |  | $ | — |  |  | (19 | ) |  | $ | 13.84 |  |
| Non-vested, March 31, 2013 | 61.00 |  |  | $ | 14.23 |  |  | 449 |  |  | $ | 14.84 |  |

[0000926326-13-000010:notes:63]
Performance-Based Restricted Stock Units

[0000926326-13-000010:notes:64]
In 2011, we began incorporating performance-based restricted stock units ("PSUs") as an element of our executive compensation plans. For 2011, we granted 100,000 PSUs; however, pursuant to their terms, 120,000 PSUs ultimately became eligible for vesting upon the achievement of a certain level of shareholder return for 2011 as described below. In 2012, we granted 125,000 PSUs of which 62,500 became eligible for vesting upon the achievement of a certain level of shareholder return for 2012 as described below.

[0000926326-13-000010:notes:65]
Our unrecognized compensation cost related to non-vested performance-based restricted stock units at March 31, 2013 was approximately $2.3 million and is expected to be recognized over a weighted-average period of 1.7 years. For the three months ended March 31, 2013, we recognized $0.4 million of compensation expense for the performance-based restricted stock units. For the three months ended March 31, 2012, we recognized $0.2 million of compensation expense for the performance-based restricted stock units.

[0000926326-13-000010:notes:66]
The accounting guidance for awards with market conditions differs from that for awards with service conditions only or service and performance conditions. Because the grant date fair value of an award containing market conditions is calculated as the expected value, averaging over all possible outcomes, the measured expense is amortized over the service period, regardless of whether the market condition is ever actually met.

[0000926326-13-000010:notes:67]
The fair value of a PSU award is the average of trial-specific values of the award over each of one million Monte Carlo trials. Each trial-specific value is the market value of the award at the end of the one-year performance period discounted back to the grant date. The market value of the award for each trial at the end of the performance period is the product of (a) the per share value of Omnicell stock at the end of the performance period and (b) the number of shares that vest. The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of each of the other companies in the NASDAQ Healthcare Index (the "Index") as shown in the tables below.

[0000926326-13-000010:notes:68]
Vesting for the PSU awards is based on the percentile placement of our total shareholder return among the companies listed in the Index and time-based vesting. We calculate total stockholder return based on the one year annualized rates of return reflecting price appreciation plus reinvestment of dividends. For  PSU awards granted on February 5, 2013 and on March 5, 2013, stock price appreciation is calculated based on the average closing prices of our common stock for the last 20 trading days leading to February 28, 2014.For PSU awards granted in 2011 and 2012, stock price appreciation is calculated based on the average closing prices of the applicable company's common stock for the 20 trading days ending on the last trading day of the year prior to the date of grant as compared to the average closing prices for the 20 trading days ended on the last trading day of the year of grant.

[0000926326-13-000010:notes:69]
The following table shows the percent of PSUs granted in 2011 and eligible for further time-based vesting based on our percentile placement:

[0000926326-13-000010:notes:70]
| Percentile Placement of Our Total Shareholder Return |  | % of PSUs Eligible for Time-Based Vesting |
| Below the 35th percentile |  | —% |
| At least the 35th percentile, but below the 50th percentile |  | 50% |
| At least the 50th percentile, but below the 65th percentile |  | 100% |
| At least the 65th percentile, but below the 75th percentile (1) |  | 110% to 119% |
| At or above the 75th percentile |  | 120% |

[0000926326-13-000010:notes:71]
_______________________________________________________________________________

[0000926326-13-000010:notes:72]
[same as prior period, unchanged from 0001445305-12-003598:notes:70]

[0000926326-13-000010:notes:73]
On January 17, 2012, the Compensation Committee of our Board of Directors confirmed 76.3% as the percentile rank of Omnicell’s 2011 total stockholder return. This resulted in 120% of the 2011 PSU awards, or 120,000 shares, becoming eligible for further time-based vesting. The eligible PSU awards will vest as follows: 25% of the eligible awards for the first year vested immediately on January 17, 2012 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service.

[0000926326-13-000010:notes:74]
[same as prior period, unchanged from 0001445305-12-003598:notes:72]

[0000926326-13-000010:notes:75]
| Percentile Placement of Our Total Shareholder Return | % of PSUs Eligible for Time-Based Vesting |
| Below the 35th percentile | —% |
| At least the 35th percentile, but below the 50th percentile | 50% |
| At least the 50th percentile | 100% |

[0000926326-13-000010:notes:76]
On January 22, 2013, the Compensation Committee of our Board of Directors confirmed 35.3% as the percentile rank of Omnicell's 2012 total stockholder return. This resulted in 50% of the 2012 PSU awards, or 62,500 shares, as eligible for further time-based vesting. The eligible performance-based restricted stock unit awards will vest as follows: 25% of the eligible shares vested immediately on January 22, 2013 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service.

[0000926326-13-000010:notes:77]
For the year ended December 31, 2012, in addition to the 125,000 PSUs granted in 2012, an additional 10,000 PSUs were deemed granted and vested as a result of Omnicell’s 2011 total stockholder return which caused 120% of the 2011 PSUs to become eligible for further time-based vesting.

[0000926326-13-000010:notes:78]
On February 5, 2013, the Compensation Committee of our Board of Directors awarded 125,000 shares, as eligible for further time-based vesting for PSU awards granted in 2012 and awarded an additional 12,500 shares on March 5, 2013. The eligible performance-based restricted stock unit awards will vest as follows: 25% of the eligible shares vested immediately with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service.

[0000926326-13-000010:notes:79]
A summary of activity of the PSUs for the three months ended March 31, 2013 is presented below:

[0000926326-13-000010:notes:80]
| Performance-based Stock Units | Number of Units |  | Weighted-AverageGrant DateFair Value PerUnit |
|  | (in thousands) |  |  |
| Non-vested, December 31, 2012 | 175 |  |  | $ | 11.00 |  |
| Granted | 138 |  |  | $ | 17.40 |  |
| Vested | (16 | ) |  | $ | 15.66 |  |
| Forfeited | (16 | ) |  | $ | — |  |
| Non-vested, March 31, 2013 | 281 |  |  | $ | 14.48 |  |

[0000926326-13-000010:notes:81]
[same as prior period, unchanged from 0001445305-12-003598:notes:78]

[0000926326-13-000010:notes:82]
We have an Employee Stock Purchase Plan (“ESPP”) under which employees can purchase shares of our common stock based on a percentage of their compensation, but not greater than 15% of their earnings, up to a maximum of $25,000 of fair value per year. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period. As of March 31, 2013, 4,039,838 shares had been issued under the ESPP. As of March 31, 2013 there were a total of 1,291,717 shares reserved for future issuance under the ESPP. For the three months ended March 31, 2013, 256,994 shares of common stock were purchased under the ESPP.

[0000926326-13-000010:notes:83]
[same as prior period, unchanged from 0001445305-12-003598:notes:80]

[0000926326-13-000010:notes:84]
[same as prior period, unchanged from 0001445305-12-003598:notes:81]

[0000926326-13-000010:notes:85]
The impact on our results for share-based compensation for the three months ended March 31, 2013 and 2012 was as follows (in thousands):

[0000926326-13-000010:notes:86]
|  | Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Cost of product and service revenues | $ | 305 |  |  | $ | 268 |  |
| Research and development expenses | 289 |  |  | 243 |  |
| Selling, general and administrative expenses | 2,332 |  |  | 1,696 |  |
| Total share-based compensation expenses | $ | 2,926 |  |  | $ | 2,207 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0000926326-13-000010:notes:87]
t income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Since t


## us-gaap:EarningsPerShareTextBlock

[0000926326-13-000010:notes:88]
|  | Net Income Per Share |

[0000926326-13-000010:notes:89]
Basic net income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Since their impact is anti-dilutive, the total number of shares excluded from the calculations of diluted net income per share for the three months ended March 31, 2013 and 2012 were 1,865,589 and 2,065,842, respectively.

[0000926326-13-000010:notes:90]
[same as prior period, unchanged from 0001445305-12-003598:notes:87]

[0000926326-13-000010:notes:91]
|  | Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Basic: |  |  |  |  |  |
| Net income | $ | 3,385 |  |  | $ | 2,351 |  |
| Weighted average shares outstanding — basic | 33,900 |  |  | 33,365 |  |
| Net income per share — basic | $ | 0.10 |  |  | $ | 0.07 |  |
| Diluted: |  |  |  |  |  |
| Net income | $ | 3,385 |  |  | $ | 2,351 |  |
| Weighted average shares outstanding — basic | 33,900 |  |  | 33,365 |  |
| Add: Dilutive effect of employee stock plans | 920 |  |  | 976 |  |
| Weighted average shares outstanding — diluted | 34,820 |  |  | 34,341 |  |
| Net income per share — diluted | $ | 0.10 |  |  | $ | 0.07 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000926326-13-000010:notes:92]
[same as prior period, unchanged from 0001445305-12-003598:notes:89]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-13-000010:notes:93]
[same as prior period, unchanged from 0001445305-12-003598:notes:90]

[0000926326-13-000010:notes:94]
Under ASC 350, Intangibles—Goodwill and Other, goodwill is not subject to amortization. We evaluate goodwill for impairment at least annually or more frequently if events and changes in circumstances suggest that the carrying amount may not be recoverable.

[0000926326-13-000010:notes:95]
Activity in goodwill by reporting units, which are the same as our operating segments, for the three months ended March 31, 2013 consists of the following (in thousands):

[0000926326-13-000010:notes:96]
|  | Goodwill at December 31, 2012 |  | Adjustments to Goodwill |  | Goodwill at March 31, 2013 |
| Reporting units: |  |  |  |  |  |
| Acute Care | $ | 28,543 |  |  | $ | — |  |  | $ | 28,543 |  |
| Non-Acute Care | 82,864 |  |  | (64 | ) |  | 82,800 |  |
| Total | $ | 111,407 |  |  | $ | (64 | ) |  | $ | 111,343 |  |

[0000926326-13-000010:notes:97]
Goodwill acquired reflects the May 21, 2012 acquisition of MedPak by Omnicell. MedPak is the parent company of MTS, a worldwide provider of medication adherence packaging systems. The acquired goodwill was assigned to the new reporting unit called Non-Acute Care, created as a result of the MTS acquisition. During the first quarter of 2013, we reduced goodwill by $0.1 million due to the adjustment to the fair value of an acquired foreign currency forward contract previously carried in a component of stockholder's equity.

[0000926326-13-000010:notes:98]
There were no indefinite-life intangibles at either March 31, 2013 or December 31, 2012. Finite-life intangible assets at these dates consist of the following (in thousands):

[0000926326-13-000010:notes:99]
|  | March 31, 2013 |  | December 31, 2012 |  |  |
|  | Gross |  |  |  | Net |  | Gross |  |  |  | Net |  |  |
|  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | AmortizationLife |
| Finite-lived intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 54,730 |  |  | $ | 3,620 |  |  | $ | 51,110 |  |  | $ | 54,730 |  |  | $ | 3,081 |  |  | $ | 51,649 |  |  | 5-30 years |
| Acquired technology | 27,580 |  |  | 1,495 |  |  | 26,085 |  |  | 27,580 |  |  | 1,128 |  |  | 26,452 |  |  | 3-20 years |
| Patents | 1,265 |  |  | 268 |  |  | 997 |  |  | 1,217 |  |  | 259 |  |  | 958 |  |  | 20 years |
| Trade name | 6,890 |  |  | 563 |  |  | 6,327 |  |  | 6,890 |  |  | 414 |  |  | 6,476 |  |  | 3-12 years |
| Non-compete agreements | 60 |  |  | 50 |  |  | 10 |  |  | 60 |  |  | 45 |  |  | 15 |  |  | 3 years |
| Total finite-lived intangibles | $ | 90,525 |  |  | $ | 5,996 |  |  | $ | 84,529 |  |  | $ | 90,477 |  |  | $ | 4,927 |  |  | $ | 85,550 |  |  |  |

[0000926326-13-000010:notes:100]
Amortization expense totaled $1.1 million and $0.2 million for the three months ended March 31, 2013 and 2012, respectively. The amortization of acquired technology is included within product cost of sales; other acquired intangibles are usually amortized within selling, general and administrative expenses.

[0000926326-13-000010:notes:101]
Estimated annual expected amortization expense of the finite-lived intangible assets at March 31, 2013 was as follows (in thousands):

[0000926326-13-000010:notes:102]
| 2013 (remaining nine months) | 3,195 |  |
| 2014 | 4,224 |  |
| 2015 | 4,200 |  |
| 2016 | 3,850 |  |
| 2017 | 3,814 |  |
| 2018 | 927 |  |
| Thereafter | 64,319 |  |
| Total | $ | 84,529 |  |


## us-gaap:IncomeTaxPolicyTextBlock

[0000926326-13-000010:notes:103]
Income taxes. We record an income tax provision for the anticipated tax consequences of the reported results of operations. In accordance with GAAP, the provision for income taxes is computed using the liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates expected to apply in the periods in which those tax assets and liabilities are expected to be realized. In the event that we determine all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-13-000010:notes:104]
[same as prior period, unchanged from 0001445305-12-003598:notes:101]

[0000926326-13-000010:notes:105]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rates before discrete items were 37.4% and 39.6% for the three months ended March 31, 2013 and 2012, respectively. The 2013 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the federal research and development credit claimed and the  domestic production activities deduction. The income tax provision for the three months ended March 31, 2013 also reflected a discrete net benefit of $0.7 million, or 18.0% of pre-tax income, related to 2012 federal research and development (“R&D”) credit which was retroactively reinstated in the three months ended March 31, 2013. No federal R&D credit benefit was recorded in the income tax provision for the three months ended March 31, 2012.

[0000926326-13-000010:notes:106]
The 2012 annual effective tax rate differed from the statutory rate of 35%, primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.

[0000926326-13-000010:notes:107]
Recently Adopted Accounting Standards

[0000926326-13-000010:notes:108]
In February 2013, the Financial Accounting Standards Board (“FASB”) issued 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income (AOCI), which aims to improve the reporting of reclassifications out of AOCI. This update requires an entity to report the effect of significant reclassifications out of AOCI on the respective line items in net income if the amount being reclassified is required under GAAP to be reclassified in its entirety to net income. For other amounts that are not required under GAAP to be reclassified in their entirety to net income in the same reporting period, an entity is required to cross-reference other disclosures required under GAAP that provide additional detail about those amounts. The amendments do not change the current requirements for reporting net income or other comprehensive income in financial statements. For public entities, the amendments are effective prospectively for reporting periods beginning after December 15, 2012. We adopted this guidance in the first quarter of 2013. This update did not have any significant impact on our financial position, operating results or cash flows.


## us-gaap:InventoryDisclosureTextBlock

[0000926326-13-000010:notes:109]
[same as prior period, unchanged from 0001445305-12-003598:notes:107]

[0000926326-13-000010:notes:110]
[same as prior period, unchanged from 0001445305-12-003598:notes:108]

[0000926326-13-000010:notes:111]
|  | March 31, 2013 | December 31, 2012 |
| Raw materials | $ | 9,350 |  | $ | 9,994 |  |
| Work in process | 562 |  | 385 |  |
| Finished goods | 16,213 |  | 16,524 |  |
| Total | $ | 26,125 |  | $ | 26,903 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000926326-13-000010:notes:112]
Contingencies

[0000926326-13-000010:notes:113]
Legal Proceedings

[0000926326-13-000010:notes:114]
On March 8, 2013, Bobbi Polanco (“Polanco”) filed a putative class action complaint in the United States District Court for the District of New Jersey against Omnicell and certain of our customers (Case No. 1:13-cv-01417-NLH-KLM) alleging breach of state security notification laws, violations of state consumer fraud laws, fraud, negligence and conspiracy relating to the theft of an Omnicell electronic device containing medication dispensing cabinet log files, including certain patient health information, and subsequent notification of this unauthorized disclosure of personal health information. Polanco is seeking an injunction against the defendants to prevent each of them from committing the acts complained of in the future and monetary damages, costs and expenses.On May 2, 2013, the United States District Court for the District of New Jersey entered an order to show cause which provided, in relevant part, that Polanco is required to show cause as to why the case should not be dismissed for lack of subject matter jurisdiction. Omnicell is currently evaluating a response to this complaint and intends to defend the matter vigorously.

[0000926326-13-000010:notes:115]
As required under ASC 450, "Contingencies," we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We believe that we have valid defenses with respect to legal proceedings pending against us. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-13-000010:notes:116]
Guarantees

[0000926326-13-000010:notes:117]
As permitted under Delaware law and our certificate of incorporation and bylaws, we have agreed to indemnify our directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become our directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that we could be required to make under these indemnification agreements. We have purchased a directors’ and officers’ liability insurance policy that may enable us to recover a portion of any future payments that we may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-13-000010:notes:118]
Additionally, we undertake indemnification obligations in our ordinary course of business in connection with, among other things, the licensing of our products and the provision of our support services. In the ordinary course of our business, we have in the past and may in the future agree to indemnify another party, generally our business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, our gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, we attempt to limit the maximum potential amount of future payments that we may be required to make under these indemnification obligations to the amounts paid to us by a customer, but in some cases the obligation may not be so limited. In addition, we have in the past and may in the future warrant to our customers that our products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that our software media is free from material defects. Sales contracts for certain of our medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances we record have historically been immaterial.

[0000926326-13-000010:notes:119]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of March 31, 2013 or December 31, 2012.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000926326-13-000010:notes:120]
[same as prior period, unchanged from 0001445305-12-003598:notes:118]

[0000926326-13-000010:notes:121]
Description of the Company. Omnicell, Inc. ("Omnicell," "our," "us," "we," or the "Company") was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication and supply control systems which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States. On May 21, 2012, we completed our acquisition of MedPak Holdings, Inc. ("MedPak"). MedPak is the parent company of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems. This acquisition aligns us with the long-term trends of the healthcare market to manage the health of patients across the continuum of care.  We can now serve both the acute care and non-acute care markets. Omnicell and MTS bring capabilities to each other that strengthen the product lines and expand the medication management coverage of both companies. Please refer to Note 14, "Business Acquisition" for more information regarding the transaction.

[0000926326-13-000010:notes:122]
Use of estimates. GAAP requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, valuation of goodwill and purchased intangibles, valuation of long-lived assets and accounting for income taxes.

[0000926326-13-000010:notes:123]
[same as prior period, unchanged from 0001445305-12-003598:notes:122]

[0000926326-13-000010:notes:124]
Reclassifications. Certain reclassifications have been made to the prior year consolidated balance sheet to conform to the current period presentation. None of these reclassifications are material to the consolidated financial statements.

[0000926326-13-000010:notes:125]
Fair value of financial instruments. We value our financial assets and liabilities on a recurring basis using the fair value hierarchy established in Accounting Standards Codification ("ASC") 820, Fair Value Measurements and Disclosures. ASC 820 describes three levels of inputs that may be used to measure fair value, as follows:

[0000926326-13-000010:notes:126]
Level 1 inputs, which include quoted prices in active markets for identical assets or liabilities;

[0000926326-13-000010:notes:127]
Level 2 inputs, which include observable inputs other than Level 1 inputs, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability; and

[0000926326-13-000010:notes:128]
Level 3 inputs, which include unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the underlying asset or liability. Level 3 assets and liabilities include those whose fair value measurements are determined using pricing models, discounted cash flow methodologies or similar valuation techniques, as well as significant management judgment or estimation.

[0000926326-13-000010:notes:129]
At March 31, 2013 and December 31, 2012, our financial assets, measured at fair value on a recurring basis, utilizing Level 1 inputs included money market funds, classified as cash equivalents. For these items, quoted market prices are readily available and fair value approximates carrying value. We do not currently have any material financial instruments, measured at fair value on a recurring basis, utilizing Level 2 or Level 3 inputs.

[0000926326-13-000010:notes:130]
Classification of marketable securities. Securities held as investments for the indefinite future pending future spending requirements are classified as “Available-for-sale” and are carried at their fair value, with any unrealized gain or loss recorded to other comprehensive income until realized. At March 31, 2013 and December 31, 2012, we held $40.4 million and $38.9 million, respectively, of money market mutual funds classified as Available-for-sale cash equivalents. We do not hold securities for purposes of trading. Marketable securities for which we have the intent and ability to hold to maturity are classified as “Held-to-maturity” and are carried at their amortized cost, including accrued interest. We had no Held-to-maturity securities at March 31, 2013 and December 31, 2012.

[0000926326-13-000010:notes:131]
Segment information. Prior to the acquisition of MTS, we managed our business on the basis of a single operating segment, and a single reporting unit within that segment per ASC 280, Segment Reporting. Beginning with the acquisition of MTS, which we completed in May 2012, we have organized our business into two operating business segments: Acute Care, which primarily includes products and services sold to hospital customers, and Non-Acute Care, which primarily includes products and services sold to customers outside of the hospital setting.

[0000926326-13-000010:notes:132]
The Acute Care segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems. The Non-Acute Care segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services, but also includes medication dispensing systems sold to non-acute care pharmacies and facilities. We report segment information based on the management approach. The management approach designates the internal reporting used by the Chief Operating Decision Maker (the "CODM") for making decisions and assessing performance as the source of our operating segments. The CODM is our Chief Executive Officer. The CODM allocates resources to and assesses the performance of each operating segment, using information about its revenues, gross profit and income (loss) from operations.

[0000926326-13-000010:notes:133]
Revenue recognition. We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems with related services, which are sold in our principal market, which is the healthcare industry. Revenues related to consumable products are reported net of discounts provided to our customers. Our customer arrangements typically include one or more of the following deliverables:

[0000926326-13-000010:notes:134]
| • | Products—Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies. |

[0000926326-13-000010:notes:135]
| • | Software—Additional software applications that enable incremental functionality of our equipment. |

[0000926326-13-000010:notes:136]
| • | Installation—Installation of equipment as integrated systems at customers' sites. |

[0000926326-13-000010:notes:137]
| • | Post-installation technical support—Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available. |

[0000926326-13-000010:notes:138]
| • | Professional services—Other customer services such as training and consulting. |

[0000926326-13-000010:notes:139]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

[0000926326-13-000010:notes:140]
| • | Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement. |

[0000926326-13-000010:notes:141]
| • | Delivery has occurred. Equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installed installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. We recognize revenue from sales of products to distributors upon delivery, when no contractual obligations for installation exists, assuming all other revenue criteria are met since we do not allow for rights of return or refund. For sales to distributors where we assume contractual installation obligations or new distributors whom we have not fully trained to install our products, the equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period, and we recognize revenue on training and professional services as those services are performed. |

[0000926326-13-000010:notes:142]
| • | Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services. |

[0000926326-13-000010:notes:143]
| • | Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable. |

[0000926326-13-000010:notes:144]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. Effective for new or modified arrangements entered into beginning on January 1, 2011, the date we adopted the revised revenue recognition guidance for arrangements with multiple deliverables on a prospective basis, we allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support services and professional services. When VSOE of fair value is not available, third-party evidence ("TPE") of fair value for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE, TPE and BESP information and obtain formal approval by appropriate levels of management.

[0000926326-13-000010:notes:145]
[same as prior period, unchanged from 0001445305-12-003598:notes:144]

[0000926326-13-000010:notes:146]
We also use the residual method of allocating the arrangement consideration in certain circumstances. We use the residual method to allocate total arrangement consideration between delivered and undelivered items for any arrangements entered into prior to January 1, 2011 and not subsequently materially-modified. The use of the residual method is required by software revenue recognition rules that applied to sales of most of our products and services until the adoption of the new revenue recognition guidance. We also use the residual method to allocate revenue between the software products that enable incremental equipment functionality and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0000926326-13-000010:notes:147]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.

[0000926326-13-000010:notes:148]
Accounts receivable and notes receivable (net investment in sales type leases). We actively manage our accounts receivable to minimize credit risk. We typically sell to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer's impaired ability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position. Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

[0000926326-13-000010:notes:149]
[same as prior period, unchanged from 0001445305-12-003598:notes:150]

[0000926326-13-000010:notes:150]
Sales of accounts receivable. We record the sale of our accounts receivables as “true sales” in accordance with accounting guidance for transfers and servicing of financial assets. During the three months ended March 31, 2013 and 2012, we transferred non-recourse accounts receivable totaling $10.2 million and $12.1 million, respectively, which approximated fair value, to third-party leasing companies. At March 31, 2013 and December 31, 2012, accounts receivable included $0.7 million and $0.7 million, respectively, due from third-party leasing companies for transferred non-recourse accounts receivable.

[0000926326-13-000010:notes:151]
Concentration in revenues and in accounts receivable. There was no single customer accounting for 10% or more of revenues in the three months ended March 31, 2013 or 2012. At March 31, 2013, one customer accounted for 12.9% of our total gross accounts receivable, and there was no single customer accounting for 10% or more of accounts receivable at December 31, 2012. At March 31, 2013, we believe that we have no significant concentration of credit risk.

[0000926326-13-000010:notes:152]
Accounting policy for shipping costs. Outbound freight billed to customers is recorded as product revenue. The related shipping and handling cost is expensed as part of selling, general and administrative expense. Such shipping and handling expenses totaled $1.4 million and $0.7 million for the three months ended March 31, 2013 and 2012, respectively.

[0000926326-13-000010:notes:153]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended March 31, 2013 and 2012 totaled approximately $7.2 million and $6.2 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-13-000010:notes:154]
[same as prior period, unchanged from 0001445305-12-003598:notes:155]

[0000926326-13-000010:notes:155]
[same as prior period, unchanged from 0001445305-12-003598:notes:156]

[0000926326-13-000010:notes:156]
|  | March 31, 2013 |  | December 31, 2012 |
| Equipment | $ | 35,849 |  |  | $ | 32,528 |  |
| Furniture and fixtures | 5,231 |  |  | 5,126 |  |
| Leasehold improvements | 7,048 |  |  | 6,992 |  |
| Purchased software | 20,445 |  |  | 19,870 |  |
| Capital in process | 1,562 |  |  | 2,693 |  |
|  | 70,135 |  |  | 67,209 |  |
| Accumulated depreciation and amortization | (35,438 | ) |  | (33,102 | ) |
| Property and equipment, net | $ | 34,697 |  |  | $ | 34,107 |  |

[0000926326-13-000010:notes:157]
Depreciation and amortization of property and equipment totaled approximately $2.7 million and $1.6 million for the three months ended March 31, 2013 and 2012, respectively.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000926326-13-000010:notes:158]
For the three months ended March 31, 2013 and 2012, the contributions of our segments to net revenues and income from operations, and the reconciliation to total net income, were as follows (amounts in thousands):

[0000926326-13-000010:notes:159]
|  | Three Months Ended March 31, |  | Three Months Ended March 31, |
|  | 2013 |  | 2012 |
|  | Acute Care |  | Non-Acute Care (1) |  | Total |  | Acute Care |  | Total |
| Net revenues from external customers | $ | 65,998 |  |  | $ | 21,112 |  |  | $ | 87,110 |  |  | $ | 64,143 |  |  | $ | 64,143 |  |
| Cost of revenues | 29,303 |  |  | 12,440 |  |  | 41,743 |  |  | 28,394 |  |  | 28,394 |  |
| Gross profit | $ | 36,695 |  |  | $ | 8,672 |  |  | $ | 45,367 |  |  | $ | 35,749 |  |  | $ | 35,749 |  |
| Gross margin % | 55.6 | % |  | 41.1 | % |  | 52.1 | % |  | 55.7 | % |  | 55.7 | % |
| Operating expenses | 32,571 |  |  | 8,627 |  |  | 41,198 |  |  | 32,114 |  |  | 32,114 |  |
| Income from operations | $ | 4,124 |  |  | $ | 45 |  |  | $ | 4,169 |  |  | $ | 3,635 |  |  | $ | 3,635 |  |
| Operating margin % | 6.2 | % |  | 0.2 | % |  | 4.8 | % |  | 5.7 | % |  | 5.7 | % |
| Interest and other income (expense), net |  |  |  |  | (223 | ) |  |  |  | 96 |  |
| Income before provision for income taxes |  |  |  |  | 3,946 |  |  |  |  | 3,731 |  |
| Provision for income taxes |  |  |  |  | 561 |  |  |  |  | 1,380 |  |
| Net income |  |  |  |  | $ | 3,385 |  |  |  |  | $ | 2,351 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the date of acquisition. |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000926326-13-000010:notes:160]
[same as prior period, unchanged from 0001445305-12-003598:notes:159]

[0000926326-13-000010:notes:161]
|  | March 31, 2013 | December 31, 2012 |
| Rebates and lease buyouts | $ | 4,097 |  | $ | 3,179 |  |
| Advance payments from customers | 2,555 |  | 2,829 |  |
| Accrued Group Purchasing Organization (GPO) fees | 2,431 |  | 2,278 |  |
| Technology license purchase obligation, current portion | 1,250 |  | 1,750 |  |
| Taxes payable | 972 |  | 555 |  |
| Other | 1,220 |  | 1,397 |  |
| Total | $ | 12,525 |  | $ | 11,988 |  |


## us-gaap:ScheduleOfCreditLossesRelatedToFinancingReceivablesNoncurrentTableTextBlock

[0000926326-13-000010:notes:162]
The following table summarizes the activity for the allowance for credit losses for the investment in sales-type leases for the three months ended March 31, 2013 and 2012 (in thousands):

[0000926326-13-000010:notes:163]
|  | Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Allowance for credit losses, beginning of period | $ | 607 |  |  | $ | 284 |  |
| Current period provision (reversal) | 13 |  |  | — |  |
| Direct write-downs charged against the allowance | (413 | ) |  | — |  |
| Recoveries of amounts previously charged off | (17 | ) |  | (27 | ) |
| Allowance for credit losses, end of period | $ | 190 |  |  | $ | 257 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000926326-13-000010:notes:164]
The minimum lease payments under sales-type leases as of March 31, 2013 were as follows (in thousands):

[0000926326-13-000010:notes:165]
| 2013 (remaining nine months) | $ | 4,571 |  |
| 2014 | 5,245 |  |
| 2015 | 4,158 |  |
| 2016 | 2,899 |  |
| 2017 | 2,165 |  |
| Thereafter | 500 |  |
| Total | $ | 19,538 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-13-000010:notes:166]
At March 31, 2013, segment assets were as follows (amounts in thousands):

[0000926326-13-000010:notes:167]
|  | March 31, |  | December 31, |
|  |  |  | 2012 |  |  |  |  | 2012 |  |
|  | Acute Care |  | Non-Acute Care |  | Total |  | Acute Care |  | Non-Acute Care |  | Total |
| Segment Assets | $ | 247,846 |  |  | $ | 209,511 |  |  | $ | 457,357 |  |  | $ | 235,186 |  |  | $ | 206,633 |  |  | $ | 441,819 |  |

[0000926326-13-000010:notes:168]
At March 31, 2013, segment depreciation/amortization, and capital expenditures were as follows (amounts in thousands):

[0000926326-13-000010:notes:169]
|  | March 31, |  | March 31, |
|  | 2013 |  | 2012 |
|  | Acute Care |  | Non-Acute Care (1) |  | Total |  | Acute Care |  | Total |
| Depreciation/Amortization | $ | 2,742 |  |  | $ | 1,730 |  |  | $ | 4,472 |  |  | $ | 2,335 |  |  | $ | 2,335 |  |
| Capital Expenditures | 1,000 |  |  | 2,338 |  |  | 3,338 |  |  | $ | 1,438 |  |  | $ | 1,438 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the date of acquisition. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-13-000010:notes:170]
Note 15. Segments

[0000926326-13-000010:notes:171]
Beginning with the acquisition of MTS, which we completed on May 21, 2012, we have organized our business into two operating business segments: Acute Care, which primarily includes products and services sold to hospital customers and Non-Acute Care, which primarily includes products and services sold to customers outside of hospital settings.

[0000926326-13-000010:notes:172]
Since 1992, Omnicell has provided automation and business information solutions to acute care hospitals. We have developed product solutions that help optimize various workflows utilized in hospitals. We have also developed sophisticated sales, installation, and service capabilities to serve the specific and special needs of the acute care environment in hospitals. As the acute care market evolves, we see opportunities to provide medication adherence solutions, which were added to our product line through the acquisition of MTS. A portion of our organization structure and management processes will continue to be structured to optimize sales and service of solutions to the acute care market.

[0000926326-13-000010:notes:173]
[same as prior period, unchanged from 0001445305-12-003598:notes:173]

[0000926326-13-000010:notes:174]
During 2012, we realigned our management reporting structure to report sales of Omnicell's dispensing systems and other related business transactions into long-term care pharmacies and facilities. Accordingly, the operations of this portion of our activities are now being reflected as a part of the Non-Acute Care segment for three months ended March 31, 2013. The impact of this reporting structure change for the three months ended March 31, 2012 was immaterial to our overall reported results.

[0000926326-13-000010:notes:175]
[same as prior period, unchanged from 0001445305-12-003598:notes:175]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-13-000010:notes:176]
[same as prior period, unchanged from 0001445305-12-003598:notes:176]

[0000926326-13-000010:notes:177]
[same as prior period, unchanged from 0001445305-12-003598:notes:177]

[0000926326-13-000010:notes:178]
2008 Stock Repurchase Program

[0000926326-13-000010:notes:179]
In February 2008, our Board of Directors authorized a stock repurchase program (the “2008 Repurchase Program”) for the repurchase of up to $90.0 million of our common stock. The timing, price and volume of the repurchases have been based on market conditions, relevant securities laws and other factors.

[0000926326-13-000010:notes:180]
There were no shares repurchased during both the three months ended March 31, 2013 and 2012 in connection with the 2008 Repurchase Program.

[0000926326-13-000010:notes:181]
From the inception of the 2008 Repurchase Program in February 2008 through March 31, 2013, we have repurchased a total of 5,853,975 shares at an average cost of $15.37 per share through open market purchases. As of March 31, 2013, we have completed the 2008 Repurchase Program having repurchased $90.0 million of our common stock.

[0000926326-13-000010:notes:182]
2012 Stock Repurchase Program

[0000926326-13-000010:notes:183]
On August 1, 2012, our Board of Directors established a new stock repurchase program (the “2012 Repurchase Program”) authorizing share repurchases of up to $50.0 million of our common stock, with no termination date. The timing, price and volume of repurchases will be based on market conditions, relevant securities laws and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions or pursuant to a Rule 10b-18 plan. The stock repurchase program does not obligate Omnicell to repurchase any specific number of shares, and Omnicell may terminate or suspend the repurchase program at any time.

[0000926326-13-000010:notes:184]
Through March 31, 2013, we have not repurchased any shares through the 2012 Repurchase Program and therefore had $50.0 million of authorized funds to repurchase shares under the 2012 Repurchase Program as of March 31, 2013.


## omcl:AccruedLiabilitiesTextBlock

[0000926326-13-000010:notes:185]
[same as prior period, unchanged from 0001445305-12-003598:notes:186]


## omcl:DeferredGrossProfitTableTextBlock

[0000926326-13-000010:notes:186]
[same as prior period, unchanged from 0001445305-12-003598:notes:187]

[0000926326-13-000010:notes:187]
|  | March 31, 2013 |  | December 31, 2012 |
| Sales of medication and supply dispensing systems and packaging equipment, which have been delivered and invoiced but not yet installed | $ | 39,937 |  |  | $ | 30,138 |  |
| Cost of revenues, excluding installation costs | (12,999 | ) |  | (9,366 | ) |
| Deferred gross profit | $ | 26,938 |  |  | $ | 20,772 |  |


## omcl:DeferredGrossProfitTextBlock

[0000926326-13-000010:notes:188]
[same as prior period, unchanged from 0001445305-12-003598:notes:189]


## omcl:ImpairmentOfSoftwareDevelopmentCostsTableTextBlock

[0000926326-13-000010:notes:189]
Note 16. Asset Impairment

[0000926326-13-000010:notes:190]
Impairment of Software Development Costs

[0000926326-13-000010:notes:191]
As part of the continuing integration of MTS, during the first quarter of 2013, we reorganized our management team, including the software development department within the Non-Acute Care segment. The Non-Acute Care segment had capitalized approximately $1.8 million of software development costs through the end of the first quarter of 2013 associated with a software solution under development which was intended to assist pharmacies in manual packaging of prescriptions. In connection with its financial statement close process for the quarter ended March 31, 2013, management reassessed the viability of this project and the net realizable value of capitalized costs in light of its decision to change the related product road map and redesign this product based on evolving market demands. As part of this redesign process, new functionality and capabilities will need to be added to the product before commercialization. This redesign is intended to provide a more robust global platform providing larger scalability and significant functionality not contained in our current beta version. As such, we have determined we can no longer support the technological feasibility of this project in conjunction with our software capitalization policy. Therefore, we charged these costs, in the amount of $1.8 million ($0.03 per diluted share, net of tax), to expense as a component of research and development in the accompanying consolidated condensed statement of operations.


## omcl:NetInvestmentsInSalesTypeLeasesTextBlock

[0000926326-13-000010:notes:192]
[same as prior period, unchanged from 0001445305-12-003598:notes:190]

[0000926326-13-000010:notes:193]
[same as prior period, unchanged from 0001445305-12-003598:notes:191]

[0000926326-13-000010:notes:194]
|  | March 31, 2013 |  | December 31, 2012 |
| Net minimum lease payments to be received | $ | 19,538 |  |  | $ | 19,665 |  |
| Less unearned interest income portion | 1,185 |  |  | 1,205 |  |
| Net investment in sales-type leases | 18,353 |  |  | 18,460 |  |
| Less current portion(1) | 5,410 |  |  | 5,232 |  |
| Non-current net investment in sales-type leases(2) | $ | 12,943 |  |  | $ | 13,228 |  |

[0000926326-13-000010:notes:195]
(1)     A component of other current assets. This amount is net of allowance for doubtful accounts of $0.1 million as of March 31, 2013 and $0.5 million as of December 31, 2012.

[0000926326-13-000010:notes:196]
(2)     This amount is net of allowance for doubtful accounts of $0.1 million as of March 31, 2013 and $0.1 million as of December 31, 2012.
