# OMCL 8-K — 0001104659-13-036605 filed 2013-05-02

## item codes, every 8-K on or before 2013-05-09

- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2013-05-09

- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-13-036605:8k_2_02:1]
EX-99.1
2
a13-11345_1ex99d1.htm
EX-99.1

[0001104659-13-036605:8k_2_02:2]
Exhibit 99.1

[0001104659-13-036605:8k_2_02:3]
| Contact: |  |
| Rob Seim | Omnicell, Inc. |
| Chief Financial Officer | 590 East Middlefield Road |
| 800-850-6664, ext. 6478 | Mountain View, CA 94043 |
| rob.seim@omnicell.com |  |

[0001104659-13-036605:8k_2_02:4]
Omnicell Announces First Quarter 2013 Results

[0001104659-13-036605:8k_2_02:5]
MOUNTAIN VIEW, Calif. — May 2, 2013 — Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its quarter ended March 31, 2013.

[0001104659-13-036605:8k_2_02:6]
GAAP results: Revenue for the first quarter of 2013 was $87.1 million, up $23.0 million or 35.8% from the first quarter of 2012 and down $3.1 million or 3.4% from the fourth quarter of 2012.

[0001104659-13-036605:8k_2_02:7]
First quarter 2013 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $3.4 million, or $0.10 per diluted share. This compares to net income of $2.4 million, or $0.07 per diluted share in the first quarter of 2012 and net income of $5.5 million, or $0.16 per diluted share  in the fourth quarter of 2012.

[0001104659-13-036605:8k_2_02:8]
Non-GAAP results: Non-GAAP net income was $7.4 million for the first quarter of 2013, or $0.21 per diluted share. Non-GAAP net income for the first quarter excludes $2.9 million of stock-based compensation expense, $0.7 million ($0.4 million net of the $0.3 million tax effect) of reorganization costs related to the continued integration of MTS Medication Technologies, Inc. (“MTS”), and $1.1 million ($0.6 million net of the $0.5 million tax effect) of amortization expense for all intangible assets acquired in connection with the acquisition of MTS in May 2012 and earlier acquisitions by Omnicell. This compares to non-GAAP net income of $4.6 million, or $0.13 per diluted share for the first quarter of 2012, excluding $2.2 million of stock-based compensation expense. First quarter 2013 results compare to non-GAAP net income of $8.6 million, or $0.25 per diluted share for the fourth quarter of 2012. Non-GAAP net income for the fourth quarter excluded $2.4 million of stock-based compensation expense and $1.1 million ($0.6 million net of the $0.5 million tax effect) of amortization expense for all intangible assets acquired in connection with the acquisition of MTS and earlier acquisitions by Omnicell.

[0001104659-13-036605:8k_2_02:9]
“Our overall results exceeded expectations for the first quarter of 2013,” said Randall Lipps, Omnicell president, chairman and CEO. “Organizationally, we’ve taken important steps toward optimizing the growth opportunities in medication management across the spectrum of healthcare settings from hospitals to long term care to home care. We believe these actions and our solid performance this quarter positions the company for a strong fiscal 2013.”

[0001104659-13-036605:8k_2_02:10]
Omnicell Conference Call Information

[0001104659-13-036605:8k_2_02:11]
Omnicell will hold a conference call today at 1:30 p.m. PT to discuss first quarter financial results. The conference call can be monitored by dialing 1-866-830-5685 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 45591563. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 3:30 p.m. PT and will be available until 8:59 p.m. PT on June 2. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, conference code # 45591563.

[0001104659-13-036605:8k_2_02:12]
About Omnicell

[0001104659-13-036605:8k_2_02:13]
For over 20 years the mission of Omnicell (NASDAQ: OMCL) has been creating new efficiencies to improve patient care, anywhere it is delivered. Omnicell is a leading supplier of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum, from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home.

[0001104659-13-036605:8k_2_02:14]
Since 1992, more than 2,600 Acute Care customers worldwide have utilized Omnicell’s medication automation, supply chain and analytics solutions to enable them to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety. Omnicell Non-Acute Care solutions, including its MTS Medication Technologies brand, provide innovative medication adherence packaging solutions that can help reduce costly hospital readmissions and enable approximately 6,000 institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0001104659-13-036605:8k_2_02:15]
For more information about Omnicell, please visit www.omnicell.com.

[0001104659-13-036605:8k_2_02:16]
Forward-Looking Statements

[0001104659-13-036605:8k_2_02:17]
To the extent any statements contained in this release deal with information that is not historical, these statements are necessarily forward-looking. As such, they are subject to the occurrence of many events outside Omnicell’s control and are subject to various risk factors that could cause actual results to differ materially from those expressed or implied in any forward-looking statement. The risk factors are described in the Company’s Securities and Exchange Commission (SEC) filings and include, the potential failure to realize the anticipated benefits of the MTS acquisition, including our ability to take advantage of the growth opportunities in medication management across the spectrum of healthcare settings from long term care to home care, unfavorable general economic and market conditions, risks to growth and acceptance of our products and services and to growth of the clinical automation and workflow automation market generally, the potential of increasing competition, potential regulatory changes, and the ability of the company to improve sales productivity to grow product backlog and to develop new products and integrate acquired companies. Prospective investors are cautioned not to place undue reliance on forward-looking statements.

[0001104659-13-036605:8k_2_02:18]
Use of Non-GAAP Financial Information

[0001104659-13-036605:8k_2_02:19]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0001104659-13-036605:8k_2_02:20]
Our non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0001104659-13-036605:8k_2_02:21]
a)  Stock-based compensation expense impact of Accounting Standards Codification (ASC) 718. We recognize equity plan-related compensation expenses, which represent the fair value of all share-based payments to employees, including grants of employee stock options, as required under ASC 718, “Stock Compensation” as non-GAAP adjustments in each period.

[0001104659-13-036605:8k_2_02:22]
b)  Reorganization costs. During the three months ended March 31, 2013, we recorded $0.7 million of reorganization costs related to our Non-Acute Care segment ($0.4 million net of the $0.3 million tax effect). This charge is not expected to be recurring and, as such, the financial impact is excluded from our non-GAAP results.

[0001104659-13-036605:8k_2_02:23]
c)  Intangible assets amortization from business acquisitions. We excluded from our non-GAAP results the amortization expense resulting from the MTS acquisition as well as earlier Omnicell acquisitions. This impacts the first quarter of fiscal 2013 non-GAAP results by $1.1 million ($0.6 million net of the $0.5 million tax effect) and the fourth quarter of fiscal 2012 non-GAAP results by $1.1 million ($0.6 million net of the $0.5 million tax effect). These non-cash charges are not, considered by management, to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0001104659-13-036605:8k_2_02:24]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock option grants.

[0001104659-13-036605:8k_2_02:25]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0001104659-13-036605:8k_2_02:26]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0001104659-13-036605:8k_2_02:27]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0001104659-13-036605:8k_2_02:28]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0001104659-13-036605:8k_2_02:29]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0001104659-13-036605:8k_2_02:30]
Set forth below are additional reasons why share-based compensation expense related to ASC 718 is excluded from our non-GAAP financial measures:

[0001104659-13-036605:8k_2_02:31]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0001104659-13-036605:8k_2_02:32]
ii)  We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0001104659-13-036605:8k_2_02:33]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense.

[0001104659-13-036605:8k_2_02:34]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0001104659-13-036605:8k_2_02:35]
· Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0001104659-13-036605:8k_2_02:36]
· Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0001104659-13-036605:8k_2_02:37]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0001104659-13-036605:8k_2_02:38]
Omnicell, Inc.

[0001104659-13-036605:8k_2_02:39]
Condensed Consolidated Statements of Operations

[0001104659-13-036605:8k_2_02:40]
(in thousands, except per share data)

[0001104659-13-036605:8k_2_02:41]
|  |  | Three Months Ended |  |
|  |  | March 31, 2013 |  | December 31, 2012 |  | March 31, 2012 |  |
| Revenues: |  | (unaudited) |  | (unaudited) |  | (unaudited) |  |
| Product |  | $ | 69,236 |  | $ | 72,415 |  | $ | 48,524 |  |
| Services and other revenues |  | 17,874 |  | 17,754 |  | 15,619 |  |
| Total revenue |  | 87,110 |  | 90,169 |  | 64,143 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues |  | 33,547 |  | 32,837 |  | 20,296 |  |
| Cost of services and other revenues |  | 8,196 |  | 7,956 |  | 8,098 |  |
| Total cost of revenues |  | 41,743 |  | 40,793 |  | 28,394 |  |
| Gross profit |  | 45,367 |  | 49,376 |  | 35,749 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development |  | 7,954 |  | 6,188 |  | 6,494 |  |
| Selling, general, and administrative |  | 33,244 |  | 33,354 |  | 25,620 |  |
| Total operating expenses |  | 41,198 |  | 39,542 |  | 32,114 |  |
| Income from operations |  | 4,169 |  | 9,834 |  | 3,635 |  |
| Other income and (expense), net |  | (223 | ) | (108 | ) | 96 |  |
| Income before provision for income taxes |  | 3,946 |  | 9,726 |  | 3,731 |  |
| Provision for income taxes |  | 561 |  | 4,194 |  | 1,380 |  |
| Net income |  | $ | 3,385 |  | $ | 5,532 |  | $ | 2,351 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic |  | $ | 0.10 |  | $ | 0.17 |  | $ | 0.07 |  |
| Diluted |  | $ | 0.10 |  | $ | 0.16 |  | $ | 0.07 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic |  | 33,900 |  | 33,282 |  | 33,365 |  |
| Diluted |  | 34,820 |  | 34,128 |  | 34,341 |  |

[0001104659-13-036605:8k_2_02:42]
Omnicell, Inc.

[0001104659-13-036605:8k_2_02:43]
Condensed Consolidated Balance Sheets

[0001104659-13-036605:8k_2_02:44]
(In thousands)

[0001104659-13-036605:8k_2_02:45]
|  |  | March 31, |  | December 31, |  |
|  |  | 2013 |  | 2012 |  |
|  |  | (unaudited) |  | (1) |  |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 69,817 |  | $ | 62,313 |  |
| Short-term investments |  | — |  | — |  |
| Accounts receivable, net |  | 65,703 |  | 55,116 |  |
| Inventories |  | 26,125 |  | 26,903 |  |
| Prepaid expenses |  | 16,049 |  | 15,392 |  |
| Deferred tax assets |  | 11,860 |  | 11,860 |  |
| Other current assets |  | 7,532 |  | 9,172 |  |
| Total current assets |  | 197,086 |  | 180,756 |  |
| Property and equipment, net |  | 34,697 |  | 34,107 |  |
| Non-current net investment in sales-type leases |  | 12,943 |  | 13,228 |  |
| Goodwill |  | 111,343 |  | 111,407 |  |
| Other intangible assets |  | 84,529 |  | 85,550 |  |
| Non-current deferred tax assets |  | 1,126 |  | 993 |  |
| Other assets |  | 15,633 |  | 15,778 |  |
| Total assets |  | $ | 457,357 |  | $ | 441,819 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |
| Accounts payable |  | $ | 18,379 |  | $ | 18,255 |  |
| Accrued compensation |  | 6,948 |  | 11,613 |  |
| Accrued liabilities |  | 12,525 |  | 11,988 |  |
| Deferred service revenue |  | 20,821 |  | 20,449 |  |
| Deferred gross profit |  | 26,938 |  | 20,772 |  |
| Total current liabilities |  | 85,611 |  | 83,077 |  |
| Non-current deferred service revenue |  | 19,463 |  | 19,892 |  |
| Non-current deferred tax liabilities |  | 25,548 |  | 26,491 |  |
| Other long-term liabilities |  | 4,942 |  | 4,809 |  |
| Total liabilities |  | 135,564 |  | 134,269 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Total stockholders’ equity |  | 321,793 |  | 307,550 |  |
| Total liabilities and stockholders’ equity |  | $ | 457,357 |  | $ | 441,819 |  |

[0001104659-13-036605:8k_2_02:46]
(1)  Information derived from our December 31, 2012 audited Consolidated Financial Statements.

[0001104659-13-036605:8k_2_02:47]
Omnicell, Inc.

[0001104659-13-036605:8k_2_02:48]
Reconciliation of GAAP to Non-GAAP

[0001104659-13-036605:8k_2_02:49]
(In thousands, except per share data, unaudited)

[0001104659-13-036605:8k_2_02:50]
|  |  | Three Months Ended |  |
|  |  | March 31, 2013 |  | December 31, 2012 |  | March 31, 2012 |  |
|  |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  |
| GAAP |  | $ | 3,385 |  | $ | 0.10 |  | $ | 5,532 |  | $ | 0.16 |  | $ | 2,351 |  | $ | 0.07 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Business acquisition costs |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reorganization costs (a) |  | 732 |  |  |  | — |  |  |  | — |  |  |  |
| Amortization of intangible assets acquired by acquisition (b) |  | 1,060 |  |  |  | 1,057 |  |  |  | — |  |  |  |
| Subtotal pretax adjustments |  | 1,792 |  |  |  | 1,057 |  |  |  | — |  |  |  |
| Income tax effect of non-GAAP adjustments (c) |  | (716 | ) |  |  | (423 | ) |  |  | — |  |  |  |
| Subtotal after-tax adjustments |  | 1,076 |  |  |  | 634 |  |  |  | — |  |  |  |
| ASC 718 share-based compensation adjustment (d) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 305 |  |  |  | 236 |  |  |  | 268 |  |  |  |
| Operating expenses |  | 2,621 |  |  |  | 2,197 |  |  |  | 1,939 |  |  |  |
| Total after-tax adjustments |  | 4,002 |  | 0.11 |  | 3,067 |  | 0.09 |  | 2,207 |  | 0.06 |  |
| Non-GAAP |  | $ | 7,387 |  | $ | 0.21 |  | $ | 8,599 |  | $ | 0.25 |  | $ | 4,558 |  | $ | 0.13 |  |

[0001104659-13-036605:8k_2_02:51]
(a)  This adjustment is for reorganization costs related to our Non-Acute Care segment for the three months ended March 31, 2013.

[0001104659-13-036605:8k_2_02:52]
(b) Beginning with the second quarter of 2012, we are recognizing the amortization expense resulting from all intangible assets recorded from business acquisitions as a non-GAAP adjustment, including MTS and prior acquisitions.

[0001104659-13-036605:8k_2_02:53]
(c)  Tax effects are calculated using the effective tax rates for the respective periods presented.

[0001104659-13-036605:8k_2_02:54]
(d) This adjustment reflects the accounting impact of non-cash stock-based compensation expense related to the impact of ASC 718 for the periods shown.

[0001104659-13-036605:8k_2_02:55]
Omnicell, Inc.

[0001104659-13-036605:8k_2_02:56]
Calculation of Adjusted EBITDA (1)

[0001104659-13-036605:8k_2_02:57]
(In thousands, unaudited)

[0001104659-13-036605:8k_2_02:58]
|  |  | Three Months Ended |  |
|  |  | March 31, 2013 |  | December 31, 2012 |  | March 31, 2012 |  |
| GAAP net income |  | $ | 3,385 |  | $ | 5,532 |  | $ | 2,351 |  |
| Add back: |  |  |  |  |  |  |  |
| ASC 718 stock compensation expense |  | 2,926 |  | 2,433 |  | 2,207 |  |
| Reorganization costs |  | 732 |  | — |  | — |  |
| Interest |  | 106 |  | (2 | ) | (31 | ) |
| Depreciation and amortization expense |  | 4,471 |  | 4,077 |  | 2,335 |  |
| Income tax expense |  | 561 |  | 4,194 |  | 1,380 |  |
| Non-GAAP adjusted EBITDA (1) |  | $ | 12,181 |  | $ | 16,234 |  | $ | 8,242 |  |

[0001104659-13-036605:8k_2_02:59]
(1) Defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including stock compensation expense, per ASC 718, as well excluding certain non-GAAP adjustments. The non-GAAP adjustments for the quarter ended March 31, 2013 also exclude transaction and integration costs for MTS, acquired in May 2012.
