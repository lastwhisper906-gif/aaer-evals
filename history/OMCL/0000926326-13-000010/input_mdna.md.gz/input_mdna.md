# OMCL MD&A — 0000926326-13-000010


## mdna

[0000926326-13-000010:mdna:1]
[same as prior period, unchanged from 0001445305-12-003598:mdna:1]

[0000926326-13-000010:mdna:2]
[same as prior period, unchanged from 0001445305-12-003598:mdna:2]

[0000926326-13-000010:mdna:3]
This Quarterly Report on Form 10-Q contains forward-looking statements. The forward looking statements are contained principally in the sections entitled “Risk Factors” and “Management's Discussion and Analysis of Financial Condition and Results of Operations.” These statements involve known and unknown risks, uncertainties and other factors which may cause our actual results, performance or achievements to be materially different from any future results, performances or achievements expressed or implied by the forward-looking statements. Forward-looking statements include, but are not limited to, statements about:

[0000926326-13-000010:mdna:4]
| • | the extent and timing of future revenues, including the amounts of our current backlog, which represents firm orders that have not completed installation and therefore have not been recognized as revenue; |

[0000926326-13-000010:mdna:5]
| • | the size or growth of our market or market share; |

[0000926326-13-000010:mdna:6]
[same as prior period, unchanged from 0001445305-12-003598:mdna:7]

[0000926326-13-000010:mdna:7]
[same as prior period, unchanged from 0001445305-12-003598:mdna:8]

[0000926326-13-000010:mdna:8]
[same as prior period, unchanged from 0001445305-12-003598:mdna:10]

[0000926326-13-000010:mdna:9]
[same as prior period, unchanged from 0001445305-12-003598:mdna:9]

[0000926326-13-000010:mdna:10]
| • | our ability to protect our intellectual property and operate our business without infringing upon the intellectual property rights of others; |

[0000926326-13-000010:mdna:11]
| • | our ability to generate cash from operations and our estimates regarding the sufficiency of our cash resources; and |

[0000926326-13-000010:mdna:12]
| • | our ability to acquire companies, businesses, products or technologies on commercially reasonable terms and integrate such acquisitions effectively. |

[0000926326-13-000010:mdna:13]
In some cases, you can identify forward-looking statements by terms such as "anticipates," "believes," "could," "estimates," "expects," "intends," "may," "plans," "potential," "predicts," "projects," "should," "will," "would" and similar expressions intended to identify forward-looking statements. Forward-looking statements reflect our current views with respect to future events, are based on assumptions and are subject to risks and uncertainties.  We discuss many of these risks in this Quarterly Report on Form 10-Q in greater detail in Part II - Section 1A. “Risk Factors” below. Given these uncertainties, you should not place undue reliance on these forward-looking statements. Also, forward-looking statements represent our estimates and assumptions only as of the date of this Quarterly Report on Form 10-Q. You should also read our Annual Report on Form 10-K and the documents that we reference in the Annual Report on Form 10-K and have filed as exhibits, completely and with the understanding that our actual future results may be materially different from what we expect.  All references in this report to "Omnicell, Inc.," "Omnicell," "our," "us," "we," or the "Company" collectively refer to Omnicell, Inc., a Delaware corporation, and its subsidiaries.

[0000926326-13-000010:mdna:14]
[same as prior period, unchanged from 0001445305-12-003598:mdna:14]

[0000926326-13-000010:mdna:15]
We are a leading provider of automation and business information solutions enabling healthcare systems to streamline the medication administration process and manage costly medical supplies for increased operational efficiency and enhanced patient safety. Our automation, analytics and medication adherence solutions are designed to enable healthcare facilities to acquire, manage, dispense and administer medications and medical-surgical supplies and are intended to enhance patient safety, reduce medication errors, reduce operating costs, improve workflow and increase operational efficiency.

[0000926326-13-000010:mdna:16]
Approximately 2,800 hospitals utilize one or more of our products, of which more than 1,700 hospitals in the United States have installed our automated hardware/software solutions for controlling, dispensing, acquiring, verifying, tracking and analyzing medications and medical and surgical supplies. Approximately 6,000 institutional and retail pharmacies utilize our medication adherence packaging solutions.

[0000926326-13-000010:mdna:17]
The medical industry has become increasingly aware that the human element of patient care inevitably creates the risk of medication administration errors.

[0000926326-13-000010:mdna:18]
The Institute of Medicine, a non-profit, non-governmental arm of the National Academies, published a report in 2006 that estimated that 1.5 million medication errors are made each year in the United States. Acute care facilities are required to adhere to medication regulatory controls that we believe cannot be adequately supported by manual tracking systems or partially automated systems. Nursing shortages add an additional challenge to acute care facilities to meet regulatory controls and improve patient safety while still providing adequate patient care. Non-acute care facilities face similar safety challenges. According to "Adherence to Long-Term Therapies-Evidence for Action," the World Health Organization has stated, “Across diseases, adherence is the single most important modifiable factor that compromises treatment outcome.” U.S. health system thought leaders see medication adherence as a key requirement for closing the medication loop and delivering better clinical outcomes and financial results. Medication non-adherence is described as a critical problem creating approximately $290 billion in extra costs, according to the New England Healthcare Institute, resulting in approximately 125,000 deaths per year. In addition, the Centers for Medicare & Medicaid Services states that 11% of all hospital admissions are related to medication non-adherence.

[0000926326-13-000010:mdna:19]
We provide solutions to help healthcare systems and caregivers address these problems. We believe that our patient-centric medication and supply management solutions help improve workflow efficiencies and patient outcomes.

[0000926326-13-000010:mdna:20]
Business Segments

[0000926326-13-000010:mdna:21]
Our business is organized into two operating business segments: Acute Care, which primarily includes products and services sold to hospital customers, and Non-Acute Care, which primarily includes products and services sold to customers outside of the hospital setting.

[0000926326-13-000010:mdna:22]
Acute Care

[0000926326-13-000010:mdna:23]
In acute care facilities, our solutions utilize advanced, software‑based medication control and tracking algorithms that interact with hardware security features, resulting in a system that provides both the pharmacist and the nurse real-time safety controls. Our solutions also go a step further by providing medication bar code verification at every step of the medication administration process, from entry to the hospital through to administration to a patient. Our systems enable our customers to reduce or eliminate inefficiencies such as manual tracking and reconciliations, nursing time spent in obtaining medications and in performing inventory control and extraneous process steps.

[0000926326-13-000010:mdna:24]
Similar to our medication solutions, our medical and surgical supply systems provide acute care hospitals control over consumable supplies critical to providing quality healthcare. Our solutions provide inventory control software that is designed to ensure critical supplies are always stocked in the right locations. At the same time, usage tracking helps hospital administrators to ensure that money is not wasted on excessive stores of supplies and helps optimize reimbursement by improving charge capture. Our systems automate the tracking of activities in perioperative areas such as the operating room and catheter lab, including tracking implantable tissue grafts for additional patient safety and regulatory compliance.

[0000926326-13-000010:mdna:25]
Additionally, we offer analytics and reporting software for pharmacists and materials managers to more easily manage inventory flow, tracking and optimization. These reports are often used to identify hospital employees who may be improperly diverting pharmaceuticals stored in the automated dispensing cabinets. Such diversion or theft, especially of controlled substances, could result in black market sales or other illicit uses.

[0000926326-13-000010:mdna:26]
Non-Acute Care

[0000926326-13-000010:mdna:27]
Our Non-Acute Care product lines were primarily added to our solutions through the acquisition of MedPak Holdings, Inc. ("MedPak") in May 2012. MedPak is the parent company of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems, and a wholly-owned Omnicell subsidiary. MTS manufactures proprietary medication dispensing systems and related products for use by medication prescription providers: primarily institutional pharmacies servicing long-term care and correctional facilities. These systems utilize consumable medication punch cards and specialized machines that allow the pharmacies to automatically or semi-automatically assemble, fill and seal drugs into medication punch cards representing a weekly or monthly supply of a patient's medication. The use of these cards and machines provides a cost-effective customized package personalized to the patient. The punch card medication dispensing system provides tamper evident packaging and promotes medication compliance.

[0000926326-13-000010:mdna:28]
Our Non-Acute Care systems are used by institutional pharmacists to package medications into blister cards that form the backbone of medication control in non-acute care facilities. Our line of equipment provides solutions ranging from low cost semi-automated packaging systems to fully automated robotic systems that help eliminate human error and increase the efficiency of packaging medication for non-acute care facilities. Our OnDemand line of multi-medication packaging equipment can be used by retail pharmacies to provide enhanced packages that we believe increase the probability that patients will adhere to the medication regimen prescribed by their healthcare provider.

[0000926326-13-000010:mdna:29]
Our Non-Acute Care segment primarily manufactures and sells consumable medication blister cards, packaging equipment and ancillary products throughout the United States, Canada, Europe and Australia. This segment's customers are predominantly institutional and independent retail pharmacies that supply nursing homes, assisted living and correctional facilities with prescription medications for their patients. We manufacture our proprietary consumable blister cards and most of our packaging equipment in our own facilities. This manufacturing process uses integrated equipment for manufacturing the consumable medication blister cards. In addition, we utilize the services of contract manufacturers for some of our packaging equipment. We distribute products directly in the United Kingdom and in Germany through our subsidiaries in those countries.

[0000926326-13-000010:mdna:30]
Our acquisition of MTS aligns us with the long-term trends of the healthcare market to participate in the management of patient health across the continuum of care. Omnicell and MTS bring capabilities to each other that strengthen the product lines and expand the medication management coverage of both companies.

[0000926326-13-000010:mdna:31]
Our key business strategies include:

[0000926326-13-000010:mdna:32]
| • | Further penetrating the existing market through sustaining technological leadership in our products by: |

[0000926326-13-000010:mdna:33]
•Consistently innovating our product and service offerings; and

[0000926326-13-000010:mdna:34]
•Maintaining our flexibility in customer product design and in the installation process.

[0000926326-13-000010:mdna:35]
| • | Increasing penetration of the international market by: |

[0000926326-13-000010:mdna:36]
•Bringing new products and technologies to market that are specific to international markets;

[0000926326-13-000010:mdna:37]
•Establishing direct sales, distribution or other capabilities when and where it is appropriate;

[0000926326-13-000010:mdna:38]
| • | Partnering with companies that have sales, distribution or other capabilities that we do not possess in non-U.S. geographies; and |

[0000926326-13-000010:mdna:39]
•Increasing customer awareness of safety issues in the administration of medications.

[0000926326-13-000010:mdna:40]
| • | Expanding our product offering through acquisitions and partnerships. |

[0000926326-13-000010:mdna:41]
Operations During the Three Months Ended March 31, 2013

[0000926326-13-000010:mdna:42]
The consolidated results presented for the three months ended March 31, 2013 reflect the impact of the acquisition of MTS since May 21, 2012 as a part of the Non-Acute Care segment.

[0000926326-13-000010:mdna:43]
Revenues grew year-over-year for both product and services, with overall revenue growth of 35.8%, comparing $87.1 million for the first quarter of 2013 with $64.1 million for the first quarter of 2012. Primarily as a result of the acquisition of MTS, the Non-Acute Care segment contributed $21.1 million of revenue for the three months ended March 31, 2013.

[0000926326-13-000010:mdna:44]
The Non-Acute Care segment for the first quarter of 2013 contributed $19.9 million and $1.2 million to the overall product and service revenue, respectively. The Acute Care segment contributed revenues of $49.3 million and $16.7 million to product and service revenue, respectively, for the three months ended March 31, 2013 as compared to $48.5 million and $15.6 million during the same period in 2012. Overall product and service margins increased by $9.6 million, or 26.9% for the three months ended March 31, 2013 as compared to the same period in 2012.

[0000926326-13-000010:mdna:45]
During the first quarter of 2013, we recognized a slight decrease of 3.4% in total revenues from the fourth quarter of 2012. Product revenue decreased by $3.2 million, or 4.4%, while service revenue increased slightly, by 0.7%. Overall gross margins for the first quarter of 2013 declined to 52.1% from 54.8% in the fourth quarter of 2012. Product gross margins declined to 51.5% on revenue of $69.2 million as compared with 54.7% on revenue of $72.4 million during the fourth quarter of 2012. Service gross margins increased slightly, to 54.1% on revenue of $17.9 million as compared to 53.2% margins on $17.8 million in revenue during the fourth quarter of 2012.

[0000926326-13-000010:mdna:46]
Cash, cash equivalents and short-term investments increased by $7.5 million during the three months ended March 31, 2013, to $69.8 million from $62.3 million at December 31, 2012. The change in cash, cash equivalents and short-term investments for the quarter was relatively flat from the prior quarter, with the increase primarily a result of cash received for shares issued under our stock option and employee stock purchase plans of approximately $5.0 million.

[0000926326-13-000010:mdna:47]
During the first quarter of 2013, we implemented a reorganization within our Non-Acute Care segment. This reorganization reduced headcount slightly and as a result, we incurred $0.7 million in severance and related expenses and an additional $0.4 million related to accelerated stock option vesting. This reorganization is intended to promote a stronger integration strategy, focus and growth.

[0000926326-13-000010:mdna:48]
[same as prior period, unchanged from 0001445305-12-003598:mdna:33]

[0000926326-13-000010:mdna:49]
[same as prior period, unchanged from 0001445305-12-003598:mdna:34]

[0000926326-13-000010:mdna:50]
[same as prior period, unchanged from 0001445305-12-003598:mdna:35]

[0000926326-13-000010:mdna:51]
[same as prior period, unchanged from 0001445305-12-003598:mdna:36]

[0000926326-13-000010:mdna:52]
[same as prior period, unchanged from 0001445305-12-003598:mdna:37]

[0000926326-13-000010:mdna:53]
[same as prior period, unchanged from 0001445305-12-003598:mdna:38]

[0000926326-13-000010:mdna:54]
[same as prior period, unchanged from 0001445305-12-003598:mdna:39]

[0000926326-13-000010:mdna:55]
[same as prior period, unchanged from 0001445305-12-003598:mdna:40]

[0000926326-13-000010:mdna:56]
During the three months ended March 31, 2013, there were no significant changes in our critical accounting policies and estimates.

[0000926326-13-000010:mdna:57]
Please refer to Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended December 31, 2012 for a more complete discussion of our other critical accounting policies and estimates.

[0000926326-13-000010:mdna:58]
Recently Adopted Accounting Standards

[0000926326-13-000010:mdna:59]
In February 2013, FASB issued 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income (AOCI), which aims to improve the reporting of reclassifications out of AOCI. This update requires an entity to report the effect of significant reclassifications out of AOCI on the respective line items in net income if the amount being reclassified is required under GAAP to be reclassified in its entirety to net income. For other amounts that are not required under GAAP to be reclassified in their entirety to net income in the same reporting period, an entity is required to cross-reference other disclosures required under GAAP that provide additional detail about those amounts.  The amendments do not change the current requirements for reporting net income or other comprehensive income in financial statements. For public entities, the amendments are effective prospectively for reporting periods beginning after December 15, 2012. We adopted this guidance in the first quarter of 2013. This update did not have any significant impact on our financial position, operating results or cash flows.

[0000926326-13-000010:mdna:60]
[same as prior period, unchanged from 0001445305-12-003598:mdna:47]

[0000926326-13-000010:mdna:61]
The table below shows the components of our results of operations as percentages of total revenues for the three months ended March 31, 2013 and 2012 (in thousands, except percentages):

[0000926326-13-000010:mdna:62]
|  | Three Months Ended March 31, |  |
|  | 2013 |  | 2012 |  |
|  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 69,236 |  |  | 79.5 | % |  | $ | 48,524 |  |  | 75.6 | % |  |
| Service and other revenues | 17,874 |  |  | 20.5 | % |  | 15,619 |  |  | 24.4 | % |  |
| Total revenues | 87,110 |  |  | 100.0 | % |  | 64,143 |  |  | 100.0 | % |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 33,547 |  |  | 38.5 | % |  | 20,296 |  |  | 31.6 | % |  |
| Cost of service and other revenues | 8,196 |  |  | 9.4 | % |  | 8,098 |  |  | 12.6 | % |  |
| Total cost of revenues | 41,743 |  |  | 47.9 | % |  | 28,394 |  |  | 44.2 | % |  |
| Gross profit | 45,367 |  |  | 52.1 | % |  | 35,749 |  |  | 55.8 | % |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 7,954 |  |  | 9.1 | % |  | 6,494 |  |  | 10.1 | % |  |
| Selling, general and administrative | 33,244 |  |  | 38.2 | % |  | 25,620 |  |  | 39.9 | % |  |
| Total operating expenses | 41,198 |  |  | 47.3 | % |  | 32,114 |  |  | 50.0 | % |  |
| Income from operations | 4,169 |  |  | 4.8 | % |  | 3,635 |  |  | 5.8 | % |  |
| Interest and other income (expense), net | (223 | ) |  | (0.3 | )% |  | 96 |  |  | 0.1 | % |  |
| Income before provision for income taxes | 3,946 |  |  | 4.5 | % |  | 3,731 |  |  | 5.9 | % |  |
| Provision for income taxes | 561 |  |  | 0.6 | % |  | 1,380 |  |  | 2.2 | % |  |
| Net income | $ | 3,385 |  |  | 3.9 | % |  | $ | 2,351 |  |  | 3.7 | % |  |

[0000926326-13-000010:mdna:63]
[same as prior period, unchanged from 0001445305-12-003598:mdna:50]

[0000926326-13-000010:mdna:64]
[same as prior period, unchanged from 0001445305-12-003598:mdna:51]

[0000926326-13-000010:mdna:65]
The table below shows our product revenues, cost of product revenues and gross profit for the three months ended March 31, 2013 and 2012 and the percentage changes between those periods (in thousands, except percentages):

[0000926326-13-000010:mdna:66]
|  | Three Months Ended March 31, |
|  | 2013 |  | 2012 |  | % Change |
| Product revenues | $ | 69,236 |  |  | $ | 48,524 |  |  | 42.7 | % |
| Cost of product revenues | 33,547 |  |  | 20,296 |  |  | 65.3 | % |
| Gross profit | $ | 35,689 |  |  | $ | 28,228 |  |  | 26.4 | % |
| Gross margin | 51.5 | % |  | 58.2 | % |  | (6.7 | )% |

[0000926326-13-000010:mdna:67]
Product revenues increased by $20.7 million, or 42.7%, in the three months ended March 31, 2013 as compared to the same period in 2012. The overall increase in product revenues was primarily driven by the contribution of our Non-Acute Care segment of $19.9 million for the three months ended March 31, 2013, of which $2.3 million was from medication cabinet revenues. Our Acute Care segment was relatively flat as compared to the same period in 2012. We anticipate our revenues will continue to increase in 2013 as we fulfill our existing orders. Additionally, year over year revenue growth for the remainder of 2013 will continue to benefit from the contribution of our Non-Acute Care segment established in May 2012. Our ability to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce consumables to fulfill customer demand, the volume of installations we are able to complete and our ability to meet customer needs by providing a quality installation experience and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-13-000010:mdna:68]
Cost of product revenues increased by $13.3 million, or 65.3%, in the three months ended March 31, 2013 as compared to the same period in 2012. This increase was primarily a result of Non-Acute Care product costs of $11.9 million for the three months ended March 31, 2013, of which $0.2 million was related to our recent reorganization and $1.0 million were costs associated with the Non-Acute Care medication cabinets noted above. Our Acute Care product cost increased $1.3 million, which is a function of product mix.

[0000926326-13-000010:mdna:69]
Gross profit on product revenue increased by $7.5 million, or 26.4%, in the three months ended March 31, 2013 as compared to the same period in 2012. This increase was primarily a result of the aforementioned contribution from our Non-Acute Care segment of $8.0 million, offset by a decrease in gross profits from our Acute Care segment of $0.5 million for the three months ended March 31, 2013, which was driven primarily by product mix.

[0000926326-13-000010:mdna:70]
[same as prior period, unchanged from 0001445305-12-003598:mdna:57]

[0000926326-13-000010:mdna:71]
The table below shows our service and other revenues, cost of service and other revenues and gross profit for the three months ended March 31, 2013 and 2012 and the percentage change between those periods (in thousands, except percentages):

[0000926326-13-000010:mdna:72]
|  | Three Months Ended March 31, |
|  | 2013 |  | 2012 |  | % Change |
| Service and other revenues | $ | 17,874 |  |  | $ | 15,619 |  |  | 14.4 | % |
| Cost of service and other revenues | 8,196 |  |  | 8,098 |  |  | 1.2 | % |
| Gross profit | $ | 9,678 |  |  | $ | 7,521 |  |  | 28.7 | % |
| Gross margin | 54.1 | % |  | 48.2 | % |  | 5.9 | % |

[0000926326-13-000010:mdna:73]
Service and other revenues include revenues from service and maintenance contracts, rentals of automation systems, and training and professional services. Service and other revenues increased by $2.3 million, or 14.4%, in the three months ended March 31, 2013 as compared to the same period in 2012. The increase in service and other revenues was primarily the result of an expansion in our installed base of automation systems and continued growth in the sales of our analytical software resulting in an increase in the number of support service contracts and higher training revenues and service revenues attributable to our Non-Acute Care segment of $1.2 million, of which $0.4 million was from medication cabinet services and other revenues for the three months ended March 31, 2013.

[0000926326-13-000010:mdna:74]
Cost of service and other revenues were relatively flat in the three months ended March 31, 2013 as compared to the same period in 2012, driven by an increase in costs attributable to our Non-Acute Care segment of $0.5 million, offset by a decrease in costs attributable to our Acute Care segment of $0.4 million as a result of cost reduction efforts.

[0000926326-13-000010:mdna:75]
Gross profit on service and other revenues increased by $2.2 million, or 28.7%, in the three months ended March 31, 2013 as compared to the same period in 2012. The increase in gross profit on service and other revenues was primarily due to increased revenues from an expanded installed base with a decrease in service cost attributable to our Acute Care segment as a result of the service cost reduction efforts throughout the period. Gross profit on service and other revenues from our Non-Acute Care segment was $0.7 million and $1.5 million from our Acute Care segment for the three months ended March 31, 2013.

[0000926326-13-000010:mdna:76]
We expect our service and other revenues and the associated gross profit to continue to increase in 2013 with the continued expansion of our installed base of automation systems and service and maintenance contracts and the addition of our Non-Acute Care segment.

[0000926326-13-000010:mdna:77]
[same as prior period, unchanged from 0001445305-12-003598:mdna:65]

[0000926326-13-000010:mdna:78]
The table below shows our operating expenses for the three months ended March 31, 2013 and 2012 and the percentage changes between those periods (in thousands, except percentages):

[0000926326-13-000010:mdna:79]
|  | Three Months Ended March 31, |
|  | 2013 |  | 2012 |  | % Change |
| Research and development | $ | 7,954 |  |  | $ | 6,494 |  |  | 22.5 | % |
| Selling, general and administrative | 33,244 |  |  | 25,620 |  |  | 29.8 | % |
| Total operating expenses | $ | 41,198 |  |  | $ | 32,114 |  |  | 28.3 | % |

[0000926326-13-000010:mdna:80]
Research and Development. Research and development expenses increased by $1.5 million, or 22.5%, in the three months ended March 31, 2013 as compared to the same period in 2012 and represented 9.1% and 10.1% of total revenues in the three months ended March 31, 2013 and 2012, respectively. The overall increase in research and development expenses reflects a $2.7 million increase in research and development expenses attributable to the Non-Acute Care segment, of which 1.8 million is attributable to the write-off of previously capitalized software development costs, discussed further in Note 16, "Asset Impairment" and $0.3 million that  relates to the reorganization previously mentioned. The increase was offset by a $1.3 million decrease in the Acute Care segment. The decrease in research and development expenses attributable to the Acute Care segment reflects an increase in capitalization software effort of $1.9 million due to the higher level of post-feasibility beta testing. The increase in capitalized software credit was partially offset by an increase of $0.6 million of labor and related costs due to an increase in staffing. The decrease as a percentage of revenue is primarily a reflection of the overall growth in revenue without a corresponding increase in research and development expenditures.

[0000926326-13-000010:mdna:81]
We expect research and development expenses to remain relatively flat as a percentage of our revenue on an annual basis and to grow in absolute dollars in the future as our revenue grows to improve and enhance our existing technologies and to create new technologies in health care automation.

[0000926326-13-000010:mdna:82]
Selling, General and Administrative. Selling, general and administrative expenses increased by $7.6 million, or 29.8%, in the three months ended March 31, 2013 as compared to the same period in 2012. Selling, general and administrative expenses represented 38.2% and 39.9% of total revenues in the three months ended March 31, 2013 and 2012, respectively. The increase was primarily due to the addition of Non-Acute Care selling, general and administrative expenses of $5.9 million, of which $0.3 million relates to the previously mentioned reorganization, and an increase from the Acute Care segment of $1.7 million. The Acute Care increase was primarily due to $1.3 million in facility and depreciation expenses for the relocation of our headquarters and manufacturing buildings late in 2012, $0.5 million in GPO fees associated with higher collections and sales volume for GPO-affiliated customers, $0.3 million in professional fees and $0.3 million in travel, promotional and trade show expenses, partially offset by a $0.6 million decrease in costs associated with compensation and related benefits, primarily due to a significant portion of the variable compensation not being earned due to the fact that we did not achieve our company goals.

[0000926326-13-000010:mdna:83]
We expect selling, general and administrative expenses to grow at a nominal rate in order to support our anticipated growth as well as international expansion efforts, but anticipate that increased efficiencies will result in a lower selling, general and administrative expense relative to total revenue growth in 2013.

[0000926326-13-000010:mdna:84]
Share-based Compensation. The effect of share-based compensation on functional expenses within our operating results for the three months ended March 31, 2013 and 2012 is presented in Note 13, “Stock Option Plans and Share-Based Compensation.”

[0000926326-13-000010:mdna:85]
[same as prior period, unchanged from 0001445305-12-003598:mdna:75]

[0000926326-13-000010:mdna:86]
The annual effective tax rate before discrete items was 37.4% and 39.6% for the three months ended March 31, 2013 and 2012, respectively. The decrease in the estimated annual effective tax rate for the three months ended March 31, 2013 as compared to the same period in 2012 was primarily due to the reinstatement of the federal research and development credit in January of 2013 along with a decrease in other non-deductible expenditures. The income tax provision for the three months ended March 31, 2013 also reflected a discrete net benefit of $0.7 million, or 18.0% of pre-tax income, related to 2012 federal research and development (“R&D”) credit which was retroactively reinstated in the three months ended March 31, 2013. No federal R&D credit benefit was recorded in the income tax provision for the three months ended March 31, 2012.

[0000926326-13-000010:mdna:87]
[same as prior period, unchanged from 0001445305-12-003598:mdna:77]

[0000926326-13-000010:mdna:88]
We had cash and cash equivalents of $69.8 million at March 31, 2013, as compared to $62.3 million in cash and cash equivalents at December 31, 2012. All of our cash is invested in short term money market funds or demand deposits. We did not hold any short or long term investments as of March 31, 2013. While in the future we may need to seek additional financing to meet our working capital needs and to finance capital expenditures, as well as to fund operations or potential acquisitions, we believe our current cash and cash equivalent balances and cash flows generated by operations will be sufficient to satisfy our anticipated cash needs for working capital and capital expenditures for at least the next twelve months.

[0000926326-13-000010:mdna:89]
Cash flows for the three months ended March 31, 2013 and 2012 consisted of the following (in thousands):

[0000926326-13-000010:mdna:90]
|  | Three Months Ended March 31, |
|  | 2013 |  | 2012 |
| Net cash provided by operating activities | $ | 4,132 |  |  | $ | 7,289 |  |
| Net cash used in investing activities | (5,247 | ) |  | (1,528 | ) |
| Net cash provided from financing activities | 8,659 |  |  | 3,816 |  |
| Effect of exchange rate changes on cash and cash equivalents | (40 | ) |  | 81 |  |
| Net increase in cash and cash equivalents | $ | 7,504 |  |  | $ | 9,658 |  |

[0000926326-13-000010:mdna:91]
Operating activities provided $4.1 million of cash during the three months ended March 31, 2013 as compared to $7.3 million for the same period in 2012. The main drivers of the $3.2 million decrease in cash generated from operations were a $10.4 million increase in accounts receivable, a $5.1 million decrease in accrued compensation, and a $1.2 million increase in prepaid expenses. These amounts were partially offset by a $4.5 million increase in deferred gross profit, and a $2.8 million increase in investment in sales-type leases. Also impacting operating cash flows are non-cash adjustments which include a $2.1 million increase in depreciation and amortization and a $1.8 million asset impairment charge related to a software development project.

[0000926326-13-000010:mdna:92]
Cash used in investing activities totaled $5.2 million during the three months ended March 31, 2013, as compared to $1.5 million cash used in investing activities during the same period in 2012. This $3.7 million increase in cash used primarily reflects an increase of $1.9 million for purchases of property and equipment and $1.9 million software development capitalization during the three months ended March 31, 2013.

[0000926326-13-000010:mdna:93]
Cash provided by financing activities was $8.7 million during the three months ended March 31, 2013, as compared to $3.8 million during the same period in 2012, resulting in a difference of $4.9 million in cash generated. The increase is primarily due to cash generated from shares issued under stock option and employee stock purchase plans.

[0000926326-13-000010:mdna:94]
[same as prior period, unchanged from 0001445305-12-003598:mdna:85]

[0000926326-13-000010:mdna:95]
There have been no material changes to our contractual obligations during the three months ended March 31, 2013. Please refer to our Annual Report on Form 10-K for the year ended December 31, 2012 for a description of our facility leases and contractual obligations and the Notes to the consolidated financial statements included therein.

[0000926326-13-000010:mdna:96]
The following table summarizes our contractual obligations at March 31, 2013 (in thousands):

[0000926326-13-000010:mdna:97]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | More than five years |
| Operating leases (1) (2) | $ | 44,307 |  |  | $ | 5,626 |  |  | $ | 10,486 |  |  | $ | 8,905 |  |  | $ | 19,290 |  |
| Commitments to contract manufacturers and suppliers (3) | 6,910 |  |  | 6,910 |  |  | — |  |  | — |  |  | — |  |
| Total (4) | $ | 51,217 |  |  | $ | 12,536 |  |  | $ | 10,486 |  |  | $ | 8,905 |  |  | $ | 19,290 |  |

[0000926326-13-000010:mdna:98]
| (1) | Commitments under operating leases relate primarily to leasehold property and office equipment. |

[0000926326-13-000010:mdna:99]
| (2) | In October 2011, we entered into a lease agreement for approximately 100,000 square feet of office space. Pursuant to the lease agreement, the landlord has constructed a single, three-story building of rentable space in Mountain View, California which we now lease and which serves as our headquarters. The term of the lease agreement, which commenced in November 2012, is for a period of 10 years, with a base lease commitment of approximately $40.0 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term. |

[0000926326-13-000010:mdna:100]
| (3) | We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. |

[0000926326-13-000010:mdna:101]
| (4) | At March 31, 2013, we have recorded $3.8 million for uncertain tax positions under long term liabilities, in accordance with GAAP, summarized under Note 1, “Organization and Summary of Significant Accounting Policies.” As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the current balance of the uncertain tax position liabilities has not been included in the table of commitments above. |

[0000926326-13-000010:mdna:102]
[same as prior period, unchanged from 0001445305-12-003598:mdna:96]

[0000926326-13-000010:mdna:103]
As of March 31, 2013, we had no off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
