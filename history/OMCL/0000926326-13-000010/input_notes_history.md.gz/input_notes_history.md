# OMCL note change history — 0001445305-12-003598 → 0000926326-13-000010


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2013-05-09):
[0000926326-13-000010:note_history:1]
On March 8, 2013, Bobbi Polanco (“Polanco”) filed a putative class action complaint in the United States District Court for the District of New Jersey against Omnicell and certain of our customers (Case No. 1:13-cv-01417-NLH-KLM) alleging breach of state security notification laws, violations of state consumer fraud laws, fraud, negligence and conspiracy relating to the theft of an Omnicell electronic device containing medication dispensing cabinet log files, including certain patient health information, and subsequent notification of this unauthorized disclosure of personal health information. Polanco is seeking an injunction against the defendants to prevent each of them from committing the acts complained of in the future and monetary damages, costs and expenses.On May 2, 2013, the United States District Court for the District of New Jersey entered an order to show cause which provided, in relevant part, that Polanco is required to show cause as to why the case should not be dismissed for lack of subject matter jurisdiction. Omnicell is currently evaluating a response to this complaint and intends to defend the matter vigorously.

- added (2013-05-09):
[0000926326-13-000010:note_history:2]
As required under ASC 450, "Contingencies," we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We believe that we have valid defenses with respect to legal proceedings pending against us. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

- changed (2013-05-09):
[0000926326-13-000010:note_history:3]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of March 31, 2013 or December 31, 2012.
  (was, 2012-11-09, similarity 0.9941):
[0001445305-12-003598:note_history:3]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of September 30, 2012 or December 31, 2011.

- removed (2013-05-09):
[0001445305-12-003598:note_history:4]
We may from time to time become involved in certain legal proceedings in the ordinary course of business. We are not a party to any legal proceedings that management believes may have a material impact on Omnicell’s financial position or results of operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2013-05-09):
[0000926326-13-000010:note_history:5]
Description of the Company. Omnicell, Inc. ("Omnicell," "our," "us," "we," or the "Company") was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication and supply control systems which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States. On May 21, 2012, we completed our acquisition of MedPak Holdings, Inc. ("MedPak"). MedPak is the parent company of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems. This acquisition aligns us with the long-term trends of the healthcare market to manage the health of patients across the continuum of care.  We can now serve both the acute care and non-acute care markets. Omnicell and MTS bring capabilities to each other that strengthen the product lines and expand the medication management coverage of both companies. Please refer to Note 14, "Business Acquisition" for more information regarding the transaction.

- changed (2013-05-09):
[0000926326-13-000010:note_history:6]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of March 31, 2013, the results of their operations and comprehensive income for the three months ended March 31, 2013 and 2012 and their cash flows for the three months ended March 31, 2013 and 2012. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2012.
  (was, 2012-11-09, similarity 0.9478):
[0001445305-12-003598:note_history:6]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of September 30, 2012, the results of their operations and comprehensive income for the three months and nine months ended September 30, 2012 and 2011 and their cash flows for the nine months ended September 30, 2012 and 2011. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2011.

- changed (2013-05-09):
[0000926326-13-000010:note_history:7]
Our results of operations, comprehensive income and cash flows for the three months ended March 31, 2013 are not necessarily indicative of results that may be expected for the year ending December 31, 2013, or for any future period.
  (was, 2012-11-09, similarity 0.9091):
[0001445305-12-003598:note_history:7]
Our results of operations, comprehensive income and cash flows for the three months and nine months ended September 30, 2012 are not necessarily indicative of results that may be expected for the year ending December 31, 2012, or for any future period.

- added (2013-05-09):
[0000926326-13-000010:note_history:8]
Use of estimates. GAAP requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, valuation of goodwill and purchased intangibles, valuation of long-lived assets and accounting for income taxes.

- changed (2013-05-09):
[0000926326-13-000010:note_history:9]
Reclassifications. Certain reclassifications have been made to the prior year consolidated balance sheet to conform to the current period presentation. None of these reclassifications are material to the consolidated financial statements.
  (was, 2012-11-09, similarity 0.7987):
[0001445305-12-003598:note_history:9]
Reclassifications. Certain reclassifications have been made to the prior year consolidated balance sheet to conform to the current period presentation, including reclassification of net receivable credit balances by customer from accounts receivable to customer advances. None of these reclassifications are material to the consolidated financial statements.

- changed (2013-05-09):
[0000926326-13-000010:note_history:10]
Fair value of financial instruments. We value our financial assets and liabilities on a recurring basis using the fair value hierarchy established in Accounting Standards Codification ("ASC") 820, Fair Value Measurements and Disclosures. ASC 820 describes three levels of inputs that may be used to measure fair value, as follows:
  (was, 2012-11-09, similarity 0.8193):
[0001445305-12-003598:note_history:10]
Fair value of financial instruments. We value our financial assets and liabilities on a recurring basis using the fair value hierarchy established in Accounting Standards Codification (“ASC”) 820, Fair Value Measurements and Disclosures.

- changed (2013-05-09):
[0000926326-13-000010:note_history:11]
Level 2 inputs, which include observable inputs other than Level 1 inputs, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability; and
  (was, 2012-11-09, similarity 0.9973):
[0001445305-12-003598:note_history:11]
Level 2 inputs, which include observable inputs other than Level 1 inputs, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability; and

- added (2013-05-09):
[0000926326-13-000010:note_history:12]
At March 31, 2013 and December 31, 2012, our financial assets, measured at fair value on a recurring basis, utilizing Level 1 inputs included money market funds, classified as cash equivalents. For these items, quoted market prices are readily available and fair value approximates carrying value. We do not currently have any material financial instruments, measured at fair value on a recurring basis, utilizing Level 2 or Level 3 inputs.

- changed (2013-05-09):
[0000926326-13-000010:note_history:13]
Classification of marketable securities. Securities held as investments for the indefinite future pending future spending requirements are classified as “Available-for-sale” and are carried at their fair value, with any unrealized gain or loss recorded to other comprehensive income until realized. At March 31, 2013 and December 31, 2012, we held $40.4 million and $38.9 million, respectively, of money market mutual funds classified as Available-for-sale cash equivalents. We do not hold securities for purposes of trading. Marketable securities for which we have the intent and ability to hold to maturity are classified as “Held-to-maturity” and are carried at their amortized cost, including accrued interest. We had no Held-to-maturity securities at March 31, 2013 and December 31, 2012.
  (was, 2012-11-09, similarity 0.8822):
[0001445305-12-003598:note_history:13]
Classification of marketable securities. Securities held as investments for the indefinite future pending future spending requirements are classified as “Available-for-sale” and are carried at their fair value, with any unrealized gain or loss recorded to other comprehensive income until realized. At September 30, 2012 and December 31, 2011, we held $31.9 million and $177.3 million, respectively, of money market mutual funds classified as Available-for-sale cash equivalents. At December 31, 2011, we held $8.1 million of non-U.S. Government securities classified as Available-for-sale short-term investments. We do not hold securities for purposes of trading. Marketable securities for which we have the intent and ability to hold to maturity are classified as “Held-to-maturity” and are carried at their amortized cost, including accrued interest. We had no Held-to-maturity securities at September 30, 2012 and December 31, 2011.

- added (2013-05-09):
[0000926326-13-000010:note_history:14]
Currency forward contracts. From time to time we enter into foreign currency forward contracts to protect our business from the risk that exchange rates may affect the eventual cash flows resulting from intercompany transactions between Omnicell and our foreign subsidiaries. These transactions primarily arise as a result of products manufactured in the U.S. and sold to foreign subsidiaries in U.S. dollars rather than the subsidiaries' functional currencies. These forward contracts are considered to be financial derivative instruments and are recorded at fair value in the balance sheet. Changes in fair values of these financial derivative instruments are either recognized in other comprehensive income (a component of stockholders' equity) or net income depending on whether the derivative has been designated and qualifies as a highly effective hedging instrument. At March 31, 2013 and December 31, 2012, we had no foreign currency forward contracts which qualify for hedge accounting.

- added (2013-05-09):
[0000926326-13-000010:note_history:15]
Segment information. Prior to the acquisition of MTS, we managed our business on the basis of a single operating segment, and a single reporting unit within that segment per ASC 280, Segment Reporting. Beginning with the acquisition of MTS, which we completed in May 2012, we have organized our business into two operating business segments: Acute Care, which primarily includes products and services sold to hospital customers, and Non-Acute Care, which primarily includes products and services sold to customers outside of the hospital setting.

- added (2013-05-09):
[0000926326-13-000010:note_history:16]
The Acute Care segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems. The Non-Acute Care segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services, but also includes medication dispensing systems sold to non-acute care pharmacies and facilities. We report segment information based on the management approach. The management approach designates the internal reporting used by the Chief Operating Decision Maker (the "CODM") for making decisions and assessing performance as the source of our operating segments. The CODM is our Chief Executive Officer. The CODM allocates resources to and assesses the performance of each operating segment, using information about its revenues, gross profit and income (loss) from operations.

- changed (2013-05-09):
[0000926326-13-000010:note_history:17]
Revenue recognition. We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems with related services, which are sold in our principal market, which is the healthcare industry. Revenues related to consumable products are reported net of discounts provided to our customers. Our customer arrangements typically include one or more of the following deliverables:
  (was, 2012-11-09, similarity 0.6839):
[0001445305-12-003598:note_history:17]
Revenue recognition. We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems with related services, which are sold in our principal market, which is the healthcare industry. Our customer arrangements typically include one or more of the following deliverables:

- changed (2013-05-09):
[0000926326-13-000010:note_history:18]
| • | Products—Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies. |
  (was, 2012-11-09, similarity 0.9949):
[0001445305-12-003598:note_history:18]
| • | Products — Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies. |

- changed (2013-05-09):
[0000926326-13-000010:note_history:19]
| • | Software—Additional software applications that enable incremental functionality of our equipment. |
  (was, 2012-11-09, similarity 0.9906):
[0001445305-12-003598:note_history:19]
| • | Software — Additional software applications that enable incremental functionality of our equipment. |

- changed (2013-05-09):
[0000926326-13-000010:note_history:20]
| • | Installation—Installation of equipment as integrated systems at customers' sites. |
  (was, 2012-11-09, similarity 0.9778):
[0001445305-12-003598:note_history:20]
| • | Installation — Installation of equipment as integrated systems at customers’ sites. |

- changed (2013-05-09):
[0000926326-13-000010:note_history:21]
| • | Post-installation technical support—Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available. |
  (was, 2012-11-09, similarity 0.994):
[0001445305-12-003598:note_history:21]
| • | Post-installation technical support — Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available. |

- changed (2013-05-09):
[0000926326-13-000010:note_history:22]
| • | Professional services—Other customer services such as training and consulting. |
  (was, 2012-11-09, similarity 0.9829):
[0001445305-12-003598:note_history:22]
| • | Professional services — Other customer services, such as training and consulting. |

- changed (2013-05-09):
[0000926326-13-000010:note_history:23]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:
  (was, 2012-11-09, similarity 0.9424):
[0001445305-12-003598:note_history:23]
We recognize revenue on our equipment when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

- changed (2013-05-09):
[0000926326-13-000010:note_history:24]
| • | Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement. |
  (was, 2012-11-09, similarity 0.9876):
[0001445305-12-003598:note_history:24]
•Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement.

- added (2013-05-09):
[0000926326-13-000010:note_history:25]
| • | Delivery has occurred. Equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installed installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. We recognize revenue from sales of products to distributors upon delivery, when no contractual obligations for installation exists, assuming all other revenue criteria are met since we do not allow for rights of return or refund. For sales to distributors where we assume contractual installation obligations or new distributors whom we have not fully trained to install our products, the equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period, and we recognize revenue on training and professional services as those services are performed. |

- changed (2013-05-09):
[0000926326-13-000010:note_history:26]
| • | Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services. |
  (was, 2012-11-09, similarity 0.9888):
[0001445305-12-003598:note_history:26]
•Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services.

- changed (2013-05-09):
[0000926326-13-000010:note_history:27]
| • | Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable. |
  (was, 2012-11-09, similarity 0.9919):
[0001445305-12-003598:note_history:27]
•Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer’s payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable.

- changed (2013-05-09):
[0000926326-13-000010:note_history:28]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. Effective for new or modified arrangements entered into beginning on January 1, 2011, the date we adopted the revised revenue recognition guidance for arrangements with multiple deliverables on a prospective basis, we allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support services and professional services. When VSOE of fair value is not available, third-party evidence ("TPE") of fair value for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE, TPE and BESP information and obtain formal approval by appropriate levels of management.
  (was, 2012-11-09, similarity 0.9908):
[0001445305-12-003598:note_history:28]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. Effective for new or modified arrangements entered into beginning on January 1, 2011, the date we adopted the revised revenue recognition guidance for arrangements with multiple deliverables on a prospective basis, we allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence (“VSOE”) of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support services and professional services. When VSOE of fair value is not available, third-party evidence (“TPE”) of fair value for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties’ prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices (“BESP”). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE, TPE and BESP information and obtain formal approval by appropriate levels of management.

- changed (2013-05-09):
[0000926326-13-000010:note_history:29]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.
  (was, 2012-11-09, similarity 0.9729):
[0001445305-12-003598:note_history:29]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is recognized in product revenue using the interest method.

- changed (2013-05-09):
[0000926326-13-000010:note_history:30]
Accounts receivable and notes receivable (net investment in sales type leases). We actively manage our accounts receivable to minimize credit risk. We typically sell to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer's impaired ability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position. Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.
  (was, 2012-11-09, similarity 0.6934):
[0001445305-12-003598:note_history:30]
Accounts receivable and notes receivable (net investment in sales type leases). We actively manage our accounts receivable to minimize credit risk. We typically sell to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer’s financial position and ability to pay. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer’s impaired ability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position.

- changed (2013-05-09):
[0000926326-13-000010:note_history:31]
Sales of accounts receivable. We record the sale of our accounts receivables as “true sales” in accordance with accounting guidance for transfers and servicing of financial assets. During the three months ended March 31, 2013 and 2012, we transferred non-recourse accounts receivable totaling $10.2 million and $12.1 million, respectively, which approximated fair value, to third-party leasing companies. At March 31, 2013 and December 31, 2012, accounts receivable included $0.7 million and $0.7 million, respectively, due from third-party leasing companies for transferred non-recourse accounts receivable.
  (was, 2012-11-09, similarity 0.7078):
[0001445305-12-003598:note_history:31]
Sales of accounts receivable. We record the sale of our accounts receivables as “true sales” in accordance with accounting guidance for transfers and servicing of financial assets. During the three months ended September 30, 2012 and 2011, we transferred non-recourse accounts receivable totaling $14.6 million and $9.0 million, respectively, which approximated fair value, to third-party leasing companies. During the nine months ended September 30, 2012 and 2011, we transferred non-recourse accounts receivable totaling $42.5 million and $32.2 million, respectively, which approximated fair value, to third-party leasing companies. At September 30, 2012 and December 31, 2011, accounts receivable included $0.8 million and $0.2 million, respectively, due from third-party leasing companies for transferred non-recourse accounts receivable.

- added (2013-05-09):
[0000926326-13-000010:note_history:32]
Concentration in revenues and in accounts receivable. There was no single customer accounting for 10% or more of revenues in the three months ended March 31, 2013 or 2012. At March 31, 2013, one customer accounted for 12.9% of our total gross accounts receivable, and there was no single customer accounting for 10% or more of accounts receivable at December 31, 2012. At March 31, 2013, we believe that we have no significant concentration of credit risk.

- changed (2013-05-09):
[0000926326-13-000010:note_history:33]
Accounting policy for shipping costs. Outbound freight billed to customers is recorded as product revenue. The related shipping and handling cost is expensed as part of selling, general and administrative expense. Such shipping and handling expenses totaled $1.4 million and $0.7 million for the three months ended March 31, 2013 and 2012, respectively.
  (was, 2012-11-09, similarity 0.8282):
[0001445305-12-003598:note_history:33]
Accounting policy for shipping costs. Outbound freight billed to customers is recorded as product revenue. The related shipping and handling cost is expensed as part of selling, general and administrative expense. Such shipping and handling expenses totaled $1.2 million and $0.7 million for the three months ended September 30, 2012 and 2011, respectively. Shipping and handling expenses totaled $2.7 million and $2.1 million for the nine months ended September 30, 2012 and 2011, respectively.

- changed (2013-05-09):
[0000926326-13-000010:note_history:34]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended March 31, 2013 and 2012 totaled approximately $7.2 million and $6.2 million, respectively.
  (was, 2012-11-09, similarity 0.8436):
[0001445305-12-003598:note_history:34]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended September 30, 2012 and 2011 were approximately $6.3 million and $4.9 million, respectively. Purchases from this supplier for the nine months ended September 30, 2012 and 2011 were approximately $17.8 million and $16.1 million, respectively.

- changed (2013-05-09):
[0000926326-13-000010:note_history:35]
Income taxes. We record an income tax provision for the anticipated tax consequences of the reported results of operations. In accordance with GAAP, the provision for income taxes is computed using the liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates expected to apply in the periods in which those tax assets and liabilities are expected to be realized. In the event that we determine all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.
  (was, 2012-11-09, similarity 0.9943):
[0001445305-12-003598:note_history:35]
Income taxes. We record an income tax provision for the anticipated tax consequences of the reported results of operations. In accordance with GAAP, the provision for income taxes is computed using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates expected to apply in the periods in which those tax assets and liabilities are expected to be realized. In the event that we determine all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

- changed (2013-05-09):
[0000926326-13-000010:note_history:36]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rates before discrete items were 37.4% and 39.6% for the three months ended March 31, 2013 and 2012, respectively. The 2013 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the federal research and development credit claimed and the  domestic production activities deduction. The income tax provision for the three months ended March 31, 2013 also reflected a discrete net benefit of $0.7 million, or 18.0% of pre-tax income, related to 2012 federal research and development (“R&D”) credit which was retroactively reinstated in the three months ended March 31, 2013. No federal R&D credit benefit was recorded in the income tax provision for the three months ended March 31, 2012.
  (was, 2012-11-09, similarity 0.6429):
[0001445305-12-003598:note_history:36]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 41.5% and 40.3% for the nine months ended September 30, 2012 and 2011, respectively. The 2012 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, including non-deductible acquisition costs, all of which were partially offset by the domestic production activities deduction.

- changed (2013-05-09):
[0000926326-13-000010:note_history:37]
The 2012 annual effective tax rate differed from the statutory rate of 35%, primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.
  (was, 2012-11-09, similarity 0.7404):
[0001445305-12-003598:note_history:37]
The 2011 annual effective tax rate differed from the statutory rate of 35%, primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the federal research and development credit claimed and the domestic production activities deduction. Our projected effective tax rate for 2012, after discrete items recorded through September 30, 2012 and 2011, were approximately 39.6% and 38.4%, respectively.

- added (2013-05-09):
[0000926326-13-000010:note_history:38]
Recently Adopted Accounting Standards

- added (2013-05-09):
[0000926326-13-000010:note_history:39]
In February 2013, the Financial Accounting Standards Board (“FASB”) issued 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income (AOCI), which aims to improve the reporting of reclassifications out of AOCI. This update requires an entity to report the effect of significant reclassifications out of AOCI on the respective line items in net income if the amount being reclassified is required under GAAP to be reclassified in its entirety to net income. For other amounts that are not required under GAAP to be reclassified in their entirety to net income in the same reporting period, an entity is required to cross-reference other disclosures required under GAAP that provide additional detail about those amounts. The amendments do not change the current requirements for reporting net income or other comprehensive income in financial statements. For public entities, the amendments are effective prospectively for reporting periods beginning after December 15, 2012. We adopted this guidance in the first quarter of 2013. This update did not have any significant impact on our financial position, operating results or cash flows.

- removed (2013-05-09):
[0001445305-12-003598:note_history:40]
Description of the Company. Omnicell, Inc. (“Omnicell,” “our,” “us,” “we,” or the “Company”) was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are medication control systems together with related consumables and services, and medical/surgical supply control systems, with related services, which are sold in our principal market, the healthcare industry. Our market is located primarily in the United States.

- removed (2013-05-09):
[0001445305-12-003598:note_history:41]
On May 21, 2012, we completed our acquisition of MedPak Holdings, Inc. (“MedPak”). MedPak is the parent company of MTS Medication Technologies, Inc. (“MTS”), a worldwide provider of medication adherence packaging systems. This acquisition aligns us with the long-term trends of the healthcare market to manage the health of patients across the continuum of care.  We can now serve both the acute care and non-acute markets. Omnicell and MTS bring capabilities to each other that strengthen the product lines and expand the medication management coverage of both companies. Please refer to Note 14, “Business Acquisition” for more information regarding the transaction.

- removed (2013-05-09):
[0001445305-12-003598:note_history:42]
Use of estimates. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Actual results could differ from those estimates.

- removed (2013-05-09):
[0001445305-12-003598:note_history:43]
ASC 820 describes three levels of inputs that may be used to measure fair value, as follows:

- removed (2013-05-09):
[0001445305-12-003598:note_history:44]
At September 30, 2012 and December 31, 2011, our financial assets, measured at fair value on a recurring basis, utilizing Level 1 inputs included cash equivalents. For these items, quoted market prices are readily available and fair value approximates carrying value. At December 31, 2011, we had a short-term investment in California revenue anticipation notes, measured at fair value on a recurring basis, the valuation inputs of which were classified as Level 2. We do not currently have any material financial instruments, measured at fair value on a recurring basis, utilizing Level 3 inputs.

- removed (2013-05-09):
[0001445305-12-003598:note_history:45]
Accounting for derivatives and hedging activities. Commencing with our May 21, 2012 acquisition of MTS, we use derivative financial instruments to limit exposure to changes in foreign currency exchange rates. We account for derivatives pursuant to ASC 815, Derivatives and Hedging. The ASC 815 guidance establishes accounting and reporting standards for derivative instruments and requires that all derivatives be recorded at fair value on the balance sheet. Changes in the fair value of derivative financial instruments are either recognized in other comprehensive income (a component of shareholders’ equity) or net income depending on whether the derivative is being used to hedge changes in cash flows or fair value.

- removed (2013-05-09):
[0001445305-12-003598:note_history:46]
Segment information. Beginning with the May 21, 2012 acquisition of MTS, we manage our business on the basis of two operating segments: Acute Care, which primarily includes products and services sold to hospital customers, and Non-Acute Care, which primarily includes products and services sold to customers outside of hospital settings. The historical Omnicell results were reported as a single segment and reporting unit, primarily comprising the Acute Care segment. MTS primarily comprises the Non-Acute Care segment and reporting unit.

- removed (2013-05-09):
[0001445305-12-003598:note_history:47]
•Delivery has occurred. Equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installed installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. We recognize revenue from sales of products to distributors upon delivery, assuming all other revenue criteria are met since we do not allow for rights of return or refund. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period. We recognize revenue on training and professional services as they are performed.

- removed (2013-05-09):
[0001445305-12-003598:note_history:48]
We recognize revenue on the sale of consumable blister cards when title and risk of loss to the products shipped has transferred to the customer. Revenue related to these products is reported net of discounts provided to customers.

- removed (2013-05-09):
[0001445305-12-003598:note_history:49]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

- removed (2013-05-09):
[0001445305-12-003598:note_history:50]
Concentration in revenues and in accounts receivable. There were no customers accounting for 10% or more of revenues in the three months ended September 30, 2012 or 2011. Additionally, there were no customers accounting for 10% or more of revenues in the nine months ended September 30, 2012 or 2011. There were no customers accounting for 10% or more of accounts receivable at September 30, 2012 or at December 31, 2011.

- removed (2013-05-09):
[0001445305-12-003598:note_history:51]
As of September 30, 2012, we had total gross unrecognized tax benefits of approximately $8.4 million, compared with approximately $5.8 million on December 31, 2011, representing an increase of approximately $2.6 million during the nine months ended September 30, 2012. Approximately $1.0 million of the increase was attributable to unrecognized tax benefits recorded as part of the MTS acquisition. Of the total unrecognized tax benefits, $7.1 million and $4.6 million as of September 30, 2012 and December 31, 2011, respectively, if recognized would reduce our effective tax rate in the period of recognition. Gross interest and penalties related to unrecognized tax benefit accrued were immaterial as of September 30, 2012 and December 31, 2011.

- removed (2013-05-09):
[0001445305-12-003598:note_history:52]
Recently adopted accounting pronouncements. In May 2011, the Financial Accounting Standards Board (“FASB”) issued ASU 2011-04, Fair Value Measurement, amending the fair value guidance in ASC 820, and thereby achieving substantially converged fair value measurement and disclosure requirements for GAAP and International Financial Reporting Standards (“IFRS”). The new guidance clarified some fair value measurement principles and expanded certain disclosure requirements. We adopted this guidance in the first quarter of 2012 without any impact to our financial position, operating results or cash flows.

- removed (2013-05-09):
[0001445305-12-003598:note_history:53]
Recently issued accounting pronouncement. In July 2012, FASB issued ASU 2012-02, Intangibles - Goodwill and Other (Topic 350): Testing Indefinite-lived Intangible Assets for Impairment, which amends the guidance in ASC 350-30 on impairment testing of intangible assets with indefinite lives other than goodwill. This guidance gives an entity the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not that an indefinite-lived asset is impaired. An entity has the option to bypass the qualitative assessment and proceed directly to calculating the fair value of an intangible asset with an indefinite life. This update will be effective for us for interim and annual impairment tests performed beginning in the first quarter of fiscal 2013. We do not anticipate this update will have any significant impact on our financial position, operating results or cash flows, as this update does not change how we calculate impairment loss.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2013-05-09):
[0000926326-13-000010:note_history:54]
Revenue recognition. We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems with related services, which are sold in our principal market, which is the healthcare industry. Revenues related to consumable products are reported net of discounts provided to our customers. Our customer arrangements typically include one or more of the following deliverables:
  (was, 2012-11-09, similarity 0.6839):
[0001445305-12-003598:note_history:54]
Revenue recognition. We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems with related services, which are sold in our principal market, which is the healthcare industry. Our customer arrangements typically include one or more of the following deliverables:

- changed (2013-05-09):
[0000926326-13-000010:note_history:55]
| • | Products—Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies. |
  (was, 2012-11-09, similarity 0.9949):
[0001445305-12-003598:note_history:55]
| • | Products — Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies. |

- changed (2013-05-09):
[0000926326-13-000010:note_history:56]
| • | Software—Additional software applications that enable incremental functionality of our equipment. |
  (was, 2012-11-09, similarity 0.9906):
[0001445305-12-003598:note_history:56]
| • | Software — Additional software applications that enable incremental functionality of our equipment. |

- changed (2013-05-09):
[0000926326-13-000010:note_history:57]
| • | Installation—Installation of equipment as integrated systems at customers' sites. |
  (was, 2012-11-09, similarity 0.9778):
[0001445305-12-003598:note_history:57]
| • | Installation — Installation of equipment as integrated systems at customers’ sites. |

- changed (2013-05-09):
[0000926326-13-000010:note_history:58]
| • | Post-installation technical support—Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available. |
  (was, 2012-11-09, similarity 0.994):
[0001445305-12-003598:note_history:58]
| • | Post-installation technical support — Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available. |

- changed (2013-05-09):
[0000926326-13-000010:note_history:59]
| • | Professional services—Other customer services such as training and consulting. |
  (was, 2012-11-09, similarity 0.9829):
[0001445305-12-003598:note_history:59]
| • | Professional services — Other customer services, such as training and consulting. |

- changed (2013-05-09):
[0000926326-13-000010:note_history:60]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:
  (was, 2012-11-09, similarity 0.9424):
[0001445305-12-003598:note_history:60]
We recognize revenue on our equipment when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

- changed (2013-05-09):
[0000926326-13-000010:note_history:61]
| • | Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement. |
  (was, 2012-11-09, similarity 0.9876):
[0001445305-12-003598:note_history:61]
•Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement.

- added (2013-05-09):
[0000926326-13-000010:note_history:62]
| • | Delivery has occurred. Equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installed installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. We recognize revenue from sales of products to distributors upon delivery, when no contractual obligations for installation exists, assuming all other revenue criteria are met since we do not allow for rights of return or refund. For sales to distributors where we assume contractual installation obligations or new distributors whom we have not fully trained to install our products, the equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period, and we recognize revenue on training and professional services as those services are performed. |

- changed (2013-05-09):
[0000926326-13-000010:note_history:63]
| • | Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services. |
  (was, 2012-11-09, similarity 0.9888):
[0001445305-12-003598:note_history:63]
•Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services.

- changed (2013-05-09):
[0000926326-13-000010:note_history:64]
| • | Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable. |
  (was, 2012-11-09, similarity 0.9919):
[0001445305-12-003598:note_history:64]
•Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer’s payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable.

- changed (2013-05-09):
[0000926326-13-000010:note_history:65]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. Effective for new or modified arrangements entered into beginning on January 1, 2011, the date we adopted the revised revenue recognition guidance for arrangements with multiple deliverables on a prospective basis, we allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support services and professional services. When VSOE of fair value is not available, third-party evidence ("TPE") of fair value for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE, TPE and BESP information and obtain formal approval by appropriate levels of management.
  (was, 2012-11-09, similarity 0.9908):
[0001445305-12-003598:note_history:65]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. Effective for new or modified arrangements entered into beginning on January 1, 2011, the date we adopted the revised revenue recognition guidance for arrangements with multiple deliverables on a prospective basis, we allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence (“VSOE”) of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support services and professional services. When VSOE of fair value is not available, third-party evidence (“TPE”) of fair value for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties’ prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices (“BESP”). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE, TPE and BESP information and obtain formal approval by appropriate levels of management.

- changed (2013-05-09):
[0000926326-13-000010:note_history:66]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.
  (was, 2012-11-09, similarity 0.9729):
[0001445305-12-003598:note_history:66]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is recognized in product revenue using the interest method.

- removed (2013-05-09):
[0001445305-12-003598:note_history:67]
•Delivery has occurred. Equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installed installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. We recognize revenue from sales of products to distributors upon delivery, assuming all other revenue criteria are met since we do not allow for rights of return or refund. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period. We recognize revenue on training and professional services as they are performed.

- removed (2013-05-09):
[0001445305-12-003598:note_history:68]
We recognize revenue on the sale of consumable blister cards when title and risk of loss to the products shipped has transferred to the customer. Revenue related to these products is reported net of discounts provided to customers.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2013-05-09):
[0001445305-12-003598:note_history:69]
Subsequent Events

- removed (2013-05-09):
[0001445305-12-003598:note_history:70]
Investment in United Kingdom Distributor

- removed (2013-05-09):
[0001445305-12-003598:note_history:71]
On September 28, 2012, we entered into an agreement with our distributor in the United Kingdom to purchase 15% of the outstanding equity in the company for approximately $0.9 million in cash. In connection with the investment, Omnicell has the right, under certain circumstances, to appoint a member to our United Kingdom distributor's board of directors as well as certain other voting rights. As a result of these and other factors, we anticipate that we will be accounting for this investment using the equity method.
