# OMCL notes — 0000926326-18-000030


## omcl:ScheduleofLongTermNetInvestmentinSaleTypeLeasesTableTextBlock

[0000926326-18-000030:notes:1]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at September 30, 2018 and December 31, 2017:

[0000926326-18-000030:notes:2]
|  | September 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 28,306 |  |  | $ | 25,899 |  |
| Less: Unearned interest income portion | (2,386 | ) |  | (1,695 | ) |
| Net investment in sales-type leases | 25,920 |  |  | 24,204 |  |
| Less: Short-term portion(1) | (8,472 | ) |  | (8,769 | ) |
| Long-term net investment in sales-type leases | $ | 17,448 |  |  | $ | 15,435 |  |

[0000926326-18-000030:notes:3]
[same as prior period, unchanged from 0000926326-18-000025:notes:3]

[0000926326-18-000030:notes:4]
[same as prior period, unchanged from 0000926326-18-000025:notes:4]


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-18-000030:notes:5]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of September 30, 2018:

[0000926326-18-000030:notes:6]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 3,436 |  |
| Non-vested restricted share awards | 707 |  |
| Shares authorized for future issuance | 3,118 |  |
| ESPP shares available for future issuance | 1,913 |  |
| Total shares reserved for future issuance | 9,174 |  |


## srt:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-18-000030:notes:7]
Balance sheet details as of September 30, 2018 and December 31, 2017 are presented in the tables below:

[0000926326-18-000030:notes:8]
|  | September 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 32,529 |  |  | $ | 31,275 |  |
| Work in process | 9,929 |  |  | 8,718 |  |
| Finished goods | 56,773 |  |  | 56,144 |  |
| Total inventories | $ | 99,231 |  |  | $ | 96,137 |  |
| Property and equipment: |  |  |  |
| Equipment | $ | 77,837 |  |  | $ | 69,550 |  |
| Furniture and fixtures | 7,961 |  |  | 6,534 |  |
| Leasehold improvements | 16,209 |  |  | 10,976 |  |
| Software | 39,611 |  |  | 37,168 |  |
| Construction in progress | 11,428 |  |  | 9,813 |  |
| Property and equipment, gross | 153,046 |  |  | 134,041 |  |
| Accumulated depreciation and amortization | (102,562 | ) |  | (91,446 | ) |
| Total property and equipment, net | $ | 50,484 |  |  | $ | 42,595 |  |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 52,088 |  |  | $ | 38,599 |  |
| Unbilled receivables | 15,573 |  |  | 9,475 |  |
| Other assets | 1,287 |  |  | 1,242 |  |
| Total other long term assets, net | $ | 68,948 |  |  | $ | 49,316 |  |
| Accrued liabilities: |  |  |  |
| Advance payments from customers | $ | 4,850 |  |  | $ | 7,779 |  |
| Rebates and lease buyouts | 8,273 |  |  | 5,428 |  |
| Group purchasing organization fees | 4,023 |  |  | 3,449 |  |
| Taxes payable | 5,770 |  |  | 9,183 |  |
| Other accrued liabilities | 12,861 |  |  | 9,854 |  |
| Total accrued liabilities | $ | 35,777 |  |  | $ | 35,693 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-18-000030:notes:9]
[same as prior period, unchanged from 0000926326-18-000025:notes:10]

[0000926326-18-000030:notes:10]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2018 and December 31, 2017, the results of operations and comprehensive income for the three and nine months ended September 30, 2018 and September 30, 2017, and cash flows for the nine months ended September 30, 2018 and September 30, 2017. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2017 filed with the SEC on February 27, 2018, except as discussed in the section entitled “Revenue Recognition” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2018 and cash flows for the nine months ended September 30, 2018 are not necessarily indicative of results that may be expected for the year ending December 31, 2018, or for any future period.


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-18-000030:notes:11]
[same as prior period, unchanged from 0000926326-18-000025:notes:12]

[0000926326-18-000030:notes:12]
On a recurring basis, the Company enters into sales-type lease transactions with the majority varying in length from one to five years. The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at September 30, 2018 and December 31, 2017:

[0000926326-18-000030:notes:13]
The Company evaluates its sales-type leases individually and collectively for impairment. The allowance for credit losses was $0.2 million as of September 30, 2018 and December 31, 2017, respectively.

[0000926326-18-000030:notes:14]
At September 30, 2018, the future minimum lease payments under sales-type leases were as follows:

[0000926326-18-000030:notes:15]
|  | September 30, 2018 |
|  | (In thousands) |
| Remaining three months of 2018 | $ | 3,043 |  |
| 2019 | 8,328 |  |
| 2020 | 6,462 |  |
| 2021 | 4,613 |  |
| 2022 | 3,930 |  |
| Thereafter | 1,930 |  |
| Total | $ | 28,306 |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-18-000030:notes:16]
Commitments and Contingencies

[0000926326-18-000030:notes:17]
Lease Commitments

[0000926326-18-000030:notes:18]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At September 30, 2018, the minimum future payments on non-cancelable operating leases were as follows:

[0000926326-18-000030:notes:19]
|  | (In thousands) |
| Remaining three months of 2018 | $ | 3,392 |  |
| 2019 | 13,329 |  |
| 2020 | 11,416 |  |
| 2021 | 10,458 |  |
| 2022 | 8,655 |  |
| Thereafter | 26,634 |  |
| Total minimum future lease payments | $ | 73,884 |  |

[0000926326-18-000030:notes:20]
Purchase Obligations

[0000926326-18-000030:notes:21]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At September 30, 2018, the Company had non-cancelable purchase commitments of $75.9 million, which are expected to be paid within the next twelve months.

[0000926326-18-000030:notes:22]
Legal Proceedings

[0000926326-18-000030:notes:23]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

[0000926326-18-000030:notes:24]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint seeks monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not yet been served with the complaint. The Company intends to defend the lawsuit vigorously.

[0000926326-18-000030:notes:25]
On June 6, 2018, a class-action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint has been held in abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The court has scheduled a status conference in the case for February 20, 2019. The Company intends to defend the lawsuit vigorously.

[0000926326-18-000030:notes:26]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, the Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (“Underlying Action”), disclosed above, together with claims for reimbursement and unjust enrichment relating to the defense of the Underlying Action in the form of attorneys’ fees and other related costs. The Company has not yet responded to the complaint. The Company filed a motion to stay proceedings in this litigation pending the outcome of the Underlying Action. The court has granted the Company’s motion to stay the requirement to respond to the complaint pending the resolution of the motion to stay the litigation. The Company intends to defend the lawsuit vigorously.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-18-000030:notes:27]
[same as prior period, unchanged from 0000926326-18-000025:notes:27]

[0000926326-18-000030:notes:28]
[same as prior period, unchanged from 0000926326-18-000025:notes:28]


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000926326-18-000030:notes:29]
[same as prior period, unchanged from 0000926326-18-000025:notes:29]

[0000926326-18-000030:notes:30]
|  | September 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 9,475 |  |  | $ | 4,590 |  |
| Long-term unbilled receivables - included in other long-term assets | 15,573 |  |  | 9,475 |  |
| Total contract assets | $ | 25,048 |  |  | $ | 14,065 |  |
| Short-term deferred revenues | $ | 87,777 |  |  | $ | 78,774 |  |
| Long-term deferred revenues | 10,634 |  |  | 10,623 |  |
| Total contract liabilities | $ | 98,411 |  |  | $ | 89,397 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-18-000030:notes:31]
Debt

[0000926326-18-000030:notes:32]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-18-000030:notes:33]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s consolidated total net leverage ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-18-000030:notes:34]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-18-000030:notes:35]
The Credit Agreement contains customary representations and warranties, and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Company’s obligations under the Credit Agreement, and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender), are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.

[0000926326-18-000030:notes:36]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement (the “Amended Credit Agreement”). Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant, and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

[0000926326-18-000030:notes:37]
On December 26, 2017, the parties entered into another amendment (the “Amendment”) to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million, and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.

[0000926326-18-000030:notes:38]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.9 million and $1.6 million for the three months ended September 30, 2018 and 2017, respectively, and approximately $5.7 million and $4.6 million for the nine months ended September 30, 2018 and 2017, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million and $0.4 million for the three months ended September 30, 2018 and 2017, respectively, and approximately $1.7 million and $1.2 million for the nine months ended September 30, 2018 and 2017, respectively. The Company was in compliance with all covenants as of September 30, 2018 and December 31, 2017.

[0000926326-18-000030:notes:39]
During the nine months ended September 30, 2018, the Company repaid $27.0 million under these Facilities.

[0000926326-18-000030:notes:40]
The components of the Company’s debt obligations as of September 30, 2018 and December 31, 2017 were as follows:

[0000926326-18-000030:notes:41]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (12,500 | ) |  | $ | 170,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | (14,500 | ) |  | 20,000 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (27,000 | ) |  | 190,000 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 1,718 |  |  | (5,157 | ) |
| Total debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (25,282 | ) |  | $ | 184,843 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 167,135 |  |

[0000926326-18-000030:notes:42]
As of September 30, 2018, the carrying amount of debt of $190.0 million approximates the comparable fair value of $192.6 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of September 30, 2018 as compared to the period as of December 31, 2017.


## us-gaap:EarningsPerShareTextBlock

[0000926326-18-000030:notes:43]
[same as prior period, unchanged from 0000926326-18-000025:notes:43]

[0000926326-18-000030:notes:44]
[same as prior period, unchanged from 0000926326-18-000025:notes:44]

[0000926326-18-000030:notes:45]
The basic and diluted net income (loss) per share calculation for the three and nine months ended September 30, 2018 and 2017 was as follows:

[0000926326-18-000030:notes:46]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | 13,628 |  |  | $ | 7,748 |  |  | $ | 22,936 |  |  | $ | (707 | ) |
| Weighted-average shares outstanding — basic | 39,432 |  |  | 37,698 |  |  | 39,015 |  |  | 37,266 |  |
| Effect of dilutive securities from stock award plans | 1,428 |  |  | 1,275 |  |  | 1,222 |  |  | — |  |
| Weighted-average shares outstanding — diluted | $ | 40,860 |  |  | $ | 38,973 |  |  | 40,237 |  |  | 37,266 |  |
| Net income (loss) per share - basic | $ | 0.35 |  |  | $ | 0.21 |  |  | $ | 0.59 |  |  | $ | (0.02 | ) |
| Net income (loss) per share - diluted | $ | 0.33 |  |  | $ | 0.20 |  |  | $ | 0.57 |  |  | $ | (0.02 | ) |
| Anti-dilutive weighted-average shares related to stock award plans | 673 |  |  | 1,383 |  |  | 1,176 |  |  | 3,757 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-18-000030:notes:47]
[same as prior period, unchanged from 0000926326-18-000025:notes:47]

[0000926326-18-000030:notes:48]
[same as prior period, unchanged from 0000926326-18-000025:notes:48]

[0000926326-18-000030:notes:49]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of September 30, 2018:

[0000926326-18-000030:notes:50]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 957 |  |  | $ | — |  |  | $ | 957 |  |
| Total financial assets | $ | — |  |  | $ | 957 |  |  | $ | — |  |  | $ | 957 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-18-000030:notes:51]
[same as prior period, unchanged from 0000926326-18-000025:notes:51]

[0000926326-18-000030:notes:52]
Cash and cash equivalents of $44.2 million and $32.4 million as of September 30, 2018 and December 31, 2017, respectively, consisted of demand deposits only.

[0000926326-18-000030:notes:53]
[same as prior period, unchanged from 0000926326-18-000025:notes:53]

[0000926326-18-000030:notes:54]
[same as prior period, unchanged from 0000926326-18-000025:notes:54]

[0000926326-18-000030:notes:55]
[same as prior period, unchanged from 0000926326-18-000025:notes:55]

[0000926326-18-000030:notes:56]
The fair value of the interest rate swap agreements at September 30, 2018 and December 31, 2017 was $1.0 million and $1.4 million, respectively. There were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.

[0000926326-18-000030:notes:57]
[same as prior period, unchanged from 0000926326-18-000025:notes:57]

[0000926326-18-000030:notes:58]
[same as prior period, unchanged from 0000926326-18-000025:notes:58]

[0000926326-18-000030:notes:59]
[same as prior period, unchanged from 0000926326-18-000025:notes:60]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-18-000030:notes:60]
[same as prior period, unchanged from 0000926326-18-000025:notes:61]

[0000926326-18-000030:notes:61]
[same as prior period, unchanged from 0000926326-18-000025:notes:62]

[0000926326-18-000030:notes:62]
[same as prior period, unchanged from 0000926326-18-000025:notes:63]

[0000926326-18-000030:notes:63]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2017 | $ | 220,851 |  |  | $ | 116,900 |  |  | $ | 337,751 |  |
| Foreign currency exchange rate fluctuations | (882 | ) |  | (352 | ) |  | (1,234 | ) |
| Net balance as of September 30, 2018 | $ | 219,969 |  |  | $ | 116,548 |  |  | $ | 336,517 |  |

[0000926326-18-000030:notes:64]
[same as prior period, unchanged from 0000926326-18-000025:notes:65]

[0000926326-18-000030:notes:65]
The carrying amounts of intangible assets as of September 30, 2018 and December 31, 2017 were as follows:

[0000926326-18-000030:notes:66]
|  | September 30, 2018 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 135,234 |  |  | $ | (42,435 | ) |  | $ | (1,003 | ) |  | $ | 91,796 |  |  | 1 - 30 |
| Acquired technology | 74,222 |  |  | (27,011 | ) |  | 123 |  |  | 47,334 |  |  | 3 - 20 |
| Backlog | 21,350 |  |  | (19,823 | ) |  | — |  |  | 1,527 |  |  | 1 - 4 |
| Trade names | 7,650 |  |  | (4,193 | ) |  | 21 |  |  | 3,478 |  |  | 1 - 12 |
| Patents | 3,239 |  |  | (1,461 | ) |  | 5 |  |  | 1,783 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (1,750 | ) |  | — |  |  | 150 |  |  | 3 |
| In-process technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | — |
| Total intangibles assets, net | $ | 247,495 |  |  | $ | (96,673 | ) |  | $ | (854 | ) |  | $ | 149,968 |  |  |  |

[0000926326-18-000030:notes:67]
[same as prior period, unchanged from 0000926326-18-000025:notes:68]

[0000926326-18-000030:notes:68]
Amortization expense of intangible assets was $5.8 million and $6.4 million for the three months ended September 30, 2018 and 2017, respectively. Amortization expense of intangible assets was $17.8 million and $19.4 million for the nine months ended September 30, 2018 and 2017, respectively.

[0000926326-18-000030:notes:69]
[same as prior period, unchanged from 0000926326-18-000025:notes:70]

[0000926326-18-000030:notes:70]
|  | September 30, 2018 |
|  | (In thousands) |
| Remaining three months of 2018 | $ | 5,685 |  |
| 2019 | 17,954 |  |
| 2020 | 16,754 |  |
| 2021 | 15,417 |  |
| 2022 | 14,069 |  |
| Thereafter (excluding in-process technology) | 76,189 |  |
| Total | $ | 146,068 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-18-000030:notes:71]
[same as prior period, unchanged from 0000926326-18-000025:notes:72]

[0000926326-18-000030:notes:72]
On December 22, 2017, the Tax Act was signed into law, most provisions of which became effective starting in 2018, including the reduction of the statutory corporate income tax rate from 35% to 21%. As of September 30, 2018, the Company has not completed the accounting for the tax effects of enactment of the Tax Act; however, in the fourth quarter of 2017, the Company made a reasonable estimate of the effects on the existing deferred tax balances and the one-time transition tax. No adjustments to the provisional amounts recorded in the fourth quarter of 2017 were made during the three and nine months ended September 30, 2018, respectively. For the nine months ended September 30, 2018, the Company assessed the effect of certain international provisions of the Tax Act that became effective January 1, 2018, and determined that these provisions had an immaterial impact; therefore, the Company did not record any impact as a result of the assessment. The Company will continue to analyze the provision for income taxes under the Tax Act as future guidance is issued. Any revisions will be treated in accordance with the measurement period guidance outlined in SEC Staff Accounting Bulletin No. 118.

[0000926326-18-000030:notes:73]
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 19.0% and 34.4% for the nine months ended September 30, 2018 and 2017, respectively.

[0000926326-18-000030:notes:74]
The 2018 annual effective tax rate differed from the statutory rate of 21% primarily due to the favorable impact of the research and development credits and foreign rate differential, which were partially offset by the unfavorable impact of state income taxes, non-deductible expenses, and non-deductible equity charges. The 2017 annual effective tax rate differed from the statutory rate of 35% primarily due to the favorable impact of the research and development credits, which were partially offset by the unfavorable impact of state income taxes, foreign rate differential, and non-deductible equity charges.

[0000926326-18-000030:notes:75]
As of September 30, 2018 and December 31, 2017, the Company had gross unrecognized tax benefits of $10.2 million and $10.7 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record the interest and penalties in operating expense. As of September 30, 2018 and December 31, 2017, the amount of accrued interest and penalties was $1.8 million and $1.4 million, respectively.

[0000926326-18-000030:notes:76]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of September 30, 2018, the Company is no longer subject to U.S., state, and foreign examination for years before 2015, 2013, and 2014, respectively.

[0000926326-18-000030:notes:77]
[same as prior period, unchanged from 0000926326-18-000025:notes:78]


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000926326-18-000030:notes:78]
[same as prior period, unchanged from 0000926326-18-000025:notes:79]

[0000926326-18-000030:notes:79]
|  | September 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| United States | $ | 43,511 |  |  | $ | 34,899 |  |
| Rest of world (1) | 6,973 |  |  | 7,696 |  |
| Total property and equipment, net | $ | 50,484 |  |  | $ | 42,595 |  |

[0000926326-18-000030:notes:80]
[same as prior period, unchanged from 0000926326-18-000025:notes:81]


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000926326-18-000030:notes:81]
[same as prior period, unchanged from 0000926326-18-000025:notes:82]

[0000926326-18-000030:notes:82]
[same as prior period, unchanged from 0000926326-18-000025:notes:83]

[0000926326-18-000030:notes:83]
On April 12, 2017, the Company completed the acquisition of all of the membership interests of Dixie Drawl, LLC d/b/a InPharmics (“InPharmics”). InPharmics is a technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies. The total consideration for the transaction was $5.0 million, net of cash acquired of $0.3 million, and includes $0.5 million holdback for potential settlement of performance obligations. At September 30, 2018, this amount has been presented as a short-term liability.

[0000926326-18-000030:notes:84]
[same as prior period, unchanged from 0000926326-18-000025:notes:85]

[0000926326-18-000030:notes:85]
[same as prior period, unchanged from 0000926326-18-000025:notes:86]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-18-000030:notes:86]
Recently Adopted Authoritative Guidance

[0000926326-18-000030:notes:87]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued ASC 606, Revenue from Contracts with Customers, a new standard related to revenue recognition. Under the new standard, revenue is recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In addition, the standard requires disclosure of the nature, amount, timing, and uncertainty of revenues and cash flows arising from contracts with customers. The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method). The Company adopted the standard using the full retrospective method effective beginning January 1, 2018.

[0000926326-18-000030:notes:88]
Under the ASC 606 guidance, fees paid to GPOs are now presented as a reduction of product revenues, whereas these fees were considered a part of selling, general, and administrative costs under the previous guidance. The majority of the incremental costs incurred to obtain a contract, primarily commission expense, are recognized during the first year with the balance recognized ratably over a period of ten years. Additionally, revenue on term software licenses is recognized upon installation of the license rather than ratably over the life of the term license. Finally, the Company no longer defers the contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price.

[0000926326-18-000030:notes:89]
Adoption of the standard related to revenue recognition impacted the Company’s reported results as follows:

[0000926326-18-000030:notes:90]
|  | Three months ended September 30, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 154,651 |  |  | $ | (34 | ) |  | $ | 154,617 |  |
| Medication Adherence | 32,131 |  |  | — |  |  | 32,131 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 74,911 |  |  | (34 | ) |  | 74,877 |  |
| Medication Adherence | 9,942 |  |  | — |  |  | 9,942 |  |
| Selling, general, and administrative expenses | 58,725 |  |  | (2,517 | ) |  | 56,208 |  |
| Provision for income taxes | 751 |  |  | 966 |  |  | 1,717 |  |
| Net income | $ | 6,231 |  |  | $ | 1,517 |  |  | $ | 7,748 |  |
| Net income per share - basic | $ | 0.17 |  |  | $ | 0.04 |  |  | $ | 0.21 |  |
| Net income per share - diluted | $ | 0.16 |  |  | $ | 0.04 |  |  | $ | 0.20 |  |

[0000926326-18-000030:notes:91]
|  | Nine months ended September 30, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 427,249 |  |  | $ | (1,878 | ) |  | $ | 425,371 |  |
| Medication Adherence | 90,972 |  |  | — |  |  | 90,972 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 198,032 |  |  | (1,878 | ) |  | 196,154 |  |
| Medication Adherence | 28,988 |  |  | — |  |  | 28,988 |  |
| Selling, general, and administrative expenses | 186,818 |  |  | (6,748 | ) |  | 180,070 |  |
| Provision for (benefit from) income taxes | (11,232 | ) |  | 1,891 |  |  | (9,341 | ) |
| Net income (loss) | $ | (3,686 | ) |  | $ | 2,979 |  |  | $ | (707 | ) |
| Net income (loss) per share - basic | $ | (0.10 | ) |  | $ | 0.08 |  |  | $ | (0.02 | ) |
| Net income (loss) per share - diluted | $ | (0.10 | ) |  | $ | 0.08 |  |  | $ | (0.02 | ) |

[0000926326-18-000030:notes:92]
|  | December 31, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Accounts receivable and unbilled receivables, net | $ | 189,227 |  |  | $ | 819 |  |  | $ | 190,046 |  |
| Prepaid expenses | 36,060 |  |  | (15,668 | ) |  | 20,392 |  |
| Prepaid commissions | — |  |  | 41,432 |  |  | 41,432 |  |
| Other long-term assets | 39,841 |  |  | 9,475 |  |  | 49,316 |  |
| Deferred revenues, net | 86,104 |  |  | (7,330 | ) |  | 78,774 |  |
| Long-term, deferred revenues | 17,244 |  |  | (6,621 | ) |  | 10,623 |  |
| Long-term, deferred tax liabilities | 28,579 |  |  | 12,867 |  |  | 41,446 |  |
| Stockholders’ equity | 517,199 |  |  | 37,142 |  |  | 554,341 |  |

[0000926326-18-000030:notes:93]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement, which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for the Company beginning January 1, 2020, with early adoption permitted. The Company early adopted this guidance effective beginning July 1, 2018. The application of this guidance did not have a material effect on the Company’s consolidated financial statements.

[0000926326-18-000030:notes:94]
Recently Issued Authoritative Guidance

[0000926326-18-000030:notes:95]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount and timing of cash flows from leases. This new guidance will be effective for the Company beginning January 1, 2019. In July 2018, the FASB issued amendments in ASU No. 2018-11, which provide a transition election to not restate comparative periods for the effects of applying the new standard. This transition election permits entities to change the date of initial application to the beginning of the year of adoption and to recognize the effects of applying the new standard as a cumulative-effect adjustment to the opening balance of retained earnings. The Company expects to elect this transition approach and recognize the cumulative impact of adoption in the opening balance of retained earnings as of January 1, 2019. The Company is in the process of completing a qualitative and quantitative assessment of the lease portfolio, implementing a new lease accounting system and implementing new processes and controls to account for leases in accordance with the new standard. The Company believes the most significant changes to the financial statements will relate to the recognition of right-of-use assets and offsetting lease liabilities in the consolidated balance sheet for operating leases. The actual impact on the consolidated balance sheet will be contingent upon the Company's population of operating leases at adoption, however the Company does not expect the standard to have a material impact on cash flows or results of operations.

[0000926326-18-000030:notes:96]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects.” ASU 2018-02 will be effective for the Company beginning January 1, 2019. The Company does not expect application of this guidance to have a material effect on its consolidated financial statements.

[0000926326-18-000030:notes:97]
In August 2018, the FASB issued ASU 2018-15, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). ASU 2018-15 will be effective for the Company beginning January 1, 2020. The Company is currently evaluating the impact ASU 2018-15 will have on its consolidated financial statements.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0000926326-18-000030:notes:98]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted stock awards (“RSAs”) |  |  |  |
| Outstanding at December 31, 2017 | 23 |  |  | $ | 41.07 |  |
| Granted | 21 |  |  | 46.60 |  |
| Vested | (23 | ) |  | 41.07 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at September 30, 2018 | 21 |  |  | $ | 46.60 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-18-000030:notes:99]
[same as prior period, unchanged from 0000926326-18-000025:notes:98]

[0000926326-18-000030:notes:100]
[same as prior period, unchanged from 0000926326-18-000025:notes:99]

[0000926326-18-000030:notes:101]
[same as prior period, unchanged from 0000926326-18-000025:notes:100]

[0000926326-18-000030:notes:102]
[same as prior period, unchanged from 0000926326-18-000025:notes:101]

[0000926326-18-000030:notes:103]
Certain prior-year amounts have been reclassified to conform with current-period presentation. These reclassifications include (i) reclassification of revenues from services and other revenues to product revenues of $0.2 million and $0.5 million for the three and nine months ended September 30, 2017, respectively, related to software term-license sales, (ii) a change in inventories presentation related to allocation of inventories obsolete reserve between finished goods, raw materials, and work in progress in the Notes to the Condensed Consolidated Financial Statements, and (iii) a change in intangible assets presentation related to presenting foreign currency impact separately in the Notes to the Condensed Consolidated Financial Statements. In addition, $0.6 million was reclassified from services and other revenues to product revenues for the nine months ended September 30, 2018 in order to conform with the presentation for the three months ended September 30, 2018. These changes were not deemed material and were included to conform with current-period classification and presentation.

[0000926326-18-000030:notes:104]
[same as prior period, unchanged from 0000926326-18-000025:notes:103]

[0000926326-18-000030:notes:105]
[same as prior period, unchanged from 0000926326-18-000025:notes:104]

[0000926326-18-000030:notes:106]
[same as prior period, unchanged from 0000926326-18-000025:notes:105]

[0000926326-18-000030:notes:107]
Software. Additional software applications that enable incremental functionality of the Company’s equipment.

[0000926326-18-000030:notes:108]
Installation. Installation of equipment as integrated systems at customer sites.

[0000926326-18-000030:notes:109]
[same as prior period, unchanged from 0000926326-18-000025:notes:108]

[0000926326-18-000030:notes:110]
[same as prior period, unchanged from 0000926326-18-000025:notes:109]

[0000926326-18-000030:notes:111]
[same as prior period, unchanged from 0000926326-18-000025:notes:110]

[0000926326-18-000030:notes:112]
[same as prior period, unchanged from 0000926326-18-000025:notes:111]

[0000926326-18-000030:notes:113]
[same as prior period, unchanged from 0000926326-18-000025:notes:112]

[0000926326-18-000030:notes:114]
[same as prior period, unchanged from 0000926326-18-000025:notes:113]

[0000926326-18-000030:notes:115]
[same as prior period, unchanged from 0000926326-18-000025:notes:114]

[0000926326-18-000030:notes:116]
[same as prior period, unchanged from 0000926326-18-000025:notes:115]

[0000926326-18-000030:notes:117]
[same as prior period, unchanged from 0000926326-18-000025:notes:116]

[0000926326-18-000030:notes:118]
[same as prior period, unchanged from 0000926326-18-000025:notes:117]

[0000926326-18-000030:notes:119]
[same as prior period, unchanged from 0000926326-18-000025:notes:118]

[0000926326-18-000030:notes:120]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an expected cost plus a margin approach to identify the standalone selling price of goods where separate sales transactions do not exist. For software and services which do not have a specific identifiable product cost, the Company uses an amount discounted from the list price as a best estimated selling price.

[0000926326-18-000030:notes:121]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues at September 30, 2018 and December 31, 2017 were $98.4 million and $89.4 million, respectively, of which $87.8 million and $78.8 million, respectively, are expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-18-000030:notes:122]
[same as prior period, unchanged from 0000926326-18-000025:notes:121]

[0000926326-18-000030:notes:123]
[same as prior period, unchanged from 0000926326-18-000025:notes:122]

[0000926326-18-000030:notes:124]
[same as prior period, unchanged from 0000926326-18-000025:notes:123]

[0000926326-18-000030:notes:125]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 44% of the lease receivable balance, are retained in-house. Revenues from sales-type leases of $11.4 million and $5.9 million for the three months ended September 30, 2018 and 2017, respectively, and $28.8 million and $19.3 million for the nine months ended September 30, 2018 and 2017, respectively, are included in product revenues in the Condensed Consolidated Statements of Operations. Interest income in these leases is recognized in product revenues using the effective interest method.

[0000926326-18-000030:notes:126]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.2 million and $2.1 million for the three months ended September 30, 2018 and 2017, respectively, and $6.2 million and $5.4 million for the nine months ended September 30, 2018 and 2017, respectively.

[0000926326-18-000030:notes:127]
[same as prior period, unchanged from 0000926326-18-000025:notes:126]

[0000926326-18-000030:notes:128]
[same as prior period, unchanged from 0000926326-18-000025:notes:127]

[0000926326-18-000030:notes:129]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenues in the normal course of business. Unbilled contract assets which were invoiced during the three and nine months ended September 30, 2018 as a result of the right to invoice for the transaction consideration becoming unconditional were not material. The contract modifications entered into during the three and nine months ended September 30, 2018 did not have a significant impact on the Company’s contract assets or deferred revenues. During the three and nine months ended September 30, 2018, the Company recognized revenues of $10.9 million and $78.9 million, respectively, that was included in the corresponding deferred revenue balance as of December 31, 2017.

[0000926326-18-000030:notes:130]
[same as prior period, unchanged from 0000926326-18-000025:notes:129]

[0000926326-18-000030:notes:131]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods. The Company recognized contract cost expense of $5.3 million and $4.6 million during the three months ended September 30, 2018 and 2017, respectively, and $16.2 million and $13.3 million during the nine months ended September 30, 2018 and 2017, respectively. The portion of commission expenses paid as of the balance sheet date to be recognized in future periods is recorded in long term prepaid commissions on the Condensed Consolidated Balance Sheets. There was no impairment loss recorded related to capitalized prepaid commissions as of and for the three and nine months ended September 30, 2018.

[0000926326-18-000030:notes:132]
[same as prior period, unchanged from 0000926326-18-000025:notes:131]

[0000926326-18-000030:notes:133]
[same as prior period, unchanged from 0000926326-18-000025:notes:132]

[0000926326-18-000030:notes:134]
[same as prior period, unchanged from 0000926326-18-000025:notes:133]

[0000926326-18-000030:notes:135]
The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company’s segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain other administrative expenses. See Note 14, Segment and Geographical Information, for additional information on segment reporting.

[0000926326-18-000030:notes:136]
[same as prior period, unchanged from 0000926326-18-000025:notes:135]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-18-000030:notes:137]
[same as prior period, unchanged from 0000926326-18-000025:notes:136]

[0000926326-18-000030:notes:138]
On March 2, 2018, the Company initiated the realignment of its Automation and Analytics commercial group in North America and France. During the nine months ended September 30, 2018, the Company accrued and paid out $3.0 million of employee severance cost and related expenses.

[0000926326-18-000030:notes:139]
On February 15, 2017, the Company announced its plan to reduce its workforce by approximately 100 full-time employees and close the Company’s Nashville, Tennessee and Slovenia facilities. The plan was completed in fiscal year 2017. During the nine months ended September 30, 2017, the Company accrued $3.8 million of employee severance cost and related expenses, and paid out $3.2 million. There were $0.6 million of facility-related costs incurred during the nine months ended September 30, 2017, of which $0.2 million was paid out.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000926326-18-000030:notes:140]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-18-000030:notes:141]
[same as prior period, unchanged from 0000926326-18-000025:notes:140]

[0000926326-18-000030:notes:142]
Short-term deferred revenues of $87.8 million and $78.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $14.9 million and $16.9 million as of September 30, 2018 and December 31, 2017, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

[0000926326-18-000030:notes:143]
Long-term deferred revenues include deferred revenues from service contracts of $10.6 million as of both September 30, 2018 and December 31, 2017.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000926326-18-000030:notes:144]
[same as prior period, unchanged from 0000926326-18-000025:notes:143]

[0000926326-18-000030:notes:145]
|  | Three months ended September 30, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| United States | $ | 180,635 |  |  | $ | 164,156 |  |
| Rest of world (1) | 23,632 |  |  | 22,592 |  |
| Total revenues | $ | 204,267 |  |  | $ | 186,748 |  |

[0000926326-18-000030:notes:146]
|  | Nine months ended September 30, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| United States | $ | 502,481 |  |  | $ | 447,877 |  |
| Rest of world (1) | 73,078 |  |  | 68,466 |  |
| Total revenues | $ | 575,559 |  |  | $ | 516,343 |  |

[0000926326-18-000030:notes:147]
[same as prior period, unchanged from 0000926326-18-000025:notes:146]


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000926326-18-000030:notes:148]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the three and nine months ended September 30, 2018 and 2017:

[0000926326-18-000030:notes:149]
|  | Three months ended September 30, |
|  | 2018 |  | 2017 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (8,896 | ) |  | $ | 953 |  |  | $ | (7,943 | ) |  | $ | (8,765 | ) |  | $ | 1,274 |  |  | $ | (7,491 | ) |
| Other comprehensive income (loss) before reclassifications | (907 | ) |  | 90 |  |  | (817 | ) |  | 1,389 |  |  | 35 |  |  | 1,424 |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (324 | ) |  | (324 | ) |  | — |  |  | (109 | ) |  | (109 | ) |
| Net current-period other comprehensive income (loss), net of tax | (907 | ) |  | (234 | ) |  | (1,141 | ) |  | 1,389 |  |  | (74 | ) |  | 1,315 |  |
| Ending balance | $ | (9,803 | ) |  | $ | 719 |  |  | $ | (9,084 | ) |  | $ | (7,376 | ) |  | $ | 1,200 |  |  | $ | (6,176 | ) |

[0000926326-18-000030:notes:150]
|  | Nine months ended September 30, |
|  | 2018 |  | 2017 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (6,954 | ) |  | $ | 841 |  |  | $ | (6,113 | ) |  | $ | (10,764 | ) |  | $ | 1,245 |  |  | $ | (9,519 | ) |
| Other comprehensive income (loss) before reclassifications | (2,849 | ) |  | 686 |  |  | (2,163 | ) |  | 3,388 |  |  | 111 |  |  | 3,499 |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (808 | ) |  | (808 | ) |  | — |  |  | (156 | ) |  | (156 | ) |
| Net current-period other comprehensive income (loss), net of tax | (2,849 | ) |  | (122 | ) |  | (2,971 | ) |  | 3,388 |  |  | (45 | ) |  | 3,343 |  |
| Ending balance | $ | (9,803 | ) |  | $ | 719 |  |  | $ | (9,084 | ) |  | $ | (7,376 | ) |  | $ | 1,200 |  |  | $ | (6,176 | ) |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0000926326-18-000030:notes:151]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2018 and 2017:

[0000926326-18-000030:notes:152]
|  | Three months ended |  | Nine months ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,150 |  |  | $ | 882 |  |  | $ | 3,346 |  |  | $ | 2,727 |  |
| Research and development | 1,397 |  |  | 915 |  |  | 4,068 |  |  | 2,651 |  |
| Selling, general, and administrative | 4,538 |  |  | 3,462 |  |  | 13,437 |  |  | 10,937 |  |
| Total share-based compensation expense | $ | 7,085 |  |  | $ | 5,259 |  |  | $ | 20,851 |  |  | $ | 16,315 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0000926326-18-000030:notes:153]
Summaries of restricted stock activity under the Company’s 2009 Equity Incentive Plan, as amended (the “2009 Plan”) are presented below for the nine months ended September 30, 2018:

[0000926326-18-000030:notes:154]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted stock units (“RSUs”) |  |  |  |  |  |  |  |
| Outstanding at December 31, 2017 | 501 |  |  | $ | 38.90 |  |  | 1.5 |  | $ | 24,293 |  |
| Granted | 138 |  |  | 46.04 |  |  |  |  |  |
| Vested | (131 | ) |  | 34.34 |  |  |  |  |  |
| Forfeited | (58 | ) |  | 38.55 |  |  |  |  |  |
| Outstanding and unvested at September 30, 2018 | 450 |  |  | $ | 42.45 |  |  | 1.3 |  | $ | 32,339 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-18-000030:notes:155]
[same as prior period, unchanged from 0000926326-18-000025:notes:154]

[0000926326-18-000030:notes:156]
|  | Three months ended September 30, |
|  | 2018 |  | 2017 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenues | $ | 120,248 |  |  | $ | 29,461 |  |  | $ | 149,709 |  |  | $ | 110,368 |  |  | $ | 26,470 |  |  | $ | 136,838 |  |
| Services and other revenues | 48,055 |  |  | 6,503 |  |  | 54,558 |  |  | 44,249 |  |  | 5,661 |  |  | 49,910 |  |
| Total revenues | 168,303 |  |  | 35,964 |  |  | 204,267 |  |  | 154,617 |  |  | 32,131 |  |  | 186,748 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 54,958 |  |  | 24,191 |  |  | 79,149 |  |  | 59,811 |  |  | 19,914 |  |  | 79,725 |  |
| Cost of services and other revenues | 22,214 |  |  | 3,995 |  |  | 26,209 |  |  | 19,929 |  |  | 2,275 |  |  | 22,204 |  |
| Total cost of revenues | 77,172 |  |  | 28,186 |  |  | 105,358 |  |  | 79,740 |  |  | 22,189 |  |  | 101,929 |  |
| Gross profit | 91,131 |  |  | 7,778 |  |  | 98,909 |  |  | 74,877 |  |  | 9,942 |  |  | 84,819 |  |
| Operating expenses | 46,015 |  |  | 10,624 |  |  | 56,639 |  |  | 44,332 |  |  | 9,901 |  |  | 54,233 |  |
| Income from operations | $ | 45,116 |  |  | $ | (2,846 | ) |  | $ | 42,270 |  |  | $ | 30,545 |  |  | $ | 41 |  |  | $ | 30,586 |  |
| Corporate costs |  |  |  |  | 24,775 |  |  |  |  |  |  | 18,389 |  |
| Income from operations |  |  |  |  | $ | 17,495 |  |  |  |  |  |  | $ | 12,197 |  |

[0000926326-18-000030:notes:157]
|  | Nine months ended September 30, |
|  | 2018 |  | 2017 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenues | $ | 335,441 |  |  | $ | 79,563 |  |  | $ | 415,004 |  |  | $ | 292,463 |  |  | $ | 73,371 |  |  | $ | 365,834 |  |
| Services and other revenues | 142,633 |  |  | 17,922 |  |  | 160,555 |  |  | 132,908 |  |  | 17,601 |  |  | 150,509 |  |
| Total revenues | 478,074 |  |  | 97,485 |  |  | 575,559 |  |  | 425,371 |  |  | 90,972 |  |  | 516,343 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 168,506 |  |  | 61,136 |  |  | 229,642 |  |  | 170,974 |  |  | 54,077 |  |  | 225,051 |  |
| Cost of services and other revenues | 65,594 |  |  | 10,176 |  |  | 75,770 |  |  | 58,243 |  |  | 7,907 |  |  | 66,150 |  |
| Total cost of revenues | 234,100 |  |  | 71,312 |  |  | 305,412 |  |  | 229,217 |  |  | 61,984 |  |  | 291,201 |  |
| Gross profit | 243,974 |  |  | 26,173 |  |  | 270,147 |  |  | 196,154 |  |  | 28,988 |  |  | 225,142 |  |
| Operating expenses | 142,572 |  |  | 31,119 |  |  | 173,691 |  |  | 139,902 |  |  | 31,196 |  |  | 171,098 |  |
| Income (loss) from segment operations | $ | 101,402 |  |  | $ | (4,946 | ) |  | $ | 96,456 |  |  | $ | 56,252 |  |  | $ | (2,208 | ) |  | $ | 54,044 |  |
| Corporate costs |  |  |  |  | 70,994 |  |  |  |  |  |  | 59,100 |  |
| Income (loss) from operations |  |  |  |  | $ | 25,462 |  |  |  |  |  |  | $ | (5,056 | ) |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000926326-18-000030:notes:158]
The following table summarizes the share option activity under the Company’s equity incentive plans during the nine months ended September 30, 2018:

[0000926326-18-000030:notes:159]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Stock options |  |  |  |  |  |  |  |
| Outstanding at December 31, 2017 | 3,323 |  |  | $ | 32.72 |  |  | 7.6 |  | $ | 53,953 |  |
| Granted | 937 |  |  | 47.36 |  |  |  |  |  |
| Exercised | (584 | ) |  | 24.63 |  |  |  |  |  |
| Expired | (12 | ) |  | 23.38 |  |  |  |  |  |
| Forfeited | (228 | ) |  | 38.85 |  |  |  |  |  |
| Outstanding at September 30, 2018 | 3,436 |  |  | $ | 37.71 |  |  | 7.7 |  | $ | 117,493 |  |
| Exercisable at September 30, 2018 | 1,247 |  |  | $ | 27.44 |  |  | 5.7 |  | $ | 55,462 |  |
| Vested and expected to vest at September 30, 2018 and thereafter | 3,240 |  |  | $ | 37.24 |  |  | 7.6 |  | $ | 112,292 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0000926326-18-000030:notes:160]
|  | Three months ended |  | Nine months ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Employee stock purchase plan |  |  |  |  |  |  |  |
| Expected life, years | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |
| Expected volatility, % | 28.1-33.8% |  |  | 26.7-32.1% |  |  | 27.7-33.8% |  |  | 25.8-32.8% |  |
| Risk free interest rate, % | 0.8-2.7% |  |  | 0.6-1.4% |  |  | 0.7-2.7% |  |  | 0.5-1.4% |  |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0000926326-18-000030:notes:161]
The following assumptions were used to value share options and Employee Stock Purchase Plan (“ESPP”) shares granted pursuant to the Company’s equity incentive plans for the three and nine months ended September 30, 2018 and 2017:

[0000926326-18-000030:notes:162]
|  | Three months ended |  | Nine months ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Stock option plans |  |  |  |  |  |  |  |
| Expected life, years | 4.8 |  |  | 4.7 |  |  | 4.8 |  |  | 4.7 |  |
| Expected volatility, % | 30.4 | % |  | 28.1 | % |  | 31.1 | % |  | 29.2 | % |
| Risk free interest rate, % | 2.8 | % |  | 1.8 | % |  | 2.7 | % |  | 1.8 | % |
| Estimated forfeiture rate, % | 6.9 | % |  | 7.7 | % |  | 6.9 | % |  | 7.7 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-18-000030:notes:163]
[same as prior period, unchanged from 0000926326-18-000025:notes:162]

[0000926326-18-000030:notes:164]
The CODM is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company’s segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

[0000926326-18-000030:notes:165]
[same as prior period, unchanged from 0000926326-18-000025:notes:164]

[0000926326-18-000030:notes:166]
[same as prior period, unchanged from 0000926326-18-000025:notes:165]

[0000926326-18-000030:notes:167]
| • | Medication Adherence. The Medication Adherence segment includes solutions to assist patients to remain adherent to their medication regimens. These solutions are comprised of a variety of tools and aids that may be directly used by a pharmacist or a healthcare provider in their direct care for a patient, or the patient themselves, and include software-based systems and medication adherence packaging. Software solutions primarily operate on the Omnicell Patient Engagement platform, a subscription-based software system which provides an environment for patient engagement by clinicians. Services running on this platform include medication synchronization, immunization management, medication therapy management, and a number of tools used by clinicians to manage patient engagement workflows. Medication Adherence packaging is designed either for patient use in care environments where there is a caregiver present or for environments where the patient cares for him or herself and includes the manufacturing and selling of consumable medication blister cards, packaging equipment, and ancillary products and services. |

[0000926326-18-000030:notes:168]
[same as prior period, unchanged from 0000926326-18-000025:notes:167]

[0000926326-18-000030:notes:169]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2018 and 2017. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable as of September 30, 2018 and December 31, 2017.

[0000926326-18-000030:notes:170]
[same as prior period, unchanged from 0000926326-18-000025:notes:169]

[0000926326-18-000030:notes:171]
[same as prior period, unchanged from 0000926326-18-000025:notes:170]


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0000926326-18-000030:notes:172]
A summary of the performance-based restricted stock activity under the 2009 Plan during the nine months ended September 30, 2018 is presented below:

[0000926326-18-000030:notes:173]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Performance-based restricted stock units (“PSUs”) |  |  |  |
| Outstanding at December 31, 2017 | 225 |  |  | $ | 31.18 |  |
| Granted | 110 |  |  | 38.03 |  |
| Vested | (67 | ) |  | 30.46 |  |
| Forfeited | (32 | ) |  | 34.47 |  |
| Outstanding and unvested at September 30, 2018 | 236 |  |  | $ | 34.13 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-18-000030:notes:174]
[same as prior period, unchanged from 0000926326-18-000025:notes:173]

[0000926326-18-000030:notes:175]
[same as prior period, unchanged from 0000926326-18-000025:notes:174]

[0000926326-18-000030:notes:176]
[same as prior period, unchanged from 0000926326-18-000025:notes:175]

[0000926326-18-000030:notes:177]
[same as prior period, unchanged from 0000926326-18-000025:notes:176]

[0000926326-18-000030:notes:178]
[same as prior period, unchanged from 0000926326-18-000025:notes:177]

[0000926326-18-000030:notes:179]
[same as prior period, unchanged from 0000926326-18-000025:notes:178]

[0000926326-18-000030:notes:180]
The weighted-average fair value per share of options granted during the three months ended September 30, 2018 and 2017 was $17.45 and $12.49, respectively, and the weighted-average fair value per share of options granted during the nine months ended September 30, 2018 and 2017 was $15.02 and $11.22, respectively. The intrinsic value of options exercised during the three months ended September 30, 2018 and 2017 was $8.2 million and $6.8 million, respectively, and the intrinsic value of options exercised during the nine months ended September 30, 2018 and 2017 was $16.7 million and $14.6 million, respectively.

[0000926326-18-000030:notes:181]
As of September 30, 2018, total unrecognized compensation cost related to unvested stock options was $24.5 million, which is expected to be recognized over a weighted-average vesting period of 2.9 years.

[0000926326-18-000030:notes:182]
[same as prior period, unchanged from 0000926326-18-000025:notes:181]

[0000926326-18-000030:notes:183]
For the nine months ended September 30, 2018 and 2017, employees purchased approximately 452,038 and 465,696 shares of common stock, respectively, under the ESPP at weighted average prices of $29.69 and $25.78, respectively. As of September 30, 2018, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $5.6 million and is expected to be recognized over a weighted-average period of 1.5 years.

[0000926326-18-000030:notes:184]
[same as prior period, unchanged from 0000926326-18-000025:notes:183]

[0000926326-18-000030:notes:185]
As of September 30, 2018, total unrecognized compensation expense related to RSUs was $16.0 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.6 years.

[0000926326-18-000030:notes:186]
As of September 30, 2018, total unrecognized compensation cost related to RSAs was $0.6 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.6 years.

[0000926326-18-000030:notes:187]
[same as prior period, unchanged from 0000926326-18-000025:notes:186]

[0000926326-18-000030:notes:188]
As of September 30, 2018, total unrecognized compensation cost related to PSUs was $3.4 million, which is expected to be recognized over the remaining weighted-average period of 1.2 years.

[0000926326-18-000030:notes:189]
[same as prior period, unchanged from 0000926326-18-000025:notes:188]

[0000926326-18-000030:notes:190]
[same as prior period, unchanged from 0000926326-18-000025:notes:189]

[0000926326-18-000030:notes:191]
On August 2, 2016, the Company's Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of September 30, 2018, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase program at any time.

[0000926326-18-000030:notes:192]
During the three and nine months ended September 30, 2018 and 2017, the Company did not repurchase any of its outstanding common stock.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-18-000030:notes:193]
[same as prior period, unchanged from 0000926326-18-000025:notes:192]

[0000926326-18-000030:notes:194]
On November 3, 2017, the Company entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC, and HSBC Securities (USA) Inc., as its sales agents, pursuant to which the Company may offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of the Company’s common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, as amended (the “Securities Act”), including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange.

[0000926326-18-000030:notes:195]
During the three and nine months ended September 30, 2018, the Company did not sell any of its common stock under the Distribution Agreement. As of September 30, 2018, the Company had an aggregate of $110.3 million available to be offered under the Distribution Agreement.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-18-000030:notes:196]
[same as prior period, unchanged from 0000926326-18-000025:notes:195]

[0000926326-18-000030:notes:197]
Depreciation expense of property and equipment was $3.7 million and $3.8 million for the three months ended September 30, 2018 and 2017, respectively. Depreciation expense of property and equipment was $11.0 million and $12.1 million for the nine months ended September 30, 2018 and 2017, respectively.
