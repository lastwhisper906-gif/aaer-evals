# OMCL 8-K — 0000926326-18-000028 filed 2018-10-25

## item codes, every 8-K on or before 2018-11-02

- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2018-11-02

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-18-000028:8k_2_02:1]
EX-99.1
2
exhibit991q318.htm
EXHIBIT 99.1

[0000926326-18-000028:8k_2_02:2]
Exhibit

[0000926326-18-000028:8k_2_02:3]
Exhibit 99.1

[0000926326-18-000028:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664 |  | Mountain View, CA 94043 |
| Peter.Kuipers@Omnicell.com |  |  |

[0000926326-18-000028:8k_2_02:5]
Omnicell Achieves Record Revenue in the Third Quarter 2018

[0000926326-18-000028:8k_2_02:6]
GAAP revenues of $204 million, up 9.4% year-over-year

[0000926326-18-000028:8k_2_02:7]
GAAP net income per diluted share of $0.33, up 65% year-over-year

[0000926326-18-000028:8k_2_02:8]
Non-GAAP revenues of $204 million, up 9.2% year-over-year

[0000926326-18-000028:8k_2_02:9]
Non-GAAP net income per diluted share of $0.63, up 37% year-over-year

[0000926326-18-000028:8k_2_02:10]
MOUNTAIN VIEW, Calif. -- October 25, 2018 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its third quarter ended September 30, 2018.

[0000926326-18-000028:8k_2_02:11]
GAAP Results

[0000926326-18-000028:8k_2_02:12]
GAAP revenues for the third quarter of 2018 were $204.3 million, up $17.5 million, or 9.4% from the third quarter of 2017. GAAP revenues for the nine months ended September 30, 2018 were $575.6 million, up $59.2 million, or 11.5%, from the nine months ended September 30, 2017.

[0000926326-18-000028:8k_2_02:13]
Third quarter 2018 GAAP net income as reported was $13.6 million, or $0.33 per diluted share. This compares to GAAP net income of $7.7 million, or $0.20 per diluted share, for the third quarter of 2017.

[0000926326-18-000028:8k_2_02:14]
GAAP net income for the nine months ended September 30, 2018 was $22.9 million, or $0.57 per diluted share. This compares to GAAP net loss of $0.7 million, or a net loss of $0.02 per diluted share, for the nine months ended September 30, 2017.

[0000926326-18-000028:8k_2_02:15]
Non-GAAP Results

[0000926326-18-000028:8k_2_02:16]
Non-GAAP revenues for the third quarter of 2018 were $204.3 million, up $17.2 million, or 9.2%, from the third quarter of 2017. Non-GAAP revenues for the nine months ended September 30, 2018 were $575.6 million, up $58.3 million, or 11.3%, from the nine months ended September 30, 2017.

[0000926326-18-000028:8k_2_02:17]
Non-GAAP net income for the third quarter of 2018 was $25.7 million, or $0.63 per diluted share. This compares to non-GAAP net income of $17.8 million, or $0.46 per diluted share, for the third quarter of 2017.

[0000926326-18-000028:8k_2_02:18]
Non-GAAP net income for the nine months ended September 30, 2018 was $55.5 million, or $1.38 per diluted share. This compares to non-GAAP net income of $33.1 million, or $0.86 per diluted share, for the nine months ended September 30, 2017.

[0000926326-18-000028:8k_2_02:19]
Non-GAAP net income for each period excludes, when applicable, the effect of share-based compensation expense, amortization expense of acquired intangible assets, acquisition-related expenses, fair value adjustments related to business acquisitions, restructuring and severance-related expenses, tax reform and restructuring benefits, contingent gains, and amortization of debt issuance cost.

[0000926326-18-000028:8k_2_02:20]
Effective January 1, 2018, the Company adopted the new revenue recognition accounting standard, ASC 606, “Revenue from Contracts with Customers,” utilizing the full retrospective transition method. All 2017 financial results have been adjusted to reflect the change.

[0000926326-18-000028:8k_2_02:21]
“Solving challenges in medication management and reducing errors across the continuum of care is our singular focus at Omnicell,” said Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell. “By replacing human workflows with a holistic approach combining hardware, software, and expert services, we are helping our healthcare partners to achieve the highest levels of clinical, operational, and financial success.”

[0000926326-18-000028:8k_2_02:22]
2018 Guidance

[0000926326-18-000028:8k_2_02:23]
For the fourth quarter of 2018, the Company expects non-GAAP revenues to be between $211 million and $217 million. The Company expects fourth quarter 2018 non-GAAP earnings to be between $0.64 and $0.69 per share.

[0000926326-18-000028:8k_2_02:24]
For the year 2018, the Company expects product bookings to be between $645 million and $670 million. The Company expects non-GAAP revenues to be between $787 million and $793 million, and non-GAAP earnings to be between $2.00 and $2.05 per share.

[0000926326-18-000028:8k_2_02:25]
The table below summarizes 2018 guidance outlined above.

[0000926326-18-000028:8k_2_02:26]
|  | Q4'18 | 2018 |
| Product bookings | Not provided | $645 million - $670 million |
| Non-GAAP revenues | $211 million - $217 million | $787 million - $793 million |
| Non-GAAP EPS | $0.64 - $0.69 | $2.00 - $2.05 |

[0000926326-18-000028:8k_2_02:27]
Omnicell Conference Call Information

[0000926326-18-000028:8k_2_02:28]
Omnicell will hold a conference call today, Thursday, October 25, 2018 at 1:30 p.m. PT to discuss third quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 3649229. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on December 6, 2018. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 3649229.

[0000926326-18-000028:8k_2_02:29]
About Omnicell

[0000926326-18-000028:8k_2_02:30]
Since 1992, Omnicell has been inspired to create safer and more efficient ways to manage medications and supplies across all care settings. Omnicell is revolutionizing the patient medication experience from hospital to home by empowering providers to keep each patient at the center of care. The Company’s autonomous approach to medication management leverages a differentiated platform for hardware and workflow software solutions, real-time predictive intelligence, and performance-driven partnerships to help drive operational, financial, and clinical success for customers.

[0000926326-18-000028:8k_2_02:31]
Supporting the highest level of patient safety is essential to excellent patient care. As a leader in medication and supply dispensing automation, central pharmacy automation, IV robotics, analytics software, and medication adherence and packaging systems, Omnicell is focused on delivering solutions for medication availability, affordability, safety, and adherence. Over 5,000 facilities worldwide use Omnicell automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety.

[0000926326-18-000028:8k_2_02:32]
Omnicell’s innovative medication adherence solutions, used by over 40,000 institutional and retail pharmacies in North America and the United Kingdom, are designed to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-18-000028:8k_2_02:33]
For more information about Omnicell, Inc. please visit www.omnicell.com.

[0000926326-18-000028:8k_2_02:34]
Omnicell and the Omnicell logo are registered trademarks of Omnicell, Inc. in the United States and other countries.

[0000926326-18-000028:8k_2_02:35]
Forward-Looking Statements

[0000926326-18-000028:8k_2_02:36]
Use of Non-GAAP Financial Information

[0000926326-18-000028:8k_2_02:37]
This press release contains financial measures that are not calculated in accordance with GAAP. Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP net income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-18-000028:8k_2_02:38]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-18-000028:8k_2_02:39]
| a) | Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell. |

[0000926326-18-000028:8k_2_02:40]
| b) | Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results. |

[0000926326-18-000028:8k_2_02:41]
| c) | Amortization of debt issuance cost. Debt issuance cost represents costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The cost includes underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results. |

[0000926326-18-000028:8k_2_02:42]
| d) | Acquisition accounting impact related to deferred revenues. In connection with recent acquisitions, business combination rules require us to account for the fair values of arrangements for which acceptance has not been obtained, and post-installation support has not been provided in our purchase accounting. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business. |

[0000926326-18-000028:8k_2_02:43]
3

[0000926326-18-000028:8k_2_02:44]
| e) | Acquisition-related expenses. We excluded from the non-GAAP results the expenses which are related to recent acquisitions. These expenses are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition-related expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance and the financial results of less acquisitive peer companies. |

[0000926326-18-000028:8k_2_02:45]
| f) | Severance and other related expenses. We excluded from our non-GAAP results the expenses which are related to restructuring events. These expenses are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies. |

[0000926326-18-000028:8k_2_02:46]
| g) | Tax impact from restructuring activity. We excluded from our non-GAAP results the tax impacts related to restructuring activity. These impacts are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these impacts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies. |

[0000926326-18-000028:8k_2_02:47]
| h) | Contingent gain. We excluded from our non-GAAP results the contingent gain related to a settlement agreement associated with the Ateb acquisition. This contingent gain is unrelated to our ongoing operations, and we do not expect it to occur in the ordinary course of business. We believe that excluding this contingent gain provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies. |

[0000926326-18-000028:8k_2_02:48]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans or other items.

[0000926326-18-000028:8k_2_02:49]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-18-000028:8k_2_02:50]
| a) | Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business. |

[0000926326-18-000028:8k_2_02:51]
| b) | Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods. |

[0000926326-18-000028:8k_2_02:52]
| c) | These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting. |

[0000926326-18-000028:8k_2_02:53]
| d) | These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance. |

[0000926326-18-000028:8k_2_02:54]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-18-000028:8k_2_02:55]
| i) | While share-based compensation calculated in accordance with Accounting Standard Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results. |

[0000926326-18-000028:8k_2_02:56]
| ii) | We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results. |

[0000926326-18-000028:8k_2_02:57]
Our adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 share-based compensation expense, as well as certain non-GAAP adjustments.

[0000926326-18-000028:8k_2_02:58]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-18-000028:8k_2_02:59]
| a) | Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718. |

[0000926326-18-000028:8k_2_02:60]
| b) | Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure. |

[0000926326-18-000028:8k_2_02:61]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-18-000028:8k_2_02:62]
The Company’s 2018 guidance for non-GAAP earnings per share, as well as certain projections discussed in today’s teleconference, exclude “certain items,” which include but are not limited to: unusual gains and losses; costs associated with future restructurings; acquisition-related expenses; and certain tax and litigation outcomes. We do not provide a reconciliation of non-GAAP earnings per share guidance to the comparable GAAP measure as these items are inherently uncertain and difficult to estimate, and cannot be predicted without unreasonable effort. We believe such a reconciliation would imply a degree of precision that could be confusing to investors. These items may also have a material impact on GAAP earnings per share in future periods.

[0000926326-18-000028:8k_2_02:63]
5

[0000926326-18-000028:8k_2_02:64]
Omnicell, Inc.

[0000926326-18-000028:8k_2_02:65]
Condensed Consolidated Statements of Operations

[0000926326-18-000028:8k_2_02:66]
(Unaudited, in thousands, except per share data)

[0000926326-18-000028:8k_2_02:67]
|  | Three Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |
|  |  | As Adjusted* |  | As Reported |  | Change |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 149,709 |  |  | $ | 136,838 |  |  | $ | 135,103 |  |  | $ | 1,735 |  |
| Services and other revenues | 54,558 |  |  | 49,910 |  |  | 51,679 |  |  | (1,769 | ) |
| Total revenues | 204,267 |  |  | 186,748 |  |  | 186,782 |  |  | (34 | ) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 79,149 |  |  | 79,725 |  |  | 79,725 |  |  | — |  |
| Cost of services and other revenues | 26,209 |  |  | 22,204 |  |  | 22,204 |  |  | — |  |
| Total cost of revenues | 105,358 |  |  | 101,929 |  |  | 101,929 |  |  | — |  |
| Gross profit | 98,909 |  |  | 84,819 |  |  | 84,853 |  |  | (34 | ) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 15,805 |  |  | 16,414 |  |  | 16,414 |  |  | — |  |
| Selling, general, and administrative | 65,609 |  |  | 56,208 |  |  | 58,725 |  |  | (2,517 | ) |
| Total operating expenses | 81,414 |  |  | 72,622 |  |  | 75,139 |  |  | (2,517 | ) |
| Income from operations | 17,495 |  |  | 12,197 |  |  | 9,714 |  |  | 2,483 |  |
| Interest and other income (expense), net | (2,837 | ) |  | (2,732 | ) |  | (2,732 | ) |  | — |  |
| Income before provision for income taxes | 14,658 |  |  | 9,465 |  |  | 6,982 |  |  | 2,483 |  |
| Provision for income taxes | 1,030 |  |  | 1,717 |  |  | 751 |  |  | 966 |  |
| Net income | $ | 13,628 |  |  | $ | 7,748 |  |  | $ | 6,231 |  |  | $ | 1,517 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.21 |  |  | $ | 0.17 |  |  | $ | 0.04 |  |
| Diluted | $ | 0.33 |  |  | $ | 0.20 |  |  | $ | 0.16 |  |  | $ | 0.04 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 39,432 |  |  | 37,698 |  |  | 37,698 |  |  |  |
| Diluted | 40,860 |  |  | 38,973 |  |  | 38,973 |  |  |  |

[0000926326-18-000028:8k_2_02:68]
| * | As adjusted for full retrospective adoption of Accounting Standard Codification (“ASC”) 606, “Revenue from Contracts with Customers.” The adjustment also includes a $0.2 million reclassification from services and other revenues to product revenues to conform with current-period presentation. |

[0000926326-18-000028:8k_2_02:69]
Omnicell, Inc.

[0000926326-18-000028:8k_2_02:70]
Condensed Consolidated Statements of Operations

[0000926326-18-000028:8k_2_02:71]
(Unaudited, in thousands, except per share data)

[0000926326-18-000028:8k_2_02:72]
|  | Nine Months Ended |
|  | September 30, 2018 (a) |  | September 30, 2017 |
|  |  | As Adjusted (b) |  | As Reported |  | Change |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 415,004 |  |  | $ | 365,834 |  |  | $ | 362,089 |  |  | $ | 3,745 |  |
| Services and other revenues | 160,555 |  |  | 150,509 |  |  | 156,132 |  |  | (5,623 | ) |
| Total revenues | 575,559 |  |  | 516,343 |  |  | 518,221 |  |  | (1,878 | ) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 229,642 |  |  | 225,051 |  |  | 225,051 |  |  | — |  |
| Cost of services and other revenues | 75,770 |  |  | 66,150 |  |  | 66,150 |  |  | — |  |
| Total cost of revenues | 305,412 |  |  | 291,201 |  |  | 291,201 |  |  | — |  |
| Gross profit | 270,147 |  |  | 225,142 |  |  | 227,020 |  |  | (1,878 | ) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 47,854 |  |  | 50,128 |  |  | 50,128 |  |  | — |  |
| Selling, general, and administrative | 196,831 |  |  | 180,070 |  |  | 186,818 |  |  | (6,748 | ) |
| Total operating expenses | 244,685 |  |  | 230,198 |  |  | 236,946 |  |  | (6,748 | ) |
| Income (loss) from operations | 25,462 |  |  | (5,056 | ) |  | (9,926 | ) |  | 4,870 |  |
| Interest and other income (expense), net | (6,462 | ) |  | (4,992 | ) |  | (4,992 | ) |  | — |  |
| Income (loss) before provision for income taxes | 19,000 |  |  | (10,048 | ) |  | (14,918 | ) |  | 4,870 |  |
| Provision for (benefit from) income taxes | (3,936 | ) |  | (9,341 | ) |  | (11,232 | ) |  | 1,891 |  |
| Net income (loss) | $ | 22,936 |  |  | $ | (707 | ) |  | $ | (3,686 | ) |  | $ | 2,979 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.59 |  |  | $ | (0.02 | ) |  | $ | (0.10 | ) |  | $ | 0.08 |  |
| Diluted | $ | 0.57 |  |  | $ | (0.02 | ) |  | $ | (0.10 | ) |  | $ | 0.08 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 39,015 |  |  | 37,266 |  |  | 37,266 |  |  |  |
| Diluted | 40,237 |  |  | 37,266 |  |  | 37,266 |  |  |  |

[0000926326-18-000028:8k_2_02:73]
| (a) | Includes a $0.6 million reclassification from services and other revenues to product revenues to conform with current-period presentation. |

[0000926326-18-000028:8k_2_02:74]
| (b) | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” The adjustment also includes a $0.5 million reclassification from services and other revenues to product revenues to conform with current-period presentation. |

[0000926326-18-000028:8k_2_02:75]
7

[0000926326-18-000028:8k_2_02:76]
Omnicell, Inc.

[0000926326-18-000028:8k_2_02:77]
Condensed Consolidated Balance Sheets

[0000926326-18-000028:8k_2_02:78]
(Unaudited, in thousands)

[0000926326-18-000028:8k_2_02:79]
|  | September 30, 2018 |  | December 31, 2017 |
|  |  | As Adjusted* |  | As Reported |  | Change |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 44,174 |  |  | $ | 32,424 |  |  | $ | 32,424 |  |  | $ | — |  |
| Accounts receivable and unbilled, net | 206,225 |  |  | 190,046 |  |  | 189,227 |  |  | 819 |  |
| Inventories | 99,231 |  |  | 96,137 |  |  | 96,137 |  |  | — |  |
| Prepaid expenses | 19,618 |  |  | 20,392 |  |  | 36,060 |  |  | (15,668 | ) |
| Other current assets | 9,871 |  |  | 13,273 |  |  | 13,273 |  |  | — |  |
| Total current assets | 379,119 |  |  | 352,272 |  |  | 367,121 |  |  | (14,849 | ) |
| Property and equipment, net | 50,484 |  |  | 42,595 |  |  | 42,595 |  |  | — |  |
| Long-term investment in sales-type leases, net | 17,448 |  |  | 15,435 |  |  | 15,435 |  |  | — |  |
| Goodwill | 336,517 |  |  | 337,751 |  |  | 337,751 |  |  | — |  |
| Intangible assets, net | 149,968 |  |  | 168,107 |  |  | 168,107 |  |  | — |  |
| Long-term deferred tax assets | 9,450 |  |  | 9,454 |  |  | 9,454 |  |  | — |  |
| Prepaid commissions | 40,441 |  |  | 41,432 |  |  | — |  |  | 41,432 |  |
| Other long-term assets | 68,948 |  |  | 49,316 |  |  | 39,841 |  |  | 9,475 |  |
| Total assets | $ | 1,052,375 |  |  | $ | 1,016,362 |  |  | $ | 980,304 |  |  | $ | 36,058 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable | $ | 38,367 |  |  | $ | 48,290 |  |  | $ | 48,290 |  |  | $ | — |  |
| Accrued compensation | 32,953 |  |  | 27,241 |  |  | 27,241 |  |  | — |  |
| Accrued liabilities | 35,777 |  |  | 35,693 |  |  | 35,693 |  |  | — |  |
| Long-term debt, current portion, net | 17,708 |  |  | 15,208 |  |  | 15,208 |  |  | — |  |
| Deferred revenues, net | 87,777 |  |  | 78,774 |  |  | 86,104 |  |  | (7,330 | ) |
| Total current liabilities | 212,582 |  |  | 205,206 |  |  | 212,536 |  |  | (7,330 | ) |
| Long-term, deferred revenues | 10,634 |  |  | 10,623 |  |  | 17,244 |  |  | (6,621 | ) |
| Long-term deferred tax liabilities | 32,593 |  |  | 41,446 |  |  | 28,579 |  |  | 12,867 |  |
| Other long-term liabilities | 10,192 |  |  | 9,829 |  |  | 9,829 |  |  | — |  |
| Long-term debt, net | 167,135 |  |  | 194,917 |  |  | 194,917 |  |  | — |  |
| Total liabilities | 433,136 |  |  | 462,021 |  |  | 463,105 |  |  | (1,084 | ) |
| Total stockholders’ equity | 619,239 |  |  | 554,341 |  |  | 517,199 |  |  | 37,142 |  |
| Total liabilities and stockholders’ equity | $ | 1,052,375 |  |  | $ | 1,016,362 |  |  | $ | 980,304 |  |  | $ | 36,058 |  |

[0000926326-18-000028:8k_2_02:80]
| * | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” |

[0000926326-18-000028:8k_2_02:81]
Omnicell, Inc.

[0000926326-18-000028:8k_2_02:82]
Condensed Consolidated Statements of Cash Flows

[0000926326-18-000028:8k_2_02:83]
(Unaudited, in thousands)

[0000926326-18-000028:8k_2_02:84]
|  | Nine months ended September 30, |
|  | 2018 |  | 2017* |
| Operating Activities |  |  |  |
| Net income (loss) | $ | 22,936 |  |  | $ | (707 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 37,490 |  |  | 38,542 |  |
| Loss on disposal of fixed assets | 136 |  |  | 128 |  |
| Share-based compensation expense | 20,851 |  |  | 16,315 |  |
| Income tax benefits from employee stock plans | — |  |  | 11 |  |
| Deferred income taxes | (8,849 | ) |  | (9,182 | ) |
| Amortization of debt financing fees | 1,718 |  |  | 1,192 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled | (16,179 | ) |  | (22,735 | ) |
| Inventories | (5,288 | ) |  | (22,942 | ) |
| Prepaid expenses | 774 |  |  | (972 | ) |
| Other current assets | 3,120 |  |  | (5,133 | ) |
| Investment in sales-type leases | (1,732 | ) |  | 6,643 |  |
| Prepaid commissions | 991 |  |  | 217 |  |
| Other long-term assets | (6,188 | ) |  | (750 | ) |
| Accounts payable | (8,439 | ) |  | 23,717 |  |
| Accrued compensation | 5,712 |  |  | 658 |  |
| Accrued liabilities | 1,482 |  |  | 4,021 |  |
| Deferred revenues | 9,014 |  |  | (9,240 | ) |
| Other long-term liabilities | (1,035 | ) |  | 865 |  |
| Net cash provided by operating activities | 56,514 |  |  | 20,648 |  |
| Investing Activities |  |  |  |
| Purchases of intangible assets, intellectual property, and patents | — |  |  | (160 | ) |
| Software development for external use | (22,213 | ) |  | (10,121 | ) |
| Purchases of property and equipment | (19,259 | ) |  | (9,374 | ) |
| Business acquisition, net of cash acquired | — |  |  | (4,446 | ) |
| Net cash used in investing activities | (41,472 | ) |  | (24,101 | ) |
| Financing Activities |  |  |  |
| Proceeds from debt | — |  |  | 37,000 |  |
| Repayment of debt and revolving credit facility | (27,000 | ) |  | (100,000 | ) |
| Payment for contingent consideration | — |  |  | (2,400 | ) |
| Proceeds from issuances under stock-based compensation plans | 27,729 |  |  | 26,468 |  |
| Employees’ taxes paid related to restricted stock units | (3,648 | ) |  | (3,133 | ) |
| Net cash used in financing activities | (2,919 | ) |  | (42,065 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (373 | ) |  | (1,504 | ) |
| Net increase (decrease) in cash and cash equivalents | 11,750 |  |  | (47,022 | ) |
| Cash and cash equivalents at beginning of period | 32,424 |  |  | 54,488 |  |
| Cash and cash equivalents at end of period | $ | 44,174 |  |  | $ | 7,466 |  |

[0000926326-18-000028:8k_2_02:85]
| * | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” |

[0000926326-18-000028:8k_2_02:86]
9

[0000926326-18-000028:8k_2_02:87]
Omnicell, Inc.

[0000926326-18-000028:8k_2_02:88]
Reconciliation of GAAP to Non-GAAP

[0000926326-18-000028:8k_2_02:89]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-18-000028:8k_2_02:90]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017* |  | September 30, 2018 |  | September 30, 2017* |
| Reconciliation of GAAP revenues to non-GAAP revenues: |  |  |  |  |  |  |  |
| GAAP revenues | $ | 204,267 |  |  | $ | 186,748 |  |  | $ | 575,559 |  |  | $ | 516,343 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 313 |  |  | — |  |  | 939 |  |
| Non-GAAP revenues | $ | 204,267 |  |  | $ | 187,061 |  |  | $ | 575,559 |  |  | $ | 517,282 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit | $ | 98,909 |  |  | $ | 84,819 |  |  | $ | 270,147 |  |  | $ | 225,142 |  |
| GAAP gross margin | 48.4 | % |  | 45.4 | % |  | 46.9 | % |  | 43.6 | % |
| Share-based compensation expense | 1,150 |  |  | 882 |  |  | 3,346 |  |  | 2,728 |  |
| Amortization of acquired intangibles | 2,728 |  |  | 2,985 |  |  | 8,275 |  |  | 8,670 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 313 |  |  | — |  |  | 939 |  |
| Severance and other expenses | — |  |  | 70 |  |  | — |  |  | 1,767 |  |
| Non-GAAP gross profit | $ | 102,787 |  |  | $ | 89,069 |  |  | $ | 281,768 |  |  | $ | 239,246 |  |
| Non-GAAP gross margin | 50.3 | % |  | 47.6 | % |  | 49.0 | % |  | 46.3 | % |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 81,414 |  |  | $ | 72,622 |  |  | $ | 244,685 |  |  | $ | 230,198 |  |
| GAAP operating expenses % to total revenues | 39.9 | % |  | 38.9 | % |  | 42.5 | % |  | 44.6 | % |
| Share-based compensation expense | (5,935 | ) |  | (4,377 | ) |  | (17,505 | ) |  | (13,587 | ) |
| Amortization of acquired intangibles | (3,029 | ) |  | (3,381 | ) |  | (9,393 | ) |  | (10,660 | ) |
| Acquisition-related expenses | — |  |  | — |  |  | — |  |  | (126 | ) |
| Severance and other expenses | 67 |  |  | (229 | ) |  | (3,180 | ) |  | (3,531 | ) |
| Non-GAAP operating expenses | $ | 72,517 |  |  | $ | 64,635 |  |  | $ | 214,607 |  |  | $ | 202,294 |  |
| Non-GAAP operating expenses % to total revenues | 35.5 | % |  | 34.6 | % |  | 37.3 | % |  | 39.1 | % |

[0000926326-18-000028:8k_2_02:91]
| * | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” |

[0000926326-18-000028:8k_2_02:92]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017* |  | September 30, 2018 |  | September 30, 2017* |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income (loss) from operations: |
| GAAP income (loss) from operations | $ | 17,495 |  |  | $ | 12,197 |  |  | $ | 25,462 |  |  | $ | (5,056 | ) |
| GAAP operating income (loss) % to total revenues | 8.6 | % |  | 6.5 | % |  | 4.4 | % |  | (1.0 | )% |
| Share-based compensation expense | 7,085 |  |  | 5,259 |  |  | 20,851 |  |  | 16,315 |  |
| Amortization of acquired intangibles | 5,757 |  |  | 6,366 |  |  | 17,668 |  |  | 19,330 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 313 |  |  | — |  |  | 939 |  |
| Acquisition-related expenses | — |  |  | — |  |  | — |  |  | 126 |  |
| Severance and other expenses | (67 | ) |  | 299 |  |  | 3,180 |  |  | 5,298 |  |
| Non-GAAP income from operations | $ | 30,270 |  |  | $ | 24,434 |  |  | $ | 67,161 |  |  | $ | 36,952 |  |
| Non-GAAP operating income % to total Non-GAAP revenues | 14.8 | % |  | 13.1 | % |  | 11.7 | % |  | 7.1 | % |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |
| GAAP net income (loss) | $ | 13,628 |  |  | $ | 7,748 |  |  | $ | 22,936 |  |  | $ | (707 | ) |
| Tax benefit for restructuring activity | — |  |  | — |  |  | (4,205 | ) |  | — |  |
| Share-based compensation expense | 7,085 |  |  | 5,259 |  |  | 20,851 |  |  | 16,315 |  |
| Amortization of acquired intangibles | 5,757 |  |  | 6,366 |  |  | 17,668 |  |  | 19,330 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 313 |  |  | — |  |  | 939 |  |
| Acquisition-related expenses(a) | 397 |  |  | 397 |  |  | 1,191 |  |  | 1,317 |  |
| Severance and other expenses | 109 |  |  | 299 |  |  | 3,708 |  |  | 5,298 |  |
| Contingent gain | — |  |  | — |  |  | (2,456 | ) |  | — |  |
| Tax effect of the adjustments above(b) | (1,315 | ) |  | (2,579 | ) |  | (4,222 | ) |  | (9,415 | ) |
| Non-GAAP net income | $ | 25,661 |  |  | $ | 17,803 |  |  | $ | 55,471 |  |  | $ | 33,077 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 40,860 |  |  | 38,973 |  |  | 40,237 |  |  | 37,266 |  |
| Shares - diluted Non-GAAP | 40,860 |  |  | 38,973 |  |  | 40,237 |  |  | 38,418 |  |
| GAAP net income (loss) per share - diluted | $ | 0.33 |  |  | $ | 0.20 |  |  | $ | 0.57 |  |  | $ | (0.02 | ) |
| Tax benefit for restructuring activity | — |  |  | — |  |  | (0.10 | ) |  | — |  |
| Share-based compensation expense | 0.17 |  |  | 0.14 |  |  | 0.52 |  |  | 0.43 |  |
| Amortization of acquired intangibles | 0.15 |  |  | 0.16 |  |  | 0.43 |  |  | 0.50 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 0.01 |  |  | — |  |  | 0.02 |  |
| Acquisition-related expenses | 0.01 |  |  | 0.01 |  |  | 0.03 |  |  | 0.03 |  |
| Severance and other expenses | — |  |  | 0.01 |  |  | 0.09 |  |  | 0.14 |  |
| Contingent gain | — |  |  | — |  |  | (0.06 | ) |  | — |  |
| Tax effect of the adjustments above(b) | (0.03 | ) |  | (0.07 | ) |  | (0.10 | ) |  | (0.24 | ) |
| Non-GAAP net income per share - diluted | $ | 0.63 |  |  | $ | 0.46 |  |  | $ | 1.38 |  |  | $ | 0.86 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP Adjusted EBITDA(c): |
| GAAP net income (loss) | $ | 13,628 |  |  | $ | 7,748 |  |  | $ | 22,936 |  |  | $ | (707 | ) |
| Share-based compensation expense | 7,085 |  |  | 5,259 |  |  | 20,851 |  |  | 16,315 |  |
| Interest (income) and expense, net | 1,561 |  |  | 2,127 |  |  | 4,948 |  |  | 4,870 |  |
| Depreciation and amortization expense | 12,661 |  |  | 12,600 |  |  | 37,490 |  |  | 38,542 |  |

[0000926326-18-000028:8k_2_02:93]
11

[0000926326-18-000028:8k_2_02:94]
| Acquisition accounting impact related to deferred revenues | — |  |  | 313 |  |  | — |  |  | 939 |  |
| Acquisition-related expenses | 397 |  |  | 397 |  |  | 1,191 |  |  | 1,317 |  |
| Severance and other expenses | 109 |  |  | 46 |  |  | 3,708 |  |  | 4,539 |  |
| Contingent gain | — |  |  | — |  |  | (2,456 | ) |  | — |  |
| Income tax expense (benefit) | 1,030 |  |  | 1,717 |  |  | (3,936 | ) |  | (9,341 | ) |
| Non-GAAP Adjusted EBITDA | $ | 36,471 |  |  | $ | 30,207 |  |  | $ | 84,732 |  |  | $ | 56,474 |  |

[0000926326-18-000028:8k_2_02:95]
| (a) | Includes amortization of debt financing fees associated with our debt facilities. |

[0000926326-18-000028:8k_2_02:96]
| (b) | Tax effects calculated for all adjustments except tax benefits and share-based compensation expense, using an estimated annual effective tax rate of 21% for fiscal year 2018 and 35% for fiscal year 2017. |

[0000926326-18-000028:8k_2_02:97]
| (c) | Defined as earnings before interest income and expense, taxes, depreciation and amortization, as well as excluding certain non-GAAP adjustments. |

[0000926326-18-000028:8k_2_02:98]
12

[0000926326-18-000028:8k_2_02:99]
Omnicell, Inc.

[0000926326-18-000028:8k_2_02:100]
Segmented Information

[0000926326-18-000028:8k_2_02:101]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000028:8k_2_02:102]
|  | Three Months Ended September 30, 2018 |  | Three Months Ended September 30, 2017 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics* |  | MedicationAdherence |  | Total* |
| Revenues | $ | 168,303 |  |  | $ | 35,964 |  |  | $ | 204,267 |  |  | $ | 154,617 |  |  | $ | 32,131 |  |  | $ | 186,748 |  |
| Cost of revenues | 77,172 |  |  | 28,186 |  |  | 105,358 |  |  | 79,740 |  |  | 22,189 |  |  | 101,929 |  |
| Gross profit | 91,131 |  |  | 7,778 |  |  | 98,909 |  |  | 74,877 |  |  | 9,942 |  |  | 84,819 |  |
| Gross margin % | 54.1 | % |  | 21.6 | % |  | 48.4 | % |  | 48.4 | % |  | 30.9 | % |  | 45.4 | % |
| Operating expenses | 46,015 |  |  | 10,624 |  |  | 56,639 |  |  | 44,332 |  |  | 9,901 |  |  | 54,233 |  |
| Income (loss) from segment operations | $ | 45,116 |  |  | $ | (2,846 | ) |  | $ | 42,270 |  |  | $ | 30,545 |  |  | $ | 41 |  |  | $ | 30,586 |  |
| Operating margin % | 26.8 | % |  | (7.9 | )% |  | 20.7 | % |  | 19.8 | % |  | 0.1 | % |  | 16.4 | % |
| Corporate costs |  |  |  |  | 24,775 |  |  |  |  |  |  | 18,389 |  |
| Income from operations |  |  |  |  | $ | 17,495 |  |  |  |  |  |  | $ | 12,197 |  |

[0000926326-18-000028:8k_2_02:103]
| * | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” |

[0000926326-18-000028:8k_2_02:104]
13

[0000926326-18-000028:8k_2_02:105]
Omnicell, Inc.

[0000926326-18-000028:8k_2_02:106]
Segmented Information

[0000926326-18-000028:8k_2_02:107]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000028:8k_2_02:108]
|  | Nine Months Ended September 30, 2018 |  | Nine Months Ended September 30, 2017 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics* |  | MedicationAdherence |  | Total* |
| Revenues | $ | 478,074 |  |  | $ | 97,485 |  |  | $ | 575,559 |  |  | $ | 425,371 |  |  | $ | 90,972 |  |  | $ | 516,343 |  |
| Cost of revenues | 234,100 |  |  | 71,312 |  |  | 305,412 |  |  | 229,217 |  |  | 61,984 |  |  | 291,201 |  |
| Gross profit | 243,974 |  |  | 26,173 |  |  | 270,147 |  |  | 196,154 |  |  | 28,988 |  |  | 225,142 |  |
| Gross margin % | 51.0 | % |  | 26.8 | % |  | 46.9 | % |  | 46.1 | % |  | 31.9 | % |  | 43.6 | % |
| Operating expenses | 142,572 |  |  | 31,119 |  |  | 173,691 |  |  | 139,902 |  |  | 31,196 |  |  | 171,098 |  |
| Income (loss) from segment operations | $ | 101,402 |  |  | $ | (4,946 | ) |  | $ | 96,456 |  |  | $ | 56,252 |  |  | $ | (2,208 | ) |  | $ | 54,044 |  |
| Operating margin % | 21.2 | % |  | (5.1 | )% |  | 16.8 | % |  | 13.2 | % |  | (2.4 | )% |  | 10.5 | % |
| Corporate costs |  |  |  |  | 70,994 |  |  |  |  |  |  | 59,100 |  |
| Income (loss) from operations |  |  |  |  | $ | 25,462 |  |  |  |  |  |  | $ | (5,056 | ) |

[0000926326-18-000028:8k_2_02:109]
| * | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” |

[0000926326-18-000028:8k_2_02:110]
14

[0000926326-18-000028:8k_2_02:111]
Omnicell, Inc.

[0000926326-18-000028:8k_2_02:112]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-18-000028:8k_2_02:113]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000028:8k_2_02:114]
|  | Three Months Ended September 30, 2018 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenues |  | % of Non-GAAP Revenues |  | Amount |  | % of GAAP Revenues |  | % of Non-GAAP Revenues |  | Amount |  | % of GAAP Revenues |  | % of Non-GAAP Revenues |
| Revenues | $ | 168,303 |  |  |  |  |  |  | $ | 35,964 |  |  |  |  |  |  | $ | 204,267 |  |  |  |  |  |
| Non-GAAP Revenues | $ | 168,303 |  |  |  |  |  |  | $ | 35,964 |  |  |  |  |  |  | $ | 204,267 |  |  |  |  |  |
| GAAP Gross profit | $ | 91,131 |  |  | 54.1 | % |  |  |  | $ | 7,778 |  |  | 21.6 | % |  |  |  | $ | 98,909 |  |  | 48.4 | % |  |  |
| Share-based compensation expense | 963 |  |  | 0.6 | % |  | 0.6 | % |  | 187 |  |  | 0.5 | % |  | 0.5 | % |  | 1,150 |  |  | 0.6 | % |  | 0.6 | % |
| Amortization expense of acquired intangible assets | 2,223 |  |  | 1.3 | % |  | 1.3 | % |  | 505 |  |  | 1.4 | % |  | 1.4 | % |  | 2,728 |  |  | 1.3 | % |  | 1.3 | % |
| Non-GAAP Gross profit | $ | 94,317 |  |  |  |  | 56.0 | % |  | $ | 8,470 |  |  |  |  | 23.6 | % |  | $ | 102,787 |  |  |  |  | 50.3 | % |
| GAAP Operating income (loss) | $ | 45,116 |  |  | 26.8 | % |  |  |  | $ | (2,846 | ) |  | (7.9 | )% |  |  |  | $ | 42,270 |  |  | 20.7 | % |  |  |
| Share-based compensation expense | 3,111 |  |  | 1.8 | % |  | 1.8 | % |  | 561 |  |  | 1.6 | % |  | 1.6 | % |  | 3,672 |  |  | 1.8 | % |  | 1.8 | % |
| Amortization expense of acquired intangible assets | 4,125 |  |  | 2.5 | % |  | 2.5 | % |  | 1,632 |  |  | 4.5 | % |  | 4.5 | % |  | 5,757 |  |  | 2.8 | % |  | 2.8 | % |
| Severance and other expenses | (199 | ) |  | (0.1 | )% |  | (0.1 | )% |  | — |  |  | — | % |  | — | % |  | (199 | ) |  | (0.1 | )% |  | (0.1 | )% |
| Non-GAAP Operating income | $ | 52,153 |  |  |  |  | 31.0 | % |  | $ | (653 | ) |  |  |  | (1.8 | )% |  | $ | 51,500 |  |  |  |  | 25.2 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 24,775 |  |  | 12.1 | % |  |  |
| Share-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (3,413 | ) |  | (1.7 | )% |  | (1.7 | )% |
| Severance and other expenses |  |  |  |  |  |  |  |  |  |  |  |  | (132 | ) |  | (0.1 | )% |  | (0.1 | )% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 21,230 |  |  |  |  | 10.4 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 30,270 |  |  |  |  | 14.8 | % |

[0000926326-18-000028:8k_2_02:115]
15

[0000926326-18-000028:8k_2_02:116]
Omnicell, Inc.

[0000926326-18-000028:8k_2_02:117]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-18-000028:8k_2_02:118]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000028:8k_2_02:119]
|  | Three Months Ended September 30, 2017 |  |  |
|  | Automation andAnalytics* |  | MedicationAdherence |  | Total* |
|  | Amount |  | % of GAAP Revenues |  | % of Non-GAAP Revenues |  | Amount |  | % of GAAP Revenues |  | % of Non-GAAP Revenues |  | Amount |  | % of GAAP Revenues |  | % of Non-GAAP Revenues |
| Revenues | $ | 154,617 |  |  |  |  |  |  | $ | 32,131 |  |  |  |  |  |  | $ | 186,748 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | — | % |  | — | % |  | 313 |  |  | 1.0 | % |  | 1.0 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Non-GAAP Revenues | $ | 154,617 |  |  |  |  |  |  | $ | 32,444 |  |  |  |  |  |  | $ | 187,061 |  |  |  |  |  |
| GAAP Gross profit | $ | 74,877 |  |  | 48.4 | % |  |  |  | $ | 9,942 |  |  | 30.9 | % |  |  |  | $ | 84,819 |  |  | 45.4 | % |  |  |
| Share-based compensation expense | 739 |  |  | 0.5 | % |  | 0.5 | % |  | 143 |  |  | 0.4 | % |  | 0.4 | % |  | 882 |  |  | 0.5 | % |  | 0.5 | % |
| Amortization expense of acquired intangible assets | 2,393 |  |  | 1.5 | % |  | 1.5 | % |  | 592 |  |  | 1.8 | % |  | 1.8 | % |  | 2,985 |  |  | 1.6 | % |  | 1.6 | % |
| Acquisition accounting impact related to deferred revenues | — |  |  | — | % |  | — | % |  | 313 |  |  | 1.0 | % |  | 1.0 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Severance and other expenses | 119 |  |  | 0.1 | % |  | 0.1 | % |  | (49 | ) |  | (0.2 | )% |  | (0.2 | )% |  | 70 |  |  | — | % |  | — | % |
| Non-GAAP Gross profit | $ | 78,128 |  |  |  |  | 50.5 | % |  | $ | 10,941 |  |  |  |  | 33.7 | % |  | $ | 89,069 |  |  |  |  | 47.6 | % |
| GAAP Operating income (loss) | $ | 30,545 |  |  | 19.8 | % |  |  |  | $ | 41 |  |  | 0.1 | % |  |  |  | $ | 30,586 |  |  | 16.4 | % |  |  |
| Share-based compensation expense | 2,365 |  |  | 1.5 | % |  | 1.5 | % |  | 368 |  |  | 1.1 | % |  | 1.1 | % |  | 2,733 |  |  | 1.5 | % |  | 1.5 | % |
| Amortization expense of acquired intangible assets | 4,485 |  |  | 2.9 | % |  | 2.9 | % |  | 1,881 |  |  | 5.9 | % |  | 5.8 | % |  | 6,366 |  |  | 3.4 | % |  | 3.4 | % |
| Acquisition accounting impact related to deferred revenues | — |  |  | — | % |  | — | % |  | 313 |  |  | 1.0 | % |  | 1.0 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Severance and other expenses | 96 |  |  | 0.1 | % |  | 0.1 | % |  | (61 | ) |  | (0.2 | )% |  | (0.2 | )% |  | 35 |  |  | — | % |  | — | % |
| Non-GAAP Operating income | $ | 37,491 |  |  |  |  | 24.2 | % |  | $ | 2,542 |  |  |  |  | 7.8 | % |  | $ | 40,033 |  |  |  |  | 21.4 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 18,389 |  |  | 9.8 | % |  |  |
| Share-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (2,526 | ) |  | (1.4 | )% |  | (1.4 | )% |
| Severance and other expenses |  |  |  |  |  |  |  |  |  |  |  |  | (264 | ) |  | (0.1 | )% |  | (0.1 | )% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 15,599 |  |  |  |  | 8.3 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 24,434 |  |  |  |  | 13.1 | % |

[0000926326-18-000028:8k_2_02:120]
| * | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” |

[0000926326-18-000028:8k_2_02:121]
16
