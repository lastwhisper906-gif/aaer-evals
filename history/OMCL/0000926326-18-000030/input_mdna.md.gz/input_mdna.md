# OMCL MD&A — 0000926326-18-000030


## mdna

[0000926326-18-000030:mdna:1]
[same as prior period, unchanged from 0000926326-18-000025:mdna:1]

[0000926326-18-000030:mdna:2]
[same as prior period, unchanged from 0000926326-18-000025:mdna:2]

[0000926326-18-000030:mdna:3]
[same as prior period, unchanged from 0000926326-18-000025:mdna:3]

[0000926326-18-000030:mdna:4]
| • | our expectations regarding our future pipeline and product bookings; |

[0000926326-18-000030:mdna:5]
27

[0000926326-18-000030:mdna:6]
[same as prior period, unchanged from 0000926326-18-000025:mdna:5]

[0000926326-18-000030:mdna:7]
[same as prior period, unchanged from 0000926326-18-000025:mdna:6]

[0000926326-18-000030:mdna:8]
[same as prior period, unchanged from 0000926326-18-000025:mdna:7]

[0000926326-18-000030:mdna:9]
[same as prior period, unchanged from 0000926326-18-000025:mdna:8]

[0000926326-18-000030:mdna:10]
[same as prior period, unchanged from 0000926326-18-000025:mdna:9]

[0000926326-18-000030:mdna:11]
[same as prior period, unchanged from 0000926326-18-000025:mdna:10]

[0000926326-18-000030:mdna:12]
[same as prior period, unchanged from 0000926326-18-000025:mdna:11]

[0000926326-18-000030:mdna:13]
[same as prior period, unchanged from 0000926326-18-000025:mdna:12]

[0000926326-18-000030:mdna:14]
[same as prior period, unchanged from 0000926326-18-000025:mdna:13]

[0000926326-18-000030:mdna:15]
[same as prior period, unchanged from 0000926326-18-000025:mdna:14]

[0000926326-18-000030:mdna:16]
[same as prior period, unchanged from 0000926326-18-000025:mdna:15]

[0000926326-18-000030:mdna:17]
[same as prior period, unchanged from 0000926326-18-000025:mdna:16]

[0000926326-18-000030:mdna:18]
[same as prior period, unchanged from 0000926326-18-000025:mdna:17]

[0000926326-18-000030:mdna:19]
[same as prior period, unchanged from 0000926326-18-000025:mdna:18]

[0000926326-18-000030:mdna:20]
[same as prior period, unchanged from 0000926326-18-000025:mdna:19]

[0000926326-18-000030:mdna:21]
We own various trademarks and service marks used in our business, including the following registered and unregistered marks which appear in this report: Omnicell®, the Omnicell logo, SureMed®, Ateb®, Aesynt®, AcuDose-Rx®, Connect-Rx®, MACH4®, Anesthesia Workstation™, and Performance Center™. This report also includes the trademarks and service marks of other companies. All other trademarks and service marks used in this report are the marks of their respective holders.

[0000926326-18-000030:mdna:22]
[same as prior period, unchanged from 0000926326-18-000025:mdna:34]

[0000926326-18-000030:mdna:23]
[same as prior period, unchanged from 0000926326-18-000025:mdna:21]

[0000926326-18-000030:mdna:24]
[same as prior period, unchanged from 0000926326-18-000025:mdna:22]

[0000926326-18-000030:mdna:25]
[same as prior period, unchanged from 0000926326-18-000025:mdna:23]

[0000926326-18-000030:mdna:26]
[same as prior period, unchanged from 0000926326-18-000025:mdna:24]

[0000926326-18-000030:mdna:27]
[same as prior period, unchanged from 0000926326-18-000025:mdna:25]

[0000926326-18-000030:mdna:28]
[same as prior period, unchanged from 0000926326-18-000025:mdna:26]

[0000926326-18-000030:mdna:29]
[same as prior period, unchanged from 0000926326-18-000025:mdna:27]

[0000926326-18-000030:mdna:30]
[same as prior period, unchanged from 0000926326-18-000025:mdna:28]

[0000926326-18-000030:mdna:31]
We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 88% of our total revenues for both the three months ended September 30, 2018 and 2017, and 87% of our total revenues for both the nine months ended September 30, 2018 and 2017. We have not sold in the past, and have no future plans to sell our products, either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-18-000030:mdna:32]
[same as prior period, unchanged from 0000926326-18-000025:mdna:30]

[0000926326-18-000030:mdna:33]
[same as prior period, unchanged from 0000926326-18-000025:mdna:31]

[0000926326-18-000030:mdna:34]
[same as prior period, unchanged from 0000926326-18-000025:mdna:32]

[0000926326-18-000030:mdna:35]
| • | Deliver our solutions to new markets. Areas of healthcare where work is done manually may benefit from our existing solutions. These areas include hospitals that continue to employ manual operations, healthcare segments of the U.S. market outside hospitals and markets outside the United States. We weigh the cost of entering these new markets against the expected benefits and focus on the markets that we believe are most likely to adopt our products. |

[0000926326-18-000030:mdna:36]
| • | Expansion of our solutions through acquisitions and partnerships. Our acquisitions have generally been focused on automation of manual workflows or data analytics, which is the enhancement of data for our customers’ decision-making processes. We believe that expansion of our product lines through acquisitions and |

[0000926326-18-000030:mdna:37]
[same as prior period, unchanged from 0000926326-18-000025:mdna:45]

[0000926326-18-000030:mdna:38]
partnerships to meet our customers changing and evolving expectations is a key component to our historical and future success.

[0000926326-18-000030:mdna:39]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, in December 2016 we announced the XT Series, our new generation of medication and supply automation that is fully integrated on our Unity enterprise platform. The XT Series includes automated medication and supply dispensing cabinets, the Anesthesia Workstation™, and Controlled Substance Manager. The XT Automated Medication Cabinets have been integrated with Connect-Rx® from Aesynt, so customers in the United States and Canada who use AcuDose-Rx® cabinets can take advantage of the new hardware without changing their software or server infrastructure. As part of this product introduction, we developed a new hardware and electronics architecture for the XT Series. The new design enables more medications to be stocked within the same footprint, enabling the XT cabinets to offer up to 50% more capacity as compared with similar units on the market. In November 2017, we introduced our new IVX Workflow Solution. This new solution powered by IVX Cloud services helps enable pharmacies to safely and efficiently compound and prepare IV treatments. In December 2017, we announced our XR2 Central Pharmacy Automated System, allowing customers to more fully automate their central pharmacies.

[0000926326-18-000030:mdna:40]
[same as prior period, unchanged from 0000926326-18-000025:mdna:38]

[0000926326-18-000030:mdna:41]
[same as prior period, unchanged from 0000926326-18-000025:mdna:39]

[0000926326-18-000030:mdna:42]
[same as prior period, unchanged from 0000926326-18-000025:mdna:40]

[0000926326-18-000030:mdna:43]
[same as prior period, unchanged from 0000926326-18-000025:mdna:41]

[0000926326-18-000030:mdna:44]
[same as prior period, unchanged from 0000926326-18-000025:mdna:42]

[0000926326-18-000030:mdna:45]
[same as prior period, unchanged from 0000926326-18-000025:mdna:43]

[0000926326-18-000030:mdna:46]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of firm orders, as evidenced generally by a non-cancellable contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are generally installable within twelve months and generally recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month.

[0000926326-18-000030:mdna:47]
[same as prior period, unchanged from 0000926326-18-000025:mdna:46]

[0000926326-18-000030:mdna:48]
[same as prior period, unchanged from 0000926326-18-000025:mdna:65]

[0000926326-18-000030:mdna:49]
[same as prior period, unchanged from 0000926326-18-000025:mdna:47]

[0000926326-18-000030:mdna:50]
[same as prior period, unchanged from 0000926326-18-000025:mdna:48]

[0000926326-18-000030:mdna:51]
[same as prior period, unchanged from 0000926326-18-000025:mdna:49]

[0000926326-18-000030:mdna:52]
Our full-time headcount was approximately 2,430 and 2,350 on September 30, 2018 and December 31, 2017, respectively.

[0000926326-18-000030:mdna:53]
[same as prior period, unchanged from 0000926326-18-000025:mdna:51]

[0000926326-18-000030:mdna:54]
[same as prior period, unchanged from 0000926326-18-000025:mdna:52]

[0000926326-18-000030:mdna:55]
[same as prior period, unchanged from 0000926326-18-000025:mdna:53]

[0000926326-18-000030:mdna:56]
[same as prior period, unchanged from 0000926326-18-000025:mdna:54]

[0000926326-18-000030:mdna:57]
[same as prior period, unchanged from 0000926326-18-000025:mdna:55]

[0000926326-18-000030:mdna:58]
[same as prior period, unchanged from 0000926326-18-000025:mdna:56]

[0000926326-18-000030:mdna:59]
[same as prior period, unchanged from 0000926326-18-000025:mdna:57]

[0000926326-18-000030:mdna:60]
[same as prior period, unchanged from 0000926326-18-000025:mdna:58]

[0000926326-18-000030:mdna:61]
[same as prior period, unchanged from 0000926326-18-000025:mdna:59]

[0000926326-18-000030:mdna:62]
[same as prior period, unchanged from 0000926326-18-000025:mdna:60]

[0000926326-18-000030:mdna:63]
[same as prior period, unchanged from 0000926326-18-000025:mdna:61]

[0000926326-18-000030:mdna:64]
[same as prior period, unchanged from 0000926326-18-000025:mdna:62]

[0000926326-18-000030:mdna:65]
[same as prior period, unchanged from 0000926326-18-000025:mdna:63]

[0000926326-18-000030:mdna:66]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the nine months ended September 30, 2018 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2017, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1 to the Condensed Consolidated Financial Statements in this quarterly report.

[0000926326-18-000030:mdna:67]
[same as prior period, unchanged from 0000926326-18-000025:mdna:77]

[0000926326-18-000030:mdna:68]
[same as prior period, unchanged from 0000926326-18-000025:mdna:67]

[0000926326-18-000030:mdna:69]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-18-000030:mdna:70]
[same as prior period, unchanged from 0000926326-18-000025:mdna:69]

[0000926326-18-000030:mdna:71]
[same as prior period, unchanged from 0000926326-18-000025:mdna:70]

[0000926326-18-000030:mdna:72]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 149,709 |  |  | $ | 136,838 |  |  | $ | 12,871 |  |  | 9 | % |
| Percentage of total revenues | 73 | % |  | 73 | % |  |  |  |  |
| Services and other revenues | 54,558 |  |  | 49,910 |  |  | 4,648 |  |  | 9 | % |
| Percentage of total revenues | 27 | % |  | 27 | % |  |  |  |  |
| Total revenues | $ | 204,267 |  |  | $ | 186,748 |  |  | $ | 17,519 |  |  | 9 | % |

[0000926326-18-000030:mdna:73]
Product revenues represented 73% of total revenues for both the three months ended September 30, 2018 and 2017. Product revenues increased by $12.9 million due to increased sales for the Automation and Analytics segment of $9.9 million and increased sales for the Medication Adherence segment of $3.0 million. The increase in the Automation and Analytics segment was primarily attributed to an increase in sales of Performance Center, primarily due to a large installation during the three months ended September 30, 2018 and an increase in sales of other product mixes. The increase in the Medication Adherence segment was primarily attributed to growth of consumables and increase in core machine sales compared to the three months ended September 30, 2017.

[0000926326-18-000030:mdna:74]
Services and other revenues represented 27% of total revenues for both the three months ended September 30, 2018 and 2017. Services and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Services and other revenues increased by $4.6 million, primarily due to an increase from our Automation and Analytics segment of $3.8 million attributed to an increase in our installed customer base.

[0000926326-18-000030:mdna:75]
Our international sales represented 12% of total revenues for both the three months ended September 30, 2018 and 2017, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-18-000030:mdna:76]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 415,004 |  |  | $ | 365,834 |  |  | $ | 49,170 |  |  | 13 | % |
| Percentage of total revenues | 72 | % |  | 71 | % |  |  |  |  |
| Services and other revenues | 160,555 |  |  | 150,509 |  |  | 10,046 |  |  | 7 | % |
| Percentage of total revenues | 28 | % |  | 29 | % |  |  |  |  |
| Total revenues | $ | 575,559 |  |  | $ | 516,343 |  |  | $ | 59,216 |  |  | 11 | % |

[0000926326-18-000030:mdna:77]
Product revenues represented 72% and 71% of total revenues for the nine months ended September 30, 2018 and 2017, respectively. Product revenues increased by $49.2 million due to increased sales for the Automation and Analytics segment of $43.0 million and increased sales for the Medication Adherence segment of $6.2 million. The increase in the Automation and Analytics segment was attributed to an increase in sales of XT series products as the sales for the nine months ended September 30, 2017 had a slower conversion of bookings and backlog into revenues due to the introduction of the new XT series of products in the fourth quarter of 2016, an increase in sales of Performance Center and an increase in sales of other product mixes. The increase in the Medication Adherence segment was primarily attributed to higher completed installations of our VBM products compared to the nine months ended September 30, 2017.

[0000926326-18-000030:mdna:78]
[same as prior period, unchanged from 0000926326-18-000025:mdna:88]

[0000926326-18-000030:mdna:79]
Services and other revenues represented 28% and 29% of total revenues for the nine months ended September 30, 2018 and 2017, respectively. Services and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Services and other revenues increased by $10.0 million, primarily due to an increase from our Automation and Analytics segment of $9.7 million attributed to an increase in our installed customer base.

[0000926326-18-000030:mdna:80]
Our international sales represented 13% of total revenues for both the nine months ended September 30, 2018 and 2017, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-18-000030:mdna:81]
[same as prior period, unchanged from 0000926326-18-000025:mdna:81]

[0000926326-18-000030:mdna:82]
[same as prior period, unchanged from 0000926326-18-000025:mdna:82]

[0000926326-18-000030:mdna:83]
[same as prior period, unchanged from 0000926326-18-000025:mdna:83]

[0000926326-18-000030:mdna:84]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Revenues: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 168,303 |  |  | $ | 154,617 |  |  | $ | 13,686 |  |  | 9 | % |
| Percentage of total revenues | 82 | % |  | 83 | % |  |  |  |  |
| Medication Adherence | 35,964 |  |  | 32,131 |  |  | 3,833 |  |  | 12 | % |
| Percentage of total revenues | 18 | % |  | 17 | % |  |  |  |  |
| Total revenues | $ | 204,267 |  |  | $ | 186,748 |  |  | $ | 17,519 |  |  | 9 | % |

[0000926326-18-000030:mdna:85]
The $13.7 million increase in Automation and Analytics revenues for the three months ended September 30, 2018 in comparison to the three months ended September 30, 2017 was due to an increase in product revenues of $9.9 million and an increase in services and other revenues of $3.8 million. The increase in product revenues in the Automation and Analytics segment was primarily attributed to an increase in sales of Performance Center, primarily due to a large installation during the three months ended September 30, 2018 and an increase in sales of other product mixes. The increase in services and other revenues of $3.8 million was primarily attributed to an increase in our installed customer base.

[0000926326-18-000030:mdna:86]
Medication Adherence revenues increased by $3.8 million for the three months ended September 30, 2018 in comparison to the three months ended September 30, 2017. The increase in revenues was primarily due to an increase in product revenues of $3.0 million. This increase was primarily attributed to growth of consumables and increase in core machine sales compared to the three months ended September 30, 2017.

[0000926326-18-000030:mdna:87]
[same as prior period, unchanged from 0000926326-18-000025:mdna:87]

[0000926326-18-000030:mdna:88]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Revenues: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 478,074 |  |  | $ | 425,371 |  |  | $ | 52,703 |  |  | 12 | % |
| Percentage of total revenues | 83 | % |  | 82 | % |  |  |  |  |
| Medication Adherence | 97,485 |  |  | 90,972 |  |  | 6,513 |  |  | 7 | % |
| Percentage of total revenues | 17 | % |  | 18 | % |  |  |  |  |
| Total revenues | $ | 575,559 |  |  | $ | 516,343 |  |  | $ | 59,216 |  |  | 11 | % |

[0000926326-18-000030:mdna:89]
The $52.7 million increase in Automation and Analytics revenues for the nine months ended September 30, 2018 in comparison to the nine months ended September 30, 2017 was due to an increase in product revenues of $43.0 million and an increase in services and other revenues of $9.7 million. The increase in product revenues was attributed to an increase in sales of XT series products as the sales for the nine months ended September 30, 2017 had a slower conversion of bookings and backlog into revenues due to the introduction of the new XT series of products in the fourth quarter of 2016, an increase in sales of Performance Center and an increase in sales of other product mixes. The increase in services and other revenues of $9.7 million was primarily attributed to an increase in our installed customer base.

[0000926326-18-000030:mdna:90]
Medication Adherence revenues increased by $6.5 million for the nine months ended September 30, 2018 in comparison to the nine months ended September 30, 2017. The increase in revenues was due to an increase in product revenues of $6.2 million. The increase in product revenues was primarily attributed to higher completed installations of our VBM products compared to the nine months ended September 30, 2017.

[0000926326-18-000030:mdna:91]
[same as prior period, unchanged from 0000926326-18-000025:mdna:92]

[0000926326-18-000030:mdna:92]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs, which account for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site and include costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory and amortization of software development costs and intangibles.

[0000926326-18-000030:mdna:93]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 77,172 |  |  | $ | 79,740 |  |  | $ | (2,568 | ) |  | (3 | )% |
| As a percentage of related revenues | 46 | % |  | 52 | % |  |  |  |  |
| Medication Adherence | 28,186 |  |  | 22,189 |  |  | 5,997 |  |  | 27 | % |
| As a percentage of related revenues | 78 | % |  | 69 | % |  |  |  |  |
| Total cost of revenues | $ | 105,358 |  |  | $ | 101,929 |  |  | $ | 3,429 |  |  | 3 | % |
| As a percentage of total revenues | 52 | % |  | 55 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 91,131 |  |  | $ | 74,877 |  |  | $ | 16,254 |  |  | 22 | % |
| Automation and Analytics gross margin | 54 | % |  | 48 | % |  |  |  |  |
| Medication Adherence | 7,778 |  |  | 9,942 |  |  | (2,164 | ) |  | (22 | )% |
| Medication Adherence gross margin | 22 | % |  | 31 | % |  |  |  |  |
| Total gross profit | $ | 98,909 |  |  | $ | 84,819 |  |  | $ | 14,090 |  |  | 17 | % |
| Total gross margin | 48 | % |  | 45 | % |  |  |  |  |

[0000926326-18-000030:mdna:94]
[same as prior period, unchanged from 0000926326-18-000025:mdna:100]

[0000926326-18-000030:mdna:95]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 234,100 |  |  | $ | 229,217 |  |  | $ | 4,883 |  |  | 2 | % |
| As a percentage of related revenues | 49 | % |  | 54 | % |  |  |  |  |
| Medication Adherence | 71,312 |  |  | 61,984 |  |  | 9,328 |  |  | 15 | % |
| As a percentage of related revenues | 73 | % |  | 68 | % |  |  |  |  |
| Total cost of revenues | $ | 305,412 |  |  | $ | 291,201 |  |  | $ | 14,211 |  |  | 5 | % |
| As a percentage of total revenues | 53 | % |  | 56 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 243,974 |  |  | $ | 196,154 |  |  | $ | 47,820 |  |  | 24 | % |
| Automation and Analytics gross margin | 51 | % |  | 46 | % |  |  |  |  |
| Medication Adherence | 26,173 |  |  | 28,988 |  |  | (2,815 | ) |  | (10 | )% |
| Medication Adherence gross margin | 27 | % |  | 32 | % |  |  |  |  |
| Total gross profit | $ | 270,147 |  |  | $ | 225,142 |  |  | $ | 45,005 |  |  | 20 | % |
| Total gross margin | 47 | % |  | 44 | % |  |  |  |  |

[0000926326-18-000030:mdna:96]
Cost of Revenues. Cost of revenues for the three months ended September 30, 2018 compared to the three months ended September 30, 2017 increased by $3.4 million, of which $6.0 million was attributed to the increase in cost of revenues in our Medication Adherence segment, offset by a decrease of $2.6 million attributed to the decrease in cost of revenues in our Automation and Analytics segment. The increase in cost of revenues in the Medication Adherence segment was primarily due to the increase in revenues of $3.8 million for the three months ended September 30, 2018 compared to the three months ended September 30, 2017 and $2.1 million of excess and obsolete reserve for slower moving inventory. The decrease in cost of revenues in the Automation and Analytics segment primarily related to efficiencies, economies of scale and cost savings on our XT series of product as we are ramping up from the introduction in the fourth quarter of 2016 as well as increase in sales for Performance Center, which have higher gross margins.

[0000926326-18-000030:mdna:97]
Cost of revenues for the nine months ended September 30, 2018 compared to the nine months ended September 30, 2017 increased by $14.2 million, of which $4.9 million was attributed to the increase in cost of revenues in our Automation and Analytics segment and $9.3 million was attributed to the increase in cost of revenues in our Medication Adherence segment. The increase in cost of revenues in the Automation and Analytics segment was due to the increase in revenues of $52.7 million in the Automation and Analytics segment for the nine months ended September 30, 2018 compared to the nine months ended September 30, 2017, partially offset by the efficiencies, economies of scale and cost savings on XT series of product as we are ramping up from the introduction in the fourth quarter of 2016 as well as increase in sales for Performance Center, which have higher gross margins. The increase in cost of revenues in the Medication Adherence segment was due to the increase in revenues of $6.5 million in the Medication Adherence segment for the nine months ended September 30, 2018 compared to the nine months ended September 30, 2017 and $2.1 million of excess and obsolete reserve for slower moving inventory.

[0000926326-18-000030:mdna:98]
Overall changes to gross margin primarily relate to product mix from sales for the periods presented, higher average selling prices as well as lower costs associated with the XT series manufacturing ramp up.

[0000926326-18-000030:mdna:99]
[same as prior period, unchanged from 0000926326-18-000025:mdna:106]

[0000926326-18-000030:mdna:100]
[same as prior period, unchanged from 0000926326-18-000025:mdna:101]

[0000926326-18-000030:mdna:101]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 15,805 |  |  | $ | 16,414 |  |  | $ | (609 | ) |  | (4 | )% |
| As a percentage of total revenues | 8 | % |  | 9 | % |  |  |  |  |
| Selling, general, and administrative | 65,609 |  |  | 56,208 |  |  | 9,401 |  |  | 17 | % |
| As a percentage of total revenues | 32 | % |  | 30 | % |  |  |  |  |
| Total operating expenses | $ | 81,414 |  |  | $ | 72,622 |  |  | $ | 8,792 |  |  | 12 | % |
| As a percentage of total revenues | 40 | % |  | 39 | % |  |  |  |  |
| Income (loss) from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 45,116 |  |  | $ | 30,545 |  |  | $ | 14,571 |  |  | 48 | % |
| Automation and Analytics operating margin | 27 | % |  | 20 | % |  |  |  |  |
| Medication Adherence | (2,846 | ) |  | 41 |  |  | (2,887 | ) |  | (7,041 | )% |
| Medication Adherence operating margin | (8 | )% |  | — | % |  |  |  |  |
| Corporate Expenses | 24,775 |  |  | 18,389 |  |  | 6,386 |  |  | 35 | % |
| Total income from operations | $ | 17,495 |  |  | $ | 12,197 |  |  | $ | 5,298 |  |  | 43 | % |
| Total operating margin | 9 | % |  | 7 | % |  |  |  |  |
| Interest and other income (expense), net | $ | (2,837 | ) |  | $ | (2,732 | ) |  | $ | (105 | ) |  | 4 | % |

[0000926326-18-000030:mdna:102]
Research and Development. The $0.6 million decrease in research and development expenses for the three months ended September 30, 2018 compared to the three months ended September 30, 2017 was primarily driven by a decrease in research and development expenses of $1.8 million in our Automation and Analytics segment, offset by an increase in research and development expenses of $0.3 million in our Medication Adherence segment, and an increase of $0.9 million in corporate-related research and development expenses. The decrease in the Automation and Analytics segment was primarily attributed to several research and development projects reaching capitalization stage during the period ended September 30, 2018, resulting in lower research and development expenses. The increase in corporate-related expenses was primarily due to an increase in consulting fees related to a key engineering product management project.

[0000926326-18-000030:mdna:103]
Selling, General, and Administrative. The $9.4 million increase in selling, general, and administrative expenses for the three months ended September 30, 2018 compared to the three months ended September 30, 2017 was primarily due to the growth of operations and an increase in employee-related expenses due to the increase in headcount.

[0000926326-18-000030:mdna:104]
Interest and Other Income (Expense), Net. Interest and other income (expense), net for the three months ended September 30, 2018 was consistent compared to the three months ended September 30, 2017.

[0000926326-18-000030:mdna:105]
36

[0000926326-18-000030:mdna:106]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 47,854 |  |  | $ | 50,128 |  |  | $ | (2,274 | ) |  | (5 | )% |
| As a percentage of total revenues | 8 | % |  | 10 | % |  |  |  |  |
| Selling, general, and administrative | 196,831 |  |  | 180,070 |  |  | 16,761 |  |  | 9 | % |
| As a percentage of total revenues | 34 | % |  | 35 | % |  |  |  |  |
| Total operating expenses | $ | 244,685 |  |  | $ | 230,198 |  |  | $ | 14,487 |  |  | 6 | % |
| As a percentage of total revenues | 43 | % |  | 45 | % |  |  |  |  |
| Income (loss) from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 101,402 |  |  | $ | 56,252 |  |  | $ | 45,150 |  |  | 80 | % |
| Automation and Analytics operating margin | 21 | % |  | 13 | % |  |  |  |  |
| Medication Adherence | (4,946 | ) |  | (2,208 | ) |  | (2,738 | ) |  | 124 | % |
| Medication Adherence operating margin | (5 | )% |  | (2 | )% |  |  |  |  |
| Corporate Expenses | 70,994 |  |  | 59,100 |  |  | 11,894 |  |  | 20 | % |
| Total income (loss) from operations | $ | 25,462 |  |  | $ | (5,056 | ) |  | $ | 30,518 |  |  | (604 | )% |
| Total operating margin | 4 | % |  | (1 | )% |  |  |  |  |
| Interest and other income (expense), net | $ | (6,462 | ) |  | $ | (4,992 | ) |  | $ | (1,470 | ) |  | 29 | % |

[0000926326-18-000030:mdna:107]
Research and Development. The $2.3 million decrease in research and development expenses for the nine months ended September 30, 2018 compared to nine months ended September 30, 2017 was primarily driven by a decrease in research and development expenses of $4.6 million in our Automation and Analytics segment, offset by an increase in research and development expenses of $0.7 million in our Medication Adherence segment and an increase of $1.6 million in corporate-related research and development expenses. The decrease in the Automation and Analytics segment was primarily attributed to several research and development projects reaching capitalization stage during the period ended September 30, 2018, resulting in lower research and development expenses. The increase in corporate-related expenses was primarily due to an increase in consulting fees related to a key engineering product management project.

[0000926326-18-000030:mdna:108]
Selling, General, and Administrative. The $16.8 million increase in selling, general, and administrative expenses for the nine months ended September 30, 2018 compared to the nine months ended September 30, 2017 was primarily due to the growth of operations and an increase in employee-related expenses due to the increase in headcount.

[0000926326-18-000030:mdna:109]
Interest and Other Income (Expense), Net. The $1.5 million increase in interest and other income (expense), net for the nine months ended September 30, 2018 compared to the nine months ended September 30, 2017 was due to an increase in expenses related to foreign currency fluctuations, interest, bank charges, and amortization of debt fees and issuance costs, partially offset by a contingent gain of $2.5 million recognized during the nine months ended September 30, 2018 related to a settlement agreement associated with the Ateb acquisition.

[0000926326-18-000030:mdna:110]
[same as prior period, unchanged from 0000926326-18-000025:mdna:111]

[0000926326-18-000030:mdna:111]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 1,030 |  |  | $ | 1,717 |  |  | $ | (687 | ) |  | (40 | )% |

[0000926326-18-000030:mdna:112]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (3,936 | ) |  | $ | (9,341 | ) |  | $ | 5,405 |  |  | (58 | )% |

[0000926326-18-000030:mdna:113]
Effective Tax Rate On Earnings. Our annual effective tax rate before discrete items was 19.0% and 34.4% for the nine months ended September 30, 2018 and 2017, respectively. The decrease in the estimated annual effective tax rate for the nine months ended September 30, 2018 compared to the same period in 2017 was primarily due to U.S. tax reform legislation that reduced the statutory corporate income tax rate from 35% to 21%, an increase in research and development credits, and corporate jurisdictional restructuring.

[0000926326-18-000030:mdna:114]
[same as prior period, unchanged from 0000926326-18-000025:mdna:115]

[0000926326-18-000030:mdna:115]
We had cash and cash equivalents of $44.2 million at September 30, 2018 compared to $32.4 million at December 31, 2017. All of our cash and cash equivalents are invested in demand deposits.

[0000926326-18-000030:mdna:116]
Our cash position and working capital at September 30, 2018 and December 31, 2017 were as follows:

[0000926326-18-000030:mdna:117]
|  | September 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Cash | $ | 44,174 |  |  | $ | 32,424 |  |
| Working capital | $ | 166,537 |  |  | $ | 147,066 |  |

[0000926326-18-000030:mdna:118]
Our ratio of current assets to current liabilities was 1.8:1 at September 30, 2018 and 1.7:1 at December 31, 2017.

[0000926326-18-000030:mdna:119]
[same as prior period, unchanged from 0000926326-18-000025:mdna:120]

[0000926326-18-000030:mdna:120]
[same as prior period, unchanged from 0000926326-18-000025:mdna:121]

[0000926326-18-000030:mdna:121]
On January 5, 2016, we entered into a $400.0 million secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200.0 million term loan facility (the “Term Loan Facility”), and prior to the amendment discussed below, a $200.0 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million.

[0000926326-18-000030:mdna:122]
On December 26, 2017 and April 11, 2017, we entered into amendments to the Credit Agreement. Under these amendments, the Revolving Credit Facility was increased from $200.0 million to $315.0 million and certain other modifications were made. Refer to Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this quarterly report. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes, including acquisitions.

[0000926326-18-000030:mdna:123]
As of September 30, 2018, the outstanding balance from the Facilities was $190.0 million and we were in compliance with all covenants.

[0000926326-18-000030:mdna:124]
[same as prior period, unchanged from 0000926326-18-000025:mdna:125]

[0000926326-18-000030:mdna:125]
[same as prior period, unchanged from 0000926326-18-000025:mdna:126]

[0000926326-18-000030:mdna:126]
During the nine months ended September 30, 2018, we did not sell any common stock under the Distribution Agreement. As of September 30, 2018, we had an aggregate of $110.3 million available to be offered under the Distribution Agreement.

[0000926326-18-000030:mdna:127]
[same as prior period, unchanged from 0000926326-18-000025:mdna:128]

[0000926326-18-000030:mdna:128]
[same as prior period, unchanged from 0000926326-18-000025:mdna:129]

[0000926326-18-000030:mdna:129]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of September 30, 2018, which may result in additional use of cash. See “Stock Repurchase Program” under Note 12. Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. There were no stock repurchases during the nine months ended September 30, 2018 and 2017.

[0000926326-18-000030:mdna:130]
[same as prior period, unchanged from 0000926326-18-000025:mdna:131]

[0000926326-18-000030:mdna:131]
[same as prior period, unchanged from 0000926326-18-000025:mdna:132]

[0000926326-18-000030:mdna:132]
[same as prior period, unchanged from 0000926326-18-000025:mdna:133]

[0000926326-18-000030:mdna:133]
|  | Nine months ended |
|  | September 30, 2018 |  | September 30, 2017 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 56,514 |  |  | $ | 20,648 |  |
| Investing activities | (41,472 | ) |  | (24,101 | ) |
| Financing activities | (2,919 | ) |  | (42,065 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (373 | ) |  | (1,504 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 11,750 |  |  | $ | (47,022 | ) |

[0000926326-18-000030:mdna:134]
[same as prior period, unchanged from 0000926326-18-000025:mdna:135]

[0000926326-18-000030:mdna:135]
[same as prior period, unchanged from 0000926326-18-000025:mdna:136]

[0000926326-18-000030:mdna:136]
Net cash provided by operating activities was $56.5 million for the nine months ended September 30, 2018, primarily as a result of net income of $22.9 million adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $37.5 million, share-based compensation expense of $20.9 million, deferred income taxes of $8.8 million, and $1.7 million of amortization of debt financing fees. The net cash inflow which contributed to changes in assets and liabilities included (i) an increase in deferred revenues of $9.0 million due to the timing of orders and revenues being recognized for installed product, (ii) an increase in accrued compensation of $5.7 million, (iii) a decrease in other current assets of $3.1 million, (iv) an increase in other accrued liabilities of $1.5 million, (v) a decrease in prepaid commissions of $1.0 million, and (vi) a decrease in prepaid expenses of $0.8 million. These inflows were partially offset by (i) an increase in accounts receivable and unbilled receivables of $16.2 million due to an increase in billings, (ii) a decrease in accounts payable of $8.4 million, primarily due to the timing of payments, (iii) an increase in other long-term assets of $6.2 million as a result of the increase in unbilled receivables, (iv) an increase in inventories of $5.3 million for inventory buildup in support of forecasted sales, (v) an increase in investments in sales-type leases of $1.7 million, and (vi) a decrease in other long-term liabilities of 1.0 million.

[0000926326-18-000030:mdna:137]
Net cash provided by operating activities was $20.6 million for the nine months ended September 30, 2017, primarily as a result of the net loss of $0.7 million adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $38.5 million, share-based compensation expense of

[0000926326-18-000030:mdna:138]
39

[0000926326-18-000030:mdna:139]
$16.3 million, deferred income taxes of $9.2 million, and $1.2 million of amortization of debt financing fees. The net cash inflow which contributed to changes in assets and liabilities included (i) an increase in accounts payable of $23.7 million, primarily due to an increase in inventories and the timing of payments, (ii) a decrease in investments in sales-type leases of $6.6 million, (iii) an increase in accrued liabilities of $4.0 million, (iv) an increase in other long-term liabilities of $0.9 million, and (v) an increase in accrued compensation of $0.7 million. These inflows were partially offset by (i) an increase in inventories of $22.9 million for inventory buildup in support of forecasted sales, (ii) an increase in accounts receivable of $22.7 million due to the timing of collections, (iii) a decrease in deferred revenues of $9.2 million due to the timing of orders and revenues being recognized for installed product, and (iv) an increase in other current assets of $5.1 million.

[0000926326-18-000030:mdna:140]
[same as prior period, unchanged from 0000926326-18-000025:mdna:141]

[0000926326-18-000030:mdna:141]
Net cash used in investing activities was $41.5 million for the nine months ended September 30, 2018, which consisted of capital expenditures of $19.3 million for property and equipment, and $22.2 million for costs of software development.

[0000926326-18-000030:mdna:142]
Net cash used in investing activities was $24.1 million for the nine months ended September 30, 2017, which consisted of $10.3 million for costs of software development mainly related to the Performance Center offering and purchase of intangibles, capital expenditures of $9.4 million for property and equipment, and $4.4 million attributable to the acquisition of InPharmics.

[0000926326-18-000030:mdna:143]
[same as prior period, unchanged from 0000926326-18-000025:mdna:144]

[0000926326-18-000030:mdna:144]
Net cash used in financing activities was $2.9 million for the nine months ended September 30, 2018, primarily from the repayment of $27.0 million of the revolving credit facilities and $3.6 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $27.7 million in proceeds from employee stock option exercises and employee stock plan purchases.

[0000926326-18-000030:mdna:145]
Net cash used in financing activities was $42.1 million for the nine months ended September 30, 2017, primarily from the repayment of $100.0 million of the revolving credit facilities, $3.1 million in employees’ taxes paid related to restricted stock unit vesting, and payment of contingent consideration of $2.4 million related to the Ateb acquisition, partially offset by $37.0 million in proceeds from term loan and revolving credit facilities, and $26.5 million in proceeds from employee stock option exercises and employee stock plan purchases.

[0000926326-18-000030:mdna:146]
[same as prior period, unchanged from 0000926326-18-000025:mdna:147]

[0000926326-18-000030:mdna:147]
There have been no significant changes during the nine months ended September 30, 2018 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2017.

[0000926326-18-000030:mdna:148]
Contractual obligations as of September 30, 2018 were as follows:

[0000926326-18-000030:mdna:149]
|  | Payments due by period |
|  | Total |  | Remainder of 2018 |  | 2019 and 2020 |  | 2021 and 2022 |  | Thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 73,884 |  |  | $ | 3,392 |  |  | $ | 24,745 |  |  | $ | 19,113 |  |  | $ | 26,634 |  |
| Purchase obligations (2) | 75,864 |  |  | 57,890 |  |  | 10,418 |  |  | 5,571 |  |  | 1,985 |  |
| Term loan facility (3) | 170,000 |  |  | 5,000 |  |  | 47,500 |  |  | 117,500 |  |  | — |  |
| Revolving credit facility (3) | 20,000 |  |  | — |  |  | — |  |  | 20,000 |  |  | — |  |
| Total (4) (5) | $ | 339,748 |  |  | $ | 66,282 |  |  | $ | 82,663 |  |  | $ | 162,184 |  |  | $ | 28,619 |  |

[0000926326-18-000030:mdna:150]
[same as prior period, unchanged from 0000926326-18-000025:mdna:151]

[0000926326-18-000030:mdna:151]
[same as prior period, unchanged from 0000926326-18-000025:mdna:152]

[0000926326-18-000030:mdna:152]
| (2) | We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. The amounts under such contracts are included in the table above because we believe |

[0000926326-18-000030:mdna:153]
40

[0000926326-18-000030:mdna:154]
that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials.

[0000926326-18-000030:mdna:155]
| (3) | Amounts shown for term loan and revolving credit facility are principal repayments only. Due to use of interest rate swaps, the cash interest expense is partly variable and partly fixed, and is not reflected in the above table. Refer to Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this quarterly report. |

[0000926326-18-000030:mdna:156]
| (4) | We have recorded $6.3 million for uncertain tax positions under long-term liabilities as of September 30, 2018 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $6.3 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-18-000030:mdna:157]
| (5) | Refer to Note 10, Commitments and Contingencies, of the Notes to the Condensed Consolidated Financial Statements included in this quarterly report. |

[0000926326-18-000030:mdna:158]
[same as prior period, unchanged from 0000926326-18-000025:mdna:157]

[0000926326-18-000030:mdna:159]
As of September 30, 2018, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
