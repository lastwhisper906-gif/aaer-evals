# OMCL MD&A — 0001445305-12-001573


## mdna

[0001445305-12-001573:mdna:1]
| Item 2. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001445305-12-001573:mdna:2]
[same as prior period, unchanged from 0001104659-11-061121:mdna:2]

[0001445305-12-001573:mdna:3]
[same as prior period, unchanged from 0001104659-11-061121:mdna:3]

[0001445305-12-001573:mdna:4]
| • | the extent and timing of future revenues, including the amounts of our current backlog, which represent firm orders that have not completed installation and therefore have not been recognized as revenue; |

[0001445305-12-001573:mdna:5]
| • | our ability to conduct acquisitions for strategic value, including our pending acquisition of MTS Medication Technologies, Inc., and successfully integrate each one into our operations; |

[0001445305-12-001573:mdna:6]
| • | the size and/or growth of our market or market-share; |

[0001445305-12-001573:mdna:7]
| • | the opportunity presented by new products or emerging markets; |

[0001445305-12-001573:mdna:8]
| • | our expectations regarding our future backlog levels; |

[0001445305-12-001573:mdna:9]
| • | the operating margins or earnings per share goals we may set; |

[0001445305-12-001573:mdna:10]
| • | our ability to align our cost structure and headcount with our current business expectations; |

[0001445305-12-001573:mdna:11]
| • | our ability to protect our intellectual property and operate our business without infringing upon the intellectual property rights of others; and |

[0001445305-12-001573:mdna:12]
| • | our ability to generate cash from operations and our estimates regarding the sufficiency of our cash resources. |

[0001445305-12-001573:mdna:13]
[same as prior period, unchanged from 0001104659-11-061121:mdna:13]

[0001445305-12-001573:mdna:14]
[same as prior period, unchanged from 0001104659-11-061121:mdna:14]

[0001445305-12-001573:mdna:15]
We were incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. We are a leading provider of automated solutions for hospital medication and supply management. Our automation and analytics solutions are designed to enable healthcare facilities to acquire, manage, dispense and administer medications and medical-surgical supplies and are intended to enhance patient safety, reduce medication errors, reduce operating costs, improve workflow and increase operational efficiency. Approximately 2,600 hospitals utilize one or more of our products, of which more than 1,600 hospitals in the United States have installed our automated hardware/software solutions for controlling, dispensing, acquiring, verifying, tracking and analyzing medications and medical and surgical supplies.

[0001445305-12-001573:mdna:16]
We sell our medication dispensing and supply automation systems, and generate the substantial majority of our revenue, in the United States. However, we expect our revenue from our international operations to increase in future periods as we continue to grow our international business. Our sales force is organized by geographic region in the United States and Canada. We also sell through distributors in Asia, Australia, Europe, and South America. We have not sold in the past, and have no future plans to sell our products either directly or indirectly to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0001445305-12-001573:mdna:17]
We operate in one business segment, the design, manufacturing, selling and servicing of medication and supply dispensing systems. Our management team evaluates our performance based on company-wide, consolidated results.  In general, we recognize revenue when our medication dispensing and supply automation systems are installed. Installation generally takes place two weeks to twelve months after our systems are ordered. The installation process at our customers’ sites includes internal procedures associated with large capital expenditures and additional time associated with adopting new technologies. Given the length of time necessary for our customers to plan for and complete their acceptance of the installation of our systems, our focus is on shipping products based on the installation dates requested by our customers and working at our customer’s pace. The amount of revenue recognized in future periods may depend upon, among other things, the terms and timing of lease contract renewals, additional product sales and the size of such transactions. We believe that future revenues will be affected, to a great extent, by the competitiveness of our products and services.

[0001445305-12-001573:mdna:18]
Pending Business Acquisition

[0001445305-12-001573:mdna:19]
On April 26, 2012, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with MedPak Holdings, Inc. (“MedPak”), Mercury Acquisition Corp, and Excellere Capital Management, LLC contemplating the acquisition of MedPak by Omnicell for $156.0 million cash, subject to certain adjustments and including approximately $13.3 million in cash that would be placed in an escrow fund at the closing of the transaction. This escrow amount would ultimately be distributed to MedPak's stockholders (subject to claims that Omnicell may make against the escrow fund for indemnification and other claims following the closing). MedPak is the privately-held parent company of MTS Medication Technologies, Inc., a worldwide provider of medication adherence packaging systems. The Merger Agreement provides for the merger of Mercury Acquisition Corp, a newly formed Omnicell subsidiary, with and into MedPak, with MedPak surviving the merger as a wholly-owned subsidiary of Omnicell.  The closing of the acquisition is subject to customary closing conditions, including the expiration of the applicable Hart-Scott-Rodino Act waiting period.

[0001445305-12-001573:mdna:20]
The financial information reported for the three months ended March 31, 2012 does not include any financial data for the pending acquisition of MTS Medication Technologies, Inc. Also, any of the forward-looking statements about "Omnicell" in this Management Discussion & Analysis refer to the existing operations of Omnicell, excluding the potential impact of the pending acquisition.

[0001445305-12-001573:mdna:21]
Operating Environment During the Three Months Ended March 31, 2012

[0001445305-12-001573:mdna:22]
Our revenues have grown year-over-year for both product and services, with overall revenue growth of 12.2%, comparing $64.1 million for the first quarter of 2012 with $57.2 million for the first quarter of 2011. Product revenue growth is reflective of installations as allowed for by our customers’ schedules, while service revenue growth reflects a growing installed base. Product and service margins increased modestly for the three months ended March 31, 2012 as compared to the same period in 2011.

[0001445305-12-001573:mdna:23]
We believe our solutions are attractive relative to our competition. In particular:

[0001445305-12-001573:mdna:24]
| • | We have continued to differentiate ourselves through a strategy intended to create the best customer experience in healthcare; |

[0001445305-12-001573:mdna:25]
| • | We have delivered industry-leading products with differentiated product features that are designed to appeal to nurses and pharmacists, such as our recently announced G4 platform, the SavvyTM Mobile Medication System, SinglePointeTM, Tissue Center System and Anywhere RNTM; and |

[0001445305-12-001573:mdna:26]
| • | The market environment of increased patient safety awareness and increased regulatory control has driven our solutions to be a high priority in customers’ capital budgets. |

[0001445305-12-001573:mdna:27]
We maintain a development staff with expertise in hospital logistics and computerized automated solutions, which allows us to deliver new innovations to the market. Our ability to grow revenue and maintain positive cash flow is dependent on our ability to obtain orders from customers, the volume of installations we are able to complete, our ability to meet customers' needs while providing a quality installation experience and our flexibility in manpower allocations among customers to complete installations on a timely basis.

[0001445305-12-001573:mdna:28]
During the first quarter of 2012, we achieved 1.9% growth in total revenues from the fourth quarter of 2011. Product revenue increased by $1.2 million, or 2.6%, while service revenue decreased slightly, by 0.2%. Overall gross margins for the first quarter of 2012 declined to 55.7% from 57.0% in the fourth quarter of 2011. Product gross margins declined to 58.2% on

[0001445305-12-001573:mdna:29]
revenue of $48.5 million as compared with 58.6% on revenue of $47.3 million in the fourth quarter of 2011. Service gross margins also declined, to 48.2% on revenue of $15.6 million as compared to 52.2% margins on $15.7 million in revenue in the fourth quarter of 2011.

[0001445305-12-001573:mdna:30]
Cash, cash equivalents and short-term investments increased during the first quarter of 2012 from $199.9 million at December 31, 2011 to $209.5 million, with $7.3 million in quarterly operating cash flow reflecting improved net income and decline of inventories after the prior year of inventory growth in support of our transition to our G4 platform. Additionally, there were no share repurchases and no software development for external use requiring cash during the three months ended March 31, 2012.

[0001445305-12-001573:mdna:31]
[same as prior period, unchanged from 0001104659-11-061121:mdna:28]

[0001445305-12-001573:mdna:32]
Our discussion and analysis of our financial condition and results of operations are based on our consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States. The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe that the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our condensed consolidated financial statements:

[0001445305-12-001573:mdna:33]
•Revenue recognition;

[0001445305-12-001573:mdna:34]
•Provision for allowances;

[0001445305-12-001573:mdna:35]
•Valuation and impairment of goodwill, other intangible assets and other long lived assets;

[0001445305-12-001573:mdna:36]
•Inventory;

[0001445305-12-001573:mdna:37]
•Valuation of share-based awards; and

[0001445305-12-001573:mdna:38]
•Accounting for income taxes.

[0001445305-12-001573:mdna:39]
During the three months ended March 31, 2012, there were no significant changes in our critical accounting policies and estimates.

[0001445305-12-001573:mdna:40]
Please refer to Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended December 31, 2011 for a more complete discussion of our critical accounting policies and estimates.

[0001445305-12-001573:mdna:41]
Recently Adopted Accounting Pronouncements

[0001445305-12-001573:mdna:42]
In May 2011, the FASB issued ASU 2011-04, Fair Value Measurement, amending the fair value guidance in ASC 820, and thereby achieving substantially converged fair value measurement and disclosure requirements for GAAP and IFRS. The new guidance clarified some fair value measurement principles and expanded certain disclosure requirements. We adopted this guidance in the first quarter of 2012, without any impact to our financial position, operating results or cash flows.

[0001445305-12-001573:mdna:43]
[same as prior period, unchanged from 0001104659-11-061121:mdna:73]

[0001445305-12-001573:mdna:44]
The table below shows the components of our results of operations as percentages of total revenues for the three months ended March 31, 2012 and 2011 (in thousands, except percentages):

[0001445305-12-001573:mdna:45]
|  | Three Months Ended March 31, |
|  | 2012 |  | 2011 |
|  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 48,524 |  |  | 75.6 | % |  | $ | 42,575 |  |  | 74.5 | % |
| Service and other revenues | 15,619 |  |  | 24.4 | % |  | 14,585 |  |  | 25.5 | % |
| Total revenues | 64,143 |  |  | 100.0 | % |  | 57,160 |  |  | 100.0 | % |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 20,296 |  |  | 31.6 | % |  | 17,836 |  |  | 31.2 | % |
| Cost of service and other revenues | 8,098 |  |  | 12.6 | % |  | 7,674 |  |  | 13.4 | % |
| Total cost of revenues | 28,394 |  |  | 44.2 | % |  | 25,510 |  |  | 44.6 | % |
| Gross profit | 35,749 |  |  | 55.8 | % |  | 31,650 |  |  | 55.4 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 6,494 |  |  | 10.1 | % |  | 4,840 |  |  | 8.5 | % |
| Selling, general and administrative | 25,620 |  |  | 39.9 | % |  | 25,781 |  |  | 45.1 | % |
| Total operating expenses | 32,114 |  |  | 50.0 | % |  | 30,621 |  |  | 53.6 | % |
| Income from operations | 3,635 |  |  | 5.8 | % |  | 1,029 |  |  | 1.8 | % |
| Interest and other income (expense) | 96 |  |  | 0.1 | % |  | 54 |  |  | 0.1 | % |
| Income before provision for income taxes | 3,731 |  |  | 5.9 | % |  | 1,083 |  |  | 1.9 | % |
| Provision for income taxes | 1,380 |  |  | 2.2 | % |  | 413 |  |  | 0.7 | % |
| Net income | $ | 2,351 |  |  | 3.7 | % |  | $ | 670 |  |  | 1.2 | % |

[0001445305-12-001573:mdna:46]
[same as prior period, unchanged from 0001104659-11-061121:mdna:76]

[0001445305-12-001573:mdna:47]
The table below shows our product revenues, cost of product revenues and gross profit for the three months ended March 31, 2012 and 2011 and the percentage changes between those periods (in thousands, except percentages):

[0001445305-12-001573:mdna:48]
|  | Three Months Ended March 31, |
|  | 2012 |  | 2011 |  | % Change |
| Product revenues | $ | 48,524 |  |  | $ | 42,575 |  |  | 14.0 | % |
| Cost of product revenues | 20,296 |  |  | 17,836 |  |  | 13.8 | % |
| Gross profit | $ | 28,228 |  |  | $ | 24,739 |  |  | 14.1 | % |
| Gross margin | 58.2 | % |  | 58.1 | % |  |  |

[0001445305-12-001573:mdna:49]
Product revenues increased by $5.9 million, or 14.0%, in the three months ended March 31, 2012 as compared to the same period in 2011. Our ability to grow revenue is dependent on our ability to continue to obtain orders from customers, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience and our flexibility in manpower allocations among customers to complete installations on a timely basis.  The timing of our product revenues is primarily dependent on when our customers' schedules allow for installations. The overall increase in product revenues was driven by a combination of increased installations of our new automation products and increases in lease renewals from existing customers. We anticipate our revenues will continue to increase in 2012 by approximately 7.0% to 8.0%, year over year, as we fulfill our existing orders and as we experience an anticipated continued high volume of lease renewals.

[0001445305-12-001573:mdna:50]
Cost of product revenues increased by $2.5 million, or 13.8%, in the three months ended March 31, 2012 as compared to the same period in 2011. This increase is consistent with the corresponding growth in revenue.

[0001445305-12-001573:mdna:51]
Gross profit on product revenue increased by $3.5 million, or 14.1%, in the three months ended March 31, 2012 as compared to the same period in 2011. This increase was primarily a result of the aforementioned increases in product revenue, together with relatively comparable increases in product costs to support this revenue growth.

[0001445305-12-001573:mdna:52]
24

[0001445305-12-001573:mdna:53]
We do not anticipate any significant fluctuations in our gross margin beyond normal fluctuations caused by changes in product mix.

[0001445305-12-001573:mdna:54]
[same as prior period, unchanged from 0001104659-11-061121:mdna:84]

[0001445305-12-001573:mdna:55]
The table below shows our service and other revenues, cost of service and other revenues and gross profit for the three months ended March 31, 2012 and 2011 and the percentage change between those periods (in thousands, except percentages):

[0001445305-12-001573:mdna:56]
|  | Three Months Ended March 31, |
|  | 2012 |  | 2011 |  | % Change |
|  | (in thousands) |  |  |
| Service and other revenues | $ | 15,619 |  |  | $ | 14,585 |  |  | 7.1 | % |
| Cost of service and other revenues | 8,098 |  |  | 7,674 |  |  | 5.5 | % |
| Gross profit | $ | 7,521 |  |  | $ | 6,911 |  |  | 8.8 | % |
| Gross margin | 48.2 | % |  | 47.4 | % |  |  |

[0001445305-12-001573:mdna:57]
Service and other revenues include revenues from service and maintenance contracts, rentals of automation systems, training and professional services. Service and other revenues increased by $1.0 million, or 7.1%, in the three months ended March 31, 2012 as compared to the same period in 2011. The increase in service and other revenues was primarily the result of an expansion in our installed base of automation systems and a resulting increase in the number of support service contracts, continued growth in analytical software and higher training revenues.

[0001445305-12-001573:mdna:58]
Cost of service and other revenues increased by $0.4 million, or 5.5%, in the three months ended March 31, 2012 as compared to the same period in 2011. The increase was primarily due to an increase in spending related to salaries and benefits associated with higher headcount, and spare parts expense in support of the expanded service base.

[0001445305-12-001573:mdna:59]
Gross profit on service and other revenues increased by $0.6 million, or 8.8%, in the three months ended March 31, 2012 as compared to the same period in 2011. The increase in gross profit on service and other revenues was due to increased revenues from an expanded installed base with nominal growth in service cost. We expect our service and other revenues and the associated gross profit to continue to increase in 2012 at a similar rate with the continued expansion of our installed base of automation systems and service and maintenance contracts.

[0001445305-12-001573:mdna:60]
[same as prior period, unchanged from 0001104659-11-061121:mdna:91]

[0001445305-12-001573:mdna:61]
The table below shows our operating expenses for the three months ended March 31, 2012 and 2011 and the percentage changes between those periods (in thousands, except percentages):

[0001445305-12-001573:mdna:62]
|  | Three Months Ended March 31, |
|  | 2012 |  | 2011 |  | % Change |
| Research and development | $ | 6,494 |  |  | $ | 4,840 |  |  | 34.2 | % |
| Selling, general and administrative | 25,620 |  |  | 25,781 |  |  | (0.6 | )% |
| Total operating expenses | $ | 32,114 |  |  | $ | 30,621 |  |  | 4.9 | % |

[0001445305-12-001573:mdna:63]
Research and Development. Research and development expenses increased by $1.7 million, or 34.2%, in the three months ended March 31, 2012 as compared to the same period in 2011. Research and development expenses represented 10.1% and 8.5% of total revenues in the three months ended March 31, 2012 and 2011, respectively. The increase was due primarily to a $1.8 million decrease in software capitalization, as there were no expenses eligible for capitalization in the current period, and an increase of $0.5 million in consulting, offset by a decrease of $0.6 million of salary related expenses. The amount of research and development expense can fluctuate based on the amount of prototype expenses for hardware and/or the amount of capitalized software development costs in any given quarter.

[0001445305-12-001573:mdna:64]
We expect research and development expenses to remain relatively flat as a percentage of our revenue on an annual basis and grow in absolute dollars in the future as our revenue grows to improve and enhance our existing technologies and to create new technologies in health care automation.

[0001445305-12-001573:mdna:65]
Selling, General and Administrative. Selling, general and administrative expenses decreased by $0.2 million, or 0.6%, in the three months ended March 31, 2012 as compared to the same period in 2011. Selling, general and administrative

[0001445305-12-001573:mdna:66]
expenses represented 39.9% and 45.1% of total revenues in the three months ended March 31, 2012 and 2011, respectively.  Selling, general and administrative expenses for the three months ended March 31, 2012 as compared to the same period in 2011 included increased salary and benefits of $1.4 million, primarily related to net increases in sales and marketing staff, offset by the reduction due to the non-recurrence of last year's Medacist litigation settlement accrual of $1.0 million, with related legal fees of $0.5 million.

[0001445305-12-001573:mdna:67]
We expect selling, general and administrative expenses to grow at a nominal rate in order to support international efforts, but anticipate that increased efficiencies will result in a lower selling, general and administrative expense growth relative to total revenue growth in 2012.

[0001445305-12-001573:mdna:68]
Share-based Compensation. The effect of share-based compensation on functional expenses within our operating results for the three months ended March 31, 2012 and 2011 is presented in Note 13 "Stock Option Plans and Share-Based Compensation".

[0001445305-12-001573:mdna:69]
[same as prior period, unchanged from 0001104659-11-061121:mdna:102]

[0001445305-12-001573:mdna:70]
The decrease in the estimated annual effective tax rate for the three months ended March 31, 2012 as compared to the same period in 2011 was primarily due to an increase in the domestic production activities deduction in 2012, partially offset by the impact of the expiration of the federal research and development credit after 2011.

[0001445305-12-001573:mdna:71]
[same as prior period, unchanged from 0001104659-11-061121:mdna:105]

[0001445305-12-001573:mdna:72]
We had cash and cash equivalents of $201.4 million at March 31, 2012, as compared to $191.8 million at December 31, 2011, plus an additional $8.1 million of short term investments at both March 31, 2012 and December 31, 2011.  All of our cash is in low risk short term money market funds or demand deposits. The $8.1 million of short term investments held at March 31, 2012 consisted of California revenue anticipation notes which are scheduled to mature June 26, 2012. We have no long term investments. While in the future we may need to seek additional financing to meet our working capital needs and to finance capital expenditures, as well as to fund operations or potential acquisitions, we believe our current cash and cash equivalent balances and cash flows generated by operations will be sufficient to satisfy our anticipated cash needs for working capital and capital expenditures for at least the next twelve months. Currently, we have cash, cash equivalents and short term investments of $209.5 million of which we will use $156.0 million cash, subject to adjustments, on the pending MTS acquisition as described in Note 14 "Subsequent Events".

[0001445305-12-001573:mdna:73]
Cash flows for the three months ended March 31, 2012 and 2011 consisted of the following (in thousands):

[0001445305-12-001573:mdna:74]
|  | Three Months Ended March 31, |
|  | 2012 |  | 2011 |
| Net cash provided by operating activities | $ | 7,289 |  |  | $ | 3,115 |  |
| Net cash used in investing activities | (1,528 | ) |  | (4,271 | ) |
| Net cash provided by (used in) financing activities | 3,816 |  |  | (810 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 81 |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents | $ | 9,658 |  |  | $ | (1,966 | ) |

[0001445305-12-001573:mdna:75]
Operating activities provided $7.3 million of cash during the three months ended March 31, 2012 as compared to $3.1 million for the three months ended March 31, 2011. The main drivers for the $4.2 million increase in cash generated from operations were a $1.7 million increase in net income, a $6.9 million increase from the change in inventories primarily the result of a non-recurring increase in 2011 in anticipation of new product introductions, partially offset by a decrease of $3.2 million in cash generated through changes in accounts receivable. Other balance sheet changes impacting the change in cash generated from operating activities were a $2.4 million increase from the change in deferred gross profit and a $1.7 million increase from the change in accrued compensation, offset by a $2.5 million decrease from the change in net investment in sales-type leases, and a $2.9 million decrease from the change in accrued liabilities and accounts payable.

[0001445305-12-001573:mdna:76]
Cash used in investing activities totaled $1.5 million during the three months ended March 31, 2012, as compared to $4.3 million used in investing activities during the three months ended March 31, 2011. This $2.7 million decrease in cash used was primarily due to $1.8 million spending in the same period of 2011for beta testing of several new software applications for external sale or lease as compared to none in the three months ended March 31, 2012.  Cash used also differed due to the  $1.0 million decrease in spending on property and equipment for the three months ended March 31, 2012 as compared to the same period of 2011.

[0001445305-12-001573:mdna:77]
Cash provided by financing activities was $3.8 million during the three months ended March 31, 2012, as compared to cash used of $0.8 million during the three months ended March 31, 2011, a difference of $4.6 million in cash generated. Cash used in the three months ended March 31, 2011 included $4.7 million to acquire our stock under our stock repurchase programs in the period. There was no such repurchase activity in the three months ended March 31, 2012.

[0001445305-12-001573:mdna:78]
[same as prior period, unchanged from 0001104659-11-061121:mdna:112]

[0001445305-12-001573:mdna:79]
Except for the Milpitas lease signed in March 2012, there have been no material changes to our contractual obligations during the three months ended March 31, 2012.  Please refer to our Annual Report on Form 10-K for the year ended December 31, 2011 for a description of our facility leases and contractual obligations and the Notes to the consolidated financial statements included therein.

[0001445305-12-001573:mdna:80]
The following table summarizes our contractual obligations at March 31, 2012 (in thousands):

[0001445305-12-001573:mdna:81]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | More than five years |
| Operating leases (1) (2) (3) | $ | 43,846 |  |  | $ | 4,242 |  |  | $ | 8,506 |  |  | $ | 8,129 |  |  | $ | 22,969 |  |
| Commitments to contract manufacturers and suppliers (4) | 5,247 |  |  | 5,247 |  |  | — |  |  | — |  |  | — |  |
| Total (5) (6) | $ | 49,093 |  |  | $ | 9,489 |  |  | $ | 8,506 |  |  | $ | 8,129 |  |  | $ | 22,969 |  |

[0001445305-12-001573:mdna:82]
(1)       Commitments under operating leases relate primarily to leasehold property and office equipment.

[0001445305-12-001573:mdna:83]
(2)       In October 2011, we entered into a lease agreement for approximately 100,000 square feet of office space. Pursuant to the lease agreement, the landlord will construct a single, three-story building of rentable space located at 590 Middlefield Road in Mountain View, California which we will subsequently lease and which will serve as our headquarters. The term of the lease agreement is for a period of 120 months, expected to commence November 2012, with a base lease commitment of approximately $40.0 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term.

[0001445305-12-001573:mdna:84]
(3)     In March 2012, we entered into a lease agreement for approximately 46,000 square feet of manufacturing, distribution and office space located at 735 Sycamore Drive in Milpitas, California. The term of the lease agreement is for a period of 60 months, expected to commence approximately October 2012, with a base lease commitment of approximately $1.8 million and a single five-year extension option.

[0001445305-12-001573:mdna:85]
(4)    We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. We record a liability for firm, non-cancelable and unconditional purchase commitments.

[0001445305-12-001573:mdna:86]
(5)    At March 31, 2012, we have recorded $1.6 million for uncertain tax positions under long term liabilities, in accordance with GAAP, summarized under Note 1 “Organization and Summary of Significant Accounting Policies.” As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $1.6 million of uncertain tax position liabilities has not been included in the table of commitments above.

[0001445305-12-001573:mdna:87]
(6)    Also excluded from the above table of commitments is $156.0 million, subject to adjustments, for the pending all-cash transaction to acquire MTS, as described in Note 14 “Subsequent Events” in this report.

[0001445305-12-001573:mdna:88]
[same as prior period, unchanged from 0001104659-11-061121:mdna:119]

[0001445305-12-001573:mdna:89]
As of March 31, 2012, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
