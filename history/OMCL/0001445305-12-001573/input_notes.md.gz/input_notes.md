# OMCL notes — 0001445305-12-001573


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001445305-12-001573:notes:1]
Cash and Cash Equivalents, Short-term Investments and Fair Value of Financial Instruments

[0001445305-12-001573:notes:2]
Cash and cash equivalents and short-term investments consist of the following significant investment asset classes, with disclosure of amortized cost, gross unrealized gains and losses, and fair value as of March 31, 2012 and December 31, 2011 (in thousands):

[0001445305-12-001573:notes:3]
|  | March 31, 2012 |  |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | Short-termInvestments |  | SecurityClassification (1) |
| Cash | $ | 12,717 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,717 |  |  | $ | 12,717 |  |  | $ | — |  |  | N/A |
| Money market funds | 188,703 |  |  | — |  |  | — |  |  | 188,703 |  |  | 188,703 |  |  | — |  |  | Available for sale |
| Non-U.S. Government securities | 8,114 |  |  | 3 |  |  | — |  |  | 8,117 |  |  | — |  |  | 8,117 |  |  | Available for sale |
| Total cash, cash equivalents and short-term investments | $ | 209,534 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 209,537 |  |  | $ | 201,420 |  |  | $ | 8,117 |  |  |  |

[0001445305-12-001573:notes:4]
|  | December 31, 2011 |  |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | Short-termInvestments |  | SecurityClassification (1) |
| Cash | $ | 14,452 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,452 |  |  | $ | 14,452 |  |  | $ | — |  |  | N/A |
| Money market funds | 177,310 |  |  | — |  |  | — |  |  | 177,310 |  |  | 177,310 |  |  | — |  |  | Available for sale |
| Non-U.S. government securities | 8,106 |  |  | 1 |  |  | — |  |  | 8,107 |  |  | — |  |  | 8,107 |  |  | Available for sale |
| Total cash, cash equivalents and short-term investments | $ | 199,868 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 199,869 |  |  | $ | 191,762 |  |  | $ | 8,107 |  |  |  |

[0001445305-12-001573:notes:5]
(1)           For Available-for-sale securities, fair value is the asset’s carrying value, equal to the amortized cost plus any unrealized gains/losses. For Held-to-maturity securities, the amortized cost is the asset’s carrying value (since there are no other-than-temporary impairments) and the fair value gains/losses are not only unrealized, but also unrecorded.

[0001445305-12-001573:notes:6]
The money market fund is a daily-traded cash equivalent with the price of $1.00, making it a Level 1 asset class, and its carrying cost closely approximates fair value. As demand deposit (cash) balances vary with the timing of collections and payments, the money market fund can cover any surplus or deficit, and thus is considered Available-for-sale.

[0001445305-12-001573:notes:7]
The short term investments purchased in September 2011 are comprised of California revenue anticipation notes, which mature in June 2012. As this is the initial investment in a broader portfolio strategy for yield management, these are considered Available-for-sale. The notes are considered a Level 2 asset class, because their pricing is drawn from multiple market-related inputs, but in general not from same-day, same-security trades.

[0001445305-12-001573:notes:8]
The following table displays the financial assets measured at fair value, on a recurring basis, with money market funds recorded within cash and cash equivalents and non-U.S Government securities in short-term investments (in thousands):

[0001445305-12-001573:notes:9]
|  | Quoted Prices in ActiveMarkets for IdenticalInstruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant UnobservableInputs(Level 3) |  | Total FairValue |
| At March 31, 2012 |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 188,703 |  |  | $ | — |  |  | — |  |  | $ | 188,703 |  |
| Non U.S. Government securities | — |  |  | 8,117 |  |  | — |  |  | 8,117 |  |
| Total | $ | 188,703 |  |  | $ | 8,117 |  |  | — |  |  | $ | 196,820 |  |
| At December 31, 2011 |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 177,310 |  |  | — |  |  | — |  |  | $ | 177,310 |  |
| Non U.S. Government securities | — |  |  | 8,107 |  |  | — |  |  | 8,107 |  |
| Total | $ | 177,310 |  |  | 8,107 |  |  | — |  |  | $ | 185,417 |  |

[0001445305-12-001573:notes:10]
Current assets and current liabilities are recorded at amortized cost, which approximates fair value due to the short-term maturities implied.


## us-gaap:CommitmentsDisclosureTextBlock

[0001445305-12-001573:notes:11]
Commitments

[0001445305-12-001573:notes:12]
At March 31, 2012, the minimum payments under our operating leases for each of the five succeeding fiscal years are as follows (in thousands):

[0001445305-12-001573:notes:13]
| 2012 (remaining nine months) | $ | 3,408 |  |
| 2013 | 4,049 |  |
| 2014 | 4,219 |  |
| 2015 | 4,115 |  |
| 2016 | 4,049 |  |
| 2017 | 4,071 |  |
| Total | $ | 23,911 |  |

[0001445305-12-001573:notes:14]
Commitments under operating leases relate primarily to leasehold property and office equipment.

[0001445305-12-001573:notes:15]
In October 2011, we entered into a lease agreement for approximately 100,000 square feet of office space. Pursuant to the lease agreement, the landlord will construct a single, three-story building of rentable space located at 590 Middlefield Road in Mountain View, California which we will subsequently lease and which will serve as our headquarters. The term of the lease agreement is for a period of 120 months, expected to commence November 2012, with a base lease commitment of approximately $40.0 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term.

[0001445305-12-001573:notes:16]
In March 2012, we entered into a lease agreement for approximately 46,000 square feet of manufacturing, distribution and office space located at 735 Sycamore Drive in Milpitas, California. The term of the lease agreement is for a period of 60 months, expected to commence approximately October 2012, with a base lease commitment of approximately $1.8 million and a single five-year extension option.

[0001445305-12-001573:notes:17]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. Our near-term commitments to our contract manufacturers and suppliers totaled $5.2 million as of March 31, 2012.

[0001445305-12-001573:notes:18]
At March 31, 2012, we have recorded $1.6 million for uncertain tax positions under long term liabilities, in accordance with GAAP, summarized under Note 1 “Organization and Summary of Significant Accounting Policies.” As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $1.6 million of uncertain tax position liabilities has not been included in the table of commitments above.

[0001445305-12-001573:notes:19]
Also excluded from the above table of commitments is the $156.0 million purchase price, subject to certain adjustments, in connection with the pending acquisition of MTS Medication Technologies, Inc., as described in Note 14 “Subsequent Events” in this report.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001445305-12-001573:notes:20]
Stock Option Plans and Share-Based Compensation

[0001445305-12-001573:notes:21]
Stock Option Plans

[0001445305-12-001573:notes:22]
At March 31, 2012, a total of 2,113,671 shares of common stock were reserved for future issuance under our 2009 Equity Incentive Plan (the “2009 Plan”). At March 31, 2012, $6.7 million of total unrecognized compensation cost related to non-vested stock options was expected to be recognized over a weighted average period of 2.7 years.

[0001445305-12-001573:notes:23]
A summary of aggregate option activity for the three months ended March 31, 2012 is presented below:

[0001445305-12-001573:notes:24]
| Options: |  | Number of Shares |  | Weighted- Average Exercise Price |
|  |  | (in thousands) |  |  |
| Outstanding at December 31, 2011 |  | 4,693 |  |  | $ | 13.36 |  |
| Granted |  | 201 |  |  | $ | 16.56 |  |
| Exercised |  | (125 | ) |  | $ | 10.10 |  |
| Forfeited |  | (34 | ) |  | $ | 13.13 |  |
| Expired |  | (40 | ) |  | $ | 22.19 |  |
| Outstanding at March 31, 2012 |  | 4,695 |  |  | $ | 13.51 |  |
| Exercisable at March 31, 2012 |  | 3,597 |  |  | $ | 13.45 |  |

[0001445305-12-001573:notes:25]
Restricted Stock and Time-based Restricted Stock Units

[0001445305-12-001573:notes:26]
The non-employee members of our Board of Directors are granted restricted stock on the day of our annual meeting of stockholders and such shares of restricted stock vest on the date of the subsequent year’s annual meeting of stockholders,  provided such non-employee director remains a director on such date. Restricted stock units (“RSUs”) are granted to certain of our employees and generally vest over a period of four years and are expensed ratably on a straight-line basis over the vesting period.  The fair value of both restricted stock and RSUs granted pursuant to our stock option plans is the product of the number of shares granted and the grant date fair value of our common stock.  Our unrecognized compensation cost related to non-vested restricted stock at March 31, 2012 was approximately $0.1 million and is expected to be recognized over a weighted-average period of 0.2 years. Expected future compensation expense relating to RSUs outstanding on March 31, 2012 is $4.2 million over a weighted-average period of 2.7 years.

[0001445305-12-001573:notes:27]
A summary of activity of both restricted stock and RSUs for the three months ended March 31, 2012 is presented below:

[0001445305-12-001573:notes:28]
|  | Restricted Stock |  | Restricted Stock Units |
|  |  |  | Weighted - |  |  |  | Weighted - |
|  | Number ofShares |  | AverageGrant DateFair Value PerShare |  | Number ofShares |  | AverageGrant DateFair Value PerShare |
|  | (in thousands) |  |  |  | (in thousands) |  |  |
| Non-vested, December 31, 2011 | 68 |  |  | $ | 14.71 |  |  | 287 |  |  | $ | 13.03 |  |
| Granted | — |  |  | — |  |  | 74 |  |  | $ | 16.59 |  |
| Vested | — |  |  | — |  |  | (20 | ) |  | $ | 12.92 |  |
| Forfeited | — |  |  | — |  |  | (9 | ) |  | $ | 14.21 |  |
| Non-vested, March 31, 2012 | 68 |  |  | $ | 14.71 |  |  | 332 |  |  | $ | 13.79 |  |

[0001445305-12-001573:notes:29]
Performance-based Restricted Stock Units

[0001445305-12-001573:notes:30]
In 2011, we began incorporating performance-based restricted stock units (“PSUs”) as an element of our executive compensation plans. For our executive officers, equity grants made in 2011 totaled 100,000 stock options, 50,000 time-based RSUs and 100,000 PSUs, however up to 120,000 PSUs would become eligible for vesting upon the achievement of a certain level of shareholder return for 2011 as described below. For 2012 to date, the executive officer equity grants total 125,000 stock options, 62,510 time-based RSUs and 125,000 PSUs. Our unrecognized compensation cost related to non-vested performance-based restricted stock units at March 31, 2012 was approximately $1.5 million and is expected to be recognized over a weighted-average period of 1.8 years.

[0001445305-12-001573:notes:31]
The fair value of a PSU award is the average of trial-specific values of the award over each of one million Monte Carlo trials. Each trial-specific value is the market value of the award at the end of the one-year performance period discounted back to the grant date. The market value of the award for each trial at the end of the performance period is the product of (a) the per share value of Omnicell stock at the end of the performance period and (b) the number of shares that vest. The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of each of the other companies in the Index as shown in the table above.

[0001445305-12-001573:notes:32]
Vesting for the PSU awards is based on the percentile placement of our total shareholder return among the companies listed in the NASDAQ Healthcare Index (the “Index”) and time-based vesting. We calculate total shareholder return based on the one year annualized rates of return reflecting price appreciation plus reinvestment of dividends. Stock price appreciation is calculated based on the average closing prices of the applicable company’s common stock for the 20 trading days ending on the last trading day of the year prior to the date of grant as compared to the average closing prices for the 20 trading days ended on the last trading day of the year of grant. The following table shows the percent of PSUs granted in 2011 eligible for further time-based vesting based on our percentile placement:

[0001445305-12-001573:notes:33]
| Percentile Placement ofOur Total ShareholderReturn | % of PSUs Eligible for Time-Based Vesting |
| Below the 35th percentile | —% |
| At least the 35th percentile, but below the 50th percentile | 50% |
| At least the 50th percentile, but below the 65th percentile | 100% |
| At least the 65th percentile, but below the 75th percentile | 110% to 119%(1) |
| At or above the 75th percentile | 120% |

[0001445305-12-001573:notes:34]
(1)                The actual percentage of PSUs eligible for further time-based vesting is based on straight-line interpolation, where, for example, if the ranking is the 70th percentile, then the vesting percentage is 115%.

[0001445305-12-001573:notes:35]
On January 17, 2012, the Compensation Committee of our Board of Directors confirmed 76.3% as the percentile rank of Omnicell's 2011 total shareholder return. This resulted in 120% of the 2011 PSU awards, or 120,000 shares, becoming eligible for further time-based vesting. The eligible PSU awards will vest as follows: 25% of the eligible awards for the first year vested immediately January 17, 2012 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service.

[0001445305-12-001573:notes:36]
The following table shows the percent of PSUs granted in 2012 eligible for further time-based vesting based on our percentile placement:

[0001445305-12-001573:notes:37]
| Percentile Placement ofOur Total ShareholderReturn | % of PSUs Eligible for Time-Based Vesting |
| Below the 35th percentile | —% |
| At least the 35th percentile, but below the 50th percentile | 50% |
| At least the 50th percentile | 100% |

[0001445305-12-001573:notes:38]
After the last trading day of 2012, the Committee will determine the percentile rank of the Company's total stockholder return and the number of performance-based restricted stock unit awards eligible for further time-based vesting. The eligible performance-based restricted stock unit awards will vest as follows: 25% of the shares on the date of the Committee meeting in 2013 when the Committee reviews the performance-based metrics and determines if they were met or not, with the remaining shares vesting on a semi-annual basis over a period of 36 months commencing on June 15, 2013 if the Company meets certain stock performance objectives compared to the Index. The actual number of shares that vest may be 0% to 100% of the numbers reflected above, depending upon the Company's performance. Vesting is contingent upon continued service.

[0001445305-12-001573:notes:39]
In addition to the 125,000 PSUs granted in the first quarter of 2012, an additional 5,000 PSUs vested during the first quarter 2012 as a result of the Company's 2011 total stockholder return which caused 120% of the 2011 PSUs to become eligible for further time based vesting.

[0001445305-12-001573:notes:40]
A summary of activity of the PSUs for the three months ended March 31, 2012 is presented below:

[0001445305-12-001573:notes:41]
|  |  |  | Weighted -AverageGrant DateFair Value Per |
| Performance-based Stock Units | Number of Shares |  | Share |
|  | (in thousands) |  |  |  |
| Non-vested, December 31, 2011 | 100 |  |  | $ | 11.15 |  |
| Granted | 130 |  |  | $ | 10.94 |  |
| Vested | (30 | ) |  | $ | 11.15 |  |
| Forfeited | — |  |  | — |  |
| Non-vested, March 31, 2012 | 200 |  |  | $ | 11.01 |  |

[0001445305-12-001573:notes:42]
Employee Stock Purchase Plan

[0001445305-12-001573:notes:43]
We have an Employee Stock Purchase Plan (“ESPP”), under which employees can purchase shares of our common stock based on a percentage of their compensation, but not greater than 15% of their earnings, up to a maximum of $25,000 of fair value per year. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period. As of March 31, 2012, 3,602,826 shares had been issued under the ESPP. As of March 31, 2012 there were a total of 1,728,729 shares reserved for future issuance under the ESPP. For the three months ended March 31, 2012, 197,831 shares of common stock were purchased under the ESPP.

[0001445305-12-001573:notes:44]
Share-based Compensation

[0001445305-12-001573:notes:45]
We account for share-based awards granted to employees and directors, including employee stock option awards, restricted stock, PSUs and RSUs issued pursuant to the 2009 Plan and employee stock purchases made under our ESPP using the estimated grant date fair value method of accounting in accordance with ASC 718, Stock Compensation.

[0001445305-12-001573:notes:46]
The impact on our results for share-based compensation for the three months ended March 31, 2012 and 2011 was as follows (in thousands):

[0001445305-12-001573:notes:47]
|  | Three Months Ended March 31, |
|  | 2012 |  | 2011 |
| Cost of product and service revenues | $ | 268 |  |  | $ | 367 |  |
| Research and development expenses | 243 |  |  | 327 |  |
| Selling, general and administrative expenses | 1,696 |  |  | 1,698 |  |
| Total share-based compensation expenses | $ | 2,207 |  |  | $ | 2,392 |  |

[0001445305-12-001573:notes:48]
We value options and ESPP shares using the Black-Scholes-Merton option-pricing model. Restricted stock and time-based RSUs are valued at the grant date fair value of the underlying common shares. The PSUs are valued via Monte Carlo simulation, as described above.


## us-gaap:EarningsPerShareTextBlock

[0001445305-12-001573:notes:49]
Net Income Per Share

[0001445305-12-001573:notes:50]
Basic net income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares less shares subject to repurchase plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Since their impact is anti-dilutive, the total number of shares excluded from the calculations of diluted net income per share for the three months ended March 31, 2012 and 2011 were 2,065,842 and 2,033,842, respectively.

[0001445305-12-001573:notes:51]
The calculation of basic and diluted net income per share is as follows (in thousands, except per share amounts):

[0001445305-12-001573:notes:52]
|  | Three Months Ended March 31, |
|  | 2012 |  | 2011 |
| Basic: |  |  |  |  |  |
| Net income | $ | 2,351 |  |  | $ | 670 |  |
| Weighted average shares outstanding — basic | 33,365 |  |  | 33,184 |  |
| Net income per share — basic | $ | 0.07 |  |  | $ | 0.02 |  |
| Diluted: |  |  |  |  |  |
| Net income | $ | 2,351 |  |  | $ | 670 |  |
| Weighted average shares outstanding — basic | 33,365 |  |  | 33,184 |  |
| Add: Dilutive effect of employee stock plans | 975 |  |  | 914 |  |
| Weighted average shares outstanding — diluted | 34,340 |  |  | 34,098 |  |
| Net income per share — diluted | $ | 0.07 |  |  | $ | 0.02 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001445305-12-001573:notes:53]
Goodwill and Other Intangible Assets

[0001445305-12-001573:notes:54]
Under ASC 350, “Intangibles — Goodwill and Other,” goodwill and intangible assets with an indefinite life are not subject to amortization.  Rather, we evaluate these assets for impairment at least annually or more frequently if events or changes in circumstances suggest that the carrying amount may not be recoverable.

[0001445305-12-001573:notes:55]
Goodwill and other intangible assets consist of the following (in thousands):

[0001445305-12-001573:notes:56]
|  | March 31, 2012 |  | December 31, 2011 |  |  |
|  | Gross |  |  |  | Net |  | Gross |  |  |  | Net |  |  |
|  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | AmortizationLife |
| Finite-lived intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 4,230 |  |  | $ | 1,703 |  |  | $ | 2,527 |  |  | $ | 4,230 |  |  | $ | 1,591 |  |  | $ | 2,639 |  |  | 5-16 years |
| Acquired technology | 980 |  |  | 210 |  |  | 770 |  |  | 980 |  |  | 175 |  |  | 805 |  |  | 3-7 years |
| Patents | 979 |  |  | 194 |  |  | 785 |  |  | 889 |  |  | 190 |  |  | 699 |  |  | 20 years |
| Trade name | 90 |  |  | 45 |  |  | 45 |  |  | 90 |  |  | 37 |  |  | 53 |  |  | 3 years |
| Non-compete agreements | 60 |  |  | 30 |  |  | 30 |  |  | 60 |  |  | 25 |  |  | 35 |  |  | 3 years |
| Total finite-lived intangibles | 6,339 |  |  | 2,182 |  |  | 4,157 |  |  | 6,249 |  |  | 2,018 |  |  | 4,231 |  |  |  |
| Goodwill | 28,543 |  |  | — |  |  | 28,543 |  |  | 28,543 |  |  | — |  |  | 28,543 |  |  | Indefinite |
| Net intangibles and goodwill | $ | 34,882 |  |  | $ | 2,182 |  |  | $ | 32,700 |  |  | $ | 34,792 |  |  | $ | 2,018 |  |  | $ | 32,774 |  |  |  |

[0001445305-12-001573:notes:57]
Amortization expense totaled $0.2 million and $0.2 million for the three months ended March 31, 2012 and 2011, respectively.  Estimated annual expected amortization expense of the finite-lived intangible assets at March 31, 2012 is as follows (in thousands):

[0001445305-12-001573:notes:58]
| 2012 (remaining nine months) | $ | 492 |  |
| 2013 | 643 |  |
| 2014 | 603 |  |
| 2015 | 580 |  |
| 2016 | 230 |  |
| 2017 | 194 |  |
| Thereafter | 1,415 |  |
| Total | $ | 4,157 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001445305-12-001573:notes:59]
Inventories

[0001445305-12-001573:notes:60]
Inventories consist of the following (in thousands):

[0001445305-12-001573:notes:61]
|  | March 31, 2012 |  | December 31, 2011 |
| Raw materials | $ | 6,724 |  |  | $ | 7,666 |  |
| Work in process | 95 |  |  | 14 |  |
| Finished goods | 10,174 |  |  | 10,427 |  |
| Total | $ | 16,993 |  |  | $ | 18,107 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001445305-12-001573:notes:62]
Contingencies

[0001445305-12-001573:notes:63]
Legal Proceedings

[0001445305-12-001573:notes:64]
We may from time to time become involved in certain legal proceedings in the ordinary course of business. We are not a party to any legal proceedings that management believes may have a material impact on Omnicell's financial position or results of operations.

[0001445305-12-001573:notes:65]
Guarantees

[0001445305-12-001573:notes:66]
As permitted under Delaware law and our certificate of incorporation and bylaws, we have agreed to indemnify our directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become our directors or officers. The term of the indemnification period is for the director's or officer's lifetime and there is no limit on the potential amount of future payments that we could be required to make under these indemnification agreements. We have purchased a directors' and officers' liability insurance policy that may enable us to recover a portion of any future payments that we may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0001445305-12-001573:notes:67]
Additionally, we undertake indemnification obligations in our ordinary course of business in connection with, among other things, the licensing of our products and the provision of our support services. In the ordinary course of our business, we have in the past and may in the future agree to indemnify another party, generally our business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, our gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, we attempt to limit the maximum potential amount of future payments that we may be required to make under these indemnification obligations to the amounts paid to us by a customer, but in some cases the obligation may not be so limited. In addition, we have in the past and may in the future warrant to our customers that our products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that our software media is free from material defects.

[0001445305-12-001573:notes:68]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no liabilities have been recorded for such indemnification obligations as of March 31, 2012 or December 31, 2011.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001445305-12-001573:notes:69]
Organization and Summary of Significant Accounting Policies

[0001445305-12-001573:notes:70]
Description of the Company. Omnicell, Inc. (“Omnicell,” “our,” “us,” “we,” or the “Company”) was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are medication and supply dispensing systems, with related services, which are sold in our principal market, the healthcare industry. Our market is located primarily in the United States.

[0001445305-12-001573:notes:71]
Basis of Presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of March 31, 2012, the results of operations and comprehensive income for the three months ended March 31, 2012 and 2011 and the statement of cash flows for the three months ended March 31, 2012 and 2011.  Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2011.

[0001445305-12-001573:notes:72]
Our results of operations, comprehensive income and cash flows for the three months ended March 31, 2012 are not necessarily indicative of results that may be expected for the year ending December 31, 2012, or for any future period.

[0001445305-12-001573:notes:73]
Use of estimates. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Actual results could differ from those estimates.

[0001445305-12-001573:notes:74]
Principles of consolidation. The condensed consolidated financial statements include the accounts of our wholly-owned subsidiaries. All significant inter-company accounts and transactions have been eliminated in consolidation.

[0001445305-12-001573:notes:75]
Reclassifications. Certain reclassifications have been made to the prior year consolidated balance sheet to conform to the current period presentation, including reclassification of net receivable credit balances by customer from accounts receivable to customer advances.  None of these reclassifications are material to the consolidated financial statements.

[0001445305-12-001573:notes:76]
Fair value of financial instruments. We value our financial assets and liabilities on a recurring basis using the fair value hierarchy established in Accounting Standards Codification (“ASC”) 820, Fair Value Measurements and Disclosures.

[0001445305-12-001573:notes:77]
ASC 820 describes three levels of inputs that may be used to measure fair value, as follows:

[0001445305-12-001573:notes:78]
Level 1 inputs, which include quoted prices in active markets for identical assets or liabilities;

[0001445305-12-001573:notes:79]
Level 2 inputs, which include observable inputs other than Level 1 inputs, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability; and

[0001445305-12-001573:notes:80]
Level 3 inputs, which include unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the underlying asset or liability. Level 3 assets and liabilities include those whose fair value measurements are determined using pricing models, discounted cash flow methodologies or similar valuation techniques, as well as significant management judgment or estimation.

[0001445305-12-001573:notes:81]
At March 31, 2012 and December 31, 2011, our financial assets, measured at fair value on a recurring basis, utilizing Level 1 inputs included cash equivalents. For these items, quoted market prices are readily available and fair value approximates carrying value. At both March 31, 2012 and at December 31, 2011, we had a short-term investment in California revenue anticipation notes, measured at fair value on a recurring basis, the valuation inputs of which were classified as Level 2. We do not currently have any material financial instruments, measured at fair value on a recurring basis, utilizing Level 3 inputs.

[0001445305-12-001573:notes:82]
Classification of marketable securities. Securities held as investments for the indefinite future, pending future spending requirements, are classified as "Available-for-sale" and are carried at their fair value, with any unrealized gain or loss recorded to other comprehensive income until realized. At March 31, 2012 and December 31, 2011, we held $188.7 million and $177.3 million, respectively, of money market mutual funds classified as Available-for-sale cash equivalents. At March 31, 2012 and December 31, 2011, respectively, we held $8.1 million and $8.1 million of non-U.S. Government securities classified as Available-for-sale short-term investments. We do not hold securities for purposes of trading. Marketable securities for which we have the intent and ability to hold to maturity are classified as "Held-to-maturity" and are carried at their amortized cost, including accrued interest. There were no Held-to-maturity securities held at March 31, 2012 and December 31, 2011.

[0001445305-12-001573:notes:83]
Revenue recognition. We earn revenues from sales of our medication and supply dispensing systems, with related services, which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States. Our customer arrangements typically include one or more of the following deliverables:

[0001445305-12-001573:notes:84]
| • | Products — Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals and other medical supplies. |

[0001445305-12-001573:notes:85]
| • | Software — Additional software applications that enable incremental functionality of our equipment. |

[0001445305-12-001573:notes:86]
| • | Installation — Installation of equipment as integrated systems at customers’ sites. |

[0001445305-12-001573:notes:87]
| • | Post-installation technical support — Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available. |

[0001445305-12-001573:notes:88]
| • | Professional services — Other customer services, such as training and consulting. |

[0001445305-12-001573:notes:89]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

[0001445305-12-001573:notes:90]
•Persuasive evidence of an arrangement exists.  We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement.

[0001445305-12-001573:notes:91]
•Delivery has occurred.  Equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installed installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. We recognize revenue from sales of products to distributors upon delivery, assuming all other revenue criteria are met since we do not allow for rights of return or refund. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period. We recognize revenue on training and professional services as they are performed.

[0001445305-12-001573:notes:92]
•Fee is fixed or determinable.  We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services.

[0001445305-12-001573:notes:93]
•Collection is probable.  We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer’s payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable.

[0001445305-12-001573:notes:94]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. Effective for new or modified arrangements entered into beginning on January 1, 2011, the date we adopted the revised revenue recognition guidance for arrangements with multiple deliverables on a prospective basis, we allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence (“VSOE”) of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support services and professional services. When VSOE of fair value is not available, third-party evidence (“TPE”) of fair value for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties’ prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices (“BESP”). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE, TPE and BESP information and obtain formal approval by appropriate levels of management.

[0001445305-12-001573:notes:95]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable on the basis of its estimated selling price. In addition, the amount recognized for any delivered items cannot exceed that which is not contingent upon delivery of any remaining items in the arrangement.

[0001445305-12-001573:notes:96]
We also use the residual method of allocating the arrangement consideration in certain circumstances. We use the residual method to allocate total arrangement consideration between delivered and undelivered items for any arrangements entered into prior to January 1, 2011 and not subsequently materially-modified. The use of the residual method is required by software revenue recognition rules that applied to sales of most of our products and services until the adoption of the new revenue recognition guidance. We also use the residual method to allocate revenue between the software products that enable incremental equipment functionality and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0001445305-12-001573:notes:97]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is recognized in product revenue using the interest method.

[0001445305-12-001573:notes:98]
Accounts receivable, net and net investment in sales type leases. We actively manage our accounts receivable to minimize credit risk. We typically sell to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer’s impaired ability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position.

[0001445305-12-001573:notes:99]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

[0001445305-12-001573:notes:100]
The retained in-house leases discussed above are considered financing receivables. Our credit policies and evaluation of credit risk and write-off policies are applied alike to trade receivables and the net-investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class. Financing receivables which are reserved are generally transferred to cash-basis accounting so that revenue is recognized only as cash is received. However, the cash basis accounts continue to accrue interest.

[0001445305-12-001573:notes:101]
Sales of accounts receivable. We record the sale of our accounts receivables as “true sales” in accordance with accounting guidance for transfers and servicing of financial assets. During the three months ended March 31, 2012 and 2011, we transferred non-recourse accounts receivable totaling $12.1 million and $11.0 million, respectively, which approximated fair value, to third-party leasing companies. At March 31, 2012 and December 31, 2011, accounts receivable included $0.7 million and $0.2 million, respectively, due from third-party leasing companies for transferred non-recourse accounts receivable.

[0001445305-12-001573:notes:102]
Concentration in revenues and in accounts receivable. There were no customers accounting for 10% or more of revenues in the three months ended March 31, 2012 or 2011. There were no customers accounting for 10% or more of accounts receivable at March 31, 2012 or at December 31, 2011.

[0001445305-12-001573:notes:103]
Accounting policy for shipping costs. Outbound freight billed to customers is recorded as product revenue. The related shipping and handling cost is expensed as part of selling, general and administrative expense. Such shipping and handling expenses totaled $0.7 million and $0.6 million for the three months ended March 31, 2012 and 2011, respectively.

[0001445305-12-001573:notes:104]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products.  There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice.  Purchases from this supplier for the three months ended March 31, 2012 and 2011 were approximately $6.2 million and $5.7 million, respectively.

[0001445305-12-001573:notes:105]
Income Taxes. We record a tax provision for the anticipated tax consequences of the reported results of operations. In accordance with GAAP, the provision for income taxes is computed using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates expected to apply in the periods in which those tax assets and liabilities are expected to be realized. In the event that we determine all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0001445305-12-001573:notes:106]
In accordance with ASC 740, Tax Provisions, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management's expectations could have a material impact on our financial condition and operating results.

[0001445305-12-001573:notes:107]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annualized effective tax rate before discrete items was 39.6% and 41.9% for the three months ended March 31, 2012 and 2011, respectively. The 2012 annualized effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.

[0001445305-12-001573:notes:108]
The 2011 annualized effective tax rate differed from the statutory rate of 35%, primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the federal research and development credit claimed and the domestic production activities deduction. Our effective tax rate, after discrete items, for the three months ended March 31, 2012 and 2011, was approximately 37.0% and 38.1%, respectively.

[0001445305-12-001573:notes:109]
Segment Information. We manage our business on the basis of one operating segment. Our products and technologies share similar distribution channels and customers and are sold primarily to hospitals and healthcare facilities to improve patient safety and care and enhance operational efficiency. Our single operating segment is medication and supply dispensing systems. Substantially all of our long-lived assets are located in the United States. For the three months ended March 31, 2012 and 2011, our revenues and gross profits were generated entirely from medication and supply dispensing systems.

[0001445305-12-001573:notes:110]
Recently Adopted Accounting Pronouncements. In May 2011, the Financial Accounting Standards Board ("FASB") issued ASU 2011-04, Fair Value Measurement, amending the fair value guidance in ASC 820, and thereby achieving substantially converged fair value measurement and disclosure requirements for GAAP and International Financial Reporting Standards ("IFRS"). The new guidance clarified some fair value measurement principles and expanded certain disclosure requirements. We adopted this guidance in the first quarter of 2012 without any impact to our financial position, operating results or cash flows.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001445305-12-001573:notes:111]
Property and Equipment

[0001445305-12-001573:notes:112]
Property and equipment consist of the following (in thousands):

[0001445305-12-001573:notes:113]
|  | March 31, 2012 |  | December 31, 2011 |
| Equipment | $ | 26,118 |  |  | $ | 25,101 |  |
| Furniture and fixtures | 1,753 |  |  | 1,811 |  |
| Leasehold improvements | 2,866 |  |  | 3,692 |  |
| Purchased software | 20,777 |  |  | 20,641 |  |
| Capital in process | 1,024 |  |  | 2,283 |  |
|  | 52,538 |  |  | 53,528 |  |
| Accumulated depreciation and amortization | (35,426 | ) |  | (36,222 | ) |
| Property and equipment, net | $ | 17,112 |  |  | $ | 17,306 |  |

[0001445305-12-001573:notes:114]
Depreciation and amortization of property and equipment totaled approximately $1.6 million and $1.4 million for the three months ended March 31, 2012 and 2011, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001445305-12-001573:notes:115]
Stockholders’ Equity

[0001445305-12-001573:notes:116]
Treasury Stock

[0001445305-12-001573:notes:117]
During 2008, our Board of Directors authorized a stock repurchase program for the repurchase of up to $90.0 million of our common stock. All repurchased shares were recorded as treasury stock and were accounted for under the cost method. No repurchased shares have been retired. The timing, price and volume of the repurchases have been based on market conditions, relevant securities laws and other factors. The stock repurchase program does not obligate us to repurchase any specific number of shares, and we may terminate or suspend the repurchase program at any time.

[0001445305-12-001573:notes:118]
During the three months ended March 31, 2012, we repurchased no shares through the stock repurchase program. We repurchased 341,100 shares through the stock repurchase program in the three months ended March 31, 2011 at an average cost of $13.87 per share.

[0001445305-12-001573:notes:119]
From the inception of the program in February 2008 through March 31, 2012, we have repurchased a total of 4,955,807 shares at an average cost of $15.67 per share through open market purchases. As of March 31, 2012, we had $12.4 million of remaining authorized funds to repurchase additional shares under the stock repurchase program.


## us-gaap:SubsequentEventsTextBlock

[0001445305-12-001573:notes:120]
Subsequent Events

[0001445305-12-001573:notes:121]
Treasury Stock Repurchase

[0001445305-12-001573:notes:122]
During the month of April 2012, we repurchased 244,687 shares at an average cost of $14.00 per share, including commissions, under our stock repurchase program. As a result, $8.9 million is the remaining balance authorized for future repurchases as of April 30, 2012.

[0001445305-12-001573:notes:123]
Pending Business Acquisition

[0001445305-12-001573:notes:124]
On April 26, 2012, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with MedPak Holdings, Inc. (“MedPak”), Mercury Acquisition Corp, and Excellere Capital Management, LLC contemplating the acquisition of MedPak by Omnicell in exchange for $156.0 million cash, subject to certain adjustments and including $13.3 million in cash that would be placed in an escrow fund at the closing of the transaction. This escrow amount would ultimately be distributed to MedPak's stockholders (subject to claims that Omnicell may make against the escrow fund for indemnification and other claims following the closing). MedPak is the privately-held parent company of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems. The Merger Agreement provides for the merger of Mercury Acquisition Corp, a newly formed Omnicell subsidiary, with and into MedPak, with MedPak surviving the merger as a wholly-owned subsidiary of Omnicell.  The closing of the acquisition is subject to customary closing conditions, including the expiration of the applicable Hart-Scott-Rodino Act waiting period.

[0001445305-12-001573:notes:125]
Other than the impact of the pending $156.0 million cash reduction, no estimates of the financial effect of the acquisition can be made at this time.


## omcl:AccruedLiabilitiesTextBlock

[0001445305-12-001573:notes:126]
Accrued Liabilities

[0001445305-12-001573:notes:127]
Accrued liabilities consist of the following (in thousands):

[0001445305-12-001573:notes:128]
|  | March 31, 2012 |  | December 31, 2011 |
| Advance payments from customers | $ | 3,058 |  |  | $ | 3,390 |  |
| Accrued Group Purchasing Organization (GPO) fees | 2,037 |  |  | 2,437 |  |
| Rebates and lease buyouts | 962 |  |  | 1,748 |  |
| Taxes Payable | 1,351 |  |  | 925 |  |
| Other | 845 |  |  | 401 |  |
| Total | $ | 8,253 |  |  | $ | 8,901 |  |


## omcl:DeferredGrossProfitTextBlock

[0001445305-12-001573:notes:129]
Deferred Gross Profit

[0001445305-12-001573:notes:130]
Deferred gross profit consists of the following (in thousands):

[0001445305-12-001573:notes:131]
|  | March 31, 2012 |  | December 31, 2011 |
| Sales of medication and supply dispensing systems, which have been delivered and invoiced but not yet installed | $ | 26,816 |  |  | $ | 24,181 |  |
| Cost of revenues, excluding installation costs | (10,939 | ) |  | (9,971 | ) |
| Deferred gross profit | $ | 15,877 |  |  | $ | 14,210 |  |


## omcl:NetInvestmentsInSalesTypeLeasesTextBlock

[0001445305-12-001573:notes:132]
Net Investment in Sales-Type Leases

[0001445305-12-001573:notes:133]
Our sales-type leases are for terms generally ranging up to five years. Sales-type lease receivables are collateralized by the underlying equipment. The components of our net investment in sales-type leases are as follows (in thousands):

[0001445305-12-001573:notes:134]
|  | March 31, 2012 |  | December 31, 2011 |
| Net minimum lease payments to be received | $ | 17,983 |  |  | $ | 15,063 |  |
| Less unearned interest income portion | 1,205 |  |  | 1,229 |  |
| Net investment in sales-type leases | 16,778 |  |  | 13,834 |  |
| Less current portion(1) | 5,417 |  |  | 5,049 |  |
| Non-current net investment in sales-type leases(2) | $ | 11,361 |  |  | $ | 8,785 |  |

[0001445305-12-001573:notes:135]
(1)     A component of other current assets. This amount is net of allowance for doubtful accounts of $0.1 million as of March 31, 2012 and $0.1 million as of December 31, 2011.

[0001445305-12-001573:notes:136]
(2)     Net of allowance for doubtful accounts of $0.1 million as of March 31, 2012 and $0.1 million as of December 31, 2011.

[0001445305-12-001573:notes:137]
The minimum lease payments under sales-type leases as of March 31, 2012 were as follows (in thousands):

[0001445305-12-001573:notes:138]
| 2012 (remaining nine months) | $ | 4,759 |  |
| 2013 | 4,722 |  |
| 2014 | 3,641 |  |
| 2015 | 2,646 |  |
| 2016 | 1,727 |  |
| Thereafter | 488 |  |
| Total | $ | 17,983 |  |

[0001445305-12-001573:notes:139]
The following table summarizes the credit losses and recorded investment in sales-type leases, excluding unearned interest, as of March 31, 2012 and December 31, 2011 (in thousands):

[0001445305-12-001573:notes:140]
|  | Allowance for Credit Losses |  | Recorded Investmentin Sales-type Leases Gross |  | Recorded Investmentin Sales-type Leases Net |
| Credit loss disclosure for March 31, 2012 : |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | 151 |  |  | $ | 151 |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 106 |  |  | 16,884 |  |  | 16,778 |  |
| Ending balances: March 31, 2012 | $ | 257 |  |  | $ | 17,035 |  |  | $ | 16,778 |  |
| Credit loss disclosure for December 31, 2011 : |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | 178 |  |  | $ | 178 |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 106 |  |  | 13,940 |  |  | 13,834 |  |
| Ending balances: December 31, 2011 | $ | 284 |  |  | $ | 14,118 |  |  | $ | 13,834 |  |

[0001445305-12-001573:notes:141]
The following table summarizes the activity for the allowance for credit losses for the investment in sales-type leases for the three months ended March 31, 2012 and 2011 (in thousands):

[0001445305-12-001573:notes:142]
|  | Three Months Ended March 31, |
|  | 2012 |  | 2011 |
| Allowance for credit losses, beginning of period | $ | 284 |  |  | $ | 411 |  |
| Current period provision (reversal) | — |  |  | (4 | ) |
| Recoveries of amounts previously charged off | (27 | ) |  | (27 | ) |
| Allowance for credit losses, end of period | $ | 257 |  |  | $ | 380 |  |
