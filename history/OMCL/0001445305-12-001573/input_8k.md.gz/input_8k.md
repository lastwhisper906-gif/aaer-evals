# OMCL 8-K — 0001104659-12-032048 filed 2012-05-02

## item codes, every 8-K on or before 2012-05-08

- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2012-05-08

- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-12-032048:8k_2_02:1]
EX-99.1
2
a12-10929_1ex99d1.htm
EX-99.1

[0001104659-12-032048:8k_2_02:2]
Exhibit 99.1

[0001104659-12-032048:8k_2_02:3]
| Contact: |  |  |
| Rob Seim |  | Omnicell, Inc. |
| Chief Financial Officer |  | 1201 Charleston Road |
| 800-850-6664, ext. 6478 |  | Mountain View, CA 94043 |
| rob.seim@omnicell.com |  |  |

[0001104659-12-032048:8k_2_02:4]
Omnicell Announces First Quarter 2012 Results

[0001104659-12-032048:8k_2_02:5]
MOUNTAIN VIEW, Calif. — May 2, 2012 — Omnicell, Inc. (NASDAQ: OMCL), a leading global provider of system solutions to acute healthcare facilities, today announced results for its quarter ended March 31, 2012.

[0001104659-12-032048:8k_2_02:6]
GAAP results: Revenue for the first quarter of 2012 was $64.1 million as compared with $62.9 million for the fourth quarter of 2011 and up $6.9 million or 12.2% from first quarter 2011 revenue of $57.2 million.

[0001104659-12-032048:8k_2_02:7]
Net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $2.4 million, or $0.07 per diluted share for the first quarter of 2012, as compared with $4.1 million, or $0.12 per diluted share, for the fourth quarter of 2011 and $0.7 million, or $0.02 per diluted share, for the first quarter of 2011.

[0001104659-12-032048:8k_2_02:8]
Non-GAAP results: Non-GAAP net income was $4.6 million for the first quarter of 2012, or $0.13 per diluted share, which excludes $2.2 million in stock compensation expense. This compares to non-GAAP net income of $6.4 million, or $0.19 per diluted share, for the fourth quarter of 2011, which excludes $2.2 million in stock compensation expense.  First quarter 2012 results compare to non-GAAP net income of $3.7 million or $0.11 per diluted share, for the first quarter of 2011, which excludes $2.4 million in stock compensation expense and $1.0 million pre-tax settlement expense for litigation claims, net of a $0.4 million tax effect.

[0001104659-12-032048:8k_2_02:9]
“I am pleased with our performance and results in the first quarter of 2012,” said Randall Lipps, Omnicell President, Chairman and CEO. “The solid results of the quarter keep our momentum in line with our annual growth projections in both revenue and profit.”

[0001104659-12-032048:8k_2_02:10]
Omnicell Conference Call Information

[0001104659-12-032048:8k_2_02:11]
Omnicell will hold a conference call today at 2:00 p.m. PDT today to discuss first quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 72808077. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 5:30 p.m. PDT and will be available until 8:59 p.m. PDT on May 9. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, conference code # 72808077

[0001104659-12-032048:8k_2_02:12]
About Omnicell

[0001104659-12-032048:8k_2_02:13]
Omnicell, Inc. (NASDAQ: OMCL) is a leading provider of systems that enable acute healthcare facilities to increase operational efficiency, enhance patient safety and allow clinicians to spend more time with their patients.

[0001104659-12-032048:8k_2_02:14]
Founded in 1992, Omnicell’s medication-use solutions include complete automation systems for the central pharmacy, anesthesia workstations for the operating room, dispensing cabinet systems for nursing units and safe, secure medication transportation and verification systems to the patient bedside. From a medication’s arrival at the receiving dock to its dosing to the patient, Omnicell systems store it, package it, bar code it, order it, issue it and provide information and controls on its use and reorder.

[0001104659-12-032048:8k_2_02:15]
Omnicell supply product lines provide a healthcare institution with comprehensive supply chain solutions that result in fast, effective control of costs, capture of charges for payer reimbursement and timely reorder of supplies. Products range from high-security closed-cabinet systems and software to open-shelf and combination solutions in the nursing unit, cath lab and operating room.

[0001104659-12-032048:8k_2_02:16]
For more information, visit www.omnicell.com.

[0001104659-12-032048:8k_2_02:17]
Forward-Looking Statements

[0001104659-12-032048:8k_2_02:18]
To the extent any statements contained in this release deal with information that is not historical, these statements are necessarily forward-looking, such as the Chairman’s statement on first quarter momentum for annual growth proiections. As such, they are subject to the occurrence of many events outside Omnicell’s control and are subject to various risk factors that could cause actual results to differ materially from those expressed or implied in any forward-looking statement. The risk factors are described in Omnicell’s Securities and Exchange Commission (SEC) filings and include, without limitation, the unfavorable general economic and market conditions, with potential variability from quarter to quarter, the tightening in the credit market, the evolution of our products and services to match changing customer requirements, the continued growth and acceptance of our products and services, the continued growth of the clinical automation and workflow automation market generally, the role of government regulation and funding in the health care industry, the impact of government budget cycles on customer demand, the potential of increasing competition, including the effect of customers’ broader business relationships with competitors many times our size, protection of our intellectual property and defense against others’ intellectual property claims, management of the volatility in our stock price resulting from variability in our operating performance, the importance of maintaining effective internal control over financial reporting for Sarbanes Oxley compliance, and our ability to grow product backlog, to recruit and retain key personnel, to cut expenses, to manage future changes in revenue levels, to successfully manage our inventory and our critical supplier relationships, to manage general purchasing organization (GPO) relationships for profitable sales growth, to avoid delays in product installations, to develop new products and integrate acquired products or intellectual property in a timely and cost-effective manner, and to improve sales productivity from our recently-expanded direct sales force. Prospective investors are cautioned not to place undue reliance on forward-looking statements.

[0001104659-12-032048:8k_2_02:19]
Use of Non-GAAP Financial Information

[0001104659-12-032048:8k_2_02:20]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP earnings per diluted share.  These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, earnings per diluted share, or any other performance measure derived in accordance with GAAP.  We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0001104659-12-032048:8k_2_02:21]
Our non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP earnings per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0001104659-12-032048:8k_2_02:22]
a)  Stock-based compensation expense impact of Accounting Standards Codification (ASC) 718.  We recognize equity plan-related compensation expenses, which represent the fair value of all share-based payments to employees, including grants of employee stock options, as required under ASC 718, “Stock Compensation” as non-GAAP adjustments in each period.

[0001104659-12-032048:8k_2_02:23]
b) Litigation settlement (net of tax).   We recorded a charge in the first quarter of 2011 for settlement of litigation claims for $1.0 million pre-tax, net of the $0.4 million income tax effect.  This charge is not expected to be recurring and, as such, the financial impact is excluded from our non-GAAP results.

[0001104659-12-032048:8k_2_02:24]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; they are non-operational, or they are non-cash expenses involving stock option grants.

[0001104659-12-032048:8k_2_02:25]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0001104659-12-032048:8k_2_02:26]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0001104659-12-032048:8k_2_02:27]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0001104659-12-032048:8k_2_02:28]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0001104659-12-032048:8k_2_02:29]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0001104659-12-032048:8k_2_02:30]
Set forth below are additional reasons why share-based compensation expense related to ASC 718 is excluded from our non-GAAP financial measures:

[0001104659-12-032048:8k_2_02:31]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0001104659-12-032048:8k_2_02:32]
ii) We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718, are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options.  As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0001104659-12-032048:8k_2_02:33]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results.  In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0001104659-12-032048:8k_2_02:34]
· Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0001104659-12-032048:8k_2_02:35]
· Other companies, including other companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0001104659-12-032048:8k_2_02:36]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0001104659-12-032048:8k_2_02:37]
Omnicell, Inc.

[0001104659-12-032048:8k_2_02:38]
Condensed Consolidated Statements of Operations

[0001104659-12-032048:8k_2_02:39]
(in thousands, except per share data, unaudited)

[0001104659-12-032048:8k_2_02:40]
|  |  | Three Months Ended |  |
|  |  | March 31, 2012 |  | December 31, 2011 |  | March 31, 2011 |  |
| Revenues: |  |  |  |  |  |  |  |
| Product |  | $ | 48,524 |  | $ | 47,281 |  | $ | 42,575 |  |
| Services and other revenues |  | 15,619 |  | 15,650 |  | 14,585 |  |
| Total revenue |  | 64,143 |  | 62,931 |  | 57,160 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues |  | 20,296 |  | 19,572 |  | 17,836 |  |
| Cost of services and other revenues |  | 8,098 |  | 7,480 |  | 7,674 |  |
| Total cost of revenues |  | 28,394 |  | 27,052 |  | 25,510 |  |
| Gross profit |  | 35,749 |  | 35,879 |  | 31,650 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development |  | 6,494 |  | 5,903 |  | 4,840 |  |
| Selling, general, and administrative |  | 25,620 |  | 23,807 |  | 25,781 |  |
| Total operating expenses |  | 32,114 |  | 29,710 |  | 30,621 |  |
| Income from operations |  | 3,635 |  | 6,169 |  | 1,029 |  |
| Other income and (expense), net |  | 96 |  | (67 | ) | 54 |  |
| Income before provision for income taxes |  | 3,731 |  | 6,102 |  | 1,083 |  |
| Provision for income taxes |  | 1,380 |  | 1,964 |  | 413 |  |
| Net income |  | $ | 2,351 |  | $ | 4,138 |  | $ | 670 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic |  | $ | 0.07 |  | $ | 0.13 |  | $ | 0.02 |  |
| Diluted |  | $ | 0.07 |  | $ | 0.12 |  | $ | 0.02 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic |  | 33,365 |  | 33,097 |  | 33,184 |  |
| Diluted |  | 34,341 |  | 34,114 |  | 34,098 |  |

[0001104659-12-032048:8k_2_02:41]
Omnicell, Inc.

[0001104659-12-032048:8k_2_02:42]
Condensed Consolidated Balance Sheets

[0001104659-12-032048:8k_2_02:43]
(In thousands)

[0001104659-12-032048:8k_2_02:44]
|  |  | March 31, |  | December 31, |  |
|  |  | 2012 |  | 2011 |  |
|  |  | (unaudited) |  | (1) |  |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 201,420 |  | $ | 191,762 |  |
| Short-term investments |  | 8,117 |  | 8,107 |  |
| Accounts receivable, net |  | 38,973 |  | 38,661 |  |
| Inventories |  | 16,993 |  | 18,107 |  |
| Prepaid expenses |  | 9,904 |  | 10,495 |  |
| Deferred tax assets |  | 10,352 |  | 10,352 |  |
| Other current assets |  | 6,046 |  | 6,107 |  |
| Total current assets |  | 291,805 |  | 283,591 |  |
| Property and equipment, net |  | 17,112 |  | 17,306 |  |
| Non-current net investment in sales-type leases |  | 11,361 |  | 8,785 |  |
| Goodwill |  | 28,543 |  | 28,543 |  |
| Other intangible assets |  | 4,157 |  | 4,231 |  |
| Non-current deferred tax assets |  | 11,801 |  | 11,677 |  |
| Other assets |  | 9,149 |  | 9,716 |  |
| Total assets |  | $ | 373,928 |  | $ | 363,849 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |
| Accounts payable |  | $ | 10,610 |  | $ | 11,000 |  |
| Accrued compensation |  | 7,727 |  | 7,328 |  |
| Accrued liabilities |  | 8,253 |  | 8,901 |  |
| Deferred service revenue |  | 19,835 |  | 19,191 |  |
| Deferred gross profit |  | 15,877 |  | 14,210 |  |
| Total current liabilities |  | 62,302 |  | 60,630 |  |
| Long-term deferred service revenue |  | 19,003 |  | 18,966 |  |
| Other long-term liabilities |  | 1,733 |  | 1,339 |  |
| Total liabilities |  | 83,038 |  | 80,935 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Total stockholders’ equity |  | 290,890 |  | 282,914 |  |
| Total liabilities and stockholders’ equity |  | $ | 373,928 |  | $ | 363,849 |  |

[0001104659-12-032048:8k_2_02:45]
(1)     Information derived from our December 31, 2011 audited consolidated financial statements, with reclassification between Accounts receivable and Accrued liabilities to be consistent with current period presentation.

[0001104659-12-032048:8k_2_02:46]
Omnicell, Inc.

[0001104659-12-032048:8k_2_02:47]
Reconciliation of GAAP to Non-GAAP

[0001104659-12-032048:8k_2_02:48]
(In thousands, except per share data, unaudited)

[0001104659-12-032048:8k_2_02:49]
|  |  | Three months ended |  |
|  |  | March 31, 2012 |  | December 31, 2011 |  | March 31, 2011 |  |
|  |  | Net income |  | Earnings per share- diluted |  | Net income |  | Earnings per share- diluted |  | Net income |  | Earnings (loss) per share-diluted |  |
| GAAP |  | $ | 2,351 |  | $ | 0.07 |  | $ | 4,138 |  | $ | 0.12 |  | $ | 670 |  | $ | 0.02 |  |
| Non-GAAP Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ASC 718 adjustment (a) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross Margin |  | 268 |  |  |  | 290 |  |  |  | 367 |  |  |  |
| Operating Expenses |  | 1,939 |  |  |  | 1,955 |  |  |  | 2,025 |  |  |  |
| Litigation settlement, net of tax (b) |  | — |  |  |  | — |  |  |  | 620 |  |  |  |
| Total after-tax adjustments |  | 2,207 |  | 0.06 |  | 2,245 |  | 0.07 |  | 3,012 |  | 0.09 |  |
| Non-GAAP |  | $ | 4,558 |  | $ | 0.13 |  | $ | 6,383 |  | $ | 0.19 |  | $ | 3,682 |  | $ | 0.11 |  |

[0001104659-12-032048:8k_2_02:50]
(a) This adjustment reflects the accounting impact of non-cash stock-based compensation expense related to the impact of ASC 718 for the periods shown.

[0001104659-12-032048:8k_2_02:51]
(b) This adjustment is for the accrual of a $1.0 million pre-tax settlement in operating expenses, net of tax effect of $0.4 million.

[0001104659-12-032048:8k_2_02:52]
Omnicell, Inc.

[0001104659-12-032048:8k_2_02:53]
Calculation of Adjusted EBITDA (1)

[0001104659-12-032048:8k_2_02:54]
(In thousands, unaudited)

[0001104659-12-032048:8k_2_02:55]
|  |  | Three Months Ended |  |
|  |  | March 31, 2012 |  | December 31, 2011 |  | March 31, 2011 |  |
| GAAP net income |  | $ | 2,351 |  | $ | 4,138 |  | $ | 670 |  |
| Add back: |  |  |  |  |  |  |  |
| ASC 718 stock compensation expense |  | 2,207 |  | 2,245 |  | 2,392 |  |
| Litigation settlement, pre-tax |  | — |  | — |  | 1,000 |  |
| Interest |  | (31 | ) | (21 | ) | (75 | ) |
| Depreciation and amortization expense |  | 2,335 |  | 2,163 |  | 1,852 |  |
| Income tax expense |  | 1,380 |  | 1,964 |  | 413 |  |
| Non-GAAP adjusted EBITDA (1) |  | $ | 8,242 |  | $ | 10,489 |  | 6,252 |  |

[0001104659-12-032048:8k_2_02:56]
(1) Defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including stock compensation expense, per ASC 718.  Also excludes first quarter 2011 non-GAAP adjustment for pre-tax litigation settlement.
