# OMCL MD&A — 0000926326-25-000031


## mdna

[0000926326-25-000031:mdna:1]
[same as prior period, unchanged from 0000926326-25-000019:mdna:1]

[0000926326-25-000031:mdna:2]
[same as prior period, unchanged from 0000926326-25-000019:mdna:2]

[0000926326-25-000031:mdna:3]
[same as prior period, unchanged from 0000926326-25-000019:mdna:4]

[0000926326-25-000031:mdna:4]
[same as prior period, unchanged from 0000926326-25-000019:mdna:5]

[0000926326-25-000031:mdna:5]
[same as prior period, unchanged from 0000926326-25-000019:mdna:6]

[0000926326-25-000031:mdna:6]
[same as prior period, unchanged from 0000926326-25-000019:mdna:7]

[0000926326-25-000031:mdna:7]
[same as prior period, unchanged from 0000926326-25-000019:mdna:8]

[0000926326-25-000031:mdna:8]
[same as prior period, unchanged from 0000926326-25-000019:mdna:9]

[0000926326-25-000031:mdna:9]
[same as prior period, unchanged from 0000926326-25-000019:mdna:10]

[0000926326-25-000031:mdna:10]
[same as prior period, unchanged from 0000926326-25-000019:mdna:11]

[0000926326-25-000031:mdna:11]
[same as prior period, unchanged from 0000926326-25-000019:mdna:12]

[0000926326-25-000031:mdna:12]
[same as prior period, unchanged from 0000926326-25-000019:mdna:13]

[0000926326-25-000031:mdna:13]
[same as prior period, unchanged from 0000926326-25-000019:mdna:14]

[0000926326-25-000031:mdna:14]
[same as prior period, unchanged from 0000926326-25-000019:mdna:15]

[0000926326-25-000031:mdna:15]
[same as prior period, unchanged from 0000926326-25-000019:mdna:16]

[0000926326-25-000031:mdna:16]
[same as prior period, unchanged from 0000926326-25-000019:mdna:17]

[0000926326-25-000031:mdna:17]
•government regulations, legislative changes, fraud and anti-kickback statues, products liability claims, the outcome of legal proceedings, and other legal obligations related to healthcare, privacy, data protection, and information security, and the costs of compliance with, and potential liability associated with, our actual or perceived failure to comply with such obligations;

[0000926326-25-000031:mdna:18]
[same as prior period, unchanged from 0000926326-25-000019:mdna:19]

[0000926326-25-000031:mdna:19]
[same as prior period, unchanged from 0000926326-25-000019:mdna:20]

[0000926326-25-000031:mdna:20]
•covenants in our credit agreement could restrict our business and operations;

[0000926326-25-000031:mdna:21]
[same as prior period, unchanged from 0000926326-25-000019:mdna:22]

[0000926326-25-000031:mdna:22]
[same as prior period, unchanged from 0000926326-25-000019:mdna:23]

[0000926326-25-000031:mdna:23]
[same as prior period, unchanged from 0000926326-25-000019:mdna:24]

[0000926326-25-000031:mdna:24]
[same as prior period, unchanged from 0000926326-25-000019:mdna:25]

[0000926326-25-000031:mdna:25]
[same as prior period, unchanged from 0000926326-25-000019:mdna:26]

[0000926326-25-000031:mdna:26]
[same as prior period, unchanged from 0000926326-25-000019:mdna:27]

[0000926326-25-000031:mdna:27]
[same as prior period, unchanged from 0000926326-25-000019:mdna:28]

[0000926326-25-000031:mdna:28]
[same as prior period, unchanged from 0000926326-25-000019:mdna:29]

[0000926326-25-000031:mdna:29]
[same as prior period, unchanged from 0000926326-25-000019:mdna:30]

[0000926326-25-000031:mdna:30]
[same as prior period, unchanged from 0000926326-25-000019:mdna:31]

[0000926326-25-000031:mdna:31]
[same as prior period, unchanged from 0000926326-25-000019:mdna:32]

[0000926326-25-000031:mdna:32]
[same as prior period, unchanged from 0000926326-25-000019:mdna:33]

[0000926326-25-000031:mdna:33]
[same as prior period, unchanged from 0000926326-25-000019:mdna:34]

[0000926326-25-000031:mdna:34]
[same as prior period, unchanged from 0000926326-25-000019:mdna:35]

[0000926326-25-000031:mdna:35]
Omnicell solutions are helping healthcare facilities worldwide to uncover cost savings, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry-defined vision of the Autonomous Pharmacy. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 90% and 91% of our total revenues for the three months ended September 30, 2025 and 2024, respectively, and 91% of our total revenues for both the nine months ended September 30, 2025 and 2024.

[0000926326-25-000031:mdna:36]
[same as prior period, unchanged from 0000926326-25-000019:mdna:37]

[0000926326-25-000031:mdna:37]
[same as prior period, unchanged from 0000926326-25-000019:mdna:38]

[0000926326-25-000031:mdna:38]
In recent years, the U.S. government has advocated for greater restrictions on trade generally. For example, in 2025, the U.S. imposed tariffs on a wide variety of products manufactured in multiple foreign jurisdictions, including China, Mexico, and Malaysia. In response to the ongoing changes in tariffs, several foreign countries have imposed reciprocal tariffs on goods manufactured in the United States. These tariff rates have fluctuated and may continue to fluctuate going forward. In an effort to address these actions, we have implemented various mitigation measures, including dual-sourcing of components and nearshoring manufacturing. While these actions have effectively mitigated some of the impact of these costs, there can be no assurance that we will be able to offset future increased costs or other adverse impacts. Although we continue to work to mitigate the impact of current or potential tariffs, we may incorrectly anticipate outcomes, forgo or pass up business opportunities, or fail to appropriately adapt or manage our business strategies in response to these changes. As a result of all of these factors, we may experience direct and indirect adverse effects on our business, operating results, cash flow, or financial condition.

[0000926326-25-000031:mdna:39]
[same as prior period, unchanged from 0000926326-25-000019:mdna:40]

[0000926326-25-000031:mdna:40]
[same as prior period, unchanged from 0000926326-25-000019:mdna:41]

[0000926326-25-000031:mdna:41]
[same as prior period, unchanged from 0000926326-25-000019:mdna:42]

[0000926326-25-000031:mdna:42]
[same as prior period, unchanged from 0000926326-25-000019:mdna:43]

[0000926326-25-000031:mdna:43]
[same as prior period, unchanged from 0000926326-25-000019:mdna:44]

[0000926326-25-000031:mdna:44]
[same as prior period, unchanged from 0000926326-25-000019:mdna:45]

[0000926326-25-000031:mdna:45]
We consider revenues generated from our consumables, technical services, and SaaS and Expert Services to be recurring revenues. For the portions of our business which generate recurring revenues, we utilize ARR as a key metric to measure our progress in growing our recurring revenue business. We define ARR at a measurement date as the revenue we expect to receive from our customers over the course of the following year for providing them with products or services. ARR includes expected revenue from all customers who are using our products or services at the reported date. For technical services and SaaS and Expert Services, solutions are generally on a contractual basis, typically with contracts for a period of 12 months or more, with a high probability of renewal. Probability of renewal is based on historic renewal experience of the individual revenue streams or management’s best estimates if historical renewal experience is not available. Consumables orders are placed by customers through our Omnicell Storefront online platform or through written or telephonic orders and are sold to a customer base who utilize the consumable products and place recurring orders when customer inventory is depleted. ARR is generally calculated based on revenues received in the most recent quarter and changes to expected revenues where solutions were added to or removed from the install or customer base in the quarter. Revenues from technical services and SaaS and Expert Services are recorded ratably over the service term. As part of our SaaS and Expert Services offerings, we provide a range of services to our customers including Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions, which typically are provided over two to seven years. In addition, to help ensure the maximum availability of our systems, our customers typically purchase technical services contracts (support and maintenance) in increments of one to five years. Revenue from consumables are recorded when the product has shipped and title has passed. Our measure of ARR may be different than that used by other companies. Because ARR is based on expected future revenue, it does not represent revenue recognized during a particular reporting period or revenue to be recognized in future reporting periods. ARR should not be viewed as a substitute for revenues.

[0000926326-25-000031:mdna:46]
[same as prior period, unchanged from 0000926326-25-000019:mdna:48]

[0000926326-25-000031:mdna:47]
[same as prior period, unchanged from 0000926326-25-000019:mdna:49]

[0000926326-25-000031:mdna:48]
[same as prior period, unchanged from 0000926326-25-000019:mdna:50]

[0000926326-25-000031:mdna:49]
[same as prior period, unchanged from 0000926326-25-000019:mdna:51]

[0000926326-25-000031:mdna:50]
[same as prior period, unchanged from 0000926326-25-000019:mdna:52]

[0000926326-25-000031:mdna:51]
[same as prior period, unchanged from 0000926326-25-000019:mdna:53]

[0000926326-25-000031:mdna:52]
[same as prior period, unchanged from 0000926326-25-000019:mdna:54]

[0000926326-25-000031:mdna:53]
Our full-time employee headcount was approximately 3,600 as of September 30, 2025.

[0000926326-25-000031:mdna:54]
[same as prior period, unchanged from 0000926326-25-000019:mdna:56]

[0000926326-25-000031:mdna:55]
In 2024, the United States spent $806 billion on prescription drugs, a 10.2% increase from 2023. We believe there are significant challenges facing the practice of pharmacy today including, but not limited to, budget constraints, increased healthcare worker turnover rates, labor shortages, drug shortages, drug diversion, manual and error-prone processes, complex compliance requirements, and limited inventory visibility. Each of these challenges may lead to poor medication management outcomes including, but not limited to, medication errors, adverse drug events, lack of patient adherence, and medication waste. We also recognize that these challenges may impact the timing of contracting for, or implementation of, our products, solutions, or services. However, we believe that over time these significant challenges to the practice of pharmacy will drive demand for increased automation, visibility, insights, and improved medication management outcomes that our solutions are designed to enable. Because of this, we believe that our solutions are well-positioned to address the evolving needs of healthcare institutions and therefore present opportunities for long-term growth.

[0000926326-25-000031:mdna:56]
[same as prior period, unchanged from 0000926326-25-000019:mdna:58]

[0000926326-25-000031:mdna:57]
[same as prior period, unchanged from 0000926326-25-000019:mdna:59]

[0000926326-25-000031:mdna:58]
•Central Pharmacy and IV Compounding.  This market represents the beginning of the medication management process in acute care settings, and we believe it is a significant automation opportunity for high volumes of manual, repetitive, and error-prone processes that are often common in pharmacies today. Manual medication dispensing processes are usually labor intensive, error-prone, and may lead to excess medication waste and expirations for our healthcare partners. Automating the central pharmacy dispensing process should enable customers to reallocate pharmacy labor, enhance dispensing accuracy and patient safety, and reduce medication waste and expirations. Likewise, the manual compounding of sterile IV preparations can be error-prone and create significant patient safety risks, and outsourcing sterile IV compounding could lead to increased medication costs and lack of access to needed medications due to an inability to source medications when they are required. As a result, we believe IV automation provides a significant opportunity to enhance patient safety and reduce costs. We anticipate that these technology-enabled services will become more critical as health systems continue to face labor shortages, increased financial pressure, and supply chain disruptions.

[0000926326-25-000031:mdna:59]
[same as prior period, unchanged from 0000926326-25-000019:mdna:61]

[0000926326-25-000031:mdna:60]
[same as prior period, unchanged from 0000926326-25-000019:mdna:62]

[0000926326-25-000031:mdna:61]
[same as prior period, unchanged from 0000926326-25-000019:mdna:63]

[0000926326-25-000031:mdna:62]
[same as prior period, unchanged from 0000926326-25-000019:mdna:64]

[0000926326-25-000031:mdna:63]
[same as prior period, unchanged from 0000926326-25-000019:mdna:65]

[0000926326-25-000031:mdna:64]
[same as prior period, unchanged from 0000926326-25-000019:mdna:66]

[0000926326-25-000031:mdna:65]
[same as prior period, unchanged from 0000926326-25-000019:mdna:67]

[0000926326-25-000031:mdna:66]
[same as prior period, unchanged from 0000926326-25-000019:mdna:68]

[0000926326-25-000031:mdna:67]
[same as prior period, unchanged from 0000926326-25-000019:mdna:69]

[0000926326-25-000031:mdna:68]
There have been no material changes in our critical accounting policies and estimates during the nine months ended September 30, 2025 as compared to those disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in our Annual Report on Form 10-K for the year ended December 31, 2024.

[0000926326-25-000031:mdna:69]
[same as prior period, unchanged from 0000926326-25-000019:mdna:71]

[0000926326-25-000031:mdna:70]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-25-000031:mdna:71]
[same as prior period, unchanged from 0000926326-25-000019:mdna:73]

[0000926326-25-000031:mdna:72]
[same as prior period, unchanged from 0000926326-25-000019:mdna:74]

[0000926326-25-000031:mdna:73]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 177,498 |  |  | $ | 158,361 |  |  | $ | 19,137 |  |  | 12% |
| Percentage of total revenues | 57% |  | 56% |  |  |  |  |
| Service revenues | 133,133 |  |  | 124,059 |  |  | $ | 9,074 |  |  | 7% |
| Percentage of total revenues | 43% |  | 44% |  |  |  |  |
| Total revenues | $ | 310,631 |  |  | $ | 282,420 |  |  | $ | 28,211 |  |  | 10% |

[0000926326-25-000031:mdna:74]
Product revenues represented 57% and 56% of total revenues for the three months ended September 30, 2025 and 2024, respectively. Product revenues increased by $19.1 million, primarily due to the increase in revenues from our XTExtend offering, partially offset by the decrease in revenues from products related to our Central Pharmacy Dispensing Service offering.

[0000926326-25-000031:mdna:75]
Service revenues represented 43% and 44% of total revenues for the three months ended September 30, 2025 and 2024. Service revenues include revenues from technical services and SaaS and Expert Services offerings. Service revenues increased by $9.1 million due to an increase of $7.7 million in technical services revenues primarily as a result of growth in our installed customer base and the impact of pricing actions. The increase is also driven by an increase of $1.4 million in SaaS and Expert Services revenues due to continued customer demand, including an increase in revenues from our Specialty Pharmacy Services offering, partially offset by lower revenues from the EnlivenHealth portfolio.

[0000926326-25-000031:mdna:76]
Our international sales represented 10% and 9% of total revenues for the three months ended September 30, 2025 and 2024, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-25-000031:mdna:77]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 485,838 |  |  | $ | 448,236 |  |  | $ | 37,602 |  |  | 8% |
| Percentage of total revenues | 56% |  | 56% |  |  |  |  |
| Service revenues | 385,023 |  |  | 357,123 |  |  | $ | 27,900 |  |  | 8% |
| Percentage of total revenues | 44% |  | 44% |  |  |  |  |
| Total revenues | $ | 870,861 |  |  | $ | 805,359 |  |  | $ | 65,502 |  |  | 8% |

[0000926326-25-000031:mdna:78]
Product revenues represented 56% of total revenues for both the nine months ended September 30, 2025 and 2024. Product revenues increased by $37.6 million, primarily due to the increase in revenues from our XTExtend offering, partially offset by lower volumes from our XT Series automated dispensing systems business due to the timing of our XT Series systems lifecycle, as we are largely through the replacement cycle, as well as the decrease in revenues from products related to our Central Pharmacy Dispensing Service offering.

[0000926326-25-000031:mdna:79]
Service revenues represented 44% of total revenues for both the nine months ended September 30, 2025 and 2024. Service revenues include revenues from technical services and SaaS and Expert Services offerings. Service revenues increased by $27.9 million due to an increase of $15.0 million in technical services revenues primarily as a result of growth in our installed customer base and the impact of pricing actions. The increase is also driven by an increase of $12.9 million in SaaS and Expert Services revenues due to continued customer demand, including an increase in revenues from our Specialty Pharmacy Services offering, partially offset by lower revenues from the EnlivenHealth portfolio.

[0000926326-25-000031:mdna:80]
Our international sales represented 9% of total revenues for both the nine months ended September 30, 2025 and 2024, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-25-000031:mdna:81]
[same as prior period, unchanged from 0000926326-25-000019:mdna:83]

[0000926326-25-000031:mdna:82]
[same as prior period, unchanged from 0000926326-25-000019:mdna:84]

[0000926326-25-000031:mdna:83]
[same as prior period, unchanged from 0000926326-25-000019:mdna:85]

[0000926326-25-000031:mdna:84]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 96,741 |  |  | $ | 94,448 |  |  | $ | 2,293 |  |  | 2% |
| As a percentage of related revenues | 55% |  | 60% |  |  |  |  |
| Cost of service revenues | 79,387 |  |  | 65,704 |  |  | $ | 13,683 |  |  | 21% |
| As a percentage of related revenues | 60% |  | 53% |  |  |  |  |
| Total cost of revenues | $ | 176,128 |  |  | $ | 160,152 |  |  | $ | 15,976 |  |  | 10% |
| As a percentage of total revenues | 57% |  | 57% |  |  |  |  |
| Gross profit | $ | 134,503 |  |  | $ | 122,268 |  |  | $ | 12,235 |  |  | 10% |
| Gross margin | 43% |  | 43% |  |  |  |  |

[0000926326-25-000031:mdna:85]
Cost of revenues for the three months ended September 30, 2025 compared to the three months ended September 30, 2024 increased by $16.0 million, of which $13.7 million was attributed to the increase in cost of service revenues and $2.3 million was attributed to the increase in cost of product revenues.

[0000926326-25-000031:mdna:86]
The increase in cost of product revenues for the three months ended September 30, 2025 compared to the three months ended September 30, 2024 was driven by an increase in product revenues of $19.1 million for the comparable period. The increase in cost of product revenues has not increased proportionally with the increase in product revenues primarily due to the favorable impact of product and customer mix, partially offset by the impact of tariffs during the three months ended September 30, 2025.

[0000926326-25-000031:mdna:87]
The increase in cost of service revenues was primarily driven by the increase in service revenues of $9.1 million for the three months ended September 30, 2025 compared to the three months ended September 30, 2024, including the associated increase in employee-related expenses, and an increase in certain non-recurring costs, including software upgrade expenses.

[0000926326-25-000031:mdna:88]
The overall gross margin remained relatively consistent for the three months ended September 30, 2025 compared to the three months ended September 30, 2024 primarily due to favorable impact of product and customer mix, partially offset by increases in employee-related and certain non-recurring software upgrade expenses and the impact of tariffs. Our gross profit for the three months ended September 30, 2025 was $134.5 million, as compared to $122.3 million for the three months ended September 30, 2024.

[0000926326-25-000031:mdna:89]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 274,245 |  |  | $ | 286,270 |  |  | $ | (12,025) |  |  | (4)% |
| As a percentage of related revenues | 56% |  | 64% |  |  |  |  |
| Cost of service revenues | 223,499 |  |  | 189,847 |  |  | $ | 33,652 |  |  | 18% |
| As a percentage of related revenues | 58% |  | 53% |  |  |  |  |
| Total cost of revenues | $ | 497,744 |  |  | $ | 476,117 |  |  | $ | 21,627 |  |  | 5% |
| As a percentage of total revenues | 57% |  | 59% |  |  |  |  |
| Gross profit | $ | 373,117 |  |  | $ | 329,242 |  |  | $ | 43,875 |  |  | 13% |
| Gross margin | 43% |  | 41% |  |  |  |  |

[0000926326-25-000031:mdna:90]
36

[0000926326-25-000031:mdna:91]
Cost of revenues for the nine months ended September 30, 2025 compared to the nine months ended September 30, 2024 increased by $21.6 million, primarily driven by a $33.7 million increase in cost of service revenues, partially offset by a $12.0 million decrease in cost of product revenues.

[0000926326-25-000031:mdna:92]
The decrease in cost of product revenues for the nine months ended September 30, 2025 compared to the nine months ended September 30, 2024 was primarily driven by the impact of more favorable materials costs as well as favorable impact from product and customer mix during the nine months ended September 30, 2025 and a decrease of $3.3 million of restructuring costs, partially offset by an increase in product revenues and the impact of tariffs.

[0000926326-25-000031:mdna:93]
The increase in cost of service revenues was primarily driven by the increase in service revenues of $27.9 million for the nine months ended September 30, 2025 compared to the nine months ended September 30, 2024, including the associated increase in employee-related expenses, and an increase in certain non-recurring costs, including software upgrade expenses.

[0000926326-25-000031:mdna:94]
The overall increase in gross margin primarily relates to higher revenues for the nine months ended September 30, 2025 compared to the nine months ended September 30, 2024, as well as a decrease in cost of product revenues for the nine months ended September 30, 2025 primarily due to the impact of more favorable materials costs as well as favorable impact from product and customer mix, partially offset by the impact of tariffs and an increase in employee-related and certain non-recurring software upgrade expenses. Our gross profit for the nine months ended September 30, 2025 was $373.1 million, as compared to $329.2 million for the nine months ended September 30, 2024.

[0000926326-25-000031:mdna:95]
[same as prior period, unchanged from 0000926326-25-000019:mdna:96]

[0000926326-25-000031:mdna:96]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 24,021 |  |  | $ | 21,214 |  |  | $ | 2,807 |  |  | 13% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 102,238 |  |  | 94,490 |  |  | $ | 7,748 |  |  | 8% |
| As a percentage of total revenues | 33% |  | 33% |  |  |  |  |
| Total operating expenses | $ | 126,259 |  |  | $ | 115,704 |  |  | $ | 10,555 |  |  | 9% |
| As a percentage of total revenues | 41% |  | 41% |  |  |  |  |
| Interest and other income (expense), net | $ | 1,459 |  |  | $ | 5,063 |  |  | $ | (3,604) |  |  | (71)% |

[0000926326-25-000031:mdna:97]
Research and Development. Research and development expenses increased by $2.8 million for the three months ended September 30, 2025 compared to the three months ended September 30, 2024.

[0000926326-25-000031:mdna:98]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $7.7 million for the three months ended September 30, 2025 compared to the three months ended September 30, 2024. The increase was primarily due to an increase of $5.2 million in employee-related expenses and an increase of $1.6 million in freight out for the three months ended September 30, 2025 compared to the three months ended September 30, 2024.

[0000926326-25-000031:mdna:99]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $3.6 million for the three months ended September 30, 2025 compared to the three months ended September 30, 2024, primarily driven by a $3.9 million decrease in other income and a $0.3 million decrease in other expense. The decrease in other income during the three months ended September 30, 2025 as compared to the three months ended September 30, 2024 is primarily attributable to lower interest income received due to lower interest rates and lower cash and cash equivalents balances following the partial repurchase of our convertible senior notes in November 2024 and repurchases of our common stock during the second and third quarters of 2025.

[0000926326-25-000031:mdna:100]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 66,120 |  |  | $ | 64,372 |  |  | $ | 1,748 |  |  | 3% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 302,252 |  |  | 276,929 |  |  | $ | 25,323 |  |  | 9% |
| As a percentage of total revenues | 35% |  | 34% |  |  |  |  |
| Total operating expenses | $ | 368,372 |  |  | $ | 341,301 |  |  | $ | 27,071 |  |  | 8% |
| As a percentage of total revenues | 42% |  | 42% |  |  |  |  |
| Interest and other income (expense), net | $ | 5,881 |  |  | $ | 14,052 |  |  | $ | (8,171) |  |  | (58)% |

[0000926326-25-000031:mdna:101]
Research and Development. Research and development expenses increased by $1.7 million for the nine months ended September 30, 2025 compared to the nine months ended September 30, 2024.

[0000926326-25-000031:mdna:102]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $25.3 million for the nine months ended September 30, 2025 compared to the nine months ended September 30, 2024. The increase was primarily due to an increase of $16.5 million in employee-related expenses primarily as a result of higher headcount and annual merit increases, an increase of $2.9 million in the allowance for credit losses, an increase of $2.7 million for legal and regulatory expenses, an increase of $2.4 million in certain restructuring and severance charges, and an increase in commissions of $2.3 million for the nine months ended September 30, 2025 compared to the nine months ended September 30, 2024.

[0000926326-25-000031:mdna:103]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $8.2 million for the nine months ended September 30, 2025 compared to the nine months ended September 30, 2024, primarily driven by a $9.0 million decrease in other income and a $0.8 million decrease in other expense. The decrease in other income during the nine months ended September 30, 2025 as compared to the nine months ended September 30, 2024 is primarily attributable to lower interest income received due to lower interest rates and lower cash and cash equivalents balances following the partial repurchase of our convertible senior notes in November 2024 and repurchases of our common stock during the second and third quarters of 2025.

[0000926326-25-000031:mdna:104]
[same as prior period, unchanged from 0000926326-25-000019:mdna:105]

[0000926326-25-000031:mdna:105]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 4,241 |  |  | $ | 2,997 |  |  | $ | 1,244 |  |  | 42% |

[0000926326-25-000031:mdna:106]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 6,548 |  |  | $ | 5,304 |  |  | $ | 1,244 |  |  | 23% |

[0000926326-25-000031:mdna:107]
For the nine months ended September 30, 2025 and September 30, 2024, we recorded a provision for income taxes of $6.5 million and $5.3 million, respectively, by applying our estimated annual effective tax rate to our year-to-date measure of ordinary income and adjusted for $3.2 million and $4.9 million, respectively, of discrete income tax expense primarily from equity compensation. The change in the provision for income taxes for the nine months ended September 30, 2025 compared to the provision for income taxes for the same period in 2024 was insignificant, consisting of various offsetting components of annual effective tax rate and discrete income tax expense.

[0000926326-25-000031:mdna:108]
[same as prior period, unchanged from 0000926326-25-000019:mdna:109]

[0000926326-25-000031:mdna:109]
[same as prior period, unchanged from 0000926326-25-000019:mdna:110]

[0000926326-25-000031:mdna:110]
We had cash and cash equivalents of $180.1 million at September 30, 2025 compared to $369.2 million at December 31, 2024. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with financial institutions of high credit quality.

[0000926326-25-000031:mdna:111]
Our cash position and working capital at September 30, 2025 and December 31, 2024 were as follows:

[0000926326-25-000031:mdna:112]
|  | September 30,2025 |  | December 31,2024 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 180,053 |  |  | $ | 369,201 |  |
| Working capital | $ | 203,032 |  |  | $ | 219,815 |  |

[0000926326-25-000031:mdna:113]
Our ratio of current assets to current liabilities was 1.4:1 at both September 30, 2025 and December 31, 2024.

[0000926326-25-000031:mdna:114]
[same as prior period, unchanged from 0000926326-25-000019:mdna:115]

[0000926326-25-000031:mdna:115]
Revolving Credit Facility

[0000926326-25-000031:mdna:116]
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023 to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 11, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q), expand our flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-25-000031:mdna:117]
On October 10, 2023, Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-25-000031:mdna:118]
As of September 30, 2025, we had $350.0 million of funds available under the Current Revolving Credit Facility. As of September 30, 2025, there was no outstanding balance under the Current Revolving Credit Facility and we were in full compliance with all covenants.

[0000926326-25-000031:mdna:119]
Refer to Note 10, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-25-000031:mdna:120]
[same as prior period, unchanged from 0000926326-25-000019:mdna:122]

[0000926326-25-000031:mdna:121]
On November 22, 2024, Omnicell, Inc. completed a private offering of $172.5 million aggregate principal amount of 1.00% Convertible Senior Notes due 2029 (the “2029 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $22.5 million aggregate principal amount of the 2029 Notes. Omnicell, Inc. received proceeds from the issuance of the 2029 Notes of $166.3 million, net of $6.2 million of transaction fees and other debt issuance costs. The 2029 Notes bear interest at a rate of 1.00% per year, payable semiannually in arrears on June 1 and December 1 of each year,

[0000926326-25-000031:mdna:122]
beginning on June 1, 2025. The 2029 Notes are general senior, unsecured obligations of Omnicell, Inc. and will mature on December 1, 2029, unless earlier redeemed, repurchased, or converted. In connection with the issuance of the 2029 Notes, in November 2024, we entered into warrant transactions and received aggregate proceeds from the sale of the warrants of approximately $25.2 million. Refer to Note 11, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-25-000031:mdna:123]
[same as prior period, unchanged from 0000926326-25-000019:mdna:124]

[0000926326-25-000031:mdna:124]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, and other contractual obligations. We may also use cash for potential acquisitions and acquisition-related activities, as well as repurchases of our common stock.

[0000926326-25-000031:mdna:125]
During the nine months ended September 30, 2025, we repurchased approximately 2,523,000 shares of our common stock under the 2016 and 2025 Repurchase Programs at an average price of $30.74 per share for an aggregate purchase price of approximately $77.6 million, which completed the 2016 Repurchase Program and substantially completed the 2025 Repurchase Program. Refer to “Stock Repurchase Programs” under Note 16, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-25-000031:mdna:126]
In November 2024, we completed a partial repurchase of $400.0 million aggregate principal amount of the 2025 Notes for approximately $391.0 million in cash. The 2025 Notes matured on September 15, 2025 and we repaid the remaining principal balance of $175.0 million in cash. Refer to Note 11, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-25-000031:mdna:127]
[same as prior period, unchanged from 0000926326-25-000019:mdna:128]

[0000926326-25-000031:mdna:128]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the growth of our business.

[0000926326-25-000031:mdna:129]
[same as prior period, unchanged from 0000926326-25-000019:mdna:130]

[0000926326-25-000031:mdna:130]
[same as prior period, unchanged from 0000926326-25-000019:mdna:131]

[0000926326-25-000031:mdna:131]
|  | Nine Months Ended September 30, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 96,946 |  |  | $ | 131,407 |  |
| Investing activities | (45,943) |  |  | (39,225) |  |
| Financing activities | (227,412) |  |  | (1,148) |  |
| Effect of exchange rate changes on cash and cash equivalents | 3,250 |  |  | 879 |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | (173,159) |  |  | $ | 91,913 |  |

[0000926326-25-000031:mdna:132]
[same as prior period, unchanged from 0000926326-25-000019:mdna:133]

[0000926326-25-000031:mdna:133]
[same as prior period, unchanged from 0000926326-25-000019:mdna:134]

[0000926326-25-000031:mdna:134]
Net cash provided by operating activities was $96.9 million for the nine months ended September 30, 2025, primarily consisting of operating inflows of $105.3 million and unfavorable working capital movements of $8.4 million. Operating inflows consisted of net income of $4.1 million, adjusted for non-cash items of $101.2 million, which consisted primarily of depreciation and amortization expense of $59.0 million and share-based compensation expense of $32.5 million. The unfavorable working capital was primarily due to an increase in inventories of $17.7 million to support production

[0000926326-25-000031:mdna:135]
requirements, including advanced purchases of certain components, as well as the impact of tariffs, a decrease in accrued liabilities of $13.1 million primarily due a decrease in taxes payable, a decrease in accrued compensation of $11.0 million primarily due to a decrease in accrued employee bonuses and commissions, as well as timing of ESPP purchases, an increase in other current assets of $10.0 million, and a decrease in operating lease liabilities of $8.8 million. These cash outflows were partially offset by an increase in deferred revenues of $26.9 million, due to the timing of billings and customers’ installation schedules, a decrease in accounts receivable and unbilled receivables of $12.5 million primarily due to the timing of billings, shipments, and collections, an increase in accounts payable of $10.7 million primarily due to an increase in inventory spend and timing of payments, and a decrease in other long-term assets of $5.9 million.

[0000926326-25-000031:mdna:136]
Net cash provided by operating activities was $131.4 million for the nine months ended September 30, 2024, primarily consisting of operating inflows of $93.8 million and favorable working capital movements of $37.6 million. Operating inflows consisted of a net loss of $3.3 million, adjusted for non-cash items of $97.1 million, which consisted primarily of depreciation and amortization expense of $62.3 million, share-based compensation expense of $30.3 million, inventory write-down charges of $5.4 million, amortization of operating lease right-of-use assets of $5.3 million, and a change in deferred income taxes of $9.4 million. The favorable working capital was primarily due to an increase in deferred revenues of $27.7 million driven by an increase in billings, a decrease in inventories of $10.0 million resulting from inventory management initiatives, a decrease of $8.4 million in other current assets due to a decrease in income tax receivables, and an increase of $7.0 million in accrued liabilities due to an increase in rebate liabilities. These cash inflows were partially offset by a decrease of $8.0 million in operating lease liabilities, an increase of $7.5 million in investment in sales-type leases resulting from growth in our SaaS and Expert Services offerings, and a decrease in accrued compensation of $6.7 million.

[0000926326-25-000031:mdna:137]
[same as prior period, unchanged from 0000926326-25-000019:mdna:137]

[0000926326-25-000031:mdna:138]
Net cash used in investing activities was $45.9 million for the nine months ended September 30, 2025, which consisted of capital expenditures of $32.7 million for property and equipment and $13.2 million for external-use software development costs.

[0000926326-25-000031:mdna:139]
Net cash used in investing activities was $39.2 million for the nine months ended September 30, 2024, which consisted of capital expenditures of $27.4 million for property and equipment and $11.8 million for external-use software development costs.

[0000926326-25-000031:mdna:140]
[same as prior period, unchanged from 0000926326-25-000019:mdna:140]

[0000926326-25-000031:mdna:141]
Net cash used in financing activities was $227.4 million for the nine months ended September 30, 2025, primarily due to the repayment of the remaining principal balance of our 2025 Notes of $175.0 million, repurchases of shares of our common stock of $77.6 million, and $6.0 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $15.2 million in proceeds from employee stock option exercises and ESPP purchases and a net change in the customer funds balances of $16.0 million.

[0000926326-25-000031:mdna:142]
Net cash used in financing activities was $1.1 million for the nine months ended September 30, 2024, primarily due to a net change in the customer funds balances of $10.7 million, partially offset by $13.1 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-25-000031:mdna:143]
[same as prior period, unchanged from 0000926326-25-000019:mdna:143]

[0000926326-25-000031:mdna:144]
There have been no significant changes during the nine months ended September 30, 2025 to the contractual obligations disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2024, other than as described in Note 11, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000926326-25-000031:mdna:145]
Contractual obligations as of September 30, 2025 were as follows:

[0000926326-25-000031:mdna:146]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2025 |  | 2026-2027 |  | 2028-2029 |  | 2030 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 43,556 |  |  | $ | 3,476 |  |  | $ | 25,146 |  |  | $ | 13,041 |  |  | $ | 1,893 |  |
| Purchase obligations (2) | $ | 134,956 |  |  | 82,111 |  |  | 52,822 |  |  | 23 |  |  | — |  |
| Convertible senior notes (3) | $ | 180,268 |  |  | 863 |  |  | 3,450 |  |  | 175,955 |  |  | — |  |
| Total (4) | $ | 358,780 |  |  | $ | 86,450 |  |  | $ | 81,418 |  |  | $ | 189,019 |  |  | $ | 1,893 |  |

[0000926326-25-000031:mdna:147]
[same as prior period, unchanged from 0000926326-25-000019:mdna:147]

[0000926326-25-000031:mdna:148]
[same as prior period, unchanged from 0000926326-25-000019:mdna:148]

[0000926326-25-000031:mdna:149]
[same as prior period, unchanged from 0000926326-25-000019:mdna:149]

[0000926326-25-000031:mdna:150]
(3)We issued the 2029 Notes in November 2024 that are due in December 2029. The obligations presented above include both principal and interest on these notes. Although these notes mature in 2029, they may be converted into cash and shares of our common stock prior to maturity if certain conditions are met. Any conversion prior to maturity can result in repayment of the principal amounts sooner than the scheduled repayment as indicated in the table above. Refer to Note 11, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-25-000031:mdna:151]
(4)Refer to Note 14, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.
