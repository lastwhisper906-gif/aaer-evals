# OMCL 8-K — 0000926326-15-000031 filed 2015-10-29

## item codes, every 8-K on or before 2015-11-06

- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2015-11-06

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-15-000031:8k_2_02:1]
EX-99.1
2
exhibit991q315.htm
EXHIBIT 99.1

[0000926326-15-000031:8k_2_02:2]
Exhibit

[0000926326-15-000031:8k_2_02:3]
Exhibit 99.1

[0000926326-15-000031:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6180 |  | Mountain View, CA 94043 |
| Peter.kuipers@omnicell.com |  |  |

[0000926326-15-000031:8k_2_02:5]
Omnicell Achieves Record Revenue in the Third Quarter 2015

[0000926326-15-000031:8k_2_02:6]
Record revenue of $125.2 million representing 11% year over year growth

[0000926326-15-000031:8k_2_02:7]
Non-GAAP EPS of $0.36 representing 20% year over year growth

[0000926326-15-000031:8k_2_02:8]
MOUNTAIN VIEW, Calif. -- October 29, 2015 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its third quarter ended September 30, 2015.

[0000926326-15-000031:8k_2_02:9]
GAAP results: Revenue for the third quarter of 2015 was $125.2 million, up $12.4 million or 11.0% from the second quarter of 2015, and up $12.7 million or 11.3% from the third quarter of 2014. Revenue for the nine months ended September 30, 2015 was $354.2 million, up $34.9 million or 10.9% from the nine months ended September 30, 2014.

[0000926326-15-000031:8k_2_02:10]
Third quarter 2015 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $8.0 million, or $0.22 per diluted share. This compares to GAAP net income of $8.8 million, or $0.24 per diluted share, for the second quarter of 2015, and GAAP net income of $7.3 million, or $0.20 per diluted share, for the third quarter of 2014.

[0000926326-15-000031:8k_2_02:11]
GAAP net income for the nine months ended September 30, 2015 was $23.1 million, or $0.63 per diluted share, which includes a $3.4 million gain on business combination of an equity investment. GAAP net income was $21.3 million, or $0.58 per diluted share, for the nine months ended September 30, 2014.

[0000926326-15-000031:8k_2_02:12]
Non-GAAP results: Non-GAAP net income for the third quarter of 2015 was $13.2 million, or $0.36 per diluted share, excluding $4.0 million of stock-based compensation expense and $1.2 million, net of tax effect of $0.8 million, of amortization expense for all intangible assets associated with past acquisitions. This compares to non-GAAP net income of $11.1 million, or $0.30 per diluted share, for the third quarter of 2014. Non-GAAP net income for the third quarter of 2014 excluded $3.2 million of stock-based compensation expense and $0.6 million, net of tax effect of $0.5 million, of amortization expense for all intangible assets associated with past acquisitions. Third quarter 2015 results compare to non-GAAP net income of $10.3 million, or $0.28 per diluted share, for the second quarter of 2015. Non-GAAP net income for the second quarter of 2015 excludes $3.6 million of stock-based compensation expense and $1.3 million, net of tax effect of $0.5 million, of amortization expense for all intangible assets associated with past acquisitions. Non-GAAP net income for the second quarter also excludes $3.4 million gain on the Company's 2012 minority equity investment in Avantec Healthcare Limited (“Avantec”), which was recorded as part of Omnicell's acquisition of the remaining 85% of the issued and outstanding ordinary shares of Avantec not already held by Omnicell in April 2015.

[0000926326-15-000031:8k_2_02:13]
Non-GAAP net income for the nine months ended September 30, 2015 was $34.2 million, or $0.93 per diluted share. Non-GAAP net income for the nine months ended September 30, 2015 excludes $11.3 million of stock-based compensation expense and $3.3 million, net of tax effect of $1.7 million of amortization expense for all intangible assets associated with past acquisitions. Non-GAAP net income for the nine months ended September 30, 2015 also excludes a $3.4 million gain on business combination of an equity investment in Avantec. Non-GAAP net income for the nine months ended September 30, 2014 was $31.9 million, or $0.87 per diluted share, excluding $8.6 million of stock-based compensation expense and $2.0 million, net of tax effect of $1.3 million of amortization expense for all intangible assets associated with our business acquisitions.

[0000926326-15-000031:8k_2_02:14]
“I am pleased to report record quarter revenues and strong earnings growth in the third quarter,” said Randall Lipps, Omnicell president, chairman and CEO. “The fundamentals of our business have not changed and we continue to close a solid mix of competitive wins and our existing customers continue to expand their implementations. Driven by our three-leg growth strategy of differentiated products, expansion into new markets and targeted acquisitions, the company has all the ingredients for continued success.”

[0000926326-15-000031:8k_2_02:15]
Reporting Segments

[0000926326-15-000031:8k_2_02:16]
As reported last quarter, beginning the first quarter of 2015, Omnicell enhanced the management of its business, operating structure and segment reporting structure by excluding certain corporate-level costs from our reporting segments based on how the Chief Operating Decision Maker (“CODM”) reviews the business. Corporate-level costs may include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses. Omnicell's CODM allocates resources and evaluates the performance of our segments using information about its revenues, gross profit and income from operations, excluding certain costs which are managed separately at the corporate level.

[0000926326-15-000031:8k_2_02:17]
Omnicell Conference Call Information

[0000926326-15-000031:8k_2_02:18]
Omnicell will hold a conference call today, Thursday, October 29, 2015 at 2:30 p.m. PT to discuss third quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 66699013. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 5:30 p.m. PT and will be available until 11:59 p.m. PT on November 12, 2015. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 66699013.

[0000926326-15-000031:8k_2_02:19]
2

[0000926326-15-000031:8k_2_02:20]
About Omnicell

[0000926326-15-000031:8k_2_02:21]
Since 1992, Omnicell (NASDAQ: OMCL) has been creating new efficiencies to improve patient care, anywhere it is delivered. Omnicell is a leading supplier of comprehensive automation and business analytics software for patient-centric medication and supply management across the entire health care continuum from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home.

[0000926326-15-000031:8k_2_02:22]
More than 3,000 customers worldwide have utilized Omnicell Automation and Analytics solutions to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety. Omnicell Medication Adherence solutions, including its MTS Medication Technologies brand, provide innovative medication adherence packaging solutions to help reduce costly hospital readmissions. In addition, these solutions enable approximately 7,000 institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-15-000031:8k_2_02:23]
For more information about Omnicell, please visit www.omnicell.com.

[0000926326-15-000031:8k_2_02:24]
Forward-Looking Statements

[0000926326-15-000031:8k_2_02:25]
Use of Non-GAAP Financial Information

[0000926326-15-000031:8k_2_02:26]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-15-000031:8k_2_02:27]
Our non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-15-000031:8k_2_02:28]
a)  Stock-based compensation expense impact of Accounting Standards Codification (ASC) 718. We recognize equity plan-related compensation expenses, which represent the fair value of all share-based payments to employees, including grants of employee stock options, as required under ASC 718, Compensation - Stock Compensation (ASC 718) as non-GAAP adjustments in each period.

[0000926326-15-000031:8k_2_02:29]
b)  Intangible assets amortization from business acquisitions. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-15-000031:8k_2_02:30]
c)  Gain on business combination of an equity investment. We excluded from our non-GAAP results the gain on a minority equity investment in a private company, Avantec, which was recognized in relation to the acquisition by Omnicell of the remainder of the company. This non-cash gain is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-15-000031:8k_2_02:31]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock option grants.

[0000926326-15-000031:8k_2_02:32]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-15-000031:8k_2_02:33]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0000926326-15-000031:8k_2_02:34]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0000926326-15-000031:8k_2_02:35]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0000926326-15-000031:8k_2_02:36]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-15-000031:8k_2_02:37]
Set forth below are additional reasons why share-based compensation expense related to ASC 718 is excluded from our non-GAAP financial measures:

[0000926326-15-000031:8k_2_02:38]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-15-000031:8k_2_02:39]
ii)  We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-15-000031:8k_2_02:40]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as excluding certain non-GAAP adjustments.

[0000926326-15-000031:8k_2_02:41]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-15-000031:8k_2_02:42]
·  Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-15-000031:8k_2_02:43]
·  Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-15-000031:8k_2_02:44]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-15-000031:8k_2_02:45]
Omnicell, Inc.

[0000926326-15-000031:8k_2_02:46]
Condensed Consolidated Statements of Operations

[0000926326-15-000031:8k_2_02:47]
(Unaudited, in thousands, except per share data)

[0000926326-15-000031:8k_2_02:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2015 |  | June 30, 2015 |  | September 30, 2014 |  | September 30, 2015 |  | September 30, 2014 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product | $ | 100,941 |  |  | $ | 89,154 |  |  | $ | 92,229 |  |  | $ | 284,204 |  |  | $ | 260,053 |  |
| Services and other revenues | 24,293 |  |  | 23,634 |  |  | 20,314 |  |  | 70,039 |  |  | 59,306 |  |
| Total revenues | 125,234 |  |  | 112,788 |  |  | 112,543 |  |  | 354,243 |  |  | 319,359 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 51,700 |  |  | 46,203 |  |  | 44,510 |  |  | 143,319 |  |  | 124,413 |  |
| Cost of services and other revenues | 9,831 |  |  | 9,123 |  |  | 8,487 |  |  | 28,074 |  |  | 24,865 |  |
| Total cost of revenues | 61,531 |  |  | 55,326 |  |  | 52,997 |  |  | 171,393 |  |  | 149,278 |  |
| Gross profit | 63,703 |  |  | 57,462 |  |  | 59,546 |  |  | 182,850 |  |  | 170,081 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 9,176 |  |  | 8,746 |  |  | 7,078 |  |  | 25,941 |  |  | 19,670 |  |
| Selling, general and administrative | 40,668 |  |  | 39,735 |  |  | 38,871 |  |  | 123,690 |  |  | 114,302 |  |
| Gain on business combination | — |  |  | (3,443 | ) |  | — |  |  | (3,443 | ) |  | — |  |
| Total operating expenses | 49,844 |  |  | 45,038 |  |  | 45,949 |  |  | 146,188 |  |  | 133,972 |  |
| Income from operations | 13,859 |  |  | 12,424 |  |  | 13,597 |  |  | 36,662 |  |  | 36,109 |  |
| Interest and other income (expense), net | (646 | ) |  | (472 | ) |  | (706 | ) |  | (1,635 | ) |  | (1,003 | ) |
| Income before provision for income taxes | 13,213 |  |  | 11,952 |  |  | 12,891 |  |  | 35,027 |  |  | 35,106 |  |
| Provision for income taxes | 5,177 |  |  | 3,201 |  |  | 5,591 |  |  | 11,922 |  |  | 13,824 |  |
| Net income | $ | 8,036 |  |  | $ | 8,751 |  |  | $ | 7,300 |  |  | $ | 23,105 |  |  | $ | 21,282 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.22 |  |  | $ | 0.24 |  |  | $ | 0.20 |  |  | $ | 0.64 |  |  | $ | 0.60 |  |
| Diluted | $ | 0.22 |  |  | $ | 0.24 |  |  | $ | 0.20 |  |  | $ | 0.63 |  |  | $ | 0.58 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic | 35,806 |  |  | 36,120 |  |  | 35,994 |  |  | 35,983 |  |  | 35,634 |  |
| Diluted | 36,613 |  |  | 37,030 |  |  | 36,832 |  |  | 36,870 |  |  | 36,617 |  |

[0000926326-15-000031:8k_2_02:49]
6

[0000926326-15-000031:8k_2_02:50]
Omnicell, Inc.

[0000926326-15-000031:8k_2_02:51]
Condensed Consolidated Balance Sheets

[0000926326-15-000031:8k_2_02:52]
(Unaudited, in thousands)

[0000926326-15-000031:8k_2_02:53]
|  | September 30, 2015 |  | December 31, 2014 |
| ASSETS |
| Current assets: |  |  |  |  |
| Cash and cash equivalents | $ | 57,757 |  |  | $ | 125,888 |  |
| Accounts receivable, net | 115,680 |  |  | 82,763 |  |
| Inventories | 49,460 |  |  | 31,554 |  |
| Prepaid expenses | 17,698 |  |  | 23,518 |  |
| Deferred tax assets | 12,489 |  |  | 12,446 |  |
| Other current assets | 6,802 |  |  | 7,215 |  |
| Total current assets | 259,886 |  |  | 283,384 |  |
| Property and equipment, net | 34,026 |  |  | 36,178 |  |
| Long-term net investment in sales-type leases | 13,557 |  |  | 10,848 |  |
| Goodwill | 148,727 |  |  | 122,720 |  |
| Intangible assets, net | 92,042 |  |  | 82,667 |  |
| Long-term deferred tax assets | 1,513 |  |  | 1,144 |  |
| Other long-term assets | 26,971 |  |  | 23,273 |  |
| Total assets | $ | 576,722 |  |  | $ | 560,214 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |
| Accounts payable | $ | 24,691 |  |  | $ | 19,432 |  |
| Accrued compensation | 15,224 |  |  | 19,874 |  |
| Accrued liabilities | 29,382 |  |  | 19,299 |  |
| Deferred service revenue | 26,168 |  |  | 25,167 |  |
| Deferred gross profit | 27,179 |  |  | 28,558 |  |
| Total current liabilities | 122,644 |  |  | 112,330 |  |
| Deferred service revenue, long-term | 18,436 |  |  | 20,308 |  |
| Long-term deferred tax liabilities | 32,320 |  |  | 30,454 |  |
| Other long-term liabilities | 11,782 |  |  | 7,024 |  |
| Total liabilities | 185,182 |  |  | 170,116 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Total stockholders’ equity | 391,540 |  |  | 390,098 |  |
| Total liabilities and stockholders’ equity | $ | 576,722 |  |  | $ | 560,214 |  |

[0000926326-15-000031:8k_2_02:54]
Omnicell, Inc.

[0000926326-15-000031:8k_2_02:55]
Condensed Consolidated Statements of Cash Flows

[0000926326-15-000031:8k_2_02:56]
(Unaudited, in thousands)

[0000926326-15-000031:8k_2_02:57]
|  | Nine months ended September 30, |
|  | 2015 |  | 2014 |
| Operating Activities |  |  |  |
| Net income | $ | 23,105 |  |  | $ | 21,282 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 18,457 |  |  | 14,705 |  |
| Gain on disposal of fixed assets | 114 |  |  | 221 |  |
| Gain on business combination | (3,443 | ) |  | — |  |
| Provision for receivable allowance | 542 |  |  | 850 |  |
| Share-based compensation expense | 11,267 |  |  | 8,610 |  |
| Income tax benefits from employee stock plans | 3,838 |  |  | 4,065 |  |
| Excess tax benefits from employee stock plans | (3,942 | ) |  | (4,456 | ) |
| Provision for excess and obsolete inventories | 317 |  |  | 450 |  |
| Deferred income taxes | (2,235 | ) |  | 1,307 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (26,132 | ) |  | (35,028 | ) |
| Inventories | (13,215 | ) |  | 1,301 |  |
| Prepaid expenses | 5,937 |  |  | 1,015 |  |
| Other current assets | 1,019 |  |  | 1,412 |  |
| Net investment in sales-type leases | (3,220 | ) |  | 677 |  |
| Other long-term assets | 247 |  |  | 360 |  |
| Accounts payable | (127 | ) |  | 5,420 |  |
| Accrued compensation | (5,003 | ) |  | (6,533 | ) |
| Accrued liabilities | 4,608 |  |  | (416 | ) |
| Deferred service revenue | (4,199 | ) |  | 2,650 |  |
| Deferred gross profit | (1,170 | ) |  | 15,585 |  |
| Other long-term liabilities | (833 | ) |  | 838 |  |
| Net cash provided by operating activities | 5,932 |  |  | 34,315 |  |
| Investing Activities |  |  |  |
| Acquisition of intangible assets, intellectual property and patents | (331 | ) |  | (236 | ) |
| Software development for external use | (9,445 | ) |  | (7,925 | ) |
| Purchases of property and equipment | (6,081 | ) |  | (10,151 | ) |
| Business acquisition, net of cash acquired | (25,455 | ) |  | (19,749 | ) |
| Net cash used in investing activities | (41,312 | ) |  | (38,061 | ) |
| Financing Activities |  |  |  |
| Proceeds from issuances under stock-based compensation plans | 15,665 |  |  | 18,157 |  |
| Employees' taxes paid related to restricted stock units | (2,285 | ) |  | (2,023 | ) |
| Common stock repurchases | (50,021 | ) |  | (17,052 | ) |
| Excess tax benefits from employee stock plans | 3,942 |  |  | 4,456 |  |
| Net cash (used) provided by financing activities | (32,699 | ) |  | 3,538 |  |
| Effect of exchange rate changes on cash and cash equivalents | (52 | ) |  | (136 | ) |
| Net decrease in cash and cash equivalents | (68,131 | ) |  | (344 | ) |
| Cash and cash equivalents at beginning of period | 125,888 |  |  | 104,531 |  |
| Cash and cash equivalents at end of period | $ | 57,757 |  |  | $ | 104,187 |  |

[0000926326-15-000031:8k_2_02:58]
8

[0000926326-15-000031:8k_2_02:59]
Omnicell, Inc.

[0000926326-15-000031:8k_2_02:60]
Reconciliation of GAAP to Non-GAAP

[0000926326-15-000031:8k_2_02:61]
(Unaudited, in thousands, except per share data)

[0000926326-15-000031:8k_2_02:62]
|  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  |  | September 30, 2015 |  | June 30, 2015 |  | September 30, 2014 |  | September 30, 2015 |  | September 30, 2014 |
| Reconciliation of GAAP net income to non-GAAP net income: |  |  |  |  |  |  |
| GAAP net income | $ | 8,036 |  |  | $ | 8,751 |  |  | $ | 7,300 |  |  | $ | 23,105 |  |  | $ | 21,282 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
|  | Share-based compensation expense: |  |  |  |  |  |  |  |  |  |
|  |  | Cost of revenues | 581 |  |  | 532 |  |  | 441 |  |  | 1,630 |  |  | 973 |  |
|  |  | Operating expenses | 3,385 |  |  | 3,104 |  |  | 2,720 |  |  | 9,637 |  |  | 7,637 |  |
|  |  | Total share-based compensation expense (a) | 3,966 |  |  | 3,636 |  |  | 3,161 |  |  | 11,267 |  |  | 8,610 |  |
|  | Amortization of acquired intangibles: |  |  |  |  |  |  |  |  |  |
|  |  | Cost of revenues | 570 |  |  | 531 |  |  | 368 |  |  | 1,469 |  |  | 1,104 |  |
|  |  | Operating expenses | 1,408 |  |  | 1,279 |  |  | 778 |  |  | 3,550 |  |  | 2,138 |  |
|  |  | Total Amortization of acquired intangibles: | 1,978 |  |  | 1,810 |  |  | 1,146 |  |  | 5,019 |  |  | 3,242 |  |
|  | Income tax effect of non-GAAP adjustments (b) | (775 | ) |  | (485 | ) |  | (497 | ) |  | (1,703 | ) |  | (1,271 | ) |
|  |  | Total Amortization of acquired intangibles, net: | 1,203 |  |  | 1,325 |  |  | 649 |  |  | 3,316 |  |  | 1,971 |  |
|  | Gain on business combination | — |  |  | (3,443 | ) |  | — |  |  | (3,443 | ) |  | — |  |
| Non-GAAP net income | $ | 13,205 |  |  | $ | 10,269 |  |  | $ | 11,110 |  |  | $ | 34,245 |  |  | $ | 31,863 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |
|  | Revenues |  | $ | 125,234 |  |  | $ | 112,788 |  |  | $ | 112,543 |  |  | $ | 354,243 |  |  | $ | 319,359 |  |
|  | GAAP gross profit | 63,703 |  |  | 57,462 |  |  | 59,546 |  |  | 182,850 |  |  | 170,081 |  |
|  | GAAP gross margin | 50.9% |  | 50.9% |  | 52.9% |  | 51.6% |  | 53.3% |
|  |  | Share-based compensation expense | 581 |  |  | 532 |  |  | 441 |  |  | 1,630 |  |  | 973 |  |
|  |  | Amortization of acquired intangibles | 570 |  |  | 531 |  |  | 368 |  |  | 1,469 |  |  | 1,104 |  |
|  | Non-GAAP gross profit | $ | 64,854 |  |  | $ | 58,525 |  |  | $ | 60,355 |  |  | $ | 185,949 |  |  | $ | 172,158 |  |
|  | Non-GAAP gross margin | 51.8% |  | 51.9% |  | 53.6% |  | 52.5% |  | 53.9% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 49,844 |  |  | $ | 45,038 |  |  | $ | 45,949 |  |  | $ | 146,188 |  |  | $ | 133,972 |  |
|  | GAAP operating expenses % to total revenue | 39.8% |  | 39.9% |  | 40.8% |  | 41.3% |  | 42.0% |
|  | Share-based compensation expense | (3,385 | ) |  | (3,104 | ) |  | (2,720 | ) |  | (9,637 | ) |  | (7,637 | ) |
|  | Amortization of acquired intangibles | (1,408 | ) |  | (1,279 | ) |  | (778 | ) |  | (3,550 | ) |  | (2,138 | ) |
|  | Gain on business combination | — |  |  | 3,443 |  |  | — |  |  | 3,443 |  |  | — |  |
| Non-GAAP operating expenses | $ | 45,051 |  |  | $ | 44,098 |  |  | $ | 42,451 |  |  | $ | 136,444 |  |  | $ | 124,197 |  |
|  | Non-GAAP operating expenses % to total revenue | 36.0% |  | 39.1% |  | 37.7% |  | 38.5% |  | 38.9% |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |  |  |  |  |
| GAAP income from operations | $ | 13,859 |  |  | $ | 12,424 |  |  | $ | 13,597 |  |  | $ | 36,662 |  |  | $ | 36,109 |  |
|  | GAAP operating income % to total revenue | 11.1% |  | 11.0% |  | 12.1% |  | 10.3% |  | 11.3% |
|  | Share-based compensation expense | 3,966 |  |  | 3,636 |  |  | 3,161 |  |  | 11,267 |  |  | 8,610 |  |
|  | Amortization of acquired intangibles | 1,978 |  |  | 1,810 |  |  | 1,146 |  |  | 5,019 |  |  | 3,242 |  |
|  | Gain on business combination | — |  |  | (3,443 | ) |  | — |  |  | (3,443 | ) |  | — |  |
| Non-GAAP income from operations | $ | 19,803 |  |  | $ | 14,427 |  |  | $ | 17,904 |  |  | $ | 49,505 |  |  | $ | 47,961 |  |
|  | Non-GAAP operating income % to total revenue | 15.8% |  | 12.8% |  | 15.9% |  | 14.0% |  | 15.0% |

[0000926326-15-000031:8k_2_02:63]
|  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  |  | September 30, 2015 |  | June 30, 2015 |  | September 30, 2014 |  | September 30, 2015 |  | September 30, 2014 |
| GAAP shares - diluted | 36,613 |  |  | 37,030 |  |  | 36,832 |  |  | 36,870 |  |  | 36,617 |  |
| GAAP net income per share - diluted | $ | 0.22 |  |  | $ | 0.24 |  |  | $ | 0.20 |  |  | $ | 0.63 |  |  | $ | 0.58 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
|  | Share-based compensation expense | 0.11 |  |  | 0.10 |  |  | 0.08 |  |  | 0.31 |  |  | 0.24 |  |
|  | Amortization of acquired intangibles | 0.03 |  |  | 0.04 |  |  | 0.02 |  |  | 0.09 |  |  | 0.05 |  |
|  | Gain on business combination | — |  |  | (0.10 | ) |  | — |  |  | (0.10 | ) |  | — |  |
| Non-GAAP net income per share - diluted | $ | 0.36 |  |  | $ | 0.28 |  |  | $ | 0.30 |  |  | $ | 0.93 |  |  | $ | 0.87 |  |
| Reconciliation of GAAP EBITDA to non-GAAP EBITDA: |  |  |  |  |  |  |
| GAAP net income | $ | 8,036 |  |  | $ | 8,751 |  |  | $ | 7,300 |  |  | $ | 23,105 |  |  | $ | 21,282 |  |
| Add back: |  |  |  |  |  |  |  |  |  |
|  | Share-based compensation expense | 3,966 |  |  | 3,636 |  |  | 3,161 |  |  | 11,267 |  |  | 8,610 |  |
|  | Interest (income) and expense, net | 138 |  |  | 84 |  |  | 55 |  |  | 321 |  |  | 20 |  |
|  | Depreciation and amortization expense | 6,482 |  |  | 6,264 |  |  | 5,314 |  |  | 18,457 |  |  | 14,705 |  |
|  | Income tax expense | 5,177 |  |  | 3,201 |  |  | 5,591 |  |  | 11,922 |  |  | 13,824 |  |
|  | Gain on business combination | — |  |  | (3,443 | ) |  | — |  |  | (3,443 | ) |  | — |  |
| Non-GAAP adjusted EBITDA (c) | $ | 23,799 |  |  | $ | 18,493 |  |  | $ | 21,421 |  |  | $ | 61,629 |  |  | $ | 58,441 |  |

[0000926326-15-000031:8k_2_02:64]
____________________________________________

[0000926326-15-000031:8k_2_02:65]
| (a) | This adjustment reflects the accounting impact of non-cash stock-based compensation expense for the periods presented. |

[0000926326-15-000031:8k_2_02:66]
| (b) | Tax effects are calculated using the effective tax rates for the respective periods presented. |

[0000926326-15-000031:8k_2_02:67]
| (c) | Defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including stock compensation expense, per ASC 718, as well as excluding certain non-GAAP adjustments. |

[0000926326-15-000031:8k_2_02:68]
10

[0000926326-15-000031:8k_2_02:69]
Omnicell, Inc.

[0000926326-15-000031:8k_2_02:70]
Segmented Information

[0000926326-15-000031:8k_2_02:71]
(Unaudited, in thousands, except for percentages)

[0000926326-15-000031:8k_2_02:72]
|  | Three Months Ended September 30, 2015 |  | Three Months Ended September 30, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 102,967 |  |  | $ | 22,267 |  |  | $ | 125,234 |  |  | $ | 89,547 |  |  | $ | 22,996 |  |  | $ | 112,543 |  |
| Cost of revenues | 45,668 |  |  | 15,863 |  |  | 61,531 |  |  | 38,412 |  |  | 14,585 |  |  | 52,997 |  |
| Gross profit | 57,299 |  |  | 6,404 |  |  | 63,703 |  |  | 51,135 |  |  | 8,411 |  |  | 59,546 |  |
| Gross margin % | 55.6% |  | 28.8% |  | 50.9% |  | 57.1% |  | 36.6% |  | 52.9% |
| Operating expenses | 30,628 |  |  | 6,070 |  |  | 36,698 |  |  | 27,420 |  |  | 4,822 |  |  | 32,242 |  |
| Income from segment operations | $ | 26,671 |  |  | $ | 334 |  |  | 27,005 |  |  | $ | 23,715 |  |  | $ | 3,589 |  |  | 27,304 |  |
| Operating margin % | 25.9% |  | 1.5% |  | 21.6% |  | 26.5% |  | 15.6% |  | 24.3% |
| Corporate costs |  |  |  |  | 13,146 |  |  |  |  |  |  | 13,707 |  |
| Income from operations |  |  |  |  | $ | 13,859 |  |  |  |  |  |  | $ | 13,597 |  |

[0000926326-15-000031:8k_2_02:73]
11

[0000926326-15-000031:8k_2_02:74]
Omnicell, Inc.

[0000926326-15-000031:8k_2_02:75]
Segmented Information

[0000926326-15-000031:8k_2_02:76]
(Unaudited, in thousands, except for percentages)

[0000926326-15-000031:8k_2_02:77]
|  | Nine Months Ended September 30, 2015 |  | Nine Months Ended September 30, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 284,447 |  |  | $ | 69,796 |  |  | $ | 354,243 |  |  | $ | 255,748 |  |  | $ | 63,611 |  |  | $ | 319,359 |  |
| Cost of revenues | 123,923 |  |  | 47,470 |  |  | 171,393 |  |  | 109,344 |  |  | 39,934 |  |  | 149,278 |  |
| Gross profit | 160,524 |  |  | 22,326 |  |  | 182,850 |  |  | 146,404 |  |  | 23,677 |  |  | 170,081 |  |
| Gross margin % | 56.4% |  | 32.0% |  | 51.6% |  | 57.2% |  | 37.2% |  | 53.3% |
| Operating expenses | 85,195 |  |  | 18,321 |  |  | 103,516 |  |  | 78,566 |  |  | 14,273 |  |  | 92,839 |  |
| Income from segment operations | $ | 75,329 |  |  | $ | 4,005 |  |  | 79,334 |  |  | $ | 67,838 |  |  | $ | 9,404 |  |  | 77,242 |  |
| Operating margin % | 26.5% |  | 5.7% |  | 22.4% |  | 26.5% |  | 14.8% |  | 24.2% |
| Corporate costs |  |  |  |  | 42,672 |  |  |  |  |  |  | 41,133 |  |
| Income from operations |  |  |  |  | $ | 36,662 |  |  |  |  |  |  | $ | 36,109 |  |

[0000926326-15-000031:8k_2_02:78]
Omnicell, Inc.

[0000926326-15-000031:8k_2_02:79]
Segment Information - Non-GAAP Gross Margin and Non-GAAP Operating Margin

[0000926326-15-000031:8k_2_02:80]
(Unaudited, in thousands, except for percentages)

[0000926326-15-000031:8k_2_02:81]
|  | Three Months Ended September 30, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 102,967 |  |  |  |  | $ | 22,267 |  |  |  |  | $ | 125,234 |  |  |  |
| GAAP Gross profit | $ | 57,299 |  |  | 55.6% |  | $ | 6,404 |  |  | 28.8% |  | $ | 63,703 |  |  | 50.9% |
| Plus: |  |  |  |  |  |  |  |  |  |  |  |
| a) Stock-based compensation expense | 403 |  |  | 0.4% |  | $ | 178 |  |  | 0.8% |  | 581 |  |  | 0.5% |
| b) Amortization expense of acquired intangible assets and other acquisition-related expenses | 238 |  |  | 0.2% |  | $ | 332 |  |  | 1.5% |  | 570 |  |  | 0.5% |
| Non-GAAP Gross profit | $ | 57,940 |  |  | 56.3% |  | $ | 6,914 |  |  | 31.1% |  | $ | 64,854 |  |  | 51.8% |
| GAAP Operating income | $ | 26,671 |  |  | 25.9% |  | $ | 334 |  |  | 1.5% |  | $ | 27,005 |  |  | 21.6% |
| Plus: |  |  |  |  |  |  |  |  |  |  |  |
| a) Stock-based compensation expense | 1,572 |  |  | 1.5% |  | 303 |  |  | 1.4% |  | 1,875 |  |  | 1.5% |
| b) Amortization expense of acquired intangible assets and other acquisition-related expenses | 902 |  |  | 0.9% |  | 1,076 |  |  | 4.8% |  | 1,978 |  |  | 1.6% |
| Non-GAAP Operating income | $ | 29,145 |  |  | 28.3% |  | $ | 1,713 |  |  | 7.7% |  | $ | 30,858 |  |  | 24.6% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 13,146 |  |  | 10.5% |
| Less: Stock-based compensation expense |  |  |  |  |  |  |  |  | 2,091 |  |  | 1.7% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 11,055 |  |  | 8.8% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  | $ | 19,803 |  |  | 15.8% |

[0000926326-15-000031:8k_2_02:82]
13

[0000926326-15-000031:8k_2_02:83]
|  | Three Months Ended September 30, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 89,547 |  |  |  |  | $ | 22,996 |  |  |  |  | $ | 112,543 |  |  |  |
| GAAP Gross profit | $ | 51,135 |  |  | 57.1% |  | $ | 8,411 |  |  | 36.6% |  | $ | 59,546 |  |  | 52.9% |
| Plus: |  |  |  |  |  |  |  |  |  |  |  |
| a) Stock-based compensation expense | 255 |  |  | 0.3% |  | $ | 59 |  |  | 0.3% |  | 314 |  |  | 0.3% |
| b) Amortization expense of acquired intangible assets and other acquisition-related expenses | 35 |  |  | 0.0% |  | $ | 333 |  |  | 1.4% |  | 368 |  |  | 0.3% |
| Non-GAAP Gross profit | $ | 51,425 |  |  | 57.4% |  | $ | 8,803 |  |  | 38.3% |  | $ | 60,228 |  |  | 53.5% |
| GAAP Operating income | $ | 23,715 |  |  | 26.5% |  | $ | 3,589 |  |  | 15.6% |  | $ | 27,304 |  |  | 24.3% |
| Plus: |  |  |  |  |  |  |  |  |  |  |  |
| a) Stock-based compensation expense | 1,306 |  |  | 1.5% |  | 158 |  |  | 0.7% |  | 1,464 |  |  | 1.3% |
| b) Amortization expense of acquired intangible assets and other acquisition-related expenses | 147 |  |  | 0.2% |  | 999 |  |  | 4.3% |  | 1,146 |  |  | 1.0% |
| Non-GAAP Operating income | $ | 25,168 |  |  | 28.1% |  | $ | 4,746 |  |  | 20.6% |  | $ | 29,914 |  |  | 26.6% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 13,707 |  |  | 12.2% |
| Less: Stock-based compensation expense |  |  |  |  |  |  |  |  | 1,697 |  |  | 1.5% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 12,010 |  |  | 10.7% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  | $ | 17,904 |  |  | 15.9% |

[0000926326-15-000031:8k_2_02:84]
14
