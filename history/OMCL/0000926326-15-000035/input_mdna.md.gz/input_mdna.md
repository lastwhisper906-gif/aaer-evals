# OMCL MD&A — 0000926326-15-000035


## mdna

[0000926326-15-000035:mdna:1]
[same as prior period, unchanged from 0000926326-15-000028:mdna:1]

[0000926326-15-000035:mdna:2]
[same as prior period, unchanged from 0000926326-15-000028:mdna:2]

[0000926326-15-000035:mdna:3]
[same as prior period, unchanged from 0000926326-15-000028:mdna:3]

[0000926326-15-000035:mdna:4]
[same as prior period, unchanged from 0000926326-15-000028:mdna:4]

[0000926326-15-000035:mdna:5]
[same as prior period, unchanged from 0000926326-15-000028:mdna:5]

[0000926326-15-000035:mdna:6]
[same as prior period, unchanged from 0000926326-15-000028:mdna:6]

[0000926326-15-000035:mdna:7]
[same as prior period, unchanged from 0000926326-15-000028:mdna:7]

[0000926326-15-000035:mdna:8]
[same as prior period, unchanged from 0000926326-15-000028:mdna:8]

[0000926326-15-000035:mdna:9]
[same as prior period, unchanged from 0000926326-15-000028:mdna:9]

[0000926326-15-000035:mdna:10]
[same as prior period, unchanged from 0000926326-15-000028:mdna:10]

[0000926326-15-000035:mdna:11]
[same as prior period, unchanged from 0000926326-15-000028:mdna:11]

[0000926326-15-000035:mdna:12]
[same as prior period, unchanged from 0000926326-15-000028:mdna:12]

[0000926326-15-000035:mdna:13]
[same as prior period, unchanged from 0000926326-15-000028:mdna:13]

[0000926326-15-000035:mdna:14]
[same as prior period, unchanged from 0000926326-15-000028:mdna:14]

[0000926326-15-000035:mdna:15]
[same as prior period, unchanged from 0000926326-15-000028:mdna:15]

[0000926326-15-000035:mdna:16]
[same as prior period, unchanged from 0000926326-15-000028:mdna:16]

[0000926326-15-000035:mdna:17]
Omnicell Medication Adherence solutions, including the MTS, SureMed and Surgichem brands, provide innovative medication adherence packaging solutions that can help reduce costly hospital readmissions and enable institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-15-000035:mdna:18]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 83% and 84% of our total revenues for the three and nine months ended September 30, 2015, respectively, and we expect our revenues from international operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-15-000035:mdna:19]
[same as prior period, unchanged from 0000926326-15-000028:mdna:19]

[0000926326-15-000035:mdna:20]
Beginning in the first quarter of 2015, we have managed our business according to two operating segments, Automation and Analytics and Medication Adherence.

[0000926326-15-000035:mdna:21]
[same as prior period, unchanged from 0000926326-15-000028:mdna:21]

[0000926326-15-000035:mdna:22]
[same as prior period, unchanged from 0000926326-15-000028:mdna:22]

[0000926326-15-000035:mdna:23]
[same as prior period, unchanged from 0000926326-15-000028:mdna:24]

[0000926326-15-000035:mdna:24]
The Medication Adherence segment primarily includes the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand name MTS, Surgichem, SureMed and the Omnicell brand. MTS products consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care and correctional facilities or retail pharmacies serving patients in their local communities. Similarly, Surgichem is a provider of medication adherence packaging systems and solutions to the United Kingdom community and home care markets.

[0000926326-15-000035:mdna:25]
[same as prior period, unchanged from 0000926326-15-000028:mdna:26]

[0000926326-15-000035:mdna:26]
[same as prior period, unchanged from 0000926326-15-000028:mdna:27]

[0000926326-15-000035:mdna:27]
[same as prior period, unchanged from 0000926326-15-000028:mdna:28]

[0000926326-15-000035:mdna:28]
[same as prior period, unchanged from 0000926326-15-000028:mdna:29]

[0000926326-15-000035:mdna:29]
[same as prior period, unchanged from 0000926326-15-000028:mdna:30]

[0000926326-15-000035:mdna:30]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, we began shipping a refresh of our product line in 2011, which we market as G4. The G4 refresh included multiple new products and an upgraded product that allowed existing customers to augment their installations to obtain the most current technology that we provide. The G4 product refresh has been a key contributor to our growth, with 73%

[0000926326-15-000035:mdna:31]
of our automation and analytics installed base ordering upgrades to their existing systems since the announcement of G4. In addition to enhanced capabilities, we have focused on attaining the highest quality and service measurements for G4 in the industry, while marketing the solution to new and existing customers. Our research and development efforts today are designed to bring new products to market beyond the G4 product line that we believe will meet customer needs in years to come.

[0000926326-15-000035:mdna:32]
Consistent with our strategy to enter new markets, we have made investments in our selling, general and administrative expenses to expand our sales team and market to new customers. Our international efforts have focused primarily on three markets: the United Kingdom and Germany where we sell automation and analytics and medication adherence products through a direct sales team; Middle Eastern countries of the Arabian Peninsula where new healthcare facility construction is taking place; and China, where we launched a Mandarin version of our automated dispensing systems in 2011. We have also expanded our sales efforts to medication adherence customers in the United States, which has allowed us to sell our automated dispensing solutions and other products to this market.

[0000926326-15-000035:mdna:33]
Expansion of our solutions through acquisitions and partnerships include our acquisition of MTS in 2012, our acquisition of Surgichem in August 2014, and our acquisitions of Mach4 and Avantec in April 2015. Surgichem is a provider of medication adherence products in the United Kingdom. Mach4 is a provider of automated medication management systems to retail and hospital pharmacy customers primarily in Europe, with additional installations in China, the Middle East and Latin America. Avantec develops medication and supply automation products that complement our solutions for configurations suited to the United Kingdom marketplace, and has been the exclusive United Kingdom distributor for our medication and supply automation solutions since 2005. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-15-000035:mdna:34]
[same as prior period, unchanged from 0000926326-15-000028:mdna:35]

[0000926326-15-000035:mdna:35]
[same as prior period, unchanged from 0000926326-15-000028:mdna:36]

[0000926326-15-000035:mdna:36]
[same as prior period, unchanged from 0000926326-15-000028:mdna:37]

[0000926326-15-000035:mdna:37]
[same as prior period, unchanged from 0000926326-15-000028:mdna:38]

[0000926326-15-000035:mdna:38]
[same as prior period, unchanged from 0000926326-15-000028:mdna:39]

[0000926326-15-000035:mdna:39]
In addition to product solution sales, we provide services to our customers. Our healthcare customers expect a high degree of partnership involvement from their technology suppliers throughout their ownership of the products. We provide extensive installation planning and consulting as part of every product sale and included in the initial price of the solution. Our customers' medication control systems are mission critical to their success and our customers require these systems to be functional at all times. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in one, two or five year increments. As a result of the growth of our installed base of customers, our service revenues have also grown. We strive to provide the best service possible, as measured by third-party rating agencies and by our own surveys, to assure our customers continue to seek service maintenance from us. Our liabilities include current and long-term deferred service revenue of $44.6 million and $45.5 million as of September 30, 2015 and December 31, 2014, respectively. Our deferred service revenue will be amortized to service revenue as the service contracts are executed.

[0000926326-15-000035:mdna:40]
The growth in our Automation and Analytics revenue for the three and nine months ended September 30, 2015 was driven primarily by our success in consistently growing the number of our customer installations. Installed customers in the United States grew to 2,023 hospitals as of September 30, 2015 from 1,886 hospitals as of September 30, 2014. To a lesser extent, but of equal importance, revenue growth was also driven by our success in upgrading installed customers to newer G4 technology, which is in line with our strategy of striving to deliver differentiated innovation in our solutions. Our larger

[0000926326-15-000035:mdna:41]
29

[0000926326-15-000035:mdna:42]
installed base has provided growth opportunities for follow on sales and increased service contracts and, as a result, our service revenues have also grown for the nine months ended September 30, 2015.

[0000926326-15-000035:mdna:43]
The growth in our Medication Adherence revenue for the nine months ended September 30, 2015 was driven primarily by the inclusion of Surgichem operations which was acquired in August 2014 and increased adoption of multi-medication adherence solutions used by patients in assisted living or home care in Europe. This growth is in line with our strategy to deliver solutions to markets outside the United States. On a geographic basis, the United States market did not contribute to, nor erode, the growth in our Medication Adherence business as the population of patients living in nursing homes in the United States has remained relatively constant over the past year.

[0000926326-15-000035:mdna:44]
[same as prior period, unchanged from 0000926326-15-000028:mdna:43]

[0000926326-15-000035:mdna:45]
Pending Aesynt Acquisition

[0000926326-15-000035:mdna:46]
On October 29, 2015, we entered into a securities purchase agreement (the “Securities Purchase Agreement”) with Aesynt Holding, L.P., Aesynt, Ltd. (together with Aesynt Holding, L.P., the “Sellers”) and Aesynt Coöperatief U.A. (“Aesynt”). Pursuant to the terms and conditions of the Securities Purchase Agreement, we will acquire from the Sellers, and the Sellers will sell to us, all of the outstanding interests of Aesynt on the closing date (such acquisition, the “Aesynt Acquisition”). Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, IV sterile preparation robotics and software, including software related to medication management. The contemplated total aggregate consideration is $275.0 million, in cash, plus cash on hand at signing minus indebtedness at close, or approximately $217.5 million, subject to certain adjustments at closing as provided for in the Securities Purchase Agreement. The closing of the Aesynt Acquisition is subject to certain closing conditions, including the expiration or termination of the applicable waiting period under the Hart-Scott-Rodino Antitrust Improvement Act of 1976, as amended.

[0000926326-15-000035:mdna:47]
In connection with the Securities Purchase Agreement, we entered into a commitment letter with Wells Fargo Bank, National Association (“Wells Fargo Bank”) and Wells Fargo Securities, LLC (“Wells Fargo Securities” and, together with Wells Fargo Bank, the “Commitment Parties”) on October 29, 2015, pursuant to which Wells Fargo Bank has committed to provide $300.0 million of senior secured credit facilities consisting of (a) a $200.0 million term loan facility, and (b) $100.0 million revolving credit facility (collectively, the “Senior Credit Facilities”), a portion of which, together with our existing cash on hand, would be used to (i) refinance the loans under Omnicell’s existing senior secured credit facility, if any, and Aesynt’s existing senior secured credit facility, (ii) pay the purchase price for the Aesynt Acquisition, and (iii) pay any fees and expenses incurred in connection with any of the foregoing. The commitment to provide the loans under the Senior Credit Facilities is subject to certain conditions, including the negotiation of definitive documentation for the Senior Credit Facilities and other customary closing conditions.

[0000926326-15-000035:mdna:48]
[same as prior period, unchanged from 0000926326-15-000028:mdna:44]

[0000926326-15-000035:mdna:49]
Our discussion and analysis of our financial condition and results of operations are based on our Condensed Consolidated Financial Statements, which have been prepared in accordance with U.S. GAAP. The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements:

[0000926326-15-000035:mdna:50]
[same as prior period, unchanged from 0000926326-15-000028:mdna:47]

[0000926326-15-000035:mdna:51]
[same as prior period, unchanged from 0000926326-15-000028:mdna:48]

[0000926326-15-000035:mdna:52]
[same as prior period, unchanged from 0000926326-15-000028:mdna:49]

[0000926326-15-000035:mdna:53]
[same as prior period, unchanged from 0000926326-15-000028:mdna:50]

[0000926326-15-000035:mdna:54]
[same as prior period, unchanged from 0000926326-15-000028:mdna:51]

[0000926326-15-000035:mdna:55]
[same as prior period, unchanged from 0000926326-15-000028:mdna:52]

[0000926326-15-000035:mdna:56]
[same as prior period, unchanged from 0000926326-15-000028:mdna:79]

[0000926326-15-000035:mdna:57]
There have been no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the three and nine months ended September 30, 2015 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2014.

[0000926326-15-000035:mdna:58]
[same as prior period, unchanged from 0000926326-15-000028:mdna:54]

[0000926326-15-000035:mdna:59]
Refer to Note 1, Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial positions and cash flows.

[0000926326-15-000035:mdna:60]
[same as prior period, unchanged from 0000926326-15-000028:mdna:56]

[0000926326-15-000035:mdna:61]
[same as prior period, unchanged from 0000926326-15-000028:mdna:57]

[0000926326-15-000035:mdna:62]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 100,941 |  |  | $ | 92,229 |  |  | 8,712 |  |  | 9 | % |
| Percentage of total revenues | 81 | % |  | 82 | % |  |  |  |  |
| Service and other revenues | 24,293 |  |  | 20,314 |  |  | 3,979 |  |  | 20 | % |
| Percentage of total revenues | 19 | % |  | 18 | % |  |  |  |  |
| Total revenues | $ | 125,234 |  |  | $ | 112,543 |  |  | $ | 12,691 |  |  | 11 | % |

[0000926326-15-000035:mdna:63]
Product revenues represented 81% and 82% of total revenues for the three months ended September 30, 2015 and September 30, 2014, respectively. Product revenues increased due to increased sales for Automation and Analytics segment of $9.5 million, partially offset by the decrease of $0.8 million in our Medication Adherence segment. The increase in our Automation and Analytics segment is attributed to larger orders received from our customers and the newly acquired companies Mach4 and Avantec, which contributed approximately $4.7 million to the increase in the product revenue compared to three months ended September 30, 2014. The decrease in Medication Adherence segment is attributed to lower sales in the consumable and equipment product sales compared to the three months ended September 30, 2014.

[0000926326-15-000035:mdna:64]
Service and other revenues represented 19% and 18% of total revenues for the three months ended September 30, 2015 and September 30, 2014, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues increased primarily due to an increase from our Automation and Analytics segment of $3.9 million. The newly acquired companies Mach4 and Avantec contributed approximately $2.0 million to the service revenue of Automation and Analytics segment for the three months ended September 30, 2015. Service and other revenues from Medication Adherence segment increased $0.1 million for the three months ended September 30, 2015 compared to the same period last year.

[0000926326-15-000035:mdna:65]
Our international sales represented 17% and 10% of total revenues for the three months ended September 30, 2015 and September 30, 2014, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-15-000035:mdna:66]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 284,204 |  |  | $ | 260,053 |  |  | 24,151 |  |  | 9 | % |
| Percentage of total revenues | 80 | % |  | 81 | % |  |  |  |  |
| Service and other revenues | 70,039 |  |  | 59,306 |  |  | 10,733 |  |  | 18 | % |
| Percentage of total revenues | 20 | % |  | 19 | % |  |  |  |  |
| Total revenues | $ | 354,243 |  |  | $ | 319,359 |  |  | $ | 34,884 |  |  | 11 | % |

[0000926326-15-000035:mdna:67]
Product revenues represented 80% and 81% of total revenues for the nine months ended September 30, 2015 and September 30, 2014, respectively. Product revenues increased due to increased sales for both our Automation and Analytics segment of $18.0 million and Medication Adherence segment of $6.2 million.  The newly acquired companies Mach4 and Avantec contributed approximately $7.6 million to the Automation and Analytics segment for the nine months ended September 30, 2015.

[0000926326-15-000035:mdna:68]
Service and other revenues represented 20% and 19% of total revenues for the nine months ended September 30, 2015 and September 30, 2014, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues increased primarily due to an increase from our Automation and Analytics segment of $10.7 million. The newly acquired companies Mach4 and Avantec contributed approximately $3.2 million to the service revenue of Automation and Analytics segment for the nine months ended September 30, 2015.

[0000926326-15-000035:mdna:69]
Our international sales represented 16% and 8% of total revenues for the nine months ended September 30, 2015 and September 30, 2014, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-15-000035:mdna:70]
We anticipate our revenues will continue to increase in 2015 compared to the same periods in 2014 as we fulfill our existing orders and based on our growth in bookings in 2014 and in the first nine months of 2015, some of which will be recognized as revenue in 2015. Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-15-000035:mdna:71]
[same as prior period, unchanged from 0000926326-15-000028:mdna:67]

[0000926326-15-000035:mdna:72]
[same as prior period, unchanged from 0000926326-15-000028:mdna:68]

[0000926326-15-000035:mdna:73]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 102,967 |  |  | $ | 89,547 |  |  | $ | 13,420 |  |  | 15 | % |
| Percentage of total revenues | 82 | % |  | 80 | % |  |  |  |  |
| Medication Adherence | 22,267 |  |  | 22,996 |  |  | (729 | ) |  | (3 | )% |
| Percentage of total revenues | 18 | % |  | 20 | % |  |  |  |  |
| Total revenues | $ | 125,234 |  |  | $ | 112,543 |  |  | $ | 12,691 |  |  | 11 | % |

[0000926326-15-000035:mdna:74]
The increase in Automation and Analytics revenues for the three months ended September 30, 2015 in comparison to the three months ended September 30, 2014 was due to an increase in product revenue which contributed $9.5 million to the increase, and service and other revenues of $3.9 million.  The increase in product and service revenue was primarily due to newly acquired companies Mach4 and Avantec which accounted for $4.7 million and $2.0 million of the increase in product and service revenue, respectively. Larger deal sizes primarily due to customer conversions, also contributed to the increase in product revenue in the three months ended September 30, 2015.

[0000926326-15-000035:mdna:75]
Medication Adherence revenues decreased for the three months ended September 30, 2015 in comparison to the three months ended September 30, 2014 primarily due to the decrease in the product revenues, particularly in the consumable and

[0000926326-15-000035:mdna:76]
[same as prior period, unchanged from 0000926326-15-000028:mdna:96]

[0000926326-15-000035:mdna:77]
equipment product sales.

[0000926326-15-000035:mdna:78]
|  | Nine months ended September 30, |
|  |  |  | Change in |  |  |
|  | 2015 |  | 2014 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 284,447 |  |  | $ | 255,748 |  |  | $ | 28,699 |  |  | 11 | % |
| Percentage of total revenues | 80 | % |  | 80 | % |  |  |  |  |
| Medication Adherence | 69,796 |  |  | 63,611 |  |  | 6,185 |  |  | 10 | % |
| Percentage of total revenues | 20 | % |  | 20 | % |  |  |  |  |
| Total revenues | $ | 354,243 |  |  | $ | 319,359 |  |  | $ | 34,884 |  |  | 11 | % |

[0000926326-15-000035:mdna:79]
The increase in Automation and Analytics revenues for the nine months ended September 30, 2015 in comparison to the nine months ended September 30, 2014 was due to an increase in product revenues of $18.0 million primarily due to the larger deal sizes, mainly attributable to competitive conversions, and revenue from the newly acquired companies Mach4 and Avantec, which contributed $7.6 million to the increase in product revenue. Service and other revenues increased by $10.7 million primarily from higher service renewal fees driven mainly by an increase in installed customer base and $3.2 million due to the newly acquired companies Mach4 and Avantec.

[0000926326-15-000035:mdna:80]
Medication Adherence revenues increased for the nine months ended September 30, 2015 in comparison to the nine months ended September 30, 2014, primarily due to an increase in product revenues of $6.9 million. The increase in product revenue was largely driven by the inclusion of Surgichem operations since its acquisition in August 2014 which contributed approximately $8.4 million, which was partially offset by lower equipment sales in the nine months ended September 30, 2015 in comparison to the same period of 2014. Service and other revenues remained relatively flat compared to the prior year.

[0000926326-15-000035:mdna:81]
[same as prior period, unchanged from 0000926326-15-000028:mdna:76]

[0000926326-15-000035:mdna:82]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which accounts for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site and include costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory and amortization of software development costs and intangibles.

[0000926326-15-000035:mdna:83]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 45,668 |  |  | $ | 38,412 |  |  | $ | 7,256 |  |  | 19 | % |
| As a percentage of related revenues | 44 | % |  | 43 | % |  |  |  |  |
| Medication Adherence | 15,863 |  |  | 14,585 |  |  | 1,278 |  |  | 9 | % |
| As a percentage of related revenues | 71 | % |  | 63 | % |  |  |  |  |
| Total cost of revenues | $ | 61,531 |  |  | $ | 52,997 |  |  | $ | 8,534 |  |  | 16 | % |
| As a percentage of total revenues | 49 | % |  | 47 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 57,299 |  |  | $ | 51,135 |  |  | $ | 6,164 |  |  | 12 | % |
| Automation and Analytics gross margin | 56 | % |  | 57 | % |  |  |  |  |
| Medication Adherence | 6,404 |  |  | 8,411 |  |  | (2,007 | ) |  | (24 | )% |
| Medication Adherence gross margin | 29 | % |  | 37 | % |  |  |  |  |
| Total gross profit | $ | 63,703 |  |  | $ | 59,546 |  |  | $ | 4,157 |  |  | 7 | % |
| Total gross margin | 51 | % |  | 53 | % |  |  |  |  |

[0000926326-15-000035:mdna:84]
[same as prior period, unchanged from 0000926326-15-000028:mdna:105]

[0000926326-15-000035:mdna:85]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 123,923 |  |  | $ | 109,344 |  |  | $ | 14,579 |  |  | 13 | % |
| As a percentage of related revenues | 44 | % |  | 42 | % |  |  |  |  |
| Medication Adherence | 47,470 |  |  | 39,934 |  |  | 7,536 |  |  | 19 | % |
| As a percentage of related revenues | 68 | % |  | 63 | % |  |  |  |  |
| Total cost of revenues | $ | 171,393 |  |  | $ | 149,278 |  |  | $ | 22,115 |  |  | 15 | % |
| As a percentage of total revenues | 48 | % |  | 47 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 160,524 |  |  | $ | 146,404 |  |  | $ | 14,120 |  |  | 10 | % |
| Automation and Analytics gross margin | 56 | % |  | 57 | % |  |  |  |  |
| Medication Adherence | 22,326 |  |  | 23,677 |  |  | (1,351 | ) |  | (6 | )% |
| Medication Adherence gross margin | 32 | % |  | 37 | % |  |  |  |  |
| Total gross profit | $ | 182,850 |  |  | $ | 170,081 |  |  | $ | 12,769 |  |  | 8 | % |
| Total gross margin | 52 | % |  | 53 | % |  |  |  |  |

[0000926326-15-000035:mdna:86]
[same as prior period, unchanged from 0000926326-15-000028:mdna:81]

[0000926326-15-000035:mdna:87]
Cost of Revenues. The increase in cost of revenues for the three months ended September 30, 2015 compared to the three months ended September 30, 2014 was $7.3 million, $6.2 million of which was attributable to product costs and $1.1 million attributable to service costs. Of the $6.2 million increase in product costs the newly acquired companies Mach4 and Avantec contributed $4.4 million. Cost of service revenues increased by $1.1 million primarily due to an increase in costs related to the newly acquired companies Mach4 and Avantec which accounted for $0.8 million of the increase.

[0000926326-15-000035:mdna:88]
The increase in cost of revenues for the nine months ended September 30, 2015 compared to the nine months ended September 30, 2014 was $14.6 million, $12.1 million of which was attributable to product costs and $2.5 million of which was attributable to service costs. Both increases were a result of higher volume of revenue. Of the $14.6 million increase in product costs the newly acquired companies Mach4 and Avantec attributed $7.5 million, $0.6 million is attributable to more product installation costs associated with higher revenue, and $1.0 million is in other costs, primarily driven by software amortization. Cost of service revenues increased by $2.5 million due to an increase in support headcount to service a larger installed base and to an increase of $1.3 million in expenses related to the newly acquired companies Mach4 and Avantec.

[0000926326-15-000035:mdna:89]
Gross profit for the three and nine months ended September 30, 2015 increased compared to the three and nine months ended September 30, 2014 as a result of increased revenue at consistent gross margin percentages, partially offset by lower gross margins from the newly acquired companies Mach4 and Avantec.

[0000926326-15-000035:mdna:90]
[same as prior period, unchanged from 0000926326-15-000028:mdna:86]

[0000926326-15-000035:mdna:91]
Cost of revenues increased by $1.3 million and $7.5 million, respectively, in the three and nine months ended September 30, 2015 compared to the three and nine months ended September 30, 2014. The increase in the three and nine months ended September 30, 2015 of cost of revenue is primarily due to higher volume of revenues from our Surgichem acquisition that closed in August 2014, changes in our product mix and higher cost of service sales.

[0000926326-15-000035:mdna:92]
Gross profit decreased due to changes in our product mix, higher manufacturing cost, higher cost of service and, the inclusion of our Surgichem acquisition in August of 2014.

[0000926326-15-000035:mdna:93]
[same as prior period, unchanged from 0000926326-15-000028:mdna:90]

[0000926326-15-000035:mdna:94]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 9,176 |  |  | $ | 7,078 |  |  | $ | 2,098 |  |  | 30 | % |
| As a percentage of total revenues | 7 | % |  | 6 | % |  |  |  |  |
| Selling, general and administrative | 40,668 |  |  | 38,871 |  |  | 1,797 |  |  | 5 | % |
| As a percentage of total revenues | 32 | % |  | 35 | % |  |  |  |  |
| Total operating expenses | $ | 46,401 |  |  | $ | 45,949 |  |  | $ | 452 |  |  | 1 | % |
| As a percentage of total revenues | 37 | % |  | 41 | % |  |  |  |  |
| Income from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 26,671 |  |  | $ | 23,715 |  |  | $ | 2,956 |  |  | 12 | % |
| Operating margin | 21 | % |  | 21 | % |  |  |  |  |
| Medication Adherence | 334 |  |  | 3,589 |  |  | (3,255 | ) |  | (91 | )% |
| Operating margin | — | % |  | 3 | % |  |  |  |  |
| Corporate Expenses | 13,146 |  |  | 13,707 |  |  | (561 | ) |  | (4 | )% |
| Total income from operations | $ | 13,859 |  |  | $ | 13,597 |  |  | $ | 262 |  |  | 2 | % |
| Total operating margin | 11 | % |  | 12 | % |  |  |  |  |

[0000926326-15-000035:mdna:95]
Research and Development. The increase in research and development expenses of $2.1 million for the three months ended September 30, 2015 in comparison to three months ended September 30, 2014 was primarily driven by an increase in research and development expenses of $2.5 million in our Automation and Analytics segment which was primarily attributable to a $0.8 million increase in head-count, a $1.0 million increase in tools and equipment expenses and personnel related costs and a $0.6 million increase in consulting expenses, partially offset by higher capitalized software costs. The increase in research and development expenses in our Automation and Analytics segment was partially offset by a decrease in our Medication Adherence segment research and development expenses of $0.3 million which was primarily driven by an increase in capitalized software costs. The increase in the capitalized software costs were the result of a higher level of post-feasibility beta testing associated with certain products under development for our Medication Adherence segment.

[0000926326-15-000035:mdna:96]
Selling, General and Administrative.  The increase in selling, general and administrative expenses for the three months ended September 30, 2015 in comparison to the three months ended September 30, 2014 was primarily due to increases from our Automation and Analytics segment of $0.8 million and our Medication Adherence segment of $1.6 million, which is partially offset by decreases in corporate expenses of $0.6 million. The increase in our Automation and Analytics segment was primarily attributable to the newly acquired companies Mach4 and Avantec by $2.3 million which was partially offset by decreases primarily in marketing and sales activities. The increase from our Medication Adherence segment of $1.6 million was the result of increases in sales and marketing related activities mainly due to an increase in headcount specifically within our marketing and international departments. The corporate expenses remained relatively flat compared to the three months ended September 30, 2014.

[0000926326-15-000035:mdna:97]
Operating Income. Operating income from our Automation and Analytics segment increased $3.0 million due to a higher gross margin of $6.2 million, partially offset by higher research and development and selling, general and administrative costs.

[0000926326-15-000035:mdna:98]
Operating income from our Medication Adherence segment decreased due to product mix, higher manufacturing costs, higher cost of service, and higher operating expenses.

[0000926326-15-000035:mdna:99]
[same as prior period, unchanged from 0000926326-15-000028:mdna:129]

[0000926326-15-000035:mdna:100]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 25,941 |  |  | $ | 19,670 |  |  | $ | 6,271 |  |  | 32 | % |
| As a percentage of total revenues | 7 | % |  | 6 | % |  |  |  |  |
| Selling, general and administrative | 123,690 |  |  | 114,302 |  |  | 9,388 |  |  | 8 | % |
| As a percentage of total revenues | 35 | % |  | 36 | % |  |  |  |  |
| Gain on business combination | (3,443 | ) |  | — |  |  | (3,443 | ) |  | 100 | % |
| As a percentage of total revenues | (1 | )% |  | — | % |  |  |  |  |
| Total operating expenses | $ | 146,188 |  |  | $ | 133,972 |  |  | $ | 12,216 |  |  | 9 | % |
| As a percentage of total revenues | 41 | % |  | 42 | % |  |  |  |  |
| Income from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 75,329 |  |  | $ | 67,838 |  |  | $ | 7,491 |  |  | 11 | % |
| Operating margin | 21 | % |  | 21 | % |  |  |  |  |
| Medication Adherence | 4,005 |  |  | 9,404 |  |  | (5,399 | ) |  | (57 | )% |
| Operating margin | 1 | % |  | 3 | % |  |  |  |  |
| Corporate Expenses | 42,672 |  |  | 41,133 |  |  | 1,539 |  |  | 4 | % |
| Total income from operations | $ | 36,662 |  |  | $ | 36,109 |  |  | $ | 553 |  |  | 2 | % |
| Total operating margin | 10 | % |  | 11 | % |  |  |  |  |

[0000926326-15-000035:mdna:101]
Research and Development. The increase in research and development expenses of $6.3 million for the nine months ended September 30, 2015 in comparison to nine months ended September 30, 2014 was primarily driven by an increase of $5.8 million in our Automation and Analytics segment which was primarily attributable to a $3.5 million increase in head-count, a $1.7 million increase in consulting expenses and $1.6 million increase in tools and equipment expenses, partially offset by an increase in capitalized software costs due to the higher level of post-feasibility beta testing which therefore decreased our research and development expenses. The research and development expenses remained flat for our Medication Adherence segment.

[0000926326-15-000035:mdna:102]
We expect research and development expenses to increase in 2015 as we continue to invest in new products and services, and increase as a percentage of total revenues from approximately 6% in 2014 to approximately 7-8% in 2015. The amount of research and development expenses can fluctuate based on the amount of prototype expenses for hardware and/or the amount of capitalized software development costs.

[0000926326-15-000035:mdna:103]
Selling, General and Administrative. The increase in selling, general and administrative expenses for the nine months ended September 30, 2015 in comparison to the nine months ended September 30, 2014 was primarily due to increases from our Automation and Analytics segment of $3.5 million, from our Medication Adherence segment of $4.4 million and increases in corporate expenses of $1.5 million. The increase in our Automation and Analytics segment was primarily attributable to the newly acquired companies Mach4 and Avantec by $3.7 million. The increase from our Medication Adherence segment was the result of $2.0 million from the inclusion of Surgichem operations for nine months in 2015 in comparison to three months of 2014, with the remainder attributed to an increase in headcount specifically within our marketing and international departments. The increase in corporate expenses was primarily related to legal expenses of $1.6 million mainly due to the investigation of a whistleblower claim.

[0000926326-15-000035:mdna:104]
[same as prior period, unchanged from 0000926326-15-000028:mdna:101]

[0000926326-15-000035:mdna:105]
Operating Income. Operating income from our Automation and Analytics segment increased for the nine months ended September 30, 2015 relative to the nine months ended September 30, 2014 due to increased revenues at consistent operating margins.

[0000926326-15-000035:mdna:106]
Operating income from our Medication Adherence segment  decreased due to product mix, higher manufacturing costs, higher cost of service, and higher operating expenses.

[0000926326-15-000035:mdna:107]
[same as prior period, unchanged from 0000926326-15-000028:mdna:144]

[0000926326-15-000035:mdna:108]
[same as prior period, unchanged from 0000926326-15-000028:mdna:104]

[0000926326-15-000035:mdna:109]
|  | Three months ended |
|  |  |  |  |  | Change in |
|  | September 30, 2015 |  | September 30, 2014 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 5,177 |  |  | $ | 5,591 |  |  | $ | (414 | ) |  | (7 | )% |

[0000926326-15-000035:mdna:110]
|  | Nine months ended |
|  |  |  |  |  | Change in |
|  | September 30, 2015 |  | September 30, 2014 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 11,922 |  |  | $ | 13,824 |  |  | $ | (1,902 | ) |  | (14 | )% |
| Effective tax rate on earnings | 39.3 | % |  | 40.5 | % |  |  |  |  |

[0000926326-15-000035:mdna:111]
Our annual effective tax rate before discrete items was 39.3% and 40.5% for the nine months ended September 30, 2015 and September 30, 2014, respectively. The decrease in the estimated annual effective tax rate for the nine months ended September 30, 2015 compared to the same period in 2014 was primarily due to the decrease in the state effective tax rate, and the decrease in non-deductible equity charges and other non-deductible expenditures.

[0000926326-15-000035:mdna:112]
[same as prior period, unchanged from 0000926326-15-000028:mdna:109]

[0000926326-15-000035:mdna:113]
[same as prior period, unchanged from 0000926326-15-000028:mdna:110]

[0000926326-15-000035:mdna:114]
We had cash and cash equivalents of $57.8 million at September 30, 2015, compared to $125.9 million at December 31, 2014. All of our cash and cash equivalents are invested in demand deposits and money market funds.

[0000926326-15-000035:mdna:115]
Our cash position and working capital at September 30, 2015 and December 31, 2014 were as follows:

[0000926326-15-000035:mdna:116]
|  | September 30, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Cash | $ | 17,649 |  |  | $ | 61,311 |  |
| Cash equivalents | 40,108 |  |  | 64,577 |  |
| Total | $ | 57,757 |  |  | $ | 125,888 |  |
| Working Capital | $ | 137,242 |  |  | $ | 171,054 |  |

[0000926326-15-000035:mdna:117]
Our ratio of current assets to current liabilities was 2.1:1 at September 30, 2015 compared to 2.5:1 at December 31, 2014.

[0000926326-15-000035:mdna:118]
We maintain a Credit Agreement with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time which provides for a $75 million revolving credit facility to be used for general corporate purposes, including future acquisitions. The Credit Agreement permits us to request one or more increases in the aggregate commitment provided such increases do not exceed $25 million in the aggregate.

[0000926326-15-000035:mdna:119]
On November 5, 2014, we entered into Amendment Number One (the “Amendment”) to the Credit Agreement. The Amendment increases the amount of our common stock that may be repurchased by us in open market transactions authorized by our Board of Directors, together with any repurchases of our common stock from any consultants, employees, officers or directors of the Company or any of our subsidiaries following the death, disability, retirement or termination of employment of such employees, officers or directors, from $25 million to $50 million per year. The Credit Agreement contains customary affirmative and negative covenants, and financial covenants that require us to, among other things, maintain a maximum

[0000926326-15-000035:mdna:120]
37

[0000926326-15-000035:mdna:121]
consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each quarter.

[0000926326-15-000035:mdna:122]
As of September 30, 2015, we were in full compliance with all covenants, and there was no outstanding balance on the credit facility.

[0000926326-15-000035:mdna:123]
In connection with the Securities Purchase Agreement of the pending Aesynt Acquisition on October 29, 2015, we entered into a commitment letter with Wells Fargo Bank and Wells Fargo Securities, pursuant to which Wells Fargo Bank has committed to provide $300 million of Senior Credit Facilities. The commitment to provide the loans under the Senior Credit Facilities is subject to certain conditions, including the negotiation of definitive documentation for the Senior Credit Facilities and other customary closing conditions.

[0000926326-15-000035:mdna:124]
[same as prior period, unchanged from 0000926326-15-000028:mdna:118]

[0000926326-15-000035:mdna:125]
[same as prior period, unchanged from 0000926326-15-000028:mdna:119]

[0000926326-15-000035:mdna:126]
Our 2014 Stock Repurchase Program had a total of $4.9 million remaining for future repurchases as of September 30, 2015, which may result in additional use of cash. See Note 12, Stock Repurchases, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. In accordance with the Avantec share purchase agreement, we may pay out potential earn-out payments of $3.0 million payable after December 31, 2015 and an additional $3.0 million payable after December 31, 2016, based on future bookings. The fair value of these earn-out payments as of the acquisition date was $5.6 million. Pursuant to the terms of the agreement we also held back $1.8 million from the purchase consideration towards any future indemnification claims that we may make at the end of the 18-month period. Additional charges to the purchase price based on actual working capital at the time of acquisition generated a payment obligation to the former owners of Avantec as of  June 30, 2015 of additional $1.8 million. This amount was paid out during the third quarter of 2015.

[0000926326-15-000035:mdna:127]
Except with respect to the Aesynt Acquisition, based on our current business plan and revenue backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under our $75 million credit agreement, will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-15-000035:mdna:128]
We do not currently have sufficient capital to consummate the Aesynt Acquisition. In connection with the Securities Purchase Agreement, we entered into a commitment letter with Wells Fargo Bank and Wells Fargo Securities, pursuant to which Wells Fargo Bank has committed to provide $300.0 million of Senior Credit Facilities. The commitment to provide the loans under the Senior Credit Facilities is subject to certain conditions, including the negotiation of definitive documentation for the Senior Credit Facilities and other customary closing conditions. We cannot assure you that either the Senior Credit Facilities will be available prior to the contractually required time for the closing of the proposed Aesynt Acquisition or that the terms of the definitive documentation for the Senior Credit Facilities will be consistent with the terms anticipated by the commitment letter or will otherwise be favorable to us. In the event that Senior Credit Facilities contemplated by the commitment letter are not available at the required time, in order to complete the Aesynt Acquisition, we would be required to raise capital through an alternative transaction or transactions, which could include an alternative loan facility, public or private debt or equity financings or other arrangements, and we may be unable to raise such additional funds in a timely manner or at all. Any equity financing could be dilutive to our stockholders.

[0000926326-15-000035:mdna:129]
[same as prior period, unchanged from 0000926326-15-000028:mdna:122]

[0000926326-15-000035:mdna:130]
[same as prior period, unchanged from 0000926326-15-000028:mdna:123]

[0000926326-15-000035:mdna:131]
|  | Nine Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 5,932 |  |  | $ | 34,315 |  |
| Investing activities | (41,312 | ) |  | (38,061 | ) |
| Financing activities | (32,699 | ) |  | 3,538 |  |
| Effect of exchange rate changes on cash and cash equivalents | (52 | ) |  | (136 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | (68,131 | ) |  | $ | (344 | ) |

[0000926326-15-000035:mdna:132]
[same as prior period, unchanged from 0000926326-15-000028:mdna:125]

[0000926326-15-000035:mdna:133]
[same as prior period, unchanged from 0000926326-15-000028:mdna:126]

[0000926326-15-000035:mdna:134]
Net cash provided by operating activities was $5.9 million for the nine months ended September 30, 2015, primarily as a result of $23.1 million in net income adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $18.5 million, share-based compensation expense, of $11.3 million and $3.4 million from our investment gain. This was offset by $42.1 million cash outflow from changes in assets and liabilities resulting primarily from i) an increase in accounts receivable of $26.1 million due to increased product shipments late in the quarter, ii) an increase in inventories of $13.2 million to support forecasted sales, iii) a decrease in deferred gross margin of $1.2 million due to timing of orders, shipments, and revenue being recognized for installed product, and iv) a decrease in accrued compensation of $5.0 million primarily due to lower sales commissions. These amounts were partially offset by a decrease in the prepaid expenses of $5.9 million primarily due to commissions driven by higher bookings in the fourth quarter of 2014 compared to the current year to date period, and an increase in accrued liabilities of $4.6 million primarily due to potential earn-out and contingent payment of $2.9 million related to the Avantec Acquisition.

[0000926326-15-000035:mdna:135]
During the nine months ended September 30, 2014, cash provided by operating activities consisted of net income of $21.3 million and non-cash charges of $25.8 million, offset by a $12.7 million decrease in net operating assets and liabilities. Our non-cash charges consisted primarily of depreciation and amortization for our fixed and intangible assets of $14.7 million, stock-based compensation expense of $8.6 million, income tax benefits from employee stock plans of $4.1 million and deferred income taxes of $1.3 million, partially offset by $4.5 million in excess tax benefits from employee stock plans.

[0000926326-15-000035:mdna:136]
The main drivers in the change in our net operating assets and liabilities were a $35.0 million increase in accounts receivable due to increased shipments under purchase contracts of medication and supply cabinets, a $6.5 million decrease in accrued compensation primarily due to incentive bonus payouts, and lower accrued commissions due to higher bookings in the fourth quarter of 2013 as compared to the nine months ended September 30, 2014. This increase was offset by a $15.6 million increase in deferred gross profit due to an increase in products shipped but not yet installed, a $5.4 million increase in trade accounts payable due to growth in our business activities, a $2.7 million increase in deferred service revenues associated with new third-party leases generated and billed, a $1.4 million decrease in other current assets due to receipt of a tax refund, a $1.0 million decrease in prepaid expenses primarily due to a decrease in commissions driven by higher bookings in the fourth quarter of 2013 as compared to the nine months ended September 30, 2014, and a $0.8 million increase in other long-term tax liabilities.

[0000926326-15-000035:mdna:137]
[same as prior period, unchanged from 0000926326-15-000028:mdna:131]

[0000926326-15-000035:mdna:138]
Net cash used in investing activities was $41.3 million for the nine months ended September 30, 2015, $25 million of which was attributable to the acquisitions of Mach4 and Avantec, and capital expenditures related to purchases of property and equipment and software development of software costs for external use of $6.1 million and $9.4 million, respectively.

[0000926326-15-000035:mdna:139]
Net cash used in investing activities for the nine months ended September 30, 2014 consisted primarily of $19.7 million for the acquisition of Surgichem, $10.2 million for purchases of property and equipment, primarily for software licenses and software upgrades, and $7.9 million expended for capitalized software development costs.

[0000926326-15-000035:mdna:140]
[same as prior period, unchanged from 0000926326-15-000028:mdna:134]

[0000926326-15-000035:mdna:141]
Net cash used by financing activities was $32.7 million for the nine months ended September 30, 2015 as a result of $50.0 million in cash used for stock repurchases under our 2012 and 2014 Stock Repurchase Programs and $2.3 million in employees taxes paid in relation to restricted stock units, partially offset by $15.7 million in proceeds from employee stock option exercises and employee stock plan purchases and $3.9 million in excess tax benefits from employee stock plans.

[0000926326-15-000035:mdna:142]
Net cash provided by financing activities during the nine months ended September 30, 2014 consisted of $18.2 million in proceeds from employee stock option exercises and employee stock plan purchases and, $4.5 million in excess tax benefits from employee stock plans, offset by $17.1 million in cash used for stock repurchases under our 2012 Stock Repurchase Program and $2.0 million in employee' taxes paid related to restricted stock units.

[0000926326-15-000035:mdna:143]
[same as prior period, unchanged from 0000926326-15-000028:mdna:137]

[0000926326-15-000035:mdna:144]
There have been no significant changes during the nine months ended September 30, 2015 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2014.

[0000926326-15-000035:mdna:145]
We had $69.2 million in contractual commitments to third parties for non-cancelable operating leases, commitments to contract manufacturers and suppliers and other purchase commitments as of September 30, 2015 as follows:

[0000926326-15-000035:mdna:146]
|  | Payments due by period |
|  | Total |  | Remainder of 2015 |  | 2016 and 2017 |  | 2018 and 2019 |  | 2020 and Thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 40,349 |  |  | $ | 1,751 |  |  | $ | 12,411 |  |  | $ | 10,971 |  |  | $ | 15,216 |  |
| Purchase obligations (2) | 28,846 |  |  | 28,846 |  |  | — |  |  | — |  |  | — |  |
| Total (3) | $ | 69,195 |  |  | $ | 30,597 |  |  | $ | 12,411 |  |  | $ | 10,971 |  |  | $ | 15,216 |  |

[0000926326-15-000035:mdna:147]
[same as prior period, unchanged from 0000926326-15-000028:mdna:141]

[0000926326-15-000035:mdna:148]
[same as prior period, unchanged from 0000926326-15-000028:mdna:142]

[0000926326-15-000035:mdna:149]
[same as prior period, unchanged from 0000926326-15-000028:mdna:143]

[0000926326-15-000035:mdna:150]
| (3) | We have recorded $7.1 million for uncertain tax positions under long-term liabilities as of September 30, 2015 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, $7.1 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-15-000035:mdna:151]
[same as prior period, unchanged from 0000926326-15-000028:mdna:146]

[0000926326-15-000035:mdna:152]
[same as prior period, unchanged from 0000926326-15-000028:mdna:147]

[0000926326-15-000035:mdna:153]
As of September 30, 2015, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
