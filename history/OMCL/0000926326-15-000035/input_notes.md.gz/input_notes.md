# OMCL notes — 0000926326-15-000035


## omcl:ScheduleofLongTermNetInvestmentinSaleTypeLeasesTableTextBlock

[0000926326-15-000035:notes:1]
The receivables as a result of these type of transactions are collateralized by the underlying equipment leased and consist of the following components at September 30, 2015 and December 31, 2014:

[0000926326-15-000035:notes:2]
|  | September 30, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 20,731 |  |  | $ | 17,616 |  |
| Less: unearned interest income portion | (1,000 | ) |  | (1,131 | ) |
| Net investment in sales-type leases | 19,731 |  |  | 16,485 |  |
| Less: short-term portion* | (6,174 | ) |  | (5,637 | ) |
| Long-term net investment in sales-type leases | $ | 13,557 |  |  | $ | 10,848 |  |

[0000926326-15-000035:notes:3]
* The short-term portion of the net investments in sales-type leases are included in the Other current assets on the Condensed Consolidated Balance Sheets.


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-15-000035:notes:4]
We had the following ordinary shares reserved for future issuance under our equity incentive plans as of June 30, 2015:

[0000926326-15-000035:notes:5]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 2,417 |  |
| Restricted share awards outstanding | 629 |  |
| Shares authorized for future issuance | 4,402 |  |
| ESPP shares available for future issuance | 3,251 |  |
| Total shares reserved for future issuance as of September 30, 2015 | 10,699 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-15-000035:notes:6]
[same as prior period, unchanged from 0000926326-15-000028:notes:5]

[0000926326-15-000035:notes:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2015 and December 31, 2014, the results of their operations, comprehensive income and cash flows for the three and nine months ended September 30, 2015 and September 30, 2014. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in our annual report on Form 10-K for the year ended December 31, 2014 filed with the SEC on March 30, 2015. Our results of operations, comprehensive income and cash flows for the three and nine months ended September 30, 2015 are not necessarily indicative of results that may be expected for the year ending December 31, 2015, or for any future period.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000926326-15-000035:notes:8]
As a result, actual results will differ from the unaudited pro forma information presented (in thousands, except per share

[0000926326-15-000035:notes:9]
data):

[0000926326-15-000035:notes:10]
|  | Nine months ended September 30, |
|  | 2015 |  | 2014 |
|  | (In thousands, except per share data) |
| Pro forma net revenues | $ | 361,217 |  |  | $ | 340,915 |  |
| Pro forma net income | $ | 23,742 |  |  | $ | 22,511 |  |
| Pro forma net income per share basic | $ | 0.66 |  |  | $ | 0.63 |  |
| Pro forma net income per share diluted | $ | 0.64 |  |  | $ | 0.61 |  |


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-15-000035:notes:11]
[same as prior period, unchanged from 0000926326-15-000028:notes:9]

[0000926326-15-000035:notes:12]
On recurring basis, we enter into sales-type lease transactions which vary in length from one to five years. The receivables as a result of these type of transactions are collateralized by the underlying equipment leased and consist of the following components at September 30, 2015 and December 31, 2014:

[0000926326-15-000035:notes:13]
We evaluate our sales-type leases individually and collectively for impairment, and recorded $0.1 million collective allowance for credit losses as of September 30, 2015 and $0.2 million as of December 31, 2014.

[0000926326-15-000035:notes:14]
At September 30, 2015, the future minimum lease payments under sales-type leases are as follows:

[0000926326-15-000035:notes:15]
|  | September 30, 2015 |
| Year ended December 31, | (In thousands) |
| Remaining three months of 2015 | $ | 1,774 |  |
| 2016 | 6,454 |  |
| 2017 | 5,428 |  |
| 2018 | 3,808 |  |
| 2019 | 2,188 |  |
| Thereafter | 1,079 |  |
| Total | $ | 20,731 |  |


## us-gaap:CommitmentsDisclosureTextBlock

[0000926326-15-000035:notes:16]
[same as prior period, unchanged from 0000926326-15-000028:notes:14]

[0000926326-15-000035:notes:17]
[same as prior period, unchanged from 0000926326-15-000028:notes:15]

[0000926326-15-000035:notes:18]
We lease office space and office equipment under operating leases. At September 30, 2015, future minimum lease payments under such operating leases were as follows:

[0000926326-15-000035:notes:19]
|  | September 30, 2015 |
|  | (In thousands) |
| Remaining three months of 2015 | $ | 1,751 |  |
| 2016 | 6,526 |  |
| 2017 | 5,885 |  |
| 2018 | 5,490 |  |
| 2019 | 5,481 |  |
| Thereafter | 15,216 |  |
| Total minimum future lease payments | $ | 40,349 |  |

[0000926326-15-000035:notes:20]
[same as prior period, unchanged from 0000926326-15-000028:notes:19]

[0000926326-15-000035:notes:21]
During the course of the business, we issue purchase orders based on our current manufacturing needs.  At September 30, 2015, we had non-cancelable purchase commitments of $28.8 million, which are expected to be paid within the next twelve months.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-15-000035:notes:22]
[same as prior period, unchanged from 0000926326-15-000028:notes:21]

[0000926326-15-000035:notes:23]
[same as prior period, unchanged from 0000926326-15-000028:notes:22]

[0000926326-15-000035:notes:24]
On April 21, 2015, we completed the acquisition of Mach4 Automatisierungstechnik GmbH (“Mach4”), a privately held German limited liability company with registered office in Bochum, Germany. On April 30, 2015, we acquired the remaining 85% of the issued and outstanding ordinary shares of Avantec Healthcare Limited (“Avantec”) not already held by Omnicell. The consolidated financial statements include the results of operations of Mach4 and Avantec commencing as of their respective acquisition dates.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000926326-15-000035:notes:25]
[same as prior period, unchanged from 0000926326-15-000028:notes:24]

[0000926326-15-000035:notes:26]
|  | September 30, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Sales of medication and supply dispensing systems including packaging equipment (1) | $ | 44,158 |  |  | $ | 36,947 |  |
| Less: cost of revenues, excluding installation costs | (16,979 | ) |  | (8,389 | ) |
| Total deferred gross profit | $ | 27,179 |  |  | $ | 28,558 |  |

[0000926326-15-000035:notes:27]
[same as prior period, unchanged from 0000926326-15-000028:notes:26]

[0000926326-15-000035:notes:28]
[same as prior period, unchanged from 0000926326-15-000028:notes:27]


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-15-000035:notes:29]
[same as prior period, unchanged from 0000926326-15-000028:notes:28]


## us-gaap:EarningsPerShareTextBlock

[0000926326-15-000035:notes:30]
[same as prior period, unchanged from 0000926326-15-000028:notes:29]

[0000926326-15-000035:notes:31]
Basic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. Diluted net income per share is computed by dividing net income for the period by the weighted-average number of shares, less shares repurchased, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. The anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share because their effect would have been anti-dilutive.

[0000926326-15-000035:notes:32]
[same as prior period, unchanged from 0000926326-15-000028:notes:31]

[0000926326-15-000035:notes:33]
|  | Three months ended September 30, | Nine months ended September 30, |
|  | 2015 |  | 2014 | 2015 |  | 2014 |
|  | (In thousands, except per share data) |
| Net income | $ | 8,036 |  |  | $ | 7,300 |  | $ | 23,105 |  |  | $ | 21,282 |  |
| Weighted-average shares outstanding — basic | 35,806 |  |  | 35,994 |  | 35,983 |  |  | 35,634 |  |
| Dilutive effect of employee stock plans | 807 |  |  | 838 |  | 887 |  |  | 983 |  |
| Weighted-average shares outstanding — diluted | 36,613 |  |  | 36,832 |  | 36,870 |  |  | 36,617 |  |
| Net income per share — basic | $ | 0.22 |  |  | $ | 0.20 |  | $ | 0.64 |  |  | $ | 0.60 |  |
| Net income per share — diluted | $ | 0.22 |  |  | $ | 0.20 |  | $ | 0.63 |  |  | $ | 0.58 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 478 |  |  | 427 |  | 380 |  |  | 364 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-15-000035:notes:34]
The following table represents the fair value hierarchy of the Company’s financial assets measured at fair value as of September 30, 2015:

[0000926326-15-000035:notes:35]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Money market funds | $ | 40,108 |  |  | $ | — |  |  | $ | — |  |  | $ | 40,108 |  |
| Derivative contracts | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Total financial assets | $ | 40,108 |  |  | $ | 17 |  |  | $ | — |  |  | $ | 40,125 |  |
| Contingent consideration liability | — |  |  | — |  |  | 5,572 |  |  | 5,572 |  |
| Total financial Liabilities | $ | — |  |  | $ | — |  |  | $ | 5,572 |  |  | $ | 5,572 |  |

[0000926326-15-000035:notes:36]
The significant unobservable inputs used in the fair value measurement of the contingent consideration classified as level 3 above are the achievement of booking targets and the discount rate. We did not hold any Level 3 assets or liabilities as of December 31, 2014.

[0000926326-15-000035:notes:37]
There have been no transfers between fair value measurement levels during the three and nine months ended September 30, 2015 and September 30, 2014.

[0000926326-15-000035:notes:38]
[same as prior period, unchanged from 0000926326-15-000028:notes:35]

[0000926326-15-000035:notes:39]
[same as prior period, unchanged from 0000926326-15-000028:notes:36]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000926326-15-000035:notes:40]
The cash and cash equivalents at September 30, 2015 and December 31, 2014 were as follows:

[0000926326-15-000035:notes:41]
|  | September 30, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Cash | $ | 17,649 |  |  | $ | 61,311 |  |
| Money market fund | 40,108 |  |  | 64,577 |  |
| Total cash and cash equivalents | $ | 57,757 |  |  | $ | 125,888 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-15-000035:notes:42]
[same as prior period, unchanged from 0000926326-15-000028:notes:39]

[0000926326-15-000035:notes:43]
Cash and cash equivalents as of September 30, 2015 and December 31, 2014 includes cash and money market funds, which have original maturities of three months or less.  Due to the short duration to maturity, the carrying value of such financial instruments approximates the estimated fair value.

[0000926326-15-000035:notes:44]
[same as prior period, unchanged from 0000926326-15-000028:notes:42]

[0000926326-15-000035:notes:45]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's foreign currency contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments. The Level 3 valuation inputs include the Company’s best estimate of what market participants would use in pricing the asset or liability at the measurement date. The inputs are unobservable in the market and significant to the instrument’s valuation.

[0000926326-15-000035:notes:46]
The Company had no financial liabilities measured at fair value at December 31, 2014.

[0000926326-15-000035:notes:47]
[same as prior period, unchanged from 0000926326-15-000028:notes:44]

[0000926326-15-000035:notes:48]
[same as prior period, unchanged from 0000926326-15-000028:notes:45]

[0000926326-15-000035:notes:49]
We operate in foreign countries, which exposes us to market risk associated with foreign currency exchange rate fluctuations between the U.S. dollar and various foreign currencies, the most significant of which is the British Pound and Euro. In order to manage foreign currency risk, we enter into foreign exchange forward contracts to mitigate risks associated with changes in spot exchange rates of mainly non-functional currency denominated assets or liabilities of our foreign subsidiaries.  In general, the market risk related to these contracts is offset by corresponding gains and losses on the hedged transactions. By working only with major banks and closely monitoring current market conditions, we seek to limit the risk that counterparties to these contracts may be unable to perform. The foreign exchange forward contracts are measured at fair value and reported as other current assets or accrued liabilities on the Condensed Consolidated Balance Sheets. The derivative instruments we use to hedge this exposure are not designated as hedges. Any gains or losses on the foreign exchange forward contracts are recognized in earnings as Other Income/Expense in the period incurred in the Condensed Consolidated Statements of Operations. We do not enter into derivative contracts for trading purposes.

[0000926326-15-000035:notes:50]
The aggregate notional amounts of our outstanding foreign exchange contracts as of September 30, 2015 were $1.8 million. The aggregate fair value of these outstanding foreign exchange contracts as of September 30, 2015 were less than $0.1 million. We did not have any outstanding foreign exchange contracts as of December 31, 2014.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-15-000035:notes:51]
[same as prior period, unchanged from 0000926326-15-000028:notes:48]

[0000926326-15-000035:notes:52]
[same as prior period, unchanged from 0000926326-15-000028:notes:49]

[0000926326-15-000035:notes:53]
The following table represents changes in the carrying amount of goodwill:

[0000926326-15-000035:notes:54]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2014 | $ | 28,543 |  |  | $ | 94,177 |  |  | $ | 122,720 |  |
| Goodwill acquired - Mach4 | 10,539 |  |  | — |  |  | 10,539 |  |
| Goodwill acquired - Avantec | 15,606 |  |  | — |  |  | 15,606 |  |
| Foreign currency exchange rate fluctuations | 194 |  |  | (332 | ) |  | (138 | ) |
| Net balance as of September 30, 2015 | $ | 54,882 |  |  | $ | 93,845 |  |  | $ | 148,727 |  |

[0000926326-15-000035:notes:55]
[same as prior period, unchanged from 0000926326-15-000028:notes:52]

[0000926326-15-000035:notes:56]
The carrying amounts of intangibles as of September 30, 2015 are as follows:

[0000926326-15-000035:notes:57]
|  | September 30, 2015 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 69,520 |  |  | $ | (10,317 | ) |  | $ | (355 | ) |  | $ | 58,848 |  |  | 5 - 30 |
| Acquired technology | 30,991 |  |  | (5,534 | ) |  | 14 |  |  | 25,471 |  |  | 3 - 20 |
| Trade names | 8,069 |  |  | (2,289 | ) |  | (6 | ) |  | 5,774 |  |  | 1 - 12 |
| Patents | 1,986 |  |  | (342 | ) |  | — |  |  | 1,644 |  |  | 2 - 20 |
| Backlog | 424 |  |  | (105 | ) |  | (14 | ) |  | 305 |  |  | 1.7 |
| Total intangibles assets, net | $ | 110,990 |  |  | $ | (18,587 | ) |  | $ | (361 | ) |  | $ | 92,042 |  |  |  |

[0000926326-15-000035:notes:58]
The carrying amounts of intangibles as of December 31, 2014 were as follows:

[0000926326-15-000035:notes:59]
|  | December 31, 2014 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
| Customer relationships | $ | 60,150 |  |  | $ | (7,596 | ) |  | $ | (323 | ) |  | $ | 52,231 |  |  | 5 - 30 |
| Acquired technology | 27,580 |  |  | (4,068 | ) |  | — |  |  | 23,512 |  |  | 3 - 20 |
| Trade names | 7,110 |  |  | (1,559 | ) |  | (17 | ) |  | 5,534 |  |  | 3 - 12 |
| Patents | 1,655 |  |  | (265 | ) |  | — |  |  | 1,390 |  |  | 2 - 20 |
| Total intangibles assets, net | $ | 96,495 |  |  | $ | (13,488 | ) |  | $ | (340 | ) |  | $ | 82,667 |  |  |  |

[0000926326-15-000035:notes:60]
Amortization expense of intangible assets was $2.0 million and $1.2 million for the three months ended September 30, 2015 and September 30, 2014, respectively, and $5.1 million and $3.3 million for the nine months ended September 30, 2015 and September 30, 2014, respectively.

[0000926326-15-000035:notes:61]
[same as prior period, unchanged from 0000926326-15-000028:notes:58]

[0000926326-15-000035:notes:62]
|  | September 30, 2015 |
| Year ended December 31, | (In thousands) |
| Remaining three months of 2015 | $ | 1,919 |  |
| 2016 | 6,849 |  |
| 2017 | 6,034 |  |
| 2018 | 5,546 |  |
| 2019 | 5,262 |  |
| Thereafter | 66,432 |  |
| Total | $ | 92,042 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-15-000035:notes:63]
[same as prior period, unchanged from 0000926326-15-000028:notes:60]

[0000926326-15-000035:notes:64]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 39.3% and 40.5% for the nine months ended September 30, 2015 and September 30, 2014, respectively. The nine months ended September 30, 2015 and 2014 annual effective tax rate differed from the statutory rate of 35.0% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.

[0000926326-15-000035:notes:65]
We recorded a gain of $3.4 million attributable to the increase in the fair value of Omnicell's 15% minority interest in Avantec which was revalued in conjunction with our purchase of the remaining 85% of Avantec shares. This gain was treated as a discrete item and excluded from profit-before-tax in calculating the annual effective tax rate for the nine months ended September 30, 2015.

[0000926326-15-000035:notes:66]
The federal research and development credit law, which was extended through December 31, 2014, retroactively has not been extended to the end of 2015. As a result the annual effect tax rate for the nine months ended September 30, 2015 and 2014 did not consider the effect of the federal research and development tax credit.

[0000926326-15-000035:notes:67]
As of September 30, 2015 and December 31, 2014, the Company had gross unrecognized tax benefits of $7.1 million and $5.9 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in operating expense. As of September 30, 2015 and December 31, 2014, the amount of accrued interest and penalties was immaterial.

[0000926326-15-000035:notes:68]
As of September 30, 2015, the calendar years 2011 and thereafter are open and are subject to potential examination in one or more jurisdictions. However, because all of the net operating loss and research credit carryforwards that may be used in future years are subject to adjustment, if and when utilized, our federal and California tax years remain open from 1996 and 1992, respectively.  We have been contacted for audit by the Internal Revenue Service for tax years 2011, 2012 and 2013.

[0000926326-15-000035:notes:69]
Although we believe we have adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. It is not possible at this time to reasonably estimate changes in the unrecognized tax benefits within the next twelve months.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000926326-15-000035:notes:70]
[same as prior period, unchanged from 0000926326-15-000028:notes:64]

[0000926326-15-000035:notes:71]
[same as prior period, unchanged from 0000926326-15-000028:notes:65]

[0000926326-15-000035:notes:72]
On April 21, 2015, we completed the acquisition of Mach4, a privately held German limited liability company with its registered office in Bochum, Germany pursuant to a share purchase agreement (the “Mach4 Agreement”), under which Omnicell International, Inc., a wholly-owned subsidiary of Omnicell Inc., purchased the entire issued share capital of Mach4 (the “Mach4 Acquisition”).

[0000926326-15-000035:notes:73]
Mach4 manufactures robotic dispensing systems used by retail and hospital pharmacies and the Mach4 acquisition provides Omnicell with a more robust product offering that is intended to be leveraged to create opportunities to sell additional Omnicell medication cabinets. The robotic storage and dispensing product offering provides Omnicell with a solution to better compete for international market share.

[0000926326-15-000035:notes:74]
[same as prior period, unchanged from 0000926326-15-000028:notes:68]

[0000926326-15-000035:notes:75]
[same as prior period, unchanged from 0000926326-15-000028:notes:69]

[0000926326-15-000035:notes:76]
On April 30, 2015, we completed the acquisition of Avantec, the privately-held distributor of Omnicell’s products in the United Kingdom, pursuant to a share purchase agreement (the “Avantec Agreement”). Pursuant to the Avantec Agreement, we acquired the remaining 85% of issued and outstanding ordinary shares of Avantec that was not previously owned by the Company. Avantec develops medication and supply automation products that complement our solutions for configurations suited to the United Kingdom marketplace, and had been the exclusive distributor of our medication and supply automation solutions since 2005 in the United Kingdom.

[0000926326-15-000035:notes:77]
[same as prior period, unchanged from 0000926326-15-000028:notes:71]

[0000926326-15-000035:notes:78]
The fair value of the contingent consideration liability related to Avantec is revalued at each reporting date or more frequently if circumstances dictate. Changes in the fair value of this obligation are recorded as income or expense within other expense in our condensed consolidated statements of operation. The significant unobservable inputs used in the fair value measurement of the contingent consideration are the achievement of booking targets and the discount rate. Significant increases or decreases in any of those inputs in isolation would result in a significantly lower or higher fair value measurement.

[0000926326-15-000035:notes:79]
Prior to the Avantec Acquisition, we accounted for our 15% ownership interest in Avantec as an equity-method investment. The Avantec acquisition -date carrying book value of our previous equity interest was $1.3 million. This transaction was accounted for as a step acquisition, which required us to re-measure our previously held 15% ownership interest to fair value and record the difference between the fair value and carrying value as a gain. The fair value of the equity investment was determined to be $4.7 million which resulted in a gain of $3.4 million that was recorded in operating income in our Condensed Consolidated Statement of Operations in the three months ended June 30, 2015.

[0000926326-15-000035:notes:80]
Both of the above acquired companies are included in our Automation and Analytics segment.

[0000926326-15-000035:notes:81]
We accounted for the transactions above under the provisions of FASB Accounting Standards Codification ("ASC") Topic 805, Business Combinations. Accordingly, the estimated fair value of the consideration transferred to purchase the acquired companies is allocated to the assets acquired and the liabilities assumed based on their respective fair values. We have made significant estimates and assumptions in determining the allocation of the acquisition consideration.

[0000926326-15-000035:notes:82]
The purchase price allocations are subject to certain post-closing working capital adjustments for the acquired current assets and current liabilities of both acquisitions at their respective acquisition dates. The total consideration and the allocation of consideration to the individual net assets is preliminary, as there are remaining uncertainties to be resolved, including the settlement of the final net working capital adjustment for each.

[0000926326-15-000035:notes:83]
[same as prior period, unchanged from 0000926326-15-000028:notes:76]

[0000926326-15-000035:notes:84]
|  | Mach4 |  | Avantec |  | Total |
|  | (In thousands) |
| Cash | $ | 397 |  |  | $ | 3,392 |  |  | $ | 3,789 |  |
| Accounts receivable | 3,743 |  |  | 3,607 |  |  | 7,350 |  |
| Inventory | 3,580 |  |  | 1,428 |  |  | 5,008 |  |
| Deferred tax assets and other current assets | 368 |  |  | 89 |  |  | 457 |  |
| Total current assets | 8,088 |  |  | 8,516 |  |  | 16,604 |  |
| Property and equipment | 463 |  |  | — |  |  | 463 |  |
| Intangibles | 7,710 |  |  | 6,341 |  |  | 14,051 |  |
| Goodwill | 10,539 |  |  | 15,606 |  |  | 26,145 |  |
| Other non-current assets | 52 |  |  | — |  |  | 52 |  |
| Total assets | 26,852 |  |  | 30,463 |  |  | 57,315 |  |
| Current liabilities | 3,684 |  |  | 4,125 |  |  | 7,809 |  |
| Non-current deferred tax liabilities | 2,564 |  |  | 1,269 |  |  | 3,833 |  |
| Deferred service revenue and gross profit | 2,314 |  |  | 928 |  |  | 3,242 |  |
| Other non-current liabilities | 1,056 |  |  | — |  |  | 1,056 |  |
| Total purchase price | $ | 17,234 |  |  | $ | 24,141 |  |  | $ | 41,375 |  |
| Total purchase price, net of cash received | $ | 16,837 |  |  | $ | 20,749 |  |  | $ | 37,586 |  |

[0000926326-15-000035:notes:85]
[same as prior period, unchanged from 0000926326-15-000028:notes:78]

[0000926326-15-000035:notes:86]
[same as prior period, unchanged from 0000926326-15-000028:notes:79]

[0000926326-15-000035:notes:87]
|  | Mach4 | Avantec |
|  | Fair value |  | Weightedaverageuseful life | Fair value |  | Weightedaverageuseful life |
|  | (In thousands) |  | (In years) | (In thousands) |  | (In years) |
| Developed technology | $ | 3,290 |  |  | 8 | $ | — |  |  | — |
| Trade name | 850 |  |  | 6 | 92 |  |  | 2 |
| Customer relationships | 3,570 |  |  | 11-12 | 5,834 |  |  | 12 |
| Backlog | — |  |  | — | 415 |  |  | 2 |
| Total purchased intangible assets | $ | 7,710 |  |  |  | $ | 6,341 |  |  |  |

[0000926326-15-000035:notes:88]
Developed technology represents completed technology that has reached the technological feasibility and/or is currently offered for sale to Mach4 customers. The fair value is determined based on the relief from royalty method under the income approach, which requires us to estimate a reasonable royalty rate, identify relevant projected revenues and expenses, and select an appropriate discount rate. A royalty rate of 5.0% was used to value the developed technology. The after-tax cash flows were discounted to present value utilizing a 17.5% discount rate, which is based on our company-wide required return for this acquisition plus a discount of 1.5% to account for the unique riskiness of the asset. The developed technology had a fair value of $3.3 million and had an estimated economic life of eight years based on estimated technological obsolescence and is being amortized on an accelerated basis.

[0000926326-15-000035:notes:89]
Trade name represents the fair value brand recognition that was determined using the relief-from-royalty method under the income approach. A royalty rate of 1.0% and 2.0% was used to value the trade names of Avantec and Mach4, respectively. The value of trade names of $0.1 million for Avantec is being amortized on straight-line method and $0.9 million for Mach4 is being amortized on an accelerated basis.

[0000926326-15-000035:notes:90]
[same as prior period, unchanged from 0000926326-15-000028:notes:83]

[0000926326-15-000035:notes:91]
[same as prior period, unchanged from 0000926326-15-000028:notes:84]

[0000926326-15-000035:notes:92]
[same as prior period, unchanged from 0000926326-15-000028:notes:85]

[0000926326-15-000035:notes:93]
The following table presents certain unaudited pro forma information for illustrative purposes only, for fiscal 2015 and fiscal 2014 as if Mach4 and Avantec had been acquired on January 1, 2014. The unaudited estimated pro forma information combines the historical results of Mach4 and Avantec with our consolidated historical results and includes certain adjustments reflecting the estimated impact of fair value adjustments for the respective periods. The pro forma information is not indicative of what would have occurred had the acquisitions taken place on January 1, 2014. Additionally, the pro forma financial information does not include the impact of possible business model changes between Mach4, Avantec and the Company. We expect to achieve further business synergies, as a result of the acquisitions that are not reflected in the pro forma amounts that follow. As a result, actual results will differ from the unaudited pro forma information presented (in thousands, except per share


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-15-000035:notes:94]
Recently issued authoritative guidance

[0000926326-15-000035:notes:95]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers. Under the new guidance, an entity is required to recognize an amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The original effective date for the ASU would have required the Company to adopt the standard beginning in its first quarter of fiscal year 2017. In July 2015, the FASB voted to amend ASU No. 2014-09 by approving a one-year deferral of the effective date as well as providing the option to early adopt the standard on the original effective date. Accordingly, we may adopt the standard in its first quarter of fiscal year 2018. The new revenue guidance may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. We are currently evaluating the impact of the adoption of this accounting standard update on our consolidated financial position or results of operations.

[0000926326-15-000035:notes:96]
In July 2015, the FASB issued ASU No. 2015-11, Simplifying the Measurement of Inventory. The new guidance changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. It applies to entities that measure inventory using a method other than last-in, first-out (LIFO) and the retail inventory method (RIM). The new guidance will be effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years and should be applied prospectively. Early adoption is permitted as of the beginning of an interim or annual reporting period. We are currently evaluating the impact of the adoption of this accounting standard update on our consolidated financial position or results of operations.

[0000926326-15-000035:notes:97]
In September 2015, the FASB issued ASU No. 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments. This ASU requires adjustments to provisional amounts that are identified during the measurement period of a business combination to be recognized in the reporting period in which the adjustment amounts are determined. Acquirers are no longer required to revise comparative information for prior periods as if the accounting for the business combination had been completed as of the acquisition date. The provisions of ASU 2015-16 are effective for reporting periods beginning after December 15, 2015. We are currently evaluating the impact of the adoption of this accounting standard update on our consolidated financial position or results of operations.

[0000926326-15-000035:notes:98]
There was no other recently issued authoritative guidance that has a material impact on our Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0000926326-15-000035:notes:99]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards (RSAs) |  |  |  |
| Outstanding at December 31, 2014 | 36 |  |  | $ | 26.47 |  |
| Granted | 37 |  |  | 36.05 |  |
| Vested | (41 | ) |  | 26.47 |  |
| Forfeited | (1 | ) |  | 27.65 |  |
| Outstanding and unvested at September 30, 2015 | 31 |  |  | $ | 35.95 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-15-000035:notes:100]
[same as prior period, unchanged from 0000926326-15-000028:notes:91]

[0000926326-15-000035:notes:101]
[same as prior period, unchanged from 0000926326-15-000028:notes:92]

[0000926326-15-000035:notes:102]
[same as prior period, unchanged from 0000926326-15-000028:notes:93]

[0000926326-15-000035:notes:103]
[same as prior period, unchanged from 0000926326-15-000028:notes:94]

[0000926326-15-000035:notes:104]
[same as prior period, unchanged from 0000926326-15-000028:notes:95]

[0000926326-15-000035:notes:105]
[same as prior period, unchanged from 0000926326-15-000028:notes:96]

[0000926326-15-000035:notes:106]
As previously disclosed, since the first quarter of 2015, we modified the segment presentation to reflect the changes in how our Chief Operating Decision Maker (“CODM”) reviews the segments and the overall business. See Note 14, Segment Information, for additional information on our segment reporting change.

[0000926326-15-000035:notes:107]
[same as prior period, unchanged from 0000926326-15-000028:notes:98]

[0000926326-15-000035:notes:108]
[same as prior period, unchanged from 0000926326-15-000028:notes:99]

[0000926326-15-000035:notes:109]
[same as prior period, unchanged from 0000926326-15-000028:notes:100]

[0000926326-15-000035:notes:110]
Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there were no customers that accounted for more than 10% of our accounts receivable as of September 30, 2015 and December 31, 2014. We believe that we have no significant concentrations of credit risk as of September 30, 2015.

[0000926326-15-000035:notes:111]
[same as prior period, unchanged from 0000926326-15-000028:notes:102]

[0000926326-15-000035:notes:112]
There have been no material changes in our significant accounting policies for the three and nine months ended September 30, 2015, as compared to the significant accounting policies described in our annual report on Form 10-K for the year ended December 31, 2014.


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-15-000035:notes:113]
|  | September 30, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 11,027 |  |  | $ | 8,254 |  |
| Work in process | 2,238 |  |  | 64 |  |
| Finished goods | 36,195 |  |  | 23,236 |  |
| Total inventories | $ | 49,460 |  |  | $ | 31,554 |  |
| Property and equipment: |  |  |  |
| Equipment | $ | 44,448 |  |  | $ | 42,829 |  |
| Furniture and fixtures | 5,903 |  |  | 5,689 |  |
| Leasehold improvements | 9,064 |  |  | 8,701 |  |
| Purchased software | 29,770 |  |  | 28,920 |  |
| Construction in progress | 4,902 |  |  | 1,538 |  |
| Property and equipment, gross | 94,087 |  |  | 87,677 |  |
| Accumulated depreciation and amortization | (60,061 | ) |  | (51,499 | ) |
| Total property and equipment, net | $ | 34,026 |  |  | $ | 36,178 |  |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 24,838 |  |  | $ | 19,643 |  |
| Other assets | 2,133 |  |  | 3,630 |  |
| Total other long term assets, net | $ | 26,971 |  |  | $ | 23,273 |  |
| Accrued liabilities: |  |  |  |
| Rebates and lease buyouts | $ | 4,603 |  |  | $ | 6,512 |  |
| Advance payments from customers | 7,567 |  |  | 4,834 |  |
| Group purchasing organization fees | 3,437 |  |  | 3,475 |  |
| Taxes payable | 3,574 |  |  | 2,181 |  |
| Other accrued liabilities | 10,201 |  |  | 2,297 |  |
| Total accrued liabilities | $ | 29,382 |  |  | $ | 19,299 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0000926326-15-000035:notes:114]
[same as prior period, unchanged from 0000926326-15-000028:notes:105]

[0000926326-15-000035:notes:115]
|  | Three months ended |  | Nine months ended |
|  | September 30, 2015 |  | September 30, 2014 |  | September 30, 2015 |  | September 30, 2014 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 581 |  |  | $ | 441 |  |  | $ | 1,630 |  |  | $ | 973 |  |
| Research and development | 587 |  |  | 407 |  |  | 1,472 |  |  | 1,156 |  |
| Selling, general and administrative | 2,798 |  |  | 2,313 |  |  | 8,165 |  |  | 6,481 |  |
| Total share-based compensation expense | $ | 3,966 |  |  | $ | 3,161 |  |  | $ | 11,267 |  |  | $ | 8,610 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0000926326-15-000035:notes:116]
Restricted stock activity under the Company’s equity incentive plans in the nine months ended September 30, 2015 is as follows:

[0000926326-15-000035:notes:117]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units (RSUs) |  |  |  |  |  |  |  |
| Outstanding at December 31, 2014 | 399 |  |  | $ | 24.00 |  |  | 1.5 |  |  |
| Granted | 131 |  |  | 34.72 |  |  |  |  |  |
| Vested | (99 | ) |  | 21.51 |  |  |  |  |  |
| Forfeited | (29 | ) |  | 23.79 |  |  |  |  |  |
| Outstanding and unvested at September 30, 2015 | 402 |  |  | $ | 28.10 |  |  | 1.3 |  | $ | 12,503 |  |
| Expected to vest after September 30, 2015 | 392 |  |  |  |  | 1.2 |  | $ | 12,181 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-15-000035:notes:118]
[same as prior period, unchanged from 0000926326-15-000028:notes:109]

[0000926326-15-000035:notes:119]
|  | Three Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 102,967 |  |  | $ | 22,267 |  |  | $ | 125,234 |  |  | $ | 89,547 |  |  | $ | 22,996 |  |  | $ | 112,543 |  |
| Cost of revenues | 45,668 |  |  | 15,863 |  |  | 61,531 |  |  | 38,412 |  |  | 14,585 |  |  | 52,997 |  |
| Gross profit | 57,299 |  |  | 6,404 |  |  | 63,703 |  |  | 51,135 |  |  | 8,411 |  |  | 59,546 |  |
| Operating expenses | 30,628 |  |  | 6,070 |  |  | 36,698 |  |  | 27,420 |  |  | 4,822 |  |  | 32,242 |  |
| Income from segment operations | $ | 26,671 |  |  | $ | 334 |  |  | $ | 27,005 |  |  | $ | 23,715 |  |  | $ | 3,589 |  |  | $ | 27,304 |  |
| Corporate costs |  |  |  |  | 13,146 |  |  |  |  |  |  | 13,707 |  |
| Income from operations |  |  |  |  | $ | 13,859 |  |  |  |  |  |  | $ | 13,597 |  |

[0000926326-15-000035:notes:120]
|  | Nine Months Ended |
|  | September 30, 2015 |  | September 30, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 284,447 |  |  | $ | 69,796 |  |  | $ | 354,243 |  |  | $ | 255,748 |  |  | $ | 63,611 |  |  | $ | 319,359 |  |
| Cost of revenues | 123,923 |  |  | 47,470 |  |  | 171,393 |  |  | 109,344 |  |  | 39,934 |  |  | 149,278 |  |
| Gross profit | 160,524 |  |  | 22,326 |  |  | 182,850 |  |  | 146,404 |  |  | 23,677 |  |  | 170,081 |  |
| Operating expenses | 85,195 |  |  | 18,321 |  |  | 103,516 |  |  | 78,566 |  |  | 14,273 |  |  | 92,839 |  |
| Income from segment operations | $ | 75,329 |  |  | $ | 4,005 |  |  | $ | 79,334 |  |  | $ | 67,838 |  |  | $ | 9,404 |  |  | $ | 77,242 |  |
| Corporate costs |  |  |  |  | 42,672 |  |  |  |  |  |  | 41,133 |  |
| Income from operations |  |  |  |  | $ | 36,662 |  |  |  |  |  |  | $ | 36,109 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000926326-15-000035:notes:121]
The following table summarizes the stock option activity under the Company’s equity incentive plans during the nine months ended September 30, 2015:

[0000926326-15-000035:notes:122]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value(1) |
|  | (In thousands, except per share data) |
| Stock Options |  |  |  |  |  |  |  |
| Outstanding at December 31, 2014 | 2,672 |  |  | $ | 19.02 |  |  | 6.5 |  |  |
| Granted | 322 |  |  | 34.90 |  |  |  |  |  |
| Exercised | (494 | ) |  | 15.90 |  |  |  |  |  |
| Expired | (2 | ) |  | 15.72 |  |  |  |  |  |
| Forfeited | (81 | ) |  | 23.82 |  |  |  |  |  |
| Outstanding at September 30, 2015 | 2,417 |  |  | $ | 21.61 |  |  | 6.5 |  | $ | 24,341 |  |
| Exercisable at September 30, 2015 | 1,368 |  |  | $ | 16.73 |  |  | 4.8 |  | $ | 19,660 |  |
| Vested and expected to vest at September 30, 2015 and thereafter | 2,390 |  |  | $ | 21.50 |  |  | 6.4 |  | $ | 24,293 |  |

[0000926326-15-000035:notes:123]
| (1) | Intrinsic value is calculated as the difference between the market value or closing price of our common stock as of the last trading day of the period as reported by the NASDAQ Global Select Market, and the exercise price of the option. |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0000926326-15-000035:notes:124]
The following weighted average assumptions are used to value share options and Employee Stock Purchase Plan ("ESPP") shares issued pursuant to our equity incentive plans for the three and nine months ended September 30, 2015 and September 30, 2014:

[0000926326-15-000035:notes:125]
|  | Three months ended |  | Nine months ended |
|  | September 30, 2015 |  | September 30, 2014 |  | September 30, 2015 |  | September 30, 2014 |
|  | (In thousands, except percentages) |
| Stock Option Plans |  |  |  |  |  |  |  |
| Expected life, years | 5.04 |  |  | 4.81 |  |  | 5.04 |  |  | 4.80 |  |
| Expected volatility, % | 29.3 | % |  | 34.1 | % |  | 31.1 | % |  | 35.1 | % |
| Risk free interest rate, % | 1.73 | % |  | 1.70 | % |  | 1.63 | % |  | 1.56 | % |
| Estimated forfeiture rate % | 2.5 | % |  | 2.5 | % |  | 2.5 | % |  | 2.5 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-15-000035:notes:126]
|  | Three months ended |  | Nine months ended |
|  | September 30, 2015 |  | September 30, 2014 |  | September 30, 2015 |  | September 30, 2014 |
|  | (In thousands, except percentages) |
| Employee Stock Purchase Plan |  |  |  |  |  |  |  |
| Expected life, years | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |
| Expected volatility, % | 25.79-34.36% |  |  | 29.56-39.69% |  |  | 25.79-37.53% |  |  | 29.56-42.16% |  |
| Risk free interest rate, % | 0.12-0.79% |  |  | 0.03-0.53% |  |  | 0.03-0.79% |  |  | 0.03-0.53% |  |
| Estimated forfeiture rate % | — | % |  | — | % |  | — | % |  | — | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:ScheduleOfTreasuryStockByClassTextBlock

[0000926326-15-000035:notes:127]
[same as prior period, unchanged from 0000926326-15-000028:notes:118]

[0000926326-15-000035:notes:128]
|  | September 30, 2015 |  | December 31, 2014 |  |
|  | (In thousands, except per share data) |
| Total number of shares repurchased | 1,424 |  |  | 884 |  |  |
| Dollar amount of shares repurchased | $ | 50,020 |  |  | $ | 24,091 |  |  |
| Average price paid per share | $ | 35.13 |  |  | $ | 27.24 |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-15-000035:notes:129]
[same as prior period, unchanged from 0000926326-15-000028:notes:120]

[0000926326-15-000035:notes:130]
[same as prior period, unchanged from 0000926326-15-000028:notes:121]

[0000926326-15-000035:notes:131]
[same as prior period, unchanged from 0000926326-15-000028:notes:122]

[0000926326-15-000035:notes:132]
[same as prior period, unchanged from 0000926326-15-000028:notes:123]

[0000926326-15-000035:notes:133]
[same as prior period, unchanged from 0000926326-15-000028:notes:124]

[0000926326-15-000035:notes:134]
[same as prior period, unchanged from 0000926326-15-000028:notes:125]

[0000926326-15-000035:notes:135]
[same as prior period, unchanged from 0000926326-15-000028:notes:126]

[0000926326-15-000035:notes:136]
The Medication Adherence segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand name MTS Medication Technologies ("MTS"), Surgichem Limited ("Surgichem"), and under the Omnicell and SureMed brands. MTS products consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care, and correctional facilities or retail pharmacies serving patients in their local communities.

[0000926326-15-000035:notes:137]
[same as prior period, unchanged from 0000926326-15-000028:notes:128]

[0000926326-15-000035:notes:138]
There were no customers that accounted for more than 10% of our total revenues for the three and nine months ended September 30, 2015 and three and nine months ended September 30, 2014.


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0000926326-15-000035:notes:139]
Performance-based restricted stock activity under our equity incentive plans in the nine months ended September 30, 2015 is as follows:

[0000926326-15-000035:notes:140]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Performance-based Restricted Stock Units (PSUs) |  |  |  |
| Outstanding at December 31, 2014 | 233 |  |  | $ | 17.96 |  |
| Granted | 60 |  |  | 29.56 |  |
| Vested | (70 | ) |  | 18.91 |  |
| Forfeited | (27 | ) |  | 14.69 |  |
| Outstanding and unvested at September 30, 2015 | 196 |  |  | $ | 21.63 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-15-000035:notes:141]
[same as prior period, unchanged from 0000926326-15-000028:notes:132]

[0000926326-15-000035:notes:142]
Stock based plans

[0000926326-15-000035:notes:143]
For a detailed explanation of our stock plans and subsequent changes please refer to Note 16, Employee Benefits and Stock-Based Compensation, of our Annual Report on Form 10-K for the year ended December 31, 2014, filed with the SEC on March 30, 2015.

[0000926326-15-000035:notes:144]
[same as prior period, unchanged from 0000926326-15-000028:notes:135]

[0000926326-15-000035:notes:145]
[same as prior period, unchanged from 0000926326-15-000028:notes:136]

[0000926326-15-000035:notes:146]
[same as prior period, unchanged from 0000926326-15-000028:notes:137]

[0000926326-15-000035:notes:147]
The weighted-average fair value per share of options granted during the three and nine months ended September 30, 2015, was $10.51 and $10.57, respectively, and the weighted-average fair value per share of options granted during the three and nine months ended September 30, 2014 was $8.51 and $8.78, respectively. The intrinsic value of options exercised during the three and nine months ended September 30, 2015 was $3.1 million and $9.7 million, respectively. The intrinsic value of options exercised during the three and nine months ended September 30, 2014 was $2.5 million and $10.4 million, respectively.

[0000926326-15-000035:notes:148]
As of September 30, 2015, total unrecognized compensation cost related to unvested stock options was $9.0 million, which is expected to be recognized over a weighted-average vesting period of 2.7 years.

[0000926326-15-000035:notes:149]
[same as prior period, unchanged from 0000926326-15-000028:notes:140]

[0000926326-15-000035:notes:150]
The weighted-average grant date fair value per share of RSUs granted during the nine months ended September 30, 2015  and September 30, 2014 was $34.72 and and $25.16,  respectively.

[0000926326-15-000035:notes:151]
As of September 30, 2015, total unrecognized compensation expense related to RSUs was $9.3 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.4 years.

[0000926326-15-000035:notes:152]
The weighted-average grant date fair value per share of RSAs granted during the nine months ended September 30, 2015 was and $36.05.

[0000926326-15-000035:notes:153]
As of September 30, 2015, total unrecognized compensation cost related to RSAs was $0.7 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.7 years.

[0000926326-15-000035:notes:154]
Performance-based restricted stock unit activity

[0000926326-15-000035:notes:155]
The weighted-average grant date fair value per share of PSUs granted during the nine months ended September 30, 2015 and September 30, 2014 was $29.56 and $14.36, respectively. The total fair value of PSUs that vested during the nine months ended September 30, 2015 and September 30, 2014 was $2.6 million and $2.1 million, respectively.

[0000926326-15-000035:notes:156]
As of September 30, 2015, total unrecognized compensation cost related to PSUs was approximately $2.0 million, which is expected to be recognized over the remaining weighted-average period of 1.1 years.

[0000926326-15-000035:notes:157]
[same as prior period, unchanged from 0000926326-15-000028:notes:148]

[0000926326-15-000035:notes:158]
The unrecognized compensation cost related to the shares to be purchased under our ESPP was approximately $2.1 million as of September 30, 2015, and is expected to be recognized over a weighted-average period of 0.1 years.

[0000926326-15-000035:notes:159]
[same as prior period, unchanged from 0000926326-15-000028:notes:150]


## us-gaap:SubsequentEventsTextBlock

[0000926326-15-000035:notes:160]
Subsequent Events

[0000926326-15-000035:notes:161]
On October 29, 2015, we entered into a securities purchase agreement (the “Securities Purchase Agreement”) with Aesynt Holding, L.P., Aesynt, Ltd. (together with Aesynt Holding, L.P., the “Sellers”) and Aesynt Coöperatief U.A. (“Aesynt”).  Pursuant to the terms and conditions of the Securities Purchase Agreement, we will acquire from the Sellers, and the Sellers will sell to Omnicell, all of the outstanding interests of Aesynt on the closing date (such acquisition, the “Aesynt Acquisition”). Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, IV sterile preparation robotics and software, including software related to medication management. The contemplated total aggregate consideration is $275.0 million, in cash, plus cash on hand at signing minus indebtedness at close, or approximately $217.5 million, subject to certain adjustments at closing as provided for in the Securities Purchase Agreement. The closing of the acquisition is subject to certain closing conditions, including the expiration or termination of the applicable waiting period under the Hart-Scott-Rodino Antitrust Improvement Act ("HSR") of 1976, as amended.

[0000926326-15-000035:notes:162]
In connection with the Securities Purchase Agreement, we entered into a commitment letter with Wells Fargo Bank, National Association (“Wells Fargo Bank”) and Wells Fargo Securities, LLC (“Wells Fargo Securities” and, together with Wells Fargo Bank, the “Commitment Parties”) on October 29, 2015, pursuant to which Wells Fargo Bank has committed to provide $300.0 million of senior secured credit facilities consisting of (a) a $200.0 million term loan facility, and (b) a $100.0 million revolving credit facility (collectively, the “Senior Credit Facilities”), a portion of which, together with our existing cash on hand, would be used to (i) refinance the loans under our existing senior secured credit facility, if any, and Aesynt’s existing senior secured credit facility, (ii) pay the purchase price for the Aesynt Acquisition, and (iii) pay any fees and expenses incurred in connection with any of the foregoing. The commitment to provide the loans under the Senior Credit Facilities is subject to certain conditions, including the negotiation of definitive documentation for the Senior Credit Facilities and other customary closing conditions.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-15-000035:notes:163]
[same as prior period, unchanged from 0000926326-15-000028:notes:151]


## us-gaap:TreasuryStockTextBlock

[0000926326-15-000035:notes:164]
[same as prior period, unchanged from 0000926326-15-000028:notes:152]

[0000926326-15-000035:notes:165]
In August 2012, our Board of Directors authorized a program (the "2012 Stock Repurchase Program") to repurchase up to $50.0 million of common stock, of which approximately $45.1 million had been repurchased as of December 31, 2014, and the remaining $4.9 million has been repurchased as of the second quarter of 2015 and the 2012 Stock Repurchase Program was concluded. In November 2014, our Board of Directors authorized a program (the "2014 Stock Repurchase Program") to repurchase up to $50.0 million of common stock of which approximately $45.1 million had been repurchased as of September 30, 2015. The 2014 Stock Repurchase Program has a total of $4.9 million remaining for future repurchases as of September 30, 2015, and the program has no expiration date.

[0000926326-15-000035:notes:166]
During the nine months ended September 30, 2015, we repurchased approximately 1,424 thousand shares under our stock repurchase programs.
