# OMCL note change history — 0000926326-22-000033 → 0000926326-23-000014


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2023-05-05):
[0000926326-22-000033:note_history:1]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceeding described above based on its belief that any potential material loss, while reasonably possible, is not probable. Further, any possible range of loss in this matter cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to the legal proceeding pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of the legal proceeding or because of the diversion of management’s attention and the creation of significant expenses.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000926326-23-000014:note_history:2]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2023, the Company had non-cancelable purchase commitments of $122.2 million, of which $110.0 million are expected to be paid within the year ending December 31, 2023.
  (was, 2022-11-04, similarity 0.9747):
[0000926326-22-000033:note_history:2]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2022, the Company had non-cancelable purchase commitments of $186.9 million, of which $115.9 million are expected to be paid within the year ending December 31, 2022.

- added (2023-05-05):
[0000926326-23-000014:note_history:3]
During the three months ended March 31, 2023, the Company did not incur any material expenses related to the previously disclosed ransomware incident. As of March 31, 2023, the Company has incurred $13.6 million of cumulative expenses related to the ransomware incident since it was detected, partially offset by $11.1 million of insurance recoveries, of

- added (2023-05-05):
[0000926326-23-000014:note_history:4]
which $9.6 million have been received as of March 31, 2023. Expenses included costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred.

- added (2023-05-05):
[0000926326-23-000014:note_history:5]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020, which was fully briefed, but the Court had not heard oral argument on the motion. The parties entered into a settlement agreement on January 25, 2022, (the “Settlement Agreement”). On February 1, 2022, the Court granted preliminary approval of the settlement. Following preliminary approval, plaintiff conducted discovery to identify class members and to determine the class size. Pursuant to the terms of the Settlement Agreement, and following class size discovery, the parties participated in non-binding mediation on November 21, 2022. A settlement was reached at the mediation and the parties executed an addendum to the Settlement Agreement (the “Addendum”) reflecting the changes to the original settlement terms. On November 30, 2022, the Court granted preliminary approval of the settlement contemplated by the Settlement Agreement, as amended by the Addendum. The Addendum required Omnicell to make a total settlement payment of $4.3 million. On April 6, 2023, the Court granted final approval of the settlement, including the Addendum, and entered judgment in the matter dismissing all claims against Omnicell with prejudice. The Company made its final required settlement payment installment on or before the April 21, 2023 due date.

- added (2023-05-05):
[0000926326-23-000014:note_history:6]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. Outside of the matter discussed above, the Company has not recorded any material accrual for contingent liabilities associated with its current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.

- added (2023-05-05):
[0000926326-23-000014:note_history:7]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company’s financial position or results of operations.

- removed (2023-05-05):
[0000926326-22-000033:note_history:8]
On May 4, 2022, the Company determined that certain of its information technology systems were affected by ransomware impacting certain internal systems. Upon detecting the security event, the Company took immediate steps designed to contain the incident and implement its business continuity plans to restore and support continued operations. The Company has contained the incident and restored substantially all of its critical information technology systems.

- removed (2023-05-05):
[0000926326-22-000033:note_history:9]
During the three months ended September 30, 2022, the Company incurred $1.0 million of expenses related to the ransomware incident, and during the nine months ended September 30, 2022, the Company incurred $13.5 million of expenses related to the ransomware incident, partially offset by $11.1 million of expected insurance recoveries. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred. For the three and nine months ended September 30, 2022, the Company included net expenses related to the ransomware incident in cost of revenues of $0.1 million and $0.3 million, respectively; in research and development of $0.2 million and $0.2 million, respectively; and in selling general and administrative expenses of $0.7 million and $1.9 million, respectively, in the Company’s Condensed Consolidated Statements of Operations.

- removed (2023-05-05):
[0000926326-22-000033:note_history:10]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court

- removed (2023-05-05):
[0000926326-22-000033:note_history:11]
subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020, which was fully briefed, but the Court had not heard oral argument on the motion. The parties entered into a settlement agreement on January 25, 2022, (the “Settlement Agreement”). On February 1, 2022, the Court granted preliminary approval of the settlement. Following preliminary approval, plaintiff conducted discovery to identify class members and to determine the class size. Pursuant to the terms of the Settlement Agreement, and following class size discovery, the parties will participate in non-binding mediation, which is currently scheduled for November 21, 2022 to determine if the settlement will move forward. The Court has scheduled an interim status conference for November 30, 2022. Subject to final approval of the settlement, the Company intends to defend the lawsuit vigorously.

- removed (2023-05-05):
[0000926326-22-000033:note_history:12]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceeding described above based on its belief that any potential material loss, while reasonably possible, is not probable. Further, any possible range of loss in this matter cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to the legal proceeding pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of the legal proceeding or because of the diversion of management’s attention and the creation of significant expenses.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000926326-23-000014:note_history:13]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2023 and December 31, 2022, and the results of operations, comprehensive income (loss), and cash flows for the three months ended March 31, 2023 and 2022. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on March 1, 2023, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations, comprehensive income (loss), and cash flows for the three months ended March 31, 2023 are not necessarily indicative of results that may be expected for the year ending December 31, 2023, or for any future period.
  (was, 2022-11-04, similarity 0.8804):
[0000926326-22-000033:note_history:13]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2022 and December 31, 2021, the results of operations and comprehensive income for the three and nine months ended September 30, 2022 and 2021, and cash flows for the nine months ended September 30, 2022 and 2021. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2022, and cash flows for the nine months ended September 30, 2022 are not necessarily indicative of results that may be expected for the year ending December 31, 2022, or for any future period.

- changed (2023-05-05):
[0000926326-23-000014:note_history:14]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of March 31, 2023, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.
  (was, 2022-11-04, similarity 0.981):
[0000926326-22-000033:note_history:14]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of September 30, 2022, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

- added (2023-05-05):
[0000926326-23-000014:note_history:15]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The update addresses diversity in practice by requiring that an acquirer recognize and measure contract assets and liabilities acquired in a business combination in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company adopted ASU 2021-08 beginning January 1, 2023 and will apply the guidance prospectively to acquisitions occurring on or after the adoption date.

- changed (2023-05-05):
[0000926326-23-000014:note_history:16]
There was no recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.
  (was, 2022-11-04, similarity 0.9558):
[0000926326-22-000033:note_history:16]
No other recently issued and effective authoritative guidance is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.

- removed (2023-05-05):
[0000926326-22-000033:note_history:17]
On January 10, 2022, the Company completed its acquisition of Hub and Spoke Innovations Limited (“Hub and Spoke Innovations”). The Condensed Consolidated Financial Statements include the results of operations of this recently acquired company, commencing as of the acquisition date. The significant accounting policies of the acquired business have been aligned to conform to the accounting policies of Omnicell.

- removed (2023-05-05):
[0000926326-22-000033:note_history:18]
In August 2020, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method is no longer permitted for convertible instruments. This update permits the use of either the modified retrospective or fully retrospective method of transition. The Company adopted ASU 2020-06 on January 1, 2022, using the modified retrospective method of transition. Upon adoption of ASU 2020-06, the previously separated equity component and associated debt issuance costs for the Company’s outstanding convertible senior notes were reclassified to the liability component, thereby eliminating the subsequent amortization of the debt discount as interest expense. In addition, the Company derecognized the deferred tax liability related to the equity component.

- removed (2023-05-05):
[0000926326-22-000033:note_history:19]
In December 2021, the Company made an irrevocable election under the indenture to require the principal portion of the Company’s convertible senior notes to be settled in cash and any conversion consideration in excess of the principal portion in cash and/or shares of the Company’s common stock at the Company’s option upon conversion. Following the irrevocable election, only the amounts expected to be settled in excess of the principal portion are considered dilutive in calculating earnings per share under the if-converted method.

- removed (2023-05-05):
[0000926326-22-000033:note_history:20]
The Company’s adoption of the update impacted the Condensed Consolidated Balance Sheets at the beginning of the period of adoption as follows:

- removed (2023-05-05):
[0000926326-22-000033:note_history:21]
|  | January 1, 2022 |
|  | Pre-ASU 2020-06 Balances |  | ASU 2020-06 Adoption Impact |  | Post-ASU 2020-06 Balances |
|  | (In thousands) |
| Long-term deferred tax assets | $ | 15,883 |  |  | $ | (452) |  |  | $ | 15,431 |  |
| Convertible senior notes, net | 488,152 |  |  | 75,353 |  |  | 563,505 |  |
| Long-term deferred tax liabilities | 51,705 |  |  | (19,572) |  |  | 32,133 |  |
| Additional paid-in capital | 1,024,580 |  |  | (72,742) |  |  | 951,838 |  |
| Retained earnings | 368,571 |  |  | 16,509 |  |  | 385,080 |  |

- removed (2023-05-05):
[0000926326-22-000033:note_history:22]
Adoption of the update did not have an impact on the Company’s Condensed Consolidated Statements of Operations or Condensed Consolidated Statements of Cash Flows as of January 1, 2022. Refer to Note 10, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.

- removed (2023-05-05):
[0000926326-22-000033:note_history:23]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The update addresses diversity in practice by requiring that an acquirer recognize and measure contract assets and liabilities acquired in a business combination in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The guidance will be applied prospectively to acquisitions occurring on or after the effective date. ASU 2021-08 will be effective for the Company beginning January 1, 2023, and early adoption is permitted. The Company is currently evaluating the impact ASU 2021-08 will have on its Condensed Consolidated Financial Statements.


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000926326-23-000014:note_history:24]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2023 and 2022:
  (was, 2022-11-04, similarity 0.9022):
[0000926326-22-000033:note_history:24]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2022 and 2021:

- added (2023-05-05):
[0000926326-23-000014:note_history:25]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 771 |  |  | $ | 764 |  |  |  |  |  |

- removed (2023-05-05):
[0000926326-22-000033:note_history:26]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 (1) |  | 2021 |  | 2022 (1) |  | 2021 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of discount | $ | — |  |  | $ | 4,679 |  |  | $ | — |  |  | $ | 13,874 |  |
| Amortization of debt issuance costs | $ | 768 |  |  | $ | 589 |  |  | $ | 2,298 |  |  | $ | 1,747 |  |

- removed (2023-05-05):
[0000926326-22-000033:note_history:27]
_________________________________________________

- removed (2023-05-05):
[0000926326-22-000033:note_history:28]
(1)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000926326-23-000014:note_history:29]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2023 and December 31, 2022:
  (was, 2022-11-04, similarity 0.963):
[0000926326-22-000033:note_history:29]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2022 and December 31, 2021:

- added (2023-05-05):
[0000926326-23-000014:note_history:30]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (7,658) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 567,342 |  |  | $ | 566,571 |  |

- removed (2023-05-05):
[0000926326-22-000033:note_history:31]
|  | September 30,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (9,197) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 565,803 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |

- removed (2023-05-05):
[0000926326-22-000033:note_history:32]
_________________________________________________

- removed (2023-05-05):
[0000926326-22-000033:note_history:33]
(1)    Classified as a long-term liability as of September 30, 2022, and a current liability as of December 31, 2021, in the Condensed Consolidated Balance Sheets.

- removed (2023-05-05):
[0000926326-22-000033:note_history:34]
(2)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000926326-23-000014:note_history:35]
On September 22, 2020, the parties entered into a first amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter. The availability of funds under the Revolving Credit Facility can be subject to reduction in order to maintain compliance with the financial covenants under the A&R Credit Agreement.
  (was, 2022-11-04, similarity 0.8771):
[0000926326-22-000033:note_history:35]
On September 22, 2020, the parties entered into an amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

- added (2023-05-05):
[0000926326-23-000014:note_history:36]
On March 29, 2023, the parties entered into a second amendment to the A&R Credit Agreement to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York (including a customary credit spread

- added (2023-05-05):
[0000926326-23-000014:note_history:37]
adjustment of 0.10% per annum) and related SOFR-based mechanics. The replacement of LIBOR did not, and the Company does not anticipate that it will, materially impact its liquidity or financial position.

- changed (2023-05-05):
[0000926326-23-000014:note_history:38]
Following the second amendment to the A&R Credit Agreement, loans under the Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the A&R Credit Agreement), plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) Adjusted Term SOFR for a one month tenor plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. The applicable margin for, and certain other terms of, any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.
  (was, 2022-11-04, similarity 0.842):
[0000926326-22-000033:note_history:38]
Loans under the Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. The applicable margin for, and certain other terms of, any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

- changed (2023-05-05):
[0000926326-23-000014:note_history:39]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in compliance with all covenants as of March 31, 2023.
  (was, 2022-11-04, similarity 0.996):
[0000926326-22-000033:note_history:39]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in compliance with all covenants as of September 30, 2022.

- changed (2023-05-05):
[0000926326-23-000014:note_history:40]
As of March 31, 2023 and December 31, 2022, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025
  (was, 2022-11-04, similarity 0.9515):
[0000926326-22-000033:note_history:40]
As of each of September 30, 2022 and December 31, 2021, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- changed (2023-05-05):
[0000926326-23-000014:note_history:41]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.
  (was, 2022-11-04, similarity 0.882):
[0000926326-22-000033:note_history:41]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank

- added (2023-05-05):
[0000926326-23-000014:note_history:42]
During the three months ended March 31, 2023 and December 31, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the second quarter of 2023, commencing on April 1, 2023, and were not convertible during the first quarter of 2023, commencing on January 1, 2023, respectively. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of both March 31, 2023 and December 31, 2022. Whether the Notes will be convertible following the second fiscal quarter of 2023 will depend on the satisfaction of the conversion conditions in the future.

- changed (2023-05-05):
[0000926326-23-000014:note_history:43]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2023, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2022-11-04, similarity 0.9854):
[0000926326-22-000033:note_history:43]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2022, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- added (2023-05-05):
[0000926326-23-000014:note_history:44]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of March 31, 2023, the remaining life of the Notes and the related issuance cost accretion is approximately 2.5 years.

- changed (2023-05-05):
[0000926326-23-000014:note_history:45]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of March 31, 2023, the if-converted value of the Notes did not exceed the principal amount.
  (was, 2022-11-04, similarity 0.9738):
[0000926326-22-000033:note_history:45]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of September 30, 2022, the if-converted value of the Notes did not exceed the principal amount.

- changed (2023-05-05):
[0000926326-23-000014:note_history:46]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2023 and December 31, 2022:
  (was, 2022-11-04, similarity 0.963):
[0000926326-22-000033:note_history:46]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2022 and December 31, 2021:

- added (2023-05-05):
[0000926326-23-000014:note_history:47]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (7,658) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 567,342 |  |  | $ | 566,571 |  |

- changed (2023-05-05):
[0000926326-23-000014:note_history:48]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2023 and 2022:
  (was, 2022-11-04, similarity 0.9022):
[0000926326-22-000033:note_history:48]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2022 and 2021:

- added (2023-05-05):
[0000926326-23-000014:note_history:49]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 771 |  |  | $ | 764 |  |  |  |  |  |

- changed (2023-05-05):
[0000926326-23-000014:note_history:50]
In connection with the issuance of the Notes in September 2020, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.
  (was, 2022-11-04, similarity 0.9737):
[0000926326-22-000033:note_history:50]
In connection with the issuance of the Notes, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

- removed (2023-05-05):
[0000926326-22-000033:note_history:51]
National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

- removed (2023-05-05):
[0000926326-22-000033:note_history:52]
During the three months ended December 31, 2021, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on December 31, 2021, the last trading day of the respective fiscal quarter. Accordingly, the Notes were convertible during the first quarter of 2022 and were classified as a current liability in the Consolidated Financial Statements as of December 31, 2021. During the three months ended September 30, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the fourth quarter of 2022, commencing on October 1, 2022. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of September 30, 2022. Whether the Notes will be convertible following the fourth fiscal quarter of 2022 will depend on the satisfaction of the conversion conditions in the future.

- removed (2023-05-05):
[0000926326-22-000033:note_history:53]
Prior to the adoption of ASU 2020-06, convertible debt instruments that could be settled in cash were required to be separated into liability and equity components. The allocation to the liability component was based on the fair value of a similar instrument that did not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs were then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represented the debt discount, which the Company amortized to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions.

- removed (2023-05-05):
[0000926326-22-000033:note_history:54]
Upon adoption of ASU 2020-06, effective January 1, 2022, the Notes are no longer separated into liability and equity components, and are accounted for as a single liability measured at its amortized cost. Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information.

- removed (2023-05-05):
[0000926326-22-000033:note_history:55]
As of September 30, 2022, the remaining life of the Notes and the related issuance cost accretion is approximately 3.0 years.

- removed (2023-05-05):
[0000926326-22-000033:note_history:56]
|  | September 30,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (9,197) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 565,803 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |

- removed (2023-05-05):
[0000926326-22-000033:note_history:57]
_________________________________________________

- removed (2023-05-05):
[0000926326-22-000033:note_history:58]
(1)    Classified as a long-term liability as of September 30, 2022, and a current liability as of December 31, 2021, in the Condensed Consolidated Balance Sheets.

- removed (2023-05-05):
[0000926326-22-000033:note_history:59]
(2)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.

- removed (2023-05-05):
[0000926326-22-000033:note_history:60]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 (1) |  | 2021 |  | 2022 (1) |  | 2021 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of discount | $ | — |  |  | $ | 4,679 |  |  | $ | — |  |  | $ | 13,874 |  |
| Amortization of debt issuance costs | $ | 768 |  |  | $ | 589 |  |  | $ | 2,298 |  |  | $ | 1,747 |  |

- removed (2023-05-05):
[0000926326-22-000033:note_history:61]
_________________________________________________

- removed (2023-05-05):
[0000926326-22-000033:note_history:62]
(1)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-05-05):
[0000926326-22-000033:note_history:63]
Prior to the adoption of ASU 2020-06, convertible debt instruments that could be settled in cash were required to be separated into liability and equity components. The allocation to the liability component was based on the fair value of a similar instrument that did not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs were then allocated to the liability and equity components in a similar manner.Upon adoption of ASU 2020-06, effective January 1, 2022, the Notes are no longer separated into liability and equity components, and are accounted for as a single liability measured at its amortized cost.


## omcl:RevenueFromContractWithCustomerTimingAndClassificationOfRevenueCategoriesTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000926326-23-000014:note_history:64]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |
  (was, 2022-11-04, similarity 0.6554):
[0000926326-22-000033:note_history:64]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| SaaS, subscription software, and technology-enabled services |  |  |  | Over time, as services are provided |  | Service |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000926326-23-000014:note_history:65]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements. Solutions in this category include, but are not limited to, XT Series automated dispensing systems and products related to the Central Pharmacy Dispensing Service and IV Compounding Service.
  (was, 2022-11-04, similarity 0.8646):
[0000926326-22-000033:note_history:65]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements with multi-year co-development plans. Solutions in this category include, but are not limited to, XT Series automated dispensing systems, the XR2 Automated Central Pharmacy System, IVX Station and IV compounding automation solutions.

- changed (2023-05-05):
[0000926326-23-000014:note_history:66]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, are designed to improve patient engagement and adherence to prescriptions.
  (was, 2022-11-04, similarity 0.9939):
[0000926326-22-000033:note_history:66]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, and are designed to improve patient engagement and adherence to prescriptions.

- added (2023-05-05):
[0000926326-23-000014:note_history:67]
Advanced Services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.

- changed (2023-05-05):
[0000926326-23-000014:note_history:68]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |
  (was, 2022-11-04, similarity 0.6554):
[0000926326-22-000033:note_history:68]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| SaaS, subscription software, and technology-enabled services |  |  |  | Over time, as services are provided |  | Service |

- removed (2023-05-05):
[0000926326-22-000033:note_history:69]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, Specialty Pharmacy Services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IVX Station and IV compounding automation solutions.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000926326-23-000014:note_history:70]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements. Solutions in this category include, but are not limited to, XT Series automated dispensing systems and products related to the Central Pharmacy Dispensing Service and IV Compounding Service.
  (was, 2022-11-04, similarity 0.8646):
[0000926326-22-000033:note_history:70]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements with multi-year co-development plans. Solutions in this category include, but are not limited to, XT Series automated dispensing systems, the XR2 Automated Central Pharmacy System, IVX Station and IV compounding automation solutions.

- changed (2023-05-05):
[0000926326-23-000014:note_history:71]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, are designed to improve patient engagement and adherence to prescriptions.
  (was, 2022-11-04, similarity 0.9939):
[0000926326-22-000033:note_history:71]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, and are designed to improve patient engagement and adherence to prescriptions.

- added (2023-05-05):
[0000926326-23-000014:note_history:72]
Advanced Services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.

- changed (2023-05-05):
[0000926326-23-000014:note_history:73]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |
  (was, 2022-11-04, similarity 0.6554):
[0000926326-22-000033:note_history:73]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| SaaS, subscription software, and technology-enabled services |  |  |  | Over time, as services are provided |  | Service |

- changed (2023-05-05):
[0000926326-23-000014:note_history:74]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $3.1 million and $4.5 million for the three months ended March 31, 2023 and 2022, respectively.
  (was, 2022-11-04, similarity 0.9322):
[0000926326-22-000033:note_history:74]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $4.8 million and $4.4 million for the three months ended September 30, 2022 and 2021, respectively, and $13.3 million and $12.0 million for the nine months ended September 30, 2022 and 2021, respectively.

- changed (2023-05-05):
[0000926326-23-000014:note_history:75]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three months ended March 31, 2023 and 2022:
  (was, 2022-11-04, similarity 0.9288):
[0000926326-22-000033:note_history:75]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and nine months ended September 30, 2022 and 2021:

- added (2023-05-05):
[0000926326-23-000014:note_history:76]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 165,147 |  |  | $ | 208,078 |  |  |  |  |  |
| Consumables | 20,568 |  |  | 17,797 |  |  |  |  |  |
| Technical services | 53,357 |  |  | 49,169 |  |  |  |  |  |
| Advanced Services | 51,557 |  |  | 43,784 |  |  |  |  |  |
| Total revenues | $ | 290,629 |  |  | $ | 318,828 |  |  |  |  |  |

- changed (2023-05-05):
[0000926326-23-000014:note_history:77]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2023 and 2022:
  (was, 2022-11-04, similarity 0.9493):
[0000926326-22-000033:note_history:77]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2022 and 2021:

- changed (2023-05-05):
[0000926326-23-000014:note_history:78]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| United States | $ | 255,943 |  |  | $ | 287,577 |  |  |  |  |  |
| Rest of world (1) | 34,686 |  |  | 31,251 |  |  |  |  |  |
| Total revenues | $ | 290,629 |  |  | $ | 318,828 |  |  |  |  |  |
  (was, 2022-11-04, similarity 0.695):
[0000926326-22-000033:note_history:78]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| United States | $ | 315,755 |  |  | $ | 271,276 |  |  | $ | 898,269 |  |  | $ | 738,411 |  |
| Rest of world (1) | 32,304 |  |  | 25,126 |  |  | 100,004 |  |  | 82,573 |  |
| Total revenues | $ | 348,059 |  |  | $ | 296,402 |  |  | $ | 998,273 |  |  | $ | 820,984 |  |

- changed (2023-05-05):
[0000926326-23-000014:note_history:79]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 23,258 |  |  | $ | 25,763 |  |
| Long-term unbilled receivables, net (2) | 13,491 |  |  | 14,744 |  |
| Total contract assets | $ | 36,749 |  |  | $ | 40,507 |  |
| Short-term deferred revenues, net | $ | 143,298 |  |  | $ | 118,947 |  |
| Long-term deferred revenues | 42,438 |  |  | 37,385 |  |
| Total contract liabilities | $ | 185,736 |  |  | $ | 156,332 |  |
  (was, 2022-11-04, similarity 0.9817):
[0000926326-22-000033:note_history:79]
|  | September 30,2022 |  | December 31,2021 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 28,354 |  |  | $ | 17,208 |  |
| Long-term unbilled receivables, net (2) | 13,815 |  |  | 18,084 |  |
| Total contract assets | $ | 42,169 |  |  | $ | 35,292 |  |
| Short-term deferred revenues, net | $ | 113,925 |  |  | $ | 112,196 |  |
| Long-term deferred revenues | 34,519 |  |  | 20,194 |  |
| Total contract liabilities | $ | 148,444 |  |  | $ | 132,390 |  |

- added (2023-05-05):
[0000926326-23-000014:note_history:80]
Short-term deferred revenues of $143.3 million and $118.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $15.6 million and $15.8 million, as of March 31, 2023 and December 31, 2022, respectively. During the three months ended March 31, 2023, the Company recognized revenues of $55.5 million that were included in the corresponding gross short-term deferred revenues balance of $134.7 million as of December 31, 2022. Long-term deferred revenues include deferred revenues from product sales and service contracts of $42.4 million and $37.4 million as of March 31, 2023 and December 31, 2022, respectively. Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, where services have not yet been provided. Short-term deferred revenues are expected to be

- added (2023-05-05):
[0000926326-23-000014:note_history:81]
recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term service contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time.

- added (2023-05-05):
[0000926326-23-000014:note_history:82]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues are $199.2 million as of March 31, 2023. Remaining performance obligations are expected to be recognized ratably over the remaining term of the contract, which is generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

- changed (2023-05-05):
[0000926326-23-000014:note_history:83]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2023 and 2022. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2023 and December 31, 2022.
  (was, 2022-11-04, similarity 0.8115):
[0000926326-22-000033:note_history:83]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2022 and 2021. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of September 30, 2022 and December 31, 2021.

- removed (2023-05-05):
[0000926326-22-000033:note_history:84]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, Specialty Pharmacy Services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IVX Station and IV compounding automation solutions.

- removed (2023-05-05):
[0000926326-22-000033:note_history:85]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 226,415 |  |  | $ | 195,820 |  |  | $ | 650,125 |  |  | $ | 534,582 |  |
| Technical services | 53,914 |  |  | 53,529 |  |  | 156,386 |  |  | 156,321 |  |
| Consumables | 20,150 |  |  | 18,150 |  |  | 56,121 |  |  | 54,424 |  |
| SaaS, subscription software, and technology-enabled services | 47,580 |  |  | 28,903 |  |  | 135,641 |  |  | 75,657 |  |
| Total revenues | $ | 348,059 |  |  | $ | 296,402 |  |  | $ | 998,273 |  |  | $ | 820,984 |  |

- removed (2023-05-05):
[0000926326-22-000033:note_history:86]
Short-term deferred revenues of $113.9 million and $112.2 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.5 million and $22.4 million, as of September 30, 2022 and December 31, 2021, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and nine months ended September 30, 2022, the Company recognized revenues of $15.2 million and $104.2 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.6 million as of December 31, 2021.

- removed (2023-05-05):
[0000926326-22-000033:note_history:87]
Long-term deferred revenues include deferred revenues from product and service contracts of $34.5 million and $20.2 million as of September 30, 2022 and December 31, 2021, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.
