# OMCL 8-K — 0000926326-23-000011 filed 2023-05-02

## item codes, every 8-K on or before 2023-05-05

- 2023-05-02 0000926326-23-000011 — 2.02, 9.01
- 2023-04-03 0000926326-23-000009 — 1.01, 2.03, 9.01
- 2023-02-28 0001104659-23-026700 — 2.02, 2.05, 5.02, 9.01
- 2022-11-30 0000926326-22-000036 — 2.05
- 2022-11-02 0000926326-22-000031 — 2.02, 9.01
- 2022-10-21 0000926326-22-000029 — 5.03, 9.01
- 2022-09-20 0001104659-22-101566 — 7.01, 9.01
- 2022-09-20 0001104659-22-101360 — 7.01, 9.01
- 2022-08-04 0000926326-22-000025 — 2.02, 8.01, 9.01
- 2022-05-31 0000926326-22-000020 — 5.02, 5.07, 9.01
- 2022-05-24 0000926326-22-000016 — 5.02
- 2022-05-09 0000926326-22-000012 — 8.01
- 2022-04-28 0000926326-22-000009 — 2.02, 9.01
- 2022-03-01 0001104659-22-028681 — 5.02, 8.01, 9.01
- 2022-02-14 0000926326-22-000004 — 2.02, 9.01
- 2022-01-04 0000926326-22-000002 — 7.01, 9.01
- 2021-12-29 0001104659-21-154294 — 7.01, 9.01
- 2021-12-13 0000926326-21-000039 — 8.01
- 2021-12-02 0000926326-21-000037 — 7.01, 9.01
- 2021-11-02 0000926326-21-000031 — 2.02, 9.01
- 2021-09-09 0000926326-21-000028 — 7.01, 9.01
- 2021-07-29 0000926326-21-000024 — 2.02, 9.01
- 2021-07-26 0000926326-21-000022 — 7.01, 9.01
- 2021-07-12 0000926326-21-000019 — 5.02, 9.01
- 2021-05-28 0000926326-21-000015 — 5.07
- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2023-05-05

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-23-000011:8k_2_02:1]
EX-99.1
2
exhibit991q1-23.htm
EX-99.1

[0000926326-23-000011:8k_2_02:2]
Document

[0000926326-23-000011:8k_2_02:3]
Exhibit 99.1

[0000926326-23-000011:8k_2_02:4]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Senior Vice President, Investor Relations |  | 4220 North Freeway |
| 650-435-3318 |  | Fort Worth, TX 76137 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0000926326-23-000011:8k_2_02:5]
Omnicell Announces First Quarter 2023 Results

[0000926326-23-000011:8k_2_02:6]
Total GAAP revenues of $291 million

[0000926326-23-000011:8k_2_02:7]
GAAP net loss per diluted share of $0.33

[0000926326-23-000011:8k_2_02:8]
Non-GAAP net income per diluted share of $0.39

[0000926326-23-000011:8k_2_02:9]
FORT WORTH, Texas -- May 2, 2023 -- Omnicell, Inc. (NASDAQ:OMCL) (“Omnicell,” “we,” “our,” “us,” “management,” or the “Company”), a leader in transforming the pharmacy care delivery model, today announced results for its first quarter ended March 31, 2023.

[0000926326-23-000011:8k_2_02:10]
“We are pleased with the financial performance this quarter,” said Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell. “As our customers continue to navigate post-pandemic challenges, we believe delivering solutions that are designed to support optimized clinical and business outcomes are more important than ever. We remain confident that we are well-positioned to continue executing on our strategy and to drive long-term value for our stockholders and our healthcare partners and their patients.”

[0000926326-23-000011:8k_2_02:11]
Financial Results

[0000926326-23-000011:8k_2_02:12]
Total GAAP revenues for the first quarter of 2023 were $291 million, down $28 million, or 9%, from the first quarter of 2022. The year-over-year decrease in total GAAP revenues reflects lower point-of-care revenues as a result of ongoing health systems capital budget constraints.

[0000926326-23-000011:8k_2_02:13]
Total GAAP net loss for the first quarter of 2023 was $15 million, or $0.33 per diluted share. This compares to GAAP net income of $8 million, or $0.17 per diluted share, for the first quarter of 2022.

[0000926326-23-000011:8k_2_02:14]
Total non-GAAP net income for the first quarter of 2023 was $17 million, or $0.39 per diluted share. This compares to non-GAAP net income of $38 million, or $0.83 per diluted share, for the first quarter of 2022.

[0000926326-23-000011:8k_2_02:15]
Total non-GAAP EBITDA for the first quarter of 2023 was $27 million. This compares to non-GAAP EBITDA of $50 million for the first quarter of 2022.

[0000926326-23-000011:8k_2_02:16]
Balance Sheet

[0000926326-23-000011:8k_2_02:17]
As of March 31, 2023, Omnicell’s balance sheet reflected cash and cash equivalents of $340 million, total debt (net of unamortized debt issuance costs) of $567 million, and total assets of $2.25 billion. Cash flows provided by operating activities in the first quarter of 2023 totaled $13 million. This compares to cash flows used in operating activities totaling $16 million in the first quarter of 2022.

[0000926326-23-000011:8k_2_02:18]
As of March 31, 2023, the Company had $500 million of availability under its revolving credit facility, which availability is subject to reduction in order to maintain compliance with certain financial covenants under the revolving credit facility.

[0000926326-23-000011:8k_2_02:19]
Business Highlights

[0000926326-23-000011:8k_2_02:20]
•Strategic Alliance with Long Island University (LIU): Omnicell has co-launched the Center for Innovative Medication Management (CIMM) with LIU, an immersive pharmacy technology and analytics laboratory designed to provide LIU pharmacy students hands-on experience with innovative technology designed to support various functions

[0000926326-23-000011:8k_2_02:21]
within medication management. The CIMM will also be used by Omnicell to train Advanced Services operational teams, who will go on to support the Company’s technology at customer sites.

[0000926326-23-000011:8k_2_02:22]
•Publication of Omnicell’s 2022 ESG Report: In April 2023, Omnicell published its third annual ESG Report. The report highlights our continued commitment in the areas of Environmental, Social, Governance, and Innovation (ESG&I) by detailing our ESG&I initiatives and progress throughout 2022 toward our public goals and targets. As we strive to build a healthier world, we remain dedicated to furthering our ESG journey through purposeful action.

[0000926326-23-000011:8k_2_02:23]
2023 Guidance

[0000926326-23-000011:8k_2_02:24]
The Company’s full year 2023 guidance is unchanged. For the full year 2023, the Company expects bookings to be between $1.000 billion and $1.100 billion. The Company expects full year 2023 total revenues to be between $1.150 billion and $1.190 billion. The Company expects full year 2023 product revenues to be between $740 million and $760 million, and full year 2023 service revenues to be between $410 million and $430 million. The Company expects full year 2023 technical services revenues to be between $210 million and $220 million, and full year 2023 Advanced Services revenues to be between $200 million and $210 million. The Company expects full year 2023 non-GAAP EBITDA to be between $120 million and $135 million. The Company expects full year 2023 non-GAAP earnings per share to be between $1.55 and $1.80 per share.

[0000926326-23-000011:8k_2_02:25]
For the second quarter of 2023, the Company expects total revenues to be between $278 million and $288 million. The Company expects second quarter 2023 product revenues to be between $181 million and $186 million, and second quarter 2023 service revenues to be between $97 million and $102 million. The Company expects second quarter 2023 non-GAAP EBITDA to be between $22 million and $28 million. The Company expects second quarter 2023 non-GAAP earnings per share to be between $0.25 and $0.35 per share.

[0000926326-23-000011:8k_2_02:26]
The table below summarizes Omnicell’s second quarter and full year 2023 guidance outlined above.

[0000926326-23-000011:8k_2_02:27]
|  | Q2 2023 | 2023 |
| Bookings | Not provided | $1.000 billion - $1.100 billion |
| Total Revenues | $278 million - $288 million | $1.150 billion - $1.190 billion |
| Product Revenues | $181 million - $186 million | $740 million - $760 million |
| Service Revenues | $97 million - $102 million | $410 million - $430 million |
| Technical Services Revenues | Not provided | $210 million - $220 million |
| Advanced Services Revenues | Not provided | $200 million - $210 million |
| Non-GAAP EBITDA | $22 million - $28 million | $120 million - $135 million |
| Non-GAAP Earnings Per Share | $0.25 - $0.35 | $1.55 - $1.80 |

[0000926326-23-000011:8k_2_02:28]
The Company does not provide guidance for GAAP net income or GAAP earnings per share, nor a reconciliation of these forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures on a forward-looking basis because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These forward-looking non-GAAP financial measures do not include certain items, which may be significant, including, but not limited to, unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-23-000011:8k_2_02:29]
Omnicell Conference Call Information

[0000926326-23-000011:8k_2_02:30]
Omnicell will hold a conference call today, Tuesday, May 2, 2023 at 4:30 p.m. ET to discuss first quarter 2023 financial results. The conference call can be monitored by dialing 1-888-550-5424 within the U.S. or 1-646-960-0819 for all other locations. A link to the live and archived webcast will also be available on the Investor Relations section of Omnicell’s website at http://ir.omnicell.com/events-and-presentations/.

[0000926326-23-000011:8k_2_02:31]
__________________________________________________

[0000926326-23-000011:8k_2_02:32]
About Omnicell

[0000926326-23-000011:8k_2_02:33]
Since 1992, Omnicell has been committed to transforming the pharmacy care delivery model in an effort to optimize financial and clinical outcomes across all settings of care. Through a comprehensive portfolio of automation and advanced services, Omnicell is uniquely positioned to address evolving healthcare challenges, connect settings of care, and streamline the medication management process. Healthcare facilities worldwide partner with Omnicell to help increase operational efficiency, reduce medication errors, improve patient safety, and enhance patient engagement and adherence, helping to reduce costly hospital readmissions. To learn more, visit omnicell.com.

[0000926326-23-000011:8k_2_02:34]
From time to time, Omnicell may use the Company’s investor relations website and other online social media channels, including its Twitter handle www.twitter.com/omnicell, LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure (“Reg FD”).

[0000926326-23-000011:8k_2_02:35]
OMNICELL and the Omnicell logo are registered trademarks of Omnicell, Inc. or one of its subsidiaries.

[0000926326-23-000011:8k_2_02:36]
Forward-Looking Statements

[0000926326-23-000011:8k_2_02:37]
Use of Non-GAAP Financial Information

[0000926326-23-000011:8k_2_02:38]
This press release contains financial measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-

[0000926326-23-000011:8k_2_02:39]
3

[0000926326-23-000011:8k_2_02:40]
GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to revenues, gross profit, operating expenses, income from operations, net income, net income per diluted share, diluted shares, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results and metrics because management considers them to be important supplemental measures of Omnicell’s performance and refers to such measures when analyzing Omnicell’s strategy and operations.

[0000926326-23-000011:8k_2_02:41]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within such period that directly drive operating income in such period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results: non-GAAP revenues excludes from its GAAP equivalent item a) below; non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items a), b), c), and f) below; non-GAAP operating expenses excludes from its GAAP equivalents items b), c), d), e), and f) below; non-GAAP income from operations and non-GAAP operating margin exclude from their GAAP equivalents items a), b), c), d), e), and f) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through g) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents items a), b), d), e), f), and g) below:

[0000926326-23-000011:8k_2_02:42]
a)Acquisition accounting impact related to deferred revenues. In connection with the acquisition of FDS Amplicare on September 9, 2021, we recorded a fair value adjustment to acquired deferred revenues as part of the purchase accounting in accordance with GAAP. The adjustment represents revenues that would have been recognized in the normal course of business by FDS Amplicare if the acquisition had not occurred, but was not recognized due to GAAP purchase accounting requirements. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0000926326-23-000011:8k_2_02:43]
b)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as it represents expenses that do not require cash settlement from Omnicell.

[0000926326-23-000011:8k_2_02:44]
c)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-23-000011:8k_2_02:45]
d)Acquisition-related expenses. We excluded from our non-GAAP results the expenses related to recent acquisitions, including amortization of representations and warranties insurance. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of acquisition activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of less acquisitive peer companies.

[0000926326-23-000011:8k_2_02:46]
e)Impairment and abandonment of operating lease right-of-use and other assets related to facilities. We excluded from our non-GAAP results the impairment and abandonment of certain operating lease right-of-use assets, as well as property and equipment, incurred in connection with restructuring activities for optimization of certain leased facilities. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-23-000011:8k_2_02:47]
f)Severance-related expenses. We excluded from our non-GAAP results the expenses related to restructuring events. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-23-000011:8k_2_02:48]
g)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of term loan and revolving credit facilities, as well as the issuance of convertible senior notes. The costs include underwriting fees,

[0000926326-23-000011:8k_2_02:49]
original issue discount, ticking fees, and legal fees. These non-cash expenses are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-23-000011:8k_2_02:50]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving stock compensation plans or other items.

[0000926326-23-000011:8k_2_02:51]
We believe that the presentation of non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0000926326-23-000011:8k_2_02:52]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-23-000011:8k_2_02:53]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-23-000011:8k_2_02:54]
c)These non-GAAP financial measures are employed by management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting.

[0000926326-23-000011:8k_2_02:55]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-23-000011:8k_2_02:56]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-23-000011:8k_2_02:57]
i)While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-23-000011:8k_2_02:58]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-23-000011:8k_2_02:59]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0000926326-23-000011:8k_2_02:60]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-23-000011:8k_2_02:61]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-23-000011:8k_2_02:62]
a)Omnicell’s equity incentive plans and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-23-000011:8k_2_02:63]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-23-000011:8k_2_02:64]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-23-000011:8k_2_02:65]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release as well as in Omnicell’s other reports filed with or furnished to the SEC.

[0000926326-23-000011:8k_2_02:66]
6

[0000926326-23-000011:8k_2_02:67]
Omnicell, Inc.

[0000926326-23-000011:8k_2_02:68]
Condensed Consolidated Statements of Operations

[0000926326-23-000011:8k_2_02:69]
(Unaudited, in thousands, except per share data)

[0000926326-23-000011:8k_2_02:70]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 185,715 |  |  | $ | 225,875 |  |  |  |  |  |
| Services and other revenues | 104,914 |  |  | 92,953 |  |  |  |  |  |
| Total revenues | 290,629 |  |  | 318,828 |  |  |  |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 109,527 |  |  | 118,338 |  |  |  |  |  |
| Cost of services and other revenues | 56,073 |  |  | 50,443 |  |  |  |  |  |
| Total cost of revenues | 165,600 |  |  | 168,781 |  |  |  |  |  |
| Gross profit | 125,029 |  |  | 150,047 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 22,878 |  |  | 25,030 |  |  |  |  |  |
| Selling, general, and administrative | 125,114 |  |  | 119,933 |  |  |  |  |  |
| Total operating expenses | 147,992 |  |  | 144,963 |  |  |  |  |  |
| Income (loss) from operations | (22,963) |  |  | 5,084 |  |  |  |  |  |
| Interest and other income (expense), net | 1,781 |  |  | (114) |  |  |  |  |  |
| Income (loss) before benefit from income taxes | (21,182) |  |  | 4,970 |  |  |  |  |  |
| Benefit from income taxes | (6,182) |  |  | (3,243) |  |  |  |  |  |
| Net income (loss) | $ | (15,000) |  |  | $ | 8,213 |  |  |  |  |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.33) |  |  | $ | 0.19 |  |  |  |  |  |
| Diluted | $ | (0.33) |  |  | $ | 0.17 |  |  |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 44,887 |  |  | 44,249 |  |  |  |  |  |
| Diluted | 44,887 |  |  | 47,918 |  |  |  |  |  |

[0000926326-23-000011:8k_2_02:71]
Omnicell, Inc.

[0000926326-23-000011:8k_2_02:72]
Condensed Consolidated Balance Sheets

[0000926326-23-000011:8k_2_02:73]
(Unaudited, in thousands)

[0000926326-23-000011:8k_2_02:74]
|  | March 31,2023 |  | December 31,2022 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 340,413 |  |  | $ | 330,362 |  |
| Accounts receivable and unbilled receivables, net | 322,073 |  |  | 299,469 |  |
| Inventories | 141,156 |  |  | 147,549 |  |
| Prepaid expenses | 27,963 |  |  | 27,070 |  |
| Other current assets | 103,364 |  |  | 77,362 |  |
| Total current assets | 934,969 |  |  | 881,812 |  |
| Property and equipment, net | 98,373 |  |  | 93,961 |  |
| Long-term investment in sales-type leases, net | 32,744 |  |  | 32,924 |  |
| Operating lease right-of-use assets | 28,228 |  |  | 38,052 |  |
| Goodwill | 734,895 |  |  | 734,274 |  |
| Intangible assets, net | 234,689 |  |  | 242,906 |  |
| Long-term deferred tax assets | 29,562 |  |  | 22,329 |  |
| Prepaid commissions | 56,909 |  |  | 59,483 |  |
| Other long-term assets | 100,469 |  |  | 105,017 |  |
| Total assets | $ | 2,250,838 |  |  | $ | 2,210,758 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 63,407 |  |  | $ | 63,389 |  |
| Accrued compensation | 48,284 |  |  | 73,455 |  |
| Accrued liabilities | 198,979 |  |  | 172,655 |  |
| Deferred revenues, net | 143,298 |  |  | 118,947 |  |
| Total current liabilities | 453,968 |  |  | 428,446 |  |
| Long-term deferred revenues | 42,438 |  |  | 37,385 |  |
| Long-term deferred tax liabilities | 1,558 |  |  | 2,095 |  |
| Long-term operating lease liabilities | 36,855 |  |  | 39,405 |  |
| Other long-term liabilities | 6,136 |  |  | 6,719 |  |
| Convertible senior notes, net | 567,342 |  |  | 566,571 |  |
| Total liabilities | 1,108,297 |  |  | 1,080,621 |  |
| Total stockholders’ equity | 1,142,541 |  |  | 1,130,137 |  |
| Total liabilities and stockholders’ equity | $ | 2,250,838 |  |  | $ | 2,210,758 |  |

[0000926326-23-000011:8k_2_02:75]
8

[0000926326-23-000011:8k_2_02:76]
Omnicell, Inc.

[0000926326-23-000011:8k_2_02:77]
Condensed Consolidated Statements of Cash Flows

[0000926326-23-000011:8k_2_02:78]
(Unaudited, in thousands)

[0000926326-23-000011:8k_2_02:79]
|  | Three Months Ended March 31, |
|  | 2023 |  | 2022 |
| Operating Activities |  |  |  |
| Net income (loss) | $ | (15,000) |  |  | $ | 8,213 |  |
| Adjustments to reconcile net income (loss) to net cash provided by (used in) operating activities: |
| Depreciation and amortization | 21,974 |  |  | 21,124 |  |
| Loss on disposal of property and equipment | 802 |  |  | — |  |
| Share-based compensation expense | 14,042 |  |  | 16,208 |  |
| Deferred income taxes | (7,770) |  |  | (4,858) |  |
| Amortization of operating lease right-of-use assets | 2,248 |  |  | 3,307 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | 7,815 |  |  | 1,753 |  |
| Amortization of debt issuance costs | 1,045 |  |  | 1,038 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | (22,156) |  |  | (49,994) |  |
| Inventories | 6,760 |  |  | (17,320) |  |
| Prepaid expenses | (873) |  |  | (1,712) |  |
| Other current assets | 34 |  |  | 7,950 |  |
| Investment in sales-type leases | 613 |  |  | (1,097) |  |
| Prepaid commissions | 2,574 |  |  | 4,152 |  |
| Other long-term assets | 628 |  |  | 2,240 |  |
| Accounts payable | 20 |  |  | 312 |  |
| Accrued compensation | (25,171) |  |  | (23,859) |  |
| Accrued liabilities | (689) |  |  | 769 |  |
| Deferred revenues | 29,135 |  |  | 19,786 |  |
| Operating lease liabilities | (2,678) |  |  | (3,521) |  |
| Other long-term liabilities | (583) |  |  | (487) |  |
| Net cash provided by (used in) operating activities | 12,770 |  |  | (15,996) |  |
| Investing Activities |  |  |  |
| External-use software development costs | (3,499) |  |  | (3,852) |  |
| Purchases of property and equipment | (10,141) |  |  | (11,489) |  |
| Business acquisition, net of cash acquired | — |  |  | (3,392) |  |
| Net cash used in investing activities | (13,640) |  |  | (18,733) |  |
| Financing Activities |  |  |  |
| Proceeds from issuances under stock-based compensation plans | 12,114 |  |  | 18,951 |  |
| Employees’ taxes paid related to restricted stock units | (1,369) |  |  | (4,322) |  |
| Change in customer funds, net | (6,883) |  |  | 5,462 |  |
| Stock repurchases | — |  |  | (52,210) |  |
| Net cash provided by (used in) financing activities | 3,862 |  |  | (32,119) |  |
| Effect of exchange rate changes on cash and cash equivalents | 176 |  |  | (411) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | 3,168 |  |  | (67,259) |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 352,835 |  |  | 355,620 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 356,003 |  |  | $ | 288,361 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |
| Cash and cash equivalents | $ | 340,413 |  |  | $ | 265,008 |  |
| Restricted cash included in other current assets | 15,590 |  |  | 23,353 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 356,003 |  |  | $ | 288,361 |  |

[0000926326-23-000011:8k_2_02:80]
Omnicell, Inc.

[0000926326-23-000011:8k_2_02:81]
Reconciliation of GAAP to Non-GAAP

[0000926326-23-000011:8k_2_02:82]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-23-000011:8k_2_02:83]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Reconciliation of GAAP revenues to non-GAAP revenues: |
| GAAP revenues |  |  |  |  | $ | 290,629 |  |  | $ | 318,828 |  |
| Acquisition accounting impact related to deferred revenues |  |  |  |  | — |  |  | 378 |  |
| Non-GAAP revenues |  |  |  |  | $ | 290,629 |  |  | $ | 319,206 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit |  |  |  |  | $ | 125,029 |  |  | $ | 150,047 |  |
| GAAP gross margin |  |  |  |  | 43.0% |  | 47.1% |
| Share-based compensation expense |  |  |  |  | 2,008 |  |  | 2,244 |  |
| Amortization of acquired intangibles |  |  |  |  | 3,025 |  |  | 3,314 |  |
| Acquisition accounting impact related to deferred revenues |  |  |  |  | — |  |  | 378 |  |
| Severance-related expenses |  |  |  |  | 144 |  |  | 156 |  |
| Non-GAAP gross profit |  |  |  |  | $ | 130,206 |  |  | $ | 156,139 |  |
| Non-GAAP gross margin |  |  |  |  | 44.8% |  | 48.9% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses |  |  |  |  | $ | 147,992 |  |  | $ | 144,963 |  |
| GAAP operating expenses % to total revenues |  |  |  |  | 50.9% |  | 45.5% |
| Share-based compensation expense |  |  |  |  | (12,034) |  |  | (13,964) |  |
| Amortization of acquired intangibles |  |  |  |  | (5,217) |  |  | (5,739) |  |
| Acquisition-related expenses |  |  |  |  | (246) |  |  | (1,395) |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) |  |  |  |  | (8,420) |  |  | (1,753) |  |
| Severance-related expenses |  |  |  |  | (5,170) |  |  | (3,371) |  |
| Non-GAAP operating expenses |  |  |  |  | $ | 116,905 |  |  | $ | 118,741 |  |
| Non-GAAP operating expenses as a % of total non-GAAP revenues |  |  |  |  | 40.2% |  | 37.2% |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income from operations: |
| GAAP income (loss) from operations |  |  |  |  | $ | (22,963) |  |  | $ | 5,084 |  |
| GAAP operating income (loss) % to total revenues |  |  |  |  | (7.9)% |  | 1.6% |
| Share-based compensation expense |  |  |  |  | 14,042 |  |  | 16,208 |  |
| Amortization of acquired intangibles |  |  |  |  | 8,242 |  |  | 9,053 |  |
| Acquisition accounting impact related to deferred revenues |  |  |  |  | — |  |  | 378 |  |
| Acquisition-related expenses |  |  |  |  | 246 |  |  | 1,395 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) |  |  |  |  | 8,420 |  |  | 1,753 |  |
| Severance-related expenses |  |  |  |  | 5,314 |  |  | 3,527 |  |
| Non-GAAP income from operations |  |  |  |  | $ | 13,301 |  |  | $ | 37,398 |  |
| Non-GAAP operating margin (non-GAAP operating income as a % of total non-GAAP revenues) |  |  |  |  | 4.6% |  | 11.7% |

[0000926326-23-000011:8k_2_02:84]
10

[0000926326-23-000011:8k_2_02:85]
Omnicell, Inc.

[0000926326-23-000011:8k_2_02:86]
Reconciliation of GAAP to Non-GAAP

[0000926326-23-000011:8k_2_02:87]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-23-000011:8k_2_02:88]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2023 |  | 2022 |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |
| GAAP net income (loss) |  |  |  |  | $ | (15,000) |  |  | $ | 8,213 |  |
| Share-based compensation expense |  |  |  |  | 14,042 |  |  | 16,208 |  |
| Amortization of acquired intangibles |  |  |  |  | 8,242 |  |  | 9,053 |  |
| Acquisition accounting impact related to deferred revenues |  |  |  |  | — |  |  | 378 |  |
| Acquisition-related expenses |  |  |  |  | 246 |  |  | 1,395 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) |  |  |  |  | 8,420 |  |  | 1,753 |  |
| Severance-related expenses |  |  |  |  | 5,314 |  |  | 3,527 |  |
| Amortization of debt issuance costs |  |  |  |  | 1,045 |  |  | 1,038 |  |
| Tax effect of the adjustments above (b) |  |  |  |  | (4,886) |  |  | (3,601) |  |
| Non-GAAP net income |  |  |  |  | $ | 17,423 |  |  | $ | 37,964 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP |  |  |  |  | 44,887 |  |  | 47,918 |  |
| Shares - diluted non-GAAP (c) |  |  |  |  | 45,120 |  |  | 46,000 |  |
| GAAP net income (loss) per share - diluted |  |  |  |  | $ | (0.33) |  |  | $ | 0.17 |  |
| Share-based compensation expense |  |  |  |  | 0.31 |  |  | 0.35 |  |
| Amortization of acquired intangibles |  |  |  |  | 0.18 |  |  | 0.20 |  |
| Acquisition accounting impact related to deferred revenues |  |  |  |  | — |  |  | 0.01 |  |
| Acquisition-related expenses |  |  |  |  | 0.01 |  |  | 0.03 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities |  |  |  |  | 0.19 |  |  | 0.04 |  |
| Severance-related expenses |  |  |  |  | 0.12 |  |  | 0.08 |  |
| Amortization of debt issuance costs |  |  |  |  | 0.02 |  |  | 0.02 |  |
| Non-GAAP dilutive shares impact from convertible note hedge transaction (c) |  |  |  |  | — |  |  | 0.01 |  |
| Tax effect of the adjustments above (b) |  |  |  |  | (0.11) |  |  | (0.08) |  |
| Non-GAAP net income per share - diluted |  |  |  |  | $ | 0.39 |  |  | $ | 0.83 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP EBITDA(d): |
| GAAP net income (loss) |  |  |  |  | $ | (15,000) |  |  | $ | 8,213 |  |
| Share-based compensation expense |  |  |  |  | 14,042 |  |  | 16,208 |  |
| Interest (income) and expense, net |  |  |  |  | (3,074) |  |  | (33) |  |
| Depreciation and amortization expense |  |  |  |  | 21,974 |  |  | 21,124 |  |
| Acquisition accounting impact related to deferred revenues |  |  |  |  | — |  |  | 378 |  |
| Acquisition-related expenses |  |  |  |  | 246 |  |  | 1,395 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) |  |  |  |  | 8,420 |  |  | 1,753 |  |
| Severance-related expenses |  |  |  |  | 5,314 |  |  | 3,527 |  |
| Amortization of debt issuance costs |  |  |  |  | 1,045 |  |  | 1,038 |  |
| Benefit from income taxes |  |  |  |  | (6,182) |  |  | (3,243) |  |
| Non-GAAP EBITDA |  |  |  |  | $ | 26,785 |  |  | $ | 50,360 |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA as a % of total non-GAAP revenues) |  |  |  |  | 9.2% |  | 15.8% |

[0000926326-23-000011:8k_2_02:89]
_________________________________________________

[0000926326-23-000011:8k_2_02:90]
(a)For the three months ended March 31, 2023, impairment charges of other assets were approximately $0.6 million related to property and equipment in connection with restructuring activities for optimization of certain leased facilities.

[0000926326-23-000011:8k_2_02:91]
(b)Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2023 and 2022.

[0000926326-23-000011:8k_2_02:92]
(c)For the three months ended March 31, 2022, non-GAAP diluted shares excluded approximately 1.9 million shares related to the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction.

[0000926326-23-000011:8k_2_02:93]
(d)Defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments.

[0000926326-23-000011:8k_2_02:94]
Omnicell, Inc.

[0000926326-23-000011:8k_2_02:95]
Reconciliation of GAAP to Non-GAAP

[0000926326-23-000011:8k_2_02:96]
(Unaudited, in thousands)

[0000926326-23-000011:8k_2_02:97]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Reconciliation of GAAP net cash provided by (used in) operating activities to non-GAAP free cash flow: |
| GAAP net cash provided by (used in) operating activities | $ | 12,770 |  |  | $ | (15,996) |  |  |  |  |  |
| External-use software development costs | (3,499) |  |  | (3,852) |  |  |  |  |  |
| Purchases of property and equipment | (10,141) |  |  | (11,489) |  |  |  |  |  |
| Non-GAAP free cash flow | $ | (870) |  |  | $ | (31,337) |  |  |  |  |  |

[0000926326-23-000011:8k_2_02:98]
12
