# OMCL notes — 0000926326-23-000014


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-23-000014:notes:1]
[same as prior period, unchanged from 0000926326-22-000033:notes:1]

[0000926326-23-000014:notes:2]
[same as prior period, unchanged from 0000926326-22-000033:notes:2]

[0000926326-23-000014:notes:3]
[same as prior period, unchanged from 0000926326-22-000033:notes:3]

[0000926326-23-000014:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2023 and December 31, 2022, and the results of operations, comprehensive income (loss), and cash flows for the three months ended March 31, 2023 and 2022. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on March 1, 2023, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations, comprehensive income (loss), and cash flows for the three months ended March 31, 2023 are not necessarily indicative of results that may be expected for the year ending December 31, 2023, or for any future period.

[0000926326-23-000014:notes:5]
[same as prior period, unchanged from 0000926326-22-000033:notes:5]

[0000926326-23-000014:notes:6]
[same as prior period, unchanged from 0000926326-22-000033:notes:6]

[0000926326-23-000014:notes:7]
[same as prior period, unchanged from 0000926326-22-000033:notes:8]

[0000926326-23-000014:notes:8]
[same as prior period, unchanged from 0000926326-22-000033:notes:9]

[0000926326-23-000014:notes:9]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of March 31, 2023, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-23-000014:notes:10]
[same as prior period, unchanged from 0000926326-22-000033:notes:11]

[0000926326-23-000014:notes:11]
[same as prior period, unchanged from 0000926326-22-000033:notes:12]

[0000926326-23-000014:notes:12]
[same as prior period, unchanged from 0000926326-22-000033:notes:13]

[0000926326-23-000014:notes:13]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The update addresses diversity in practice by requiring that an acquirer recognize and measure contract assets and liabilities acquired in a business combination in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company adopted ASU 2021-08 beginning January 1, 2023 and will apply the guidance prospectively to acquisitions occurring on or after the adoption date.

[0000926326-23-000014:notes:14]
[same as prior period, unchanged from 0000926326-22-000033:notes:19]

[0000926326-23-000014:notes:15]
There was no recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-23-000014:notes:16]
[same as prior period, unchanged from 0000926326-22-000033:notes:51]

[0000926326-23-000014:notes:17]
[same as prior period, unchanged from 0000926326-22-000033:notes:52]

[0000926326-23-000014:notes:18]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements. Solutions in this category include, but are not limited to, XT Series automated dispensing systems and products related to the Central Pharmacy Dispensing Service and IV Compounding Service.

[0000926326-23-000014:notes:19]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, are designed to improve patient engagement and adherence to prescriptions.

[0000926326-23-000014:notes:20]
[same as prior period, unchanged from 0000926326-22-000033:notes:54]

[0000926326-23-000014:notes:21]
Advanced Services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.

[0000926326-23-000014:notes:22]
[same as prior period, unchanged from 0000926326-22-000033:notes:57]

[0000926326-23-000014:notes:23]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |

[0000926326-23-000014:notes:24]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $3.1 million and $4.5 million for the three months ended March 31, 2023 and 2022, respectively.

[0000926326-23-000014:notes:25]
[same as prior period, unchanged from 0000926326-22-000033:notes:60]

[0000926326-23-000014:notes:26]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three months ended March 31, 2023 and 2022:

[0000926326-23-000014:notes:27]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 165,147 |  |  | $ | 208,078 |  |  |  |  |  |
| Consumables | 20,568 |  |  | 17,797 |  |  |  |  |  |
| Technical services | 53,357 |  |  | 49,169 |  |  |  |  |  |
| Advanced Services | 51,557 |  |  | 43,784 |  |  |  |  |  |
| Total revenues | $ | 290,629 |  |  | $ | 318,828 |  |  |  |  |  |

[0000926326-23-000014:notes:28]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2023 and 2022:

[0000926326-23-000014:notes:29]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| United States | $ | 255,943 |  |  | $ | 287,577 |  |  |  |  |  |
| Rest of world (1) | 34,686 |  |  | 31,251 |  |  |  |  |  |
| Total revenues | $ | 290,629 |  |  | $ | 318,828 |  |  |  |  |  |

[0000926326-23-000014:notes:30]
_________________________________________________

[0000926326-23-000014:notes:31]
[same as prior period, unchanged from 0000926326-22-000033:notes:65]

[0000926326-23-000014:notes:32]
[same as prior period, unchanged from 0000926326-22-000033:notes:66]

[0000926326-23-000014:notes:33]
[same as prior period, unchanged from 0000926326-22-000033:notes:67]

[0000926326-23-000014:notes:34]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 23,258 |  |  | $ | 25,763 |  |
| Long-term unbilled receivables, net (2) | 13,491 |  |  | 14,744 |  |
| Total contract assets | $ | 36,749 |  |  | $ | 40,507 |  |
| Short-term deferred revenues, net | $ | 143,298 |  |  | $ | 118,947 |  |
| Long-term deferred revenues | 42,438 |  |  | 37,385 |  |
| Total contract liabilities | $ | 185,736 |  |  | $ | 156,332 |  |

[0000926326-23-000014:notes:35]
[same as prior period, unchanged from 0000926326-22-000033:notes:69]

[0000926326-23-000014:notes:36]
[same as prior period, unchanged from 0000926326-22-000033:notes:70]

[0000926326-23-000014:notes:37]
[same as prior period, unchanged from 0000926326-22-000033:notes:71]

[0000926326-23-000014:notes:38]
Short-term deferred revenues of $143.3 million and $118.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $15.6 million and $15.8 million, as of March 31, 2023 and December 31, 2022, respectively. During the three months ended March 31, 2023, the Company recognized revenues of $55.5 million that were included in the corresponding gross short-term deferred revenues balance of $134.7 million as of December 31, 2022. Long-term deferred revenues include deferred revenues from product sales and service contracts of $42.4 million and $37.4 million as of March 31, 2023 and December 31, 2022, respectively. Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, where services have not yet been provided. Short-term deferred revenues are expected to be

[0000926326-23-000014:notes:39]
recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term service contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time.

[0000926326-23-000014:notes:40]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues are $199.2 million as of March 31, 2023. Remaining performance obligations are expected to be recognized ratably over the remaining term of the contract, which is generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

[0000926326-23-000014:notes:41]
[same as prior period, unchanged from 0000926326-22-000033:notes:74]

[0000926326-23-000014:notes:42]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2023 and 2022. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2023 and December 31, 2022.


## us-gaap:EarningsPerShareTextBlock

[0000926326-23-000014:notes:43]
Net Income (Loss) Per Share
The basic and diluted net income (loss) per share calculations for the three months ended March 31, 2023 and 2022 were as follows:

[0000926326-23-000014:notes:44]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | (15,000) |  |  | $ | 8,213 |  |  |  |  |  |
| Weighted-average shares outstanding – basic | 44,887 |  |  | 44,249 |  |  |  |  |  |
| Effect of dilutive securities from stock award plans | — |  |  | 1,646 |  |  |  |  |  |
| Effect of convertible senior notes | — |  |  | 1,918 |  |  |  |  |  |
| Effect of warrants | — |  |  | 105 |  |  |  |  |  |
| Weighted-average shares outstanding – diluted | 44,887 |  |  | 47,918 |  |  |  |  |  |
| Net income (loss) per share – basic | $ | (0.33) |  |  | $ | 0.19 |  |  |  |  |  |
| Net income (loss) per share – diluted | $ | (0.33) |  |  | $ | 0.17 |  |  |  |  |  |
| Anti-dilutive weighted-average shares related to stock award plans | 3,634 |  |  | 336 |  |  |  |  |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | 11,816 |  |  | — |  |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-23-000014:notes:45]
Cash, Cash Equivalents, and Restricted Cash and Fair Value of Financial Instruments
Cash and cash equivalents of $340.4 million and $330.4 million, and restricted cash (inclusive of cash equivalents) of $15.6 million and $22.5 million, as of March 31, 2023 and December 31, 2022, respectively, consisted of bank accounts and highly-liquid U.S. Government money market funds held in sweep and asset management accounts with financial institutions of high credit quality.

[0000926326-23-000014:notes:46]
The following table reflects the Company’s cash equivalents and restricted cash equivalents, which consisted of money market funds held in sweep and asset management accounts:

[0000926326-23-000014:notes:47]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Cash equivalents (1) | $ | 321,230 |  |  | $ | 300,969 |  |
| Restricted cash equivalents (2) | 13,873 |  |  | — |  |
| Total cash equivalents and restricted cash equivalents | $ | 335,103 |  |  | $ | 300,969 |  |

[0000926326-23-000014:notes:48]
(1)    Included in cash and cash equivalents in the Condensed Consolidated Balance Sheets.

[0000926326-23-000014:notes:49]
(2)    Included in other current assets in the Condensed Consolidated Balance Sheets.

[0000926326-23-000014:notes:50]
Fair Value Hierarchy
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s credit facility is classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company’s convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. As of March 31, 2023 and December 31, 2022, the fair value of the convertible senior notes was $528.4 million and $501.4 million, respectively, compared to their carrying values of $567.3 million and $566.6 million, respectively, which are net of unamortized debt issuance costs. Refer to Note 9, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 10, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-23-000014:notes:51]
Balance Sheet Components
Balance sheet details as of March 31, 2023 and December 31, 2022 are presented in the tables below:

[0000926326-23-000014:notes:52]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 67,154 |  |  | $ | 75,854 |  |
| Work in process | 10,772 |  |  | 9,280 |  |
| Finished goods | 63,230 |  |  | 62,415 |  |
| Total inventories | $ | 141,156 |  |  | $ | 147,549 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 83,172 |  |  | $ | 56,703 |  |
| Net investment in sales-type leases, current portion | 11,053 |  |  | 11,486 |  |
| Prepaid income taxes | 112 |  |  | 1,702 |  |
| Other current assets | 9,027 |  |  | 7,471 |  |
| Total other current assets | $ | 103,364 |  |  | $ | 77,362 |  |
| Other long-term assets: |  |  |  |
| External-use software development costs, net | $ | 77,114 |  |  | $ | 80,760 |  |
| Unbilled receivables, net | 13,491 |  |  | 14,744 |  |
| Deferred debt issuance costs | 1,784 |  |  | 2,058 |  |
| Other long-term assets | 8,080 |  |  | 7,455 |  |
| Total other long-term assets | $ | 100,469 |  |  | $ | 105,017 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 10,875 |  |  | $ | 10,761 |  |
| Customer fund liabilities | 83,172 |  |  | 56,703 |  |
| Advance payments from customers | 11,753 |  |  | 11,556 |  |
| Rebate liabilities | 47,432 |  |  | 42,802 |  |
| Group purchasing organization fees | 5,790 |  |  | 7,723 |  |
| Taxes payable | 9,549 |  |  | 9,642 |  |
| Other accrued liabilities | 30,408 |  |  | 33,468 |  |
| Total accrued liabilities | $ | 198,979 |  |  | $ | 172,655 |  |

[0000926326-23-000014:notes:53]
(1)    Includes restricted cash of $15.6 million and $22.5 million as of March 31, 2023 and December 31, 2022, respectively.

[0000926326-23-000014:notes:54]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss), which consisted of foreign currency translation adjustments, for the three months ended March 31, 2023 and 2022:

[0000926326-23-000014:notes:55]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| Beginning balance | $ | (17,087) |  |  | $ | (8,407) |  |  |  |  |  |
| Other comprehensive income (loss) | 1,479 |  |  | (2,555) |  |  |  |  |  |
| Ending balance | $ | (15,608) |  |  | $ | (10,962) |  |  |  |  |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-23-000014:notes:56]
Property and Equipment
The following table represents the property and equipment balances as of March 31, 2023 and December 31, 2022:

[0000926326-23-000014:notes:57]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Equipment | $ | 94,546 |  |  | $ | 91,391 |  |
| Furniture and fixtures | 4,989 |  |  | 5,154 |  |
| Leasehold improvements | 18,828 |  |  | 19,510 |  |
| Purchased software and internal-use software development costs | 85,283 |  |  | 76,327 |  |
| Construction in progress | 26,861 |  |  | 28,223 |  |
| Property and equipment, gross | 230,507 |  |  | 220,605 |  |
| Accumulated depreciation and amortization | (132,134) |  |  | (126,644) |  |
| Total property and equipment, net | $ | 98,373 |  |  | $ | 93,961 |  |

[0000926326-23-000014:notes:58]
Depreciation and amortization expense of property and equipment was $6.3 million and $5.3 million for the three months ended March 31, 2023 and 2022, respectively.

[0000926326-23-000014:notes:59]
The geographic location of the Company’s property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of March 31, 2023 and December 31, 2022:

[0000926326-23-000014:notes:60]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| United States | $ | 94,472 |  |  | $ | 89,989 |  |
| Rest of world (1) | 3,901 |  |  | 3,972 |  |
| Total property and equipment, net | $ | 98,373 |  |  | $ | 93,961 |  |

[0000926326-23-000014:notes:61]
[same as prior period, unchanged from 0000926326-22-000033:notes:92]


## us-gaap:ResearchDevelopmentAndComputerSoftwareDisclosureTextBlock

[0000926326-23-000014:notes:62]
External-Use Software Development Costs
The carrying amounts of external-use software development costs as of March 31, 2023 and December 31, 2022 were as follows:

[0000926326-23-000014:notes:63]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Gross carrying amount | $ | 228,766 |  |  | $ | 225,004 |  |
| Accumulated amortization | (151,652) |  |  | (144,244) |  |
| External-use software development costs, net (1) | $ | 77,114 |  |  | $ | 80,760 |  |

[0000926326-23-000014:notes:64]
(1)     Included in other long-term assets in the Condensed Consolidated Balance Sheets.

[0000926326-23-000014:notes:65]
The Company recorded $7.4 million and $6.7 million to cost of revenues for amortization of external-use software development costs for the three months ended March 31, 2023 and 2022, respectively.

[0000926326-23-000014:notes:66]
The estimated future amortization expenses for external-use software development costs were as follows:

[0000926326-23-000014:notes:67]
|  | March 31,2023 |
|  | (In thousands) |
| Remaining nine months of 2023 | $ | 21,435 |  |
| 2024 | 23,544 |  |
| 2025 | 16,156 |  |
| 2026 | 10,617 |  |
| 2027 | 4,662 |  |
| Thereafter | 700 |  |
| Total | $ | 77,114 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-23-000014:notes:68]
[same as prior period, unchanged from 0000926326-22-000033:notes:93]

[0000926326-23-000014:notes:69]
[same as prior period, unchanged from 0000926326-22-000033:notes:94]

[0000926326-23-000014:notes:70]
|  |  |  |  |  | (In thousands) |
| Balance as of December 31, 2022 |  |  |  |  | $ | 734,274 |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | 621 |  |
| Balance as of March 31, 2023 |  |  |  |  | $ | 734,895 |  |

[0000926326-23-000014:notes:71]
[same as prior period, unchanged from 0000926326-22-000033:notes:97]

[0000926326-23-000014:notes:72]
The carrying amounts and useful lives of intangible assets as of March 31, 2023 and December 31, 2022 were as follows:

[0000926326-23-000014:notes:73]
|  | March 31, 2023 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 311,089 |  |  | $ | (104,149) |  |  | $ | (1,432) |  |  | $ | 205,508 |  |  | 4 - 30 |
| Acquired technology | 92,066 |  |  | (67,033) |  |  | — |  |  | 25,033 |  |  | 4 - 20 |
| Backlog | 1,800 |  |  | (1,125) |  |  | — |  |  | 675 |  |  | 2 |
| Trade names | 9,200 |  |  | (6,895) |  |  | — |  |  | 2,305 |  |  | 5 - 12 |
| Patents | 2,430 |  |  | (1,362) |  |  | — |  |  | 1,068 |  |  | 2 - 20 |
| Non-compete agreements | 600 |  |  | (500) |  |  | — |  |  | 100 |  |  | 3 |
| Total intangibles assets, net | $ | 417,185 |  |  | $ | (181,064) |  |  | $ | (1,432) |  |  | $ | 234,689 |  |  |  |

[0000926326-23-000014:notes:74]
|  | December 31, 2022 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 311,089 |  |  | $ | (99,177) |  |  | $ | (1,514) |  |  | $ | 210,398 |  |  | 4 - 30 |
| Acquired technology | 92,066 |  |  | (64,299) |  |  | — |  |  | 27,767 |  |  | 4 - 20 |
| Backlog | 1,800 |  |  | (900) |  |  | — |  |  | 900 |  |  | 2 |
| Trade names | 9,200 |  |  | (6,633) |  |  | — |  |  | 2,567 |  |  | 5 - 12 |
| Patents | 2,430 |  |  | (1,306) |  |  | — |  |  | 1,124 |  |  | 2 - 20 |
| Non-compete agreements | 600 |  |  | (450) |  |  | — |  |  | 150 |  |  | 3 |
| Total intangibles assets, net | $ | 417,185 |  |  | $ | (172,765) |  |  | $ | (1,514) |  |  | $ | 242,906 |  |  |  |

[0000926326-23-000014:notes:75]
Amortization expense of intangible assets was $8.3 million and $9.1 million for the three months ended March 31, 2023 and 2022, respectively.

[0000926326-23-000014:notes:76]
[same as prior period, unchanged from 0000926326-22-000033:notes:103]

[0000926326-23-000014:notes:77]
|  | March 31,2023 |
|  | (In thousands) |
| Remaining nine months of 2023 | $ | 23,238 |  |
| 2024 | 23,059 |  |
| 2025 | 21,043 |  |
| 2026 | 18,065 |  |
| 2027 | 16,796 |  |
| Thereafter | 132,488 |  |
| Total | $ | 234,689 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-23-000014:notes:78]
Debt and Credit Agreement
2019 Revolving Credit Facility

[0000926326-23-000014:notes:79]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-23-000014:notes:80]
On September 22, 2020, the parties entered into a first amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter. The availability of funds under the Revolving Credit Facility can be subject to reduction in order to maintain compliance with the financial covenants under the A&R Credit Agreement.

[0000926326-23-000014:notes:81]
On March 29, 2023, the parties entered into a second amendment to the A&R Credit Agreement to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York (including a customary credit spread

[0000926326-23-000014:notes:82]
adjustment of 0.10% per annum) and related SOFR-based mechanics. The replacement of LIBOR did not, and the Company does not anticipate that it will, materially impact its liquidity or financial position.

[0000926326-23-000014:notes:83]
Following the second amendment to the A&R Credit Agreement, loans under the Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the A&R Credit Agreement), plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) Adjusted Term SOFR for a one month tenor plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. The applicable margin for, and certain other terms of, any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

[0000926326-23-000014:notes:84]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in compliance with all covenants as of March 31, 2023.

[0000926326-23-000014:notes:85]
As of March 31, 2023 and December 31, 2022, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-23-000014:notes:86]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

[0000926326-23-000014:notes:87]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

[0000926326-23-000014:notes:88]
During the three months ended March 31, 2023 and December 31, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the second quarter of 2023, commencing on April 1, 2023, and were not convertible during the first quarter of 2023, commencing on January 1, 2023, respectively. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of both March 31, 2023 and December 31, 2022. Whether the Notes will be convertible following the second fiscal quarter of 2023 will depend on the satisfaction of the conversion conditions in the future.

[0000926326-23-000014:notes:89]
Under the original terms of the Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of Notes of at least $1,000. As a result, for Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of Notes above $1,000. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that could occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

[0000926326-23-000014:notes:90]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2023, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-23-000014:notes:91]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

[0000926326-23-000014:notes:92]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of March 31, 2023, the remaining life of the Notes and the related issuance cost accretion is approximately 2.5 years.

[0000926326-23-000014:notes:93]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of March 31, 2023, the if-converted value of the Notes did not exceed the principal amount.

[0000926326-23-000014:notes:94]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2023 and December 31, 2022:

[0000926326-23-000014:notes:95]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (7,658) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 567,342 |  |  | $ | 566,571 |  |

[0000926326-23-000014:notes:96]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2023 and 2022:

[0000926326-23-000014:notes:97]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 771 |  |  | $ | 764 |  |  |  |  |  |

[0000926326-23-000014:notes:98]
Convertible Note Hedge and Warrant Transactions

[0000926326-23-000014:notes:99]
In connection with the issuance of the Notes in September 2020, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

[0000926326-23-000014:notes:100]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.

[0000926326-23-000014:notes:101]
Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-23-000014:notes:102]
Lessor Leases
Sales-Type Leases

[0000926326-23-000014:notes:103]
The Company enters into multi-year, sales-type lease agreements, with the majority of such leases varying in length from one to five years. The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases, other than Advanced Services sales-type leases, to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company’s sales-type leases, mostly those relating to U.S. government hospitals which comprised approximately 31% of the lease receivable balance as of March 31, 2023, and those associated with financed service contracts related to certain Advanced Services products, including Central Pharmacy Dispensing Service and IV Compounding Service, are retained in-house by the Company.

[0000926326-23-000014:notes:104]
The following table presents the Company’s income recognized from sales-type leases for the three months ended March 31, 2023 and 2022:

[0000926326-23-000014:notes:105]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| Sales-type lease revenues | $ | 5,716 |  |  | $ | 6,505 |  |  |  |  |  |
| Cost of sales-type lease revenues | (2,662) |  |  | (3,078) |  |  |  |  |  |
| Selling profit on sales-type lease revenues | $ | 3,054 |  |  | $ | 3,427 |  |  |  |  |  |

[0000926326-23-000014:notes:106]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at March 31, 2023 and December 31, 2022:

[0000926326-23-000014:notes:107]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 50,356 |  |  | $ | 50,755 |  |
| Less: Unearned interest income portion | (6,559) |  |  | (6,345) |  |
| Net investment in sales-type leases | 43,797 |  |  | 44,410 |  |
| Less: Current portion (1) | (11,053) |  |  | (11,486) |  |
| Long-term investment in sales-type leases, net | $ | 32,744 |  |  | $ | 32,924 |  |

[0000926326-23-000014:notes:108]
(1)    The current portion of the net investment in sales-type leases is included in other current assets in the Condensed Consolidated Balance Sheets.

[0000926326-23-000014:notes:109]
The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value.

[0000926326-23-000014:notes:110]
The maturity schedule of future minimum lease payments under sales-type leases retained in-house and the reconciliation to the net investment in sales-type leases reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-23-000014:notes:111]
|  | March 31,2023 |
|  | (In thousands) |
| Remaining nine months of 2023 | $ | 9,810 |  |
| 2024 | 10,710 |  |
| 2025 | 8,707 |  |
| 2026 | 7,073 |  |
| 2027 | 5,627 |  |
| Thereafter | 8,429 |  |
| Total future minimum sales-type lease payments | 50,356 |  |
| Present value adjustment | (6,559) |  |
| Total net investment in sales-type leases | $ | 43,797 |  |

[0000926326-23-000014:notes:112]
Operating Leases

[0000926326-23-000014:notes:113]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of ASC 842, Leases. These agreements in place prior to January 1, 2019 continue to be treated as operating leases; however, any leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with ASC 842. The operating lease arrangements generally have initial terms of one to seven years.

[0000926326-23-000014:notes:114]
The following table represents the Company’s income recognized from operating leases for the three months ended March 31, 2023 and 2022:

[0000926326-23-000014:notes:115]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| Rental income | $ | 2,259 |  |  | $ | 2,472 |  |  |  |  |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-23-000014:notes:116]
Lessee Leases The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to twelve years. As of March 31, 2023, the Company did not have any additional material operating leases that were entered into, but not yet commenced.
The maturity schedule of future minimum lease payments under operating leases and the reconciliation to the operating lease liabilities reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-23-000014:notes:117]
|  | March 31,2023 |
|  | (In thousands) |
| Remaining nine months of 2023 | $ | 10,005 |  |
| 2024 | 12,223 |  |
| 2025 | 9,417 |  |
| 2026 | 8,794 |  |
| 2027 | 7,167 |  |
| Thereafter | 7,135 |  |
| Total operating lease payments | 54,741 |  |
| Present value adjustment | (7,011) |  |
| Total operating lease liabilities (1) | $ | 47,730 |  |

[0000926326-23-000014:notes:118]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $10.9 million and $36.9 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-23-000014:notes:119]
Operating lease costs were $3.0 million and $4.1 million for the three months ended March 31, 2023 and 2022, respectively. Short-term lease costs and variable lease costs were not material for the three months ended March 31, 2023 and 2022. During the three months ended March 31, 2023 and 2022, the Company recorded impairment and abandonment charges to operating lease right-of-use assets of $7.8 million and $1.8 million, respectively, in connection with restructuring activities to reduce its real estate footprint and for optimization of certain leased facilities. The impairment and abandonment charges were recorded to selling, general, and administrative expenses on the Company’s Condensed Consolidated Statements of Operations. Refer to Note 16, Restructuring Expenses, for additional information regarding the Company’s restructuring activities.

[0000926326-23-000014:notes:120]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the three months ended March 31, 2023 and 2022:

[0000926326-23-000014:notes:121]
|  | Three Months Ended March 31, |
|  | 2023 |  | 2022 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 3,358 |  |  | $ | 4,193 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 189 |  |  | $ | 497 |  |

[0000926326-23-000014:notes:122]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of March 31, 2023 and December 31, 2022:

[0000926326-23-000014:notes:123]
|  | March 31,2023 |  | December 31,2022 |
| Weighted-average remaining lease term, years | 4.8 |  | 5.0 |
| Weighted-average discount rate, % | 5.7 | % |  | 5.7 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-23-000014:notes:124]
Commitments and Contingencies
Purchase Obligations

[0000926326-23-000014:notes:125]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2023, the Company had non-cancelable purchase commitments of $122.2 million, of which $110.0 million are expected to be paid within the year ending December 31, 2023.

[0000926326-23-000014:notes:126]
Ransomware Incident

[0000926326-23-000014:notes:127]
During the three months ended March 31, 2023, the Company did not incur any material expenses related to the previously disclosed ransomware incident. As of March 31, 2023, the Company has incurred $13.6 million of cumulative expenses related to the ransomware incident since it was detected, partially offset by $11.1 million of insurance recoveries, of

[0000926326-23-000014:notes:128]
which $9.6 million have been received as of March 31, 2023. Expenses included costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred.

[0000926326-23-000014:notes:129]
Legal Proceedings

[0000926326-23-000014:notes:130]
The Company is currently involved in various legal proceedings.

[0000926326-23-000014:notes:131]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020, which was fully briefed, but the Court had not heard oral argument on the motion. The parties entered into a settlement agreement on January 25, 2022, (the “Settlement Agreement”). On February 1, 2022, the Court granted preliminary approval of the settlement. Following preliminary approval, plaintiff conducted discovery to identify class members and to determine the class size. Pursuant to the terms of the Settlement Agreement, and following class size discovery, the parties participated in non-binding mediation on November 21, 2022. A settlement was reached at the mediation and the parties executed an addendum to the Settlement Agreement (the “Addendum”) reflecting the changes to the original settlement terms. On November 30, 2022, the Court granted preliminary approval of the settlement contemplated by the Settlement Agreement, as amended by the Addendum. The Addendum required Omnicell to make a total settlement payment of $4.3 million. On April 6, 2023, the Court granted final approval of the settlement, including the Addendum, and entered judgment in the matter dismissing all claims against Omnicell with prejudice. The Company made its final required settlement payment installment on or before the April 21, 2023 due date.

[0000926326-23-000014:notes:132]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. Outside of the matter discussed above, the Company has not recorded any material accrual for contingent liabilities associated with its current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.

[0000926326-23-000014:notes:133]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company’s financial position or results of operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-23-000014:notes:134]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 36.8% and 26.4% for the three months ended March 31, 2023 and 2022, respectively.

[0000926326-23-000014:notes:135]
For the three months ended March 31, 2023, the Company recognized a discrete income tax expense related to equity compensation of $1.6 million. For the three months ended March 31, 2022, the Company recognized a net discrete income tax benefit of $4.6 million, primarily due to a $4.4 million tax benefit from equity compensation.

[0000926326-23-000014:notes:136]
The 2023 annual effective tax rate before discrete items differed from the statutory rate of 21% primarily due to the favorable benefit of the research and development credits, state income taxes, and foreign-derived intangible income (“FDII”) deduction, partially offset by unfavorable impact of non-deductible compensation and equity charges, and Global Intangible Low-Taxed Income (“GILTI”) tax inclusion. The 2022 annual effective tax rate before discrete items differed from the statutory rate of 21% primarily due to the unfavorable impact of state income taxes, non-deductible compensation and equity charges, and GILTI tax inclusion, partially offset by the favorable impact of research and development credits and an FDII deduction.

[0000926326-23-000014:notes:137]
On August 16, 2022, the Inflation Reduction Act of 2022 (the “IRA”), was signed into law and introduced a 15% corporate alternative minimum tax for tax years beginning after December 31, 2022 and levies a 1% excise tax on net stock repurchases after December 31, 2022. These provisions did not have an impact on the Company’s provision for income taxes for the three months ended March 31, 2023.

[0000926326-23-000014:notes:138]
As of March 31, 2023 and December 31, 2022, the Company had gross unrecognized tax benefits of $9.7 million and $9.3 million, respectively. The Company recognizes interest and penalties related to uncertain tax positions in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. Accrued interest and penalties are included within other long-term liabilities on the Condensed Consolidated Balance Sheets. As of both March 31, 2023 and December 31, 2022, the amount of accrued interest and penalties was $0.2 million.

[0000926326-23-000014:notes:139]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examinations by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, France, and the United Kingdom. With few exceptions, as of March 31, 2023, the Company was no longer subject to U.S., state, and foreign tax examinations for years before 2019, 2018, and 2018, respectively.

[0000926326-23-000014:notes:140]
[same as prior period, unchanged from 0000926326-22-000033:notes:175]


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-23-000014:notes:141]
Employee Benefits and Share-Based Compensation
Share-Based Compensation Expense

[0000926326-23-000014:notes:142]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three months ended March 31, 2023 and 2022:

[0000926326-23-000014:notes:143]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| Cost of product and service revenues | $ | 2,008 |  |  | $ | 2,244 |  |  |  |  |  |
| Research and development | 1,606 |  |  | 2,264 |  |  |  |  |  |
| Selling, general, and administrative | 10,428 |  |  | 11,700 |  |  |  |  |  |
| Total share-based compensation expense | $ | 14,042 |  |  | $ | 16,208 |  |  |  |  |  |

[0000926326-23-000014:notes:144]
During the three months ended March 31, 2023, the Company capitalized approximately $1.1 million of non-cash share-based compensation expense to internal-use and external-use software development costs related to internal labor. The Company did not capitalize any material share-based compensation expense to inventory during the three months ended March 31, 2023 and 2022, or any material share-based compensation expense to internal-use and external-use software development costs during the three months ended March 31, 2022.

[0000926326-23-000014:notes:145]
[same as prior period, unchanged from 0000926326-22-000033:notes:181]

[0000926326-23-000014:notes:146]
The following assumptions were used to value shares under the ESPP for the three months ended March 31, 2023 and 2022:

[0000926326-23-000014:notes:147]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  |  |  |  |
| Expected volatility, % | 31.7% - 63.9% |  | 28.8% - 45.6% |  |  |  |  |
| Risk-free interest rate, % | 0.1% - 5.1% |  | 0.1% - 1.5% |  |  |  |  |
| Dividend yield, % | — | % |  | — | % |  |  |  |  |

[0000926326-23-000014:notes:148]
For the three months ended March 31, 2023 and 2022, employees purchased approximately 209,000 and 175,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $46.96 and $66.81, respectively. As of March 31, 2023, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $4.1 million and is expected to be recognized over a weighted-average period of 1.5 years.

[0000926326-23-000014:notes:149]
[same as prior period, unchanged from 0000926326-22-000033:notes:185]

[0000926326-23-000014:notes:150]
The following assumptions were used to value stock options granted pursuant to the Company’s 2009 Equity Incentive Plan, as amended, (the “2009 Plan”) for the three months ended March 31, 2023. There were no stock options granted during the three months ended March 31, 2022.

[0000926326-23-000014:notes:151]
|  |  |  |  |  | Three Months Ended March 31, |
|  |  |  |  |  |  |  | 2023 |
| Expected life, years |  |  |  |  |  |  | 3.2 |
| Expected volatility, % |  |  |  |  |  |  | 44.8 | % |
| Risk-free interest rate, % |  |  |  |  |  |  | 3.7 | % |
| Estimated forfeiture rate, % |  |  |  |  |  |  | 10.0 | % |
| Dividend yield, % |  |  |  |  |  |  | — | % |

[0000926326-23-000014:notes:152]
The following table summarizes the stock option activity under the 2009 Plan during the three months ended March 31, 2023:

[0000926326-23-000014:notes:153]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2022 | 2,434 |  |  | $ | 68.65 |  |  | 6.1 |  | $ | 7,887 |  |
| Granted | 200 |  |  | 55.60 |  |  |  |  |  |
| Exercised | (65) |  |  | 35.74 |  |  |  |  |  |
| Expired | (12) |  |  | 75.27 |  |  |  |  |  |
| Forfeited | (41) |  |  | 80.43 |  |  |  |  |  |
| Outstanding at March 31, 2023 | 2,516 |  |  | $ | 68.24 |  |  | 5.7 |  | $ | 13,054 |  |
| Exercisable at March 31, 2023 | 1,899 |  |  | $ | 65.73 |  |  | 5.5 |  | $ | 12,440 |  |
| Vested and expected to vest at March 31, 2023 and thereafter | 2,466 |  |  | $ | 68.12 |  |  | 5.7 |  | $ | 12,986 |  |

[0000926326-23-000014:notes:154]
The weighted-average fair value per share of options granted during the three months ended March 31, 2023 was $19.48. The intrinsic value of options exercised during the three months ended March 31, 2023 and 2022 was $1.3 million and $12.7 million, respectively.

[0000926326-23-000014:notes:155]
As of March 31, 2023, total unrecognized compensation cost related to unvested stock options was $16.2 million, which is expected to be recognized over a weighted-average vesting period of 1.3 years.

[0000926326-23-000014:notes:156]
[same as prior period, unchanged from 0000926326-22-000033:notes:192]

[0000926326-23-000014:notes:157]
The following table summarizes the RSU activity under the 2009 Plan during the three months ended March 31, 2023:

[0000926326-23-000014:notes:158]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2022 | 1,117 |  |  | $ | 115.75 |  |  | 1.6 |  | $ | 56,297 |  |
| Granted (Awarded) | 74 |  |  | 55.41 |  |  |  |  |  |
| Vested (Released) | (63) |  |  | 128.15 |  |  |  |  |  |
| Forfeited | (116) |  |  | 117.91 |  |  |  |  |  |
| Outstanding and unvested at March 31, 2023 | 1,012 |  |  | $ | 110.36 |  |  | 1.5 |  | $ | 59,372 |  |

[0000926326-23-000014:notes:159]
As of March 31, 2023, total unrecognized compensation cost related to RSUs was $95.8 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.9 years.

[0000926326-23-000014:notes:160]
[same as prior period, unchanged from 0000926326-22-000033:notes:196]

[0000926326-23-000014:notes:161]
The following table summarizes the RSA activity under the 2009 Plan during the three months ended March 31, 2023:

[0000926326-23-000014:notes:162]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2022 | 13 |  |  | $ | 109.39 |  |
| Granted (Awarded) | — |  |  | — |  |
| Vested (Released) | — |  |  | — |  |
| Outstanding and unvested at March 31, 2023 | 13 |  |  | $ | 109.39 |  |

[0000926326-23-000014:notes:163]
As of March 31, 2023, total unrecognized compensation cost related to RSAs was $0.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.2 years.

[0000926326-23-000014:notes:164]
[same as prior period, unchanged from 0000926326-22-000033:notes:200]

[0000926326-23-000014:notes:165]
The following table summarizes the PSU activity under the 2009 Plan during the three months ended March 31, 2023:

[0000926326-23-000014:notes:166]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2022 | 135 |  |  | $ | 147.42 |  |
| Granted | — |  |  | — |  |
| Vested | (10) |  |  | 164.48 |  |
| Forfeited | (63) |  |  | 153.89 |  |
| Outstanding and unvested at March 31, 2023 | 62 |  |  | $ | 138.00 |  |

[0000926326-23-000014:notes:167]
As of March 31, 2023, total unrecognized compensation cost related to PSUs was approximately $3.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.8 years.

[0000926326-23-000014:notes:168]
[same as prior period, unchanged from 0000926326-22-000033:notes:204]

[0000926326-23-000014:notes:169]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of March 31, 2023:

[0000926326-23-000014:notes:170]
|  | Number of Shares |
|  | (In thousands) |
| Stock options outstanding | 2,516 |  |
| Non-vested restricted stock awards | 1,087 |  |
| Shares authorized for future issuance | 1,433 |  |
| ESPP shares available for future issuance | 394 |  |
| Total shares reserved for future issuance | 5,430 |  |

[0000926326-23-000014:notes:171]
[same as prior period, unchanged from 0000926326-22-000033:notes:207]

[0000926326-23-000014:notes:172]
On August 2, 2016, the Company’s Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2014 Repurchase Program”). During the first quarter of 2022, the 2014 Repurchase Program was completed, and as of March 31, 2023, the maximum dollar value of shares that may yet be purchased under the 2016 Repurchase Program was $2.7 million. The 2016 Repurchase Program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the 2016 Repurchase Program at any time.
During the three months ended March 31, 2022, the Company repurchased approximately 389,300 shares of its common stock under the repurchase programs at an average price of $134.11 per share for an aggregate purchase price of approximately $52.2 million. During the three months ended March 31, 2023, the Company did not repurchase any of its outstanding common stock under the 2016 Repurchase Program.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-23-000014:notes:173]
Restructuring Expenses
During the first quarter of 2022, the Company initiated certain domestic and international restructuring initiatives, in order to enhance and streamline certain engineering functions for its domestic operations, and to realign its international sales organization to better serve its customers in various international markets. During the three months ended March 31, 2022, the Company incurred $3.5 million of employee severance costs and related expenses in connection with this restructuring plan. As of March 31, 2023, there was no material unpaid balance related to this restructuring plan.

[0000926326-23-000014:notes:174]
On November 23, 2022, the Company committed to a plan to reduce the Company’s headcount (the “Plan”), as part of the Company’s expense containment efforts being implemented due to ongoing macroeconomic headwinds. During the first quarter of 2023, as a result of continued exploration of expense containment measures, the Company committed to further reduce its headcount across many of its functions, and also committed to reduce its real estate footprint to align with its broader hybrid work strategy and in an effort to further reduce costs. During the three months ended March 31, 2023, the Company incurred $5.3 million of employee severance costs and related expenses in connection with the Plan. As of March 31, 2023, the Company has incurred $22.8 million of cumulative restructuring expense related to employee severance costs and related expenses since the inception of the Plan. As of March 31, 2023 and December 31, 2022, the unpaid balance related to the Plan was $8.1 million and $18.2 million, respectively.

[0000926326-23-000014:notes:175]
Refer to Note 12, Lessee Leases, for information regarding the Company’s restructuring activities for the reduction of its real estate footprint and optimization of certain leased facilities.

[0000926326-23-000014:notes:176]
The following table summarizes the total employee-related restructuring expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three months ended March 31, 2023 and 2022:

[0000926326-23-000014:notes:177]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| Cost of product and service revenues | $ | 144 |  |  | $ | 156 |  |  |  |  |  |
| Research and development | 485 |  |  | 1,594 |  |  |  |  |  |
| Selling, general, and administrative | 4,685 |  |  | 1,777 |  |  |  |  |  |
| Total restructuring expense | $ | 5,314 |  |  | $ | 3,527 |  |  |  |  |  |
