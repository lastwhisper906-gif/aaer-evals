# OMCL MD&A — 0000926326-23-000014


## mdna

[0000926326-23-000014:mdna:1]
[same as prior period, unchanged from 0000926326-22-000033:mdna:1]

[0000926326-23-000014:mdna:2]
[same as prior period, unchanged from 0000926326-22-000033:mdna:2]

[0000926326-23-000014:mdna:3]
•our expectations regarding our future sales pipeline and bookings;

[0000926326-23-000014:mdna:4]
[same as prior period, unchanged from 0000926326-22-000033:mdna:6]

[0000926326-23-000014:mdna:5]
[same as prior period, unchanged from 0000926326-22-000033:mdna:7]

[0000926326-23-000014:mdna:6]
•our beliefs about drivers of demand for our products, services, and solutions, opportunities in certain market categories, and continued expansion in these market categories, as well as our belief that our technology, services, and solutions within these market categories position us well to address the needs of retail, acute, post-acute, and specialty pharmacy providers;

[0000926326-23-000014:mdna:7]
[same as prior period, unchanged from 0000926326-22-000033:mdna:12]

[0000926326-23-000014:mdna:8]
•our goal of advancing our platform with the development of new products, services, or solutions or the enhancement of existing products, services, or solutions;

[0000926326-23-000014:mdna:9]
•growth opportunities presented by new products, services, solutions, and markets;

[0000926326-23-000014:mdna:10]
•our projected target revenues, operating costs, and cash flows;

[0000926326-23-000014:mdna:11]
•our ability to align our intelligent infrastructure development and global workforce headcount with our current business expectations;

[0000926326-23-000014:mdna:12]
•our goal to deliver on the industry vision of the Autonomous Pharmacy, as well as our plan to migrate our customers from an on-premise infrastructure to our cloud-based platform;

[0000926326-23-000014:mdna:13]
•our belief that our solutions that support the industry vision of the Autonomous Pharmacy, are strongly aligned with trends in the healthcare market, and are well-positioned to address the evolving needs of healthcare institutions;

[0000926326-23-000014:mdna:14]
•our expectation to continue to acquire companies, businesses, products, services, or technologies and to effectively integrate or manage these acquired companies, businesses, products, services, or technologies;

[0000926326-23-000014:mdna:15]
•our ability to secure adequate supplies of raw materials and components utilized in the manufacture of our products of a quality that we require, on a timely basis, and at acceptable prices;

[0000926326-23-000014:mdna:16]
•our containment of the impacts of the ransomware incident we experienced in May 2022, and any further impacts on the Company, including its business, operating results, cash flow, or financial condition;

[0000926326-23-000014:mdna:17]
•our expectations about the impact of epidemics, pandemics, or other major public health crises, such as the ongoing COVID-19 pandemic (including new variants of the virus) and associated efforts to contain the spread of the pandemic on our workforce and operations as well as those of our customers and suppliers, and the anticipated continuing effects of the COVID-19 pandemic and associated containment measures on our business, operating results, cash flow, or financial condition;

[0000926326-23-000014:mdna:18]
•our expected future uses of cash and the sufficiency of our sources of funding; and

[0000926326-23-000014:mdna:19]
[same as prior period, unchanged from 0000926326-22-000033:mdna:20]

[0000926326-23-000014:mdna:20]
In some cases, you can identify forward-looking statements by terms such as “anticipates,” “believes,” “could,” “estimates,” “expects,” “forecasts,” “goals,” “intends,” “may,” “plans,” “potential,” “predicts,” “projects,” “seeks,” “should,” “target,” “will,” “would,” and variations of these terms and similar expressions.

[0000926326-23-000014:mdna:21]
[same as prior period, unchanged from 0000926326-22-000033:mdna:22]

[0000926326-23-000014:mdna:22]
All references in this Quarterly Report on Form 10-Q to “Omnicell,” “our,” “us,” “we,” or “the Company” collectively refer to Omnicell, Inc., a Delaware corporation, and its subsidiaries. The term “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries.

[0000926326-23-000014:mdna:23]
We own various registered and unregistered trademarks and service marks used in our business, some of which appear in this Quarterly Report on Form 10-Q, including Omnicell®. This Quarterly Report on Form 10-Q may also include the trademarks and service marks of other companies. Such trademarks and service marks are the marks of their respective owners.

[0000926326-23-000014:mdna:24]
[same as prior period, unchanged from 0000926326-22-000033:mdna:25]

[0000926326-23-000014:mdna:25]
[same as prior period, unchanged from 0000926326-22-000033:mdna:26]

[0000926326-23-000014:mdna:26]
Omnicell, a leader in transforming the pharmacy care delivery model, is committed to solving the critical challenges inherent in medication management and elevating the role of clinicians within healthcare as an essential component of care delivery. Omnicell is focused on not only helping its customers optimize medication management in each setting of care, but also placing the patient at the center and helping its customers optimize medication management across all care settings from inpatient to outpatient. We are doing so with an industry-leading medication management intelligent infrastructure to equip and empower pharmacists and pharmacies with the ability to focus on clinical care rather than administrative tasks. This intelligent infrastructure provides the critical foundation for customers to realize the industry vision of the Autonomous Pharmacy, a vision defined by pharmacy leaders for improving operational efficiencies and ultimately targeting zero-error medication management.

[0000926326-23-000014:mdna:27]
Facilities worldwide use our automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. Institutional and retail pharmacies across North America and the United Kingdom leverage our innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 88% and 90% of our total revenues for the three months ended March 31, 2023 and 2022, respectively.

[0000926326-23-000014:mdna:28]
Over the past several years, our business has expanded from a single-point solution to a platform of products and services that will help to further advance the industry vision of the Autonomous Pharmacy. This expansion has resulted in larger deal sizes across multiple products, services, and implementations for customers and, we believe, more comprehensive, valuable, and enduring relationships. As our business evolves, we continue to evaluate the metrics and methods we use to measure the success of our business.

[0000926326-23-000014:mdna:29]
We utilize bookings as an indicator of the success of our business. We define bookings generally as: (i) the value of non-cancelable contracts for our connected devices, software products, and Advanced Services (although, for those Advanced Services contracts without a minimum commitment, bookings only include the amount of revenue that has been recognized once the services have been provided); and (ii) for our consumables, the value of orders placed through our Omnicell Storefront online platform or through written or telephonic orders. We typically exclude technical services and other less significant items ancillary to our products and services, such as freight revenue from bookings. As noted, the portfolio of products, solutions and services we offer has evolved. As a result, the ordering process for certain of our solutions has also evolved. For example, orders for certain of our solutions may not include a purchase order. Connected devices and software license bookings are recorded as revenue upon customer acceptance of the installation or receipt of goods. Revenues from Advanced Services bookings are recorded over the contractual term.

[0000926326-23-000014:mdna:30]
We generally provide installation planning and consulting as part of most connected device product sales, which is typically included in the initial price of the solution. To help ensure the maximum availability of our systems, our customers typically purchase technical services contracts (maintenance and support) in increments of one to five years. In addition to connected device product sales, we provide a range of services to our customers. We also provide Advanced Services such as Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions, which typically are provided over 2-7 years.

[0000926326-23-000014:mdna:31]
[same as prior period, unchanged from 0000926326-22-000033:mdna:32]

[0000926326-23-000014:mdna:32]
| Revenue Category |  | Revenue Type |  | Income Statement Classification |  | Included in Bookings |
| Connected devices, software licenses, and other |  | Nonrecurring |  | Product |  | Yes (1) |
| Consumables |  | Recurring |  | Product |  | Yes |
| Technical services |  | Recurring |  | Service |  | No |
| Advanced Services (2) (3) |  | Recurring |  | Service |  | Yes |

[0000926326-23-000014:mdna:33]
[same as prior period, unchanged from 0000926326-22-000033:mdna:34]

[0000926326-23-000014:mdna:34]
(1)    Certain other insignificant revenue streams ancillary to our products and services, such as freight revenue, are not included in bookings.

[0000926326-23-000014:mdna:35]
(2)    Includes Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions.

[0000926326-23-000014:mdna:36]
(3)    For those Advanced Services contracts without a minimum commitment, bookings only include the amount of revenue that has been recognized once the services have been provided.

[0000926326-23-000014:mdna:37]
Our full-time employee headcount was approximately 3,830 and 4,230 on March 31, 2023 and December 31, 2022, respectively. The decrease in employee headcount reflects the impact of the restructuring plan announced in November 2022.

[0000926326-23-000014:mdna:38]
[same as prior period, unchanged from 0000926326-22-000033:mdna:38]

[0000926326-23-000014:mdna:39]
[same as prior period, unchanged from 0000926326-22-000033:mdna:39]

[0000926326-23-000014:mdna:40]
[same as prior period, unchanged from 0000926326-22-000033:mdna:40]

[0000926326-23-000014:mdna:41]
The U.S. spent a total of $577 billion on prescription drugs that accounted for 14% of National Health Expenditures in 2021, and prescription drugs impact the vast majority of patients in virtually all settings of care. We believe there are significant challenges facing the practice of pharmacy today including, but not limited to, labor shortages, medication errors, drug shortages, medication loss due to drug diversion, significant medication waste and expiration costs, a high level of manual processes, complexity around compliance requirements, high healthcare worker turnover rates affecting tenure and expertise, hospitalizations from adverse drug events in outpatient settings, high variability in outcomes, and limited inventory visibility. Each of these challenges can translate into a major economic impact for hospitals and health systems. We believe that these significant challenges to the practice of pharmacy drive demand for increased digitization, visibility, and insights that our solutions enable, and that our solutions therefore present large opportunities.

[0000926326-23-000014:mdna:42]
In an effort to address these challenges and deliver solutions to help drive positive medication management outcomes, we believe a combination of technology, expertise and intelligence is needed in each care setting and across the entire continuum of care. We are focused on delivering solutions to help drive these medication management outcomes with outstanding customer experience through a mature channel in four market categories:

[0000926326-23-000014:mdna:43]
•Point of Care.  As a market leader, we expect to continue expansion into this product market as customers increase use of our dispensing systems in more areas within their hospitals. Should labor shortages continue to challenge the delivery of healthcare services, we believe that deploying solutions and workflows that are intended to save nursing time is essential. We are more than halfway through the replacement, upgrade, and expansion cycle of older models of automated dispensing systems with our XT Series within our customer base, which we believe remains a significant market opportunity. We have been successful in market expansion through competitive conversions and we expect this success to continue. We also believe there is an opportunity for us to expand the offering and define a new standard for dispensing systems in perioperative settings. We believe our current solutions within the Point of Care market and new innovation and services will continue to help customers drive improved outcomes.

[0000926326-23-000014:mdna:44]
•Central Pharmacy and IV Compounding.  This market represents the beginning of the medication management process in acute care settings, and, we believe, it is a significant automation opportunity for high volumes of manual, repetitive, and error-prone processes that are often common in pharmacies today. Manual medication dispensing processes are usually labor intensive, error-prone, and may lead to excess medication waste and expirations for our healthcare partners. Automating the central pharmacy dispensing process should enable customers to reallocate pharmacy labor, enhance dispensing accuracy and patient safety, and reduce medication

[0000926326-23-000014:mdna:45]
waste and expirations. Likewise, the manual compounding of sterile IV preparations can be error-prone and create significant patient safety risks, and outsourcing sterile IV compounding could lead to increased medication costs. As a result, we believe IV automation provides a significant opportunity to enhance patient safety and reduce costs. Because adoption of our Central Pharmacy and IV automation solution is still nascent, we believe that the implementation of new solutions (as well as upgrading older technology) will be accelerated by combining technology, expertise, and intelligence into a comprehensive offering that is designed to deliver improved outcomes. We anticipate that these bundled solutions will become more critical as health systems continue to face labor shortages, increased financial pressure, and supply chain disruptions.

[0000926326-23-000014:mdna:46]
•Specialty Pharmacy and 340B Program.  We believe that health systems will invest in more revenue-generating activities that are intended to improve patient outcomes by utilizing specialty pharmacies and the 340B Drug Pricing Program, which allow hospitals and health systems to stretch federal resources and expand patient access to healthcare by requiring manufacturers participating in Medicaid to sell outpatient drugs at discounted prices to healthcare organizations. Specialty drugs are used for treatment of complex conditions and often require intensive patient management and specialized workflows for dispensing and care coordination. Specialty medications are projected to account for 60% of U.S. total spending on medications, with total spending projected to be approximately $420 billion in 2025. Specialty pharmacies serve as the connection between patients, prescribing physicians, and payers and work to streamline access and adherence to these specialty drugs. We believe a solution that addresses start-up and managed services for health systems that is designed to optimize their specialty pharmacy programs and the related pharmaceutical aspects of patient care will help ensure continuity of care and should contribute to the revenue and profitability of those organizations. We believe that a fully optimized specialty pharmacy operation represents one of the largest economic opportunities for hospitals and health systems.

[0000926326-23-000014:mdna:47]
•Retail, Institutional, and Payer.  We believe the Retail, Institutional, and Payer market represents a significant opportunity as healthcare evolves. A majority of all prescription drugs are distributed in the non-acute sector. The COVID-19 pandemic accelerated the shift of certain primary care from hospitals and physician offices to other, more convenient settings, such as retail pharmacies and the home (including through telehealth technologies). New technologies and updated state board regulations appear to be spurring innovation by retail pharmacies, which, combined with the move to value-based care, we believe will drive the adoption of solutions that are intended to help providers and payers engage patients in new ways that improve patient care, reduce the total cost of care, and lead to more profitable operations. Because of the complexity of relationships between payers and providers, as well as the large number of retail pharmacies, including a significant number of independent pharmacies, we believe a network of established relationships between payers, providers and pharmacies will also be important.

[0000926326-23-000014:mdna:48]
[same as prior period, unchanged from 0000926326-22-000033:mdna:61]

[0000926326-23-000014:mdna:49]
[same as prior period, unchanged from 0000926326-22-000033:mdna:62]

[0000926326-23-000014:mdna:50]
[same as prior period, unchanged from 0000926326-22-000033:mdna:63]

[0000926326-23-000014:mdna:51]
[same as prior period, unchanged from 0000926326-22-000033:mdna:64]

[0000926326-23-000014:mdna:52]
•Lessor leases;

[0000926326-23-000014:mdna:53]
•Allowance for credit losses;

[0000926326-23-000014:mdna:54]
[same as prior period, unchanged from 0000926326-22-000033:mdna:67]

[0000926326-23-000014:mdna:55]
•Internal-use and external-use software development costs;

[0000926326-23-000014:mdna:56]
•Lessee leases;

[0000926326-23-000014:mdna:57]
[same as prior period, unchanged from 0000926326-22-000033:mdna:69]

[0000926326-23-000014:mdna:58]
[same as prior period, unchanged from 0000926326-22-000033:mdna:70]

[0000926326-23-000014:mdna:59]
[same as prior period, unchanged from 0000926326-22-000033:mdna:72]

[0000926326-23-000014:mdna:60]
[same as prior period, unchanged from 0000926326-22-000033:mdna:73]

[0000926326-23-000014:mdna:61]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the three months ended March 31, 2023 as compared to those disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in our Annual Report on Form 10-K for the year ended December 31, 2022, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000926326-23-000014:mdna:62]
[same as prior period, unchanged from 0000926326-22-000033:mdna:75]

[0000926326-23-000014:mdna:63]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-23-000014:mdna:64]
[same as prior period, unchanged from 0000926326-22-000033:mdna:77]

[0000926326-23-000014:mdna:65]
[same as prior period, unchanged from 0000926326-22-000033:mdna:78]

[0000926326-23-000014:mdna:66]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 185,715 |  |  | $ | 225,875 |  |  | $ | (40,160) |  |  | (18)% |
| Percentage of total revenues | 64% |  | 71% |  |  |  |  |
| Services and other revenues | 104,914 |  |  | 92,953 |  |  | 11,961 |  |  | 13% |
| Percentage of total revenues | 36% |  | 29% |  |  |  |  |
| Total revenues | $ | 290,629 |  |  | $ | 318,828 |  |  | $ | (28,199) |  |  | (9)% |

[0000926326-23-000014:mdna:67]
Product revenues represented 64% and 71% of total revenues for the three months ended March 31, 2023 and 2022, respectively. Product revenues decreased by $40.2 million, primarily due to lower revenues from our automated dispensing systems business as a result of ongoing health systems capital budget constraints.

[0000926326-23-000014:mdna:68]
Services and other revenues represented 36% and 29% of total revenues for the three months ended March 31, 2023 and 2022, respectively. Services and other revenues include revenues from technical services and Advanced Services offerings. Services and other revenues increased by $12.0 million, primarily due to increased customer demand for our Advanced Services and continued growth in our installed customer base as well as the impact of pricing actions.

[0000926326-23-000014:mdna:69]
Our international sales represented 12% and 10% of total revenues for the three months ended March 31, 2023 and 2022, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-23-000014:mdna:70]
[same as prior period, unchanged from 0000926326-22-000033:mdna:87]

[0000926326-23-000014:mdna:71]
[same as prior period, unchanged from 0000926326-22-000033:mdna:88]

[0000926326-23-000014:mdna:72]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which account for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product, and overhead costs associated with production; (ii) costs of providing services and installation costs, including

[0000926326-23-000014:mdna:73]
costs of personnel and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, provisions for excess and obsolete inventory, and amortization of software development costs and intangibles.

[0000926326-23-000014:mdna:74]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 109,527 |  |  | $ | 118,338 |  |  | $ | (8,811) |  |  | (7)% |
| As a percentage of related revenues | 59% |  | 52% |  |  |  |  |
| Cost of services and other revenues | 56,073 |  |  | 50,443 |  |  | 5,630 |  |  | 11% |
| As a percentage of related revenues | 53% |  | 54% |  |  |  |  |
| Total cost of revenues | $ | 165,600 |  |  | $ | 168,781 |  |  | $ | (3,181) |  |  | (2)% |
| As a percentage of total revenues | 57% |  | 53% |  |  |  |  |
| Gross profit | $ | 125,029 |  |  | $ | 150,047 |  |  | $ | (25,018) |  |  | (17)% |
| Gross margin | 43% |  | 47% |  |  |  |  |

[0000926326-23-000014:mdna:75]
Cost of revenues for the three months ended March 31, 2023 compared to the three months ended March 31, 2022 decreased by $3.2 million, primarily driven by an $8.8 million decrease in cost of product revenues, partially offset by a $5.6 million increase in cost of services and other revenues.

[0000926326-23-000014:mdna:76]
The decrease in cost of product revenues was primarily driven by the decrease in product revenues of $40.2 million for the three months ended March 31, 2023 compared to the three months ended March 31, 2022. The decrease in cost of product revenues have not decreased proportionally with the decrease in product revenues for the three months ended March 31, 2023, primarily due to certain fixed costs, such as labor and overhead. The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $12.0 million for the three months ended March 31, 2023 compared to the three months ended March 31, 2022.

[0000926326-23-000014:mdna:77]
The overall decrease in gross margin primarily relates to lower product revenues for the three months ended March 31, 2023 whereas the decrease in cost of product revenues have not decreased proportionally with the decrease in product revenues, primarily due to certain fixed costs, such as labor and overhead. The decrease is partially offset by continued growth in our services and other revenues. Our gross profit for the three months ended March 31, 2023 was $125.0 million, as compared to $150.0 million for the three months ended March 31, 2022.

[0000926326-23-000014:mdna:78]
[same as prior period, unchanged from 0000926326-22-000033:mdna:101]

[0000926326-23-000014:mdna:79]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 22,878 |  |  | $ | 25,030 |  |  | $ | (2,152) |  |  | (9)% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 125,114 |  |  | 119,933 |  |  | 5,181 |  |  | 4% |
| As a percentage of total revenues | 43% |  | 38% |  |  |  |  |
| Total operating expenses | $ | 147,992 |  |  | $ | 144,963 |  |  | $ | 3,029 |  |  | 2% |
| As a percentage of total revenues | 51% |  | 45% |  |  |  |  |
| Interest and other income (expense), net | $ | 1,781 |  |  | $ | (114) |  |  | $ | 1,895 |  |  | (1,662)% |

[0000926326-23-000014:mdna:80]
Research and Development. Research and development expenses decreased by $2.2 million for the three months ended March 31, 2023 compared to the three months ended March 31, 2022. The decrease was primarily attributed to a decrease of $1.1 million in employee-related expenses for restructuring initiatives and decrease in consulting expenses of approximately $1.3 million.

[0000926326-23-000014:mdna:81]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $5.2 million for the three months ended March 31, 2023 compared to the three months ended March 31, 2022. The increase was primarily due to an increase of $6.7 million for impairment and abandonment charges of operating lease right-of-use and other assets in connection with restructuring activities of certain leased facilities. The increase was also driven by an increase of $2.9 million in employee-related expenses for restructuring initiatives. The increase is partially offset by a decrease in commission expense of $1.4 million, a decrease in travel expense of $1.3 million as well as other cost savings initiatives.

[0000926326-23-000014:mdna:82]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $1.9 million for the three months ended March 31, 2023 compared to the three months ended March 31, 2022, primarily driven by a $1.9 million increase in other income. The increase in other income during the three months ended March 31, 2023 as compared to the three months ended March 31, 2022 is primarily attributable to higher interest income received due to higher interest rates, partially offset by benefits from certain arrangements outside of our normal course of business recognized during the three months ended March 31, 2022.

[0000926326-23-000014:mdna:83]
[same as prior period, unchanged from 0000926326-22-000033:mdna:112]

[0000926326-23-000014:mdna:84]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Benefit from income taxes | $ | (6,182) |  |  | $ | (3,243) |  |  | $ | (2,939) |  |  | 91% |

[0000926326-23-000014:mdna:85]
For the three months ended March 31, 2023, we recognized a benefit from income taxes of $6.2 million as we applied our estimated annual effective tax rate of 36.8% to our year-to-date measure of ordinary income and adjusted for $1.6 million of discrete income tax expense from equity compensation. Benefit from income taxes for the three months ended March 31, 2022 was $3.2 million and included a net discrete income tax benefit of $4.6 million, primarily due to a $4.4 million tax benefit from equity compensation. The increase in the income tax benefit for the three months ended March 31, 2023 compared to the same period in 2022 was primarily due to a decrease in profit before taxes and an increase in research and development credits.

[0000926326-23-000014:mdna:86]
[same as prior period, unchanged from 0000926326-22-000033:mdna:119]

[0000926326-23-000014:mdna:87]
[same as prior period, unchanged from 0000926326-22-000033:mdna:120]

[0000926326-23-000014:mdna:88]
We had cash and cash equivalents of $340.4 million at March 31, 2023 compared to $330.4 million at December 31, 2022. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with major financial institutions of high credit quality.

[0000926326-23-000014:mdna:89]
Our cash position and working capital at March 31, 2023 and December 31, 2022 were as follows:

[0000926326-23-000014:mdna:90]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 340,413 |  |  | $ | 330,362 |  |
| Working capital | $ | 481,001 |  |  | $ | 453,366 |  |

[0000926326-23-000014:mdna:91]
Our ratio of current assets to current liabilities was 2.1:1 at both March 31, 2023 and December 31, 2022.

[0000926326-23-000014:mdna:92]
[same as prior period, unchanged from 0000926326-22-000033:mdna:127]

[0000926326-23-000014:mdna:93]
Revolving Credit Facility

[0000926326-23-000014:mdna:94]
On November 15, 2019, we entered into an Amended and Restated Credit Agreement (as subsequently amended, as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded our 2016 senior secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.

[0000926326-23-000014:mdna:95]
On September 22, 2020, the parties entered into a first amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions

[0000926326-23-000014:mdna:96]
described below, expand our flexibility to repurchase our common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that required us to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and requires us to maintain a consolidated secured net leverage ratio not to exceed 3.00:1 for the calendar quarters ending thereafter. The availability of funds under the Revolving Credit Facility can be subject to reduction in order to maintain compliance with the financial covenants under the A&R Credit Agreement.

[0000926326-23-000014:mdna:97]
On March 29, 2023, the parties entered into a second amendment to the A&R Credit Agreement to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York (including a customary credit spread adjustment of 0.10% per annum) and related SOFR-based mechanics. The replacement of LIBOR did not, and the Company does not anticipate that it will, materially impact its liquidity or financial position.

[0000926326-23-000014:mdna:98]
As of March 31, 2023, there was no outstanding balance for the Revolving Credit Facility and we were in compliance with all covenants. Refer to Note 9, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information. We expect to use future loans under the Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-23-000014:mdna:99]
[same as prior period, unchanged from 0000926326-22-000033:mdna:133]

[0000926326-23-000014:mdna:100]
[same as prior period, unchanged from 0000926326-22-000033:mdna:134]

[0000926326-23-000014:mdna:101]
The 2016 Repurchase Program has a total of $2.7 million remaining for future repurchases as of March 31, 2023, which may result in additional use of cash. There were no stock repurchases during the three months ended March 31, 2023. Refer to “Stock Repurchase Programs” under Note 15, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-23-000014:mdna:102]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-23-000014:mdna:103]
[same as prior period, unchanged from 0000926326-22-000033:mdna:137]

[0000926326-23-000014:mdna:104]
[same as prior period, unchanged from 0000926326-22-000033:mdna:138]

[0000926326-23-000014:mdna:105]
|  | Three Months Ended March 31, |
|  | 2023 |  | 2022 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 12,770 |  |  | $ | (15,996) |  |
| Investing activities | (13,640) |  |  | (18,733) |  |
| Financing activities | 3,862 |  |  | (32,119) |  |
| Effect of exchange rate changes on cash and cash equivalents | 176 |  |  | (411) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 3,168 |  |  | $ | (67,259) |  |

[0000926326-23-000014:mdna:106]
[same as prior period, unchanged from 0000926326-22-000033:mdna:140]

[0000926326-23-000014:mdna:107]
[same as prior period, unchanged from 0000926326-22-000033:mdna:141]

[0000926326-23-000014:mdna:108]
Net cash provided by operating activities was $12.8 million for the three months ended March 31, 2023, primarily consisting of a net loss of $15.0 million and changes in assets and liabilities of $12.4 million, offset by non-cash items of $40.2 million. The non-cash items primarily consisted of depreciation and amortization expense of $22.0 million, share-based

[0000926326-23-000014:mdna:109]
compensation expense of $14.0 million, amortization of operating lease right-of-use assets of $2.2 million, impairment and abandonment of operating lease right-of-use assets related to facilities of $7.8 million, amortization of debt issuance costs of $1.0 million, and a change in deferred income taxes of $7.8 million. Changes in assets and liabilities include cash outflows primarily from (i) a decrease in accrued compensation of $25.2 million primarily due to a decrease in the accrual for restructuring initiatives, lower commissions, as well as timing of payroll and ESPP purchases, (ii) an increase in accounts receivable and unbilled receivables of $22.2 million primarily due to the timing of billings, shipments and collections, and (iii) a decrease in operating lease liabilities of $2.7 million. These cash outflows were partially offset by (i) an increase in deferred revenues of $29.1 million primarily due to an increase in billings for certain service and subscription offerings, (ii) a decrease in inventories of $6.8 million primarily due to management of inventory levels to align with the current forecasted demand, and (iii) a decrease in prepaid commissions of $2.6 million.

[0000926326-23-000014:mdna:110]
Net cash used in operating activities was $16.0 million for the three months ended March 31, 2022, primarily consisting of net income of $8.2 million adjusted for non-cash items of $38.6 million, offset by changes in assets and liabilities of $62.8 million. The non-cash items primarily consisted of depreciation and amortization expense of $21.1 million, share-based compensation expense of $16.2 million, amortization of operating lease right-of-use assets of $3.3 million, impairment of operating lease right-of-use assets of $1.8 million, amortization of debt issuance costs of $1.0 million, and a change in deferred income taxes of $4.9 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $50.0 million primarily due to an increase in billings driven by overall business growth and the timing of shipments and collections, (ii) a decrease in accrued compensation of $23.9 million primarily due to a decrease in accrued commissions and bonuses as well as timing of ESPP purchases, (iii) an increase in inventories of $17.3 million to support forecasted sales, including advanced purchases of certain components, as well as higher costs of inventory, (iv) a decrease in operating lease liabilities of $3.5 million, (v) an increase in prepaid expenses of $1.7 million, and (vi) an increase in investment in sales-type leases of $1.1 million. These cash outflows were partially offset by (i) an increase in deferred revenues of $19.8 million primarily due to an increase in billings driven by the timing of annual maintenance renewals, the billing of other ongoing service commitments, and shipments of product in order to meet customers’ implementation schedules and recognition of revenues for products requiring installation, (ii) a decrease in other current assets, net of funds held for customers, of $8.0 million, (iii) a decrease in prepaid commissions of $4.2 million, and (iv) a decrease in other long-term assets of $2.2 million.

[0000926326-23-000014:mdna:111]
[same as prior period, unchanged from 0000926326-22-000033:mdna:144]

[0000926326-23-000014:mdna:112]
Net cash used in investing activities was $13.6 million for the three months ended March 31, 2023, which consisted of capital expenditures of $10.1 million for property and equipment, and $3.5 million for external-use software development costs.

[0000926326-23-000014:mdna:113]
Net cash used in investing activities was $18.7 million for the three months ended March 31, 2022, which consisted of $3.4 million consideration paid for the acquisition of Hub and Spoke Innovations, net of cash acquired, capital expenditures of $11.5 million for property and equipment, and $3.9 million for external-use software development costs.

[0000926326-23-000014:mdna:114]
[same as prior period, unchanged from 0000926326-22-000033:mdna:147]

[0000926326-23-000014:mdna:115]
Net cash provided by financing activities was $3.9 million for the three months ended March 31, 2023, primarily due to $12.1 million in proceeds from employee stock option exercises and ESPP purchases, partially offset by $1.4 million in employees’ taxes paid related to restricted stock unit vesting and a net change in the customer funds balances of $6.9 million.

[0000926326-23-000014:mdna:116]
Net cash used in financing activities was $32.1 million for the three months ended March 31, 2022, primarily due to $52.2 million for repurchases of our stock and $4.3 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $19.0 million in proceeds from employee stock option exercises and ESPP purchases, and a net change in the customer funds balances of $5.5 million.

[0000926326-23-000014:mdna:117]
[same as prior period, unchanged from 0000926326-22-000033:mdna:150]

[0000926326-23-000014:mdna:118]
There have been no significant changes during the three months ended March 31, 2023 to the contractual obligations disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2022.

[0000926326-23-000014:mdna:119]
Contractual obligations as of March 31, 2023 were as follows:

[0000926326-23-000014:mdna:120]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2023 |  | 2024 - 2025 |  | 2026 - 2027 |  | 2028 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 54,741 |  |  | $ | 10,005 |  |  | $ | 21,640 |  |  | $ | 15,961 |  |  | $ | 7,135 |  |
| Purchase obligations (2) | 122,211 |  |  | 110,005 |  |  | 12,103 |  |  | 103 |  |  | — |  |
| Convertible senior notes (3) | 578,594 |  |  | 719 |  |  | 577,875 |  |  | — |  |  | — |  |
| Total (4) | $ | 755,546 |  |  | $ | 120,729 |  |  | $ | 611,618 |  |  | $ | 16,064 |  |  | $ | 7,135 |  |

[0000926326-23-000014:mdna:121]
[same as prior period, unchanged from 0000926326-22-000033:mdna:124]

[0000926326-23-000014:mdna:122]
[same as prior period, unchanged from 0000926326-22-000033:mdna:155]

[0000926326-23-000014:mdna:123]
[same as prior period, unchanged from 0000926326-22-000033:mdna:156]

[0000926326-23-000014:mdna:124]
[same as prior period, unchanged from 0000926326-22-000033:mdna:157]

[0000926326-23-000014:mdna:125]
(4)Refer to Note 13, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.
