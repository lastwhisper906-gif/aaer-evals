# OMCL 8-K — 0000926326-18-000022 filed 2018-07-26

## item codes, every 8-K on or before 2018-08-03

- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2018-08-03

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-18-000022:8k_2_02:1]
EX-99.1
2
exhibit991q218.htm
EXHIBIT 99.1

[0000926326-18-000022:8k_2_02:2]
Exhibit

[0000926326-18-000022:8k_2_02:3]
Exhibit 99.1

[0000926326-18-000022:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664 |  | Mountain View, CA 94043 |
| Peter.Kuipers@Omnicell.com |  |  |

[0000926326-18-000022:8k_2_02:5]
Omnicell Announces Second Quarter 2018 Results

[0000926326-18-000022:8k_2_02:6]
GAAP revenues of $189 million, up 4.2% year-over-year

[0000926326-18-000022:8k_2_02:7]
GAAP net income per diluted share of $0.16, up $0.11 year-over-year

[0000926326-18-000022:8k_2_02:8]
Non-GAAP revenues of $189 million, up 4.0% year-over-year

[0000926326-18-000022:8k_2_02:9]
Non-GAAP net income per diluted share of $0.46, up $0.13 year-over-year

[0000926326-18-000022:8k_2_02:10]
MOUNTAIN VIEW, Calif. -- July 26, 2018 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its second quarter ended June 30, 2018.

[0000926326-18-000022:8k_2_02:11]
GAAP Results

[0000926326-18-000022:8k_2_02:12]
GAAP revenues for the second quarter of 2018 were $188.7 million, up $7.6 million, or 4.2% from the second quarter of 2017. GAAP revenues for the six months ended June 30, 2018 were $371.3 million, up $41.7 million, or 12.7% from the six months ended June 30, 2017.

[0000926326-18-000022:8k_2_02:13]
Second quarter 2018 GAAP net income as reported was $6.6 million, or $0.16 per diluted share. This compares to GAAP net income of $1.9 million, or $0.05 per diluted share, for the second quarter of 2017.

[0000926326-18-000022:8k_2_02:14]
GAAP net income for the six months ended June 30, 2018 was $9.3 million, or $0.23 per diluted share. This compares to GAAP net loss of $8.5 million, or a net loss of $0.23 per diluted share, for the six months ended June 30, 2017.

[0000926326-18-000022:8k_2_02:15]
Non-GAAP Results

[0000926326-18-000022:8k_2_02:16]
Non-GAAP revenues for the second quarter of 2018 were $188.7 million, up $7.3 million, or 4.0% from the second quarter of 2017. Non-GAAP revenues for the six months ended June 30, 2018 were $371.3 million, up $41.1 million, or 12.4% from the six months ended June 30, 2017.

[0000926326-18-000022:8k_2_02:17]
Non-GAAP net income for the second quarter of 2018 was $18.4 million, or $0.46 per diluted share. This compares to non-GAAP net income of $12.8 million, or $0.33 per diluted share, for the second quarter of 2017.

[0000926326-18-000022:8k_2_02:18]
Non-GAAP net income for the six months ended June 30, 2018 was $29.8 million, or $0.75 per diluted share. This compares to non-GAAP net income of $15.3 million, or $0.40 per diluted share, for the six months ended June 30, 2017.

[0000926326-18-000022:8k_2_02:19]
Non-GAAP net income for each period excludes, when applicable, the effect of share-based compensation expense, amortization expense of acquired intangible assets, acquisition-related expenses, fair value adjustments related to business acquisitions, restructuring and severance-related expenses, tax reform and restructuring benefits, contingent gains, and amortization of debt issuance cost.

[0000926326-18-000022:8k_2_02:20]
Effective January 1, 2018, the Company adopted the new revenue recognition accounting standard, ASC 606, “Revenue from Contracts with Customers,” utilizing the full retrospective transition method. All 2017 financial results have been adjusted to reflect the change.

[0000926326-18-000022:8k_2_02:21]
“Medication management is playing an increasingly strategic role in patient outcomes and the financial success of healthcare institutions,” said Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell. “With a continued focus on digital transformation and strategic partnerships, we are driving efficiency and supporting patient safety through Omnicell’s industry-leading platform.”

[0000926326-18-000022:8k_2_02:22]
2018 Guidance

[0000926326-18-000022:8k_2_02:23]
For the third quarter of 2018, the Company expects non-GAAP revenues to be between $200 million and $206 million. The Company expects third quarter 2018 non-GAAP earnings to be between $0.52 and $0.57 per share.

[0000926326-18-000022:8k_2_02:24]
For the year 2018, the Company expects product bookings to be between $630 million and $665 million. The Company expects non-GAAP revenues to be between $780 million and $800 million, and non-GAAP earnings to be between $1.90 and $2.05 per share.

[0000926326-18-000022:8k_2_02:25]
The table below summarizes 2018 guidance outlined above.

[0000926326-18-000022:8k_2_02:26]
|  | Q3’18 | Total Year 2018 |
| Product Bookings | Not provided | $630 million - $665 million |
| Non-GAAP Revenues | $200 million - $206 million | $780 million - $800 million |
| Non-GAAP EPS | $0.52 - $0.57 | $1.90 - $2.05 |

[0000926326-18-000022:8k_2_02:27]
Omnicell Conference Call Information

[0000926326-18-000022:8k_2_02:28]
Omnicell will hold a conference call today, Thursday, July 26, 2018 at 1:30 p.m. PT to discuss second quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 7290938. Internet users can access the conference call at http://ir.omnicell.com/events.cfm.  A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on September 6, 2018. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 7290938.

[0000926326-18-000022:8k_2_02:29]
About Omnicell

[0000926326-18-000022:8k_2_02:30]
Since 1992, Omnicell (NASDAQ: OMCL) has been inspired to create safer and more efficient ways to manage medications and supplies across all care settings. Omnicell is revolutionizing the patient medication experience from hospital to home by empowering providers to keep each patient at the center of care. The Company’s autonomous approach to medication management leverages a differentiated platform for hardware and workflow software solutions, real-time predictive intelligence, and performance-driven partnerships to help drive operational, financial, and clinical success for customers.

[0000926326-18-000022:8k_2_02:31]
Supporting the highest level of patient safety is essential to excellent patient care. As a leader in medication and supply dispensing automation, central pharmacy automation, IV robotics, analytics software, and medication adherence and packaging systems, Omnicell is focused on delivering solutions for medication availability, affordability, safety, and adherence. Over 4,500 facilities worldwide use Omnicell® automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety.

[0000926326-18-000022:8k_2_02:32]
Omnicell’s innovative medication adherence solutions, used by over 32,000 institutional and retail pharmacies in North America and the United Kingdom, are designed to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-18-000022:8k_2_02:33]
For more information about Omnicell, Inc. please visit www.omnicell.com.

[0000926326-18-000022:8k_2_02:34]
Forward-Looking Statements

[0000926326-18-000022:8k_2_02:35]
Use of Non-GAAP Financial Information

[0000926326-18-000022:8k_2_02:36]
This press release contains financial measures that are not calculated in accordance with GAAP. Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP net income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-18-000022:8k_2_02:37]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-18-000022:8k_2_02:38]
| a) | Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell. |

[0000926326-18-000022:8k_2_02:39]
| b) | Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results. |

[0000926326-18-000022:8k_2_02:40]
| c) | Amortization of debt issuance cost. Debt issuance cost represents costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The cost includes underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results. |

[0000926326-18-000022:8k_2_02:41]
| d) | Acquisition accounting impact related to deferred revenues. In connection with recent acquisitions, business combination rules require us to account for the fair values of arrangements for which acceptance has not been obtained, and post installation support has not been provided in our purchase accounting. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business. |

[0000926326-18-000022:8k_2_02:42]
3

[0000926326-18-000022:8k_2_02:43]
| e) | Acquisition-related expenses. We excluded from the non-GAAP results the expenses which are related to recent acquisitions. These expenses are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition-related expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance and the financial results of less acquisitive peer companies. |

[0000926326-18-000022:8k_2_02:44]
| f) | Severance and other related expenses. We excluded from our non-GAAP results the expenses which are related to restructuring events. These expenses are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies. |

[0000926326-18-000022:8k_2_02:45]
| g) | Tax impact from restructuring activity. We excluded from our non-GAAP results the tax impacts related to restructuring activity. These impacts are unrelated to our ongoing operations, and we do not expect them to occur in the ordinary course of business. We believe that excluding these impacts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies. |

[0000926326-18-000022:8k_2_02:46]
| h) | Contingent gain. We excluded from our non-GAAP results the contingent gain related to a settlement agreement associated with the Ateb acquisition. This contingent gain is unrelated to our ongoing operations, and we do not expect it to occur in the ordinary course of business. We believe that excluding this contingent gain provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and the financial results of peer companies. |

[0000926326-18-000022:8k_2_02:47]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans or other items.

[0000926326-18-000022:8k_2_02:48]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-18-000022:8k_2_02:49]
| a) | Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business. |

[0000926326-18-000022:8k_2_02:50]
| b) | Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods. |

[0000926326-18-000022:8k_2_02:51]
| c) | These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting. |

[0000926326-18-000022:8k_2_02:52]
| d) | These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance. |

[0000926326-18-000022:8k_2_02:53]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-18-000022:8k_2_02:54]
| i) | While share-based compensation calculated in accordance with Accounting Standard Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results. |

[0000926326-18-000022:8k_2_02:55]
| ii) | We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results. |

[0000926326-18-000022:8k_2_02:56]
Our adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 share-based compensation expense, as well as certain non-GAAP adjustments.

[0000926326-18-000022:8k_2_02:57]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-18-000022:8k_2_02:58]
| a) | Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718. |

[0000926326-18-000022:8k_2_02:59]
| b) | Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure. |

[0000926326-18-000022:8k_2_02:60]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-18-000022:8k_2_02:61]
The Company’s 2018 guidance for non-GAAP earnings per share, as well as certain projections discussed in today’s teleconference, exclude “certain items,” which include but are not limited to: unusual gains and losses; costs associated with future restructurings; acquisition-related expenses; and certain tax and litigation outcomes. We do not provide a reconciliation of non-GAAP earnings per share guidance to the comparable GAAP measure as these items are inherently uncertain and difficult to estimate, and cannot be predicted without unreasonable effort. We believe such a reconciliation would imply a degree of precision that could be confusing to investors. These items may also have a material impact on GAAP earnings per share in future periods.

[0000926326-18-000022:8k_2_02:62]
5

[0000926326-18-000022:8k_2_02:63]
Omnicell, Inc.

[0000926326-18-000022:8k_2_02:64]
Condensed Consolidated Statements of Operations

[0000926326-18-000022:8k_2_02:65]
(Unaudited, in thousands, except per share data)

[0000926326-18-000022:8k_2_02:66]
|  | Three Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |
|  |  | As Adjusted* |  | As Reported |  | Change |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 134,636 |  |  | $ | 130,205 |  |  | $ | 128,056 |  |  | $ | 2,149 |  |
| Services and other revenues | 54,037 |  |  | 50,837 |  |  | 52,829 |  |  | (1,992 | ) |
| Total revenues | 188,673 |  |  | 181,042 |  |  | 180,885 |  |  | 157 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 75,076 |  |  | 81,738 |  |  | 81,738 |  |  | — |  |
| Cost of services and other revenues | 24,814 |  |  | 21,172 |  |  | 21,172 |  |  | — |  |
| Total cost of revenues | 99,890 |  |  | 102,910 |  |  | 102,910 |  |  | — |  |
| Gross profit | 88,783 |  |  | 78,132 |  |  | 77,975 |  |  | 157 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 15,512 |  |  | 16,911 |  |  | 16,911 |  |  | — |  |
| Selling, general, and administrative | 65,937 |  |  | 61,922 |  |  | 63,468 |  |  | (1,546 | ) |
| Total operating expenses | 81,449 |  |  | 78,833 |  |  | 80,379 |  |  | (1,546 | ) |
| Income (loss) from operations | 7,334 |  |  | (701 | ) |  | (2,404 | ) |  | 1,703 |  |
| Interest and other income (expense), net | (896 | ) |  | 196 |  |  | 196 |  |  | — |  |
| Income (loss) before provision for income taxes | 6,438 |  |  | (505 | ) |  | (2,208 | ) |  | 1,703 |  |
| Provision for (benefit from) income taxes | (150 | ) |  | (2,385 | ) |  | (3,045 | ) |  | 660 |  |
| Net income (loss) | $ | 6,588 |  |  | $ | 1,880 |  |  | $ | 837 |  |  | $ | 1,043 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.17 |  |  | $ | 0.05 |  |  | $ | 0.02 |  |  | $ | 0.03 |  |
| Diluted | $ | 0.16 |  |  | $ | 0.05 |  |  | $ | 0.02 |  |  | $ | 0.03 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 38,970 |  |  | 37,250 |  |  | 37,250 |  |  |  |
| Diluted | 40,000 |  |  | 38,370 |  |  | 38,370 |  |  |  |

[0000926326-18-000022:8k_2_02:67]
| * | As adjusted for full retrospective adoption of Accounting Standard Codification (“ASC”) 606, “Revenue from Contracts with Customers.” The adjustment also includes a $0.2 million reclassification from services and other revenues to product revenues to conform with current-period presentation. |

[0000926326-18-000022:8k_2_02:68]
Omnicell, Inc.

[0000926326-18-000022:8k_2_02:69]
Condensed Consolidated Statements of Operations

[0000926326-18-000022:8k_2_02:70]
(Unaudited, in thousands, except per share data)

[0000926326-18-000022:8k_2_02:71]
|  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017 |
|  |  | As Adjusted* |  | As Reported |  | Change |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 265,295 |  |  | $ | 228,996 |  |  | $ | 226,986 |  |  | $ | 2,010 |  |
| Services and other revenues | 105,997 |  |  | 100,599 |  |  | 104,453 |  |  | (3,854 | ) |
| Total revenues | 371,292 |  |  | 329,595 |  |  | 331,439 |  |  | (1,844 | ) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 150,493 |  |  | 145,326 |  |  | 145,326 |  |  | — |  |
| Cost of services and other revenues | 49,561 |  |  | 43,946 |  |  | 43,946 |  |  | — |  |
| Total cost of revenues | 200,054 |  |  | 189,272 |  |  | 189,272 |  |  | — |  |
| Gross profit | 171,238 |  |  | 140,323 |  |  | 142,167 |  |  | (1,844 | ) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 32,049 |  |  | 33,714 |  |  | 33,714 |  |  | — |  |
| Selling, general, and administrative | 131,222 |  |  | 123,862 |  |  | 128,093 |  |  | (4,231 | ) |
| Total operating expenses | 163,271 |  |  | 157,576 |  |  | 161,807 |  |  | (4,231 | ) |
| Income (loss) from operations | 7,967 |  |  | (17,253 | ) |  | (19,640 | ) |  | 2,387 |  |
| Interest and other income (expense), net | (3,625 | ) |  | (2,260 | ) |  | (2,260 | ) |  | — |  |
| Income (loss) before provision for income taxes | 4,342 |  |  | (19,513 | ) |  | (21,900 | ) |  | 2,387 |  |
| Provision for (benefit from) income taxes | (4,966 | ) |  | (11,058 | ) |  | (11,983 | ) |  | 925 |  |
| Net income (loss) | $ | 9,308 |  |  | $ | (8,455 | ) |  | $ | (9,917 | ) |  | $ | 1,462 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.24 |  |  | $ | (0.23 | ) |  | $ | (0.27 | ) |  | $ | 0.04 |  |
| Diluted | $ | 0.23 |  |  | $ | (0.23 | ) |  | $ | (0.27 | ) |  | $ | 0.04 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 38,804 |  |  | 37,046 |  |  | 37,046 |  |  |  |
| Diluted | 39,854 |  |  | 37,046 |  |  | 37,046 |  |  |  |

[0000926326-18-000022:8k_2_02:72]
| * | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” The adjustment also includes a $0.3 million reclassification from services and other revenues to product revenues to conform with current-period presentation. |

[0000926326-18-000022:8k_2_02:73]
7

[0000926326-18-000022:8k_2_02:74]
Omnicell, Inc.

[0000926326-18-000022:8k_2_02:75]
Condensed Consolidated Balance Sheets

[0000926326-18-000022:8k_2_02:76]
(Unaudited, in thousands)

[0000926326-18-000022:8k_2_02:77]
|  | June 30, 2018 |  | December 31, 2017 |
|  |  | As Adjusted* |  | As Reported |  | Change |
| ASSETS |
| Current assets: |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 46,168 |  |  | $ | 32,424 |  |  | $ | 32,424 |  |  | $ | — |  |
| Accounts receivable and unbilled, net | 174,570 |  |  | 190,046 |  |  | 189,227 |  |  | 819 |  |
| Inventories, net | 103,732 |  |  | 96,137 |  |  | 96,137 |  |  | — |  |
| Prepaid expenses | 18,266 |  |  | 20,392 |  |  | 36,060 |  |  | (15,668 | ) |
| Other current assets | 16,122 |  |  | 13,273 |  |  | 13,273 |  |  | — |  |
| Total current assets | 358,858 |  |  | 352,272 |  |  | 367,121 |  |  | (14,849 | ) |
| Property and equipment, net | 50,884 |  |  | 42,595 |  |  | 42,595 |  |  | — |  |
| Long-term investment in sales-type leases, net | 16,707 |  |  | 15,435 |  |  | 15,435 |  |  | — |  |
| Goodwill | 336,550 |  |  | 337,751 |  |  | 337,751 |  |  | — |  |
| Intangible assets, net | 155,750 |  |  | 168,107 |  |  | 168,107 |  |  | — |  |
| Long-term deferred tax assets | 9,451 |  |  | 9,454 |  |  | 9,454 |  |  | — |  |
| Prepaid commissions | 38,620 |  |  | 41,432 |  |  | — |  |  | 41,432 |  |
| Other long-term assets | 59,655 |  |  | 49,316 |  |  | 39,841 |  |  | 9,475 |  |
| Total assets | $ | 1,026,475 |  |  | $ | 1,016,362 |  |  | $ | 980,304 |  |  | $ | 36,058 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable | $ | 35,261 |  |  | $ | 48,290 |  |  | $ | 48,290 |  |  | $ | — |  |
| Accrued compensation | 31,168 |  |  | 27,241 |  |  | 27,241 |  |  | — |  |
| Accrued liabilities | 31,721 |  |  | 35,693 |  |  | 35,693 |  |  | — |  |
| Long-term debt, current portion, net | 17,708 |  |  | 15,208 |  |  | 15,208 |  |  | — |  |
| Deferred revenues, net | 85,776 |  |  | 78,774 |  |  | 86,104 |  |  | (7,330 | ) |
| Total current liabilities | 201,634 |  |  | 205,206 |  |  | 212,536 |  |  | (7,330 | ) |
| Long-term, deferred revenues | 8,957 |  |  | 10,623 |  |  | 17,244 |  |  | (6,621 | ) |
| Long-term deferred tax liabilities | 34,788 |  |  | 41,446 |  |  | 28,579 |  |  | 12,867 |  |
| Other long-term liabilities | 11,394 |  |  | 9,829 |  |  | 9,829 |  |  | — |  |
| Long-term debt, net | 181,062 |  |  | 194,917 |  |  | 194,917 |  |  | — |  |
| Total liabilities | 437,835 |  |  | 462,021 |  |  | 463,105 |  |  | (1,084 | ) |
| Total stockholders’ equity | 588,640 |  |  | 554,341 |  |  | 517,199 |  |  | 37,142 |  |
| Total liabilities and stockholders’ equity | $ | 1,026,475 |  |  | $ | 1,016,362 |  |  | $ | 980,304 |  |  | $ | 36,058 |  |

[0000926326-18-000022:8k_2_02:78]
| * | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” |

[0000926326-18-000022:8k_2_02:79]
Omnicell, Inc.

[0000926326-18-000022:8k_2_02:80]
Condensed Consolidated Statements of Cash Flows

[0000926326-18-000022:8k_2_02:81]
(Unaudited, in thousands)

[0000926326-18-000022:8k_2_02:82]
|  | Six months ended June 30, |
|  | 2018 |  | 2017* |
| Operating Activities |  |  |  |
| Net income (loss) | $ | 9,308 |  |  | $ | (8,455 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 24,829 |  |  | 25,942 |  |
| Loss on disposal of fixed assets | — |  |  | 79 |  |
| Share-based compensation expense | 13,766 |  |  | 11,056 |  |
| Income tax benefits from employee stock plans | — |  |  | 11 |  |
| Deferred income taxes | (6,655 | ) |  | (11,722 | ) |
| Amortization of debt financing fees | 1,145 |  |  | 795 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled | 15,476 |  |  | (1,058 | ) |
| Inventories | (9,789 | ) |  | (12,226 | ) |
| Prepaid expenses | 2,126 |  |  | 128 |  |
| Other current assets | (2,283 | ) |  | 202 |  |
| Investment in sales-type leases | (1,838 | ) |  | 5,482 |  |
| Prepaid commissions | 2,812 |  |  | 1,554 |  |
| Other long-term assets | (2,797 | ) |  | (622 | ) |
| Accounts payable | (12,229 | ) |  | 23,357 |  |
| Accrued compensation | 3,927 |  |  | 4,529 |  |
| Accrued liabilities | (2,574 | ) |  | 2,165 |  |
| Deferred revenues | 5,336 |  |  | (3,412 | ) |
| Other long-term liabilities | 167 |  |  | 1,119 |  |
| Net cash provided by operating activities | 40,727 |  |  | 38,924 |  |
| Investing Activities |  |  |  |
| Purchases of intangible assets, intellectual property, and patents | — |  |  | (160 | ) |
| Software development for external use | (13,091 | ) |  | (6,748 | ) |
| Purchases of property and equipment | (14,985 | ) |  | (6,493 | ) |
| Business acquisition, net of cash acquired | — |  |  | (4,446 | ) |
| Net cash used in investing activities | (28,076 | ) |  | (17,847 | ) |
| Financing Activities |  |  |  |
| Proceeds from debt | — |  |  | 10,000 |  |
| Repayment of debt and revolving credit facility | (12,500 | ) |  | (70,500 | ) |
| Proceeds from issuances under stock-based compensation plans | 16,117 |  |  | 15,783 |  |
| Employees’ taxes paid related to restricted stock units | (3,062 | ) |  | (2,638 | ) |
| Net cash provided by (used in) financing activities | 555 |  |  | (47,355 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 538 |  |  | (1,274 | ) |
| Net increase (decrease) in cash and cash equivalents | 13,744 |  |  | (27,552 | ) |
| Cash and cash equivalents at beginning of period | 32,424 |  |  | 54,488 |  |
| Cash and cash equivalents at end of period | $ | 46,168 |  |  | $ | 26,936 |  |

[0000926326-18-000022:8k_2_02:83]
| * | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” |

[0000926326-18-000022:8k_2_02:84]
9

[0000926326-18-000022:8k_2_02:85]
Omnicell, Inc.

[0000926326-18-000022:8k_2_02:86]
Reconciliation of GAAP to Non-GAAP

[0000926326-18-000022:8k_2_02:87]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-18-000022:8k_2_02:88]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017* |  | June 30, 2018 |  | June 30, 2017* |
| Reconciliation of GAAP revenues to non-GAAP revenues: |  |  |  |  |  |
| GAAP revenues | $ | 188,673 |  |  | $ | 181,042 |  |  | $ | 371,292 |  |  | $ | 329,595 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 313 |  |  | — |  |  | 626 |  |
| Non-GAAP revenues | $ | 188,673 |  |  | $ | 181,355 |  |  | $ | 371,292 |  |  | $ | 330,221 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit | $ | 88,783 |  |  | $ | 78,132 |  |  | $ | 171,238 |  |  | $ | 140,323 |  |
| GAAP gross margin | 47.1 | % |  | 43.2 | % |  | 46.1 | % |  | 42.6 | % |
| Share-based compensation expense | 1,177 |  |  | 864 |  |  | 2,196 |  |  | 1,846 |  |
| Amortization of acquired intangibles | 2,756 |  |  | 2,848 |  |  | 5,547 |  |  | 5,685 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 313 |  |  | — |  |  | 626 |  |
| Severance and other expenses | — |  |  | — |  |  | — |  |  | 1,697 |  |
| Non-GAAP gross profit | $ | 92,716 |  |  | $ | 82,157 |  |  | $ | 178,981 |  |  | $ | 150,177 |  |
| Non-GAAP gross margin | 49.1 | % |  | 45.3 | % |  | 48.2 | % |  | 45.5 | % |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 81,449 |  |  | $ | 78,833 |  |  | $ | 163,271 |  |  | $ | 157,576 |  |
| GAAP operating expenses % to total revenues | 43.2 | % |  | 43.5 | % |  | 44.0 | % |  | 47.8 | % |
| Share-based compensation expense | (6,061 | ) |  | (4,681 | ) |  | (11,570 | ) |  | (9,210 | ) |
| Amortization of acquired intangibles | (3,126 | ) |  | (3,626 | ) |  | (6,364 | ) |  | (7,279 | ) |
| Acquisition-related expenses | — |  |  | — |  |  | — |  |  | (126 | ) |
| Severance and other expenses | (1,735 | ) |  | (970 | ) |  | (3,247 | ) |  | (3,302 | ) |
| Non-GAAP operating expenses | $ | 70,527 |  |  | $ | 69,556 |  |  | $ | 142,090 |  |  | $ | 137,659 |  |
| Non-GAAP operating expenses % to total revenues | 37.4 | % |  | 38.4 | % |  | 38.3 | % |  | 41.7 | % |

[0000926326-18-000022:8k_2_02:89]
| * | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” |

[0000926326-18-000022:8k_2_02:90]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2018 |  | June 30, 2017* |  | June 30, 2018 |  | June 30, 2017* |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income (loss) from operations: |
| GAAP income (loss) from operations | $ | 7,334 |  |  | $ | (701 | ) |  | $ | 7,967 |  |  | $ | (17,253 | ) |
| GAAP operating income (loss) % to total revenues | 3.9 | % |  | (0.4 | )% |  | 2.1 | % |  | (5.2 | )% |
| Share-based compensation expense | 7,238 |  |  | 5,545 |  |  | 13,766 |  |  | 11,056 |  |
| Amortization of acquired intangibles | 5,882 |  |  | 6,474 |  |  | 11,911 |  |  | 12,964 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 313 |  |  | — |  |  | 626 |  |
| Acquisition-related expenses | — |  |  | — |  |  | — |  |  | 126 |  |
| Severance and other expenses | 1,735 |  |  | 970 |  |  | 3,247 |  |  | 4,999 |  |
| Non-GAAP income (loss) from operations | $ | 22,189 |  |  | $ | 12,601 |  |  | $ | 36,891 |  |  | $ | 12,518 |  |
| Non-GAAP operating income (loss) % to total Non-GAAP revenues | 11.8 | % |  | 6.9 | % |  | 9.9 | % |  | 3.8 | % |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |
| GAAP net income (loss) | $ | 6,588 |  |  | $ | 1,880 |  |  | $ | 9,308 |  |  | $ | (8,455 | ) |
| Tax benefit for restructuring activity | — |  |  | — |  |  | (4,205 | ) |  | — |  |
| Share-based compensation expense | 7,238 |  |  | 5,545 |  |  | 13,766 |  |  | 11,056 |  |
| Amortization of acquired intangibles | 5,882 |  |  | 6,474 |  |  | 11,911 |  |  | 12,964 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 313 |  |  | — |  |  | 626 |  |
| Acquisition-related expenses(c) | 397 |  |  | 397 |  |  | 794 |  |  | 920 |  |
| Severance and other expenses | 1,911 |  |  | 970 |  |  | 3,599 |  |  | 4,999 |  |
| Contingent gain | (2,456 | ) |  | — |  |  | (2,456 | ) |  | — |  |
| Tax effect of the adjustments above(a) | (1,204 | ) |  | (2,817 | ) |  | (2,907 | ) |  | (6,836 | ) |
| Non-GAAP net income | $ | 18,356 |  |  | $ | 12,762 |  |  | $ | 29,810 |  |  | $ | 15,274 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 40,000 |  |  | 38,370 |  |  | 39,854 |  |  | 37,046 |  |
| Shares - diluted Non-GAAP | 40,000 |  |  | 38,370 |  |  | 39,854 |  |  | 38,103 |  |
| GAAP net income (loss) per share - diluted | $ | 0.16 |  |  | $ | 0.05 |  |  | $ | 0.23 |  |  | $ | (0.23 | ) |
| Tax benefit for restructuring activity | — |  |  | — |  |  | (0.11 | ) |  | — |  |
| Share-based compensation expense | 0.18 |  |  | 0.14 |  |  | 0.35 |  |  | 0.29 |  |
| Amortization of acquired intangibles | 0.15 |  |  | 0.17 |  |  | 0.30 |  |  | 0.34 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 0.01 |  |  | — |  |  | 0.02 |  |
| Acquisition-related expenses | 0.01 |  |  | 0.01 |  |  | 0.02 |  |  | 0.03 |  |
| Severance and other expenses | 0.05 |  |  | 0.02 |  |  | 0.09 |  |  | 0.13 |  |
| Contingent gain | (0.06 | ) |  | — |  |  | (0.06 | ) |  | — |  |
| Tax effect of the adjustments above(a) | (0.03 | ) |  | (0.07 | ) |  | (0.07 | ) |  | (0.18 | ) |
| Non-GAAP net income per share - diluted | $ | 0.46 |  |  | $ | 0.33 |  |  | $ | 0.75 |  |  | $ | 0.40 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP Adjusted EBITDA(b): |  |  |  |  |  |
| GAAP net income (loss) | $ | 6,588 |  |  | $ | 1,880 |  |  | $ | 9,308 |  |  | $ | (8,455 | ) |
| Share-based compensation expense | 7,238 |  |  | 5,545 |  |  | 13,766 |  |  | 11,056 |  |
| Interest (income) and expense, net | 1,615 |  |  | 1,311 |  |  | 3,387 |  |  | 2,743 |  |
| Depreciation and amortization expense | 12,519 |  |  | 13,494 |  |  | 24,829 |  |  | 25,942 |  |

[0000926326-18-000022:8k_2_02:91]
11

[0000926326-18-000022:8k_2_02:92]
| Acquisition accounting impact related to deferred revenues | — |  |  | 313 |  |  | — |  |  | 626 |  |
| Acquisition-related expenses | 397 |  |  | 397 |  |  | 794 |  |  | 920 |  |
| Severance and other expenses | 1,911 |  |  | 728 |  |  | 3,599 |  |  | 4,493 |  |
| Contingent gain | (2,456 | ) |  | — |  |  | (2,456 | ) |  | — |  |
| Income tax expense (benefit) | (150 | ) |  | (2,385 | ) |  | (4,966 | ) |  | (11,058 | ) |
| Non-GAAP Adjusted EBITDA | $ | 27,662 |  |  | $ | 21,283 |  |  | $ | 48,261 |  |  | $ | 26,267 |  |

[0000926326-18-000022:8k_2_02:93]
| (a) | Tax effects calculated for all adjustments except tax benefits and share-based compensation expense, using an estimated annual effective tax rate of 21% for fiscal year 2018 and 35% for fiscal year 2017. |

[0000926326-18-000022:8k_2_02:94]
| (b) | Defined as earnings before interest income and expense, taxes, depreciation and amortization, as well as excluding certain non-GAAP adjustments. |

[0000926326-18-000022:8k_2_02:95]
| (c) | Includes amortization of debt financing fees associated with our debt facilities. |

[0000926326-18-000022:8k_2_02:96]
12

[0000926326-18-000022:8k_2_02:97]
Omnicell, Inc.

[0000926326-18-000022:8k_2_02:98]
Segmented Information

[0000926326-18-000022:8k_2_02:99]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000022:8k_2_02:100]
|  | Three Months Ended June 30, 2018 |  | Three Months Ended June 30, 2017 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics* |  | MedicationAdherence |  | Total* |
| Revenues | $ | 158,365 |  |  | $ | 30,308 |  |  | $ | 188,673 |  |  | $ | 148,584 |  |  | $ | 32,458 |  |  | $ | 181,042 |  |
| Cost of revenues | 78,686 |  |  | 21,204 |  |  | 99,890 |  |  | 80,716 |  |  | 22,194 |  |  | 102,910 |  |
| Gross profit | 79,679 |  |  | 9,104 |  |  | 88,783 |  |  | 67,868 |  |  | 10,264 |  |  | 78,132 |  |
| Gross margin % | 50.3 | % |  | 30.0 | % |  | 47.1 | % |  | 45.7 | % |  | 31.6 | % |  | 43.2 | % |
| Operating expenses | 48,167 |  |  | 10,296 |  |  | 58,463 |  |  | 47,508 |  |  | 10,099 |  |  | 57,607 |  |
| Income (loss) from segment operations | $ | 31,512 |  |  | $ | (1,192 | ) |  | $ | 30,320 |  |  | $ | 20,360 |  |  | $ | 165 |  |  | $ | 20,525 |  |
| Operating margin % | 19.9 | % |  | (3.9 | )% |  | 16.1 | % |  | 13.7 | % |  | 0.5 | % |  | 11.3 | % |
| Corporate costs |  |  |  |  | 22,986 |  |  |  |  |  |  | 21,226 |  |
| Income (loss) from operations |  |  |  |  | $ | 7,334 |  |  |  |  |  |  | $ | (701 | ) |

[0000926326-18-000022:8k_2_02:101]
| * | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” |

[0000926326-18-000022:8k_2_02:102]
13

[0000926326-18-000022:8k_2_02:103]
Omnicell, Inc.

[0000926326-18-000022:8k_2_02:104]
Segmented Information

[0000926326-18-000022:8k_2_02:105]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000022:8k_2_02:106]
|  | Six Months Ended June 30, 2018 |  | Six Months Ended June 30, 2017 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics* |  | MedicationAdherence |  | Total* |
| Revenues | $ | 309,771 |  |  | $ | 61,521 |  |  | $ | 371,292 |  |  | $ | 270,754 |  |  | $ | 58,841 |  |  | $ | 329,595 |  |
| Cost of revenues | 156,928 |  |  | 43,126 |  |  | 200,054 |  |  | 149,477 |  |  | 39,795 |  |  | 189,272 |  |
| Gross profit | 152,843 |  |  | 18,395 |  |  | 171,238 |  |  | 121,277 |  |  | 19,046 |  |  | 140,323 |  |
| Gross margin % | 49.3 | % |  | 29.9 | % |  | 46.1 | % |  | 44.8 | % |  | 32.4 | % |  | 42.6 | % |
| Operating expenses | 96,558 |  |  | 20,495 |  |  | 117,053 |  |  | 95,570 |  |  | 21,295 |  |  | 116,865 |  |
| Income (loss) from segment operations | $ | 56,285 |  |  | $ | (2,100 | ) |  | $ | 54,185 |  |  | $ | 25,707 |  |  | $ | (2,249 | ) |  | $ | 23,458 |  |
| Operating margin % | 18.2 | % |  | (3.4 | )% |  | 14.6 | % |  | 9.5 | % |  | (3.8 | )% |  | 7.1 | % |
| Corporate costs |  |  |  |  | 46,218 |  |  |  |  |  |  | 40,711 |  |
| Income (loss) from operations |  |  |  |  | $ | 7,967 |  |  |  |  |  |  | $ | (17,253 | ) |

[0000926326-18-000022:8k_2_02:107]
| * | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” |

[0000926326-18-000022:8k_2_02:108]
14

[0000926326-18-000022:8k_2_02:109]
Omnicell, Inc.

[0000926326-18-000022:8k_2_02:110]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-18-000022:8k_2_02:111]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000022:8k_2_02:112]
|  | Three Months Ended June 30, 2018 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenues |  | % of Non-GAAP Revenues |  | Amount |  | % of GAAP Revenues |  | % of Non-GAAP Revenues |  | Amount |  | % of GAAP Revenues |  | % of Non-GAAP Revenues |
| Revenues | $ | 158,365 |  |  |  |  |  |  | $ | 30,308 |  |  |  |  |  |  | $ | 188,673 |  |  |  |  |  |
| Non-GAAP Revenues | $ | 158,365 |  |  |  |  |  |  | $ | 30,308 |  |  |  |  |  |  | $ | 188,673 |  |  |  |  |  |
| GAAP Gross profit | $ | 79,679 |  |  | 50.3 | % |  |  |  | $ | 9,104 |  |  | 30.0 | % |  |  |  | $ | 88,783 |  |  | 47.1 | % |  |  |
| Share-based compensation expense | 1,004 |  |  | 0.6 | % |  | 0.6 | % |  | 173 |  |  | 0.6 | % |  | 0.6 | % |  | 1,177 |  |  | 0.6 | % |  | 0.6 | % |
| Amortization expense of acquired intangible assets | 2,232 |  |  | 1.4 | % |  | 1.4 | % |  | 524 |  |  | 1.7 | % |  | 1.7 | % |  | 2,756 |  |  | 1.5 | % |  | 1.5 | % |
| Non-GAAP Gross profit | $ | 82,915 |  |  |  |  | 52.4 | % |  | $ | 9,801 |  |  |  |  | 32.3 | % |  | $ | 92,716 |  |  |  |  | 49.1 | % |
| GAAP Operating income (loss) | $ | 31,512 |  |  | 19.9 | % |  |  |  | $ | (1,192 | ) |  | (3.9 | )% |  |  |  | $ | 30,320 |  |  | 16.1 | % |  |  |
| Share-based compensation expense | 3,148 |  |  | 2.0 | % |  | 2.0 | % |  | 489 |  |  | 1.6 | % |  | 1.6 | % |  | 3,637 |  |  | 1.9 | % |  | 1.9 | % |
| Amortization expense of acquired intangible assets | 4,204 |  |  | 2.7 | % |  | 2.7 | % |  | 1,678 |  |  | 5.5 | % |  | 5.5 | % |  | 5,882 |  |  | 3.1 | % |  | 3.1 | % |
| Severance and other expenses | 996 |  |  | 0.6 | % |  | 0.6 | % |  | (25 | ) |  | (0.1 | )% |  | (0.1 | )% |  | 971 |  |  | 0.5 | % |  | 0.5 | % |
| Non-GAAP Operating income | $ | 39,860 |  |  |  |  | 25.2 | % |  | $ | 950 |  |  |  |  | 3.1 | % |  | $ | 40,810 |  |  |  |  | 21.6 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 22,986 |  |  | 12.2 | % |  |  |
| Share-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (3,601 | ) |  | (1.9 | )% |  | (1.9 | )% |
| Severance and other expenses |  |  |  |  |  |  |  |  |  |  |  |  | (764 | ) |  | (0.4 | )% |  | (0.4 | )% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 18,621 |  |  |  |  | 9.9 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 22,189 |  |  |  |  | 11.8 | % |

[0000926326-18-000022:8k_2_02:113]
15

[0000926326-18-000022:8k_2_02:114]
Omnicell, Inc.

[0000926326-18-000022:8k_2_02:115]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-18-000022:8k_2_02:116]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000022:8k_2_02:117]
|  | Three Months Ended June 30, 2017 |  |  |
|  | Automation andAnalytics* |  | MedicationAdherence |  | Total* |
|  | Amount |  | % of GAAP Revenues |  | % of Non-GAAP Revenues |  | Amount |  | % of GAAP Revenues |  | % of Non-GAAP Revenues |  | Amount |  | % of GAAP Revenues |  | % of Non-GAAP Revenues |
| Revenues | $ | 148,584 |  |  |  |  |  |  | $ | 32,458 |  |  |  |  |  |  | $ | 181,042 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | — | % |  | — | % |  | 313 |  |  | 1.0 | % |  | 1.0 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Non-GAAP Revenues | $ | 148,584 |  |  |  |  |  |  | $ | 32,771 |  |  |  |  |  |  | $ | 181,355 |  |  |  |  |  |
| GAAP Gross profit | $ | 67,868 |  |  | 45.7 | % |  |  |  | $ | 10,264 |  |  | 31.6 | % |  |  |  | $ | 78,132 |  |  | 43.2 | % |  |  |
| Share-based compensation expense | 736 |  |  | 0.5 | % |  | 0.5 | % |  | 128 |  |  | 0.4 | % |  | 0.4 | % |  | 864 |  |  | 0.5 | % |  | 0.5 | % |
| Amortization expense of acquired intangible assets | 2,228 |  |  | 1.5 | % |  | 1.5 | % |  | 620 |  |  | 1.9 | % |  | 1.9 | % |  | 2,848 |  |  | 1.6 | % |  | 1.6 | % |
| Acquisition accounting impact related to deferred revenues | — |  |  | — | % |  | — | % |  | 313 |  |  | 1.0 | % |  | 1.0 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Non-GAAP Gross profit | $ | 70,832 |  |  |  |  | 47.7 | % |  | $ | 11,325 |  |  |  |  | 34.6 | % |  | $ | 82,157 |  |  |  |  | 45.3 | % |
| GAAP Operating income (loss) | $ | 20,360 |  |  | 13.7 | % |  |  |  | $ | 165 |  |  | 0.5 | % |  |  |  | $ | 20,525 |  |  | 11.3 | % |  |  |
| Share-based compensation expense | 2,275 |  |  | 1.5 | % |  | 1.5 | % |  | 354 |  |  | 1.1 | % |  | 1.1 | % |  | 2,629 |  |  | 1.5 | % |  | 1.4 | % |
| Amortization expense of acquired intangible assets | 4,545 |  |  | 3.1 | % |  | 3.1 | % |  | 1,929 |  |  | 5.9 | % |  | 5.9 | % |  | 6,474 |  |  | 3.6 | % |  | 3.6 | % |
| Acquisition accounting impact related to deferred revenues | — |  |  | — | % |  | — | % |  | 313 |  |  | 1.0 | % |  | 1.0 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Severance and other expenses | 610 |  |  | 0.4 | % |  | 0.4 | % |  | — |  |  | — | % |  | — | % |  | 610 |  |  | 0.3 | % |  | 0.3 | % |
| Non-GAAP Operating income | $ | 27,790 |  |  |  |  | 18.7 | % |  | $ | 2,761 |  |  |  |  | 8.4 | % |  | $ | 30,551 |  |  |  |  | 16.8 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 21,226 |  |  | 11.7 | % |  |  |
| Share-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (2,916 | ) |  | (1.6 | )% |  | (1.6 | )% |
| Severance and other expenses |  |  |  |  |  |  |  |  |  |  |  |  | (360 | ) |  | (0.2 | )% |  | (0.2 | )% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 17,950 |  |  |  |  | 9.9 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 12,601 |  |  |  |  | 6.9 | % |

[0000926326-18-000022:8k_2_02:118]
| * | As adjusted for full retrospective adoption of ASC 606, “Revenue from Contracts with Customers.” |

[0000926326-18-000022:8k_2_02:119]
16
