# OMCL note change history — 0000926326-18-000015 → 0000926326-18-000025


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-08-03):
[0000926326-18-000025:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At June 30, 2018, the minimum future payments on non-cancelable operating leases were as follows:
  (was, 2018-05-04, similarity 0.983):
[0000926326-18-000015:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At March 31, 2018, the minimum future payments on non-cancelable operating leases were as follows:

- changed (2018-08-03):
[0000926326-18-000025:note_history:2]
|  | (In thousands) |
| Remaining six months of 2018 | $ | 6,651 |  |
| 2019 | 13,264 |  |
| 2020 | 11,399 |  |
| 2021 | 10,465 |  |
| 2022 | 8,660 |  |
| Thereafter | 26,707 |  |
| Total minimum future lease payments | $ | 77,146 |  |
  (was, 2018-05-04, similarity 0.9861):
[0000926326-18-000015:note_history:2]
|  | (In thousands) |
| Remaining nine months of 2018 | $ | 8,896 |  |
| 2019 | 11,763 |  |
| 2020 | 10,803 |  |
| 2021 | 10,515 |  |
| 2022 | 8,818 |  |
| Thereafter | 26,383 |  |
| Total minimum future lease payments | $ | 77,178 |  |

- changed (2018-08-03):
[0000926326-18-000025:note_history:3]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At June 30, 2018, the Company had non-cancelable purchase commitments of $56.2 million, which are expected to be paid within the next twelve months.
  (was, 2018-05-04, similarity 0.9822):
[0000926326-18-000015:note_history:3]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At March 31, 2018, the Company had non-cancelable purchase commitments of $55.4 million, which are expected to be paid within the next twelve months.

- changed (2018-08-03):
[0000926326-18-000025:note_history:4]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.
  (was, 2018-05-04, similarity 0.999):
[0000926326-18-000015:note_history:4]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

- changed (2018-08-03):
[0000926326-18-000025:note_history:5]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint seeks monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not yet been served with the complaint. The Company intends to defend the lawsuit vigorously.
  (was, 2018-05-04, similarity 0.9818):
[0000926326-18-000015:note_history:5]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al. (Case No. CL18-152-1). The complaint seeks monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention and training and, as against the Company and Aesynt, claims of product liability, negligence and breach of implied warranties. The Company and Aesynt have not yet been served with the complaint. The Company intends to defend the lawsuit vigorously.

- added (2018-08-03):
[0000926326-18-000025:note_history:6]
On June 6, 2018, a class-action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. Counsel for the proposed class filed a motion to certify the class; the court continued the motion and scheduled a status conference for October 4, 2018. The Company’s obligation to respond to the complaint has been held in abeyance until further determination by the court. The Company intends to defend the lawsuit vigorously.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-08-03):
[0000926326-18-000025:note_history:7]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products are automated medication, supply control systems and medication adherence solutions which are sold in its principal market, which is the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.
  (was, 2018-05-04, similarity 0.9415):
[0000926326-18-000015:note_history:7]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company's major products are automated medication, supply control systems and medication adherence solutions which are sold in its principal market, which is the healthcare industry. The Company's market is primarily located in the United States and Europe. "Omnicell" or the "Company" collectively refer to Omnicell, Inc. and its subsidiaries.

- changed (2018-08-03):
[0000926326-18-000025:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2018 and December 31, 2017, and the results of its operations, comprehensive income (loss), and cash flows for the three and six months ended June 30, 2018 and June 30, 2017. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2017 filed with the SEC on February 27, 2018, except as discussed in the section entitled “Revenue Recognition” below. The Company’s results of operations, comprehensive income (loss) and cash flows for the three and six months ended June 30, 2018 are not necessarily indicative of results that may be expected for the year ending December 31, 2018, or for any future period.
  (was, 2018-05-04, similarity 0.8707):
[0000926326-18-000015:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2018 and December 31, 2017, the results of its operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2018 and March 31, 2017. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2017 filed with the SEC on February 27, 2018, except as discussed in the "Revenue recognition" below. The Company's results of operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2018 are not necessarily indicative of results that may be expected for the year ending December 31, 2018, or for any future period.

- changed (2018-08-03):
[0000926326-18-000025:note_history:9]
Certain prior-year amounts have been adjusted to conform with the adoption of ASC 606, Revenue from Contracts with Customers (“ASC 606”), which became effective for the Company beginning on January 1, 2018. Refer to “Recently Adopted Authoritative Guidance” for the effects of adoption of ASC 606 and the section below for the updated revenue recognition policy.
  (was, 2018-05-04, similarity 0.9714):
[0000926326-18-000015:note_history:9]
Certain prior year amounts have been adjusted to conform with the adoption of ASC 606, Revenue from Contracts with Customers ("ASC 606"), which became effective for the Company beginning on January 1, 2018. Refer to "Recently adopted authoritative guidance" for the effects of adoption of ASC 606 and the section below for the updated revenue recognition policy.

- added (2018-08-03):
[0000926326-18-000025:note_history:10]
Certain prior-year amounts have been reclassified to conform with current-period presentation. These reclassifications include (i) reclassification of revenues from services and other revenues to product revenues of $0.2 million and $0.3 million for the three and six months ended June 30, 2017, respectively, related to software term-license sales, (ii) change in inventories presentation related to allocation of inventories obsolete reserve between finished goods, raw materials, and work in progress in the Notes to the Condensed Consolidated Financial Statements, and (iii) change in intangible assets presentation related to presenting foreign currency impact separately in the Notes to the Condensed Consolidated Financial Statements. These changes were not deemed material and were included to conform with current-period classification and presentation.

- added (2018-08-03):
[0000926326-18-000025:note_history:11]
The Company earns revenues from sales of its medication and medical and surgical supply automation systems, along with consumables and related services, which are sold in the healthcare industry, its principal market. The transaction price of each contract with a customer is allocated to the identified performance obligations based on the relative fair value of each obligation. The Company’s customer arrangements typically include one or more of the following performance obligations:

- changed (2018-08-03):
[0000926326-18-000025:note_history:12]
Installation. Installation of equipment as integrated systems at customers’ sites.
  (was, 2018-05-04, similarity 0.9878):
[0000926326-18-000015:note_history:12]
Installation. Installation of equipment as integrated systems at customers' sites.

- changed (2018-08-03):
[0000926326-18-000025:note_history:13]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.
  (was, 2018-05-04, similarity 0.9968):
[0000926326-18-000015:note_history:13]
Post-installation technical support. Phone support, on-site service, parts and access to unspecified software updates and enhancements, if and when available.

- changed (2018-08-03):
[0000926326-18-000025:note_history:14]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following the Company’s standard business process and terms.
  (was, 2018-05-04, similarity 0.9167):
[0000926326-18-000015:note_history:14]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following our standard business process and terms.

- changed (2018-08-03):
[0000926326-18-000025:note_history:15]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract.) The Company’s agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.
  (was, 2018-05-04, similarity 0.9969):
[0000926326-18-000015:note_history:15]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract.) The Company's agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.

- changed (2018-08-03):
[0000926326-18-000025:note_history:16]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues at June 30, 2018 and December 31, 2017 was $94.7 million and $89.4 million, respectively, of which $85.8 million and $78.8 million, respectively, are expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.
  (was, 2018-05-04, similarity 0.9803):
[0000926326-18-000015:note_history:16]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service.  Determining when control transfers requires management to make judgments that affect the timing of revenue recognized.  Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligation at March 31, 2018 and December 31, 2017 was $104.5 million and $89.4 million, respectively, of which $95.7 million and $78.8 million, respectively, was expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

- changed (2018-08-03):
[0000926326-18-000025:note_history:17]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.
  (was, 2018-05-04, similarity 0.9944):
[0000926326-18-000015:note_history:17]
Revenues, contract assets and contract liabilities are recorded net of associated taxes.

- added (2018-08-03):
[0000926326-18-000025:note_history:18]
The payment terms associated with the Company’s contracts vary, however, payment terms for product revenues are generally based on milestones tied to contract signing, shipment of products, and/or customer acceptance. Payment terms associated with the service portion of agreements are generally periodic and can be billed on a monthly, quarterly, or annual basis. In certain circumstances multiple years are billed at one time. The portion of these contract liabilities not expected to be recognized as revenue within twelve months of the balance sheet date are considered long term.

- changed (2018-08-03):
[0000926326-18-000025:note_history:19]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 42% of the lease receivable balance, are retained in-house. Revenues from sales-type leases of $7.6 million and $10.2 million for the three months ended June 30, 2018 and 2017, respectively, and $17.4 million and $13.4 million for the six months ended June 30, 2018 and 2017, respectively, are included in product revenues in the Condensed Consolidated Statements of Operations. Interest income in these leases is recognized in product revenues using the effective interest method.
  (was, 2018-05-04, similarity 0.8138):
[0000926326-18-000015:note_history:19]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 40% of the lease receivable balance, are retained in-house. Revenue from sales-type leases of $9.8 million and $3.2 million for the three months ended March 31, 2018 and 2017, respectively, is included in product revenue in the Condensed Consolidated Statements of Operations. Interest income in these leases is recognized in product revenue using the effective interest method.

- changed (2018-08-03):
[0000926326-18-000025:note_history:20]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.1 million and $1.2 million for the three months ended June 30, 2018 and 2017, respectively, and $4.0 million and $3.3 million for the six months ended June 30, 2018 and 2017, respectively.
  (was, 2018-05-04, similarity 0.8569):
[0000926326-18-000015:note_history:20]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations ("GPOs"). GPOs are often owned fully or in part by the Company’s customers and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $1.9 million and $2.1 million for the quarters ended March 31, 2018 and 2017, respectively.

- changed (2018-08-03):
[0000926326-18-000025:note_history:21]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts, and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.
  (was, 2018-05-04, similarity 0.9994):
[0000926326-18-000015:note_history:21]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

- added (2018-08-03):
[0000926326-18-000025:note_history:22]
|  | June 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 6,031 |  |  | $ | 4,590 |  |
| Long-term unbilled receivables - included in other long-term assets | 12,150 |  |  | 9,475 |  |
| Total contract assets | $ | 18,181 |  |  | $ | 14,065 |  |
| Short-term deferred revenues | $ | 85,776 |  |  | $ | 78,774 |  |
| Long-term deferred revenues | 8,957 |  |  | 10,623 |  |
| Total contract liabilities | $ | 94,733 |  |  | $ | 89,397 |  |

- changed (2018-08-03):
[0000926326-18-000025:note_history:23]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenues in the normal course of business. Unbilled contract assets which were invoiced during the three and six months ended June 30, 2018 as a result of the right to invoice for the transaction consideration becoming unconditional were not material. The contract modifications entered into during the three and six months ended June 30, 2018 did not have a significant impact on the Company’s contract assets or deferred revenues. During the three and six months ended June 30, 2018, the Company recognized revenues of $21.4 million and $68.0 million, respectively, that was included in the corresponding deferred revenue balance as of December 31, 2017.
  (was, 2018-05-04, similarity 0.836):
[0000926326-18-000015:note_history:23]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenue in the normal course of business. Unbilled contract assets which were invoiced during the three months ended March 31, 2018 as a result of the right to invoice for the transaction consideration becoming unconditional were not material. The contract modifications entered into during the three months ended March 31, 2018, did not have a significant impact on the Company’s contract assets or deferred revenues. During the three months ended March 31, 2018, the Company recognized revenue of $46.6 million that was included in the corresponding deferred revenue balance as of December 31, 2017.

- changed (2018-08-03):
[0000926326-18-000025:note_history:24]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods. The Company recognized contract cost expense of $5.3 million and $4.6 million during the three months ended June 30, 2018 and 2017, respectively, and $10.9 million and $8.7 million during the six months ended June 30, 2018 and 2017, respectively. The portion of commission expenses paid as of the balance sheet date to be recognized in future periods is recorded in long term prepaid commissions expense on the Condensed Consolidated Balance Sheets. There was no impairment loss in relation to the costs capitalized during the three and six months ended June 30, 2018.
  (was, 2018-05-04, similarity 0.9493):
[0000926326-18-000015:note_history:24]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio.  A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods. During the three months ended March 31, 2018 and March 31, 2017, the Company recognized contract cost expense of $5.6 million and $4.1 million, respectively. The portion of commission expenses paid as of the balance sheet date to be recognized in future periods is recorded in long term prepaid commissions expense on the Condensed Consolidated Balance Sheets. There was no impairment loss in relation to the costs capitalized during the three months ended March 31, 2018.

- changed (2018-08-03):
[0000926326-18-000025:note_history:25]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases; inventory valuation; capitalized software development costs; valuation and impairment of goodwill; purchased intangibles and long-lived assets; fair value of assets acquired and liabilities assumed in business combination; share-based compensation; and accounting for income taxes.
  (was, 2018-05-04, similarity 0.9901):
[0000926326-18-000015:note_history:25]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company's Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company's critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, accounts receivable and notes receivable from investment in sales-type leases, inventory valuation, capitalized software development costs, valuation and impairment of goodwill, purchased intangibles and long-lived assets, fair value of assets acquired and liabilities assumed in business combination, share-based compensation, and accounting for income taxes.

- changed (2018-08-03):
[0000926326-18-000025:note_history:26]
The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company’s segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management; finance and accounting; human resources; legal; training and development; and certain other administrative expenses. See Note 14, Segment and Geographical Information, for additional information on segment reporting.
  (was, 2018-05-04, similarity 0.8818):
[0000926326-18-000015:note_history:26]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain other administrative expenses.  See Note 14, Segment and Geographical Information, for additional information on segment reporting.

- changed (2018-08-03):
[0000926326-18-000025:note_history:27]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued ASC 606, Revenue from Contracts with Customers, a new standard related to revenue recognition. Under the new standard, revenue is recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In addition, the standard requires disclosure of the nature, amount, timing, and uncertainty of revenues and cash flows arising from contracts with customers. The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method). The Company adopted the standard using the full retrospective method effective beginning January 1, 2018.
  (was, 2018-05-04, similarity 0.8998):
[0000926326-18-000015:note_history:27]
In May 2014, the Financial Accounting Standards Board ("FASB") issued ASC 606, Revenue from Contracts with Customers, a new standard related to revenue recognition. Under the new standard, revenue is recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In addition, the standard requires disclosure of the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method). We adopted the standard using the full retrospective method effective beginning January 1, 2018.

- changed (2018-08-03):
[0000926326-18-000025:note_history:28]
Under the ASC 606 guidance, fees paid to GPOs are now presented as a reduction of product revenues, whereas these fees were considered a part of selling, general, and administrative costs under the previous guidance. The majority of the incremental costs incurred to obtain a contract, primarily commission expense, are recognized during the first year with the balance recognized ratably over a period of ten years. Additionally, revenue on term software licenses is recognized upon installation of the license rather than ratably over the life of the term license. Finally, the Company no longer defers the contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price.
  (was, 2018-05-04, similarity 0.9234):
[0000926326-18-000015:note_history:28]
Under the ASC 606 guidance, fees paid to GPOs are now presented as a reduction of Product Revenue, whereas these fees were considered a part of Selling, General and Administrative costs under the previous guidance. The majority of the incremental costs incurred to obtain a contract, primarily commission expense, are recognized during the first year with the balance recognized ratably over a period of ten years. Additionally, revenue on term software licenses is recognized upon installation of the license rather than ratably over the life of the term license. Finally, the Company no longer defers the contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price. Adoption of the standard related to revenue recognition impacted our reported results for the three months period, as follows:

- added (2018-08-03):
[0000926326-18-000025:note_history:29]
Adoption of the standard related to revenue recognition impacted the Company’s reported results as follows:

- changed (2018-08-03):
[0000926326-18-000025:note_history:30]
|  | Three months ended June 30, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 148,427 |  |  | $ | 157 |  |  | $ | 148,584 |  |
| Medication Adherence | 32,458 |  |  | — |  |  | 32,458 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 67,711 |  |  | 157 |  |  | 67,868 |  |
| Medication Adherence | 10,264 |  |  | — |  |  | 10,264 |  |
| Selling, general, and administrative expenses | 63,468 |  |  | (1,546 | ) |  | 61,922 |  |
| Provision for (benefit from) income taxes | (3,045 | ) |  | 660 |  |  | (2,385 | ) |
| Net income | $ | 837 |  |  | $ | 1,043 |  |  | $ | 1,880 |  |
| Net income per share | $ | 0.02 |  |  | $ | 0.03 |  |  | $ | 0.05 |  |
  (was, 2018-05-04, similarity 0.7034):
[0000926326-18-000015:note_history:30]
|  | March 31, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenue |  |  |  |  |  |
| Automation and Analytics | $ | 124,171 |  |  | $ | (2,001 | ) |  | $ | 122,170 |  |
| Medication Adherence | 26,383 |  |  | — |  |  | 26,383 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 55,410 |  |  | (2,001 | ) |  | 53,409 |  |
| Medication Adherence | 8,782 |  |  | — |  |  | 8,782 |  |
| Selling, general and administrative expenses | 64,625 |  |  | (2,685 | ) |  | 61,940 |  |
| Provision for income taxes | (8,938 | ) |  | 265 |  |  | (8,673 | ) |
| Net income | $ | (10,754 | ) |  | $ | 419 |  |  | $ | (10,335 | ) |
| Earnings per share | $ | (0.29 | ) |  | $ | 0.01 |  |  | $ | (0.28 | ) |

- added (2018-08-03):
[0000926326-18-000025:note_history:31]
|  | Six months ended June 30, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 272,598 |  |  | $ | (1,844 | ) |  | $ | 270,754 |  |
| Medication Adherence | 58,841 |  |  | — |  |  | 58,841 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 123,121 |  |  | (1,844 | ) |  | 121,277 |  |
| Medication Adherence | 19,046 |  |  | — |  |  | 19,046 |  |
| Selling, general, and administrative expenses | 128,093 |  |  | (4,231 | ) |  | 123,862 |  |
| Provision for (benefit from) income taxes | (11,983 | ) |  | 925 |  |  | (11,058 | ) |
| Net income (loss) | $ | (9,917 | ) |  | $ | 1,462 |  |  | $ | (8,455 | ) |
| Net income (loss) per share | $ | (0.27 | ) |  | $ | 0.04 |  |  | $ | (0.23 | ) |

- changed (2018-08-03):
[0000926326-18-000025:note_history:32]
|  | December 31, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Accounts receivable and unbilled receivables, net | $ | 189,227 |  |  | $ | 819 |  |  | $ | 190,046 |  |
| Prepaid expenses | 36,060 |  |  | (15,668 | ) |  | 20,392 |  |
| Prepaid commissions | — |  |  | 41,432 |  |  | 41,432 |  |
| Other long-term assets | 39,841 |  |  | 9,475 |  |  | 49,316 |  |
| Deferred revenues, net | 86,104 |  |  | (7,330 | ) |  | 78,774 |  |
| Long-term, deferred revenues | 17,244 |  |  | (6,621 | ) |  | 10,623 |  |
| Long-term, deferred tax liabilities | 28,579 |  |  | 12,867 |  |  | 41,446 |  |
| Stockholders’ equity | 517,199 |  |  | 37,142 |  |  | 554,341 |  |
  (was, 2018-05-04, similarity 0.9849):
[0000926326-18-000015:note_history:32]
|  | December 31, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Accounts receivable and unbilled, net | $ | 189,227 |  |  | $ | 819 |  |  | $ | 190,046 |  |
| Prepaid expenses | 36,060 |  |  | (15,668 | ) |  | 20,392 |  |
| Prepaid commissions | — |  |  | 41,432 |  |  | 41,432 |  |
| Other long-term assets | 39,841 |  |  | 9,475 |  |  | 49,316 |  |
| Deferred revenue, net | 86,104 |  |  | (7,330 | ) |  | 78,774 |  |
| Long-term, deferred revenue | 17,244 |  |  | (6,621 | ) |  | 10,623 |  |
| Long-term, deferred tax liabilities | 28,579 |  |  | 12,867 |  |  | 41,446 |  |
| Stockholders' equity | 517,199 |  |  | 37,142 |  |  | 554,341 |  |

- added (2018-08-03):
[0000926326-18-000025:note_history:33]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount and timing of cash flows from leases. This new guidance will be effective for the Company beginning January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. The Company is currently evaluating the impact ASU 2016-02 will have on its consolidated financial statements.

- added (2018-08-03):
[0000926326-18-000025:note_history:34]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects.” ASU 2018-02 will be effective for the Company beginning January 1, 2019. The Company does not expect application of this guidance to have a material effect on its consolidated financial statements.

- changed (2018-08-03):
[0000926326-18-000025:note_history:35]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.
  (was, 2018-05-04, similarity 0.9951):
[0000926326-18-000015:note_history:35]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company's Condensed Consolidated Financial Statements through the reporting date.

- removed (2018-08-03):
[0000926326-18-000015:note_history:36]
The Company earns revenues from sales of its medication and medical and surgical supply automation systems along with consumables and related services, which are sold in the healthcare industry, our principal market. The transaction price of each contract with a customer is allocated to identified performance obligations based on the relative fair value of each obligation. The Company's customer arrangements typically include one or more of the following performance obligations:

- removed (2018-08-03):
[0000926326-18-000015:note_history:37]
The payment terms associated with the Company’s contracts vary, however, payment terms for product revenue are generally based on milestones tied to contract signing, shipment of products and/or customer acceptance. Payment terms associated with the service portion of agreements are generally periodic and can be billed on a monthly, quarterly or annual basis. In certain circumstances multiple years are billed at one time. The portion of these contract liabilities not expected to be recognized as revenue within twelve months of the balance sheet date are considered long term.

- removed (2018-08-03):
[0000926326-18-000015:note_history:38]
|  | March 31, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Short-term unbilled receivable - included in accounts receivable and unbilled | $ | 4,859 |  |  | $ | 4,590 |  |
| Long-term unbilled receivable - included in other long-term assets | 10,877 |  |  | 9,475 |  |
| Total contract assets | $ | 15,736 |  |  | $ | 14,065 |  |
| Short-term deferred revenue | $ | 95,709 |  |  | $ | 78,774 |  |
| Long-term deferred revenue | 8,806 |  |  | 10,623 |  |
| Total contract liabilities | $ | 104,515 |  |  | $ | 89,397 |  |

- removed (2018-08-03):
[0000926326-18-000015:note_history:39]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects”. ASU 2018-02 will be effective for the Company beginning January 1, 2019. The Company is currently in the process of evaluating the impact of adoption on the consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-03):
[0000926326-18-000025:note_history:40]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.
  (was, 2018-05-04, similarity 0.8997):
[0000926326-18-000015:note_history:40]
On January 5, 2016, the Company entered into a $400 million senior secured credit facility pursuant to a credit agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200 million, which was subsequently increased pursuant to the amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

- changed (2018-08-03):
[0000926326-18-000025:note_history:41]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s consolidated total net leverage ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio will accrue on the average daily amount of letter of credit exposure.
  (was, 2018-05-04, similarity 0.999):
[0000926326-18-000015:note_history:41]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the 2016 Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s consolidated total net leverage ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio will accrue on the average daily amount of letter of credit exposure.

- changed (2018-08-03):
[0000926326-18-000025:note_history:42]
The Credit Agreement contains customary representations and warranties, and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Company’s obligations under the Credit Agreement, and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender), are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.
  (was, 2018-05-04, similarity 0.9982):
[0000926326-18-000015:note_history:42]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.

- changed (2018-08-03):
[0000926326-18-000025:note_history:43]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement (the “Amended Credit Agreement”). Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant, and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.
  (was, 2018-05-04, similarity 0.994):
[0000926326-18-000015:note_history:43]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement (the "Amended Credit Agreement"). Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

- changed (2018-08-03):
[0000926326-18-000025:note_history:44]
On December 26, 2017, the parties entered into another amendment (the “Amendment”) to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million, and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.
  (was, 2018-05-04, similarity 0.7788):
[0000926326-18-000015:note_history:44]
On December 26, 2017, the parties entered into another amendment (the "Amendment") to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.

- changed (2018-08-03):
[0000926326-18-000025:note_history:45]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.9 million and $1.5 million for the three months ended June 30, 2018 and 2017, respectively, and approximately $3.8 million and $3.0 million for the six months ended June 30, 2018 and 2017, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million and $0.4 million for the three months ended June 30, 2018 and 2017, respectively, and approximately $1.1 million and $0.8 million for the six months ended June 30, 2018 and 2017, respectively. The Company was in compliance with all covenants as of June 30, 2018 and December 31, 2017.
  (was, 2018-05-04, similarity 0.8739):
[0000926326-18-000015:note_history:45]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.9 million and $1.5 million for the three months ended March 31, 2018 and 2017, respectively. Amortization expense related to fees and issuance cost was approximately$0.6 million and $0.4 million for the three months ended March 31, 2018 and 2017, respectively. The Company was in compliance with all covenants as of March 31, 2018 and December 31, 2017.

- added (2018-08-03):
[0000926326-18-000025:note_history:46]
During the six months ended June 30, 2018, the Company repaid $12.5 million under these Facilities.

- added (2018-08-03):
[0000926326-18-000025:note_history:47]
The components of the Company’s debt obligations as of June 30, 2018 and December 31, 2017 were as follows:

- added (2018-08-03):
[0000926326-18-000025:note_history:48]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | June 30, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (7,500 | ) |  | $ | 175,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | (5,000 | ) |  | 29,500 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (12,500 | ) |  | 204,500 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 1,145 |  |  | (5,730 | ) |
| Total debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (11,355 | ) |  | $ | 198,770 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 181,062 |  |

- changed (2018-08-03):
[0000926326-18-000025:note_history:49]
As of June 30, 2018, the carrying amount of debt of $204.5 million approximates the comparable fair value of $207.4 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of June 30, 2018 as compared to the period as of December 31, 2017.
  (was, 2018-05-04, similarity 0.8621):
[0000926326-18-000015:note_history:49]
As of March 31, 2018, the carrying amount of debt of $214.5 million approximates the comparable fair value of $217.6 million. The Company's debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments, and long-term credit ratings.

- removed (2018-08-03):
[0000926326-18-000015:note_history:50]
As of March 31, 2018 the Company has repaid $139.5 million borrowed under these Facilities, which includes $2.5 million repaid during the three months ended March 31, 2018. The components of the Company’s debt obligations as of March 31, 2018 and December 31, 2017 are as follows:

- removed (2018-08-03):
[0000926326-18-000015:note_history:51]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | March 31, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (2,500 | ) |  | $ | 180,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | — |  |  | 34,500 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (2,500 | ) |  | 214,500 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 573 |  |  | (6,302 | ) |
| Total Debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (1,927 | ) |  | $ | 208,198 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 190,490 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-03):
[0000926326-18-000025:note_history:52]
The components of the Company’s debt obligations as of June 30, 2018 and December 31, 2017 were as follows:
  (was, 2018-05-04, similarity 0.9381):
[0000926326-18-000015:note_history:52]
The components of the Company’s debt obligations as of March 31, 2018 and December 31, 2017 are as follows:

- added (2018-08-03):
[0000926326-18-000025:note_history:53]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | June 30, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (7,500 | ) |  | $ | 175,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | (5,000 | ) |  | 29,500 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (12,500 | ) |  | 204,500 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 1,145 |  |  | (5,730 | ) |
| Total debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (11,355 | ) |  | $ | 198,770 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 181,062 |  |

- removed (2018-08-03):
[0000926326-18-000015:note_history:54]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | March 31, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (2,500 | ) |  | $ | 180,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | — |  |  | 34,500 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (2,500 | ) |  | 214,500 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 573 |  |  | (6,302 | ) |
| Total Debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (1,927 | ) |  | $ | 208,198 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 190,490 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-08-03):
[0000926326-18-000025:note_history:55]
Contract Costs

- added (2018-08-03):
[0000926326-18-000025:note_history:56]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods.

- added (2018-08-03):
[0000926326-18-000025:note_history:57]
Revenue Recognition

- added (2018-08-03):
[0000926326-18-000025:note_history:58]
The Company earns revenues from sales of its medication and medical and surgical supply automation systems, along with consumables and related services, which are sold in the healthcare industry, its principal market. The transaction price of each contract with a customer is allocated to the identified performance obligations based on the relative fair value of each obligation. The Company’s customer arrangements typically include one or more of the following performance obligations:

- added (2018-08-03):
[0000926326-18-000025:note_history:59]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

- added (2018-08-03):
[0000926326-18-000025:note_history:60]
Software. Additional software applications that enable incremental functionality of its equipment.

- added (2018-08-03):
[0000926326-18-000025:note_history:61]
Installation. Installation of equipment as integrated systems at customers’ sites.

- added (2018-08-03):
[0000926326-18-000025:note_history:62]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.

- added (2018-08-03):
[0000926326-18-000025:note_history:63]
Professional services. Other customer services, such as training and consulting.

- added (2018-08-03):
[0000926326-18-000025:note_history:64]
Prior to recognizing revenue, the Company identifies the contract, performance obligations, and transaction price, and allocates the transaction price to the performance obligations. All identified contracts meet the following required criteria:

- added (2018-08-03):
[0000926326-18-000025:note_history:65]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of the Company’s contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via phone or a manual purchase order.

- added (2018-08-03):
[0000926326-18-000025:note_history:66]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following the Company’s standard business process and terms.

- added (2018-08-03):
[0000926326-18-000025:note_history:67]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 days from shipment of tangible product or services performed. Where a written contract does not exist, the Company’s standard payment terms are net 30 day terms.

- added (2018-08-03):
[0000926326-18-000025:note_history:68]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract.) The Company’s agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.

- added (2018-08-03):
[0000926326-18-000025:note_history:69]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. The Company performs a credit check for all significant customers or transactions and where collectability is not probable, payment in full or a substantial down payment is typically required to help assure the full agreed upon contract price will be collected.

- added (2018-08-03):
[0000926326-18-000025:note_history:70]
The Company often enters into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. The Company’s change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

- added (2018-08-03):
[0000926326-18-000025:note_history:71]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, the Company combines the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify its performance obligations, the Company considers all of the products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, the Company considers an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of the Company’s sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, consumables and software products, support and maintenance, and professional services.

- added (2018-08-03):
[0000926326-18-000025:note_history:72]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of the Company’s commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

- added (2018-08-03):
[0000926326-18-000025:note_history:73]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an expected cost plus a margin approach to identify the standalone selling price of goods where separate sales transactions do not exist. For software and services which do not have a specific identifiable product cost, the Company uses a discounted from the list price amount as a best estimated selling price.

- added (2018-08-03):
[0000926326-18-000025:note_history:74]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues at June 30, 2018 and December 31, 2017 was $94.7 million and $89.4 million, respectively, of which $85.8 million and $78.8 million, respectively, are expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

- added (2018-08-03):
[0000926326-18-000025:note_history:75]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

- added (2018-08-03):
[0000926326-18-000025:note_history:76]
The payment terms associated with the Company’s contracts vary, however, payment terms for product revenues are generally based on milestones tied to contract signing, shipment of products, and/or customer acceptance. Payment terms associated with the service portion of agreements are generally periodic and can be billed on a monthly, quarterly, or annual basis. In certain circumstances multiple years are billed at one time. The portion of these contract liabilities not expected to be recognized as revenue within twelve months of the balance sheet date are considered long term.

- added (2018-08-03):
[0000926326-18-000025:note_history:77]
In the normal course of business, the Company typically does not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. The Company establishes provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to the Condensed Consolidated Financial Statements for any periods presented.

- added (2018-08-03):
[0000926326-18-000025:note_history:78]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 42% of the lease receivable balance, are retained in-house. Revenues from sales-type leases of $7.6 million and $10.2 million for the three months ended June 30, 2018 and 2017, respectively, and $17.4 million and $13.4 million for the six months ended June 30, 2018 and 2017, respectively, are included in product revenues in the Condensed Consolidated Statements of Operations. Interest income in these leases is recognized in product revenues using the effective interest method.

- added (2018-08-03):
[0000926326-18-000025:note_history:79]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.1 million and $1.2 million for the three months ended June 30, 2018 and 2017, respectively, and $4.0 million and $3.3 million for the six months ended June 30, 2018 and 2017, respectively.

- added (2018-08-03):
[0000926326-18-000025:note_history:80]
Contract Assets and Contract Liabilities

- added (2018-08-03):
[0000926326-18-000025:note_history:81]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts, and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-08-03):
[0000926326-18-000025:note_history:82]
Deferred Revenues

- added (2018-08-03):
[0000926326-18-000025:note_history:83]
Short-term deferred revenues of $85.8 million and $78.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $14.6 million and $16.9 million as of June 30, 2018 and December 31, 2017, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

- added (2018-08-03):
[0000926326-18-000025:note_history:84]
Long-term deferred revenues include deferred revenues from service contracts of $9.0 million and $10.6 million, as of June 30, 2018 and December 31, 2017, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2018-08-03):
[0000926326-18-000015:note_history:85]
Subsequent Event

- removed (2018-08-03):
[0000926326-18-000015:note_history:86]
On April 30, 2018, the Company entered into a settlement agreement related to certain contingencies associated with the Ateb 2016 acquisition. The settlement, which will be recognized in the second quarter of 2018, is for approximately $2.5 million.
