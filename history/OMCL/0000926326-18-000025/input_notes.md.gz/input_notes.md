# OMCL notes — 0000926326-18-000025


## omcl:ScheduleofLongTermNetInvestmentinSaleTypeLeasesTableTextBlock

[0000926326-18-000025:notes:1]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at June 30, 2018 and December 31, 2017:

[0000926326-18-000025:notes:2]
|  | June 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 27,303 |  |  | $ | 25,899 |  |
| Less: Unearned interest income portion | (2,141 | ) |  | (1,695 | ) |
| Net investment in sales-type leases | 25,162 |  |  | 24,204 |  |
| Less: Short-term portion(1) | (8,455 | ) |  | (8,769 | ) |
| Long-term net investment in sales-type leases | $ | 16,707 |  |  | $ | 15,435 |  |

[0000926326-18-000025:notes:3]
_________________________________________________

[0000926326-18-000025:notes:4]
| (1) | The short-term portion of the net investments in sales-type leases is included in other current assets in the Condensed Consolidated Balance Sheets. |


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-18-000025:notes:5]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of June 30, 2018:

[0000926326-18-000025:notes:6]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 3,509 |  |
| Non-vested restricted share awards | 723 |  |
| Shares authorized for future issuance | 3,306 |  |
| ESPP shares available for future issuance | 2,077 |  |
| Total shares reserved for future issuance | 9,615 |  |


## srt:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-18-000025:notes:7]
Balance sheet details as of June 30, 2018 and December 31, 2017 are presented in the tables below:

[0000926326-18-000025:notes:8]
|  | June 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 32,046 |  |  | $ | 31,275 |  |
| Work in process | 13,028 |  |  | 8,718 |  |
| Finished goods | 58,658 |  |  | 56,144 |  |
| Total inventories | $ | 103,732 |  |  | $ | 96,137 |  |
| Property and equipment: |  |  |  |
| Equipment | $ | 75,205 |  |  | $ | 69,550 |  |
| Furniture and fixtures | 6,779 |  |  | 6,534 |  |
| Leasehold improvements | 15,598 |  |  | 10,976 |  |
| Software | 39,502 |  |  | 37,168 |  |
| Construction in progress | 12,493 |  |  | 9,813 |  |
| Property and equipment, gross | 149,577 |  |  | 134,041 |  |
| Accumulated depreciation and amortization | (98,693 | ) |  | (91,446 | ) |
| Total property and equipment, net | $ | 50,884 |  |  | $ | 42,595 |  |

[0000926326-18-000025:notes:9]
|  | June 30, 2018 |  | December 31, 2017 |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 46,141 |  |  | $ | 38,599 |  |
| Unbilled receivables | 12,150 |  |  | 9,475 |  |
| Other assets | 1,364 |  |  | 1,242 |  |
| Total other long term assets, net | $ | 59,655 |  |  | $ | 49,316 |  |
| Accrued liabilities: |  |  |  |
| Advance payments from customers | $ | 7,140 |  |  | $ | 7,779 |  |
| Rebates and lease buyouts | 5,195 |  |  | 5,428 |  |
| Group purchasing organization fees | 3,677 |  |  | 3,449 |  |
| Taxes payable | 6,067 |  |  | 9,183 |  |
| Other accrued liabilities | 9,642 |  |  | 9,854 |  |
| Total accrued liabilities | $ | 31,721 |  |  | $ | 35,693 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-18-000025:notes:10]
Basis of Presentation

[0000926326-18-000025:notes:11]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2018 and December 31, 2017, and the results of its operations, comprehensive income (loss), and cash flows for the three and six months ended June 30, 2018 and June 30, 2017. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2017 filed with the SEC on February 27, 2018, except as discussed in the section entitled “Revenue Recognition” below. The Company’s results of operations, comprehensive income (loss) and cash flows for the three and six months ended June 30, 2018 are not necessarily indicative of results that may be expected for the year ending December 31, 2018, or for any future period.


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-18-000025:notes:12]
[same as prior period, unchanged from 0000926326-18-000015:notes:10]

[0000926326-18-000025:notes:13]
On a recurring basis, the Company enters into sales-type lease transactions with the majority varying in length from one to five years. The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at June 30, 2018 and December 31, 2017:

[0000926326-18-000025:notes:14]
The Company evaluates its sales-type leases individually and collectively for impairment. The allowance for credit losses was $0.2 million as of June 30, 2018 and December 31, 2017, respectively.

[0000926326-18-000025:notes:15]
At June 30, 2018, the future minimum lease payments under sales-type leases were as follows:

[0000926326-18-000025:notes:16]
|  | June 30, 2018 |
|  | (In thousands) |
| Remaining six months of 2018 | $ | 5,259 |  |
| 2019 | 7,635 |  |
| 2020 | 5,765 |  |
| 2021 | 3,944 |  |
| 2022 | 3,299 |  |
| Thereafter | 1,401 |  |
| Total | $ | 27,303 |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-18-000025:notes:17]
Commitments and Contingencies

[0000926326-18-000025:notes:18]
Lease Commitments

[0000926326-18-000025:notes:19]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At June 30, 2018, the minimum future payments on non-cancelable operating leases were as follows:

[0000926326-18-000025:notes:20]
|  | (In thousands) |
| Remaining six months of 2018 | $ | 6,651 |  |
| 2019 | 13,264 |  |
| 2020 | 11,399 |  |
| 2021 | 10,465 |  |
| 2022 | 8,660 |  |
| Thereafter | 26,707 |  |
| Total minimum future lease payments | $ | 77,146 |  |

[0000926326-18-000025:notes:21]
Purchase Obligations

[0000926326-18-000025:notes:22]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At June 30, 2018, the Company had non-cancelable purchase commitments of $56.2 million, which are expected to be paid within the next twelve months.

[0000926326-18-000025:notes:23]
Legal Proceedings

[0000926326-18-000025:notes:24]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

[0000926326-18-000025:notes:25]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint seeks monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not yet been served with the complaint. The Company intends to defend the lawsuit vigorously.

[0000926326-18-000025:notes:26]
On June 6, 2018, a class-action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. Counsel for the proposed class filed a motion to certify the class; the court continued the motion and scheduled a status conference for October 4, 2018. The Company’s obligation to respond to the complaint has been held in abeyance until further determination by the court. The Company intends to defend the lawsuit vigorously.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-18-000025:notes:27]
Principles of Consolidation

[0000926326-18-000025:notes:28]
[same as prior period, unchanged from 0000926326-18-000015:notes:25]


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000926326-18-000025:notes:29]
The following table reflects the Company’s contract assets and contract liabilities:

[0000926326-18-000025:notes:30]
|  | June 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 6,031 |  |  | $ | 4,590 |  |
| Long-term unbilled receivables - included in other long-term assets | 12,150 |  |  | 9,475 |  |
| Total contract assets | $ | 18,181 |  |  | $ | 14,065 |  |
| Short-term deferred revenues | $ | 85,776 |  |  | $ | 78,774 |  |
| Long-term deferred revenues | 8,957 |  |  | 10,623 |  |
| Total contract liabilities | $ | 94,733 |  |  | $ | 89,397 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-18-000025:notes:31]
Debt

[0000926326-18-000025:notes:32]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-18-000025:notes:33]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s consolidated total net leverage ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-18-000025:notes:34]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-18-000025:notes:35]
The Credit Agreement contains customary representations and warranties, and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Company’s obligations under the Credit Agreement, and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender), are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.

[0000926326-18-000025:notes:36]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement (the “Amended Credit Agreement”). Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant, and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

[0000926326-18-000025:notes:37]
On December 26, 2017, the parties entered into another amendment (the “Amendment”) to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million, and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.

[0000926326-18-000025:notes:38]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.9 million and $1.5 million for the three months ended June 30, 2018 and 2017, respectively, and approximately $3.8 million and $3.0 million for the six months ended June 30, 2018 and 2017, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million and $0.4 million for the three months ended June 30, 2018 and 2017, respectively, and approximately $1.1 million and $0.8 million for the six months ended June 30, 2018 and 2017, respectively. The Company was in compliance with all covenants as of June 30, 2018 and December 31, 2017.

[0000926326-18-000025:notes:39]
During the six months ended June 30, 2018, the Company repaid $12.5 million under these Facilities.

[0000926326-18-000025:notes:40]
The components of the Company’s debt obligations as of June 30, 2018 and December 31, 2017 were as follows:

[0000926326-18-000025:notes:41]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | June 30, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (7,500 | ) |  | $ | 175,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | (5,000 | ) |  | 29,500 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (12,500 | ) |  | 204,500 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 1,145 |  |  | (5,730 | ) |
| Total debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (11,355 | ) |  | $ | 198,770 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 181,062 |  |

[0000926326-18-000025:notes:42]
As of June 30, 2018, the carrying amount of debt of $204.5 million approximates the comparable fair value of $207.4 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of June 30, 2018 as compared to the period as of December 31, 2017.


## us-gaap:EarningsPerShareTextBlock

[0000926326-18-000025:notes:43]
[same as prior period, unchanged from 0000926326-18-000015:notes:40]

[0000926326-18-000025:notes:44]
Basic net income (loss) per share is computed by dividing net income (loss) for the period by the weighted-average number of shares outstanding during the period, less shares repurchased. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units computed using the treasury stock method. Any anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share.

[0000926326-18-000025:notes:45]
The basic and diluted net income (loss) per share calculation for the three and six months ended June 30, 2018 and 2017 was as follows:

[0000926326-18-000025:notes:46]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | 6,588 |  |  | $ | 1,880 |  |  | $ | 9,308 |  |  | $ | (8,455 | ) |
| Weighted-average shares outstanding — basic | 38,970 |  |  | 37,250 |  |  | 38,804 |  |  | 37,046 |  |
| Effect of dilutive securities from stock award plans | 1,030 |  |  | 1,120 |  |  | 1,050 |  |  | — |  |
| Weighted-average shares outstanding — diluted | $ | 40,000 |  |  | $ | 38,370 |  |  | 39,854 |  |  | 37,046 |  |
| Net income (loss) per share - basic | $ | 0.17 |  |  | $ | 0.05 |  |  | $ | 0.24 |  |  | $ | (0.23 | ) |
| Net income (loss) per share - diluted | $ | 0.16 |  |  | $ | 0.05 |  |  | $ | 0.23 |  |  | $ | (0.23 | ) |
| Anti-dilutive weighted-average shares related to stock award plans | 1,264 |  |  | 2,121 |  |  | 1,249 |  |  | 4,039 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-18-000025:notes:47]
[same as prior period, unchanged from 0000926326-18-000015:notes:47]

[0000926326-18-000025:notes:48]
[same as prior period, unchanged from 0000926326-18-000015:notes:48]

[0000926326-18-000025:notes:49]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of June 30, 2018:

[0000926326-18-000025:notes:50]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 1,270 |  |  | $ | — |  |  | $ | 1,270 |  |
| Total financial assets | $ | — |  |  | $ | 1,270 |  |  | $ | — |  |  | $ | 1,270 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-18-000025:notes:51]
[same as prior period, unchanged from 0000926326-18-000015:notes:49]

[0000926326-18-000025:notes:52]
Cash and cash equivalents of $46.2 million and $32.4 million as of June 30, 2018 and December 31, 2017, respectively, consisted of demand deposits only.

[0000926326-18-000025:notes:53]
[same as prior period, unchanged from 0000926326-18-000015:notes:51]

[0000926326-18-000025:notes:54]
The Company uses interest rate swap agreements to protect the Company against adverse fluctuations in interest rates by reducing its exposure to variability in cash flows relating to interest payments on a portion of its outstanding debt. The Company’s interest rate swaps, which are designated as cash flow hedges, involve the receipt of variable amounts from counterparties in exchange for the Company making fixed-rate payments over the life of the agreements. The Company does not hold or issue any derivative financial instruments for speculative trading purposes.

[0000926326-18-000025:notes:55]
During 2016, the Company entered into an interest rate swap agreement with a combined notional amount of $100.0 million with one counterparty that became effective on June 30, 2016 and is maturing on April 30, 2019. The swap agreement requires the Company to pay a fixed rate of 0.8% and provides that the Company will receive a variable rate based on the one month LIBOR rate subject to a LIBOR floor of 0.0%. Amounts payable by or due to the Company will be net settled with the respective counterparty on the last business day of each month, commencing July 31, 2016.

[0000926326-18-000025:notes:56]
The fair value of the interest rate swap agreements at June 30, 2018 and December 31, 2017 was $1.3 million and $1.4 million, respectively. There were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.

[0000926326-18-000025:notes:57]
Fair Value Hierarchy

[0000926326-18-000025:notes:58]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s interest rate swap contracts and foreign currency contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments.

[0000926326-18-000025:notes:59]
There were no transfers between fair value measurement levels during the six months ended June 30, 2018 and 2017.

[0000926326-18-000025:notes:60]
Net Investment in Sales-Type Leases. The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value, as the unearned interest income is immaterial.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-18-000025:notes:61]
[same as prior period, unchanged from 0000926326-18-000015:notes:58]

[0000926326-18-000025:notes:62]
[same as prior period, unchanged from 0000926326-18-000015:notes:59]

[0000926326-18-000025:notes:63]
[same as prior period, unchanged from 0000926326-18-000015:notes:60]

[0000926326-18-000025:notes:64]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2017 | $ | 220,851 |  |  | $ | 116,900 |  |  | $ | 337,751 |  |
| Foreign currency exchange rate fluctuations | (881 | ) |  | (320 | ) |  | (1,201 | ) |
| Net balance as of June 30, 2018 | $ | 219,970 |  |  | $ | 116,580 |  |  | $ | 336,550 |  |

[0000926326-18-000025:notes:65]
Intangible Assets, Net

[0000926326-18-000025:notes:66]
The carrying amounts of intangible assets as of June 30, 2018 and December 31, 2017 were as follows:

[0000926326-18-000025:notes:67]
|  | June 30, 2018 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 135,234 |  |  | $ | (39,709 | ) |  | $ | (1,034 | ) |  | $ | 94,491 |  |  | 1 - 30 |
| Acquired technology | 74,222 |  |  | (25,152 | ) |  | 125 |  |  | 49,195 |  |  | 3 - 20 |
| Backlog | 21,350 |  |  | (18,943 | ) |  | — |  |  | 2,407 |  |  | 1 - 4 |
| Trade names | 7,650 |  |  | (4,025 | ) |  | 22 |  |  | 3,647 |  |  | 1 - 12 |
| Patents | 3,239 |  |  | (1,434 | ) |  | 5 |  |  | 1,810 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (1,600 | ) |  | — |  |  | 300 |  |  | 3 |
| In-process technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | — |
| Total intangibles assets, net | $ | 247,495 |  |  | $ | (90,863 | ) |  | $ | (882 | ) |  | $ | 155,750 |  |  |  |

[0000926326-18-000025:notes:68]
|  | December 31, 2017 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 135,234 |  |  | $ | (33,988 | ) |  | $ | (787 | ) |  | $ | 100,459 |  |  | 1 - 30 |
| Acquired technology | 74,222 |  |  | (21,345 | ) |  | 221 |  |  | 53,098 |  |  | 3 - 20 |
| Backlog | 21,350 |  |  | (17,182 | ) |  | — |  |  | 4,168 |  |  | 1 - 4 |
| Trade names | 7,650 |  |  | (3,688 | ) |  | 40 |  |  | 4,002 |  |  | 1 - 12 |
| Patents | 3,239 |  |  | (1,369 | ) |  | 10 |  |  | 1,880 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (1,300 | ) |  | — |  |  | 600 |  |  | 3 |
| In-process technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | — |
| Total intangibles assets, net | $ | 247,495 |  |  | $ | (78,872 | ) |  | $ | (516 | ) |  | $ | 168,107 |  |  |  |

[0000926326-18-000025:notes:69]
Amortization expense of intangible assets was $6.0 million and $6.8 million for the three months ended June 30, 2018 and 2017, respectively. Amortization expense of intangible assets was $12.0 million and $13.0 million for the six months ended June 30, 2018 and 2017, respectively.

[0000926326-18-000025:notes:70]
The estimated future amortization expenses for amortizable intangible assets were as follows:

[0000926326-18-000025:notes:71]
|  | June 30, 2018 |
|  | (In thousands) |
| Remaining six months of 2018 | $ | 11,479 |  |
| 2019 | 17,949 |  |
| 2020 | 16,746 |  |
| 2021 | 15,320 |  |
| 2022 | 13,968 |  |
| Thereafter (excluding in-process technology) | 76,388 |  |
| Total | $ | 151,850 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-18-000025:notes:72]
[same as prior period, unchanged from 0000926326-18-000015:notes:69]

[0000926326-18-000025:notes:73]
On December 22, 2017, the Tax Act was signed into law, most provisions of which became effective starting in 2018, including the reduction of the statutory corporate income tax rate from 35% to 21%. As of June 30, 2018, the Company has not completed the accounting for the tax effects of enactment of the Tax Act; however, in the fourth quarter of 2017, the Company made a reasonable estimate of the effects on the existing deferred tax balances and the one-time transition tax. No adjustments to the provisional amounts recorded in the fourth quarter of 2017 were made during the three and six months ended June 30, 2018, respectively. For the six months ended June 30, 2018, the Company assessed the effect of certain international provisions of the Tax Act that became effective January 1, 2018, and determined that these provisions had an immaterial impact; therefore, the Company did not record any impact as a result of the assessment. The Company will continue to analyze the provision for income taxes under the Tax Act as future guidance is issued. Any revisions will be treated in accordance with the measurement period guidance outlined in SEC Staff Accounting Bulletin No. 118.

[0000926326-18-000025:notes:74]
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 16.5% and 41.1% for the six months ended June 30, 2018 and 2017, respectively.

[0000926326-18-000025:notes:75]
The 2018 annual effective tax rate differed from the statutory rate of 21% primarily due to the favorable impact of the research and development credits and foreign rate differential, which were partially offset by the unfavorable impact of state income taxes, non-deductible expenses, and non-deductible equity charges. The 2017 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, foreign rate differential, and non-deductible equity charges, which were partially offset by the domestic production activities deduction and the research and development credits.

[0000926326-18-000025:notes:76]
As of June 30, 2018 and December 31, 2017, the Company had gross unrecognized tax benefits of $11.6 million and $10.7 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in operating expense. As of June 30, 2018 and December 31, 2017, the amount of accrued interest and penalties was $1.7 million and $1.4 million, respectively.

[0000926326-18-000025:notes:77]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of June 30, 2018, the Company is no longer subject to U.S., state, and foreign examination for years before 2014, 2013, and 2014, respectively.

[0000926326-18-000025:notes:78]
Although the Company believes it has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. It is not possible at this time to reasonably estimate changes in the unrecognized tax benefits within the next twelve months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000926326-18-000025:notes:79]
Property and Equipment, Net

[0000926326-18-000025:notes:80]
|  | June 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| United States | $ | 43,490 |  |  | $ | 34,899 |  |
| Rest of world (1) | 7,394 |  |  | 7,696 |  |
| Total property and equipment, net | $ | 50,884 |  |  | $ | 42,595 |  |

[0000926326-18-000025:notes:81]
| (1) | No individual country represented more than 10% of the respective totals. |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000926326-18-000025:notes:82]
[same as prior period, unchanged from 0000926326-18-000015:notes:80]

[0000926326-18-000025:notes:83]
[same as prior period, unchanged from 0000926326-18-000015:notes:81]

[0000926326-18-000025:notes:84]
On April 12, 2017, the Company completed the acquisition of all of the membership interest of Dixie Drawl, LLC d/b/a InPharmics (“InPharmics”). InPharmics is a technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies. The total consideration for the transaction was $5.0 million, net of cash acquired of $0.3 million, and includes $0.5 million holdback for potential settlement of performance obligations. At June 30, 2018, this amount has been presented as a short-term liability.

[0000926326-18-000025:notes:85]
The Company accounted for the acquisition of InPharmics in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition date. The purchase price was preliminarily allocated to intangible assets in the amount of $1.9 million, which included developed technology and customer contracts, with the remainder allocated to goodwill.

[0000926326-18-000025:notes:86]
The results of the InPharmics’ operations have been included in the Company’s consolidated results of operations and are presented as part of the Automation and Analytics segment.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-18-000025:notes:87]
Recently Adopted Authoritative Guidance

[0000926326-18-000025:notes:88]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued ASC 606, Revenue from Contracts with Customers, a new standard related to revenue recognition. Under the new standard, revenue is recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In addition, the standard requires disclosure of the nature, amount, timing, and uncertainty of revenues and cash flows arising from contracts with customers. The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method). The Company adopted the standard using the full retrospective method effective beginning January 1, 2018.

[0000926326-18-000025:notes:89]
Under the ASC 606 guidance, fees paid to GPOs are now presented as a reduction of product revenues, whereas these fees were considered a part of selling, general, and administrative costs under the previous guidance. The majority of the incremental costs incurred to obtain a contract, primarily commission expense, are recognized during the first year with the balance recognized ratably over a period of ten years. Additionally, revenue on term software licenses is recognized upon installation of the license rather than ratably over the life of the term license. Finally, the Company no longer defers the contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price.

[0000926326-18-000025:notes:90]
Adoption of the standard related to revenue recognition impacted the Company’s reported results as follows:

[0000926326-18-000025:notes:91]
|  | Three months ended June 30, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 148,427 |  |  | $ | 157 |  |  | $ | 148,584 |  |
| Medication Adherence | 32,458 |  |  | — |  |  | 32,458 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 67,711 |  |  | 157 |  |  | 67,868 |  |
| Medication Adherence | 10,264 |  |  | — |  |  | 10,264 |  |
| Selling, general, and administrative expenses | 63,468 |  |  | (1,546 | ) |  | 61,922 |  |
| Provision for (benefit from) income taxes | (3,045 | ) |  | 660 |  |  | (2,385 | ) |
| Net income | $ | 837 |  |  | $ | 1,043 |  |  | $ | 1,880 |  |
| Net income per share | $ | 0.02 |  |  | $ | 0.03 |  |  | $ | 0.05 |  |

[0000926326-18-000025:notes:92]
|  | Six months ended June 30, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenues |  |  |  |  |  |
| Automation and Analytics | $ | 272,598 |  |  | $ | (1,844 | ) |  | $ | 270,754 |  |
| Medication Adherence | 58,841 |  |  | — |  |  | 58,841 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 123,121 |  |  | (1,844 | ) |  | 121,277 |  |
| Medication Adherence | 19,046 |  |  | — |  |  | 19,046 |  |
| Selling, general, and administrative expenses | 128,093 |  |  | (4,231 | ) |  | 123,862 |  |
| Provision for (benefit from) income taxes | (11,983 | ) |  | 925 |  |  | (11,058 | ) |
| Net income (loss) | $ | (9,917 | ) |  | $ | 1,462 |  |  | $ | (8,455 | ) |
| Net income (loss) per share | $ | (0.27 | ) |  | $ | 0.04 |  |  | $ | (0.23 | ) |

[0000926326-18-000025:notes:93]
|  | December 31, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Accounts receivable and unbilled receivables, net | $ | 189,227 |  |  | $ | 819 |  |  | $ | 190,046 |  |
| Prepaid expenses | 36,060 |  |  | (15,668 | ) |  | 20,392 |  |
| Prepaid commissions | — |  |  | 41,432 |  |  | 41,432 |  |
| Other long-term assets | 39,841 |  |  | 9,475 |  |  | 49,316 |  |
| Deferred revenues, net | 86,104 |  |  | (7,330 | ) |  | 78,774 |  |
| Long-term, deferred revenues | 17,244 |  |  | (6,621 | ) |  | 10,623 |  |
| Long-term, deferred tax liabilities | 28,579 |  |  | 12,867 |  |  | 41,446 |  |
| Stockholders’ equity | 517,199 |  |  | 37,142 |  |  | 554,341 |  |

[0000926326-18-000025:notes:94]
Recently Issued Authoritative Guidance

[0000926326-18-000025:notes:95]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance will also require significant additional disclosures about the amount and timing of cash flows from leases. This new guidance will be effective for the Company beginning January 1, 2019 using a modified retrospective approach. The modified retrospective approach includes a number of optional practical expedients that entities may elect to apply. The Company is currently evaluating the impact ASU 2016-02 will have on its consolidated financial statements.

[0000926326-18-000025:notes:96]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects.” ASU 2018-02 will be effective for the Company beginning January 1, 2019. The Company does not expect application of this guidance to have a material effect on its consolidated financial statements.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0000926326-18-000025:notes:97]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted stock awards (“RSAs”) |  |  |  |
| Outstanding at December 31, 2017 | 23 |  |  | $ | 41.07 |  |
| Granted | 21 |  |  | 46.60 |  |
| Vested | (23 | ) |  | 41.07 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at June 30, 2018 | 21 |  |  | $ | 46.60 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-18-000025:notes:98]
[same as prior period, unchanged from 0000926326-18-000015:notes:91]

[0000926326-18-000025:notes:99]
[same as prior period, unchanged from 0000926326-18-000015:notes:92]

[0000926326-18-000025:notes:100]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products are automated medication, supply control systems and medication adherence solutions which are sold in its principal market, which is the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.

[0000926326-18-000025:notes:101]
Certain prior-year amounts have been adjusted to conform with the adoption of ASC 606, Revenue from Contracts with Customers (“ASC 606”), which became effective for the Company beginning on January 1, 2018. Refer to “Recently Adopted Authoritative Guidance” for the effects of adoption of ASC 606 and the section below for the updated revenue recognition policy.

[0000926326-18-000025:notes:102]
Certain prior-year amounts have been reclassified to conform with current-period presentation. These reclassifications include (i) reclassification of revenues from services and other revenues to product revenues of $0.2 million and $0.3 million for the three and six months ended June 30, 2017, respectively, related to software term-license sales, (ii) change in inventories presentation related to allocation of inventories obsolete reserve between finished goods, raw materials, and work in progress in the Notes to the Condensed Consolidated Financial Statements, and (iii) change in intangible assets presentation related to presenting foreign currency impact separately in the Notes to the Condensed Consolidated Financial Statements. These changes were not deemed material and were included to conform with current-period classification and presentation.

[0000926326-18-000025:notes:103]
Revenue Recognition

[0000926326-18-000025:notes:104]
The Company earns revenues from sales of its medication and medical and surgical supply automation systems, along with consumables and related services, which are sold in the healthcare industry, its principal market. The transaction price of each contract with a customer is allocated to the identified performance obligations based on the relative fair value of each obligation. The Company’s customer arrangements typically include one or more of the following performance obligations:

[0000926326-18-000025:notes:105]
[same as prior period, unchanged from 0000926326-18-000015:notes:97]

[0000926326-18-000025:notes:106]
[same as prior period, unchanged from 0000926326-18-000015:notes:98]

[0000926326-18-000025:notes:107]
Installation. Installation of equipment as integrated systems at customers’ sites.

[0000926326-18-000025:notes:108]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.

[0000926326-18-000025:notes:109]
[same as prior period, unchanged from 0000926326-18-000015:notes:101]

[0000926326-18-000025:notes:110]
[same as prior period, unchanged from 0000926326-18-000015:notes:102]

[0000926326-18-000025:notes:111]
[same as prior period, unchanged from 0000926326-18-000015:notes:103]

[0000926326-18-000025:notes:112]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following the Company’s standard business process and terms.

[0000926326-18-000025:notes:113]
[same as prior period, unchanged from 0000926326-18-000015:notes:105]

[0000926326-18-000025:notes:114]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract.) The Company’s agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.

[0000926326-18-000025:notes:115]
[same as prior period, unchanged from 0000926326-18-000015:notes:107]

[0000926326-18-000025:notes:116]
[same as prior period, unchanged from 0000926326-18-000015:notes:108]

[0000926326-18-000025:notes:117]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, the Company combines the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify its performance obligations, the Company considers all of the products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, the Company considers an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of the Company’s sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, consumables and software products, support and maintenance, and professional services.

[0000926326-18-000025:notes:118]
[same as prior period, unchanged from 0000926326-18-000015:notes:110]

[0000926326-18-000025:notes:119]
[same as prior period, unchanged from 0000926326-18-000015:notes:111]

[0000926326-18-000025:notes:120]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues at June 30, 2018 and December 31, 2017 was $94.7 million and $89.4 million, respectively, of which $85.8 million and $78.8 million, respectively, are expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-18-000025:notes:121]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

[0000926326-18-000025:notes:122]
The payment terms associated with the Company’s contracts vary, however, payment terms for product revenues are generally based on milestones tied to contract signing, shipment of products, and/or customer acceptance. Payment terms associated with the service portion of agreements are generally periodic and can be billed on a monthly, quarterly, or annual basis. In certain circumstances multiple years are billed at one time. The portion of these contract liabilities not expected to be recognized as revenue within twelve months of the balance sheet date are considered long term.

[0000926326-18-000025:notes:123]
[same as prior period, unchanged from 0000926326-18-000015:notes:115]

[0000926326-18-000025:notes:124]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 42% of the lease receivable balance, are retained in-house. Revenues from sales-type leases of $7.6 million and $10.2 million for the three months ended June 30, 2018 and 2017, respectively, and $17.4 million and $13.4 million for the six months ended June 30, 2018 and 2017, respectively, are included in product revenues in the Condensed Consolidated Statements of Operations. Interest income in these leases is recognized in product revenues using the effective interest method.

[0000926326-18-000025:notes:125]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.1 million and $1.2 million for the three months ended June 30, 2018 and 2017, respectively, and $4.0 million and $3.3 million for the six months ended June 30, 2018 and 2017, respectively.

[0000926326-18-000025:notes:126]
Contract Assets and Contract Liabilities

[0000926326-18-000025:notes:127]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts, and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

[0000926326-18-000025:notes:128]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenues in the normal course of business. Unbilled contract assets which were invoiced during the three and six months ended June 30, 2018 as a result of the right to invoice for the transaction consideration becoming unconditional were not material. The contract modifications entered into during the three and six months ended June 30, 2018 did not have a significant impact on the Company’s contract assets or deferred revenues. During the three and six months ended June 30, 2018, the Company recognized revenues of $21.4 million and $68.0 million, respectively, that was included in the corresponding deferred revenue balance as of December 31, 2017.

[0000926326-18-000025:notes:129]
Contract Costs

[0000926326-18-000025:notes:130]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods. The Company recognized contract cost expense of $5.3 million and $4.6 million during the three months ended June 30, 2018 and 2017, respectively, and $10.9 million and $8.7 million during the six months ended June 30, 2018 and 2017, respectively. The portion of commission expenses paid as of the balance sheet date to be recognized in future periods is recorded in long term prepaid commissions expense on the Condensed Consolidated Balance Sheets. There was no impairment loss in relation to the costs capitalized during the three and six months ended June 30, 2018.

[0000926326-18-000025:notes:131]
Use of Estimates

[0000926326-18-000025:notes:132]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases; inventory valuation; capitalized software development costs; valuation and impairment of goodwill; purchased intangibles and long-lived assets; fair value of assets acquired and liabilities assumed in business combination; share-based compensation; and accounting for income taxes.

[0000926326-18-000025:notes:133]
Segment Reporting

[0000926326-18-000025:notes:134]
The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company’s segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management; finance and accounting; human resources; legal; training and development; and certain other administrative expenses. See Note 14, Segment and Geographical Information, for additional information on segment reporting.

[0000926326-18-000025:notes:135]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-18-000025:notes:136]
[same as prior period, unchanged from 0000926326-18-000015:notes:128]

[0000926326-18-000025:notes:137]
On March 2, 2018, the Company initiated the realignment of its Automation and Analytics commercial group in North America and France. During the six months ended June 30, 2018, the Company accrued $3.0 million of employee severance cost and related expenses, and paid out $1.9 million. The remaining, unpaid balance of $1.1 million of accrued employee severance cost and related expenses as of June 30, 2018 is presented as a component of accrued compensation liabilities in the Condensed Consolidated Balance Sheets, and is expected to be paid during the third quarter of fiscal year 2018.

[0000926326-18-000025:notes:138]
On February 15, 2017, the Company announced its plan to reduce its workforce by approximately 100 full-time employees and close the Company’s Nashville, Tennessee and Slovenia facilities. The plan was completed in fiscal year 2017. During the six months ended June 30, 2017, the Company accrued $3.8 million of employee severance cost and related expenses, and paid out $3.1 million. The remaining, unpaid balance of $0.7 million accrued severance cost and related expenses as of June 30, 2017 is presented as a component of accrued compensation in the Condensed Consolidated Balance Sheets. There were $0.6 million of facility-related costs incurred during the six months ended June 30, 2017, of which $0.1 million was paid out. The remaining unpaid balance of $0.5 million accrued facilities-related expenses as of June 30, 2017 is presented as a component of accrued liabilities in the Condensed Consolidated Balance Sheets.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000926326-18-000025:notes:139]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-18-000025:notes:140]
Deferred Revenues

[0000926326-18-000025:notes:141]
Short-term deferred revenues of $85.8 million and $78.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $14.6 million and $16.9 million as of June 30, 2018 and December 31, 2017, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

[0000926326-18-000025:notes:142]
Long-term deferred revenues include deferred revenues from service contracts of $9.0 million and $10.6 million, as of June 30, 2018 and December 31, 2017, respectively.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000926326-18-000025:notes:143]
[same as prior period, unchanged from 0000926326-18-000015:notes:131]

[0000926326-18-000025:notes:144]
|  | Three months ended June 30, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| United States | $ | 163,645 |  |  | $ | 153,442 |  |
| Rest of world (1) | 25,028 |  |  | 27,600 |  |
| Total revenues | $ | 188,673 |  |  | $ | 181,042 |  |

[0000926326-18-000025:notes:145]
|  | Six months ended June 30, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| United States | $ | 321,847 |  |  | $ | 283,721 |  |
| Rest of world (1) | 49,445 |  |  | 45,874 |  |
| Total revenues | $ | 371,292 |  |  | $ | 329,595 |  |

[0000926326-18-000025:notes:146]
(1)    No individual country represented more than 10% of the respective totals.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000926326-18-000025:notes:147]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the three and six months ended June 30, 2018 and 2017:

[0000926326-18-000025:notes:148]
|  | Three months ended June 30, |
|  | 2018 |  | 2017 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (4,482 | ) |  | $ | 1,043 |  |  | $ | (3,439 | ) |  | $ | (9,841 | ) |  | $ | 1,427 |  |  | $ | (8,414 | ) |
| Other comprehensive income (loss) before reclassifications | (4,414 | ) |  | 195 |  |  | (4,219 | ) |  | 1,076 |  |  | (100 | ) |  | 976 |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (285 | ) |  | (285 | ) |  | — |  |  | (53 | ) |  | (53 | ) |
| Net current-period other comprehensive income (loss), net of tax | (4,414 | ) |  | (90 | ) |  | (4,504 | ) |  | 1,076 |  |  | (153 | ) |  | 923 |  |
| Ending balance | $ | (8,896 | ) |  | $ | 953 |  |  | $ | (7,943 | ) |  | $ | (8,765 | ) |  | $ | 1,274 |  |  | $ | (7,491 | ) |

[0000926326-18-000025:notes:149]
|  | Six months ended June 30, |
|  | 2018 |  | 2017 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (6,954 | ) |  | $ | 841 |  |  | $ | (6,113 | ) |  | $ | (10,764 | ) |  | $ | 1,245 |  |  | $ | (9,519 | ) |
| Other comprehensive income (loss) before reclassifications | (1,942 | ) |  | 596 |  |  | (1,346 | ) |  | 1,999 |  |  | 76 |  |  | 2,075 |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (484 | ) |  | (484 | ) |  | — |  |  | (47 | ) |  | (47 | ) |
| Net current-period other comprehensive income (loss), net of tax | (1,942 | ) |  | 112 |  |  | (1,830 | ) |  | 1,999 |  |  | 29 |  |  | 2,028 |  |
| Ending balance | $ | (8,896 | ) |  | $ | 953 |  |  | $ | (7,943 | ) |  | $ | (8,765 | ) |  | $ | 1,274 |  |  | $ | (7,491 | ) |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0000926326-18-000025:notes:150]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2018 and 2017:

[0000926326-18-000025:notes:151]
|  | Three months ended |  | Six months ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,177 |  |  | $ | 845 |  |  | $ | 2,196 |  |  | $ | 1,827 |  |
| Research and development | 1,437 |  |  | 810 |  |  | 2,671 |  |  | 1,707 |  |
| Selling, general, and administrative | 4,624 |  |  | 3,890 |  |  | 8,899 |  |  | 7,522 |  |
| Total share-based compensation expense | $ | 7,238 |  |  | $ | 5,545 |  |  | $ | 13,766 |  |  | $ | 11,056 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0000926326-18-000025:notes:152]
Summaries of restricted stock activity under the Company’s 2009 Equity Incentive Plan, as amended (the “2009 Plan”) are presented below for the six months ended June 30, 2018:

[0000926326-18-000025:notes:153]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted stock units (“RSUs”) |  |  |  |  |  |  |  |
| Outstanding at December 31, 2017 | 501 |  |  | $ | 38.90 |  |  | 1.5 |  | $ | 24,293 |  |
| Granted | 113 |  |  | 44.38 |  |  |  |  |  |
| Vested | (104 | ) |  | 34.42 |  |  |  |  |  |
| Forfeited | (44 | ) |  | 38.33 |  |  |  |  |  |
| Outstanding and unvested at June 30, 2018 | 466 |  |  | $ | 41.28 |  |  | 1.5 |  | $ | 24,423 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-18-000025:notes:154]
The following tables summarize the financial performance of the Company’s reportable segments, including a reconciliation of income from segment operations to income from total operations:

[0000926326-18-000025:notes:155]
|  | Three months ended June 30, |
|  | 2018 |  | 2017 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenues | $ | 110,262 |  |  | $ | 24,374 |  |  | $ | 134,636 |  |  | $ | 103,557 |  |  | $ | 26,648 |  |  | $ | 130,205 |  |
| Services and other revenues | 48,103 |  |  | 5,934 |  |  | 54,037 |  |  | 45,027 |  |  | 5,810 |  |  | 50,837 |  |
| Total revenues | 158,365 |  |  | 30,308 |  |  | 188,673 |  |  | 148,584 |  |  | 32,458 |  |  | 181,042 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 57,045 |  |  | 18,031 |  |  | 75,076 |  |  | 62,185 |  |  | 19,553 |  |  | 81,738 |  |
| Cost of services and other revenues | 21,641 |  |  | 3,173 |  |  | 24,814 |  |  | 18,531 |  |  | 2,641 |  |  | 21,172 |  |
| Total cost of revenues | 78,686 |  |  | 21,204 |  |  | 99,890 |  |  | 80,716 |  |  | 22,194 |  |  | 102,910 |  |
| Gross profit | 79,679 |  |  | 9,104 |  |  | 88,783 |  |  | 67,868 |  |  | 10,264 |  |  | 78,132 |  |
| Operating expenses | 48,167 |  |  | 10,296 |  |  | 58,463 |  |  | 47,508 |  |  | 10,099 |  |  | 57,607 |  |
| Income from operations | $ | 31,512 |  |  | $ | (1,192 | ) |  | $ | 30,320 |  |  | $ | 20,360 |  |  | $ | 165 |  |  | $ | 20,525 |  |
| Corporate costs |  |  |  |  | 22,986 |  |  |  |  |  |  | 21,226 |  |
| Income from operations |  |  |  |  | $ | 7,334 |  |  |  |  |  |  | $ | (701 | ) |

[0000926326-18-000025:notes:156]
|  | Six months ended June 30, |
|  | 2018 |  | 2017 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenues | $ | 215,193 |  |  | $ | 50,102 |  |  | $ | 265,295 |  |  | $ | 182,095 |  |  | $ | 46,901 |  |  | $ | 228,996 |  |
| Services and other revenues | 94,578 |  |  | 11,419 |  |  | 105,997 |  |  | 88,659 |  |  | 11,940 |  |  | 100,599 |  |
| Total revenues | 309,771 |  |  | 61,521 |  |  | 371,292 |  |  | 270,754 |  |  | 58,841 |  |  | 329,595 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 113,548 |  |  | 36,945 |  |  | 150,493 |  |  | 111,164 |  |  | 34,162 |  |  | 145,326 |  |
| Cost of services and other revenues | 43,380 |  |  | 6,181 |  |  | 49,561 |  |  | 38,313 |  |  | 5,633 |  |  | 43,946 |  |
| Total cost of revenues | 156,928 |  |  | 43,126 |  |  | 200,054 |  |  | 149,477 |  |  | 39,795 |  |  | 189,272 |  |
| Gross profit | 152,843 |  |  | 18,395 |  |  | 171,238 |  |  | 121,277 |  |  | 19,046 |  |  | 140,323 |  |
| Operating expenses | 96,558 |  |  | 20,495 |  |  | 117,053 |  |  | 95,570 |  |  | 21,295 |  |  | 116,865 |  |
| Income (loss) from segment operations | $ | 56,285 |  |  | $ | (2,100 | ) |  | $ | 54,185 |  |  | $ | 25,707 |  |  | $ | (2,249 | ) |  | $ | 23,458 |  |
| Corporate costs |  |  |  |  | 46,218 |  |  |  |  |  |  | 40,711 |  |
| Income (loss) from operations |  |  |  |  | $ | 7,967 |  |  |  |  |  |  | $ | (17,253 | ) |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000926326-18-000025:notes:157]
The following table summarizes the share option activity under the Company’s equity incentive plans during the six months ended June 30, 2018:

[0000926326-18-000025:notes:158]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Stock options |  |  |  |  |  |  |  |
| Outstanding at December 31, 2017 | 3,323 |  |  | $ | 32.72 |  |  | 7.6 |  | $ | 53,953 |  |
| Granted | 720 |  |  | 44.73 |  |  |  |  |  |
| Exercised | (356 | ) |  | 24.15 |  |  |  |  |  |
| Expired | (6 | ) |  | 21.92 |  |  |  |  |  |
| Forfeited | (172 | ) |  | 38.13 |  |  |  |  |  |
| Outstanding at June 30, 2018 | 3,509 |  |  | $ | 35.80 |  |  | 7.6 |  | $ | 58,487 |  |
| Exercisable at June 30, 2018 | 1,338 |  |  | $ | 26.29 |  |  | 5.6 |  | $ | 35,014 |  |
| Vested and expected to vest at June 30, 2018 and thereafter | 3,303 |  |  | $ | 35.34 |  |  | 7.5 |  | $ | 56,583 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0000926326-18-000025:notes:159]
|  | Three months ended |  | Six months ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| Employee stock purchase plan |  |  |  |  |  |  |  |
| Expected life, years | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |
| Expected volatility, % | 27.7-33.8% |  |  | 25.8-32.8% |  |  | 27.7-33.8% |  |  | 25.8-32.8% |  |
| Risk free interest rate, % | 0.7-2.3% |  |  | 0.5-1.3% |  |  | 0.7-2.3% |  |  | 0.5-1.3% |  |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0000926326-18-000025:notes:160]
The following assumptions were used to value share options and Employee Stock Purchase Plan (“ESPP”) shares granted pursuant to the Company’s equity incentive plans for the three and six months ended June 30, 2018 and 2017:

[0000926326-18-000025:notes:161]
|  | Three months ended |  | Six months ended |
|  | June 30, 2018 |  | June 30, 2017 |  | June 30, 2018 |  | June 30, 2017 |
| Stock option plans |  |  |  |  |  |  |  |
| Expected life, years | 4.8 |  |  | 4.7 |  |  | 4.8 |  |  | 4.7 |  |
| Expected volatility, % | 30.6 | % |  | 28.3 | % |  | 31.4 | % |  | 29.7 | % |
| Risk free interest rate, % | 2.8 | % |  | 1.8 | % |  | 2.7 | % |  | 1.8 | % |
| Estimated forfeiture rate, % | 6.9 | % |  | 7.7 | % |  | 6.9 | % |  | 7.7 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-18-000025:notes:162]
[same as prior period, unchanged from 0000926326-18-000015:notes:149]

[0000926326-18-000025:notes:163]
The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company’s segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

[0000926326-18-000025:notes:164]
The two operating segments, which are the same as the Company’s two reportable segments, are as follows:

[0000926326-18-000025:notes:165]
| • | Automation and Analytics. The Automation and Analytics segment is organized around the design, manufacturing, selling, and servicing of medication and supply dispensing systems; pharmacy inventory management systems; and related software. The Automation and Analytics products are designed to enable the Company’s customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care, and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, the Company’s systems can be tailored to specific customer needs. The financial results of InPharmics acquired in the second quarter of 2017 are included in the Automation and Analytics segment. |

[0000926326-18-000025:notes:166]
| • | Medication Adherence. The Medication Adherence segment includes solutions to assist patients to remain adherent to their medication regimens. These solutions are comprised of a variety of tools and aids that may be directly used by a pharmacist or a healthcare provider in their direct care for a patient, or the patient themselves, and include software-based systems and medication adherence packaging. Software solutions primarily operate on the Patient Management Access Portal (“PMAP”), a subscription-based software system which provides an environment for patient engagement by clinicians. Services running on PMAP include Time My Meds® medication synchronization, immunization management, and a number of tools used by clinicians to manage patient engagement workflows. Medication Adherence packaging is designed either for patient use in care environments where there is a caregiver present or for environments where the patient cares for him or herself and includes the manufacturing and selling of consumable medication blister cards, packaging equipment, and ancillary products and services. |

[0000926326-18-000025:notes:167]
Significant Customers

[0000926326-18-000025:notes:168]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2018 and 2017. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable as of June 30, 2018 and December 31, 2017.

[0000926326-18-000025:notes:169]
[same as prior period, unchanged from 0000926326-18-000015:notes:157]

[0000926326-18-000025:notes:170]
[same as prior period, unchanged from 0000926326-18-000015:notes:158]


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0000926326-18-000025:notes:171]
A summary of the performance-based restricted stock activity under the 2009 Plan during the six months ended June 30, 2018 is presented below:

[0000926326-18-000025:notes:172]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Performance-based restricted stock units (“PSUs”) |  |  |  |
| Outstanding at December 31, 2017 | 225 |  |  | $ | 31.18 |  |
| Granted | 110 |  |  | 38.03 |  |
| Vested | (67 | ) |  | 30.46 |  |
| Forfeited | (32 | ) |  | 34.47 |  |
| Outstanding and unvested at June 30, 2018 | 236 |  |  | $ | 34.13 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-18-000025:notes:173]
[same as prior period, unchanged from 0000926326-18-000015:notes:161]

[0000926326-18-000025:notes:174]
Stock-Based Plans

[0000926326-18-000025:notes:175]
For a detailed explanation of the Company's stock plans and subsequent changes, please refer to Note 11, Employee Benefits and Share-Based Compensation, of the Company's annual report on Form 10-K for the year ended December 31, 2017 filed with the SEC on February 27, 2018.

[0000926326-18-000025:notes:176]
Share-Based Compensation Expense

[0000926326-18-000025:notes:177]
[same as prior period, unchanged from 0000926326-18-000015:notes:165]

[0000926326-18-000025:notes:178]
Stock Options Activity

[0000926326-18-000025:notes:179]
The weighted-average fair value per share of options granted during the three months ended June 30, 2018 and 2017 was $14.43 and $11.31, respectively, and the weighted-average fair value per share of options granted during the six months ended June 30, 2018 and 2017 was $14.29 and $10.92, respectively. The intrinsic value of options exercised during the three months ended June 30, 2018 and 2017 was $6.5 million and $4.9 million, respectively, and the intrinsic value of options exercised during the six months ended June 30, 2018 and 2017 was $8.5 million and $7.8 million, respectively.

[0000926326-18-000025:notes:180]
As of June 30, 2018, total unrecognized compensation cost related to unvested stock options was $23.7 million, which is expected to be recognized over a weighted-average vesting period of 2.9 years.

[0000926326-18-000025:notes:181]
Employee Stock Purchase Plan Activity

[0000926326-18-000025:notes:182]
For the six months ending June 30, 2018 and 2017, employees purchased approximately 289,000 and 259,000 shares of common stock, respectively, under the ESPP at weighted average prices of $26.30 and $25.51, respectively. As of June 30, 2018, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $4.7 million and is expected to be recognized over a weighted-average period of 1.2 years.

[0000926326-18-000025:notes:183]
[same as prior period, unchanged from 0000926326-18-000015:notes:171]

[0000926326-18-000025:notes:184]
As of June 30, 2018, total unrecognized compensation expense related to RSUs was $16.9 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.8 years.

[0000926326-18-000025:notes:185]
As of June 30, 2018, total unrecognized compensation cost related to RSAs was $0.8 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.9 years.

[0000926326-18-000025:notes:186]
Performance-Based Restricted Stock Units

[0000926326-18-000025:notes:187]
As of June 30, 2018, total unrecognized compensation cost related to PSUs was $4.3 million, which is expected to be recognized over the remaining weighted-average period of 1.5 years.

[0000926326-18-000025:notes:188]
[same as prior period, unchanged from 0000926326-18-000015:notes:177]

[0000926326-18-000025:notes:189]
[same as prior period, unchanged from 0000926326-18-000015:notes:178]

[0000926326-18-000025:notes:190]
On August 2, 2016, the Company's Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of June 30, 2018, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase program at any time.

[0000926326-18-000025:notes:191]
During the three and six months ended June 30, 2018 and 2017, the Company did not repurchase any of its outstanding common stock.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-18-000025:notes:192]
[same as prior period, unchanged from 0000926326-18-000015:notes:181]

[0000926326-18-000025:notes:193]
On November 3, 2017, the Company entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC, and HSBC Securities (USA) Inc., as its sales agents, pursuant to which the Company may offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of the Company’s common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, as amended (the “Securities Act”), including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange.

[0000926326-18-000025:notes:194]
During the three and six months ended June 30, 2018, the Company did not sell any of its common stock under the Distribution Agreement. As of June 30, 2018, the Company had an aggregate of $110.3 million available to be offered under the Distribution Agreement.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-18-000025:notes:195]
[same as prior period, unchanged from 0000926326-18-000015:notes:186]
