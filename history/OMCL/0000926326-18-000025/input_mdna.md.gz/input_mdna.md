# OMCL MD&A — 0000926326-18-000025


## mdna

[0000926326-18-000025:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000926326-18-000025:mdna:2]
[same as prior period, unchanged from 0000926326-18-000015:mdna:2]

[0000926326-18-000025:mdna:3]
This quarterly report on Form 10-Q contains forward-looking statements. The forward-looking statements are contained principally in the sections entitled “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations.” Forward-looking statements include, but are not limited to, statements about:

[0000926326-18-000025:mdna:4]
[same as prior period, unchanged from 0000926326-18-000015:mdna:4]

[0000926326-18-000025:mdna:5]
[same as prior period, unchanged from 0000926326-18-000015:mdna:5]

[0000926326-18-000025:mdna:6]
[same as prior period, unchanged from 0000926326-18-000015:mdna:6]

[0000926326-18-000025:mdna:7]
[same as prior period, unchanged from 0000926326-18-000015:mdna:7]

[0000926326-18-000025:mdna:8]
[same as prior period, unchanged from 0000926326-18-000015:mdna:8]

[0000926326-18-000025:mdna:9]
| • | our ability to deliver on our goals of advancing our platform with new product introductions annually and producing solutions that support fully digitized and automated central pharmacy operations; |

[0000926326-18-000025:mdna:10]
| • | our belief that continued investment in our key business strategies will continue to generate our revenues and earnings growth, as well as our expectations about the trends and other factors we believe will be critical to the success of our strategies; |

[0000926326-18-000025:mdna:11]
| • | the bookings, revenue, and margin opportunity presented by new products, emerging markets, and international markets; |

[0000926326-18-000025:mdna:12]
[same as prior period, unchanged from 0000926326-18-000015:mdna:12]

[0000926326-18-000025:mdna:13]
[same as prior period, unchanged from 0000926326-18-000015:mdna:13]

[0000926326-18-000025:mdna:14]
[same as prior period, unchanged from 0000926326-18-000015:mdna:14]

[0000926326-18-000025:mdna:15]
[same as prior period, unchanged from 0000926326-18-000015:mdna:15]

[0000926326-18-000025:mdna:16]
[same as prior period, unchanged from 0000926326-18-000015:mdna:16]

[0000926326-18-000025:mdna:17]
[same as prior period, unchanged from 0000926326-18-000015:mdna:17]

[0000926326-18-000025:mdna:18]
[same as prior period, unchanged from 0000926326-18-000015:mdna:18]

[0000926326-18-000025:mdna:19]
In some cases, you can identify forward-looking statements by terms such as “anticipates,” “believes,” “could,” “estimates,” “expects,” “intends,” “seeks,” “may,” “plans,” “potential,” “predicts,” “projects,” “should,” “will,” “would,” and variations of these terms and similar expressions. Forward-looking statements are based on our current expectations and assumptions, and are subject to known and unknown risks and uncertainties, which may cause our actual results, performance, or achievements to be materially different from those expressed or implied in the forward-looking statements.

[0000926326-18-000025:mdna:20]
We own various trademarks and service marks used in our business, including the following registered and unregistered marks which appear in this report: Omnicell®, the Omnicell logo, SureMed®, Ateb®, Time My Meds®, Aesynt®, AcuDose-Rx®, Connect-Rx®, MACH4®, Anesthesia Workstation™, and Performance Center™. This report also includes the trademarks and service marks of other companies. All other trademarks and service marks used in this report are the marks of their respective holders.

[0000926326-18-000025:mdna:21]
[same as prior period, unchanged from 0000926326-18-000015:mdna:23]

[0000926326-18-000025:mdna:22]
[same as prior period, unchanged from 0000926326-18-000015:mdna:24]

[0000926326-18-000025:mdna:23]
[same as prior period, unchanged from 0000926326-18-000015:mdna:25]

[0000926326-18-000025:mdna:24]
[same as prior period, unchanged from 0000926326-18-000015:mdna:26]

[0000926326-18-000025:mdna:25]
We manage our business as two operating segments, Automation and Analytics and Medication Adherence:

[0000926326-18-000025:mdna:26]
| • | Automation and Analytics. The Automation and Analytics segment is organized around the design, manufacturing, selling, and servicing of medication and supply dispensing systems; pharmacy inventory management systems; and related software. Our Automation and Analytics products are designed to enable our customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care, and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, our systems can be tailored to specific customer needs. |

[0000926326-18-000025:mdna:27]
| • | Medication Adherence. The Medication Adherence segment primarily includes the development, manufacturing, and selling of solutions to assist patients to remain adherent to their medication regimens. These solutions are comprised of a variety of tools and aids that may be directly used by a pharmacist or a healthcare provider in their direct care for a patient, or the patient themselves, and include software-based systems, medication adherence packaging, packaging equipment, and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand names MTS, SureMed, Ateb, and Omnicell. |

[0000926326-18-000025:mdna:28]
For further description of our operating segments, please refer to Note 14, Segment and Geographical Information, of the Notes to the Condensed Consolidated Financial Statements in this quarterly report.

[0000926326-18-000025:mdna:29]
We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 87% and 85% of our total revenues for the three months ended June 30, 2018 and 2017, respectively, and 87% and 86% of our total revenues for the six months ended June 30, 2018 and 2017, respectively. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-18-000025:mdna:30]
[same as prior period, unchanged from 0000926326-18-000015:mdna:32]

[0000926326-18-000025:mdna:31]
The healthcare market is experiencing a period of substantive change. The adoption of electronic healthcare records, new regulatory constraints, and changes in the reimbursement structure have caused healthcare institutions to re-examine their operating structures, re-prioritize their investments, and seek efficiencies. We believe our customers’ evolving operating environment creates challenges for any supplier, but also affords opportunities for suppliers that are able to partner with customers to help them meet the changing demands. We have invested, and intend to continue to invest, in the strategies which we believe have generated, and will continue to generate, our revenue and earnings growth, while supporting our customers’ initiatives and needs. These strategies include:

[0000926326-18-000025:mdna:32]
[same as prior period, unchanged from 0000926326-18-000015:mdna:36]

[0000926326-18-000025:mdna:33]
| • | Deliver our solutions to new markets. Areas of healthcare where work is done manually may benefit from our existing solutions. These areas include hospitals that continue to employ manual operations, healthcare segments |

[0000926326-18-000025:mdna:34]
28

[0000926326-18-000025:mdna:35]
of the U.S. market outside hospitals and markets outside the United States. We weigh the cost of entering these new markets against the expected benefits and focus on the markets that we believe are most likely to adopt our products.

[0000926326-18-000025:mdna:36]
[same as prior period, unchanged from 0000926326-18-000015:mdna:38]

[0000926326-18-000025:mdna:37]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, in December 2016 we announced the XT Series, our new generation of medication and supply automation that is fully integrated on our Unity enterprise platform. The XT Series includes automated medication and supply dispensing cabinets, the Anesthesia Workstation™, and Controlled Substance Manager. The XT Automated Medication Cabinets have been integrated with Connect-Rx® from Aesynt, so customers in the United States and Canada who use AcuDose-Rx® cabinets can take advantage of the new hardware without changing their software or server infrastructure. As part of this product introduction, we developed a new hardware and electronics architecture for the XT Series. The new design enables more medications to be stocked within the same footprint-the XT cabinets offer up to 50% more capacity compared with similar units on the market. In November 2017, we introduced our new IVX Workflow Solution. This new solution powered by IVX Cloud services helps enable pharmacies to safely and efficiently compound and prepare IV treatments. In December 2017, we announced our XR2 Central Pharmacy Automated System, allowing customers to more fully automate their central pharmacies.

[0000926326-18-000025:mdna:38]
Consistent with our strategy to enter new markets, we have made investments in our selling, general, and administrative expenses to expand our sales team and market to new customers. Our international efforts have focused primarily on two markets: Western Europe, where we sell solutions through a direct sales team in the United Kingdom, France, and Germany and through resellers in other markets; and in the Middle Eastern countries of the Arabian Peninsula. We have also expanded our sales efforts to medication adherence customers in the United States, which has allowed us to sell our automated dispensing solutions and other products to this market.

[0000926326-18-000025:mdna:39]
Expansion of our solutions through acquisitions and partnerships include our acquisition of Aesynt in January 2016, our acquisition of Ateb in December 2016, and most recently, our acquisition of InPharmics in April 2017. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage, and dispensing carts and cabinets, as well as I.V. sterile preparation robotics and software, including software related to medication management. Ateb is a provider of pharmacy-based patient care solutions and medication synchronization to independent and chain retail pharmacies. InPharmics is a provider of advanced pharmacy informatics solutions to hospital pharmacies. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-18-000025:mdna:40]
We believe that the success of our three-leg strategy of differentiated products, expansion into new markets, and acquisition and partnership in future periods, will be based on, among other factors:

[0000926326-18-000025:mdna:41]
| • | Our expectation that the overall market demand for healthcare services will increase as the population grows, life expectancies continue to increase, and the quality and availability of healthcare services increases; |

[0000926326-18-000025:mdna:42]
| • | Our expectation that the environment of increased patient safety awareness, increased regulatory control, increased demand for innovative products that improve the care experience, and increased need for workflow efficiency through the adoption of technology in the healthcare industry will make our solutions a priority in the capital budgets of healthcare facilities; and |

[0000926326-18-000025:mdna:43]
[same as prior period, unchanged from 0000926326-18-000015:mdna:46]

[0000926326-18-000025:mdna:44]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced generally by a non-cancellable contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are generally installable within twelve months and, other than subscription-based sales, generally recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month.

[0000926326-18-000025:mdna:45]
[same as prior period, unchanged from 0000926326-18-000015:mdna:84]

[0000926326-18-000025:mdna:46]
[same as prior period, unchanged from 0000926326-18-000015:mdna:48]

[0000926326-18-000025:mdna:47]
The growth in Medication Adherence revenues was primarily driven by further market penetration and adoption of our automated and semi-automated packaging equipment within the United States and Europe, Middle East and Africa (“EMEA”), as well as modest price increases across the product lines.

[0000926326-18-000025:mdna:48]
[same as prior period, unchanged from 0000926326-18-000015:mdna:50]

[0000926326-18-000025:mdna:49]
In fiscal year 2017, we created Centers of Excellence (“COE”) for product development, engineering, and manufacturing, with the Point of Use COE located at our facilities in California; the Robotics and Central Pharmacy COE located at our facilities near Pittsburgh, Pennsylvania; and the Medication Adherence Consumables COE located at our facilities in St. Petersburg, Florida. As part of this initiative, we reduced our workforce in the first half of 2017 by approximately 100 full-time employees, or about 4% of the total headcount, and closed our Nashville, Tennessee and Slovenia facilities.

[0000926326-18-000025:mdna:50]
Our full-time headcount was approximately 2,420 and 2,350 on June 30, 2018 on December 31, 2017, respectively.

[0000926326-18-000025:mdna:51]
[same as prior period, unchanged from 0000926326-18-000015:mdna:53]

[0000926326-18-000025:mdna:52]
On April 12, 2017, we completed the acquisition of InPharmics, a technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies. The purchase price consideration was $5.0 million, net of cash acquired of $0.3 million. The results of InPharmics' operations have been included in our consolidated results of operations beginning April 13, 2017, and are presented as part of the Automation and Analytics segment.

[0000926326-18-000025:mdna:53]
[same as prior period, unchanged from 0000926326-18-000015:mdna:55]

[0000926326-18-000025:mdna:54]
Our discussion and analysis of our financial condition and results of operations are based on our Condensed Consolidated Financial Statements, which have been prepared in accordance with United States Generally Accepted Accounting Principles (“U.S. GAAP”). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions.

[0000926326-18-000025:mdna:55]
We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements:

[0000926326-18-000025:mdna:56]
[same as prior period, unchanged from 0000926326-18-000015:mdna:57]

[0000926326-18-000025:mdna:57]
[same as prior period, unchanged from 0000926326-18-000015:mdna:58]

[0000926326-18-000025:mdna:58]
[same as prior period, unchanged from 0000926326-18-000015:mdna:59]

[0000926326-18-000025:mdna:59]
[same as prior period, unchanged from 0000926326-18-000015:mdna:60]

[0000926326-18-000025:mdna:60]
[same as prior period, unchanged from 0000926326-18-000015:mdna:61]

[0000926326-18-000025:mdna:61]
| • | Valuation and impairment of goodwill, intangible assets, and other long-lived assets; |

[0000926326-18-000025:mdna:62]
[same as prior period, unchanged from 0000926326-18-000015:mdna:64]

[0000926326-18-000025:mdna:63]
[same as prior period, unchanged from 0000926326-18-000015:mdna:65]

[0000926326-18-000025:mdna:64]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the six months ended June 30, 2018 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on

[0000926326-18-000025:mdna:65]
[same as prior period, unchanged from 0000926326-18-000015:mdna:92]

[0000926326-18-000025:mdna:66]
Form 10-K for the year ended December 31, 2017, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1 to the Condensed Consolidated Financial Statements in this quarterly report.

[0000926326-18-000025:mdna:67]
Recently Issued Authoritative Guidance

[0000926326-18-000025:mdna:68]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-18-000025:mdna:69]
[same as prior period, unchanged from 0000926326-18-000015:mdna:69]

[0000926326-18-000025:mdna:70]
[same as prior period, unchanged from 0000926326-18-000015:mdna:70]

[0000926326-18-000025:mdna:71]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 134,636 |  |  | $ | 130,205 |  |  | $ | 4,431 |  |  | 3 | % |
| Percentage of total revenues | 71 | % |  | 72 | % |  |  |  |  |
| Services and other revenues | 54,037 |  |  | 50,837 |  |  | 3,200 |  |  | 6 | % |
| Percentage of total revenues | 29 | % |  | 28 | % |  |  |  |  |
| Total revenues | $ | 188,673 |  |  | $ | 181,042 |  |  | $ | 7,631 |  |  | 4 | % |

[0000926326-18-000025:mdna:72]
Product revenues represented 71% and 72% of total revenues for the three months ended June 30, 2018 and 2017, respectively. Product revenues increased by $4.4 million due to increased sales for the Automation and Analytics segment of $6.7 million, offset by decreased sales for the Medication Adherence segment of $2.3 million. The increase in the Automation and Analytics segment was attributed to an increase in sales of XT series products of $9.0 million as the sales for the three months ended June 30, 2017 had a slower conversion of bookings and backlog into revenues due to the introduction of the new XT series of products in the fourth quarter of 2016, and an increase in sales from Performance Center of $1.0 million. The increase in revenues was offset by a decrease in sales from IV solutions due to the timing of installations. The decrease in the Medication Adherence segment was primarily attributed to lower installations of OnDemand® machines compared to the three months ended June 30, 2017 due to the timing of completed installations.

[0000926326-18-000025:mdna:73]
Services and other revenues represented 29% and 28% of total revenues for the three months ended June 30, 2018 and 2017, respectively. Services and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Services and other revenues increased by $3.2 million primarily due to an increase from our Automation and Analytics segment of $3.1 million attributed to an increase in our installed customer base.

[0000926326-18-000025:mdna:74]
Our international sales represented 13% and 15% of total revenues for the three months ended June 30, 2018 and 2017, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-18-000025:mdna:75]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 265,295 |  |  | $ | 228,996 |  |  | $ | 36,299 |  |  | 16 | % |
| Percentage of total revenues | 71 | % |  | 69 | % |  |  |  |  |
| Services and other revenues | 105,997 |  |  | 100,599 |  |  | 5,398 |  |  | 5 | % |
| Percentage of total revenues | 29 | % |  | 31 | % |  |  |  |  |
| Total revenues | $ | 371,292 |  |  | $ | 329,595 |  |  | $ | 41,697 |  |  | 13 | % |

[0000926326-18-000025:mdna:76]
Product revenues represented 71% and 69% of total revenues for the six months ended June 30, 2018 and 2017, respectively. Product revenues increased by $36.3 million due to increased sales for the Automation and Analytics segment of $33.1 million and increased sales for the Medication Adherence segment of $3.2 million. The increase in the Automation and Analytics segment was attributed to an increase in sales of XT series products as the sales for the six months ended June 30,

[0000926326-18-000025:mdna:77]
31

[0000926326-18-000025:mdna:78]
2017 had a slower conversion of bookings and backlog into revenues due to the introduction of the new XT series of products in the fourth quarter of 2016. The increase in the Medication Adherence segment was primarily attributed to higher completed installations of our VBM products compared to the six months ended June 30, 2017.

[0000926326-18-000025:mdna:79]
Services and other revenues represented 29% and 31% of total revenues for the six months ended June 30, 2018 and 2017, respectively. Services and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Services and other revenues increased by $5.4 million primarily due to an increase from our Automation and Analytics segment of $5.9 million attributed to an increase in our installed customer base.

[0000926326-18-000025:mdna:80]
Our international sales represented 13% and 14% of total revenues for the six months ended June 30, 2018 and 2017, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-18-000025:mdna:81]
Our ability to continue to grow revenues is dependent on our ability to continue to obtain orders from customers, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-18-000025:mdna:82]
[same as prior period, unchanged from 0000926326-18-000015:mdna:76]

[0000926326-18-000025:mdna:83]
[same as prior period, unchanged from 0000926326-18-000015:mdna:77]

[0000926326-18-000025:mdna:84]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Revenues: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 158,365 |  |  | $ | 148,584 |  |  | $ | 9,781 |  |  | 7 | % |
| Percentage of total revenues | 84 | % |  | 82 | % |  |  |  |  |
| Medication Adherence | 30,308 |  |  | 32,458 |  |  | (2,150 | ) |  | (7 | )% |
| Percentage of total revenues | 16 | % |  | 18 | % |  |  |  |  |
| Total revenues | $ | 188,673 |  |  | $ | 181,042 |  |  | $ | 7,631 |  |  | 4 | % |

[0000926326-18-000025:mdna:85]
The $9.8 million increase in Automation and Analytics revenues for the three months ended June 30, 2018 in comparison to the three months ended June 30, 2017 was due to an increase in product revenues of $6.7 million and an increase in services and other revenues of $3.1 million. The increase in the Automation and Analytics segment was attributed to an increase in sales of XT series products of $9.0 million as the sales for the three months ended June 30, 2017 had a slower conversion of bookings and backlog into revenues due to the introduction of the new XT series of products in the fourth quarter of 2016, and an increase in sales from Performance Center of $1.0 million. The increase in revenues was offset by a decrease in sales from IV solutions due to the timing of installations. The increase in services and other revenues of $3.1 million was primarily attributed to an increase in our installed customer base.

[0000926326-18-000025:mdna:86]
Medication Adherence revenues decreased by $2.2 million for the three months ended June 30, 2018 in comparison to the three months ended June 30, 2017. The decrease in revenues was primarily due to a decrease in product revenues of $2.3 million. The decrease in product revenues of $2.3 million was primarily attributed to lower installations of OnDemand machines compared to the three months ended June 30, 2017 due to the timing of completed installations.

[0000926326-18-000025:mdna:87]
.

[0000926326-18-000025:mdna:88]
[same as prior period, unchanged from 0000926326-18-000015:mdna:119]

[0000926326-18-000025:mdna:89]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Revenues: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 309,771 |  |  | $ | 270,754 |  |  | $ | 39,017 |  |  | 14 | % |
| Percentage of total revenues | 83 | % |  | 82 | % |  |  |  |  |
| Medication Adherence | 61,521 |  |  | 58,841 |  |  | 2,680 |  |  | 5 | % |
| Percentage of total revenues | 17 | % |  | 18 | % |  |  |  |  |
| Total revenues | $ | 371,292 |  |  | $ | 329,595 |  |  | $ | 41,697 |  |  | 13 | % |

[0000926326-18-000025:mdna:90]
The $39.0 million increase in Automation and Analytics revenues for the six months ended June 30, 2018 in comparison to the six months ended June 30, 2017 was due to an increase in product revenues of $33.1 million and an increase in services and other revenues of $5.9 million. The increase in product revenues in the Automation and Analytics segment was attributed to an increase in sales of XT series products as the sales for the three months ended March 31, 2017 had a slower conversion of bookings and backlog into revenues due to the introduction of the new XT series of products in the fourth quarter of 2016. The increase in services and other revenues of $5.9 million was primarily attributed to an increase in our installed customer base.

[0000926326-18-000025:mdna:91]
Medication Adherence revenues increased by $2.7 million for the six months ended June 30, 2018 in comparison to the six months ended June 30, 2017. The increase in revenues was due to an increase in product revenues of $3.2 million, offset by a decrease in services and other revenues of $0.5 million. The increase in product revenues of $3.2 million was attributed primarily to higher completed installations of our VBM products during the six months ended June 30, 2018 compared to the six months ended June 30, 2017.

[0000926326-18-000025:mdna:92]
[same as prior period, unchanged from 0000926326-18-000015:mdna:81]

[0000926326-18-000025:mdna:93]
[same as prior period, unchanged from 0000926326-18-000015:mdna:82]

[0000926326-18-000025:mdna:94]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 78,686 |  |  | $ | 80,716 |  |  | $ | (2,030 | ) |  | (3 | )% |
| As a percentage of related revenues | 50 | % |  | 54 | % |  |  |  |  |
| Medication Adherence | 21,204 |  |  | 22,194 |  |  | (990 | ) |  | (4 | )% |
| As a percentage of related revenues | 70 | % |  | 68 | % |  |  |  |  |
| Total cost of revenues | $ | 99,890 |  |  | $ | 102,910 |  |  | $ | (3,020 | ) |  | (3 | )% |
| As a percentage of total revenues | 53 | % |  | 57 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 79,679 |  |  | $ | 67,868 |  |  | $ | 11,811 |  |  | 17 | % |
| Automation and Analytics gross margin | 50 | % |  | 46 | % |  |  |  |  |
| Medication Adherence | 9,104 |  |  | 10,264 |  |  | (1,160 | ) |  | (11 | )% |
| Medication Adherence gross margin | 30 | % |  | 32 | % |  |  |  |  |
| Total gross profit | $ | 88,783 |  |  | $ | 78,132 |  |  | $ | 10,651 |  |  | 14 | % |
| Total gross margin | 47 | % |  | 43 | % |  |  |  |  |

[0000926326-18-000025:mdna:95]
[same as prior period, unchanged from 0000926326-18-000015:mdna:136]

[0000926326-18-000025:mdna:96]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 156,928 |  |  | $ | 149,477 |  |  | $ | 7,451 |  |  | 5 | % |
| As a percentage of related revenues | 51 | % |  | 55 | % |  |  |  |  |
| Medication Adherence | 43,126 |  |  | 39,795 |  |  | 3,331 |  |  | 8 | % |
| As a percentage of related revenues | 70 | % |  | 68 | % |  |  |  |  |
| Total cost of revenues | $ | 200,054 |  |  | $ | 189,272 |  |  | $ | 10,782 |  |  | 6 | % |
| As a percentage of total revenues | 54 | % |  | 57 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 152,843 |  |  | $ | 121,277 |  |  | $ | 31,566 |  |  | 26 | % |
| Automation and Analytics gross margin | 49 | % |  | 45 | % |  |  |  |  |
| Medication Adherence | 18,395 |  |  | 19,046 |  |  | (651 | ) |  | (3 | )% |
| Medication Adherence gross margin | 30 | % |  | 32 | % |  |  |  |  |
| Total gross profit | $ | 171,238 |  |  | $ | 140,323 |  |  | $ | 30,915 |  |  | 22 | % |
| Total gross margin | 46 | % |  | 43 | % |  |  |  |  |

[0000926326-18-000025:mdna:97]
Cost of Revenues. Cost of revenues for the three months ended June 30, 2018 compared to the three months ended June 30, 2017 decreased by $3.0 million, of which $2.0 million was attributed to the decrease in cost of revenues in our Automation and Analytics segment and $1.0 million was attributed to the decrease in cost of revenues in our Medication Adherence segment. The decrease in cost of revenues in the Automation and Analytics segment primarily related to costs incurred during the three months ended June 30, 2017 related to the XT series manufacturing ramp up, including costs relating to design refinement. The decrease in cost of revenues in the Medication Adherence segment was consistent with the decrease in revenues of $2.2 million in the Medication Adherence segment for the three months ended June 30, 2018 compared to the three months ended June 30, 2017.

[0000926326-18-000025:mdna:98]
Cost of revenues for the six months ended June 30, 2018 compared to the six months ended June 30, 2017 increased by $10.8 million, of which $7.5 million was attributed to the increase in cost of revenues in our Automation and Analytics segment and $3.3 million was attributed to the increase in cost of revenues in our Medication Adherence segment. The increase in cost of revenues in the Automation and Analytics segment was consistent with the increase in revenues of $39.0 million in the Automation and Analytics segment for the six months ended June 30, 2018 compared to the six months ended June 30, 2017, partially offset by the decrease in costs related to XT series manufacturing ramp up. The increase in cost of revenues in the Medication Adherence segment was consistent with the increase in revenues of $2.7 million in the Medication Adherence segment for the six months ended June 30, 2018 compared to the six months ended June 30, 2017.

[0000926326-18-000025:mdna:99]
Overall changes to gross margin primarily relate to product mix from sales for the periods presented as well as lower costs associated with XT series manufacturing ramp up.

[0000926326-18-000025:mdna:100]
34

[0000926326-18-000025:mdna:101]
Operating Expenses and Interest and Other Income (Expense), Net

[0000926326-18-000025:mdna:102]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 15,512 |  |  | $ | 16,911 |  |  | $ | (1,399 | ) |  | (8 | )% |
| As a percentage of total revenues | 8 | % |  | 9 | % |  |  |  |  |
| Selling, general, and administrative | 65,937 |  |  | 61,922 |  |  | 4,015 |  |  | 6 | % |
| As a percentage of total revenues | 35 | % |  | 34 | % |  |  |  |  |
| Total operating expenses | $ | 81,449 |  |  | $ | 78,833 |  |  | $ | 2,616 |  |  | 3 | % |
| As a percentage of total revenues | 43 | % |  | 44 | % |  |  |  |  |
| Income (loss) from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 31,512 |  |  | $ | 20,360 |  |  | $ | 11,152 |  |  | 55 | % |
| Automation and Analytics operating margin | 20 | % |  | 14 | % |  |  |  |  |
| Medication Adherence | (1,192 | ) |  | 165 |  |  | (1,357 | ) |  | (822 | )% |
| Medication Adherence operating margin | (4 | )% |  | 1 | % |  |  |  |  |
| Corporate Expenses | 22,986 |  |  | 21,226 |  |  | 1,760 |  |  | 8 | % |
| Total income (loss) from operations | $ | 7,334 |  |  | $ | (701 | ) |  | $ | 8,035 |  |  | (1,146 | )% |
| Total operating margin | 4 | % |  | — | % |  |  |  |  |
| Interest and other income (expense), net | $ | (896 | ) |  | $ | 196 |  |  | $ | (1,092 | ) |  | (557 | )% |

[0000926326-18-000025:mdna:103]
Research and Development. The $1.4 million decrease in research and development expenses for the three months ended June 30, 2018 compared to the three months ended June 30, 2017 was primarily driven by a decrease in research and development expenses of $1.7 million in our Automation and Analytics segment and a decrease in research and development expenses of $0.2 million in our Medication Adherence segment, offset by an increase of $0.5 million in corporate-related research and development expenses. The decrease in the Automation and Analytics segment was primarily attributed to several research and development projects reaching capitalization stage during the period ended June 30, 2018, resulting in lower research and development expenses. The increase in corporate-related expenses was primarily due to an increase in consulting fees related to a key engineering product management project.

[0000926326-18-000025:mdna:104]
Selling, General, and Administrative. The $4.0 million increase in selling, general, and administrative expenses for the three months ended June 30, 2018 compared to the three months ended June 30, 2017 was primarily due to the growth of operations and an increase in employee-related expenses due to the increase in headcount.

[0000926326-18-000025:mdna:105]
Interest and Other Income (Expense), Net. The $1.1 million increase in interest and other income (expense), net for the three months ended June 30, 2018 compared to the three months ended June 30, 2017 was due to an increase in expenses related to foreign currency fluctuations, interest, bank charges, and amortization of debt fees and issuance costs, partially offset by a contingent gain of $2.5 million recognized during the three months ended June 30, 2018 related to a settlement agreement associated with the Ateb acquisition.

[0000926326-18-000025:mdna:106]
35

[0000926326-18-000025:mdna:107]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 32,049 |  |  | $ | 33,714 |  |  | $ | (1,665 | ) |  | (5 | )% |
| As a percentage of total revenues | 9 | % |  | 10 | % |  |  |  |  |
| Selling, general, and administrative | 131,222 |  |  | 123,862 |  |  | 7,360 |  |  | 6 | % |
| As a percentage of total revenues | 35 | % |  | 38 | % |  |  |  |  |
| Total operating expenses | $ | 163,271 |  |  | $ | 157,576 |  |  | $ | 5,695 |  |  | 4 | % |
| As a percentage of total revenues | 44 | % |  | 48 | % |  |  |  |  |
| Income (loss) from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 56,285 |  |  | $ | 25,707 |  |  | $ | 30,578 |  |  | 119 | % |
| Automation and Analytics operating margin | 18 | % |  | 9 | % |  |  |  |  |
| Medication Adherence | (2,100 | ) |  | (2,249 | ) |  | 149 |  |  | (7 | )% |
| Medication Adherence operating margin | (3 | )% |  | (4 | )% |  |  |  |  |
| Corporate Expenses | 46,218 |  |  | 40,711 |  |  | 5,507 |  |  | 14 | % |
| Total income (loss) from operations | $ | 7,967 |  |  | $ | (17,253 | ) |  | $ | 25,220 |  |  | (146 | )% |
| Total operating margin | 2 | % |  | (5 | )% |  |  |  |  |
| Interest and other income (expense), net | $ | (3,625 | ) |  | $ | (2,260 | ) |  | $ | (1,365 | ) |  | 60 | % |

[0000926326-18-000025:mdna:108]
Research and Development. The $1.7 million decrease in research and development expenses for the six months ended June 30, 2018 compared to six months ended June 30, 2017 was primarily driven by a decrease in research and development expenses of $2.8 million in our Automation and Analytics segment, offset by an increase in research and development expenses of $0.4 million in our Medication Adherence segment and an increase of $0.7 million in corporate-related research and development expenses. The decrease in the Automation and Analytics segment was primarily attributed to several research and development projects reaching capitalization stage during the period ended June 30, 2018, resulting in lower research and development expenses. The increase in corporate-related expenses was primarily due to an increase in consulting fees related to a key engineering product management project.

[0000926326-18-000025:mdna:109]
Selling, General, and Administrative. The $7.4 million increase in selling, general, and administrative expenses for the six months ended June 30, 2018 compared to the six months ended June 30, 2017 was primarily due to the growth of operations and an increase in employee-related expenses due to the increase in headcount.

[0000926326-18-000025:mdna:110]
Interest and Other Income (Expense), Net. The $1.4 million increase in interest and other income (expense), net for the six months ended June 30, 2018 compared to the six months ended June 30, 2017 was due to an increase in expenses related to foreign currency fluctuations, interest, bank charges, and amortization of debt fees and issuance costs, partially offset by a contingent gain of $2.5 million recognized during the six months ended June 30, 2018 related to a settlement agreement associated with the Ateb acquisition.

[0000926326-18-000025:mdna:111]
[same as prior period, unchanged from 0000926326-18-000015:mdna:90]

[0000926326-18-000025:mdna:112]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (150 | ) |  | $ | (2,385 | ) |  | $ | 2,235 |  |  | (94 | )% |

[0000926326-18-000025:mdna:113]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (4,966 | ) |  | $ | (11,058 | ) |  | $ | 6,092 |  |  | (55 | )% |

[0000926326-18-000025:mdna:114]
Effective Tax Rate On Earnings. Our annual effective tax rate before discrete items was 16.5% and 41.1% for the six months ended June 30, 2018 and 2017, respectively. The decrease in the estimated annual effective tax rate for the six months ended June 30, 2018 compared to the same period in 2017 was primarily due to U.S. tax reform legislation that reduced the statutory corporate income tax rate from 35% to 21%, an increase in research and development credits, and corporate jurisdictional restructuring.

[0000926326-18-000025:mdna:115]
[same as prior period, unchanged from 0000926326-18-000015:mdna:94]

[0000926326-18-000025:mdna:116]
We had cash and cash equivalents of $46.2 million at June 30, 2018 compared to $32.4 million at December 31, 2017. All of our cash and cash equivalents are invested in demand deposits.

[0000926326-18-000025:mdna:117]
Our cash position and working capital at June 30, 2018 and December 31, 2017 were as follows:

[0000926326-18-000025:mdna:118]
|  | June 30, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Cash | $ | 46,168 |  |  | $ | 32,424 |  |
| Working capital | $ | 157,224 |  |  | $ | 147,066 |  |

[0000926326-18-000025:mdna:119]
Our ratio of current assets to current liabilities was 1.8:1 at June 30, 2018 and 1.7:1 at December 31, 2017.

[0000926326-18-000025:mdna:120]
[same as prior period, unchanged from 0000926326-18-000015:mdna:99]

[0000926326-18-000025:mdna:121]
[same as prior period, unchanged from 0000926326-18-000015:mdna:100]

[0000926326-18-000025:mdna:122]
On January 5, 2016, we entered into a $400.0 million secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200.0 million term loan facility (the “Term Loan Facility”), and prior to the amendment discussed below, a $200.0 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million.

[0000926326-18-000025:mdna:123]
On December 26, 2017 and April 11, 2017, we entered into amendments to the Credit Agreement. Under these amendments, the Revolving Credit Facility was increased from $200.0 million to $315.0 million and certain other modifications were made. Refer to Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this quarterly report. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes, including acquisitions.

[0000926326-18-000025:mdna:124]
As of June 30, 2018, the outstanding balance from the Facilities was $204.5 million and we were in compliance with all covenants.

[0000926326-18-000025:mdna:125]
[same as prior period, unchanged from 0000926326-18-000015:mdna:104]

[0000926326-18-000025:mdna:126]
On November 3, 2017, we entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC and HSBC Securities (USA) Inc., as our sales agents, pursuant to which we may offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of our common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange. We intend to use the net proceeds from the sale, if any, of common stock in the offering for general corporate purposes, which may include, without limitation, the acquisition of complementary businesses, the repayment of outstanding indebtedness, capital expenditures and working capital.

[0000926326-18-000025:mdna:127]
During the six months ended June 30, 2018, we did not sell any common stock under the Distribution Agreement. As of June 30, 2018, we had an aggregate of $110.3 million available to be offered under the Distribution Agreement.

[0000926326-18-000025:mdna:128]
[same as prior period, unchanged from 0000926326-18-000015:mdna:107]

[0000926326-18-000025:mdna:129]
[same as prior period, unchanged from 0000926326-18-000015:mdna:108]

[0000926326-18-000025:mdna:130]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of June 30, 2018, which may result in additional use of cash. See “Stock Repurchase Program” under Note 12. Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. There were no stock repurchases during the six months ended June 30, 2018 and 2017.

[0000926326-18-000025:mdna:131]
[same as prior period, unchanged from 0000926326-18-000015:mdna:110]

[0000926326-18-000025:mdna:132]
[same as prior period, unchanged from 0000926326-18-000015:mdna:111]

[0000926326-18-000025:mdna:133]
[same as prior period, unchanged from 0000926326-18-000015:mdna:112]

[0000926326-18-000025:mdna:134]
|  | Six months ended |
|  | June 30, 2018 |  | June 30, 2017 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 40,727 |  |  | $ | 38,924 |  |
| Investing activities | (28,076 | ) |  | (17,847 | ) |
| Financing activities | 555 |  |  | (47,355 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 538 |  |  | (1,274 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 13,744 |  |  | $ | (27,552 | ) |

[0000926326-18-000025:mdna:135]
Operating Activities

[0000926326-18-000025:mdna:136]
We expect cash from our operating activities to fluctuate in future periods as a result of a number of factors, including the timing of our billings and collections, our operating results, and the timing of other liability payments.

[0000926326-18-000025:mdna:137]
Net cash provided by operating activities was $40.7 million for the six months ended June 30, 2018, primarily as a result of net income of $9.3 million adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $24.8 million, share-based compensation expense of $13.8 million, deferred income taxes of $6.7 million, and $1.1 million of amortization of debt financing fees. The net cash outflow which contributed to changes in assets and liabilities included (i) a decrease in accounts payable of $12.2 million primarily due to the timing of payments, (ii) an increase in inventories of $9.8 million for inventory buildup in support of forecasted sales, (iii) an increase in other long-term assets of $2.8 million as a result of the increase in unbilled receivables (iv) a decrease in other accrued liabilities of $2.6 million, (v) an increase in other current assets of $2.3 million, and (vi) an increase in investments in sales-type leases of $1.8 million. These outflows were partially offset by a decrease in accounts receivable and unbilled receivables of $15.5 million due to an increase in collections and a decrease in billings, an increase in deferred revenues of $5.3 million due to the timing of orders and revenues being recognized for installed product, a decrease in prepaid commissions of $2.8 million, an increase in accrued compensation of $3.9 million, and a decrease in prepaid expenses of $2.1 million.

[0000926326-18-000025:mdna:138]
Net cash provided by operating activities was $38.9 million for the six months ended June 30, 2017, primarily as a result of the net loss of $8.5 million adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $25.9 million, deferred income taxes of $11.7 million, share-based compensation expense of $11.1 million, and $0.8 million of amortization of debt financing fees. The net cash inflow

[0000926326-18-000025:mdna:139]
38

[0000926326-18-000025:mdna:140]
which contributed to changes in assets and liabilities included (i) an increase in accounts payable of $23.4 million primarily due to an increase in inventories and the timing of payments, (ii) an increase in accrued compensation of $4.5 million as a result of employee bonus accruals, (iii) an increase in accrued liabilities of $2.2 million, (iv) a decrease in prepaid commissions of $1.6 million, and (v) a decrease in investments in sales-type leases of $5.5 million. These inflows were partially offset by an increase in inventories of $12.2 million for inventory buildup in support of forecasted sales, particularly for the XT series, a decrease in deferred revenues of $3.4 million due to the timing of orders and revenues being recognized for installed product, and an increase in accounts receivable of $1.1 million due to the timing of collections.

[0000926326-18-000025:mdna:141]
Investing Activities

[0000926326-18-000025:mdna:142]
Net cash used in investing activities was $28.1 million for the six months ended June 30, 2018, which consisted of capital expenditures of $15.0 million for property and equipment, and $13.1 million for costs of software development.

[0000926326-18-000025:mdna:143]
Net cash used in investing activities was $17.8 million for the six months ended June 30, 2017, which consisted of $6.9 million for costs of software development mainly related to the Performance Center offering and purchase of intangibles, capital expenditures of $6.5 million for property and equipment, and $4.4 million attributable to the acquisition of InPharmics.

[0000926326-18-000025:mdna:144]
Financing Activities

[0000926326-18-000025:mdna:145]
Net cash provided by financing activities was $0.6 million for the six months ended June 30, 2018, primarily from $16.1 million in proceeds from employee stock option exercises and employee stock plan purchases, partially offset by the repayment of $12.5 million of the revolving credit facilities and $3.1 million in employees’ taxes paid related to restricted stock unit vesting.

[0000926326-18-000025:mdna:146]
Net cash used in financing activities was $47.4 million for the six months ended June 30, 2017, primarily from the repayment of $70.5 million of the revolving credit facilities and $2.6 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $15.8 million in proceeds from employee stock option exercises and employee stock plan purchases, and $10.0 million in proceeds from term loan and revolving credit facilities.

[0000926326-18-000025:mdna:147]
[same as prior period, unchanged from 0000926326-18-000015:mdna:125]

[0000926326-18-000025:mdna:148]
There have been no significant changes during the six months ended June 30, 2018 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2017.

[0000926326-18-000025:mdna:149]
Contractual obligations as of June 30, 2018 were as follows:

[0000926326-18-000025:mdna:150]
|  | Payments due by period |
|  | Total |  | Remainder of 2018 |  | 2019 and 2020 |  | 2021 and 2022 |  | Thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 77,146 |  |  | $ | 6,651 |  |  | $ | 24,663 |  |  | $ | 19,125 |  |  | $ | 26,707 |  |
| Purchase obligations (2) | 56,246 |  |  | 48,447 |  |  | 4,268 |  |  | 3,531 |  |  | — |  |
| Term loan facility (3) | 175,000 |  |  | 10,000 |  |  | 47,500 |  |  | 117,500 |  |  | — |  |
| Revolving credit facility (3) | 29,500 |  |  | — |  |  | — |  |  | 29,500 |  |  | — |  |
| Total (4) (5) | $ | 337,892 |  |  | $ | 65,098 |  |  | $ | 76,431 |  |  | $ | 169,656 |  |  | $ | 26,707 |  |

[0000926326-18-000025:mdna:151]
[same as prior period, unchanged from 0000926326-18-000015:mdna:129]

[0000926326-18-000025:mdna:152]
[same as prior period, unchanged from 0000926326-18-000015:mdna:130]

[0000926326-18-000025:mdna:153]
[same as prior period, unchanged from 0000926326-18-000015:mdna:131]

[0000926326-18-000025:mdna:154]
| (3) | Amounts shown for term loan and revolving credit facility are principal repayments only. Due to use of interest rate swaps, the cash interest expense is partly variable and partly fixed, and is not reflected in the above table. Refer to Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this quarterly report. |

[0000926326-18-000025:mdna:155]
| (4) | We have recorded $7.4 million for uncertain tax positions under long-term liabilities as of June 30, 2018 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $7.4 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-18-000025:mdna:156]
| (5) | Refer to Note 10, Commitments and Contingencies, of the Notes to the Condensed Consolidated Financial Statements included in this quarterly report. |

[0000926326-18-000025:mdna:157]
[same as prior period, unchanged from 0000926326-18-000015:mdna:135]

[0000926326-18-000025:mdna:158]
As of June 30, 2018, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
