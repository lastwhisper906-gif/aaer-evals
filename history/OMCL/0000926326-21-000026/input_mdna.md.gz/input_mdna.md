# OMCL MD&A — 0000926326-21-000026


## mdna

[0000926326-21-000026:mdna:1]
[same as prior period, unchanged from 0000926326-21-000013:mdna:1]

[0000926326-21-000026:mdna:2]
[same as prior period, unchanged from 0000926326-21-000013:mdna:2]

[0000926326-21-000026:mdna:3]
•our expectations about the continuing impact of the ongoing COVID-19 pandemic (including new variants of the virus) and associated efforts to contain the spread of the pandemic on our workforce and operations, as well as the continuing impacts on our customers and suppliers, and the anticipated continuing effects of the COVID-19 pandemic and associated containment measures on our business, financial condition, liquidity, and results of operations;

[0000926326-21-000026:mdna:4]
[same as prior period, unchanged from 0000926326-21-000013:mdna:4]

[0000926326-21-000026:mdna:5]
[same as prior period, unchanged from 0000926326-21-000013:mdna:5]

[0000926326-21-000026:mdna:6]
[same as prior period, unchanged from 0000926326-21-000013:mdna:6]

[0000926326-21-000026:mdna:7]
[same as prior period, unchanged from 0000926326-21-000013:mdna:7]

[0000926326-21-000026:mdna:8]
[same as prior period, unchanged from 0000926326-21-000013:mdna:8]

[0000926326-21-000026:mdna:9]
[same as prior period, unchanged from 0000926326-21-000013:mdna:9]

[0000926326-21-000026:mdna:10]
[same as prior period, unchanged from 0000926326-21-000013:mdna:10]

[0000926326-21-000026:mdna:11]
[same as prior period, unchanged from 0000926326-21-000013:mdna:11]

[0000926326-21-000026:mdna:12]
[same as prior period, unchanged from 0000926326-21-000013:mdna:12]

[0000926326-21-000026:mdna:13]
[same as prior period, unchanged from 0000926326-21-000013:mdna:13]

[0000926326-21-000026:mdna:14]
•our ability to secure adequate supplies of raw materials and components utilized in the manufacture of our products of a quality that we require and at acceptable prices;

[0000926326-21-000026:mdna:15]
[same as prior period, unchanged from 0000926326-21-000013:mdna:14]

[0000926326-21-000026:mdna:16]
[same as prior period, unchanged from 0000926326-21-000013:mdna:15]

[0000926326-21-000026:mdna:17]
•the outcome of any legal proceedings to which we are a party;

[0000926326-21-000026:mdna:18]
[same as prior period, unchanged from 0000926326-21-000013:mdna:17]

[0000926326-21-000026:mdna:19]
[same as prior period, unchanged from 0000926326-21-000013:mdna:18]

[0000926326-21-000026:mdna:20]
[same as prior period, unchanged from 0000926326-21-000013:mdna:19]

[0000926326-21-000026:mdna:21]
[same as prior period, unchanged from 0000926326-21-000013:mdna:20]

[0000926326-21-000026:mdna:22]
[same as prior period, unchanged from 0000926326-21-000013:mdna:21]

[0000926326-21-000026:mdna:23]
[same as prior period, unchanged from 0000926326-21-000013:mdna:22]

[0000926326-21-000026:mdna:24]
[same as prior period, unchanged from 0000926326-21-000013:mdna:23]

[0000926326-21-000026:mdna:25]
[same as prior period, unchanged from 0000926326-21-000013:mdna:24]

[0000926326-21-000026:mdna:26]
We own various registered and unregistered trademarks and service marks used in our business, some of which appear in this report. The most important of these marks include Omnicell® and the Omnicell logo. This report may also include the trademarks and service marks of other companies. Such trademarks and service marks are the marks of their respective owners.

[0000926326-21-000026:mdna:27]
[same as prior period, unchanged from 0000926326-21-000013:mdna:27]

[0000926326-21-000026:mdna:28]
[same as prior period, unchanged from 0000926326-21-000013:mdna:28]

[0000926326-21-000026:mdna:29]
[same as prior period, unchanged from 0000926326-21-000013:mdna:29]

[0000926326-21-000026:mdna:30]
Over 7,000 facilities worldwide use our automation and analytics solutions which are designed to improve pharmacy workflows, increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 50,000 institutional and retail pharmacies across North America and the United Kingdom leverage our innovative medication adherence and population health solutions to improve patient engagement, and adherence to prescriptions and vaccine scheduling, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 89% of our total revenues for both the three months ended June 30, 2021 and 2020, and 89% and 90% of our total revenues for the six months ended June 30, 2021 and 2020, respectively.

[0000926326-21-000026:mdna:31]
[same as prior period, unchanged from 0000926326-21-000013:mdna:31]

[0000926326-21-000026:mdna:32]
[same as prior period, unchanged from 0000926326-21-000013:mdna:32]

[0000926326-21-000026:mdna:33]
[same as prior period, unchanged from 0000926326-21-000013:mdna:33]

[0000926326-21-000026:mdna:34]
[same as prior period, unchanged from 0000926326-21-000013:mdna:34]

[0000926326-21-000026:mdna:35]
[same as prior period, unchanged from 0000926326-21-000013:mdna:35]

[0000926326-21-000026:mdna:36]
[same as prior period, unchanged from 0000926326-21-000013:mdna:36]

[0000926326-21-000026:mdna:37]
[same as prior period, unchanged from 0000926326-21-000013:mdna:37]

[0000926326-21-000026:mdna:38]
[same as prior period, unchanged from 0000926326-21-000013:mdna:38]

[0000926326-21-000026:mdna:39]
Our full-time employee headcount was approximately 3,080 and 2,860 on June 30, 2021 and December 31, 2020, respectively.

[0000926326-21-000026:mdna:40]
[same as prior period, unchanged from 0000926326-21-000013:mdna:40]

[0000926326-21-000026:mdna:41]
[same as prior period, unchanged from 0000926326-21-000013:mdna:41]

[0000926326-21-000026:mdna:42]
[same as prior period, unchanged from 0000926326-21-000013:mdna:42]

[0000926326-21-000026:mdna:43]
[same as prior period, unchanged from 0000926326-21-000013:mdna:43]

[0000926326-21-000026:mdna:44]
•Point of Care.  As a market leader, we expect to continue expansion of this product category as customers increase use of our dispensing systems in more areas within their hospitals. In addition, we are nearly midway through the replacement, upgrade, and expansion cycle of our XT Series automated dispensing systems which we believe is a significant market opportunity and we expect to continue to focus on further penetrating markets through competitive conversions. We believe our current portfolio within the Point of Care market and new innovation and services will continue to drive improved outcomes and lower costs for our customers.

[0000926326-21-000026:mdna:45]
•Central Pharmacy.  This market represents the beginning of the medication management process in acute care settings, and, we believe, the next big automation opportunity to replace manual and repetitive processes which are common in the pharmacy today. Manual processes are prone to significant errors, and products such as IVX Workflow, our IV sterile compounding solutions, and the XR2 Automated Central Pharmacy System automate these manual processes and are designed to reduce the risk of error for our healthcare partners. We believe new products and innovations, including Omnicell One, in the Central Pharmacy market create opportunities to replace prior generation Central Pharmacy robotics and carousels. The Central Pharmacy also represents an opportunity to provide technology-enabled services designed to reduce the administrative burden on the pharmacy and allow clinicians to operate at the top of their license.

[0000926326-21-000026:mdna:46]
•340B Software-Enabled Services.  This market is targeted to covered entities participating in Section 340B of the Public Health Services Act. The act requires pharmaceutical manufacturers participating in Medicaid to sell outpatient drugs at discounted prices to health care organizations that care for many uninsured and low-income patients and results in a complex compliance environment. We believe that there are significant opportunities for health systems to improve participation benefits and maximize program savings through software-enabled services

[0000926326-21-000026:mdna:47]
and solutions. Our Omnicell 340B platform of technology-enabled services includes split billing software, contract pharmacy administration, specialty contract pharmacy administration, and drug discount access solutions.

[0000926326-21-000026:mdna:48]
•Retail, Institutional, and Payer.  We believe the Retail, Institutional, and Payer market represents a large opportunity as the majority of drugs are distributed in the non-acute sector. New technology and updated state board regulations are leading to innovation at traditional retail providers, which, combined with the move to value-based care, we believe will incentivize the market to adopt solutions to help providers and payers engage patients in new ways that lower the total cost of care. We believe adoption of our EnlivenHealth (formerly Population Health Solutions) portfolio of software products and services, along with medication adherence packaging, will increase adherence performance rates, increase prescription volume for our customers, and reduce hospital and emergency room visits due to improved adherence. As retail pharmacies play an increasingly vital role in population health following the onset of the COVID-19 pandemic, EnlivenHealth has extended solutions to assist with vaccination programs, testing protocols, and patient engagement efforts. There are four main areas of focus:

[0000926326-21-000026:mdna:49]
[same as prior period, unchanged from 0000926326-21-000013:mdna:48]

[0000926326-21-000026:mdna:50]
[same as prior period, unchanged from 0000926326-21-000013:mdna:49]

[0000926326-21-000026:mdna:51]
◦Omnichannel Communications Platform is our comprehensive engagement solution that leverages machine learning and proven Interactive Voice Response technology to enable customers to create a personalized and differentiated pharmacy experience for their patients.

[0000926326-21-000026:mdna:52]
[same as prior period, unchanged from 0000926326-21-000013:mdna:50]

[0000926326-21-000026:mdna:53]
[same as prior period, unchanged from 0000926326-21-000013:mdna:51]

[0000926326-21-000026:mdna:54]
[same as prior period, unchanged from 0000926326-21-000013:mdna:52]

[0000926326-21-000026:mdna:55]
[same as prior period, unchanged from 0000926326-21-000013:mdna:53]

[0000926326-21-000026:mdna:56]
[same as prior period, unchanged from 0000926326-21-000013:mdna:54]

[0000926326-21-000026:mdna:57]
[same as prior period, unchanged from 0000926326-21-000013:mdna:55]

[0000926326-21-000026:mdna:58]
On July 26, 2021, we announced our acquisition of RxInnovation Inc., a Delaware corporation, operating as FDS Amplicare (“FDS Amplicare”), for total aggregate cash consideration of $177.0 million, subject to customary adjustments. We will use cash available on our balance sheet to fund the transaction. FDS Amplicare is a pharmacy software solutions provider. The transaction, which is expected to close in the second half of 2021, is subject to clearance under the Hart-Scott-Rodino Act and the satisfaction of other customary closing conditions. The acquisition will add a comprehensive and differentiated suite of financial management, analytics, and population health solutions to Omnicell’s EnlivenHealth division.

[0000926326-21-000026:mdna:59]
On October 1, 2020, we completed the acquisition of the 340B Link business (the “340B Link Business”) of Pharmaceutical Strategies Group, LLC pursuant to the terms and conditions of the Equity Purchase Agreement, dated August 11, 2020, as amended, by and among the Company, PSGH, LLC, BW Apothecary Holdings, LLC, the sellers identified therein and the seller’s representative for total cash consideration of $225.0 million. The acquisition adds a comprehensive and differentiated suite of software-enabled services and solutions used by certain eligible hospitals, health systems, clinics, and

[0000926326-21-000026:mdna:60]
entities to manage compliance and capture 340B drug cost savings on outpatient prescriptions filled through the eligible entity’s pharmacy or a contracted pharmacy partner. The results of the operations of the 340B Link Business have been included in our consolidated results of operations beginning October 1, 2020.

[0000926326-21-000026:mdna:61]
[same as prior period, unchanged from 0000926326-21-000013:mdna:57]

[0000926326-21-000026:mdna:62]
[same as prior period, unchanged from 0000926326-21-000013:mdna:58]

[0000926326-21-000026:mdna:63]
[same as prior period, unchanged from 0000926326-21-000013:mdna:59]

[0000926326-21-000026:mdna:64]
[same as prior period, unchanged from 0000926326-21-000013:mdna:60]

[0000926326-21-000026:mdna:65]
[same as prior period, unchanged from 0000926326-21-000013:mdna:61]

[0000926326-21-000026:mdna:66]
[same as prior period, unchanged from 0000926326-21-000013:mdna:62]

[0000926326-21-000026:mdna:67]
[same as prior period, unchanged from 0000926326-21-000013:mdna:63]

[0000926326-21-000026:mdna:68]
[same as prior period, unchanged from 0000926326-21-000013:mdna:64]

[0000926326-21-000026:mdna:69]
[same as prior period, unchanged from 0000926326-21-000013:mdna:65]

[0000926326-21-000026:mdna:70]
[same as prior period, unchanged from 0000926326-21-000013:mdna:66]

[0000926326-21-000026:mdna:71]
[same as prior period, unchanged from 0000926326-21-000013:mdna:67]

[0000926326-21-000026:mdna:72]
[same as prior period, unchanged from 0000926326-21-000013:mdna:68]

[0000926326-21-000026:mdna:73]
[same as prior period, unchanged from 0000926326-21-000013:mdna:69]

[0000926326-21-000026:mdna:74]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the six months ended June 30, 2021 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2020, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q.

[0000926326-21-000026:mdna:75]
[same as prior period, unchanged from 0000926326-21-000013:mdna:71]

[0000926326-21-000026:mdna:76]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-21-000026:mdna:77]
[same as prior period, unchanged from 0000926326-21-000013:mdna:73]

[0000926326-21-000026:mdna:78]
[same as prior period, unchanged from 0000926326-21-000013:mdna:74]

[0000926326-21-000026:mdna:79]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 196,911 |  |  | $ | 138,942 |  |  | $ | 57,969 |  |  | 42% |
| Percentage of total revenues | 72% |  | 70% |  |  |  |  |
| Services and other revenues | 75,828 |  |  | 60,679 |  |  | 15,149 |  |  | 25% |
| Percentage of total revenues | 28% |  | 30% |  |  |  |  |
| Total revenues | $ | 272,739 |  |  | $ | 199,621 |  |  | $ | 73,118 |  |  | 37% |

[0000926326-21-000026:mdna:80]
Product revenues represented 72% and 70% of total revenues for the three months ended June 30, 2021 and 2020, respectively. Product revenues increased by $58.0 million, due to increased customer demand, primarily within our automated dispensing systems business. In comparison, the second quarter of 2020 was impacted by the COVID-19 pandemic as health systems were focusing resources on COVID-19 essential activities.

[0000926326-21-000026:mdna:81]
Services and other revenues represented 28% and 30% of total revenues for the three months ended June 30, 2021 and 2020, respectively. Services and other revenues include revenues from technical services, SaaS, subscription software, and technology-enabled services, and other services. Services and other revenues increased by $15.1 million, primarily due to revenues of $11.5 million from the newly-acquired 340B Link Business, as well as continued growth in our installed customer base.

[0000926326-21-000026:mdna:82]
Our international sales represented 11% of total revenues for both the three months ended June 30, 2021 and 2020, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-21-000026:mdna:83]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 375,036 |  |  | $ | 309,015 |  |  | $ | 66,021 |  |  | 21% |
| Percentage of total revenues | 71% |  | 72% |  |  |  |  |
| Services and other revenues | 149,546 |  |  | 120,292 |  |  | 29,254 |  |  | 24% |
| Percentage of total revenues | 29% |  | 28% |  |  |  |  |
| Total revenues | $ | 524,582 |  |  | $ | 429,307 |  |  | $ | 95,275 |  |  | 22% |

[0000926326-21-000026:mdna:84]
Product revenues represented 71% and 72% of total revenues for the six months ended June 30, 2021 and 2020, respectively. Product revenues increased by $66.0 million, due to increased customer demand, primarily within our automated dispensing systems business. In comparison, the second quarter of 2020 was impacted by the COVID-19 pandemic as health systems were focusing resources on COVID-19 essential activities.

[0000926326-21-000026:mdna:85]
Services and other revenues represented 29% and 28% of total revenues for the six months ended June 30, 2021 and 2020, respectively. Services and other revenues include revenues from technical services, SaaS, subscription software, and technology-enabled services, and other services. Services and other revenues increased by $29.3 million, primarily due to revenues of $22.4 million from the newly-acquired 340B Link Business, as well as continued growth in our installed customer base.

[0000926326-21-000026:mdna:86]
Our international sales represented 11% and 10% of total revenues for the six months ended June 30, 2021 and 2020, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-21-000026:mdna:87]
Our ability to continue to grow revenues is dependent on our ability to continue to obtain orders from customers, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower

[0000926326-21-000026:mdna:88]
allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-21-000026:mdna:89]
[same as prior period, unchanged from 0000926326-21-000013:mdna:80]

[0000926326-21-000026:mdna:90]
[same as prior period, unchanged from 0000926326-21-000013:mdna:81]

[0000926326-21-000026:mdna:91]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 100,227 |  |  | $ | 85,779 |  |  | $ | 14,448 |  |  | 17% |
| As a percentage of related revenues | 51% |  | 62% |  |  |  |  |
| Cost of services and other revenues | 36,214 |  |  | 30,617 |  |  | 5,597 |  |  | 18% |
| As a percentage of related revenues | 48% |  | 50% |  |  |  |  |
| Total cost of revenues | $ | 136,441 |  |  | $ | 116,396 |  |  | $ | 20,045 |  |  | 17% |
| As a percentage of total revenues | 50% |  | 58% |  |  |  |  |
| Gross profit | $ | 136,298 |  |  | $ | 83,225 |  |  | $ | 53,073 |  |  | 64% |
| Gross margin | 50% |  | 42% |  |  |  |  |

[0000926326-21-000026:mdna:92]
Cost of revenues for the three months ended June 30, 2021 compared to the three months ended June 30, 2020 increased by $20.0 million, of which $14.4 million was attributed to the increase in cost of product revenues and $5.6 million was attributed to the increase in cost of services and other revenues.

[0000926326-21-000026:mdna:93]
The increase in cost of product revenues was primarily driven by the increase in product revenues of $58.0 million for the three months ended June 30, 2021 compared to the three months ended June 30, 2020, partially offset by the benefits associated with economies of scale due to higher volumes, as well as the reduction of employee-related expenses for restructuring initiatives.

[0000926326-21-000026:mdna:94]
The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $15.1 million, including incremental revenues from the newly-acquired 340B Link Business, for the three months ended June 30, 2021 compared to the three months ended June 30, 2020, as well as additional investments in our service business to support new product offerings.

[0000926326-21-000026:mdna:95]
The overall increase in gross margin primarily relates to higher revenues for the three months ended June 30, 2021 due to increased customer demand, benefits associated with economies of scale due to higher volumes, as well as the reduction of employee-related expenses for restructuring initiatives. Gross margin in the second quarter of 2020 was impacted by the COVID-19 pandemic. Our gross profit for the three months ended June 30, 2021 was $136.3 million, as compared to $83.2 million for the three months ended June 30, 2020.

[0000926326-21-000026:mdna:96]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 192,854 |  |  | $ | 176,051 |  |  | $ | 16,803 |  |  | 10% |
| As a percentage of related revenues | 51% |  | 57% |  |  |  |  |
| Cost of services and other revenues | 73,147 |  |  | 60,409 |  |  | 12,738 |  |  | 21% |
| As a percentage of related revenues | 49% |  | 50% |  |  |  |  |
| Total cost of revenues | $ | 266,001 |  |  | $ | 236,460 |  |  | $ | 29,541 |  |  | 12% |
| As a percentage of total revenues | 51% |  | 55% |  |  |  |  |
| Gross profit | $ | 258,581 |  |  | $ | 192,847 |  |  | $ | 65,734 |  |  | 34% |
| Gross margin | 49% |  | 45% |  |  |  |  |

[0000926326-21-000026:mdna:97]
Cost of revenues for the six months ended June 30, 2021 compared to the six months ended June 30, 2020 increased by $29.5 million, of which $16.8 million was attributed to the increase in cost of product revenues and $12.7 million was attributed to the increase in cost of services and other revenues.

[0000926326-21-000026:mdna:98]
The increase in cost of product revenues was primarily driven by the increase in product revenues of $66.0 million for the six months ended June 30, 2021 compared to the six months ended June 30, 2020, partially offset by the benefits associated with economies of scale due to higher volumes, as well as the reduction of employee-related expenses for restructuring initiatives.

[0000926326-21-000026:mdna:99]
The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $29.3 million, including incremental revenues from the newly-acquired 340B Link Business, for the six months ended June 30, 2021 compared to the six months ended June 30, 2020, as well as additional investments in our service business to support new product offerings.

[0000926326-21-000026:mdna:100]
The overall increase in gross margin primarily relates to higher revenues for the six months ended June 30, 2021 due to increased customer demand, benefits associated with economies of scale due to higher volumes, as well as the reduction of employee-related expenses for restructuring initiatives. Gross margin in the second quarter of 2020 was impacted by the COVID-19 pandemic. Our gross profit for the six months ended June 30, 2021 was $258.6 million, as compared to $192.8 million for the six months ended June 30, 2020.

[0000926326-21-000026:mdna:101]
[same as prior period, unchanged from 0000926326-21-000013:mdna:87]

[0000926326-21-000026:mdna:102]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 18,213 |  |  | $ | 20,830 |  |  | $ | (2,617) |  |  | (13)% |
| As a percentage of total revenues | 7% |  | 10% |  |  |  |  |
| Selling, general, and administrative | 89,169 |  |  | 69,386 |  |  | 19,783 |  |  | 29% |
| As a percentage of total revenues | 33% |  | 35% |  |  |  |  |
| Total operating expenses | $ | 107,382 |  |  | $ | 90,216 |  |  | $ | 17,166 |  |  | 19% |
| As a percentage of total revenues | 39% |  | 45% |  |  |  |  |
| Interest and other income (expense), net | $ | (5,959) |  |  | $ | 174 |  |  | $ | (6,133) |  |  | (3,525)% |

[0000926326-21-000026:mdna:103]
Research and Development. Research and development expenses decreased by $2.6 million for the three months ended June 30, 2021 compared to the three months ended June 30, 2020. The decrease was primarily attributed to a reduction of $2.9 million in employee-related expenses for restructuring initiatives.

[0000926326-21-000026:mdna:104]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $19.8 million for the three months ended June 30, 2021 compared to the three months ended June 30, 2020. The increase was primarily due to an increase of approximately $12.2 million in employee-related expenses primarily related to increased headcount, including the incremental headcount from the 340B Link Business acquisition, an increase of $2.0 million in acquisition-related expenses, as well as higher consulting and other expenses.

[0000926326-21-000026:mdna:105]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $6.1 million for the three months ended June 30, 2021 compared to the three months ended June 30, 2020, primarily driven by a $6.2 million increase in other expenses. The increase in other expenses during the three months ended June 30, 2021 as compared to the three months ended June 30, 2020 is primarily driven by amortization of discount and debt issuance costs as well as interest expense associated with our convertible senior notes issued in September 2020.

[0000926326-21-000026:mdna:106]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 34,293 |  |  | $ | 39,482 |  |  | $ | (5,189) |  |  | (13)% |
| As a percentage of total revenues | 7% |  | 9% |  |  |  |  |
| Selling, general, and administrative | 175,762 |  |  | 148,205 |  |  | 27,557 |  |  | 19% |
| As a percentage of total revenues | 34% |  | 35% |  |  |  |  |
| Total operating expenses | $ | 210,055 |  |  | $ | 187,687 |  |  | $ | 22,368 |  |  | 12% |
| As a percentage of total revenues | 40% |  | 44% |  |  |  |  |
| Interest and other income (expense), net | $ | (12,650) |  |  | $ | (648) |  |  | $ | (12,002) |  |  | 1,852% |

[0000926326-21-000026:mdna:107]
Research and Development. Research and development expenses decreased by $5.2 million for the six months ended June 30, 2021 compared to the six months ended June 30, 2020. The decrease was primarily attributed to a reduction of $3.6 million in employee-related expenses for restructuring initiatives, as well as lower consulting expenses.

[0000926326-21-000026:mdna:108]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $27.6 million for the six months ended June 30, 2021 compared to the six months ended June 30, 2020. The increase was primarily due to an increase of approximately $20.1 million in employee-related expenses primarily related to increased headcount, including the incremental headcount from the 340B Link Business acquisition, as well as higher consulting expenses and an increase in acquisition-related expenses of $2.0 million, partially offset by a reduction in employee-related expenses for restructuring initiatives of $2.2 million.

[0000926326-21-000026:mdna:109]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $12.0 million for the six months ended June 30, 2021 compared to the six months ended June 30, 2020, primarily driven by a $11.3 million increase in other expenses and a $0.7 million decrease in other income. The increase in other expenses during the six months ended June 30, 2021 as compared to the six months ended June 30, 2020 is primarily driven by amortization of discount and debt issuance costs as well as interest expense associated with our convertible senior notes issued in September 2020.

[0000926326-21-000026:mdna:110]
[same as prior period, unchanged from 0000926326-21-000013:mdna:92]

[0000926326-21-000026:mdna:111]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 2,533 |  |  | $ | (2,518) |  |  | $ | 5,051 |  |  | (201)% |

[0000926326-21-000026:mdna:112]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 1,325 |  |  | $ | (2,500) |  |  | $ | 3,825 |  |  | (153)% |

[0000926326-21-000026:mdna:113]
Our annual effective tax rate before discrete items was 27.8% and 28.0% for the six months ended June 30, 2021 and 2020, respectively. The decrease in the estimated annual effective tax rate for the six months ended June 30, 2021 compared to the same period in 2020 was primarily due to our higher profitability during the period, a decrease in in non-deductible expenses, and an increase in research and development credits.

[0000926326-21-000026:mdna:114]
Provision for income taxes for the six months ended June 30, 2021 included net discrete income tax benefit of $8.6 million, primarily due to a $8.2 million tax benefit from equity compensation.

[0000926326-21-000026:mdna:115]
Provision for income taxes for the six months ended June 30, 2020 included net discrete income tax benefit of $3.8 million, primarily due to a $3.3 million tax benefit from equity compensation.

[0000926326-21-000026:mdna:116]
[same as prior period, unchanged from 0000926326-21-000013:mdna:97]

[0000926326-21-000026:mdna:117]
[same as prior period, unchanged from 0000926326-21-000013:mdna:98]

[0000926326-21-000026:mdna:118]
We had cash and cash equivalents of $614.2 million at June 30, 2021 compared to $485.9 million at December 31, 2020. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with major financial institutions.

[0000926326-21-000026:mdna:119]
Our cash position and working capital at June 30, 2021 and December 31, 2020 were as follows:

[0000926326-21-000026:mdna:120]
|  | June 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 614,236 |  |  | $ | 485,928 |  |
| Working capital | $ | 667,176 |  |  | $ | 552,991 |  |

[0000926326-21-000026:mdna:121]
Our ratio of current assets to current liabilities was 3.1:1 and 3.0:1 at June 30, 2021 and December 31, 2020, respectively.

[0000926326-21-000026:mdna:122]
[same as prior period, unchanged from 0000926326-21-000013:mdna:103]

[0000926326-21-000026:mdna:123]
Revolving Credit Facility

[0000926326-21-000026:mdna:124]
On November 15, 2019, we entered into an Amended and Restated Credit Agreement (as subsequently amended, as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded our 2016 senior secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.

[0000926326-21-000026:mdna:125]
On September 22, 2020, the parties entered into an amendment (the “Amendment”) to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions described below, expand our flexibility to repurchase our common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires us to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

[0000926326-21-000026:mdna:126]
As of June 30, 2021, there was no outstanding balance for the Revolving Credit Facility and we were in full compliance with all covenants. Refer to Note 9, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q for more details. We expect to use future loans under the Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-21-000026:mdna:127]
[same as prior period, unchanged from 0000926326-21-000013:mdna:109]

[0000926326-21-000026:mdna:128]
On September 25, 2020, we completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. We received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed,

[0000926326-21-000026:mdna:129]
repurchased, or converted. Refer to Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q for more details.

[0000926326-21-000026:mdna:130]
During the fourth quarter of 2020, we used approximately $49.3 million of the net proceeds from the offering to pay the cost of the convertible note hedge transactions (partially offset by the proceeds we received from the sale of the warrant transactions), approximately $53.0 million of the net proceeds to repurchase shares of our common stock from purchasers of the Notes, $150.0 million of the net proceeds to pay down outstanding borrowings under the Revolving Credit Facility, and $225.0 million for the acquisition of the 340B Link Business. We intend to use the remainder of the net proceeds from this offering for working capital and other general corporate purposes, which may include potential acquisitions, strategic transactions, and potential future repurchases of our common stock.

[0000926326-21-000026:mdna:131]
[same as prior period, unchanged from 0000926326-21-000013:mdna:112]

[0000926326-21-000026:mdna:132]
[same as prior period, unchanged from 0000926326-21-000013:mdna:113]

[0000926326-21-000026:mdna:133]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of June 30, 2021, which may result in additional use of cash. Refer to “Stock Repurchase Program” under Note 15, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q for more details. There were no stock repurchases during the three and six months ended June 30, 2021 and 2020.

[0000926326-21-000026:mdna:134]
Based on our current business plan and product backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan (“ESPP”), along with the availability of funds under the Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-21-000026:mdna:135]
[same as prior period, unchanged from 0000926326-21-000013:mdna:116]

[0000926326-21-000026:mdna:136]
[same as prior period, unchanged from 0000926326-21-000013:mdna:117]

[0000926326-21-000026:mdna:137]
|  | Six Months Ended June 30, |
|  | 2021 |  | 2020 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 129,188 |  |  | $ | 72,735 |  |
| Investing activities | (26,482) |  |  | (33,213) |  |
| Financing activities | 22,413 |  |  | (32,308) |  |
| Effect of exchange rate changes on cash and cash equivalents | (74) |  |  | (841) |  |
| Net increase in cash, cash equivalents, and restricted cash | $ | 125,045 |  |  | $ | 6,373 |  |

[0000926326-21-000026:mdna:138]
[same as prior period, unchanged from 0000926326-21-000013:mdna:119]

[0000926326-21-000026:mdna:139]
[same as prior period, unchanged from 0000926326-21-000013:mdna:120]

[0000926326-21-000026:mdna:140]
Net cash provided by operating activities was $129.2 million for the six months ended June 30, 2021, primarily consisting of net income of $34.6 million adjusted for non-cash items of $76.9 million and changes in assets and liabilities of $17.7 million. The non-cash items primarily consisted of depreciation and amortization expense of $35.0 million, share-based compensation expense of $24.8 million, amortization of discount on convertible senior notes of $9.2 million, amortization of operating lease right-of-use assets of $5.8 million, amortization of debt issuance costs of $1.7 million, and a change in deferred income taxes of $0.5 million. Changes in assets and liabilities include cash inflows from (i) an increase in deferred revenues of $27.5 million primarily due to an increase in billings driven by the timing of shipments in order to meet customers’ implementation schedules and recognition of revenues for products requiring installation, (ii) an increase in accounts payable of $15.7 million primarily due to an overall increase in spending, as well as timing of payments, (iii) an increase in accrued liabilities of $10.1 million primarily due to an increase in rebates and buyout liabilities, (iv) a decrease in investment in sales-

[0000926326-21-000026:mdna:141]
type leases of $2.4 million, (v) a decrease in prepaid commissions of $1.9 million, and (vi) a decrease in other long-term assets of $1.6 million. These cash inflows were partially offset by (i) an increase in accounts receivable and unbilled receivables of $19.7 million primarily due to an increase in billings driven by the timing of shipments as well as collections, (ii) a decrease in accrued compensation of $7.3 million primarily due to a decrease in accrued commissions and bonuses, (iii) an increase in inventories of $6.6 million to support forecasted sales, (iv) a decrease in operating lease liabilities of $6.2 million, and (v) an increase in prepaid expenses of $1.4 million.

[0000926326-21-000026:mdna:142]
Net cash provided by operating activities was $72.7 million for the six months ended June 30, 2020, primarily consisting of net income of $7.0 million adjusted for non-cash items of $47.0 million and changes in assets and liabilities of $18.7 million. The non-cash items primarily consisted of depreciation and amortization expense of $28.8 million, share-based compensation expense of $22.0 million, amortization of operating lease right-of-use assets of $5.2 million, amortization of debt issuance costs of $0.5 million, and a change in deferred income taxes of $9.4 million. Changes in assets and liabilities include cash inflows from (i) a decrease in accounts receivable and unbilled receivables of $28.2 million primarily due to an increase in collections and a decrease in billings due to timing of shipments, (ii) an increase in deferred revenues of $16.3 million primarily due to the timing of shipments in order to meet customers’ implementation schedules and recognition of revenues for products requiring installation, (iii) an increase in other long-term liabilities of $4.4 million, (iv) a decrease in prepaid commissions of $4.0 million, and (v) a decrease in prepaid expenses of $1.2 million. These cash inflows were partially offset by (i) a decrease in accounts payable of $11.3 million primarily due to an overall decrease in spending, as well as timing of payments, (ii) an increase in inventories of $7.3 million to support forecasted sales, (iii) a decrease in operating lease liabilities of $5.2 million, (iv) an increase in other long-term assets of $4.6 million, (v) a decrease in accrued compensation of $3.1 million, (vi) a decrease in accrued liabilities of $2.8 million, and (vii) an increase in investment in sales-type leases of $1.4 million.

[0000926326-21-000026:mdna:143]
[same as prior period, unchanged from 0000926326-21-000013:mdna:123]

[0000926326-21-000026:mdna:144]
Net cash used in investing activities was $26.5 million for the six months ended June 30, 2021, which consisted of capital expenditures of $11.1 million for property and equipment, and $15.4 million for costs of software development for external use.

[0000926326-21-000026:mdna:145]
Net cash used in investing activities was $33.2 million for the six months ended June 30, 2020, which consisted of capital expenditures of $13.2 million for property and equipment, and $20.0 million for costs of software development for external use.

[0000926326-21-000026:mdna:146]
[same as prior period, unchanged from 0000926326-21-000013:mdna:126]

[0000926326-21-000026:mdna:147]
Net cash provided by financing activities was $22.4 million for the six months ended June 30, 2021, primarily due to $32.3 million in proceeds from employee stock option exercises and ESPP purchases, partially offset by $6.7 million in employees’ taxes paid related to restricted stock unit vesting, and a net decrease in the customer funds balances of $3.3 million.

[0000926326-21-000026:mdna:148]
Net cash used in financing activities was $32.3 million for the six months ended June 30, 2020, primarily due to the repayment of $50.0 million of the Revolving Credit Facility and $3.5 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $21.2 million in proceeds from employee stock option exercises and employee stock plan purchases.

[0000926326-21-000026:mdna:149]
[same as prior period, unchanged from 0000926326-21-000013:mdna:129]

[0000926326-21-000026:mdna:150]
There have been no significant changes during the six months ended June 30, 2021 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2020.

[0000926326-21-000026:mdna:151]
Contractual obligations as of June 30, 2021 were as follows:

[0000926326-21-000026:mdna:152]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2021 |  | 2022 - 2023 |  | 2024 - 2025 |  | 2026 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 64,592 |  |  | $ | 7,482 |  |  | $ | 24,478 |  |  | $ | 15,355 |  |  | $ | 17,277 |  |
| Purchase obligations (2) | 114,388 |  |  | 89,479 |  |  | 23,246 |  |  | 1,567 |  |  | 96 |  |
| Convertible senior notes (3) | 581,469 |  |  | 719 |  |  | 2,875 |  |  | 577,875 |  |  | — |  |
| Total (4) | $ | 760,449 |  |  | $ | 97,680 |  |  | $ | 50,599 |  |  | $ | 594,797 |  |  | $ | 17,373 |  |

[0000926326-21-000026:mdna:153]
[same as prior period, unchanged from 0000926326-21-000013:mdna:133]

[0000926326-21-000026:mdna:154]
(1)Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 12, Lessee Leases, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q for more details.

[0000926326-21-000026:mdna:155]
[same as prior period, unchanged from 0000926326-21-000013:mdna:135]

[0000926326-21-000026:mdna:156]
(3)We issued convertible senior notes in September 2020 that are due in September 2025. The obligations presented above include both principal and interest for these notes. Although these notes mature in 2025, they may be converted into cash and shares of our common stock prior to maturity if certain conditions are met. Any conversion prior to maturity can result in repayment of the principal amounts sooner than the scheduled repayment as indicated in the table above. Refer to Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q for more details.

[0000926326-21-000026:mdna:157]
(4)Refer to Note 13, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q for more details.

[0000926326-21-000026:mdna:158]
[same as prior period, unchanged from 0000926326-21-000013:mdna:138]

[0000926326-21-000026:mdna:159]
As of June 30, 2021, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Exchange Act and the instructions thereto.
