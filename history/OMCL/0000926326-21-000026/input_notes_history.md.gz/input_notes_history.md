# OMCL note change history — 0000926326-21-000013 → 0000926326-21-000026


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-08-06):
[0000926326-21-000026:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2021, the Company had non-cancelable purchase commitments of $114.4 million, of which $89.5 million are expected to be paid within the year ending December 31, 2021.
  (was, 2021-05-04, similarity 0.9836):
[0000926326-21-000013:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2021, the Company had non-cancelable purchase commitments of $82.8 million, of which $78.8 million are expected to be paid within the year ending December 31, 2021.

- added (2021-08-06):
[0000926326-21-000026:note_history:2]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a

- added (2021-08-06):
[0000926326-21-000026:note_history:3]
motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020. The Company's motion to dismiss is now fully briefed and the Court has scheduled oral argument on the motion for September 17, 2021. The Company intends to defend the lawsuit vigorously.

- changed (2021-08-06):
[0000926326-21-000026:note_history:4]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “Omnicell Complaint”). This action (the “Omnicell Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The Omnicell Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees and costs, and pre-judgment and post-judgment interest. On March 17, 2021, the parties filed a joint motion to stay the Omnicell Action, which motion was granted by the Court on June 8, 2021. The stay is in place for no more than 180 days, setting the deadline for filing the Company’s answer to the Omnicell Complaint as December 6, 2021, unless an extension to such stay is mutually agreed to by the parties and approved by the Court. The Company intends to defend the lawsuit vigorously.
  (was, 2021-05-04, similarity 0.8587):
[0000926326-21-000013:note_history:4]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “Omnicell Complaint”). This action (the “Omnicell Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The Omnicell Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees

- removed (2021-08-06):
[0000926326-21-000013:note_history:5]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020. The Company's motion to dismiss is now fully briefed and the Court has scheduled oral argument on the motion for June 4, 2021. The Company intends to defend the lawsuit vigorously.

- removed (2021-08-06):
[0000926326-21-000013:note_history:6]
and costs, and pre-judgment and post-judgment interest. On March 17, 2021, the parties filed a joint motion to stay the Omnicell Action, which motion remains pending with the Court. On April 30, 2021, pending the decision from the Court regarding the joint motion to stay the Omnicell Action, the Company filed a consent motion for extension of time supported by BD to file the Company’s answer to the Omnicell Complaint. The consent motion was granted by the Court on April 30, 2021, and the Company’s answer to the Omnicell Complaint is now due June 3, 2021. The Company intends to defend the lawsuit vigorously.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-08-06):
[0000926326-21-000026:note_history:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2021 and December 31, 2020, the results of operations and comprehensive income (loss) for the three and six months ended June 30, 2021 and 2020, and cash flows for the six months ended June 30, 2021 and 2020. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 24, 2021, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and six months ended June 30, 2021, and cash flows for the six months ended June 30, 2021 are not necessarily indicative of results that may be expected for the year ending December 31, 2021, or for any future period.
  (was, 2021-05-04, similarity 0.8157):
[0000926326-21-000013:note_history:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2021 and December 31, 2020, and the results of operations, comprehensive income, and cash flows for the three months ended March 31, 2021 and 2020. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 24, 2021, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations, comprehensive income, and cash flows for the three months ended March 31, 2021 are not necessarily indicative of results that may be expected for the year ending December 31, 2021, or for any future period.

- changed (2021-08-06):
[0000926326-21-000026:note_history:8]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of revenues for the three and six months ended June 30, 2020 in Note 3, Revenues. This change was not deemed material and was included to conform with current-period classification and presentation.
  (was, 2021-05-04, similarity 0.943):
[0000926326-21-000013:note_history:8]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of revenues for the three months ended March 31, 2020 in Note 3, Revenues. This change was not deemed material and was included to conform with current-period classification and presentation.

- changed (2021-08-06):
[0000926326-21-000026:note_history:9]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of June 30, 2021, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.
  (was, 2021-05-04, similarity 0.6758):
[0000926326-21-000013:note_history:9]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of March 31, 2021, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

- changed (2021-08-06):
[0000926326-21-000026:note_history:10]
In August 2020, the FASB issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. This update permits the use of either the modified retrospective or fully retrospective method of transition. ASU 2020-06 will be effective for the Company beginning January 1, 2022. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. The Company is currently evaluating the impact ASU 2020-06 will have on its Consolidated Financial Statements.
  (was, 2021-05-04, similarity 0.9947):
[0000926326-21-000013:note_history:10]
In August 2020, the FASB issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. This update permits the use of either the modified retrospective or fully retrospective method of transition. ASU 2020-06 will be effective for the Company beginning January 1, 2022. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. The Company is currently evaluating the impact ASU 2020-06 will have on its Condensed Consolidated Financial Statements.


## omcl:ScheduleOfDebtIssuanceCostsNetTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-06):
[0000926326-21-000026:note_history:11]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (549) |  |
| Balance as of June 30, 2021 | $ | 3,704 |  |
  (was, 2021-05-04, similarity 0.9686):
[0000926326-21-000013:note_history:11]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (274) |  |
| Balance as of March 31, 2021 | $ | 3,979 |  |


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-06):
[0000926326-21-000026:note_history:12]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2021:
  (was, 2021-05-04, similarity 0.911):
[0000926326-21-000013:note_history:12]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2021:

- added (2021-08-06):
[0000926326-21-000026:note_history:13]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |
|  | 2021 |  |  |  | 2021 |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  |  |  | $ | 719 |  |  |  |
| Amortization of discount | $ | 4,624 |  |  |  |  | $ | 9,195 |  |  |  |
| Amortization of debt issuance costs | $ | 583 |  |  |  |  | $ | 1,158 |  |  |  |

- removed (2021-08-06):
[0000926326-21-000013:note_history:14]
|  | Three Months Ended |  |  |  |  |
|  | March 31, 2021 |  |  |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  |  |  |  |  |  |
| Amortization of discount | $ | 4,571 |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 575 |  |  |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-06):
[0000926326-21-000026:note_history:15]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2021 and December 31, 2020:
  (was, 2021-05-04, similarity 0.966):
[0000926326-21-000013:note_history:15]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2021 and December 31, 2020:

- changed (2021-08-06):
[0000926326-21-000026:note_history:16]
|  | June 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (86,549) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (10,897) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 477,554 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |
  (was, 2021-05-04, similarity 0.9873):
[0000926326-21-000013:note_history:16]
|  | March 31,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (91,173) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (11,480) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 472,347 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-08-06):
[0000926326-21-000026:note_history:17]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo

- changed (2021-08-06):
[0000926326-21-000026:note_history:18]
Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility (the “Prior Credit Agreement”) and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.
  (was, 2021-05-04, similarity 0.6861):
[0000926326-21-000013:note_history:18]
Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

- changed (2021-08-06):
[0000926326-21-000026:note_history:19]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of June 30, 2021.
  (was, 2021-05-04, similarity 0.9974):
[0000926326-21-000013:note_history:19]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of March 31, 2021.

- changed (2021-08-06):
[0000926326-21-000026:note_history:20]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. In connection with the Amendment on September 22, 2020, the Company incurred and capitalized an additional $0.6 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs for credit agreements was approximately $0.3 million and $0.2 million for the three months ended June 30, 2021 and 2020, respectively, and approximately $0.5 million for both the six months ended June 30, 2021 and 2020.
  (was, 2021-05-04, similarity 0.927):
[0000926326-21-000013:note_history:20]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. In connection with the Amendment on September 22, 2020, the Company incurred and capitalized an additional $0.6 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs for credit agreements was approximately $0.3 million and $0.2 million for the three months ended March 31, 2021 and 2020, respectively.

- changed (2021-08-06):
[0000926326-21-000026:note_history:21]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (549) |  |
| Balance as of June 30, 2021 | $ | 3,704 |  |
  (was, 2021-05-04, similarity 0.9686):
[0000926326-21-000013:note_history:21]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (274) |  |
| Balance as of March 31, 2021 | $ | 3,979 |  |

- changed (2021-08-06):
[0000926326-21-000026:note_history:22]
As of each of June 30, 2021 and December 31, 2020, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025
  (was, 2021-05-04, similarity 0.973):
[0000926326-21-000013:note_history:22]
As of each of March 31, 2021 and December 31, 2020, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- changed (2021-08-06):
[0000926326-21-000026:note_history:23]
During the three months ended June 30, 2021, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on June 30, 2021, the last trading day of the fiscal quarter. Accordingly, the Notes are convertible, in whole or in part, at the option of the holders during the third quarter of 2021. Whether the Notes will be convertible following the third fiscal quarter of 2021 will depend on the continued satisfaction of this condition or another conversion condition in the future. The Company continues to classify the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of June 30, 2021 based on contractual settlement provisions.
  (was, 2021-05-04, similarity 0.9757):
[0000926326-21-000013:note_history:23]
During the three months ended March 31, 2021, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on March 31, 2021, the last trading day of the fiscal quarter. Accordingly, the Notes are convertible, in whole or in part, at the option of the holders during the second quarter of 2021. Whether the Notes will be convertible following the second fiscal quarter of 2021 will depend on the continued satisfaction of this condition or another conversion condition in the future. The Company continues to classify the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of March 31, 2021 based on contractual settlement provisions.

- changed (2021-08-06):
[0000926326-21-000026:note_history:24]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2021, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2021-05-04, similarity 0.6657):
[0000926326-21-000013:note_history:24]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal

- changed (2021-08-06):
[0000926326-21-000026:note_history:25]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.
  (was, 2021-05-04, similarity 0.9985):
[0000926326-21-000013:note_history:25]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

- changed (2021-08-06):
[0000926326-21-000026:note_history:26]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represents the debt discount, which the Company will amortize to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions. As of June 30, 2021, the remaining life of the Notes and the related debt discount and issuance cost accretion is approximately 4.2 years.
  (was, 2021-05-04, similarity 0.9958):
[0000926326-21-000013:note_history:26]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represents the debt discount, which the Company will amortize to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions. As of March 31, 2021, the remaining life of the Notes and the related debt discount and issuance cost accretion is approximately 4.5 years.

- changed (2021-08-06):
[0000926326-21-000026:note_history:27]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 8.1 million shares. As of June 30, 2021, the if-converted value of the Notes exceeded the principal amount by $319.8 million.
  (was, 2021-05-04, similarity 0.9835):
[0000926326-21-000013:note_history:27]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 8.1 million shares. As of March 31, 2021, the if-converted value of the Notes exceeded the principal amount by $192.3 million.

- changed (2021-08-06):
[0000926326-21-000026:note_history:28]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2021 and December 31, 2020:
  (was, 2021-05-04, similarity 0.966):
[0000926326-21-000013:note_history:28]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2021 and December 31, 2020:

- changed (2021-08-06):
[0000926326-21-000026:note_history:29]
|  | June 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (86,549) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (10,897) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 477,554 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |
  (was, 2021-05-04, similarity 0.9873):
[0000926326-21-000013:note_history:29]
|  | March 31,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (91,173) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (11,480) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 472,347 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |

- changed (2021-08-06):
[0000926326-21-000026:note_history:30]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2021:
  (was, 2021-05-04, similarity 0.911):
[0000926326-21-000013:note_history:30]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2021:

- added (2021-08-06):
[0000926326-21-000026:note_history:31]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |
|  | 2021 |  |  |  | 2021 |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  |  |  | $ | 719 |  |  |  |
| Amortization of discount | $ | 4,624 |  |  |  |  | $ | 9,195 |  |  |  |
| Amortization of debt issuance costs | $ | 583 |  |  |  |  | $ | 1,158 |  |  |  |

- added (2021-08-06):
[0000926326-21-000026:note_history:32]
In connection with the issuance of the Notes, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

- changed (2021-08-06):
[0000926326-21-000026:note_history:33]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.
  (was, 2021-05-04, similarity 0.6446):
[0000926326-21-000013:note_history:33]
In connection with the issuance of the Notes, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.

- added (2021-08-06):
[0000926326-21-000026:note_history:34]
Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.

- removed (2021-08-06):
[0000926326-21-000013:note_history:35]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility (the “Prior Credit Agreement”) and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit

- removed (2021-08-06):
[0000926326-21-000013:note_history:36]
amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2021, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- removed (2021-08-06):
[0000926326-21-000013:note_history:37]
|  | Three Months Ended |  |  |  |  |
|  | March 31, 2021 |  |  |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  |  |  |  |  |  |
| Amortization of discount | $ | 4,571 |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 575 |  |  |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-08-06):
[0000926326-21-000026:note_history:38]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule contract with the Department of Veterans Affairs (the "GSA Contract"). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee ("IFF") to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $4.2 million and $1.7 million for the three months ended June 30, 2021 and 2020, respectively, and $7.6 million and $4.6 million for the six months ended June 30, 2021 and 2020, respectively.
  (was, 2021-05-04, similarity 0.9388):
[0000926326-21-000013:note_history:38]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule contract with the Department of Veterans Affairs (the "GSA Contract"). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee ("IFF") to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $3.4 million and $2.9 million for the three months ended March 31, 2021 and 2020, respectively.

- changed (2021-08-06):
[0000926326-21-000026:note_history:39]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and six months ended June 30, 2021 and 2020:
  (was, 2021-05-04, similarity 0.9349):
[0000926326-21-000013:note_history:39]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three months ended March 31, 2021 and 2020:

- changed (2021-08-06):
[0000926326-21-000026:note_history:40]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 179,044 |  |  | $ | 121,377 |  |  | $ | 338,762 |  |  | $ | 268,724 |  |
| Technical services | 51,932 |  |  | 50,178 |  |  | 102,792 |  |  | 99,697 |  |
| Consumables | 17,867 |  |  | 17,565 |  |  | 36,274 |  |  | 40,291 |  |
| SaaS, subscription software, and technology-enabled services | 23,896 |  |  | 10,501 |  |  | 46,754 |  |  | 20,595 |  |
| Total revenues | $ | 272,739 |  |  | $ | 199,621 |  |  | $ | 524,582 |  |  | $ | 429,307 |  |
  (was, 2021-05-04, similarity 0.7687):
[0000926326-21-000013:note_history:40]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 159,718 |  |  | $ | 147,347 |  |  |  |  |  |
| Technical services | 50,860 |  |  | 49,519 |  |  |  |  |  |
| Consumables | 18,407 |  |  | 22,726 |  |  |  |  |  |
| SaaS, subscription software, and technology-enabled services | 22,858 |  |  | 10,094 |  |  |  |  |  |
| Total revenues | $ | 251,843 |  |  | $ | 229,686 |  |  |  |  |  |

- changed (2021-08-06):
[0000926326-21-000026:note_history:41]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2021 and 2020:
  (was, 2021-05-04, similarity 0.9539):
[0000926326-21-000013:note_history:41]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2021 and 2020:

- changed (2021-08-06):
[0000926326-21-000026:note_history:42]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| United States | $ | 242,859 |  |  | $ | 178,052 |  |  | $ | 467,135 |  |  | $ | 385,786 |  |
| Rest of world (1) | 29,880 |  |  | 21,569 |  |  | 57,447 |  |  | 43,521 |  |
| Total revenues | $ | 272,739 |  |  | $ | 199,621 |  |  | $ | 524,582 |  |  | $ | 429,307 |  |
  (was, 2021-05-04, similarity 0.714):
[0000926326-21-000013:note_history:42]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (In thousands) |
| United States | $ | 224,276 |  |  | $ | 207,734 |  |  |  |  |  |
| Rest of world (1) | 27,567 |  |  | 21,952 |  |  |  |  |  |
| Total revenues | $ | 251,843 |  |  | $ | 229,686 |  |  |  |  |  |

- changed (2021-08-06):
[0000926326-21-000026:note_history:43]
|  | June 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 12,465 |  |  | $ | 13,895 |  |
| Long-term unbilled receivables, net (2) | 15,074 |  |  | 17,205 |  |
| Total contract assets | $ | 27,539 |  |  | $ | 31,100 |  |
| Short-term deferred revenues, net | $ | 121,305 |  |  | $ | 100,053 |  |
| Long-term deferred revenues | 11,875 |  |  | 5,673 |  |
| Total contract liabilities | $ | 133,180 |  |  | $ | 105,726 |  |
  (was, 2021-05-04, similarity 0.9882):
[0000926326-21-000013:note_history:43]
|  | March 31,2021 |  | December 31,2020 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 12,184 |  |  | $ | 13,895 |  |
| Long-term unbilled receivables, net (2) | 14,856 |  |  | 17,205 |  |
| Total contract assets | $ | 27,040 |  |  | $ | 31,100 |  |
| Short-term deferred revenues, net | $ | 119,588 |  |  | $ | 100,053 |  |
| Long-term deferred revenues | 7,887 |  |  | 5,673 |  |
| Total contract liabilities | $ | 127,475 |  |  | $ | 105,726 |  |

- changed (2021-08-06):
[0000926326-21-000026:note_history:44]
Short-term deferred revenues of $121.3 million and $100.1 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $21.4 million and $21.0 million, as of June 30, 2021 and December 31, 2020, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and six months ended June 30, 2021, the Company recognized revenues of $23.8 million and $71.1 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $121.1 million as of December 31, 2020.
  (was, 2021-05-04, similarity 0.7725):
[0000926326-21-000013:note_history:44]
Short-term deferred revenues of $119.6 million and $100.1 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $20.8 million and $21.0 million, as of March 31, 2021 and December 31, 2020, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three months ended March 31, 2021, the Company recognized revenues of $47.3 million that were included in the corresponding gross short-term deferred revenues balance of $121.1 million as of December 31, 2020.

- changed (2021-08-06):
[0000926326-21-000026:note_history:45]
Long-term deferred revenues include deferred revenues from product and service contracts of $11.9 million and $5.7 million as of June 30, 2021 and December 31, 2020, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.
  (was, 2021-05-04, similarity 0.9853):
[0000926326-21-000013:note_history:45]
Long-term deferred revenues include deferred revenues from product and service contracts of $7.9 million and $5.7 million as of March 31, 2021 and December 31, 2020, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.

- changed (2021-08-06):
[0000926326-21-000026:note_history:46]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2021 and 2020. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of June 30, 2021 and December 31, 2020.
  (was, 2021-05-04, similarity 0.9048):
[0000926326-21-000013:note_history:46]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2021 and 2020. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2021 and December 31, 2020.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-08-06):
[0000926326-21-000026:note_history:47]
Subsequent EventsOn July 26, 2021, the Company announced its acquisition of RxInnovation Inc., a Delaware corporation, operating as FDS Amplicare (“FDS Amplicare”), for total aggregate cash consideration of $177.0 million, subject to customary adjustments. FDS Amplicare is a pharmacy software solutions provider. The transaction, which is expected to close in the second half of 2021, is subject to clearance under the Hart-Scott-Rodino Act and the satisfaction of other customary closing conditions.
