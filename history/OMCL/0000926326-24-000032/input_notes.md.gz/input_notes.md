# OMCL notes — 0000926326-24-000032


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-24-000032:notes:1]
[same as prior period, unchanged from 0000926326-24-000027:notes:1]

[0000926326-24-000032:notes:2]
[same as prior period, unchanged from 0000926326-24-000027:notes:2]

[0000926326-24-000032:notes:3]
[same as prior period, unchanged from 0000926326-24-000027:notes:3]

[0000926326-24-000032:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2024 and December 31, 2023, the results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2024 and 2023, and cash flows for the nine months ended September 30, 2024 and 2023. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on February 28, 2024. The Company’s results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2024, and cash flows for the nine months ended September 30, 2024 are not necessarily indicative of results that may be expected for the year ending December 31, 2024, or for any future period.

[0000926326-24-000032:notes:5]
[same as prior period, unchanged from 0000926326-24-000027:notes:5]

[0000926326-24-000032:notes:6]
[same as prior period, unchanged from 0000926326-24-000027:notes:6]

[0000926326-24-000032:notes:7]
[same as prior period, unchanged from 0000926326-24-000027:notes:7]

[0000926326-24-000032:notes:8]
[same as prior period, unchanged from 0000926326-24-000027:notes:8]

[0000926326-24-000032:notes:9]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of September 30, 2024, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-24-000032:notes:10]
[same as prior period, unchanged from 0000926326-24-000027:notes:10]

[0000926326-24-000032:notes:11]
[same as prior period, unchanged from 0000926326-24-000027:notes:11]

[0000926326-24-000032:notes:12]
[same as prior period, unchanged from 0000926326-24-000027:notes:12]

[0000926326-24-000032:notes:13]
[same as prior period, unchanged from 0000926326-24-000027:notes:13]

[0000926326-24-000032:notes:14]
[same as prior period, unchanged from 0000926326-24-000027:notes:14]

[0000926326-24-000032:notes:15]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires public entities to disclose significant segment expenses that are regularly provided to the CODM. Public entities with a single reportable segment are required to apply the disclosure requirements in ASU 2023-07, as well as all existing segment disclosures and reconciliation requirements in ASC 280, on an interim and annual basis. The amendments are effective for the Company’s annual periods beginning January 1, 2024, and for interim periods within fiscal years beginning January 1, 2025. Retrospective application is required, with early adoption permitted. The Company does not expect the adoption of ASU 2023-07 to have a material impact on its balance sheets, statements of operations, or statements of cash flows, as the anticipated changes will be the inclusion of additional disclosures related to the Company’s single reportable segment.

[0000926326-24-000032:notes:16]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning January 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2023-09 will have on its consolidated financial statements.

[0000926326-24-000032:notes:17]
[same as prior period, unchanged from 0000926326-24-000027:notes:17]

[0000926326-24-000032:notes:18]
[same as prior period, unchanged from 0000926326-24-000027:notes:18]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-24-000032:notes:19]
[same as prior period, unchanged from 0000926326-24-000027:notes:19]

[0000926326-24-000032:notes:20]
[same as prior period, unchanged from 0000926326-24-000027:notes:20]

[0000926326-24-000032:notes:21]
[same as prior period, unchanged from 0000926326-24-000027:notes:21]

[0000926326-24-000032:notes:22]
[same as prior period, unchanged from 0000926326-24-000027:notes:22]

[0000926326-24-000032:notes:23]
[same as prior period, unchanged from 0000926326-24-000027:notes:23]

[0000926326-24-000032:notes:24]
[same as prior period, unchanged from 0000926326-24-000027:notes:24]

[0000926326-24-000032:notes:25]
[same as prior period, unchanged from 0000926326-24-000027:notes:25]

[0000926326-24-000032:notes:26]
[same as prior period, unchanged from 0000926326-24-000027:notes:26]

[0000926326-24-000032:notes:27]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.5 million and $3.6 million for the three months ended September 30, 2024 and 2023, respectively, and $6.9 million and $9.5 million for the nine months ended September 30, 2024 and 2023, respectively.

[0000926326-24-000032:notes:28]
[same as prior period, unchanged from 0000926326-24-000027:notes:28]

[0000926326-24-000032:notes:29]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and nine months ended September 30, 2024 and 2023:

[0000926326-24-000032:notes:30]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 135,672 |  |  | $ | 167,560 |  |  | $ | 381,280 |  |  | $ | 500,182 |  |
| Consumables | 22,689 |  |  | 21,195 |  |  | 66,956 |  |  | 62,724 |  |
| Technical services | 59,583 |  |  | 57,303 |  |  | 177,419 |  |  | 167,851 |  |
| Advanced Services | 64,476 |  |  | 52,605 |  |  | 179,704 |  |  | 157,508 |  |
| Total revenues | $ | 282,420 |  |  | $ | 298,663 |  |  | $ | 805,359 |  |  | $ | 888,265 |  |

[0000926326-24-000032:notes:31]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2024 and 2023:

[0000926326-24-000032:notes:32]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| United States | $ | 258,177 |  |  | $ | 272,649 |  |  | $ | 731,670 |  |  | $ | 785,794 |  |
| Rest of world (1) | 24,243 |  |  | 26,014 |  |  | 73,689 |  |  | 102,471 |  |
| Total revenues | $ | 282,420 |  |  | $ | 298,663 |  |  | $ | 805,359 |  |  | $ | 888,265 |  |

[0000926326-24-000032:notes:33]
[same as prior period, unchanged from 0000926326-24-000027:notes:33]

[0000926326-24-000032:notes:34]
[same as prior period, unchanged from 0000926326-24-000027:notes:34]

[0000926326-24-000032:notes:35]
[same as prior period, unchanged from 0000926326-24-000027:notes:35]

[0000926326-24-000032:notes:36]
[same as prior period, unchanged from 0000926326-24-000027:notes:36]

[0000926326-24-000032:notes:37]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 33,722 |  |  | $ | 22,524 |  |
| Long-term unbilled receivables, net (2) | 9,171 |  |  | 11,850 |  |
| Total contract assets | $ | 42,893 |  |  | $ | 34,374 |  |
| Short-term deferred revenues | $ | 152,367 |  |  | $ | 121,734 |  |
| Long-term deferred revenues | 69,811 |  |  | 58,622 |  |
| Total contract liabilities | $ | 222,178 |  |  | $ | 180,356 |  |

[0000926326-24-000032:notes:38]
[same as prior period, unchanged from 0000926326-24-000027:notes:38]

[0000926326-24-000032:notes:39]
[same as prior period, unchanged from 0000926326-24-000027:notes:39]

[0000926326-24-000032:notes:40]
[same as prior period, unchanged from 0000926326-24-000027:notes:40]

[0000926326-24-000032:notes:41]
Short-term deferred revenues of $121.7 million as of December 31, 2023 include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.4 million. During the three and nine months ended September 30, 2024, the Company recognized revenues of $21.6 million and $106.6 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.1 million as of December 31, 2023.

[0000926326-24-000032:notes:42]
[same as prior period, unchanged from 0000926326-24-000027:notes:42]

[0000926326-24-000032:notes:43]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $403.0 million as of September 30, 2024. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

[0000926326-24-000032:notes:44]
[same as prior period, unchanged from 0000926326-24-000027:notes:44]

[0000926326-24-000032:notes:45]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2024 and 2023. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable and unbilled receivables balances as of September 30, 2024 and December 31, 2023.


## us-gaap:EarningsPerShareTextBlock

[0000926326-24-000032:notes:46]
Net Income (Loss) Per Share
The basic and diluted net income (loss) per share calculations for the three and nine months ended September 30, 2024 and 2023 were as follows:

[0000926326-24-000032:notes:47]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | 8,630 |  |  | $ | 5,553 |  |  | $ | (3,311) |  |  | $ | (5,996) |  |
| Weighted-average shares outstanding – basic | 46,153 |  |  | 45,333 |  |  | 45,947 |  |  | 45,117 |  |
| Effect of dilutive securities from stock award plans | 274 |  |  | 262 |  |  | — |  |  | — |  |
| Weighted-average shares outstanding – diluted | 46,427 |  |  | 45,595 |  |  | 45,947 |  |  | 45,117 |  |
| Net income (loss) per share – basic | $ | 0.19 |  |  | $ | 0.12 |  |  | $ | (0.07) |  |  | $ | (0.13) |  |
| Net income (loss) per share – diluted | $ | 0.19 |  |  | $ | 0.12 |  |  | $ | (0.07) |  |  | $ | (0.13) |  |
| Anti-dilutive weighted-average shares related to stock award plans | 2,687 |  |  | 2,727 |  |  | 3,767 |  |  | 3,536 |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | 11,816 |  |  | 11,816 |  |  | 11,816 |  |  | 11,816 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-24-000032:notes:48]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $570.6 million and $468.0 million as of September 30, 2024 and December 31, 2023, respectively, consisted of bank accounts and highly-liquid U.S. Government money market funds held in sweep and asset management accounts with financial institutions of high credit quality. As of September 30, 2024 and December 31, 2023, cash equivalents were $535.2 million and $451.0 million, respectively, which consisted of money market funds held in sweep and asset management accounts.

[0000926326-24-000032:notes:49]
Fair Value Hierarchy
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s credit facility is classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company’s convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. As of September 30, 2024 and December 31, 2023, the fair value of the convertible senior notes was $548.8 million and $527.2 million, respectively, compared to their carrying values of $572.0 million and $569.7 million, respectively, which are net of unamortized debt issuance costs. Refer to Note 9, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 10, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-24-000032:notes:50]
Balance Sheet Components
Balance sheet details as of September 30, 2024 and December 31, 2023 are presented in the tables below:

[0000926326-24-000032:notes:51]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 37,638 |  |  | $ | 51,439 |  |
| Work in process | 2,531 |  |  | 1,327 |  |
| Finished goods | 54,890 |  |  | 57,333 |  |
| Total inventories | $ | 95,059 |  |  | $ | 110,099 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 31,849 |  |  | $ | 43,649 |  |
| Net investment in sales-type leases, current portion | 11,699 |  |  | 11,867 |  |
| Prepaid income taxes | 2,233 |  |  | 8,279 |  |
| Other current assets (2) | 19,146 |  |  | 7,714 |  |
| Total other current assets | $ | 64,927 |  |  | $ | 71,509 |  |
| Other long-term assets: |  |  |  |
| External-use software development costs, net | $ | 59,557 |  |  | $ | 66,659 |  |
| Unbilled receivables, net | 9,171 |  |  | 11,850 |  |
| Deferred debt issuance costs | 3,134 |  |  | 3,718 |  |
| Other long-term assets | 9,872 |  |  | 8,239 |  |
| Total other long-term assets | $ | 81,734 |  |  | $ | 90,466 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 10,615 |  |  | $ | 10,518 |  |
| Customer fund liabilities | 31,849 |  |  | 43,649 |  |
| Advance payments from customers | 8,941 |  |  | 10,551 |  |
| Rebate liabilities | 58,079 |  |  | 51,277 |  |
| Group purchasing organization fees | 4,859 |  |  | 4,445 |  |
| Taxes payable | 2,842 |  |  | 2,191 |  |
| Other accrued liabilities | 27,068 |  |  | 26,645 |  |
| Total accrued liabilities | $ | 144,253 |  |  | $ | 149,276 |  |

[0000926326-24-000032:notes:52]
(1)    Includes restricted cash of $22.3 million and $33.0 million as of September 30, 2024 and December 31, 2023, respectively.

[0000926326-24-000032:notes:53]
(2)    Includes deferred cost of sales of $13.7 million as of September 30, 2024.

[0000926326-24-000032:notes:54]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss), which consisted of foreign currency translation adjustments, for the three and nine months ended September 30, 2024 and 2023:

[0000926326-24-000032:notes:55]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Beginning balance | $ | (14,878) |  |  | $ | (14,176) |  |  | $ | (13,432) |  |  | $ | (17,087) |  |
| Other comprehensive income (loss) | 4,575 |  |  | (2,953) |  |  | 3,129 |  |  | (42) |  |
| Ending balance | $ | (10,303) |  |  | $ | (17,129) |  |  | $ | (10,303) |  |  | $ | (17,129) |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-24-000032:notes:56]
Property and Equipment
The following table represents the property and equipment balances as of September 30, 2024 and December 31, 2023:

[0000926326-24-000032:notes:57]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Equipment | $ | 99,491 |  |  | $ | 95,996 |  |
| Furniture and fixtures | 5,312 |  |  | 4,500 |  |
| Leasehold improvements | 17,996 |  |  | 17,919 |  |
| Purchased software and internal-use software development costs | 141,082 |  |  | 118,004 |  |
| Construction in progress | 9,119 |  |  | 11,614 |  |
| Property and equipment, gross | 273,000 |  |  | 248,033 |  |
| Accumulated depreciation and amortization | (161,256) |  |  | (139,432) |  |
| Total property and equipment, net | $ | 111,744 |  |  | $ | 108,601 |  |

[0000926326-24-000032:notes:58]
Depreciation and amortization expense of property and equipment was $8.6 million and $6.7 million for the three months ended September 30, 2024 and 2023, respectively, and $25.9 million and $19.6 million for the nine months ended September 30, 2024 and 2023, respectively.

[0000926326-24-000032:notes:59]
The geographic location of the Company’s property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of September 30, 2024 and December 31, 2023:

[0000926326-24-000032:notes:60]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| United States | $ | 107,551 |  |  | $ | 104,312 |  |
| Rest of world | 4,193 |  |  | 4,289 |  |
| Total property and equipment, net | $ | 111,744 |  |  | $ | 108,601 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwareDisclosureTextBlock

[0000926326-24-000032:notes:61]
External-Use Software Development Costs
The carrying amounts of external-use software development costs as of September 30, 2024 and December 31, 2023 were as follows:

[0000926326-24-000032:notes:62]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Gross carrying amount | $ | 245,155 |  |  | $ | 239,038 |  |
| Accumulated amortization | (185,598) |  |  | (172,379) |  |
| External-use software development costs, net (1) | $ | 59,557 |  |  | $ | 66,659 |  |

[0000926326-24-000032:notes:63]
[same as prior period, unchanged from 0000926326-24-000027:notes:63]

[0000926326-24-000032:notes:64]
The Company recorded $6.0 million and $7.1 million to cost of revenues for amortization of external-use software development costs for the three months ended September 30, 2024 and 2023, respectively, and $19.1 million and $21.9 million for the nine months ended September 30, 2024 and 2023, respectively.

[0000926326-24-000032:notes:65]
[same as prior period, unchanged from 0000926326-24-000027:notes:65]

[0000926326-24-000032:notes:66]
|  | September 30,2024 |
|  | (In thousands) |
| Remaining three months of 2024 | $ | 5,862 |  |
| 2025 | 20,545 |  |
| 2026 | 15,269 |  |
| 2027 | 9,336 |  |
| 2028 | 5,478 |  |
| Thereafter | 3,067 |  |
| Total | $ | 59,557 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-24-000032:notes:67]
[same as prior period, unchanged from 0000926326-24-000027:notes:67]

[0000926326-24-000032:notes:68]
[same as prior period, unchanged from 0000926326-24-000027:notes:68]

[0000926326-24-000032:notes:69]
|  |  |  |  |  | (In thousands) |
| Balance as of December 31, 2023 |  |  |  |  | $ | 735,810 |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | 1,359 |  |
| Balance as of September 30, 2024 |  |  |  |  | $ | 737,169 |  |

[0000926326-24-000032:notes:70]
[same as prior period, unchanged from 0000926326-24-000027:notes:70]

[0000926326-24-000032:notes:71]
The carrying amounts and useful lives of intangible assets as of September 30, 2024 and December 31, 2023 were as follows:

[0000926326-24-000032:notes:72]
|  | September 30, 2024 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 307,418 |  |  | $ | (128,750) |  |  | $ | (1,197) |  |  | $ | 177,471 |  |  | 4 - 30 |
| Acquired technology | 46,134 |  |  | (31,405) |  |  | — |  |  | 14,729 |  |  | 4 - 20 |
| Trade names | 2,400 |  |  | (1,460) |  |  | — |  |  | 940 |  |  | 5 |
| Patents | 2,291 |  |  | (1,462) |  |  | — |  |  | 829 |  |  | 2 - 20 |
| Total intangible assets, net | $ | 358,243 |  |  | $ | (163,077) |  |  | $ | (1,197) |  |  | $ | 193,969 |  |  |  |

[0000926326-24-000032:notes:73]
[same as prior period, unchanged from 0000926326-24-000027:notes:73]

[0000926326-24-000032:notes:74]
[same as prior period, unchanged from 0000926326-24-000027:notes:74]

[0000926326-24-000032:notes:75]
Amortization expense of intangible assets was $5.6 million and $7.7 million for the three months ended September 30, 2024 and 2023, respectively, and $17.3 million and $24.1 million for the nine months ended September 30, 2024 and 2023, respectively.

[0000926326-24-000032:notes:76]
[same as prior period, unchanged from 0000926326-24-000027:notes:76]

[0000926326-24-000032:notes:77]
|  | September 30,2024 |
|  | (In thousands) |
| Remaining three months of 2024 | $ | 5,526 |  |
| 2025 | 21,002 |  |
| 2026 | 18,087 |  |
| 2027 | 16,269 |  |
| 2028 | 15,184 |  |
| Thereafter | 117,901 |  |
| Total | $ | 193,969 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-24-000032:notes:78]
Debt and Credit Agreement
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. As referred to herein, “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023, to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q), expand the Company’s flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-24-000032:notes:79]
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-24-000032:notes:80]
Loans under the Current Revolving Credit Facility bear interest, at Omnicell, Inc.’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility Omnicell, Inc. is permitted to

[0000926326-24-000032:notes:81]
make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

[0000926326-24-000032:notes:82]
The Second A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Second A&R Credit Agreement contains financial covenants that require the Company to not exceed a maximum consolidated secured net leverage ratio (not to exceed 3.00:1) and maintain a minimum consolidated interest coverage ratio (not to be less than 3.00:1). In addition, the Second A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.

[0000926326-24-000032:notes:83]
Omnicell, Inc.’s obligations under the Second A&R Credit Agreement and, at the election of Omnicell, Inc. and the contracting counterparty, any secured swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the Second A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, Omnicell, Inc. and certain of Omnicell, Inc.’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement.

[0000926326-24-000032:notes:84]
The refinancing of the Prior Credit Agreement on October 10, 2023 was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the Second A&R Credit Agreement. The Company incurred and capitalized an additional $3.0 million of debt issuance costs which are being amortized to interest expense using the straight-line method through 2028.

[0000926326-24-000032:notes:85]
As of both September 30, 2024 and December 31, 2023, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of September 30, 2024 and December 31, 2023, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of September 30, 2024.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-24-000032:notes:86]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

[0000926326-24-000032:notes:87]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on

[0000926326-24-000032:notes:88]
the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

[0000926326-24-000032:notes:89]
During the three months ended September 30, 2024 and December 31, 2023, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the fourth quarter of 2024, commencing on October 1, 2024, and were not convertible during the first quarter of 2024, commencing on January 1, 2024. As such, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of December 31, 2023. As the Notes will mature on September 15, 2025, the Company classified the Notes as a current liability as of September 30, 2024. Whether the Notes will be convertible following the fourth fiscal quarter of 2024 will depend on the satisfaction of the conversion conditions in the future.

[0000926326-24-000032:notes:90]
Under the original terms of the Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of Notes of at least $1,000. As a result, for Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of Notes above $1,000. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that could occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

[0000926326-24-000032:notes:91]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2024, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-24-000032:notes:92]
As of September 30, 2024, the Company may redeem for cash all or any portion of the Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

[0000926326-24-000032:notes:93]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of September 30, 2024, the remaining life of the Notes and the related issuance cost accretion is approximately 1.0 year.

[0000926326-24-000032:notes:94]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of September 30, 2024, the if-converted value of the Notes did not exceed the principal amount.

[0000926326-24-000032:notes:95]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2024 and December 31, 2023:

[0000926326-24-000032:notes:96]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (3,003) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 571,997 |  |  | $ | 569,662 |  |

[0000926326-24-000032:notes:97]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2024 and 2023:

[0000926326-24-000032:notes:98]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of debt issuance costs | $ | 780 |  |  | $ | 773 |  |  | $ | 2,335 |  |  | $ | 2,316 |  |

[0000926326-24-000032:notes:99]
Convertible Note Hedge and Warrant Transactions

[0000926326-24-000032:notes:100]
In connection with the issuance of the Notes in September 2020, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

[0000926326-24-000032:notes:101]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.

[0000926326-24-000032:notes:102]
Separately from the convertible note hedge, in September 2020, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-24-000032:notes:103]
[same as prior period, unchanged from 0000926326-24-000027:notes:102]

[0000926326-24-000032:notes:104]
[same as prior period, unchanged from 0000926326-24-000027:notes:103]

[0000926326-24-000032:notes:105]
The following table presents the Company’s income recognized from sales-type leases for the three and nine months ended September 30, 2024 and 2023:

[0000926326-24-000032:notes:106]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 6,952 |  |  | $ | 14,388 |  |  | $ | 25,564 |  |  | $ | 27,960 |  |
| Cost of sales-type lease revenues | (3,912) |  |  | (7,141) |  |  | (15,209) |  |  | (14,183) |  |
| Selling profit on sales-type lease revenues | $ | 3,040 |  |  | $ | 7,247 |  |  | $ | 10,355 |  |  | $ | 13,777 |  |

[0000926326-24-000032:notes:107]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at September 30, 2024 and December 31, 2023:

[0000926326-24-000032:notes:108]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 74,595 |  |  | $ | 65,017 |  |
| Less: Unearned interest income portion | (12,321) |  |  | (10,196) |  |
| Net investment in sales-type leases | 62,274 |  |  | 54,821 |  |
| Less: Current portion (1) | (11,699) |  |  | (11,867) |  |
| Long-term investment in sales-type leases, net | $ | 50,575 |  |  | $ | 42,954 |  |

[0000926326-24-000032:notes:109]
[same as prior period, unchanged from 0000926326-24-000027:notes:108]

[0000926326-24-000032:notes:110]
[same as prior period, unchanged from 0000926326-24-000027:notes:109]

[0000926326-24-000032:notes:111]
[same as prior period, unchanged from 0000926326-24-000027:notes:110]

[0000926326-24-000032:notes:112]
|  | September 30,2024 |
|  | (In thousands) |
| Remaining three months of 2024 | $ | 3,795 |  |
| 2025 | 14,238 |  |
| 2026 | 12,627 |  |
| 2027 | 11,080 |  |
| 2028 | 10,094 |  |
| Thereafter | 22,761 |  |
| Total future minimum sales-type lease payments | 74,595 |  |
| Present value adjustment | (12,321) |  |
| Total net investment in sales-type leases | $ | 62,274 |  |

[0000926326-24-000032:notes:113]
[same as prior period, unchanged from 0000926326-24-000027:notes:112]

[0000926326-24-000032:notes:114]
The following table represents the Company’s income recognized from operating leases for the three and nine months ended September 30, 2024 and 2023:

[0000926326-24-000032:notes:115]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Rental income | $ | 1,230 |  |  | $ | 1,330 |  |  | $ | 2,797 |  |  | $ | 5,459 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-24-000032:notes:116]
Lessee Leases 
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to twelve years. As of September 30, 2024, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-24-000032:notes:117]
[same as prior period, unchanged from 0000926326-24-000027:notes:116]

[0000926326-24-000032:notes:118]
|  | September 30,2024 |
|  | (In thousands) |
| Remaining three months of 2024 | $ | 3,296 |  |
| 2025 | 12,432 |  |
| 2026 | 11,561 |  |
| 2027 | 9,557 |  |
| 2028 | 8,193 |  |
| Thereafter | 2,271 |  |
| Total operating lease payments | 47,310 |  |
| Present value adjustment | (5,171) |  |
| Total operating lease liabilities (1) | $ | 42,139 |  |

[0000926326-24-000032:notes:119]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $10.6 million and $31.5 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-24-000032:notes:120]
Operating lease costs were $2.5 million and $2.6 million for the three months ended September 30, 2024 and 2023, respectively, and $7.7 million and $8.2 million for the nine months ended September 30, 2024 and 2023, respectively. Short-term lease costs and variable lease costs were not material for the three and nine months ended September 30, 2024 and 2023. The Company recorded impairment and abandonment charges to operating lease right-of-use assets of $7.8 million during the nine months ended September 30, 2023, in connection with restructuring activities to reduce its real estate footprint and for optimization of certain leased facilities. The impairment and abandonment charges were recorded to selling, general, and administrative expenses on the Company’s Condensed Consolidated Statements of Operations. Refer to Note 16, Restructuring Expenses, for additional information regarding the Company’s restructuring activities.

[0000926326-24-000032:notes:121]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the nine months ended September 30, 2024 and 2023:

[0000926326-24-000032:notes:122]
|  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 9,891 |  |  | $ | 10,100 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 5,831 |  |  | $ | 1,758 |  |

[0000926326-24-000032:notes:123]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of September 30, 2024 and December 31, 2023:

[0000926326-24-000032:notes:124]
|  | September 30,2024 |  | December 31,2023 |
| Weighted-average remaining lease term, years | 4.0 |  | 4.6 |
| Weighted-average discount rate, % | 5.8 | % |  | 5.8 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-24-000032:notes:125]
Commitments and Contingencies
Purchase Obligations

[0000926326-24-000032:notes:126]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2024, the Company had non-cancelable purchase commitments of $111.2 million, of which $71.4 million are expected to be paid within the year ending December 31, 2024.

[0000926326-24-000032:notes:127]
Legal Proceedings

[0000926326-24-000032:notes:128]
The Company is currently involved in various legal proceedings.

[0000926326-24-000032:notes:129]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in such matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.

[0000926326-24-000032:notes:130]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company’s financial position or results of operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-24-000032:notes:131]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. For the nine months ended September 30, 2024 and September 30, 2023, the Company recorded a provision for income taxes of $5.3 million and $4.4 million, respectively, by applying its estimated annual effective tax rate to its year-to-date measure of ordinary income and adjusted for $4.9 million and $5.6 million, respectively, of discrete income tax expense primarily from equity compensation.

[0000926326-24-000032:notes:132]
The effective tax rate for the nine months ended September 30, 2024 and 2023, differed from the statutory rate of 21% primarily due to the benefit of the research and development credits and a foreign-derived intangible income (“FDII”) benefit deduction, partially offset by the unfavorable impact of the non-deductible compensation and equity charges.

[0000926326-24-000032:notes:133]
The Organization for Economic Co-Operation and Development (“OECD”) introduced Base Erosion and Profit Shifting (“BEPS”) Pillar Two rules that impose a global minimum tax rate of 15% on multi-national corporations. The rules are effective for the Company’s financial year beginning January 1, 2024. These rules did not have an impact on the Company’s provision for income taxes for the nine months ended September 30, 2024.

[0000926326-24-000032:notes:134]
As of September 30, 2024 and December 31, 2023, the Company had gross unrecognized tax benefits of $11.5 million and $10.7 million, respectively. The Company recognizes interest and penalties related to uncertain tax positions in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. Accrued interest and penalties are included within other long-term liabilities on the Condensed Consolidated Balance Sheets. As of September 30, 2024 and December 31, 2023, the amount of accrued interest and penalties was $0.8 million and $0.4 million, respectively.

[0000926326-24-000032:notes:135]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examinations by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, France, and the United Kingdom. With few exceptions, as of September 30, 2024, the Company was no longer subject to U.S., state, and foreign tax examinations for years before 2020, 2019, and 2019, respectively.

[0000926326-24-000032:notes:136]
[same as prior period, unchanged from 0000926326-24-000027:notes:135]


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-24-000032:notes:137]
[same as prior period, unchanged from 0000926326-24-000027:notes:136]

[0000926326-24-000032:notes:138]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2024 and 2023:

[0000926326-24-000032:notes:139]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,709 |  |  | $ | 2,213 |  |  | $ | 4,884 |  |  | $ | 6,489 |  |
| Research and development | 1,062 |  |  | 1,917 |  |  | 3,276 |  |  | 5,220 |  |
| Selling, general, and administrative | 8,834 |  |  | 10,852 |  |  | 22,117 |  |  | 31,404 |  |
| Total share-based compensation expense | $ | 11,605 |  |  | $ | 14,982 |  |  | $ | 30,277 |  |  | $ | 43,113 |  |

[0000926326-24-000032:notes:140]
The Company capitalized approximately $1.0 million and $1.1 million during the three months ended September 30, 2024 and 2023, respectively, and $2.7 million and $3.3 million during the nine months ended September 30, 2024 and 2023, respectively, of non-cash share-based compensation expense to internal-use and external-use software development costs related to internal labor. The Company did not capitalize any material share-based compensation expense to inventory during the three and nine months ended September 30, 2024 and 2023.

[0000926326-24-000032:notes:141]
[same as prior period, unchanged from 0000926326-24-000027:notes:140]

[0000926326-24-000032:notes:142]
The following assumptions were used to value shares under the ESPP for the three and nine months ended September 30, 2024 and 2023:

[0000926326-24-000032:notes:143]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Expected volatility, % | 33.7% - 58.7% |  | 32.0% - 63.9% |  | 33.7% - 58.7% |  | 31.7% - 63.9% |
| Risk-free interest rate, % | 3.2% - 5.3% |  | 0.2% - 5.5% |  | 1.5% - 5.5% |  | 0.1% - 5.5% |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-24-000032:notes:144]
For the nine months ended September 30, 2024 and 2023, employees purchased approximately 524,000 and 353,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $24.14 and $46.68, respectively. As of September 30, 2024, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $0.6 million and is expected to be recognized over a weighted-average period of 1.6 years.

[0000926326-24-000032:notes:145]
[same as prior period, unchanged from 0000926326-24-000027:notes:144]

[0000926326-24-000032:notes:146]
The following assumptions were used to value stock options granted pursuant to the Company’s 2009 Equity Incentive Plan, as amended (the “2009 Plan”) for the nine months ended September 30, 2023. There were no stock options granted during the three and nine months ended September 30, 2024 or the three months ended September 30, 2023.

[0000926326-24-000032:notes:147]
|  |  | Nine Months Ended September 30, |  |  |
|  |  |  | 2023 |  |  |  |  |
| Expected life, years |  |  | 3.2 |  |  |  |  |
| Expected volatility, % |  |  | 44.8 | % |  |  |  |  |
| Risk-free interest rate, % |  |  | 3.7 | % |  |  |  |  |
| Estimated forfeiture rate, % |  |  | 10.0 | % |  |  |  |  |
| Dividend yield, % |  |  | — | % |  |  |  |  |

[0000926326-24-000032:notes:148]
The following table summarizes the stock option activity under the 2009 Plan during the nine months ended September 30, 2024:

[0000926326-24-000032:notes:149]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2023 | 2,023 |  |  | $ | 67.68 |  |  | 4.6 |  | $ | 1,013 |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (16) |  |  | 30.54 |  |  |  |  |  |
| Expired | (209) |  |  | 73.50 |  |  |  |  |  |
| Forfeited | (23) |  |  | 63.93 |  |  |  |  |  |
| Outstanding at September 30, 2024 | 1,775 |  |  | $ | 67.38 |  |  | 4.1 |  | $ | 2,399 |  |
| Exercisable at September 30, 2024 | 1,762 |  |  | $ | 66.97 |  |  | 4.0 |  | $ | 2,399 |  |
| Vested and expected to vest at September 30, 2024 and thereafter | 1,774 |  |  | $ | 67.36 |  |  | 4.1 |  | $ | 2,399 |  |

[0000926326-24-000032:notes:150]
As of September 30, 2024, total unrecognized compensation cost related to unvested stock options was $0.3 million, which is expected to be recognized over a weighted-average vesting period of 0.4 years.

[0000926326-24-000032:notes:151]
[same as prior period, unchanged from 0000926326-24-000027:notes:150]

[0000926326-24-000032:notes:152]
The following table summarizes the RSU activity under the 2009 Plan during the nine months ended September 30, 2024:

[0000926326-24-000032:notes:153]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2023 | 1,078 |  |  | $ | 84.66 |  |  | 1.5 |  | $ | 40,551 |  |
| Granted (Awarded) | 1,023 |  |  | 40.04 |  |  |  |  |  |
| Vested (Released) | (297) |  |  | 88.81 |  |  |  |  |  |
| Forfeited | (130) |  |  | 78.53 |  |  |  |  |  |
| Outstanding and unvested at September 30, 2024 | 1,674 |  |  | $ | 57.13 |  |  | 1.7 |  | $ | 72,966 |  |

[0000926326-24-000032:notes:154]
As of September 30, 2024, total unrecognized compensation cost related to RSUs was $62.5 million, which is expected to be recognized over the remaining weighted-average vesting period of 3.2 years.

[0000926326-24-000032:notes:155]
[same as prior period, unchanged from 0000926326-24-000027:notes:154]

[0000926326-24-000032:notes:156]
The following table summarizes the RSA activity under the 2009 Plan during the nine months ended September 30, 2024:

[0000926326-24-000032:notes:157]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2023 | 24 |  |  | $ | 70.96 |  |
| Granted (Awarded) | 51 |  |  | 31.94 |  |
| Vested (Released) | (26) |  |  | 67.32 |  |
| Outstanding and unvested at September 30, 2024 | 49 |  |  | $ | 31.91 |  |

[0000926326-24-000032:notes:158]
As of September 30, 2024, total unrecognized compensation cost related to RSAs was $0.8 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.6 years.

[0000926326-24-000032:notes:159]
[same as prior period, unchanged from 0000926326-24-000027:notes:158]

[0000926326-24-000032:notes:160]
The following table summarizes the PSU activity under the 2009 Plan during the nine months ended September 30, 2024:

[0000926326-24-000032:notes:161]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2023 | 75 |  |  | $ | 127.14 |  |
| Granted (Awarded) | 177 |  |  | 28.67 |  |
| Vested (Released) | (5) |  |  | 157.56 |  |
| Forfeited | (65) |  |  | 122.29 |  |
| Outstanding and unvested at September 30, 2024 | 182 |  |  | $ | 32.33 |  |

[0000926326-24-000032:notes:162]
As of September 30, 2024, total unrecognized compensation cost related to PSUs was approximately $3.9 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.6 years.

[0000926326-24-000032:notes:163]
[same as prior period, unchanged from 0000926326-24-000027:notes:162]

[0000926326-24-000032:notes:164]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of September 30, 2024:

[0000926326-24-000032:notes:165]
|  | Number of Shares |
|  | (In thousands) |
| Stock options outstanding | 1,775 |  |
| Non-vested restricted stock awards | 1,905 |  |
| Shares authorized for future issuance | 3,396 |  |
| ESPP shares available for future issuance | 2,726 |  |
| Total shares reserved for future issuance | 9,802 |  |

[0000926326-24-000032:notes:166]
[same as prior period, unchanged from 0000926326-24-000027:notes:165]

[0000926326-24-000032:notes:167]
On August 2, 2016, the Company’s Board of Directors (the “Board”) authorized a stock repurchase program, which does not expire, providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). As of September 30, 2024, the maximum dollar value of shares that may yet be purchased under the 2016 Repurchase Program was $2.7 million.

[0000926326-24-000032:notes:168]
[same as prior period, unchanged from 0000926326-24-000027:notes:167]

[0000926326-24-000032:notes:169]
During the three and nine months ended September 30, 2024 and 2023, the Company did not repurchase any of its outstanding common stock under the 2016 Repurchase Program.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-24-000032:notes:170]
Restructuring Expenses
On November 23, 2022, the Company committed to a plan to reduce the Company’s headcount (the “2022 Plan”), as part of the Company’s expense containment efforts being implemented due to ongoing macroeconomic headwinds. During the first quarter of 2023, as a result of continued exploration of expense containment measures, the Company committed to further reduce its headcount across many of its functions, and also committed to reduce its real estate footprint to align with its broader hybrid work strategy and in an effort to further reduce costs. During the three months ended September 30, 2023, the Company recorded an immaterial reversal of previously recognized restructuring expenses associated with the 2022 Plan. During the nine months ended September 30, 2023, the Company incurred $5.5 million of employee severance costs and related expenses, net of reversals, in connection with the 2022 Plan. As of September 30, 2024, there was no unpaid balance related to the 2022 Plan.

[0000926326-24-000032:notes:171]
On November 2, 2023, the Company committed to a plan to reduce the Company’s headcount and real estate footprint (the “2023 Plan”) as part of the Company’s expense containment initiatives and other actions to reduce discretionary spending being implemented due to challenging industry dynamics and macroeconomic conditions. The Company did not incur any material expenses related to the 2023 Plan during both the three and nine months ended September 30, 2024 and 2023. As of September 30, 2024 and December 31, 2023, the unpaid balance related to the 2023 Plan was $0.8 million and $8.9 million, respectively.

[0000926326-24-000032:notes:172]
On April 26, 2024, the Company’s management committed to the wind down of the Company’s Medimat Robotic Dispensing System (“RDS”) product line, subject to local law and statutory works council consultation requirements. During the three and nine months ended September 30, 2024, the Company incurred approximately $0.6 million and $4.1 million, respectively, of employee severance costs and other expenses related to the RDS product line wind down, net of immaterial reversals of previously recognized restructuring expenses, the majority of which were unpaid as of September 30, 2024. In addition, during the nine months ended September 30, 2024, the Company incurred $5.4 million of inventory write-down charges related to the RDS product line wind down that were recorded to cost of revenues in the Company’s Condensed Consolidated Statements of Operations.

[0000926326-24-000032:notes:173]
[same as prior period, unchanged from 0000926326-24-000027:notes:172]

[0000926326-24-000032:notes:174]
The following table summarizes the total employee-related restructuring expense, net of reversals, recognized in the Company’s Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2024 and 2023:

[0000926326-24-000032:notes:175]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 642 |  |  | $ | (280) |  |  | $ | 3,338 |  |  | $ | 102 |  |
| Research and development | (15) |  |  | (25) |  |  | 296 |  |  | 467 |  |
| Selling, general, and administrative | (7) |  |  | (276) |  |  | 149 |  |  | 4,885 |  |
| Total restructuring expense | $ | 620 |  |  | $ | (581) |  |  | $ | 3,783 |  |  | $ | 5,454 |  |
