# OMCL MD&A — 0000926326-24-000032


## mdna

[0000926326-24-000032:mdna:1]
[same as prior period, unchanged from 0000926326-24-000027:mdna:1]

[0000926326-24-000032:mdna:2]
[same as prior period, unchanged from 0000926326-24-000027:mdna:2]

[0000926326-24-000032:mdna:3]
[same as prior period, unchanged from 0000926326-24-000027:mdna:3]

[0000926326-24-000032:mdna:4]
[same as prior period, unchanged from 0000926326-24-000027:mdna:4]

[0000926326-24-000032:mdna:5]
[same as prior period, unchanged from 0000926326-24-000027:mdna:5]

[0000926326-24-000032:mdna:6]
[same as prior period, unchanged from 0000926326-24-000027:mdna:6]

[0000926326-24-000032:mdna:7]
[same as prior period, unchanged from 0000926326-24-000027:mdna:7]

[0000926326-24-000032:mdna:8]
[same as prior period, unchanged from 0000926326-24-000027:mdna:8]

[0000926326-24-000032:mdna:9]
[same as prior period, unchanged from 0000926326-24-000027:mdna:9]

[0000926326-24-000032:mdna:10]
[same as prior period, unchanged from 0000926326-24-000027:mdna:10]

[0000926326-24-000032:mdna:11]
[same as prior period, unchanged from 0000926326-24-000027:mdna:11]

[0000926326-24-000032:mdna:12]
[same as prior period, unchanged from 0000926326-24-000027:mdna:12]

[0000926326-24-000032:mdna:13]
[same as prior period, unchanged from 0000926326-24-000027:mdna:13]

[0000926326-24-000032:mdna:14]
[same as prior period, unchanged from 0000926326-24-000027:mdna:14]

[0000926326-24-000032:mdna:15]
[same as prior period, unchanged from 0000926326-24-000027:mdna:15]

[0000926326-24-000032:mdna:16]
[same as prior period, unchanged from 0000926326-24-000027:mdna:16]

[0000926326-24-000032:mdna:17]
[same as prior period, unchanged from 0000926326-24-000027:mdna:17]

[0000926326-24-000032:mdna:18]
[same as prior period, unchanged from 0000926326-24-000027:mdna:18]

[0000926326-24-000032:mdna:19]
[same as prior period, unchanged from 0000926326-24-000027:mdna:19]

[0000926326-24-000032:mdna:20]
[same as prior period, unchanged from 0000926326-24-000027:mdna:20]

[0000926326-24-000032:mdna:21]
[same as prior period, unchanged from 0000926326-24-000027:mdna:21]

[0000926326-24-000032:mdna:22]
[same as prior period, unchanged from 0000926326-24-000027:mdna:22]

[0000926326-24-000032:mdna:23]
[same as prior period, unchanged from 0000926326-24-000027:mdna:23]

[0000926326-24-000032:mdna:24]
[same as prior period, unchanged from 0000926326-24-000027:mdna:24]

[0000926326-24-000032:mdna:25]
Omnicell solutions are helping healthcare facilities worldwide to reduce costs, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry vision of the Autonomous Pharmacy. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 91% of our total revenues for both the three months ended September 30, 2024 and 2023, and 91% and 88% of our total revenues for the nine months ended September 30, 2024 and 2023, respectively.

[0000926326-24-000032:mdna:26]
[same as prior period, unchanged from 0000926326-24-000027:mdna:26]

[0000926326-24-000032:mdna:27]
[same as prior period, unchanged from 0000926326-24-000027:mdna:27]

[0000926326-24-000032:mdna:28]
[same as prior period, unchanged from 0000926326-24-000027:mdna:28]

[0000926326-24-000032:mdna:29]
We generally provide installation planning and consulting as part of most connected device product sales, which are typically included in the initial price of the solution. To help ensure the maximum availability of our systems, our customers typically purchase technical services contracts (maintenance and support) in increments of one to five years. In addition to connected device product sales, we provide a range of services to our customers. We also provide Advanced Services such as Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions, which typically are provided over two to seven years.

[0000926326-24-000032:mdna:30]
[same as prior period, unchanged from 0000926326-24-000027:mdna:30]

[0000926326-24-000032:mdna:31]
[same as prior period, unchanged from 0000926326-24-000027:mdna:31]

[0000926326-24-000032:mdna:32]
[same as prior period, unchanged from 0000926326-24-000027:mdna:32]

[0000926326-24-000032:mdna:33]
[same as prior period, unchanged from 0000926326-24-000027:mdna:33]

[0000926326-24-000032:mdna:34]
[same as prior period, unchanged from 0000926326-24-000027:mdna:34]

[0000926326-24-000032:mdna:35]
[same as prior period, unchanged from 0000926326-24-000027:mdna:35]

[0000926326-24-000032:mdna:36]
Our full-time employee headcount was approximately 3,660 and 3,650 on September 30, 2024 and December 31, 2023, respectively.

[0000926326-24-000032:mdna:37]
[same as prior period, unchanged from 0000926326-24-000027:mdna:37]

[0000926326-24-000032:mdna:38]
[same as prior period, unchanged from 0000926326-24-000027:mdna:38]

[0000926326-24-000032:mdna:39]
[same as prior period, unchanged from 0000926326-24-000027:mdna:39]

[0000926326-24-000032:mdna:40]
[same as prior period, unchanged from 0000926326-24-000027:mdna:40]

[0000926326-24-000032:mdna:41]
[same as prior period, unchanged from 0000926326-24-000027:mdna:41]

[0000926326-24-000032:mdna:42]
[same as prior period, unchanged from 0000926326-24-000027:mdna:42]

[0000926326-24-000032:mdna:43]
[same as prior period, unchanged from 0000926326-24-000027:mdna:43]

[0000926326-24-000032:mdna:44]
•Central Pharmacy and IV Compounding.  This market represents the beginning of the medication management process in acute care settings, and we believe it is a significant automation opportunity for high volumes of manual, repetitive, and error-prone processes that are often common in pharmacies today. Manual medication dispensing processes are usually labor intensive, error-prone, and may lead to excess medication waste and expirations for our healthcare partners. Automating the central pharmacy dispensing process should enable customers to reallocate pharmacy labor, enhance dispensing accuracy and patient safety, and reduce medication waste and expirations. Likewise, the manual compounding of sterile IV preparations can be error-prone and create significant patient safety risks, and outsourcing sterile IV compounding could lead to increased medication costs and lack of access to needed medications as a result of being unable to source medications when they are required. As a result, we believe IV automation provides a significant opportunity to enhance patient safety and reduce costs. We anticipate that these technology-enabled services will become more critical as health systems continue to face labor shortages, increased financial pressure, and supply chain disruptions. As health systems expand and grow, we find that traditional methods of medication management may lead to multi-vendor environments that may complicate workflows, often creating unnecessary redundancy and increasing chances for potential errors. We believe health systems need a single source for technology and resources that is designed to execute and optimize centralized medication management strategies to better meet current and future health system needs.

[0000926326-24-000032:mdna:45]
[same as prior period, unchanged from 0000926326-24-000027:mdna:45]

[0000926326-24-000032:mdna:46]
31

[0000926326-24-000032:mdna:47]
•Retail, Institutional, and Payer.  We believe the Retail, Institutional, and Payer market represents a significant opportunity as healthcare evolves. Retail drug prescriptions represent 85% of all prescription drugs dispensed in the U.S., growing at a rate of 2.7% annually through 2024. Additionally, the COVID-19 pandemic accelerated the shift of outpatient care from hospitals and physician offices to other, more convenient settings, such as retail pharmacies and the home (including through telehealth technologies). New technologies and increased scope of practice for pharmacists appear to be spurring innovation and expansion of the provision of clinical services by retail pharmacies, which, combined with the move to value-based care, we believe will drive the adoption of our patient engagement solutions, that are intended to help providers (including pharmacists) and payers engage patients in new ways that are expected to improve outcomes, reduce the total cost of care, and lead to more profitable operations. Because of the complexity of relationships between payers and providers, as well as the large number of retail pharmacies, including a significant number of independent pharmacies, we believe a network of established relationships between payers, providers and pharmacies will continue to be important.

[0000926326-24-000032:mdna:48]
[same as prior period, unchanged from 0000926326-24-000027:mdna:48]

[0000926326-24-000032:mdna:49]
[same as prior period, unchanged from 0000926326-24-000027:mdna:49]

[0000926326-24-000032:mdna:50]
[same as prior period, unchanged from 0000926326-24-000027:mdna:50]

[0000926326-24-000032:mdna:51]
[same as prior period, unchanged from 0000926326-24-000027:mdna:51]

[0000926326-24-000032:mdna:52]
[same as prior period, unchanged from 0000926326-24-000027:mdna:52]

[0000926326-24-000032:mdna:53]
[same as prior period, unchanged from 0000926326-24-000027:mdna:53]

[0000926326-24-000032:mdna:54]
[same as prior period, unchanged from 0000926326-24-000027:mdna:54]

[0000926326-24-000032:mdna:55]
[same as prior period, unchanged from 0000926326-24-000027:mdna:55]

[0000926326-24-000032:mdna:56]
[same as prior period, unchanged from 0000926326-24-000027:mdna:56]

[0000926326-24-000032:mdna:57]
[same as prior period, unchanged from 0000926326-24-000027:mdna:57]

[0000926326-24-000032:mdna:58]
[same as prior period, unchanged from 0000926326-24-000027:mdna:58]

[0000926326-24-000032:mdna:59]
[same as prior period, unchanged from 0000926326-24-000027:mdna:59]

[0000926326-24-000032:mdna:60]
[same as prior period, unchanged from 0000926326-24-000027:mdna:60]

[0000926326-24-000032:mdna:61]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the nine months ended September 30, 2024 as compared to those disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in our Annual Report on Form 10-K for the year ended December 31, 2023.

[0000926326-24-000032:mdna:62]
[same as prior period, unchanged from 0000926326-24-000027:mdna:62]

[0000926326-24-000032:mdna:63]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-24-000032:mdna:64]
[same as prior period, unchanged from 0000926326-24-000027:mdna:64]

[0000926326-24-000032:mdna:65]
[same as prior period, unchanged from 0000926326-24-000027:mdna:65]

[0000926326-24-000032:mdna:66]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 158,361 |  |  | $ | 188,755 |  |  | $ | (30,394) |  |  | (16)% |
| Percentage of total revenues | 56% |  | 63% |  |  |  |  |
| Service revenues | 124,059 |  |  | 109,908 |  |  | $ | 14,151 |  |  | 13% |
| Percentage of total revenues | 44% |  | 37% |  |  |  |  |
| Total revenues | $ | 282,420 |  |  | $ | 298,663 |  |  | $ | (16,243) |  |  | (5)% |

[0000926326-24-000032:mdna:67]
Product revenues represented 56% and 63% of total revenues for the three months ended September 30, 2024 and 2023, respectively. Product revenues decreased by $30.4 million, primarily due to lower volumes from our automated dispensing systems business primarily as a result of the impact of a continued challenging environment for some of our health system customers and the timing of our XT Series systems lifecycle, as we are largely through the replacement cycle.

[0000926326-24-000032:mdna:68]
Service revenues represented 44% and 37% of total revenues for the three months ended September 30, 2024 and 2023, respectively. Service revenues include revenues from technical services and Advanced Services offerings. Service revenues increased by $14.2 million, primarily due to an increase of $2.3 million in technical services revenues as a result of growth in our installed customer base and the impact of pricing actions, as well as an increase of $11.9 million in Advanced Services revenues due to continued customer demand.

[0000926326-24-000032:mdna:69]
Our international sales represented 9% of total revenues for both the three months ended September 30, 2024 and 2023 and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-24-000032:mdna:70]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 448,236 |  |  | $ | 562,906 |  |  | $ | (114,670) |  |  | (20)% |
| Percentage of total revenues | 56% |  | 63% |  |  |  |  |
| Service revenues | 357,123 |  |  | 325,359 |  |  | 31,764 |  |  | 10% |
| Percentage of total revenues | 44% |  | 37% |  |  |  |  |
| Total revenues | $ | 805,359 |  |  | $ | 888,265 |  |  | $ | (82,906) |  |  | (9)% |

[0000926326-24-000032:mdna:71]
Product revenues represented 56% and 63% of total revenues for the nine months ended September 30, 2024 and 2023, respectively. Product revenues decreased by $114.7 million, due to lower volumes from our automated dispensing systems business primarily as a result of the impact of a continued challenging environment for some of our health system customers and the timing of our XT Series systems lifecycle, as we are largely through the replacement cycle.

[0000926326-24-000032:mdna:72]
Service revenues represented 44% and 37% of total revenues for the nine months ended September 30, 2024 and 2023, respectively. Service revenues include revenues from technical services and Advanced Services offerings. Service revenues increased by $31.8 million, primarily due to an increase of $9.6 million in technical services revenues as a result of growth in our installed customer base and the impact of pricing actions, as well as an increase of $22.2 million in Advanced Services revenues due to continued customer demand.

[0000926326-24-000032:mdna:73]
Our international sales represented 9% and 12% of total revenues for the nine months ended September 30, 2024 and 2023, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-24-000032:mdna:74]
[same as prior period, unchanged from 0000926326-24-000027:mdna:74]

[0000926326-24-000032:mdna:75]
[same as prior period, unchanged from 0000926326-24-000027:mdna:75]

[0000926326-24-000032:mdna:76]
[same as prior period, unchanged from 0000926326-24-000027:mdna:76]

[0000926326-24-000032:mdna:77]
[same as prior period, unchanged from 0000926326-24-000027:mdna:77]

[0000926326-24-000032:mdna:78]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 94,448 |  |  | $ | 106,311 |  |  | $ | (11,863) |  |  | (11)% |
| As a percentage of related revenues | 60% |  | 56% |  |  |  |  |
| Cost of service revenues | 65,704 |  |  | 60,388 |  |  | $ | 5,316 |  |  | 9% |
| As a percentage of related revenues | 53% |  | 55% |  |  |  |  |
| Total cost of revenues | $ | 160,152 |  |  | $ | 166,699 |  |  | $ | (6,547) |  |  | (4)% |
| As a percentage of total revenues | 57% |  | 56% |  |  |  |  |
| Gross profit | $ | 122,268 |  |  | $ | 131,964 |  |  | $ | (9,696) |  |  | (7)% |
| Gross margin | 43% |  | 44% |  |  |  |  |

[0000926326-24-000032:mdna:79]
Cost of revenues for the three months ended September 30, 2024 compared to the three months ended September 30, 2023 decreased by $6.5 million, primarily driven by a $11.9 million decrease in cost of product revenues, partially offset by a $5.3 million increase in cost of service revenues.

[0000926326-24-000032:mdna:80]
The decrease in cost of product revenues was primarily driven by the decrease in product revenues of $30.4 million for the three months ended September 30, 2024 compared to the three months ended September 30, 2023. The decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues for the three months ended September 30, 2024, primarily due to the decrease in revenues of higher margin products as well as the impact of certain fixed costs, such as labor and overhead. In addition, the decrease in cost of product revenues was partially offset by an increase of $0.9 million of restructuring costs for the three months ended September 30, 2024 compared to the three months ended September 30, 2023. The increase in cost of service revenues was primarily driven by the increase in service revenues of $14.2 million for the three months ended September 30, 2024 compared to the three months ended September 30, 2023.

[0000926326-24-000032:mdna:81]
The overall decrease in gross margin primarily relates to lower product revenues for the three months ended September 30, 2024 compared to the three months ended September 30, 2023, whereas the decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues, primarily due to the decrease in revenues of higher margin products as well as the impact of certain fixed costs, such as labor and overhead. The decrease in cost of product revenues is partially offset by restructuring costs incurred during the three months ended September 30, 2024. Our gross profit for the three months ended September 30, 2024 was $122.3 million, as compared to $132.0 million for the three months ended September 30, 2023.

[0000926326-24-000032:mdna:82]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 286,270 |  |  | $ | 323,800 |  |  | $ | (37,530) |  |  | (12)% |
| As a percentage of related revenues | 64% |  | 58% |  |  |  |  |
| Cost of service revenues | 189,847 |  |  | 173,029 |  |  | $ | 16,818 |  |  | 10% |
| As a percentage of related revenues | 53% |  | 53% |  |  |  |  |
| Total cost of revenues | $ | 476,117 |  |  | $ | 496,829 |  |  | $ | (20,712) |  |  | (4)% |
| As a percentage of total revenues | 59% |  | 56% |  |  |  |  |
| Gross profit | $ | 329,242 |  |  | $ | 391,436 |  |  | $ | (62,194) |  |  | (16)% |
| Gross margin | 41% |  | 44% |  |  |  |  |

[0000926326-24-000032:mdna:83]
Cost of revenues for the nine months ended September 30, 2024 compared to the nine months ended September 30, 2023 decreased by $20.7 million, primarily driven by a $37.5 million decrease in cost of product revenues, partially offset by a $16.8 million increase in cost of service revenues.

[0000926326-24-000032:mdna:84]
The decrease in cost of product revenues was primarily driven by the decrease in product revenues of $114.7 million for the nine months ended September 30, 2024 compared to the nine months ended September 30, 2023. The decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues for the nine months ended September 30, 2024, primarily due to the decrease in revenues of higher margin products as well as the impact of certain fixed costs, such as labor and overhead. In addition, the decrease in cost of product revenues was partially offset by $5.4 million of inventory write-down charges related to the RDS product line wind down incurred during the nine months ended September 30, 2024 and an increase of $2.9 million of restructuring costs for the nine months ended September 30, 2024 compared to the nine months ended September 30, 2023. The increase in cost of service revenues was primarily driven by the increase in service revenues of $31.8 million for the nine months ended September 30, 2024 compared to the nine months ended September 30, 2023.

[0000926326-24-000032:mdna:85]
The overall decrease in gross margin primarily relates to lower product revenues for the nine months ended September 30, 2024 compared to the nine months ended September 30, 2023, whereas the decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues, primarily due to the decrease in revenues of higher margin products as well as the impact of certain fixed costs, such as labor and overhead. The decrease in cost of product revenues is partially offset by inventory write-down charges related to the RDS product line wind down and restructuring costs incurred during the nine months ended September 30, 2024. Our gross profit for the nine months ended September 30, 2024 was $329.2 million, as compared to $391.4 million for the nine months ended September 30, 2023.

[0000926326-24-000032:mdna:86]
[same as prior period, unchanged from 0000926326-24-000027:mdna:86]

[0000926326-24-000032:mdna:87]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 21,214 |  |  | $ | 24,281 |  |  | $ | (3,067) |  |  | (13)% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 94,490 |  |  | 103,971 |  |  | $ | (9,481) |  |  | (9)% |
| As a percentage of total revenues | 33% |  | 35% |  |  |  |  |
| Total operating expenses | $ | 115,704 |  |  | $ | 128,252 |  |  | $ | (12,548) |  |  | (10)% |
| As a percentage of total revenues | 41% |  | 43% |  |  |  |  |
| Interest and other income (expense), net | $ | 5,063 |  |  | $ | 3,670 |  |  | $ | 1,393 |  |  | 38% |

[0000926326-24-000032:mdna:88]
35

[0000926326-24-000032:mdna:89]
Research and Development. Research and development expenses decreased by $3.1 million for the three months ended September 30, 2024 compared to the three months ended September 30, 2023. The decrease was primarily attributed to a decrease in employee-related expenses as a result of lower headcount.

[0000926326-24-000032:mdna:90]
Selling, General, and Administrative. Selling, general, and administrative expenses decreased by $9.5 million for the three months ended September 30, 2024 compared to the three months ended September 30, 2023. The decrease was primarily due to a decrease of $6.6 million in employee-related expenses as a result of lower headcount and a decrease of $1.1 million in freight out for the three months ended September 30, 2024 compared to the three months ended September 30, 2023, as well as $1.3 million of executives transition costs incurred during the three months ended September 30, 2023.

[0000926326-24-000032:mdna:91]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $1.4 million for the three months ended September 30, 2024 compared to the three months ended September 30, 2023, primarily driven by a $1.5 million increase in other income and a $0.1 million increase in other expense. The increase in other income during the three months ended September 30, 2024 as compared to the three months ended September 30, 2023 is primarily attributable to higher interest income received due to higher cash and cash equivalents balances.

[0000926326-24-000032:mdna:92]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 64,372 |  |  | $ | 70,296 |  |  | $ | (5,924) |  |  | (8)% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 276,929 |  |  | 332,643 |  |  | $ | (55,714) |  |  | (17)% |
| As a percentage of total revenues | 34% |  | 37% |  |  |  |  |
| Total operating expenses | $ | 341,301 |  |  | $ | 402,939 |  |  | $ | (61,638) |  |  | (15)% |
| As a percentage of total revenues | 42% |  | 45% |  |  |  |  |
| Interest and other income (expense), net | $ | 14,052 |  |  | $ | 9,912 |  |  | $ | 4,140 |  |  | 42% |

[0000926326-24-000032:mdna:93]
Research and Development. Research and development expenses decreased by $5.9 million for the nine months ended September 30, 2024 compared to the nine months ended September 30, 2023. The decrease was primarily attributed to a decrease of $11.8 million in employee-related expenses as a result of lower headcount, partially offset by an increase of $2.1 million due to the timing of capitalized software projects, an increase of $1.6 million in cloud hosting services expenses, and an increase of $1.3 million in consulting expenses.

[0000926326-24-000032:mdna:94]
Selling, General, and Administrative. Selling, general, and administrative expenses decreased by $55.7 million for the nine months ended September 30, 2024 compared to the nine months ended September 30, 2023. The decrease was primarily due to a decrease of $28.9 million in employee-related expenses as a result of lower headcount, a decrease of $8.4 million in impairment and abandonment charges of operating lease right-of-use and other assets in connection with restructuring activities of certain leased facilities, a decrease of $4.7 million in restructuring costs, a decrease of $3.3 million in commissions expenses, a decrease of $2.6 million in freight out, and a decrease of $2.2 million in executives transition costs.

[0000926326-24-000032:mdna:95]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $4.1 million for the nine months ended September 30, 2024 compared to the nine months ended September 30, 2023, primarily driven by a $5.1 million increase in other income and a $1.0 million increase in other expense. The increase in other income during the nine months ended September 30, 2024 as compared to the nine months ended September 30, 2023 is primarily attributable to higher interest income received due to higher interest rates and higher cash and cash equivalents balances.

[0000926326-24-000032:mdna:96]
[same as prior period, unchanged from 0000926326-24-000027:mdna:96]

[0000926326-24-000032:mdna:97]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 2,997 |  |  | $ | 1,829 |  |  | $ | 1,168 |  |  | 64% |

[0000926326-24-000032:mdna:98]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2024 |  | 2023 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 5,304 |  |  | $ | 4,405 |  |  | $ | 899 |  |  | 20% |

[0000926326-24-000032:mdna:99]
For the nine months ended September 30, 2024 and 2023, we recorded a provision for income taxes of $5.3 million and $4.4 million, respectively, by applying our estimated annual effective tax rate to our year-to-date measure of ordinary income and adjusted for $4.9 million and $5.6 million, respectively, of discrete income tax expense primarily from equity compensation. The change in the provision for income taxes for the nine months ended September 30, 2024 compared to the provision for income taxes for the same period in 2023 was insignificant, consisting of various offsetting components of annual effective tax rate and discrete income tax expense.

[0000926326-24-000032:mdna:100]
[same as prior period, unchanged from 0000926326-24-000027:mdna:100]

[0000926326-24-000032:mdna:101]
[same as prior period, unchanged from 0000926326-24-000027:mdna:101]

[0000926326-24-000032:mdna:102]
We had cash and cash equivalents of $570.6 million at September 30, 2024 compared to $468.0 million at December 31, 2023. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with financial institutions of high credit quality.

[0000926326-24-000032:mdna:103]
Our cash position and working capital at September 30, 2024 and December 31, 2023 were as follows:

[0000926326-24-000032:mdna:104]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 570,628 |  |  | $ | 467,972 |  |
| Working capital (1) | $ | 49,745 |  |  | $ | 559,779 |  |

[0000926326-24-000032:mdna:105]
[same as prior period, unchanged from 0000926326-24-000027:mdna:133]

[0000926326-24-000032:mdna:106]
(1)    The decrease in working capital as of September 30, 2024 was primarily due to the classification of our convertible senior notes as a current rather than long-term liability. Refer to Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-24-000032:mdna:107]
Our ratio of current assets to current liabilities was 1.1:1 and 2.5:1 at September 30, 2024 and December 31, 2023, respectively.

[0000926326-24-000032:mdna:108]
[same as prior period, unchanged from 0000926326-24-000027:mdna:106]

[0000926326-24-000032:mdna:109]
Revolving Credit Facility

[0000926326-24-000032:mdna:110]
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023 to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements

[0000926326-24-000032:mdna:111]
included in this Quarterly Report on Form 10-Q), expand our flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-24-000032:mdna:112]
On October 10, 2023, Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-24-000032:mdna:113]
As of September 30, 2024, we had $350.0 million of funds available under the Current Revolving Credit Facility. As of September 30, 2024, there was no outstanding balance under the Current Revolving Credit Facility and we were in full compliance with all covenants. Refer to Note 9, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-24-000032:mdna:114]
[same as prior period, unchanged from 0000926326-24-000027:mdna:112]

[0000926326-24-000032:mdna:115]
[same as prior period, unchanged from 0000926326-24-000027:mdna:113]

[0000926326-24-000032:mdna:116]
The 2016 Repurchase Program has a total of $2.7 million remaining for future repurchases as of September 30, 2024, which may result in additional use of cash. There were no stock repurchases during the nine months ended September 30, 2024. Refer to “Stock Repurchase Programs” under Note 15, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-24-000032:mdna:117]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, outstanding debt, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the growth of our business.

[0000926326-24-000032:mdna:118]
[same as prior period, unchanged from 0000926326-24-000027:mdna:116]

[0000926326-24-000032:mdna:119]
[same as prior period, unchanged from 0000926326-24-000027:mdna:117]

[0000926326-24-000032:mdna:120]
|  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 131,407 |  |  | $ | 142,680 |  |
| Investing activities | (39,225) |  |  | (42,644) |  |
| Financing activities | (1,148) |  |  | 10,290 |  |
| Effect of exchange rate changes on cash and cash equivalents | 879 |  |  | (464) |  |
| Net increase in cash, cash equivalents, and restricted cash | $ | 91,913 |  |  | $ | 109,862 |  |

[0000926326-24-000032:mdna:121]
[same as prior period, unchanged from 0000926326-24-000027:mdna:119]

[0000926326-24-000032:mdna:122]
[same as prior period, unchanged from 0000926326-24-000027:mdna:120]

[0000926326-24-000032:mdna:123]
Net cash provided by operating activities was $131.4 million for the nine months ended September 30, 2024, primarily consisting of operating inflows of $93.8 million and favorable working capital movements of $37.6 million. Operating inflows consisted of a net loss of $3.3 million, adjusted for non-cash items of $97.1 million, which consisted primarily of depreciation and amortization expense of $62.3 million, share-based compensation expense of $30.3 million, inventory write-down charges of $5.4 million, amortization of operating lease right-of-use assets of $5.3 million, and a change in deferred income taxes of $9.4 million. The favorable working capital was primarily due to an increase in deferred revenues of $27.7 million driven by an increase in billings, a decrease in inventories of $10.0 million resulting from inventory management initiatives, a decrease of $8.4 million in other current assets due to a decrease in income tax receivables, and an increase of $7.0 million in accrued liabilities due to an increase in rebate liabilities. These cash inflows were partially offset by a decrease of $8.0 million in operating lease liabilities, an increase of $7.5 million in investment in sales-type leases resulting from growth in our Advanced Services offerings, and a decrease in accrued compensation of $6.7 million.

[0000926326-24-000032:mdna:124]
Net cash provided by operating activities was $142.7 million for the nine months ended September 30, 2023, primarily consisting of operating inflows of $107.8 million and favorable working capital movements of $34.9 million. Operating inflows consisted of a net loss of $6.0 million, adjusted for non-cash items of $113.8 million, which consisted primarily of depreciation and amortization expense of $65.6 million, share-based compensation expense of $43.1 million, impairment and abandonment of operating lease right-of-use assets related to facilities of $7.8 million, amortization of operating lease right-of-use assets of $6.2 million, and a change in deferred income taxes of $14.2 million. The favorable working capital was primarily due to a decrease in inventories of $31.7 million primarily due to management of inventory levels to align with the current forecasted demand, a decrease in accounts receivable and unbilled receivables of $27.1 million primarily due to the timing of billings, shipments, and collections, as well as the impacts of lower revenues, an increase in deferred revenues of $23.6 million primarily due to an increase in billings for certain service and subscription offerings, and a decrease in prepaid commissions of $5.5 million. These cash inflows were partially offset by a decrease in accrued compensation of $29.4 million primarily due to a decrease in the accrual for restructuring initiatives, lower commissions, as well as timing of payroll and ESPP purchases, a decrease in accounts payable of $13.4 million primarily due to an overall decrease in spending, as well as the timing of payments, an increase in investment in sales-type leases of $8.8 million primarily due to the acceptance of certain Advanced Services products under sales-type lease arrangements, and a decrease in operating lease liabilities of $8.1 million.

[0000926326-24-000032:mdna:125]
[same as prior period, unchanged from 0000926326-24-000027:mdna:123]

[0000926326-24-000032:mdna:126]
Net cash used in investing activities was $39.2 million for the nine months ended September 30, 2024, which consisted of capital expenditures of $27.4 million for property and equipment and $11.8 million for external-use software development costs.

[0000926326-24-000032:mdna:127]
Net cash used in investing activities was $42.6 million for the nine months ended September 30, 2023, which consisted of capital expenditures of $32.4 million for property and equipment, and $10.2 million for external-use software development costs.

[0000926326-24-000032:mdna:128]
[same as prior period, unchanged from 0000926326-24-000027:mdna:126]

[0000926326-24-000032:mdna:129]
Net cash used in financing activities was $1.1 million for the nine months ended September 30, 2024, primarily due to a net change in the customer funds balances of $10.7 million, partially offset by $13.1 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-24-000032:mdna:130]
Net cash provided by financing activities was $10.3 million for the nine months ended September 30, 2023, primarily due to $23.0 million in proceeds from employee stock option exercises and ESPP purchases, partially offset by $6.1 million in employees’ taxes paid related to restricted stock unit vesting and a net change in the customer funds balances of $6.6 million.

[0000926326-24-000032:mdna:131]
[same as prior period, unchanged from 0000926326-24-000027:mdna:129]

[0000926326-24-000032:mdna:132]
There have been no significant changes during the nine months ended September 30, 2024 to the contractual obligations disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2023.

[0000926326-24-000032:mdna:133]
Contractual obligations as of September 30, 2024 were as follows:

[0000926326-24-000032:mdna:134]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2024 |  | 2025 - 2026 |  | 2027 - 2028 |  | 2029 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 47,310 |  |  | $ | 3,296 |  |  | $ | 23,993 |  |  | $ | 17,750 |  |  | $ | 2,271 |  |
| Purchase obligations (2) | $ | 111,167 |  |  | 71,423 |  |  | 39,666 |  |  | 78 |  |  | — |  |
| Convertible senior notes (3) | $ | 576,438 |  |  | — |  |  | 576,438 |  |  | — |  |  | — |  |
| Total (4) | $ | 734,915 |  |  | $ | 74,719 |  |  | $ | 640,097 |  |  | $ | 17,828 |  |  | $ | 2,271 |  |

[0000926326-24-000032:mdna:135]
_________________________________________________

[0000926326-24-000032:mdna:136]
[same as prior period, unchanged from 0000926326-24-000027:mdna:134]

[0000926326-24-000032:mdna:137]
[same as prior period, unchanged from 0000926326-24-000027:mdna:135]

[0000926326-24-000032:mdna:138]
[same as prior period, unchanged from 0000926326-24-000027:mdna:136]

[0000926326-24-000032:mdna:139]
(4)Refer to Note 13, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.
