# OMCL notes — 0001445305-12-002594


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001445305-12-002594:notes:1]
[same as prior period, unchanged from 0001445305-12-001573:notes:1]

[0001445305-12-002594:notes:2]
[same as prior period, unchanged from 0001445305-12-001573:notes:2]

[0001445305-12-002594:notes:3]
[same as prior period, unchanged from 0001445305-12-001573:notes:3]

[0001445305-12-002594:notes:4]
[same as prior period, unchanged from 0001445305-12-001573:notes:4]

[0001445305-12-002594:notes:5]
[same as prior period, unchanged from 0001445305-12-001573:notes:5]

[0001445305-12-002594:notes:6]
[same as prior period, unchanged from 0001445305-12-001573:notes:6]

[0001445305-12-002594:notes:7]
[same as prior period, unchanged from 0001445305-12-001573:notes:7]

[0001445305-12-002594:notes:8]
[same as prior period, unchanged from 0001445305-12-001573:notes:8]

[0001445305-12-002594:notes:9]
[same as prior period, unchanged from 0001445305-12-001573:notes:9]

[0001445305-12-002594:notes:10]
[same as prior period, unchanged from 0001445305-12-001573:notes:10]


## us-gaap:CommitmentsDisclosureTextBlock

[0001445305-12-002594:notes:11]
[same as prior period, unchanged from 0001445305-12-001573:notes:11]

[0001445305-12-002594:notes:12]
[same as prior period, unchanged from 0001445305-12-001573:notes:12]

[0001445305-12-002594:notes:13]
[same as prior period, unchanged from 0001445305-12-001573:notes:13]

[0001445305-12-002594:notes:14]
[same as prior period, unchanged from 0001445305-12-001573:notes:14]

[0001445305-12-002594:notes:15]
[same as prior period, unchanged from 0001445305-12-001573:notes:15]

[0001445305-12-002594:notes:16]
[same as prior period, unchanged from 0001445305-12-001573:notes:16]

[0001445305-12-002594:notes:17]
[same as prior period, unchanged from 0001445305-12-001573:notes:17]

[0001445305-12-002594:notes:18]
[same as prior period, unchanged from 0001445305-12-001573:notes:18]

[0001445305-12-002594:notes:19]
Also excluded from the above table of commitments is the $156.0 million purchase price, subject to certain adjustments, in connection with the pending acquisition of MTS Medication Technologies, Inc., as described in Note 14 “Subsequent Events” in this report.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001445305-12-002594:notes:20]
[same as prior period, unchanged from 0001445305-12-001573:notes:20]

[0001445305-12-002594:notes:21]
[same as prior period, unchanged from 0001445305-12-001573:notes:21]

[0001445305-12-002594:notes:22]
[same as prior period, unchanged from 0001445305-12-001573:notes:22]

[0001445305-12-002594:notes:23]
[same as prior period, unchanged from 0001445305-12-001573:notes:23]

[0001445305-12-002594:notes:24]
[same as prior period, unchanged from 0001445305-12-001573:notes:24]

[0001445305-12-002594:notes:25]
[same as prior period, unchanged from 0001445305-12-001573:notes:25]

[0001445305-12-002594:notes:26]
[same as prior period, unchanged from 0001445305-12-001573:notes:26]

[0001445305-12-002594:notes:27]
[same as prior period, unchanged from 0001445305-12-001573:notes:27]

[0001445305-12-002594:notes:28]
[same as prior period, unchanged from 0001445305-12-001573:notes:28]

[0001445305-12-002594:notes:29]
[same as prior period, unchanged from 0001445305-12-001573:notes:29]

[0001445305-12-002594:notes:30]
[same as prior period, unchanged from 0001445305-12-001573:notes:30]

[0001445305-12-002594:notes:31]
[same as prior period, unchanged from 0001445305-12-001573:notes:31]

[0001445305-12-002594:notes:32]
[same as prior period, unchanged from 0001445305-12-001573:notes:32]

[0001445305-12-002594:notes:33]
[same as prior period, unchanged from 0001445305-12-001573:notes:33]

[0001445305-12-002594:notes:34]
[same as prior period, unchanged from 0001445305-12-001573:notes:34]

[0001445305-12-002594:notes:35]
[same as prior period, unchanged from 0001445305-12-001573:notes:35]

[0001445305-12-002594:notes:36]
[same as prior period, unchanged from 0001445305-12-001573:notes:36]

[0001445305-12-002594:notes:37]
[same as prior period, unchanged from 0001445305-12-001573:notes:37]

[0001445305-12-002594:notes:38]
[same as prior period, unchanged from 0001445305-12-001573:notes:38]

[0001445305-12-002594:notes:39]
[same as prior period, unchanged from 0001445305-12-001573:notes:39]

[0001445305-12-002594:notes:40]
[same as prior period, unchanged from 0001445305-12-001573:notes:40]

[0001445305-12-002594:notes:41]
[same as prior period, unchanged from 0001445305-12-001573:notes:41]

[0001445305-12-002594:notes:42]
[same as prior period, unchanged from 0001445305-12-001573:notes:42]

[0001445305-12-002594:notes:43]
[same as prior period, unchanged from 0001445305-12-001573:notes:43]

[0001445305-12-002594:notes:44]
[same as prior period, unchanged from 0001445305-12-001573:notes:44]

[0001445305-12-002594:notes:45]
[same as prior period, unchanged from 0001445305-12-001573:notes:45]

[0001445305-12-002594:notes:46]
[same as prior period, unchanged from 0001445305-12-001573:notes:46]

[0001445305-12-002594:notes:47]
[same as prior period, unchanged from 0001445305-12-001573:notes:47]

[0001445305-12-002594:notes:48]
[same as prior period, unchanged from 0001445305-12-001573:notes:48]


## us-gaap:EarningsPerShareTextBlock

[0001445305-12-002594:notes:49]
[same as prior period, unchanged from 0001445305-12-001573:notes:49]

[0001445305-12-002594:notes:50]
[same as prior period, unchanged from 0001445305-12-001573:notes:50]

[0001445305-12-002594:notes:51]
[same as prior period, unchanged from 0001445305-12-001573:notes:51]

[0001445305-12-002594:notes:52]
[same as prior period, unchanged from 0001445305-12-001573:notes:52]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001445305-12-002594:notes:53]
[same as prior period, unchanged from 0001445305-12-001573:notes:53]

[0001445305-12-002594:notes:54]
[same as prior period, unchanged from 0001445305-12-001573:notes:54]

[0001445305-12-002594:notes:55]
[same as prior period, unchanged from 0001445305-12-001573:notes:55]

[0001445305-12-002594:notes:56]
[same as prior period, unchanged from 0001445305-12-001573:notes:56]

[0001445305-12-002594:notes:57]
[same as prior period, unchanged from 0001445305-12-001573:notes:57]

[0001445305-12-002594:notes:58]
[same as prior period, unchanged from 0001445305-12-001573:notes:58]


## us-gaap:InventoryDisclosureTextBlock

[0001445305-12-002594:notes:59]
[same as prior period, unchanged from 0001445305-12-001573:notes:59]

[0001445305-12-002594:notes:60]
[same as prior period, unchanged from 0001445305-12-001573:notes:60]

[0001445305-12-002594:notes:61]
[same as prior period, unchanged from 0001445305-12-001573:notes:61]


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001445305-12-002594:notes:62]
Contingencies

[0001445305-12-002594:notes:63]
Legal Proceedings

[0001445305-12-002594:notes:64]
We may from time to time become involved in certain legal proceedings in the ordinary course of business. We are not a party to any legal proceedings that management believes may have a material impact on Omnicell's financial position or results of operations.

[0001445305-12-002594:notes:65]
Guarantees

[0001445305-12-002594:notes:66]
As permitted under Delaware law and our certificate of incorporation and bylaws, we have agreed to indemnify our directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become our directors or officers. The term of the indemnification period is for the director's or officer's lifetime and there is no limit on the potential amount of future payments that we could be required to make under these indemnification agreements. We have purchased a directors' and officers' liability insurance policy that may enable us to recover a portion of any future payments that we may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0001445305-12-002594:notes:67]
Additionally, we undertake indemnification obligations in our ordinary course of business in connection with, among other things, the licensing of our products and the provision of our support services. In the ordinary course of our business, we have in the past and may in the future agree to indemnify another party, generally our business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, our gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, we attempt to limit the maximum potential amount of future payments that we may be required to make under these indemnification obligations to the amounts paid to us by a customer, but in some cases the obligation may not be so limited. In addition, we have in the past and may in the future warrant to our customers that our products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that our software media is free from material defects.

[0001445305-12-002594:notes:68]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no liabilities have been recorded for such indemnification obligations as of March 31, 2012 or December 31, 2011.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001445305-12-002594:notes:69]
[same as prior period, unchanged from 0001445305-12-001573:notes:69]

[0001445305-12-002594:notes:70]
[same as prior period, unchanged from 0001445305-12-001573:notes:70]

[0001445305-12-002594:notes:71]
[same as prior period, unchanged from 0001445305-12-001573:notes:71]

[0001445305-12-002594:notes:72]
[same as prior period, unchanged from 0001445305-12-001573:notes:72]

[0001445305-12-002594:notes:73]
[same as prior period, unchanged from 0001445305-12-001573:notes:73]

[0001445305-12-002594:notes:74]
[same as prior period, unchanged from 0001445305-12-001573:notes:74]

[0001445305-12-002594:notes:75]
[same as prior period, unchanged from 0001445305-12-001573:notes:75]

[0001445305-12-002594:notes:76]
[same as prior period, unchanged from 0001445305-12-001573:notes:76]

[0001445305-12-002594:notes:77]
[same as prior period, unchanged from 0001445305-12-001573:notes:77]

[0001445305-12-002594:notes:78]
[same as prior period, unchanged from 0001445305-12-001573:notes:78]

[0001445305-12-002594:notes:79]
[same as prior period, unchanged from 0001445305-12-001573:notes:79]

[0001445305-12-002594:notes:80]
[same as prior period, unchanged from 0001445305-12-001573:notes:80]

[0001445305-12-002594:notes:81]
[same as prior period, unchanged from 0001445305-12-001573:notes:81]

[0001445305-12-002594:notes:82]
[same as prior period, unchanged from 0001445305-12-001573:notes:82]

[0001445305-12-002594:notes:83]
[same as prior period, unchanged from 0001445305-12-001573:notes:83]

[0001445305-12-002594:notes:84]
[same as prior period, unchanged from 0001445305-12-001573:notes:84]

[0001445305-12-002594:notes:85]
[same as prior period, unchanged from 0001445305-12-001573:notes:85]

[0001445305-12-002594:notes:86]
[same as prior period, unchanged from 0001445305-12-001573:notes:86]

[0001445305-12-002594:notes:87]
[same as prior period, unchanged from 0001445305-12-001573:notes:87]

[0001445305-12-002594:notes:88]
[same as prior period, unchanged from 0001445305-12-001573:notes:88]

[0001445305-12-002594:notes:89]
[same as prior period, unchanged from 0001445305-12-001573:notes:89]

[0001445305-12-002594:notes:90]
[same as prior period, unchanged from 0001445305-12-001573:notes:90]

[0001445305-12-002594:notes:91]
[same as prior period, unchanged from 0001445305-12-001573:notes:91]

[0001445305-12-002594:notes:92]
[same as prior period, unchanged from 0001445305-12-001573:notes:92]

[0001445305-12-002594:notes:93]
[same as prior period, unchanged from 0001445305-12-001573:notes:93]

[0001445305-12-002594:notes:94]
[same as prior period, unchanged from 0001445305-12-001573:notes:94]

[0001445305-12-002594:notes:95]
[same as prior period, unchanged from 0001445305-12-001573:notes:95]

[0001445305-12-002594:notes:96]
[same as prior period, unchanged from 0001445305-12-001573:notes:96]

[0001445305-12-002594:notes:97]
[same as prior period, unchanged from 0001445305-12-001573:notes:97]

[0001445305-12-002594:notes:98]
[same as prior period, unchanged from 0001445305-12-001573:notes:98]

[0001445305-12-002594:notes:99]
[same as prior period, unchanged from 0001445305-12-001573:notes:99]

[0001445305-12-002594:notes:100]
[same as prior period, unchanged from 0001445305-12-001573:notes:100]

[0001445305-12-002594:notes:101]
[same as prior period, unchanged from 0001445305-12-001573:notes:101]

[0001445305-12-002594:notes:102]
[same as prior period, unchanged from 0001445305-12-001573:notes:102]

[0001445305-12-002594:notes:103]
[same as prior period, unchanged from 0001445305-12-001573:notes:103]

[0001445305-12-002594:notes:104]
[same as prior period, unchanged from 0001445305-12-001573:notes:104]

[0001445305-12-002594:notes:105]
[same as prior period, unchanged from 0001445305-12-001573:notes:105]

[0001445305-12-002594:notes:106]
[same as prior period, unchanged from 0001445305-12-001573:notes:106]

[0001445305-12-002594:notes:107]
[same as prior period, unchanged from 0001445305-12-001573:notes:107]

[0001445305-12-002594:notes:108]
[same as prior period, unchanged from 0001445305-12-001573:notes:108]

[0001445305-12-002594:notes:109]
[same as prior period, unchanged from 0001445305-12-001573:notes:109]

[0001445305-12-002594:notes:110]
Recently Adopted Accounting Pronouncements. In May 2011, the Financial Accounting Standards Board ("FASB") issued ASU 2011-04, Fair Value Measurement, amending the fair value guidance in ASC 820, and thereby achieving substantially converged fair value measurement and disclosure requirements for GAAP and International Financial Reporting Standards ("IFRS"). The new guidance clarified some fair value measurement principles and expanded certain disclosure requirements. We adopted this guidance in the first quarter of 2012 without any impact to our financial position, operating results or cash flows.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001445305-12-002594:notes:111]
[same as prior period, unchanged from 0001445305-12-001573:notes:111]

[0001445305-12-002594:notes:112]
[same as prior period, unchanged from 0001445305-12-001573:notes:112]

[0001445305-12-002594:notes:113]
[same as prior period, unchanged from 0001445305-12-001573:notes:113]

[0001445305-12-002594:notes:114]
[same as prior period, unchanged from 0001445305-12-001573:notes:114]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001445305-12-002594:notes:115]
[same as prior period, unchanged from 0001445305-12-001573:notes:115]

[0001445305-12-002594:notes:116]
[same as prior period, unchanged from 0001445305-12-001573:notes:116]

[0001445305-12-002594:notes:117]
[same as prior period, unchanged from 0001445305-12-001573:notes:117]

[0001445305-12-002594:notes:118]
[same as prior period, unchanged from 0001445305-12-001573:notes:118]

[0001445305-12-002594:notes:119]
[same as prior period, unchanged from 0001445305-12-001573:notes:119]


## us-gaap:SubsequentEventsTextBlock

[0001445305-12-002594:notes:120]
Subsequent Events

[0001445305-12-002594:notes:121]
Treasury Stock Repurchase

[0001445305-12-002594:notes:122]
During the month of April 2012, we repurchased 244,687 shares at an average cost of $14.00 per share, including commissions, under our stock repurchase program. As a result, $8.9 million is the remaining balance authorized for future repurchases as of April 30, 2012.

[0001445305-12-002594:notes:123]
Pending Business Acquisition

[0001445305-12-002594:notes:124]
On April 26, 2012, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with MedPak Holdings, Inc. (“MedPak”), Mercury Acquisition Corp, and Excellere Capital Management, LLC contemplating the acquisition of MedPak by Omnicell in exchange for $156.0 million cash, subject to certain adjustments and including $13.3 million in cash that would be placed in an escrow fund at the closing of the transaction. This escrow amount would ultimately be distributed to MedPak's stockholders (subject to claims that Omnicell may make against the escrow fund for indemnification and other claims following the closing). MedPak is the privately-held parent company of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems. The Merger Agreement provides for the merger of Mercury Acquisition Corp, a newly formed Omnicell subsidiary, with and into MedPak, with MedPak surviving the merger as a wholly-owned subsidiary of Omnicell.  The closing of the acquisition is subject to customary closing conditions, including the expiration of the applicable Hart-Scott-Rodino Act waiting period.

[0001445305-12-002594:notes:125]
Other than the impact of the pending $156.0 million cash reduction, no estimates of the financial effect of the acquisition can be made at this time.


## omcl:AccruedLiabilitiesTextBlock

[0001445305-12-002594:notes:126]
[same as prior period, unchanged from 0001445305-12-001573:notes:126]

[0001445305-12-002594:notes:127]
[same as prior period, unchanged from 0001445305-12-001573:notes:127]

[0001445305-12-002594:notes:128]
[same as prior period, unchanged from 0001445305-12-001573:notes:128]


## omcl:DeferredGrossProfitTextBlock

[0001445305-12-002594:notes:129]
[same as prior period, unchanged from 0001445305-12-001573:notes:129]

[0001445305-12-002594:notes:130]
[same as prior period, unchanged from 0001445305-12-001573:notes:130]

[0001445305-12-002594:notes:131]
[same as prior period, unchanged from 0001445305-12-001573:notes:131]


## omcl:NetInvestmentsInSalesTypeLeasesTextBlock

[0001445305-12-002594:notes:132]
[same as prior period, unchanged from 0001445305-12-001573:notes:132]

[0001445305-12-002594:notes:133]
[same as prior period, unchanged from 0001445305-12-001573:notes:133]

[0001445305-12-002594:notes:134]
[same as prior period, unchanged from 0001445305-12-001573:notes:134]

[0001445305-12-002594:notes:135]
[same as prior period, unchanged from 0001445305-12-001573:notes:135]

[0001445305-12-002594:notes:136]
[same as prior period, unchanged from 0001445305-12-001573:notes:136]

[0001445305-12-002594:notes:137]
[same as prior period, unchanged from 0001445305-12-001573:notes:137]

[0001445305-12-002594:notes:138]
[same as prior period, unchanged from 0001445305-12-001573:notes:138]

[0001445305-12-002594:notes:139]
[same as prior period, unchanged from 0001445305-12-001573:notes:139]

[0001445305-12-002594:notes:140]
[same as prior period, unchanged from 0001445305-12-001573:notes:140]

[0001445305-12-002594:notes:141]
[same as prior period, unchanged from 0001445305-12-001573:notes:141]

[0001445305-12-002594:notes:142]
[same as prior period, unchanged from 0001445305-12-001573:notes:142]
