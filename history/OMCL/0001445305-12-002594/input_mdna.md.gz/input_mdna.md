# OMCL MD&A — 0001445305-12-002594


## mdna

[0001445305-12-002594:mdna:1]
[same as prior period, unchanged from 0001445305-12-001573:mdna:1]

[0001445305-12-002594:mdna:2]
[same as prior period, unchanged from 0001445305-12-001573:mdna:2]

[0001445305-12-002594:mdna:3]
[same as prior period, unchanged from 0001445305-12-001573:mdna:3]

[0001445305-12-002594:mdna:4]
[same as prior period, unchanged from 0001445305-12-001573:mdna:4]

[0001445305-12-002594:mdna:5]
| • | our ability to conduct acquisitions for strategic value, including our acquisition of MTS, and successfully integrate each one into our operations; |

[0001445305-12-002594:mdna:6]
[same as prior period, unchanged from 0001445305-12-001573:mdna:6]

[0001445305-12-002594:mdna:7]
[same as prior period, unchanged from 0001445305-12-001573:mdna:7]

[0001445305-12-002594:mdna:8]
[same as prior period, unchanged from 0001445305-12-001573:mdna:8]

[0001445305-12-002594:mdna:9]
[same as prior period, unchanged from 0001445305-12-001573:mdna:9]

[0001445305-12-002594:mdna:10]
[same as prior period, unchanged from 0001445305-12-001573:mdna:10]

[0001445305-12-002594:mdna:11]
[same as prior period, unchanged from 0001445305-12-001573:mdna:11]

[0001445305-12-002594:mdna:12]
[same as prior period, unchanged from 0001445305-12-001573:mdna:12]

[0001445305-12-002594:mdna:13]
[same as prior period, unchanged from 0001445305-12-001573:mdna:13]

[0001445305-12-002594:mdna:14]
[same as prior period, unchanged from 0001445305-12-001573:mdna:14]

[0001445305-12-002594:mdna:15]
We were incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. We are a leading provider of automated solutions for medication and supply management in healthcare. Our automation and analytics solutions are designed to enable healthcare facilities to acquire, manage, dispense and administer medications and medical-surgical supplies and are intended to enhance patient safety, reduce medication errors, reduce operating costs, improve workflow and increase operational efficiency. Approximately 2,600 hospitals utilize one or more of our products, of which more than 1,600 hospitals in the United States have installed our automated hardware/software solutions for controlling, dispensing, acquiring, verifying, tracking and analyzing medications and medical and surgical supplies. Approximately 6,000 institutional and retail pharmacies utilize our medication adherence packaging solutions.

[0001445305-12-002594:mdna:16]
We sell our medication control systems together with related consumables and services, and medical/surgical supply control systems and generate the majority of our revenue in the United States. However, we expect our revenue from our international operations to increase in future periods as we continue to grow our international business. Our sales force is organized by geographic region in the United States and Canada, and for a portion of our products in the United Kingdom and Germany. We also sell through distributors in Asia, Australia, Europe, the Middle East and South America. We have not sold in the past, and have no future plans to sell our products either directly or indirectly to customers located in countries that are

[0001445305-12-002594:mdna:17]
identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0001445305-12-002594:mdna:18]
Business Acquisition

[0001445305-12-002594:mdna:19]
On May 21, 2012, we completed our acquisition of MedPak pursuant to the Merger Agreement for $158.3 million in cash, subject to certain adjustments, and including $13.5 million in cash that was placed in an escrow fund at the closing of the transaction. Under the terms of the Merger Agreement, Merger Sub, a newly formed Omnicell subsidiary, was merged with and into MedPak, with MedPak surviving the merger as a wholly-owned subsidiary of Omnicell. MedPak is the parent company of MTS, a worldwide provider of medication adherence packaging systems and solutions. MTS primarily manufactures and sells consumable medication blister cards, packaging equipment and ancillary products throughout the United States, Canada, Europe and Australia. Its customers are predominantly institutional pharmacies that supply nursing homes, assisted living and correctional facilities with prescription medications for their patients. MTS manufactures its proprietary consumable blister cards and most of its packaging equipment in its own facilities. This manufacturing process uses integrated equipment for manufacturing the consumable medication blister cards. In addition, MTS utilizes the services of outside contract manufacturers for some of its packaging equipment. The consumable medication blister cards and packaging equipment are designed to provide a cost-effective method for pharmacies to dispense medications. MTS’ medication dispensing systems and products provide innovative methods for dispensing medications in disposable packages. MTS Limited distributes products for MTS primarily in the United Kingdom. MTS GmbH distributes products for MTS in Germany. MTS currently serves more than 6,000 institutional pharmacies in the long-term care and correctional markets, both domestically and internationally.

[0001445305-12-002594:mdna:20]
With the acquisition of MTS, we organized our business into two operating business segments: Acute Care and Non-Acute Care. The Acute Care segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems. The Non-Acute Care segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products. We report segment information based on the management approach. The management approach designates the internal reporting used by the Chief Operating Decision Maker (“CODM”), for making decisions and assessing performance as the source of our operating segments. The CODM is our Chief Executive Officer. The CODM allocates resources to and assesses the performance of each operating segment using information about its revenues, gross profit and income (loss) from operations.

[0001445305-12-002594:mdna:21]
Operations During the Three Months and Six Months Ended June 30, 2012

[0001445305-12-002594:mdna:22]
The consolidated results presented for the three months and six months ended June 30, 2012 reflect the impact of the Non-Acute Care segment since the May 21, 2012 acquisition of MTS.

[0001445305-12-002594:mdna:23]
Revenues grew year-over-year for both product and services, with overall revenue growth of 23.6%, comparing $75.4 million for the second quarter of 2012 with $61.0 million for the second quarter of 2011. Overall revenue growth was 18.1% for the six month period ending June 30, 2012, comparing $139.5 million with $118.2 million for the same period in 2011. Overall revenue growth attributable to the newly acquired Non-Acute Care segment was $8.9 million, for the three months and six months ended June 30, 2012.

[0001445305-12-002594:mdna:24]
Product revenue growth is primarily reflective of overall increased installations as allowed for by our customers’ schedules, while service revenue growth reflects a growing installed base. Additionally, Non-Acute Care since the date of the acquisition of MTS, contributed $8.6 million and $0.3 million to the overall product and service revenue growth, respectively. Overall product and service margins increased by $5.6 million, or 16.5% for the three months ended June 30, 2012 as compared to the same period in 2011. Product and service margins increased by $9.7 million, or 14.8% for the six months ended June 30, 2012 as compared to the same period in 2011.

[0001445305-12-002594:mdna:25]
[same as prior period, unchanged from 0001445305-12-001573:mdna:23]

[0001445305-12-002594:mdna:26]
[same as prior period, unchanged from 0001445305-12-001573:mdna:24]

[0001445305-12-002594:mdna:27]
| • | We have delivered industry-leading products with differentiated product features that are designed to appeal to nurses and pharmacists, such as our G4 platform, the SavvyTM Mobile Medication System, SinglePointeTM, Anywhere RNTM and OnDemand; |

[0001445305-12-002594:mdna:28]
| • | Through acquisitions, we have broadened our medication control product line to address the growing need for medication management across the continuum of care beyond hospitals; and |

[0001445305-12-002594:mdna:29]
[same as prior period, unchanged from 0001445305-12-001573:mdna:26]

[0001445305-12-002594:mdna:30]
We maintain a development staff with expertise in hospital logistics, pharmacy operations and computerized automated solutions, which allows us to deliver new innovations to the market. Our ability to grow revenue and maintain positive cash flow is dependent on our ability to obtain orders from customers, our ability to manufacture consumables to customer demand, the volume of installations we are able to complete, our ability to meet customers’ needs while providing a quality installation experience and our flexibility in manpower allocations among customers to complete installations on a timely basis.

[0001445305-12-002594:mdna:31]
During the second quarter of 2012, we achieved 17.5% growth in total revenues from the first quarter of 2012, inclusive of the aforementioned Non-Acute Care contribution. Product revenue increased by $10.7 million, or 22.1%, while service revenue increased by $0.5 million, or 3.2%. Overall gross margins for the second quarter of 2012 declined to 52.2% from 55.7% in the first quarter of 2012. Product gross margins declined to 51.7% on revenue of $59.3 million as compared with 58.2% on revenue of $48.5 million in the first quarter of 2012. Service gross margins increased to 54.0% on revenue of $16.1 million as compared to 48.2% margins on $15.6 million in revenue in the first quarter of 2012. The overall decrease in gross margins is primarily attributable to Non-Acute Care activity which has lower margins, coupled with product mix in the Acute Care segment.

[0001445305-12-002594:mdna:32]
Cash, cash equivalents and short-term investments decreased  by $145.8 million during the six months ended June 30, 2012 to $54.1 million from $199.9 million at December 31, 2011. During the quarter ended June 30, 2012, we expended $159.2 million for the acquisition of MTS and related transaction costs, and $7.1 million to repurchase 505,137 shares of our common stock through our stock repurchase program. These expenditures were partially offset by $18.8 million in quarterly operating cash flow reflecting improved net income and a decline in Acute Care inventories.

[0001445305-12-002594:mdna:33]
[same as prior period, unchanged from 0001445305-12-001573:mdna:31]

[0001445305-12-002594:mdna:34]
Our discussion and analysis of our financial condition and results of operations are based on our consolidated financial statements, which have been prepared in accordance with U.S. GAAP. The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe that the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our condensed consolidated financial statements:

[0001445305-12-002594:mdna:35]
[same as prior period, unchanged from 0001445305-12-001573:mdna:33]

[0001445305-12-002594:mdna:36]
[same as prior period, unchanged from 0001445305-12-001573:mdna:34]

[0001445305-12-002594:mdna:37]
[same as prior period, unchanged from 0001445305-12-001573:mdna:35]

[0001445305-12-002594:mdna:38]
[same as prior period, unchanged from 0001445305-12-001573:mdna:36]

[0001445305-12-002594:mdna:39]
[same as prior period, unchanged from 0001445305-12-001573:mdna:37]

[0001445305-12-002594:mdna:40]
[same as prior period, unchanged from 0001445305-12-001573:mdna:38]

[0001445305-12-002594:mdna:41]
During the six months ended June 30, 2012, there were no significant changes in our critical accounting policies and estimates.

[0001445305-12-002594:mdna:42]
Please refer to Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended December 31, 2011 for a more complete discussion of our other critical accounting policies and estimates.

[0001445305-12-002594:mdna:43]
Recently Adopted Accounting Pronouncements

[0001445305-12-002594:mdna:44]
In May 2011, the FASB issued ASU 2011-04, Fair Value Measurement, amending the fair value guidance in ASC 820, and thereby achieving substantially converged fair value measurement and disclosure requirements for GAAP and IFRS. The new guidance clarified some fair value measurement principles and expanded certain disclosure requirements. We adopted this guidance in the first quarter of 2012, without any impact to our financial position, operating results or cash flows.

[0001445305-12-002594:mdna:45]
[same as prior period, unchanged from 0001445305-12-001573:mdna:43]

[0001445305-12-002594:mdna:46]
The table below shows the components of our results of operations as percentages of total revenues for the three months and six months ended June 30, 2012 and 2011 (in thousands, except percentages):

[0001445305-12-002594:mdna:47]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
|  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 59,269 |  |  | 78.6 | % |  | $ | 46,218 |  |  | 75.8 | % |  | $ | 107,793 |  |  | 77.3 | % |  | $ | 88,793 |  |  | 75.1 | % |
| Service and other revenues | 16,115 |  |  | 21.4 | % |  | 14,787 |  |  | 24.2 | % |  | 31,734 |  |  | 22.7 | % |  | 29,372 |  |  | 24.9 | % |
| Total revenues | 75,384 |  |  | 100.0 | % |  | 61,005 |  |  | 100.0 | % |  | 139,527 |  |  | 100.0 | % |  | 118,165 |  |  | 100.0 | % |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 28,600 |  |  | 38.0 | % |  | 19,730 |  |  | 32.4 | % |  | 48,896 |  |  | 35.0 | % |  | 37,566 |  |  | 31.8 | % |
| Cost of service and other revenues | 7,408 |  |  | 9.8 | % |  | 7,468 |  |  | 12.2 | % |  | 15,506 |  |  | 11.1 | % |  | 15,142 |  |  | 12.8 | % |
| Total cost of revenues | 36,008 |  |  | 47.8 | % |  | 27,198 |  |  | 44.6 | % |  | 64,402 |  |  | 46.1 | % |  | 52,708 |  |  | 44.6 | % |
| Gross profit | 39,376 |  |  | 52.2 | % |  | 33,807 |  |  | 55.4 | % |  | 75,125 |  |  | 53.9 | % |  | 65,457 |  |  | 55.4 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 5,499 |  |  | 7.3 | % |  | 5,280 |  |  | 8.7 | % |  | 11,993 |  |  | 8.6 | % |  | 10,120 |  |  | 8.5 | % |
| Selling, general and administrative | 31,446 |  |  | 41.7 | % |  | 24,297 |  |  | 39.8 | % |  | 57,066 |  |  | 40.9 | % |  | 50,078 |  |  | 42.4 | % |
| Total operating expenses | 36,945 |  |  | 49.0 | % |  | 29,577 |  |  | 48.5 | % |  | 69,059 |  |  | 49.5 | % |  | 60,198 |  |  | 50.9 | % |
| Income from operations | 2,431 |  |  | 3.2 | % |  | 4,230 |  |  | 6.9 | % |  | 6,066 |  |  | 4.4 | % |  | 5,259 |  |  | 4.5 | % |
| Interest and other income (expense), net | (73 | ) |  | (0.1 | )% |  | 71 |  |  | 0.1 | % |  | 23 |  |  | — |  |  | 125 |  |  | 0.1 | % |
| Income before provision for income taxes | 2,358 |  |  | 3.1 | % |  | 4,301 |  |  | 7.0 | % |  | 6,089 |  |  | 4.4 | % |  | 5,384 |  |  | 4.6 | % |
| Provision for income taxes | 983 |  |  | 1.3 | % |  | 1,714 |  |  | 2.8 | % |  | 2,363 |  |  | 1.7 | % |  | 2,127 |  |  | 1.8 | % |
| Net income | $ | 1,375 |  |  | 1.8 | % |  | $ | 2,587 |  |  | 4.2 | % |  | $ | 3,726 |  |  | 2.7 | % |  | $ | 3,257 |  |  | 2.8 | % |

[0001445305-12-002594:mdna:48]
The table above and the ensuing financial information and discussions presented include Non-Acute Care results since the May 21, 2012 acquisition of MTS.

[0001445305-12-002594:mdna:49]
[same as prior period, unchanged from 0001445305-12-001573:mdna:46]

[0001445305-12-002594:mdna:50]
The table below shows our product revenues, cost of product revenues and gross profit for the three months and six months ended June 30, 2012 and 2011 and the percentage changes between those periods (in thousands, except percentages):

[0001445305-12-002594:mdna:51]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2012 |  | 2011 |  | % Change |  | 2012 |  | 2011 |  | % Change |
| Product revenues | $ | 59,269 |  |  | $ | 46,218 |  |  | 28.2 | % |  | $ | 107,793 |  |  | $ | 88,793 |  |  | 21.4 | % |
| Cost of product revenues | 28,600 |  |  | 19,730 |  |  | 45.0 | % |  | 48,896 |  |  | 37,566 |  |  | 30.2 | % |
| Gross profit | $ | 30,669 |  |  | $ | 26,488 |  |  | 15.8 | % |  | $ | 58,897 |  |  | $ | 51,227 |  |  | 15.0 | % |
| Gross margin | 51.7 | % |  | 57.3 | % |  |  |  | 54.6 | % |  | 57.7 | % |  |  |

[0001445305-12-002594:mdna:52]
Product revenues increased by $13.1 million, or 28.2%, in the three months ended June 30, 2012 as compared to the same period in 2011. Product revenues increased by $19.0 million, or 21.4%, in the six months ended June 30, 2012 as compared to the same period in 2011. Our ability to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce consumables to customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience and our flexibility in manpower allocations among

[0001445305-12-002594:mdna:53]
customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations. The overall increase in product revenues was driven by a combination of increased installations of our new automation products, increases in lease renewals from existing customers and the contribution of $8.5 million from MTS products in our Non-Acute Care segment since acquisition May 21, 2012. We anticipate our revenues will continue to increase in 2012. We expect growth in our Acute Care products segment of approximately 7.0% to 8.0%, year over year, as we fulfill our existing orders and as we experience an anticipated continued high volume of lease renewals. Additionally, year over year revenue growth for the remainder of 2012 will be impacted by the results from the Non-Acute Care segment that we did not have in 2011.

[0001445305-12-002594:mdna:54]
Cost of product revenues increased by $8.9 million, or 45.0%, in the three months ended June 30, 2012 as compared to the same period in 2011. Cost of product revenues increased by $11.3 million, or 30.2%, in the six months ended June 30, 2012 as compared to the same period in 2011. This increase was primarily a function of Acute Care revenue growth in addition to $6.7 million of Non-Acute Care product costs incurred since May 21, 2012 and included in both the three months and six months ended June 30, 2012. The Non-Acute Care product costs included $1.6 million of acquisition related charges associated with the step-up to the estimated fair value of inventory acquired from MTS and consumed in the normal manufacturing cycle of our business, and $0.1 million for severance expenses related to staff realignment.

[0001445305-12-002594:mdna:55]
Gross profit on product revenue increased by $4.2 million, or 15.8%, in the three months ended June 30, 2012 as compared to the same period in 2011. Gross profit on product revenue increased by $7.7 million, or 15.0%, in the six months ended June 30, 2012 as compared to the same period in 2011. This increase was primarily a result of the aforementioned increases in product revenue, together with relatively comparable increases in product costs to support this revenue growth. Gross profit on product revenue as a percentage of total product revenue decreased for both the three months and six months ended June 30, 2012, as compared to the corresponding prior year period primarily due to the lower margins on our Non-Acute Care product revenues, the step up of inventory valuation, and other charges associated with the acquisition of MTS that are not expected to reoccur.

[0001445305-12-002594:mdna:56]
We anticipate lower overall gross profit on product sales as a percentage of total product sales in the third quarter of 2012 and subsequent quarters, as we record a full quarter of Non-Acute Care revenues which carry lower gross margins than our Acute Care segment.

[0001445305-12-002594:mdna:57]
[same as prior period, unchanged from 0001445305-12-001573:mdna:54]

[0001445305-12-002594:mdna:58]
The table below shows our service and other revenues, cost of service and other revenues and gross profit for the three months and six months ended June 30, 2012 and 2011 and the percentage change between those periods (in thousands, except percentages):

[0001445305-12-002594:mdna:59]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2012 |  | 2011 |  | % Change |  | 2012 |  | 2011 |  | % Change |
| Service and other revenues | $ | 16,115 |  |  | $ | 14,787 |  |  | 9.0 | % |  | $ | 31,734 |  |  | $ | 29,372 |  |  | 8.0 | % |
| Cost of service and other revenues | 7,408 |  |  | 7,468 |  |  | (0.8 | )% |  | 15,506 |  |  | 15,142 |  |  | 2.4 | % |
| Gross profit | $ | 8,707 |  |  | $ | 7,319 |  |  | 19.0 | % |  | $ | 16,228 |  |  | $ | 14,230 |  |  | 14.0 | % |
| Gross margin | 54.0 | % |  | 49.5 | % |  |  |  | 51.1 | % |  | 48.4 | % |  |  |

[0001445305-12-002594:mdna:60]
Service and other revenues include revenues from service and maintenance contracts, rentals of automation systems, training and professional services. Service and other revenues increased by $1.3 million, or 9.0%, in the three months ended June 30, 2012 as compared to the same period in 2011. Service and other revenues increased by $2.4 million, or 8.0%, in the six months ended June 30, 2012 as compared to the same period in 2011. The increase in service and other revenues was primarily the result of an expansion in our installed base of automation systems and a resulting increase in the number of support service contracts, continued growth in analytical software, higher training revenues and $0.3 million of service revenues attributable to MTS.

[0001445305-12-002594:mdna:61]
Cost of service and other revenues were flat, in the three months ended June 30, 2012 as compared to the same period in 2011 and increased by $0.4 million, or 2.4%, in the six months ended June 30, 2012 as compared to the same period in 2011. The increase was primarily due to an increase in spending of approximately $0.2 million related to salaries, benefits and other costs associated with higher headcount in support of the expanded service base in our Acute Care segment coupled with and expenses attributable to the Non-Acute Care segment.

[0001445305-12-002594:mdna:62]
Gross profit on service and other revenues increased by $1.4 million, or 19.0%, in the three months ended June 30, 2012 as compared to the same period in 2011. Gross profit on service and other revenues increased by $2.0 million, or 14.0%, in the six months ended June 30, 2012 as compared to the same period in 2011. The increase in gross profit on service and other revenues was primarily due to increased revenues from an expanded installed base with nominal growth in service cost attributable to our Acute Care segment. The contribution to gross profit on service and other revenues from our Non-Acute Care segment was immaterial.

[0001445305-12-002594:mdna:63]
We expect our service and other revenues and associated gross profit to vary in the future. We expect increases in the install base and the addition of non acute care segment service revenue and gross profit to be partially or fully offset by an increased propensity for customers to contract for service on a time and material basis, variations in the quantity and cost of spare parts used to service our install base, and increases in staffing to accommodate an increased number of customers.

[0001445305-12-002594:mdna:64]
[same as prior period, unchanged from 0001445305-12-001573:mdna:60]

[0001445305-12-002594:mdna:65]
The table below shows our operating expenses for the three months and six months ended June 30, 2012 and 2011 and the percentage changes between those periods (in thousands, except percentages):

[0001445305-12-002594:mdna:66]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2012 |  | 2011 |  | % Change |  | 2012 |  | 2011 |  | % Change |
| Research and development | $ | 5,499 |  |  | $ | 5,280 |  |  | 4.1 | % |  | $ | 11,993 |  |  | $ | 10,120 |  |  | 18.5 | % |
| Selling, general and administrative | 31,446 |  |  | 24,297 |  |  | 29.4 | % |  | 57,066 |  |  | 50,078 |  |  | 14.0 | % |
| Total operating expenses | $ | 36,945 |  |  | $ | 29,577 |  |  | 24.9 | % |  | $ | 69,059 |  |  | $ | 60,198 |  |  | 14.7 | % |

[0001445305-12-002594:mdna:67]
Research and Development. Research and development expenses increased by $0.2 million, or 4.1%, in the three months ended June 30, 2012 as compared to the same period in 2011, primarily due to the addition of Non-Acute Care research and development expenses. Research and development expenses represented 7.3% and 8.7% of total revenues in the three months ended June 30, 2012 and 2011, respectively. Research and development expenses increased by $1.9 million, or 18.5%, in the six months ended June 30, 2012 as compared to the same period in 2011 and represented 8.6% and 8.5% of total revenues in the six months ended June 30, 2012 and 2011, respectively. The increase was primarily due to a $1.8 million decrease in software capitalization primarily the result of no similar expenses eligible for capitalization in the first quarter of 2012, and an increase of $0.5 million in consulting, offset by a decrease of $0.8 million primarily due to salary related expenses in our Acute Care segment coupled with the aforementioned increase associated with our Non-Acute Care segment. The amount of research and development expense can fluctuate based on the amount of prototype expenses for hardware and/or the amount of capitalized software development costs in any given quarter.

[0001445305-12-002594:mdna:68]
[same as prior period, unchanged from 0001445305-12-001573:mdna:64]

[0001445305-12-002594:mdna:69]
Selling, General and Administrative. Selling, general and administrative expenses increased by $7.1 million, or 29.4%, in the three months ended June 30, 2012 as compared to the same period in 2011. Selling, general and administrative expenses represented 41.7% and 39.8% of total revenues in the three months ended June 30, 2012 and 2011, respectively. The increase was primarily due to the addition of MTS selling, general and administrative expenses of $2.4 million, $1.0 million increase in compensation costs related to increased sales and marketing staffing, $0.4 million in bad debt expense, and $3.2 million in acquisition-related expenses.

[0001445305-12-002594:mdna:70]
Selling, general and administrative expenses increased by $7.0 million, or 14.0%, in the six months ended June 30, 2012 as compared to the same period in 2011. Selling, general and administrative expenses represented 40.9% and 42.4% of total revenues in the six months ended June 30, 2012 and 2011, respectively. The increase was primarily due to the addition of Non-Acute Care selling, general and administrative expenses of $2.4 million, a $2.4 million increase in compensation costs related to increased sales and marketing staffing, and $3.2 million in acquisition-related expenses, offset by a $1.1 million decrease in legal expenses related to the settlement of the Medacist litigation in the six months ended June 30, 2011.

[0001445305-12-002594:mdna:71]
We expect selling, general and administrative expenses to grow at a nominal rate in order to support our anticipated growth as well as international expansion efforts, but anticipate that increased efficiencies will result in a lower selling, general and administrative expense growth relative to total revenue growth in 2012.

[0001445305-12-002594:mdna:72]
Share-based Compensation. The effect of share-based compensation on functional expenses within our operating results for the three months and six months ended June 30, 2012 and 2011 is presented in Note 13, “Stock Option Plans and

[0001445305-12-002594:mdna:73]
Share-Based Compensation.”

[0001445305-12-002594:mdna:74]
[same as prior period, unchanged from 0001445305-12-001573:mdna:69]

[0001445305-12-002594:mdna:75]
The annual effective tax rate before discrete items was 40.9% and 41.7% for the six months ended June 30, 2012 and 2011, respectively.The decrease in the estimated 2012 annual effective tax rate recorded in the six months ended June 30, 2012 as compared to the same period in 2011 was primarily due to an increase in expected domestic production activities deduction in 2012, partially offset by the expiration of the federal research and development credit after 2011 and non-deductible acquisition costs.

[0001445305-12-002594:mdna:76]
[same as prior period, unchanged from 0001445305-12-001573:mdna:71]

[0001445305-12-002594:mdna:77]
We had cash and cash equivalents of $54.1 million at June 30, 2012, as compared to $191.8 million in cash and cash equivalents and $8.1 million of short term investments at December 31, 2011. All of our cash is in low risk short term money market funds or demand deposits. The $8.1 million of short term investments held at December 31, 2011 consisted of California revenue anticipation notes which matured on June 26, 2012. We have no long term investments. While in the future we may need to seek additional financing to meet our working capital needs and to finance capital expenditures, as well as to fund operations or potential acquisitions, we believe our current cash and cash equivalent balances and cash flows generated by operations will be sufficient to satisfy our anticipated cash needs for working capital and capital expenditures for at least the next twelve months. Our cash and cash equivalents of $54.1 million reflects use of $156.3 million of cash expended to acquire MTS on May 21, 2012, net of cash acquired, as described in Note 14, “Business Acquisition”.

[0001445305-12-002594:mdna:78]
Cash flows for the six months ended June 30, 2012 and 2011 consisted of the following (in thousands):

[0001445305-12-002594:mdna:79]
|  | Six Months Ended June 30, |
|  | 2012 |  | 2011 |
| Net cash provided by operating activities | $ | 18,758 |  |  | $ | 7,263 |  |
| Net cash (used in) provided by investing activities | (153,940 | ) |  | 222 |  |
| Net cash used in financing activities | (2,532 | ) |  | (1,870 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 23 |  |  | 8 |  |
| Net (decrease) increase in cash and cash equivalents | $ | (137,691 | ) |  | $ | 5,623 |  |

[0001445305-12-002594:mdna:80]
Operating activities provided $18.8 million of cash during the six months ended June 30, 2012 as compared to $7.3 million for the six months ended June 30, 2011. The main drivers for the $11.5 million increase in cash generated from operations were a $0.5 million increase in net income, a $12.9 million increase from the change in inventories primarily the result of a non-recurring increase in 2011 in anticipation of new product introductions, a $5.6 million cash increase from accrued compensation, and a $1.6 million cash increase from the excess tax benefits from employee stock plans. These were partially offset by a $2.5 million cash decrease from prepaid expenses, a $2.1 million decrease from accrued liabilities, a $2.0 million decrease from accounts payable and a $1.5 million decrease from investment in sales-type leases.

[0001445305-12-002594:mdna:81]
Cash used in investing activities totaled $153.9 million during the six months ended June 30, 2012, as compared to $0.2 million provided by investing activities during the six months ended June 30, 2011. This $154.2 million decrease in cash  primarily reflects the $156.3 million of net cash used to acquire MTS. This was partially offset by a decline in software development, from $3.1 million for the six months ended June 30, 2011 as compared to $1.4 million in the six months ended June 30, 2012. The prior period had more pre-capitalization testing of several new software applications for external sale or lease.

[0001445305-12-002594:mdna:82]
Cash used by financing activities was $2.5 million during the six months ended June 30, 2012, as compared to $1.9 million during the six months ended June 30, 2011, a difference of $0.7 million in cash used. Excess tax benefits from employees stock plans provided $1.6 million lower cash inflow in the six months ended June 30, 2012, whereas the cash effect of stock purchases, comparing the two periods, provided $0.9 million more cash.

[0001445305-12-002594:mdna:83]
[same as prior period, unchanged from 0001445305-12-001573:mdna:78]

[0001445305-12-002594:mdna:84]
Except for the Milpitas lease signed in March 2012 and the assumption of the St. Petersburg lease in May 2012, there have been no material changes to our contractual obligations during the six months ended June 30, 2012. Please refer to our Annual Report on Form 10-K for the year ended December 31, 2011 for a description of our facility leases and contractual obligations and the Notes to the consolidated financial statements included therein.

[0001445305-12-002594:mdna:85]
The following table summarizes our contractual obligations at June 30, 2012 (in thousands):

[0001445305-12-002594:mdna:86]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | More than five years |
| Operating leases (1) (2) (3) (4) | $ | 48,121 |  |  | $ | 5,486 |  |  | $ | 10,591 |  |  | $ | 9,549 |  |  | $ | 22,495 |  |
| Commitments to contract manufacturers and suppliers (5) | 7,310 |  |  | 7,310 |  |  | — |  |  | — |  |  | — |  |
| Total (6) | $ | 55,431 |  |  | $ | 12,796 |  |  | $ | 10,591 |  |  | $ | 9,549 |  |  | $ | 22,495 |  |

[0001445305-12-002594:mdna:87]
[same as prior period, unchanged from 0001445305-12-001573:mdna:82]

[0001445305-12-002594:mdna:88]
(2)       In October 2011, we entered into a lease agreement for approximately 100,000 square feet of office space. Pursuant to the lease agreement, the landlord will construct a single, three-story building of rentable space located at 590 Middlefield Road in Mountain View, California which we will subsequently lease and which will serve as our headquarters. The term of the lease agreement is for a period of ten years, expected to commence November 2012, with a base lease commitment of approximately $40.0 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional sixty month term.

[0001445305-12-002594:mdna:89]
(3)      In March 2012, we entered into a lease agreement for approximately 46,000 square feet of manufacturing, distribution and office space located at 735 Sycamore Drive in Milpitas, California. The term of the lease agreement is for a period of sixty months, expected to commence approximately October 2012, with a base lease commitment of approximately $1.8 million and a single sixty month extension option.

[0001445305-12-002594:mdna:90]
(4)    Commencing with the May 2012 acquisition of MTS, we assumed responsibility for 132,500 square feet of manufacturing, warehousing and office space in St. Petersburg, Florida. The remaining term of the original 12 year lease agreement is through September 30, 2016 with a remaining base lease commitment of approximately $3.9 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term. In Leeds, United Kingdom, MTS leases an office and distribution center. The remaining term of the original 10 year lease agreement is through June 8, 2021, with no extension options. The remaining base lease commitment, converted from British Pounds at the current conversion rate, is approximately $1.2 million. MTS also has smaller rented offices in Strongsville, Ohio and Germany.

[0001445305-12-002594:mdna:91]
(5)    We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates.

[0001445305-12-002594:mdna:92]
(6)    At June 30, 2012, we have recorded $3.0 million for uncertain tax positions under long term liabilities, in accordance with GAAP, summarized under Note 1, “Organization and Summary of Significant Accounting Policies.” As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $3.0 million of uncertain tax position liabilities has not been included in the table of commitments above.

[0001445305-12-002594:mdna:93]
[same as prior period, unchanged from 0001445305-12-001573:mdna:88]

[0001445305-12-002594:mdna:94]
As of June 30, 2012, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
