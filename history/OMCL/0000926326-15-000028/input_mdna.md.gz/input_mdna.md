# OMCL MD&A — 0000926326-15-000028


## mdna

[0000926326-15-000028:mdna:1]
[same as prior period, unchanged from 0000926326-15-000018:mdna:1]

[0000926326-15-000028:mdna:2]
[same as prior period, unchanged from 0000926326-15-000018:mdna:2]

[0000926326-15-000028:mdna:3]
[same as prior period, unchanged from 0000926326-15-000018:mdna:3]

[0000926326-15-000028:mdna:4]
[same as prior period, unchanged from 0000926326-15-000018:mdna:4]

[0000926326-15-000028:mdna:5]
[same as prior period, unchanged from 0000926326-15-000018:mdna:5]

[0000926326-15-000028:mdna:6]
[same as prior period, unchanged from 0000926326-15-000018:mdna:6]

[0000926326-15-000028:mdna:7]
[same as prior period, unchanged from 0000926326-15-000018:mdna:7]

[0000926326-15-000028:mdna:8]
[same as prior period, unchanged from 0000926326-15-000018:mdna:8]

[0000926326-15-000028:mdna:9]
[same as prior period, unchanged from 0000926326-15-000018:mdna:9]

[0000926326-15-000028:mdna:10]
[same as prior period, unchanged from 0000926326-15-000018:mdna:10]

[0000926326-15-000028:mdna:11]
[same as prior period, unchanged from 0000926326-15-000018:mdna:11]

[0000926326-15-000028:mdna:12]
[same as prior period, unchanged from 0000926326-15-000018:mdna:12]

[0000926326-15-000028:mdna:13]
In some cases, you can identify forward-looking statements by terms such as "anticipates," "believes," "could," "estimates," "expects," "intends," "may," "plans," "potential," "predicts," "projects," "should," "will," "would" and similar expressions intended to identify forward-looking statements. Forward-looking statements reflect our current views with respect to future events, are based on assumptions and are subject to risks and uncertainties.  We discuss many of these risks in this quarterly report in greater detail in Part II - Section 1A “Risk Factors” below. Given these uncertainties, you should not place undue reliance on these forward-looking statements. Also, forward-looking statements represent our estimates and assumptions only as of the date of this quarterly report. You should also read this quarterly report and the documents that we reference in this quarterly report and have filed as exhibits, completely and with the understanding that our actual future results may be materially different from what we expect. All references in this report to "Omnicell," "our," "us," "we," or the "Company" collectively refer to Omnicell, Inc., a Delaware corporation, and its subsidiaries. The term "Omnicell, Inc.," refers only to Omnicell, Inc., excluding its subsidiaries.

[0000926326-15-000028:mdna:14]
[same as prior period, unchanged from 0000926326-15-000018:mdna:14]

[0000926326-15-000028:mdna:15]
[same as prior period, unchanged from 0000926326-15-000018:mdna:15]

[0000926326-15-000028:mdna:16]
We are a leading provider of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum, from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home. Our Omnicell Automation and Analytics customers worldwide use our medication automation, supply chain and analytics solutions to help enable them to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety.

[0000926326-15-000028:mdna:17]
Omnicell Medication Adherence solutions, including the MTS, Suremed and Surgichem brands, provide innovative medication adherence packaging solutions that can help reduce costly hospital readmissions and enable institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-15-000028:mdna:18]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 87% and 86% of our total revenues for the three and six months ended June 30, 2015, respectively, and we expect our revenues from international operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-15-000028:mdna:19]
[same as prior period, unchanged from 0000926326-15-000018:mdna:19]

[0000926326-15-000028:mdna:20]
Beginning in the first quarter of 2015, we have managed our business according to two product segments, Automation and Analytics and Medication Adherence.

[0000926326-15-000028:mdna:21]
[same as prior period, unchanged from 0000926326-15-000018:mdna:21]

[0000926326-15-000028:mdna:22]
[same as prior period, unchanged from 0000926326-15-000018:mdna:22]

[0000926326-15-000028:mdna:23]
25

[0000926326-15-000028:mdna:24]
[same as prior period, unchanged from 0000926326-15-000018:mdna:23]

[0000926326-15-000028:mdna:25]
The Medication Adherence segment primarily includes the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand name MTS, Surgichem, Suremed and the Omnicell brand. MTS products consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care, and correctional facilities or retail pharmacies serving patients in their local communities. Similarly, Surgichem is a provider of medication adherence packaging systems and solutions to the United Kingdom community and home care markets.

[0000926326-15-000028:mdna:26]
[same as prior period, unchanged from 0000926326-15-000018:mdna:25]

[0000926326-15-000028:mdna:27]
[same as prior period, unchanged from 0000926326-15-000018:mdna:26]

[0000926326-15-000028:mdna:28]
[same as prior period, unchanged from 0000926326-15-000018:mdna:27]

[0000926326-15-000028:mdna:29]
[same as prior period, unchanged from 0000926326-15-000018:mdna:28]

[0000926326-15-000028:mdna:30]
[same as prior period, unchanged from 0000926326-15-000018:mdna:29]

[0000926326-15-000028:mdna:31]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, we began shipping a refresh of our product line in 2011, which we market as G4. The G4 refresh included multiple new products and an upgrade product that allowed existing customers to augment their installations to obtain the most current technology that we provide. The G4 product refresh has been a key contributor to our growth, with 69% of our automation and analytics installed base ordering upgrades to their existing systems since the announcement of G4. In addition to enhanced capabilities, we have focused on attaining the highest quality and service measurements for G4 in the industry, while marketing the solution to new and existing customers. Our research and development efforts today are designed to bring new products to market beyond the G4 product line that we believe will meet customer needs in years to come.

[0000926326-15-000028:mdna:32]
Consistent with our strategy to enter new markets, we have made investments in our selling, general and administrative expenses to expand our sales team and market to new customers. Our international efforts have focused primarily on four markets: the United Kingdom and Germany where we sell automation and analytics and medication adherence products through a direct sales team and automation and analytics products are now sold through a direct sales team with our acquisition of Avantec; Germany, where we sell medication adherence products through a direct sales team, Middle Eastern countries of the Arabian Peninsula where new healthcare facility construction is taking place; and China, where we launched a Mandarin version of our automated dispensing systems in 2011. We have also expanded our sales efforts to medication adherence customers in the United States, which has allowed us to sell our automated dispensing solutions and other products to this market.

[0000926326-15-000028:mdna:33]
Expansion of our solutions through acquisitions and partnerships include our acquisition of MTS in 2012, our acquisition of Surgichem in August 2014 and our acquisitions of Mach4 and Avantec in April 2015. Surgichem is a provider of medication adherence products in the United Kingdom. Mach4 is a provider of automated medication management systems to retail and hospital pharmacy customers primarily in Europe, with additional installations in China, the Middle East and Latin

[0000926326-15-000028:mdna:34]
America. Avantec develops medication and supply automation products that complement our solutions for configurations suited to the United Kingdom marketplace, and has been the exclusive United Kingdom distributor for our medication and supply automation solutions since 2005. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-15-000028:mdna:35]
We believe that the success of our three-leg strategy of differentiated products, expansion into new markets, and acquisition and partnership in future periods will be based on, among other factors:

[0000926326-15-000028:mdna:36]
[same as prior period, unchanged from 0000926326-15-000018:mdna:35]

[0000926326-15-000028:mdna:37]
[same as prior period, unchanged from 0000926326-15-000018:mdna:36]

[0000926326-15-000028:mdna:38]
[same as prior period, unchanged from 0000926326-15-000018:mdna:37]

[0000926326-15-000028:mdna:39]
[same as prior period, unchanged from 0000926326-15-000018:mdna:38]

[0000926326-15-000028:mdna:40]
In addition to product solution sales, we provide services to our customers. Our healthcare customers expect a high degree of partnership involvement from their technology suppliers throughout their ownership of the products. We provide extensive installation planning and consulting as part of every product sale and included in the initial price of the solution. Our customers' medication control systems are mission critical to their success and our customers require these systems to be functional at all times. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in one, two or five year increments. As a result of the growth of our installed base of customers, our service revenues have also grown. We strive to provide the best service possible, as measured by third-party rating agencies and by our own surveys, to assure our customers continue to seek service maintenance from us. Our liabilities include current and long-term deferred service revenue of $42.6 million and $45.5 million as of June 30, 2015 and December 31, 2014, respectively. Our deferred service revenue will be amortized to service revenue as the service contracts are executed.

[0000926326-15-000028:mdna:41]
The growth in our Automation and Analytics revenue for the three and six months ended June 30, 2015 was driven primarily by our success in consistently growing the number of our customer installations. Installed customers in the United States grew to 1975 hospitals as of June 30, 2015 from 1886 hospitals as of June 30, 2014. To a lesser extent, but of equal importance, revenue growth was also driven by our success in upgrading installed customers to newer G4 technology, which is in line with our strategy of striving to deliver differentiated innovation in our solutions. Our larger installed base has provided growth opportunities for follow on sales and increased service contracts and, as a result, our service revenues have also grown for the three and six months ended June 30, 2015.

[0000926326-15-000028:mdna:42]
The growth in our Medication Adherence revenue was driven primarily by increased adoption of multi-medication adherence solutions used by patients in assisted living or home care in Europe for the three months ended June 30, 2015. This growth is in line with our strategy to deliver solutions to markets outside the United States. On a geographic basis, the United States market did not contribute to, nor erode, the growth in our Medication Adherence business as the population of patients living in nursing homes in the United States has remained relatively constant over the past year.

[0000926326-15-000028:mdna:43]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but for our focus to remain on improving healthcare with solutions that help change practices in ways that improve patient and provider outcomes. We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue. In 2015, we also intend to manage our business to operating profit margins similar to those achieved in 2014.

[0000926326-15-000028:mdna:44]
[same as prior period, unchanged from 0000926326-15-000018:mdna:44]

[0000926326-15-000028:mdna:45]
Our discussion and analysis of our financial condition and results of operations are based on our Condensed Consolidated Financial Statements, which have been prepared in accordance with U.S. GAAP. The preparation of these

[0000926326-15-000028:mdna:46]
financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements:

[0000926326-15-000028:mdna:47]
[same as prior period, unchanged from 0000926326-15-000018:mdna:46]

[0000926326-15-000028:mdna:48]
[same as prior period, unchanged from 0000926326-15-000018:mdna:47]

[0000926326-15-000028:mdna:49]
[same as prior period, unchanged from 0000926326-15-000018:mdna:48]

[0000926326-15-000028:mdna:50]
[same as prior period, unchanged from 0000926326-15-000018:mdna:49]

[0000926326-15-000028:mdna:51]
[same as prior period, unchanged from 0000926326-15-000018:mdna:50]

[0000926326-15-000028:mdna:52]
[same as prior period, unchanged from 0000926326-15-000018:mdna:51]

[0000926326-15-000028:mdna:53]
There have been no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the three and six months ended June 30, 2015 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2014.

[0000926326-15-000028:mdna:54]
[same as prior period, unchanged from 0000926326-15-000018:mdna:53]

[0000926326-15-000028:mdna:55]
Refer to Note 1, Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial positions and cash flows.

[0000926326-15-000028:mdna:56]
[same as prior period, unchanged from 0000926326-15-000018:mdna:55]

[0000926326-15-000028:mdna:57]
[same as prior period, unchanged from 0000926326-15-000018:mdna:56]

[0000926326-15-000028:mdna:58]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 89,154 |  |  | $ | 85,244 |  |  | 3,910 |  |  | 5 | % |
| Percentage of total revenues | 79 | % |  | 81 | % |  |  |  |  |
| Service and other revenues | 23,634 |  |  | 19,808 |  |  | 3,826 |  |  | 19 | % |
| Percentage of total revenues | 21 | % |  | 19 | % |  |  |  |  |
| Total revenues | $ | 112,788 |  |  | $ | 105,052 |  |  | $ | 7,736 |  |  | 7 | % |

[0000926326-15-000028:mdna:59]
Product revenues represented 79% and 81% of total revenues for the three months ended June 30, 2015 and June 30, 2014, respectively. Product revenues increased due to increased sales for Medication Adherence segment of $3.8 million. Product sales from our Automation and Analytics segment remained flat. The newly acquired companies Mach4 and Avantec contributed approximately $2.9 million to the product revenue of Automation and Analytics segment for the three months ended June 30, 2015.

[0000926326-15-000028:mdna:60]
Service and other revenues represented 21% and 19% of total revenues for the three months ended June 30, 2015 and June 30, 2014. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues primarily increased due to an increase from our Automation and Analytics segment of $3.9 million which is partially offset by a decrease in service revenues from Medication Adherence segment of less than $0.1 million. The newly acquired companies Mach4 and Avantec contributed approximately $1.3 million to the service revenue of Automation and Analytics segment for the three months ended June 30, 2015.

[0000926326-15-000028:mdna:61]
Our international sales represented 14% and 10% of total revenues for the three months ended June 30, 2015 and June 30, 2014, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-15-000028:mdna:62]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 183,263 |  |  | $ | 167,824 |  |  | 15,439 |  |  | 9 | % |
| Percentage of total revenues | 80 | % |  | 81 | % |  |  |  |  |
| Service and other revenues | 45,746 |  |  | 38,992 |  |  | 6,754 |  |  | 17 | % |
| Percentage of total revenues | 20 | % |  | 19 | % |  |  |  |  |
| Total revenues | $ | 229,009 |  |  | $ | 206,816 |  |  | $ | 22,193 |  |  | 11 | % |

[0000926326-15-000028:mdna:63]
Product revenues represented 80% and 81% of total revenues for the six months ended June 30, 2015 and June 30, 2014, respectively. Product revenues increased due to increased sales for both our Automation and Analytics segment of $8.5 million and Medication Adherence segment of $6.9 million.  The newly acquired companies Mach4 and Avantec contributed approximately $2.9 million to the Automation and Analytics segment for the six months ended June 30, 2015.

[0000926326-15-000028:mdna:64]
Service and other revenues represented 20% and 19% of total revenues for the six months ended June 30, 2015 and June 30, 2014, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues primarily increased due to an increase from our Automation and Analytics segment of $6.8 million. The newly acquired companies Mach4 and Avantec contributed approximately $1.3 million to the service revenue of Automation and Analytics segment for the three months ended June 30, 2015.

[0000926326-15-000028:mdna:65]
Our international sales represented 14% and 10% of total revenues for the six months ended June 30, 2015 and June 30, 2014, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-15-000028:mdna:66]
We anticipate our revenues will continue to increase in 2015 compared to the same periods in 2014 as we fulfill our existing orders and based on our growth in bookings in 2014 and in the first six months of 2015, some of which will be recognized as revenue in 2015. Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-15-000028:mdna:67]
[same as prior period, unchanged from 0000926326-15-000018:mdna:61]

[0000926326-15-000028:mdna:68]
[same as prior period, unchanged from 0000926326-15-000018:mdna:62]

[0000926326-15-000028:mdna:69]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 88,701 |  |  | $ | 84,702 |  |  | $ | 3,999 |  |  | 5 | % |
| Percentage of total revenues | 79 | % |  | 81 | % |  |  |  |  |
| Medication Adherence | 24,087 |  |  | 20,350 |  |  | 3,737 |  |  | 18 | % |
| Percentage of total revenues | 21 | % |  | 19 | % |  |  |  |  |
| Total revenues | $ | 112,788 |  |  | $ | 105,052 |  |  | $ | 7,736 |  |  | 7 | % |

[0000926326-15-000028:mdna:70]
The increase in Automation and Analytics revenues for the three months ended June 30, 2015 in comparison to the three months ended June 30, 2014 was due to increase in Service and other revenues of $3.9 million, $2.3 million of which was primarily due to higher service renewal fees driven primarily by an increase in installed customer base and as well as $1.3 million contributed by the newly acquired companies Mach4 and Avantec. The product revenues remained flat primarily due to delayed installations. Our installations in progress include a higher proportion of new and competitive conversion customers and larger installations. These installations take longer to install as the customers spend more time planning the installation, assuring interfaces to other computer systems used in the facility are fully tested, and in the training of their staff.

[0000926326-15-000028:mdna:71]
Medication Adherence revenues increased for the three months ended June 30, 2015 in comparison to the three months ended June 30, 2014 primarily due to an increase in product revenues of $3.8 million primarily driven by the inclusion of

[0000926326-15-000028:mdna:72]
Surgichem operations since its acquisition in August 2014. Service and other revenues decreased slightly by $0.1 million.

[0000926326-15-000028:mdna:73]
|  | Six Months Ended June 30, |
|  |  |  | Change in |  |  |
|  | 2015 |  | 2014 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 181,480 |  |  | $ | 166,201 |  |  | $ | 15,279 |  |  | 9 | % |
| Percentage of total revenues | 79 | % |  | 80 | % |  |  |  |  |
| Medication Adherence | 47,529 |  |  | 40,615 |  |  | 6,914 |  |  | 17 | % |
| Percentage of total revenues | 21 | % |  | 20 | % |  |  |  |  |
| Total revenues | $ | 229,009 |  |  | $ | 206,816 |  |  | $ | 22,193 |  |  | 11 | % |

[0000926326-15-000028:mdna:74]
The increase in Automation and Analytics revenues for the six months ended June 30, 2015 in comparison to the six months ended June 30, 2014 was due to an increase in product revenues of $8.5 million primarily due to the increase of $5.6 million in automation dispensing systems and related software sales, and $2.9 million from the newly acquired companies Mach4 and Avantec. Service and other revenues increased by $5.5 million primarily from higher service renewal fees driven mainly by an increase in installed customer base and $1.3 million due to the newly acquired companies Mach4 and Avantec.

[0000926326-15-000028:mdna:75]
Medication Adherence revenues increased for the six months ended June 30, 2015 in comparison to the six months ended June 30, 2014, primarily due to an increase in product revenues of $6.9 million primarily driven by the inclusion of Surgichem operations since its acquisition in August 2014. Service and other revenues remained relatively flat compared to the prior year.

[0000926326-15-000028:mdna:76]
[same as prior period, unchanged from 0000926326-15-000018:mdna:67]

[0000926326-15-000028:mdna:77]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which accounts for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site, and include costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory and amortization of software development costs and intangibles.

[0000926326-15-000028:mdna:78]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 39,403 |  |  | $ | 35,992 |  |  | $ | 3,411 |  |  | 9 | % |
| As a percentage of related revenues | 44 | % |  | 42 | % |  |  |  |  |
| Medication Adherence | 15,923 |  |  | 13,020 |  |  | 2,903 |  |  | 22 | % |
| As a percentage of related revenues | 66 | % |  | 64 | % |  |  |  |  |
| Total cost of revenues | $ | 55,326 |  |  | $ | 49,012 |  |  | $ | 6,314 |  |  | 13 | % |
| As a percentage of total revenues | 49 | % |  | 47 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 49,298 |  |  | $ | 48,710 |  |  | $ | 588 |  |  | 1 | % |
| Automation and Analytics gross margin | 55 | % |  | 57 | % |  |  |  |  |
| Medication Adherence | 8,164 |  |  | 7,330 |  |  | 834 |  |  | 11 | % |
| Medication Adherence gross margin | 35 | % |  | 39 | % |  |  |  |  |
| Total gross profit | $ | 57,462 |  |  | $ | 56,040 |  |  | $ | 1,422 |  |  | 3 | % |
| Total gross margin | 51 | % |  | 54 | % |  |  |  |  |

[0000926326-15-000028:mdna:79]
30

[0000926326-15-000028:mdna:80]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 78,255 |  |  | $ | 70,932 |  |  | $ | 7,323 |  |  | 10 | % |
| As a percentage of related revenues | 43 | % |  | 42 | % |  |  |  |  |
| Medication Adherence | 31,607 |  |  | 25,349 |  |  | 6,258 |  |  | 25 | % |
| As a percentage of related revenues | 67 | % |  | 62 | % |  |  |  |  |
| Total cost of revenues | $ | 109,862 |  |  | $ | 96,281 |  |  | $ | 13,581 |  |  | 14 | % |
| As a percentage of total revenues | 48 | % |  | 47 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 103,225 |  |  | $ | 95,269 |  |  | $ | 7,956 |  |  | 8 | % |
| Automation and Analytics gross margin | 57 | % |  | 57 | % |  |  |  |  |
| Medication Adherence | 15,922 |  |  | 15,266 |  |  | 656 |  |  | 4 | % |
| Medication Adherence gross margin | 33 | % |  | 38 | % |  |  |  |  |
| Total gross profit | $ | 119,147 |  |  | $ | 110,535 |  |  | $ | 8,612 |  |  | 8 | % |
| Total gross margin | 52 | % |  | 53 | % |  |  |  |  |

[0000926326-15-000028:mdna:81]
[same as prior period, unchanged from 0000926326-15-000018:mdna:70]

[0000926326-15-000028:mdna:82]
Cost of Revenues. The increase in cost of revenues for the three months ended June 30, 2015 compared to the three months ended June 30, 2014 was $3.4 million. $2.5 million of which was attributable to product costs and $0.9 million attributable to service costs. Of the $2.5 million increase in product costs the newly acquired companies Mach4 and Avantec attributed $3.1 million. There was also a $0.9 million reduction in standard cost of goods sold for all other products not associated with the acquisitions and an increase of $0.3 million of product installation costs to support the higher upcoming revenues. Cost of service revenues increased by $0.4 million primarily due to an increase in costs related to the newly acquired companies Mach4 and Avantec.

[0000926326-15-000028:mdna:83]
The increase in cost of revenues for the six months ended June 30, 2015 compared to the six months ended June 30, 2014 was $7.3 million. $6.0 million of which was attributable to product costs and $1.3 million of which was attributable to service costs. Both increases were a result of higher volume of revenue. Of the $6.0 million increase in product costs the newly acquired companies Mach4 and Avantec attributed $3.1 million, $0.9 million is attributed to a different mixture of customers, products and overall growth in product sales, $1.3 million is attributable to more product installation costs associated with higher revenue, and $0.7 million is in other costs, primarily driven by software amortization.

[0000926326-15-000028:mdna:84]
Cost of service revenues increased by $1.3 million due to an increase in support headcount to service a larger installed base and to an increase of $0.5 million in expenses related to the newly acquired companies Mach4 and Avantec.

[0000926326-15-000028:mdna:85]
Gross profit for the three and six months ended June 30, 2015 increased compared to the three and six months ended June 30, 2014 as a result of increased revenue at consistent gross margin percentages, partially offset by lower gross margins from the newly acquired companies Mach4 and Avantec.

[0000926326-15-000028:mdna:86]
[same as prior period, unchanged from 0000926326-15-000018:mdna:73]

[0000926326-15-000028:mdna:87]
Cost of revenues increased by $2.6 million in product costs and $0.3 million in service costs. Product costs increased due to higher levels of revenue and due to higher production scrap rates and higher overtime costs. Cost of service sales increased by $0.3 million due to the seasonality of some expenses.

[0000926326-15-000028:mdna:88]
[same as prior period, unchanged from 0000926326-15-000018:mdna:75]

[0000926326-15-000028:mdna:89]
[same as prior period, unchanged from 0000926326-15-000018:mdna:76]

[0000926326-15-000028:mdna:90]
[same as prior period, unchanged from 0000926326-15-000018:mdna:78]

[0000926326-15-000028:mdna:91]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 8,746 |  |  | $ | 6,471 |  |  | $ | 2,275 |  |  | 35 | % |
| As a percentage of total revenues | 8 | % |  | 6 | % |  |  |  |  |
| Selling, general and administrative | 39,735 |  |  | 37,011 |  |  | 2,724 |  |  | 7 | % |
| As a percentage of total revenues | 35 | % |  | 35 | % |  |  |  |  |
| Gain on business combination | (3,443 | ) |  | — |  |  | (3,443 | ) |  | 100 | % |
| As a percentage of total revenues |  |  |  |  |  |  |  |
| Total operating expenses | $ | 45,038 |  |  | $ | 43,482 |  |  | $ | 1,556 |  |  | 4 | % |
| As a percentage of total revenues | 40 | % |  | 41 | % |  |  |  |  |
| Income from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 23,320 |  |  | $ | 22,666 |  |  | $ | 654 |  |  | 3 | % |
| Operating margin | 21 | % |  | 22 | % |  |  |  |  |
| Medication Adherence | 2,254 |  |  | 2,530 |  |  | (276 | ) |  | (11 | )% |
| Operating margin | 2 | % |  | 2 | % |  |  |  |  |
| Corporate Expenses | 13,150 |  |  | $ | 12,638 |  |  | 512 |  |  | 4 | % |
| Total income from operations | $ | 12,424 |  |  | $ | 12,558 |  |  | $ | (134 | ) |  | (1 | )% |
| Total operating margin | 11 | % |  | 12 | % |  |  |  |  |

[0000926326-15-000028:mdna:92]
Research and Development. The increase in research and development expenses of $2.3 million for the three months ended June 30, 2015 in comparison to three months ended June 30, 2014 was primarily driven by an increase in research and development expenses of $2.5 million in our Automation and Analytics segment which was primarily attributable to a $0.8 million increase in head-count, $0.8 million increase in tools and equipment expenses and personnel related costs and a $0.6 million increase in consulting expenses. The increase in research and development expenses in our Automation and Analytics was partially offset by a decrease in our Medication Adherence segment research and development expenses of $0.3 million which was primarily driven by an increase in capitalized software costs due to the higher level of post-feasibility beta testing which therefore decreases our research and development expenses.

[0000926326-15-000028:mdna:93]
Selling, General and Administrative.  The increase in selling, general and administrative expenses for the three months ended June 30, 2015 in comparison to three months ended June 30, 2014 was primarily due to increases from our Automation and Analytics segment of $0.8 million, from our Medication Adherence segment of $1.4 million and increases in corporate expenses of $0.5 million. The increase in our Automation and Analytics segment was primarily attributable to the newly acquired companies Mach4 and Avantec by $1.0 million which was partially offset by decrease of $0.4 million in Group Purchasing Organization fees due to timing of collections and decrease in marketing expenses in international sales organization of $0.3 million. The increase from our Medication Adherence segment was the result of $1.0 million from the inclusion of Surgichem operations, with the remainder incurred from clinical studies and an increase in headcount specifically within our marketing and international departments.The increase in corporate expenses was primarily related to the investigation of a whistleblower claim of $0.4 million with the remainder to support the growing business.

[0000926326-15-000028:mdna:94]
Operating Income. Operating income from our Automation and Analytics segment increased $3.4 million due to a business combination gain recorded related to a step acquisition of Avantec which required that we re-measure our previously held 15% ownership interest to fair value and record the difference between the fair value and carrying value as a gain, offset by product and service revenues growing at a slower rate than cost of sales and operating expenses.

[0000926326-15-000028:mdna:95]
[same as prior period, unchanged from 0000926326-15-000018:mdna:85]

[0000926326-15-000028:mdna:96]
32

[0000926326-15-000028:mdna:97]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2015 |  | 2014 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 16,765 |  |  | $ | 12,592 |  |  | $ | 4,173 |  |  | 33 | % |
| As a percentage of total revenues | 7 | % |  | 6 | % |  |  |  |  |
| Selling, general and administrative | 83,022 |  |  | 75,431 |  |  | 7,591 |  |  | 10 | % |
| As a percentage of total revenues | 36 | % |  | 36 | % |  |  |  |  |
| Gain on business combination | (3,443 | ) |  | — |  |  | (3,443 | ) |  | 100 | % |
| As a percentage of total revenues | (2 | )% |  | — | % |  |  |  |  |
| Total operating expenses | $ | 96,344 |  |  | $ | 88,023 |  |  | $ | 8,321 |  |  | 9 | % |
| As a percentage of total revenues | 42 | % |  | 43 | % |  |  |  |  |
| Income from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 48,658 |  |  | $ | 44,123 |  |  | $ | 4,535 |  |  | 10 | % |
| Operating margin | 21 | % |  | 21 | % |  |  |  |  |
| Medication Adherence | 3,671 |  |  | 5,815 |  |  | (2,144 | ) |  | (37 | )% |
| Operating margin | 2 | % |  | 3 | % |  |  |  |  |
| Corporate Expenses | 29,526 |  |  | 27,426 |  |  | 2,100 |  |  | 8 | % |
| Total income from operations | $ | 22,803 |  |  | $ | 22,512 |  |  | $ | 291 |  |  | 1 | % |
| Total operating margin | 10 | % |  | 11 | % |  |  |  |  |

[0000926326-15-000028:mdna:98]
Research and Development. The increase in research and development expenses of $4.2 million for the six months ended June 30, 2015 in comparison to six months ended June 30, 2014 was primarily driven by increase in research and development expenses of $4.1 million in our Automation and Analytics which was primarily attributable to a $2.0 million increase in head-count, a $1.1 million increase in consulting expenses and $0.9 million increase in tools and equipment expenses. The research and development expenses remained flat for Medication Adherence segment.

[0000926326-15-000028:mdna:99]
[same as prior period, unchanged from 0000926326-15-000018:mdna:81]

[0000926326-15-000028:mdna:100]
Selling, General and Administrative. The increase in selling, general and administrative expenses for the six months ended June 30, 2015 in comparison to six months ended June 30, 2014 was primarily due to increases from our Automation and Analytics segment of $2.7 million, from our Medication Adherence segment of $2.8 million and increases in corporate expenses of $2.2 million. The increase in our Automation and Analytics segment was primarily attributable to the newly acquired companies Mach4 and Avantec by $1.0 million and $1.8 million in employee-related expenses due to increased staffing and higher year over year benefit costs. The increase from our Medication Adherence segment was the result of $2.0 million from the inclusion of Surgichem operations, with the remainder attributed to an increase in headcount specifically within our marketing and international departments. The increase in corporate expenses was primarily related to the investigation of a whistleblower claim of $1.9 million with the remainder to support the growing business.

[0000926326-15-000028:mdna:101]
[same as prior period, unchanged from 0000926326-15-000018:mdna:83]

[0000926326-15-000028:mdna:102]
Operating Income. Operating income from our Automation and Analytics segment increased for the six months ended June 30, 2015 relative to the six months ended June 30, 2014 due to increased sales at consistent operating margins.

[0000926326-15-000028:mdna:103]
Operating income from our Medication Adherence segment decreased due to production inefficiencies and higher operating expenses.

[0000926326-15-000028:mdna:104]
[same as prior period, unchanged from 0000926326-15-000018:mdna:86]

[0000926326-15-000028:mdna:105]
33

[0000926326-15-000028:mdna:106]
|  | Three Months Ended |
|  |  |  |  |  | Change in |
|  | June 30, 2015 |  | June 30, 2014 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 3,201 |  |  | $ | 4,729 |  |  | $ | (1,528 | ) |  | (32 | )% |

[0000926326-15-000028:mdna:107]
|  | Six Months Ended |
|  |  |  |  |  | Change in |
|  | June 30, 2015 |  | June 30, 2014 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 6,745 |  |  | $ | 8,233 |  |  | $ | (1,488 | ) |  | (18 | )% |
| Effective tax rate on earnings | 38 | % |  | 39 | % |  |  |  |  |

[0000926326-15-000028:mdna:108]
Our annual effective tax rate before discrete items was 38.5% and 39.2% for the six months ended June 30, 2015 and June 30, 2014, respectively. The decrease in the estimated annual effective tax rate for the six months ended June 30, 2015 compared to the same period in 2014 was primarily due to the decrease in the state effective tax rate, offset by an increase in non-deductible equity charges and non-deductible transaction costs.

[0000926326-15-000028:mdna:109]
[same as prior period, unchanged from 0000926326-15-000018:mdna:90]

[0000926326-15-000028:mdna:110]
[same as prior period, unchanged from 0000926326-15-000018:mdna:91]

[0000926326-15-000028:mdna:111]
We had cash and cash equivalents of $88.0 million at June 30, 2015, compared to $125.9 million at December 31, 2014. All of our cash and cash equivalents are invested in demand deposits and money market funds.

[0000926326-15-000028:mdna:112]
Our cash position and working capital at June 30, 2015 and December 31, 2014 were as follows:

[0000926326-15-000028:mdna:113]
|  | June 30, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Cash | $ | 27,925 |  |  | $ | 61,311 |  |
| Cash equivalents | 60,103 |  |  | 64,577 |  |
| Total | $ | 88,028 |  |  | $ | 125,888 |  |
| Working Capital | $ | 147,049 |  |  | $ | 171,054 |  |

[0000926326-15-000028:mdna:114]
Our ratio of current assets to current liabilities was 2.1:1 at June 30, 2015 compared to 2.5:1 at December 31, 2014.

[0000926326-15-000028:mdna:115]
We maintain a Credit Agreement with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time which provides for a $75 million revolving credit facility to be used for general corporate purposes, including future acquisitions. The Credit Agreement permits us to request one or more increases in the aggregate commitment provided such increases do not exceed $25 million in the aggregate.

[0000926326-15-000028:mdna:116]
On November 5, 2014, we entered into Amendment Number One (the “Amendment”) to the Credit Agreement. The Amendment increases the amount of our common stock that may be repurchased by us in open market transactions authorized by our Board of Directors, together with any repurchases of our common stock from any consultants, employees, officers or directors of the Company or any of our subsidiaries following the death, disability, retirement or termination of employment of such employees, officers or directors, from $25 million to $50 million per year. The Credit Agreement contains customary affirmative and negative covenants, and financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each quarter.

[0000926326-15-000028:mdna:117]
As of June 30, 2015, we were in full compliance with all covenants, and there was no outstanding balance on the credit facility.

[0000926326-15-000028:mdna:118]
[same as prior period, unchanged from 0000926326-15-000018:mdna:95]

[0000926326-15-000028:mdna:119]
Our future uses of cash are expected to be primarily for working capital, capital expenditures and other contractual obligations. We also expect the continued use of cash for potential acquisition and acquisition assessment activities.

[0000926326-15-000028:mdna:120]
Our 2014 Stock Repurchase Program has a total of $29.9 million remaining for future repurchases as of June 30, 2015, which may result in additional use of cash. See Note 12, Stock Repurchases, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. In accordance with the Avantec share purchase agreement, we may pay out potential earn-out payments of $3.0 million payable after December 31, 2015 and an additional $3.0 million payable after December 31, 2016, based on future bookings. The fair value of these earn-out payments as of the acquisition date was $5.6 million. Pursuant to the terms of the agreement we also held back an amount of $1.8 million from the purchase consideration towards any future indemnification claims that we may make at the end of the 18-month period. Additional charges to the purchase price based on actual working capital at the time of acquisition generated a payable to the former owners of Avantec on June 30, 2015 of additional $1.8 million.

[0000926326-15-000028:mdna:121]
Based on our current business plan and revenue backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under our $75 million credit agreement, will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-15-000028:mdna:122]
[same as prior period, unchanged from 0000926326-15-000018:mdna:99]

[0000926326-15-000028:mdna:123]
[same as prior period, unchanged from 0000926326-15-000018:mdna:100]

[0000926326-15-000028:mdna:124]
|  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 10,190 |  |  | $ | 25,421 |  |
| Investing activities | (33,741 | ) |  | (13,033 | ) |
| Financing activities | (14,476 | ) |  | 9,341 |  |
| Effect of exchange rate changes on cash and cash equivalents | 167 |  |  | 119 |  |
| Net increase (decrease) in cash and cash equivalents | $ | (37,860 | ) |  | $ | 21,848 |  |

[0000926326-15-000028:mdna:125]
[same as prior period, unchanged from 0000926326-15-000018:mdna:102]

[0000926326-15-000028:mdna:126]
[same as prior period, unchanged from 0000926326-15-000018:mdna:103]

[0000926326-15-000028:mdna:127]
Net cash provided by operating activities was $10.2 million for the six months ended June 30, 2015, primarily as a result of $15.1 million in net income adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $12.0 million, share-based compensation expense, net of tax of $7.2 million and $3.4 million from our investment gain. This was offset by $19.6 million cash outflow from changes in assets and liabilities resulting primarily from an increase in accounts receivable of $27.7 million, due to increased product shipments late in the quarter, an increase in inventories of $9.6 million to support forecasted sales and from the acquisition of Mach4 and Avantec, a decrease in deferred service revenue of $2.9 million primarily due to the timing of service contracts renewals and a slight decrease in product sales and $1.7 million decrease in accrued compensation due to lower sales commissions. These amounts were partially offset by a decrease in the prepaid expenses of $8.2 million primarily due to commissions driven by higher bookings in the fourth quarter of 2014 compared to the current year to date period, an increase in deferred gross profit of $6.0 million due to timing of orders, shipments, and revenue being recognized for installed product, an increase in accrued liabilities of $5.8 million due to potential earn-out and contingent payments related to the Avantec Acquisition, a $1.4 million increase trade accounts payable due to growth in our business activities and a decrease in other assets of $1.5 million.

[0000926326-15-000028:mdna:128]
During the six months ended June 30, 2014, cash provided by operating activities consisted of net income of $14.0 million and non-cash charges of $16.3 million, offset by a $4.9 million decrease in net operating assets and liabilities. Our non-cash charges consisted primarily of depreciation and amortization of $9.4 million, stock-based compensation expense of $5.4

[0000926326-15-000028:mdna:129]
35

[0000926326-15-000028:mdna:130]
million, income tax benefits from employee stock plans of $3.1 million and deferred income taxes of $0.9 million, offset by $3.3 million in excess tax benefits from employee stock plans. The main attributes in the change in our net operating assets and liabilities were a $24.4 million increase in accounts receivable due to increased billing primarily from increased shipments of medication and supply cabinets, a $3.9 million decrease in accrued compensation primarily due to lower accrued commissions due to higher bookings in the fourth quarter of 2013 compared to the current year to date period, offset by a $10.8 million increase in deferred gross profit due to increase in products shipped but not yet installed, $2.6 million increase in deferred service revenues primarily due to increase in new third-party leases generated and billed, a $2.4 million increase primarily in trade accounts payable due to growth in our business activities, a $2.4 million increase in accrued liabilities due to growth in business activities, a $2.1 million decrease in prepaid expenses primarily due to decrease in commissions driven by higher bookings in the fourth quarter of 2013 compared to the June 30, 2014 year to date period, a $1.6 million decrease in other current assets and a $0.8 million increase in other long-term tax liabilities.

[0000926326-15-000028:mdna:131]
[same as prior period, unchanged from 0000926326-15-000018:mdna:106]

[0000926326-15-000028:mdna:132]
Net cash used in investing activities was $33.7 million for the six months ended June 30, 2015, primarily attributable to the acquisitions of Mach4 and Avantec in the amount of $23.7 million, purchases of property and equipment of $3.8 million and $6.1 million, respectively, for development of software for external use.

[0000926326-15-000028:mdna:133]
Net cash used in investing activities for the six months ended June 30, 2014 consisted primarily of $7.3 million for purchases of property and equipment, primarily for software license and software upgrades, and $5.5 million expended for capitalized software development costs.

[0000926326-15-000028:mdna:134]
[same as prior period, unchanged from 0000926326-15-000018:mdna:109]

[0000926326-15-000028:mdna:135]
Net cash used by financing activities was $14.5 million for the six months ended June 30, 2015 as a result of $25.0 million in cash used for stock repurchases under our 2012 and 2014 Stock Repurchase Programs and $2.0 million in employees' taxes paid related to restricted stock units, partially offset by $9.4 million in proceeds from employee stock option exercises and employee stock plan purchases and $3.1 million in excess tax benefits from employee stock plans.

[0000926326-15-000028:mdna:136]
Net cash provided by financing activities during the six months ended June 30, 2014 consisted of $11.8 million in proceeds from employee stock option exercises and employee stock plan purchases and $3.3 million in excess tax benefits from employee stock plans, offset by $4.1 million in cash used for stock repurchases under our 2012 Stock Repurchase Program and $1.7 million in employee taxes paid related to restricted stock units.

[0000926326-15-000028:mdna:137]
[same as prior period, unchanged from 0000926326-15-000018:mdna:112]

[0000926326-15-000028:mdna:138]
There have been no significant changes during the six months ended June 30, 2015 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2014.

[0000926326-15-000028:mdna:139]
We had $67.4 million in contractual commitments to third parties for non-cancelable operating leases, commitments to contract manufacturers and suppliers and other purchase commitments as of June 30, 2015 as follows:

[0000926326-15-000028:mdna:140]
|  | Payments Due by Period |
|  | Total |  | Remainder of 2015 |  | 2016 and 2017 |  | 2018 and 2019 |  | 2020 and Thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 42,150 |  |  | $ | 3,421 |  |  | $ | 12,457 |  |  | $ | 10,977 |  |  | $ | 15,295 |  |
| Purchase obligations (2) | 25,227 |  |  | 25,227 |  |  | — |  |  | — |  |  | — |  |
| Total (3) | $ | 67,377 |  |  | $ | 28,648 |  |  | $ | 12,457 |  |  | $ | 10,977 |  |  | $ | 15,295 |  |

[0000926326-15-000028:mdna:141]
[same as prior period, unchanged from 0000926326-15-000018:mdna:116]

[0000926326-15-000028:mdna:142]
[same as prior period, unchanged from 0000926326-15-000018:mdna:117]

[0000926326-15-000028:mdna:143]
[same as prior period, unchanged from 0000926326-15-000018:mdna:118]

[0000926326-15-000028:mdna:144]
36

[0000926326-15-000028:mdna:145]
| (3) | We have recorded $7.0 million for uncertain tax positions under long-term liabilities as of June 30, 2015 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, $7.0 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-15-000028:mdna:146]
See Note 9, Commitments, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-15-000028:mdna:147]
[same as prior period, unchanged from 0000926326-15-000018:mdna:121]

[0000926326-15-000028:mdna:148]
As of June 30, 2015, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
