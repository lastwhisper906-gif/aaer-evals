# OMCL note change history — 0000926326-15-000018 → 0000926326-15-000028


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-08-07):
[0000926326-15-000028:note_history:1]
Organization and Summary of Significant Accounting Policies
  (was, 2015-05-08, similarity 0.8317):
[0000926326-15-000018:note_history:1]
Summary of Significant Accounting Policies

- changed (2015-08-07):
[0000926326-15-000028:note_history:2]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2015 and December 31, 2014, the results of their operations, comprehensive income and cash flows for the three and six months ended June 30, 2015 and June 30, 2014. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in our annual report on Form 10-K for the year ended December 31, 2014. Our results of operations, comprehensive income and cash flows for the three and six months ended June 30, 2015 are not necessarily indicative of results that may be expected for the year ending December 31, 2015, or for any future period.
  (was, 2015-05-08, similarity 0.8549):
[0000926326-15-000018:note_history:2]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2015 and December 31, 2014, the results of their operations, comprehensive income and cash flows for the three months ended March 31, 2015 and March 31, 2014. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in our annual report on Form 10-K for the year ended December 31, 2014. Our results of operations, comprehensive income and cash flows for the three months ended March 31, 2015 are not necessarily indicative of results that may be expected for the year ending December 31, 2015, or for any future period.

- added (2015-08-07):
[0000926326-15-000028:note_history:3]
On April 21, 2015, we completed the acquisition of Mach4 Automatisierungstechnik GmbH (“Mach4”), a privately held German limited liability company with registered office in Bochum, Germany. On April 30, 2015, we acquired the 85% of the issued and outstanding ordinary shares of Avantec Healthcare Limited (“Avantec”) not already held by Omnicell. Omnicell previously had a 15% interest in Avantec. The consolidated financial statements include the results of operations of Mach4 and Avantec commencing as of their respective acquisition dates.

- changed (2015-08-07):
[0000926326-15-000028:note_history:4]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in our Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, accounts receivable and notes receivable (net investment in sales-type leases), valuation of goodwill, purchased intangibles and long-lived assets, and accounting for income taxes.
  (was, 2015-05-08, similarity 0.8862):
[0000926326-15-000018:note_history:4]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in our Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, valuation of goodwill, purchased intangibles and long-lived assets, and accounting for income taxes.

- added (2015-08-07):
[0000926326-15-000028:note_history:5]
As previously disclosed, since the first quarter of 2015, we modified the segment presentation to reflect the changes in how our Chief Operating Decision Maker (“CODM”) reviews the segments and the overall business. This change does not impact previously reported Condensed Consolidated Financial Statements. See Note 14, Segment Information, for additional information on our segment reporting change.

- added (2015-08-07):
[0000926326-15-000028:note_history:6]
Our CODM is our Chief Executive Officer. With the increase in completed acquisitions in the last two years, our CODM changed how the financial information was reviewed to exclude general corporate-level costs that are not specific to either of the reporting segments when evaluating the operating results of each segment. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

- changed (2015-08-07):
[0000926326-15-000028:note_history:7]
The historical information presented has been retrospectively adjusted to reflect the modified segment reporting. Our CODM allocates resources and evaluates the performance of our segments using information about its revenues, gross profit and income from operations, excluding certain costs which are managed separately at the corporate level. We enhanced our segment reporting structure to match our operating structure based on how our CODM views the business and allocates resources, beginning in the first quarter of 2015.
  (was, 2015-05-08, similarity 0.7258):
[0000926326-15-000018:note_history:7]
The historical information presented has been retrospectively adjusted to reflect the modified segment reporting. Our CODM allocates resources and evaluates the performance of our segments using information about its revenues, gross profit and income from operations, excluding certain costs which are managed separately at the corporate level. We enhanced our segment reporting structure to match our operating structure based on how our Chief Operating Decision Maker (“CODM”) views the business and allocates resources, beginning in the first quarter of 2015. Our CODM is our Chief Executive Officer. Retrospective adjustments of prior period financial information have been made to conform to the current period presentation. This change does not impact previously reported Condensed Consolidated Financial Statements. See Note 15, Segment Information, for additional information on our segment reporting change.

- changed (2015-08-07):
[0000926326-15-000028:note_history:8]
Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there were no customers that accounted for more than 10% of our accounts receivable as of June 30, 2015 and December 31, 2014. We believe that we have no significant concentrations of credit risk as of June 30, 2015.
  (was, 2015-05-08, similarity 0.9895):
[0000926326-15-000018:note_history:8]
Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there were no customers that accounted for more than 10% of our accounts receivable as of March 31, 2015 and December 31, 2014. We believe that we have no significant concentrations of credit risk as of March 31, 2015.

- changed (2015-08-07):
[0000926326-15-000028:note_history:9]
There have been no material changes in our significant accounting policies for the three and six months ended June 30, 2015, as compared to the significant accounting policies described in our annual report on Form 10-K for the year ended December 31, 2014.
  (was, 2015-05-08, similarity 0.9106):
[0000926326-15-000018:note_history:9]
There have been no material changes in our significant accounting policies for the three months ended March 31, 2015, as compared to the significant accounting policies described in our annual report on Form 10-K for the year ended December 31, 2014.

- added (2015-08-07):
[0000926326-15-000028:note_history:10]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers, which provides new guidance on the recognition of revenue and states that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This standard will be effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. Early application is not permitted, however, in July 2015, the FASB voted to approve deferring the effective date by one year (i.e., interim and annual reporting periods beginning after December 15, 2017). Early adoption is permitted, but not before the original effective date (i.e., interim and annual reporting periods beginning after December 15, 2016). For financial reporting purposes, the standard allows for either full retrospective adoption, meaning the standard is applied to all of the periods presented, or modified retrospective adoption, meaning the standard is applied only to the most current period presented in the financial statements with the cumulative effect of initially applying the standard recognized at the date of initial application. We are currently evaluating the impact of the adoption of this accounting standard update on our consolidated financial position or results of operations.

- removed (2015-08-07):
[0000926326-15-000018:note_history:11]
In the first quarter of 2015, we modified the segment presentation to reflect the changes in how our Chief Operating Decision Maker (“CODM”) reviews the segments and the overall business. With the increase in acquisitions in the last two years the CODM changed how the financial information was reviewed to exclude general corporate-level costs that are not specific to either of the reporting segments when evaluating the operating results of each segment. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

- removed (2015-08-07):
[0000926326-15-000018:note_history:12]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers, which provides new guidance on the recognition of revenue and states that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This standard will be effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. Early application is not permitted, however, in April 2015, the FASB tentatively proposed a one-year deferral of the effective date. If the proposed deferral is approved, the new standard will become effective for us in the first quarter of fiscal 2018. We are currently evaluating the impact of the adoption of this accounting standard update on our consolidated financial position or results of operations.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2015-08-07):
[0000926326-15-000018:note_history:13]
Credit Agreement

- removed (2015-08-07):
[0000926326-15-000018:note_history:14]
In September 2013, we entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time party thereto. The Credit Agreement provides for a $75 million revolving credit facility with a $10 million letter of credit sub-limit. Loans under the Credit Agreement mature on September 25, 2018. The Credit Agreement permits us to request one or more increases in the aggregate commitments provided that such increases do not exceed $25 million in the aggregate. We expect to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. Our obligations under the Credit Agreement are guaranteed by certain of our domestic subsidiaries and secured by substantially all of our and the subsidiary guarantors’ assets. We have not yet drawn any funds under the credit facility to date.

- removed (2015-08-07):
[0000926326-15-000018:note_history:15]
Amounts drawn under the Credit Agreement bear interest, at our election, at a Eurodollar rate plus a margin of 1.75% per annum, or an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.75%. We are required to pay a commitment fee of 0.25% per annum on the aggregate undrawn amount of the commitments under the credit facility.

- removed (2015-08-07):
[0000926326-15-000018:note_history:16]
On November 5, 2014, we entered into Amendment Number One (the “Amendment”) to the Credit Agreement. The Amendment increases the amount of our common stock that may be repurchased by us in open market transactions authorized by our Board of Directors, together with any repurchases of our common stock from any consultants, employees, officers or directors of the Company or any of our subsidiaries following the death, disability, retirement or termination of employment of such employees, officers or directors, from $25 million to $50 million per year.

- removed (2015-08-07):
[0000926326-15-000018:note_history:17]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each quarter. We were in full compliance with all covenants as of March 31, 2015.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2015-08-07):
[0000926326-15-000018:note_history:18]
Subsequent Events

- removed (2015-08-07):
[0000926326-15-000018:note_history:19]
On April 21, 2015, Omnicell International, Inc. (“Omnicell International”), a wholly-owned subsidiary of Omnicell, Inc., completed its acquisition of Mach 4 Automatisierungstechnik GmbH (“Mach4”) pursuant to the Agreement, dated February 26, 2015, by and among Apotheka Imedisa 2001 S.A., Holger Wallat, Dirk Rolf Beils and Peter Jansen (collectively, the “Selling Shareholders”) and Omnicell International (the “Share Purchase Agreement”). Pursuant to the Share Purchase Agreement, Omnicell International purchased the entire registered share capital of Mach4 from the Selling Shareholders for aggregate consideration of approximately $16.5 million, of which $2.7 million was placed in an escrow fund, which will ultimately be distributed to the Selling Shareholders (subject to claims that Omnicell International may have against the escrow fund for indemnification and other claims following the closing) (the “Acquisition”). In addition, Omnicell International will pay approximately $0.9 million to Mach4 for the payoff of existing debt of Mach4. The final purchase price remains subject to certain adjustments as provided for in the Share Purchase Agreement.

- removed (2015-08-07):
[0000926326-15-000018:note_history:20]
On April 30, 2015, we closed our acquisition of Avantec Healthcare Limited (“Avantec”) pursuant to  a share purchase agreement (the “Avantec Share Purchase Agreement”) among Omnicell, Inc. and the selling shareholders thereto (the “Avantec Selling Shareholders”) for the purchase of the entire issued share capital of Avantec not already owned by Omnicell, Inc. We previously owned 15% of the company and accounted for it under the equity method. Avantec develops medication and supply automation products that complement our solutions for configurations suited to the United Kingdom marketplace, and has been the exclusive distributor of our medication and supply automation solutions since 2005 in the United Kingdom. As a result of the Acquisition, we paid the Avantec Selling Shareholders an amount equal to $10.2 million in cash, subject to certain adjustments provided for in the Avantec Share Purchase Agreement, and retained an additional $1.8 million of the purchase price which will ultimately be distributed to the Avantec Selling Shareholders (subject to claims that we may have against such funds for indemnification and other claims following the closing). In addition, the Avantec Selling Shareholders will be entitled to receive up to an additional $3.0 million upon the achievement of bookings milestones for 2015 and an additional $3.0 million upon the achievement of bookings milestones for 2016.

- removed (2015-08-07):
[0000926326-15-000018:note_history:21]
Both of these acquired companies will be in our Automation and Analytics segment. The valuations and related purchase price allocations for these acquisitions have not yet been completed.
