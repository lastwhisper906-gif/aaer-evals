# OMCL notes — 0000926326-15-000028


## omcl:ScheduleofLongTermNetInvestmentinSaleTypeLeasesTableTextBlock

[0000926326-15-000028:notes:1]
Net investment in sales-type leases consists of the following components:

[0000926326-15-000028:notes:2]
|  | June 30, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 16,674 |  |  | $ | 17,616 |  |
| Less: unearned interest income portion | (1,118 | ) |  | (1,131 | ) |
| Net investment in sales-type leases | 15,556 |  |  | 16,485 |  |
| Less: short-term portion | (5,348 | ) |  | (5,637 | ) |
| Long-term net investment in sales-type leases | $ | 10,208 |  |  | $ | 10,848 |  |


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-15-000028:notes:3]
We had the following ordinary shares reserved for future issuance under its equity incentive plans as of June 30, 2015:

[0000926326-15-000028:notes:4]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 2,463 |  |
| Restricted share awards outstanding | 559 |  |
| Shares authorized for future issuance | 4,637 |  |
| ESPP shares available for future issuance | 3,393 |  |
| Total shares reserved for future issuance as of June 30, 2015 | 11,052 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-15-000028:notes:5]
[same as prior period, unchanged from 0000926326-15-000018:notes:6]

[0000926326-15-000028:notes:6]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2015 and December 31, 2014, the results of their operations, comprehensive income and cash flows for the three and six months ended June 30, 2015 and June 30, 2014. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in our annual report on Form 10-K for the year ended December 31, 2014. Our results of operations, comprehensive income and cash flows for the three and six months ended June 30, 2015 are not necessarily indicative of results that may be expected for the year ending December 31, 2015, or for any future period.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000926326-15-000028:notes:7]
As a result, actual results will differ from the unaudited pro forma information presented (in thousands, except per share data):

[0000926326-15-000028:notes:8]
|  | Six Months Ended June 30, |
|  | 2015 |  | 2014 |
|  | (In thousands, except per share data) |
| Pro forma net revenues | $ | 236,000 |  |  | $ | 220,000 |  |
| Pro forma net income | $ | 15,700 |  |  | $ | 14,400 |  |
| Pro forma net income per share basic | $ | 0.44 |  |  | $ | 0.41 |  |
| Pro forma net income per share diluted | $ | 0.42 |  |  | $ | 0.39 |  |


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-15-000028:notes:9]
[same as prior period, unchanged from 0000926326-15-000018:notes:8]

[0000926326-15-000028:notes:10]
The terms of our sales-type leases are generally up to five years in length. Sales-type lease receivables are collateralized by the underlying equipment. Net investment in sales-type leases consists of the following components:

[0000926326-15-000028:notes:11]
We evaluate our sales-type leases individually and collectively for impairment, and recorded no collective allowance for credit losses as of June 30, 2015 and $0.2 million as of December 31, 2014.

[0000926326-15-000028:notes:12]
[same as prior period, unchanged from 0000926326-15-000018:notes:11]

[0000926326-15-000028:notes:13]
|  | June 30, 2015 |
|  | (In thousands) |
| Remainder of 2015 | $ | 3,147 |  |
| 2016 | 5,308 |  |
| 2017 | 4,281 |  |
| 2018 | 2,652 |  |
| 2019 | 1,054 |  |
| Thereafter | 232 |  |
| Total | $ | 16,674 |  |


## us-gaap:CommitmentsDisclosureTextBlock

[0000926326-15-000028:notes:14]
[same as prior period, unchanged from 0000926326-15-000018:notes:13]

[0000926326-15-000028:notes:15]
[same as prior period, unchanged from 0000926326-15-000018:notes:14]

[0000926326-15-000028:notes:16]
[same as prior period, unchanged from 0000926326-15-000018:notes:15]

[0000926326-15-000028:notes:17]
[same as prior period, unchanged from 0000926326-15-000018:notes:16]

[0000926326-15-000028:notes:18]
|  | June 30, 2015 |
|  | (In thousands) |
| Remainder of 2015 | $ | 3,421 |  |
| 2016 | 6,557 |  |
| 2017 | 5,900 |  |
| 2018 | 5,487 |  |
| 2019 | 5,490 |  |
| Thereafter | 15,295 |  |
| Total minimum future lease payments | $ | 42,150 |  |

[0000926326-15-000028:notes:19]
[same as prior period, unchanged from 0000926326-15-000018:notes:18]

[0000926326-15-000028:notes:20]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. Our purchase obligations to our contract manufacturers and suppliers within the next year were $25.2 million as of June 30, 2015.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-15-000028:notes:21]
[same as prior period, unchanged from 0000926326-15-000018:notes:20]

[0000926326-15-000028:notes:22]
[same as prior period, unchanged from 0000926326-15-000018:notes:21]

[0000926326-15-000028:notes:23]
On April 21, 2015, we completed the acquisition of Mach4 Automatisierungstechnik GmbH (“Mach4”), a privately held German limited liability company with registered office in Bochum, Germany. On April 30, 2015, we acquired the 85% of the issued and outstanding ordinary shares of Avantec Healthcare Limited (“Avantec”) not already held by Omnicell. Omnicell previously had a 15% interest in Avantec. The consolidated financial statements include the results of operations of Mach4 and Avantec commencing as of their respective acquisition dates.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000926326-15-000028:notes:24]
[same as prior period, unchanged from 0000926326-15-000018:notes:27]

[0000926326-15-000028:notes:25]
|  | June 30, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Sales of medication and supply dispensing systems including packaging equipment (1) | $ | 55,304 |  |  | $ | 36,947 |  |
| Less: cost of revenues, excluding installation costs | (18,633 | ) |  | (8,389 | ) |
| Total deferred gross profit | $ | 36,671 |  |  | $ | 28,558 |  |

[0000926326-15-000028:notes:26]
[same as prior period, unchanged from 0000926326-15-000018:notes:29]

[0000926326-15-000028:notes:27]
[same as prior period, unchanged from 0000926326-15-000018:notes:30]


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-15-000028:notes:28]
[same as prior period, unchanged from 0000926326-15-000018:notes:31]


## us-gaap:EarningsPerShareTextBlock

[0000926326-15-000028:notes:29]
[same as prior period, unchanged from 0000926326-15-000018:notes:32]

[0000926326-15-000028:notes:30]
[same as prior period, unchanged from 0000926326-15-000018:notes:33]

[0000926326-15-000028:notes:31]
[same as prior period, unchanged from 0000926326-15-000018:notes:34]

[0000926326-15-000028:notes:32]
|  | Three months ended June 30, | Six months ended June 30, |
|  | 2015 |  | 2014 | 2015 |  | 2014 |
|  | (In thousands, except per share data) |
| Net income | $ | 8,751 |  |  | $ | 7,789 |  | $ | 15,069 |  |  | $ | 13,983 |  |
| Weighted-average shares outstanding — basic | 36,120 |  |  | 35,661 |  | 36,072 |  |  | 35,451 |  |
| Dilutive effect of employee stock plans | 910 |  |  | 957 |  | 915 |  |  | 1,027 |  |
| Weighted-average shares outstanding — diluted | 37,030 |  |  | 36,618 |  | 36,987 |  |  | 36,478 |  |
| Net income per share — basic | $ | 0.24 |  |  | $ | 0.22 |  | $ | 0.42 |  |  | $ | 0.39 |  |
| Net income per share — diluted | $ | 0.24 |  |  | $ | 0.21 |  | $ | 0.41 |  |  | $ | 0.38 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 377 |  |  | 353 |  | 356 |  |  | 1,347 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-15-000028:notes:33]
The following table represents the fair value hierarchy of the Company’s financial assets measured at fair value as of June 30, 2015:

[0000926326-15-000028:notes:34]
|  | Level 1 |  | Level 2 |  | Total |
|  | (In thousands) |
| Money market funds | $ | 60,103 |  |  | $ | — |  |  | $ | 60,103 |  |
| Total financial assets | $ | 60,103 |  |  | $ | — |  |  | $ | 60,103 |  |
| Derivative contracts | $ | — |  |  | $ | 92 |  |  | $ | 92 |  |
| Total financial liabilities | $ | — |  |  | $ | 92 |  |  | $ | 92 |  |

[0000926326-15-000028:notes:35]
The following table represents the fair value hierarchy of the Company’s financial asset measured at fair value as of December 31, 2014:

[0000926326-15-000028:notes:36]
|  | Level 1 |  | Level 2 |  | Total |
|  | (In thousands) |
| Money market fund | $ | 64,577 |  |  | $ | — |  |  | $ | 64,577 |  |
| Total financial assets | $ | 64,577 |  |  | $ | — |  |  | $ | 64,577 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000926326-15-000028:notes:37]
[same as prior period, unchanged from 0000926326-15-000018:notes:36]

[0000926326-15-000028:notes:38]
|  | June 30, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Cash | $ | 27,925 |  |  | $ | 61,311 |  |
| Money market fund | 60,103 |  |  | 64,577 |  |
| Total cash and cash equivalents | $ | 88,028 |  |  | $ | 125,888 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-15-000028:notes:39]
Cash and Cash Equivalents and Fair Value of Financial Instruments

[0000926326-15-000028:notes:40]
Cash and cash equivalents as of June 30, 2015 and December 31, 2014 includes the following significant asset investment class:

[0000926326-15-000028:notes:41]
Cash equivalents. Cash equivalents consist of money market funds which have original maturities of three months or less, and therefore the carrying amount is a reasonable estimate of fair value due to the short duration to maturity.

[0000926326-15-000028:notes:42]
Fair value hierarchy

[0000926326-15-000028:notes:43]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1. Cash equivalents are valued primarily using quoted market prices utilizing market observable inputs. In addition, foreign currency contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments. The Level 3 valuation inputs include the Company’s best estimate of what market participants would use in pricing the asset or liability at the measurement date. The inputs are unobservable in the market and significant to the instrument’s valuation. We did not hold any Level 3 assets or liabilities as of June 30, 2015 and December 31, 2014. There have been no transfers between fair value measurement levels during the three and six months ended June 30, 2015.

[0000926326-15-000028:notes:44]
[same as prior period, unchanged from 0000926326-15-000018:notes:46]

[0000926326-15-000028:notes:45]
[same as prior period, unchanged from 0000926326-15-000018:notes:47]

[0000926326-15-000028:notes:46]
[same as prior period, unchanged from 0000926326-15-000018:notes:48]

[0000926326-15-000028:notes:47]
The aggregate notional amounts of our outstanding foreign exchange contracts as of June 30, 2015 were $2.2 million. The aggregate fair value of these outstanding foreign exchange contracts as of June 30, 2015 were $0.1 million. We did not have any outstanding foreign exchange contracts as of December 31, 2014.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-15-000028:notes:48]
[same as prior period, unchanged from 0000926326-15-000018:notes:50]

[0000926326-15-000028:notes:49]
[same as prior period, unchanged from 0000926326-15-000018:notes:51]

[0000926326-15-000028:notes:50]
[same as prior period, unchanged from 0000926326-15-000018:notes:52]

[0000926326-15-000028:notes:51]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2014 | $ | 28,543 |  |  | $ | 94,177 |  |  | $ | 122,720 |  |
| Goodwill acquired - Mach4 | 10,520 |  |  | — |  |  | 10,520 |  |
| Goodwill acquired - Avantec | 15,606 |  |  | — |  |  | 15,606 |  |
| Foreign currency exchange rate fluctuations | 729 |  |  | 79 |  |  | 808 |  |
| Net balance as of June 30, 2015 | $ | 55,398 |  |  | $ | 94,256 |  |  | $ | 149,654 |  |

[0000926326-15-000028:notes:52]
[same as prior period, unchanged from 0000926326-15-000018:notes:54]

[0000926326-15-000028:notes:53]
The carrying amounts of intangibles as of June 30, 2015 are as follows:

[0000926326-15-000028:notes:54]
|  | June 30, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Foreign Currency Exchange Rate Fluctuations |  | Net CarryingAmount |  | Useful Life(Years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 69,554 |  |  | $ | (9,182 | ) |  | $ | (94 | ) |  | $ | 60,278 |  |  | 5 - 30 |
| Acquired technology | 30,870 |  |  | (4,967 | ) |  | 122 |  |  | 26,025 |  |  | 3 - 20 |
| Trade names | 8,052 |  |  | (2,012 | ) |  | 2 |  |  | 6,042 |  |  | 1 - 12 |
| Patents | 1,879 |  |  | (320 | ) |  | — |  |  | 1,559 |  |  | 2 - 20 |
| Backlog | 415 |  |  | (42 | ) |  | 8 |  |  | 381 |  |  | 1.7 |
| Total intangibles assets, net | $ | 110,770 |  |  | $ | (16,523 | ) |  | $ | 38 |  |  | $ | 94,285 |  |  |  |

[0000926326-15-000028:notes:55]
The carrying amounts of intangibles as of December 31, 2014 are as follows:

[0000926326-15-000028:notes:56]
|  | December 31, 2014 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Foreign currency exchange rate fluctuations |  | Net CarryingAmount |  | Useful Life(Years) |
| Customer relationships | $ | 60,150 |  |  | $ | (7,596 | ) |  | $ | (323 | ) |  | $ | 52,231 |  |  | 5 - 30 |
| Acquired technology | 27,580 |  |  | (4,068 | ) |  | — |  |  | 23,512 |  |  | 3 - 20 |
| Trade names | 7,110 |  |  | (1,559 | ) |  | (17 | ) |  | 5,534 |  |  | 3 - 12 |
| Patents | 1,655 |  |  | (265 | ) |  | — |  |  | 1,390 |  |  | 2 - 20 |
| Total intangibles assets, net | $ | 96,495 |  |  | $ | (13,488 | ) |  | $ | (340 | ) |  | $ | 82,667 |  |  |  |

[0000926326-15-000028:notes:57]
Amortization expense of intangible assets was $1.8 million and $1.1 million for the three months ended June 30, 2015 and June 30, 2014, respectively, and $3.1 million and $2.2 million for the six months ended June 30, 2015 and June 30, 2014, respectively.

[0000926326-15-000028:notes:58]
The estimated future amortization expenses for intangible assets are as follows:

[0000926326-15-000028:notes:59]
|  | June 30, 2015 |
|  | (In thousands) |
| Remainder of 2015 | $ | 3,510 |  |
| 2016 | 6,599 |  |
| 2017 | 5,843 |  |
| 2018 | 5,463 |  |
| 2019 | 5,297 |  |
| Thereafter | 67,573 |  |
| Total | $ | 94,285 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-15-000028:notes:60]
[same as prior period, unchanged from 0000926326-15-000018:notes:60]

[0000926326-15-000028:notes:61]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 38.5% and 39.2% for the six months ended June 30, 2015 and June 30, 2014, respectively. The 2015 and 2014 annual effective tax rate differed from the statutory rate of 35.0% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.

[0000926326-15-000028:notes:62]
We recorded a gain of $3.4 million attributable to the increase in the fair value of Omnicell's 15% minority interest in Avantec which was revalued in conjunction with our purchase of the remaining 85% of Avantec shares. This gain was treated as a discrete item and excluded from profit-before-tax in calculating the annual effective tax rate for the six months ended June 30, 2015.

[0000926326-15-000028:notes:63]
The federal research and development credits law, which was extended through December 31, 2014, retroactively has not been extended to the end of 2015. As a result the annual effect tax rate for the six months ended June 30, 2015 and 2014 did not consider the effect of the federal research and development tax credit.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000926326-15-000028:notes:64]
Business Acquisitions

[0000926326-15-000028:notes:65]
Mach4 Acquisition

[0000926326-15-000028:notes:66]
On April 21, 2015, we completed the acquisition of Mach 4 Automatisierungstechnik GmbH (“Mach4”), a privately held German limited liability company with its registered office in Bochum, Germany pursuant to a share purchase agreement (the  “Mach4 Agreement”), under which Omnicell International, Inc., a wholly owned subsidiary of Omnicell Inc., purchased the entire issued share capital of Mach4 (the “Mach4 Acquisition”).

[0000926326-15-000028:notes:67]
Mach4 manufacturers robotic dispensing systems used by retail and hospital pharmacies and the Mach4 acquisition provides Omnicell with a more robust product offering that is intended to be leveraged to create opportunities to sell additional Omnicell medication cabinets. The robotic storage and dispensing  product offering provides Omnicell with a solution to better compete for international market share.

[0000926326-15-000028:notes:68]
Pursuant to the terms of the Mach4 Agreement, we paid approximately $17.2 million in cash after adjustments provided for in the Mach4 Agreement, of which $2.7 million was placed in an escrow fund, which will be distributed to Mach4's former stockholders subject to claims that we may make against the escrow fund with respect to indemnification and other claims within 18 months after the closing date of this transaction.

[0000926326-15-000028:notes:69]
Avantec Acquisition

[0000926326-15-000028:notes:70]
On April 30, 2015, we completed the acquisition of Avantec Healthcare Limited (“Avantec”), the privately-held distributor of Omnicell’s products in United Kingdom, pursuant to a share purchase agreement (the “Avantec Agreement”).  Pursuant to the Avantec Agreement, we acquired the entire issued and outstanding ordinary shares of Avantec that represented the remaining 85% interest in Avantec (the “Avantec Acquisition”). Omnicell previously had a 15% interest in Avantec. Avantec develops medication and supply automation products that complement our solutions for configurations suited to the United Kingdom marketplace, and has been the exclusive distributor of our medication and supply automation solutions since 2005 in the United Kingdom.

[0000926326-15-000028:notes:71]
Pursuant to the terms of the Avantec Agreement, we agreed to pay $12.0 million in cash (the “Purchase Consideration”) and potential earn-out payments of up to $3.0 million payable after December 31, 2015 and an additional $3.0 million payable after December 31, 2016, based on future bookings. The fair value of these potential earn-out payments as of the acquisition date was $5.6 million. Pursuant to the terms of the Avantec Agreement we retained $1.8 million of the Purchase Consideration to be held to settle any future indemnification claims within 18 months period that we may make following the closing.

[0000926326-15-000028:notes:72]
Prior to the Avantec Acquisition, we accounted for our 15% ownership interest in Avantec as an equity-method investment. The Avantec acquisition-date carrying book value of our previous equity interest was $1.3 million. This transaction was accounted for as a step acquisition, which required us to re-measure our previously held 15% ownership interest to fair value and record the difference between the fair value and carrying value as a gain. The fair value of the equity investment was determined to be $4.7 million that resulted in a gain of $3.4 million that was recorded in operating income in our Condensed Consolidated Statement of Operations in the period ended June 30, 2015.

[0000926326-15-000028:notes:73]
Both of the above acquired companies will be in the Company’s Automation and Analytics segment.

[0000926326-15-000028:notes:74]
We are accounting for both transactions under the acquisition method of accounting in accordance with the provisions of FASB Accounting Standards Codification ("ASC") Topic 805, Business Combinations.  Accordingly, the estimated fair value of the consideration transferred to purchase the acquired companies is allocated to the assets acquired and the liabilities assumed based on their respective fair values. We have made significant estimates and assumptions in determining the allocation of the acquisition consideration.

[0000926326-15-000028:notes:75]
The purchase price allocations are subject to certain post-closing working capital adjustments for the acquired current assets and current liabilities of both acquisitions at their respective acquisition dates. The total consideration, and the allocation of consideration to the individual net assets is preliminary, as there are remaining uncertainties to be resolved, including the settlement of the final net working capital adjustment for each.

[0000926326-15-000028:notes:76]
Our preliminary allocation of the total purchase price for each transaction is summarized below:

[0000926326-15-000028:notes:77]
|  | Mach4 |  | Avantec |  | Total |
|  | (In thousands) |
| Cash | $ | 397 |  |  | $ | 3,392 |  |  | $ | 3,789 |  |
| Accounts receivable | 3,743 |  |  | 3,607 |  |  | 7,350 |  |
| Inventory | 3,580 |  |  | 1,428 |  |  | 5,008 |  |
| Deferred tax assets and other current assets | 368 |  |  | 89 |  |  | 457 |  |
| Total current assets | 8,088 |  |  | 8,516 |  |  | 16,604 |  |
| Property and equipment | 463 |  |  | — |  |  | 463 |  |
| Intangibles | 7,710 |  |  | 6,341 |  |  | 14,051 |  |
| Goodwill | 10,520 |  |  | 15,606 |  |  | 26,126 |  |
| Other non-current assets | 52 |  |  | — |  |  | 52 |  |
| Total assets | 26,833 |  |  | 30,463 |  |  | 57,296 |  |
| Current liabilities | 3,684 |  |  | 4,125 |  |  | 7,809 |  |
| Non-current deferred tax liabilities | 2,564 |  |  | 1,269 |  |  | 3,833 |  |
| Deferred service revenue and gross profit | 2,314 |  |  | 928 |  |  | 3,242 |  |
| Other non-current liabilities | 1,056 |  |  | — |  |  | 1,056 |  |
| Total purchase price | $ | 17,215 |  |  | $ | 24,141 |  |  | $ | 41,356 |  |
| Total purchase price, net of cash received | $ | 16,818 |  |  | $ | 20,749 |  |  | $ | 37,567 |  |

[0000926326-15-000028:notes:78]
Identifiable intangible assets

[0000926326-15-000028:notes:79]
Intangible assets acquired and their respective estimated remaining useful lives over which each asset will be amortized are as follows:

[0000926326-15-000028:notes:80]
|  | Mach4 | Avantec |
|  | Fair Value |  | WeightedAverageUseful life | Fair Value |  | WeightedAverageUseful life |
|  | (In thousands) |  | (In years) | (In thousands) |  | (In years) |
| Developed Technology | $ | 3,290 |  |  | 8 | $ | — |  |  | — |
| Trade name | 850 |  |  | 6 | 92 |  |  | 2 |
| Customer relationships | 3,570 |  |  | 11-12 | 5,834 |  |  | 12 |
| Backlog | — |  |  | — | 415 |  |  | 2 |
| Total purchased intangible assets | $ | 7,710 |  |  |  | $ | 6,341 |  |  |  |

[0000926326-15-000028:notes:81]
Developed technology represents completed technology that has reached the technological feasibility and/or is currently offered for sale to Mach4 customers. The fair value is determined based on the relief from royalty method under the income approach, which requires the valuation specialist to estimate a reasonable royalty rate, identify relevant projected revenues and expenses, and select an appropriate discount rate. A royalty rate of 5.0% was used to value the developed technology. The after-tax cash flows were discounted to present value utilizing a 17.5% discount rate, which is based on the our company-wide required return for this acquisition plus a discount of 1.5% to account for the unique riskiness of the asset. The developed technology had a fair value of $3.3 million and had an estimated economic life of eight years based on estimated technological obsolescence and is being amortized on an accelerated basis.

[0000926326-15-000028:notes:82]
Trade name represents the fair value brand recognition that was determined using the relief-from-royalty approach. The fair value is determined based on the relief-from-royalty method under the income approach, which requires the valuation specialist to estimate a reasonable royalty rate, identify relevant projected revenues and expenses, and select an appropriate discount rate. A royalty rate of 1.0% and 2.0% was used to value the trade names of Avantec and Mach4, respectively. The value of trade names of $0.1 million for Avantec is being amortized on straight-line method and $0.9 million for Mach4 is being amortized on an accelerated basis.

[0000926326-15-000028:notes:83]
Customer relationships represent the fair value of future projected revenues that will be derived from the sale of products to existing customers of the acquired company. The fair value of the customer relationships is determined based on the excess earnings method under the income approach that resulted in a value of $3.6 million for Mach4 and $5.8 million for Avantec and has been amortized over their useful lives on accelerated basis.

[0000926326-15-000028:notes:84]
Backlog represents the fair value of sales order backlog as of the valuation date and its fair value is determined based on the excess earnings method under the income approach and is being amortized on straight-line method.

[0000926326-15-000028:notes:85]
The goodwill arising from these acquisitions is primarily attributed to sales of future products and services and the assembled workforce. Goodwill is not deductible for tax purposes. Goodwill is not being amortized but is reviewed annually for impairment or more frequently if impairment indicators arise, in accordance with authoritative guidance.

[0000926326-15-000028:notes:86]
The following table presents certain unaudited pro forma information for illustrative purposes only, for fiscal 2015 and fiscal 2014 as if Mach4 and Avantec had been acquired on January 1, 2014. The unaudited estimated pro forma information combines the historical results of Mach4 and Avantec with the Company’s consolidated historical results and includes certain adjustments reflecting the estimated impact of fair value adjustments for the respective periods. The pro forma information is not indicative of what would have occurred had the acquisitions taken place on January 1, 2014. Additionally, the pro forma financial information does not include the impact of possible business model changes between Mach4, Avantec and the Company. The Company expects to achieve further business synergies, as a result of the acquisitions that are not reflected in the pro forma amounts that follow. As a result, actual results will differ from the unaudited pro forma information presented (in thousands, except per share data):


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-15-000028:notes:87]
Recently issued authoritative guidance

[0000926326-15-000028:notes:88]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, Revenue from Contracts with Customers, which provides new guidance on the recognition of revenue and states that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. This standard will be effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. Early application is not permitted, however, in July 2015, the FASB voted to approve deferring the effective date by one year (i.e., interim and annual reporting periods beginning after December 15, 2017). Early adoption is permitted, but not before the original effective date (i.e., interim and annual reporting periods beginning after December 15, 2016). For financial reporting purposes, the standard allows for either full retrospective adoption, meaning the standard is applied to all of the periods presented, or modified retrospective adoption, meaning the standard is applied only to the most current period presented in the financial statements with the cumulative effect of initially applying the standard recognized at the date of initial application. We are currently evaluating the impact of the adoption of this accounting standard update on our consolidated financial position or results of operations.

[0000926326-15-000028:notes:89]
There was no other recently issued authoritative guidance that has a material impact on our Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0000926326-15-000028:notes:90]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards (RSAs) |  |  |  |
| Outstanding at December 31, 2014 | 36 |  |  | $ | 26.47 |  |
| Granted | 37 |  |  | 36.05 |  |
| Vested | (41 | ) |  | 26.47 |  |
| Forfeited | (1 | ) |  | 27.65 |  |
| Outstanding and unvested at June 30, 2015 | 31 |  |  | $ | 35.95 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-15-000028:notes:91]
Organization and Summary of Significant Accounting Policies

[0000926326-15-000028:notes:92]
[same as prior period, unchanged from 0000926326-15-000018:notes:72]

[0000926326-15-000028:notes:93]
[same as prior period, unchanged from 0000926326-15-000018:notes:73]

[0000926326-15-000028:notes:94]
[same as prior period, unchanged from 0000926326-15-000018:notes:74]

[0000926326-15-000028:notes:95]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in our Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, accounts receivable and notes receivable (net investment in sales-type leases), valuation of goodwill, purchased intangibles and long-lived assets, and accounting for income taxes.

[0000926326-15-000028:notes:96]
[same as prior period, unchanged from 0000926326-15-000018:notes:76]

[0000926326-15-000028:notes:97]
As previously disclosed, since the first quarter of 2015, we modified the segment presentation to reflect the changes in how our Chief Operating Decision Maker (“CODM”) reviews the segments and the overall business. This change does not impact previously reported Condensed Consolidated Financial Statements. See Note 14, Segment Information, for additional information on our segment reporting change.

[0000926326-15-000028:notes:98]
Our CODM is our Chief Executive Officer. With the increase in completed acquisitions in the last two years, our CODM changed how the financial information was reviewed to exclude general corporate-level costs that are not specific to either of the reporting segments when evaluating the operating results of each segment. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

[0000926326-15-000028:notes:99]
The historical information presented has been retrospectively adjusted to reflect the modified segment reporting. Our CODM allocates resources and evaluates the performance of our segments using information about its revenues, gross profit and income from operations, excluding certain costs which are managed separately at the corporate level. We enhanced our segment reporting structure to match our operating structure based on how our CODM views the business and allocates resources, beginning in the first quarter of 2015.

[0000926326-15-000028:notes:100]
[same as prior period, unchanged from 0000926326-15-000018:notes:79]

[0000926326-15-000028:notes:101]
Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there were no customers that accounted for more than 10% of our accounts receivable as of June 30, 2015 and December 31, 2014. We believe that we have no significant concentrations of credit risk as of June 30, 2015.

[0000926326-15-000028:notes:102]
[same as prior period, unchanged from 0000926326-15-000018:notes:81]

[0000926326-15-000028:notes:103]
There have been no material changes in our significant accounting policies for the three and six months ended June 30, 2015, as compared to the significant accounting policies described in our annual report on Form 10-K for the year ended December 31, 2014.


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-15-000028:notes:104]
|  | June 30, 2015 |  | December 31, 2014 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 10,725 |  |  | $ | 8,254 |  |
| Work in process | 2,554 |  |  | 64 |  |
| Finished goods | 32,748 |  |  | 23,236 |  |
| Total inventories, net | $ | 46,027 |  |  | $ | 31,554 |  |
| Property and Equipment: |  |  |  |
| Equipment | $ | 43,717 |  |  | $ | 42,829 |  |
| Furniture and fixtures | 5,895 |  |  | 5,689 |  |
| Leasehold improvements | 8,991 |  |  | 8,701 |  |
| Purchased software | 29,729 |  |  | 28,920 |  |
| Construction in progress | 3,982 |  |  | 1,538 |  |
|  | 92,314 |  |  | 87,677 |  |
| Accumulated depreciation and amortization | (57,542 | ) |  | (51,499 | ) |
| Total Property and equipment, net | $ | 34,772 |  |  | $ | 36,178 |  |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 23,066 |  |  | $ | 19,643 |  |
| Other assets | 2,316 |  |  | 3,630 |  |
| Total Other long term assets, net | $ | 25,382 |  |  | $ | 23,273 |  |
| Accrued liabilities: |  |  |  |
| Rebates and lease buyouts | $ | 7,253 |  |  | $ | 6,512 |  |
| Advance payments from customers | 7,840 |  |  | 4,834 |  |
| Group purchasing organization fees | 3,007 |  |  | 3,475 |  |
| Taxes payable | 3,488 |  |  | 2,181 |  |
| Other Accrued liabilities | 11,831 |  |  | 2,297 |  |
| Total Accrued liabilities | $ | 33,419 |  |  | $ | 19,299 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0000926326-15-000028:notes:105]
The following table sets forth the total share-based compensation expense recognized in our Condensed Consolidated Statements of Operations:

[0000926326-15-000028:notes:106]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 532 |  |  | $ | 264 |  |  | $ | 1,049 |  |  | $ | 532 |  |
| Research and development | 451 |  |  | 380 |  |  | 885 |  |  | 749 |  |
| Selling, general and administrative | 2,653 |  |  | 2,076 |  |  | 5,367 |  |  | 4,168 |  |
| Total share-based compensation expense | $ | 3,636 |  |  | $ | 2,720 |  |  | $ | 7,301 |  |  | $ | 5,449 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0000926326-15-000028:notes:107]
Restricted stock activity under the Company’s equity incentive plans in the six months ended June 30, 2015 is as follows:

[0000926326-15-000028:notes:108]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units (RSUs) |  |  |  |  |  |  |  |
| Outstanding at December 31, 2014 | 399 |  |  | $ | 24.00 |  |  | 1.5 |  |  |
| Granted | 65 |  |  | 34.19 |  |  |  |  |  |
| Vested | (77 | ) |  | 21.57 |  |  |  |  |  |
| Forfeited | (23 | ) |  | 22.35 |  |  |  |  |  |
| Outstanding and unvested at June 30, 2015 | 364 |  |  | $ | 26.45 |  |  | 1.3 |  | $ | 13,714 |  |
| Expected to vest at June 30, 2015 | 353 |  |  |  |  | 1.3 |  | $ | 13,329 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-15-000028:notes:109]
The following table summarizes the financial performance of our reportable segments, including a reconciliation of income from segment operations to income from total operations:

[0000926326-15-000028:notes:110]
|  | Three Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 88,701 |  |  | $ | 24,087 |  |  | $ | 112,788 |  |  | $ | 84,702 |  |  | $ | 20,350 |  |  | $ | 105,052 |  |
| Cost of revenues | 39,403 |  |  | 15,923 |  |  | 55,326 |  |  | 35,992 |  |  | 13,020 |  |  | 49,012 |  |
| Gross profit | 49,298 |  |  | 8,164 |  |  | 57,462 |  |  | 48,710 |  |  | 7,330 |  |  | 56,040 |  |
| Operating expenses | 25,978 |  |  | 5,910 |  |  | 31,888 |  |  | 26,044 |  |  | 4,800 |  |  | 30,844 |  |
| Income from segment operations | $ | 23,320 |  |  | $ | 2,254 |  |  | $ | 25,574 |  |  | $ | 22,666 |  |  | $ | 2,530 |  |  | $ | 25,196 |  |
| Corporate costs |  |  |  |  | 13,150 |  |  |  |  |  |  | 12,638 |  |
| Income from operations |  |  |  |  | $ | 12,424 |  |  |  |  |  |  | $ | 12,558 |  |

[0000926326-15-000028:notes:111]
|  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 181,480 |  |  | $ | 47,529 |  |  | $ | 229,009 |  |  | $ | 166,201 |  |  | $ | 40,615 |  |  | $ | 206,816 |  |
| Cost of revenues | 78,255 |  |  | 31,607 |  |  | 109,862 |  |  | 70,932 |  |  | 25,349 |  |  | 96,281 |  |
| Gross profit | 103,225 |  |  | 15,922 |  |  | 119,147 |  |  | 95,269 |  |  | 15,266 |  |  | 110,535 |  |
| Operating expenses | 54,567 |  |  | 12,251 |  |  | 66,818 |  |  | 51,146 |  |  | 9,451 |  |  | 60,597 |  |
| Income from segment operations | $ | 48,658 |  |  | $ | 3,671 |  |  | $ | 52,329 |  |  | $ | 44,123 |  |  | $ | 5,815 |  |  | $ | 49,938 |  |
| Corporate costs |  |  |  |  | 29,526 |  |  |  |  |  |  | 27,426 |  |
| Income from operations |  |  |  |  | $ | 22,803 |  |  |  |  |  |  | $ | 22,512 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000926326-15-000028:notes:112]
The following table summarizes the share option activity under the Company’s equity incentive plans during the six months ended June 30, 2015:

[0000926326-15-000028:notes:113]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value(1) |
|  | (In thousands, except per share data) |
| Stock Options |  |  |  |  |  |  |  |
| Outstanding at December 31, 2014 | 2,672 |  |  | $ | 19.02 |  |  | 6.5 |  |  |
| Granted | 200 |  |  | 34.10 |  |  |  |  |  |
| Exercised | (340 | ) |  | 15.54 |  |  |  |  |  |
| Expired | (2 | ) |  | 15.57 |  |  |  |  |  |
| Forfeited | (67 | ) |  | 23.30 |  |  |  |  |  |
| Outstanding at June 30, 2015 | 2,463 |  |  | $ | 20.60 |  |  | 6.5 |  | $ | 42,138 |  |
| Exercisable at June 30, 2015 | 1,425 |  |  | $ | 16.46 |  |  | 4.9 |  | $ | 30,277 |  |
| Vested and expected to vest at June 30, 2015 | 2,435 |  |  | $ | 20.50 |  |  | 6.4 |  | $ | 41,919 |  |

[0000926326-15-000028:notes:114]
[same as prior period, unchanged from 0000926326-15-000018:notes:95]


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0000926326-15-000028:notes:115]
The following weighted average assumptions are used to value share options and Employee Stock Purchase Plan ("ESPP") shares issued pursuant to our equity incentive plans for the three and six months ended June 30, 2015 and June 30, 2014:

[0000926326-15-000028:notes:116]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
|  | (In thousands) |
| Stock Option Plans |  |  |  |  |  |  |  |
| Expected life, years | 5.04 |  |  | 4.77 |  |  | 5.04 |  |  | 4.79 |  |
| Expected volatility, % | 29.3 | % |  | 35.9 | % |  | 32.2 | % |  | 35.4 | % |
| Risk free interest rate, % | 1.51 | % |  | 1.62 | % |  | 1.58 | % |  | 1.52 | % |
| Estimated forfeiture rate % | 2.5 | % |  | 2.5 | % |  | 2.5 | % |  | 2.5 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-15-000028:notes:117]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
|  | (In thousands) |
| Employee Stock Purchase Plan |  |  |  |  |  |  |  |
| Expected life, years | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |
| Expected volatility, % | 28.52%-37.53% |  |  | 29.56%-39.84% |  |  | 23.75%-35.67% |  |  | 29.56%-39.84% |  |
| Risk free interest rate, % | 0.03%-0.72% |  |  | 0.03%-0.53% |  |  | 0.03%-0.72% |  |  | 0.03%-0.53% |  |
| Estimated forfeiture rate % | — | % |  | — | % |  | — | % |  | — | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:ScheduleOfTreasuryStockByClassTextBlock

[0000926326-15-000028:notes:118]
The following table summarizes our stock repurchases:

[0000926326-15-000028:notes:119]
|  | June 30, 2015 |  | December 31, 2014 |  |
|  | (In thousands, except per share data) |
| Total number of shares repurchased | 680 |  |  | 884 |  |  |
| Dollar amount of shares repurchased | $ | 25,020 |  |  | $ | 24,091 |  |  |
| Average price paid per share | $ | 36.74 |  |  | $ | 27.24 |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-15-000028:notes:120]
[same as prior period, unchanged from 0000926326-15-000018:notes:96]

[0000926326-15-000028:notes:121]
In the first quarter of 2015, we modified the segment presentation to reflect the changes in how our Chief Operating Decision Maker (“CODM”) reviews the segments and the overall business. With the increase in completed acquisitions in the last two years, we changed how the financial information was presented for CODM review to exclude general corporate-level costs that are not specific to either of the reporting segments when evaluating the operating results of each segment. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.

[0000926326-15-000028:notes:122]
The historical information presented has been retrospectively adjusted to reflect the modified segment reporting. Our CODM allocates resources and evaluates the performance of our segments using information about its revenues, gross profit and income from operations, excluding certain costs which are managed separately at the corporate level. We enhanced our segment reporting structure to match our operating structure based on how our Chief Operating Decision Maker (“CODM”) views the business and allocates resources, beginning in the first quarter of 2015. Our CODM is our Chief Executive Officer. Retrospective adjustments of prior period financial information have been made to conform to the current period presentation.

[0000926326-15-000028:notes:123]
The two operating segments, which are the same as our reportable segments, are as follows:

[0000926326-15-000028:notes:124]
[same as prior period, unchanged from 0000926326-15-000018:notes:98]

[0000926326-15-000028:notes:125]
[same as prior period, unchanged from 0000926326-15-000018:notes:99]

[0000926326-15-000028:notes:126]
[same as prior period, unchanged from 0000926326-15-000018:notes:100]

[0000926326-15-000028:notes:127]
The Medication Adherence segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand name MTS Medication Technologies ("MTS"), Surgichem Limited ("Surgichem"), and under the Omnicell and Suremed brands. MTS products consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care, and correctional facilities or retail pharmacies serving patients in their local communities.

[0000926326-15-000028:notes:128]
[same as prior period, unchanged from 0000926326-15-000018:notes:104]

[0000926326-15-000028:notes:129]
There were no customers that accounted for more than 10% of our total revenues for the three and six months ended June 30, 2015 and three and six months ended June 30, 2014.


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0000926326-15-000028:notes:130]
Performance-based restricted stock activity under the Company’s equity incentive plans in the six months ended June 30, 2015 is as follows:

[0000926326-15-000028:notes:131]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Performance-based Restricted Stock Units (PSUs) |  |  |  |
| Outstanding at December 31, 2014 | 233 |  |  | $ | 17.96 |  |
| Granted | 60 |  |  | 29.56 |  |
| Vested | (70 | ) |  | 18.91 |  |
| Forfeited | (27 | ) |  | 14.69 |  |
| Outstanding and unvested at June 30, 2015 | 196 |  |  | $ | 21.63 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-15-000028:notes:132]
[same as prior period, unchanged from 0000926326-15-000018:notes:108]

[0000926326-15-000028:notes:133]
Stock Based plans

[0000926326-15-000028:notes:134]
For a detailed explanation of our stock plan and subsequent changes please refer to Note 16, Employee Benefits and Stock-Based Compensation, of our Annual Report on Form 10-K for the year ended December 31, 2014.

[0000926326-15-000028:notes:135]
[same as prior period, unchanged from 0000926326-15-000018:notes:121]

[0000926326-15-000028:notes:136]
Stock option and restricted stock activity

[0000926326-15-000028:notes:137]
[same as prior period, unchanged from 0000926326-15-000018:notes:123]

[0000926326-15-000028:notes:138]
The weighted-average fair value per share of options granted during the three and six months ended June 30, 2015, was $10.09 and $10.61, respectively and the weighted-average fair value per share of options granted during the three and six months ended June 30, 2014 was $9.00 and $8.29, respectively. The intrinsic value of options exercised during the three and six months ended June 30, 2015 was $4.3 million and $6.7 million, respectively. The intrinsic value of options exercised during the three and six months ended June 30, 2014 was $5.3 million and $7.9 million, respectively.

[0000926326-15-000028:notes:139]
As of June 30, 2015, total unrecognized compensation cost related to unvested stock options was $8.8 million, which is expected to be recognized over a weighted-average vesting period of 2.7 years.

[0000926326-15-000028:notes:140]
[same as prior period, unchanged from 0000926326-15-000018:notes:126]

[0000926326-15-000028:notes:141]
The weighted-average grant date fair value per share of RSUs granted during the six months ended June 30, 2015 was $34.19, respectively. The weighted-average grant date fair value per share of RSUs granted during the six months ended June 30, 2014 was $26.46, respectively.

[0000926326-15-000028:notes:142]
As of June 30, 2015, total unrecognized compensation expense related to RSUs was $8.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.4 years.

[0000926326-15-000028:notes:143]
The weighted-average grant date fair value per share of RSAs granted during the six months ended June 30, 2015 was and $36.05.

[0000926326-15-000028:notes:144]
As of June 30, 2015, total unrecognized compensation cost related to RSAs was $1.0 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.9 years.

[0000926326-15-000028:notes:145]
[same as prior period, unchanged from 0000926326-15-000018:notes:131]

[0000926326-15-000028:notes:146]
The weighted-average grant date fair value per share of PSUs granted during the six months ended June 30, 2015 and June 30, 2014 was $29.56 and $16.49, respectively. The total fair value of PSUs that vested during the six months ended June 30, 2015 and June 30, 2014 was $2.6 million and $2.1 million, respectively.

[0000926326-15-000028:notes:147]
As of June 30, 2015, total unrecognized compensation cost related to PSUs was approximately $2.5 million, which is expected to be recognized over the remaining weighted-average period of 1.4 years.

[0000926326-15-000028:notes:148]
Employee Stock Purchase Plan (ESPP) activity

[0000926326-15-000028:notes:149]
The unrecognized compensation cost related to the shares to be purchased under our ESPP was approximately $2.2 million as of June 30, 2015, and is expected to be recognized over a weighted-average period of 0.1 years.

[0000926326-15-000028:notes:150]
Summary of shares reserved for future issuance under equity incentive plans


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-15-000028:notes:151]
Balance Sheet Components


## us-gaap:TreasuryStockTextBlock

[0000926326-15-000028:notes:152]
[same as prior period, unchanged from 0000926326-15-000018:notes:140]

[0000926326-15-000028:notes:153]
In August 2012, our Board of Directors authorized a program (the "2012 Stock Repurchase Program") to repurchase up to $50.0 million of common stock, of which approximately $45.1 million had been repurchased as of December 31, 2014, and the remaining $4.9 million has been repurchased as of June 30, 2015 and the 2012 Stock Repurchase Program has concluded now. In November 2014, our Board of Directors authorized a program (the "2014 Stock Repurchase Program") to repurchase up to $50.0 million of common stock of which approximately $20.1 million had been repurchased as of June 30, 2015. The 2014 Stock Repurchase Program has a total of $29.9 million remaining for future repurchases as of June 30, 2015, and the program has no expiration date.

[0000926326-15-000028:notes:154]
During the six months ended June 30, 2015, we repurchased approximately 680 thousand shares under our stock repurchase programs.
