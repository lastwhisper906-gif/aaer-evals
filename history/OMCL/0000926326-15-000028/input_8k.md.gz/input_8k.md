# OMCL 8-K — 0000926326-15-000024 filed 2015-07-30

## item codes, every 8-K on or before 2015-08-07

- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2015-08-07

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-15-000024:8k_2_02:1]
EX-99.1
2
exhibit991q215.htm
EXHIBIT 99.1

[0000926326-15-000024:8k_2_02:2]
Exhibit991Q215

[0000926326-15-000024:8k_2_02:3]
Exhibit 99.1

[0000926326-15-000024:8k_2_02:4]
| Contact: |  |  |
| Rob Seim |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6478 |  | Mountain View, CA 94043 |
| rob.seim@omnicell.com |  |  |

[0000926326-15-000024:8k_2_02:5]
Omnicell Announces Second Quarter 2015 Results

[0000926326-15-000024:8k_2_02:6]
| • | Revenue of $112.8 million grew 7.4% Year-Over-Year |

[0000926326-15-000024:8k_2_02:7]
MOUNTAIN VIEW, Calif. -- July 30, 2015 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its second quarter ended June 30, 2015.

[0000926326-15-000024:8k_2_02:8]
GAAP results: Revenue for the second quarter of 2015 was $112.8 million, down $3.4 million or 3.0% from the first quarter of 2015, and up $7.7 million or 7.4% from the second quarter of 2014. Revenue for the six months ended June 30, 2015 was $229.0 million, up $22.2 million or 10.7% from the six months ended June 30, 2014.

[0000926326-15-000024:8k_2_02:9]
Second quarter 2015 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $8.8 million, or $0.24 per diluted share. This compares to GAAP net income of $6.3 million, or $0.17 per diluted share, for the first quarter of 2015, and GAAP net income of $7.8 million, or $0.21 per diluted share, for the second quarter of 2014.

[0000926326-15-000024:8k_2_02:10]
GAAP net income for the six months ended June 30, 2015 was $15.1 million, or $0.41 per diluted share, which included a $3.4 million gain on business combination of an equity investment. GAAP net income was $14.0 million, or $0.38 per diluted share, for the six months ended June 30, 2014.

[0000926326-15-000024:8k_2_02:11]
Non-GAAP results: Non-GAAP net income for the second quarter of 2015 was $10.3 million, or $0.28 per diluted share, excluding $3.6 million of stock-based compensation expense and $1.3 million ($1.8 million net of $0.5 million tax effect) of amortization expense for all intangible assets associated with past acquisitions. Non-GAAP net income for the second quarter also excludes $3.4 million gain on the Company's 2012 minority equity investment in Avantec Healthcare Ltd., which was recorded as part of Omnicell's acquisition of the remainder of Avantec Healthcare Ltd. in April. This compares to non-GAAP net income of $11.2 million, or $0.30 per diluted share, for the second quarter of 2014. Non-GAAP net income for the second quarter of 2014 excluded $2.7 million of stock-based compensation expense and $0.6 million ($1.0 million net of $0.4 million tax effect) of amortization expense for all intangible assets associated with past acquisitions. Second quarter 2015 results compare to non-GAAP net income of $10.8 million, or $0.29 per diluted share, for the first quarter of 2015. Non-GAAP net income for the first quarter of 2015 excludes $3.7 million of stock-based compensation expense and $0.8 million ($1.2 million net of $0.4 million tax effect) of amortization expense for all intangible assets associated with past acquisitions.

[0000926326-15-000024:8k_2_02:12]
Non-GAAP net income for the six months ended June 30, 2015 was $21.0 million, or $0.57 per diluted share. Non-GAAP net income for the six months ended June 30, 2015, excludes $7.3 million of stock-based compensation expense and $2.1 million ($3.0 million net of the $0.9 million tax effect) of amortization expense for all intangible assets associated with past acquisitions. Non-GAAP net income for the six months ended June 30, 2015 also excludes $3.4 million gain on business combination of an equity investment in Avantec Healthcare Ltd. This compares to non-GAAP net income of $20.8 million, or $0.57 per diluted share for the six months ended June 30, 2014, excluding $5.4 million of stock-based compensation expense and $1.3 million ($2.1 million net of $0.8 million tax effect) of amortization expense for all intangible assets associated with past acquisitions.

[0000926326-15-000024:8k_2_02:13]
“Omnicell’s business has grown well from 2014 with a strong contribution from new customer orders. A small sequential decline in revenue due to timing of customer implementations affected our results for the second quarter, but our order intake and the pipeline of new sales opportunities demonstrate that we have not lost market momentum.” said Randall Lipps, Omnicell president, chairman and CEO. “Driven by our three-leg growth strategy of differentiated products, expansion into new markets and targeted acquisitions, the company has all the ingredients for continued success.”

[0000926326-15-000024:8k_2_02:14]
Reporting Segments

[0000926326-15-000024:8k_2_02:15]
As reported last quarter, beginning the first quarter of 2015, Omnicell enhanced the management of its business, operating structure and segment reporting structure by excluding certain corporate-level costs from our reporting segments based on how the Chief Operating Decision Maker (“CODM”) reviews the business. Corporate-level costs may include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses. Omnicell's CODM allocates resources and evaluates the performance of our segments using information about its revenues, gross profit and income from operations, excluding certain costs which are managed separately at the corporate level.

[0000926326-15-000024:8k_2_02:16]
Omnicell Conference Call Information

[0000926326-15-000024:8k_2_02:17]
Omnicell will hold a conference call today, Thursday, July 30, 2015 at 1:30 p.m. PT to discuss second quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 86450368. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on August 13, 2015. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 86450368.

[0000926326-15-000024:8k_2_02:18]
2

[0000926326-15-000024:8k_2_02:19]
About Omnicell

[0000926326-15-000024:8k_2_02:20]
Since 1992, Omnicell (NASDAQ: OMCL) has been creating new efficiencies to improve patient care, anywhere it is delivered. Omnicell is a leading supplier of comprehensive automation and business analytics software for patient-centric medication and supply management across the entire health care continuum from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home.

[0000926326-15-000024:8k_2_02:21]
More than 3,000 customers worldwide have utilized Omnicell Automation and Analytics solutions to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety. Omnicell Medication Adherence solutions, including its MTS Medication Technologies brand, provide innovative medication adherence packaging solutions to help reduce costly hospital readmissions. In addition, these solutions enable approximately 6,000 institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-15-000024:8k_2_02:22]
For more information about Omnicell, please visit www.omnicell.com.

[0000926326-15-000024:8k_2_02:23]
Forward-Looking Statements

[0000926326-15-000024:8k_2_02:24]
Use of Non-GAAP Financial Information

[0000926326-15-000024:8k_2_02:25]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-15-000024:8k_2_02:26]
Our non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-15-000024:8k_2_02:27]
a)  Stock-based compensation expense impact of Accounting Standards Codification (ASC) 718. We recognize equity plan-related compensation expenses, which represent the fair value of all share-based payments to employees, including grants of employee stock options, as required under ASC 718, Compensation - Stock Compensation (ASC 718) as non-GAAP adjustments in each period.

[0000926326-15-000024:8k_2_02:28]
b)  Intangible assets amortization from business acquisitions. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-15-000024:8k_2_02:29]
c)  Gain on business combination of an equity investment. We excluded from our non-GAAP results the gain on a minority equity investment in a private company, Avantec Healthcare Ltd., which was recognized in relation to the acquisition by Omnicell of the remainder of the company. This non-cash gain is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-15-000024:8k_2_02:30]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock option grants.

[0000926326-15-000024:8k_2_02:31]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-15-000024:8k_2_02:32]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0000926326-15-000024:8k_2_02:33]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0000926326-15-000024:8k_2_02:34]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0000926326-15-000024:8k_2_02:35]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-15-000024:8k_2_02:36]
Set forth below are additional reasons why share-based compensation expense related to ASC 718 is excluded from our non-GAAP financial measures:

[0000926326-15-000024:8k_2_02:37]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-15-000024:8k_2_02:38]
ii)  We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-15-000024:8k_2_02:39]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as excluding certain non-GAAP adjustments.

[0000926326-15-000024:8k_2_02:40]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-15-000024:8k_2_02:41]
·  Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-15-000024:8k_2_02:42]
·  Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-15-000024:8k_2_02:43]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-15-000024:8k_2_02:44]
Omnicell, Inc.

[0000926326-15-000024:8k_2_02:45]
Condensed Consolidated Statements of Operations

[0000926326-15-000024:8k_2_02:46]
(Unaudited, in thousands, except per share data)

[0000926326-15-000024:8k_2_02:47]
|  | Three Months Ended |  | Six Months Ended |
|  | June 30, 2015 |  | March 31, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product | $ | 89,154 |  |  | $ | 94,109 |  |  | $ | 85,244 |  |  | $ | 183,263 |  |  | $ | 167,824 |  |
| Services and other revenues | 23,634 |  |  | 22,112 |  |  | 19,808 |  |  | 45,746 |  |  | 38,992 |  |
| Total revenues | 112,788 |  |  | 116,221 |  |  | 105,052 |  |  | 229,009 |  |  | 206,816 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 46,203 |  |  | 45,416 |  |  | 41,003 |  |  | 91,619 |  |  | 79,903 |  |
| Cost of services and other revenues | 9,123 |  |  | 9,120 |  |  | 8,009 |  |  | 18,243 |  |  | 16,378 |  |
| Total cost of revenues | 55,326 |  |  | 54,536 |  |  | 49,012 |  |  | 109,862 |  |  | 96,281 |  |
| Gross profit | 57,462 |  |  | 61,685 |  |  | 56,040 |  |  | 119,147 |  |  | 110,535 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 8,746 |  |  | 8,019 |  |  | 6,471 |  |  | 16,765 |  |  | 12,592 |  |
| Selling, general and administrative | 39,735 |  |  | 43,287 |  |  | 37,011 |  |  | 83,022 |  |  | 75,431 |  |
| Gain on business combination | (3,443 | ) |  | — |  |  | — |  |  | (3,443 | ) |  | — |  |
| Total operating expenses | 45,038 |  |  | 51,306 |  |  | 43,482 |  |  | 96,344 |  |  | 88,023 |  |
| Income from operations | 12,424 |  |  | 10,379 |  |  | 12,558 |  |  | 22,803 |  |  | 22,512 |  |
| Interest and other income (expense), net | (472 | ) |  | (517 | ) |  | (40 | ) |  | (989 | ) |  | (296 | ) |
| Income before provision for income taxes | 11,952 |  |  | 9,862 |  |  | 12,518 |  |  | 21,814 |  |  | 22,216 |  |
| Provision for income taxes | 3,201 |  |  | 3,544 |  |  | 4,729 |  |  | 6,745 |  |  | 8,233 |  |
| Net income | $ | 8,751 |  |  | $ | 6,318 |  |  | $ | 7,789 |  |  | $ | 15,069 |  |  | $ | 13,983 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.24 |  |  | $ | 0.18 |  |  | $ | 0.22 |  |  | $ | 0.42 |  |  | $ | 0.39 |  |
| Diluted | $ | 0.24 |  |  | $ | 0.17 |  |  | $ | 0.21 |  |  | $ | 0.41 |  |  | $ | 0.38 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic | 36,120 |  |  | 36,024 |  |  | 35,661 |  |  | 36,072 |  |  | 35,451 |  |
| Diluted | 37,030 |  |  | 36,914 |  |  | 36,618 |  |  | 36,987 |  |  | 36,478 |  |

[0000926326-15-000024:8k_2_02:48]
6

[0000926326-15-000024:8k_2_02:49]
Omnicell, Inc.

[0000926326-15-000024:8k_2_02:50]
Condensed Consolidated Balance Sheets

[0000926326-15-000024:8k_2_02:51]
(Unaudited, in thousands)

[0000926326-15-000024:8k_2_02:52]
|  | June 30, 2015 |  | December 31, 2014 |
| ASSETS |
| Current assets: |  |  |  |  |
| Cash and cash equivalents | $ | 88,028 |  |  | $ | 125,888 |  |
| Accounts receivable, net | 117,307 |  |  | 82,763 |  |
| Inventories | 46,027 |  |  | 31,554 |  |
| Prepaid expenses | 15,401 |  |  | 23,518 |  |
| Deferred tax assets | 12,490 |  |  | 12,446 |  |
| Other current assets | 6,071 |  |  | 7,215 |  |
| Total current assets | 285,324 |  |  | 283,384 |  |
| Property and equipment, net | 34,772 |  |  | 36,178 |  |
| Long-term net investment in sales-type leases | 10,208 |  |  | 10,848 |  |
| Goodwill | 149,654 |  |  | 122,720 |  |
| Intangible assets, net | 94,285 |  |  | 82,667 |  |
| Long-term deferred tax assets | 1,397 |  |  | 1,144 |  |
| Other long-term assets | 25,382 |  |  | 23,273 |  |
| Total assets | $ | 601,022 |  |  | $ | 560,214 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |
| Accounts payable | $ | 26,085 |  |  | $ | 19,432 |  |
| Accrued compensation | 18,573 |  |  | 19,874 |  |
| Accrued liabilities | 33,419 |  |  | 19,299 |  |
| Deferred service revenue | 23,527 |  |  | 25,167 |  |
| Deferred gross profit | 36,671 |  |  | 28,558 |  |
| Total current liabilities | 138,275 |  |  | 112,330 |  |
| Non-current deferred service revenue | 19,056 |  |  | 20,308 |  |
| Non-current deferred tax liabilities | 32,723 |  |  | 30,454 |  |
| Other long-term liabilities | 11,620 |  |  | 7,024 |  |
| Total liabilities | 201,674 |  |  | 170,116 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Total stockholders’ equity | 399,348 |  |  | 390,098 |  |
| Total liabilities and stockholders’ equity | $ | 601,022 |  |  | $ | 560,214 |  |

[0000926326-15-000024:8k_2_02:53]
Omnicell, Inc.

[0000926326-15-000024:8k_2_02:54]
Condensed Consolidated Statements of Cash Flows

[0000926326-15-000024:8k_2_02:55]
(Unaudited, in thousands)

[0000926326-15-000024:8k_2_02:56]
|  | Six months ended June 30, |
|  | 2015 |  | 2014 |
| Operating Activities |  |  |  |
| Net income | $ | 15,069 |  |  | $ | 13,983 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 11,977 |  |  | 9,391 |  |
| Gain (loss) on disposal of fixed assets | (5 | ) |  | 202 |  |
| Gain on business combination | (3,443 | ) |  | — |  |
| Provision for receivable allowance | 480 |  |  | 436 |  |
| Share-based compensation expense | 7,301 |  |  | 5,449 |  |
| Income tax benefits from employee stock plans | 3,087 |  |  | 3,058 |  |
| Excess tax benefits from employee stock plans | (3,159 | ) |  | (3,326 | ) |
| Provision for excess and obsolete inventories | 168 |  |  | 250 |  |
| Deferred income taxes | (1,717 | ) |  | 860 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | (27,676 | ) |  | (24,408 | ) |
| Inventories | (9,633 | ) |  | (335 | ) |
| Prepaid expenses | 8,234 |  |  | 2,144 |  |
| Other current assets | 1,507 |  |  | 1,602 |  |
| Net investment in sales-type leases | 353 |  |  | 622 |  |
| Other long-term assets | 64 |  |  | 228 |  |
| Accounts payable | 1,364 |  |  | 2,494 |  |
| Accrued compensation | (1,654 | ) |  | (3,910 | ) |
| Accrued liabilities | 5,752 |  |  | 2,424 |  |
| Deferred service revenue | (2,892 | ) |  | 2,640 |  |
| Deferred gross profit | 6,008 |  |  | 10,788 |  |
| Other long-term liabilities | (995 | ) |  | 829 |  |
| Net cash provided by operating activities | 10,190 |  |  | 25,421 |  |
| Investing Activities |  |  |  |
| Acquisition of intangible assets, intellectual property and patents | (225 | ) |  | (191 | ) |
| Software development for external use | (6,127 | ) |  | (5,507 | ) |
| Purchases of property and equipment | (3,764 | ) |  | (7,335 | ) |
| Business acquisition, net of cash acquired | (23,625 | ) |  | — |  |
| Net cash used in investing activities | (33,741 | ) |  | (13,033 | ) |
| Financing Activities |  |  |  |
| Proceeds from issuances under stock-based compensation plans | 9,432 |  |  | 11,813 |  |
| Employees' taxes paid related to restricted stock units | (2,046 | ) |  | (1,729 | ) |
| Common stock repurchases | (25,021 | ) |  | (4,069 | ) |
| Excess tax benefits from employee stock plans | 3,159 |  |  | 3,326 |  |
| Net cash (used) provided by financing activities | (14,476 | ) |  | 9,341 |  |
| Effect of exchange rate changes on cash and cash equivalents | 167 |  |  | 119 |  |
| Net (decrease) increase in cash and cash equivalents | (37,860 | ) |  | 21,848 |  |
| Cash and cash equivalents at beginning of period | 125,888 |  |  | 104,531 |  |
| Cash and cash equivalents at end of period | $ | 88,028 |  |  | $ | 126,379 |  |

[0000926326-15-000024:8k_2_02:57]
8

[0000926326-15-000024:8k_2_02:58]
Omnicell, Inc.

[0000926326-15-000024:8k_2_02:59]
Reconciliation of GAAP to Non-GAAP

[0000926326-15-000024:8k_2_02:60]
(Unaudited, in thousands, except per share data)

[0000926326-15-000024:8k_2_02:61]
|  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  |  | June 30, 2015 |  | March 31, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Reconciliation of GAAP net income to non-GAAP net income: |  |  |  |  |  |  |
| GAAP net income | $ | 8,751 |  |  | $ | 6,318 |  |  | $ | 7,789 |  |  | $ | 15,069 |  |  | $ | 13,983 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
|  | Share-based compensation expense: |  |  |  |  |  |  |  |  |  |
|  |  | Cost of revenues | 532 |  |  | 517 |  |  | 264 |  |  | 1,049 |  |  | 532 |  |
|  |  | Operating expenses | 3,104 |  |  | 3,148 |  |  | 2,456 |  |  | 6,252 |  |  | 4,917 |  |
|  |  | Total share-based compensation expense (a) | 3,636 |  |  | 3,665 |  |  | 2,720 |  |  | 7,301 |  |  | 5,449 |  |
|  | Amortization of acquired intangibles: |  |  |  |  |  |  |  |  |  |
|  |  | Cost of revenues | 531 |  |  | 368 |  |  | 368 |  |  | 899 |  |  | 736 |  |
|  |  | Operating expenses | 1,279 |  |  | 863 |  |  | 680 |  |  | 2,142 |  |  | 1,360 |  |
|  |  | Total Amortization of acquired intangibles: | 1,810 |  |  | 1,231 |  |  | 1,048 |  |  | 3,041 |  |  | 2,096 |  |
|  | Income tax effect of non-GAAP adjustments (b) | (485 | ) |  | (443 | ) |  | (395 | ) |  | (928 | ) |  | (774 | ) |
|  |  | Total Amortization of acquired intangibles, net: | 1,325 |  |  | 788 |  |  | 653 |  |  | 2,113 |  |  | 1,322 |  |
|  | Gain on business combination | (3,443 | ) |  | — |  |  | — |  |  | (3,443 | ) |  | — |  |
| Non-GAAP net income | $ | 10,269 |  |  | $ | 10,771 |  |  | $ | 11,162 |  |  | $ | 21,040 |  |  | $ | 20,754 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |  |  |
|  | Revenues |  | $ | 112,788 |  |  | $ | 116,221 |  |  | $ | 105,052 |  |  | $ | 229,009 |  |  | $ | 206,816 |  |
|  | GAAP gross profit | 57,462 |  |  | 61,685 |  |  | 56,040 |  |  | 119,147 |  |  | 110,535 |  |
|  | GAAP gross margin | 50.9% |  | 53.1% |  | 53.3% |  | 52.0% |  | 53.4% |
|  |  | Share-based compensation expense | 532 |  |  | 517 |  |  | 264 |  |  | 1,049 |  |  | 532 |  |
|  |  | Amortization of acquired intangibles | 531 |  |  | 368 |  |  | 368 |  |  | 899 |  |  | 736 |  |
|  | Non-GAAP gross profit | $ | 58,525 |  |  | $ | 62,570 |  |  | $ | 56,672 |  |  | $ | 121,095 |  |  | $ | 111,803 |  |
|  | Non-GAAP gross margin | 51.9% |  | 53.8% |  | 53.9% |  | 52.9% |  | 54.1% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |  |  |
| GAAP operating expenses | $ | 45,038 |  |  | $ | 51,306 |  |  | $ | 43,482 |  |  | $ | 96,344 |  |  | $ | 88,023 |  |
|  | GAAP operating expenses % to total revenue | 39.9% |  | 44.1% |  | 41.4% |  | 42.1% |  | 42.6% |
|  | Share-based compensation expense | (3,104 | ) |  | (3,148 | ) |  | (2,456 | ) |  | (6,252 | ) |  | (4,917 | ) |
|  | Amortization of acquired intangibles | (1,279 | ) |  | (863 | ) |  | (680 | ) |  | (2,142 | ) |  | (1,360 | ) |
|  | Gain on business combination | $ | 3,443 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,443 |  |  | $ | — |  |
| Non-GAAP operating expenses | $ | 44,098 |  |  | $ | 47,295 |  |  | $ | 40,346 |  |  | $ | 91,393 |  |  | $ | 81,746 |  |
|  | Non-GAAP operating expenses % to total revenue | 39.1% |  | 40.7% |  | 38.4% |  | 39.9% |  | 39.5% |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |  |  |  |  |
| GAAP income (loss) from operations | $ | 12,424 |  |  | $ | 10,379 |  |  | $ | 12,558 |  |  | $ | 22,803 |  |  | $ | 22,512 |  |
|  | GAAP operating income % to total revenue | 11.0% |  | 8.9% |  | 12.0% |  | 10.0% |  | 10.9% |
|  | Share-based compensation expense | 3,636 |  |  | 3,665 |  |  | 2,720 |  |  | 7,301 |  |  | 5,449 |  |
|  | Amortization of acquired intangibles | 1,810 |  |  | 1,231 |  |  | 1,048 |  |  | 3,041 |  |  | 2,096 |  |
|  | Gain on business combination | (3,443 | ) |  | — |  |  | — |  |  | (3,443 | ) |  | — |  |
| Non-GAAP income from operations | $ | 14,427 |  |  | $ | 15,275 |  |  | $ | 16,326 |  |  | $ | 29,702 |  |  | $ | 30,057 |  |
|  | Non-GAAP operating income % to total revenue | 12.8% |  | 13.1% |  | 15.5% |  | 13.0% |  | 14.5% |

[0000926326-15-000024:8k_2_02:62]
|  |  |  |  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  |  |  |  | June 30, 2015 |  | March 31, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| GAAP shares - diluted | 37,030 |  |  | 36,914 |  |  | 36,618 |  |  | 36,987 |  |  | 36,478 |  |
| GAAP net income per share - diluted | $ | 0.24 |  |  | $ | 0.17 |  |  | $ | 0.21 |  |  | $ | 0.41 |  |  | $ | 0.38 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
|  | Share-based compensation expense | 0.10 |  |  | 0.10 |  |  | 0.07 |  |  | 0.20 |  |  | 0.15 |  |
|  | Amortization of acquired intangibles | 0.04 |  |  | 0.02 |  |  | 0.02 |  |  | 0.06 |  |  | 0.04 |  |
|  | Gain on business combination | (0.10 | ) |  | — |  |  | — |  |  | (0.10 | ) |  | — |  |
| Non-GAAP net income per share - diluted | $ | 0.28 |  |  | $ | 0.29 |  |  | $ | 0.30 |  |  | $ | 0.57 |  |  | $ | 0.57 |  |
| Reconciliation of GAAP EBITDA to non-GAAP EBITDA: |  |  |  |  |  |  |  |  |  |
| GAAP net income | $ | 8,751 |  |  | $ | 6,318 |  |  | $ | 7,789 |  |  | $ | 15,069 |  |  | $ | 13,983 |  |
| Add back: |  |  |  |  |  |  |  |  |  |
|  | Share-based compensation expense | 3,636 |  |  | 3,665 |  |  | 2,720 |  |  | 7,301 |  |  | 5,449 |  |
|  | Interest (income) and expense, net | 84 |  |  | 99 |  |  | (32 | ) |  | 183 |  |  | (35 | ) |
|  | Depreciation and amortization expense | 6,264 |  |  | 5,711 |  |  | 4,779 |  |  | 11,975 |  |  | 9,391 |  |
|  | Income tax expense | 3,201 |  |  | 3,544 |  |  | 4,729 |  |  | 6,745 |  |  | 8,233 |  |
|  | Gain on business combination | $ | (3,443 | ) |  | $ | — |  |  | $ | — |  |  | $ | (3,443 | ) |  | $ | — |  |
| Non-GAAP adjusted EBITDA (c) | $ | 18,493 |  |  | $ | 19,337 |  |  | $ | 19,985 |  |  | $ | 37,830 |  |  | $ | 37,021 |  |

[0000926326-15-000024:8k_2_02:63]
____________________________________________

[0000926326-15-000024:8k_2_02:64]
| (a) | This adjustment reflects the accounting impact of non-cash stock-based compensation expense for the periods presented. |

[0000926326-15-000024:8k_2_02:65]
| (b) | Tax effects are calculated using the effective tax rates for the respective periods presented. |

[0000926326-15-000024:8k_2_02:66]
| (c) | Defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including stock compensation expense, per ASC 718, as well as excluding certain non-GAAP adjustments. |

[0000926326-15-000024:8k_2_02:67]
10

[0000926326-15-000024:8k_2_02:68]
Omnicell, Inc.

[0000926326-15-000024:8k_2_02:69]
Segmented Information

[0000926326-15-000024:8k_2_02:70]
(Unaudited, in thousands, except for percentages)

[0000926326-15-000024:8k_2_02:71]
|  | Three Months Ended June 30, 2015 |  | Three Months Ended June 30, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 88,701 |  |  | $ | 24,087 |  |  | $ | 112,788 |  |  | $ | 84,702 |  |  | $ | 20,350 |  |  | $ | 105,052 |  |
| Cost of revenues | 39,403 |  |  | 15,923 |  |  | 55,326 |  |  | 35,992 |  |  | 13,020 |  |  | 49,012 |  |
| Gross profit | 49,298 |  |  | 8,164 |  |  | 57,462 |  |  | 48,710 |  |  | 7,330 |  |  | 56,040 |  |
| Gross margin % | 55.6% |  | 33.9% |  | 50.9% |  | 57.5% |  | 36.0% |  | 53.3% |
| Operating expenses | 25,978 |  |  | 5,910 |  |  | 31,888 |  |  | 26,044 |  |  | 4,800 |  |  | 30,844 |  |
| Income from segment operations | $ | 23,320 |  |  | $ | 2,254 |  |  | 25,574 |  |  | $ | 22,666 |  |  | $ | 2,530 |  |  | 25,196 |  |
| Operating margin % | 26.3% |  | 9.4% |  | 22.7% |  | 26.8% |  | 12.4% |  | 24.0% |
| Corporate costs |  |  |  |  | 13,150 |  |  |  |  |  |  | 12,638 |  |
| Income from operations |  |  |  |  | $ | 12,424 |  |  |  |  |  |  | $ | 12,558 |  |

[0000926326-15-000024:8k_2_02:72]
11

[0000926326-15-000024:8k_2_02:73]
Omnicell, Inc.

[0000926326-15-000024:8k_2_02:74]
Segmented Information

[0000926326-15-000024:8k_2_02:75]
(Unaudited, in thousands, except for percentages)

[0000926326-15-000024:8k_2_02:76]
|  | Six Months Ended June 30, 2015 |  | Six Months Ended June 30, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 181,480 |  |  | $ | 47,529 |  |  | $ | 229,009 |  |  | $ | 166,201 |  |  | $ | 40,615 |  |  | $ | 206,816 |  |
| Cost of revenues | 78,255 |  |  | 31,607 |  |  | 109,862 |  |  | 70,932 |  |  | 25,349 |  |  | 96,281 |  |
| Gross profit | 103,225 |  |  | 15,922 |  |  | 119,147 |  |  | 95,269 |  |  | 15,266 |  |  | 110,535 |  |
| Gross margin % | 56.9% |  | 33.5% |  | 52.0% |  | 57.3% |  | 37.6% |  | 53.4% |
| Operating expenses | 54,567 |  |  | 12,251 |  |  | 66,818 |  |  | 51,146 |  |  | 9,451 |  |  | 60,597 |  |
| Income from segment operations | $ | 48,658 |  |  | $ | 3,671 |  |  | 52,329 |  |  | $ | 44,123 |  |  | $ | 5,815 |  |  | 49,938 |  |
| Operating margin % | 26.8% |  | 7.7% |  | 22.9% |  | 26.5% |  | 14.3% |  | 24.1% |
| Corporate costs |  |  |  |  | 29,526 |  |  |  |  |  |  | 27,426 |  |
| Income from operations |  |  |  |  | $ | 22,803 |  |  |  |  |  |  | $ | 22,512 |  |

[0000926326-15-000024:8k_2_02:77]
Omnicell, Inc.

[0000926326-15-000024:8k_2_02:78]
Segment Information - Non-GAAP Gross Margin and Non-GAAP Operating Margin

[0000926326-15-000024:8k_2_02:79]
(Unaudited, in thousands, except for percentages)

[0000926326-15-000024:8k_2_02:80]
|  | Three Months Ended June 30, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 88,701 |  |  |  |  | $ | 24,087 |  |  |  |  | $ | 112,788 |  |  |  |
| GAAP Gross profit | $ | 49,298 |  |  | 55.6% |  | $ | 8,164 |  |  | 33.9% |  | $ | 57,462 |  |  | 50.9% |
| Plus: |  |  |  |  |  |  |  |  |  |  |  |
| a) Stock-based compensation expense | 370 |  |  | 0.4% |  | $ | 162 |  |  | 0.7% |  | 532 |  |  | 0.5% |
| b) Amortization expense of acquired intangible assets and other acquisition-related expenses | 199 |  |  | 0.2% |  | $ | 332 |  |  | 1.4% |  | 531 |  |  | 0.5% |
| Non-GAAP Gross profit | $ | 49,867 |  |  | 56.2% |  | $ | 8,658 |  |  | 35.9% |  | $ | 58,525 |  |  | 51.9% |
| GAAP Operating income | $ | 23,320 |  |  | 26.3% |  | $ | 2,254 |  |  | 9.4% |  | $ | 25,574 |  |  | 22.7% |
| Plus: |  |  |  |  |  |  |  |  |  |  |  |
| a) Stock-based compensation expense | 1,207 |  |  | 1.4% |  | 377 |  |  | 1.6% |  | 1,584 |  |  | 1.4% |
| b) Amortization expense of acquired intangible assets and other acquisition-related expenses | 724 |  |  | 0.8% |  | 1,086 |  |  | 4.5% |  | 1,810 |  |  | 1.6% |
| c) Gain on business combination | (3,443 | ) |  | (3.9)% |  | $ | 0 |  |  | —% |  | (3,443 | ) |  | (3.1)% |
| Non-GAAP Operating income | $ | 21,808 |  |  | 24.6% |  | $ | 3,717 |  |  | 15.4% |  | $ | 25,525 |  |  | 22.6% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 13,150 |  |  | 11.7% |
| Less: Stock-based compensation expense |  |  |  |  |  |  |  |  | 2,052 |  |  | 1.8% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 11,098 |  |  | 9.8% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  | $ | 14,427 |  |  | 12.8% |

[0000926326-15-000024:8k_2_02:81]
13

[0000926326-15-000024:8k_2_02:82]
|  | Three Months Ended June 30, 2014 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 84,702 |  |  |  |  | $ | 20,350 |  |  |  |  | $ | 105,052 |  |  |  |
| GAAP Gross profit | $ | 48,710 |  |  | 57.5% |  | $ | 7,330 |  |  | 36.0% |  | $ | 56,040 |  |  | 53.3% |
| Plus: |  |  |  |  |  |  |  |  |  |  |  |
| a) Stock-based compensation expense | 226 |  |  | 0.3% |  | $ | 38 |  |  | 0.2% |  | 264 |  |  | 0.3% |
| b) Amortization expense of acquired intangible assets and other acquisition-related expenses | 35 |  |  | 0.0% |  | $ | 333 |  |  | 1.6% |  | 368 |  |  | 0.4% |
| Non-GAAP Gross profit | $ | 48,971 |  |  | 57.8% |  | $ | 7,701 |  |  | 37.8% |  | $ | 56,672 |  |  | 53.9% |
| GAAP Operating income | $ | 22,666 |  |  | 26.8% |  | $ | 2,530 |  |  | 12.4% |  | $ | 25,196 |  |  | 24.0% |
| Plus: |  |  |  |  |  |  |  |  |  |  |  |
| a) Stock-based compensation expense | 1,020 |  |  | 1.2% |  | 168 |  |  | 0.8% |  | 1,188 |  |  | 1.1% |
| b) Amortization expense of acquired intangible assets and other acquisition-related expenses | 147 |  |  | 0.2% |  | 901 |  |  | 4.4% |  | 1,048 |  |  | 1.0% |
| Non-GAAP Operating income | $ | 23,833 |  |  | 28.1% |  | $ | 3,599 |  |  | 17.7% |  | $ | 27,432 |  |  | 26.1% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 12,638 |  |  | 12.0% |
| Less: Stock-based compensation expense |  |  |  |  |  |  |  |  | 1,532 |  |  | 1.5% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 11,106 |  |  | 10.6% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  | $ | 16,326 |  |  | 15.5% |

[0000926326-15-000024:8k_2_02:83]
14
