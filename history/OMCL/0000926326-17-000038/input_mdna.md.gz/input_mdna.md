# OMCL MD&A — 0000926326-17-000038


## mdna

[0000926326-17-000038:mdna:1]
[same as prior period, unchanged from 0000926326-17-000032:mdna:1]

[0000926326-17-000038:mdna:2]
[same as prior period, unchanged from 0000926326-17-000032:mdna:2]

[0000926326-17-000038:mdna:3]
[same as prior period, unchanged from 0000926326-17-000032:mdna:3]

[0000926326-17-000038:mdna:4]
[same as prior period, unchanged from 0000926326-17-000032:mdna:4]

[0000926326-17-000038:mdna:5]
[same as prior period, unchanged from 0000926326-17-000032:mdna:5]

[0000926326-17-000038:mdna:6]
[same as prior period, unchanged from 0000926326-17-000032:mdna:6]

[0000926326-17-000038:mdna:7]
[same as prior period, unchanged from 0000926326-17-000032:mdna:7]

[0000926326-17-000038:mdna:8]
[same as prior period, unchanged from 0000926326-17-000032:mdna:8]

[0000926326-17-000038:mdna:9]
[same as prior period, unchanged from 0000926326-17-000032:mdna:9]

[0000926326-17-000038:mdna:10]
[same as prior period, unchanged from 0000926326-17-000032:mdna:10]

[0000926326-17-000038:mdna:11]
| • | our ability to generate cash from operations and our estimates regarding the sufficiency of our cash resources. |

[0000926326-17-000038:mdna:12]
[same as prior period, unchanged from 0000926326-17-000032:mdna:13]

[0000926326-17-000038:mdna:13]
[same as prior period, unchanged from 0000926326-17-000032:mdna:14]

[0000926326-17-000038:mdna:14]
[same as prior period, unchanged from 0000926326-17-000032:mdna:12]

[0000926326-17-000038:mdna:15]
[same as prior period, unchanged from 0000926326-17-000032:mdna:15]

[0000926326-17-000038:mdna:16]
[same as prior period, unchanged from 0000926326-17-000032:mdna:16]

[0000926326-17-000038:mdna:17]
[same as prior period, unchanged from 0000926326-17-000032:mdna:17]

[0000926326-17-000038:mdna:18]
[same as prior period, unchanged from 0000926326-17-000032:mdna:18]

[0000926326-17-000038:mdna:19]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 88% and 88% of total revenue for the three months ended September 30, 2017 and 2016, respectively, and 87% and 86% of total revenue for the nine months ended September 30, 2017 and 2016. We expect our revenues from international operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-17-000038:mdna:20]
[same as prior period, unchanged from 0000926326-17-000032:mdna:20]

[0000926326-17-000038:mdna:21]
[same as prior period, unchanged from 0000926326-17-000032:mdna:21]

[0000926326-17-000038:mdna:22]
[same as prior period, unchanged from 0000926326-17-000032:mdna:22]

[0000926326-17-000038:mdna:23]
[same as prior period, unchanged from 0000926326-17-000032:mdna:23]

[0000926326-17-000038:mdna:24]
[same as prior period, unchanged from 0000926326-17-000032:mdna:24]

[0000926326-17-000038:mdna:25]
[same as prior period, unchanged from 0000926326-17-000032:mdna:25]

[0000926326-17-000038:mdna:26]
[same as prior period, unchanged from 0000926326-17-000032:mdna:26]

[0000926326-17-000038:mdna:27]
[same as prior period, unchanged from 0000926326-17-000032:mdna:27]

[0000926326-17-000038:mdna:28]
[same as prior period, unchanged from 0000926326-17-000032:mdna:28]

[0000926326-17-000038:mdna:29]
| • | Development of differentiated solutions. We invest in the development of products that we believe bring patient safety and workflow efficiency to our customers’ operations that they cannot get from other competing solutions. These differentiators may be as small as how a transaction operates or information provided on a report or as large |

[0000926326-17-000038:mdna:30]
as the entire automation of a workflow that would otherwise be completed manually. We intend to continue our focus on differentiating our products, and we carefully assess our investments regularly as we strive to ensure those investments provide the solutions most valuable to our customers.

[0000926326-17-000038:mdna:31]
[same as prior period, unchanged from 0000926326-17-000032:mdna:30]

[0000926326-17-000038:mdna:32]
[same as prior period, unchanged from 0000926326-17-000032:mdna:31]

[0000926326-17-000038:mdna:33]
[same as prior period, unchanged from 0000926326-17-000032:mdna:32]

[0000926326-17-000038:mdna:34]
[same as prior period, unchanged from 0000926326-17-000032:mdna:33]

[0000926326-17-000038:mdna:35]
[same as prior period, unchanged from 0000926326-17-000032:mdna:35]

[0000926326-17-000038:mdna:36]
[same as prior period, unchanged from 0000926326-17-000032:mdna:36]

[0000926326-17-000038:mdna:37]
[same as prior period, unchanged from 0000926326-17-000032:mdna:37]

[0000926326-17-000038:mdna:38]
[same as prior period, unchanged from 0000926326-17-000032:mdna:38]

[0000926326-17-000038:mdna:39]
[same as prior period, unchanged from 0000926326-17-000032:mdna:34]

[0000926326-17-000038:mdna:40]
[same as prior period, unchanged from 0000926326-17-000032:mdna:39]

[0000926326-17-000038:mdna:41]
[same as prior period, unchanged from 0000926326-17-000032:mdna:40]

[0000926326-17-000038:mdna:42]
[same as prior period, unchanged from 0000926326-17-000032:mdna:41]

[0000926326-17-000038:mdna:43]
[same as prior period, unchanged from 0000926326-17-000032:mdna:42]

[0000926326-17-000038:mdna:44]
On February 15, 2017, we announced our intention to create Centers of Excellence (“COE”) for product development, engineering and manufacturing, with the Point of Use COE located at our facilities in California, the Robotics and Central Pharmacy COE located at our facilities near Pittsburgh, Pennsylvania, and the Medication Adherence Consumables COE located at our facilities in St. Petersburg, Florida. As part of this initiative, we reduced our workforce by approximately 100 full-time employees, or about 4% of the total headcount, closed our Nashville, Tennessee facility, and plan to close our Slovenia facilities in the fourth quarter of 2017. Our full-time headcount was approximately 2,331 and 2,444 on September 30, 2017 on December 31, 2016, respectively.

[0000926326-17-000038:mdna:45]
[same as prior period, unchanged from 0000926326-17-000032:mdna:44]

[0000926326-17-000038:mdna:46]
[same as prior period, unchanged from 0000926326-17-000032:mdna:45]

[0000926326-17-000038:mdna:47]
[same as prior period, unchanged from 0000926326-17-000032:mdna:46]

[0000926326-17-000038:mdna:48]
[same as prior period, unchanged from 0000926326-17-000032:mdna:47]

[0000926326-17-000038:mdna:49]
28

[0000926326-17-000038:mdna:50]
[same as prior period, unchanged from 0000926326-17-000032:mdna:48]

[0000926326-17-000038:mdna:51]
[same as prior period, unchanged from 0000926326-17-000032:mdna:49]

[0000926326-17-000038:mdna:52]
[same as prior period, unchanged from 0000926326-17-000032:mdna:50]

[0000926326-17-000038:mdna:53]
[same as prior period, unchanged from 0000926326-17-000032:mdna:51]

[0000926326-17-000038:mdna:54]
[same as prior period, unchanged from 0000926326-17-000032:mdna:52]

[0000926326-17-000038:mdna:55]
[same as prior period, unchanged from 0000926326-17-000032:mdna:53]

[0000926326-17-000038:mdna:56]
[same as prior period, unchanged from 0000926326-17-000032:mdna:54]

[0000926326-17-000038:mdna:57]
[same as prior period, unchanged from 0000926326-17-000032:mdna:55]

[0000926326-17-000038:mdna:58]
[same as prior period, unchanged from 0000926326-17-000032:mdna:56]

[0000926326-17-000038:mdna:59]
[same as prior period, unchanged from 0000926326-17-000032:mdna:57]

[0000926326-17-000038:mdna:60]
There have been no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the nine months ended September 30, 2017 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2016.

[0000926326-17-000038:mdna:61]
[same as prior period, unchanged from 0000926326-17-000032:mdna:59]

[0000926326-17-000038:mdna:62]
[same as prior period, unchanged from 0000926326-17-000032:mdna:60]

[0000926326-17-000038:mdna:63]
[same as prior period, unchanged from 0000926326-17-000032:mdna:62]

[0000926326-17-000038:mdna:64]
[same as prior period, unchanged from 0000926326-17-000032:mdna:63]

[0000926326-17-000038:mdna:65]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 135,103 |  |  | $ | 133,621 |  |  | $ | 1,482 |  |  | 1 | % |
| Percentage of total revenues | 72 | % |  | 76 | % |  |  |  |  |
| Service and other revenues | 51,679 |  |  | 43,116 |  |  | 8,563 |  |  | 20 | % |
| Percentage of total revenues | 28 | % |  | 24 | % |  |  |  |  |
| Total revenues | $ | 186,782 |  |  | $ | 176,737 |  |  | $ | 10,045 |  |  | 6 | % |

[0000926326-17-000038:mdna:66]
Product revenues represented 72% and 76% of total revenues for the three months ended September 30, 2017 and September 30, 2016, respectively. Product revenues increased by $1.5 million due to increased sales for the Medication Adherence segment of $2.9 million, offset by decreased sales for the Automation and Analytics segment of $1.4 million. The decrease in the Automation and Analytics segment was attributed to a slower conversion of bookings and backlog into revenue due to the introduction of the new XT series of products introduced in the fourth quarter of 2016. The increase in the Medication Adherence segment was attributed to higher completed installations compared to the three months ended September 30, 2016, primarily due to the introduction in the fourth quarter of 2016 our VBM product line. In addition, $1.1 million of the increase was attributed to the Ateb acquisition in the fourth quarter of 2016.

[0000926326-17-000038:mdna:67]
Service and other revenues represented 28% and 24% of total revenues for the three months ended September 30, 2017 and September 30, 2016, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues increased by $8.6 million primarily due to an increase from our

[0000926326-17-000038:mdna:68]
[same as prior period, unchanged from 0000926326-17-000032:mdna:61]

[0000926326-17-000038:mdna:69]
Automation and Analytics segment of $3.7 million attributed to higher service renewal fees, driven mainly by an increase in our installed customer base. Service and other revenues from the Medication Adherence segment increased $4.9 million, primarily attributed to Ateb, acquired in the fourth quarter of 2016, which contributed $5.0 million to the service revenue during the three months ended September 30, 2017.

[0000926326-17-000038:mdna:70]
Our international sales represented 12% and 12% of total revenues for the three months ended September 30, 2017 and 2016, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-17-000038:mdna:71]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 362,089 |  |  | $ | 392,190 |  |  | $ | (30,101 | ) |  | (8 | )% |
| Percentage of total revenues | 70 | % |  | 75 | % |  |  |  |  |
| Service and other revenues | 156,132 |  |  | 128,458 |  |  | 27,674 |  |  | 22 | % |
| Percentage of total revenues | 30 | % |  | 25 | % |  |  |  |  |
| Total revenues | $ | 518,221 |  |  | $ | 520,648 |  |  | $ | (2,427 | ) |  | — | % |

[0000926326-17-000038:mdna:72]
Product revenues represented 70% and 75% of total revenues for the nine months ended September 30, 2017 and September 30, 2016, respectively. Product revenues decreased by $30.1 million due to decreased sales for the Automation and Analytics segment of $35.4 million, partially offset by increased sales for the Medication Adherence segment of $5.3 million. The decrease in the Automation and Analytics segment was attributed to slower conversion of bookings and backlog into revenue as a result of the introduction of the XT series products in the fourth quarter of 2016. The increase in the Medication Adherence segment was attributed to higher machine sales compared to the nine months ended September 30, 2016, primarily due to the introduction of VBM product series in the fourth quarter of 2016. In addition, $2.7 million of the increase was attributed to Ateb.

[0000926326-17-000038:mdna:73]
Service and other revenues represented 30% and 25% of total revenues for the nine months ended September 30, 2017 and September 30, 2016, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues increased by $27.7 million primarily due to an increase from our Automation and Analytics segment of $12.6 million attributed to higher service renewal fees driven mainly by an increase in our installed customer base. Service and other revenues from the Medication Adherence segment increased $15.1 million, primarily attributed to Ateb, which contributed $15.5 million to the service revenue during the nine months ended September 30, 2017.

[0000926326-17-000038:mdna:74]
International revenues represented 13% and 14% of total revenues for the nine months ended September 30, 2017 and 2016, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. The decrease as a percentage of our total revenues in international revenues were primarily related to our recently acquired companies, Aesynt and Ateb, which have a higher market presence in United States compared to international markets. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-17-000038:mdna:75]
Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-17-000038:mdna:76]
30

[0000926326-17-000038:mdna:77]
[same as prior period, unchanged from 0000926326-17-000032:mdna:74]

[0000926326-17-000038:mdna:78]
[same as prior period, unchanged from 0000926326-17-000032:mdna:75]

[0000926326-17-000038:mdna:79]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 154,651 |  |  | $ | 152,437 |  |  | $ | 2,214 |  |  | 1.5 | % |
| Percentage of total revenues | 83 | % |  | 86 | % |  |  |  |  |
| Medication Adherence | 32,131 |  |  | 24,300 |  |  | 7,831 |  |  | 32 | % |
| Percentage of total revenues | 17 | % |  | 14 | % |  |  |  |  |
| Total revenues | $ | 186,782 |  |  | $ | 176,737 |  |  | $ | 10,045 |  |  | 6 | % |

[0000926326-17-000038:mdna:80]
The $2.2 million increase in Automation and Analytics revenues for the three months ended September 30, 2017 in comparison to the three months ended September 30, 2016 was due to an increase in service revenues of $3.7 million, partially offset by a decrease in product revenue of $1.4 million. The decrease in product revenue in the Automation and Analytics segment was attributed to slower conversion of bookings and backlog into revenue as result of the introduction of the XT series products in the fourth quarter of 2016. The service revenue increase of $3.7 million was primarily attributed to higher service renewal fees driven mainly by an increase in installed customer base.

[0000926326-17-000038:mdna:81]
Medication Adherence revenues increased by $7.8 million for the three months ended September 30, 2017 in comparison to the three months ended September 30, 2016. The increase in revenue was due to an increase in product revenue of $2.9 million and an increase in service revenue of $4.9 million. The product revenue increase of $2.9 million was attributed primarily to the introduction of the VBM product series in the fourth quarter of 2016. The service revenue increase of $4.9 million was primarily attributed to Ateb, which contributed $5.0 million to the service revenue during the three months ended September 30, 2017.

[0000926326-17-000038:mdna:82]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 427,250 |  |  | $ | 450,043 |  |  | $ | (22,793 | ) |  | (5 | )% |
| Percentage of total revenues | 82 | % |  | 86 | % |  |  |  |  |
| Medication Adherence | 90,971 |  |  | 70,605 |  |  | 20,366 |  |  | 29 | % |
| Percentage of total revenues | 18 | % |  | 14 | % |  |  |  |  |
| Total revenues | $ | 518,221 |  |  | $ | 520,648 |  |  | $ | (2,427 | ) |  | — | % |

[0000926326-17-000038:mdna:83]
The $22.8 million decrease in Automation and Analytics revenues for the nine months ended September 30, 2017 in comparison to the nine months ended September 30, 2016 was due to a decrease in product revenue of $35.4 million, partially offset by an increase in service revenues of $12.6 million. The decrease in the Automation and Analytics segment was attributed to a slower conversion of bookings and backlog into revenue due to the introduction of the new XT series of products in the fourth quarter of 2016. While we have experienced larger deal sizes, the administrative process of converting our existing bookings of G4 products into XT series products has decelerated revenue recognition during the nine months ended September 30, 2017 compared to the nine months ended September 30, 2016. Service revenue increase of $12.6 million was primarily attributed to higher service renewal fees driven mainly by an increase in installed customer base.

[0000926326-17-000038:mdna:84]
Medication Adherence revenues increased by $20.4 million for the nine months ended September 30, 2017 in comparison to the nine months ended September 30, 2016. The increase in revenue was comprised of an increase in product revenue of $5.3 million and increase in service revenue of $15.1 million. Product revenue increase of $5.3 million was attributed primarily to the introduction of the VBM product series in the fourth quarter of 2016. The service revenue increase of $15.1 million was primarily attributed to Ateb, which contributed $15.5 million to the service revenue during the nine months ended September 30, 2017.

[0000926326-17-000038:mdna:85]
[same as prior period, unchanged from 0000926326-17-000032:mdna:83]

[0000926326-17-000038:mdna:86]
[same as prior period, unchanged from 0000926326-17-000032:mdna:79]

[0000926326-17-000038:mdna:87]
[same as prior period, unchanged from 0000926326-17-000032:mdna:84]

[0000926326-17-000038:mdna:88]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 79,740 |  |  | $ | 77,828 |  |  | $ | 1,912 |  |  | 2 | % |
| As a percentage of related revenues | 52 | % |  | 51 | % |  |  |  |  |
| Medication Adherence | 22,189 |  |  | 17,401 |  |  | 4,788 |  |  | 28 | % |
| As a percentage of related revenues | 69 | % |  | 72 | % |  |  |  |  |
| Total cost of revenues | $ | 101,929 |  |  | $ | 95,229 |  |  | $ | 6,700 |  |  | 7 | % |
| As a percentage of total revenues | 55 | % |  | 54 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 74,911 |  |  | $ | 74,609 |  |  | $ | 302 |  |  | — | % |
| Automation and Analytics gross margin | 48 | % |  | 49 | % |  |  |  |  |
| Medication Adherence | 9,942 |  |  | 6,899 |  |  | 3,043 |  |  | 44 | % |
| Medication Adherence gross margin | 31 | % |  | 28 | % |  |  |  |  |
| Total gross profit | $ | 84,853 |  |  | $ | 81,508 |  |  | $ | 3,345 |  |  | 4 | % |
| Total gross margin | 45 | % |  | 46 | % |  |  |  |  |

[0000926326-17-000038:mdna:89]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 229,218 |  |  | $ | 233,401 |  |  | $ | (4,183 | ) |  | (2 | )% |
| As a percentage of related revenues | 54 | % |  | 52 | % |  |  |  |  |
| Medication Adherence | 61,983 |  |  | 47,777 |  |  | 14,206 |  |  | 30 | % |
| As a percentage of related revenues | 68 | % |  | 68 | % |  |  |  |  |
| Total cost of revenues | $ | 291,201 |  |  | $ | 281,178 |  |  | $ | 10,023 |  |  | 4 | % |
| As a percentage of total revenues | 56 | % |  | 54 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 198,032 |  |  | $ | 216,642 |  |  | $ | (18,610 | ) |  | (9 | )% |
| Automation and Analytics gross margin | 46 | % |  | 48 | % |  |  |  |  |
| Medication Adherence | 28,988 |  |  | 22,828 |  |  | 6,160 |  |  | 27 | % |
| Medication Adherence gross margin | 32 | % |  | 32 | % |  |  |  |  |
| Total gross profit | $ | 227,020 |  |  | $ | 239,470 |  |  | $ | (12,450 | ) |  | (5 | )% |
| Total gross margin | 44 | % |  | 46 | % |  |  |  |  |

[0000926326-17-000038:mdna:90]
Cost of Revenues. Cost of revenues for the three months ended September 30, 2017 compared to the three months ended September 30, 2016 increased by $6.7 million, of which $1.9 million was attributed to the increase of cost of revenue in our Automation and Analytics segment and $4.8 million was attributed to the increase of cost of revenue in our Medication Adherence segment. The increase of the cost of revenue in the Automation and Analytics is consistent with the increase of revenue of $2.2 million in the Automation and Analytics for the three months ended September 30, 2017 compared to the three months ended September 30, 2016. The increase of the cost of revenue in the Medication Adherence segment was attributed to Ateb, which contributed $3.1 million to the increase.

[0000926326-17-000038:mdna:91]
[same as prior period, unchanged from 0000926326-17-000032:mdna:86]

[0000926326-17-000038:mdna:92]
Cost of revenues for the nine months ended September 30, 2017 compared to the nine months ended September 30, 2016 increased by $10.0 million, $14.2 million of which was attributed to the increased cost of revenue in our Medication Adherence segment, partially offset by $4.2 million of decrease in cost of revenue in our Automation and Analytics segment. The decrease of the cost of revenue in the Automation and Analytics segment was attributed to a decrease of $35.4 million in product revenue and costs attributed to the XT series manufacturing ramp up, including addressing quality concerns, partially offset by lower amortization expenses of acquired technology and integration related expenses related to the Aesynt acquisition. The increase of the cost of revenue in the Medication Adherence segment was mainly attributed to Ateb, which contributed $9.1 million to the increase, and increased equipment sales including VBM medication packaging products.

[0000926326-17-000038:mdna:93]
Gross Profit. Gross profit for the three months ended September 30, 2017 increased by $3.3 million compared to the three months ended September 30, 2016 as a result of an increase in gross profit for the Medication Adherence segment of $3.0 million as a result of the Ateb acquisition.

[0000926326-17-000038:mdna:94]
Gross profit for the nine months ended September 30, 2017 decreased by $12.5 million compared to the nine months ended September 30, 2016 primarily due to the decrease in sales as part of the XT series product introduction, partially offset by approximately $9.1 million of gross profit from Ateb.

[0000926326-17-000038:mdna:95]
[same as prior period, unchanged from 0000926326-17-000032:mdna:93]

[0000926326-17-000038:mdna:96]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 16,414 |  |  | $ | 15,264 |  |  | $ | 1,150 |  |  | 8 | % |
| As a percentage of total revenues | 9 | % |  | 9 | % |  |  |  |  |
| Selling, general and administrative | 58,725 |  |  | 61,316 |  |  | (2,591 | ) |  | (4 | )% |
| As a percentage of total revenues | 31 | % |  | 35 | % |  |  |  |  |
| Total operating expenses | $ | 75,139 |  |  | $ | 76,580 |  |  | $ | (1,441 | ) |  | (2 | )% |
| As a percentage of total revenues | 40 | % |  | 43 | % |  |  |  |  |
| Income (loss) from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 28,062 |  |  | $ | 25,486 |  |  | $ | 2,576 |  |  | 10 | % |
| Operating margin | 18 | % |  | 17 | % |  |  |  |  |
| Medication Adherence | 41 |  |  | 762 |  |  | (721 | ) |  | (95 | )% |
| Operating margin | — | % |  | 3 | % |  |  |  |  |
| Corporate Expenses | 18,389 |  |  | 21,320 |  |  | (2,931 | ) |  | (14 | )% |
| Total income (loss) from operations | $ | 9,714 |  |  | $ | 4,928 |  |  | $ | 4,786 |  |  | 97 | % |
| Total operating margin | 5 | % |  | 3 | % |  |  |  |  |

[0000926326-17-000038:mdna:97]
Research and Development. The $1.2 million increase in research and development expenses for the three months ended September 30, 2017 compared to three months ended September 30, 2016 was primarily driven by an increase in research and development expenses of $1.5 million in our Medication Adherence segment as result of the Ateb acquisition which contributed $1.3 million to the increase.

[0000926326-17-000038:mdna:98]
Selling, General and Administrative.  The $2.6 million decrease in selling, general and administrative expenses for the three months ended September 30, 2017 compared to the three months ended September 30, 2016 was primarily due to the decrease in corporate-related expenses of $3.2 million as a result of a decrease in employee-related expenses and a decrease of $1.7 million in our Automation and Analytics segment due to lower amortization expenses from the acquired intangible assets, partially offset by an increase of $2.3 million in our Medication Adherence segment primarily due to the Ateb acquisition, which contributed $2.2 million to the increase.

[0000926326-17-000038:mdna:99]
Operating Income (Loss). Operating income from our Automation and Analytics segment increased by $2.6 million due to the higher gross margin of $0.3 million, partially offset by lower research and development and selling, general and administrative costs of $2.3 million. Operating income from our Medication Adherence segment decreased by $0.7 million due to higher research and development and selling, general and administrative costs of attributed to Ateb, which accounted for $3.4 million of the increase, partially offset by higher gross margin of $3.0 million.

[0000926326-17-000038:mdna:100]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2017 |  | 2016 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 50,128 |  |  | $ | 42,896 |  |  | $ | 7,232 |  |  | 17 | % |
| As a percentage of total revenues | 10 | % |  | 8 | % |  |  |  |  |
| Selling, general and administrative | 186,818 |  |  | 189,912 |  |  | (3,094 | ) |  | (1.6 | )% |
| As a percentage of total revenues | 36 | % |  | 36 | % |  |  |  |  |
| Total operating expenses | $ | 236,946 |  |  | $ | 232,808 |  |  | $ | 4,138 |  |  | 2 | % |
| As a percentage of total revenues | 46 | % |  | 45 | % |  |  |  |  |
| Income (loss) from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 51,381 |  |  | $ | 65,534 |  |  | $ | (14,153 | ) |  | (22 | )% |
| Operating margin | 12 | % |  | 15 | % |  |  |  |  |
| Medication Adherence | (2,208 | ) |  | 5,310 |  |  | (7,518 | ) |  | (142 | )% |
| Operating margin | (2 | )% |  | 8 | % |  |  |  |  |
| Corporate Expenses | 59,099 |  |  | 64,182 |  |  | (5,083 | ) |  | (8 | )% |
| Total income (loss) from operations | $ | (9,926 | ) |  | $ | 6,662 |  |  | $ | (16,588 | ) |  | (249 | )% |
| Total operating margin | (2 | )% |  | 1 | % |  |  |  |  |

[0000926326-17-000038:mdna:101]
Research and Development. Research and development expenses increased by $7.2 million for the nine months ended September 30, 2017 compared to the nine months ended September 30, 2016. The increase was primarily driven by an increase of $4.9 million in our Medication Adherence segment, mainly due to the acquisition of Ateb in the fourth quarter of 2016, which accounted for $3.9 million of this segment's increase, and an increase of $1.4 million for the Automation and Analytics segment research and development expenses, primarily due to restructuring expenses.

[0000926326-17-000038:mdna:102]
Selling, General and Administrative.  Selling, general and administrative expenses decreased by $3.1 million for the nine months ended September 30, 2017 compared to the nine months ended September 30, 2016. The decrease was due to a $5.8 million decrease from our Automation and Analytics segment, and a decrease of $6.0 million in our corporate expenses, partially offset by an increase of $8.8 million in our Medication Adherence segment. The decrease in our Automation and Analytics segment was mainly due to lower amortization expense related to intangible assets and restructuring expenses as most restructuring activities related to this segment were concluded during the nine months ended September 30, 2016. The decrease in our corporate expenses was mainly due to lower integration and acquisition related cost as well as an overall reduction in cost as part of cost saving initiatives. The increase in the Medication Adherence segment is attributed to Ateb, which contributed $7.9 million.

[0000926326-17-000038:mdna:103]
Operating Income (Loss). Operating income from our Automation and Analytics segment decreased by $14.2 million due to the lower gross margin of $18.6 million, partially offset by selling, general and administrative costs. Operating income from our Medication Adherence segment decreased by $7.5 million due to increased research and development and selling, general and administrative costs of $11.8 million attributed to Ateb, partially offset by higher gross margin of $6.2 million.

[0000926326-17-000038:mdna:104]
[same as prior period, unchanged from 0000926326-17-000032:mdna:98]

[0000926326-17-000038:mdna:105]
[same as prior period, unchanged from 0000926326-17-000032:mdna:104]

[0000926326-17-000038:mdna:106]
|  | Three months ended |
|  |  |  |  |  | Change in |
|  | September 30, 2017 |  | September 30, 2016 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 751 |  |  | $ | 224 |  |  | $ | 527 |  |  | 235 | % |

[0000926326-17-000038:mdna:107]
|  | Nine months ended |
|  |  |  |  |  | Change in |
|  | September 30, 2017 |  | September 30, 2016 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (11,232 | ) |  | $ | (557 | ) |  | $ | (10,675 | ) |  | 1,917 | % |

[0000926326-17-000038:mdna:108]
Our estimated effective tax rate before discrete items was 34.4% and 38.3% for the nine months ended September 30, 2017 and 2016, respectively. The decrease in the estimated effective tax rate for the nine months ended September 30, 2017 compared to the same period in 2016 was primarily due to changes in the mix of earnings with differing statutory rates and a decrease in domestic production activities deduction. Additionally, the Company adopted ASU 2016-09 effective January 1, 2017 and is now recognizing all excess tax benefits and tax deficiencies as income tax expense or benefit. An income tax benefit of approximately $2.1 million and $4.7 million for the three and nine months ended September 30, 2017, respectively, was recorded as a result of the adoption of ASU 2016-09.

[0000926326-17-000038:mdna:109]
[same as prior period, unchanged from 0000926326-17-000032:mdna:108]

[0000926326-17-000038:mdna:110]
Our cash position and working capital at September 30, 2017 and December 31, 2016 were as follows:

[0000926326-17-000038:mdna:111]
|  | September 30, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 7,466 |  |  | $ | 54,488 |  |
| Working Capital | $ | 109,511 |  |  | $ | 134,496 |  |

[0000926326-17-000038:mdna:112]
All of our cash and cash equivalents for these periods were invested in bank demand deposits. Our ratio of current assets to current liabilities was 1.5:1 at September 30, 2017 compared to 1.7:1 at December 31, 2016.

[0000926326-17-000038:mdna:113]
[same as prior period, unchanged from 0000926326-17-000032:mdna:112]

[0000926326-17-000038:mdna:114]
On January 5, 2016, we entered into a $400 million secured credit facility pursuant to a credit agreement, by and among us, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as sole lead arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200 million term loan facility (the “Term Loan Facility”) and a $200 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes, including acquisitions. The Credit Agreement replaced our Credit Agreement, dated September 25, 2013, by and among the Company, the lenders from time to time party thereto and Wells Fargo Bank, National Association, as administrative agent, as amended.

[0000926326-17-000038:mdna:115]
Loans under the Facilities bear interest, at our option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on our Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit

[0000926326-17-000038:mdna:116]
[same as prior period, unchanged from 0000926326-17-000032:mdna:103]

[0000926326-17-000038:mdna:117]
[same as prior period, unchanged from 0000926326-17-000032:mdna:115]

[0000926326-17-000038:mdna:118]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us and our subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Credit Agreement also includes financial covenants requiring us not to exceed a maximum consolidated total leverage ratio of 3.00:1 (subject to certain exceptions) and to maintain a minimum fixed charge coverage ratio of 1.50:1.

[0000926326-17-000038:mdna:119]
As of September 30, 2017, the outstanding balance from the facilities (before netting deferred issuance cost) was $197.5 million. We were in full compliance with all covenants.

[0000926326-17-000038:mdna:120]
[same as prior period, unchanged from 0000926326-17-000032:mdna:118]

[0000926326-17-000038:mdna:121]
[same as prior period, unchanged from 0000926326-17-000032:mdna:119]

[0000926326-17-000038:mdna:122]
In accordance with the 2015 Avantec share purchase agreement, we agreed to make potential earn-out payments based on the achievement of bookings targets. Payments earned and paid during the year ended December 31, 2016 were $3.0 million and payments earned and paid to sellers for the period ended September 30, 2017 were $2.4 million.

[0000926326-17-000038:mdna:123]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of September 30, 2017, which may result in additional use of cash.  See "Stock Repurchase Program" under Note 12. Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-17-000038:mdna:124]
[same as prior period, unchanged from 0000926326-17-000032:mdna:122]

[0000926326-17-000038:mdna:125]
[same as prior period, unchanged from 0000926326-17-000032:mdna:123]

[0000926326-17-000038:mdna:126]
The following table summarizes, for the periods indicated, selected items in our Condensed Consolidated Statements of Cash Flows (as adjusted for adoption of ASU 2016-09):

[0000926326-17-000038:mdna:127]
|  | Nine months ended |
|  | September 30, 2017 |  | September 30, 2016 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 20,648 |  |  | $ | 26,030 |  |
| Investing activities | (24,101 | ) |  | (293,343 | ) |
| Financing activities | (42,065 | ) |  | 233,650 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,504 | ) |  | (1,267 | ) |
| Net decrease in cash and cash equivalents | $ | (47,022 | ) |  | $ | (34,930 | ) |

[0000926326-17-000038:mdna:128]
[same as prior period, unchanged from 0000926326-17-000032:mdna:126]

[0000926326-17-000038:mdna:129]
[same as prior period, unchanged from 0000926326-17-000032:mdna:127]

[0000926326-17-000038:mdna:130]
Net cash provided by operating activities was $20.6 million for the nine months ended September 30, 2017, primarily as a result of the net loss of $3.7 million adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $38.5 million, and share-based compensation expense of $16.3 million, deferred income taxes of $11.1 million and $1.2 million of amortization of debt financing fees. The net cash outflow which was contributed to changes in assets and liabilities include (i) an increase in accounts receivable of $21.7 million due to the timing of collections, (ii) an increase in inventories of $22.9 million for inventory buildup in support of

[0000926326-17-000038:mdna:131]
36

[0000926326-17-000038:mdna:132]
forecasted sales, (iii) a decrease in deferred revenue of $7.4 million due to the timing of orders and revenue being recognized for installed product, and (iv) an increase in other current assets of $5.1 million. These outflows were partially offset by an increase in accounts payable of $23.7 million primarily due to the increase in inventory and timing of payments, a decrease in the investment in sales-type leases of $6.6 million, and an increase in other accrued liabilities of $4.0 million.

[0000926326-17-000038:mdna:133]
Net cash provided by operating activities was $26.0 million for the nine months ended September 30, 2016, primarily as a result of $0.4 million in net income adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $43.9 million, share-based compensation expense of $14.1 million and deferred income taxes of $4.8 million. The cash outflow attributed to changes in assets and liabilities includes (i) an increase in accounts receivable of $25.8 million due to increased product shipments late in the quarter, (ii) an increase in inventories of $7.7 million to support forecasted sales, (iii) increases in long-term investment in sales-type leases of $5.3 million due to two significant lease transactions entered into during the year, (iv) increases in prepaid expenses of $5.8 million mainly due to decrease in prepaid commissions and prepaid income taxes, (v) a decrease in accrued liabilities of $1.9 million due to timing of payments to employees related liabilities and (vi) a decrease in the other-long term liabilities of $2.3 million. These amounts were partially offset by an increase in the accounts payables of $5.6 million due to timing of payments, an increase in deferred revenue of $12.8 million due to timing of orders and revenue being recognized for installed product, and decreases in other long-term assets of $1.2 million.

[0000926326-17-000038:mdna:134]
[same as prior period, unchanged from 0000926326-17-000032:mdna:132]

[0000926326-17-000038:mdna:135]
Net cash used in investing activities was $24.1 million for the nine months ended September 30, 2017, which consisted of capital expenditures of $9.4 million for property and equipment, $10.3 million for costs of software development mainly related to the Performance Center offering and purchase of intangibles, and $4.4 million attributable to the acquisition of InPharmics.

[0000926326-17-000038:mdna:136]
Net cash used in investing activities was $293.3 million for the nine months ended September 30, 2016, $271.5 million of which was attributable to the acquisition of Aesynt. Capital expenditures related to purchases of property and equipment, software development costs for external use, and purchases of intangible assets contributed $10.0 million, $10.6 million, and $1.3 million, respectively.

[0000926326-17-000038:mdna:137]
[same as prior period, unchanged from 0000926326-17-000032:mdna:135]

[0000926326-17-000038:mdna:138]
Net cash used in financing activities was $42.1 million for the nine months ended September 30, 2017, primarily from the repayment of $100.0 million of the credit facilities and $3.1 million in employees' taxes paid related to restricted stock unit vesting, partially offset by $26.5 million in proceeds from employee stock option exercises and employee stock plan purchases, and $37.0 million proceeds from term loan and revolving credit facilities.

[0000926326-17-000038:mdna:139]
Net cash provided by financing activities was $233.7 million for the nine months ended September 30, 2016 as a result of proceeds from term loan and revolving credit facilities of $247.1 million, net of deferred issuance cost of $7.9 million, and $16.5 million in proceeds from employee stock option exercises and employee stock plan purchases. The increase in cash provided from financing activities was partially offset by repayment of $25.0 million of the credit facilities, payment of contingent consideration of $3.0 million related to the Avantec acquisition, and $1.9 million in employees' taxes paid related to restricted stock units

[0000926326-17-000038:mdna:140]
[same as prior period, unchanged from 0000926326-17-000032:mdna:138]

[0000926326-17-000038:mdna:141]
There have been no significant changes during the nine months ended September 30, 2017 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2016.

[0000926326-17-000038:mdna:142]
We had $337.8 million in contractual commitments to third parties for non-cancelable operating leases, commitments to contract manufacturers and suppliers, other purchase commitments and term loan and revolving credit facility as of September 30, 2017 as follows:

[0000926326-17-000038:mdna:143]
|  | Payments due by period |
|  | Total |  | Remainder of 2017 |  | 2018 and 2019 |  | 2020 and 2021 |  | Thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 80,376 |  |  | $ | 3,203 |  |  | $ | 24,717 |  |  | $ | 21,288 |  |  | $ | 31,168 |  |
| Purchase obligations (2) | 59,928 |  |  | 46,477 |  |  | 11,343 |  |  | 1,173 |  |  | 935 |  |
| Term loan facility (3) | 185,000 |  |  | 2,500 |  |  | 37,500 |  |  | 145,000 |  |  | — |  |
| Revolving credit facility (3) | 12,500 |  |  | — |  |  | — |  |  | 12,500 |  |  | — |  |
| Total (4) | $ | 337,804 |  |  | $ | 52,180 |  |  | $ | 73,560 |  |  | $ | 179,961 |  |  | $ | 32,103 |  |

[0000926326-17-000038:mdna:144]
[same as prior period, unchanged from 0000926326-17-000032:mdna:142]

[0000926326-17-000038:mdna:145]
[same as prior period, unchanged from 0000926326-17-000032:mdna:143]

[0000926326-17-000038:mdna:146]
[same as prior period, unchanged from 0000926326-17-000032:mdna:144]

[0000926326-17-000038:mdna:147]
| (3) | Amounts shown for term loan and revolving credit facility are principal repayments only. Due to use of interest rate swaps, the cash interest expense is partly variable and partly fixed, and is not reflected in the above table. Refer to Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this quarterly report. |

[0000926326-17-000038:mdna:148]
| (4) | We have recorded $6.8 million for uncertain tax positions under long-term liabilities as of September 30, 2017 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $6.8 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-17-000038:mdna:149]
[same as prior period, unchanged from 0000926326-17-000032:mdna:147]

[0000926326-17-000038:mdna:150]
As of September 30, 2017, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
