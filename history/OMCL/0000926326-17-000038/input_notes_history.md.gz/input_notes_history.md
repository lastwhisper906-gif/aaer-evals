# OMCL note change history — 0000926326-17-000032 → 0000926326-17-000038


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-11-03):
[0000926326-17-000038:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At September 30, 2017, the minimum future payments on non-cancelable operating leases were as follows:
  (was, 2017-08-04, similarity 0.7992):
[0000926326-17-000032:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At June 30, 2017, the minimum future payments on non-cancelable operating leases were as follows:

- changed (2017-11-03):
[0000926326-17-000038:note_history:2]
|  | (In thousands) |
| Remaining three months of 2017 | $ | 3,203 |  |
| 2018 | 12,447 |  |
| 2019 | 12,270 |  |
| 2020 | 10,972 |  |
| 2021 | 10,316 |  |
| Thereafter | 31,168 |  |
| Total minimum future lease payments | $ | 80,376 |  |
  (was, 2017-08-04, similarity 0.9778):
[0000926326-17-000032:note_history:2]
|  | (In thousands) |
| Remaining six months of 2017 | $ | 6,387 |  |
| 2018 | 12,411 |  |
| 2019 | 12,250 |  |
| 2020 | 10,979 |  |
| 2021 | 10,300 |  |
| Thereafter | 31,120 |  |
| Total minimum future lease payments | $ | 83,447 |  |

- changed (2017-11-03):
[0000926326-17-000038:note_history:3]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At September 30, 2017, the Company had non-cancelable purchase commitments of $59.9 million, which are expected to be paid within the next twelve months.
  (was, 2017-08-04, similarity 0.9745):
[0000926326-17-000032:note_history:3]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At June 30, 2017, the Company had non-cancelable purchase commitments of $60.9 million, which are expected to be paid within the next twelve months.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-03):
[0000926326-17-000038:note_history:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2017 and December 31, 2016, the results of its operations, comprehensive income (loss) and cash flows for the three and nine months ended September 30, 2017 and September 30, 2016. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2016 filed with the SEC on February 28, 2017. The Company's results of operations, comprehensive income (loss) and cash flows for the three and nine months ended September 30, 2017 are not necessarily indicative of results that may be expected for the year ending December 31, 2017, or for any future period.
  (was, 2017-08-04, similarity 0.8615):
[0000926326-17-000032:note_history:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2017 and December 31, 2016, the results of its operations, comprehensive income (loss) and cash flows for the three and six months ended June 30, 2017 and June 30, 2016. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2016 filed with the SEC on February 28, 2017. The Company's results of operations, comprehensive income (loss) and cash flows for the three and six months ended June 30, 2017 are not necessarily indicative of results that may be expected for the year ending December 31, 2017, or for any future period.

- added (2017-11-03):
[0000926326-17-000038:note_history:5]
Certain prior year amounts have been reclassified to conform to the 2017 presentation with the adoption of ASU 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. Additionally, see "Recently adopted authoritative guidance" for the effects of first quarter adoption of ASU 2016-09.

- changed (2017-11-03):
[0000926326-17-000038:note_history:6]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain other administrative expenses.  See Note 13, Segment and Geographical Information, for additional information on segment reporting.
  (was, 2017-08-04, similarity 0.9957):
[0000926326-17-000032:note_history:6]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain administrative expenses.  See Note 13, Segment and Geographical Information, for additional information on segment reporting.

- changed (2017-11-03):
[0000926326-17-000038:note_history:7]
In March 2016, the FASB issued ASU No. 2016-09. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. The Company adopted the standard effective January 1, 2017.  The impact of adoption was the recording of excess tax benefits within income tax expense, rather than in Additional Paid in Capital of $2.1 million and $4.7 million for the three and nine months ended September 30, 2017, respectively.  Additionally, in the first quarter of 2017, the Company recognized the previously unrecognized excess tax benefits using the modified retrospective transition method, which resulted in a cumulative-effect adjustment of $1.6 million to retained earnings.
  (was, 2017-08-04, similarity 0.8701):
[0000926326-17-000032:note_history:7]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. The Company adopted the standard effective January 1, 2017.  The impact of adoption was the recording of excess tax benefits within income tax expense, rather than in Additional Paid in Capital of $0.8 million and $2.6 million for the three and six months ended June 30, 2017, respectively.  Additionally, in the first quarter of 2017, the Company recognized the previously unrecognized excess tax benefits using the modified retrospective transition method, which resulted in a cumulative-effect adjustment of $1.6 million to retained earnings.

- changed (2017-11-03):
[0000926326-17-000038:note_history:8]
In January 2017, the FASB issued ASU 2017-04, Intangibles-Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment, which simplifies the accounting for goodwill impairment for all entities by requiring impairment charges to be based on the first step in today’s two-step impairment test under ASC 350, “Intangibles-Goodwill and Other.” Under the new guidance, if a reporting unit’s carrying amount exceeds its fair value, an entity will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill allocated to that reporting unit. The standard eliminates the current ASC 350 requirement to calculate a goodwill impairment charge using Step 2. ASU 2017-04 is effective for annual and interim impairment tests performed in periods beginning after December 15, 2019. Early adoption is permitted for annual and interim goodwill impairment testing dates after January 1, 2017. The Company adopted ASU 2017-04 effective January 1, 2017. The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the periods presented.
  (was, 2017-08-04, similarity 0.9996):
[0000926326-17-000032:note_history:8]
In January 2017, the FASB issued ASU 2017-04, Intangibles-Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment, which simplifies the accounting for goodwill impairment for all entities by requiring impairment charges to be based on the first step in today’s two-step impairment test under ASC 350, “Intangibles-Goodwill and Other.” Under the new guidance, if a reporting unit’s carrying amount exceeds its fair value, an entity will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill allocated to that reporting unit. The standard eliminates the current ASC 350 requirement to calculate a goodwill impairment charge using Step 2. ASU 2017-14 is effective for annual and interim impairment tests performed in periods beginning after December 15, 2019. Early adoption is permitted for annual and interim goodwill impairment testing dates after January 1, 2017. The Company adopted ASU 2017-04 effective January 1, 2017. The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the period presented.

- changed (2017-11-03):
[0000926326-17-000038:note_history:9]
In January 2017, the FASB issued ASU 2017-01, Business Combinations, which clarifies the definition of a business and provides a screen to determine when a set of assets and activities is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set is not a business. This screen reduces the number of transactions that need to be further evaluated. ASU 2017-01 is effective for fiscal years beginning after December 15, 2017, with early adoption permitted.  The Company adopted ASU 2017-01 effective January 1, 2017.  The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the periods presented.
  (was, 2017-08-04, similarity 0.9994):
[0000926326-17-000032:note_history:9]
In January 2017, the FASB issued ASU 2017-01, Business Combinations, which clarifies the definition of a business and provides a screen to determine when a set of assets and activities is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set is not a business. This screen reduces the number of transactions that need to be further evaluated. ASU 2017-01 is effective for fiscal years beginning after December 15, 2017, with early adoption permitted.  The Company adopted ASU 2017-01 effective January 1, 2017.  The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the period presented.

- added (2017-11-03):
[0000926326-17-000038:note_history:10]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815), which simplifies the application of the hedge accounting guidance and improves the financial reporting, specifically simplifies designation and measurement for qualifying hedging relationships and the presentation of hedge results. ASU 2017-12 is effective for annual periods beginning after December 15, 2018 and interim periods within those annual periods with early adoption permitted. The Company adopted ASU 2017-12 effective August 1, 2017. The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the periods presented.

- changed (2017-11-03):
[0000926326-17-000038:note_history:11]
Currently, the Company is in the process of reviewing its historical contracts to quantify the impact on its consolidated financial statements. The most significant impact of the standard relates to accounting for term software license revenue, contingent income, and commission expense.  Specifically, under the standard the Company expects to recognize revenue on term software licenses upon installation of the license rather than ratably over the life of the term license.  Additionally, the standard no longer requires deferral of contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price which will result in earlier recognition of revenue.  Finally, the standard requires expense to be recognized for incremental costs incurred to obtain a contract, primarily commission expense, on a systematic basis that is consistent with the transfer to the customer of the product and services to which the cost relates, including an estimate of the period of service renewals for the transaction. Currently, the Company recognizes commission expense at the time of recognizing the related product revenue. The Company is also in the process of assessing the appropriate changes to its business processes and upgrading its systems and controls to support recognition and disclosure under ASU 2014-09. The Company expects to complete its assessment process within the last quarter of 2017.
  (was, 2017-08-04, similarity 0.8641):
[0000926326-17-000032:note_history:11]
Currently, the Company is in the process of reviewing its historical contracts to quantify the impact on its consolidated financial statements. The most significant impact of the standard relates to accounting for term software license revenue, contingent income, and commission expense.  Specifically, under the standard the Company expects to recognize revenue on term software licenses upon installation of the license rather than ratably over the life of the term license.  Additionally, the standard no longer requires deferral of contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price which will result in earlier recognition of revenue.  Finally, the standard requires expense to be recognized for incremental costs incurred to obtain a contract, primarily commission expense, on a systematic basis that is consistent with the transfer to the customer of the product and services to which the cost relates.  Rather than recognize commission expense at the time of recognizing the related product revenue, the new standard will require commission expense to be recognized consistent with the timing of product and service revenue, including an estimate of the period of service renewals for the transaction.  The company is also in the process of assessing the appropriate changes to its business processes and upgrading its systems and controls to support recognition and disclosure under ASU 2014-09. The Company expects to complete its assessment process within the next two quarters of 2017.

- removed (2017-11-03):
[0000926326-17-000032:note_history:12]
Certain prior year amounts have been reclassified to conform to the 2017 presentation. These reclassifications include: (i) provision for excess and obsolete inventories, and (ii) provision for the allowance for doubtful accounts have been reclassified/combined with inventories and accounts receivable within net cash provided by operating activities in the Consolidated Statements of Cash Flows. These changes are not material and do not impact previously disclosed net cash provided by operating activities, net cash used in investing activities, and net cash used by financing activities.

- removed (2017-11-03):
[0000926326-17-000032:note_history:13]
Additionally, see "Recently adopted authoritative guidance" for the effects of first quarter adoption of ASU 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-03):
[0000926326-17-000038:note_history:14]
On January 5, 2016, the Company borrowed the full $200.0 million under the Term Loan Facility and $55.0 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses. On December 2, 2016, the Company borrowed $40.0 million under the Revolving Credit Facility to complete the Ateb acquisition and pay related fees and expenses. On April 3, 2017, the Company borrowed an additional $10.0 million under the Revolving Credit Facility to pay for the InPharmics acquisition and fund its operations. On July 7, 2017 and July 31, 2017, the Company borrowed an additional $15.0 million and $12.0 million, respectively, under the Revolving Credit Facility to fund its operations. As of September 30, 2017 the Company has repaid $134.5 million borrowed under these Facilities, which includes $100.0 million repaid during the nine months ended September 30, 2017.
  (was, 2017-08-04, similarity 0.6937):
[0000926326-17-000032:note_history:14]
On January 5, 2016, the Company borrowed the full $200.0 million under the Term Loan Facility and $55.0 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses. On December 2, 2016, the Company borrowed $40.0 million under the Revolving Credit Facility to complete the Ateb acquisition and pay related fees and expenses. On April 3, 2017, the Company borrowed an additional $10.0 million under the Revolving Credit Facility to pay for the InPhamics acquisition and fund its operations. As of June 30, 2017 the Company has repaid $105.0 million borrowed under these Facilities, which includes $70.5 million repaid during the six months ended June 30, 2017.

- changed (2017-11-03):
[0000926326-17-000038:note_history:15]
In connection with these Facilities, the Company incurred $7.9 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.6 million and $1.2 million for the three months ended September 30, 2017 and 2016, respectively. Interest expense (exclusive of fees and issuance cost amortization) was approximately $4.6 million and $4.0 million for the nine months ended September 30, 2017 and 2016, respectively. The Company was in full compliance with all covenants as of September 30, 2017 and December 31, 2016.
  (was, 2017-08-04, similarity 0.9397):
[0000926326-17-000032:note_history:15]
In connection with these Facilities, the Company incurred $7.9 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.5 million and $1.2 million for the three months ended June 30, 2017 and 2016, respectively. Interest expense (exclusive of fees and issuance cost amortization) was approximately $3.0 million and $2.8 million for the six months ended June 30, 2017 and 2016, respectively. The Company was in full compliance with all covenants as of June 30, 2017 and December 31, 2016.

- changed (2017-11-03):
[0000926326-17-000038:note_history:16]
The components of the Company’s debt obligations for the nine months ended September 30, 2017 are as follows:
  (was, 2017-08-04, similarity 0.9208):
[0000926326-17-000032:note_history:16]
The components of the Company’s debt obligations for the six months ended June 30, 2017 are as follows:

- added (2017-11-03):
[0000926326-17-000038:note_history:17]
|  | December 31, 2016 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2017 |
|  | (In thousands) |
| Term loan facility | $ | 192,500 |  |  | $ | — |  |  | $ | (7,500 | ) |  | $ | 185,000 |  |
| Revolving credit facility | 68,000 |  |  | 37,000 |  |  | (92,500 | ) |  | 12,500 |  |
| Total debt under the facilities | 260,500 |  |  | 37,000 |  |  | (100,000 | ) |  | 197,500 |  |
| Less: Deferred issuance cost | (6,359 | ) |  | — |  |  | 1,192 |  |  | (5,167 | ) |
| Total Debt, net of deferred issuance cost | $ | 254,141 |  |  | $ | 37,000 |  |  | $ | (98,808 | ) |  | $ | 192,333 |  |
| Long term debt, current portion, net of deferred issuance cost | 8,410 |  |  |  |  |  |  | 13,410 |  |
| Long term debt, net of deferred issuance cost | $ | 245,731 |  |  |  |  |  |  | $ | 178,923 |  |

- changed (2017-11-03):
[0000926326-17-000038:note_history:18]
As of September 30, 2017, the carrying amount of debt of $197.5 million approximates the comparable fair value of $199.2 million. The Company's debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments, and long-term credit ratings.
  (was, 2017-08-04, similarity 0.9849):
[0000926326-17-000032:note_history:18]
As of June 30, 2017, the carrying amount of debt of $200.0 million approximates the comparable fair value of $200.9 million. The Company's debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments, and long-term credit ratings.

- removed (2017-11-03):
[0000926326-17-000032:note_history:19]
|  | December 31, 2016 |  | Borrowings |  | Repayment / Amortization |  | June 30, 2017 |
|  | (In thousands) |
| Term loan facility | $ | 192,500 |  |  | $ | — |  |  | $ | (5,000 | ) |  | $ | 187,500 |  |
| Revolving credit facility | 68,000 |  |  | 10,000 |  |  | (65,500 | ) |  | 12,500 |  |
| Total debt under the facilities | 260,500 |  |  | 10,000 |  |  | (70,500 | ) |  | 200,000 |  |
| Less: Deferred issuance cost | (6,359 | ) |  | — |  |  | 795 |  |  | (5,564 | ) |
| Total Debt, net of deferred issuance cost | $ | 254,141 |  |  | $ | 10,000 |  |  | $ | (69,705 | ) |  | $ | 194,436 |  |
| Long term debt, current portion, net of deferred issuance cost | 8,410 |  |  |  |  |  |  | 10,910 |  |
| Long term debt, net of deferred issuance cost | $ | 245,731 |  |  |  |  |  |  | $ | 183,526 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-03):
[0000926326-17-000038:note_history:20]
The components of the Company’s debt obligations for the nine months ended September 30, 2017 are as follows:
  (was, 2017-08-04, similarity 0.9208):
[0000926326-17-000032:note_history:20]
The components of the Company’s debt obligations for the six months ended June 30, 2017 are as follows:

- added (2017-11-03):
[0000926326-17-000038:note_history:21]
|  | December 31, 2016 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2017 |
|  | (In thousands) |
| Term loan facility | $ | 192,500 |  |  | $ | — |  |  | $ | (7,500 | ) |  | $ | 185,000 |  |
| Revolving credit facility | 68,000 |  |  | 37,000 |  |  | (92,500 | ) |  | 12,500 |  |
| Total debt under the facilities | 260,500 |  |  | 37,000 |  |  | (100,000 | ) |  | 197,500 |  |
| Less: Deferred issuance cost | (6,359 | ) |  | — |  |  | 1,192 |  |  | (5,167 | ) |
| Total Debt, net of deferred issuance cost | $ | 254,141 |  |  | $ | 37,000 |  |  | $ | (98,808 | ) |  | $ | 192,333 |  |
| Long term debt, current portion, net of deferred issuance cost | 8,410 |  |  |  |  |  |  | 13,410 |  |
| Long term debt, net of deferred issuance cost | $ | 245,731 |  |  |  |  |  |  | $ | 178,923 |  |

- removed (2017-11-03):
[0000926326-17-000032:note_history:22]
|  | December 31, 2016 |  | Borrowings |  | Repayment / Amortization |  | June 30, 2017 |
|  | (In thousands) |
| Term loan facility | $ | 192,500 |  |  | $ | — |  |  | $ | (5,000 | ) |  | $ | 187,500 |  |
| Revolving credit facility | 68,000 |  |  | 10,000 |  |  | (65,500 | ) |  | 12,500 |  |
| Total debt under the facilities | 260,500 |  |  | 10,000 |  |  | (70,500 | ) |  | 200,000 |  |
| Less: Deferred issuance cost | (6,359 | ) |  | — |  |  | 795 |  |  | (5,564 | ) |
| Total Debt, net of deferred issuance cost | $ | 254,141 |  |  | $ | 10,000 |  |  | $ | (69,705 | ) |  | $ | 194,436 |  |
| Long term debt, current portion, net of deferred issuance cost | 8,410 |  |  |  |  |  |  | 10,910 |  |
| Long term debt, net of deferred issuance cost | $ | 245,731 |  |  |  |  |  |  | $ | 183,526 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2017-11-03):
[0000926326-17-000038:note_history:23]
On October 2, 2017 and October 10, 2017, the Company borrowed $12.0 million and $10.0 million, respectively, under the Revolving Credit Facility to fund its operations.
  (was, 2017-08-04, similarity 0.9262):
[0000926326-17-000032:note_history:23]
On  July 7, 2017 and July 31, 2017, the Company borrowed $15.0 million and $12.0 million, respectively, under the Revolving Credit Facility to fund its operations.
