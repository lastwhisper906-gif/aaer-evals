# OMCL notes — 0000926326-17-000038


## omcl:ScheduleofLongTermNetInvestmentinSaleTypeLeasesTableTextBlock

[0000926326-17-000038:notes:1]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at September 30, 2017 and December 31, 2016:

[0000926326-17-000038:notes:2]
|  | September 30, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 26,173 |  |  | $ | 33,591 |  |
| Less: Unearned interest income portion | (1,986 | ) |  | (2,763 | ) |
| Net investment in sales-type leases | 24,187 |  |  | 30,828 |  |
| Less: Short-term portion(1) | (8,201 | ) |  | (10,243 | ) |
| Long-term net investment in sales-type leases | $ | 15,986 |  |  | $ | 20,585 |  |

[0000926326-17-000038:notes:3]
[same as prior period, unchanged from 0000926326-17-000032:notes:3]


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-17-000038:notes:4]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of September 30, 2017:

[0000926326-17-000038:notes:5]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 2,965 |  |
| Non-vested restricted share awards | 741 |  |
| Shares authorized for future issuance | 2,191 |  |
| ESPP shares available for future issuance | 2,365 |  |
| Total shares reserved for future issuance | 8,262 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-17-000038:notes:6]
[same as prior period, unchanged from 0000926326-17-000032:notes:6]

[0000926326-17-000038:notes:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2017 and December 31, 2016, the results of its operations, comprehensive income (loss) and cash flows for the three and nine months ended September 30, 2017 and September 30, 2016. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2016 filed with the SEC on February 28, 2017. The Company's results of operations, comprehensive income (loss) and cash flows for the three and nine months ended September 30, 2017 are not necessarily indicative of results that may be expected for the year ending December 31, 2017, or for any future period.


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-17-000038:notes:8]
[same as prior period, unchanged from 0000926326-17-000032:notes:8]

[0000926326-17-000038:notes:9]
On a recurring basis, we enter into sales-type lease transactions with the majority varying in length from one to five years. The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at September 30, 2017 and December 31, 2016:

[0000926326-17-000038:notes:10]
The Company evaluates its sales-type leases individually and collectively for impairment.  The allowance for credit losses were $0.2 million and $0.3 million as of September 30, 2017 and of December 31, 2016, respectively.

[0000926326-17-000038:notes:11]
At September 30, 2017, the future minimum lease payments under sales-type leases are as follows:

[0000926326-17-000038:notes:12]
|  | September 30, 2017 |
|  | (In thousands) |
| Remaining three months of 2017 | $ | 2,470 |  |
| 2018 | 8,038 |  |
| 2019 | 6,474 |  |
| 2020 | 4,548 |  |
| 2021 | 2,749 |  |
| Thereafter | 1,894 |  |
| Total | $ | 26,173 |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-17-000038:notes:13]
Commitments and Contingencies

[0000926326-17-000038:notes:14]
Lease commitments

[0000926326-17-000038:notes:15]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At September 30, 2017, the minimum future payments on non-cancelable operating leases were as follows:

[0000926326-17-000038:notes:16]
|  | (In thousands) |
| Remaining three months of 2017 | $ | 3,203 |  |
| 2018 | 12,447 |  |
| 2019 | 12,270 |  |
| 2020 | 10,972 |  |
| 2021 | 10,316 |  |
| Thereafter | 31,168 |  |
| Total minimum future lease payments | $ | 80,376 |  |

[0000926326-17-000038:notes:17]
Purchase obligations

[0000926326-17-000038:notes:18]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At September 30, 2017, the Company had non-cancelable purchase commitments of $59.9 million, which are expected to be paid within the next twelve months.

[0000926326-17-000038:notes:19]
Legal Proceedings

[0000926326-17-000038:notes:20]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-17-000038:notes:21]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company's financial position or results of operations.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-17-000038:notes:22]
[same as prior period, unchanged from 0000926326-17-000032:notes:22]

[0000926326-17-000038:notes:23]
[same as prior period, unchanged from 0000926326-17-000032:notes:23]


## us-gaap:DebtDisclosureTextBlock

[0000926326-17-000038:notes:24]
Debt

[0000926326-17-000038:notes:25]
On January 5, 2016, the Company entered into a $400 million senior secured credit facility pursuant to a credit agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200 million (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-17-000038:notes:26]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the 2016 Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-17-000038:notes:27]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-17-000038:notes:28]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.

[0000926326-17-000038:notes:29]
On January 5, 2016, the Company borrowed the full $200.0 million under the Term Loan Facility and $55.0 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses. On December 2, 2016, the Company borrowed $40.0 million under the Revolving Credit Facility to complete the Ateb acquisition and pay related fees and expenses. On April 3, 2017, the Company borrowed an additional $10.0 million under the Revolving Credit Facility to pay for the InPharmics acquisition and fund its operations. On July 7, 2017 and July 31, 2017, the Company borrowed an additional $15.0 million and $12.0 million, respectively, under the Revolving Credit Facility to fund its operations. As of September 30, 2017 the Company has repaid $134.5 million borrowed under these Facilities, which includes $100.0 million repaid during the nine months ended September 30, 2017.

[0000926326-17-000038:notes:30]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement. Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

[0000926326-17-000038:notes:31]
In connection with these Facilities, the Company incurred $7.9 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.6 million and $1.2 million for the three months ended September 30, 2017 and 2016, respectively. Interest expense (exclusive of fees and issuance cost amortization) was approximately $4.6 million and $4.0 million for the nine months ended September 30, 2017 and 2016, respectively. The Company was in full compliance with all covenants as of September 30, 2017 and December 31, 2016.

[0000926326-17-000038:notes:32]
The components of the Company’s debt obligations for the nine months ended September 30, 2017 are as follows:

[0000926326-17-000038:notes:33]
|  | December 31, 2016 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2017 |
|  | (In thousands) |
| Term loan facility | $ | 192,500 |  |  | $ | — |  |  | $ | (7,500 | ) |  | $ | 185,000 |  |
| Revolving credit facility | 68,000 |  |  | 37,000 |  |  | (92,500 | ) |  | 12,500 |  |
| Total debt under the facilities | 260,500 |  |  | 37,000 |  |  | (100,000 | ) |  | 197,500 |  |
| Less: Deferred issuance cost | (6,359 | ) |  | — |  |  | 1,192 |  |  | (5,167 | ) |
| Total Debt, net of deferred issuance cost | $ | 254,141 |  |  | $ | 37,000 |  |  | $ | (98,808 | ) |  | $ | 192,333 |  |
| Long term debt, current portion, net of deferred issuance cost | 8,410 |  |  |  |  |  |  | 13,410 |  |
| Long term debt, net of deferred issuance cost | $ | 245,731 |  |  |  |  |  |  | $ | 178,923 |  |

[0000926326-17-000038:notes:34]
As of September 30, 2017, the carrying amount of debt of $197.5 million approximates the comparable fair value of $199.2 million. The Company's debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments, and long-term credit ratings.


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-17-000038:notes:35]
[same as prior period, unchanged from 0000926326-17-000032:notes:35]

[0000926326-17-000038:notes:36]
Short-term deferred revenue includes deferred revenue from product sales and service contracts, net of deferred cost of sales of $14.5 million and $14.2 million as of September 30, 2017 and December 31, 2016, respectively. The short-term deferred revenues from product sales relate to the delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

[0000926326-17-000038:notes:37]
Long-term deferred revenue includes deferred revenue from service contracts of $16.4 million and $17.1 million, as of September 30, 2017 and December 31, 2016, respectively.


## us-gaap:EarningsPerShareTextBlock

[0000926326-17-000038:notes:38]
[same as prior period, unchanged from 0000926326-17-000032:notes:38]

[0000926326-17-000038:notes:39]
[same as prior period, unchanged from 0000926326-17-000032:notes:39]

[0000926326-17-000038:notes:40]
The basic and diluted net income (loss) per share calculation for the three and nine months ended September 30, 2017 and 2016 is as follows:

[0000926326-17-000038:notes:41]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | 6,231 |  |  | $ | 1,983 |  |  | $ | (3,686 | ) |  | $ | 446 |  |
| Weighted-average shares outstanding — basic | 37,698 |  |  | 36,332 |  |  | 37,266 |  |  | 36,020 |  |
| Effect of dilutive securities from stock award plans | 1,275 |  |  | 747 |  |  | — |  |  | 675 |  |
| Weighted-average shares outstanding — diluted | $ | 38,973 |  |  | $ | 37,079 |  |  | 37,266 |  |  | 36,695 |  |
| Net income (loss) per share - basic | $ | 0.17 |  |  | $ | 0.05 |  |  | $ | (0.10 | ) |  | $ | 0.01 |  |
| Net income (loss) per share - diluted | $ | 0.16 |  |  | $ | 0.05 |  |  | $ | (0.10 | ) |  | $ | 0.01 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 1,383 |  |  | 326 |  |  | 3,757 |  |  | 1,255 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-17-000038:notes:42]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of September 30, 2017:

[0000926326-17-000038:notes:43]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 1,200 |  |  | $ | — |  |  | $ | 1,200 |  |
| Total financial assets | $ | — |  |  | $ | 1,200 |  |  | $ | — |  |  | $ | 1,200 |  |

[0000926326-17-000038:notes:44]
There have been no transfers between fair value measurement levels during the nine months ended September 30, 2017 and September 30, 2016.

[0000926326-17-000038:notes:45]
[same as prior period, unchanged from 0000926326-17-000032:notes:45]

[0000926326-17-000038:notes:46]
[same as prior period, unchanged from 0000926326-17-000032:notes:46]


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-17-000038:notes:47]
[same as prior period, unchanged from 0000926326-17-000032:notes:47]

[0000926326-17-000038:notes:48]
Cash and cash equivalents of $7.5 million and $54.5 million as of September 30, 2017 and December 31, 2016, respectively, consisted of demand deposits only.

[0000926326-17-000038:notes:49]
[same as prior period, unchanged from 0000926326-17-000032:notes:49]

[0000926326-17-000038:notes:50]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's foreign currency contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments. In accordance with the 2015 Avantec share purchase agreement, the Company agreed to make potential earn-out payments of $3.0 million based on the achievement of bookings targets. The Company has concluded that only $2.4 million of the total potential earn out payment has been earned, which was paid out during the three month period ended September 30, 2017.

[0000926326-17-000038:notes:51]
[same as prior period, unchanged from 0000926326-17-000032:notes:51]

[0000926326-17-000038:notes:52]
[same as prior period, unchanged from 0000926326-17-000032:notes:52]

[0000926326-17-000038:notes:53]
[same as prior period, unchanged from 0000926326-17-000032:notes:53]

[0000926326-17-000038:notes:54]
[same as prior period, unchanged from 0000926326-17-000032:notes:54]

[0000926326-17-000038:notes:55]
The fair value of the interest rate swap agreements at September 30, 2017 and December 31, 2016 was $1.2 million and $1.2 million, respectively. There were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.


## us-gaap:FiniteLivedAndIndefiniteLivedIntangibleAssetsAcquiredAsPartOfBusinessCombinationTableTextBlock

[0000926326-17-000038:notes:56]
[same as prior period, unchanged from 0000926326-17-000032:notes:56]

[0000926326-17-000038:notes:57]
|  | Aesynt |  | Ateb (Preliminary) |
|  | Fair value |  | Weightedaverageuseful life |  | Fair value |  | Weightedaverageuseful life |
|  | (In thousands) |  | (In years) |  | (In thousands) |  | (In years) |
| Customer relationships | $ | 58,200 |  |  | 14-16 |  | $ | 8,900 |  |  | 12 |
| Developed technology | 38,800 |  |  | 8 |  | 3,400 |  |  | 5 |
| Backlog | 20,200 |  |  | 1-3 |  | — |  | — |
| In-process research and development (1) | 3,900 |  |  | — |  | — |  | — |
| Non-compete | 1,800 |  |  | 3 |  | 100 |  |  | 1 |
| Trade names | 800 |  |  | 1 |  | 100 |  |  | 1 |
| Total purchased intangible assets | $ | 123,700 |  |  |  |  | $ | 12,500 |  |  |  |

[0000926326-17-000038:notes:58]
[same as prior period, unchanged from 0000926326-17-000032:notes:58]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-17-000038:notes:59]
[same as prior period, unchanged from 0000926326-17-000032:notes:59]

[0000926326-17-000038:notes:60]
[same as prior period, unchanged from 0000926326-17-000032:notes:60]

[0000926326-17-000038:notes:61]
[same as prior period, unchanged from 0000926326-17-000032:notes:61]

[0000926326-17-000038:notes:62]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2016 | $ | 215,082 |  |  | $ | 112,642 |  |  | $ | 327,724 |  |
| Goodwill acquired | 3,113 |  |  | 819 |  |  | 3,932 |  |
| Foreign currency exchange rate fluctuations | 2,351 |  |  | 773 |  |  | 3,124 |  |
| Net balance as of September 30, 2017 | $ | 220,546 |  |  | $ | 114,234 |  |  | $ | 334,780 |  |

[0000926326-17-000038:notes:63]
Goodwill acquired in the Automation and Analytics segment represents the value assigned to goodwill as part of the InPharmics acquisition. Goodwill acquired in the Medication Adherence segment represents adjustments to the preliminary value assigned to goodwill in connection with Ateb acquisition to reflect measurement period adjustments related to accounts receivable and other non-current assets of $0.1 million and $0.7 million, respectively.

[0000926326-17-000038:notes:64]
[same as prior period, unchanged from 0000926326-17-000032:notes:64]

[0000926326-17-000038:notes:65]
The carrying amounts of intangibles assets as of September 30, 2017 and December 31, 2016 are as follows:

[0000926326-17-000038:notes:66]
|  | September 30, 2017 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 133,456 |  |  | $ | (30,421 | ) |  | $ | 297 |  |  | $ | 103,332 |  |  | 1 - 30 |
| Acquired technology | 74,457 |  |  | (19,493 | ) |  | 75 |  |  | 55,039 |  |  | 3 - 20 |
| Backlog | 21,702 |  |  | (16,654 | ) |  | — |  |  | 5,048 |  |  | 1 - 5 |
| Trade names | 8,683 |  |  | (4,508 | ) |  | 13 |  |  | 4,188 |  |  | 1 - 12 |
| Patents | 3,290 |  |  | (1,331 | ) |  | (6 | ) |  | 1,953 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (1,133 | ) |  | — |  |  | 767 |  |  | 3 |
| In-process technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | — |
| Total intangibles assets, net | $ | 247,388 |  |  | $ | (73,540 | ) |  | $ | 379 |  |  | $ | 174,227 |  |  |  |

[0000926326-17-000038:notes:67]
[same as prior period, unchanged from 0000926326-17-000032:notes:67]

[0000926326-17-000038:notes:68]
Amortization expense of intangible assets was $6.4 million and $8.9 million for the three months ended September 30, 2017 and 2016, respectively. Amortization expense of intangible assets was $19.4 million and $27.2 million for the nine months ended September 30, 2017 and 2016, respectively.

[0000926326-17-000038:notes:69]
[same as prior period, unchanged from 0000926326-17-000032:notes:69]

[0000926326-17-000038:notes:70]
|  | September 30, 2017 |
|  | (In thousands) |
| Remaining three months of 2017 | $ | 6,166 |  |
| 2018 | 23,302 |  |
| 2019 | 17,837 |  |
| 2020 | 16,631 |  |
| 2021 | 15,065 |  |
| Thereafter (excluding in-process technology) | 91,326 |  |
| Total | $ | 170,327 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-17-000038:notes:71]
[same as prior period, unchanged from 0000926326-17-000032:notes:71]

[0000926326-17-000038:notes:72]
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. For the three month ended September 30, 2017, the provision for income taxes was computed based on the actual effective tax rate for the year-to-date by applying the discrete method. The Company determined that as small changes in estimated “ordinary” income result in significant changes in the estimated annual effective tax rate, the actual effective tax rate provided a more accurate income tax provision for the reporting period ended September 30, 2017. The estimated effective tax rate before discrete items was 34.4% and 38.3% for the nine months ended September 30, 2017 and 2016, respectively.

[0000926326-17-000038:notes:73]
The estimated effective tax rate for the nine months ended September 30, 2017 differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, foreign rate differential, and non-deductible equity charges, which were partially offset by the favorable impact of the Research & Development credits. The effective tax rate for the nine months ended September 30, 2016 differed from the statutory rate of 35% primarily due to the favorable impact of the IRS settlement and release of tax reserves, the domestic production activities deduction, Research & Development credits and a calculated benefit in state income taxes, offset by unfavorable items such as non-deductible transaction costs related to the Aesynt transaction, and non-deductible equity charges under ASC 740-718.

[0000926326-17-000038:notes:74]
As of September 30, 2017 and December 31, 2016, the Company had gross unrecognized tax benefits of $6.8 million and $6.5 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in operating expense. As of September 30, 2017 and December 31, 2016, the amount of accrued interest and penalties was $1.2 million and $0.7 million, respectively.

[0000926326-17-000038:notes:75]
As of September 30, 2017, calendar years 2011 and thereafter are open and subject to potential examination in one or more jurisdictions. However, our research credit carryforwards that may be used in future years are subject to adjustment, if and when utilized. As such our federal and California tax years remain open from 2015 and 1992, respectively.  During fiscal 2016, the Internal Revenue Service and the Company settled all outstanding items related to the audit of the Company's federal income tax returns for the fiscal year ended December 31, 2014.

[0000926326-17-000038:notes:76]
[same as prior period, unchanged from 0000926326-17-000032:notes:76]


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000926326-17-000038:notes:77]
[same as prior period, unchanged from 0000926326-17-000032:notes:77]

[0000926326-17-000038:notes:78]
|  | September 30, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| United States | $ | 33,620 |  |  | $ | 36,497 |  |
| Rest of world (1) | 6,599 |  |  | 5,514 |  |
| Total property and equipment, net | $ | 40,219 |  |  | $ | 42,011 |  |

[0000926326-17-000038:notes:79]
[same as prior period, unchanged from 0000926326-17-000032:notes:79]

[0000926326-17-000038:notes:80]
[same as prior period, unchanged from 0000926326-17-000032:notes:80]


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000926326-17-000038:notes:81]
[same as prior period, unchanged from 0000926326-17-000032:notes:81]

[0000926326-17-000038:notes:82]
[same as prior period, unchanged from 0000926326-17-000032:notes:82]

[0000926326-17-000038:notes:83]
[same as prior period, unchanged from 0000926326-17-000032:notes:83]

[0000926326-17-000038:notes:84]
[same as prior period, unchanged from 0000926326-17-000032:notes:84]

[0000926326-17-000038:notes:85]
[same as prior period, unchanged from 0000926326-17-000032:notes:85]

[0000926326-17-000038:notes:86]
[same as prior period, unchanged from 0000926326-17-000032:notes:86]

[0000926326-17-000038:notes:87]
[same as prior period, unchanged from 0000926326-17-000032:notes:87]

[0000926326-17-000038:notes:88]
[same as prior period, unchanged from 0000926326-17-000032:notes:88]

[0000926326-17-000038:notes:89]
|  | Aesynt |  | Ateb(preliminary) |  | Total |
|  | (in thousands) |
| Cash | $ | 8,164 |  |  | $ | 902 |  |  | $ | 9,066 |  |
| Accounts receivable | 43,312 |  |  | 7,761 |  |  | 51,073 |  |
| Inventory | 19,021 |  |  | 225 |  |  | 19,246 |  |
| Other current assets | 3,787 |  |  | 1,239 |  |  | 5,026 |  |
| Total current assets | 74,284 |  |  | 10,127 |  |  | 84,411 |  |
| Property and equipment | 10,389 |  |  | 2,447 |  |  | 12,836 |  |
| Intangibles | 123,700 |  |  | 12,500 |  |  | 136,200 |  |
| Goodwill | 163,599 |  |  | 21,651 |  |  | 185,250 |  |
| Other non-current assets | 968 |  |  | 334 |  |  | 1,302 |  |
| Total assets | 372,940 |  |  | 47,059 |  |  | 419,999 |  |
| Current liabilities | 26,753 |  |  | 2,314 |  |  | 29,067 |  |
| Deferred revenue | 25,512 |  |  | 2,776 |  |  | 28,288 |  |
| Non-current deferred tax liabilities | 38,622 |  |  | — |  |  | 38,622 |  |
| Other non-current liabilities | 2,431 |  |  | 367 |  |  | 2,798 |  |
| Total liabilities | 93,318 |  |  | 5,457 |  |  | 98,775 |  |
| Total purchase price | $ | 279,622 |  |  | $ | 41,602 |  |  | $ | 321,224 |  |
| Total purchase price, net of cash received | $ | 271,458 |  |  | $ | 40,700 |  |  | $ | 312,158 |  |

[0000926326-17-000038:notes:90]
[same as prior period, unchanged from 0000926326-17-000032:notes:90]

[0000926326-17-000038:notes:91]
The $21.7 million of goodwill arising from the Ateb acquisition is primarily attributed to sales of future products and services and Ateb's assembled workforce.

[0000926326-17-000038:notes:92]
[same as prior period, unchanged from 0000926326-17-000032:notes:92]

[0000926326-17-000038:notes:93]
[same as prior period, unchanged from 0000926326-17-000032:notes:93]

[0000926326-17-000038:notes:94]
[same as prior period, unchanged from 0000926326-17-000032:notes:94]

[0000926326-17-000038:notes:95]
The fair value of trade names, acquired developed technology, and acquired IPR&D was determined based on an income approach using the relief-from-royalty method at the royalty rates of 0.5%, 4% to 8% and 12.5%, respectively. The fair value of customer relationships, backlog, and non-compete intangible assets were determined based on an income approach using the discounted cash flow method, at the discounted rates of 13%, 10% and13%, respectively. The intangible assets, except customer relationship and IPR&D, are being amortized over their estimated useful lives using the straight line method of amortization. The customer relationship intangible asset is being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. In accordance with authoritative guidance, the IPR&D is accounted for as an indefinite-lived intangible asset until completion or abandonment of the associated research and development efforts. IPR&D is tested for impairment during the period it is considered an indefinite lived asset. IPR&D related projects are expected to be completed in two to three years. As of September 30, 2017, none of the IPR&D projects have been completed, and they have progressed as previously estimated and are expected to be completed in fiscal 2018.

[0000926326-17-000038:notes:96]
[same as prior period, unchanged from 0000926326-17-000032:notes:96]

[0000926326-17-000038:notes:97]
[same as prior period, unchanged from 0000926326-17-000032:notes:97]

[0000926326-17-000038:notes:98]
[same as prior period, unchanged from 0000926326-17-000032:notes:98]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-17-000038:notes:99]
Recently adopted authoritative guidance

[0000926326-17-000038:notes:100]
In March 2016, the FASB issued ASU No. 2016-09. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. The Company adopted the standard effective January 1, 2017.  The impact of adoption was the recording of excess tax benefits within income tax expense, rather than in Additional Paid in Capital of $2.1 million and $4.7 million for the three and nine months ended September 30, 2017, respectively.  Additionally, in the first quarter of 2017, the Company recognized the previously unrecognized excess tax benefits using the modified retrospective transition method, which resulted in a cumulative-effect adjustment of $1.6 million to retained earnings.

[0000926326-17-000038:notes:101]
In January 2017, the FASB issued ASU 2017-04, Intangibles-Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment, which simplifies the accounting for goodwill impairment for all entities by requiring impairment charges to be based on the first step in today’s two-step impairment test under ASC 350, “Intangibles-Goodwill and Other.” Under the new guidance, if a reporting unit’s carrying amount exceeds its fair value, an entity will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill allocated to that reporting unit. The standard eliminates the current ASC 350 requirement to calculate a goodwill impairment charge using Step 2. ASU 2017-04 is effective for annual and interim impairment tests performed in periods beginning after December 15, 2019. Early adoption is permitted for annual and interim goodwill impairment testing dates after January 1, 2017. The Company adopted ASU 2017-04 effective January 1, 2017. The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the periods presented.

[0000926326-17-000038:notes:102]
In January 2017, the FASB issued ASU 2017-01, Business Combinations, which clarifies the definition of a business and provides a screen to determine when a set of assets and activities is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set is not a business. This screen reduces the number of transactions that need to be further evaluated. ASU 2017-01 is effective for fiscal years beginning after December 15, 2017, with early adoption permitted.  The Company adopted ASU 2017-01 effective January 1, 2017.  The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the periods presented.

[0000926326-17-000038:notes:103]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815), which simplifies the application of the hedge accounting guidance and improves the financial reporting, specifically simplifies designation and measurement for qualifying hedging relationships and the presentation of hedge results. ASU 2017-12 is effective for annual periods beginning after December 15, 2018 and interim periods within those annual periods with early adoption permitted. The Company adopted ASU 2017-12 effective August 1, 2017. The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the periods presented.

[0000926326-17-000038:notes:104]
Recently issued authoritative guidance

[0000926326-17-000038:notes:105]
In May 2014, the FASB issued ASU 2014-09-Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, accordingly, it is possible more judgment and estimates may be required within the revenue recognition process than is required under existing U.S. GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. The FASB has recently issued several amendments to ASU 2014-09, including clarification on accounting for licenses of intellectual property and identifying performance obligations. ASU 2014-09 will be effective for the Company beginning January 1, 2018.

[0000926326-17-000038:notes:106]
The two permitted transition methods under ASU 2014-09 are the full retrospective method, in which case ASU 2014-09 would be applied to each prior reporting period presented and the cumulative effect of applying ASU 2014-09 would be recognized at the earliest period shown, or the modified retrospective method, in which case the cumulative effect of applying ASU 2014-09 would be recognized at the date of initial application. While the Company currently expects to apply the full retrospective method, the Company is continuing to evaluate the availability of information and resources necessary and may decide the benefit of applying the full retrospective method is not significant enough to support the cost.

[0000926326-17-000038:notes:107]
Currently, the Company is in the process of reviewing its historical contracts to quantify the impact on its consolidated financial statements. The most significant impact of the standard relates to accounting for term software license revenue, contingent income, and commission expense.  Specifically, under the standard the Company expects to recognize revenue on term software licenses upon installation of the license rather than ratably over the life of the term license.  Additionally, the standard no longer requires deferral of contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price which will result in earlier recognition of revenue.  Finally, the standard requires expense to be recognized for incremental costs incurred to obtain a contract, primarily commission expense, on a systematic basis that is consistent with the transfer to the customer of the product and services to which the cost relates, including an estimate of the period of service renewals for the transaction. Currently, the Company recognizes commission expense at the time of recognizing the related product revenue. The Company is also in the process of assessing the appropriate changes to its business processes and upgrading its systems and controls to support recognition and disclosure under ASU 2014-09. The Company expects to complete its assessment process within the last quarter of 2017.

[0000926326-17-000038:notes:108]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company's Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0000926326-17-000038:notes:109]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards ("RSAs") |  |  |  |
| Outstanding at December 31, 2016 | 30 |  |  | $ | 31.57 |  |
| Granted | 24 |  |  | 41.10 |  |
| Vested | (30 | ) |  | 31.58 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at September 30, 2017 | 24 |  |  | $ | 41.05 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-17-000038:notes:110]
[same as prior period, unchanged from 0000926326-17-000032:notes:109]

[0000926326-17-000038:notes:111]
[same as prior period, unchanged from 0000926326-17-000032:notes:110]

[0000926326-17-000038:notes:112]
[same as prior period, unchanged from 0000926326-17-000032:notes:111]

[0000926326-17-000038:notes:113]
Certain prior year amounts have been reclassified to conform to the 2017 presentation with the adoption of ASU 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. Additionally, see "Recently adopted authoritative guidance" for the effects of first quarter adoption of ASU 2016-09.

[0000926326-17-000038:notes:114]
[same as prior period, unchanged from 0000926326-17-000032:notes:114]

[0000926326-17-000038:notes:115]
[same as prior period, unchanged from 0000926326-17-000032:notes:115]

[0000926326-17-000038:notes:116]
[same as prior period, unchanged from 0000926326-17-000032:notes:116]

[0000926326-17-000038:notes:117]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain other administrative expenses.  See Note 13, Segment and Geographical Information, for additional information on segment reporting.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-17-000038:notes:118]
[same as prior period, unchanged from 0000926326-17-000032:notes:118]

[0000926326-17-000038:notes:119]
On February 15, 2017, the Company announced its plan to reduce its workforce by approximately 100 full-time employees and close the Company’s Nashville, Tennessee and Slovenia facilities.  The plan is expected to be completed in fiscal year 2017. The estimated total cost for the plan is $4.3 million, which includes estimated employee severance cost of approximately $3.8 million, and facility-related costs of approximately $0.5 million.

[0000926326-17-000038:notes:120]
During the nine months ended September 30, 2017, the Company accrued $3.8 million of severance and related expenses, and paid out $3.2 million.  The remaining unpaid balance of $0.6 million accrued severance and related expenses as of September 30, 2017 is presented as a component of accrued compensation in the Condensed Consolidated Balance Sheet.

[0000926326-17-000038:notes:121]
There were $0.6 million of facility-related costs incurred during the nine months ended September 30, 2017, of which $0.2 million was paid out. The remaining unpaid balance of $0.4 million accrued facilities-related expenses as of September 30, 2017 is presented as a component of accrued liabilities in the Condensed Consolidated Balance Sheet.

[0000926326-17-000038:notes:122]
For the three and nine months periods ending September 30, 2017, the total restructuring expense was $0 and $4.3 million, respectively.

[0000926326-17-000038:notes:123]
During the second quarter of 2016, the Company integrated its Sales and Field organizations in North America to better serve its customers which resulted in a reduction in headcount of 36 employees. Accordingly, the Company incurred approximately $1.7 million of restructuring expenses in the nine months ended September 30, 2016, based on agreements with terminated employees covering salary and benefit continuation. As of September 30, 2016 the restructuring program has been concluded.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000926326-17-000038:notes:124]
[same as prior period, unchanged from 0000926326-17-000032:notes:125]

[0000926326-17-000038:notes:125]
|  | Three months ended |
|  | September 30, 2017 |  | September 30, 2016 |
|  | (In thousands) |
| United States | $ | 164,190 |  |  | $ | 155,989 |  |
| Rest of world (1) | 22,592 |  |  | 20,748 |  |
| Total revenues | $ | 186,782 |  |  | $ | 176,737 |  |

[0000926326-17-000038:notes:126]
|  | Nine months ended |
|  | September 30, 2017 |  | September 30, 2016 |
|  | (In thousands) |
| United States | $ | 449,755 |  |  | $ | 445,470 |  |
| Rest of world (1) | 68,466 |  |  | 75,178 |  |
| Total revenues | $ | 518,221 |  |  | $ | 520,648 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000926326-17-000038:notes:127]
The following tables summarize the changes in accumulated balances of other comprehensive income (loss) for the three and nine months ended September 30, 2017 and 2016:

[0000926326-17-000038:notes:128]
|  | Three months ended September 30, |
|  | 2017 |  | 2016 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (8,765 | ) |  | $ | 1,274 |  |  | $ | (7,491 | ) |  | $ | (7,524 | ) |  | $ | — |  |  | $ | (7,524 | ) |
| Other comprehensive income (loss) before reclassifications | 1,389 |  |  | 35 |  |  | 1,424 |  |  | (502 | ) |  | 108 |  |  | (394 | ) |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (109 | ) |  | (109 | ) |  | — |  |  | — |  |  | — |  |
| Net current-period other comprehensive income (loss), net of tax | 1,389 |  |  | (74 | ) |  | 1,315 |  |  | (502 | ) |  | 108 |  |  | (394 | ) |
| Ending balance | $ | (7,376 | ) |  | $ | 1,200 |  |  | $ | (6,176 | ) |  | $ | (8,026 | ) |  | $ | 108 |  |  | $ | (7,918 | ) |

[0000926326-17-000038:notes:129]
|  | Nine months ended September 30, |
|  | 2017 |  | 2016 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |  |  |  |  |  |  |
| Beginning balance | $ | (10,764 | ) |  | $ | 1,245 |  |  | $ | (9,519 | ) |  | $ | (2,730 | ) |  | $ | — |  |  | $ | (2,730 | ) |
| Other comprehensive income (loss) before reclassifications | 3,388 |  |  | 111 |  |  | 3,499 |  |  | (5,296 | ) |  | 108 |  |  | (5,188 | ) |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (156 | ) |  | (156 | ) |  | — |  |  | — |  |  | — |  |
| Net current-period other comprehensive income (loss), net of tax | 3,388 |  |  | (45 | ) |  | 3,343 |  |  | (5,296 | ) |  | 108 |  |  | (5,188 | ) |
| Ending balance | $ | (7,376 | ) |  | $ | 1,200 |  |  | $ | (6,176 | ) |  | $ | (8,026 | ) |  | $ | 108 |  |  | $ | (7,918 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-17-000038:notes:130]
Balance sheet details as of September 30, 2017 and December 31, 2016 are presented in the tables below:

[0000926326-17-000038:notes:131]
|  | September 30, 2017 |  | December 31, 2016 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 20,736 |  |  | $ | 14,322 |  |
| Work in process | 10,769 |  |  | 7,800 |  |
| Finished goods | 60,734 |  |  | 47,175 |  |
| Total inventories | $ | 92,239 |  |  | $ | 69,297 |  |
| Prepaid expense |  |  |  |
| Prepaid commissions | $ | 11,622 |  |  | $ | 13,176 |  |
| Other prepaid expenses | 16,422 |  |  | 15,470 |  |
| Total prepaid expense | $ | 28,044 |  |  | $ | 28,646 |  |
| Property and equipment: |  |  |  |
| Equipment | $ | 70,343 |  |  | $ | 64,384 |  |
| Furniture and fixtures | 6,881 |  |  | 6,517 |  |
| Leasehold improvements | 10,143 |  |  | 9,778 |  |
| Software | 37,574 |  |  | 35,607 |  |
| Construction in progress | 8,083 |  |  | 7,211 |  |
| Property and equipment, gross | 133,024 |  |  | 123,497 |  |
| Accumulated depreciation and amortization | (92,805 | ) |  | (81,486 | ) |
| Total property and equipment, net | $ | 40,219 |  |  | $ | 42,011 |  |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 36,713 |  |  | $ | 33,233 |  |
| Other assets | 883 |  |  | 1,818 |  |
| Total other long term assets, net | $ | 37,596 |  |  | $ | 35,051 |  |

[0000926326-17-000038:notes:132]
|  | September 30, 2017 |  | December 31, 2016 |
| Accrued liabilities: |  |  |  |
| Advance payments from customers | $ | 7,780 |  |  | $ | 7,030 |  |
| Rebates and lease buyouts | 5,943 |  |  | 4,025 |  |
| Group purchasing organization fees | 3,380 |  |  | 3,737 |  |
| Taxes payable | 5,575 |  |  | 4,003 |  |
| Other accrued liabilities | 10,383 |  |  | 12,400 |  |
| Total accrued liabilities | $ | 33,061 |  |  | $ | 31,195 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0000926326-17-000038:notes:133]
[same as prior period, unchanged from 0000926326-17-000032:notes:134]

[0000926326-17-000038:notes:134]
|  | Three months ended |  | Nine months ended |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 882 |  |  | $ | 628 |  |  | $ | 2,727 |  |  | $ | 1,821 |  |
| Research and development | 915 |  |  | 825 |  |  | 2,651 |  |  | 2,267 |  |
| Selling, general and administrative | 3,462 |  |  | 3,224 |  |  | 10,937 |  |  | 9,975 |  |
| Total share-based compensation expense | $ | 5,259 |  |  | $ | 4,677 |  |  | $ | 16,315 |  |  | $ | 14,063 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0000926326-17-000038:notes:135]
The following table summarizes the restricted stock activity under the Company’s equity incentive plans during the nine months ended September 30, 2017:

[0000926326-17-000038:notes:136]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units ("RSUs") |  |  |  |  |  |  |  |
| Outstanding at December 31, 2016 | 505 |  |  | $ | 31.42 |  |  | 1.6 |  | $ | 17,135 |  |
| Granted | 93 |  |  | 37.86 |  |  |  |  |  |
| Vested | (126 | ) |  | 29.19 |  |  |  |  |  |
| Forfeited | (16 | ) |  | 32.17 |  |  |  |  |  |
| Outstanding and unvested at September 30, 2017 | 456 |  |  | $ | 33.33 |  |  | 1.2 |  | $ | 23,257 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-17-000038:notes:137]
[same as prior period, unchanged from 0000926326-17-000032:notes:138]

[0000926326-17-000038:notes:138]
|  | Three months ended |
|  | September 30, 2017 |  | September 30, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 154,651 |  |  | $ | 32,131 |  |  | $ | 186,782 |  |  | $ | 152,437 |  |  | $ | 24,300 |  |  | $ | 176,737 |  |
| Cost of revenues | 79,740 |  |  | 22,189 |  |  | 101,929 |  |  | 77,828 |  |  | 17,401 |  |  | 95,229 |  |
| Gross profit | 74,911 |  |  | 9,942 |  |  | 84,853 |  |  | 74,609 |  |  | 6,899 |  |  | 81,508 |  |
| Operating expenses | 46,849 |  |  | 9,901 |  |  | 56,750 |  |  | 49,123 |  |  | 6,137 |  |  | 55,260 |  |
| Income (loss) from segment operations | $ | 28,062 |  |  | $ | 41 |  |  | $ | 28,103 |  |  | $ | 25,486 |  |  | $ | 762 |  |  | $ | 26,248 |  |
| Corporate costs |  |  |  |  | 18,389 |  |  |  |  |  |  | 21,320 |  |
| Income (loss) from operations |  |  |  |  | $ | 9,714 |  |  |  |  |  |  | $ | 4,928 |  |

[0000926326-17-000038:notes:139]
|  | Nine months ended |
|  | September 30, 2017 |  | September 30, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 427,250 |  |  | $ | 90,971 |  |  | $ | 518,221 |  |  | $ | 450,043 |  |  | $ | 70,605 |  |  | $ | 520,648 |  |
| Cost of revenues | 229,218 |  |  | 61,983 |  |  | 291,201 |  |  | 233,401 |  |  | 47,777 |  |  | 281,178 |  |
| Gross profit | 198,032 |  |  | 28,988 |  |  | 227,020 |  |  | 216,642 |  |  | 22,828 |  |  | 239,470 |  |
| Operating expenses | 146,651 |  |  | 31,196 |  |  | 177,847 |  |  | 151,108 |  |  | 17,518 |  |  | 168,626 |  |
| Income (loss) from segment operations | $ | 51,381 |  |  | $ | (2,208 | ) |  | $ | 49,173 |  |  | $ | 65,534 |  |  | $ | 5,310 |  |  | $ | 70,844 |  |
| Corporate costs |  |  |  |  | 59,099 |  |  |  |  |  |  | 64,182 |  |
| Income (loss) from operations |  |  |  |  | $ | (9,926 | ) |  |  |  |  |  | $ | 6,662 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000926326-17-000038:notes:140]
The following table summarizes the share option activity under the Company’s equity incentive plans during the nine months ended September 30, 2017:

[0000926326-17-000038:notes:141]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Stock Options |  |  |  |  |  |  |  |
| Outstanding at December 31, 2016 | 3,214 |  |  | $ | 26.06 |  |  | 7.3 |  | $ | 26,331 |  |
| Granted | 504 |  |  | 38.87 |  |  |  |  |  |
| Exercised | (668 | ) |  | 21.66 |  |  |  |  |  |
| Expired | (6 | ) |  | 27.53 |  |  |  |  |  |
| Forfeited | (79 | ) |  | 32.54 |  |  |  |  |  |
| Outstanding at September 30, 2017 | 2,965 |  |  | $ | 29.06 |  |  | 7.4 |  | $ | 65,247 |  |
| Exercisable at September 30, 2017 | 1,252 |  |  | $ | 22.36 |  |  | 5.5 |  | $ | 35,915 |  |
| Vested and expected to vest at September 30, 2017 and thereafter | 2,965 |  |  | $ | 29.06 |  |  | 7.4 |  | $ | 65,247 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0000926326-17-000038:notes:142]
|  | Three months ended |  | Nine months ended |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Employee Stock Purchase Plan |  |  |  |  |  |  |  |
| Expected life, years | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |
| Expected volatility, % | 26.7-32.1% |  |  | 25.8-34.8% |  |  | 25.8-32.8% |  |  | 25.8-34.8% |  |
| Risk free interest rate, % | 0.61-1.39% |  |  | 0.41-0.79% |  |  | 0.52-1.39% |  |  | 0.34-0.79% |  |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0000926326-17-000038:notes:143]
The following weighted average assumptions are used to value stock options and Employee Stock Purchase Plan ("ESPP") shares issued pursuant to the Company's equity incentive plans for the three and nine months ended September 30, 2017 and 2016:

[0000926326-17-000038:notes:144]
|  | Three months ended |  | Nine months ended |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Stock Option Plans |  |  |  |  |  |  |  |
| Expected life, years | 4.67 |  |  | 4.92 |  |  | 4.67 |  |  | 4.92 |  |
| Expected volatility, % | 28.1 | % |  | 30.0 | % |  | 29.2 | % |  | 31.4 | % |
| Risk free interest rate, % | 1.81 | % |  | 1.21 | % |  | 1.83 | % |  | 1.34 | % |
| Estimated forfeiture rate % | 7.7 | % |  | 8.6 | % |  | 7.7 | % |  | 8.6 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-17-000038:notes:145]
[same as prior period, unchanged from 0000926326-17-000032:notes:146]

[0000926326-17-000038:notes:146]
[same as prior period, unchanged from 0000926326-17-000032:notes:147]

[0000926326-17-000038:notes:147]
[same as prior period, unchanged from 0000926326-17-000032:notes:148]

[0000926326-17-000038:notes:148]
[same as prior period, unchanged from 0000926326-17-000032:notes:149]

[0000926326-17-000038:notes:149]
[same as prior period, unchanged from 0000926326-17-000032:notes:150]

[0000926326-17-000038:notes:150]
[same as prior period, unchanged from 0000926326-17-000032:notes:151]

[0000926326-17-000038:notes:151]
[same as prior period, unchanged from 0000926326-17-000032:notes:152]

[0000926326-17-000038:notes:152]
There were no customers that accounted for more than 10% of our total revenues for the three and nine months ended September 30, 2017 and 2016. Also, there were no customers that accounted for more than 10% of our accounts receivable as of September 30, 2017 and December 31, 2016.

[0000926326-17-000038:notes:153]
[same as prior period, unchanged from 0000926326-17-000032:notes:154]

[0000926326-17-000038:notes:154]
[same as prior period, unchanged from 0000926326-17-000032:notes:155]


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0000926326-17-000038:notes:155]
The following table summarizes the performance-based restricted stock activity under the Company’s equity incentive plans during the nine months ended September 30, 2017:

[0000926326-17-000038:notes:156]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Performance-based Restricted Stock Units ("PSUs") |  |  |  |
| Outstanding at December 31, 2016 | 184 |  |  | $ | 24.89 |  |
| Granted | 146 |  |  | 33.89 |  |
| Vested | (69 | ) |  | 24.43 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at September 30, 2017 | 261 |  |  | $ | 30.06 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-17-000038:notes:157]
[same as prior period, unchanged from 0000926326-17-000032:notes:158]

[0000926326-17-000038:notes:158]
[same as prior period, unchanged from 0000926326-17-000032:notes:159]

[0000926326-17-000038:notes:159]
[same as prior period, unchanged from 0000926326-17-000032:notes:160]

[0000926326-17-000038:notes:160]
[same as prior period, unchanged from 0000926326-17-000032:notes:161]

[0000926326-17-000038:notes:161]
[same as prior period, unchanged from 0000926326-17-000032:notes:162]

[0000926326-17-000038:notes:162]
The weighted-average fair value per share of options granted during the three months ended September 30, 2017 and 2016 was $12.49 and $10.32, respectively, and the weighted-average fair value per share of options granted during the nine months ended September 30, 2017 and 2016 was $11.22 and $8.82, respectively. The intrinsic value of options exercised during the three months ended September 30, 2017 and 2016 was $6.8 million and $2.1 million, respectively, and the intrinsic value of options exercised during the nine months ended September 30, 2017 and 2016 was $14.6 million and $5.0 million, respectively,

[0000926326-17-000038:notes:163]
As of September 30, 2017, total unrecognized compensation cost related to unvested stock options was $13.7 million, which is expected to be recognized over a weighted-average vesting period of 2.8 years.

[0000926326-17-000038:notes:164]
[same as prior period, unchanged from 0000926326-17-000032:notes:165]

[0000926326-17-000038:notes:165]
The weighted-average grant date fair value per share of RSUs granted during the nine months ended September 30, 2017 and September 30, 2016 was $37.86 and $29.19, respectively.

[0000926326-17-000038:notes:166]
As of September 30, 2017, total unrecognized compensation expense related to RSUs was $11.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.4 years.

[0000926326-17-000038:notes:167]
As of September 30, 2017, total unrecognized compensation cost related to RSAs was $0.6 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.64 years.

[0000926326-17-000038:notes:168]
[same as prior period, unchanged from 0000926326-17-000032:notes:169]

[0000926326-17-000038:notes:169]
The weighted-average grant date fair value per share of PSUs granted during the nine months ended September 30, 2017 and 2016 was $33.89 and $24.66, respectively. As of September 30, 2017, total unrecognized compensation cost related to PSUs was $3.5 million, which is expected to be recognized over the remaining weighted-average period of 1.3 years.

[0000926326-17-000038:notes:170]
[same as prior period, unchanged from 0000926326-17-000032:notes:171]

[0000926326-17-000038:notes:171]
For the nine months ending September 30, 2017 and 2016, purchases under the ESPP were approximately 465,696 and 420,000 shares at weighted average prices of $25.78 and $23.23, respectively. As of September 30, 2017, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $1.6 million and is expected to be recognized over a weighted-average period of 1.6 years.

[0000926326-17-000038:notes:172]
[same as prior period, unchanged from 0000926326-17-000032:notes:173]

[0000926326-17-000038:notes:173]
[same as prior period, unchanged from 0000926326-17-000032:notes:174]

[0000926326-17-000038:notes:174]
On August 2, 2016, the Company's Board of Directors (the "Board") authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of September 30, 2017, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase program at any time.

[0000926326-17-000038:notes:175]
During the three and nine months period ended September 30, 2017 and 2016, the Company did not repurchase any of its outstanding common stock.


## us-gaap:SubsequentEventsTextBlock

[0000926326-17-000038:notes:176]
Subsequent Event

[0000926326-17-000038:notes:177]
On October 2, 2017 and October 10, 2017, the Company borrowed $12.0 million and $10.0 million, respectively, under the Revolving Credit Facility to fund its operations.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-17-000038:notes:178]
[same as prior period, unchanged from 0000926326-17-000032:notes:179]
