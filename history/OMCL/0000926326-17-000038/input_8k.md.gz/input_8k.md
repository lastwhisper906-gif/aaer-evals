# OMCL 8-K — 0000926326-17-000035 filed 2017-10-26

## item codes, every 8-K on or before 2017-11-03

- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2017-11-03

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-17-000035:8k_2_02:1]
EX-99.1
2
exhibit991q317.htm
EXHIBIT 99.1

[0000926326-17-000035:8k_2_02:2]
Exhibit

[0000926326-17-000035:8k_2_02:3]
Exhibit 99.1

[0000926326-17-000035:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6180 |  | Mountain View, CA 94043 |
| Peter.kuipers@omnicell.com |  |  |

[0000926326-17-000035:8k_2_02:5]
Omnicell Achieves Record Revenue in the Third Quarter 2017

[0000926326-17-000035:8k_2_02:6]
GAAP revenue of $186.8 million and GAAP net income per diluted share of $0.16

[0000926326-17-000035:8k_2_02:7]
Non-GAAP revenue of $187.1 million and non-GAAP net income per diluted share of $0.42

[0000926326-17-000035:8k_2_02:8]
MOUNTAIN VIEW, Calif. -- October 26, 2017 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its third quarter ended September 30, 2017.

[0000926326-17-000035:8k_2_02:9]
GAAP results: Revenue for the third quarter of 2017 was $186.8 million, up $5.9 million, or 3.3% from the second quarter of 2017, and up $10.1 million, or 5.7% from the third quarter of 2016. Revenue for the nine months ended September 30, 2017 was $518.2 million, down $2.4 million, or 0.5% from the nine months ended September 30, 2016.

[0000926326-17-000035:8k_2_02:10]
Third quarter 2017 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $6.2 million, or $0.16 per diluted share. This compares to GAAP net income of $0.8 million, or $0.02 per diluted share, for the second quarter of 2017, and GAAP net income of $2.0 million, or $0.05 per diluted share, for the third quarter of 2016.

[0000926326-17-000035:8k_2_02:11]
GAAP net loss for the nine months ended September 30, 2017 was $3.7 million, or $0.10 per diluted share. GAAP net income was $0.4 million, or $0.01 per diluted share, for the nine months ended September 30, 2016.

[0000926326-17-000035:8k_2_02:12]
Non-GAAP results: Non-GAAP revenue for the third quarter of 2017 was $187.1 million, up $5.9 million, or 3.3% from the second quarter of 2017, and up $7.7 million, or 4.3% from the third quarter of 2016. Non-GAAP revenue for the nine months ended September 30, 2017 was $519.2 million, down $9.5 million, or 1.8% from the nine months ended September 30, 2016.

[0000926326-17-000035:8k_2_02:13]
Non-GAAP net income for the third quarter of 2017 was $16.3 million, or $0.42 per diluted share. This compares to non-GAAP net income of $11.7 million, or $0.31 per diluted share, for the second quarter of 2017 and $14.9 million, or $0.40 per diluted share, for the third quarter of 2016.

[0000926326-17-000035:8k_2_02:14]
Non-GAAP net income for the nine months ended September 30, 2017 was $30.1 million, or $0.78 per diluted share. This compares to non-GAAP net income of $42.0 million, or $1.14 per diluted share for the nine months ended September 30, 2016.

[0000926326-17-000035:8k_2_02:15]
Non-GAAP net income for each period presented excludes, when applicable, the effect of stock-based compensation expense, amortization expense of acquired intangible assets, acquisition related expenses, fair value adjustments related to business acquisitions, severance and integration-related expenses, and amortization of debt issuance cost.

[0000926326-17-000035:8k_2_02:16]
“Omnicell is winning in the marketplace.  New product introductions and innovation across the Omnicell platform drove customer wins and increased portfolio adoption in Q3," said Randall Lipps, Omnicell president, CEO and chairman. "We are proud of the company’s financial performance and our strategic execution aimed at supporting health systems in achieving their patient safety, operational and financial goals.”

[0000926326-17-000035:8k_2_02:17]
2017 Guidance:

[0000926326-17-000035:8k_2_02:18]
For the fourth quarter of 2017, the Company expects both GAAP and non-GAAP revenue to be between $201 million and $207 million, and non-GAAP earnings to be between $0.49 and $0.55 per share.

[0000926326-17-000035:8k_2_02:19]
For the year 2017, the Company expects product bookings to be between $570 million and $590 million. The Company expects both GAAP and non-GAAP revenue to be between $720 million and $726 million, and non-GAAP earnings to be between $1.27 and $1.33 per share.

[0000926326-17-000035:8k_2_02:20]
Long term financial framework and preliminary 2018 Guidance:

[0000926326-17-000035:8k_2_02:21]
The Company’s long term financial framework is:

[0000926326-17-000035:8k_2_02:22]
| • | 8%-12% Organic Revenue Growth |

[0000926326-17-000035:8k_2_02:23]
| • | 5% Inorganic Revenue Growth on average over the long term |

[0000926326-17-000035:8k_2_02:24]
| • | 15% Non-GAAP Operating Margin |

[0000926326-17-000035:8k_2_02:25]
For 2018 onwards the Company expects organic growth to be in the long term 8%-12% range. The Company's preliminary view of Product Bookings growth for 2018 is at the high end and potentially above the 8%-12% range. The Company's preliminary view of Revenue growth for 2018 is also in the 8% to 12% range, however, at this point the Company has visibility to the middle of the 8%-12% range with potential upside toward the higher end of the range.

[0000926326-17-000035:8k_2_02:26]
The Company expects to provide more specific guidance during the 2017 fourth quarter earnings call.

[0000926326-17-000035:8k_2_02:27]
Omnicell Conference Call Information

[0000926326-17-000035:8k_2_02:28]
Omnicell will hold a conference call today, Thursday, October 26, 2017 at 1:30 p.m. PT to discuss third quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 36567558. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on November 30, 2017. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 36567558.

[0000926326-17-000035:8k_2_02:29]
About Omnicell

[0000926326-17-000035:8k_2_02:30]
Since 1992, Omnicell (NASDAQ: OMCL) has been inspired to create safer and more efficient ways to manage medications and supplies across all care settings. As a leader in medication and supply dispensing automation, central pharmacy automation, IV robotics, analytics software, and medication adherence and packaging systems, Omnicell is focused on improving care across the entire healthcare continuum-from the acute care hospital setting, to post-acute skilled nursing and long-term care facilities, to the patient’s home.

[0000926326-17-000035:8k_2_02:31]
Approximately 4,000 customers worldwide use Omnicell® automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence and improve patient safety.

[0000926326-17-000035:8k_2_02:32]
Omnicell’s innovative medication adherence solutions, used by over 32,000 institutional and retail pharmacies in North America and the United Kingdom, are designed to improve patient adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-17-000035:8k_2_02:33]
Recent Omnicell acquisitions add distinct capabilities, particularly in central pharmacy, IV robotics, and pharmacy software, creating the broadest medication management product portfolio in the industry.

[0000926326-17-000035:8k_2_02:34]
For more information about Omnicell, Inc. please visit www.omnicell.com.

[0000926326-17-000035:8k_2_02:35]
Forward-Looking Statements

[0000926326-17-000035:8k_2_02:36]
Use of Non-GAAP Financial Information

[0000926326-17-000035:8k_2_02:37]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles. Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-17-000035:8k_2_02:38]
Our non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-17-000035:8k_2_02:39]
a)  Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-17-000035:8k_2_02:40]
b) Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-17-000035:8k_2_02:41]
c) Amortization of debt issuance cost. Debt issuance cost represents costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The cost includes underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-17-000035:8k_2_02:42]
d) Acquisition accounting impact related to deferred revenue. In connection with recent acquisitions, business combination rules require us to account for the fair values of arrangements for which acceptance has not been obtained, and post installation support has not been provided in our purchase accounting. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0000926326-17-000035:8k_2_02:43]
e) Inventory fair value adjustments. In connection with acquisition of Aesynt, business combination rules require us to account for the fair values of inventory acquired in our purchase accounting. The non-GAAP adjustment to the cost of revenues is intended to include the impact of such adjustment. We believe the adjustment is useful as a measure of the ongoing performance of our business.

[0000926326-17-000035:8k_2_02:44]
f) Acquisition related expenses. We excluded from the non-GAAP results the expenses which are related to the recent acquisitions. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition related expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of less acquisitive peer companies.

[0000926326-17-000035:8k_2_02:45]
g) Severance and other related expenses. We excluded from our non-GAAP results the expenses which are related to the restructuring and integrations related events. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of less acquisitive peer companies.

[0000926326-17-000035:8k_2_02:46]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans.

[0000926326-17-000035:8k_2_02:47]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-17-000035:8k_2_02:48]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0000926326-17-000035:8k_2_02:49]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0000926326-17-000035:8k_2_02:50]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0000926326-17-000035:8k_2_02:51]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-17-000035:8k_2_02:52]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-17-000035:8k_2_02:53]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-17-000035:8k_2_02:54]
ii) We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-17-000035:8k_2_02:55]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as certain non-GAAP adjustments.

[0000926326-17-000035:8k_2_02:56]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-17-000035:8k_2_02:57]
| • | Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718. |

[0000926326-17-000035:8k_2_02:58]
| • | Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure. |

[0000926326-17-000035:8k_2_02:59]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-17-000035:8k_2_02:60]
With respect to the Company’s expectations under “Guidance” above, and regarding certain projections discussed on today’s teleconference, reconciliation of non-GAAP earnings ranges per share guidance for the remainder of 2017, to the closest corresponding GAAP measures is not available without unreasonable efforts as we are unable to predict with reasonable certainty the matters we would allocate to “certain items,” including unusual gains and losses, costs associated with future restructurings, acquisition-related expenses and litigation outcomes. These items are uncertain, complex, depend on various factors, have low visibility and could have a material impact on GAAP EPS in future periods.

[0000926326-17-000035:8k_2_02:61]
5

[0000926326-17-000035:8k_2_02:62]
Omnicell, Inc.

[0000926326-17-000035:8k_2_02:63]
Condensed Consolidated Statements of Operations

[0000926326-17-000035:8k_2_02:64]
(Unaudited, in thousands, except per share data)

[0000926326-17-000035:8k_2_02:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2017 |  | June 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product | $ | 135,103 |  |  | $ | 128,056 |  |  | $ | 133,621 |  |  | $ | 362,089 |  |  | $ | 392,190 |  |
| Services and other revenues | 51,679 |  |  | 52,829 |  |  | 43,116 |  |  | 156,132 |  |  | 128,458 |  |
| Total revenues | 186,782 |  |  | 180,885 |  |  | 176,737 |  |  | 518,221 |  |  | 520,648 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 79,725 |  |  | 81,738 |  |  | 76,188 |  |  | 225,051 |  |  | 224,412 |  |
| Cost of services and other revenues | 22,204 |  |  | 21,172 |  |  | 19,041 |  |  | 66,150 |  |  | 56,766 |  |
| Total cost of revenues | 101,929 |  |  | 102,910 |  |  | 95,229 |  |  | 291,201 |  |  | 281,178 |  |
| Gross profit | 84,853 |  |  | 77,975 |  |  | 81,508 |  |  | 227,020 |  |  | 239,470 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 16,414 |  |  | 16,911 |  |  | 15,264 |  |  | 50,128 |  |  | 42,896 |  |
| Selling, general and administrative | 58,725 |  |  | 63,468 |  |  | 61,316 |  |  | 186,818 |  |  | 189,912 |  |
| Total operating expenses | 75,139 |  |  | 80,379 |  |  | 76,580 |  |  | 236,946 |  |  | 232,808 |  |
| Income (loss) from operations | 9,714 |  |  | (2,404 | ) |  | 4,928 |  |  | (9,926 | ) |  | 6,662 |  |
| Interest and other income (expense), net | (2,732 | ) |  | 196 |  |  | (2,721 | ) |  | (4,992 | ) |  | (6,773 | ) |
| Income (loss) before provision for income taxes | 6,982 |  |  | (2,208 | ) |  | 2,207 |  |  | (14,918 | ) |  | (111 | ) |
| Expense (benefit) for income taxes | 751 |  |  | (3,045 | ) |  | 224 |  |  | (11,232 | ) |  | (557 | ) |
| Net income (loss) | $ | 6,231 |  |  | $ | 837 |  |  | $ | 1,983 |  |  | $ | (3,686 | ) |  | $ | 446 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.17 |  |  | $ | 0.02 |  |  | $ | 0.05 |  |  | $ | (0.10 | ) |  | $ | 0.01 |  |
| Diluted | $ | 0.16 |  |  | $ | 0.02 |  |  | $ | 0.05 |  |  | $ | (0.10 | ) |  | $ | 0.01 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic | 37,698 |  |  | 37,250 |  |  | 36,332 |  |  | 37,266 |  |  | 36,020 |  |
| Diluted | 38,973 |  |  | 38,370 |  |  | 37,079 |  |  | 37,266 |  |  | 36,695 |  |

[0000926326-17-000035:8k_2_02:66]
6

[0000926326-17-000035:8k_2_02:67]
Omnicell, Inc.

[0000926326-17-000035:8k_2_02:68]
Condensed Consolidated Balance Sheets

[0000926326-17-000035:8k_2_02:69]
(Unaudited, in thousands)

[0000926326-17-000035:8k_2_02:70]
|  | September 30, 2017 |  | December 31, 2016 |
| ASSETS |
| Current assets: |  |  |  |  |
| Cash and cash equivalents | $ | 7,466 |  |  | $ | 54,488 |  |
| Accounts receivable, net | 171,869 |  |  | 150,303 |  |
| Inventories | 92,239 |  |  | 69,297 |  |
| Prepaid expenses | 28,044 |  |  | 28,646 |  |
| Other current assets | 15,763 |  |  | 12,674 |  |
| Total current assets | 315,381 |  |  | 315,408 |  |
| Property and equipment, net | 40,219 |  |  | 42,011 |  |
| Long-term investment in sales-type leases, net | 15,986 |  |  | 20,585 |  |
| Goodwill | 334,780 |  |  | 327,724 |  |
| Intangible assets, net | 174,227 |  |  | 190,283 |  |
| Long-term deferred tax assets | 5,629 |  |  | 4,041 |  |
| Other long-term assets | 37,596 |  |  | 35,051 |  |
| Total assets | $ | 923,818 |  |  | $ | 935,103 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |
| Accounts payable | $ | 51,182 |  |  | $ | 27,069 |  |
| Accrued compensation | 27,380 |  |  | 26,722 |  |
| Accrued liabilities | 33,061 |  |  | 31,195 |  |
| Long-term debt, current portion, net | 13,410 |  |  | 8,410 |  |
| Deferred revenue, net | 80,837 |  |  | 87,516 |  |
| Total current liabilities | 205,870 |  |  | 180,912 |  |
| Long-term, deferred revenue | 16,376 |  |  | 17,051 |  |
| Long-term deferred tax liabilities | 40,527 |  |  | 51,592 |  |
| Other long-term liabilities | 9,625 |  |  | 8,210 |  |
| Long-term debt, net | 178,923 |  |  | 245,731 |  |
| Total liabilities | 451,321 |  |  | 503,496 |  |
| Total stockholders’ equity | 472,497 |  |  | 431,607 |  |
| Total liabilities and stockholders’ equity | $ | 923,818 |  |  | $ | 935,103 |  |

[0000926326-17-000035:8k_2_02:71]
Omnicell, Inc.

[0000926326-17-000035:8k_2_02:72]
Condensed Consolidated Statements of Cash Flows

[0000926326-17-000035:8k_2_02:73]
(Unaudited, in thousands)

[0000926326-17-000035:8k_2_02:74]
|  | Nine months ended September 30, |
|  | 2017 |  | 2016 |
| Operating Activities |  |  |  |
| Net income (loss) | $ | (3,686 | ) |  | $ | 446 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 38,542 |  |  | 43,905 |  |
| (Gain) loss on disposal of fixed assets | 128 |  |  | (9 | ) |
| Share-based compensation expense | 16,315 |  |  | 14,063 |  |
| Income tax benefits from employee stock plans | 11 |  |  | 1,256 |  |
| Deferred income taxes | (11,071 | ) |  | (4,767 | ) |
| Amortization of debt financing fees | 1,192 |  |  | 1,192 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | (21,710 | ) |  | (25,802 | ) |
| Inventories | (22,942 | ) |  | (7,745 | ) |
| Prepaid expenses | 602 |  |  | (5,782 | ) |
| Other current assets | (5,133 | ) |  | (89 | ) |
| Investment in sales-type leases | 6,643 |  |  | (5,296 | ) |
| Other long-term assets | (150 | ) |  | 1,153 |  |
| Accounts payable | 23,717 |  |  | 5,573 |  |
| Accrued compensation | 658 |  |  | (687 | ) |
| Accrued liabilities | 4,021 |  |  | (1,901 | ) |
| Deferred revenue | (7,354 | ) |  | 12,819 |  |
| Other long-term liabilities | 865 |  |  | (2,299 | ) |
| Net cash provided by operating activities | 20,648 |  |  | 26,030 |  |
| Investing Activities |  |  |  |
| Purchases of intangible assets, intellectual property and patents | (160 | ) |  | (1,311 | ) |
| Software development for external use | (10,121 | ) |  | (10,569 | ) |
| Purchases of property and equipment | (9,374 | ) |  | (10,005 | ) |
| Business acquisition, net of cash acquired | (4,446 | ) |  | (271,458 | ) |
| Net cash used in investing activities | (24,101 | ) |  | (293,343 | ) |
| Financing Activities |  |  |  |
| Proceeds from debt | 37,000 |  |  | 247,051 |  |
| Repayment of debt and revolving credit facility | (100,000 | ) |  | (25,000 | ) |
| Payment for contingent consideration | (2,400 | ) |  | (3,000 | ) |
| Proceeds from issuances under stock-based compensation plans | 26,468 |  |  | 16,516 |  |
| Employees' taxes paid related to restricted stock units | (3,133 | ) |  | (1,917 | ) |
| Net cash provided by (used in) financing activities | (42,065 | ) |  | 233,650 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,504 | ) |  | (1,267 | ) |
| Net decrease in cash and cash equivalents | (47,022 | ) |  | (34,930 | ) |
| Cash and cash equivalents at beginning of period | 54,488 |  |  | 82,217 |  |
| Cash and cash equivalents at end of period | $ | 7,466 |  |  | $ | 47,287 |  |

[0000926326-17-000035:8k_2_02:75]
8

[0000926326-17-000035:8k_2_02:76]
Omnicell, Inc.

[0000926326-17-000035:8k_2_02:77]
Reconciliation of GAAP to Non-GAAP

[0000926326-17-000035:8k_2_02:78]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-17-000035:8k_2_02:79]
|  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  |  | September 30, 2017 |  | June 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Reconciliation of GAAP revenue to non-GAAP revenue: |  |  |  |  |  |  |
| GAAP revenue |  | $ | 186,782 |  |  | $ | 180,885 |  |  | $ | 176,737 |  |  | $ | 518,221 |  |  | $ | 520,648 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 939 |  |  | 7,989 |  |
| Non-GAAP revenue | $ | 187,095 |  |  | $ | 181,198 |  |  | $ | 179,400 |  |  | $ | 519,160 |  |  | $ | 528,637 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |
| GAAP gross profit | $ | 84,853 |  |  | $ | 77,975 |  |  | $ | 81,508 |  |  | $ | 227,020 |  |  | $ | 239,470 |  |
| GAAP gross margin | 45.4% |  | 43.1% |  | 46.1% |  | 43.8% |  | 46.0% |
|  | Share-based compensation expense | 882 |  |  | 864 |  |  | 628 |  |  | 2,728 |  |  | 1,821 |  |
|  | Amortization of acquired intangibles | 2,985 |  |  | 2,848 |  |  | 5,199 |  |  | 8,670 |  |  | 15,624 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 939 |  |  | 7,989 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 920 |  |  | — |  |  | 2,761 |  |
|  | Acquisitions related expenses | — |  |  | — |  |  | 44 |  |  | — |  |  | 72 |  |
|  | Severance and other expenses* | 70 |  |  | — |  |  | — |  |  | 1,767 |  |  | 199 |  |
| Non-GAAP gross profit | $ | 89,103 |  |  | $ | 82,000 |  |  | $ | 90,962 |  |  | $ | 241,124 |  |  | $ | 267,936 |  |
| Non-GAAP gross margin | 47.6% |  | 45.3% |  | 50.7% |  | 46.4% |  | 50.7% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 75,139 |  |  | $ | 80,379 |  |  | $ | 76,580 |  |  | $ | 236,946 |  |  | $ | 232,808 |  |
| GAAP operating expenses % to total revenue |  | 40.2% |  | 44.4% |  | 43.3% |  | 45.7% |  | 44.7% |
|  | Share-based compensation expense | (4,377 | ) |  | (4,681 | ) |  | (4,049 | ) |  | (13,587 | ) |  | (12,242 | ) |
|  | Amortization of acquired intangibles | (3,381 | ) |  | (3,626 | ) |  | (3,714 | ) |  | (10,660 | ) |  | (11,500 | ) |
|  | Acquisitions related expenses | — |  |  | — |  |  | (342 | ) |  | (126 | ) |  | (3,420 | ) |
|  | Severance and other expenses* | (229 | ) |  | (970 | ) |  | — |  |  | (3,531 | ) |  | (1,504 | ) |
| Non-GAAP operating expenses | $ | 67,152 |  |  | $ | 71,102 |  |  | $ | 68,475 |  |  | $ | 209,042 |  |  | $ | 204,142 |  |
| Non-GAAP operating expenses % to total revenue | 35.9% |  | 39.2% |  | 38.2% |  | 40.3% |  | 38.6% |

[0000926326-17-000035:8k_2_02:80]
* Other expenses include depreciation adjustment related to purchase price allocation from acquisition of $253, integration consulting of $30, restructuring rent expense of $14 and an adjustment to relocation and severance charges of ($68) for the three months ended September 30, 2017. Other expenses include relocation charge of $320, restructuring rent expense of $499, integration consulting of $156 and depreciation adjustment related to purchase price allocation from acquisition of $759 for the nine months ended September 30, 2017.

[0000926326-17-000035:8k_2_02:81]
|  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  |  | September 30, 2017 |  | June 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income (loss) from operations: |  |  |
| GAAP income (loss) from operations | $ | 9,714 |  |  | $ | (2,404 | ) |  | $ | 4,928 |  |  | $ | (9,926 | ) |  | $ | 6,662 |  |
| GAAP operating income (loss) % to total revenue |  | 5.2% |  | (1.3)% |  | 2.8% |  | (1.9)% |  | 1.3% |
|  | Share-based compensation expense | 5,259 |  |  | 5,545 |  |  | 4,677 |  |  | 16,315 |  |  | 14,063 |  |
|  | Amortization of acquired intangibles | 6,366 |  |  | 6,474 |  |  | 8,913 |  |  | 19,330 |  |  | 27,124 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 939 |  |  | 7,989 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 920 |  |  | — |  |  | 2,761 |  |
|  | Acquisitions related expenses | — |  |  | — |  |  | 386 |  |  | 126 |  |  | 3,492 |  |
|  | Severance and other expenses | 299 |  |  | 970 |  |  | — |  |  | 5,298 |  |  | 1,703 |  |
| Non-GAAP income from operations | $ | 21,951 |  |  | $ | 10,898 |  |  | $ | 22,487 |  |  | $ | 32,082 |  |  | $ | 63,794 |  |
| Non-GAAP operating income % to total Non-GAAP revenue | 11.7% |  | 6.0% |  | 12.5% |  | 6.2% |  | 12.1% |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |  |  |  |  |  |  |
| GAAP net income (loss) | $ | 6,231 |  |  | $ | 837 |  |  | $ | 1,983 |  |  | $ | (3,686 | ) |  | $ | 446 |  |
|  | Share-based compensation expense | 5,259 |  |  | 5,545 |  |  | 4,677 |  |  | 16,315 |  |  | 14,063 |  |
|  | Amortization of acquired intangibles | 6,366 |  |  | 6,474 |  |  | 8,913 |  |  | 19,330 |  |  | 27,124 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 939 |  |  | 7,989 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 920 |  |  | — |  |  | 2,761 |  |
|  | Acquisitions related expenses | 397 |  |  | 397 |  |  | 783 |  |  | 1,317 |  |  | 4,684 |  |
|  | Severance and other expenses | 299 |  |  | 970 |  |  | — |  |  | 5,298 |  |  | 1,703 |  |
|  | Tax effect of the adjustments above(a) | (2,579 | ) |  | (2,817 | ) |  | (5,047 | ) |  | (9,415 | ) |  | (16,820 | ) |
| Non-GAAP net income | $ | 16,286 |  |  | $ | 11,719 |  |  | $ | 14,892 |  |  | $ | 30,098 |  |  | $ | 41,950 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 38,973 |  |  | 38,370 |  |  | 37,079 |  |  | 37,266 |  |  | 36,695 |  |
| Shares - diluted Non-GAAP | 38,973 |  |  | 38,370 |  |  | 37,079 |  |  | 38,418 |  |  | 36,695 |  |
| GAAP net income (loss) per share - diluted | $ | 0.16 |  |  | $ | 0.02 |  |  | $ | 0.05 |  |  | $ | (0.10 | ) |  | $ | 0.01 |  |
|  | Share-based compensation expense | 0.14 |  |  | 0.14 |  |  | 0.13 |  |  | 0.43 |  |  | 0.38 |  |
|  | Amortization of acquired intangibles | 0.16 |  |  | 0.17 |  |  | 0.24 |  |  | 0.50 |  |  | 0.74 |  |
|  | Acquisition accounting impact related to deferred revenue | 0.01 |  |  | 0.01 |  |  | 0.07 |  |  | 0.02 |  |  | 0.22 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 0.02 |  |  | — |  |  | 0.08 |  |
|  | Acquisitions related expenses | 0.01 |  |  | 0.01 |  |  | 0.02 |  |  | 0.03 |  |  | 0.13 |  |
|  | Severance and other expenses | 0.01 |  |  | 0.02 |  |  | — |  |  | 0.14 |  |  | 0.04 |  |
|  | Tax effect of the adjustments above(a) | (0.07 | ) |  | (0.06 | ) |  | (0.13 | ) |  | (0.24 | ) |  | (0.46 | ) |
| Non-GAAP net income per share - diluted | $ | 0.42 |  |  | $ | 0.31 |  |  | $ | 0.40 |  |  | $ | 0.78 |  |  | $ | 1.14 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP Adjusted EBITDA(b): |  |  |  |  |  |  |
| GAAP net income (loss) | $ | 6,231 |  |  | $ | 837 |  |  | $ | 1,983 |  |  | $ | (3,686 | ) |  | $ | 446 |  |
|  | Share-based compensation expense | 5,259 |  |  | 5,545 |  |  | 4,677 |  |  | 16,315 |  |  | 14,063 |  |
|  | Interest (income) and expense, net | 2,127 |  |  | 1,311 |  |  | 1,523 |  |  | 4,870 |  |  | 4,618 |  |
|  | Depreciation and amortization expense | 12,600 |  |  | 13,494 |  |  | 14,702 |  |  | 38,542 |  |  | 43,899 |  |
|  | Acquisition accounting impact related to deferred revenue | 313 |  |  | 313 |  |  | 2,663 |  |  | 939 |  |  | 7,989 |  |
|  | Inventory fair value adjustments | — |  |  | — |  |  | 920 |  |  | — |  |  | 2,761 |  |
|  | Acquisitions related expenses | 397 |  |  | 397 |  |  | 783 |  |  | 1,317 |  |  | 4,684 |  |
|  | Severance expense | 46 |  |  | 728 |  |  | — |  |  | 4,539 |  |  | 1,703 |  |
|  | Income tax expense | 751 |  |  | (3,045 | ) |  | 224 |  |  | (11,232 | ) |  | (557 | ) |
| Non-GAAP Adjusted EBITDA | $ | 27,724 |  |  | $ | 19,580 |  |  | $ | 27,475 |  |  | $ | 51,604 |  |  | $ | 79,606 |  |

[0000926326-17-000035:8k_2_02:82]
(a) Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 35% for fiscal year 2017 and 38% for fiscal year 2016.

[0000926326-17-000035:8k_2_02:83]
(b) Defined as earnings before interest income and expense, taxes, depreciation and amortization, as well as excluding certain non-GAAP adjustments.

[0000926326-17-000035:8k_2_02:84]
10

[0000926326-17-000035:8k_2_02:85]
Omnicell, Inc.

[0000926326-17-000035:8k_2_02:86]
Segmented Information

[0000926326-17-000035:8k_2_02:87]
(Unaudited, in thousands, except for percentages)

[0000926326-17-000035:8k_2_02:88]
|  | Three Months Ended September 30, 2017 |  | Three Months Ended September 30, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 154,651 |  |  | $ | 32,131 |  |  | $ | 186,782 |  |  | $ | 152,437 |  |  | $ | 24,300 |  |  | $ | 176,737 |  |
| Cost of revenues | 79,740 |  |  | 22,189 |  |  | 101,929 |  |  | 77,828 |  |  | 17,401 |  |  | 95,229 |  |
| Gross profit | 74,911 |  |  | 9,942 |  |  | 84,853 |  |  | 74,609 |  |  | 6,899 |  |  | 81,508 |  |
| Gross margin % | 48.4% |  | 30.9% |  | 45.4% |  | 48.9% |  | 28.4% |  | 46.1% |
| Operating expenses | 46,849 |  |  | 9,901 |  |  | 56,750 |  |  | 49,123 |  |  | 6,137 |  |  | 55,260 |  |
| Income from segment operations | $ | 28,062 |  |  | $ | 41 |  |  | $ | 28,103 |  |  | $ | 25,486 |  |  | $ | 762 |  |  | $ | 26,248 |  |
| Operating margin % | 18.1% |  | 0.1% |  | 15.0% |  | 16.7% |  | 3.1% |  | 14.9% |
| Corporate costs |  |  |  |  | 18,389 |  |  |  |  |  |  | 21,320 |  |
| Loss from operations |  |  |  |  | $ | 9,714 |  |  |  |  |  |  | $ | 4,928 |  |

[0000926326-17-000035:8k_2_02:89]
11

[0000926326-17-000035:8k_2_02:90]
Omnicell, Inc.

[0000926326-17-000035:8k_2_02:91]
Segmented Information

[0000926326-17-000035:8k_2_02:92]
(Unaudited, in thousands, except for percentages)

[0000926326-17-000035:8k_2_02:93]
|  | Nine Months Ended September 30, 2017 |  | Nine Months Ended September 30, 2016 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 427,250 |  |  | $ | 90,971 |  |  | $ | 518,221 |  |  | $ | 450,043 |  |  | $ | 70,605 |  |  | $ | 520,648 |  |
| Cost of revenues | 229,218 |  |  | 61,983 |  |  | 291,201 |  |  | 233,401 |  |  | 47,777 |  |  | 281,178 |  |
| Gross profit | 198,032 |  |  | 28,988 |  |  | 227,020 |  |  | 216,642 |  |  | 22,828 |  |  | 239,470 |  |
| Gross margin % | 46.4% |  | 31.9% |  | 43.8% |  | 48.1% |  | 32.3% |  | 46.0% |
| Operating expenses | 146,651 |  |  | 31,196 |  |  | 177,847 |  |  | 151,108 |  |  | 17,518 |  |  | 168,626 |  |
| Income (loss) from segment operations | $ | 51,381 |  |  | $ | (2,208 | ) |  | $ | 49,173 |  |  | $ | 65,534 |  |  | $ | 5,310 |  |  | $ | 70,844 |  |
| Operating margin % | 12.0% |  | (2.4)% |  | 9.5% |  | 14.6% |  | 7.5% |  | 13.6% |
| Corporate costs |  |  |  |  | 59,099 |  |  |  |  |  |  | 64,182 |  |
| Income (loss) from operations |  |  |  |  | $ | (9,926 | ) |  |  |  |  |  | $ | 6,662 |  |

[0000926326-17-000035:8k_2_02:94]
Omnicell, Inc.

[0000926326-17-000035:8k_2_02:95]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-17-000035:8k_2_02:96]
(Unaudited, in thousands, except for percentages)

[0000926326-17-000035:8k_2_02:97]
|  | Three Months Ended September 30, 2017 |  |  |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 154,651 |  |  |  |  |  |  | $ | 32,131 |  |  |  |  |  |  | $ | 186,782 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenue | — |  |  | —% |  | —% |  | 313 |  |  | 1.0% |  | 1.0% |  | 313 |  |  | 0.2% |  | 0.2% |
| Non-GAAP Revenues | $ | 154,651 |  |  |  |  |  |  | $ | 32,444 |  |  |  |  |  |  | $ | 187,095 |  |  |  |  |  |
| GAAP Gross profit | $ | 74,911 |  |  | 48.4% |  |  |  | $ | 9,942 |  |  | 30.9% |  |  |  | $ | 84,853 |  |  | 45.4% |  |  |
| Share-based compensation expense | 739 |  |  | 0.5% |  | 0.5% |  | 143 |  |  | 0.4% |  | 0.4% |  | 882 |  |  | 0.5% |  | 0.5% |
| Amortization expense of acquired intangible assets | 2,393 |  |  | 1.5% |  | 1.5% |  | 592 |  |  | 1.8% |  | 1.8% |  | 2,985 |  |  | 1.6% |  | 1.6% |
| Acquisition accounting impact related to deferred revenue | — |  |  | —% |  | —% |  | 313 |  |  | 1.0% |  | 1.0% |  | 313 |  |  | 0.2% |  | 0.2% |
| Severance and other expenses | 119 |  |  | 0.1% |  | 0.1% |  | (49 | ) |  | (0.2)% |  | (0.2)% |  | 70 |  |  | —% |  | —% |
| Non-GAAP Gross profit | $ | 78,162 |  |  |  |  | 50.5% |  | $ | 10,941 |  |  |  |  | 33.7% |  | $ | 89,103 |  |  |  |  | 47.6% |
| GAAP Operating income | $ | 28,062 |  |  | 18.1% |  |  |  | $ | 41 |  |  | 0.1% |  |  |  | $ | 28,103 |  |  | 15.0% |  |  |
| Share-based compensation expense | 2,365 |  |  | 1.5% |  | 1.5% |  | 368 |  |  | 1.1% |  | 1.1% |  | 2,733 |  |  | 1.5% |  | 1.5% |
| Amortization expense of acquired intangible assets | 4,485 |  |  | 2.9% |  | 2.9% |  | 1,881 |  |  | 5.9% |  | 5.8% |  | 6,366 |  |  | 3.4% |  | 3.4% |
| Acquisition accounting impact related to deferred revenue | — |  |  | —% |  | —% |  | 313 |  |  | 1.0% |  | 1.0% |  | 313 |  |  | 0.2% |  | 0.2% |
| Severance and other expenses | 96 |  |  | 0.1% |  | 0.1% |  | (61 | ) |  | (0.2)% |  | (0.2)% |  | 35 |  |  | —% |  | —% |
| Non-GAAP Operating income | $ | 35,008 |  |  |  |  | 22.6% |  | $ | 2,542 |  |  |  |  | 7.8% |  | $ | 37,550 |  |  |  |  | 20.1% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 18,389 |  |  | 9.8% |  |  |
| Share-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (2,526 | ) |  | (1.4)% |  | (1.4)% |
| Acquisition-related expenses |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | —% |  | —% |
| Severance and other expenses |  |  |  |  |  |  |  |  |  |  |  |  | (264 | ) |  | (0.1)% |  | (0.1)% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 15,599 |  |  |  |  | 8.3% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 21,951 |  |  |  |  | 11.7% |

[0000926326-17-000035:8k_2_02:98]
13

[0000926326-17-000035:8k_2_02:99]
Omnicell, Inc.

[0000926326-17-000035:8k_2_02:100]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-17-000035:8k_2_02:101]
(Unaudited, in thousands, except for percentages)

[0000926326-17-000035:8k_2_02:102]
|  | Three Months Ended September 30, 2016 |  |  |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 152,437 |  |  |  |  |  |  | $ | 24,300 |  |  |  |  |  |  | $ | 176,737 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.7 | % |  | 1.7 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.5 | % |  | 1.5 | % |
| Non-GAAP Revenues | $ | 155,100 |  |  |  |  |  |  | $ | 24,300 |  |  |  |  |  |  | $ | 179,400 |  |  |  |  |  |
| GAAP Gross profit | $ | 74,609 |  |  | 48.9 | % |  |  |  | $ | 6,899 |  |  | 28.4 | % |  |  |  | $ | 81,508 |  |  | 46.1 | % |  |  |
| Stock-based compensation expense | 511 |  |  | 0.3 | % |  | 0.3 | % |  | 117 |  |  | 0.5 | % |  | 0.5 | % |  | 628 |  |  | 0.4 | % |  | 0.4 | % |
| Amortization expense of acquired intangible assets | 4,867 |  |  | 3.2 | % |  | 3.1 | % |  | 332 |  |  | 1.4 | % |  | 1.4 | % |  | 5,199 |  |  | 2.9 | % |  | 2.9 | % |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.7 | % |  | 1.7 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.5 | % |  | 1.5 | % |
| Inventory fair value adjustments | 920 |  |  | 0.6 | % |  | 0.6 | % |  | — |  |  | — | % |  | — | % |  | 920 |  |  | 0.5 | % |  | 0.5 | % |
| Acquisitions related expenses | 44 |  |  | — | % |  | — | % |  | — |  |  | — | % |  | — | % |  | 44 |  |  | — | % |  | — | % |
| Non-GAAP Gross profit | $ | 83,614 |  |  |  |  | 53.9 | % |  | $ | 7,348 |  |  |  |  | 30.2 | % |  | $ | 90,962 |  |  |  |  | 50.7 | % |
| GAAP Operating income | $ | 25,486 |  |  | 16.7 | % |  |  |  | $ | 762 |  |  | 3.1 | % |  |  |  | $ | 26,248 |  |  | 14.9 | % |  |  |
| Stock-based compensation expense | 1,952 |  |  | 1.3 | % |  | 1.3 | % |  | 264 |  |  | 1.1 | % |  | 1.1 | % |  | 2,216 |  |  | 1.3 | % |  | 1.2 | % |
| Amortization expense of acquired intangible assets | 7,623 |  |  | 5.0 | % |  | 4.9 | % |  | 1,290 |  |  | 5.3 | % |  | 5.3 | % |  | 8,913 |  |  | 5.0 | % |  | 5.0 | % |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.7 | % |  | 1.7 | % |  | — |  |  | — | % |  | — | % |  | 2,663 |  |  | 1.5 | % |  | 1.5 | % |
| Inventory fair value adjustments | 920 |  |  | 0.6 | % |  | 0.6 | % |  | — |  |  | — | % |  | — | % |  | 920 |  |  | 0.5 | % |  | 0.5 | % |
| Acquisitions related expenses | 133 |  |  | 0.1 | % |  | 0.1 | % |  | — |  |  | — | % |  | — | % |  | 133 |  |  | 0.1 | % |  | 0.1 | % |
| Non-GAAP Operating income | $ | 38,777 |  |  |  |  | 25.0 | % |  | $ | 2,316 |  |  |  |  | 9.5 | % |  | $ | 41,093 |  |  |  |  | 22.9 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 21,320 |  |  | 12.1 | % |  |  |
| Stock-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (2,461 | ) |  | (1.4 | )% |  | (1.4 | )% |
| Acquisition related expenses |  |  |  |  |  |  |  |  |  |  |  |  | (253 | ) |  | (0.1 | )% |  | (0.1 | )% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 18,606 |  |  |  |  | 10.4 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 22,487 |  |  |  |  | 12.5 | % |
