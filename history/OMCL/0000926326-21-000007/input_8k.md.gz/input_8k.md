# OMCL 8-K — 0000926326-21-000004 filed 2021-02-01

## item codes, every 8-K on or before 2021-02-24

- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2021-02-24

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-21-000004:8k_2_02:1]
EX-99.1
2
exhibit991q4-20.htm
EX-99.1

[0000926326-21-000004:8k_2_02:2]
Document

[0000926326-21-000004:8k_2_02:3]
Exhibit 99.1

[0000926326-21-000004:8k_2_02:4]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Vice President, Investor Relations |  | 590 East Middlefield Road |
| 650-435-3318 |  | Mountain View, CA 94043 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0000926326-21-000004:8k_2_02:5]
Omnicell Reports Fiscal Year and Fourth Quarter 2020 Results

[0000926326-21-000004:8k_2_02:6]
Record 2020 Total Product Bookings of $1+ billion

[0000926326-21-000004:8k_2_02:7]
Full Year 2020 Revenues of $892.2 million

[0000926326-21-000004:8k_2_02:8]
Ended Year with 145 Long-Term, Sole-Source Agreements with the Top 300 U.S. Health Systems

[0000926326-21-000004:8k_2_02:9]
Entered 2021 with Record Product Backlog of $924 million

[0000926326-21-000004:8k_2_02:10]
MOUNTAIN VIEW, Calif. -- February 1, 2021 -- Omnicell, Inc. (NASDAQ:OMCL), a leading provider of medication management solutions and adherence tools for healthcare systems and pharmacies, today announced results for its fiscal year and fourth quarter ended December 31, 2020.

[0000926326-21-000004:8k_2_02:11]
GAAP Results

[0000926326-21-000004:8k_2_02:12]
Total revenues for the fourth quarter of 2020 were $249.2 million, up $0.9 million from the fourth quarter of 2019. Total revenues for the year ended December 31, 2020 were $892.2 million, down $4.8 million from the year ended December 31, 2019.

[0000926326-21-000004:8k_2_02:13]
Fourth quarter 2020 GAAP net income was $16.4 million, or $0.37 per diluted share. This compares to GAAP net income of $22.1 million, or $0.51 per diluted share, for the fourth quarter of 2019.

[0000926326-21-000004:8k_2_02:14]
GAAP net income for the year ended December 31, 2020 was $32.2 million, or $0.74 per diluted share. This compares to GAAP net income of $61.3 million, or $1.43 per diluted share, for the year ended December 31, 2019.

[0000926326-21-000004:8k_2_02:15]
Non-GAAP Results

[0000926326-21-000004:8k_2_02:16]
Non-GAAP net income for the fourth quarter of 2020 was $40.2 million, or $0.91 per diluted share. This compares to non-GAAP net income of $33.5 million, or $0.77 per diluted share, for the fourth quarter of 2019.

[0000926326-21-000004:8k_2_02:17]
Non-GAAP net income for the year ended December 31, 2020 was $111.3 million, or $2.54 per diluted share. This compares to non-GAAP net income of $120.7 million, or $2.81 per diluted share, for the year ended December 31, 2019.

[0000926326-21-000004:8k_2_02:18]
Non-GAAP net income for each period excludes, when applicable, the effect of share-based compensation expense, amortization expense of acquired intangible assets, acquisition-related expenses, restructuring and severance-related expenses, tax restructuring benefits and expenses, amortization of debt issuance costs, amortization of discount on convertible senior notes, and certain litigation costs.

[0000926326-21-000004:8k_2_02:19]
Total product bookings for the year ended December 31, 2020 were $1.002 billion compared to $813 million for the year ended December 31, 2019, or an increase of 23% year-over-year. Total product backlog for the year ended December 31, 2020 was $924 million compared to $588 million for the year ended December 31, 2019, or an increase of 57% year-over-year.

[0000926326-21-000004:8k_2_02:20]
“We had a strong fourth quarter and full year 2020, consistent with the preliminary results we announced last month. We are pleased to have exceeded our pre-pandemic bookings guidance and October 2020 guidance across all key metrics, including total revenues, total product bookings, and non-GAAP earnings per share, and ended the year with record product bookings of more than $1 billion,” stated Randall Lipps, Chairman, President, Chief Executive Officer, and founder of Omnicell. “We made tremendous progress advancing the autonomous pharmacy as we continued expanding our portfolio and investing in developing a single, cloud-based platform that can connect nearly all of our devices. The pandemic highlighted the need for increased digitization and virtualization of processes throughout the healthcare system, underscoring the strategic relevance of Omnicell’s solutions. Pharmacy

[0000926326-21-000004:8k_2_02:21]
automation is becoming increasingly important, and that is reflected in the robust and growing demand for our offerings. Looking ahead, I believe we are well-positioned to continue driving growth in our business and delivering value for our shareholders as we support our healthcare partners on their journey to the autonomous pharmacy.”

[0000926326-21-000004:8k_2_02:22]
2021 Guidance

[0000926326-21-000004:8k_2_02:23]
For the first quarter of 2021, the Company expects total revenues to be between $243 million and $248 million. The Company expects product revenues to be between $171 million and $174 million, and service revenues to be between $72 million and $74 million. The Company expects first quarter 2021 non-GAAP EBITDA to be between $40 million and $43 million. The Company expects first quarter 2021 non-GAAP earnings to be between $0.64 and $0.69 per share.

[0000926326-21-000004:8k_2_02:24]
For the full year 2021, the Company expects product bookings to be between $1.090 billion and $1.150 billion. The Company expects total revenues to be between $1.085 billion and $1.105 billion. The Company expects product revenues to be between $770 million and $785 million, and service revenues to be between $315 million and $320 million. The Company expects 2021 non-GAAP EBITDA to be between $228 million and $240 million. The Company expects 2021 non-GAAP earnings to be between $3.40 and $3.60 per share.

[0000926326-21-000004:8k_2_02:25]
The table below summarizes Omnicell's 2021 guidance outlined above.

[0000926326-21-000004:8k_2_02:26]
|  | Q1 2021 | 2021 |
| Product Bookings | Not provided | $1.090 billion - $1.150 billion |
| Total Revenues | $243 million - $248 million | $1.085 billion - $1.105 billion |
| Product Revenues | $171 million - $174 million | $770 million - $785 million |
| Service Revenues | $72 million - $74 million | $315 million - $320 million |
| Non-GAAP EBITDA | $40 million - $43 million | $228 million - $240 million |
| Non-GAAP Earnings Per Share | $0.64 - $0.69 | $3.40 - $3.60 |

[0000926326-21-000004:8k_2_02:27]
The Company does not provide guidance for GAAP net income or GAAP earnings per share nor a reconciliation of forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures on a forward-looking basis because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These non-GAAP financial measures do not include certain items, which may be significant, including but not limited to unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-21-000004:8k_2_02:28]
2025 Targets

[0000926326-21-000004:8k_2_02:29]
The Company has established a 2025 total revenue target of $1.9 billion to $2.0 billion, reflecting a 2021-2025 compound annual growth rate (“CAGR”) of 14%-15%. On an organic basis, the Company is targeting an 11%-12% revenue CAGR over the same time frame, with expected total organic revenue of $1.65 billion to $1.75 billion in 2025.

[0000926326-21-000004:8k_2_02:30]
The Company is targeting a revenue CAGR of approximately 50% from 2020 to 2025 for Software-as-a-Service (“SaaS”), Subscription Software and Technology-Enabled Services, with revenues expected to reach 20%-30% of total Omnicell revenues by 2025.

[0000926326-21-000004:8k_2_02:31]
Omnicell has also set a non-GAAP operating margin target of approximately 21% and a non-GAAP EBITDA margin target of approximately 25% by 2025. This represents a non-GAAP operating margin and a non-GAAP EBITDA margin expansion of approximately 400 bps from 2021.

[0000926326-21-000004:8k_2_02:32]
The Company does not provide GAAP operating margin targets or GAAP net operating income margin targets nor a reconciliation of non-GAAP financial targets to the most directly comparable GAAP financial targets because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These non-GAAP financial targets do not include certain items, which may be significant, including but not limited to unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-21-000004:8k_2_02:33]
COVID-19 Update

[0000926326-21-000004:8k_2_02:34]
Keeping in mind its role in the healthcare industry, the Company is continuing to closely monitor the COVID-19 pandemic. As a result of the COVID-19 pandemic, health systems have faced financial pressures which the Company believes led its customers to delay or defer purchasing decisions and/or implementation of the Company's solutions during the first half of 2020. However, starting in the third quarter of 2020, the Company began to see its customers returning to pre-pandemic purchasing patterns consistent with long-term strategic investments. Though the Company expects to continue to face challenges and opportunities

[0000926326-21-000004:8k_2_02:35]
brought on by the COVID-19 pandemic, it remains confident in the overall health of its business and in its ability to navigate through these unusual times.

[0000926326-21-000004:8k_2_02:36]
Omnicell Conference Call Information

[0000926326-21-000004:8k_2_02:37]
Omnicell will hold a conference call today, Monday, February 1, 2021, at 1:30 p.m. PST, to discuss its 2020 fiscal year and fourth quarter financial results. Interested parties can access the conference call by dialing 1-844-358-6756 within the U.S. or 1-216-562-0399 for all other locations. The Conference ID # is 9490367. The webcast of the conference call, along with related slides, will be accessible through Omnicell’s website at https://ir.omnicell.com/investor-relations and will be available for replay through Monday, March 1, 2021.

[0000926326-21-000004:8k_2_02:38]
About Omnicell

[0000926326-21-000004:8k_2_02:39]
Since 1992, Omnicell has been committed to transforming the pharmacy care delivery model to dramatically improve outcomes and lower costs. Through the vision of the autonomous pharmacy, a combination of automation, intelligence, and technology-enabled services, powered by a cloud data platform, Omnicell supports more efficient ways to manage medications across all care settings.

[0000926326-21-000004:8k_2_02:40]
Over 7,000 facilities worldwide use Omnicell automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 50,000 institutional and retail pharmacies across North America and the United Kingdom leverage Omnicell's innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-21-000004:8k_2_02:41]
To learn more, visit www.omnicell.com. From time to time, Omnicell may use the Company's investor relations site and other online social media channels, including its Twitter handle www.twitter.com/omnicell, LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure ("FD").

[0000926326-21-000004:8k_2_02:42]
Omnicell is a registered trademark and the Omnicell logo and Omnicell One are trademarks of Omnicell, Inc. in the United States and other countries.

[0000926326-21-000004:8k_2_02:43]
Forward-Looking Statements

[0000926326-21-000004:8k_2_02:44]
Use of Non-GAAP Financial Information

[0000926326-21-000004:8k_2_02:45]
This press release contains financial measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles ("GAAP"). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to gross profit, operating expenses, income from operations, net income, net income per diluted share, GAAP diluted shares, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results and metrics because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-21-000004:8k_2_02:46]
Our non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items a), b), and d) below; non-GAAP operating expenses, non-GAAP operating margin, and non-GAAP income from operations exclude from their GAAP equivalents items a), b), c), d), h), and i) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through i) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, and amortization. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents items a), c), d), e), f), h), and i) below:

[0000926326-21-000004:8k_2_02:47]
a)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-21-000004:8k_2_02:48]
b)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-21-000004:8k_2_02:49]
c)Acquisition-related expenses. We excluded from our non-GAAP results the expenses which are related to recent acquisitions. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition-related expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of less acquisitive peer companies.

[0000926326-21-000004:8k_2_02:50]
d)Severance-related expenses. We excluded from our non-GAAP results the expenses which are related to restructuring events. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-21-000004:8k_2_02:51]
e)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of term loan and revolving credit facilities, as well as the issuance of convertible senior notes. The costs include underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-21-000004:8k_2_02:52]
f)Amortization of discount on convertible senior notes. We excluded from our non-GAAP results the amortization of the imputed discount on our convertible senior notes. Under GAAP, certain convertible debt instruments that may be settled in cash upon conversion are required to be bifurcated into separate liability and equity components in a manner that reflects the issuer's assumed non-convertible debt borrowing rate. For GAAP purposes, we are required to recognize the imputed interest expense on the difference between our assumed non-convertible debt borrowing rate and the coupon rate on our convertible senior notes. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-21-000004:8k_2_02:53]
g)Tax impact from intellectual property (“IP”) restructuring. We excluded from our non-GAAP results the tax impacts related to IP restructuring. These impacts are unrelated to our ongoing operations, and we do not expect them to occur in

[0000926326-21-000004:8k_2_02:54]
the ordinary course of business. We believe that excluding these impacts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-21-000004:8k_2_02:55]
h)IP and legal entities restructuring costs. We excluded from our non-GAAP results the expenses which are related to IP and legal entities restructuring events, such as legal and tax consulting costs. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-21-000004:8k_2_02:56]
i)Certain litigation costs. We exclude non-recurring charges and benefits, including litigation expenses and settlements, related to litigation matters that are outside of the ordinary course of our business or that are not representative of those that we historically have incurred. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-21-000004:8k_2_02:57]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans or other items.

[0000926326-21-000004:8k_2_02:58]
We believe that the presentation of non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0000926326-21-000004:8k_2_02:59]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-21-000004:8k_2_02:60]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-21-000004:8k_2_02:61]
c)These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting.

[0000926326-21-000004:8k_2_02:62]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-21-000004:8k_2_02:63]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-21-000004:8k_2_02:64]
i)While share-based compensation calculated in accordance with Accounting Standard Codification ("ASC") 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-21-000004:8k_2_02:65]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-21-000004:8k_2_02:66]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0000926326-21-000004:8k_2_02:67]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our

[0000926326-21-000004:8k_2_02:68]
overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-21-000004:8k_2_02:69]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-21-000004:8k_2_02:70]
a)Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-21-000004:8k_2_02:71]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-21-000004:8k_2_02:72]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-21-000004:8k_2_02:73]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-21-000004:8k_2_02:74]
6

[0000926326-21-000004:8k_2_02:75]
Omnicell, Inc.

[0000926326-21-000004:8k_2_02:76]
Condensed Consolidated Statements of Operations

[0000926326-21-000004:8k_2_02:77]
(Unaudited, in thousands, except per share data)

[0000926326-21-000004:8k_2_02:78]
|  | Three Months Ended December 31, |  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 175,679 |  |  | $ | 187,125 |  |  | $ | 636,031 |  |  | $ | 659,602 |  |
| Services and other revenues | 73,523 |  |  | 61,167 |  |  | 256,177 |  |  | 237,425 |  |
| Total revenues | 249,202 |  |  | 248,292 |  |  | 892,208 |  |  | 897,027 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 91,264 |  |  | 94,825 |  |  | 354,004 |  |  | 344,914 |  |
| Cost of services and other revenues | 34,284 |  |  | 29,864 |  |  | 124,912 |  |  | 115,201 |  |
| Total cost of revenues | 125,548 |  |  | 124,689 |  |  | 478,916 |  |  | 460,115 |  |
| Gross profit | 123,654 |  |  | 123,603 |  |  | 413,292 |  |  | 436,912 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 15,482 |  |  | 19,093 |  |  | 70,161 |  |  | 68,644 |  |
| Selling, general, and administrative | 87,958 |  |  | 82,328 |  |  | 307,605 |  |  | 289,916 |  |
| Total operating expenses | 103,440 |  |  | 101,421 |  |  | 377,766 |  |  | 358,560 |  |
| Income from operations | 20,214 |  |  | 22,182 |  |  | 35,526 |  |  | 78,352 |  |
| Interest and other income (expense), net | (6,338) |  |  | (212) |  |  | (6,177) |  |  | (4,419) |  |
| Income before provision for income taxes | 13,876 |  |  | 21,970 |  |  | 29,349 |  |  | 73,933 |  |
| Provision for (benefit from) income taxes | (2,501) |  |  | (125) |  |  | (2,845) |  |  | 12,595 |  |
| Net income | $ | 16,377 |  |  | $ | 22,095 |  |  | $ | 32,194 |  |  | $ | 61,338 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.39 |  |  | $ | 0.53 |  |  | $ | 0.76 |  |  | $ | 1.48 |  |
| Diluted | $ | 0.37 |  |  | $ | 0.51 |  |  | $ | 0.74 |  |  | $ | 1.43 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 42,510 |  |  | 41,993 |  |  | 42,583 |  |  | 41,462 |  |
| Diluted | 44,001 |  |  | 43,327 |  |  | 43,743 |  |  | 42,943 |  |

[0000926326-21-000004:8k_2_02:79]
Omnicell, Inc.

[0000926326-21-000004:8k_2_02:80]
Condensed Consolidated Balance Sheets

[0000926326-21-000004:8k_2_02:81]
(Unaudited, in thousands)

[0000926326-21-000004:8k_2_02:82]
|  | December 31, |
|  | 2020 |  | 2019 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 485,928 |  |  | $ | 127,210 |  |
| Accounts receivable and unbilled receivables, net | 190,117 |  |  | 218,362 |  |
| Inventories | 96,298 |  |  | 108,011 |  |
| Prepaid expenses | 16,027 |  |  | 14,478 |  |
| Other current assets | 41,044 |  |  | 15,177 |  |
| Total current assets | 829,414 |  |  | 483,238 |  |
| Property and equipment, net | 59,073 |  |  | 54,246 |  |
| Long-term investment in sales-type leases, net | 22,156 |  |  | 19,750 |  |
| Operating lease right-of-use assets | 55,114 |  |  | 56,130 |  |
| Goodwill | 499,309 |  |  | 336,539 |  |
| Intangible assets, net | 168,211 |  |  | 124,867 |  |
| Long-term deferred tax assets | 15,019 |  |  | 14,142 |  |
| Prepaid commissions | 56,919 |  |  | 48,862 |  |
| Other long-term assets | 119,289 |  |  | 103,036 |  |
| Total assets | $ | 1,824,504 |  |  | $ | 1,240,810 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 40,309 |  |  | $ | 46,380 |  |
| Accrued compensation | 55,750 |  |  | 44,155 |  |
| Accrued liabilities | 80,311 |  |  | 55,567 |  |
| Deferred revenues, net | 100,053 |  |  | 90,894 |  |
| Total current liabilities | 276,423 |  |  | 236,996 |  |
| Long-term deferred revenues | 5,673 |  |  | 7,083 |  |
| Long-term deferred tax liabilities | 39,633 |  |  | 39,090 |  |
| Long-term operating lease liabilities | 48,897 |  |  | 50,669 |  |
| Other long-term liabilities | 19,174 |  |  | 11,718 |  |
| Revolving credit facility | — |  |  | 50,000 |  |
| Convertible senior notes, net | 467,201 |  |  | — |  |
| Total liabilities | 857,001 |  |  | 395,556 |  |
| Total stockholders’ equity | 967,503 |  |  | 845,254 |  |
| Total liabilities and stockholders’ equity | $ | 1,824,504 |  |  | $ | 1,240,810 |  |

[0000926326-21-000004:8k_2_02:83]
8

[0000926326-21-000004:8k_2_02:84]
Omnicell, Inc.

[0000926326-21-000004:8k_2_02:85]
Condensed Consolidated Statements of Cash Flows

[0000926326-21-000004:8k_2_02:86]
(Unaudited, in thousands)

[0000926326-21-000004:8k_2_02:87]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |
| Operating Activities |  |  |  |
| Net income | $ | 32,194 |  |  | $ | 61,338 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 61,067 |  |  | 53,559 |  |
| Loss on disposal of property and equipment | 267 |  |  | 445 |  |
| Share-based compensation expense | 44,697 |  |  | 34,049 |  |
| Deferred income taxes | (6,546) |  |  | (1,339) |  |
| Amortization of operating lease right-of-use assets | 10,528 |  |  | 10,562 |  |
| Amortization of debt issuance costs | 1,597 |  |  | 2,204 |  |
| Amortization of discount on convertible senior notes | 4,766 |  |  | — |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | 36,842 |  |  | (21,540) |  |
| Inventories | 12,359 |  |  | (8,123) |  |
| Prepaid expenses | (2,081) |  |  | 2,909 |  |
| Other current assets | (6,408) |  |  | (2,010) |  |
| Investment in sales-type leases | (2,882) |  |  | (3,699) |  |
| Prepaid commissions | (8,057) |  |  | (2,719) |  |
| Other long-term assets | (7,675) |  |  | 4,528 |  |
| Accounts payable | (6,300) |  |  | 7,893 |  |
| Accrued compensation | 11,595 |  |  | 2,495 |  |
| Accrued liabilities | 4,374 |  |  | 3,045 |  |
| Deferred revenues | 7,620 |  |  | 5,445 |  |
| Operating lease liabilities | (9,543) |  |  | (10,040) |  |
| Other long-term liabilities | 7,456 |  |  | 6,006 |  |
| Net cash provided by operating activities | 185,870 |  |  | 145,008 |  |
| Investing Activities |  |  |  |
| Software development for external use | (32,024) |  |  | (45,770) |  |
| Purchases of property and equipment | (22,842) |  |  | (15,894) |  |
| Business acquisition | (225,000) |  |  | — |  |
| Net cash used in investing activities | (279,866) |  |  | (61,664) |  |
| Financing Activities |  |  |  |
| Proceeds from revolving credit facility | 150,000 |  |  | — |  |
| Repayment of debt and revolving credit facility | (200,000) |  |  | (90,000) |  |
| Payments for debt issuance costs for revolving credit facility | (550) |  |  | (2,321) |  |
| Proceeds from issuance of convertible senior notes, net of issuance costs | 559,665 |  |  | — |  |
| Purchase of convertible note hedge | (100,625) |  |  | — |  |
| Proceeds from sale of warrants | 51,290 |  |  | — |  |
| At the market equity offering, net of offering costs | — |  |  | 37,806 |  |
| Proceeds from issuances under stock-based compensation plans | 54,270 |  |  | 40,706 |  |
| Employees' taxes paid related to restricted stock units | (8,738) |  |  | (9,670) |  |
| Stock repurchases | (53,035) |  |  | — |  |
| Change in customer funds, net | 3,992 |  |  | — |  |
| Net cash provided by (used in) financing activities | 456,269 |  |  | (23,479) |  |
| Effect of exchange rate changes on cash and cash equivalents | 437 |  |  | 153 |  |
| Net increase in cash, cash equivalents, and restricted cash | 362,710 |  |  | 60,018 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 127,210 |  |  | 67,192 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 489,920 |  |  | $ | 127,210 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |  |  |  |
| Cash and cash equivalents | $ | 485,928 |  |  | $ | 127,210 |  |
| Restricted cash included in Other current assets | 3,992 |  |  | — |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 489,920 |  |  | $ | 127,210 |  |

[0000926326-21-000004:8k_2_02:88]
Omnicell, Inc.

[0000926326-21-000004:8k_2_02:89]
Reconciliation of GAAP to Non-GAAP

[0000926326-21-000004:8k_2_02:90]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-21-000004:8k_2_02:91]
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit | $ | 123,654 |  |  | $ | 123,603 |  |  | $ | 413,292 |  |  | $ | 436,912 |  |
| GAAP gross margin | 49.6% |  | 49.8% |  | 46.3% |  | 48.7% |
|  | Share-based compensation expense | 1,811 |  |  | 1,454 |  |  | 7,469 |  |  | 5,648 |  |
|  | Amortization of acquired intangibles | 2,901 |  |  | 2,035 |  |  | 9,001 |  |  | 8,182 |  |
|  | Severance-related expenses | — |  |  | — |  |  | 2,564 |  |  | — |  |
| Non-GAAP gross profit | $ | 128,366 |  |  | $ | 127,092 |  |  | $ | 432,326 |  |  | $ | 450,742 |  |
| Non-GAAP gross margin | 51.5% |  | 51.2% |  | 48.5% |  | 50.2% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 103,440 |  |  | $ | 101,421 |  |  | $ | 377,766 |  |  | $ | 358,560 |  |
| GAAP operating expenses % to total revenues | 41.5% |  | 40.8% |  | 42.3% |  | 40.0% |
|  | Share-based compensation expense | (9,852) |  |  | (7,420) |  |  | (37,228) |  |  | (28,401) |  |
|  | Amortization of acquired intangibles | (3,545) |  |  | (2,690) |  |  | (10,601) |  |  | (10,581) |  |
|  | Acquisition-related expenses | (2,482) |  |  | — |  |  | (5,603) |  |  | — |  |
|  | Severance-related and other expenses (a) | (1,113) |  |  | (795) |  |  | (9,385) |  |  | (1,715) |  |
| Non-GAAP operating expenses | $ | 86,448 |  |  | $ | 90,516 |  |  | $ | 314,949 |  |  | $ | 317,863 |  |
| Non-GAAP operating expenses % to total revenues | 34.7% |  | 36.5% |  | 35.3% |  | 35.4% |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |
| GAAP income from operations | $ | 20,214 |  |  | $ | 22,182 |  |  | $ | 35,526 |  |  | $ | 78,352 |  |
| GAAP operating income % to total revenues | 8.1% |  | 8.9% |  | 4.0% |  | 8.7% |
|  | Share-based compensation expense | 11,663 |  |  | 8,874 |  |  | 44,697 |  |  | 34,049 |  |
|  | Amortization of acquired intangibles | 6,446 |  |  | 4,725 |  |  | 19,602 |  |  | 18,763 |  |
|  | Acquisition-related expenses | 2,482 |  |  | — |  |  | 5,603 |  |  | — |  |
|  | Severance-related and other expenses (a) | 1,113 |  |  | 795 |  |  | 11,949 |  |  | 1,715 |  |
| Non-GAAP income from operations | $ | 41,918 |  |  | $ | 36,576 |  |  | $ | 117,377 |  |  | $ | 132,879 |  |
| Non-GAAP operating margin (non-GAAP operating income % to total revenues) | 16.8% |  | 14.7% |  | 13.2% |  | 14.8% |

[0000926326-21-000004:8k_2_02:92]
10

[0000926326-21-000004:8k_2_02:93]
Omnicell, Inc.

[0000926326-21-000004:8k_2_02:94]
Reconciliation of GAAP to Non-GAAP

[0000926326-21-000004:8k_2_02:95]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-21-000004:8k_2_02:96]
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Reconciliation of GAAP net income to non-GAAP net income: |  |  |  |  |  |
| GAAP net income | $ | 16,377 |  |  | $ | 22,095 |  |  | $ | 32,194 |  |  | $ | 61,338 |  |
|  | Tax impact of IP restructuring | — |  |  | (2,192) |  |  | — |  |  | 7,432 |  |
|  | Share-based compensation expense | 11,663 |  |  | 8,874 |  |  | 44,697 |  |  | 34,049 |  |
|  | Amortization of acquired intangibles | 6,446 |  |  | 4,725 |  |  | 19,602 |  |  | 18,763 |  |
|  | Acquisition-related expenses | 2,482 |  |  | — |  |  | 5,603 |  |  | — |  |
|  | Severance-related and other expenses (a) | 1,113 |  |  | 795 |  |  | 11,949 |  |  | 1,715 |  |
|  | Amortization of debt issuance costs | 843 |  |  | 486 |  |  | 1,597 |  |  | 2,205 |  |
|  | Amortization of discount on convertible senior notes | 4,517 |  |  | — |  |  | 4,766 |  |  | — |  |
|  | Tax effect of the adjustments above (b) | (3,234) |  |  | (1,261) |  |  | (9,139) |  |  | (4,762) |  |
| Non-GAAP net income | $ | 40,207 |  |  | $ | 33,522 |  |  | $ | 111,269 |  |  | $ | 120,740 |  |
| Reconciliation of GAAP net income per share - diluted to non-GAAP net income per share - diluted: |  |  |
| Shares - diluted GAAP | 44,001 |  |  | 43,327 |  |  | 43,743 |  |  | 42,943 |  |
|  | Dilution offset from convertible note hedge transaction (c) | (45) |  |  | — |  |  | — |  |  | — |  |
| Shares - diluted Non-GAAP | 43,956 |  |  | 43,327 |  |  | 43,743 |  |  | 42,943 |  |
| GAAP net income per share - diluted | $ | 0.37 |  |  | $ | 0.51 |  |  | $ | 0.74 |  |  | $ | 1.43 |  |
|  | Tax impact of IP restructuring | — |  |  | (0.05) |  |  | — |  |  | 0.17 |  |
|  | Share-based compensation expense | 0.26 |  |  | 0.20 |  |  | 1.01 |  |  | 0.79 |  |
|  | Amortization of acquired intangibles | 0.14 |  |  | 0.11 |  |  | 0.45 |  |  | 0.44 |  |
|  | Acquisition-related expenses | 0.06 |  |  | — |  |  | 0.13 |  |  | — |  |
|  | Severance-related and other expenses | 0.03 |  |  | 0.02 |  |  | 0.27 |  |  | 0.04 |  |
|  | Amortization of debt issuance costs | 0.02 |  |  | 0.01 |  |  | 0.04 |  |  | 0.05 |  |
|  | Amortization of discount on convertible senior notes | 0.10 |  |  | — |  |  | 0.11 |  |  | — |  |
|  | Tax effect of the adjustments above (b) | (0.07) |  |  | (0.03) |  |  | (0.21) |  |  | (0.11) |  |
| Non-GAAP net income per share - diluted | $ | 0.91 |  |  | $ | 0.77 |  |  | $ | 2.54 |  |  | $ | 2.81 |  |
| Reconciliation of GAAP net income to non-GAAP EBITDA (d): |  |  |  |  |  |
| GAAP net income | $ | 16,377 |  |  | $ | 22,095 |  |  | $ | 32,194 |  |  | $ | 61,338 |  |
|  | Share-based compensation expense | 11,663 |  |  | 8,874 |  |  | 44,697 |  |  | 34,049 |  |
|  | Interest (income) and expense, net | (82) |  |  | (587) |  |  | 360 |  |  | 1,378 |  |
|  | Depreciation and amortization expense | 17,164 |  |  | 14,034 |  |  | 61,067 |  |  | 53,559 |  |
|  | Acquisition-related expenses | 2,482 |  |  | — |  |  | 5,603 |  |  | — |  |
|  | Severance-related and other expenses (a) | 1,113 |  |  | 795 |  |  | 11,949 |  |  | 1,715 |  |
|  | Amortization of debt issuance costs | 843 |  |  | 486 |  |  | 1,597 |  |  | 2,205 |  |
|  | Amortization of discount on convertible senior notes | 4,517 |  |  | — |  |  | 4,766 |  |  | — |  |
|  | Income tax expense (benefit) | (2,501) |  |  | (125) |  |  | (2,845) |  |  | 12,595 |  |
| Non-GAAP EBITDA | $ | 51,576 |  |  | $ | 45,572 |  |  | $ | 159,388 |  |  | $ | 166,839 |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA % to total revenues) | 20.7% |  | 18.4% |  | 17.9% |  | 18.6% |

[0000926326-21-000004:8k_2_02:97]
_________________________________________________

[0000926326-21-000004:8k_2_02:98]
(a)For the three months ended December 31, 2020, other expenses included approximately $0.1 million of IP and legal entities restructuring costs, and $1.0 million of certain litigation costs. For the year ended December 31, 2020, other expenses included approximately $1.0 million of IP and legal entities restructuring costs, and $1.0 million of certain litigation costs. For the three months and year ended December 31, 2019, other expenses included approximately $0.8 million and $1.7 million of IP and legal entities restructuring costs, respectively.

[0000926326-21-000004:8k_2_02:99]
(b)Tax effects calculated for all adjustments except tax benefits and expenses, and share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2020 and 2019.

[0000926326-21-000004:8k_2_02:100]
(c)Non-GAAP diluted shares exclude the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction.

[0000926326-21-000004:8k_2_02:101]
(d)Defined as earnings before interest income and expense, taxes, depreciation, amortization, share-based compensation, as well as excluding certain non-GAAP adjustments.

[0000926326-21-000004:8k_2_02:102]
12

[0000926326-21-000004:8k_2_02:103]
Omnicell, Inc.

[0000926326-21-000004:8k_2_02:104]
Reconciliation of GAAP to Non-GAAP

[0000926326-21-000004:8k_2_02:105]
(Unaudited, in thousands)

[0000926326-21-000004:8k_2_02:106]
|  | Three Months Ended December 31, |  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Reconciliation of GAAP net cash provided by operating activities to non-GAAP free cash flow: |
| GAAP net cash provided by operating activities | $ | 76,448 |  |  | $ | 34,820 |  |  | $ | 185,870 |  |  | $ | 145,008 |  |
| Software development for external use | (6,115) |  |  | (11,641) |  |  | (32,024) |  |  | (45,770) |  |
| Purchases of property and equipment | (5,577) |  |  | (3,262) |  |  | (22,842) |  |  | (15,894) |  |
| Non-GAAP free cash flow | $ | 64,756 |  |  | $ | 19,917 |  |  | $ | 131,004 |  |  | $ | 83,344 |  |
