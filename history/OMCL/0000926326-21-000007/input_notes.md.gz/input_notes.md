# OMCL notes — 0000926326-21-000007


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000926326-21-000007:notes:1]
Portions of the registrant’s definitive Proxy Statement for the 2021 Annual Meeting of Stockholders to be filed with the United States Securities and Exchange Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Form 10-K are incorporated by reference in Part III, Items 10-14 of this Form 10-K.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-21-000007:notes:2]
Organization and Summary of Significant Accounting Policies
Business

[0000926326-21-000007:notes:3]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products are medication management automation solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.

[0000926326-21-000007:notes:4]
Basis of Presentation

[0000926326-21-000007:notes:5]
The accompanying Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and include all adjustments necessary for the fair presentation of the Company’s consolidated financial position, results of operations, and cash flows for the periods presented.

[0000926326-21-000007:notes:6]
Principles of Consolidation

[0000926326-21-000007:notes:7]
The Consolidated Financial Statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000926326-21-000007:notes:8]
On October 1, 2020, the Company completed its acquisition of the 340B Link business (the “340B Link Business”) of Pharmaceutical Strategies Group, LLC. The Consolidated Financial Statements include the results of operations of this recently acquired company, commencing as of the acquisition date. The significant accounting policies of the acquired business have been aligned to conform to the accounting policies of Omnicell.

[0000926326-21-000007:notes:9]
Reclassifications and Adjustments

[0000926326-21-000007:notes:10]
Certain prior-year amounts have been reclassified to conform with current-period presentation. These reclassifications include (i) a change in the presentation of certain items in the disaggregation of revenues for the years ended December 31, 2020, 2019, and 2018 in Note 3, Revenues, and (ii) a change in the presentation of certain items in the reconciliation of the provision for (benefit from) income taxes for the years ended December 31, 2019 and 2018 in Note 17, Income Taxes. These changes were not deemed material and were included to conform with current-period classification and presentation.

[0000926326-21-000007:notes:11]
Use of Estimates

[0000926326-21-000007:notes:12]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable, including any potential impacts from the COVID-19 pandemic. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. Those policies are revenue recognition; accounts receivable, unbilled receivables, and notes receivable from investment in sales-type leases; operating lease right-of-use assets and liabilities; inventory valuation; capitalized software development costs; impairment of goodwill; purchased intangibles and long-lived assets; fair value of assets acquired and liabilities assumed in business combinations; convertible senior notes; share-based compensation; and accounting for income taxes. As of December 31, 2020, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities. Given the ongoing uncertainty surrounding the COVID-19 pandemic, events or circumstances may arise that could result in a change in estimates, judgments, or revisions to the carrying value of the Company’s assets or liabilities.

[0000926326-21-000007:notes:13]
Segment Reporting

[0000926326-21-000007:notes:14]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.

[0000926326-21-000007:notes:15]
Foreign Currency Translation and Remeasurement

[0000926326-21-000007:notes:16]
Most of the Company’s foreign subsidiaries use the local currency of their respective countries as their functional currency. The Company translates the assets and liabilities of such non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recorded as foreign currency translation adjustments and included in accumulated other comprehensive income (loss) in stockholders’ equity.

[0000926326-21-000007:notes:17]
Assets and liabilities denominated in a currency other than the functional currency are remeasured into the respective entity’s functional currency. Monetary assets and liabilities are remeasured at exchange rates in effect at the end of each period, and non-monetary assets and liabilities are remeasured at historical rates. Gains and losses from foreign currency remeasurement of monetary assets and liabilities are recorded in interest and other income (expense), net.

[0000926326-21-000007:notes:18]
Revenue Recognition

[0000926326-21-000007:notes:19]
The Company earns revenues from sales of its products and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following revenue categories:

[0000926326-21-000007:notes:20]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements with multi-year co-development plans. Solutions in this category include, but are not limited to, XT Series automated dispensing systems, the XR2 Automated Central Pharmacy system, and IV compounding automation solutions.

[0000926326-21-000007:notes:21]
Technical services. Post-installation technical support and other related services, including phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.

[0000926326-21-000007:notes:22]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, and are designed to improve patient engagement and adherence to prescriptions.

[0000926326-21-000007:notes:23]
Software-as-a-service (“SaaS”), subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth (formerly Population Health Solutions), 340B solutions, and services associated with Omnicell One (formerly Performance Center), Central Pharmacy Compounding Services, including the XR2 Automated Central Pharmacy system, and Central Pharmacy Compounding Services, including IV compounding automation solutions.

[0000926326-21-000007:notes:24]
The following table summarizes revenue recognition for each revenue category which is further discussed below:

[0000926326-21-000007:notes:25]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| SaaS, subscription software, and technology-enabled services |  |  |  | Over time, as services are provided |  | Service |

[0000926326-21-000007:notes:26]
Prior to recognizing revenue, the Company identifies the contract, performance obligations, and transaction price, and allocates the transaction price to the performance obligations. All identified contracts meet the following required criteria:

[0000926326-21-000007:notes:27]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of the Company’s contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via phone or a purchase order.

[0000926326-21-000007:notes:28]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following the Company’s standard business process and terms.

[0000926326-21-000007:notes:29]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 to 60 days from shipment of tangible product or services performed for customers in the United States. Where a written contract does not exist, the Company’s standard payment terms are net 30 day terms.

[0000926326-21-000007:notes:30]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract). The Company’s agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.

[0000926326-21-000007:notes:31]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. The Company performs a credit check for all significant customers or transactions and where collectability is not probable, payment in full or a substantial down payment is typically required to help assure the full agreed upon contract price will be collected.

[0000926326-21-000007:notes:32]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, the Company combines the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify its performance obligations, the Company considers all of the products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, the Company considers an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of the Company’s sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, consumables and software products, support and maintenance, and professional services.

[0000926326-21-000007:notes:33]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of the Company’s commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

[0000926326-21-000007:notes:34]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated selling price.

[0000926326-21-000007:notes:35]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligations recorded as deferred revenues, net of deferred cost of goods sold, at December 31, 2020 and 2019 were $105.7 million and $98.0 million, respectively, of which $100.1 million and $90.9 million, respectively, are expected to be completed within one year and are presented as current deferred revenues, net on the Consolidated Balance Sheets. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-21-000007:notes:36]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

[0000926326-21-000007:notes:37]
The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements are generally periodic and are billed on a monthly, quarterly, or annual basis. In certain circumstances, multiple years are billed at one time.

[0000926326-21-000007:notes:38]
The amount invoiced for equipment and software is typically reflected in both accounts receivable and deferred revenues, net. The Company typically recognizes product revenue, and correspondingly reduces deferred revenues, net, for equipment and software upon written customer acceptance of installation. Consumables are recorded as revenue upon shipment to or receipt by the customer, depending upon contract terms. The portion of deferred revenues, net, not expected to be recognized as revenue within twelve months of the balance sheet date are included in long-term deferred revenues on the Consolidated Balance Sheets.

[0000926326-21-000007:notes:39]
The Company often enters into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. The Company’s change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

[0000926326-21-000007:notes:40]
In the normal course of business, the Company typically does not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. The Company establishes provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to the Consolidated Financial Statements for any periods presented.

[0000926326-21-000007:notes:41]
The Company contracts with Group Purchasing Organizations (“GPOs”), each of which functions as a purchasing agent on behalf of member hospitals and other healthcare providers. The Company also has a Federal Supply Schedule contract with the Department of Veterans Affairs (the "GSA Contract"), allowing the Department of Veterans Affairs, the Department of Defense, and other Federal government customers to purchase or lease the Company's products. Pursuant to the terms of GPO agreements and the GSA Contract, each member or agency contracts directly with Omnicell and can purchase the Company’s products at pre-negotiated contract terms and pricing. GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee ("IFF") to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $9.7 million, $11.1 million, and $8.7 million for the years ended December 31, 2020, 2019, and 2018, respectively. The accounts receivable balances are with individual members of the GPOs and Federal agencies that purchase under the GSA Contract, and therefore no significant concentration of credit risk exists. During the year ended December 31, 2020, sales to members of the ten largest GPOs and Federal agencies that purchase under the GSA Contract accounted for approximately 60% of total consolidated revenues.

[0000926326-21-000007:notes:42]
Contract Assets and Contract Liabilities

[0000926326-21-000007:notes:43]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts, and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

[0000926326-21-000007:notes:44]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenues in the normal course of business. As a result of the right to invoice for the transaction consideration becoming unconditional, unbilled contract assets as of December 31, 2019 which were invoiced during the year ended December 31, 2020 were not material. The contract modifications entered into during the year ended December 31, 2020 did not have a significant impact on the Company’s contract assets or deferred revenues.

[0000926326-21-000007:notes:45]
Contract Costs

[0000926326-21-000007:notes:46]
The Company has determined that certain incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are no commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract as part of a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. In accordance with U.S. GAAP, while certain compensation elements are expensed as incurred, a portion of the pool’s capitalized asset is recorded as an expense over the first two quarters after booking, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining capitalized contract costs are recorded as expense ratably over the ten year estimated initial and renewal service periods. The Company recognized contract cost expense of $22.1 million, $24.4 million, and $21.1 million during the years

[0000926326-21-000007:notes:47]
ended December 31, 2020, 2019, and 2018, respectively. The commission expenses paid or due to be paid as of the consolidated balance sheet date to be recognized in future periods are recorded in long-term prepaid commissions on the Consolidated Balance Sheets. There was no impairment loss recorded related to capitalized prepaid commissions as of and for the year ended December 31, 2020.

[0000926326-21-000007:notes:48]
Lessor Leases

[0000926326-21-000007:notes:49]
The Company determines if an arrangement is a lease at inception. The transaction price is allocated to separate performance obligations, generally consisting of hardware and software products, installation, and post-installation technical support, proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated selling price.

[0000926326-21-000007:notes:50]
Sales-Type Leases

[0000926326-21-000007:notes:51]
The Company enters into non-cancelable sales-type lease arrangements, most of which do not have an option to extend the lease term. At the end of the lease term, the customer must either return the equipment or negotiate a new agreement, resulting in a new purchase or lease transaction. Failure of the customer to either return the equipment or negotiate a new agreement results in the contract becoming a month-to-month rental. Certain sales-type leases automatically renew for successive one year periods at the end of each lease term with written notice from the customer. The Company’s sales-type lease agreements do not contain any material residual value guarantees.

[0000926326-21-000007:notes:52]
For sales-type leases, the Company recognizes revenues for its hardware and software products, net of lease execution costs, post-installation product maintenance, and technical support, at the net present value of the lease payment stream upon customer acceptance. The Company recognizes service revenues associated with sales-type leases ratably over the term of the agreement in service revenues in the Consolidated Statements of Operations. The Company recognizes interest income from sales-type leases using the effective interest method. Both hardware and software revenues, and interest income from sales-types leases are recorded in product revenues in the Consolidated Statements of Operations.

[0000926326-21-000007:notes:53]
The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 67% of the lease receivable balance, are retained in-house.

[0000926326-21-000007:notes:54]
Operating Leases

[0000926326-21-000007:notes:55]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of Accounting Standards Codification ("ASC") 842, Leases. Those agreements in place prior to January 1, 2019 continue to be treated as operating leases, however, any leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with ASC 842. The operating lease arrangements entered into prior to January 1, 2019 are non-cancelable, and most automatically renew for successive one year periods at the end of each lease term absent written notice from the customer. The Company’s operating lease agreements do not contain any material residual value guarantees.

[0000926326-21-000007:notes:56]
For operating leases, rental income is generally recognized on a straight-line basis over the term of the associated lease, and recorded in services and other revenues in the Consolidated Statements of Operations. Leased assets under operating leases are carried at amortized cost net of accumulated depreciation in property and equipment, net on the Consolidated Balance Sheets. The depreciation expense of the leased assets is recognized on a straight-line basis over the contractual term of the associated lease, and recorded in cost of revenues in the Consolidated Statements of Operations.

[0000926326-21-000007:notes:57]
Allowance for Credit Losses

[0000926326-21-000007:notes:58]
The Company is exposed to credit losses primarily through sales of its products and services, as well as its sales-type leasing arrangements. The Company performs credit evaluations of its customers’ financial condition in order to assess each customer’s ability to pay. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, and a financial review of the customer. The Company continues to monitor customers’ creditworthiness on an ongoing basis.

[0000926326-21-000007:notes:59]
The Company maintains an allowance for credit losses for accounts receivable, unbilled receivables, and net investment in sales-type leases based on expected credit losses resulting from the inability of its customers to make required payments. The allowance for credit losses is measured using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective

[0000926326-21-000007:notes:60]
(pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. Actual collection losses may differ from management’s estimates, and such differences could be material to the Company’s financial position and results of operations.

[0000926326-21-000007:notes:61]
The allowance for credit losses is presented in the Consolidated Balance Sheets as a deduction from the respective asset balance. The following table summarizes the Company’s allowance for credit losses by asset type:

[0000926326-21-000007:notes:62]
|  | December 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Allowance for credit losses: |  |  |  |
| Accounts receivable and unbilled receivables | $ | 4,286 |  |  | $ | 3,227 |  |
| Long-term unbilled receivables (1) | 30 |  |  | — |  |
| Net investment in sales-type leases (2) | 265 |  |  | 225 |  |

[0000926326-21-000007:notes:63]
_________________________________________________

[0000926326-21-000007:notes:64]
(1)    Included in other long-term assets in the Consolidated Balance Sheets.

[0000926326-21-000007:notes:65]
(2)    Includes both current and long-term portions presented in other current assets and long-term investment in sales-type leases, net, respectively.

[0000926326-21-000007:notes:66]
Funds Held for Customers and Customer Fund Liabilities

[0000926326-21-000007:notes:67]
With the acquisition of the 340B Link Business, the Company now offers certain products and services in which it is customary for pharmacies to owe funds to the Company which are collected on behalf of, and, after a short holding period, disbursed to, the Company’s customers. The Company presents amounts due from pharmacies and amounts due to be disbursed to customers on a gross basis within other current assets and accrued liabilities, respectively, in the Consolidated Balance Sheets, as such amounts are expected to be settled within one year. Any funds received from the pharmacies that are held by the Company are segregated from its other corporate cash accounts. These funds are classified as restricted cash as the Company is contractually obligated to disburse these amounts to customers.

[0000926326-21-000007:notes:68]
Sales of Accounts Receivable

[0000926326-21-000007:notes:69]
The Company records the sale of its accounts receivables in accordance with accounting guidance for transfers and servicing of financial assets. The Company transferred non-recourse accounts receivable totaling $58.8 million, $48.3 million, and $46.6 million during the years ended December 31, 2020, 2019, and 2018, respectively, which approximated fair value, to leasing companies on a non-recourse basis. Accounts receivable balance included approximately $7.8 million and $4.6 million due from third-party leasing companies for transferred non-recourse accounts receivable as of December 31, 2020 and 2019, respectively.

[0000926326-21-000007:notes:70]
Cash and Cash Equivalents

[0000926326-21-000007:notes:71]
The Company classifies all highly-liquid investments with original maturities of three months or less as cash equivalents. The Company’s cash and cash equivalent balances include bank accounts and highly-liquid U.S. Government money market funds held in sweep accounts with financial institutions of high credit quality. The Company continuously monitors the credit worthiness of the financial institutions in which it invests. The Company has not experienced any credit losses from its cash equivalents. Cash and cash equivalents were $485.9 million and $127.2 million as of December 31, 2020 and 2019, respectively. As of December 31, 2020, cash equivalents were $447.2 million, which consisted of money market funds held in sweep accounts, and as of December 31, 2019, the Company had no cash equivalents.

[0000926326-21-000007:notes:72]
Financial Instruments

[0000926326-21-000007:notes:73]
For assets and liabilities measured at fair value, the amounts are based on an expected exit price representing the amount that would be received from the sale of an asset or paid to transfer a liability in a transaction between market participants. The fair value may be based on assumptions that market participants would use in pricing an asset or liability. ASC 820, Fair Value Measurement, establishes a consistent framework for measuring fair value on either a recurring or nonrecurring basis whereby inputs used in valuation techniques are assigned a hierarchical level, as follows:

[0000926326-21-000007:notes:74]
Level 1 – Observable inputs, such as quoted prices in active markets for identical instruments;

[0000926326-21-000007:notes:75]
Level 2 – Quoted prices for similar instruments in active markets, or quoted prices for identical instruments in inactive markets; and

[0000926326-21-000007:notes:76]
Level 3 – Unobservable inputs for financial instruments reflecting Company’s assumptions.

[0000926326-21-000007:notes:77]
Interest Rate Swap Agreements

[0000926326-21-000007:notes:78]
The Company uses interest rate swap agreements to protect the Company against adverse fluctuations in interest rates by reducing its exposure to variability in cash flows relating to interest payments on a portion of its outstanding debt. The Company does not hold or issue any derivative financial instruments for speculative trading purposes.

[0000926326-21-000007:notes:79]
The Company's interest rate swap agreements qualify as cash flow hedging instruments in accordance with ASC 815, Derivatives and Hedging. The Company records its interest rate swap agreements on its Consolidated Balance Sheets at fair value. The effective portion of changes in fair value are recorded in accumulated other comprehensive loss and subsequently reclassified into earnings in the period that the hedged forecasted transaction affects earnings. Any ineffective portion is recognized in earnings. On a quarterly basis, the Company performs a qualitative assessment to determine effectiveness. For further information, refer to Note 5, Fair Value of Financial Instruments. As of December 31, 2020, the Company did not have any outstanding interest rate swap agreements.

[0000926326-21-000007:notes:80]
Inventory

[0000926326-21-000007:notes:81]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. Inbound shipping costs are included in cost of inventory. The Company regularly monitors inventory quantities on hand and records write-downs for excess and obsolete inventories based on the Company’s estimate of demand for its products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Shipments from suppliers or contract manufacturers before the Company receives them are recorded as in-transit inventory when title and the significant risks and rewards of ownership have passed to the Company.

[0000926326-21-000007:notes:82]
The Company has a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in its hardware products. There are no minimum purchase requirements. The contract with the Company’s supplier may be terminated by either the supplier or by the Company without cause and at any time upon delivery of six months’ notice. Purchases from this supplier were $76.3 million, $75.1 million, and $54.8 million for the years ended December 31, 2020, 2019, and 2018, respectively.

[0000926326-21-000007:notes:83]
Shipping Costs

[0000926326-21-000007:notes:84]
Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general, and administrative expense. Shipping and handling expenses were $15.6 million, $15.9 million, and $14.1 million for the years ended December 31, 2020, 2019, and 2018, respectively.

[0000926326-21-000007:notes:85]
Property and Equipment

[0000926326-21-000007:notes:86]
Property and equipment less accumulated depreciation are stated at historical cost. The Company’s expenditures for property and equipment are primarily for computer equipment and software used in the administration of its business, and for leasehold improvements to its leased facilities. The Company also develops molds and dies used in long-term manufacturing arrangements with suppliers and for production automation equipment used in the manufacturing of consumable blister card components. Depreciation and amortization is computed by use of the straight-line method over the estimated useful lives of the assets as stated below:

[0000926326-21-000007:notes:87]
| Computer equipment and related software | 3 - 5 years |
| Leasehold and building improvements | Shorter of the lease term or the estimated useful life |
| Furniture and fixtures | 5 - 7 years |
| Equipment | 2 - 12 years |

[0000926326-21-000007:notes:88]
The Company capitalizes costs related to computer software developed or obtained for internal use in accordance with ASC 350-40, Internal-Use Software. Software obtained for internal use includes enterprise-level business and finance software that the Company customizes to meet its specific operational needs, as well as certain costs for the development of its subscription and cloud-based offerings sold to its customers. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred. The Company capitalized $6.8 million and $0.3 million of

[0000926326-21-000007:notes:89]
costs related to the application development of enterprise-level software and its subscription and cloud-based offerings that were included in property and equipment during the years ended December 31, 2020 and 2019, respectively.

[0000926326-21-000007:notes:90]
Software Development Costs

[0000926326-21-000007:notes:91]
The Company capitalizes certain software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which those costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. The Company establishes technological feasibility when it completes a detail program design or a working model. The Company amortizes development costs over the estimated lives of the related products, which is generally five years. The Company capitalized software development costs of $32.0 million and $45.8 million, which are included in other long-term assets as of December 31, 2020 and 2019, respectively. The Company recorded $23.1 million, $17.5 million, and $12.5 million to cost of revenues for amortization of capitalized software development costs for the years ended December 31, 2020, 2019, and 2018, respectively. All development costs prior to the completion of a detail program design or a working model are recognized as research and development expense.

[0000926326-21-000007:notes:92]
Lessee Leases

[0000926326-21-000007:notes:93]
The Company determines if an arrangement is a lease at inception. Operating lease right-of-use assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. As most of its lease contracts do not provide an implicit rate, the Company uses its incremental borrowing rate based on information available at the commencement date in determining the present value of the lease payments. Lease expense is recognized on a straight-line basis over the lease term. The Company does not recognize a right-of-use asset and a lease liability for leases with an initial term of 12 months or less. The Company elected the practical expedient to not separate lease components from nonlease components and applied that practical expedient to all material classes of leased assets.

[0000926326-21-000007:notes:94]
Many of the Company’s operating leases include an option to extend the lease. The specific terms and conditions of the extension options vary from lease to lease, but are consistent with standard industry practices in each area that the Company operates. The Company reviews each of its lease options at a time required by the terms of the lease contract, and notifies the lessor if it chooses to exercise the lease renewal option. Until the Company is reasonably certain that it will extend the lease contract, the renewal option periods will not be recognized as right-of-use assets or lease liabilities.

[0000926326-21-000007:notes:95]
Certain leases include provisions for early termination, which allow the contract parties to terminate their obligations under the lease contract. The terms and conditions of the termination options vary by contract. When the Company has made a decision to exercise an early termination option, the right-of-use assets and associated lease liabilities are remeasured in accordance with the present value of the remaining cash flows under the lease contract.

[0000926326-21-000007:notes:96]
Certain building lease agreements include rental payments subject to change annually based on fluctuations in various indexes (i.e. Consumer Price Index (“CPI”), Retail Price Index, and other international indexes). Certain data center lease agreements include rental payments subject to change based on usage and CPI fluctuations. The changes based on usage and indexes are treated as variable lease costs and recognized in the period in which the obligation for those payments was incurred.

[0000926326-21-000007:notes:97]
The Company’s operating lease agreements do not contain any material residual value guarantees, restrictions, or restriction covenants.

[0000926326-21-000007:notes:98]
Business Combinations

[0000926326-21-000007:notes:99]
The Company uses the acquisition method of accounting under ASC 805, Business Combinations. Each acquired company’s operating results are included in the Company's Consolidated Financial Statements starting on the date of acquisition. The purchase price is equivalent to the fair value of consideration transferred. Tangible and identifiable intangible assets acquired and liabilities assumed as of the date of acquisition are recorded at the acquisition date fair value. Goodwill is recognized for the excess of purchase price over the net fair value of assets acquired and liabilities assumed.

[0000926326-21-000007:notes:100]
Amounts allocated to assets and liabilities are based upon fair values. Such valuations require management to make significant estimates and assumptions, especially with respect to the identifiable intangible assets. Management makes estimates of fair value based upon assumptions believed to be reasonable and that of a market participant. These estimates are based on historical experience and information obtained from the management of the acquired companies and the estimates are inherently uncertain. The separately identifiable intangible assets generally include customer relationships, acquired technology, backlog, trade names, and non-compete agreements.

[0000926326-21-000007:notes:101]
Goodwill and Acquired Intangible Assets

[0000926326-21-000007:notes:102]
Goodwill

[0000926326-21-000007:notes:103]
The Company reviews goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. This assessment is also performed whenever there is a change in circumstances that indicates the carrying value of goodwill may be impaired. The Company has one reporting unit, which is the same as its operating segment. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. A qualitative assessment includes, among others, consideration of: (i) past, current, and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this qualitative assessment indicates that it is more likely than not that impairment exists, or if the Company decides to bypass this option, it proceeds to the quantitative assessment. The quantitative assessment involves a comparison between the estimated fair value of the Company’s reporting unit with its carrying amount including goodwill. If the carrying value exceeds estimated fair value, the Company will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill.

[0000926326-21-000007:notes:104]
To determine the reporting unit’s fair value under the quantitative approach, the Company uses a combination of income and market approaches, equally weighting the two approaches, such as estimated discounted future cash flows of the reporting unit, multiples of earnings or revenues, and analysis of recent sales or offerings of comparable entities. The Company also considers its market capitalization on the date of the analysis to ensure the reasonableness of its reporting unit's fair value.

[0000926326-21-000007:notes:105]
The Company performed a qualitative impairment assessment analysis as of October 1, 2020 for its reporting unit taking into consideration past, current, and projected future earnings, recent trends, and market conditions, and valuation metrics involving similar companies that are publicly-traded. Based on the result of this analysis, an impairment does not exist as of December 31, 2020, and there were no accumulated impairment losses.

[0000926326-21-000007:notes:106]
Intangible Assets

[0000926326-21-000007:notes:107]
In connection with its acquisitions, the Company generally recognizes assets for customer relationships, acquired technology, backlog, trade names, and non-compete agreements. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets, generally from one to 30 years. Amortization for acquired technology and backlog is recognized in cost of revenues, and amortization for customer relationships, trade names, non-compete agreements, and patents is recognized in selling, general, and administrative expenses.

[0000926326-21-000007:notes:108]
The Company assesses the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset’s carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. The Company’s cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of the Company’s intangible assets are subjective and are affected by changes to its business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of the Company’s assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company’s operating results and financial condition. For the years ended December 31, 2020 and 2019, there were no events or changes in circumstances to indicate that intangible assets carrying amounts may not be recoverable.

[0000926326-21-000007:notes:109]
Convertible Debt

[0000926326-21-000007:notes:110]
The Company accounts for convertible debt and related transactions in accordance with ASC 470-20, Debt with Conversion and Other Options, ASC 815, Derivatives and Hedging, and ASC 480, Distinguishing Liabilities from Equity. The Company evaluates convertible debt instruments and related transactions at inception to determine if those contracts or embedded components of those contracts qualify as derivatives to be separately accounted for. Convertible debt instruments that may be settled in cash are separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. The difference between the principal amount of the convertible debt instruments and the liability component, inclusive of issuance costs, represents the debt discount, which is amortized to interest expense over the term of instruments. The determination of the discount rate requires certain estimates and assumptions.

[0000926326-21-000007:notes:111]
Convertible note hedge and warrant transactions associated with convertible debt instruments are accounted for as equity instruments, and are recorded in additional paid-in capital in the Consolidated Balance Sheets.

[0000926326-21-000007:notes:112]
Valuation of Share-Based Compensation

[0000926326-21-000007:notes:113]
The Company accounts for share-based compensation in accordance with ASC 718, Stock Compensation. The Company recognizes compensation expense related to share-based compensation based on the grant date estimated fair value.

[0000926326-21-000007:notes:114]
The fair value of stock options (“options”) on the grant date is estimated using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of its common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on the Company’s historical experience of employee stock option exercises, including forfeitures. Expense is recognized on a straight-line basis over the requisite service period.

[0000926326-21-000007:notes:115]
The fair value of restricted stock units (“RSUs”) is based on the stock price on the grant date. The fair value of restricted stock awards (“RSAs”) is their intrinsic value, which is the difference between the fair value of the underlying stock at the measurement date and the purchase price. The RSUs and RSAs are subject to a service vesting condition and are recognized on a straight-line basis over the requisite service period.

[0000926326-21-000007:notes:116]
The fair value of performance-based stock unit awards (“PSUs”) with service and market conditions is estimated using a Monte Carlo simulation model applying multiple awards approach. Expense is recognized when it is probable that the performance condition will be met using the accelerated attribution method over the requisite service period.

[0000926326-21-000007:notes:117]
Forfeiture rates are estimated based on the Company's historical experience with equity awards that were granted and forfeited prior to vesting. The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods.

[0000926326-21-000007:notes:118]
Accounting for Income Taxes

[0000926326-21-000007:notes:119]
The Company records an income tax provision for (benefit from) the anticipated tax consequences of the reported results of operations. In accordance with ASC 740, Income Taxes, the provision for (benefit from) income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, the Company will incur a benefit or detriment on its income tax expense in the period of change. If the Company were to determine that all or part of the net deferred tax assets are not realizable in the future, it will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-21-000007:notes:120]
In accordance with ASC 740, the Company recognizes the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of ASC 740 and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0000926326-21-000007:notes:121]
Recently Adopted Authoritative Guidance

[0000926326-21-000007:notes:122]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). The Company adopted ASU 2018-15 on January 1, 2020 on a prospective basis. The adoption of this guidance did not have a material impact on the Company’s Consolidated Financial Statements.

[0000926326-21-000007:notes:123]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans, and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans, and held-to-maturity debt securities, the standard replaced the current “incurred loss” approach with an

[0000926326-21-000007:notes:124]
“expected loss” model. Entities are required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. The Company adopted the new standard on January 1, 2020 using the modified retrospective transition method, which resulted in the recognition of an immaterial cumulative-effect adjustment to retained earnings.

[0000926326-21-000007:notes:125]
Recently Issued Authoritative Guidance

[0000926326-21-000007:notes:126]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740) Simplifying the Accounting for Income Taxes. The update simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740, as well as improves consistent application of and simplifies the guidance for other areas of ASC 740 by clarifying and amending existing guidance. ASU 2019-12 will be effective for the Company beginning January 1, 2021. The Company does not expect ASU 2019-12 to have a material impact on its Consolidated Financial Statements.

[0000926326-21-000007:notes:127]
In August 2020, the FASB issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. This update permits the use of either the modified retrospective or fully retrospective method of transition. ASU 2020-06 will be effective for the Company beginning January 1, 2022. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. The Company is currently evaluating the impact ASU 2020-06 will have on its Consolidated Financial Statements.

[0000926326-21-000007:notes:128]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Consolidated Financial Statements through the reporting date.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000926326-21-000007:notes:129]
Contract Costs
The Company has determined that certain incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are no commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract as part of a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. In accordance with U.S. GAAP, while certain compensation elements are expensed as incurred, a portion of the pool’s capitalized asset is recorded as an expense over the first two quarters after booking, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining capitalized contract costs are recorded as expense ratably over the ten year estimated initial and renewal service periodsShipping CostsOutbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general, and administrative expense.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000926326-21-000007:notes:130]
Depreciation and amortization is computed by use of the straight-line method over the estimated useful lives of the assets as stated below:

[0000926326-21-000007:notes:131]
The following table represents the property and equipment balances as of December 31, 2020 and 2019:

[0000926326-21-000007:notes:132]
|  | December 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Equipment | $ | 81,034 |  |  | $ | 88,569 |  |
| Furniture and fixtures | 7,498 |  |  | 7,925 |  |
| Leasehold improvements | 19,517 |  |  | 18,979 |  |
| Software | 50,230 |  |  | 48,309 |  |
| Construction in progress | 7,095 |  |  | 6,179 |  |
| Property and equipment, gross (1) | 165,374 |  |  | 169,961 |  |
| Accumulated depreciation and amortization (1) | (106,301) |  |  | (115,715) |  |
| Total property and equipment, net | $ | 59,073 |  |  | $ | 54,246 |  |

[0000926326-21-000007:notes:133]
(1)     The change in balances between periods is primarily due to the disposal of certain fully depreciated property and equipment, partially offset by additions, and depreciation and amortization.
The following table summarizes the geographic information for property and equipment, net, as of December 31, 2020 and 2019:

[0000926326-21-000007:notes:134]
|  | December 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| United States | $ | 53,203 |  |  | $ | 48,769 |  |
| Rest of world (1) | 5,870 |  |  | 5,477 |  |
| Total property and equipment, net | $ | 59,073 |  |  | $ | 54,246 |  |

[0000926326-21-000007:notes:135]
(1)    No individual country represented more than 10% of the total property and equipment, net.


## us-gaap:DebtPolicyTextBlock

[0000926326-21-000007:notes:136]
The Company accounts for convertible debt and related transactions in accordance with ASC 470-20, Debt with Conversion and Other Options, ASC 815, Derivatives and Hedging, and ASC 480, Distinguishing Liabilities from Equity. The Company evaluates convertible debt instruments and related transactions at inception to determine if those contracts or embedded components of those contracts qualify as derivatives to be separately accounted for. Convertible debt instruments that may be settled in cash are separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. The difference between the principal amount of the convertible debt instruments and the liability component, inclusive of issuance costs, represents the debt discount, which is amortized to interest expense over the term of instruments. The determination of the discount rate requires certain estimates and assumptions.
Convertible note hedge and warrant transactions associated with convertible debt instruments are accounted for as equity instruments, and are recorded in additional paid-in capital in the Consolidated Balance SheetThe refinancing of the Prior Credit Agreement was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the A&R Credit Agreement.Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-21-000007:notes:137]
Business Combinations
340B Link Business Acquisition

[0000926326-21-000007:notes:138]
On October 1, 2020, the Company completed the acquisition of all of the outstanding equity of the 340B Link Business pursuant to the terms and conditions of the Equity Purchase Agreement, dated August 11, 2020, as amended, by and among the Company, PSGH, LLC, BW Apothecary Holdings, LLC, the sellers identified therein and the sellers’ representative for total cash consideration of $225.0 million. The 340B Link Business acquisition adds a comprehensive and differentiated suite of software-enabled services and solutions used by certain eligible hospitals, health systems, clinics, and entities to manage compliance and capture 340B drug cost savings on outpatient prescriptions filled through the eligible entity’s pharmacy or a contracted pharmacy partner. The results of the 340B Link Business' operations have been included in the Company's consolidated results of operations, commencing as of the acquisition date.

[0000926326-21-000007:notes:139]
The Company accounted for the acquisition of the 340B Link Business in accordance with ASC 805. The tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition date. The preliminary fair values assume management's best estimates based on information available at the acquisition date and may change over the measurement period, which will end no later than one year form the acquisition date, as additional information is received. The following table represents the preliminary allocation of the purchase price to the assets acquired and the liabilities assumed by the Company as part of the acquisition reconciled to the purchase price transferred included in the Company's Consolidated Balance Sheets:

[0000926326-21-000007:notes:140]
|  | 340B Link Business(Preliminary) |
|  | (In thousands) |
| Accounts receivable and unbilled receivables | $ | 8,197 |  |
| Prepaid expenses | 232 |  |
| Other current assets | 22,747 |  |
| Total current assets | 31,176 |  |
| Property and equipment | 531 |  |
| Operating lease right-of-use assets | 3,138 |  |
| Goodwill | 161,117 |  |
| Intangible assets | 62,800 |  |
| Total assets | 258,762 |  |
| Accounts payable | 568 |  |
| Accrued liabilities | 23,787 |  |
| Long-term deferred tax liabilities | 6,818 |  |
| Long-term operating lease liabilities | 2,589 |  |
| Total liabilities | 33,762 |  |
| Total purchase price | $ | 225,000 |  |

[0000926326-21-000007:notes:141]
The $161.1 million of goodwill arising from the 340B Link Business acquisition is primarily attributed to sales of future software-enabled services and solutions and the 340B Link Business’ assembled workforce. Goodwill that is expected to be deductible for tax purposes is approximately $93.9 million.

[0000926326-21-000007:notes:142]
Intangible assets eligible for recognition separate from goodwill were those that satisfied either the contractual/legal criterion or the separability criterion in the accounting guidance. The identifiable intangible assets acquired and their estimated useful lives for amortization are as follows:

[0000926326-21-000007:notes:143]
|  | 304B Link Business |
|  | Fair value |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 53,000 |  |  | 21 |
| Acquired technology | 9,000 |  |  | 5 |
| Trade names | 200 |  |  | 1 |
| Non-compete agreements | 600 |  |  | 3 |
| Total purchased intangible assets | $ | 62,800 |  |  |  |

[0000926326-21-000007:notes:144]
The customer relationships intangible asset represents the fair value of the underlying relationships and agreements with the 340B Link Business’ customers. The acquired technology intangible asset represents the fair value of the 340B Link Business' portfolio of software and solutions that have reached technological feasibility and were part of the 340B Link Business’ offerings at the date of acquisition. The trade names intangible asset represents the fair value of brand and name recognition associated with the marketing of the 340B Link Business' software-enabled services and solutions. The non-compete agreements intangible asset represents the fair value of non-compete agreements with former key members of the 340B Link Business' management.

[0000926326-21-000007:notes:145]
The fair value of the customer relationships intangible asset was determined based on the excess earnings method; the fair values of the acquired technology and trade names intangible assets were determined based on the relief-from-royalty

[0000926326-21-000007:notes:146]
method; and the fair value of the non-compete agreements intangible asset was determined based on the lost profits method. The key assumptions used in estimating the fair values of intangible assets included forecasted financial information; customer attrition rates; royalty rates of 10.0% and 0.5% for the acquired technology and trade names intangible assets, respectively; discount rate of 14.0% for all intangible assets; and certain other assumptions.

[0000926326-21-000007:notes:147]
The customer relationships and acquired technology intangible assets are being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. The trade names and non-compete agreements are being amortized over their estimated useful lives using the straight-line method of amortization.

[0000926326-21-000007:notes:148]
The Company believes that the fair value assigned to the assets acquired and liabilities assumed are based on reasonable assumptions and estimates that market participants would use. Actual results may differ from these estimates and assumptions.

[0000926326-21-000007:notes:149]
The Company incurred approximately $6.5 million in acquisition-related costs related to the 340B Link Business acquisition during the year ended December 31, 2020. These costs were expensed as incurred, and are included in selling, general, and administrative expenses in the Company's Consolidated Statements of Operations.

[0000926326-21-000007:notes:150]
Revenues and earnings from the 340B Link Business operations since the acquisition date through December 31, 2020 were $10.2 million and $1.3 million, respectively.

[0000926326-21-000007:notes:151]
Pro Forma Financial Information

[0000926326-21-000007:notes:152]
The following table presents certain unaudited pro forma information for illustrative purposes only, for the years ended December 31, 2020 and 2019 as if this acquisition had been completed on January 1, 2019. The pro forma information is not indicative of what would have occurred had the acquisition taken place on January 1, 2019. The unaudited pro forma information combines the historical results of the acquisition with the Company’s consolidated historical results and includes certain adjustments including, but not limited to, amortization and depreciation of intangible assets and property and equipment acquired; imputed interest, interest expense, and amortization of debt issuance costs for the indebtedness incurred to complete the acquisition; and acquisition-related costs incurred.

[0000926326-21-000007:notes:153]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |
|  | (In thousands, except per share data) |
| Pro forma revenues | $ | 920,314 |  |  | $ | 929,106 |  |
| Pro forma net income | $ | 37,559 |  |  | $ | 56,897 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-21-000007:notes:154]
Revenues
Disaggregation of Revenues

[0000926326-21-000007:notes:155]
The following table summarizes the Company’s revenues disaggregated by revenue type for the years ended December 31, 2020, 2019, and 2018:

[0000926326-21-000007:notes:156]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 560,368 |  |  | $ | 573,844 |  |  | $ | 483,414 |  |
| Technical services | 202,383 |  |  | 194,183 |  |  | 183,202 |  |
| Consumables | 75,663 |  |  | 85,758 |  |  | 86,182 |  |
| SaaS, subscription software, and technology-enabled services | 53,794 |  |  | 43,242 |  |  | 34,511 |  |
| Total revenues | $ | 892,208 |  |  | $ | 897,027 |  |  | $ | 787,309 |  |

[0000926326-21-000007:notes:157]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the years ended December 31, 2020, 2019, and 2018:

[0000926326-21-000007:notes:158]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| United States | $ | 797,602 |  | $ | 806,900 |  | $ | 685,881 |
| Rest of world (1) | 94,606 |  | 90,127 |  | 101,428 |
| Total revenues | $ | 892,208 |  | $ | 897,027 |  | $ | 787,309 |

[0000926326-21-000007:notes:159]
(1)    No individual country represented more than 10% of total revenues.

[0000926326-21-000007:notes:160]
The following table reflects the Company’s contract assets and contract liabilities:

[0000926326-21-000007:notes:161]
|  | December 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 13,895 |  |  | $ | 11,707 |  |
| Long-term unbilled receivables, net (2) | 17,205 |  |  | 12,260 |  |
| Total contract assets | $ | 31,100 |  |  | $ | 23,967 |  |
| Short-term deferred revenues, net | $ | 100,053 |  |  | $ | 90,894 |  |
| Long-term deferred revenues | 5,673 |  |  | 7,083 |  |
| Total contract liabilities | $ | 105,726 |  |  | $ | 97,977 |  |

[0000926326-21-000007:notes:162]
(1)     Included in accounts receivable and unbilled receivables in the Consolidated Balance Sheets.

[0000926326-21-000007:notes:163]
(2)    Included in other long-term assets in the Consolidated Balance Sheets.

[0000926326-21-000007:notes:164]
Short-term deferred revenues of $100.1 million and $90.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $21.0 million and $13.1 million, as of December 31, 2020 and 2019, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the year ended December 31, 2020, the Company recognized revenues of $84.0 million that were included in the corresponding gross short-term deferred revenue balance of $104.0 million as of December 31, 2019.

[0000926326-21-000007:notes:165]
Long-term deferred revenues include deferred revenues from service contracts of $5.7 million and $7.1 million as of December 31, 2020 and 2019, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-21-000007:notes:166]
Significant Customers

[0000926326-21-000007:notes:167]
There were no customers that accounted for more than 10% of the Company’s total revenues for the years ended December 31, 2020, 2019, and 2018. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of December 31, 2020 and 2019.


## us-gaap:EarningsPerShareTextBlock

[0000926326-21-000007:notes:168]
Net Income Per ShareBasic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period, using the treasury stock method. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units, as well as shares the Company could be obligated to issue from its convertible senior notes and warrants, as described in Note 10, Convertible Senior Notes. Any anti-dilutive weighted-average dilutive shares related to stock award plans, convertible senior notes, and warrants are excluded from the computation of the diluted net income per share.
The basic and diluted net income per share calculations for the years ended December 31, 2020, 2019, and 2018 were as follows:

[0000926326-21-000007:notes:169]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands, except per share data) |
| Net income | $ | 32,194 |  |  | $ | 61,338 |  |  | $ | 37,729 |  |
| Weighted-average shares outstanding - basic | 42,583 |  |  | 41,462 |  |  | 39,242 |  |
| Effect of dilutive securities from stock award plans | 1,160 |  |  | 1,481 |  |  | 1,317 |  |
| Effect of convertible senior notes and warrants | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 43,743 |  |  | 42,943 |  |  | 40,559 |  |
| Net income per share - basic | $ | 0.76 |  |  | $ | 1.48 |  |  | $ | 0.96 |  |
| Net income per share - diluted | $ | 0.74 |  |  | $ | 1.43 |  |  | $ | 0.93 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 2,054 |  |  | 926 |  |  | 1,279 |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | 11,816 |  |  | — |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-21-000007:notes:170]
Fair Value of Financial Instruments
Fair Value Hierarchy

[0000926326-21-000007:notes:171]
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's interest rate swap contracts and credit facilities are classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company's convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. As of December 31, 2020, the fair value of the convertible senior notes was $782.3 million, compared to their carrying value of $467.2 million, which is net of unamortized discount and debt issuance costs and excludes amounts classified within additional paid-in capital. Refer to Note 9, Debt and Credit Agreements, for further information regarding the Company’s credit facilities and Note 10, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.

[0000926326-21-000007:notes:172]
Interest Rate Swap Contracts

[0000926326-21-000007:notes:173]
During 2016, the Company entered into an interest rate swap agreement with a combined notional amount of $100.0 million with one counterparty that became effective on June 30, 2016 and matured on April 30, 2019. The swap agreement required the Company to pay a fixed rate of 0.8% and provided that the Company receive a variable rate based on the one month LIBOR rate subject to a LIBOR floor of 0.0%. Amounts payable by or due to the Company were net settled with the respective counterparty on the last business day of each month, commencing July 31, 2016. The Company’s interest rate swap agreement matured during the second quarter of 2019, and, as of December 31, 2020, the Company did not have any outstanding interest rate swap agreements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-21-000007:notes:174]
Balance Sheet Components
Balance sheet details as of December 31, 2020 and 2019 are presented in the tables below:

[0000926326-21-000007:notes:175]
|  | December 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 28,205 |  |  | $ | 31,331 |  |
| Work in process | 7,973 |  |  | 7,620 |  |
| Finished goods | 60,120 |  |  | 69,060 |  |
| Total inventories | $ | 96,298 |  |  | $ | 108,011 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 18,164 |  |  | $ | — |  |
| Net investment in sales-type leases, current portion | 10,246 |  |  | 9,770 |  |
| Prepaid income taxes | 10,095 |  |  | 4,347 |  |
| Other current assets | 2,539 |  |  | 1,060 |  |
| Total other current assets | $ | 41,044 |  |  | $ | 15,177 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net | $ | 94,027 |  |  | $ | 85,070 |  |
| Unbilled receivables, net | 17,205 |  |  | 12,260 |  |
| Deferred debt issuance costs | 4,253 |  |  | 4,700 |  |
| Other long-term assets | 3,804 |  |  | 1,006 |  |
| Total other long-term assets | $ | 119,289 |  |  | $ | 103,036 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 12,197 |  |  | $ | 10,058 |  |
| Customer fund liabilities | 18,164 |  |  | — |  |
| Advance payments from customers | 6,981 |  |  | 4,006 |  |
| Rebates and lease buyouts | 21,815 |  |  | 14,911 |  |
| Group purchasing organization fees | 4,412 |  |  | 5,934 |  |
| Taxes payable | 3,520 |  |  | 3,744 |  |
| Other accrued liabilities | 13,222 |  |  | 16,914 |  |
| Total accrued liabilities | $ | 80,311 |  |  | $ | 55,567 |  |

[0000926326-21-000007:notes:176]
(1)    Includes $4.0 million of restricted cash.

[0000926326-21-000007:notes:177]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the years ended December 31, 2020 and 2019:

[0000926326-21-000007:notes:178]
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  |
|  | (In thousands) |  |
| Balance as of December 31, 2018 | $ | (11,274) |  |  | $ | 420 |  |  | $ | (10,854) |  |  |
| Other comprehensive income (loss) before reclassifications | 1,828 |  |  | 148 |  |  | 1,976 |  |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (568) |  |  | (568) |  |  |
| Net current-period other comprehensive income (loss), net of tax | 1,828 |  |  | (420) |  |  | 1,408 |  |  |
| Balance as of December 31, 2019 | (9,446) |  |  | — |  |  | (9,446) |  |  |
| Other comprehensive income (loss) before reclassifications | 3,924 |  |  | — |  |  | 3,924 |  |  |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | — |  |  | — |  |  |
| Net current-period other comprehensive income (loss), net of tax | 3,924 |  |  | — |  |  | 3,924 |  |  |
| Balance as of December 31, 2020 | $ | (5,522) |  |  | $ | — |  |  | $ | (5,522) |  |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-21-000007:notes:179]
Property and Equipment
The following table represents the property and equipment balances as of December 31, 2020 and 2019:

[0000926326-21-000007:notes:180]
(1)     The change in balances between periods is primarily due to the disposal of certain fully depreciated property and equipment, partially offset by additions, and depreciation and amortization.

[0000926326-21-000007:notes:181]
Depreciation and amortization expense of property and equipment was $18.3 million, $17.2 million, and $15.1 million for the years ended December 31, 2020, 2019, and 2018, respectively.

[0000926326-21-000007:notes:182]
The geographic location of the Company's property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of December 31, 2020 and 2019:


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-21-000007:notes:183]
Goodwill and Intangible Assets
Goodwill

[0000926326-21-000007:notes:184]
The following table represents changes in the carrying amount of goodwill:

[0000926326-21-000007:notes:185]
|  |  |  |  |  | (In thousands) |
| Balance as of December 31, 2018 |  |  |  |  | $ | 335,887 |  |
| Additions |  |  |  |  | — |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | 652 |  |
| Balance as of December 31, 2019 |  |  |  |  | 336,539 |  |
| Additions (1) |  |  |  |  | 161,117 |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | 1,653 |  |
| Balance as of December 31, 2020 |  |  |  |  | $ | 499,309 |  |

[0000926326-21-000007:notes:186]
(1)     Additions represent the preliminary value assigned to goodwill in connection with the 340B Link Business acquisition in October 2020.

[0000926326-21-000007:notes:187]
Intangible Assets, Net

[0000926326-21-000007:notes:188]
The carrying amounts and useful lives of intangible assets as of December 31, 2020 and 2019 were as follows:

[0000926326-21-000007:notes:189]
|  | December 31, 2020 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 187,889 |  |  | $ | (64,254) |  |  | $ | (777) |  |  | $ | 122,858 |  |  | 10 - 30 |
| Acquired technology | 86,029 |  |  | (44,851) |  |  | 6 |  |  | 41,184 |  |  | 3 - 20 |
| Backlog | 1,150 |  |  | (1,078) |  |  | — |  |  | 72 |  |  | 4 |
| Trade names | 7,850 |  |  | (5,794) |  |  | 14 |  |  | 2,070 |  |  | 1 - 12 |
| Patents | 2,930 |  |  | (1,455) |  |  | 2 |  |  | 1,477 |  |  | 2 - 20 |
| Non-compete agreements | 600 |  |  | (50) |  |  | — |  |  | 550 |  |  | 3 |
| Total intangibles assets, net | $ | 286,448 |  |  | $ | (117,482) |  |  | $ | (755) |  |  | $ | 168,211 |  |  |  |

[0000926326-21-000007:notes:190]
|  | December 31, 2019 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 135,234 |  |  | $ | (54,860) |  |  | $ | (1,058) |  |  | $ | 79,316 |  |  | 10 - 30 |
| Acquired technology | 77,142 |  |  | (36,194) |  |  | 5 |  |  | 40,953 |  |  | 3 - 20 |
| Backlog | 1,150 |  |  | (791) |  |  | — |  |  | 359 |  |  | 4 |
| Trade names | 7,650 |  |  | (5,037) |  |  | 11 |  |  | 2,624 |  |  | 6 - 12 |
| Patents | 3,217 |  |  | (1,603) |  |  | 1 |  |  | 1,615 |  |  | 2 - 20 |
| Total intangibles assets, net | $ | 224,393 |  |  | $ | (98,485) |  |  | $ | (1,041) |  |  | $ | 124,867 |  |  |  |

[0000926326-21-000007:notes:191]
(1)     The differences in gross carrying amounts between periods are primarily due to additions of intangible assets in connection with the 340B Link Business acquisition, partially offset by the write-off of certain fully amortized intangible assets.

[0000926326-21-000007:notes:192]
Amortization expense of intangible assets was $19.7 million, $18.9 million, and $23.8 million for the years ended December 31, 2020, 2019, and 2018, respectively.

[0000926326-21-000007:notes:193]
The estimated future amortization expenses for amortizable intangible assets were as follows:

[0000926326-21-000007:notes:194]
|  | December 31,2020 |
|  | (In thousands) |
| 2021 | $ | 23,948 |  |
| 2022 | 21,134 |  |
| 2023 | 19,113 |  |
| 2024 | 12,825 |  |
| 2025 | 11,616 |  |
| Thereafter | 79,575 |  |
| Total | $ | 168,211 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-21-000007:notes:195]
Debt and Credit Agreements 
2016 Senior Credit Facility

[0000926326-21-000007:notes:196]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Prior Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Prior Term Loan Facility” and, together with the Prior Revolving Credit Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Prior Credit Agreement had an expiration date of January 5, 2021, upon which date all remaining outstanding borrowings were due and payable.

[0000926326-21-000007:notes:197]
Loans under the Prior Facilities bore interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Prior Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Prior Credit Agreement). Undrawn commitments under the Prior Revolving Credit Facility were subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s consolidated total net leverage ratio on the average daily unused portion of the Prior Revolving Credit Facility.

[0000926326-21-000007:notes:198]
On each of April 11, 2017 and December 26, 2017, the parties entered into amendments to the Prior Credit Agreement. Under these amendments, the Prior Revolving Credit Facility was increased from $200.0 million to $315.0 million and certain other modifications were made. In connection with the December 2017 amendment, the Company incurred and capitalized an additional $2.1 million of debt issuance costs.

[0000926326-21-000007:notes:199]
2019 Revolving Credit Facility

[0000926326-21-000007:notes:200]
On November 15, 2019, the Company refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-21-000007:notes:201]
On November 15, 2019, the $80.0 million outstanding term loan balance under the Prior Facilities was transferred to the Current Revolving Credit Facility.

[0000926326-21-000007:notes:202]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the

[0000926326-21-000007:notes:203]
prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. The applicable margin for and certain other terms of any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

[0000926326-21-000007:notes:204]
On September 22, 2020, the parties entered into an amendment (the “Amendment”) to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

[0000926326-21-000007:notes:205]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total net leverage ratio and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of December 31, 2020.

[0000926326-21-000007:notes:206]
The refinancing of the Prior Credit Agreement was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the A&R Credit Agreement.

[0000926326-21-000007:notes:207]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. In connection with the Amendment on September 22, 2020, the Company incurred and capitalized an additional $0.6 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs was approximately $1.0 million, $2.2 million, and $2.3 million for the years ended December 31, 2020, 2019, and 2018, respectively.

[0000926326-21-000007:notes:208]
Interest expense (exclusive of fees and debt issuance cost amortization) was approximately $0.5 million, $3.6 million, and $7.5 million for the years ended December 31, 2020, 2019, and 2018, respectively.

[0000926326-21-000007:notes:209]
The following table represents changes in the carrying amount of the Company's debt obligations:

[0000926326-21-000007:notes:210]
|  |  |  | Current Revolving Credit Facility |  |  |
|  |  |  | (In thousands) |
| Balance as of December 31, 2019 |  |  | $ | 50,000 |  |  |  |
| Proceeds |  |  | 150,000 |  |  |  |
| Repayments |  |  | (200,000) |  |  |  |
| Balance as of December 31, 2020 |  |  | $ | — |  |  |  |

[0000926326-21-000007:notes:211]
The following table represents changes in the balance of the Company's deferred debt issuance costs:

[0000926326-21-000007:notes:212]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | 550 |  |
| Amortization | (997) |  |
| Balance as of December 31, 2020 | $ | 4,253 |  |

[0000926326-21-000007:notes:213]
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-21-000007:notes:214]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

[0000926326-21-000007:notes:215]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

[0000926326-21-000007:notes:216]
Upon conversion, the Company may satisfy its conversion obligation by paying or delivering, as the case may be, cash, shares of its common stock, or a combination of cash and shares of its common stock, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

[0000926326-21-000007:notes:217]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of December 31, 2020, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-21-000007:notes:218]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all the outstanding Notes, at least $150.0 million aggregate

[0000926326-21-000007:notes:219]
principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

[0000926326-21-000007:notes:220]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represents the debt discount, which the Company will amortize to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions. As of December 31, 2020, the remaining life of the Notes and the related debt discount and issuance cost accretion is approximately 4.7 years.

[0000926326-21-000007:notes:221]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 8.1 million shares.

[0000926326-21-000007:notes:222]
The Notes consisted of the following balances reported in the Consolidated Balance Sheets as of December 31, 2020:

[0000926326-21-000007:notes:223]
|  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |
| Principal amount | $ | 575,000 |  |
| Unamortized discount | (95,744) |  |
| Unamortized debt issuance costs | (12,055) |  |
| Convertible senior notes, liability component | $ | 467,201 |  |
| Equity: |  |
| Embedded conversion option | $ | 100,510 |  |
| Debt issuance costs | (2,680) |  |
| Deferred tax impact | (25,098) |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |

[0000926326-21-000007:notes:224]
(1)    Included in additional paid-in capital in the Consolidated Balance Sheets.

[0000926326-21-000007:notes:225]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Consolidated Statements of Operations for the year ended December 31, 2020:

[0000926326-21-000007:notes:226]
|  | Year EndedDecember 31, 2020 |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 379 |  |  |  |  |  |  |  |
| Amortization of discount | $ | 4,766 |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 600 |  |  |  |  |  |  |  |

[0000926326-21-000007:notes:227]
Convertible Note Hedge and Warrant Transactions

[0000926326-21-000007:notes:228]
In connection with the issuance of the Notes, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

[0000926326-21-000007:notes:229]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The 
convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid in capital at issuance in the Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-21-000007:notes:230]
Lessor Leases
Sales-Type Leases

[0000926326-21-000007:notes:231]
On a recurring basis, the Company enters into multi-year, sales-type lease agreements with the majority varying in length from one to five years. The following table presents the Company’s income recognized from sales-type leases for the years ended December 31, 2020, 2019, and 2018:

[0000926326-21-000007:notes:232]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 26,040 |  |  | $ | 37,175 |  |  | $ | 39,167 |  |
| Cost of sales-type lease revenues | (10,624) |  |  | (14,985) |  |  | (16,185) |  |
| Selling profit on sales-type lease revenues | $ | 15,416 |  |  | $ | 22,190 |  |  | $ | 22,982 |  |
| Interest income on sales-type lease receivables | $ | 1,933 |  |  | $ | 1,756 |  |  | $ | 1,296 |  |

[0000926326-21-000007:notes:233]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at December 31, 2020 and 2019:

[0000926326-21-000007:notes:234]
|  | December 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 35,331 |  |  | $ | 32,360 |  |
| Less: Unearned interest income portion | (2,929) |  |  | (2,840) |  |
| Net investment in sales-type leases | 32,402 |  |  | 29,520 |  |
| Less: Current portion (1) | (10,246) |  |  | (9,770) |  |
| Long-term investment in sales-type leases, net | $ | 22,156 |  |  | $ | 19,750 |  |

[0000926326-21-000007:notes:235]
(1)    The current portion of the net investment in sales-type leases is included in other current assets in the Consolidated Balance Sheets.

[0000926326-21-000007:notes:236]
The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value.

[0000926326-21-000007:notes:237]
The maturity schedule of future minimum lease payments under sales-type leases retained in-house and the reconciliation to the net investment in sales-type leases reported on the Consolidated Balance Sheets was as follows:

[0000926326-21-000007:notes:238]
|  | December 31,2020 |
|  | (In thousands) |
| 2021 | $ | 11,312 |  |
| 2022 | 9,499 |  |
| 2023 | 7,334 |  |
| 2024 | 4,535 |  |
| 2025 | 2,616 |  |
| Thereafter | 35 |  |
| Total future minimum sales-type lease payments | 35,331 |  |
| Present value adjustment | (2,929) |  |
| Total net investment in sales-type leases | $ | 32,402 |  |

[0000926326-21-000007:notes:239]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of ASC 842, Leases. These agreements in place prior to January 1, 2019 continue to be treated as operating leases, however any leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with ASC 842. The operating lease arrangements generally have initial terms of one to seven years. The following table represents the Company’s income recognized from operating leases for the years ended December 31, 2020, 2019, and 2018:

[0000926326-21-000007:notes:240]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Rental income | $ | 11,668 |  |  | $ | 12,660 |  |  | $ | 12,207 |  |

[0000926326-21-000007:notes:241]
The net carrying value of the leased equipment under operating leases was $1.4 million and $2.1 million, which includes accumulated depreciation of $2.5 million and $1.6 million, as of December 31, 2020 and 2019, respectively. Depreciation expense of the leased equipment for the years ended December 31, 2020, 2019, and 2018 was $0.6 million, $0.7 million, and $0.5 million, respectively.

[0000926326-21-000007:notes:242]
The maturity schedule of future minimum lease payments under operating leases was as follows:

[0000926326-21-000007:notes:243]
|  | December 31, 2020 |
|  | (In thousands) |
| 2021 | $ | 8,848 |  |
| 2022 | 4,816 |  |
| 2023 | 2,910 |  |
| 2024 | 852 |  |
| 2025 | 256 |  |
| Thereafter | 89 |  |
| Total future minimum operating lease payments | $ | 17,771 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-21-000007:notes:244]
Lessee LeasesThe Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to 12 years. As of December 31, 2020, the Company did not have any additional material operating leases that were entered into, but not yet commenced. 
The maturity schedule of future minimum lease payments under operating leases and the reconciliation to the operating lease liabilities reported on the Consolidated Balance Sheets was as follows:

[0000926326-21-000007:notes:245]
|  | December 31, 2020 |
|  | (In thousands) |
| 2021 | $ | 15,290 |  |
| 2022 | 14,106 |  |
| 2023 | 10,221 |  |
| 2024 | 8,922 |  |
| 2025 | 6,571 |  |
| Thereafter | 17,422 |  |
| Total operating lease payments | 72,532 |  |
| Present value adjustment | (11,438) |  |
| Total operating lease liabilities (1) | $ | 61,094 |  |

[0000926326-21-000007:notes:246]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $12.2 million and $48.9 million, respectively. The short-term portion of the operating lease liabilities is included in accrued liabilities in the Consolidated Balance Sheets.

[0000926326-21-000007:notes:247]
Operating lease costs were $14.3 million and $14.6 million for the years ended December 31, 2020 and 2019, respectively. Short-term lease costs and variable lease costs were immaterial for the years ended December 31, 2020 and 2019, respectively.

[0000926326-21-000007:notes:248]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the years ended December 31, 2020 and 2019:

[0000926326-21-000007:notes:249]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 14,490 |  |  | $ | 14,636 |  |
| Right-of-use assets obtained in exchange for new lease liabilities, including leases obtained from recent acquisitions | $ | 10,025 |  |  | $ | 1,204 |  |

[0000926326-21-000007:notes:250]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of December 31, 2020 and 2019:

[0000926326-21-000007:notes:251]
|  | December 31, |
|  | 2020 |  | 2019 |
| Weighted-average remaining lease term, years | 5.9 |  | 6.4 |
| Weighted-average discount rate, % | 5.8 | % |  | 6.4 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-21-000007:notes:252]
Commitments and Contingencies
Purchase Obligations

[0000926326-21-000007:notes:253]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of December 31, 2020, the Company had non-cancelable purchase commitments of $72.8 million, of which $69.9 million are expected to be paid within the next twelve months.

[0000926326-21-000007:notes:254]
Legal Proceedings

[0000926326-21-000007:notes:255]
The Company is currently involved in various legal proceedings.

[0000926326-21-000007:notes:256]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company.

[0000926326-21-000007:notes:257]
The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the complaint on October 28, 2020. The Company's motion to dismiss is now fully briefed and the Court has scheduled oral argument on the motion for June 4, 2021. The Company intends to defend the lawsuit vigorously.

[0000926326-21-000007:notes:258]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “Omnicell Complaint”). This action was commenced in relation to another action brought by BD, in the same Court, (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol to facilitate the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The Omnicell Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees and costs, and pre-judgment and post-judgment interest. BD has not yet served the Omnicell Complaint on the Company, and, therefore, there are no response dates pending. The Company intends to defend the lawsuit vigorously.

[0000926326-21-000007:notes:259]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceedings described above based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to these legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of any of these legal proceedings or because of the diversion of management’s attention and the creation of significant expenses.

[0000926326-21-000007:notes:260]
Guarantees

[0000926326-21-000007:notes:261]
Under the Company’s certificate of incorporation and bylaws, the Company has agreed to indemnify its directors and executive officers to the fullest extent not prohibited by Delaware and other applicable law, subject to certain exceptions. The Company has entered into individual indemnification agreements with its directors and officers. The term of the indemnification period is for the entirety of the director’s or officer’s service to the Company and continues so long as the director or officer may be subject to any claim, action, or proceeding, and there is no limit on the potential amount of future payments that the Company could be required to make under these indemnification agreements. The Company has purchased a directors’ and officers’ liability insurance policy that may enable it to recover a portion of any future payments that it may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits, and other policy provisions, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability, or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-21-000007:notes:262]
Additionally, the Company undertakes indemnification obligations in its ordinary course of business in connection with, among other things, the licensing of its products and the provision of its support services. In the ordinary course of the Company’s business, the Company has in the past and may in the future agree to indemnify another party, generally its business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, its gross negligence or intentional acts in the performance of support services, and violations of laws. The term of these indemnification obligations is generally perpetual. In general, the Company attempts to limit the maximum potential amount of future payments that it may be required to make under these indemnification obligations to the amounts paid to it by a customer, but in some cases the obligation may not be so limited.

[0000926326-21-000007:notes:263]
In addition, the Company has in the past and may in the future warrant to its customers that its products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that its software media is free from material defects. Sales contracts for certain of the Company’s medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances the Company records have historically been immaterial.

[0000926326-21-000007:notes:264]
From time to time, the Company may also warrant that its professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. The Company generally seeks to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality, and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive, or similar damages. In some states, such disclaimers may not be enforceable. If necessary, the Company would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. The Company has not been subject to any significant claims for such losses and has not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of December 31, 2020 and 2019.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-21-000007:notes:265]
Employee Benefits and Share-Based Compensation
Stock Purchase Plan

[0000926326-21-000007:notes:266]
1997 Employee Stock Purchase Plan

[0000926326-21-000007:notes:267]
The Company has an Employee Stock Purchase Plan (“ESPP”), under which employees can purchase shares of its common stock based on a percentage of their compensation, but not greater than 15% of their earnings; provided, however, an eligible employee’s right to purchase shares of the Company’s common stock may not accrue at a rate which exceeds $25,000 of the fair market value of such shares for each calendar year in which such rights are outstanding. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-21-000007:notes:268]
There was a total of 1.2 million shares reserved for future issuance under the ESPP as of December 31, 2020.

[0000926326-21-000007:notes:269]
Stock Award Plans

[0000926326-21-000007:notes:270]
2009 Equity Incentive Plan

[0000926326-21-000007:notes:271]
The 2009 Equity Incentive Plan (“2009 Plan”), as amended, provides for the issuance of incentive stock options, RSAs, RSUs, PSUs, and other stock awards to the Company’s employees, directors, and consultants. There were 5.9 million shares of common stock reserved for future issuance under the 2009 Plan as of December 31, 2020.

[0000926326-21-000007:notes:272]
Options granted under the 2009 Plan generally become exercisable over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 36 equal monthly installments thereafter. The exercise prices of the options is the fair market value of common stock on the date of grant. RSUs generally vest over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 12 equal quarterly installments thereafter. Awards of restricted stock to non-employee directors are granted on the date of the annual meeting of stockholders and vest in full on the date of the next annual meeting of stockholders, provided such non-employee director remains a director on such date. The fair value of the awards on the date of issuance is amortized to expense from the date of grant to the date of vesting and are expensed ratably on a straight-line basis over the vesting period. PSUs granted to the Company’s executives might include performance and market conditions. PSUs become eligible for vesting when certain market or performance conditions are met.

[0000926326-21-000007:notes:273]
Share-Based Compensation Expense

[0000926326-21-000007:notes:274]
The following table sets forth the total share-based compensation expense recognized in the Company’s Consolidated Statements of Operations:

[0000926326-21-000007:notes:275]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 7,469 |  |  | $ | 5,648 |  |  | $ | 4,634 |  |
| Research and development | 6,497 |  |  | 6,604 |  |  | 5,746 |  |
| Selling, general, and administrative | 30,731 |  |  | 21,797 |  |  | 18,505 |  |
| Total share-based compensation expense | $ | 44,697 |  |  | $ | 34,049 |  |  | $ | 28,885 |  |

[0000926326-21-000007:notes:276]
The Company did not capitalize any share-based compensation as inventory as such amounts were not material for the years ended December 31, 2020 and 2019. Income tax benefits realized from share-based compensation were $10.3 million, $11.0 million, and $6.5 million, for the years ended December 31, 2020, 2019, and 2018, respectively.

[0000926326-21-000007:notes:277]
Stock Options and ESPP Shares

[0000926326-21-000007:notes:278]
The following assumptions were used to value stock options and ESPP shares granted pursuant to the Company’s equity incentive plans for the years ended December 31, 2020, 2019, and 2018:

[0000926326-21-000007:notes:279]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Stock options |  |  |  |  |  |
| Expected life, years | 4.7 |  | 4.4 |  | 4.8 |
| Expected volatility, % | 39.4 | % |  | 33.7 | % |  | 31.1 | % |
| Risk-free interest rate, % | 0.7 | % |  | 2.0 | % |  | 2.8 | % |
| Estimated forfeiture rate, % | 5.7 | % |  | 7.2 | % |  | 6.9 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |

[0000926326-21-000007:notes:280]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
| Employee stock purchase plan shares |  |  |  |  |  |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Expected volatility, % | 30.4% - 53.5% |  | 28.2% - 39.9% |  | 28.1% - 33.8% |
| Risk-free interest rate, % | 0.1% - 2.7% |  | 1.3% - 2.7% |  | 0.8% - 2.7% |
| Dividend yield, % | — | % |  | — | % |  | — | % |

[0000926326-21-000007:notes:281]
Stock Options Activity

[0000926326-21-000007:notes:282]
The following table summarizes the share option activity under the Company’s 2009 Plan during the year ended December 31, 2020:

[0000926326-21-000007:notes:283]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2019 | 3,902 |  |  | $ | 52.75 |  |  | 7.7 |  | $ | 113,198 |  |
| Granted | 1,351 |  |  | 78.83 |  |  |  |  |  |
| Exercised | (891) |  |  | 42.67 |  |  |  |  |  |
| Expired | (19) |  |  | 59.65 |  |  |  |  |  |
| Forfeited | (411) |  |  | 66.65 |  |  |  |  |  |
| Outstanding at December 31, 2020 | 3,932 |  |  | $ | 62.50 |  |  | 7.8 |  | $ | 226,160 |  |
| Exercisable at December 31, 2020 | 1,556 |  |  | $ | 45.49 |  |  | 6.2 |  | $ | 115,949 |  |
| Vested and expected to vest at December 31, 2020 and thereafter | 3,755 |  |  | $ | 61.86 |  |  | 7.7 |  | $ | 218,379 |  |

[0000926326-21-000007:notes:284]
The weighted-average fair value per share of options granted during the years ended December 31, 2020, 2019, and 2018 was $26.48, $23.54, and $17.22, respectively. The intrinsic value of options exercised during the years ended December 31, 2020, 2019, and 2018 was $39.8 million, $32.8 million, and $20.1 million, respectively. The tax benefit realized from stock options exercised was $7.1 million, $6.3 million, and $3.6 million, for the years ended December 31, 2020, 2019, and 2018, respectively.

[0000926326-21-000007:notes:285]
As of December 31, 2020, total unrecognized compensation cost related to unvested stock options was $52.7 million, which is expected to be recognized over a weighted-average vesting period of 2.8 years.

[0000926326-21-000007:notes:286]
Employee Stock Purchase Plan Activity

[0000926326-21-000007:notes:287]
For the years ended December 31, 2020 and 2019, employees purchased approximately 333,000 and 374,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $48.77 and $41.44, respectively. As of December 31, 2020, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $4.1 million and is expected to be recognized over a weighted-average period of 1.3 years.

[0000926326-21-000007:notes:288]
Restricted Stock Units (RSUs) and Restricted Stock Awards (RSAs)

[0000926326-21-000007:notes:289]
Summaries of the restricted stock activity under the 2009 Plan are presented below for the year ended December 31, 2020:

[0000926326-21-000007:notes:290]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted stock units |  |  |  |  |  |  |  |
| Outstanding at December 31, 2019 | 544 |  |  | $ | 66.65 |  |  | 1.6 |  | $ | 44,492 |  |
| Granted (Awarded) | 343 |  |  | 74.52 |  |  |  |  |  |
| Vested (Released) | (183) |  |  | 61.30 |  |  |  |  |  |
| Forfeited | (124) |  |  | 67.16 |  |  |  |  |  |
| Outstanding and unvested at December 31, 2020 | 580 |  |  | $ | 72.87 |  |  | 1.6 |  | $ | 69,670 |  |

[0000926326-21-000007:notes:291]
The weighted-average grant date fair value per share of RSUs granted during the years ended December 31, 2020, 2019, and 2018 was $74.52, $78.49, and $59.52, respectively. The total fair value of RSUs that vested in the years ended December 31, 2020, 2019, and 2018 was $11.2 million, $10.6 million, and $7.9 million, respectively.

[0000926326-21-000007:notes:292]
As of December 31, 2020, total unrecognized compensation cost related to RSUs was $40.5 million, which is expected to be recognized over the remaining weighted-average vesting period of 3.1 years.

[0000926326-21-000007:notes:293]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  |  |  |  |  |  |  |
|  | (In thousands, except per share data) |
| Restricted stock awards |  |  |  |  |  |  |  |  |  |  |
| Outstanding at December 31, 2019 | 17 |  |  | $ | 81.92 |  |  |  |  |  |  |  |  |
| Granted (Awarded) | 21 |  |  | 68.11 |  |  |  |  |  |  |  |  |
| Vested (Released) | (17) |  |  | 81.92 |  |  |  |  |  |  |  |  |
| Outstanding and unvested at December 31, 2020 | 21 |  |  | $ | 68.11 |  |  |  |  |  |  |  |  |

[0000926326-21-000007:notes:294]
The weighted-average grant date fair value per share of RSAs granted during the years ended December 31, 2020, 2019, and 2018 was $68.11, $81.86, and $46.60, respectively. The total fair value of RSAs that vested in the years ended December 31, 2020, 2019, and 2018 was $1.4 million, $1.0 million, and $1.0 million, respectively.

[0000926326-21-000007:notes:295]
As of December 31, 2020, total unrecognized compensation cost related to RSAs was $0.5 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.4 years.

[0000926326-21-000007:notes:296]
Performance-Based Restricted Stock Units (PSUs)

[0000926326-21-000007:notes:297]
In 2019, the Company granted 61,098 PSUs to its executive officers, all of which became eligible for vesting upon the achievement of a certain level of shareholder return. In 2020, the Company granted 62,759 PSUs to its executive officers, all, none, or a portion of which may become eligible for vesting depending on the level of shareholder return for the period from March 1, 2020 through March 1, 2021.

[0000926326-21-000007:notes:298]
The fair value of PSU awards to executive officers is determined using a Monte Carlo simulation model. The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of each of the other companies in the NASDAQ Healthcare Index (the “Index”).

[0000926326-21-000007:notes:299]
For PSUs granted on February 13, 2020, stock price appreciation is calculated based on the trailing 20-day average stock price just prior to the first trading day of March 2020, compared to the trailing 20-day average stock price just prior to the first trading day of March 2021. For PSUs granted on February 13, 2019, stock price appreciation is calculated based on the trailing 20-day average stock price just prior to the first trading day of March 2019, compared to the trailing 20-day average stock price just prior to the first trading day of March 2020.

[0000926326-21-000007:notes:300]
On March 5, 2019, the Compensation Committee confirmed the Company's total stockholder return at the 90th percentile rank of the Index. This resulted in 100% of the 2018 PSUs, or 110,432 shares, as eligible for further time-based vesting. The eligible PSUs will vest as follows: 25% of the shares vested immediately on March 5, 2019 with the remaining shares vesting on a semi-annual basis period of 36 months commencing on June 15, 2019. Vesting is contingent upon continued service. Of the 110,432 shares eligible for time-based vesting under the 2018 PSUs, 67,066 shares, net of forfeitures, have vested as of December 31, 2020.

[0000926326-21-000007:notes:301]
On March 3, 2020, the Compensation Committee confirmed the Company's total stockholder return at the 70th percentile rank of the Index. This resulted in 100% of the 2019 PSUs, or 61,098 shares, as eligible for further time-based vesting. The eligible PSUs will vest as follows: 25% of the shares vested immediately on March 3, 2020 with the remaining shares vesting on a semi-annual basis period of 36 months commencing on June 15, 2020. Vesting is contingent upon continued service. Of the 61,098 shares eligible for time-based vesting under the 2019 PSUs, 30,548 shares, net of forfeitures, have vested as of December 31, 2020.

[0000926326-21-000007:notes:302]
In addition to executive officers' PSU awards, from time to time, the Company may grant PSUs with specific performance and service conditions to certain employees on an ad hoc basis. Historically such grants have not been material.

[0000926326-21-000007:notes:303]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below for the year ended December 31, 2020:

[0000926326-21-000007:notes:304]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2019 | 134 |  |  | $ | 55.82 |  |
| Granted | 99 |  |  | 82.17 |  |
| Vested | (73) |  |  | 50.54 |  |
| Forfeited | (5) |  |  | 81.72 |  |
| Outstanding and unvested at December 31, 2020 | 155 |  |  | $ | 74.26 |  |

[0000926326-21-000007:notes:305]
The weighted-average grant date fair value per share of PSUs granted during the years ended December 31, 2020, 2019, and 2018 was $82.17, $73.38, and $38.03, respectively. The total fair value of PSUs that vested in the years ended December 31, 2020, 2019, and 2018 was $3.7 million, $3.5 million, and $3.2 million, respectively.

[0000926326-21-000007:notes:306]
As of December 31, 2020, total unrecognized compensation cost related to PSUs was approximately $5.6 million, which is expected to be recognized over the remaining weighted-average period of 1.4 years.

[0000926326-21-000007:notes:307]
Summary of Shares Reserved for Future Issuance under Equity Incentive Plans

[0000926326-21-000007:notes:308]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of December 31, 2020:

[0000926326-21-000007:notes:309]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 3,932 |  |
| Non-vested restricted stock awards | 756 |  |
| Shares authorized for future issuance | 1,250 |  |
| ESPP shares available for future issuance | 1,206 |  |
| Total shares reserved for future issuance | 7,144 |  |

[0000926326-21-000007:notes:310]
401(k) Plan
The Company has established a pre-tax savings plan under Section 401(k) of the Internal Revenue Code of 1986, as amended. The 401(k) Plan allows eligible employees in the United States to voluntarily contribute a portion of their pre-tax salary, subject to a maximum limit specified in the Internal Revenue Code. The Company matches 50% of employee contributions up to $3,000, annually. The Company’s contributions under this plan were $5.7 million, $5.1 million, and $4.6 million in the years ended December 31, 2020, 2019, and 2018, respectively.


## us-gaap:TreasuryStockTextBlock

[0000926326-21-000007:notes:311]
Stock Repurchase Program
On August 2, 2016, the Company’s Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2014 Repurchase Program”). As of December 31, 2020, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million.

[0000926326-21-000007:notes:312]
The timing, price, and volume of repurchases are to be based on market conditions, relevant securities laws, and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions, or pursuant to a Rule 10b-18 plan, subject to the terms and conditions of that certain A&R Credit Agreement, as amended. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase programs at any time.

[0000926326-21-000007:notes:313]
On September 17, 2020, the Board authorized a one-time stock repurchase transaction providing for the repurchase of up to $75.0 million of the Company’s common stock in privately negotiated transactions concurrently with the issuance of the Notes, described in Note 10, Convertible Senior Notes. In September 2020, the Company repurchased 749,300 shares of its common stock from purchasers of the Notes in the offering in privately negotiated transactions effected through one of the

[0000926326-21-000007:notes:314]
initial purchasers or its affiliate at an average price of $70.78 per share for an aggregate purchase price of approximately $53.0 million. There will be no further repurchases under this one-time authorization.

[0000926326-21-000007:notes:315]
During the years ended December 31, 2020, 2019, and 2018, the Company did not repurchase any of its outstanding common stock, including under the 2014 Repurchase Program or the 2016 Repurchase Program, other than the separately-authorized one-time stock repurchase concurrent with the offering of the Notes in September 2020.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-21-000007:notes:316]
Equity Offerings
On November 3, 2017, the Company entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC, and HSBC Securities (USA) Inc., as its sales agents, pursuant to which the Company was able to offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of the Company’s common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange.

[0000926326-21-000007:notes:317]
For the year ended December 31, 2018, the Company received gross proceeds of $40.3 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 557,000 shares of its common stock at an average price of approximately $72.40 per share.

[0000926326-21-000007:notes:318]
For the year ended December 31, 2019, the Company received gross proceeds of $38.5 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 460,000 shares of its common stock at an average price of approximately $83.81 per share.

[0000926326-21-000007:notes:319]
For the year ended December 31, 2020, the Company did not sell any of its common stock under the Distribution Agreement.

[0000926326-21-000007:notes:320]
The registration statement under which the shares that could have been sold pursuant to the Distribution Agreement expired on November 3, 2020, and, accordingly, no additional sales will be made pursuant to the Distribution Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-21-000007:notes:321]
Income Taxes
The following is a geographical breakdown of income (loss) before the provision for income taxes:

[0000926326-21-000007:notes:322]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Domestic | $ | 34,714 |  |  | $ | 81,641 |  |  | $ | 46,528 |  |
| Foreign | (5,365) |  |  | (7,708) |  |  | (10,912) |  |
| Income (loss) before provision for income taxes | $ | 29,349 |  |  | $ | 73,933 |  |  | $ | 35,616 |  |

[0000926326-21-000007:notes:323]
The provision for (benefit from) income taxes consisted of the following:

[0000926326-21-000007:notes:324]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Federal | $ | 1,874 |  |  | $ | 8,006 |  |  | $ | 1,404 |  |
| State | 1,733 |  |  | 4,549 |  |  | 1,832 |  |
| Foreign | 647 |  |  | 1,240 |  |  | 768 |  |
| Total current income taxes | 4,254 |  |  | 13,795 |  |  | 4,004 |  |
| Deferred: |  |  |  |  |  |
| Federal | (3,868) |  |  | (1,292) |  |  | 5,455 |  |
| State | (2,494) |  |  | (1,609) |  |  | (909) |  |
| Foreign | (737) |  |  | 1,701 |  |  | (10,663) |  |
| Total deferred income taxes | (7,099) |  |  | (1,200) |  |  | (6,117) |  |
| Total provision for (benefit from) income taxes | $ | (2,845) |  |  | $ | 12,595 |  |  | $ | (2,113) |  |

[0000926326-21-000007:notes:325]
The provision for (benefit from) income taxes differs from the amount computed by applying the statutory federal tax rate as follows:

[0000926326-21-000007:notes:326]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| U.S. federal tax provision at statutory rate | $ | 6,163 |  |  | $ | 15,525 |  |  | $ | 7,479 |  |
| State taxes | (601) |  |  | 2,258 |  |  | 651 |  |
| Section 162(m) limitation | 2,550 |  |  | 2,279 |  |  | 738 |  |
| Non-deductible expenses | 325 |  |  | 619 |  |  | 686 |  |
| Uncertain tax positions | (394) |  |  | (2,472) |  |  | (412) |  |
| Share-based compensation tax benefit | (6,929) |  |  | (7,892) |  |  | (4,005) |  |
| Research tax credits | (4,038) |  |  | (3,805) |  |  | (3,230) |  |
| Restructuring impact | — |  |  | 7,432 |  |  | (4,205) |  |
| Foreign derived intangible income deduction | (204) |  |  | (449) |  |  | (349) |  |
| Foreign rate differential | (102) |  |  | (1,424) |  |  | 561 |  |
| Other | 385 |  |  | 524 |  |  | (27) |  |
| Total provision for (benefit from) income taxes | $ | (2,845) |  |  | $ | 12,595 |  |  | $ | (2,113) |  |

[0000926326-21-000007:notes:327]
As a result of global operational centralization activities during the year ended December 31, 2018, the Company recognized $4.2 million of tax benefit associated with making a check-the-box election to treat Aesynt Holding Coöperatief U.A. (Netherlands) as the U.S. disregarded entity beginning in the first quarter of 2018. Subsequently, during the year ended December 31, 2019, the Company recognized gain on the sale of certain intellectual property rights by Aesynt B.V. to Omnicell, Inc. and by Mach4 Automatisierungstechnik GmbH ("Mach4") to Omnicell, Inc., which resulted in a tax expense, net of tax benefit, of $7.4 million. As the Company continued with global operational centralization activities during the year ended December 31, 2020, Aesynt B.V. merged with and into Aesynt Holding B.V., with Aesynt Holding B.V. surviving and changing its name to Omnicell B.V., Aesynt Holding Coöperatief U.A. liquidated into Omnicell, Inc., and Omnicell GmbH merged with and into Mach4, with Mach4 surviving and changing its name to Omnicell GmbH. During the year ended December 31, 2020, the Company also recognized a gain on Omnicell Limited’s transferring shares of Omnicell GmbH to Omnicell International, LLC, which resulted in an immaterial tax expense.

[0000926326-21-000007:notes:328]
On March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was signed into law in response to the COVID-19 pandemic. The CARES Act, among other provisions, includes provisions related to refundable payroll tax credits, deferment of the employer portion of certain payroll taxes, net operating losses carryback periods, alternative minimum tax credit refunds, modification to the net interest expense deduction limitation, and technical amendments to tax depreciation methods for qualified improvement property placed in service after December 31, 2017. The provisions of the CARES Act did not have a material impact on the Company’s income taxes.

[0000926326-21-000007:notes:329]
Significant components of the Company’s deferred tax assets (liabilities) were as follows:

[0000926326-21-000007:notes:330]
|  | December 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Deferred tax assets (liabilities): |  |  |  |
| Deferred revenues | $ | 5,910 |  |  | $ | 4,129 |  |
| Share-based compensation | 8,094 |  |  | 6,483 |  |
| Inventory-related items | 4,953 |  |  | 3,507 |  |
| Tax credit carryforwards | 12,105 |  |  | 13,472 |  |
| Reserves and accruals | 8,160 |  |  | 5,712 |  |
| Loss carryforwards | 8,461 |  |  | 9,484 |  |
| Lease liability | 15,465 |  |  | 15,471 |  |
| Other, net | 1,578 |  |  | 543 |  |
| Gross deferred tax assets | 64,726 |  |  | 58,801 |  |
| Valuation allowance | (1,199) |  |  | (1,186) |  |
| Total net deferred tax assets | 63,527 |  |  | 57,615 |  |
| Intangibles | (22,010) |  |  | (18,941) |  |
| Depreciation and amortization | (36,528) |  |  | (35,941) |  |
| Prepaid expenses | (15,654) |  |  | (13,395) |  |
| Right-of-use assets | (13,949) |  |  | (14,286) |  |
| Total deferred tax liabilities | (88,141) |  |  | (82,563) |  |
| Net deferred tax liabilities | $ | (24,614) |  |  | $ | (24,948) |  |

[0000926326-21-000007:notes:331]
Deferred income tax assets (liabilities) are provided for temporary differences that will result in future tax deductions or future taxable income, as well as the future benefit of tax credit carryforwards. The Company recognizes deferred tax assets to the extent that it believes these assets are more likely than not to be realized. In making such a determination, the Company considers all available positive and negative evidence, including future reversals of existing temporary differences, projected future taxable income, tax planning strategies, and results of recent operations. On the basis of this evaluation, as of December 31, 2020, $1.2 million of valuation allowance was recorded on certain foreign net operating losses carried forward, as the Company believes that such deferred tax assets are not more likely than not to be realized.

[0000926326-21-000007:notes:332]
As of December 31, 2020, the Company had $6.0 million of state net operating loss carryforwards expiring at various dates beginning in 2024, and $29.7 million of foreign net operating losses carried forward indefinitely. For income tax purposes, the Company has federal and California research tax credits carryforwards of $1.3 million and $17.0 million, respectively. Federal research tax credit carryforwards from prior years will begin to expire in 2035. California credits are available indefinitely to reduce cash taxes payable.

[0000926326-21-000007:notes:333]
It is the Company's practice and intention to reinvest the earnings of its non-U.S. subsidiaries in those operations. As of December 31, 2020, the Company has not made a provision for U.S. federal income, withholding, and state income taxes on the outside basis difference related to certain foreign subsidiaries because earnings are intended to be indefinitely reinvested in operations outside the U.S.

[0000926326-21-000007:notes:334]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of December 31, 2020, the Company was no longer subject to U.S., state, and foreign examination for years before 2017, 2016, and 2016, respectively.

[0000926326-21-000007:notes:335]
The aggregate change in the balance of gross unrecognized tax benefits, which excludes interest and penalties, for the three years ended December 31, 2020 was as follows:

[0000926326-21-000007:notes:336]
|  | (In thousands) |
| Balance as of December 31, 2017 | $ | 10,741 |  |
| Increases related to tax positions taken during a prior period | 19 |  |
| Decreases related to tax positions taken during the prior period | (1,257) |  |
| Increases related to tax positions taken during the current period | 870 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (412) |  |
| Balance as of December 31, 2018 | 9,961 |  |
| Increases related to tax positions taken during a prior period | 10 |  |
| Decreases related to tax positions taken during the prior period | (6) |  |
| Increases related to tax positions taken during the current period | 9,282 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (2,472) |  |
| Balance as of December 31, 2019 | 16,775 |  |
| Increases related to tax positions taken during a prior period | 88 |  |
| Decreases related to tax positions taken during the prior period | — |  |
| Increases related to tax positions taken during the current period | 2,294 |  |
| Decreases related to settlements | — |  |
| Decreases related to expiration of statute of limitations | (911) |  |
| Balance as of December 31, 2020 | $ | 18,246 |  |

[0000926326-21-000007:notes:337]
The total amounts of gross unrecognized tax benefit that, if realized, would favorably affect the Company's effective income tax rate in future periods, was $18.2 million and $16.8 million as of December 31, 2020 and 2019, respectively. The Company recognizes interest and/or penalties related to uncertain tax positions in interest and other income (expense), net in the Consolidated Statements of Operations, accruing $0.4 million, $0.5 million, and $0.5 million for the years ended December 31, 2020, 2019, and 2018, respectively. Accrued interest and penalties are included within other long-term liabilities on the Consolidated Balance Sheets. The combined amount of cumulative accrued interest and penalties was approximately $1.4 million, $1.0 million, and $1.4 million for the years ended December 31, 2020, 2019, and 2018, respectively. The Company does not believe there will be any significant changes in its unrecognized tax positions over the next twelve months.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-21-000007:notes:338]
Restructuring Expenses
In the first quarter of 2020, the Company announced a company-wide organizational realignment initiative in order to more effectively align its organizational infrastructure and operations with the strategic vision of the autonomous pharmacy. In the second quarter of 2020, the Company continued its organizational realignment initiative, as well as initiated a restructuring plan to help mitigate the adverse impact of the COVID-19 pandemic on its business and financial results. During the year ended December 31, 2020, the Company incurred and accrued $10.0 million of employee severance costs and related expenses. As of December 31, 2020, the unpaid balance related to this restructuring plan was $0.6 million.

[0000926326-21-000007:notes:339]
In the fourth quarter of 2018, the Company announced a company-wide organizational realignment initiative in order to align its organizational infrastructure for future expected growth. During the year ended December 31, 2018, the Company accrued and paid out $1.3 million of restructuring expenses, which includes severance and consulting-related expenses.

[0000926326-21-000007:notes:340]
On March 2, 2018, the Company initiated the realignment of its Automation and Analytics commercial group in North America and France. During the year ended December 31, 2018, the Company accrued and paid out $3.0 million of employee severance costs and related expenses.

[0000926326-21-000007:notes:341]
The following table summarizes the total restructuring expenses recognized in the Company’s Consolidated Statements of Operations for the years ended December 31, 2020, 2019, and 2018:

[0000926326-21-000007:notes:342]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 2,564 |  |  | $ | — |  |  | $ | 186 |  |
| Research and development | 3,716 |  |  | — |  |  | — |  |
| Selling, general, and administrative | 3,681 |  |  | — |  |  | 4,160 |  |
| Total restructuring expenses | $ | 9,961 |  |  | $ | — |  |  | $ | 4,346 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000926326-21-000007:notes:343]
SCHEDULE II

[0000926326-21-000007:notes:344]
VALUATION AND QUALIFYING ACCOUNTS

[0000926326-21-000007:notes:345]
|  | Balance atBeginning of Period (1) |  | Charged (Credited) toCosts and Expenses (2) |  | Debited (Credited) toOther Accounts (3) |  | AmountsWritten Off (4) |  | Other Adjustments (5) |  | Balance atEnd of Period (1) |
|  | (In thousands) |
| Year ended December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables | $ | 5,738 |  |  | $ | (127) |  |  | $ | 12 |  |  | $ | (3,010) |  |  | $ | (31) |  |  | $ | 2,582 |  |
| Long-term unbilled receivables | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net investment in sales-type leases | 192 |  |  | 10 |  |  | 12 |  |  | — |  |  | — |  |  | 214 |  |
| Total allowances deducted from assets | $ | 5,930 |  |  | $ | (117) |  |  | $ | 24 |  |  | $ | (3,010) |  |  | $ | (31) |  |  | $ | 2,796 |  |
| Year ended December 31, 2019 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables | $ | 2,582 |  |  | $ | 2,488 |  |  | $ | — |  |  | $ | (1,986) |  |  | $ | 143 |  |  | $ | 3,227 |  |
| Long-term unbilled receivables | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net investment in sales-type leases | 214 |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | 225 |  |
| Total allowances deducted from assets | $ | 2,796 |  |  | $ | 2,499 |  |  | $ | — |  |  | $ | (1,986) |  |  | $ | 143 |  |  | $ | 3,452 |  |
| Year ended December 31, 2020 |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables | $ | 3,227 |  |  | $ | 1,095 |  |  | $ | — |  |  | $ | (535) |  |  | $ | 499 |  |  | $ | 4,286 |  |
| Long-term unbilled receivables | — |  |  | — |  |  | — |  |  | — |  |  | 30 |  |  | 30 |  |
| Net investment in sales-type leases | 225 |  |  | 40 |  |  | — |  |  | — |  |  | — |  |  | 265 |  |
| Total allowances deducted from assets | $ | 3,452 |  |  | $ | 1,135 |  |  | $ | — |  |  | $ | (535) |  |  | $ | 529 |  |  | $ | 4,581 |  |

[0000926326-21-000007:notes:346]
__________________________________________________

[0000926326-21-000007:notes:347]
(1)Allowance for credit losses.

[0000926326-21-000007:notes:348]
(2)Represents amounts charged and credited for provisions for credit losses.

[0000926326-21-000007:notes:349]
(3)Represents amounts debited to receivables as recoveries, increasing the allowance.

[0000926326-21-000007:notes:350]
(4)Represents amounts written off from the allowance and receivable.

[0000926326-21-000007:notes:351]
(5)Represents other adjustments, such as foreign currency translation, adoption of new accounting guidance, and purchase price accounting adjustments in connection with acquisitions.
