# OMCL MD&A — 0000926326-21-000007


## mdna

[0000926326-21-000007:mdna:1]
ITEM 7.    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000926326-21-000007:mdna:2]
The following discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes in this annual report on Form 10-K. This may contain forward-looking statements based upon current expectations that involve risks and uncertainties. Our actual results and the timing of selected events could differ materially from those anticipated in these forward-looking statements as a result of several factors, including those set forth under

[0000926326-21-000007:mdna:3]
Item 1A “Risk Factors” and elsewhere in this annual report on Form 10-K. Unless otherwise stated, references in this report to particular years or quarters refer to our fiscal year and the associated quarters of those fiscal years.

[0000926326-21-000007:mdna:4]
We have elected to omit discussion of the earliest of the three years covered by the Consolidated Financial Statements presented. Such omitted discussion can be found under Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, located in our annual report on Form 10-K for the fiscal year ended December 31, 2019, filed with the SEC on February 26, 2020, for reference to discussion of the fiscal year ended December 31, 2018, the earliest of the three fiscal years presented.

[0000926326-21-000007:mdna:5]
OVERVIEW

[0000926326-21-000007:mdna:6]
Our Business

[0000926326-21-000007:mdna:7]
We are a leader in transforming the pharmacy care delivery model. Our medication management automation solutions and adherence tools empower healthcare systems and pharmacies to focus on clinical care, rather than administrative tasks. Our solutions support the vision of a fully autonomous pharmacy, a roadmap designed to improve operational efficiencies through a fully automated, medication management infrastructure. Our vision is to transform the pharmacy care delivery model through automation designed to replace manual, error-prone processes, combined with a single, cloud-based platform and advanced services offerings. We believe our connected devices, products, and solutions will help our customers harness the power of data and analytics, and deliver improved patient outcomes.

[0000926326-21-000007:mdna:8]
Over 7,000 facilities worldwide use our automation and analytics solutions which are designed to improve pharmacy workflows, increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 50,000 institutional and retail pharmacies across North America and the United Kingdom leverage our innovative medication adherence and population health solutions to improve patient engagement, and adherence to prescriptions and vaccine scheduling, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 89% of our total revenues for the year ended December 31, 2020.

[0000926326-21-000007:mdna:9]
Over the past several years, our business has expanded from a single-point solution to a platform of products and services that will help to further advance the vision of the autonomous pharmacy. This has resulted in larger deal sizes across multiple products, services, and implementations for customers and, we believe, more comprehensive, valuable, and enduring relationships.

[0000926326-21-000007:mdna:10]
We utilize product bookings as an indicator of the success of our business. Product bookings generally consist of all firm orders other than for technical services and other less significant items, as evidenced generally by a non-cancelable contract and purchase order for equipment and software products, and by a purchase order for consumables. The majority of connected devices and software license product bookings are installable within twelve months of booking, and are recorded as revenue upon customer acceptance of the installation or receipt of goods. Revenues from software-as-a-service (“SaaS”), subscription software, and technology-enabled services product bookings are recorded over the contractual term. Product bookings increased by 23%, from $813 million in 2019 to $1.002 billion in 2020, driven by the success of our growth strategies in our comprehensive platform and differentiated products, as well as expanding our customer portfolio.

[0000926326-21-000007:mdna:11]
In addition to product solution sales, we provide services to our customers. We provide installation planning and consulting as part of most product sales which is generally included in the initial price of the solution. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in increments of one to five years. As a result of the growth of our installed base of customers and expanded service offerings, our service revenues have also grown.

[0000926326-21-000007:mdna:12]
The following table summarizes each revenue category:

[0000926326-21-000007:mdna:13]
| Revenue Category |  | Revenue Type (1) |  | Income Statement Classification |  | Included in Product Bookings |
| Connected devices, software licenses, and other |  | High visibility/Nonrecurring |  | Product |  | Yes (2) |
| Technical services |  | High visibility/Recurring |  | Service |  | No |
| Consumables |  | High visibility/Recurring |  | Product |  | Yes |
| SaaS, subscription software, and technology-enabled services |  | High visibility/Recurring |  | Service |  | Yes |

[0000926326-21-000007:mdna:14]
_________________________________________________

[0000926326-21-000007:mdna:15]
(1)     All revenue types are highly visible from long-term, sole-source agreements, backlog, or the recurring nature of the revenue stream.

[0000926326-21-000007:mdna:16]
(2)     Freight revenue and certain other insignificant revenue streams are not included in product bookings.

[0000926326-21-000007:mdna:17]
Our full-time headcount of approximately 2,860 on December 31, 2020, an increase of approximately 160 from December 31, 2019, reflects our efforts to grow our operations, while driving profitability and optimizing resource allocation.

[0000926326-21-000007:mdna:18]
Operating Segments

[0000926326-21-000007:mdna:19]
We manage our operations as a single segment for the purposes of assessing performance and making operating decisions. Our Chief Operating Decision Maker ("CODM") is our Chief Executive Officer. The CODM allocates resources and evaluates the performance of Omnicell at the consolidated level using information about our revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of Omnicell as one operating segment, which is the same as our reporting segment.

[0000926326-21-000007:mdna:20]
Strategy

[0000926326-21-000007:mdna:21]
We are committed to being the care provider’s most trusted partner and executing on the vision of the autonomous pharmacy by delivering automation, intelligence, and advanced services, powered by a single, cloud-based platform. We believe there are significant challenges in pharmacy practice including, but not limited to, medication errors, drug shortages, medication loss due to drug diversion, significant medication waste and expiration costs, a high level of manual steps in the medication management automation process, complexity around compliance requirements, high pharmacy employee turnover rates, hospitalizations from adverse drug events in outpatient settings, high variability in outcomes, and limited inventory visibility. We believe that these significant challenges in pharmacy practice drive the demand for increased digitization and virtualization, and that our solutions enable this and represent large opportunities in four market categories:

[0000926326-21-000007:mdna:22]
•Point of Care.  As a market leader, we expect to continue expansion of this product category as customers increase use of our dispensing systems in more areas within their hospitals. In addition, we are early in the replacement, upgrade, and expansion cycle of our XT Series automated dispensing systems which we believe is a significant market opportunity and we expect to continue to focus on further penetrating markets through competitive conversions. We believe our current portfolio within the Point of Care market and new innovation and services will continue to drive improved outcomes and lower costs for our customers.

[0000926326-21-000007:mdna:23]
•Central Pharmacy.  This market represents the beginning of the medication management process in acute care settings, and, we believe, the next big automation opportunity to replace manual and repetitive processes which are common in the pharmacy today. Manual processes are prone to significant errors, and products such as IVX Workflow, our IV sterile compounding solutions, and the XR2 Automated Central Pharmacy system automate these manual processes and are designed to reduce the risk of error for our healthcare partners. We believe new products and innovations, including Omnicell One, in the Central Pharmacy market create opportunities to replace prior generation Central Pharmacy robotics and carousels. The Central Pharmacy also represents an opportunity to provide technology-enabled services designed to reduce the administrative burden on the pharmacy and allow clinicians to operate at the top of their license.

[0000926326-21-000007:mdna:24]
•340B Software-Enabled Services.  This market is targeted to covered entities participating in Section 340B of the Public Health Services Act. The act requires pharmaceutical manufacturers participating in Medicaid to sell outpatient drugs at discounted prices to health care organizations that care for many uninsured and low-income patients and results in a complex compliance environment. We believe that there are significant opportunities for health systems to improve participation benefits and maximize program savings through software-enabled services

[0000926326-21-000007:mdna:25]
and solutions. Our Omnicell 340B platform of technology-enabled services includes split billing software, contract pharmacy administration, specialty contract pharmacy administration, and drug discount access solutions.

[0000926326-21-000007:mdna:26]
•Retail, Institutional, and Payer.  We believe the Retail, Institutional, and Payer market represents a large opportunity as the majority of drugs are distributed in the non-acute sector. New technology and updated state board regulations are leading to innovation at traditional retail providers, which, combined with the move to value-based care, we believe will incentivize the market to adopt solutions to help providers and payers engage patients in new ways that lower the total cost of care. We believe adoption of our EnlivenHealth (formerly Population Health Solutions) portfolio of software products and services, along with medication adherence packaging, will increase adherence performance rates, increase prescription volume for our customers, and reduce hospital and emergency room visits due to improved adherence. As retail pharmacies play an increasingly vital role in population health following the onset of the COVID-19 pandemic, EnlivenHealth has extended solutions to assist with vaccination programs, testing protocols, and patient engagement efforts. There are three main areas of focus:

[0000926326-21-000007:mdna:27]
◦CareScheduler is an exclusive digital solution that automates the scheduling, reporting, and patient outreach for administering the COVID-19 vaccine and other vaccines and testing procedures.

[0000926326-21-000007:mdna:28]
◦Medication Synchronization is an appointment-based solution that aligns a patient's medications to a single refill date, designed to improve medication adherence and reduce hospital readmissions.

[0000926326-21-000007:mdna:29]
◦Medication Therapy Management is a platform that offers intuitive workflow with high-level decision support for efficiently completing CMS-compliant Comprehensive Medication Reviews using pharmacy claims data.

[0000926326-21-000007:mdna:30]
We believe our technology, services, and solutions within these market categories position us well to address the needs of retail, acute, and post-acute pharmacy providers.

[0000926326-21-000007:mdna:31]
COVID-19 Update

[0000926326-21-000007:mdna:32]
Keeping in mind our role in the healthcare industry, we are continuing to closely monitor the COVID-19 pandemic. As a result of the COVID-19 pandemic, health systems have faced financial pressures which we believe led our customers to delay or defer purchasing decisions and/or implementation of our solutions during the first half of 2020. However, starting in the third quarter of 2020, we began to see our customers returning to pre-pandemic purchasing patterns consistent with long-term strategic investments. We believe that the challenges that our customers have faced during the COVID-19 pandemic, including the need for robust visibility throughout their pharmacy supply chains, have increased the strategic relevance of our products and services. Though we expect to continue to face challenges and opportunities brought on by the COVID-19 pandemic, we remain confident in the overall health of our business and in our ability to navigate through these unusual times.

[0000926326-21-000007:mdna:33]
Acquisitions

[0000926326-21-000007:mdna:34]
On October 1, 2020, we completed the acquisition of the 340B Link business (the “340B Link Business”) of Pharmaceutical Strategies Group, LLC pursuant to the terms and conditions of the Equity Purchase Agreement, dated August 11, 2020, as amended, by and among the Company, PSGH, LLC, BW Apothecary Holdings, LLC, the sellers identified therein and the seller’s representative for total cash consideration of $225.0 million. The acquisition adds a comprehensive and differentiated suite of software-enabled services and solutions used by certain eligible hospitals, health systems, clinics, and entities to manage compliance and capture 340B drug cost savings on outpatient prescriptions filled through the eligible entity’s pharmacy or a contracted pharmacy partner. The results of the operations of the 340B Link Business have been included in our consolidated results of operations beginning October 1, 2020.

[0000926326-21-000007:mdna:35]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0000926326-21-000007:mdna:36]
Our discussion and analysis of our financial condition and results of operations are based on our Consolidated Financial Statements, which have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0000926326-21-000007:mdna:37]
Revenue Recognition

[0000926326-21-000007:mdna:38]
We earn revenues from sales of our products and related services, which are sold in the healthcare industry, our principal market.

[0000926326-21-000007:mdna:39]
Prior to recognizing revenue, we identify the contract, performance obligations, and transaction price, and allocate the transaction price to the performance obligations. All identified contracts meet the following required criteria:

[0000926326-21-000007:mdna:40]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of our contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via phone or a purchase order.

[0000926326-21-000007:mdna:41]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following our standard business process and terms.

[0000926326-21-000007:mdna:42]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 to 60 days from shipment of tangible product or services performed for customers in the United States. Where a written contract does not exist, our standard payment terms are net 30 day terms.

[0000926326-21-000007:mdna:43]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract). Our agreements are an exchange of cash for a combination of products and services which result in changes in the amount of our future cash flows.

[0000926326-21-000007:mdna:44]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. We perform a credit check for all significant customers or transactions and where collectability is not probable, payment in full or a substantial down payment is typically required to help assure the full agreed upon contract price will be collected.

[0000926326-21-000007:mdna:45]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, we combine the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify our performance obligations, we consider all of the products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, we consider an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of our sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, consumables and software products, support and maintenance, and professional services.

[0000926326-21-000007:mdna:46]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of our commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

[0000926326-21-000007:mdna:47]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price we charge for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, our products and services are not generally sold separately. We use an amount discounted from the list price as a best estimated selling price.

[0000926326-21-000007:mdna:48]
We recognize revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as we provide a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to our unsatisfied performance obligations are recorded as deferred revenues.

[0000926326-21-000007:mdna:49]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

[0000926326-21-000007:mdna:50]
We often enter into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. Our change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

[0000926326-21-000007:mdna:51]
In the normal course of business, we typically do not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. We establish provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to our Consolidated Financial Statements for any periods presented.

[0000926326-21-000007:mdna:52]
Lessor Leases

[0000926326-21-000007:mdna:53]
We determine if an arrangement is a lease at inception. The transaction price is allocated to separate performance obligations, generally consisting of hardware and software products, installation, and post-installation technical support, proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price we charge for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, our products and services are not generally sold separately. We use an amount discounted from the list price as a best estimated selling price.

[0000926326-21-000007:mdna:54]
Sales-Type Leases

[0000926326-21-000007:mdna:55]
We enter into non-cancelable sales-type lease arrangements, most of which do not have an option to extend the lease term. At the end of the lease term, the customer must either return the equipment or negotiate a new agreement, resulting in a new purchase or lease transaction. Failure of the customer to either return the equipment or negotiate a new agreement results in the contract becoming a month-to-month rental. Certain sales-type leases automatically renew for successive one year periods at the end of each lease term with written notice from the customer. Our sales-type lease agreements do not contain any material residual value guarantees.

[0000926326-21-000007:mdna:56]
For sales-type leases, we recognize revenues for our hardware and software products, net of lease execution costs, post-installation product maintenance, and technical support, at the net present value of the lease payment stream upon customer acceptance. We recognize service revenues associated with sales-type leases ratably over the term of the agreement in service revenues in the Consolidated Statements of Operations. We recognize interest income from sales-type leases using the effective interest method. Both hardware and software revenues, and interest income from sales-types leases are recorded in product revenues in the Consolidated Statements of Operations.

[0000926326-21-000007:mdna:57]
We optimize cash flows by selling a majority of our non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house.

[0000926326-21-000007:mdna:58]
Allowance for Credit Losses

[0000926326-21-000007:mdna:59]
We are exposed to credit losses primarily through sales of our products and services, as well as our sales-type leasing arrangements. We perform credit evaluations of our customers’ financial condition in order to assess each customer’s ability to pay. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, and a financial review of the customer. We continue to monitor customers’ creditworthiness on an ongoing basis.

[0000926326-21-000007:mdna:60]
We maintain an allowance for credit losses for accounts receivable, unbilled receivables, and net investment in sales-type leases based on expected credit losses resulting from the inability of our customers to make required payments. The allowance for credit losses is measured using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. We also record a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. Actual collection losses may differ from management’s estimates, and such differences could be material to our financial position and results of operations.

[0000926326-21-000007:mdna:61]
Inventory

[0000926326-21-000007:mdna:62]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. Inbound shipping costs are included in cost of inventory. We regularly monitor inventory quantities on hand and record write-downs for excess and obsolete inventories based on our estimate of demand for our products, potential obsolescence of

[0000926326-21-000007:mdna:63]
41

[0000926326-21-000007:mdna:64]
technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Shipments from suppliers or contract manufacturers before we receive them are recorded as in-transit inventory when title and the significant risks and rewards of ownership have passed to us.

[0000926326-21-000007:mdna:65]
Software Development Costs

[0000926326-21-000007:mdna:66]
We capitalize certain software development costs in accordance with Accounting Standards Codification ("ASC") 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which those costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. We establish technological feasibility when we complete a detail program design or a working model. We amortize development costs over the estimated lives of the related products, which is generally five years. All development costs prior to the completion of a detail program design or a working model are recognized as research and development expense.

[0000926326-21-000007:mdna:67]
Lessee Leases

[0000926326-21-000007:mdna:68]
We determine if an arrangement is a lease at inception. Operating lease right-of-use assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. As most of our lease contracts do not provide an implicit rate, we use our incremental borrowing rate based on information available at the commencement date in determining the present value of the lease payments. Lease expense is recognized on a straight-line basis over the lease term. We do not recognize a right-of-use asset and a lease liability for leases with an initial term of 12 months or less. We elected the practical expedient to not separate lease components from nonlease components and applied that practical expedient to all material classes of leased assets.

[0000926326-21-000007:mdna:69]
Many of our operating leases include an option to extend the lease. The specific terms and conditions of the extension options vary from lease to lease, but are consistent with standard industry practices in each area that we operate. We review each of our lease options at a time required by the terms of the lease contract, and notify the lessor if we choose to exercise the lease renewal option. Until we are reasonably certain that we will extend the lease contract, the renewal option periods will not be recognized as right-of-use assets or lease liabilities.

[0000926326-21-000007:mdna:70]
Certain leases include provisions for early termination, which allow the contract parties to terminate their obligations under the lease contract. The terms and conditions of the termination options vary by contract. When we have made a decision to exercise an early termination option, the right-of-use assets and associated lease liabilities are remeasured in accordance with the present value of the remaining cash flows under the lease contract.

[0000926326-21-000007:mdna:71]
Certain building lease agreements include rental payments subject to change annually based on fluctuations in various indexes (i.e. Consumer Price Index (“CPI”), Retail Price Index, and other international indexes). Certain data center lease agreements include rental payments subject to change based on usage and CPI fluctuations. The changes based on usage and indexes are treated as variable lease costs and recognized in the period in which the obligation for those payments was incurred.

[0000926326-21-000007:mdna:72]
Business Combinations

[0000926326-21-000007:mdna:73]
We use the acquisition method of accounting under the authoritative guidance on business combinations. Each acquired company’s operating results are included in our Consolidated Financial Statements starting on the date of acquisition. The purchase price is equivalent to the fair value of consideration transferred. Tangible and identifiable intangible assets acquired and liabilities assumed as of the date of acquisition are recorded at the acquisition date fair value. Goodwill is recognized for the excess of purchase price over the net fair value of assets acquired and liabilities assumed.

[0000926326-21-000007:mdna:74]
Amounts allocated to assets and liabilities are based upon fair values. Such valuations require management to make significant estimates and assumptions, especially with respect to the identifiable intangible assets. Management makes estimates of fair value based upon assumptions believed to be reasonable and that of a market participant. These estimates are based on historical experience and information obtained from the management of the acquired companies and the estimates are inherently uncertain. The separately identifiable intangible assets generally include customer relationships, acquired technology, backlog, trade names, and non-compete agreements.

[0000926326-21-000007:mdna:75]
Goodwill and Acquired Intangible Assets

[0000926326-21-000007:mdna:76]
Goodwill

[0000926326-21-000007:mdna:77]
We review goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. This assessment is also performed whenever there is a change in circumstances that indicates the carrying value of goodwill may be impaired. We have one reporting unit, which is the same as our operating segment. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. A qualitative assessment includes, among others, consideration of: (i) past, current, and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this qualitative assessment indicates that it is more likely than not that impairment exists, or if we decide to bypass this option, we proceed to the quantitative assessment. The quantitative assessment involves a comparison between the estimated fair value of our reporting unit with its carrying amount including goodwill. If the carrying value exceeds estimated fair value, we will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill.

[0000926326-21-000007:mdna:78]
To determine the reporting unit’s fair value under the quantitative approach, we use a combination of income and market approaches, equally weighting the two approaches, such as estimated discounted future cash flows of the reporting unit, multiples of earnings or revenues, and analysis of recent sales or offerings of comparable entities. We also consider our market capitalization on the date of the analysis to ensure the reasonableness of our reporting unit's fair value.

[0000926326-21-000007:mdna:79]
Intangible Assets

[0000926326-21-000007:mdna:80]
In connection with our acquisitions, we generally recognize assets for customer relationships, acquired technology, backlog, trade names, and non-compete agreements. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets, generally from one to 30 years. Amortization for acquired technology and backlog is recognized in cost of revenues, and amortization for customer relationships, trade names, non-compete agreements, and patents is recognized in selling, general, and administrative expenses.

[0000926326-21-000007:mdna:81]
We assess the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset’s carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. Our cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of our intangible assets are subjective and are affected by changes to our business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of our assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0000926326-21-000007:mdna:82]
Convertible Debt

[0000926326-21-000007:mdna:83]
We account for convertible debt and related transactions in accordance with ASC 470-20, Debt with Conversion and Other Options, ASC 815, Derivatives and Hedging, and ASC 480, Distinguishing Liabilities from Equity. We evaluate convertible debt instruments and related transactions at inception to determine if those contracts or embedded components of those contracts qualify as derivatives to be separately accounted for. Convertible debt instruments that may be settled in cash are separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. The difference between the principal amount of the convertible debt instruments and the liability component, inclusive of issuance costs, represents the debt discount, which is amortized to interest expense over the term of instruments. The determination of the discount rate requires certain estimates and assumptions.

[0000926326-21-000007:mdna:84]
Convertible note hedge and warrant transactions associated with convertible debt instruments are accounted for as equity instruments, and are recorded in additional paid-in capital in the Consolidated Balance Sheets.

[0000926326-21-000007:mdna:85]
Valuation of Share-Based Compensation

[0000926326-21-000007:mdna:86]
We account for share-based compensation in accordance with ASC 718, Stock Compensation. We recognize compensation expense related to share-based compensation based on the grant date estimated fair value.

[0000926326-21-000007:mdna:87]
The fair value of stock options (“options”) on the grant date is estimated using the Black-Scholes option pricing model, which requires the following inputs: expected life, expected volatility, risk-free interest rate, expected dividend yield rate, exercise price, and closing price of our common stock on the date of grant. The expected volatility is based on a combination of historical and market-based implied volatility, and the expected life of the awards is based on our historical experience of employee stock option exercises, including forfeitures. Expense is recognized on a straight-line basis over the requisite service period.

[0000926326-21-000007:mdna:88]
The fair value of restricted stock units (“RSUs”) is based on the stock price on the grant date. The fair value of restricted stock awards (“RSAs”) is their intrinsic value, which is the difference between the fair value of the underlying stock at the measurement date and the purchase price. The RSUs and RSAs are subject to a service vesting condition and are recognized on a straight-line basis over the requisite service period.

[0000926326-21-000007:mdna:89]
The fair value of performance-based stock unit awards (“PSUs”) with service and market conditions is estimated using a Monte Carlo simulation model applying multiple awards approach. Expense is recognized when it is probable that the performance condition will be met using the accelerated attribution method over the requisite service period.

[0000926326-21-000007:mdna:90]
Forfeiture rates are estimated based on our historical experience with equity awards that were granted and forfeited prior to vesting. The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods.

[0000926326-21-000007:mdna:91]
Accounting for Income Taxes

[0000926326-21-000007:mdna:92]
We record an income tax provision for (benefit from) the anticipated tax consequences of the reported results of operations. In accordance with ASC 740, Income Taxes, the provision for (benefit from) income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, we will incur a benefit or detriment on our income tax expense in the period of change. If we were to determine that all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-21-000007:mdna:93]
In accordance with ASC 740, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of ASC 740 and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.

[0000926326-21-000007:mdna:94]
Recently Issued Authoritative Guidance

[0000926326-21-000007:mdna:95]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Consolidated Financial Statements in this annual report on Form 10-K for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-21-000007:mdna:96]
RESULTS OF OPERATIONS

[0000926326-21-000007:mdna:97]
Total Revenues

[0000926326-21-000007:mdna:98]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Product revenues | $ | 636,031 |  |  | $ | 659,602 |  |  | $ | (23,571) |  |  | (4)% |  |  |  |  |  |  |
| Percentage of total revenues | 71% |  | 74% |  |  |  |  |  |  |  |  |  |  |
| Services and other revenues | 256,177 |  |  | 237,425 |  |  | 18,752 |  |  | 8% |  |  |  |  |  |  |
| Percentage of total revenues | 29% |  | 26% |  |  |  |  |  |  |  |  |  |  |
| Total revenues | $ | 892,208 |  |  | $ | 897,027 |  |  | $ | (4,819) |  |  | (1)% |  |  |  |  |  |  |

[0000926326-21-000007:mdna:99]
Product revenues represented 71% and 74% of total revenues for the years ended December 31, 2020 and 2019, respectively. Product revenues decreased by $23.6 million, primarily due to the impact of the COVID-19 pandemic as health systems were focusing resources on COVID-19 essential activities during the second and third quarters of 2020.

[0000926326-21-000007:mdna:100]
Services and other revenues represented 29% and 26% of total revenues for the years ended December 31, 2020 and 2019, respectively. Services and other revenues include revenues from technical services, SaaS, subscription software, and technology-enabled services, and other services. Services and other revenues increased by $18.8 million, primarily due to revenues of $10.2 million from the newly-acquired 340B Link Business, as well as continued growth in our installed customer base.

[0000926326-21-000007:mdna:101]
Our international sales represented 11% and 10% of total revenues for the years ended December 31, 2020 and 2019, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-21-000007:mdna:102]
Our ability to continue to grow revenues is dependent on our ability to continue to obtain orders from customers, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-21-000007:mdna:103]
The effects of the COVID-19 pandemic have had an adverse impact on our revenues for the year ended December 31, 2020. During the first half of 2020, we experienced delays in implementations and lower product bookings compared to management’s expectations prior to the COVID-19 outbreak. Starting in the third quarter of 2020, we began to see our customers returning to pre-pandemic purchasing patterns consistent with long-term strategic investments. Future developments with respect to the COVID-19 pandemic remain uncertain and may impact future periods.

[0000926326-21-000007:mdna:104]
Cost of Revenues and Gross Profit

[0000926326-21-000007:mdna:105]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which account for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site and include costs of the field installation personnel, including labor, travel expenses, and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory, and amortization of software development costs and intangibles.

[0000926326-21-000007:mdna:106]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 354,004 |  |  | $ | 344,914 |  |  | $ | 9,090 |  |  | 3% |  |  |  |  |  |  |
| As a percentage of related revenues | 56% |  | 52% |  |  |  |  |  |  |  |  |  |  |
| Cost of services and other revenues | 124,912 |  |  | 115,201 |  |  | 9,711 |  |  | 8% |  |  |  |  |  |  |
| As a percentage of related revenues | 49% |  | 49% |  |  |  |  |  |  |  |  |  |  |
| Total cost of revenues | $ | 478,916 |  |  | $ | 460,115 |  |  | $ | 18,801 |  |  | 4% |  |  |  |  |  |  |
| As a percentage of total revenues | 54% |  | 51% |  |  |  |  |  |  |  |  |  |  |
| Gross profit | $ | 413,292 |  |  | $ | 436,912 |  |  | $ | (23,620) |  |  | (5)% |  |  |  |  |  |  |
| Gross margin | 46% |  | 49% |  |  |  |  |  |  |  |  |  |  |

[0000926326-21-000007:mdna:107]
Cost of revenues for the year ended December 31, 2020 compared to the year ended December 31, 2019 increased by $18.8 million, of which $9.1 million was attributed to the increase in cost of product revenues and $9.7 million was attributed to the increase in cost of services and other revenues.

[0000926326-21-000007:mdna:108]
The increase in cost of product revenues is reflective of investments made to drive the customer experience and support expected annual revenue levels which were impacted by the COVID-19 pandemic. While product revenues decreased by $23.6 million for the year ended December 31, 2020 compared to the year ended December 31, 2019, cost of product revenues increased by $9.1 million primarily due to certain fixed costs, such as labor and overhead. The increase in cost of product revenues was also driven by an increase of $4.1 million of amortization of capitalized software development costs for

[0000926326-21-000007:mdna:109]
external use and an increase of $2.0 million in employee-related expenses related to restructuring initiatives, partially offset by cost-saving initiatives.

[0000926326-21-000007:mdna:110]
The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $18.8 million, including incremental revenues from the newly-acquired 340B Link Business, for the year ended December 31, 2020 compared to the year ended December 31, 2019, as well as additional investments in our service business to support new product offerings, an increase of $1.4 million of amortization of capitalized software development costs for external use, and an increase of $0.6 million in employee-related expenses related to restructuring initiatives.

[0000926326-21-000007:mdna:111]
The overall decrease in gross margin primarily relates to lower revenues during the year ended December 31, 2020 due to the impact of the COVID-19 pandemic, employee-related expenses related to restructuring initiatives, and additional investments in our business, including increased amortization of capitalized software development costs for external use, partially offset by lower costs associated with cost-saving initiatives. Our gross profit for the year ended December 31, 2020 was $413.3 million compared to $436.9 million for the year ended December 31, 2019.

[0000926326-21-000007:mdna:112]
The effects of the COVID-19 pandemic have had an adverse impact on our cost of revenues and gross margins for the year ended December 31, 2020. Future developments with respect to the COVID-19 pandemic remain uncertain and may impact future periods.

[0000926326-21-000007:mdna:113]
Operating Expenses and Interest and Other Income (Expense), Net

[0000926326-21-000007:mdna:114]
|  | Year Ended December 31, |  | Change in |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |  |  |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 70,161 |  |  | $ | 68,644 |  |  | $ | 1,517 |  |  | 2% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 307,605 |  |  | 289,916 |  |  | 17,689 |  |  | 6% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 34% |  | 32% |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 377,766 |  |  | $ | 358,560 |  |  | $ | 19,206 |  |  | 5% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 42% |  | 40% |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense), net | $ | (6,177) |  |  | $ | (4,419) |  |  | $ | (1,758) |  |  | 40% |  |  |  |  |  |  |  |  |

[0000926326-21-000007:mdna:115]
Research and Development. Research and development expenses increased by $1.5 million for the year ended December 31, 2020 compared to the year ended December 31, 2019. The increase was primarily attributed to an increase of $3.7 million in employee-related expenses related to restructuring initiatives as well as timing of projects, partially offset by lower consulting expenses and reduced travel costs.

[0000926326-21-000007:mdna:116]
Selling, General, and Administrative. Selling, general, and administrative expenses increased $17.7 million for the year ended December 31, 2020 compared to the year ended December 31, 2019, primarily due to overall growth of operations and increase in overall headcount. The increase was primarily due to an increase of $26.1 million in employee-related expenses primarily related to increased headcount, including the incremental headcount from the 340B Link Business acquisition, an increase of $3.7 million in employee-related expenses related to restructuring initiatives, and an increase of $6.5 million in acquisition-related expenses, partially offset by approximately $18.2 million of certain cost savings, including reduced travel, meetings, trade shows, and commission expenses.

[0000926326-21-000007:mdna:117]
In response to the COVID-19 pandemic, we implemented cost reduction initiatives in all aspects of our business and remain mindful of the uncertainty related to the pandemic.

[0000926326-21-000007:mdna:118]
Interest and Other Income (Expense), Net. Interest and other income (expense), net, changed by $1.8 million for the year ended December 31, 2020 compared to the year ended December 31, 2019, primarily driven by a $1.6 million increase in other expenses. The increase in other expenses is primarily due to $5.1 million of amortization of discount and interest expense incurred on our convertible senior notes issued in September 2020, partially offset by a decrease of $3.1 million in interest expense on our credit facilities as a result of a lower outstanding balances during the year ended December 31, 2020 as compared to the year ended December 31, 2019, as well as favorable foreign currency fluctuations during the period.

[0000926326-21-000007:mdna:119]
Provision for (Benefit from) Income Taxes

[0000926326-21-000007:mdna:120]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2020 |  | 2019 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (2,845) |  |  | $ | 12,595 |  |  | $ | (15,440) |  |  | (123)% |  |  |  |  |  |  |
| Effective tax rate on earnings | (10)% |  | 17% |  |  |  |  |  |  |  |  |  |  |

[0000926326-21-000007:mdna:121]
We recorded a benefit for income taxes of $2.8 million and had a negative effective tax rate of 10% for the year ended December 31, 2020 compared to an income tax expense of $12.6 million and an effective tax rate of 17% for the year ended December 31, 2019. The 2020 annual effective tax rate differed from the statutory tax rate of 21%, and resulted in a decrease as compared to the 2019 annual effective tax rate, primarily due to a favorable impact of the excess tax benefit from equity-based compensation and research and development credits, partially offset by an unfavorable impact from non-deductible compensation and equity charges.

[0000926326-21-000007:mdna:122]
Refer to Note 17, Income Taxes, of the Notes to Consolidated Financial Statements included in this annual report on Form 10-K for more details.

[0000926326-21-000007:mdna:123]
LIQUIDITY AND CAPITAL RESOURCES

[0000926326-21-000007:mdna:124]
We had cash and cash equivalents of $485.9 million at December 31, 2020, compared to $127.2 million at December 31, 2019. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep accounts with major financial institutions.

[0000926326-21-000007:mdna:125]
Our cash position and working capital at December 31, 2020 and 2019 were as follows:

[0000926326-21-000007:mdna:126]
|  | December 31, |
|  | 2020 |  | 2019 |
|  | (In thousands) |
| Cash | $ | 485,928 |  |  | $ | 127,210 |  |
| Working Capital | $ | 552,991 |  |  | $ | 246,242 |  |

[0000926326-21-000007:mdna:127]
Our ratio of current assets to current liabilities was 3.0:1 at December 31, 2020 and 2.0:1 at December 31, 2019.

[0000926326-21-000007:mdna:128]
Sources of Cash

[0000926326-21-000007:mdna:129]
Credit Facilities

[0000926326-21-000007:mdna:130]
On January 5, 2016, we entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association, as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for a $200.0 million term loan facility (the “Prior Term Loan Facility”), and prior to the amendment discussed below, a $200.0 million revolving credit facility (the “Prior Revolving Credit Facility” and, together with the Prior Term Loan Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million.

[0000926326-21-000007:mdna:131]
On April 11, 2017 and December 26, 2017, we entered into amendments to the Prior Credit Agreement. Under these amendments, the Prior Revolving Credit Facility was increased from $200.0 million to $315.0 million and certain other modifications were made.

[0000926326-21-000007:mdna:132]
On November 15, 2019, we refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (as subsequently amended, as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. On November 15, 2019, the $80.0 million outstanding term loan balance under the Prior Facilities was transferred to the Current Revolving Credit Facility.

[0000926326-21-000007:mdna:133]
On September 22, 2020, the parties entered into an amendment (the “Amendment”) to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions described below, expand our flexibility to repurchase our common stock and make other restricted payments and replace the total net leverage covenant with a new secured net leverage covenant that requires us to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

[0000926326-21-000007:mdna:134]
As of December 31, 2020, there was no outstanding balance for the Current Revolving Credit Facility and we were in full compliance with all covenants. Refer to Note 9, Debt and Credit Agreements, of the Notes to Consolidated Financial Statements included in this annual report on Form 10-K. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-21-000007:mdna:135]
Convertible Senior Notes

[0000926326-21-000007:mdna:136]
On September 25, 2020, we completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. We received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted. Refer to Note 10, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this annual report on Form 10-K.

[0000926326-21-000007:mdna:137]
We used approximately $49.3 million of the net proceeds from the offering to pay the cost of the convertible note hedge transactions (partially offset by proceeds to the Company from the sale of the warrant transactions), approximately $53.0 million of the net proceeds to repurchase shares of our common stock from purchasers of the Notes, $150.0 million of the net proceeds to pay down outstanding borrowings under the Current Revolving Credit Facility, and $225.0 million for the acquisition of the 340B Link Business. We intend to use the remainder of the net proceeds from this offering for working capital and other general corporate purposes, which may include potential acquisitions, strategic transactions, and potential future repurchases of our common stock.

[0000926326-21-000007:mdna:138]
Distribution Agreement

[0000926326-21-000007:mdna:139]
On November 3, 2017, we entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC, and HSBC Securities (USA) Inc., as our sales agents, pursuant to which we may offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of our common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange. The registration statement under which the shares that could have been sold pursuant to the Distribution Agreement expired on November 3, 2020 and, accordingly, no additional sales will be made pursuant to the Distribution Agreement.

[0000926326-21-000007:mdna:140]
For the year ended December 31, 2019, we received gross proceeds of $38.5 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 460,000 shares of our common stock at an average price of approximately $83.81 per share.

[0000926326-21-000007:mdna:141]
For the year ended December 31, 2020, we did not sell any of our common stock under the Distribution Agreement.

[0000926326-21-000007:mdna:142]
Uses of Cash

[0000926326-21-000007:mdna:143]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, and other contractual obligations. We also expect a continued use of cash for potential acquisitions and acquisition-related activities, as well as repurchases of our common stock.

[0000926326-21-000007:mdna:144]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of December 31, 2020, which may result in additional use of cash. Refer to Note 15, Stock Repurchase Program, of the Notes to Consolidated Financial Statements included in this annual report on Form 10-K. In September 2020, we repurchased 749,300 shares of our common stock from purchasers of the Notes in the offering in privately negotiated transactions effected through one of the initial purchasers or its affiliate at an average price of $70.78 per share for an aggregate purchase price of approximately $53.0 million. The repurchases were made concurrently with the issuance of the Notes. The repurchases were separately authorized by the Board of Directors, and did not impact the total remaining for future purchases under the previously authorized stock purchase programs. There were no stock repurchases during the years ended December 31, 2020 and 2019

[0000926326-21-000007:mdna:145]
including under our stock repurchase programs, other than the separately-authorized one-time stock repurchase concurrent with the offering of the Notes in September 2020.

[0000926326-21-000007:mdna:146]
Based on our current business plan and product backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-21-000007:mdna:147]
We believe that our current financial position and resources will allow us to manage the anticipated impact of the COVID-19 pandemic on our business for the foreseeable future, including any potential changes in timing of revenue recognition or potential extensions in customer payments. However, the future impact of COVID-19 cannot be predicted with certainty and may increase our borrowing costs and other costs of capital and otherwise adversely affect our business, results of operations, financial condition, and liquidity.

[0000926326-21-000007:mdna:148]
Cash Flows

[0000926326-21-000007:mdna:149]
The following table summarizes, for the periods indicated, selected items in our Consolidated Statements of Cash Flows:

[0000926326-21-000007:mdna:150]
|  | Year Ended December 31, |
|  | 2020 |  | 2019 |  |  |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 185,870 |  |  | $ | 145,008 |  |  |  |
| Investing activities | (279,866) |  |  | (61,664) |  |  |  |
| Financing activities | 456,269 |  |  | (23,479) |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents | 437 |  |  | 153 |  |  |  |
| Net increase in cash and cash equivalents | $ | 362,710 |  |  | $ | 60,018 |  |  |  |

[0000926326-21-000007:mdna:151]
Operating Activities

[0000926326-21-000007:mdna:152]
We expect cash from our operating activities to fluctuate in future periods as a result of a number of factors, including the timing of our billings and collections, our operating results, and the timing of other liability payments.

[0000926326-21-000007:mdna:153]
Net cash provided by operating activities was $185.9 million for 2020, primarily consisting of net income of $32.2 million adjusted for non-cash items of $116.4 million and changes in assets and liabilities of $37.3 million. The non-cash items primarily consisted of depreciation and amortization expense of $61.1 million, share-based compensation expense of $44.7 million, amortization of operating lease right-of-use assets of $10.5 million, amortization of debt issuance costs of $1.6 million, amortization of discount on convertible senior notes of $4.8 million, and a change in deferred income taxes of $6.5 million. Changes in assets and liabilities include cash inflows from (i) a decrease in accounts receivable and unbilled receivables of $36.8 million primarily due to higher collections in the fourth quarter of 2020, (ii) a decrease in inventories of $12.4 million primarily due to timing of shipments and a focus on supply chain efficiencies, (iii) an increase in accrued compensation of $11.6 million primarily due to an increase in accrued commissions, as well as timing of payroll, (iv) an increase in deferred revenues of $7.6 million primarily due to the timing of shipments in order to meet customers’ implementation schedules and recognition of revenues for products requiring installation, (v) an increase in other long-term liabilities of $7.5 million primarily due to the deferral of certain payroll taxes related to the CARES Act, and (vi) an increase in accrued liabilities of $4.4 million. These cash inflows were partially offset by (i) a decrease in operating lease liabilities of $9.5 million, (ii) an increase in prepaid commissions of $8.1 million primarily due to an increase in bookings, (iii) an increase in other long-term assets of $7.7 million primarily due to an increase in unbilled receivables, (iv) an increase in other current assets of $6.4 million, (v) a decrease in accounts payables of $6.3 million primarily due to an overall decrease in spending, as well as timing of payments, (vi) an increase in investment in sales-type leases of $2.9 million, and (vii) an increase in prepaid expenses of $2.1 million.

[0000926326-21-000007:mdna:154]
Net cash provided by operating activities was $145.0 million for 2019, primarily consisting of net income of $61.3 million adjusted for non-cash items of $99.5 million offset by changes in assets and liabilities of $15.8 million. The non-cash items primarily consisted of depreciation and amortization expense of $53.6 million, share-based compensation expense of $34.0 million, amortization of operating lease right-of-use assets of $10.6 million, amortization of debt issuance costs of

[0000926326-21-000007:mdna:155]
$2.2 million, and a change in deferred income taxes of $1.3 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $21.5 million due to increased billings and the timing of billings and collections, (ii) a decrease in operating lease liabilities of $10.0 million, (iii) an increase in inventories of $8.1 million for inventory buildup in support of forecasted sales, (iv) an increase in investment in sales-type leases of $3.7 million, (v) an increase in prepaid commissions of $2.7 million, and (vi) an increase in other current assets of $2.0 million. These cash outflows were partially offset by (i) an increase in accounts payables of $7.9 million due to increased spending with vendors and increased consulting costs, (ii) an increase in other long-term liabilities of $6.0 million, (iii) an increase in deferred revenues of $5.4 million, (iv) a decrease in other long-term assets of $4.5 million, (v) an increase in accrued liabilities of $3.0 million, (vi) a decrease in prepaid expenses of $2.9 million, and (vii) an increase in accrued compensation of $2.5 million.

[0000926326-21-000007:mdna:156]
Investing Activities

[0000926326-21-000007:mdna:157]
Net cash used in investing activities was $279.9 million for 2020, which consisted of $225.0 million consideration paid for the acquisition of the 340B Link Business, capital expenditures of $22.8 million for property and equipment, and $32.0 million for costs of software development for external use.

[0000926326-21-000007:mdna:158]
Net cash used in investing activities was $61.7 million for 2019, which consisted of capital expenditures of $15.9 million for property and equipment, and $45.8 million for costs of software development for external use.

[0000926326-21-000007:mdna:159]
Financing Activities

[0000926326-21-000007:mdna:160]
Net cash provided by financing activities was $456.3 million for 2020, primarily due to proceeds of $559.7 million from the issuance of the Notes, net of issuance costs, proceeds of approximately $51.3 million from the sale of warrants in connection with the issuance of the Notes, $150.0 million of proceeds under the Current Revolving Credit Facility, $54.3 million in proceeds from employee stock option exercises and employee stock plan purchases, and a net increase in the customer funds balances of $4.0 million, partially offset by repayments of $200.0 million under the Current Revolving Credit Facility, $100.6 million for the purchase of the convertible note hedge in connection with the issuance of the Notes, $53.0 million for repurchases of our stock, $8.7 million in employees’ taxes paid related to restricted stock unit vesting, and payments for debt issuance costs related to the Current Revolving Credit Facility of $0.6 million.

[0000926326-21-000007:mdna:161]
Net cash used in financing activities was $23.5 million for 2019, primarily due to the repayment of $90.0 million of the Prior Facilities and the Current Revolving Credit Facility, $9.7 million in employees’ taxes paid related to restricted stock unit vesting, and payments of debt issuance costs of $2.3 million, partially offset by $40.7 million in proceeds from employee stock option exercises and employee stock plan purchases, and $37.8 million proceeds from sales of our common stock under the Distribution Agreement.

[0000926326-21-000007:mdna:162]
Contractual Obligations

[0000926326-21-000007:mdna:163]
Contractual obligations as of December 31, 2020 were as follows:

[0000926326-21-000007:mdna:164]
|  | Payments Due by Period |
|  | Total |  | 2021 |  | 2022 - 2023 |  | 2024 - 2025 |  | 2026 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 72,532 |  |  | $ | 15,290 |  |  | $ | 24,327 |  |  | $ | 15,493 |  |  | $ | 17,422 |  |
| Purchase obligations (2) | 72,751 |  |  | 69,893 |  |  | 2,338 |  |  | 479 |  |  | 41 |  |
| Convertible senior notes (3) | 582,148 |  |  | 1,398 |  |  | 2,875 |  |  | 577,875 |  |  | — |  |
| Total (4) | $ | 727,431 |  |  | $ | 86,581 |  |  | $ | 29,540 |  |  | $ | 593,847 |  |  | $ | 17,463 |  |

[0000926326-21-000007:mdna:165]
_________________________________________________

[0000926326-21-000007:mdna:166]
(1)Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 12, Lessee Leases, of the Notes to Consolidated Financial Statements included in this annual report on Form 10-K.

[0000926326-21-000007:mdna:167]
(2)We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. The amounts under such contracts are included in the table above because we believe that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials.

[0000926326-21-000007:mdna:168]
(3)We issued convertible senior notes in September 2020 that are due in September 2025. The obligations presented above include both principal and interest for these notes. Although these notes mature in 2025, they may be converted into cash and shares of our common stock prior to maturity if certain conditions are met. Any conversion prior to maturity can result in repayment of the principal amounts sooner than the scheduled repayment as indicated in the table above. Refer to Note 10, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this annual report on Form 10-K.

[0000926326-21-000007:mdna:169]
(4)Refer to Note 13, Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this annual report on Form 10-K.

[0000926326-21-000007:mdna:170]
Off-Balance Sheet Arrangements

[0000926326-21-000007:mdna:171]
As of December 31, 2020, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Exchange Act and the instructions thereto.
