# OMCL note change history — 0000926326-23-000014 → 0000926326-23-000031


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0000926326-23-000031:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2023, the Company had non-cancelable purchase commitments of $127.1 million, of which $106.9 million are expected to be paid within the year ending December 31, 2023.
  (was, 2023-05-05, similarity 0.9836):
[0000926326-23-000014:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2023, the Company had non-cancelable purchase commitments of $122.2 million, of which $110.0 million are expected to be paid within the year ending December 31, 2023.

- added (2023-08-04):
[0000926326-23-000031:note_history:2]
During the six months ended June 30, 2023, the Company did not incur any material expenses related to the previously disclosed ransomware incident. During the three months ended June 30, 2022, the Company incurred $12.5 million of expenses related to the ransomware incident, partially offset by $11.1 million of expected insurance recoveries. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred. For the three months ended June 30, 2022, the Company included net expenses of $0.2 million in cost of revenues and $1.2 million in selling, general, and administrative expenses in the Company’s Condensed Consolidated Statements of Operations.

- changed (2023-08-04):
[0000926326-23-000031:note_history:3]
As of June 30, 2023, the Company has incurred $13.6 million of cumulative expenses related to the ransomware incident since it was detected, partially offset by $11.1 million of insurance recoveries, of which $10.9 million have been received as of June 30, 2023.
  (was, 2023-05-05, similarity 0.6239):
[0000926326-23-000014:note_history:3]
During the three months ended March 31, 2023, the Company did not incur any material expenses related to the previously disclosed ransomware incident. As of March 31, 2023, the Company has incurred $13.6 million of cumulative expenses related to the ransomware incident since it was detected, partially offset by $11.1 million of insurance recoveries, of

- added (2023-08-04):
[0000926326-23-000031:note_history:4]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with its current legal proceedings based on its belief that any potential material loss, while

- added (2023-08-04):
[0000926326-23-000031:note_history:5]
reasonably possible, is not probable. Furthermore, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.

- removed (2023-08-04):
[0000926326-23-000014:note_history:6]
which $9.6 million have been received as of March 31, 2023. Expenses included costs to investigate and remediate the ransomware incident, as well as legal and other professional services, all of which were expensed as incurred.

- removed (2023-08-04):
[0000926326-23-000014:note_history:7]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. Outside of the matter discussed above, the Company has not recorded any material accrual for contingent liabilities associated with its current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0000926326-23-000031:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2023 and December 31, 2022, the results of operations and comprehensive income (loss) for the three and six months ended June 30, 2023 and 2022, and cash flows for the six months ended June 30, 2023 and 2022. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on March 1, 2023, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income (loss) for the three and six months ended June 30, 2023, and cash flows for the six months ended June 30, 2023 are not necessarily indicative of results that may be expected for the year ending December 31, 2023, or for any future period.
  (was, 2023-05-05, similarity 0.8193):
[0000926326-23-000014:note_history:8]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2023 and December 31, 2022, and the results of operations, comprehensive income (loss), and cash flows for the three months ended March 31, 2023 and 2022. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on March 1, 2023, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations, comprehensive income (loss), and cash flows for the three months ended March 31, 2023 are not necessarily indicative of results that may be expected for the year ending December 31, 2023, or for any future period.

- changed (2023-08-04):
[0000926326-23-000031:note_history:9]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of June 30, 2023, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.
  (was, 2023-05-05, similarity 0.6758):
[0000926326-23-000014:note_history:9]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of March 31, 2023, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0000926326-23-000031:note_history:10]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2023 and 2022:
  (was, 2023-05-05, similarity 0.9131):
[0000926326-23-000014:note_history:10]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2023 and 2022:

- changed (2023-08-04):
[0000926326-23-000031:note_history:11]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of debt issuance costs | $ | 772 |  |  | $ | 766 |  |  | $ | 1,543 |  |  | $ | 1,530 |  |
  (was, 2023-05-05, similarity 0.7193):
[0000926326-23-000014:note_history:11]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 771 |  |  | $ | 764 |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0000926326-23-000031:note_history:12]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2023 and December 31, 2022:
  (was, 2023-05-05, similarity 0.966):
[0000926326-23-000014:note_history:12]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2023 and December 31, 2022:

- changed (2023-08-04):
[0000926326-23-000031:note_history:13]
|  | June 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (6,886) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 568,114 |  |  | $ | 566,571 |  |
  (was, 2023-05-05, similarity 0.9777):
[0000926326-23-000014:note_history:13]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (7,658) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 567,342 |  |  | $ | 566,571 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-08-04):
[0000926326-23-000031:note_history:14]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo

- changed (2023-08-04):
[0000926326-23-000031:note_history:15]
Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.
  (was, 2023-05-05, similarity 0.8714):
[0000926326-23-000014:note_history:15]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

- changed (2023-08-04):
[0000926326-23-000031:note_history:16]
On September 22, 2020, the parties entered into a first amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter. The availability of funds under the Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the A&R Credit Agreement.
  (was, 2023-05-05, similarity 0.9965):
[0000926326-23-000014:note_history:16]
On September 22, 2020, the parties entered into a first amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter. The availability of funds under the Revolving Credit Facility can be subject to reduction in order to maintain compliance with the financial covenants under the A&R Credit Agreement.

- changed (2023-08-04):
[0000926326-23-000031:note_history:17]
On March 29, 2023, the parties entered into a second amendment to the A&R Credit Agreement to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York (including a customary credit spread adjustment of 0.10% per annum) and related SOFR-based mechanics. The replacement of LIBOR did not, and the Company does not anticipate that it will, materially impact its liquidity or financial position.
  (was, 2023-05-05, similarity 0.8197):
[0000926326-23-000014:note_history:17]
On March 29, 2023, the parties entered into a second amendment to the A&R Credit Agreement to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York (including a customary credit spread

- changed (2023-08-04):
[0000926326-23-000031:note_history:18]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in compliance with all covenants as of June 30, 2023.
  (was, 2023-05-05, similarity 0.9974):
[0000926326-23-000014:note_history:18]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in compliance with all covenants as of March 31, 2023.

- changed (2023-08-04):
[0000926326-23-000031:note_history:19]
As of June 30, 2023 and December 31, 2022, the Company had $417.7 million and $500.0 million of funds available under the Revolving Credit Facility, respectively. As of June 30, 2023 and December 31, 2022, the Company had no outstanding balance under the Revolving Credit Facility. 
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025
  (was, 2023-05-05, similarity 0.6397):
[0000926326-23-000014:note_history:19]
As of March 31, 2023 and December 31, 2022, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- changed (2023-08-04):
[0000926326-23-000031:note_history:20]
During the three months ended June 30, 2023 and December 31, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the third quarter of 2023, commencing on July 1, 2023, and were not convertible during the first quarter of 2023, commencing on January 1, 2023, respectively. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of both June 30, 2023 and December 31, 2022. Whether the Notes will be convertible following the third fiscal quarter of 2023 will depend on the satisfaction of the conversion conditions in the future.
  (was, 2023-05-05, similarity 0.9647):
[0000926326-23-000014:note_history:20]
During the three months ended March 31, 2023 and December 31, 2022, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the second quarter of 2023, commencing on April 1, 2023, and were not convertible during the first quarter of 2023, commencing on January 1, 2023, respectively. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of both March 31, 2023 and December 31, 2022. Whether the Notes will be convertible following the second fiscal quarter of 2023 will depend on the satisfaction of the conversion conditions in the future.

- changed (2023-08-04):
[0000926326-23-000031:note_history:21]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2023, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2023-05-05, similarity 0.8349):
[0000926326-23-000014:note_history:21]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2023, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- changed (2023-08-04):
[0000926326-23-000031:note_history:22]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a
  (was, 2023-05-05, similarity 0.7324):
[0000926326-23-000014:note_history:22]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

- added (2023-08-04):
[0000926326-23-000031:note_history:23]
redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

- changed (2023-08-04):
[0000926326-23-000031:note_history:24]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of June 30, 2023, the remaining life of the Notes and the related issuance cost accretion is approximately 2.2 years.
  (was, 2023-05-05, similarity 0.9833):
[0000926326-23-000014:note_history:24]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of March 31, 2023, the remaining life of the Notes and the related issuance cost accretion is approximately 2.5 years.

- changed (2023-08-04):
[0000926326-23-000031:note_history:25]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of June 30, 2023, the if-converted value of the Notes did not exceed the principal amount.
  (was, 2023-05-05, similarity 0.983):
[0000926326-23-000014:note_history:25]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of March 31, 2023, the if-converted value of the Notes did not exceed the principal amount.

- changed (2023-08-04):
[0000926326-23-000031:note_history:26]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2023 and December 31, 2022:
  (was, 2023-05-05, similarity 0.966):
[0000926326-23-000014:note_history:26]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2023 and December 31, 2022:

- changed (2023-08-04):
[0000926326-23-000031:note_history:27]
|  | June 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (6,886) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 568,114 |  |  | $ | 566,571 |  |
  (was, 2023-05-05, similarity 0.9777):
[0000926326-23-000014:note_history:27]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (7,658) |  |  | (8,429) |  |
| Convertible senior notes, net | $ | 567,342 |  |  | $ | 566,571 |  |

- changed (2023-08-04):
[0000926326-23-000031:note_history:28]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2023 and 2022:
  (was, 2023-05-05, similarity 0.9131):
[0000926326-23-000014:note_history:28]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2023 and 2022:

- changed (2023-08-04):
[0000926326-23-000031:note_history:29]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of debt issuance costs | $ | 772 |  |  | $ | 766 |  |  | $ | 1,543 |  |  | $ | 1,530 |  |
  (was, 2023-05-05, similarity 0.7193):
[0000926326-23-000014:note_history:29]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 771 |  |  | $ | 764 |  |  |  |  |  |

- removed (2023-08-04):
[0000926326-23-000014:note_history:30]
adjustment of 0.10% per annum) and related SOFR-based mechanics. The replacement of LIBOR did not, and the Company does not anticipate that it will, materially impact its liquidity or financial position.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- removed (2023-08-04):
[0000926326-23-000014:note_history:31]
Revenue Recognition


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0000926326-23-000031:note_history:32]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.8 million and $4.0 million for the three months ended June 30, 2023 and 2022, respectively, and $5.9 million and $8.5 million for the six months ended June 30, 2023 and 2022, respectively.
  (was, 2023-05-05, similarity 0.9389):
[0000926326-23-000014:note_history:32]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $3.1 million and $4.5 million for the three months ended March 31, 2023 and 2022, respectively.

- changed (2023-08-04):
[0000926326-23-000031:note_history:33]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and six months ended June 30, 2023 and 2022:
  (was, 2023-05-05, similarity 0.9349):
[0000926326-23-000014:note_history:33]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three months ended March 31, 2023 and 2022:

- changed (2023-08-04):
[0000926326-23-000031:note_history:34]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 167,475 |  |  | $ | 215,632 |  |  | $ | 332,622 |  |  | $ | 423,710 |  |
| Consumables | 20,961 |  |  | 18,174 |  |  | 41,529 |  |  | 35,971 |  |
| Technical services | 57,191 |  |  | 53,303 |  |  | 110,548 |  |  | 102,472 |  |
| Advanced Services | 53,346 |  |  | 44,277 |  |  | 104,903 |  |  | 88,061 |  |
| Total revenues | $ | 298,973 |  |  | $ | 331,386 |  |  | $ | 589,602 |  |  | $ | 650,214 |  |
  (was, 2023-05-05, similarity 0.6288):
[0000926326-23-000014:note_history:34]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 165,147 |  |  | $ | 208,078 |  |  |  |  |  |
| Consumables | 20,568 |  |  | 17,797 |  |  |  |  |  |
| Technical services | 53,357 |  |  | 49,169 |  |  |  |  |  |
| Advanced Services | 51,557 |  |  | 43,784 |  |  |  |  |  |
| Total revenues | $ | 290,629 |  |  | $ | 318,828 |  |  |  |  |  |

- changed (2023-08-04):
[0000926326-23-000031:note_history:35]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2023 and 2022:
  (was, 2023-05-05, similarity 0.9539):
[0000926326-23-000014:note_history:35]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2023 and 2022:

- changed (2023-08-04):
[0000926326-23-000031:note_history:36]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  | (In thousands) |
| United States | $ | 257,202 |  |  | $ | 294,937 |  |  | $ | 513,145 |  |  | $ | 582,514 |  |
| Rest of world (1) | 41,771 |  |  | 36,449 |  |  | 76,457 |  |  | 67,700 |  |
| Total revenues | $ | 298,973 |  |  | $ | 331,386 |  |  | $ | 589,602 |  |  | $ | 650,214 |  |
  (was, 2023-05-05, similarity 0.714):
[0000926326-23-000014:note_history:36]
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
|  | (In thousands) |
| United States | $ | 255,943 |  |  | $ | 287,577 |  |  |  |  |  |
| Rest of world (1) | 34,686 |  |  | 31,251 |  |  |  |  |  |
| Total revenues | $ | 290,629 |  |  | $ | 318,828 |  |  |  |  |  |

- changed (2023-08-04):
[0000926326-23-000031:note_history:37]
|  | June 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 22,111 |  |  | $ | 25,763 |  |
| Long-term unbilled receivables, net (2) | 15,132 |  |  | 14,744 |  |
| Total contract assets | $ | 37,243 |  |  | $ | 40,507 |  |
| Short-term deferred revenues, net | $ | 124,602 |  |  | $ | 118,947 |  |
| Long-term deferred revenues | 48,750 |  |  | 37,385 |  |
| Total contract liabilities | $ | 173,352 |  |  | $ | 156,332 |  |
  (was, 2023-05-05, similarity 0.9882):
[0000926326-23-000014:note_history:37]
|  | March 31,2023 |  | December 31,2022 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 23,258 |  |  | $ | 25,763 |  |
| Long-term unbilled receivables, net (2) | 13,491 |  |  | 14,744 |  |
| Total contract assets | $ | 36,749 |  |  | $ | 40,507 |  |
| Short-term deferred revenues, net | $ | 143,298 |  |  | $ | 118,947 |  |
| Long-term deferred revenues | 42,438 |  |  | 37,385 |  |
| Total contract liabilities | $ | 185,736 |  |  | $ | 156,332 |  |

- changed (2023-08-04):
[0000926326-23-000031:note_history:38]
Short-term deferred revenues of $124.6 million and $118.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $13.6 million and $15.8 million, as of June 30, 2023 and December 31, 2022, respectively. During the three and six months ended June 30, 2023, the Company recognized revenues of $30.6 million and $86.1 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.7 million as of December 31, 2022. Long-term deferred revenues include deferred revenues from product sales and service contracts of $48.8 million and $37.4 million as of June 30, 2023 and December 31, 2022, respectively. Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, where services have not yet been provided. Short-term
  (was, 2023-05-05, similarity 0.9302):
[0000926326-23-000014:note_history:38]
Short-term deferred revenues of $143.3 million and $118.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $15.6 million and $15.8 million, as of March 31, 2023 and December 31, 2022, respectively. During the three months ended March 31, 2023, the Company recognized revenues of $55.5 million that were included in the corresponding gross short-term deferred revenues balance of $134.7 million as of December 31, 2022. Long-term deferred revenues include deferred revenues from product sales and service contracts of $42.4 million and $37.4 million as of March 31, 2023 and December 31, 2022, respectively. Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, where services have not yet been provided. Short-term deferred revenues are expected to be

- added (2023-08-04):
[0000926326-23-000031:note_history:39]
deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term service contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time.

- added (2023-08-04):
[0000926326-23-000031:note_history:40]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues are $288.7 million as of June 30, 2023. Remaining performance obligations are expected to be recognized ratably over the remaining term of the contract, which is generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

- changed (2023-08-04):
[0000926326-23-000031:note_history:41]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2023 and 2022. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of June 30, 2023 and December 31, 2022.
  (was, 2023-05-05, similarity 0.9048):
[0000926326-23-000014:note_history:41]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2023 and 2022. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2023 and December 31, 2022.

- removed (2023-08-04):
[0000926326-23-000014:note_history:42]
recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term service contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time.

- removed (2023-08-04):
[0000926326-23-000014:note_history:43]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues are $199.2 million as of March 31, 2023. Remaining performance obligations are expected to be recognized ratably over the remaining term of the contract, which is generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.
