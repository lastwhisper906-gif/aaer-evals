# OMCL MD&A — 0000926326-23-000031


## mdna

[0000926326-23-000031:mdna:1]
[same as prior period, unchanged from 0000926326-23-000014:mdna:1]

[0000926326-23-000031:mdna:2]
[same as prior period, unchanged from 0000926326-23-000014:mdna:2]

[0000926326-23-000031:mdna:3]
[same as prior period, unchanged from 0000926326-23-000014:mdna:3]

[0000926326-23-000031:mdna:4]
[same as prior period, unchanged from 0000926326-23-000014:mdna:4]

[0000926326-23-000031:mdna:5]
[same as prior period, unchanged from 0000926326-23-000014:mdna:5]

[0000926326-23-000031:mdna:6]
[same as prior period, unchanged from 0000926326-23-000014:mdna:6]

[0000926326-23-000031:mdna:7]
[same as prior period, unchanged from 0000926326-23-000014:mdna:7]

[0000926326-23-000031:mdna:8]
[same as prior period, unchanged from 0000926326-23-000014:mdna:8]

[0000926326-23-000031:mdna:9]
[same as prior period, unchanged from 0000926326-23-000014:mdna:9]

[0000926326-23-000031:mdna:10]
[same as prior period, unchanged from 0000926326-23-000014:mdna:10]

[0000926326-23-000031:mdna:11]
[same as prior period, unchanged from 0000926326-23-000014:mdna:11]

[0000926326-23-000031:mdna:12]
[same as prior period, unchanged from 0000926326-23-000014:mdna:12]

[0000926326-23-000031:mdna:13]
[same as prior period, unchanged from 0000926326-23-000014:mdna:13]

[0000926326-23-000031:mdna:14]
[same as prior period, unchanged from 0000926326-23-000014:mdna:14]

[0000926326-23-000031:mdna:15]
[same as prior period, unchanged from 0000926326-23-000014:mdna:15]

[0000926326-23-000031:mdna:16]
[same as prior period, unchanged from 0000926326-23-000014:mdna:16]

[0000926326-23-000031:mdna:17]
•our expected future uses of cash and the sufficiency of our sources of funding;

[0000926326-23-000031:mdna:18]
•our ability to generate cash from operations and our estimates regarding the sufficiency of our cash resources; and

[0000926326-23-000031:mdna:19]
•our expectations about the impact of epidemics, pandemics, or other major public health crises, such as the COVID-19 pandemic, and the associated containment measures, on our workforce and operations as well as those of our customers and suppliers, and the effect on our business, operating results, cash flow, or financial condition.

[0000926326-23-000031:mdna:20]
[same as prior period, unchanged from 0000926326-23-000014:mdna:20]

[0000926326-23-000031:mdna:21]
[same as prior period, unchanged from 0000926326-23-000014:mdna:21]

[0000926326-23-000031:mdna:22]
[same as prior period, unchanged from 0000926326-23-000014:mdna:22]

[0000926326-23-000031:mdna:23]
[same as prior period, unchanged from 0000926326-23-000014:mdna:23]

[0000926326-23-000031:mdna:24]
[same as prior period, unchanged from 0000926326-23-000014:mdna:24]

[0000926326-23-000031:mdna:25]
[same as prior period, unchanged from 0000926326-23-000014:mdna:25]

[0000926326-23-000031:mdna:26]
[same as prior period, unchanged from 0000926326-23-000014:mdna:26]

[0000926326-23-000031:mdna:27]
Facilities worldwide use our automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. Institutional and retail pharmacies across North America and the United Kingdom leverage our innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 86% and

[0000926326-23-000031:mdna:28]
89% of our total revenues for the three months ended June 30, 2023 and 2022, respectively, and 87% and 90% for the six months ended June 30, 2023 and 2022, respectively.

[0000926326-23-000031:mdna:29]
[same as prior period, unchanged from 0000926326-23-000014:mdna:28]

[0000926326-23-000031:mdna:30]
[same as prior period, unchanged from 0000926326-23-000014:mdna:29]

[0000926326-23-000031:mdna:31]
[same as prior period, unchanged from 0000926326-23-000014:mdna:30]

[0000926326-23-000031:mdna:32]
[same as prior period, unchanged from 0000926326-23-000014:mdna:31]

[0000926326-23-000031:mdna:33]
[same as prior period, unchanged from 0000926326-23-000014:mdna:32]

[0000926326-23-000031:mdna:34]
[same as prior period, unchanged from 0000926326-23-000014:mdna:33]

[0000926326-23-000031:mdna:35]
[same as prior period, unchanged from 0000926326-23-000014:mdna:34]

[0000926326-23-000031:mdna:36]
[same as prior period, unchanged from 0000926326-23-000014:mdna:35]

[0000926326-23-000031:mdna:37]
[same as prior period, unchanged from 0000926326-23-000014:mdna:36]

[0000926326-23-000031:mdna:38]
Our full-time employee headcount was approximately 3,780 and 4,230 on June 30, 2023 and December 31, 2022, respectively. The decrease in employee headcount reflects the impact of the restructuring plan announced in November 2022.

[0000926326-23-000031:mdna:39]
[same as prior period, unchanged from 0000926326-23-000014:mdna:38]

[0000926326-23-000031:mdna:40]
[same as prior period, unchanged from 0000926326-23-000014:mdna:39]

[0000926326-23-000031:mdna:41]
[same as prior period, unchanged from 0000926326-23-000014:mdna:40]

[0000926326-23-000031:mdna:42]
[same as prior period, unchanged from 0000926326-23-000014:mdna:41]

[0000926326-23-000031:mdna:43]
[same as prior period, unchanged from 0000926326-23-000014:mdna:42]

[0000926326-23-000031:mdna:44]
[same as prior period, unchanged from 0000926326-23-000014:mdna:43]

[0000926326-23-000031:mdna:45]
•Central Pharmacy and IV Compounding.  This market represents the beginning of the medication management process in acute care settings, and, we believe, it is a significant automation opportunity for high volumes of manual, repetitive, and error-prone processes that are often common in pharmacies today. Manual medication dispensing processes are usually labor intensive, error-prone, and may lead to excess medication waste and expirations for our healthcare partners. Automating the central pharmacy dispensing process should enable customers to reallocate pharmacy labor, enhance dispensing accuracy and patient safety, and reduce medication waste and expirations. Likewise, the manual compounding of sterile IV preparations can be error-prone and create significant patient safety risks, and outsourcing sterile IV compounding could lead to increased medication costs. As a result, we believe IV automation provides a significant opportunity to enhance patient safety and reduce costs. Because adoption of our Central Pharmacy and IV automation solution is still nascent, we believe that the implementation of new solutions (as well as upgrading older technology) will be accelerated by combining technology, expertise, and intelligence into a comprehensive offering that is designed to deliver improved outcomes. We anticipate that these bundled solutions will become more critical as health systems continue to face labor shortages, increased financial pressure, and supply chain disruptions.

[0000926326-23-000031:mdna:46]
[same as prior period, unchanged from 0000926326-23-000014:mdna:46]

[0000926326-23-000031:mdna:47]
[same as prior period, unchanged from 0000926326-23-000014:mdna:47]

[0000926326-23-000031:mdna:48]
[same as prior period, unchanged from 0000926326-23-000014:mdna:48]

[0000926326-23-000031:mdna:49]
[same as prior period, unchanged from 0000926326-23-000014:mdna:49]

[0000926326-23-000031:mdna:50]
[same as prior period, unchanged from 0000926326-23-000014:mdna:50]

[0000926326-23-000031:mdna:51]
[same as prior period, unchanged from 0000926326-23-000014:mdna:51]

[0000926326-23-000031:mdna:52]
[same as prior period, unchanged from 0000926326-23-000014:mdna:52]

[0000926326-23-000031:mdna:53]
[same as prior period, unchanged from 0000926326-23-000014:mdna:53]

[0000926326-23-000031:mdna:54]
[same as prior period, unchanged from 0000926326-23-000014:mdna:54]

[0000926326-23-000031:mdna:55]
[same as prior period, unchanged from 0000926326-23-000014:mdna:55]

[0000926326-23-000031:mdna:56]
[same as prior period, unchanged from 0000926326-23-000014:mdna:56]

[0000926326-23-000031:mdna:57]
[same as prior period, unchanged from 0000926326-23-000014:mdna:57]

[0000926326-23-000031:mdna:58]
[same as prior period, unchanged from 0000926326-23-000014:mdna:58]

[0000926326-23-000031:mdna:59]
[same as prior period, unchanged from 0000926326-23-000014:mdna:59]

[0000926326-23-000031:mdna:60]
[same as prior period, unchanged from 0000926326-23-000014:mdna:60]

[0000926326-23-000031:mdna:61]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the six months ended June 30, 2023 as compared to those disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in our Annual Report on Form 10-K for the year ended December 31, 2022, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000926326-23-000031:mdna:62]
[same as prior period, unchanged from 0000926326-23-000014:mdna:62]

[0000926326-23-000031:mdna:63]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-23-000031:mdna:64]
[same as prior period, unchanged from 0000926326-23-000014:mdna:64]

[0000926326-23-000031:mdna:65]
[same as prior period, unchanged from 0000926326-23-000014:mdna:65]

[0000926326-23-000031:mdna:66]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 188,436 |  |  | $ | 233,806 |  |  | $ | (45,370) |  |  | (19)% |
| Percentage of total revenues | 63% |  | 71% |  |  |  |  |
| Services and other revenues | 110,537 |  |  | 97,580 |  |  | 12,957 |  |  | 13% |
| Percentage of total revenues | 37% |  | 29% |  |  |  |  |
| Total revenues | $ | 298,973 |  |  | $ | 331,386 |  |  | $ | (32,413) |  |  | (10)% |

[0000926326-23-000031:mdna:67]
Product revenues represented 63% and 71% of total revenues for the three months ended June 30, 2023 and 2022, respectively. Product revenues decreased by $45.4 million, primarily due to lower revenues from our automated dispensing systems business primarily as a result of ongoing health systems capital budget and labor constraints.

[0000926326-23-000031:mdna:68]
Services and other revenues represented 37% and 29% of total revenues for the three months ended June 30, 2023 and 2022, respectively. Services and other revenues include revenues from technical services and Advanced Services offerings. Services and other revenues increased by $13.0 million, primarily due to increased customer demand for our Advanced Services and continued growth in our installed customer base as well as the impact of pricing actions.

[0000926326-23-000031:mdna:69]
Our international sales represented 14% and 11% of total revenues for the three months ended June 30, 2023 and 2022, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-23-000031:mdna:70]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 374,151 |  |  | $ | 459,681 |  |  | $ | (85,530) |  |  | (19)% |
| Percentage of total revenues | 63% |  | 71% |  |  |  |  |
| Services and other revenues | 215,451 |  |  | 190,533 |  |  | 24,918 |  |  | 13% |
| Percentage of total revenues | 37% |  | 29% |  |  |  |  |
| Total revenues | $ | 589,602 |  |  | $ | 650,214 |  |  | $ | (60,612) |  |  | (9)% |

[0000926326-23-000031:mdna:71]
Product revenues represented 63% and 71% of total revenues for the six months ended June 30, 2023 and 2022, respectively. Product revenues decreased by $85.5 million, primarily due to lower revenues from our automated dispensing systems business primarily as a result of ongoing health systems capital budget and labor constraints, partially offset by an increase of $5.6 million in revenues from consumables.

[0000926326-23-000031:mdna:72]
Services and other revenues represented 37% and 29% of total revenues for the six months ended June 30, 2023 and 2022, respectively. Services and other revenues include revenues from technical services and Advanced Services offerings. Services and other revenues increased by $24.9 million, primarily due to increased customer demand for our Advanced Services and continued growth in our installed customer base as well as the impact of pricing actions.

[0000926326-23-000031:mdna:73]
Our international sales represented 13% and 10% of total revenues for the six months ended June 30, 2023 and 2022, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-23-000031:mdna:74]
Our ability to grow revenues is dependent on our ability to continue to obtain orders from customers, which may be dependent upon customers’ capital equipment budgets and/or capital equipment approval cycles, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, our ability to develop new or enhance existing solutions, and our

[0000926326-23-000031:mdna:75]
flexibility in workforce allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules and/or staffing levels allow for installations.

[0000926326-23-000031:mdna:76]
[same as prior period, unchanged from 0000926326-23-000014:mdna:71]

[0000926326-23-000031:mdna:77]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which account for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product, and overhead costs associated with production; (ii) costs of providing services and installation costs, including costs of personnel and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, provisions for excess and obsolete inventory, and amortization of software development costs and intangibles.

[0000926326-23-000031:mdna:78]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 107,962 |  |  | $ | 121,814 |  |  | $ | (13,852) |  |  | (11)% |
| As a percentage of related revenues | 57% |  | 52% |  |  |  |  |
| Cost of services and other revenues | 56,568 |  |  | 51,480 |  |  | 5,088 |  |  | 10% |
| As a percentage of related revenues | 51% |  | 53% |  |  |  |  |
| Total cost of revenues | $ | 164,530 |  |  | $ | 173,294 |  |  | $ | (8,764) |  |  | (5)% |
| As a percentage of total revenues | 55% |  | 52% |  |  |  |  |
| Gross profit | $ | 134,443 |  |  | $ | 158,092 |  |  | $ | (23,649) |  |  | (15)% |
| Gross margin | 45% |  | 48% |  |  |  |  |

[0000926326-23-000031:mdna:79]
Cost of revenues for the three months ended June 30, 2023 compared to the three months ended June 30, 2022 decreased by $8.8 million, primarily driven by a $13.9 million decrease in cost of product revenues, partially offset by a $5.1 million increase in cost of services and other revenues.

[0000926326-23-000031:mdna:80]
The decrease in cost of product revenues was primarily driven by the decrease in product revenues of $45.4 million for the three months ended June 30, 2023 compared to the three months ended June 30, 2022. The decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues for the three months ended June 30, 2023, primarily due to certain fixed costs, such as labor and overhead. In addition, the decrease in cost of product revenues was also driven by lower inventory-related costs as pricing for semiconductors, steel, freight, and other costs has decreased from the prior period. The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $13.0 million for the three months ended June 30, 2023 compared to the three months ended June 30, 2022.

[0000926326-23-000031:mdna:81]
The overall decrease in gross margin primarily relates to lower product revenues for the three months ended June 30, 2023 whereas the decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues, primarily due to certain fixed costs, such as labor and overhead. The decrease is partially offset by continued growth in our services and other revenues, as well as lower inventory-related costs. Our gross profit for the three months ended June 30, 2023 was $134.4 million, as compared to $158.1 million for the three months ended June 30, 2022.

[0000926326-23-000031:mdna:82]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 217,489 |  |  | $ | 240,152 |  |  | $ | (22,663) |  |  | (9)% |
| As a percentage of related revenues | 58% |  | 52% |  |  |  |  |
| Cost of services and other revenues | 112,641 |  |  | 101,923 |  |  | 10,718 |  |  | 11% |
| As a percentage of related revenues | 52% |  | 53% |  |  |  |  |
| Total cost of revenues | $ | 330,130 |  |  | $ | 342,075 |  |  | $ | (11,945) |  |  | (3)% |
| As a percentage of total revenues | 56% |  | 53% |  |  |  |  |
| Gross profit | $ | 259,472 |  |  | $ | 308,139 |  |  | $ | (48,667) |  |  | (16)% |
| Gross margin | 44% |  | 47% |  |  |  |  |

[0000926326-23-000031:mdna:83]
Cost of revenues for the six months ended June 30, 2023 compared to the six months ended June 30, 2022 decreased by $11.9 million, primarily driven by a $22.7 million decrease in cost of product revenues, partially offset by a $10.7 million increase in cost of services and other revenues.

[0000926326-23-000031:mdna:84]
The decrease in cost of product revenues was primarily driven by the decrease in product revenues of $85.5 million for the six months ended June 30, 2023 compared to the six months ended June 30, 2022. The decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues for the six months ended June 30, 2023, primarily due to certain fixed costs, such as labor and overhead. The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $24.9 million for the six months ended June 30, 2023 compared to the six months ended June 30, 2022.

[0000926326-23-000031:mdna:85]
The overall decrease in gross margin primarily relates to lower product revenues for the six months ended June 30, 2023 whereas the decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues, primarily due to certain fixed costs, such as labor and overhead. The decrease is partially offset by continued growth in our services and other revenues. Our gross profit for the six months ended June 30, 2023 was $259.5 million, as compared to $308.1 million for the six months ended June 30, 2022.

[0000926326-23-000031:mdna:86]
[same as prior period, unchanged from 0000926326-23-000014:mdna:78]

[0000926326-23-000031:mdna:87]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 23,137 |  |  | $ | 26,355 |  |  | $ | (3,218) |  |  | (12)% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 103,558 |  |  | 119,252 |  |  | (15,694) |  |  | (13)% |
| As a percentage of total revenues | 35% |  | 36% |  |  |  |  |
| Total operating expenses | $ | 126,695 |  |  | $ | 145,607 |  |  | $ | (18,912) |  |  | (13)% |
| As a percentage of total revenues | 42% |  | 44% |  |  |  |  |
| Interest and other income (expense), net | $ | 4,461 |  |  | $ | (1,711) |  |  | $ | 6,172 |  |  | (361)% |

[0000926326-23-000031:mdna:88]
Research and Development. Research and development expenses decreased by $3.2 million for the three months ended June 30, 2023 compared to the three months ended June 30, 2022. The decrease was primarily driven by a decrease in consulting expenses of $2.0 million.

[0000926326-23-000031:mdna:89]
Selling, General, and Administrative. Selling, general, and administrative expenses decreased by $15.7 million for the three months ended June 30, 2023 compared to the three months ended June 30, 2022. The decrease was primarily due to a

[0000926326-23-000031:mdna:90]
decrease of $5.8 million in employee-related expenses due to lower headcount, as well as decreases in commission expenses of $1.7 million and consulting expenses of $1.7 million. The decrease is also driven by $3.3 million for impairment and abandonment charges of operating lease right-of-use and other assets in connection with restructuring activities of certain leased facilities and $1.2 million of ransomware-related expenses, net of insurance recoveries, incurred during the three months ended June 30, 2022.

[0000926326-23-000031:mdna:91]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $6.2 million for the three months ended June 30, 2023 compared to the three months ended June 30, 2022, primarily driven by a $5.7 million increase in other income and a $0.5 million decrease in other expense. The increase in other income during the three months ended June 30, 2023 as compared to the three months ended June 30, 2022 is primarily attributable to higher interest income received due to higher interest rates and higher cash balances.

[0000926326-23-000031:mdna:92]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 46,015 |  |  | $ | 51,385 |  |  | $ | (5,370) |  |  | (10)% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 228,672 |  |  | 239,185 |  |  | (10,513) |  |  | (4)% |
| As a percentage of total revenues | 39% |  | 37% |  |  |  |  |
| Total operating expenses | $ | 274,687 |  |  | $ | 290,570 |  |  | $ | (15,883) |  |  | (5)% |
| As a percentage of total revenues | 47% |  | 45% |  |  |  |  |
| Interest and other income (expense), net | $ | 6,242 |  |  | $ | (1,825) |  |  | $ | 8,067 |  |  | (442)% |

[0000926326-23-000031:mdna:93]
Research and Development. Research and development expenses decreased by $5.4 million for the six months ended June 30, 2023 compared to the six months ended June 30, 2022. The decrease was primarily attributed to a decrease of $1.1 million in employee-related expenses for restructuring initiatives and a decrease in consulting expenses of $3.1 million.

[0000926326-23-000031:mdna:94]
Selling, General, and Administrative. Selling, general, and administrative expenses decreased by $10.5 million for the six months ended June 30, 2023 compared to the six months ended June 30, 2022. The decrease was primarily due to a decrease of $6.5 million in employee-related expenses due to lower headcount, as well as decreases in commission expenses of $3.1 million, consulting expenses of $1.7 million, and travel expenses of $2.4 million. The decrease is also driven by $1.2 million of ransomware-related expenses, net of insurance recoveries, incurred during the six months ended June 30, 2022. The decrease is partially offset by an increase of $3.4 million in employee-related expenses for restructuring initiatives, as well as an increase of $2.7 million for impairment and abandonment charges of operating lease right-of-use and other assets in connection with restructuring activities of certain leased facilities.

[0000926326-23-000031:mdna:95]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $8.1 million for the six months ended June 30, 2023 compared to the six months ended June 30, 2022, primarily driven by a $7.6 million increase in other income and a $0.5 million decrease in other expense. The increase in other income during the six months ended June 30, 2023 as compared to the six months ended June 30, 2022 is primarily attributable to higher interest income received due to higher interest rates and higher cash balances.

[0000926326-23-000031:mdna:96]
35

[0000926326-23-000031:mdna:97]
[same as prior period, unchanged from 0000926326-23-000014:mdna:83]

[0000926326-23-000031:mdna:98]
|  | Three Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Benefit from income taxes | $ | 8,758 |  |  | $ | 1,705 |  |  | $ | 7,053 |  |  | 414% |

[0000926326-23-000031:mdna:99]
|  | Six Months Ended June 30, |
|  |  |  |  |  | Change in |
|  | 2023 |  | 2022 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 2,576 |  |  | $ | (1,538) |  |  | $ | 4,114 |  |  | (267)% |

[0000926326-23-000031:mdna:100]
For the six months ended June 30, 2023, we recorded a provision for income taxes of $2.6 million by applying our estimated annual effective tax rate to our year-to-date measure of ordinary income and adjusted for $2.7 million of discrete income tax expense primarily from equity compensation. Benefit from income taxes for the six months ended June 30, 2022 was $1.5 million and included a net discrete income tax benefit of $5.3 million, primarily due to a $5.1 million tax benefit from equity compensation. The change in the provision for income taxes for the six months ended June 30, 2023 compared to the benefit from income taxes for the same period in 2022 was primarily due to a decrease in excess tax benefit from equity compensation.

[0000926326-23-000031:mdna:101]
[same as prior period, unchanged from 0000926326-23-000014:mdna:86]

[0000926326-23-000031:mdna:102]
[same as prior period, unchanged from 0000926326-23-000014:mdna:87]

[0000926326-23-000031:mdna:103]
We had cash and cash equivalents of $399.5 million at June 30, 2023 compared to $330.4 million at December 31, 2022. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with major financial institutions of high credit quality.

[0000926326-23-000031:mdna:104]
Our cash position and working capital at June 30, 2023 and December 31, 2022 were as follows:

[0000926326-23-000031:mdna:105]
|  | June 30,2023 |  | December 31,2022 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 399,464 |  |  | $ | 330,362 |  |
| Working capital | $ | 511,204 |  |  | $ | 453,366 |  |

[0000926326-23-000031:mdna:106]
Our ratio of current assets to current liabilities was 2.4:1 and 2.1:1 at June 30, 2023 and December 31, 2022, respectively.

[0000926326-23-000031:mdna:107]
[same as prior period, unchanged from 0000926326-23-000014:mdna:92]

[0000926326-23-000031:mdna:108]
Revolving Credit Facility

[0000926326-23-000031:mdna:109]
On November 15, 2019, we entered into an Amended and Restated Credit Agreement (as subsequently amended, as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded our 2016 senior secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.

[0000926326-23-000031:mdna:110]
On September 22, 2020, the parties entered into a first amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions described below, expand our flexibility to repurchase our common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that required us to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and requires us to maintain a consolidated secured net leverage ratio not to exceed 3.00:1 for the calendar quarters ending

[0000926326-23-000031:mdna:111]
thereafter. The availability of funds under the Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the A&R Credit Agreement.

[0000926326-23-000031:mdna:112]
On March 29, 2023, the parties entered into a second amendment to the A&R Credit Agreement to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics applicable to borrowings under the A&R Credit Agreement with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York (including a customary credit spread adjustment of 0.10% per annum) and related SOFR-based mechanics. The replacement of LIBOR did not, and we do not anticipate that it will, materially impact our liquidity or financial position.

[0000926326-23-000031:mdna:113]
As of June 30, 2023, we had $417.7 million of funds available and no outstanding balance under the Revolving Credit Facility. As of June 30, 2023, we were in compliance with all covenants under the A&R Credit Agreement. Refer to Note 9, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information. We expect to use future loans under the Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-23-000031:mdna:114]
[same as prior period, unchanged from 0000926326-23-000014:mdna:99]

[0000926326-23-000031:mdna:115]
[same as prior period, unchanged from 0000926326-23-000014:mdna:100]

[0000926326-23-000031:mdna:116]
The 2016 Repurchase Program has a total of $2.7 million remaining for future repurchases as of June 30, 2023, which may result in additional use of cash. There were no stock repurchases during the six months ended June 30, 2023. Refer to “Stock Repurchase Programs” under Note 15, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-23-000031:mdna:117]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-23-000031:mdna:118]
[same as prior period, unchanged from 0000926326-23-000014:mdna:103]

[0000926326-23-000031:mdna:119]
[same as prior period, unchanged from 0000926326-23-000014:mdna:104]

[0000926326-23-000031:mdna:120]
|  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 85,673 |  |  | $ | (25,547) |  |
| Investing activities | (28,457) |  |  | (25,550) |  |
| Financing activities | 7,465 |  |  | (33,571) |  |
| Effect of exchange rate changes on cash and cash equivalents | 148 |  |  | (2,123) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 64,829 |  |  | $ | (86,791) |  |

[0000926326-23-000031:mdna:121]
[same as prior period, unchanged from 0000926326-23-000014:mdna:106]

[0000926326-23-000031:mdna:122]
[same as prior period, unchanged from 0000926326-23-000014:mdna:107]

[0000926326-23-000031:mdna:123]
Net cash provided by operating activities was $85.7 million for the six months ended June 30, 2023, primarily consisting of a net loss of $11.5 million adjusted for non-cash items of $76.3 million and changes in assets and liabilities of $20.9 million. The non-cash items primarily consisted of depreciation and amortization expense of $44.1 million, share-based compensation expense of $28.1 million, impairment and abandonment of operating lease right-of-use assets related to facilities of $7.8 million, amortization of operating lease right-of-use assets of $4.2 million, amortization of debt issuance costs of $2.1 million, and a change in deferred income taxes of $11.0 million. Changes in assets and liabilities include cash inflows

[0000926326-23-000031:mdna:124]
primarily from (i) a decrease in accounts receivable and unbilled receivables of $26.5 million primarily due to the timing of billings, shipments, and collections, (ii) a decrease in inventories of $17.8 million primarily due to management of inventory levels to align with the current forecasted demand, (iii) an increase in deferred revenues of $16.5 million primarily due to an increase in billings for certain service and subscription offerings, (iv) a decrease in prepaid commissions of $4.7 million, and (v) a decrease in prepaid expenses of $3.6 million. These cash inflows were partially offset by (i) a decrease in accrued compensation of $21.0 million primarily due to a decrease in the accrual for restructuring initiatives, lower commissions, as well as timing of payroll and ESPP purchases, (ii) a decrease in accounts payable of $15.8 million primarily due to an overall decrease in spending, as well as timing of payments, (iii) a decrease in operating lease liabilities of $5.4 million, (iv) a decrease in accrued liabilities of $4.6 million, and (v) an increase in investment in sales-type leases of $1.7 million.

[0000926326-23-000031:mdna:125]
Net cash used in operating activities was $25.5 million for the six months ended June 30, 2022, primarily consisting of net income of $17.3 million adjusted for non-cash items of $80.9 million, offset by changes in assets and liabilities of $123.7 million. The non-cash items primarily consisted of depreciation and amortization expense of $43.0 million, share-based compensation expense of $33.4 million, amortization of operating lease right-of-use assets of $6.8 million, impairment and abandonment of operating lease right-of-use assets of $5.1 million, amortization of debt issuance costs of $2.1 million, and a change in deferred income taxes of $9.5 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $71.4 million primarily due to an increase in billings driven by overall business growth and the timing of shipments and collections, as well as the timing of invoicing due to the previously disclosed ransomware incident, (ii) an increase in inventories of $32.6 million primarily to support forecasted sales, including advanced purchases of certain components, such as semiconductors, as well as higher costs of inventory and timing of shipments, (iii) an increase in investment in sales-type leases of $12.5 million primarily due to the increase in sales-type lease revenues associated with Advanced Services products, (iv) a decrease in accrued compensation of $11.1 million primarily due to a decrease in accrued commissions and bonuses, (v) a decrease in operating lease liabilities of $7.2 million, (vi) a decrease in accounts payable of $3.1 million, and (vii) an increase in other current assets, net of funds held for customers, of $2.0 million. These cash outflows were partially offset by (i) a decrease in prepaid commissions of $6.0 million, (ii) an increase in accrued liabilities of $4.7 million, (iii) a decrease in prepaid expenses of $1.7 million, (iv) a decrease in other long-term assets of $1.5 million, (v) an increase in deferred revenues of $1.4 million, and (vi) an increase in other long-term liabilities of $1.0 million.

[0000926326-23-000031:mdna:126]
[same as prior period, unchanged from 0000926326-23-000014:mdna:111]

[0000926326-23-000031:mdna:127]
Net cash used in investing activities was $28.5 million for the six months ended June 30, 2023, which consisted of capital expenditures of $21.8 million for property and equipment, and $6.7 million for external-use software development costs.

[0000926326-23-000031:mdna:128]
Net cash used in investing activities was $25.6 million for the six months ended June 30, 2022, which consisted of $3.4 million consideration paid for the acquisition of Hub and Spoke Innovations, net of cash acquired, capital expenditures of $21.1 million for property and equipment, and $6.5 million for costs of software development for external use, partially offset by working capital adjustments from acquisitions of $5.5 million.

[0000926326-23-000031:mdna:129]
[same as prior period, unchanged from 0000926326-23-000014:mdna:114]

[0000926326-23-000031:mdna:130]
Net cash provided by financing activities was $7.5 million for the six months ended June 30, 2023, primarily due to $15.2 million in proceeds from employee stock option exercises and ESPP purchases, partially offset by $3.5 million in employees’ taxes paid related to restricted stock unit vesting and a net change in the customer funds balances of $4.3 million.

[0000926326-23-000031:mdna:131]
Net cash used in financing activities was $33.6 million for the six months ended June 30, 2022, primarily due to $52.2 million for repurchases of our stock and $8.5 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $21.1 million in proceeds from employee stock option exercises and ESPP purchases, and a net change in the customer funds balances of $6.0 million.

[0000926326-23-000031:mdna:132]
[same as prior period, unchanged from 0000926326-23-000014:mdna:117]

[0000926326-23-000031:mdna:133]
There have been no significant changes during the six months ended June 30, 2023 to the contractual obligations disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2022.

[0000926326-23-000031:mdna:134]
Contractual obligations as of June 30, 2023 were as follows:

[0000926326-23-000031:mdna:135]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2023 |  | 2024 - 2025 |  | 2026 - 2027 |  | 2028 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 53,193 |  |  | $ | 6,721 |  |  | $ | 22,052 |  |  | $ | 16,336 |  |  | $ | 8,084 |  |
| Purchase obligations (2) | 127,138 |  |  | 106,935 |  |  | 19,893 |  |  | 310 |  |  | — |  |
| Convertible senior notes (3) | 578,594 |  |  | 719 |  |  | 577,875 |  |  | — |  |  | — |  |
| Total (4) | $ | 758,925 |  |  | $ | 114,375 |  |  | $ | 619,820 |  |  | $ | 16,646 |  |  | $ | 8,084 |  |

[0000926326-23-000031:mdna:136]
[same as prior period, unchanged from 0000926326-23-000014:mdna:121]

[0000926326-23-000031:mdna:137]
[same as prior period, unchanged from 0000926326-23-000014:mdna:122]

[0000926326-23-000031:mdna:138]
[same as prior period, unchanged from 0000926326-23-000014:mdna:123]

[0000926326-23-000031:mdna:139]
[same as prior period, unchanged from 0000926326-23-000014:mdna:124]

[0000926326-23-000031:mdna:140]
(4)Refer to Note 13, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.
