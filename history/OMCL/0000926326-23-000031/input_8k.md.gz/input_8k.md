# OMCL 8-K — 0000926326-23-000027 filed 2023-08-01

## item codes, every 8-K on or before 2023-08-04

- 2023-08-03 0000926326-23-000029 — 5.02, 9.01
- 2023-08-01 0000926326-23-000027 — 2.02, 9.01
- 2023-07-11 0000926326-23-000025 — 5.02, 9.01
- 2023-06-26 0000926326-23-000022 — 5.02 — amendment of 0001104659-23-026700
- 2023-05-30 0001104659-23-066011 — 5.02, 9.01
- 2023-05-26 0000926326-23-000020 — 5.02, 5.07, 9.01
- 2023-05-15 0001104659-23-060768 — 5.02, 9.01
- 2023-05-02 0000926326-23-000011 — 2.02, 9.01
- 2023-04-03 0000926326-23-000009 — 1.01, 2.03, 9.01
- 2023-02-28 0001104659-23-026700 — 2.02, 2.05, 5.02, 9.01
- 2022-11-30 0000926326-22-000036 — 2.05
- 2022-11-02 0000926326-22-000031 — 2.02, 9.01
- 2022-10-21 0000926326-22-000029 — 5.03, 9.01
- 2022-09-20 0001104659-22-101566 — 7.01, 9.01
- 2022-09-20 0001104659-22-101360 — 7.01, 9.01
- 2022-08-04 0000926326-22-000025 — 2.02, 8.01, 9.01
- 2022-05-31 0000926326-22-000020 — 5.02, 5.07, 9.01
- 2022-05-24 0000926326-22-000016 — 5.02
- 2022-05-09 0000926326-22-000012 — 8.01
- 2022-04-28 0000926326-22-000009 — 2.02, 9.01
- 2022-03-01 0001104659-22-028681 — 5.02, 8.01, 9.01
- 2022-02-14 0000926326-22-000004 — 2.02, 9.01
- 2022-01-04 0000926326-22-000002 — 7.01, 9.01
- 2021-12-29 0001104659-21-154294 — 7.01, 9.01
- 2021-12-13 0000926326-21-000039 — 8.01
- 2021-12-02 0000926326-21-000037 — 7.01, 9.01
- 2021-11-02 0000926326-21-000031 — 2.02, 9.01
- 2021-09-09 0000926326-21-000028 — 7.01, 9.01
- 2021-07-29 0000926326-21-000024 — 2.02, 9.01
- 2021-07-26 0000926326-21-000022 — 7.01, 9.01
- 2021-07-12 0000926326-21-000019 — 5.02, 9.01
- 2021-05-28 0000926326-21-000015 — 5.07
- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2023-08-04

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-23-000027:8k_2_02:1]
EX-99.1
2
exhibit991q2-23.htm
EX-99.1

[0000926326-23-000027:8k_2_02:2]
Document

[0000926326-23-000027:8k_2_02:3]
Exhibit 99.1

[0000926326-23-000027:8k_2_02:4]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Senior Vice President, Investor Relations |  | 4220 North Freeway |
| 650-435-3318 |  | Fort Worth, TX 76137 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0000926326-23-000027:8k_2_02:5]
Omnicell Announces Second Quarter 2023 Results

[0000926326-23-000027:8k_2_02:6]
Total GAAP revenues of $299 million

[0000926326-23-000027:8k_2_02:7]
GAAP net income per diluted share of $0.08

[0000926326-23-000027:8k_2_02:8]
Non-GAAP net income per diluted share of $0.57

[0000926326-23-000027:8k_2_02:9]
FORT WORTH, Texas -- August 1, 2023 -- Omnicell, Inc. (NASDAQ:OMCL) (“Omnicell,” “we,” “our,” “us,” “management,” or the “Company”), a leader in transforming the pharmacy care delivery model, today announced results for its second quarter ended June 30, 2023.

[0000926326-23-000027:8k_2_02:10]
“Our second quarter results reflect sequential revenue and profit growth, as we exceeded our previously disclosed guidance ranges for total product and service revenues, non-GAAP EBITDA, and non-GAAP earnings per share,” said Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell. “We continue to make progress integrating our most recent acquisitions and executing go-to-market strategies for each. In addition, we believe our recent customer wins demonstrate the important role Omnicell plays in automating and modernizing global medication management infrastructure. We are maintaining what we believe is a prudent approach to managing the business and believe Omnicell will play a key role in addressing the labor constraints that so many of our customers continue to navigate. We remain focused on delivering mission-critical medication management solutions and long-term growth.”

[0000926326-23-000027:8k_2_02:11]
Financial Results

[0000926326-23-000027:8k_2_02:12]
Total GAAP revenues for the second quarter of 2023 were $299 million, down $32 million, or 10%, from the second quarter of 2022. The year-over-year decrease in total GAAP revenues reflects lower point-of-care revenues primarily as a result of ongoing health systems capital budget and labor constraints.

[0000926326-23-000027:8k_2_02:13]
Total GAAP net income for the second quarter of 2023 was $3 million, or $0.08 per diluted share. This compares to GAAP net income of $9 million, or $0.20 per diluted share, for the second quarter of 2022.

[0000926326-23-000027:8k_2_02:14]
Total non-GAAP net income for the second quarter of 2023 was $26 million, or $0.57 per diluted share. This compares to non-GAAP net income of $38 million, or $0.84 per diluted share, for the second quarter of 2022.

[0000926326-23-000027:8k_2_02:15]
Total non-GAAP EBITDA for the second quarter of 2023 was $47 million. This compares to non-GAAP EBITDA of $56 million for the second quarter of 2022.

[0000926326-23-000027:8k_2_02:16]
Balance Sheet

[0000926326-23-000027:8k_2_02:17]
As of June 30, 2023, Omnicell’s balance sheet reflected cash and cash equivalents of $399 million, total debt (net of unamortized debt issuance costs) of $568 million, and total assets of $2.19 billion. Cash flows provided by operating activities in the second quarter of 2023 totaled $73 million. This compares to cash flows used in operating activities totaling $10 million in the second quarter of 2022.

[0000926326-23-000027:8k_2_02:18]
As of June 30, 2023, the Company had $418 million of availability under its revolving credit facility, which availability is subject to reduction in order to maintain compliance with certain financial covenants under the revolving credit facility. As of June 30, 2023, the Company had no outstanding balance under the revolving credit facility.

[0000926326-23-000027:8k_2_02:19]
Updated 2023 Guidance

[0000926326-23-000027:8k_2_02:20]
For the full year 2023, the Company expects bookings to trend toward the lower end of the previously disclosed guidance range of $1.000 billion and $1.100 billion. The Company expects full year 2023 total revenues to be between $1.160 billion and $1.200 billion. The Company expects full year 2023 product revenues to be between $740 million and $760 million, and full year 2023 service revenues to be between $420 million and $440 million. The Company expects full year 2023 technical services revenues to be between $215 million and $225 million, and full year 2023 Advanced Services revenues to be between $205 million and $215 million. The Company expects full year 2023 non-GAAP EBITDA to be between $130 million and $145 million. The Company expects full year 2023 non-GAAP earnings per share to be between $1.75 and $2.00 per share.

[0000926326-23-000027:8k_2_02:21]
For the third quarter of 2023, the Company expects total revenues to be between $290 million and $300 million. The Company expects third quarter 2023 product revenues to be between $185 million and $190 million, and third quarter 2023 service revenues to be between $105 million and $110 million. The Company expects third quarter 2023 non-GAAP EBITDA to be between $31 million and $37 million. The Company expects third quarter 2023 non-GAAP earnings per share to be between $0.42 and $0.52 per share.

[0000926326-23-000027:8k_2_02:22]
The table below summarizes Omnicell’s third quarter and updated full year 2023 guidance outlined above.

[0000926326-23-000027:8k_2_02:23]
|  | Q3 2023 | 2023 |
| Bookings | Not provided | $1.000 billion - $1.100 billion |
| Total Revenues | $290 million - $300 million | $1.160 billion - $1.200 billion |
| Product Revenues | $185 million - $190 million | $740 million - $760 million |
| Service Revenues | $105 million - $110 million | $420 million - $440 million |
| Technical Services Revenues | Not provided | $215 million - $225 million |
| Advanced Services Revenues | Not provided | $205 million - $215 million |
| Non-GAAP EBITDA | $31 million - $37 million | $130 million - $145 million |
| Non-GAAP Earnings Per Share | $0.42 - $0.52 | $1.75 - $2.00 |

[0000926326-23-000027:8k_2_02:24]
The Company does not provide guidance for GAAP net income or GAAP earnings per share, nor a reconciliation of these forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures on a forward-looking basis because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These forward-looking non-GAAP financial measures do not include certain items, which may be significant, including, but not limited to, unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-23-000027:8k_2_02:25]
Omnicell Conference Call Information

[0000926326-23-000027:8k_2_02:26]
Omnicell will hold a conference call today, Tuesday, August 1, 2023 at 4:30 p.m. ET to discuss second quarter 2023 financial results. The conference call can be monitored by dialing 1-888-550-5424 within the U.S. or 1-646-960-0819 for all other locations. A link to the live and archived webcast will also be available on the Investor Relations section of Omnicell’s website at http://ir.omnicell.com/events-and-presentations/.

[0000926326-23-000027:8k_2_02:27]
__________________________________________________

[0000926326-23-000027:8k_2_02:28]
About Omnicell

[0000926326-23-000027:8k_2_02:29]
Since 1992, Omnicell has been committed to transforming the pharmacy care delivery model in an effort to optimize financial and clinical outcomes across all settings of care. Through a comprehensive portfolio of automation and advanced services, Omnicell is uniquely positioned to address evolving healthcare challenges, connect settings of care, and streamline the medication management process. Healthcare facilities worldwide partner with Omnicell to help increase operational efficiency, reduce medication errors, improve patient safety, and enhance patient engagement and adherence, helping to reduce costly hospital readmissions. To learn more, visit omnicell.com.

[0000926326-23-000027:8k_2_02:30]
From time to time, Omnicell may use the Company’s investor relations website and other online social media channels, including its Twitter handle www.twitter.com/omnicell, LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure (“Reg FD”).

[0000926326-23-000027:8k_2_02:31]
OMNICELL and the Omnicell logo are registered trademarks of Omnicell, Inc. or one of its subsidiaries.

[0000926326-23-000027:8k_2_02:32]
Forward-Looking Statements

[0000926326-23-000027:8k_2_02:33]
Use of Non-GAAP Financial Information

[0000926326-23-000027:8k_2_02:34]
This press release contains financial measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to revenues, gross profit, operating expenses, income from operations, net income, net income per diluted share, diluted shares, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results

[0000926326-23-000027:8k_2_02:35]
3

[0000926326-23-000027:8k_2_02:36]
and metrics because management considers them to be important supplemental measures of Omnicell’s performance and refers to such measures when analyzing Omnicell’s strategy and operations.

[0000926326-23-000027:8k_2_02:37]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within such period that directly drive operating income in such period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results: non-GAAP revenues excludes from its GAAP equivalent item a) below; non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items a), b), c), f), and h) below; non-GAAP operating expenses excludes from its GAAP equivalents items b), c), d), e), f), g) and h) below; non-GAAP income from operations and non-GAAP operating margin exclude from their GAAP equivalents items a), b), c), d), e), f), g) and h) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through i) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents items a), b), d), e), f), g), h) and i) below:

[0000926326-23-000027:8k_2_02:38]
a)Acquisition accounting impact related to deferred revenues. In connection with the acquisition of FDS Amplicare on September 9, 2021, we recorded a fair value adjustment to acquired deferred revenues as part of the purchase accounting in accordance with GAAP. The adjustment represents revenues that would have been recognized in the normal course of business by FDS Amplicare if the acquisition had not occurred, but was not recognized due to GAAP purchase accounting requirements. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0000926326-23-000027:8k_2_02:39]
b)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as it represents expenses that do not require cash settlement from Omnicell.

[0000926326-23-000027:8k_2_02:40]
c)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-23-000027:8k_2_02:41]
d)Acquisition-related expenses. We excluded from our non-GAAP results the expenses related to recent acquisitions, including amortization of representations and warranties insurance. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of acquisition activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of less acquisitive peer companies.

[0000926326-23-000027:8k_2_02:42]
e)Impairment and abandonment of operating lease right-of-use and other assets related to facilities. We excluded from our non-GAAP results the impairment and abandonment of certain operating lease right-of-use assets, as well as property and equipment, incurred in connection with restructuring activities for optimization of certain leased facilities. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-23-000027:8k_2_02:43]
f)Ransomware-related expenses, net of insurance recoveries. We excluded from our non-GAAP results the net expenses related to the previously disclosed ransomware incident identified by the Company on May 4, 2022. Expenses include costs to investigate and remediate the ransomware incident, as well as legal and other professional services, and are presented net of expected insurance recoveries. These expenses are unrelated to our ongoing operations and would not have otherwise been incurred by us in the normal course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-23-000027:8k_2_02:44]
g)Executives transition costs. We excluded from our non-GAAP results the executives transition costs associated with the departure of certain executive officers, primarily consisting of severance expenses. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that

[0000926326-23-000027:8k_2_02:45]
excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-23-000027:8k_2_02:46]
h)Severance-related expenses. We excluded from our non-GAAP results the expenses related to restructuring events. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-23-000027:8k_2_02:47]
i)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of term loan and revolving credit facilities, as well as the issuance of convertible senior notes. The costs include underwriting fees, original issue discount, ticking fees, and legal fees. These non-cash expenses are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-23-000027:8k_2_02:48]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving stock compensation plans or other items.

[0000926326-23-000027:8k_2_02:49]
We believe that the presentation of non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0000926326-23-000027:8k_2_02:50]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-23-000027:8k_2_02:51]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-23-000027:8k_2_02:52]
c)These non-GAAP financial measures are employed by management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting.

[0000926326-23-000027:8k_2_02:53]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-23-000027:8k_2_02:54]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-23-000027:8k_2_02:55]
i)While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-23-000027:8k_2_02:56]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-23-000027:8k_2_02:57]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0000926326-23-000027:8k_2_02:58]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of

[0000926326-23-000027:8k_2_02:59]
our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-23-000027:8k_2_02:60]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-23-000027:8k_2_02:61]
a)Omnicell’s equity incentive plans and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-23-000027:8k_2_02:62]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-23-000027:8k_2_02:63]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-23-000027:8k_2_02:64]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release as well as in Omnicell’s other reports filed with or furnished to the SEC.

[0000926326-23-000027:8k_2_02:65]
6

[0000926326-23-000027:8k_2_02:66]
Omnicell, Inc.

[0000926326-23-000027:8k_2_02:67]
Condensed Consolidated Statements of Operations

[0000926326-23-000027:8k_2_02:68]
(Unaudited, in thousands, except per share data)

[0000926326-23-000027:8k_2_02:69]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 188,436 |  |  | $ | 233,806 |  |  | $ | 374,151 |  |  | $ | 459,681 |  |
| Services and other revenues | 110,537 |  |  | 97,580 |  |  | 215,451 |  |  | 190,533 |  |
| Total revenues | 298,973 |  |  | 331,386 |  |  | 589,602 |  |  | 650,214 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 107,962 |  |  | 121,814 |  |  | 217,489 |  |  | 240,152 |  |
| Cost of services and other revenues | 56,568 |  |  | 51,480 |  |  | 112,641 |  |  | 101,923 |  |
| Total cost of revenues | 164,530 |  |  | 173,294 |  |  | 330,130 |  |  | 342,075 |  |
| Gross profit | 134,443 |  |  | 158,092 |  |  | 259,472 |  |  | 308,139 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 23,137 |  |  | 26,355 |  |  | 46,015 |  |  | 51,385 |  |
| Selling, general, and administrative | 103,558 |  |  | 119,252 |  |  | 228,672 |  |  | 239,185 |  |
| Total operating expenses | 126,695 |  |  | 145,607 |  |  | 274,687 |  |  | 290,570 |  |
| Income (loss) from operations | 7,748 |  |  | 12,485 |  |  | (15,215) |  |  | 17,569 |  |
| Interest and other income (expense), net | 4,461 |  |  | (1,711) |  |  | 6,242 |  |  | (1,825) |  |
| Income (loss) before income taxes | 12,209 |  |  | 10,774 |  |  | (8,973) |  |  | 15,744 |  |
| Provision for (benefit from) income taxes | 8,758 |  |  | 1,705 |  |  | 2,576 |  |  | (1,538) |  |
| Net income (loss) | $ | 3,451 |  |  | $ | 9,069 |  |  | $ | (11,549) |  |  | $ | 17,282 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.08 |  |  | $ | 0.21 |  |  | $ | (0.26) |  |  | $ | 0.39 |  |
| Diluted | $ | 0.08 |  |  | $ | 0.20 |  |  | $ | (0.26) |  |  | $ | 0.37 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 45,125 |  |  | 44,219 |  |  | 45,007 |  |  | 44,234 |  |
| Diluted | 45,472 |  |  | 46,260 |  |  | 45,007 |  |  | 47,121 |  |

[0000926326-23-000027:8k_2_02:70]
Omnicell, Inc.

[0000926326-23-000027:8k_2_02:71]
Condensed Consolidated Balance Sheets

[0000926326-23-000027:8k_2_02:72]
(Unaudited, in thousands)

[0000926326-23-000027:8k_2_02:73]
|  | June 30,2023 |  | December 31,2022 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 399,464 |  |  | $ | 330,362 |  |
| Accounts receivable and unbilled receivables, net | 273,899 |  |  | 299,469 |  |
| Inventories | 130,577 |  |  | 147,549 |  |
| Prepaid expenses | 23,514 |  |  | 27,070 |  |
| Other current assets | 53,907 |  |  | 77,362 |  |
| Total current assets | 881,361 |  |  | 881,812 |  |
| Property and equipment, net | 103,212 |  |  | 93,961 |  |
| Long-term investment in sales-type leases, net | 35,039 |  |  | 32,924 |  |
| Operating lease right-of-use assets | 27,698 |  |  | 38,052 |  |
| Goodwill | 735,523 |  |  | 734,274 |  |
| Intangible assets, net | 226,707 |  |  | 242,906 |  |
| Long-term deferred tax assets | 32,764 |  |  | 22,329 |  |
| Prepaid commissions | 54,777 |  |  | 59,483 |  |
| Other long-term assets | 96,791 |  |  | 105,017 |  |
| Total assets | $ | 2,193,872 |  |  | $ | 2,210,758 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 47,192 |  |  | $ | 63,389 |  |
| Accrued compensation | 52,475 |  |  | 73,455 |  |
| Accrued liabilities | 145,888 |  |  | 172,655 |  |
| Deferred revenues, net | 124,602 |  |  | 118,947 |  |
| Total current liabilities | 370,157 |  |  | 428,446 |  |
| Long-term deferred revenues | 48,750 |  |  | 37,385 |  |
| Long-term deferred tax liabilities | 1,511 |  |  | 2,095 |  |
| Long-term operating lease liabilities | 35,510 |  |  | 39,405 |  |
| Other long-term liabilities | 6,265 |  |  | 6,719 |  |
| Convertible senior notes, net | 568,114 |  |  | 566,571 |  |
| Total liabilities | 1,030,307 |  |  | 1,080,621 |  |
| Total stockholders’ equity | 1,163,565 |  |  | 1,130,137 |  |
| Total liabilities and stockholders’ equity | $ | 2,193,872 |  |  | $ | 2,210,758 |  |

[0000926326-23-000027:8k_2_02:74]
8

[0000926326-23-000027:8k_2_02:75]
Omnicell, Inc.

[0000926326-23-000027:8k_2_02:76]
Condensed Consolidated Statements of Cash Flows

[0000926326-23-000027:8k_2_02:77]
(Unaudited, in thousands)

[0000926326-23-000027:8k_2_02:78]
|  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |
| Operating Activities |  |  |  |
| Net income (loss) | $ | (11,549) |  |  | $ | 17,282 |  |
| Adjustments to reconcile net income (loss) to net cash provided by (used in) operating activities: |
| Depreciation and amortization | 44,054 |  |  | 43,017 |  |
| Loss on disposal of property and equipment | 993 |  |  | — |  |
| Share-based compensation expense | 28,131 |  |  | 33,421 |  |
| Deferred income taxes | (11,019) |  |  | (9,506) |  |
| Amortization of operating lease right-of-use assets | 4,225 |  |  | 6,801 |  |
| Impairment and abandonment of operating lease right-of-use assets related to facilities | 7,815 |  |  | 5,093 |  |
| Amortization of debt issuance costs | 2,091 |  |  | 2,079 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | 26,463 |  |  | (71,418) |  |
| Inventories | 17,820 |  |  | (32,625) |  |
| Prepaid expenses | 3,576 |  |  | 1,660 |  |
| Other current assets | 773 |  |  | (1,996) |  |
| Investment in sales-type leases | (1,707) |  |  | (12,465) |  |
| Prepaid commissions | 4,706 |  |  | 6,033 |  |
| Other long-term assets | 43 |  |  | 1,455 |  |
| Accounts payable | (15,806) |  |  | (3,130) |  |
| Accrued compensation | (20,980) |  |  | (11,118) |  |
| Accrued liabilities | (4,646) |  |  | 4,682 |  |
| Deferred revenues | 16,540 |  |  | 1,395 |  |
| Operating lease liabilities | (5,396) |  |  | (7,176) |  |
| Other long-term liabilities | (454) |  |  | 969 |  |
| Net cash provided by (used in) operating activities | 85,673 |  |  | (25,547) |  |
| Investing Activities |  |  |  |
| External-use software development costs | (6,685) |  |  | (6,543) |  |
| Purchases of property and equipment | (21,772) |  |  | (21,099) |  |
| Business acquisition, net of cash acquired | — |  |  | (3,392) |  |
| Purchase price adjustments from business acquisitions | — |  |  | 5,484 |  |
| Net cash used in investing activities | (28,457) |  |  | (25,550) |  |
| Financing Activities |  |  |  |
| Proceeds from issuances under stock-based compensation plans | 15,203 |  |  | 21,123 |  |
| Employees’ taxes paid related to restricted stock units | (3,465) |  |  | (8,470) |  |
| Change in customer funds, net | (4,273) |  |  | 5,986 |  |
| Stock repurchases | — |  |  | (52,210) |  |
| Net cash provided by (used in) financing activities | 7,465 |  |  | (33,571) |  |
| Effect of exchange rate changes on cash and cash equivalents | 148 |  |  | (2,123) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | 64,829 |  |  | (86,791) |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 352,835 |  |  | 355,620 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 417,664 |  |  | $ | 268,829 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |
| Cash and cash equivalents | $ | 399,464 |  |  | $ | 244,953 |  |
| Restricted cash included in other current assets | 18,200 |  |  | 23,876 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 417,664 |  |  | $ | 268,829 |  |

[0000926326-23-000027:8k_2_02:79]
Omnicell, Inc.

[0000926326-23-000027:8k_2_02:80]
Reconciliation of GAAP to Non-GAAP

[0000926326-23-000027:8k_2_02:81]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-23-000027:8k_2_02:82]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Reconciliation of GAAP revenues to non-GAAP revenues: |
| GAAP revenues | $ | 298,973 |  |  | $ | 331,386 |  |  | $ | 589,602 |  |  | $ | 650,214 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 302 |  |  | — |  |  | 680 |  |
| Non-GAAP revenues | $ | 298,973 |  |  | $ | 331,688 |  |  | $ | 589,602 |  |  | $ | 650,894 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit | $ | 134,443 |  |  | $ | 158,092 |  |  | $ | 259,472 |  |  | $ | 308,139 |  |
| GAAP gross margin | 45.0% |  | 47.7% |  | 44.0% |  | 47.4% |
| Share-based compensation expense | 2,268 |  |  | 2,160 |  |  | 4,276 |  |  | 4,404 |  |
| Amortization of acquired intangibles | 2,900 |  |  | 3,537 |  |  | 5,925 |  |  | 6,851 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 302 |  |  | — |  |  | 680 |  |
| Ransomware-related expenses, net of insurance recoveries | — |  |  | 222 |  |  | — |  |  | 222 |  |
| Severance-related expenses | 238 |  |  | — |  |  | 382 |  |  | 156 |  |
| Non-GAAP gross profit | $ | 139,849 |  |  | $ | 164,313 |  |  | $ | 270,055 |  |  | $ | 320,452 |  |
| Non-GAAP gross margin | 46.8% |  | 49.5% |  | 45.8% |  | 49.2% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 126,695 |  |  | $ | 145,607 |  |  | $ | 274,687 |  |  | $ | 290,570 |  |
| GAAP operating expenses % to total revenues | 42.4% |  | 43.9% |  | 46.6% |  | 44.7% |
| Share-based compensation expense | (11,821) |  |  | (15,053) |  |  | (23,855) |  |  | (29,017) |  |
| Amortization of acquired intangibles | (5,135) |  |  | (5,308) |  |  | (10,352) |  |  | (11,047) |  |
| Acquisition-related expenses | (246) |  |  | (263) |  |  | (492) |  |  | (1,658) |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) | — |  |  | (3,340) |  |  | (8,420) |  |  | (5,093) |  |
| Ransomware-related expenses, net of insurance recoveries | — |  |  | (1,152) |  |  | — |  |  | (1,152) |  |
| Executives transition costs | (841) |  |  | — |  |  | (841) |  |  | — |  |
| Severance-related expenses | (483) |  |  | — |  |  | (5,653) |  |  | (3,371) |  |
| Non-GAAP operating expenses | $ | 108,169 |  |  | $ | 120,491 |  |  | $ | 225,074 |  |  | $ | 239,232 |  |
| Non-GAAP operating expenses as a % of total non-GAAP revenues | 36.2% |  | 36.3% |  | 38.2% |  | 36.8% |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income from operations: |
| GAAP income (loss) from operations | $ | 7,748 |  |  | $ | 12,485 |  |  | $ | (15,215) |  |  | $ | 17,569 |  |
| GAAP operating income (loss) % to total revenues | 2.6% |  | 3.8% |  | (2.6)% |  | 2.7% |
| Share-based compensation expense | 14,089 |  |  | 17,213 |  |  | 28,131 |  |  | 33,421 |  |
| Amortization of acquired intangibles | 8,035 |  |  | 8,845 |  |  | 16,277 |  |  | 17,898 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 302 |  |  | — |  |  | 680 |  |
| Acquisition-related expenses | 246 |  |  | 263 |  |  | 492 |  |  | 1,658 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) | — |  |  | 3,340 |  |  | 8,420 |  |  | 5,093 |  |
| Ransomware-related expenses, net of insurance recoveries | — |  |  | 1,374 |  |  | — |  |  | 1,374 |  |
| Executives transition costs | 841 |  |  | — |  |  | 841 |  |  | — |  |
| Severance-related expenses | 721 |  |  | — |  |  | 6,035 |  |  | 3,527 |  |
| Non-GAAP income from operations | $ | 31,680 |  |  | $ | 43,822 |  |  | $ | 44,981 |  |  | $ | 81,220 |  |
| Non-GAAP operating margin (non-GAAP operating income as a % of total non-GAAP revenues) | 10.6% |  | 13.2% |  | 7.6% |  | 12.5% |

[0000926326-23-000027:8k_2_02:83]
10

[0000926326-23-000027:8k_2_02:84]
Omnicell, Inc.

[0000926326-23-000027:8k_2_02:85]
Reconciliation of GAAP to Non-GAAP

[0000926326-23-000027:8k_2_02:86]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-23-000027:8k_2_02:87]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |
| GAAP net income (loss) | $ | 3,451 |  |  | $ | 9,069 |  |  | $ | (11,549) |  |  | $ | 17,282 |  |
| Share-based compensation expense | 14,089 |  |  | 17,213 |  |  | 28,131 |  |  | 33,421 |  |
| Amortization of acquired intangibles | 8,035 |  |  | 8,845 |  |  | 16,277 |  |  | 17,898 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 302 |  |  | — |  |  | 680 |  |
| Acquisition-related expenses | 246 |  |  | 263 |  |  | 492 |  |  | 1,658 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) | — |  |  | 3,340 |  |  | 8,420 |  |  | 5,093 |  |
| Ransomware-related expenses, net of insurance recoveries | — |  |  | 1,374 |  |  | — |  |  | 1,374 |  |
| Executives transition costs | 841 |  |  | — |  |  | 841 |  |  | — |  |
| Severance-related expenses | 721 |  |  | — |  |  | 6,035 |  |  | 3,527 |  |
| Amortization of debt issuance costs | 1,046 |  |  | 1,041 |  |  | 2,091 |  |  | 2,079 |  |
| Tax effect of the adjustments above (b) | (2,287) |  |  | (3,185) |  |  | (7,173) |  |  | (6,786) |  |
| Non-GAAP net income | $ | 26,142 |  |  | $ | 38,262 |  |  | $ | 43,565 |  |  | $ | 76,226 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 45,472 |  |  | 46,260 |  |  | 45,007 |  |  | 47,121 |  |
| Shares - diluted non-GAAP (c) | 45,472 |  |  | 45,361 |  |  | 45,306 |  |  | 45,655 |  |
| GAAP net income (loss) per share - diluted | $ | 0.08 |  |  | $ | 0.20 |  |  | $ | (0.26) |  |  | $ | 0.37 |  |
| Share-based compensation expense | 0.31 |  |  | 0.38 |  |  | 0.62 |  |  | 0.73 |  |
| Amortization of acquired intangibles | 0.17 |  |  | 0.19 |  |  | 0.36 |  |  | 0.39 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |
| Acquisition-related expenses | 0.01 |  |  | 0.01 |  |  | 0.01 |  |  | 0.04 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities | — |  |  | 0.07 |  |  | 0.19 |  |  | 0.11 |  |
| Ransomware-related expenses, net of insurance recoveries | — |  |  | 0.03 |  |  | — |  |  | 0.03 |  |
| Executives transition costs | 0.02 |  |  | — |  |  | 0.02 |  |  | — |  |
| Severance-related expenses | 0.02 |  |  | — |  |  | 0.13 |  |  | 0.08 |  |
| Amortization of debt issuance costs | 0.02 |  |  | 0.02 |  |  | 0.05 |  |  | 0.05 |  |
| Non-GAAP dilutive shares impact from convertible note hedge transaction (c) | — |  |  | — |  |  | — |  |  | 0.01 |  |
| Tax effect of the adjustments above (b) | (0.06) |  |  | (0.07) |  |  | (0.16) |  |  | (0.15) |  |
| Non-GAAP net income per share - diluted | $ | 0.57 |  |  | $ | 0.84 |  |  | $ | 0.96 |  |  | $ | 1.67 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP EBITDA(d): |
| GAAP net income (loss) | $ | 3,451 |  |  | $ | 9,069 |  |  | $ | (11,549) |  |  | $ | 17,282 |  |
| Share-based compensation expense | 14,089 |  |  | 17,213 |  |  | 28,131 |  |  | 33,421 |  |
| Interest (income) and expense, net | (4,410) |  |  | (142) |  |  | (7,484) |  |  | (175) |  |
| Depreciation and amortization expense | 22,080 |  |  | 21,893 |  |  | 44,054 |  |  | 43,017 |  |
| Acquisition accounting impact related to deferred revenues | — |  |  | 302 |  |  | — |  |  | 680 |  |
| Acquisition-related expenses | 246 |  |  | 263 |  |  | 492 |  |  | 1,658 |  |
| Impairment and abandonment of operating lease right-of-use and other assets related to facilities (a) | — |  |  | 3,340 |  |  | 8,420 |  |  | 5,093 |  |
| Ransomware-related expenses, net of insurance recoveries | — |  |  | 1,374 |  |  | — |  |  | 1,374 |  |
| Executives transition costs | 841 |  |  | — |  |  | 841 |  |  | — |  |
| Severance-related expenses | 721 |  |  | — |  |  | 6,035 |  |  | 3,527 |  |
| Amortization of debt issuance costs | 1,046 |  |  | 1,041 |  |  | 2,091 |  |  | 2,079 |  |
| Provision for (benefit from) income taxes | 8,758 |  |  | 1,705 |  |  | 2,576 |  |  | (1,538) |  |
| Non-GAAP EBITDA | $ | 46,822 |  |  | $ | 56,058 |  |  | $ | 73,607 |  |  | $ | 106,418 |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA as a % of total non-GAAP revenues) | 15.7% |  | 16.9% |  | 12.5% |  | 16.3% |

[0000926326-23-000027:8k_2_02:88]
_________________________________________________

[0000926326-23-000027:8k_2_02:89]
(a)For the six months ended June 30, 2023, impairment charges of other assets were approximately $0.6 million related to property and equipment in connection with restructuring activities for optimization of certain leased facilities.

[0000926326-23-000027:8k_2_02:90]
(b)Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2023 and 2022.

[0000926326-23-000027:8k_2_02:91]
(c)For the three and six months ended June 30, 2022, non-GAAP diluted shares excluded approximately 0.9 million and 1.5 million shares, respectively, related to the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction.

[0000926326-23-000027:8k_2_02:92]
(d)Defined as earnings before interest income and expense, taxes, depreciation, amortization, and share-based compensation, as well as excluding certain other non-GAAP adjustments.

[0000926326-23-000027:8k_2_02:93]
12

[0000926326-23-000027:8k_2_02:94]
Omnicell, Inc.

[0000926326-23-000027:8k_2_02:95]
Reconciliation of GAAP to Non-GAAP

[0000926326-23-000027:8k_2_02:96]
(Unaudited, in thousands)

[0000926326-23-000027:8k_2_02:97]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Reconciliation of GAAP net cash provided by (used in) operating activities to non-GAAP free cash flow: |
| GAAP net cash provided by (used in) operating activities | $ | 72,903 |  |  | $ | (9,551) |  |  | $ | 85,673 |  |  | $ | (25,547) |  |
| External-use software development costs | (3,186) |  |  | (2,691) |  |  | (6,685) |  |  | (6,543) |  |
| Purchases of property and equipment | (11,631) |  |  | (9,610) |  |  | (21,772) |  |  | (21,099) |  |
| Non-GAAP free cash flow | $ | 58,086 |  |  | $ | (21,852) |  |  | $ | 57,216 |  |  | $ | (53,189) |  |
