# OMCL notes — 0000926326-14-000010


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000926326-14-000010:notes:1]
[same as prior period, unchanged from 0000926326-13-000016:notes:1]

[0000926326-14-000010:notes:2]
|  | Allowance for Credit Losses |  | Recorded Investmentin Sales-type Leases Gross |  | Recorded Investmentin Sales-type Leases Net |
| Credit loss disclosure for March 31, 2014: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | — |  |  | $ | — |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 169 |  |  | 17,123 |  |  | 16,954 |  |
| Ending balances: March 31, 2014 | $ | 169 |  |  | $ | 17,123 |  |  | $ | 16,954 |  |
| Credit loss disclosure for December 31, 2013: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | — |  |  | $ | — |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 167 |  |  | 16,884 |  |  | 16,717 |  |
| Ending balances: December 31, 2013 | $ | 167 |  |  | $ | 16,884 |  |  | $ | 16,717 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-14-000010:notes:3]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of March 31, 2014, the results of their operations, comprehensive income and cash flows for the three months ended March 31, 2014 and 2013. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2013.

[0000926326-14-000010:notes:4]
Our results of operations, comprehensive income and cash flows for the three months ended March 31, 2014 are not necessarily indicative of results that may be expected for the year ending December 31, 2014, or for any future period.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0000926326-14-000010:notes:5]
[same as prior period, unchanged from 0000926326-13-000016:notes:22]

[0000926326-14-000010:notes:6]
Cash and cash equivalents consist of the following significant asset investment classes as of March 31, 2014 and December 31, 2013 (in thousands):

[0000926326-14-000010:notes:7]
|  | March 31, 2014 |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | SecurityClassification |
| Cash | $ | 52,906 |  |  | $ | — |  |  | $ | — |  |  | $ | 52,906 |  |  | $ | 52,906 |  |  | N/A |
| Money market fund | 54,652 |  |  | — |  |  | — |  |  | 54,652 |  |  | 54,652 |  |  | Available for sale |
| Total cash and cash equivalents | $ | 107,558 |  |  | $ | — |  |  | $ | — |  |  | $ | 107,558 |  |  | $ | 107,558 |  |  |  |

[0000926326-14-000010:notes:8]
| c | December 31, 2013 |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | SecurityClassification |
| Cash | $ | 38,823 |  |  | $ | — |  |  | $ | — |  |  | $ | 38,823 |  |  | $ | 38,823 |  |  | N/A |
| Money market fund | 65,708 |  |  | — |  |  | — |  |  | 65,708 |  |  | 65,708 |  |  | Available for sale |
| Total cash and cash equivalents | $ | 104,531 |  |  | $ | — |  |  | $ | — |  |  | $ | 104,531 |  |  | $ | 104,531 |  |  |  |

[0000926326-14-000010:notes:9]
The money market fund is a daily-traded cash equivalent with a price of $1.00, making it a Level 1 asset class, and its carrying cost closely approximates fair value. As demand deposit (cash) balances vary with the timing of collections and payments, the money market fund can cover any surplus or deficit, and thus is considered Available-for-sale.  We did not hold any Level 2 and Level 3 assets or liabilities as of March 31, 2014 and December 31, 2013.

[0000926326-14-000010:notes:10]
The following table shows our financial assets measured at fair value, on a recurring basis, with money market funds recorded within cash and cash equivalents (in thousands):

[0000926326-14-000010:notes:11]
|  | Quoted Prices in ActiveMarkets for IdenticalInstruments (Level 1) |  | Total FairValue |
| Money market fund at March 31, 2014 | $ | 54,652 |  |  | $ | 54,652 |  |
| Money market fund at December 31, 2013 | $ | 65,708 |  |  | $ | 65,708 |  |


## us-gaap:CommitmentsDisclosureTextBlock

[0000926326-14-000010:notes:12]
[same as prior period, unchanged from 0000926326-13-000016:notes:30]

[0000926326-14-000010:notes:13]
We lease properties in California, Florida, Illinois, Tennessee, and the United Kingdom. We also have smaller rented offices in Strongsville, Ohio, the United Arab Emirates, the People's Republic of China and the Federal Republic of Germany.

[0000926326-14-000010:notes:14]
At March 31, 2014, the minimum payments under our operating leases for each of the five succeeding fiscal years were as follows (in thousands):

[0000926326-14-000010:notes:15]
| Remainder of 2014 | $ | 3,538 |  |
| 2015 | 5,408 |  |
| 2016 | 5,442 |  |
| 2017 | 5,178 |  |
| 2018 | 4,299 |  |
| Thereafter | 16,743 |  |
| Total | $ | 40,608 |  |

[0000926326-14-000010:notes:16]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. Our near-term commitments to our contract manufacturers and suppliers totaled $9.7 million as of March 31, 2014.


## us-gaap:DebtDisclosureTextBlock

[0000926326-14-000010:notes:17]
Credit Agreement

[0000926326-14-000010:notes:18]
In September 2013, we entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time party thereto. The Credit Agreement provides for a $75.0 million revolving credit facility with a $10.0 million letter of credit sub-limit. Loans under the Credit Agreement mature on September 25, 2018. The Credit Agreement permits us to request one or more increases in the aggregate commitments provided that such increases do not exceed $25.0 million in the aggregate. We expect to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. Our obligations under the Credit Agreement are guaranteed by certain of our domestic subsidiaries and secured by substantially all of our and the subsidiary guarantors’ assets. To date, we have not yet drawn any funds under the credit facility.

[0000926326-14-000010:notes:19]
Amounts drawn under the Credit Agreement bear interest, at our election, at a Eurodollar rate plus a margin of 1.75% per annum, or an alternate base rate equal to the highest of (a) the prime rate, (b) the federal funds rate plus 0.50%, and (c) LIBOR for an interest period of one month plus 1.75%. We are required to pay a commitment fee of 0.25% per annum on the aggregate undrawn amount of the commitments under the credit facility.

[0000926326-14-000010:notes:20]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each fiscal quarter. We were in full compliance with all covenants at March 31, 2014.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000926326-14-000010:notes:21]
[same as prior period, unchanged from 0000926326-13-000016:notes:45]

[0000926326-14-000010:notes:22]
[same as prior period, unchanged from 0000926326-13-000016:notes:47]

[0000926326-14-000010:notes:23]
[same as prior period, unchanged from 0000926326-13-000016:notes:48]

[0000926326-14-000010:notes:24]
For a detailed explanation of our stock plan and subsequent changes please refer back to our Note 16, Stock Option Plans, Share-Based Compensation and 401(k) Plan on our Annual Report on Form 10-K for the year ended December 31, 2013. At March 31, 2014, 2,457,760 shares of common stock were reserved for future issuance our 2009 Equity Incentive Plan, as amended (the "2009 Plan"), and $6.3 million of total unrecognized compensation cost related to non-vested stock options was expected to be recognized over a weighted average period of 2.8 years.

[0000926326-14-000010:notes:25]
A summary of option activity under the 2009 Plan for the three months ended March 31, 2014 is presented below:

[0000926326-14-000010:notes:26]
| Options: |  | Number of Shares |  | Weighted-Average Exercise Price |
|  |  | (in thousands) |  |  |
| Outstanding at December 31, 2013 |  | 3,143 |  |  | $ | 15.82 |  |
| Granted |  | 241 |  |  | $ | 25.43 |  |
| Exercised |  | (401 | ) |  | $ | 15.24 |  |
| Forfeited |  | (38 | ) |  | $ | 16.54 |  |
| Expired |  | (3 | ) |  | $ | 22.99 |  |
| Outstanding at March 31, 2014 |  | 2,942 |  |  | $ | 16.67 |  |
| Vested and expected to vest at March 31, 2014 |  | 2,909 |  |  | $ | 16.61 |  |
| Exercisable at March 31, 2014 |  | 1,810 |  |  | $ | 15.08 |  |

[0000926326-14-000010:notes:27]
The aggregate intrinsic value of our options is calculated as the difference between the exercise price of the underlying options and the quoted price of our common stock at the end of the reporting period. The aggregate intrinsic value of options exercised under our stock plans for the three months ended March 31, 2014 and March 31, 2013 was $11.4 million and $8.3 million, respectively, determined as of the date of option exercise.

[0000926326-14-000010:notes:28]
Restricted Stock and Restricted Stock Units

[0000926326-14-000010:notes:29]
A summary of activity of both restricted stock and RSUs for the three months ended March 31, 2014 is presented below:

[0000926326-14-000010:notes:30]
|  | Restricted Stock |  | Restricted Stock Units |
|  | Number ofShares |  | Weighted-AverageGrant DateFair Value PerShare |  | Number ofShares |  | Weighted-AverageGrant DateFair Value PerShare |
|  | (in thousands) |  |  |  | (in thousands) |  |  |
| Non-vested, December 31, 2013 | 52 |  |  | $ | 18.43 |  |  | 362 |  |  | $ | 17.15 |  |
| Granted | — |  |  | $ | — |  |  | 97 |  |  | $ | 25.54 |  |
| Vested | — |  |  | $ | — |  |  | (31 | ) |  | $ | 15.69 |  |
| Forfeited | — |  |  | $ | — |  |  | (14 | ) |  | $ | 15.45 |  |
| Non-vested, March 31, 2014 | 52 |  |  | $ | 18.43 |  |  | 414 |  |  | $ | 19.27 |  |

[0000926326-14-000010:notes:31]
The fair value of restricted stock is the product of the number of shares granted and the closing market price of our common stock on the grant date. Our unrecognized compensation cost related to non-vested restricted stock is approximately $7.2 million and is expected to be recognized over a weighted-average period of 2.8 years.

[0000926326-14-000010:notes:32]
[same as prior period, unchanged from 0000926326-13-000016:notes:63]

[0000926326-14-000010:notes:33]
Performance-based restricted stock units ("PSUs") are an element of our executive compensation plans. In 2012, we granted 125,000 PSUs to our executive officer of which 62,500 became eligible for vesting upon the achievement of a certain level of shareholder return for 2012 as described below. In 2013, we granted 137,500 PSUs to our executive officers, all of which became eligible for vesting upon the achievement of a certain level of shareholder return for the period from January 1, 2013 through February 28, 2014, as described below. In 2014, we granted 132,500 PSUs to our executive officers, all, none or a portion of which may become eligible for vesting depending on the level of shareholder return for 2014. For a more detailed explanation of our PSUs and subsequent changes, please refer back to our Note 16, Stock Option Plans, Share-Based Compensation and 401(k) Plan on our Annual Report on Form 10-K for the year ended December 31, 2013.

[0000926326-14-000010:notes:34]
Our unrecognized compensation cost related to non-vested performance-based restricted stock units at March 31, 2014 was approximately $2.8 million and is expected to be recognized over a weighted-average period of 1.5 years. For the three months ended March 31, 2014 and 2013, we recognized $0.5 million and $0.4 million, respectively, of compensation expense for the PSUs.

[0000926326-14-000010:notes:35]
[same as prior period, unchanged from 0000926326-13-000016:notes:73]

[0000926326-14-000010:notes:36]
[same as prior period, unchanged from 0000926326-13-000016:notes:74]

[0000926326-14-000010:notes:37]
On January 22, 2013, the Compensation Committee of our Board of Directors ("the Compensation Committee") confirmed 35.3% as the percentile rank of Omnicell's 2012 total stockholder return. This resulted in 50% of the 2012 PSU awards, or 62,500 shares, as eligible for further time-based vesting. The eligible performance-based restricted stock unit awards will vest as follows: 25% of the eligible shares vested immediately on January 22, 2013 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service.

[0000926326-14-000010:notes:38]
The following table shows the percent of PSUs granted in 2013 eligible for further time-based vesting based on our percentile placement:

[0000926326-14-000010:notes:39]
On March 20, 2014, the Compensation Committee confirmed 63.94% as the percentile rank of Omnicell's 2013-2014 total stockholder return. This resulted in 100% of the 2013 PSU awards, or 137,500 shares, as eligible for further time-based vesting. The eligible performance-based restricted stock unit awards will vest as follows: 25% of the eligible shares vested immediately on March 20, 2014 with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service.

[0000926326-14-000010:notes:40]
On February 5, 2014, the Compensation Committee approved PSU awards of 132,500 shares. If the minimum performance threshold is met as determined by the Compensation Committee in 2015, the eligible performance-based restricted stock unit awards will vest as follows: 25% of the eligible shares will vest immediately, with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service.

[0000926326-14-000010:notes:41]
A summary of activity of the PSUs for the three months ended March 31, 2014 is presented below:

[0000926326-14-000010:notes:42]
| Performance-based Stock Units | Number of Shares |  | Weighted-AverageGrant Date Fair Value PerShare |
|  | (in thousands) |  |  |
| Non-vested, December 31, 2013 | 225 |  |  | $ | 13.32 |  |
| Granted | 132 |  |  | $ | 16.59 |  |
| Vested | (34 | ) |  | $ | 14.81 |  |
| Forfeited | — |  |  | $ | — |  |
| Non-vested, March 31, 2014 | 323 |  |  | $ | 14.41 |  |

[0000926326-14-000010:notes:43]
1997 Employee Stock Purchase Plan

[0000926326-14-000010:notes:44]
We have an Employee Stock Purchase Plan (the “ESPP”) under which employees can purchase shares of our common stock based on a percentage of their compensation, but not greater than 15% of their earnings, up to a maximum of $25,000 of fair value per year. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-14-000010:notes:45]
At the 2009 Annual Meeting of Stockholders, the stockholders approved an amendment to the ESPP, which added 2,622,426 shares to the reserve for future issuance. As of March 31, 2014, there were 846,891 shares reserved for future issuance under the ESPP. For the three months ended March 31, 2014, 254,009 shares of common stock were purchased under the ESPP. As of March 31, 2014, 4,484,664 shares had been issued under the ESPP.

[0000926326-14-000010:notes:46]
As of March 31, 2014, our unrecognized compensation cost related to the shares to be purchased under our ESPP was approximately $1.4 million and is expected to be recognized over a weighted average period of 2.0 years.

[0000926326-14-000010:notes:47]
[same as prior period, unchanged from 0000926326-13-000016:notes:81]

[0000926326-14-000010:notes:48]
We account for share-based awards granted to employees and directors, including employee stock option awards, restricted stock, PSUs and RSUs issued pursuant to the 2009 Plan and employee stock purchases made under our ESPP using the estimated grant date fair value method of accounting in accordance with ASC 718, Stock Compensation.

[0000926326-14-000010:notes:49]
We value options and ESPP shares using the Black-Scholes-Merton option-pricing model. Restricted stock and time-based RSUs are valued at the grant date fair value of the underlying common shares. The PSUs are valued via Monte Carlo simulation.

[0000926326-14-000010:notes:50]
The impact on our results for share-based compensation was as follows (in thousands):

[0000926326-14-000010:notes:51]
|  | Three Months Ended March 31, |
|  | 2014 |  | 2013 |
| Cost of product and service revenues | $ | 268 |  |  | $ | 305 |  |
| Research and development expenses | 369 |  |  | 289 |  |
| Selling, general and administrative expenses | 2,092 |  |  | 2,332 |  |
| Total share-based compensation expenses | $ | 2,729 |  |  | $ | 2,926 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0000926326-14-000010:notes:52]
Basic net income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Since their impact is anti-dilutive, we excluded 347,265 and 1,865,589 shares from the calculations of diluted net income per share for the three months ended March 31, 2014 and 2013, respectively.


## us-gaap:EarningsPerShareTextBlock

[0000926326-14-000010:notes:53]
[same as prior period, unchanged from 0000926326-13-000016:notes:86]

[0000926326-14-000010:notes:54]
[same as prior period, unchanged from 0000926326-13-000016:notes:88]

[0000926326-14-000010:notes:55]
|  | Three Months Ended March 31, |
|  | 2014 |  | 2013 |
| Basic: |  |  |  |  |  |
| Net income | $ | 6,194 |  |  | $ | 3,385 |  |
| Weighted average shares outstanding — basic | 35,225 |  |  | 33,900 |  |
| Net income per share — basic | $ | 0.18 |  |  | $ | 0.10 |  |
| Diluted: |  |  |  |  |  |
| Net income | $ | 6,194 |  |  | $ | 3,385 |  |
| Weighted average shares outstanding — basic | 35,225 |  |  | 33,900 |  |
| Add: Dilutive effect of employee stock plans | 1,080 |  |  | 920 |  |
| Weighted average shares outstanding — diluted | 36,305 |  |  | 34,820 |  |
| Net income per share — diluted | $ | 0.17 |  |  | $ | 0.10 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-14-000010:notes:56]
Goodwill and Intangible Assets

[0000926326-14-000010:notes:57]
Goodwill

[0000926326-14-000010:notes:58]
Goodwill is tested for impairment on an annual basis and between annual tests if events or circumstances indicate that an impairment loss may have occurred, and we write down these assets when impaired. We perform our annual impairment tests during the fourth quarter of each fiscal year using the closing balance sheet as of the last day of the third quarter.

[0000926326-14-000010:notes:59]
During the three months ended March 31, 2014, we noted no indications of impairment or triggering events to cause us to review goodwill for potential impairment. We will conduct our annual goodwill testing during the fourth fiscal quarter.

[0000926326-14-000010:notes:60]
There were no changes in the carrying amount of goodwill for the period from December 31, 2013 to March 31, 2014. Goodwill by reporting unit, which is the same for our operating segments are as follows (in thousands):

[0000926326-14-000010:notes:61]
|  | Goodwill at December 31, 2013 |  | Adjustments to Goodwill |  | Goodwill at March 31, 2014 |
| Reporting units: |  |  |  |  |  |
| Automation and Analytics | $ | 28,543 |  |  | $ | — |  |  | $ | 28,543 |  |
| Medication Adherence | 82,800 |  |  | — |  |  | 82,800 |  |
| Total | $ | 111,343 |  |  | $ | — |  |  | $ | 111,343 |  |

[0000926326-14-000010:notes:62]
Intangible Assets, net

[0000926326-14-000010:notes:63]
There were no indefinite-lived intangible assets as of March 31, 2014 or December 31, 2013. Finite-lived intangible assets consist of the following (in thousands):

[0000926326-14-000010:notes:64]
|  | March 31, 2014 |  | December 31, 2013 |  |  |
|  | Gross |  |  |  | Net |  | Gross |  |  |  | Net |  |  |
|  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | AmortizationLife |
| Finite-lived intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 54,730 |  |  | $ | 5,775 |  |  | $ | 48,955 |  |  | $ | 54,730 |  |  | $ | 5,236 |  |  | $ | 49,494 |  |  | 5-30 years |
| Acquired technology | 27,580 |  |  | 2,965 |  |  | 24,615 |  |  | 27,580 |  |  | 2,598 |  |  | 24,982 |  |  | 3-20 years |
| Patents | 1,561 |  |  | 303 |  |  | 1,258 |  |  | 1,493 |  |  | 254 |  |  | 1,239 |  |  | 20 years |
| Trade name | 6,890 |  |  | 1,145 |  |  | 5,745 |  |  | 6,890 |  |  | 1,003 |  |  | 5,887 |  |  | 3-12 years |
| Non-compete agreements | — |  |  | — |  |  | — |  |  | 60 |  |  | 60 |  |  | — |  |  | 3 years |
| Total finite-lived intangibles | $ | 90,761 |  |  | $ | 10,188 |  |  | $ | 80,573 |  |  | $ | 90,753 |  |  | $ | 9,151 |  |  | $ | 81,602 |  |  |  |

[0000926326-14-000010:notes:65]
Amortization expense totaled $1.1 million for both the three months ended March 31, 2014 and 2013. The amortization of acquired technology is included within product cost of sales and amortization of other acquired intangibles is included within selling, general and administrative expenses.

[0000926326-14-000010:notes:66]
Estimated future amortization expense of finite-lived intangible assets are as follows (in thousands):

[0000926326-14-000010:notes:67]
| Remainder of 2014 | $ | 3,191 |  |
| 2015 | 4,225 |  |
| 2016 | 3,857 |  |
| 2017 | 3,822 |  |
| 2018 | 3,714 |  |
| Thereafter | 61,764 |  |
| Total | $ | 80,573 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-14-000010:notes:68]
Income Taxes

[0000926326-14-000010:notes:69]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 39.1% and 37.4% for the three-months ended March 31, 2014 and 2013, respectively. The 2014 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.

[0000926326-14-000010:notes:70]
The 2013 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the federal research and development credit claimed and the domestic production activities deduction. The income tax provision for the three months ended March 31, 2013 also reflected a discrete net benefit of $0.7 million, or 18.0% of pre-tax income, related to 2012 federal research and development credit which was retroactively reinstated in the three months ended March 31, 2013.


## us-gaap:InventoryDisclosureTextBlock

[0000926326-14-000010:notes:71]
[same as prior period, unchanged from 0000926326-13-000016:notes:105]

[0000926326-14-000010:notes:72]
[same as prior period, unchanged from 0000926326-13-000016:notes:106]

[0000926326-14-000010:notes:73]
|  | March 31, 2014 |  | December 31, 2013 |
| Raw materials | $ | 10,278 |  |  | $ | 10,765 |  |
| Work in process | 944 |  |  | 534 |  |
| Finished goods | 19,753 |  |  | 20,158 |  |
| Total | $ | 30,975 |  |  | $ | 31,457 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000926326-14-000010:notes:74]
Contingencies

[0000926326-14-000010:notes:75]
Legal Proceedings

[0000926326-14-000010:notes:76]
On March 8, 2013, Bobbi Polanco (“Polanco”) filed a putative class action complaint in the United States District Court for the District of New Jersey (the "Court") against Omnicell and certain of our customers (Case No. 1:13-cv-01417-NLH-KLM) alleging breach of state security notification laws, violations of state consumer fraud laws, fraud, negligence and conspiracy relating to the theft of an Omnicell electronic device containing medication dispensing cabinet log files, including certain patient health information, and subsequent notification of this unauthorized disclosure of personal health information. Polanco is seeking an injunction against the defendants to prevent each of them from committing the acts complained of in the future and monetary damages, costs and expenses. On May 2, 2013, the Court entered an order to show cause which provided, in relevant part, that Polanco is required to show cause as to why the case should not be dismissed for lack of subject matter jurisdiction. On May 13, 2013, Polanco filed an amended complaint. On May 31, 2013, Omnicell filed a motion to dismiss the complaint on the grounds that Polanco failed to satisfy constitutional standing requirements and that she failed to state a claim against Omnicell  for violating  state data breach notification statutes, consumer fraud, common law fraud, negligence and conspiracy. Omnicell also joined in the arguments of the other defendants seeking dismissal. On July 1, 2013, Polanco filed an opposition to the motions to dismiss. On July 15, 2013, Omnicell filed its reply to the opposition from Polanco. In December 2013, the Court granted the defendants' motions to dismiss without prejudice. Polanco failed to file an appeal of the Court's decision by the January 27, 2014 deadline.

[0000926326-14-000010:notes:77]
As required under ASC 450, Contingencies, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We did not record any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that any potential loss, while reasonably possible, was not probable. We believe that we have valid defenses with respect to legal proceedings pending against us. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-14-000010:notes:78]
Guarantees

[0000926326-14-000010:notes:79]
As permitted under Delaware law and our certificate of incorporation and bylaws, we have agreed to indemnify our directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become our directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that we could be required to make under these indemnification agreements. We have purchased a directors’ and officers’ liability insurance policy that may enable us to recover a portion of any future payments that we may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-14-000010:notes:80]
Additionally, we undertake indemnification obligations in our ordinary course of business in connection with, among other things, the licensing of our products and the provision of our support services. In the ordinary course of our business, we have in the past and may in the future agree to indemnify another party, generally our business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, our gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, we attempt to limit the maximum potential amount of future payments that we may be required to make under these indemnification obligations to the amounts paid to us by a customer, but in some cases the obligation may not be so limited. In addition, we have in the past and may in the future warrant to our customers that our products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that our software media is free from material defects. Sales contracts for certain of our medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances we record have historically been immaterial.

[0000926326-14-000010:notes:81]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of March 31, 2014 or December 31, 2013.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-14-000010:notes:82]
Recently Adopted Accounting Standards

[0000926326-14-000010:notes:83]
In July 2013, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2013-11,  Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. ASU 2013-11 requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except as follows: to the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. We adopted the amendments in ASU 2013-11 in the first quarter of 2014. This update did not have a significant impact on our financial position, operating results or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000926326-14-000010:notes:84]
[same as prior period, unchanged from 0000926326-13-000016:notes:118]

[0000926326-14-000010:notes:85]
Description of the Company. Omnicell, Inc. ("Omnicell," "our," "us," "we," or the "Company") was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication supply control systems and medical adherence solutions which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States and Canada.

[0000926326-14-000010:notes:86]
Use of estimates. GAAP requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, valuation of goodwill and purchased intangibles, valuation of long-lived assets and accounting for income taxes.

[0000926326-14-000010:notes:87]
Principles of consolidation. The condensed consolidated financial statements include the accounts of our wholly-owned subsidiaries. All significant inter-company accounts and transactions have been eliminated in consolidation.

[0000926326-14-000010:notes:88]
Concentration of credit risk. Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there was no single customer accounting for 10% or more of revenues in the three months ended March 31, 2014. Additionally, there was no single customer accounting for 10% or more of accounts receivable at March 31, 2014 or December 31, 2013. We believe that we have no significant concentrations of credit risk at March 31, 2014.

[0000926326-14-000010:notes:89]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended March 31, 2014 and 2013 totaled approximately $8.9 million and $7.2 million, respectively.

[0000926326-14-000010:notes:90]
There have been no material changes in our significant accounting policies as of and for the three months ended March 31, 2014, compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2013.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-14-000010:notes:91]
[same as prior period, unchanged from 0000926326-13-000016:notes:120]

[0000926326-14-000010:notes:92]
[same as prior period, unchanged from 0000926326-13-000016:notes:121]

[0000926326-14-000010:notes:93]
|  | March 31, 2014 |  | December 31, 2013 |
| Equipment | $ | 40,682 |  |  | $ | 40,180 |  |
| Furniture and fixtures | 5,296 |  |  | 5,260 |  |
| Leasehold improvements | 7,451 |  |  | 7,394 |  |
| Purchased software | 21,299 |  |  | 20,199 |  |
| Construction in process | 3,355 |  |  | 2,649 |  |
|  | 78,083 |  |  | 75,682 |  |
| Accumulated depreciation and amortization | (42,905 | ) |  | (40,428 | ) |
| Property and equipment, net | $ | 35,178 |  |  | $ | 35,254 |  |

[0000926326-14-000010:notes:94]
Depreciation and amortization of property and equipment totaled approximately $2.5 million and $2.7 million for the three months ended March 31, 2014 and 2013, respectively.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000926326-14-000010:notes:95]
|  | Three Months Ended March 31, 2014 |  | Three Months Ended March 31, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Total revenues | $ | 81,499 |  |  | $ | 20,265 |  |  | $ | 101,764 |  |  | $ | 68,713 |  |  | $ | 18,397 |  |  | $ | 87,110 |  |
| Cost of revenues | 34,940 |  |  | 12,329 |  |  | 47,269 |  |  | 30,276 |  |  | 11,467 |  |  | 41,743 |  |
| Gross profit | $ | 46,559 |  |  | $ | 7,936 |  |  | $ | 54,495 |  |  | $ | 38,437 |  |  | $ | 6,930 |  |  | $ | 45,367 |  |
| Gross margin % | 57.1 | % |  | 39.2 | % |  | 53.6 | % |  | 55.9 | % |  | 37.7 | % |  | 52.1 | % |
| Operating expenses | 37,402 |  |  | 7,139 |  |  | 44,541 |  |  | 33,104 |  |  | 8,094 |  |  | 41,198 |  |
| Income (loss) from operations | $ | 9,157 |  |  | $ | 797 |  |  | $ | 9,954 |  |  | $ | 5,333 |  |  | $ | (1,164 | ) |  | $ | 4,169 |  |
| Operating margin % | 11.2 | % |  | 3.9 | % |  | 9.8 | % |  | 7.8 | % |  | (6.3 | )% |  | 4.8 | % |
| Interest and other income (expense), net |  |  |  |  | (256 | ) |  |  |  |  |  | (223 | ) |
| Income before provision for income taxes |  |  |  |  | 9,698 |  |  |  |  |  |  | 3,946 |  |
| Provision for income taxes |  |  |  |  | 3,504 |  |  |  |  |  |  | 561 |  |
| Net income |  |  |  |  | $ | 6,194 |  |  |  |  |  |  | $ | 3,385 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000926326-14-000010:notes:96]
[same as prior period, unchanged from 0000926326-13-000016:notes:143]

[0000926326-14-000010:notes:97]
|  | March 31, 2014 |  | December 31, 2013 |
| Rebates and lease buyouts | $ | 2,036 |  |  | $ | 1,699 |  |
| Advance payments from customers | 3,778 |  |  | 4,971 |  |
| Accrued Group Purchasing Organization (GPO) fees | 2,558 |  |  | 2,324 |  |
| Technology license purchase obligation, current portion | 1,000 |  |  | 1,500 |  |
| Taxes payable | 2,406 |  |  | 1,664 |  |
| Other | 1,716 |  |  | 1,588 |  |
| Total | $ | 13,494 |  |  | $ | 13,746 |  |


## us-gaap:ScheduleOfCreditLossesRelatedToFinancingReceivablesNoncurrentTableTextBlock

[0000926326-14-000010:notes:98]
The following table summarizes the activity for the allowance for credit losses for the investment in sales-type leases for the three months ended March 31, 2014 and 2013 (in thousands):

[0000926326-14-000010:notes:99]
|  | Three Months Ended March 31, |
|  | 2014 |  | 2013 |
| Allowance for credit losses, beginning of period | $ | 167 |  |  | $ | 607 |  |
| Current period provision | 2 |  |  | 13 |  |
| Direct write-downs charged against the allowance | — |  |  | (413 | ) |
| Recoveries of amounts previously charged off | — |  |  | (17 | ) |
| Allowance for credit losses, end of period | $ | 169 |  |  | $ | 190 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000926326-14-000010:notes:100]
The minimum lease payments under sales-type leases as of March 31, 2014 were as follows (in thousands):

[0000926326-14-000010:notes:101]
| Remainder of 2014 | $ | 4,549 |  |
| 2015 | 5,230 |  |
| 2016 | 3,991 |  |
| 2017 | 3,042 |  |
| 2018 | 1,466 |  |
| Thereafter | 73 |  |
| Total | $ | 18,351 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-14-000010:notes:102]
For the three months ended March 31, 2014 and 2013, segment depreciation/amortization, and capital expenditures were as follows (amounts in thousands):

[0000926326-14-000010:notes:103]
|  | Three Months Ended March 31, 2014 |  | Three Months Ended March 31, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Depreciation/Amortization | $ | 2,898 |  |  | $ | 1,714 |  |  | $ | 4,612 |  |  | $ | 2,899 |  |  | $ | 1,573 |  |  | $ | 4,472 |  |
| Capital Expenditures | $ | 1,748 |  |  | $ | 803 |  |  | $ | 2,551 |  |  | $ | 1,000 |  |  | $ | 2,338 |  |  | $ | 3,338 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-14-000010:notes:104]
[same as prior period, unchanged from 0000926326-13-000016:notes:154]

[0000926326-14-000010:notes:105]
Beginning with the acquisition of MTS, which was completed in May 2012, we have organized our business into two operating business segments. Previously, we reported segments based on the customers that our products were sold to, with the Acute Care segment primarily including products and services sold to hospital customers, and the Non-Acute Care segment primarily including products and services sold to customers outside of hospital settings. We are at a point where many of our Acute Care and Non-Acute Care customers are converging to provide services across the continuum of care. These customers seek automation and analytics products that function across the various facilities they manage and we find ourselves providing solutions across multiple types of care environments. These customers are also interested in obtaining higher levels of adherence to prescribed medication regimens that our blister card products provide. Our business has evolved to be managed more on a product basis and it has become more difficult to determine whether a customer is a hospital or a blend of hospitals and non-acute care facilities. Accordingly, beginning in 2014, we have realigned our segments to reflect the products we sell, regardless of who they are sold to.

[0000926326-14-000010:notes:106]
The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software.

[0000926326-14-000010:notes:107]
The Medication Adherence segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services.

[0000926326-14-000010:notes:108]
Prior period amounts in the table below have been recast to conform to the way we internally manage and monitor performance at the segment level during the current period.

[0000926326-14-000010:notes:109]
We report segment information based on the management approach. The management approach designates the internal reporting used by the Chief Operating Decision Maker (the "CODM") for making decisions and assessing performance as the source of our operating segments. The CODM is our Chief Executive Officer. The CODM allocates resources to and assesses the performance of each operating segment, using information about its revenues, gross profit and income (loss) from operations. The CODM does not evaluate operating business segments using discrete asset information; accordingly, we do not report segment assets.

[0000926326-14-000010:notes:110]
Since 1992, Omnicell has provided automation and business information solutions to healthcare facilities in general, but with a focus on acute care hospitals. We have developed product solutions that help optimize various workflows utilized in hospitals. We have also developed sophisticated sales, installation, and service capabilities to serve the specific and special needs of hospitals. As the healthcare market evolves, acute care facilities are beginning to merge operationally with non-acute care facilities. The new healthcare organizations desire medication and supply inventory control and business analytics across the continuum of care environments they serve. Our Automation and Analytics segment represents the products we sell to fulfill these needs.

[0000926326-14-000010:notes:111]
Since 1984, MTS has provided medication adherence solutions to the non-acute care market. These solutions provide automated and semi-automated equipment to assist institutional and retail pharmacists in filling medication orders into blister cards, the primary method of medication control in non-acute care settings. Completing the product solution are the consumables used by institutional and retail pharmacists to make the medication adherence package. MTS has developed process manufacturing capabilities as well as sales capabilities to market medication adherence solutions to institutional and retail pharmacies.

[0000926326-14-000010:notes:112]
As healthcare evolves, these medication adherence solutions are finding application in acute care settings as well. Our Medication Adherence segment represents all the products we sell to fulfill medication adherence needs through blister cards, blister card packaging equipment, and related software.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-14-000010:notes:113]
[same as prior period, unchanged from 0000926326-13-000016:notes:165]

[0000926326-14-000010:notes:114]
[same as prior period, unchanged from 0000926326-13-000016:notes:166]

[0000926326-14-000010:notes:115]
[same as prior period, unchanged from 0000926326-13-000016:notes:171]

[0000926326-14-000010:notes:116]
On August 1, 2012, our Board of Directors established a stock repurchase program (the “2012 Repurchase Program”) authorizing share repurchases of up to $50.0 million of our common stock, with no termination date. The timing, price and volume of repurchases will be based on market conditions, relevant securities laws and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions or pursuant to a Rule 10b-18 plan. The 2012 Repurchase Program does not obligate us to repurchase any specific number of shares, and we may terminate or suspend the repurchase program at any time.

[0000926326-14-000010:notes:117]
For the three months ended March 31, 2014, we repurchased a total of $4.1 million, or 145,737 shares, at an average cost of $27.92, including commissions. We did not repurchase any shares for the three months ended March 31, 2013.

[0000926326-14-000010:notes:118]
From the inception of the 2012 Repurchase Program, we have repurchased a total of $25.0 million, or 1,030,382 shares at an average cost of $24.29 per share, including commissions. As of March 31, 2014, the maximum dollar value of shares that may yet be purchased under the plan is $25.0 million.


## omcl:AccruedLiabilitiesTextBlock

[0000926326-14-000010:notes:119]
[same as prior period, unchanged from 0000926326-13-000016:notes:174]


## omcl:DeferredGrossProfitTableTextBlock

[0000926326-14-000010:notes:120]
[same as prior period, unchanged from 0000926326-13-000016:notes:175]

[0000926326-14-000010:notes:121]
|  | March 31, 2014 |  | December 31, 2013 |
| Sales of medication and supply dispensing systems and packaging equipment, delivered and invoiced but not yet installed | $ | 36,151 |  |  | $ | 29,040 |  |
| Cost of revenues, excluding installation costs | (11,045 | ) |  | (9,083 | ) |
| Deferred gross profit | $ | 25,106 |  |  | $ | 19,957 |  |


## omcl:DeferredGrossProfitTextBlock

[0000926326-14-000010:notes:122]
[same as prior period, unchanged from 0000926326-13-000016:notes:177]


## omcl:ImpairmentOfSoftwareDevelopmentCostsTableTextBlock

[0000926326-14-000010:notes:123]
[same as prior period, unchanged from 0000926326-13-000016:notes:179]

[0000926326-14-000010:notes:124]
As part of the continuing integration of MTS, in the first quarter of 2013, we reorganized our management team, including the software development department, within the Medication Adherence segment. Through the end of the first quarter of 2013, the Medication Adherence segment had capitalized approximately $1.8 million of software development costs associated with a software solution under development which was intended to assist pharmacies in manual packaging of prescriptions. In connection with our financial statement close process for the quarter ended March 31, 2013, our management reassessed the viability of this project and the net realizable value of capitalized costs in light of its decision to change the related product road map and redesign this product based on evolving market demands. As part of this redesign process, new functionality and capabilities will need to be added to the product before commercialization. This redesign is intended to provide a more robust global platform providing larger scalability and significant functionality not contained in our current beta version. As such, we have determined we can no longer support the technological feasibility of this project in conjunction with our software capitalization policy. Therefore, we charged these costs, in the amount of $1.8 million, ($0.03 per diluted share, net of tax), to expense as a component of research and development in the accompanying condensed consolidated statement of operations.


## omcl:NetInvestmentsInSalesTypeLeasesTextBlock

[0000926326-14-000010:notes:125]
[same as prior period, unchanged from 0000926326-13-000016:notes:181]

[0000926326-14-000010:notes:126]
[same as prior period, unchanged from 0000926326-13-000016:notes:182]

[0000926326-14-000010:notes:127]
|  | March 31, 2014 |  | December 31, 2013 |
| Net minimum lease payments to be received | $ | 18,351 |  |  | $ | 18,172 |  |
| Less unearned interest income portion | 1,397 |  |  | 1,455 |  |
| Net investment in sales-type leases | 16,954 |  |  | 16,717 |  |
| Less current portion(1) | 5,310 |  |  | 5,232 |  |
| Non-current net investment in sales-type leases(2) | $ | 11,644 |  |  | $ | 11,485 |  |

[0000926326-14-000010:notes:128]
(1)     A component of other current assets. This amount is net of an immaterial allowance for doubtful accounts as of March 31, 2014 and December 31, 2013.

[0000926326-14-000010:notes:129]
(2)     This amount is net of an immaterial allowance for doubtful accounts as of March 31, 2014 and December 31, 2013.
