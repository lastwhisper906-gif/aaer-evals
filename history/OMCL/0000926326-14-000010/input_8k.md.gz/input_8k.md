# OMCL 8-K — 0000926326-14-000008 filed 2014-05-01

## item codes, every 8-K on or before 2014-05-12

- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2014-05-12

- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-14-000008:8k_2_02:1]
EX-99.1
2
exhibit991q114.htm
EX-99.1

[0000926326-14-000008:8k_2_02:2]
Exhibit991Q114

[0000926326-14-000008:8k_2_02:3]
Exhibit 99.1

[0000926326-14-000008:8k_2_02:4]
| Contact: |  |  |
| Rob Seim |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6478 |  | Mountain View, CA 94043 |
| rob.seim@omnicell.com |  |  |

[0000926326-14-000008:8k_2_02:5]
Omnicell Announces First Quarter 2014 Results

[0000926326-14-000008:8k_2_02:6]
MOUNTAIN VIEW, Calif. — May 1, 2014— Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its first quarter ended March 31, 2014.

[0000926326-14-000008:8k_2_02:7]
GAAP results: Revenue for the first quarter of 2014 was $101.8 million, up $14.7 million or 16.8% from the first quarter of 2013, and down $4.0 million or 3.8% from the fourth quarter of 2013.

[0000926326-14-000008:8k_2_02:8]
First quarter 2014 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $6.2 million, or $0.17 per diluted share. This compares to net income of $3.4 million, or $0.10 per diluted share, in the first quarter of 2013 and net income of $6.8 million, or $0.19 per diluted share, in the fourth quarter of 2013.

[0000926326-14-000008:8k_2_02:9]
Non-GAAP results: Non-GAAP net income was $9.6 million for the first quarter of 2014, or $0.26 per diluted share. Non-GAAP net income for the first quarter excludes $2.7 million of stock-based compensation expense and $1.0 million ($0.6 million net of the $0.4 million tax effect) of amortization expense for all intangible assets associated with past acquisitions made by Omnicell. This compares to non-GAAP net income of $7.4 million, or $0.21 per diluted share, for the first quarter of 2013. Non-GAAP net income for the first quarter of 2013 excludes $2.9 million of stock-based compensation expense, $0.7 million ($0.4 million net of $0.3 million tax effect) of reorganization costs related to the continued integration of MTS Medication Technologies, Inc. (“MTS”), and $1.1 million ($0.7 million net of $0.4 million tax effect) of amortization expense for all intangible assets acquired in connection with the acquisition of MTS in May 2012 and earlier acquisitions.

[0000926326-14-000008:8k_2_02:10]
First quarter 2014 results compare to non-GAAP net income of $10.5 million for the fourth quarter of 2013 or $0.29 per diluted share. Non-GAAP net income for the fourth quarter excludes $2.7 million of stock-based compensation expense, $1.0 million ($0.6 million net of the $0.4 million tax effect) of amortization expense for all intangible assets associated with past acquisitions made by Omnicell, and $0.6 million ($0.4 million net of $0.2 million tax effect) of non-recurring charges incurred in connection with the previously announced agreement to acquire Surgichem Limited, a wholly-owned subsidiary of Bupa Care Homes Plc.

[0000926326-14-000008:8k_2_02:11]
“Omnicell’s momentum from our record-setting 2013 has continued through the first quarter of 2014,” said Randall Lipps, President, CEO and Chairman. “Our revenue is ahead of expectations, earnings are ahead of our first quarter guidance, and our business has grown 17% over the first quarter of 2013.”

[0000926326-14-000008:8k_2_02:12]
Reporting Segments

[0000926326-14-000008:8k_2_02:13]
As our business has evolved, it has become more difficult to determine whether a customer is an acute care hospital or a blend of hospitals and non-acute care facilities. Accordingly, we will no longer report the customer-centric Acute Care and Non-Acute Care segments, as such segmentation no longer reflects the way we manage our business. Effective with the first quarter of 2014, we began to manage our business according to two product segments: Automation and Analytics and Medication Adherence. The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. The Medication Adherence segment includes primarily the

[0000926326-14-000008:8k_2_02:14]
manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. The change in the reportable segment structure discussed above affects only the manner in which we previously reported the results of our reportable segments. This does not restate any of the consolidated financial statements we previously filed with the Securities and Exchange Commission for any completed period nor does it reflect any subsequent information or events, other than the change in segments described above.

[0000926326-14-000008:8k_2_02:15]
The historical recasting of certain financial results reflecting this change are included below in 'Segmented Information - As Recast.' We have also provided the same Segmented Information for our current quarter.

[0000926326-14-000008:8k_2_02:16]
Omnicell Conference Call Information

[0000926326-14-000008:8k_2_02:17]
Omnicell will hold a conference call today, Thursday, May 1, 2014 at 1:30 p.m. PT to discuss first quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 31573767. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:00 p.m. PT on June 1, 2014. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 31573767.

[0000926326-14-000008:8k_2_02:18]
About Omnicell

[0000926326-14-000008:8k_2_02:19]
For over 20 years, the mission of Omnicell (NASDAQ: OMCL) has been creating new efficiencies to help improve patient care, anywhere it is delivered. Omnicell is a leading supplier of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum, from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home.

[0000926326-14-000008:8k_2_02:20]
More than 2,800 Automation and Analytics customers worldwide have utilized Omnicell’s medication automation, supply chain and analytics solutions to enable them to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety. Omnicell Medication Adherence solutions, including its MTS Medication Technologies brand, provide innovative medication adherence packaging solutions that can help reduce costly hospital readmissions and enable approximately 6,000 institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-14-000008:8k_2_02:21]
For more information about Omnicell, please visit www.omnicell.com

[0000926326-14-000008:8k_2_02:22]
Forward-Looking Statements

[0000926326-14-000008:8k_2_02:23]
Use of Non-GAAP Financial Information

[0000926326-14-000008:8k_2_02:24]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-14-000008:8k_2_02:25]
Our non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-14-000008:8k_2_02:26]
a)  Stock-based compensation expense impact of Accounting Standards Codification (ASC) 718. We recognize equity plan-related compensation expenses, which represent the fair value of all share-based payments to employees, including grants of employee stock options, as required under ASC 718, “Stock Compensation” as non-GAAP adjustments in each period.

[0000926326-14-000008:8k_2_02:27]
b)  Reorganization costs. During the three months ended March 31, 2013, we recorded $0.7 million ($0.4 million net of $0.3 million tax effect) of reorganization costs related to our Medication Adherence segment. This charge is not expected to be recurring and, as such, the financial impact is excluded from our non-GAAP results.

[0000926326-14-000008:8k_2_02:28]
c) Acquisition-related transaction expenses. In connection with the previously announced agreement to acquire Surgichem Limited, we recorded $0.6 million ($0.4 million net of $0.2 million tax effect) of pre-acquisition costs in the fourth quarter of 2013. These charges are not expected to be recurring and, as such, the financial impact of these costs is excluded from our non-GAAP results.

[0000926326-14-000008:8k_2_02:29]
d)  Intangible assets amortization from business acquisitions. We excluded from our non-GAAP results the intangible assets amortization expense resulting from the MTS acquisition as well as earlier Omnicell acquisitions. This impacts the first quarter of fiscal 2014 non-GAAP results, the fourth quarter of 2013 non-GAAP results, and the first quarter of 2013 non-GAAP results by $1.1 million ($0.7 million net of $0.4 million tax effect). These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-14-000008:8k_2_02:30]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock option grants.

[0000926326-14-000008:8k_2_02:31]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-14-000008:8k_2_02:32]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0000926326-14-000008:8k_2_02:33]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0000926326-14-000008:8k_2_02:34]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0000926326-14-000008:8k_2_02:35]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-14-000008:8k_2_02:36]
Set forth below are additional reasons why share-based compensation expense related to ASC 718 is excluded from our non-GAAP financial measures:

[0000926326-14-000008:8k_2_02:37]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-14-000008:8k_2_02:38]
ii)  We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-14-000008:8k_2_02:39]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as excluding certain non-GAAP adjustments.

[0000926326-14-000008:8k_2_02:40]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-14-000008:8k_2_02:41]
• Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-14-000008:8k_2_02:42]
• Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-14-000008:8k_2_02:43]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-14-000008:8k_2_02:44]
Omnicell, Inc.

[0000926326-14-000008:8k_2_02:45]
Condensed Consolidated Statements of Operations

[0000926326-14-000008:8k_2_02:46]
(Unaudited, in thousands, except per share data)

[0000926326-14-000008:8k_2_02:47]
|  |  | Three Months Ended |  |
|  |  | March 31, 2014 |  | December 31, 2013 |  | March 31, 2013 |  |
| Revenues: |  |  |  |  |  |  |  |
| Product |  | $ | 82,580 |  |  | $ | 86,864 |  |  | $ | 69,236 |  |  |
| Services and other revenues |  | 19,184 |  |  | 18,886 |  |  | 17,874 |  |  |
| Total revenue |  | 101,764 |  |  | 105,750 |  |  | 87,110 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues |  | 38,900 |  |  | 41,187 |  |  | 33,547 |  |  |
| Cost of services and other revenues |  | 8,369 |  |  | 7,939 |  |  | 8,196 |  |  |
| Total cost of revenues |  | 47,269 |  |  | 49,126 |  |  | 41,743 |  |  |
| Gross profit |  | 54,495 |  |  | 56,624 |  |  | 45,367 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development |  | 6,121 |  |  | 7,440 |  |  | 7,954 |  |  |
| Selling, general and administrative |  | 38,420 |  |  | 38,129 |  |  | 33,244 |  |  |
| Total operating expenses |  | 44,541 |  |  | 45,569 |  |  | 41,198 |  |  |
| Income from operations |  | 9,954 |  |  | 11,055 |  |  | 4,169 |  |  |
| Interest and other income (expense), net |  | (256 | ) |  | (136 | ) |  | (223 | ) |  |
| Income before provision for income taxes |  | 9,698 |  |  | 10,919 |  |  | 3,946 |  |  |
| Provision for income taxes |  | 3,504 |  |  | 4,096 |  |  | 561 |  |  |
| Net income |  | $ | 6,194 |  |  | $ | 6,823 |  |  | $ | 3,385 |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic |  | $ | 0.18 |  |  | $ | 0.19 |  |  | $ | 0.10 |  |  |
| Diluted |  | $ | 0.17 |  |  | $ | 0.19 |  |  | $ | 0.10 |  |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |
| Basic |  | 35,225 |  |  | 35,495 |  |  | 33,900 |  |  |
| Diluted |  | 36,305 |  |  | 36,610 |  |  | 34,820 |  |  |

[0000926326-14-000008:8k_2_02:48]
Omnicell, Inc.

[0000926326-14-000008:8k_2_02:49]
Condensed Consolidated Balance Sheets

[0000926326-14-000008:8k_2_02:50]
(Unaudited, in thousands)

[0000926326-14-000008:8k_2_02:51]
|  |  | March 31, 2014 |  | December 31, 2013 |  |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 107,558 |  |  | $ | 104,531 |  |  |
| Accounts receivable, net |  | 75,496 |  |  | 58,597 |  |  |
| Inventories |  | 30,975 |  |  | 31,457 |  |  |
| Prepaid expenses |  | 16,378 |  |  | 18,883 |  |  |
| Deferred tax assets |  | 12,636 |  |  | 12,635 |  |  |
| Other current assets |  | 7,799 |  |  | 7,675 |  |  |
| Total current assets |  | 250,842 |  |  | 233,778 |  |  |
| Property and equipment, net |  | 35,178 |  |  | 35,254 |  |  |
| Non-current net investment in sales-type leases |  | 11,644 |  |  | 11,485 |  |  |
| Goodwill |  | 111,343 |  |  | 111,343 |  |  |
| Intangible assets, net |  | 80,573 |  |  | 81,602 |  |  |
| Non-current deferred tax assets |  | 1,164 |  |  | 1,102 |  |  |
| Other assets |  | 19,661 |  |  | 17,937 |  |  |
| Total assets |  | $ | 510,405 |  |  | $ | 492,501 |  |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |
| Accounts payable |  | 20,154 |  |  | 16,471 |  |  |
| Accrued compensation |  | 12,018 |  |  | 19,604 |  |  |
| Accrued liabilities |  | 13,494 |  |  | 13,746 |  |  |
| Deferred service revenue |  | 21,328 |  |  | 22,626 |  |  |
| Deferred gross profit |  | 25,106 |  |  | 19,957 |  |  |
| Total current liabilities |  | 92,100 |  |  | 92,404 |  |  |
| Non-current deferred service revenue |  | 19,773 |  |  | 17,763 |  |  |
| Non-current deferred tax liabilities |  | 27,926 |  |  | 28,162 |  |  |
| Other long-term liabilities |  | 5,430 |  |  | 5,175 |  |  |
| Total liabilities |  | 145,229 |  |  | 143,504 |  |  |
| Stockholders’ equity: |  |  |  |  |  |
| Total stockholders’ equity |  | 365,176 |  |  | 348,997 |  |  |
| Total liabilities and stockholders’ equity |  | $ | 510,405 |  |  | $ | 492,501 |  |  |

[0000926326-14-000008:8k_2_02:52]
Omnicell, Inc.

[0000926326-14-000008:8k_2_02:53]
Reconciliation of GAAP to Non-GAAP

[0000926326-14-000008:8k_2_02:54]
(Unaudited, in thousands, except per share data)

[0000926326-14-000008:8k_2_02:55]
|  |  | Three Months Ended |  |
|  |  | March 31, 2014 |  | December 31, 2013 |  | March 31, 2013 |  |
|  |  | Net Income |  | Net Income per Share-Diluted |  | Net Income |  | Net Income per Share-Diluted |  | Net Income |  | Net Income per Share-Diluted |  |
| GAAP |  | $ | 6,194 |  |  | $ | 0.17 |  |  | $ | 6,823 |  |  | $ | 0.19 |  |  | $ | 3,385 |  |  | $ | 0.10 |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Pre-acquisition, transaction and integration costs for acquisitions |  | — |  |  |  |  | 605 |  |  |  |  | — |  |  |  |  |
| Reorganization costs (a) |  | — |  |  |  |  | — |  |  |  |  | 732 |  |  |  |  |
| Amortization of intangible assets acquired by acquisition |  | 1,048 |  |  |  |  | 1,049 |  |  |  |  | 1,060 |  |  |  |  |
| Subtotal pretax adjustments |  | 1,048 |  |  |  |  | 1,654 |  |  |  |  | 1,792 |  |  |  |  |
| Income tax effect of non-GAAP adjustments (b) |  | (379 | ) |  |  |  | (662 | ) |  |  |  | (716 | ) |  |  |  |
| Subtotal after-tax adjustments |  | 669 |  |  |  |  | 992 |  |  |  |  | 1,076 |  |  |  |  |
| ASC 718 share-based compensation adjustment(c): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 268 |  |  |  |  | 287 |  |  |  |  | 305 |  |  |  |  |
| Operating expenses |  | 2,461 |  |  |  |  | 2,442 |  |  |  |  | 2,621 |  |  |  |  |
| Total |  | 3,398 |  |  | 0.09 |  |  | 3,721 |  |  | 0.10 |  |  | 4,002 |  |  | 0.11 |  |  |
| Non-GAAP |  | $ | 9,592 |  |  | $ | 0.26 |  |  | $ | 10,544 |  |  | $ | 0.29 |  |  | 7,387 |  | $ | 0.21 |  |  |

[0000926326-14-000008:8k_2_02:56]
(a) This adjustment is for reorganization costs related to our Medication Adherence segment for the three months ended March 31, 2013.

[0000926326-14-000008:8k_2_02:57]
(b) Tax effect amounts are calculated using the effective tax rates for the respective periods presented.

[0000926326-14-000008:8k_2_02:58]
(c) This adjustment reflects the accounting impact of non-cash stock-based compensation expense for the periods shown.

[0000926326-14-000008:8k_2_02:59]
Omnicell, Inc.

[0000926326-14-000008:8k_2_02:60]
Calculation of Adjusted EBITDA (1)

[0000926326-14-000008:8k_2_02:61]
(Unaudited, in thousands)

[0000926326-14-000008:8k_2_02:62]
|  |  | Three Months Ended |  |
|  |  | March 31, 2014 |  | December 31, 2013 |  | March 31, 2013 |  |
| GAAP net income |  | $ | 6,194 |  |  | $ | 6,823 |  |  | $ | 3,385 |  |  |
| Add back: |  |  |  |  |  |  |  |
| ASC 718 stock compensation expense |  | 2,729 |  |  | 2,729 |  |  | 2,926 |  |  |
| Reorganization costs |  | — |  |  | — |  |  | 732 |  |  |
| Transaction and integration costs for acquisitions, pre-tax |  | — |  |  | 605 |  |  | — |  |  |
| Interest (expense) and income, net |  | (2 | ) |  | 7 |  |  | 106 |  |  |
| Depreciation and amortization expense |  | 4,612 |  |  | 4,633 |  |  | 4,471 |  |  |
| Income tax expense |  | 3,504 |  |  | 4,096 |  |  | 561 |  |  |
| Non-GAAP adjusted EBITDA (1) |  | $ | 17,037 |  |  | $ | 18,893 |  |  | $ | 12,181 |  |  |

[0000926326-14-000008:8k_2_02:63]
| (1) | Defined as earnings before non-cash stock compensation expense per ASC 718, other non-GAAP adjustments, interest expense and income, net, depreciation and amortization, and taxes. Non-GAAP adjustments for the quarter ended December 31, 2013 exclude transaction and integration costs for MTS, acquired in May 2012. |

[0000926326-14-000008:8k_2_02:64]
Omnicell, Inc.

[0000926326-14-000008:8k_2_02:65]
Segmented Information - As Recast

[0000926326-14-000008:8k_2_02:66]
(Unaudited, in thousands, except for percentages)

[0000926326-14-000008:8k_2_02:67]
|  | Three Months Ended March 31, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |
| Net revenues from external customers | $ | 68,713 |  |  | $ | 18,397 |  |  | $ | 87,110 |  |
| Cost of revenues | 30,289 |  |  | 11,454 |  |  | 41,743 |  |
| Gross profit | $ | 38,424 |  |  | $ | 6,943 |  |  | $ | 45,367 |  |
| Gross margin % | 55.9 | % |  | 37.7 | % |  | 52.1 | % |
| Operating expenses | 32,564 |  |  | 8,635 |  |  | 41,199 |  |
| Income from operations | $ | 5,860 |  |  | $ | (1,692 | ) |  | $ | 4,168 |  |
| Operating margin % | 8.5 | % |  | (9.2 | )% |  | 4.8 | % |
| Interest and other income (expense), net |  |  |  |  | (223 | ) |
| Income before provision for income taxes |  |  |  |  | 3,945 |  |
| Provision for income taxes |  |  |  |  | 561 |  |
| Net income |  |  |  |  | $ | 3,384 |  |

[0000926326-14-000008:8k_2_02:68]
Omnicell, Inc.

[0000926326-14-000008:8k_2_02:69]
Segmented Information - As Recast

[0000926326-14-000008:8k_2_02:70]
(Unaudited, in thousands, except for percentages)

[0000926326-14-000008:8k_2_02:71]
|  | Three Months Ended June 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |
| Net revenues from external customers | $ | 73,866 |  |  | $ | 19,820 |  |  | $ | 93,686 |  |
| Cost of revenues | 31,936 |  |  | 12,382 |  |  | 44,318 |  |
| Gross profit | $ | 41,930 |  |  | $ | 7,438 |  |  | $ | 49,368 |  |
| Gross margin % | 56.8 | % |  | 37.5 | % |  | 52.7 | % |
| Operating expenses | 33,808 |  |  | 6,201 |  |  | 40,009 |  |
| Income from operations | $ | 8,122 |  |  | $ | 1,237 |  |  | $ | 9,359 |  |
| Operating margin % | 11.0 | % |  | 6.2 | % |  | 10.0 | % |
| Interest and other income (expense), net |  |  |  |  | 63 |  |
| Income before provision for income taxes |  |  |  |  | 9,422 |  |
| Provision for income taxes |  |  |  |  | 3,406 |  |
| Net income |  |  |  |  | $ | 6,016 |  |

[0000926326-14-000008:8k_2_02:72]
Omnicell, Inc.

[0000926326-14-000008:8k_2_02:73]
Segmented Information - As Recast

[0000926326-14-000008:8k_2_02:74]
(Unaudited, in thousands, except for percentages)

[0000926326-14-000008:8k_2_02:75]
|  | Three Months Ended September 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |
| Net revenues from external customers | $ | 75,110 |  |  | $ | 18,929 |  |  | $ | 94,039 |  |
| Cost of revenues | 30,240 |  |  | 11,759 |  |  | 41,999 |  |
| Gross profit | $ | 44,870 |  |  | $ | 7,170 |  |  | $ | 52,040 |  |
| Gross margin % | 59.7 | % |  | 37.9 | % |  | 55.3 | % |
| Operating expenses | 35,052 |  |  | 6,271 |  |  | 41,323 |  |
| Income from operations | $ | 9,818 |  |  | $ | 899 |  |  | $ | 10,717 |  |
| Operating margin % | 13.1 | % |  | 4.7 | % |  | 11.4 | % |
| Interest and other income (expense), net |  |  |  |  | 25 |  |
| Income before provision for income taxes |  |  |  |  | 10,742 |  |
| Provision for income taxes |  |  |  |  | 2,987 |  |
| Net income |  |  |  |  | $ | 7,755 |  |

[0000926326-14-000008:8k_2_02:76]
Omnicell, Inc.

[0000926326-14-000008:8k_2_02:77]
Segmented Information - As Recast

[0000926326-14-000008:8k_2_02:78]
(Unaudited, in thousands, except for percentages)

[0000926326-14-000008:8k_2_02:79]
|  | Three Months Ended December 31, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |
| Net revenues from external customers | $ | 85,228 |  |  | $ | 20,522 |  |  | $ | 105,750 |  |
| Cost of revenues | 36,862 |  |  | 12,264 |  |  | 49,126 |  |
| Gross profit | $ | 48,366 |  |  | $ | 8,258 |  |  | $ | 56,624 |  |
| Gross margin % | 56.7 | % |  | 40.2 | % |  | 53.5 | % |
| Operating expenses | 38,122 |  |  | 7,447 |  |  | 45,569 |  |
| Income from operations | $ | 10,244 |  |  | $ | 811 |  |  | $ | 11,055 |  |
| Operating margin % | 12.0 | % |  | 4.0 | % |  | 10.5 | % |
| Interest and other income (expense), net |  |  |  |  | (136 | ) |
| Income before provision for income taxes |  |  |  |  | 10,919 |  |
| Provision for income taxes |  |  |  |  | 4,096 |  |
| Net income |  |  |  |  | $ | 6,823 |  |

[0000926326-14-000008:8k_2_02:80]
Omnicell, Inc.

[0000926326-14-000008:8k_2_02:81]
Segmented Information - As Recast

[0000926326-14-000008:8k_2_02:82]
(Unaudited, in thousands, except for percentages)

[0000926326-14-000008:8k_2_02:83]
|  | Twelve Months Ended December 31, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |
| Net revenues from external customers | $ | 302,917 |  |  | $ | 77,668 |  |  | $ | 380,585 |  |
| Cost of revenues | 129,327 |  |  | 47,859 |  |  | 177,186 |  |
| Gross profit | $ | 173,590 |  |  | $ | 29,809 |  |  | $ | 203,399 |  |
| Gross margin % | 57.3 | % |  | 38.4 | % |  | 53.4 | % |
| Operating expenses | 139,546 |  |  | 28,554 |  |  | 168,100 |  |
| Income from operations | $ | 34,044 |  |  | $ | 1,255 |  |  | $ | 35,299 |  |
| Operating margin % | 11.2 | % |  | 1.6 | % |  | 9.3 | % |
| Interest and other income (expense), net |  |  |  |  | (270 | ) |
| Income before provision for income taxes |  |  |  |  | 35,029 |  |
| Provision for income taxes |  |  |  |  | 11,050 |  |
| Net income |  |  |  |  | $ | 23,979 |  |

[0000926326-14-000008:8k_2_02:84]
Omnicell, Inc.

[0000926326-14-000008:8k_2_02:85]
Segmented Information

[0000926326-14-000008:8k_2_02:86]
(Unaudited, in thousands, except for percentages)

[0000926326-14-000008:8k_2_02:87]
|  | Three Months Ended March 31, 2014 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |
| Net revenues from external customers | $ | 81,499 |  |  | $ | 20,265 |  |  | $ | 101,764 |  |
| Cost of revenues | 34,940 |  |  | 12,329 |  |  | 47,269 |  |
| Gross profit | $ | 46,559 |  |  | $ | 7,936 |  |  | $ | 54,495 |  |
| Gross margin % | 57.1 | % |  | 39.2 | % |  | 53.6 | % |
| Operating expenses | 37,402 |  |  | 7,139 |  |  | 44,541 |  |
| Income from operations | $ | 9,157 |  |  | $ | 797 |  |  | $ | 9,954 |  |
| Operating margin % | 11.2 | % |  | 3.9 | % |  | 9.8 | % |
| Interest and other income (expense), net |  |  |  |  | (256 | ) |
| Income before provision for income taxes |  |  |  |  | 9,698 |  |
| Provision for income taxes |  |  |  |  | 3,504 |  |
| Net income |  |  |  |  | $ | 6,194 |  |
