# OMCL MD&A — 0000926326-14-000010


## mdna

[0000926326-14-000010:mdna:1]
[same as prior period, unchanged from 0000926326-13-000016:mdna:1]

[0000926326-14-000010:mdna:2]
[same as prior period, unchanged from 0000926326-13-000016:mdna:2]

[0000926326-14-000010:mdna:3]
[same as prior period, unchanged from 0000926326-13-000016:mdna:3]

[0000926326-14-000010:mdna:4]
| • | our expectations regarding our future product bookings; |

[0000926326-14-000010:mdna:5]
| • | the extent and timing of future revenues, including the amounts of our current backlog; |

[0000926326-14-000010:mdna:6]
[same as prior period, unchanged from 0000926326-13-000016:mdna:5]

[0000926326-14-000010:mdna:7]
| • | the opportunity presented by new products, emerging markets and international market; |

[0000926326-14-000010:mdna:8]
[same as prior period, unchanged from 0000926326-13-000016:mdna:8]

[0000926326-14-000010:mdna:9]
[same as prior period, unchanged from 0000926326-13-000016:mdna:9]

[0000926326-14-000010:mdna:10]
[same as prior period, unchanged from 0000926326-13-000016:mdna:10]

[0000926326-14-000010:mdna:11]
[same as prior period, unchanged from 0000926326-13-000016:mdna:11]

[0000926326-14-000010:mdna:12]
[same as prior period, unchanged from 0000926326-13-000016:mdna:12]

[0000926326-14-000010:mdna:13]
In some cases, you can identify forward-looking statements by terms such as "anticipates," "believes," "could," "estimates," "expects," "intends," "may," "plans," "potential," "predicts," "projects," "should," "will," "would" and similar expressions intended to identify forward-looking statements. Forward-looking statements reflect our current views with respect to future events, are based on assumptions and are subject to risks and uncertainties. We discuss many of these risks in this Quarterly Report on Form 10-Q in greater detail in Part II - Section 1A. “Risk Factors” below. Given these uncertainties, you should not place undue reliance on these forward-looking statements. Also, forward-looking statements represent our estimates and assumptions only as of the date of this Quarterly Report on Form 10-Q. You should read our Annual Report on Form 10-K and the documents that we reference in the Annual Report on Form 10-K and have filed as exhibits, completely and with the understanding that our actual future results may be materially different from what we expect.  All references in this report to "Omnicell, Inc.," "Omnicell," "our," "us," "we," or the "Company" collectively refer to Omnicell, Inc., a Delaware corporation, and its subsidiaries.

[0000926326-14-000010:mdna:14]
[same as prior period, unchanged from 0000926326-13-000016:mdna:14]

[0000926326-14-000010:mdna:15]
We are a leading provider of automated solutions for medication and supply management in healthcare. We believe our products improve healthcare for everyone, and it is our mission to continue improving healthcare with solutions that change the practice of healthcare in ways that improve patient and provider outcomes. Our automation and analytics solutions are designed to enable healthcare facilities to acquire, manage, dispense and administer medications and medical-surgical supplies and are intended to enhance patient safety, reduce medication errors, reduce operating costs, improve workflow and increase operational efficiency. We sell our medication control systems together with related consumables and services, and medical and surgical supply control systems. We generate approximately 89% of our product revenue in the United States and Canada. However, we expect our revenue from international operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-14-000010:mdna:16]
Prior to the first quarter of 2014, we managed our business in two customer-centric operating segments: Acute Care which primarily included products and services sold to hospital customers, and Non-Acute Care which primarily included products and services sold to customers outside of hospital settings.

[0000926326-14-000010:mdna:17]
We are at a point where many of our Acute Care and Non-Acute Care customers are converging to provide services across the continuum of care. These customers seek Automation and Analytics products that function across the various facilities they manage and we find ourselves providing solutions across multiple types of care environments. These customers are also interested in obtaining higher levels of adherence to prescribed medication regimens that our blister card products provide. Our business has evolved to be managed more on a product basis and it has become more difficult to determine whether a customer is a hospital or a blend of hospitals and non-acute care facilities. Accordingly, effective in the first quarter of 2014, we began to manage our business according to two product segments: Automation and Analytics, and Medication Adherence. The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. The Medication Adherence segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services.

[0000926326-14-000010:mdna:18]
Our Automation and Analytics segment has been the predominant market for our products since the company's inception in 1992 and today comprises approximately 80% of our overall business. The Medication Adherence segment became a significant portion of our business in May 2012, when we completed our acquisition of MedPak Holdings, Inc. ("MedPak"). MedPak is the parent company of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems. The acquisition aligned us with the long-term trends of the healthcare market to manage the health of patients across the continuum of care. The combination of Omnicell and MTS brought capabilities to each other that strengthened the product lines and expanded the medication management coverage of both companies. As our business evolves, we will continue to assess our segments which could result in future modifications to the current presentation.

[0000926326-14-000010:mdna:19]
The healthcare market is experiencing a period of substantive change. The adoption of electronic healthcare records, new regulatory constraints, and changes in the reimbursement structure have caused healthcare institutions to re-examine their operating structures, re-prioritize their investments, and seek efficiencies. We believe our customers’ evolving operating environment creates challenges for any supplier, but also affords opportunities for suppliers that are able to partner with customers to help them meet the changing demands. We have invested in strategies which we believe have generated our revenue and earnings growth by directly supporting our customers’ initiatives. These strategies include:

[0000926326-14-000010:mdna:20]
| • | Development of differentiated products. We invest in the development of products that we believe bring patient safety and workflow efficiency to our customers’ operations that they cannot get from other competing solutions. These differentiators may be as small as how a transaction operates or information provided on a report or as large as the entire automation of a workflow that would otherwise be completed manually. We intend to continue our focus on differentiating our products, and we carefully assess our investments regularly as we strive to assure those investments provide the solutions most valuable to our customers. |

[0000926326-14-000010:mdna:21]
| • | Deliver our solutions to new markets. Areas of healthcare where work is done manually may benefit from our existing solutions. These areas include hospitals that continue to utilize manual operations, healthcare segments of the US market outside hospitals, and markets outside the United States. We weigh the cost of entering these new markets against the expected benefits and focus on the markets that we believe are most likely to adopt our products. |

[0000926326-14-000010:mdna:22]
| • | Expansion of our solutions through acquisitions and partnerships. Our acquisitions have generally been focused on automation of manual workflows or data analytics, which is the enhancement of data for our customers’ decision-making processes. We believe that expansion of our product lines through acquisition and partnerships to meet our customers changing and evolving expectations is a key aspect to our historical and future success. |

[0000926326-14-000010:mdna:23]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, we began shipping a refresh of our product line in 2011 which we market as G4. The G4 refresh included multiple new products and an upgrade product that allowed existing customers to augment their installations to obtain the most current technology that we provide. The G4 product refresh has been a key contributor to our growth, with 41% of our automation and analytics installed base ordering upgrades to their existing systems since the announcement of G4. In addition to enhanced capabilities, we have focused on attaining the highest quality and service measurements for G4 in the industry, while marketing the solution to new and existing customers. Our research and development efforts today are designed to bring new products to market beyond the G4 product line that we believe will meet customer needs in years to come.

[0000926326-14-000010:mdna:24]
Consistent with our strategy to enter new markets, we have made investments in our selling, general and administrative expenses to expand our sales team and market to new customers. Our international efforts have focused primarily on three markets: China, where we made a Mandarin version of our automated dispensing systems available in 2011, the Middle Eastern countries of the Arabian Peninsula where new healthcare facility construction is taking place, and in the United Kingdom where, in the third quarter of 2012, we purchased 15% of our United Kingdom distributor’s outstanding equity for approximately $0.9 million in cash to accelerate the adoption of medication and supply automation. In connection with the investment, we have the right, under certain circumstances, to appoint a member to this company's board of directors

[0000926326-14-000010:mdna:25]
26

[0000926326-14-000010:mdna:26]
as well as certain other voting rights and, therefore, we believe we have the ability to exert significant influence over this distributor's operations. Our proportionate equity share of the income of this distributor recognized in our financial statements for the three months ended March 31, 2014 was immaterial. We have also expanded our sales efforts to medication adherence customers in the United States which has allowed us to sell our automated dispensing solutions and other products to this market.

[0000926326-14-000010:mdna:27]
Expansion of our solutions through acquisitions and partnerships include our acquisition of MTS in 2012 and an announced, but not completed, potential acquisition of Surgichem Limited from Bupa Care Homes (CFG) Plc. Surgichem is a provider of medication adherence products in the United Kingdom. If completed, the combination of Surgichem with Omnicell is expected to enable both entities to sell their lines of proven multi- and single-dose products across a broader medication adherence packaging market in the United Kingdom. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-14-000010:mdna:28]
We believe that the success of our three leg strategy of differentiated products, expansion into new markets, and acquisition and partnership in future periods will be based on, among other factors:

[0000926326-14-000010:mdna:29]
| • | Our expectation that the overall market demand for healthcare services will increase as the population grows, life expectancies continue to increase, the quality and availability of healthcare services increases; |

[0000926326-14-000010:mdna:30]
| • | Our expectation that the environment of increased patient safety awareness, increased regulatory control and increased need for workflow efficiency through the adoption of technology in the healthcare industry will make our solutions a priority in the capital budgets of healthcare facilities; and |

[0000926326-14-000010:mdna:31]
| • | Our belief that healthcare customers will continue to value a consultative customer experience from their suppliers. |

[0000926326-14-000010:mdna:32]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced by a contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are installable within 12 months and generally recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month.

[0000926326-14-000010:mdna:33]
In addition to product solution sales, we provide services to our customers. Our healthcare customers expect a high degree of partnership involvement from their technology suppliers throughout their ownership of the products. We provide extensive installation planning and consulting as part of every product sale and included in the initial price of the solution. Our customers' medication control systems are mission critical to their success and our customers require these systems to be functional at all times. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in one, two or five year increments. As a result of the growth of our installed base of customers, our service revenues have also grown. We strive to provide the best service possible, as measured by third party rating agencies and by our own surveys, to assure our customers continue to seek service maintenance from us. Our long-term liabilities include long-term deferred service revenue of $19.8 million and $17.8 million as of March 31, 2014 and December 31, 2013, respectively. Our deferred service revenue will be amortized to service revenue as the service contracts are executed.

[0000926326-14-000010:mdna:34]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but our focus will remain on improving healthcare with solutions that improve patient and provider outcomes. We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue. In 2014, we also intend to manage our business to operating profit margins similar to those achieved in 2013.

[0000926326-14-000010:mdna:35]
Operations During the Three Months Ended March 31, 2014

[0000926326-14-000010:mdna:36]
|  | Three Months Ended March 31, 2014 |  | Three Months Ended March 31, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Total revenues | $ | 81,499 |  |  | $ | 20,265 |  |  | $ | 101,764 |  |  | $ | 68,713 |  |  | $ | 18,397 |  |  | $ | 87,110 |  |
| Cost of revenues | 34,940 |  |  | 12,329 |  |  | 47,269 |  |  | 30,276 |  |  | 11,467 |  |  | 41,743 |  |
| Gross profit | $ | 46,559 |  |  | $ | 7,936 |  |  | $ | 54,495 |  |  | $ | 38,437 |  |  | $ | 6,930 |  |  | $ | 45,367 |  |
| Gross margin % | 57.1 | % |  | 39.2 | % |  | 53.6 | % |  | 55.9 | % |  | 37.7 | % |  | 52.1 | % |
| Operating expenses | $ | 37,402 |  |  | $ | 7,139 |  |  | $ | 44,541 |  |  | $ | 33,104 |  |  | $ | 8,094 |  |  | $ | 41,198 |  |
| Income (loss) from operations | $ | 9,157 |  |  | $ | 797 |  |  | $ | 9,954 |  |  | $ | 5,333 |  |  | $ | (1,164 | ) |  | $ | 4,169 |  |
| Operating margin % | 11.2 | % |  | 3.9 | % |  | 9.8 | % |  | 7.8 | % |  | (6.3 | )% |  | 4.8 | % |

[0000926326-14-000010:mdna:37]
Total revenues grew 16.8% year-over-year, comparing $101.8 million for the first quarter of 2014 with $87.1 million for the same period last year.

[0000926326-14-000010:mdna:38]
For the three months ended March 31, 2014, the Automation and Analytics segment contributed revenues of $63.1 million and $18.4 million to product and service revenue, respectively, compared to $51.6 million and $17.1 million, for the same period in 2013. The Medication Adherence segment contributed $19.5 million and $0.8 million to the overall product and service revenue, respectively, compared to $17.6 million and $0.8 million, during the same period in 2013. Overall product and service gross margins increased by $9.1 million, or 20.1%, respectively, for the three months ended March 31, 2014 compared to the same period in 2013.

[0000926326-14-000010:mdna:39]
During the first quarter of 2014, we recognized a decrease of 3.8%, in total revenues from the fourth quarter of 2013. Product revenue decreased by $4.3 million, or 4.9%, while service revenue increased slightly by 1.6%. Overall gross margins in the first quarter of 2014 remained relatively flat at 53.6% compared with 53.5% in the fourth quarter of 2013. Product gross margins remained relatively flat at 52.9% on revenue of $82.6 million during the first quarter of 2013 compared with 52.6% on revenue of $86.9 million during the fourth quarter of 2013. Service gross margins decreased to 56.4% on revenue of $19.2 million during the first quarter of 2014 compared to 58.0% on revenue of $18.9 million during the fourth quarter of 2013.

[0000926326-14-000010:mdna:40]
Cash and cash equivalents increased by $3.0 million during the three months ended March 31, 2014 to $107.6 million from $104.5 million at December 31, 2013 primarily due to working capital improvements and cash received for shares issued under our stock option and employee stock purchase plans.

[0000926326-14-000010:mdna:41]
[same as prior period, unchanged from 0000926326-13-000016:mdna:51]

[0000926326-14-000010:mdna:42]
Management's discussion and analysis of our financial condition and results of operations are based on our consolidated financial statements, which have been prepared in accordance with U.S. GAAP. The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe that the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our condensed consolidated financial statements:

[0000926326-14-000010:mdna:43]
[same as prior period, unchanged from 0000926326-13-000016:mdna:54]

[0000926326-14-000010:mdna:44]
•Valuation and impairment of goodwill, intangible assets and other long lived assets;

[0000926326-14-000010:mdna:45]
•Excess and obsolete inventory reserve;

[0000926326-14-000010:mdna:46]
[same as prior period, unchanged from 0000926326-13-000016:mdna:58]

[0000926326-14-000010:mdna:47]
[same as prior period, unchanged from 0000926326-13-000016:mdna:59]

[0000926326-14-000010:mdna:48]
During the three months ended March 31, 2014, there were no significant changes in our critical accounting policies and estimates.

[0000926326-14-000010:mdna:49]
Please refer to Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended December 31, 2013 for a more complete discussion of our other critical accounting policies and estimates.

[0000926326-14-000010:mdna:50]
Recently Adopted Accounting Standards

[0000926326-14-000010:mdna:51]
In July 2013, the FASB issued ASU 2013-11,  Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. ASU 2013-11 requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except as follows: to the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. We adopted the amendments in ASU 2013-11 in the first quarter of 2014. This update did not have any significant impact on our financial position, operating results or cash flows.

[0000926326-14-000010:mdna:52]
[same as prior period, unchanged from 0000926326-13-000016:mdna:64]

[0000926326-14-000010:mdna:53]
The table below shows the components of our consolidated results of operations as percentages of total revenues for the three months ended March 31, 2014 and 2013 (in thousands, except percentages):

[0000926326-14-000010:mdna:54]
|  | Three Months Ended |  |
|  | March 31, 2014 |  | March 31, 2013 |  |
|  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 82,580 |  |  | 81.1 | % |  | $ | 69,236 |  |  | 79.5 | % |  |
| Service and other revenues | 19,184 |  |  | 18.9 | % |  | 17,874 |  |  | 20.5 | % |  |
| Total revenues | 101,764 |  |  | 100.0 | % |  | 87,110 |  |  | 100.0 | % |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 38,900 |  |  | 38.2 | % |  | 33,547 |  |  | 38.5 | % |  |
| Cost of service and other revenues | 8,369 |  |  | 8.2 | % |  | 8,196 |  |  | 9.4 | % |  |
| Total cost of revenues | 47,269 |  |  | 46.4 | % |  | 41,743 |  |  | 47.9 | % |  |
| Gross profit | 54,495 |  |  | 53.6 | % |  | 45,367 |  |  | 52.1 | % |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 6,121 |  |  | 6.0 | % |  | 7,954 |  |  | 9.1 | % |  |
| Selling, general and administrative | 38,420 |  |  | 37.8 | % |  | 33,244 |  |  | 38.2 | % |  |
| Total operating expenses | 44,541 |  |  | 43.8 | % |  | 41,198 |  |  | 47.3 | % |  |
| Income from operations | 9,954 |  |  | 9.8 | % |  | 4,169 |  |  | 4.8 | % |  |
| Interest and other income (expense), net | (256 | ) |  | (0.3 | )% |  | (223 | ) |  | (0.3 | )% |  |
| Income before provision for income taxes | 9,698 |  |  | 9.5 | % |  | 3,946 |  |  | 4.5 | % |  |
| Provision for income taxes | 3,504 |  |  | 3.4 | % |  | 561 |  |  | 0.6 | % |  |
| Net income | $ | 6,194 |  |  | 6.1 | % |  | $ | 3,385 |  |  | 3.9 | % |  |

[0000926326-14-000010:mdna:55]
Revenues, Cost of Revenues and Gross Profit

[0000926326-14-000010:mdna:56]
The table below shows our consolidated revenues, cost of revenues and gross profit for the three months ended March 31, 2014 and 2013 and the change between those periods (in thousands, except percentages):

[0000926326-14-000010:mdna:57]
|  | Three Months Ended March 31, 2014 |  | Three Months Ended March 31, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Total revenues | $ | 81,499 |  |  | $ | 20,265 |  |  | $ | 101,764 |  |  | $ | 68,713 |  |  | $ | 18,397 |  |  | $ | 87,110 |  |
| Cost of revenues | 34,940 |  |  | 12,329 |  |  | 47,269 |  |  | 30,276 |  |  | 11,467 |  |  | 41,743 |  |
| Gross profit | $ | 46,559 |  |  | $ | 7,936 |  |  | $ | 54,495 |  |  | $ | 38,437 |  |  | $ | 6,930 |  |  | $ | 45,367 |  |
| Gross margin % | 57.1 | % |  | 39.2 | % |  | 53.6 | % |  | 55.9 | % |  | 37.7 | % |  | 52.1 | % |

[0000926326-14-000010:mdna:58]
Revenues. The increase in revenues for the three months ended March 31, 2014 was primarily driven by increased installations of our automation products and, to a lesser extent, increased consumables revenue related to our Medication Adherence segment.

[0000926326-14-000010:mdna:59]
We anticipate our revenues will continue to increase in 2014 compared to the same periods in 2013, as we fulfill our existing orders. Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality consumables to fulfill customer demand, the volume of installations we are able to complete and our ability to meet customer needs by providing a quality installation experience and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-14-000010:mdna:60]
Cost of revenues. The increase in cost of product revenues was primarily a function of revenue growth and overall product mix.

[0000926326-14-000010:mdna:61]
Gross profit. The increase in gross profit and gross margin percentage was primarily a result of the overall increase in revenues and changes in product mix.

[0000926326-14-000010:mdna:62]
Automation and Analytics Segment

[0000926326-14-000010:mdna:63]
The table below shows our Automation and Analytics segment results for the periods shown, and the change between those periods (in thousands, except percentages):

[0000926326-14-000010:mdna:64]
|  |  | Three Months Ended March 31, |  | Change in |
|  |  | 2014 |  | 2013 |  | $ |  | % |
| Product Revenue |  | $ | 63,120 |  |  | $ | 51,608 |  |  | $ | 11,512 |  |  | 22.3 | % |
| Service Revenue |  | 18,379 |  |  | 17,105 |  |  | 1,274 |  |  | 7.4 | % |
| Total revenues |  | 81,499 |  |  | 68,713 |  |  | 12,786 |  |  | 18.6 | % |
| Product Cost |  | 27,151 |  |  | 22,616 |  |  | 4,535 |  |  | 20.1 | % |
| Service Cost |  | 7,789 |  |  | 7,660 |  |  | 129 |  |  | 1.7 | % |
| Cost of revenues |  | 34,940 |  |  | 30,276 |  |  | 4,664 |  |  | 15.4 | % |
| Product Margin |  | 35,969 |  |  | 28,992 |  |  | 6,977 |  |  | 24.1 | % |
| Service Margin |  | 10,590 |  |  | 9,445 |  |  | 1,145 |  |  | 12.1 | % |
| Gross profit |  | $ | 46,559 |  |  | $ | 38,437 |  |  | $ | 8,122 |  |  | 21.1 | % |
| Gross margin % |  | 57.1 | % |  | 55.9 | % |  |  |  |  |

[0000926326-14-000010:mdna:65]
Our Automation and Analytics segment contributed $63.1 million in product revenue for the three months ended March 31, 2014 compared to $51.6 million for the same period in 2013. This growth was driven by increased installations of our automation and analytics products fueled by our strong booking performance in 2013, which is a result of continued competitive conversions, increased volume of upgrades to our G4 platform and sales of automated dispensing systems into non-acute care facilities. Service revenues for this segment, which reflect maintenance contracts, rentals of automation systems,

[0000926326-14-000010:mdna:66]
and training and professional services, contributed $18.4 million in services and other revenues for the three months ended March 31, 2014 compared to $17.1 million for the same period in 2013. This growth is a result of expansion of our installed customer base generated by new installations over the last year.

[0000926326-14-000010:mdna:67]
Our Automation and Analytics segment contributed $27.2 million in product costs for the three months ended March 31, 2014 compared to $22.6 million for the same period in 2013 while service costs of $7.8 million in the three months ended March 31, 2014 was relatively flat with the same period in 2013. The increase in product costs is primarily a function of the increased revenue and product mix.

[0000926326-14-000010:mdna:68]
Our Automation and Analytics segment gross profit on product revenue increased by $7.0 million for the three months ended March 31, 2014 compared to the same period in 2013 as a result of the overall increase in revenues. Product gross margin, which may fluctuate as a result of product mix, remained relatively flat for these same periods. Service gross profit increased by $1.1 million with a corresponding increase in service margins in excess of 12.1% which reflects the higher service revenues without a consistent increase in service staffing or spare parts usage. This increased efficiency is a result of higher reliability rates of our G4 product platform as compared to previous products.

[0000926326-14-000010:mdna:69]
Medication Adherence Segment

[0000926326-14-000010:mdna:70]
The table below shows our Medication Adherence segment results for the periods shown, and the change between those periods (in thousands, except percentages):

[0000926326-14-000010:mdna:71]
|  |  | Three Months Ended March 31, |  | Change in |
|  |  | 2014 |  | 2013 |  | $ |  | % |
| Product Revenue |  | $ | 19,460 |  |  | $ | 17,628 |  |  | $ | 1,832 |  |  | 10.4 | % |
| Service Revenue |  | 805 |  |  | 769 |  |  | 36 |  |  | 4.7 | % |
| Total revenues |  | 20,265 |  |  | 18,397 |  |  | 1,868 |  |  | 10.2 | % |
| Product Cost |  | 11,748 |  |  | 10,931 |  |  | 817 |  |  | 7.5 | % |
| Service Cost |  | 581 |  |  | 536 |  |  | 45 |  |  | 8.4 | % |
| Cost of revenues |  | 12,329 |  |  | 11,467 |  |  | 862 |  |  | 7.5 | % |
| Product Margin |  | 7,712 |  |  | 6,697 |  |  | 1,015 |  |  | 15.2 | % |
| Service Margin |  | 224 |  |  | 233 |  |  | (9 | ) |  | (3.9 | )% |
| Gross profit |  | $ | 7,936 |  |  | $ | 6,930 |  |  | $ | 1,006 |  |  | 14.5 | % |
| Gross margin % |  | 39.2 | % |  | 37.7 | % |  |  |  |  |  |

[0000926326-14-000010:mdna:72]
Our Medication Adherence segment contributed $19.5 million in product revenues for the three months ended March 31, 2014 as compared to $17.6 million for the same period in 2013. Our product revenues in this segment increased year over year due to increased sales of medication adherence blister cards and increased sales of OnDemand medication packaging systems. Service revenues in this segment remained approximately 4.1% of total revenue and showed a modest increase commensurate with our growing installed base.

[0000926326-14-000010:mdna:73]
Our Medication Adherence segment contributed product costs of $11.7 million for the three months ended March 31, 2014 as compared to $10.9 million for the same period in 2013. These higher costs are attributable to the product revenue growth in this segment.

[0000926326-14-000010:mdna:74]
Our Medication Adherence segment's increase in gross profit and gross margin percentage for the three months ended March 31, 2014, reflect primarily a product mix shift towards higher value medication adherence solutions.

[0000926326-14-000010:mdna:75]
[same as prior period, unchanged from 0000926326-13-000016:mdna:94]

[0000926326-14-000010:mdna:76]
The table below shows our operating expenses for the three months ended March 31, 2014 and 2013 and the change between those periods (in thousands, except percentages):

[0000926326-14-000010:mdna:77]
|  | Three Months Ended March 31, |  | Change in |
|  | 2014 |  | 2013 |  | $ |  | % |
| Research and development | $ | 6,121 |  |  | $ | 7,954 |  |  | $ | (1,833 | ) |  | (23.0 | )% |
| Selling, general and administrative | 38,420 |  |  | 33,244 |  |  | 5,176 |  |  | 15.5 | % |
| Total operating expenses | $ | 44,541 |  |  | $ | 41,198 |  |  | $ | 3,343 |  |  | 8.1 | % |

[0000926326-14-000010:mdna:78]
Research and Development. The overall decrease in research and development expenses was primarily due to a $1.6 million decrease in research and development expenses attributable to the Medication Adherence segment which was driven by a one-time $1.8 million write-off of previously capitalized software development costs in the first quarter of 2013, partially offset by $0.2 million increase in consulting related expense. The Automation and Analytics segment contributed $0.3 million to the decrease in research and development expenses in the three months ended March 31, 2014 compared to the same period in 2013, primarily driven by $1.0 million increase in capitalized software effort due to the higher level of post-feasibility beta testing, partially offset by an increase of $0.7 million in employee related expenses due to increased staffing and higher year over year benefit costs.

[0000926326-14-000010:mdna:79]
[same as prior period, unchanged from 0000926326-13-000016:mdna:100]

[0000926326-14-000010:mdna:80]
Selling, General and Administrative. The overall increase in selling, general and administrative expenses reflected a $4.6 million increase attributable to the Automation and Analytics segment. The increase was driven primarily by $0.9 million in commission expenses associated with increased revenues, $1.5 million employee related expenses due to increased staffing and higher year over year benefit costs, $1.3 million in compensation expense which was higher due to a significant portion of variable compensation not being earned in the three month ended March 31, 2013 due to the fact that we did not achieve our company goals, and $0.9 million in consulting and professional fees driven by merger and acquisition related activities and increased accounting and auditing fees.

[0000926326-14-000010:mdna:81]
We expect selling, general, and administrative expenses to remain relatively flat as a percentage of our revenue on an annual basis and to grow in absolute dollars in the future as our revenue grows to support our anticipated growth as well as international expansion efforts.

[0000926326-14-000010:mdna:82]
[same as prior period, unchanged from 0000926326-13-000016:mdna:105]

[0000926326-14-000010:mdna:83]
The annual effective tax rate before discrete items was 39.1% and 37.4% for the three months ended March 31, 2014 and 2013, respectively. The increase in the estimated annual effective tax rate for the three months ended March 31, 2014 compared to the same period in 2013 was primarily due to the reinstatement of the federal research and development credit in January of 2013 which was partially offset by a decrease in other non-deductible expenditures. The impact of these amounts was 2.2%  and (0.5)%, respectively.

[0000926326-14-000010:mdna:84]
[same as prior period, unchanged from 0000926326-13-000016:mdna:107]

[0000926326-14-000010:mdna:85]
We had cash and cash equivalents of $107.6 million at March 31, 2014, compared to $104.5 million at December 31, 2013. All of our cash and cash equivalents are invested in demand deposits or money market funds.

[0000926326-14-000010:mdna:86]
In September 2013, we entered into a Credit Agreement with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time, which provides for a $75.0 million revolving credit facility to be used for general corporate purposes, including future acquisitions. The Credit Agreement permits us to request one or more increases in the aggregate commitment provided such increases do not exceed $25.0 million in the aggregate. The Credit Agreement contains affirmative and negative covenants, and financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each fiscal quarter. We were in full compliance with all covenants at March 31, 2014. For additional details, refer to Note 16, Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000926326-14-000010:mdna:87]
Based on our current business plan and revenue backlog, we believe that our existing cash, cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan, along with the availability of funds under our $75.0 million Credit Agreement, will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-14-000010:mdna:88]
Cash flows for the three months ended March 31, 2014 and 2013, and the change between those periods, are as follows (in thousands):

[0000926326-14-000010:mdna:89]
|  | Three Months Ended March 31, |  |
|  | 2014 |  | 2013 | Change |
| Net cash provided by operating activities | $ | 1,117 |  |  | $ | 4,132 |  | $ | (3,015 | ) |
| Net cash used in investing activities | (5,592 | ) |  | (5,247 | ) | (345 | ) |
| Net cash provided by financing activities | 7,493 |  |  | 8,659 |  | (1,166 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 9 |  |  | (40 | ) | 49 |  |
| Net increase in cash and cash equivalents | $ | 3,027 |  |  | $ | 7,504 |  | $ | (4,477 | ) |

[0000926326-14-000010:mdna:90]
Operating activities. The decrease in net cash provided by operating activities was primarily due to a $6.4 million increase in accounts receivable as a result of timing of shipments and a $2.9 million decrease in accrued compensation primarily due payment of accrued incentive bonus during the first quarter of 2014. These uses of cash were partially offset by a $3.6 million increase in accounts payable driven primarily by the timing of payments during the first quarter of 2014, and $2.8 million increase in net income.

[0000926326-14-000010:mdna:91]
Investing activities. Net cash used in investing activities increased primarily due to $1.0 million increase in capitalized software development costs, partially offset by $0.7 million decrease in cash used for purchases of property and equipment.

[0000926326-14-000010:mdna:92]
Financing activities. Net cash provided by financing activities decreased primarily due to stock repurchases of $4.1 million in the first quarter of 2014, partially offset by an increase of $1.3 million in cash generated from shares issued under stock option and employee stock purchase plans and $1.7 million in tax benefits associated with employee stock plans.

[0000926326-14-000010:mdna:93]
[same as prior period, unchanged from 0000926326-13-000016:mdna:117]

[0000926326-14-000010:mdna:94]
There were no material changes to our contractual obligations during the three months ended March 31, 2014. For a description of our facility leases and contractual obligations, refer to our Annual Report on Form 10-K for the year ended December 31, 2013 and the Notes to the Consolidated Financial Statements included therein.

[0000926326-14-000010:mdna:95]
The following table summarizes our contractual obligations at March 31, 2014 (in thousands):

[0000926326-14-000010:mdna:96]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | More than five years |
| Operating leases (1) (2) | $ | 40,608 |  |  | $ | 5,925 |  |  | $ | 10,449 |  |  | $ | 8,728 |  |  | $ | 15,506 |  |
| Commitments to contract manufacturers and suppliers (3) | 9,653 |  |  | 9,653 |  |  | — |  |  | — |  |  | — |  |
| Total (4) | $ | 50,261 |  |  | $ | 15,578 |  |  | $ | 10,449 |  |  | $ | 8,728 |  |  | $ | 15,506 |  |

[0000926326-14-000010:mdna:97]
(1)     Commitments under operating leases relate primarily to leasehold property and office equipment.

[0000926326-14-000010:mdna:98]
[same as prior period, unchanged from 0000926326-13-000016:mdna:122]

[0000926326-14-000010:mdna:99]
[same as prior period, unchanged from 0000926326-13-000016:mdna:123]

[0000926326-14-000010:mdna:100]
| (4) | At March 31, 2014, we have recorded $5.2 million for uncertain tax positions under long term liabilities, in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. |

[0000926326-14-000010:mdna:101]
[same as prior period, unchanged from 0000926326-13-000016:mdna:86]

[0000926326-14-000010:mdna:102]
| (5) | Accordingly, as the timing and amount of payment cannot be estimated, a $5.2 million of uncertain tax position liability has not been included in the contractual obligations table. |

[0000926326-14-000010:mdna:103]
[same as prior period, unchanged from 0000926326-13-000016:mdna:125]

[0000926326-14-000010:mdna:104]
As of March 31, 2014, we had no off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
