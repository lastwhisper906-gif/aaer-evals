# OMCL note change history — 0000926326-13-000016 → 0000926326-14-000010


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-05-12):
[0000926326-14-000010:note_history:1]
On March 8, 2013, Bobbi Polanco (“Polanco”) filed a putative class action complaint in the United States District Court for the District of New Jersey (the "Court") against Omnicell and certain of our customers (Case No. 1:13-cv-01417-NLH-KLM) alleging breach of state security notification laws, violations of state consumer fraud laws, fraud, negligence and conspiracy relating to the theft of an Omnicell electronic device containing medication dispensing cabinet log files, including certain patient health information, and subsequent notification of this unauthorized disclosure of personal health information. Polanco is seeking an injunction against the defendants to prevent each of them from committing the acts complained of in the future and monetary damages, costs and expenses. On May 2, 2013, the Court entered an order to show cause which provided, in relevant part, that Polanco is required to show cause as to why the case should not be dismissed for lack of subject matter jurisdiction. On May 13, 2013, Polanco filed an amended complaint. On May 31, 2013, Omnicell filed a motion to dismiss the complaint on the grounds that Polanco failed to satisfy constitutional standing requirements and that she failed to state a claim against Omnicell  for violating  state data breach notification statutes, consumer fraud, common law fraud, negligence and conspiracy. Omnicell also joined in the arguments of the other defendants seeking dismissal. On July 1, 2013, Polanco filed an opposition to the motions to dismiss. On July 15, 2013, Omnicell filed its reply to the opposition from Polanco. In December 2013, the Court granted the defendants' motions to dismiss without prejudice. Polanco failed to file an appeal of the Court's decision by the January 27, 2014 deadline.
  (was, 2013-11-08, similarity 0.8996):
[0000926326-13-000016:note_history:1]
On March 8, 2013, Bobbi Polanco (“Polanco”) filed a putative class action complaint in the United States District Court for the District of New Jersey against Omnicell and certain of our customers (Case No. 1:13-cv-01417-NLH-KLM) alleging breach of state security notification laws, violations of state consumer fraud laws, fraud, negligence and conspiracy relating to the theft of an Omnicell electronic device containing medication dispensing cabinet log files, including certain patient health information, and subsequent notification of this unauthorized disclosure of personal health information. Polanco is seeking an injunction against the defendants to prevent each of them from committing the acts complained of in the future and monetary damages, costs and expenses. On May 2, 2013, the United States District Court for the District of New Jersey entered an order to show cause which provided, in relevant part, that Polanco is required to show cause as to why the case should not be dismissed for lack of subject matter jurisdiction. On May 13, 2013, Polanco filed an amended complaint. On May 31, 2013, Omnicell filed a motion to dismiss the complaint on the grounds that Polanco failed to satisfy constitutional standing requirements and that she failed to state a claim against Omnicell  for violating  state data breach notification statutes, consumer fraud, common law fraud, negligence and conspiracy. Omnicell also joined in the arguments of the other defendants seeking dismissal. On July 1, 2013, Polanco filed an opposition to the motions to dismiss. On July 15, 2013, Omnicell filed its reply to the opposition from Polanco. Omnicell is currently awaiting a decision from the court and intends to defend the matter vigorously.

- changed (2014-05-12):
[0000926326-14-000010:note_history:2]
As required under ASC 450, Contingencies, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We did not record any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that any potential loss, while reasonably possible, was not probable. We believe that we have valid defenses with respect to legal proceedings pending against us. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.
  (was, 2013-11-08, similarity 0.8095):
[0000926326-13-000016:note_history:2]
As required under ASC 450, Contingencies, we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We believe that we have valid defenses with respect to legal proceedings pending against us. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

- changed (2014-05-12):
[0000926326-14-000010:note_history:3]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of March 31, 2014 or December 31, 2013.
  (was, 2013-11-08, similarity 0.9941):
[0000926326-13-000016:note_history:3]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of September 30, 2013 or December 31, 2012.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-05-12):
[0000926326-14-000010:note_history:4]
Description of the Company. Omnicell, Inc. ("Omnicell," "our," "us," "we," or the "Company") was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication supply control systems and medical adherence solutions which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States and Canada.

- changed (2014-05-12):
[0000926326-14-000010:note_history:5]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of March 31, 2014, the results of their operations, comprehensive income and cash flows for the three months ended March 31, 2014 and 2013. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2013.
  (was, 2013-11-08, similarity 0.9307):
[0000926326-13-000016:note_history:5]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of September 30, 2013, the results of their operations and comprehensive income for the three and nine months ended September 30, 2013 and 2012 and their cash flows for the nine months ended September 30, 2013 and 2012. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2012.

- added (2014-05-12):
[0000926326-14-000010:note_history:6]
Our results of operations, comprehensive income and cash flows for the three months ended March 31, 2014 are not necessarily indicative of results that may be expected for the year ending December 31, 2014, or for any future period.

- added (2014-05-12):
[0000926326-14-000010:note_history:7]
Use of estimates. GAAP requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, valuation of goodwill and purchased intangibles, valuation of long-lived assets and accounting for income taxes.

- added (2014-05-12):
[0000926326-14-000010:note_history:8]
Principles of consolidation. The condensed consolidated financial statements include the accounts of our wholly-owned subsidiaries. All significant inter-company accounts and transactions have been eliminated in consolidation.

- added (2014-05-12):
[0000926326-14-000010:note_history:9]
Concentration of credit risk. Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there was no single customer accounting for 10% or more of revenues in the three months ended March 31, 2014. Additionally, there was no single customer accounting for 10% or more of accounts receivable at March 31, 2014 or December 31, 2013. We believe that we have no significant concentrations of credit risk at March 31, 2014.

- added (2014-05-12):
[0000926326-14-000010:note_history:10]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended March 31, 2014 and 2013 totaled approximately $8.9 million and $7.2 million, respectively.

- added (2014-05-12):
[0000926326-14-000010:note_history:11]
There have been no material changes in our significant accounting policies as of and for the three months ended March 31, 2014, compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2013.

- added (2014-05-12):
[0000926326-14-000010:note_history:12]
Recently Adopted Accounting Standards

- added (2014-05-12):
[0000926326-14-000010:note_history:13]
In July 2013, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2013-11,  Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. ASU 2013-11 requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except as follows: to the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. We adopted the amendments in ASU 2013-11 in the first quarter of 2014. This update did not have a significant impact on our financial position, operating results or cash flows.

- removed (2014-05-12):
[0000926326-13-000016:note_history:14]
Description of the Company. Omnicell, Inc. ("Omnicell," "our," "us," "we," or the "Company") was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication and supply control systems which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States. On May 21, 2012, we completed our acquisition of MedPak Holdings, Inc. ("MedPak"). MedPak is the parent company of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems. This acquisition aligns us with the long-term trends of the healthcare market to manage the health of patients across the continuum of care. We now serve both the acute care and non-acute care markets. Please refer to Note 14, "Business Acquisition" for more information regarding the transaction.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-12):
[0000926326-14-000010:note_history:15]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each fiscal quarter. We were in full compliance with all covenants at March 31, 2014.
  (was, 2013-11-08, similarity 0.9868):
[0000926326-13-000016:note_history:15]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case,  as of the last day of each fiscal quarter. We were in full compliance with all covenants at September 30, 2013.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2014-05-12):
[0000926326-13-000016:note_history:16]
Revenue recognition. We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems with related services, which are sold in our principal market, which is the healthcare industry. Revenues related to consumable products are reported net of discounts provided to our customers. Our customer arrangements typically include one or more of the following deliverables:

- removed (2014-05-12):
[0000926326-13-000016:note_history:17]
| • | Products—Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies. |

- removed (2014-05-12):
[0000926326-13-000016:note_history:18]
| • | Software—Additional software applications that enable incremental functionality of our equipment. |

- removed (2014-05-12):
[0000926326-13-000016:note_history:19]
| • | Installation—Installation of equipment as integrated systems at customers' sites. |

- removed (2014-05-12):
[0000926326-13-000016:note_history:20]
| • | Post-installation technical support—Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available. |

- removed (2014-05-12):
[0000926326-13-000016:note_history:21]
| • | Professional services—Other customer services such as training and consulting. |

- removed (2014-05-12):
[0000926326-13-000016:note_history:22]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

- removed (2014-05-12):
[0000926326-13-000016:note_history:23]
| • | Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for equipment leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement. |

- removed (2014-05-12):
[0000926326-13-000016:note_history:24]
| • | Delivery has occurred. Equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installed installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. We recognize revenue from sales of products to distributors upon delivery, when no contractual obligations for installation exists, assuming all other revenue criteria are met since we do not allow for rights of return or refund. For sales to distributors where we assume contractual installation obligations or new distributors whom we have not fully trained to install our products, the equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period, and we recognize revenue on training and professional services as those services are performed. |

- removed (2014-05-12):
[0000926326-13-000016:note_history:25]
| • | Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services. |

- removed (2014-05-12):
[0000926326-13-000016:note_history:26]
| • | Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable. |

- removed (2014-05-12):
[0000926326-13-000016:note_history:27]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. We allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support services and professional services. When VSOE of fair value is not available, third-party evidence ("TPE") of fair value for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE, TPE and BESP information and obtain formal approval by appropriate levels of management.

- removed (2014-05-12):
[0000926326-13-000016:note_history:28]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable on the basis of its estimated selling price. In addition, the amount recognized for any delivered items cannot exceed that which is not contingent upon delivery of any remaining items in the arrangement.

- removed (2014-05-12):
[0000926326-13-000016:note_history:29]
We also use the residual method of allocating the arrangement consideration in certain circumstances. We use the residual method to allocate total arrangement consideration between delivered and undelivered items for any arrangements entered into prior to January 1, 2011 and not subsequently materially-modified. The use of the residual method is required by software revenue recognition rules that applied to sales of most of our products and services until the adoption of the new revenue recognition guidance. We also use the residual method to allocate revenue between the software products that enable incremental equipment functionality and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

- removed (2014-05-12):
[0000926326-13-000016:note_history:30]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.
