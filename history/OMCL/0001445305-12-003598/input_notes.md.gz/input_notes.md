# OMCL notes — 0001445305-12-003598


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0001445305-12-003598:notes:1]
The following table summarizes the credit losses and recorded investment in sales-type leases, excluding unearned interest, as of September 30, 2012 and December 31, 2011 (in thousands):

[0001445305-12-003598:notes:2]
|  | Allowance for Credit Losses |  | Recorded Investmentin Sales-type Leases Gross |  | Recorded Investmentin Sales-type Leases Net |
| Credit loss disclosure for September 30, 2012 : |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | 518 |  |  | $ | 518 |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 119 |  |  | 15,136 |  |  | 15,017 |  |
| Ending balances: September 30, 2012 | $ | 637 |  |  | $ | 15,654 |  |  | $ | 15,017 |  |
| Credit loss disclosure for December 31, 2011 : |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | 178 |  |  | $ | 178 |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 106 |  |  | 13,940 |  |  | 13,834 |  |
| Ending balances: December 31, 2011 | $ | 284 |  |  | $ | 14,118 |  |  | $ | 13,834 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001445305-12-003598:notes:3]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of September 30, 2012, the results of their operations and comprehensive income for the three months and nine months ended September 30, 2012 and 2011 and their cash flows for the nine months ended September 30, 2012 and 2011. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2011.

[0001445305-12-003598:notes:4]
Our results of operations, comprehensive income and cash flows for the three months and nine months ended September 30, 2012 are not necessarily indicative of results that may be expected for the year ending December 31, 2012, or for any future period.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001445305-12-003598:notes:5]
[same as prior period, unchanged from 0001445305-12-002594:notes:5]

[0001445305-12-003598:notes:6]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Revenues | $ | 84,331 |  |  | $ | 82,468 |  |  | $ | 252,601 |  |  | $ | 239,715 |  |
| Net income | $ | 6,920 |  |  | $ | 3,785 |  |  | $ | 13,515 |  |  | $ | 9,841 |  |

[0001445305-12-003598:notes:7]
[same as prior period, unchanged from 0001445305-12-002594:notes:7]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001445305-12-003598:notes:8]
[same as prior period, unchanged from 0001445305-12-002594:notes:8]

[0001445305-12-003598:notes:9]
On May 21, 2012, we completed our merger with MedPak Holdings, Inc. (“MedPak”) pursuant to an Agreement and Plan of Merger (the “Merger Agreement”) under which Mercury Acquisition Corp, a newly formed Omnicell subsidiary, was merged with and into MedPak, with MedPak surviving the merger as a wholly-owned subsidiary of Omnicell. MedPak is the parent company of MTS.

[0001445305-12-003598:notes:10]
Pursuant to the terms of the Merger Agreement, we paid approximately $158.3 million in cash after adjustments provided for in the Merger Agreement, of which approximately $13.5 million was placed in an escrow fund, which will be distributed to MedPak's stockholders (subject to claims that we may make against the escrow fund for indemnification and other claims following the closing). We had accrued a $1.8 million liability against this escrow fund as of June 30, 2012, based on additional estimated working capital adjustments as provided under the Merger Agreement.

[0001445305-12-003598:notes:11]
As of September 30, 2012, the working capital adjustment has been finalized with a resulting reduction in goodwill of $0.3 million and a corresponding reduction in accrued liabilities, leaving a balance of $1.5 million. In October 2012, the portion of the escrow fund set aside for the working capital adjustment was disbursed with Omnicell receiving $0.3 million and Medpak's former stockholders receiving the remainder.

[0001445305-12-003598:notes:12]
The MTS acquisition primarily was to align Omnicell with the long term trends of the healthcare market to manage the health of patients across the continuum of care. We can now better serve both the acute care and non-acute care markets. Omnicell and MTS bring capabilities to each other that strengthen the product lines and expand the medication management coverage of both companies.

[0001445305-12-003598:notes:13]
We are accounting for the transaction under the acquisition method of accounting in accordance with the provisions of FASB ASC Topic 805, Business Combinations. Under the acquisition method, the estimated fair value of the consideration transferred to purchase the acquired company is allocated to the assets acquired and the liabilities assumed based on their fair values. We have made significant estimates and assumptions in determining the allocation of the acquisition consideration. The revised acquisition consideration of $159.8 million is comprised of $158.3 million in cash at closing plus an estimated $1.5 million net working capital adjustment recorded in accrued liabilities, subject to review by the seller and possible adjustment.

[0001445305-12-003598:notes:14]
[same as prior period, unchanged from 0001445305-12-002594:notes:13]

[0001445305-12-003598:notes:15]
The total revised acquisition price was approximately $159.8 million and the preliminary acquisition price allocation is comprised of the following (in thousands):

[0001445305-12-003598:notes:16]
|  |  | Fair value acquired |  |  |
| Cash including restricted cash |  | $ | 2,000 |  |  |
| Accounts receivable |  | 7,403 |  |  |
| Inventory |  | 11,726 |  |  |
| Deferred tax assets and other current assets |  | 2,864 |  |  |
| Total current assets |  | 23,993 |  |  |
| Property and equipment |  | 11,088 |  |  |
| Intangibles |  | 83,500 |  |  |
| Goodwill |  | 84,140 |  |  |
| Other non-current assets |  | 244 |  |  |
| Total assets |  | 202,965 |  |  |
| Current liabilities |  | (8,046 | ) |  |
| Non-current deferred tax liabilities |  | (33,898 | ) |  |
| Other non-current liabilities |  | (1,227 | ) |  |
| Net assets acquired |  | $ | 159,794 |  |  |
| Cash consideration, fair value |  | $ | 159,794 |  |  |

[0001445305-12-003598:notes:17]
Accounts receivable is presented at its fair value, comprised of total contractual obligations due of $7.6 million, of which $0.2 million is not expected to be collected. Based on an acquisition date valuation, the estimated fair values of acquired inventory and property and equipment exceeded their historical carrying values.

[0001445305-12-003598:notes:18]
[same as prior period, unchanged from 0001445305-12-002594:notes:17]

[0001445305-12-003598:notes:19]
[same as prior period, unchanged from 0001445305-12-002594:notes:18]

[0001445305-12-003598:notes:20]
For income tax purposes, the historical tax bases of the acquired assets and assumed liabilities, along with the tax attributes of the MTS companies, will carryover. Because the transaction was a cash-for-stock transaction, there is no tax basis in the newly acquired intangible assets. Accordingly, the acquisition accounting includes the establishment of net deferred tax liabilities of $33.9 million, resulting from book tax basis differences related to the intangible assets acquired, as well as to the step up in the value of fixed assets and inventory to their estimated fair values at the time of acquisition.

[0001445305-12-003598:notes:21]
Goodwill. Approximately $84.1 million has been allocated to goodwill. Goodwill represents the excess of the fair value of the consideration transferred over the fair value of the underlying net tangible and identifiable intangible assets on the acquisition date. In accordance with ASC Topic 350, Intangibles - Goodwill and Other, goodwill will not be amortized, but instead will be tested for impairment at least annually or more frequently if certain indicators are present. In the event our management determines that the value of goodwill has become impaired, we will incur an accounting charge for the amount of impairment during the quarter in which the determination is made. We believe the MTS acquisition enhances our offerings and diversifies our revenue mix, providing a more robust product and service solution to its current customers while expanding Omnicell’s international presence. We consider these factors as supporting the amount of goodwill recorded.

[0001445305-12-003598:notes:22]
[same as prior period, unchanged from 0001445305-12-002594:notes:21]

[0001445305-12-003598:notes:23]
[same as prior period, unchanged from 0001445305-12-002594:notes:22]

[0001445305-12-003598:notes:24]
For the nine months ended September 30, 2012, we incurred approximately $3.2 million in acquisition-related costs in connection with the MTS acquisition. These costs are included in selling, general and administrative expenses on our Condensed Consolidated Statement of Operations.

[0001445305-12-003598:notes:25]
During the three months ended September 30, 2012, the acquired MTS operations (consolidated since the May 21, 2012 acquisition date) generated revenue of approximately $18.3 million and net income of $1.9 million.

[0001445305-12-003598:notes:26]
The pro forma unaudited condensed consolidated operating results presented above were calculated after applying Omnicell's accounting policies and by adding together the historical operating statements of MTS and Omnicell, with certain adjustments, assuming an acquisition date of January 1, 2011. The adjustments include replacement of MTS historical depreciation and amortization expense with acquisition-accounting depreciation and amortization expense, based on the estimated fair values and useful lives determined from the allocation of total MTS acquisition consideration. Also reflected is the interest expense elimination effect of MTS on its debt (since it would have been paid off at acquisition) and the elimination of certain management fees to an affiliated party, offset in part by interest income foregone by Omnicell, by no longer having the acquisition consideration available as interest-bearing cash, cash equivalents and short-term investments.

[0001445305-12-003598:notes:27]
[same as prior period, unchanged from 0001445305-12-002594:notes:26]

[0001445305-12-003598:notes:28]
[same as prior period, unchanged from 0001445305-12-002594:notes:27]


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001445305-12-003598:notes:29]
[same as prior period, unchanged from 0001445305-12-002594:notes:28]

[0001445305-12-003598:notes:30]
Cash and cash equivalents and short-term investments consist of the following significant investment asset classes, with disclosure of amortized cost, gross unrealized gains and losses, and fair value as of September 30, 2012 and December 31, 2011 (in thousands):

[0001445305-12-003598:notes:31]
|  | September 30, 2012 |  |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | Short-termInvestments |  | SecurityClassification |
| Cash | $ | 22,911 |  |  | $ | — |  |  | $ | — |  |  | $ | 22,911 |  |  | $ | 22,911 |  |  | $ | — |  |  | N/A |
| Money market funds | 31,907 |  |  | — |  |  | — |  |  | 31,907 |  |  | 31,907 |  |  | — |  |  | Available for sale |
| Total cash, cash equivalents and short-term investments | $ | 54,818 |  |  | $ | — |  |  | $ | — |  |  | $ | 54,818 |  |  | $ | 54,818 |  |  | $ | — |  |  |  |

[0001445305-12-003598:notes:32]
[same as prior period, unchanged from 0001445305-12-002594:notes:31]

[0001445305-12-003598:notes:33]
The money market fund is a daily-traded cash equivalent with a price of $1.00, making it a Level 1 asset class, and its carrying cost closely approximates fair value. As demand deposit (cash) balances vary with the timing of collections and payments, the money market fund can cover any surplus or deficit, and thus is considered Available-for-sale.

[0001445305-12-003598:notes:34]
[same as prior period, unchanged from 0001445305-12-002594:notes:33]

[0001445305-12-003598:notes:35]
[same as prior period, unchanged from 0001445305-12-002594:notes:34]

[0001445305-12-003598:notes:36]
|  | Quoted Prices in ActiveMarkets for IdenticalInstruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant UnobservableInputs(Level 3) |  | Total FairValue |
| At September 30, 2012 |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 31,907 |  |  | $ | — |  |  | — |  |  | $ | 31,907 |  |
| Total | $ | 31,907 |  |  | $ | — |  |  | — |  |  | $ | 31,907 |  |
| At December 31, 2011 |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 177,310 |  |  | — |  |  | — |  |  | $ | 177,310 |  |
| Non U.S. Government securities | — |  |  | $ | 8,107 |  |  | — |  |  | 8,107 |  |
| Total | $ | 177,310 |  |  | $ | 8,107 |  |  | — |  |  | $ | 185,417 |  |

[0001445305-12-003598:notes:37]
[same as prior period, unchanged from 0001445305-12-002594:notes:36]


## us-gaap:CommitmentsDisclosureTextBlock

[0001445305-12-003598:notes:38]
[same as prior period, unchanged from 0001445305-12-002594:notes:37]

[0001445305-12-003598:notes:39]
At September 30, 2012, the minimum payments under our operating leases for each of the five succeeding fiscal years were as follows (in thousands):

[0001445305-12-003598:notes:40]
| 2012 (remaining three months) | $ | 1,518 |  |
| 2013 | 5,595 |  |
| 2014 | 5,367 |  |
| 2015 | 5,187 |  |
| 2016 | 4,908 |  |
| 2017 | 4,217 |  |
| Thereafter | 20,301 |  |
| Total | $ | 47,093 |  |

[0001445305-12-003598:notes:41]
[same as prior period, unchanged from 0001445305-12-002594:notes:40]

[0001445305-12-003598:notes:42]
In October 2011, we entered into a lease agreement for approximately 100,000 square feet of office space. Pursuant to the lease agreement, the landlord has constructed a single, three-story building of rentable space located at 590 Middlefield Road in Mountain View, California which we will lease and which will serve as our headquarters. The term of the lease agreement is for a period of 10 years, and will commence in November 2012, with a base lease commitment of approximately $40.0 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term.

[0001445305-12-003598:notes:43]
In March 2012, we entered into a lease agreement for approximately 46,000 square feet of manufacturing, distribution and office space located at 735 Sycamore Drive in Milpitas, California which commenced in October 2012. The term of the lease agreement is for a period of 60 months, with a base lease commitment of approximately $1.8 million and a single 60 month extension option.

[0001445305-12-003598:notes:44]
Commencing with the acquisition of MTS, we assumed responsibility for its 132,500 square feet of manufacturing, warehousing and office space in St. Petersburg, Florida. The remaining term of the original 12 year lease agreement is through September 30, 2016 with a remaining base lease commitment of approximately $3.7 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term.

[0001445305-12-003598:notes:45]
In Leeds, United Kingdom, we lease an office and distribution center. The remaining term of the original 10 year lease agreement is through June 8, 2021, with no extension options. The remaining base lease commitment, converted from British Pounds at the current conversion rate, is approximately $1.2 million. We also have smaller rented offices in Strongsville, Ohio and Germany.

[0001445305-12-003598:notes:46]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. Our near-term commitments to our contract manufacturers and suppliers totaled $6.3 million as of September 30, 2012.

[0001445305-12-003598:notes:47]
At September 30, 2012, we have recorded $3.5 million for uncertain tax positions under long term liabilities, in accordance with GAAP, summarized under Note 1, “Organization and Summary of Significant Accounting Policies.” As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the current balance of the uncertain tax position liabilities has not been included in the table of commitments above.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001445305-12-003598:notes:48]
[same as prior period, unchanged from 0001445305-12-002594:notes:47]

[0001445305-12-003598:notes:49]
[same as prior period, unchanged from 0001445305-12-002594:notes:48]

[0001445305-12-003598:notes:50]
Currency Forward Contracts

[0001445305-12-003598:notes:51]
From time to time we enter into foreign currency forward contracts to protect our business from the risk that the eventual cash flows resulting from intercompany transactions between Omnicell and our foreign subsidiaries. These transactions primarily arise as a result of products manufactured in the U.S. and sold to foreign subsidiaries in U.S. dollars rather than the subsidiaries' functional currencies.

[0001445305-12-003598:notes:52]
These forward contracts are considered to be financial derivative instruments and are recorded at fair value in the balance sheet. Changes in fair values of these financial derivative instruments are either recognized in other comprehensive income (a component of stockholders' equity) or net income depending on whether the derivative has been designated and qualifies as a hedging instrument. As of September 30, 2012, we had no foreign currency forward contracts outstanding.


## us-gaap:DerivativesPolicyTextBlock

[0001445305-12-003598:notes:53]
[same as prior period, unchanged from 0001445305-12-002594:notes:53]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001445305-12-003598:notes:54]
[same as prior period, unchanged from 0001445305-12-002594:notes:54]

[0001445305-12-003598:notes:55]
[same as prior period, unchanged from 0001445305-12-002594:notes:55]

[0001445305-12-003598:notes:56]
At September 30, 2012, a total of 1,817,936 shares of common stock were reserved for future issuance under our 2009 Equity Incentive Plan (the “2009 Plan”). At September 30, 2012, $6.5 million of total unrecognized compensation cost related to non-vested stock options was expected to be recognized over a weighted average period of 2.7 years.

[0001445305-12-003598:notes:57]
A summary of aggregate option activity for the nine months ended September 30, 2012 is presented below:

[0001445305-12-003598:notes:58]
| Options: |  | Number of Shares |  | Weighted- Average Exercise Price |
|  |  | (in thousands) |  |  |
| Outstanding at December 31, 2011 |  | 4,693 |  |  | $ | 13.36 |  |
| Granted |  | 473 |  |  | $ | 15.15 |  |
| Exercised |  | (362 | ) |  | $ | 8.61 |  |
| Forfeited |  | (65 | ) |  | $ | 13.71 |  |
| Expired |  | (100 | ) |  | $ | 21.58 |  |
| Outstanding at September 30, 2012 |  | 4,639 |  |  | $ | 13.73 |  |
| Exercisable at September 30, 2012 |  | 3,513 |  |  | $ | 13.60 |  |

[0001445305-12-003598:notes:59]
[same as prior period, unchanged from 0001445305-12-002594:notes:59]

[0001445305-12-003598:notes:60]
The non-employee members of our Board of Directors are granted restricted stock on the day of our annual meeting of stockholders and such shares of restricted stock vest on the date of the subsequent year’s annual meeting of stockholders, provided such non-employee director remains a director on such date. Restricted stock units (“RSUs”) are granted to certain of our employees and generally vest over a period of four years and are expensed ratably on a straight-line basis over the vesting period. The fair value of both restricted stock and RSUs granted pursuant to our stock option plans is the product of the number of shares granted and the grant date fair value of our common stock. Our unrecognized compensation cost related to non-vested restricted stock at September 30, 2012 was approximately $0.6 million and is expected to be recognized over a weighted-average period of 0.6 years. Expected future compensation expense relating to RSUs outstanding on September 30, 2012 is $4.9 million over a weighted-average period of 2.6 years.

[0001445305-12-003598:notes:61]
A summary of activity of both restricted stock and RSUs for the nine months ended September 30, 2012 is presented below:

[0001445305-12-003598:notes:62]
|  | Restricted Stock |  | Restricted Stock Units |
|  |  |  | Weighted - |  |  |  | Weighted - |
|  | Number ofShares |  | AverageGrant DateFair Value PerShare |  | Number ofShares |  | AverageGrant DateFair Value PerShare |
|  | (in thousands) |  |  |  | (in thousands) |  |  |
| Non-vested, December 31, 2011 | 68 |  |  | $ | 14.71 |  |  | 287 |  |  | $ | 13.03 |  |
| Granted | 67 |  |  | $ | 14.19 |  |  | 218 |  |  | $ | 14.80 |  |
| Vested | (68 | ) |  | $ | 14.71 |  |  | (86 | ) |  | $ | 12.76 |  |
| Forfeited | — |  |  | — |  |  | (16 | ) |  | $ | 14.46 |  |
| Non-vested, September 30, 2012 | 67 |  |  | $ | 14.19 |  |  | 403 |  |  | $ | 13.98 |  |

[0001445305-12-003598:notes:63]
[same as prior period, unchanged from 0001445305-12-002594:notes:63]

[0001445305-12-003598:notes:64]
In 2011, we began incorporating performance-based restricted stock units (“PSUs”) as an element of our executive compensation plans. Our unrecognized compensation cost related to non-vested performance-based restricted stock units at September 30, 2012 was approximately $1.0 million and is expected to be recognized over a weighted-average period of 1.4 years.

[0001445305-12-003598:notes:65]
The accounting guidance for awards with market conditions differs from that for awards with service conditions only or service and performance conditions. Because the grant date fair value of an award containing market conditions is calculated as the expected value, averaging over all possible outcomes, the measured expense is amortized over the service period, regardless of whether the market condition is ever actually met. PSU expense of $0.2 million and $0.1 million was recognized for the three months ended September 30, 2012 and 2011, respectively. PSU expense of $0.8 million and $0.4 million was recognized for the nine months ended September 30, 2012 and 2011, respectively.

[0001445305-12-003598:notes:66]
The fair value of a PSU award is the average of trial-specific values of the award over each of one million Monte Carlo trials. Each trial-specific value is the market value of the award at the end of the one-year performance period discounted back to the grant date. The market value of the award for each trial at the end of the performance period is the product of (a) the per share value of Omnicell stock at the end of the performance period and (b) the number of shares that vest. The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of each of the other companies in the NASDAQ Healthcare Index (the “Index”) as shown in the tables below.

[0001445305-12-003598:notes:67]
Vesting for the PSU awards is based on the percentile placement of our total shareholder return among the companies listed in the Index and time-based vesting. We calculate total stockholder return based on the one year annualized rates of return reflecting price appreciation plus reinvestment of dividends. Stock price appreciation is calculated based on the average closing prices of the applicable company’s common stock for the 20 trading days ending on the last trading day of the year prior to the date of grant as compared to the average closing prices for the 20 trading days ended on the last trading day of the year of grant.

[0001445305-12-003598:notes:68]
[same as prior period, unchanged from 0001445305-12-002594:notes:68]

[0001445305-12-003598:notes:69]
[same as prior period, unchanged from 0001445305-12-002594:notes:69]

[0001445305-12-003598:notes:70]
(1)               The actual percentage of PSUs eligible for further time-based vesting is based on straight-line interpolation, where, for example, if the ranking is the 70th percentile, then the vesting percentage is 115%.

[0001445305-12-003598:notes:71]
[same as prior period, unchanged from 0001445305-12-002594:notes:71]

[0001445305-12-003598:notes:72]
[same as prior period, unchanged from 0001445305-12-002594:notes:72]

[0001445305-12-003598:notes:73]
[same as prior period, unchanged from 0001445305-12-002594:notes:73]

[0001445305-12-003598:notes:74]
[same as prior period, unchanged from 0001445305-12-002594:notes:74]

[0001445305-12-003598:notes:75]
During the nine months ended September 30, 2012, in addition to the 125,000 PSUs granted in 2012, an additional 7,500 PSUs vested as a result of Omnicell’s 2011 total stockholder return which caused 120% of the 2011 PSUs to become eligible for further time-based vesting.

[0001445305-12-003598:notes:76]
A summary of activity of the PSUs for the nine months ended September 30, 2012 is presented below:

[0001445305-12-003598:notes:77]
|  |  |  | Weighted -AverageGrant DateFair Value Per |
| Performance-based Stock Units | Number of Shares |  | Share |
|  | (in thousands) |  |  |  |
| Non-vested, December 31, 2011 | 100 |  |  | $ | 11.15 |  |
| Granted | 133 |  |  | $ | 10.94 |  |
| Vested | (45 | ) |  | $ | 11.15 |  |
| Forfeited | — |  |  | — |  |
| Non-vested, September 30, 2012 | 188 |  |  | $ | 11.00 |  |

[0001445305-12-003598:notes:78]
[same as prior period, unchanged from 0001445305-12-002594:notes:78]

[0001445305-12-003598:notes:79]
We have an Employee Stock Purchase Plan (“ESPP”), under which employees can purchase shares of our common stock based on a percentage of their compensation, but not greater than 15% of their earnings, up to a maximum of $25,000 of fair value per year. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period. As of September 30, 2012, 3,782,844 shares had been issued under the ESPP. As of September 30, 2012 there were a total of 1,548,711 shares reserved for future issuance under the ESPP. For the three months and nine months ended September 30, 2012, 180,018 shares and 377,849 shares, respectively, of common stock were purchased under the ESPP.

[0001445305-12-003598:notes:80]
[same as prior period, unchanged from 0001445305-12-002594:notes:80]

[0001445305-12-003598:notes:81]
[same as prior period, unchanged from 0001445305-12-002594:notes:81]

[0001445305-12-003598:notes:82]
The impact on our results for share-based compensation for the three months and nine months ended September 30, 2012 and 2011 was as follows (in thousands):

[0001445305-12-003598:notes:83]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Cost of product and service revenues | $ | 275 |  |  | $ | 358 |  |  | $ | 776 |  |  | $ | 1,108 |  |
| Research and development expenses | 232 |  |  | 333 |  |  | 686 |  |  | 1,005 |  |
| Selling, general and administrative expenses | 1,854 |  |  | 1,720 |  |  | 5,319 |  |  | 5,141 |  |
| Total share-based compensation expenses | $ | 2,361 |  |  | $ | 2,411 |  |  | $ | 6,781 |  |  | $ | 7,254 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001445305-12-003598:notes:84]
Basic net income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method.


## us-gaap:EarningsPerShareTextBlock

[0001445305-12-003598:notes:85]
[same as prior period, unchanged from 0001445305-12-002594:notes:85]

[0001445305-12-003598:notes:86]
Basic net income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Since their impact is anti-dilutive, the total number of shares excluded from the calculations of diluted net income per share for the nine months ended September 30, 2012 and 2011 were 2,067,273 and 2,089,739, respectively.

[0001445305-12-003598:notes:87]
[same as prior period, unchanged from 0001445305-12-002594:notes:87]

[0001445305-12-003598:notes:88]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |  |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Basic: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 6,920 |  |  | $ | 2,994 |  |  | $ | 10,646 |  |  | $ | 6,251 |  |
| Weighted average shares outstanding — basic | 33,193 |  |  | 33,209 |  |  | 33,316 |  |  | 33,132 |  |
| Net income per share — basic | $ | 0.21 |  |  | $ | 0.09 |  |  | $ | 0.32 |  |  | $ | 0.19 |  |
| Diluted: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 6,920 |  |  | $ | 2,994 |  |  | $ | 10,646 |  |  | $ | 6,251 |  |
| Weighted average shares outstanding — basic | 33,193 |  |  | 33,209 |  |  | 33,316 |  |  | 33,132 |  |
| Add: Dilutive effect of employee stock plans | 875 |  |  | 1,010 |  |  | 925 |  |  | 968 |  |
| Weighted average shares outstanding — diluted | 34,068 |  |  | 34,219 |  |  | 34,241 |  |  | 34,100 |  |
| Net income per share — diluted | $ | 0.20 |  |  | $ | 0.09 |  |  | $ | 0.31 |  |  | $ | 0.18 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001445305-12-003598:notes:89]
[same as prior period, unchanged from 0001445305-12-002594:notes:89]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001445305-12-003598:notes:90]
[same as prior period, unchanged from 0001445305-12-002594:notes:91]

[0001445305-12-003598:notes:91]
[same as prior period, unchanged from 0001445305-12-002594:notes:92]

[0001445305-12-003598:notes:92]
Activity in Goodwill by reporting units, which are the same as our operating segments, for the nine months ended September 30, 2012 consists of the following (in thousands):

[0001445305-12-003598:notes:93]
|  | Goodwill at December 31, 2011 |  | Goodwill acquired |  | Goodwill at September 30, 2012 |
| Reporting units: |  |  |  |  |  |
| Acute Care | $ | 28,543 |  |  | $ | — |  |  | $ | 28,543 |  |
| Non-Acute Care | — |  |  | 84,140 |  |  | 84,140 |  |
| Total | $ | 28,543 |  |  | $ | 84,140 |  |  | $ | 112,683 |  |

[0001445305-12-003598:notes:94]
[same as prior period, unchanged from 0001445305-12-002594:notes:95]

[0001445305-12-003598:notes:95]
There were no indefinite-life intangibles at either September 30, 2012 or December 31, 2011. Finite-life intangible assets at these dates consist of the following (in thousands):

[0001445305-12-003598:notes:96]
|  | September 30, 2012 |  | December 31, 2011 |  |  |
|  | Gross |  |  |  | Net |  | Gross |  |  |  | Net |  |  |
|  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | AmortizationLife |
| Finite-lived intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 54,330 |  |  | $ | 2,539 |  |  | $ | 51,791 |  |  | $ | 4,230 |  |  | $ | 1,591 |  |  | $ | 2,639 |  |  | 5-30 years |
| Acquired technology | 27,580 |  |  | 760 |  |  | 26,820 |  |  | 980 |  |  | 175 |  |  | 805 |  |  | 3-20 years |
| Patents | 1,192 |  |  | 214 |  |  | 978 |  |  | 889 |  |  | 190 |  |  | 699 |  |  | 20 years |
| Trade name | 6,890 |  |  | 265 |  |  | 6,625 |  |  | 90 |  |  | 37 |  |  | 53 |  |  | 3-12 years |
| Non-compete agreements | 60 |  |  | 40 |  |  | 20 |  |  | 60 |  |  | 25 |  |  | 35 |  |  | 3 years |
| Total finite-lived intangibles | $ | 90,052 |  |  | $ | 3,818 |  |  | $ | 86,234 |  |  | $ | 6,249 |  |  | $ | 2,018 |  |  | $ | 4,231 |  |  |  |

[0001445305-12-003598:notes:97]
Amortization expense totaled $1.1 million and $0.2 million for the three months ended September 30, 2012 and 2011, respectively. Amortization expense totaled $1.8 million and $0.5 million for the nine months ended September 30, 2012 and 2011, respectively. The amortization of acquired technology is included within product cost of sales; other acquired intangibles are usually amortized within selling, general and administrative expenses.

[0001445305-12-003598:notes:98]
Estimated annual expected amortization expense of the finite-lived intangible assets at September 30, 2012 was as follows (in thousands):

[0001445305-12-003598:notes:99]
| 2012 (remaining three months) | $ | 1,062 |  |
| 2013 | 4,235 |  |
| 2014 | 4,195 |  |
| 2015 | 4,172 |  |
| 2016 | 3,821 |  |
| 2017 | 3,786 |  |
| Thereafter | 64,963 |  |
| Total | $ | 86,234 |  |


## us-gaap:IncomeTaxPolicyTextBlock

[0001445305-12-003598:notes:100]
[same as prior period, unchanged from 0001445305-12-002594:notes:101]

[0001445305-12-003598:notes:101]
[same as prior period, unchanged from 0001445305-12-002594:notes:102]

[0001445305-12-003598:notes:102]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 41.5% and 40.3% for the nine months ended September 30, 2012 and 2011, respectively. The 2012 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, including non-deductible acquisition costs, all of which were partially offset by the domestic production activities deduction.

[0001445305-12-003598:notes:103]
The 2011 annual effective tax rate differed from the statutory rate of 35%, primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the federal research and development credit claimed and the domestic production activities deduction. Our projected effective tax rate for 2012, after discrete items recorded through September 30, 2012 and 2011, were approximately 39.6% and 38.4%, respectively.

[0001445305-12-003598:notes:104]
As of September 30, 2012, we had total gross unrecognized tax benefits of approximately $8.4 million, compared with approximately $5.8 million on December 31, 2011, representing an increase of approximately $2.6 million during the nine months ended September 30, 2012. Approximately $1.0 million of the increase was attributable to unrecognized tax benefits recorded as part of the MTS acquisition. Of the total unrecognized tax benefits, $7.1 million and $4.6 million as of September 30, 2012 and December 31, 2011, respectively, if recognized would reduce our effective tax rate in the period of recognition. Gross interest and penalties related to unrecognized tax benefit accrued were immaterial as of September 30, 2012 and December 31, 2011.

[0001445305-12-003598:notes:105]
Recently adopted accounting pronouncements. In May 2011, the Financial Accounting Standards Board (“FASB”) issued ASU 2011-04, Fair Value Measurement, amending the fair value guidance in ASC 820, and thereby achieving substantially converged fair value measurement and disclosure requirements for GAAP and International Financial Reporting Standards (“IFRS”). The new guidance clarified some fair value measurement principles and expanded certain disclosure requirements. We adopted this guidance in the first quarter of 2012 without any impact to our financial position, operating results or cash flows.

[0001445305-12-003598:notes:106]
Recently issued accounting pronouncement. In July 2012, FASB issued ASU 2012


## us-gaap:InventoryDisclosureTextBlock

[0001445305-12-003598:notes:107]
[same as prior period, unchanged from 0001445305-12-002594:notes:107]

[0001445305-12-003598:notes:108]
[same as prior period, unchanged from 0001445305-12-002594:notes:108]

[0001445305-12-003598:notes:109]
|  | September 30, 2012 |  | December 31, 2011 |
| Raw materials | $ | 9,290 |  |  | $ | 7,666 |  |
| Work in process | 526 |  |  | 14 |  |
| Finished goods | 16,584 |  |  | 10,427 |  |
| Total | $ | 26,400 |  |  | $ | 18,107 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001445305-12-003598:notes:110]
Contingencies

[0001445305-12-003598:notes:111]
Legal Proceedings

[0001445305-12-003598:notes:112]
We may from time to time become involved in certain legal proceedings in the ordinary course of business. We are not a party to any legal proceedings that management believes may have a material impact on Omnicell’s financial position or results of operations.

[0001445305-12-003598:notes:113]
Guarantees

[0001445305-12-003598:notes:114]
As permitted under Delaware law and our certificate of incorporation and bylaws, we have agreed to indemnify our directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become our directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that we could be required to make under these indemnification agreements. We have purchased a directors’ and officers’ liability insurance policy that may enable us to recover a portion of any future payments that we may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0001445305-12-003598:notes:115]
Additionally, we undertake indemnification obligations in our ordinary course of business in connection with, among other things, the licensing of our products and the provision of our support services. In the ordinary course of our business, we have in the past and may in the future agree to indemnify another party, generally our business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, our gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, we attempt to limit the maximum potential amount of future payments that we may be required to make under these indemnification obligations to the amounts paid to us by a customer, but in some cases the obligation may not be so limited. In addition, we have in the past and may in the future warrant to our customers that our products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that our software media is free from material defects. Sales contracts for certain of our medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances we record have historically been immaterial.

[0001445305-12-003598:notes:116]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of September 30, 2012 or December 31, 2011.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001445305-12-003598:notes:117]
Recently issued accounting pronouncement. In July 2012, FASB issued ASU 2012-02, Intangibles - Goodwill and Other (Topic 350): Testing Indefinite-lived Intangible Assets for Impairment, which amends the guidance in ASC 350-30 on impairment testing of intangible assets with indefinite lives other than goodwill. This guidance gives an entity the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not that an indefinite-lived asset is impaired. An entity has the option to bypass the qualitative assessment and proceed directly to calculating the fair value of an intangible asset with an indefinite life. This update will be effective for us for interim and annual impairment tests performed beginning in the first quarter of fiscal 2013. We do not anticipate this update will have any significant impact on our financial position, operating results or cash flows, as this update does not change how we calculate impairment loss.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001445305-12-003598:notes:118]
[same as prior period, unchanged from 0001445305-12-002594:notes:118]

[0001445305-12-003598:notes:119]
[same as prior period, unchanged from 0001445305-12-002594:notes:119]

[0001445305-12-003598:notes:120]
On May 21, 2012, we completed our acquisition of MedPak Holdings, Inc. (“MedPak”). MedPak is the parent company of MTS Medication Technologies, Inc. (“MTS”), a worldwide provider of medication adherence packaging systems. This acquisition aligns us with the long-term trends of the healthcare market to manage the health of patients across the continuum of care.  We can now serve both the acute care and non-acute markets. Omnicell and MTS bring capabilities to each other that strengthen the product lines and expand the medication management coverage of both companies. Please refer to Note 14, “Business Acquisition” for more information regarding the transaction.

[0001445305-12-003598:notes:121]
[same as prior period, unchanged from 0001445305-12-002594:notes:121]

[0001445305-12-003598:notes:122]
[same as prior period, unchanged from 0001445305-12-002594:notes:122]

[0001445305-12-003598:notes:123]
[same as prior period, unchanged from 0001445305-12-002594:notes:123]

[0001445305-12-003598:notes:124]
[same as prior period, unchanged from 0001445305-12-002594:notes:124]

[0001445305-12-003598:notes:125]
[same as prior period, unchanged from 0001445305-12-002594:notes:125]

[0001445305-12-003598:notes:126]
[same as prior period, unchanged from 0001445305-12-002594:notes:126]

[0001445305-12-003598:notes:127]
[same as prior period, unchanged from 0001445305-12-002594:notes:127]

[0001445305-12-003598:notes:128]
[same as prior period, unchanged from 0001445305-12-002594:notes:128]

[0001445305-12-003598:notes:129]
At September 30, 2012 and December 31, 2011, our financial assets, measured at fair value on a recurring basis, utilizing Level 1 inputs included cash equivalents. For these items, quoted market prices are readily available and fair value approximates carrying value. At December 31, 2011, we had a short-term investment in California revenue anticipation notes, measured at fair value on a recurring basis, the valuation inputs of which were classified as Level 2. We do not currently have any material financial instruments, measured at fair value on a recurring basis, utilizing Level 3 inputs.

[0001445305-12-003598:notes:130]
Classification of marketable securities. Securities held as investments for the indefinite future pending future spending requirements are classified as “Available-for-sale” and are carried at their fair value, with any unrealized gain or loss recorded to other comprehensive income until realized. At September 30, 2012 and December 31, 2011, we held $31.9 million and $177.3 million, respectively, of money market mutual funds classified as Available-for-sale cash equivalents. At December 31, 2011, we held $8.1 million of non-U.S. Government securities classified as Available-for-sale short-term investments. We do not hold securities for purposes of trading. Marketable securities for which we have the intent and ability to hold to maturity are classified as “Held-to-maturity” and are carried at their amortized cost, including accrued interest. We had no Held-to-maturity securities at September 30, 2012 and December 31, 2011.

[0001445305-12-003598:notes:131]
Segment information. Beginning with the May 21, 2012 acquisition of MTS, we manage our business on the basis of two operating segments: Acute Care, which primarily includes products and services sold to hospital customers, and Non-Acute Care, which primarily includes products and services sold to customers outside of hospital settings. The historical Omnicell results were reported as a single segment and reporting unit, primarily comprising the Acute Care segment. MTS primarily comprises the Non-Acute Care segment and reporting unit.

[0001445305-12-003598:notes:132]
Revenue recognition. We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems with related services, which are sold in our principal market, which is the healthcare industry. Our customer arrangements typically include one or more of the following deliverables:

[0001445305-12-003598:notes:133]
[same as prior period, unchanged from 0001445305-12-002594:notes:133]

[0001445305-12-003598:notes:134]
[same as prior period, unchanged from 0001445305-12-002594:notes:134]

[0001445305-12-003598:notes:135]
[same as prior period, unchanged from 0001445305-12-002594:notes:135]

[0001445305-12-003598:notes:136]
[same as prior period, unchanged from 0001445305-12-002594:notes:136]

[0001445305-12-003598:notes:137]
[same as prior period, unchanged from 0001445305-12-002594:notes:137]

[0001445305-12-003598:notes:138]
[same as prior period, unchanged from 0001445305-12-002594:notes:138]

[0001445305-12-003598:notes:139]
[same as prior period, unchanged from 0001445305-12-002594:notes:139]

[0001445305-12-003598:notes:140]
[same as prior period, unchanged from 0001445305-12-002594:notes:140]

[0001445305-12-003598:notes:141]
[same as prior period, unchanged from 0001445305-12-002594:notes:141]

[0001445305-12-003598:notes:142]
[same as prior period, unchanged from 0001445305-12-002594:notes:142]

[0001445305-12-003598:notes:143]
[same as prior period, unchanged from 0001445305-12-002594:notes:143]

[0001445305-12-003598:notes:144]
[same as prior period, unchanged from 0001445305-12-002594:notes:144]

[0001445305-12-003598:notes:145]
[same as prior period, unchanged from 0001445305-12-002594:notes:145]

[0001445305-12-003598:notes:146]
[same as prior period, unchanged from 0001445305-12-002594:notes:146]

[0001445305-12-003598:notes:147]
[same as prior period, unchanged from 0001445305-12-002594:notes:147]

[0001445305-12-003598:notes:148]
[same as prior period, unchanged from 0001445305-12-002594:notes:148]

[0001445305-12-003598:notes:149]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

[0001445305-12-003598:notes:150]
[same as prior period, unchanged from 0001445305-12-002594:notes:150]

[0001445305-12-003598:notes:151]
Sales of accounts receivable. We record the sale of our accounts receivables as “true sales” in accordance with accounting guidance for transfers and servicing of financial assets. During the three months ended September 30, 2012 and 2011, we transferred non-recourse accounts receivable totaling $14.6 million and $9.0 million, respectively, which approximated fair value, to third-party leasing companies. During the nine months ended September 30, 2012 and 2011, we transferred non-recourse accounts receivable totaling $42.5 million and $32.2 million, respectively, which approximated fair value, to third-party leasing companies. At September 30, 2012 and December 31, 2011, accounts receivable included $0.8 million and $0.2 million, respectively, due from third-party leasing companies for transferred non-recourse accounts receivable.

[0001445305-12-003598:notes:152]
Concentration in revenues and in accounts receivable. There were no customers accounting for 10% or more of revenues in the three months ended September 30, 2012 or 2011. Additionally, there were no customers accounting for 10% or more of revenues in the nine months ended September 30, 2012 or 2011. There were no customers accounting for 10% or more of accounts receivable at September 30, 2012 or at December 31, 2011.

[0001445305-12-003598:notes:153]
Accounting policy for shipping costs. Outbound freight billed to customers is recorded as product revenue. The related shipping and handling cost is expensed as part of selling, general and administrative expense. Such shipping and handling expenses totaled $1.2 million and $0.7 million for the three months ended September 30, 2012 and 2011, respectively. Shipping and handling expenses totaled $2.7 million and $2.1 million for the nine months ended September 30, 2012 and 2011, respectively.

[0001445305-12-003598:notes:154]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended September 30, 2012 and 2011 were approximately $6.3 million and $4.9 million, respectively. Purchases from this supplier for the nine months ended September 30, 2012 and 2011 were approximately $17.8 million and $16.1 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001445305-12-003598:notes:155]
[same as prior period, unchanged from 0001445305-12-002594:notes:155]

[0001445305-12-003598:notes:156]
[same as prior period, unchanged from 0001445305-12-002594:notes:156]

[0001445305-12-003598:notes:157]
|  | September 30, 2012 |  | December 31, 2011 |
| Equipment | $ | 32,373 |  |  | $ | 25,101 |  |
| Furniture and fixtures | 2,262 |  |  | 1,811 |  |
| Leasehold improvements | 4,234 |  |  | 3,692 |  |
| Purchased software | 21,500 |  |  | 20,641 |  |
| Capital in process | 6,608 |  |  | 2,283 |  |
|  | 66,977 |  |  | 53,528 |  |
| Accumulated depreciation and amortization | (34,792 | ) |  | (36,222 | ) |
| Property and equipment, net | $ | 32,185 |  |  | $ | 17,306 |  |

[0001445305-12-003598:notes:158]
Depreciation and amortization of property and equipment totaled approximately $2.2 million and $1.5 million for the three months ended September 30, 2012 and 2011, respectively. Depreciation and amortization of property and equipment totaled approximately $5.7 million and $4.3 million for the nine months ended September 30, 2012 and 2011, respectively.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001445305-12-003598:notes:159]
[same as prior period, unchanged from 0001445305-12-002594:notes:159]

[0001445305-12-003598:notes:160]
|  | September 30, 2012 |  | December 31, 2011 |
| Advance payments from customers | $ | 3,001 |  |  | $ | 3,390 |  |
| Accrued Group Purchasing Organization (GPO) fees | 2,271 |  |  | 2,437 |  |
| Acquisition consideration payable | 1,482 |  |  | — |  |
| Rebates and lease buyouts | 2,175 |  |  | 1,748 |  |
| Taxes payable | 855 |  |  | 925 |  |
| Other | 2,422 |  |  | 401 |  |
| Total | $ | 12,206 |  |  | $ | 8,901 |  |


## us-gaap:ScheduleOfCreditLossesRelatedToFinancingReceivablesNoncurrentTableTextBlock

[0001445305-12-003598:notes:161]
The following table summarizes the activity for the allowance for credit losses for the investment in sales-type leases for the three months and nine months ended September 30, 2012 and 2011 (in thousands):

[0001445305-12-003598:notes:162]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Allowance for credit losses, beginning of period | $ | 659 |  |  | $ | 353 |  |  | $ | 284 |  |  | $ | 411 |  |
| Current period provision (reversal) | 4 |  |  | (7 | ) |  | 426 |  |  | (16 | ) |
| Direct write-downs charged against the allowance | — |  |  | — |  |  | — |  |  | — |  |
| Recoveries of amounts previously charged off | (26 | ) |  | (24 | ) |  | (73 | ) |  | (73 | ) |
| Allowance for credit losses, end of period | $ | 637 |  |  | $ | 322 |  |  | $ | 637 |  |  | $ | 322 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0001445305-12-003598:notes:163]
The minimum lease payments under sales-type leases as of September 30, 2012 were as follows (in thousands):

[0001445305-12-003598:notes:164]
| 2012 (remaining three months) | $ | 1,087 |  |  |
| 2013 | 5,152 |  |  |
| 2014 | 4,028 |  |  |
| 2015 | 2,973 |  |  |
| 2016 | 1,927 |  |  |
| 2017 | 1,055 |  |  |
| Thereafter | 173 |  |  |
| Total | $ | 16,395 |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001445305-12-003598:notes:165]
For the three months and nine months ended September 30, 2012 and 2011, the contributions of our segments to net revenues and income from operations, and the reconciliation to total net income, were as follows (amounts in thousands):

[0001445305-12-003598:notes:166]
|  | Three Months Ended September 30, |  | Three Months Ended September 30, |
|  | 2012 |  | 2011 |
|  | Acute Care |  | Non-Acute Care (1) |  | Total |  | Acute Care |  | Total |
| Net revenues from external customers | $ | 64,394 |  |  | $ | 19,937 |  |  | $ | 84,331 |  |  | $ | 64,439 |  |  | $ | 64,439 |  |
| Cost of revenues | 26,920 |  |  | 11,324 |  |  | 38,244 |  |  | 29,991 |  |  | 29,991 |  |
| Gross profit | $ | 37,474 |  |  | $ | 8,613 |  |  | $ | 46,087 |  |  | $ | 34,448 |  |  | $ | 34,448 |  |
| Gross margin % | 58.2 | % |  | 43.2 | % |  | 54.7 | % |  | 53.5 | % |  | 53.5 | % |
| Operating expenses | 29,070 |  |  | 5,791 |  |  | 34,861 |  |  | 29,654 |  |  | 29,654 |  |
| Income from operations | $ | 8,404 |  |  | $ | 2,822 |  |  | $ | 11,226 |  |  | $ | 4,794 |  |  | $ | 4,794 |  |
| Operating margin % | 13.1 | % |  | 14.2 | % |  | 13.3 | % |  | 7.4 | % |  | 7.4 | % |
| Interest and other income (expense), net |  |  |  |  | 34 |  |  |  |  | (191 | ) |
| Income before provision for income taxes |  |  |  |  | 11,260 |  |  |  |  | 4,603 |  |
| Provision for income taxes |  |  |  |  | 4,340 |  |  |  |  | 1,609 |  |
| Net income |  |  |  |  | $ | 6,920 |  |  |  |  | $ | 2,994 |  |

[0001445305-12-003598:notes:167]
|  | Nine Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2012 |  | 2011 |
|  | Acute Care |  | Non-Acute Care (1) |  | Total |  | Acute Care |  | Total |
| Net revenues from external customers | $ | 191,294 |  |  | $ | 32,564 |  |  | $ | 223,858 |  |  | $ | 182,604 |  |  | $ | 182,604 |  |
| Cost of revenues | 82,858 |  |  | 19,788 |  |  | 102,646 |  |  | 82,699 |  |  | 82,699 |  |
| Gross profit | $ | 108,436 |  |  | $ | 12,776 |  |  | $ | 121,212 |  |  | $ | 99,905 |  |  | $ | 99,905 |  |
| Gross margin % | 56.7 | % |  | 39.2 | % |  | 54.1 | % |  | 54.7 | % |  | 54.7 | % |
| Operating expenses | 94,167 |  |  | 9,753 |  |  | 103,920 |  |  | 89,852 |  |  | 89,852 |  |
| Income from operations | $ | 14,269 |  |  | $ | 3,023 |  |  | $ | 17,292 |  |  | $ | 10,053 |  |  | $ | 10,053 |  |
| Operating margin % | 7.5 | % |  | 9.3 | % |  | 7.7 | % |  | 5.5 | % |  | 5.5 | % |
| Interest and other income (expense), net |  |  |  |  | 57 |  |  |  |  | (66 | ) |
| Income before provision for income taxes |  |  |  |  | 17,349 |  |  |  |  | 9,987 |  |
| Provision for income taxes |  |  |  |  | 6,703 |  |  |  |  | 3,736 |  |
| Net income |  |  |  |  | $ | 10,646 |  |  |  |  | $ | 6,251 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the date of acquisition. |  |  |  |  |  |  |  |  |  |

[0001445305-12-003598:notes:168]
For the nine months ended September 30, 2012, the Non-Acute Care cost of revenues included $1.7 million of acquisition-related charges primarily associated with the step-up to the estimated fair value of inventory acquired from MTS and consumed in the normal manufacturing cycle of our business. The Non-Acute Care operating expenses included $0.9 million of acquisition-related charges primarily associated with severance expenses. For the nine months ended September 30, 2012, the Acute Care operating expenses included $2.3 million of acquisition-related charges for transaction costs, required to be expensed under ASC 805 Business Combinations. As of September 30, 2012, we have not assigned assets to our operating segments.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001445305-12-003598:notes:169]
[same as prior period, unchanged from 0001445305-12-002594:notes:170]

[0001445305-12-003598:notes:170]
Beginning with the acquisition of MTS, we have organized our business into two operating business segments: Acute Care, which primarily includes products and services sold to hospital customers and Non-Acute Care, which primarily includes products and services sold to customers outside of hospital settings.

[0001445305-12-003598:notes:171]
The Acute Care segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems. The Non-Acute Care segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services, but also includes medication dispensing systems sold to non-acute care pharmacies and facilities. We report segment information based on the management approach. The management approach designates the internal reporting used by the Chief Operating Decision Maker (“CODM”), for making decisions and assessing performance as the source of our operating segments. The CODM is our Chief Executive Officer. The CODM allocates resources to and assesses the performance of each operating segment, using information about its revenues, gross profit and income (loss) from operations.

[0001445305-12-003598:notes:172]
[same as prior period, unchanged from 0001445305-12-002594:notes:173]

[0001445305-12-003598:notes:173]
[same as prior period, unchanged from 0001445305-12-002594:notes:174]

[0001445305-12-003598:notes:174]
During the three months ended September 30, 2012, we realigned our management reporting structure to report sales of Omnicell's dispensing systems and other related business transactions into long-term care pharmacies and facilities. Accordingly, the operations of this portion of our activities is now being reflected as a part of the Non-Acute Care segment for the three months and nine months ended September 30, 2012. The impact of this reporting structure change on the three months and nine months ended September 30, 2011 was immaterial to our overall reported results.

[0001445305-12-003598:notes:175]
[same as prior period, unchanged from 0001445305-12-002594:notes:175]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001445305-12-003598:notes:176]
[same as prior period, unchanged from 0001445305-12-002594:notes:176]

[0001445305-12-003598:notes:177]
[same as prior period, unchanged from 0001445305-12-002594:notes:177]

[0001445305-12-003598:notes:178]
In February 2008, our Board of Directors authorized a stock repurchase program, the “2008 Repurchase Program”, for the repurchase of up to $90.0 million of our common stock. All repurchased shares were recorded as treasury stock and were accounted for under the cost method. None of the repurchased shares have been retired. The timing, price and volume of the repurchases have been based on market conditions, relevant securities laws and other factors. The stock repurchase program does not obligate us to repurchase any specific number of shares, and we may terminate or suspend the repurchase program at any time.

[0001445305-12-003598:notes:179]
On August 1, 2012, our Board of Directors established a new stock repurchase program, the “2012 Repurchase Program”, authorizing share repurchases of up to $50.0 million of our common stock, with no termination date. The timing, price and volume of repurchases will be based on market conditions, relevant securities laws and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions or pursuant to a Rule 10b-18 plan. The stock repurchase program does not obligate Omnicell to repurchase any specific number of shares, and Omnicell may terminate or suspend the repurchase program at any time.

[0001445305-12-003598:notes:180]
During the three months ended September 30, 2012, we repurchased 393,031 shares through the 2008 Repurchase Program at an average cost of $13.49 per share, including commissions, compared to 505,137 shares repurchased in the three months ended June 30, 2012 at an average cost of $13.98 per share, including commissions. For the nine months ended September 30, 2012, we repurchased 898,168 shares at an average cost of $13.76 per share, including commissions. In the three months ended September 30, 2011, we repurchased 182,784 shares through the 2008  Repurchase Program at an average cost of $14.01 per share, including commissions, For the nine months ended September 30, 2011, we repurchased 741,959 shares at an average cost of $14.23, including commissions.

[0001445305-12-003598:notes:181]
From the inception of the 2008 Repurchase Program in February 2008 through September 30, 2012, we have repurchased a total of 5,853,975 shares at an average cost of $15.37 per share through open market purchases. As of September 30, 2012, we have completed the 2008 Repurchase Program having repurchased $90.0 million of our common stock.

[0001445305-12-003598:notes:182]
Through September 30, 2012, we have not repurchased any shares through the 2012 Repurchase Program and therefore had $50.0 million of authorized funds to repurchase shares under the 2012 Repurchase Program.


## us-gaap:SubsequentEventsTextBlock

[0001445305-12-003598:notes:183]
Subsequent Events

[0001445305-12-003598:notes:184]
Investment in United Kingdom Distributor

[0001445305-12-003598:notes:185]
On September 28, 2012, we entered into an agreement with our distributor in the United Kingdom to purchase 15% of the outstanding equity in the company for approximately $0.9 million in cash. In connection with the investment, Omnicell has the right, under certain circumstances, to appoint a member to our United Kingdom distributor's board of directors as well as certain other voting rights. As a result of these and other factors, we anticipate that we will be accounting for this investment using the equity method.


## omcl:AccruedLiabilitiesTextBlock

[0001445305-12-003598:notes:186]
[same as prior period, unchanged from 0001445305-12-002594:notes:185]


## omcl:DeferredGrossProfitTableTextBlock

[0001445305-12-003598:notes:187]
[same as prior period, unchanged from 0001445305-12-002594:notes:186]

[0001445305-12-003598:notes:188]
|  | September 30, 2012 |  | December 31, 2011 |
| Sales of medication and supply dispensing systems and packaging equipment, which have been delivered and invoiced but not yet installed | $ | 28,984 |  |  | $ | 24,181 |  |
| Cost of revenues, excluding installation costs | (9,397 | ) |  | (9,971 | ) |
| Deferred gross profit | $ | 19,587 |  |  | $ | 14,210 |  |


## omcl:DeferredGrossProfitTextBlock

[0001445305-12-003598:notes:189]
[same as prior period, unchanged from 0001445305-12-002594:notes:188]


## omcl:NetInvestmentsInSalesTypeLeasesTextBlock

[0001445305-12-003598:notes:190]
[same as prior period, unchanged from 0001445305-12-002594:notes:189]

[0001445305-12-003598:notes:191]
[same as prior period, unchanged from 0001445305-12-002594:notes:190]

[0001445305-12-003598:notes:192]
|  | September 30, 2012 |  | December 31, 2011 |
| Net minimum lease payments to be received | $ | 16,395 |  |  | $ | 15,063 |  |
| Less unearned interest income portion | 1,378 |  |  | 1,229 |  |
| Net investment in sales-type leases | 15,017 |  |  | 13,834 |  |
| Less current portion(1) | 4,389 |  |  | 5,049 |  |
| Non-current net investment in sales-type leases(2) | $ | 10,628 |  |  | $ | 8,785 |  |

[0001445305-12-003598:notes:193]
(1)     A component of other current assets. This amount is net of allowance for doubtful accounts of $0.5 million as of September 30, 2012 and $0.1 million as of December 31, 2011.

[0001445305-12-003598:notes:194]
(2)     Net of allowance for doubtful accounts of $0.1 million as of September 30, 2012 and $0.1 million as of December 31, 2011.
