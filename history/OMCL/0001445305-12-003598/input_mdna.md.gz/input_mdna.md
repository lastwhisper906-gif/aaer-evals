# OMCL MD&A — 0001445305-12-003598


## mdna

[0001445305-12-003598:mdna:1]
[same as prior period, unchanged from 0001445305-12-002594:mdna:1]

[0001445305-12-003598:mdna:2]
[same as prior period, unchanged from 0001445305-12-002594:mdna:2]

[0001445305-12-003598:mdna:3]
[same as prior period, unchanged from 0001445305-12-002594:mdna:3]

[0001445305-12-003598:mdna:4]
[same as prior period, unchanged from 0001445305-12-002594:mdna:4]

[0001445305-12-003598:mdna:5]
| • | our ability to conduct acquisitions for strategic value and successfully integrate each one into our operations, including our acquisition of MTS; |

[0001445305-12-003598:mdna:6]
[same as prior period, unchanged from 0001445305-12-002594:mdna:6]

[0001445305-12-003598:mdna:7]
[same as prior period, unchanged from 0001445305-12-002594:mdna:7]

[0001445305-12-003598:mdna:8]
[same as prior period, unchanged from 0001445305-12-002594:mdna:8]

[0001445305-12-003598:mdna:9]
[same as prior period, unchanged from 0001445305-12-002594:mdna:9]

[0001445305-12-003598:mdna:10]
[same as prior period, unchanged from 0001445305-12-002594:mdna:10]

[0001445305-12-003598:mdna:11]
[same as prior period, unchanged from 0001445305-12-002594:mdna:11]

[0001445305-12-003598:mdna:12]
[same as prior period, unchanged from 0001445305-12-002594:mdna:12]

[0001445305-12-003598:mdna:13]
In some cases, you can identify forward-looking statements by terms such as “anticipates,” “believes,” “could,” “estimates,” “expects,” “intends,” “may,” “plans,” “potential,” “predicts,” “will,” “would” and similar expressions intended to identify forward-looking statements. Forward-looking statements reflect our current views with respect to future events, are based on assumptions, and are subject to risks and uncertainties. We discuss many of these risks in this Quarterly Report on Form 10-Q in greater detail in Part II — Section 1A. “Risk Factors” below. Given these uncertainties, you should not place undue reliance on these forward-looking statements. Also, forward-looking statements represent our estimates and assumptions only as of the date of this Quarterly Report on Form 10-Q. You should also read our Annual Report on Form 10-K and the documents that we reference in the Annual Report on Form 10-K and have filed as exhibits, completely and with the understanding that our actual future results may be materially different from what we expect.  All references in this report to “Omnicell, Inc.,” “Omnicell,” “our,” “us,” “we” or the “Company” collectively refer to Omnicell, Inc., a Delaware corporation, and its subsidiaries.

[0001445305-12-003598:mdna:14]
[same as prior period, unchanged from 0001445305-12-002594:mdna:14]

[0001445305-12-003598:mdna:15]
We were incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. We are a leading provider of automated solutions for medication and supply management in healthcare. Our automation and analytics solutions are designed to enable healthcare facilities to acquire, manage, dispense and administer medications and medical-surgical supplies and are intended to enhance patient safety, reduce medication errors, reduce operating costs, improve workflow and increase operational efficiency. Approximately 2,700 hospitals utilize one or more of our products, of which more than 1,700 hospitals in the United States have installed our automated hardware/software solutions for controlling, dispensing, acquiring, verifying, tracking and analyzing medications and medical and surgical supplies. Approximately 6,000 institutional and retail pharmacies utilize our medication adherence packaging solutions.

[0001445305-12-003598:mdna:16]
[same as prior period, unchanged from 0001445305-12-002594:mdna:16]

[0001445305-12-003598:mdna:17]
[same as prior period, unchanged from 0001445305-12-002594:mdna:17]

[0001445305-12-003598:mdna:18]
[same as prior period, unchanged from 0001445305-12-002594:mdna:18]

[0001445305-12-003598:mdna:19]
On May 21, 2012, we completed our acquisition of MedPak pursuant to the Merger Agreement for $158.3 million in cash, subject to certain adjustments, and including $13.5 million in cash that was placed in an escrow fund at the closing of the transaction, of which approximately $0.3 million was released to Omnicell and approximately $2.0 million was released to the former MedPak stockholders pursuant to a final working capital adjustment recorded during the third quarter of 2012. Under the terms of the Merger Agreement, Mercury Acquisition Corp, a newly formed Omnicell subsidiary, was merged with and into MedPak, with MedPak surviving the merger as a wholly-owned subsidiary of Omnicell. MedPak is the parent company of MTS, a worldwide provider of medication adherence packaging systems and solutions. MTS primarily manufactures and sells consumable medication blister cards, packaging equipment and ancillary products throughout the United States, Canada, Europe and Australia. Its customers are predominantly institutional pharmacies that supply nursing homes, assisted living and correctional facilities with prescription medications for their patients. MTS manufactures its proprietary consumable blister cards and most of its packaging equipment in its own facilities. This manufacturing process uses integrated equipment for manufacturing the consumable medication blister cards. In addition, MTS utilizes the services of outside contract manufacturers for some of its packaging equipment. The consumable medication blister cards and packaging equipment are designed to provide a cost-effective method for pharmacies to dispense medications. MTS’ medication dispensing systems and products provide innovative methods for dispensing medications in disposable packages. MTS Medication Technologies Limited distributes products for MTS primarily in the United Kingdom. MTS Medication Technologies GmbH distributes products for MTS in Germany. MTS currently serves more than 6,000 institutional pharmacies in the long-term care and correctional markets, both domestically and internationally.

[0001445305-12-003598:mdna:20]
With the acquisition of MTS, we organized our business into two operating business segments: Acute Care and Non-Acute Care. The Acute Care segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems. The Non-Acute Care segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products. We report segment information based on the management approach. The management approach designates the internal reporting used by the Chief Operating Decision Maker (“CODM”), for making decisions and assessing performance as the source of our operating segments. The CODM is our Chief Executive Officer. The CODM allocates resources to and assesses the performance of each operating segment, using information about its revenues, gross profit and income (loss) from operations.

[0001445305-12-003598:mdna:21]
Operations During the Three Months and Nine Months Ended September 30, 2012

[0001445305-12-003598:mdna:22]
The consolidated results presented for the three months and nine months ended September 30, 2012 reflect the impact of the acquisition of MTS since May 21, 2012 as a part of the Non-Acute Care segment.

[0001445305-12-003598:mdna:23]
Revenues grew year-over-year for both product and services, with overall revenue growth of 30.9%, comparing $84.3 million for the third quarter of 2012 with $64.4 million for the third quarter of 2011. Overall revenue growth was 22.6% for the nine months ended September 30, 2012, comparing $223.9 million with $182.6 million for the same period in 2011. As a result of the acquisition of MTS, the Non-Acute Care segment contributed $19.9 million and $32.6 million in the three months and nine months ended September 30, 2012, respectively.

[0001445305-12-003598:mdna:24]
The Non-Acute Care segment for the third quarter of 2012 contributed $18.7 million and $1.2 million to the overall product and service revenue growth, respectively. The Acute Care segment contributed revenues of $64.4 million which were unchanged for the three months ended September 30, 2012 as compared to the same period in 2011. Overall product and service margins increased by $11.6 million, or 33.8% for the three months ended September 30, 2012 as compared to the same period in 2011. Product and service margins increased by $21.3 million, or 21.3% for the nine months ended September 30, 2012 as compared to the same period in 2011.

[0001445305-12-003598:mdna:25]
During the third quarter of 2012, we achieved 11.9% growth in total revenues from the second quarter of 2012, inclusive of a full quarter of Non-Acute Care growth of $19.9 million. Product revenue increased by $8.2 million, or 13.8%, while service revenue increased by $0.8 million, or 4.8%. Overall gross margins for the third quarter of 2012 increased to 54.7% from 52.2% in the second quarter of 2012. Product gross margins increased to 54.6% on revenue of $67.4 million as compared to 51.7% on revenue of $59.3 million in the second quarter of 2012. Service gross margins increased to 54.9% on revenue of $16.9 million as compared to 54.0% on revenue of $16.1 million in the second quarter of 2012. The overall increase in gross margins is primarily attributable to a favorable product mix in the Acute Care segment.

[0001445305-12-003598:mdna:26]
[same as prior period, unchanged from 0001445305-12-002594:mdna:25]

[0001445305-12-003598:mdna:27]
[same as prior period, unchanged from 0001445305-12-002594:mdna:26]

[0001445305-12-003598:mdna:28]
| • | We have delivered industry-leading products with differentiated product features that are designed to appeal to nurses and pharmacists, such as our G4 platform, the SavvyTM Mobile Medication System, SinglePointeTM, Anywhere RNTM and the OnDemand product line; |

[0001445305-12-003598:mdna:29]
[same as prior period, unchanged from 0001445305-12-002594:mdna:28]

[0001445305-12-003598:mdna:30]
[same as prior period, unchanged from 0001445305-12-002594:mdna:29]

[0001445305-12-003598:mdna:31]
We maintain a development staff with expertise in hospital logistics, pharmacy operations and computerized automated solutions, which allows us to deliver new innovations to the market. Our ability to grow revenue and maintain positive cash flow is dependent on our ability to obtain orders from customers, our ability to manufacture consumables to meet customer demand, the volume of installations we are able to complete, our ability to meet customers’ needs while providing a quality installation experience and our flexibility in manpower allocations among customers to complete installations on a timely basis.

[0001445305-12-003598:mdna:32]
Cash, cash equivalents and short-term investments increased by $0.7 million during the three months ended September 30, 2012, to $54.8 million from $54.1 million at June 30, 2012. The change in cash, cash equivalents and short-term investments for the quarter was relatively unchanged from the prior quarter, with the increase in net income being offset by financing activities which included stock repurchases and shares issued under our stock option and employee stock purchase plans. Cash, cash equivalents and short-term investments decreased by $145.1 million during the nine months ended September 30, 2012, to $54.8 million from $199.9 million at December 31, 2011. Contributing to this decrease in cash, cash equivalents and short-term investments was $159.8 million used for the acquisition of MTS,including related transaction costs incurred during the quarter ended June 30, 2012 and year-to-date stock repurchase activity of $12.4 million to repurchase 898,168 shares of our common stock through our stock repurchase program. These expenditures were partially offset by $27.5 million in quarterly operating cash flow, reflecting improved net income and a decline in Acute Care inventories.

[0001445305-12-003598:mdna:33]
[same as prior period, unchanged from 0001445305-12-002594:mdna:33]

[0001445305-12-003598:mdna:34]
[same as prior period, unchanged from 0001445305-12-002594:mdna:34]

[0001445305-12-003598:mdna:35]
[same as prior period, unchanged from 0001445305-12-002594:mdna:35]

[0001445305-12-003598:mdna:36]
[same as prior period, unchanged from 0001445305-12-002594:mdna:36]

[0001445305-12-003598:mdna:37]
[same as prior period, unchanged from 0001445305-12-002594:mdna:37]

[0001445305-12-003598:mdna:38]
[same as prior period, unchanged from 0001445305-12-002594:mdna:38]

[0001445305-12-003598:mdna:39]
[same as prior period, unchanged from 0001445305-12-002594:mdna:39]

[0001445305-12-003598:mdna:40]
[same as prior period, unchanged from 0001445305-12-002594:mdna:40]

[0001445305-12-003598:mdna:41]
During the nine months ended September 30, 2012, there were no significant changes in our critical accounting policies and estimates.

[0001445305-12-003598:mdna:42]
[same as prior period, unchanged from 0001445305-12-002594:mdna:42]

[0001445305-12-003598:mdna:43]
Recently Adopted Accounting Pronouncements

[0001445305-12-003598:mdna:44]
In May 2011, FASB issued ASU 2011-04, Fair Value Measurement, amending the fair value guidance in ASC 820, and thereby achieving substantially converged fair value measurement and disclosure requirements for GAAP and IFRS. The new guidance clarified some fair value measurement principles and expanded certain disclosure requirements. We adopted this guidance in the first quarter of 2012, without any impact to our financial position, operating results or cash flows.

[0001445305-12-003598:mdna:45]
Recently Issued Accounting Pronouncements

[0001445305-12-003598:mdna:46]
In July 2012, FASB issued ASU 2012-02, Intangibles - Goodwill and Other (Topic 350): Testing Indefinite-lived Intangible Assets for Impairment, which amends the guidance in ASC 350-30 on impairment testing of intangible assets with indefinite lives other than goodwill. This guidance gives an entity the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not that an indefinite-lived asset is impaired. An entity has the option to bypass the qualitative assessment and proceed directly to calculating the fair value of an intangible asset with an indefinite life. This update will be effective for us for interim and annual impairment tests performed beginning in the first quarter of fiscal 2013. We do not anticipate this update will have any significant impact on our financial position, operating results or cash flows, as this update does not change how we calculate impairment loss.

[0001445305-12-003598:mdna:47]
[same as prior period, unchanged from 0001445305-12-002594:mdna:45]

[0001445305-12-003598:mdna:48]
The table below shows the components of our results of operations as percentages of total revenues for the three months and nine months ended September 30, 2012 and 2011 (in thousands, except percentages):

[0001445305-12-003598:mdna:49]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | 2012 |  | 2011 |
|  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 67,446 |  |  | 80.0 | % |  | $ | 49,790 |  |  | 77.3 | % |  | $ | 175,239 |  |  | 78.3 | % |  | $ | 138,583 |  |  | 75.9 | % |
| Service and other revenues | 16,885 |  |  | 20.0 | % |  | 14,649 |  |  | 22.7 | % |  | 48,619 |  |  | 21.7 | % |  | 44,021 |  |  | 24.1 | % |
| Total revenues | 84,331 |  |  | 100.0 | % |  | 64,439 |  |  | 100.0 | % |  | 223,858 |  |  | 100.0 | % |  | 182,604 |  |  | 100.0 | % |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 30,636 |  |  | 36.3 | % |  | 22,429 |  |  | 34.8 | % |  | 79,532 |  |  | 35.5 | % |  | 59,995 |  |  | 32.9 | % |
| Cost of service and other revenues | 7,608 |  |  | 9.0 | % |  | 7,562 |  |  | 11.8 | % |  | 23,114 |  |  | 10.3 | % |  | 22,704 |  |  | 12.4 | % |
| Total cost of revenues | 38,244 |  |  | 45.3 | % |  | 29,991 |  |  | 46.6 | % |  | 102,646 |  |  | 45.8 | % |  | 82,699 |  |  | 45.3 | % |
| Gross profit | 46,087 |  |  | 54.7 | % |  | 34,448 |  |  | 53.4 | % |  | 121,212 |  |  | 54.2 | % |  | 99,905 |  |  | 54.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 5,545 |  |  | 6.6 | % |  | 6,019 |  |  | 9.3 | % |  | 17,538 |  |  | 7.8 | % |  | 16,139 |  |  | 8.8 | % |
| Selling, general and administrative | 29,316 |  |  | 34.8 | % |  | 23,635 |  |  | 36.7 | % |  | 86,382 |  |  | 38.6 | % |  | 73,713 |  |  | 40.4 | % |
| Total operating expenses | 34,861 |  |  | 41.4 | % |  | 29,654 |  |  | 46.0 | % |  | 103,920 |  |  | 46.4 | % |  | 89,852 |  |  | 49.2 | % |
| Income from operations | 11,226 |  |  | 13.3 | % |  | 4,794 |  |  | 7.4 | % |  | 17,292 |  |  | 7.8 | % |  | 10,053 |  |  | 5.5 | % |
| Interest and other income (expense), net | 34 |  |  | — | % |  | (191 | ) |  | (0.3 | )% |  | 57 |  |  | — |  |  | (66 | ) |  | — | % |
| Income before provision for income taxes | 11,260 |  |  | 13.3 | % |  | 4,603 |  |  | 7.1 | % |  | 17,349 |  |  | 7.8 | % |  | 9,987 |  |  | 5.5 | % |
| Provision for income taxes | 4,340 |  |  | 5.1 | % |  | 1,609 |  |  | 2.5 | % |  | 6,703 |  |  | 3.0 | % |  | 3,736 |  |  | 2.1 | % |
| Net income | $ | 6,920 |  |  | 8.2 | % |  | $ | 2,994 |  |  | 4.6 | % |  | $ | 10,646 |  |  | 4.8 | % |  | $ | 6,251 |  |  | 3.4 | % |

[0001445305-12-003598:mdna:50]
[same as prior period, unchanged from 0001445305-12-002594:mdna:48]

[0001445305-12-003598:mdna:51]
[same as prior period, unchanged from 0001445305-12-002594:mdna:49]

[0001445305-12-003598:mdna:52]
The table below shows our product revenues, cost of product revenues and gross profit for the three months and nine months ended September 30, 2012 and 2011 and the percentage changes between those periods (in thousands, except percentages):

[0001445305-12-003598:mdna:53]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | % Change |  | 2012 |  | 2011 |  | % Change |
| Product revenues | $ | 67,446 |  |  | $ | 49,790 |  |  | 35.5 | % |  | $ | 175,239 |  |  | $ | 138,583 |  |  | 26.5 | % |
| Cost of product revenues | 30,636 |  |  | 22,429 |  |  | 36.6 | % |  | 79,532 |  |  | 59,995 |  |  | 32.6 | % |
| Gross profit | $ | 36,810 |  |  | $ | 27,361 |  |  | 34.5 | % |  | $ | 95,707 |  |  | $ | 78,588 |  |  | 21.8 | % |
| Gross margin | 54.6 | % |  | 55.0 | % |  |  |  | 54.6 | % |  | 56.7 | % |  |  |

[0001445305-12-003598:mdna:54]
Product revenues increased by $17.7 million, or 35.5%, in the three months ended September 30, 2012 as compared to the same period in 2011. Product revenues increased by $36.7 million, or 26.5%, in the nine months ended September 30, 2012 as compared to the same period in 2011. The overall increase in product revenues was driven by the contribution of our Non-Acute Care segment of $18.7 million and $30.2 million for the three months and nine months ended September 30, 2012, respectively, while the Acute Care segment was flat as compared to the same period in 2011. We anticipate our revenues will continue to increase in 2012 as we fulfill our existing orders and as we experience an anticipated continued high volume of lease renewals. Additionally, year over year revenue growth for the remainder of 2012 will continue to be affected by the results from the Non-Acute Care segment that we established in May 2012. Our ability to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0001445305-12-003598:mdna:55]
Cost of product revenues increased by $8.2 million, or 36.6%, in the three months ended September 30, 2012 as compared to the same period in 2011. Cost of product revenues increased by $19.5 million, or 32.6%, in the nine months ended September 30, 2012 as compared to the same period in 2011. This increase was primarily a result of Non-Acute Care product costs of $19.1 million, which includes $1.7 million of transaction and integration expenses related to the MTS acquisition. The $1.7 million is comprised of a $1.6 million write off of the inventory fair value step up recorded on the opening balance sheet, and $0.1 million for severance expenses related to staff realignment. Acute Care product costs for the nine months ended September 30, 2012 increased by $0.4 million, which is a function of increased revenues, and product mix.

[0001445305-12-003598:mdna:56]
Gross profit on product revenue increased by $9.4 million, or 34.5%, in the three months ended September 30, 2012 as compared to the same period in 2011. Gross profit on product revenue increased by $17.1 million, or 21.8%, in the nine months ended September 30, 2012 as compared to the same period in 2011. These increases were primarily a result of the aforementioned contribution from our Non-Acute Care market, as well as increased gross profits in our Acute Care segment of $1.6 million and $6.0 million for the three months and nine months ended September 30, 2012, respectively, which were driven primarily by product mix.

[0001445305-12-003598:mdna:57]
[same as prior period, unchanged from 0001445305-12-002594:mdna:57]

[0001445305-12-003598:mdna:58]
The table below shows our service and other revenues, cost of service and other revenues and gross profit for the three months and nine months ended September 30, 2012 and 2011 and the percentage change between those periods (in thousands, except percentages):

[0001445305-12-003598:mdna:59]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | % Change |  | 2012 |  | 2011 |  | % Change |
| Service and other revenues | $ | 16,885 |  |  | $ | 14,649 |  |  | 15.3 | % |  | $ | 48,619 |  |  | $ | 44,021 |  |  | 10.4 | % |
| Cost of service and other revenues | 7,608 |  |  | 7,562 |  |  | 0.6 | % |  | 23,114 |  |  | 22,704 |  |  | 1.8 | % |
| Gross profit | $ | 9,277 |  |  | $ | 7,087 |  |  | 30.9 | % |  | $ | 25,505 |  |  | $ | 21,317 |  |  | 19.6 | % |
| Gross margin | 54.9 | % |  | 48.4 | % |  |  |  | 52.5 | % |  | 48.4 | % |  |  |

[0001445305-12-003598:mdna:60]
Service and other revenues include revenues from service and maintenance contracts, rentals of automation systems, training and professional services. Service and other revenues increased by $2.2 million, or 15.3%, in the three months ended September 30, 2012 as compared to the same period in 2011. Service and other revenues increased by $4.6 million, or 10.4%, in the nine months ended September 30, 2012 as compared to the same period in 2011. The increase in service and other

[0001445305-12-003598:mdna:61]
revenues was primarily the result of an expansion in our installed base of automation systems and continued growth in analytical software business resulting in an increase in the number of support service contracts, higher training revenues and service revenues attributable to our Non-Acute Care segment of $1.2 million and $2.3 million for the three months and nine months ended September 30, 2012, respectively.

[0001445305-12-003598:mdna:62]
Cost of service and other revenues were flat in the three months ended September 30, 2012 as compared to the same period in 2011 and increased by $0.4 million, or 1.8%, in the nine months ended September 30, 2012 as compared to the same period in 2011. This increase was primarily due to costs attributable to our Non-Acute Care segment.

[0001445305-12-003598:mdna:63]
Gross profit on service and other revenues increased by $2.2 million, or 30.9%, in the three months ended September 30, 2012 as compared to the same period in 2011. Gross profit on service and other revenues increased by $4.2 million, or 19.6%, in the nine months ended September 30, 2012 as compared to the same period in 2011. The increase in gross profit on service and other revenues was primarily due to increased revenues from an expanded installed base with nominal growth in service cost attributable to our Acute Care segment as a result of service cost reduction efforts throughout the periods. The contribution to gross profit on service and other revenues from our Non-Acute Care segment was $0.7 million and $1.7 million three months and nine months ended September 30, 2012, respectively.

[0001445305-12-003598:mdna:64]
We expect our service and other revenues and associated gross profit to vary in the future. We expect increases in the installed base and the addition of Non-Acute Care service revenue and gross profit to be partially or fully offset by an increased propensity for customers to contract for service on a time and material basis, variations in the quantity and cost of spare parts used to service our installed base, and increases in staffing to accommodate an increased number of customers.

[0001445305-12-003598:mdna:65]
[same as prior period, unchanged from 0001445305-12-002594:mdna:64]

[0001445305-12-003598:mdna:66]
The table below shows our operating expenses for the three months and nine months ended September 30, 2012 and 2011 and the percentage changes between those periods (in thousands, except percentages):

[0001445305-12-003598:mdna:67]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2012 |  | 2011 |  | % Change |  | 2012 |  | 2011 |  | % Change |
| Research and development | $ | 5,545 |  |  | $ | 6,019 |  |  | (7.9 | )% |  | $ | 17,538 |  |  | $ | 16,139 |  |  | 8.7 | % |
| Selling, general and administrative | 29,316 |  |  | 23,635 |  |  | 24.0 | % |  | 86,382 |  |  | 73,713 |  |  | 17.2 | % |
| Total operating expenses | $ | 34,861 |  |  | $ | 29,654 |  |  | 17.6 | % |  | $ | 103,920 |  |  | $ | 89,852 |  |  | 15.7 | % |

[0001445305-12-003598:mdna:68]
Research and Development. Research and development expenses decreased by $0.5 million, or 7.9%, in the three months ended September 30, 2012 as compared to the same period in 2011 and represented 6.6% and 9.3% of total revenues in the three months ended September 30, 2012 and 2011, respectively. The overall decrease in research and development expenses reflects a $0.9 million increase in the amount of software development capitalized and a $0.3 million decrease in compensation, benefits and other expenses during the three months ended September 30, 2012 as compared with the year-ago period, offset by an overall increase of $0.7 million in research and development expenses attributable to the Non-Acute Care segment. The decrease as a percentage of revenue is primarily a reflection of the overall growth in revenue without a corresponding increase in research and development expenditures. Research and development expenses increased by $1.4 million, or 8.7%, in the nine months ended September 30, 2012 as compared to the same period in 2011 and represented 7.8% and 8.8% of total revenues in the nine months ended September 30, 2012 and 2011, respectively. The increase in research and development expenses during the nine month period ended September 30, 2012 as compared with the year-ago period was primarily due to $0.8 million in research and development expenses attributable to the Non-Acute Care segment and a $1.0 million decrease in software development capitalized, partially offset by lower vacation and other compensation related expenses. The amount of research and development expense can fluctuate based on the amount of prototype expenses for hardware and/or the amount of capitalized software development costs in any given quarter.

[0001445305-12-003598:mdna:69]
[same as prior period, unchanged from 0001445305-12-002594:mdna:68]

[0001445305-12-003598:mdna:70]
Selling, General and Administrative. Selling, general and administrative expenses increased by $5.7 million, or 24.0%, in the three months ended September 30, 2012 as compared to the same period in 2011. Selling, general and administrative expenses represented 34.8% and 36.7% of total revenues in the three months ended September 30, 2012 and 2011, respectively. The increase was primarily due to the addition of Non-Acute Care selling, general and administrative expenses of $5.1 million and a $0.9 million increase in compensation costs related to increased sales and marketing staffing,

[0001445305-12-003598:mdna:71]
offset by lower commissions of $0.3 million.

[0001445305-12-003598:mdna:72]
Selling, general and administrative expenses increased by $12.7 million, or 17.2%, in the nine months ended September 30, 2012 as compared to the same period in 2011. Selling, general and administrative expenses represented 38.6% and 40.4% of total revenues in the nine months ended September 30, 2012 and 2011, respectively. The increase was primarily due to the addition of Non-Acute Care selling, general and administrative expenses of $8.8 million, a $3.8 million increase in costs associated with compensation and related benefits, $2.3 million in transaction and integration expenses related to the acquisition of MTS and an increase of $0.9 million in bad debt, offset by a $1.1 million decrease in legal expenses related to the settlement of  litigation in 2011, a $1.1 million decrease in consulting expenses and a $0.6 million decrease in promotional and other expenses.

[0001445305-12-003598:mdna:73]
We expect selling, general and administrative expenses to grow at a nominal rate in order to support our anticipated growth as well as international expansion efforts, but anticipate that increased efficiencies will result in a lower selling, general and administrative expense relative to total revenue growth in 2012.

[0001445305-12-003598:mdna:74]
Share-based Compensation. The effect of share-based compensation on functional expenses within our operating results for the three months and nine months ended September 30, 2012 and 2011 is presented in Note 13, “Stock Option Plans and Share-Based Compensation.”

[0001445305-12-003598:mdna:75]
[same as prior period, unchanged from 0001445305-12-002594:mdna:74]

[0001445305-12-003598:mdna:76]
The annual effective tax rate before discrete items was 41.5% and 40.3% for the nine months ended September 30, 2012 and 2011, respectively. The increase in the estimated 2012 annual effective tax rate recorded in the nine months ended September 30, 2012 as compared to the same period in 2011 was primarily due to the expiration of the federal research and development credit after 2011 and non-deductible acquisition costs and equity charges, partially offset by an increase in domestic production activity deduction.

[0001445305-12-003598:mdna:77]
[same as prior period, unchanged from 0001445305-12-002594:mdna:76]

[0001445305-12-003598:mdna:78]
We had cash and cash equivalents of $54.8 million at September 30, 2012, as compared to $191.8 million in cash and cash equivalents and $8.1 million of short term investments at December 31, 2011. All of our cash is in low risk short term money market funds or demand deposits. The $8.1 million of short term investments held at December 31, 2011 consisted of California revenue anticipation notes which matured on June 26, 2012. We had no long term investments as of September 30, 2012. While in the future we may need to seek additional financing to meet our working capital needs and to finance capital expenditures, as well as to fund operations or potential acquisitions, we believe our current cash and cash equivalent balances and cash flows generated by operations will be sufficient to satisfy our anticipated cash needs for working capital and capital expenditures for at least the next twelve months. Our cash and cash equivalents of $54.8 million reflects use of $156.3 million of cash expended to acquire MTS on May 21, 2012, net of cash acquired, as described in Note 14, “Business Acquisition.”

[0001445305-12-003598:mdna:79]
Cash flows for the nine months ended September 30, 2012 and 2011 consisted of the following (in thousands):

[0001445305-12-003598:mdna:80]
|  | Nine Months Ended September 30, |
|  | 2012 |  | 2011 |
| Net cash provided by operating activities | $ | 27,477 |  |  | $ | 14,629 |  |
| Net cash used in investing activities | (161,171 | ) |  | (10,421 | ) |
| Net cash used in financing activities | (3,250 | ) |  | (400 | ) |
| Effect of exchange rate changes on cash and cash equivalents | — |  |  | (140 | ) |
| Net (decrease) increase in cash and cash equivalents | $ | (136,944 | ) |  | $ | 3,668 |  |

[0001445305-12-003598:mdna:81]
Operating activities provided $27.5 million of cash during the nine months ended September 30, 2012 as compared to $14.6 million for the nine months ended September 30, 2011. The main drivers for the $12.8 million increase in cash generated from operations were a $4.4 million increase in net income, a $10.8 million increase from the change in inventories primarily the result of a non-recurring increase in 2011 in anticipation of new product introductions, a $0.8 million increase in other long term liabilities, a $1.9 million increase from other current assets, a $1.5 million cash increase from accrued compensation, and a $1.2 million cash increase from the excess tax benefits from employee stock plans. These amounts were partially offset by a $4.8 million cash decrease in prepaid expenses, a $3.8 million decrease in accounts receivable, a $2.0 million decrease in accrued liabilities, a $0.8 million decrease in other assets and a $2.4 million decrease in investment in sales-type leases.

[0001445305-12-003598:mdna:82]
34

[0001445305-12-003598:mdna:83]
Cash used in investing activities totaled $161.2 million during the nine months ended September 30, 2012, as compared to $10.4 million provided by investing activities during the nine months ended September 30, 2011. This $150.8 million decrease in cash primarily reflects the $156.3 million of net cash used to acquire MTS combined with cash used of $2.8 million for purchases of property and equipment. The increase in cash used in investing activities was offset by the $8.1 million in net proceeds from maturities of California revenue anticipation notes. Software development capitalization decreased by $0.4 million from the prior period as a result of more pre-capitalization testing of several new software applications for external sale or lease performed in the prior period.

[0001445305-12-003598:mdna:84]
Cash used by financing activities was $3.3 million during the nine months ended September 30, 2012, as compared to $0.4 million during the nine months ended September 30, 2011, resulting in a difference of $2.9 million in cash used. The increase is primarily due to cash used for stock repurchases of $1.8 million. Additionally, excess tax benefits from employees stock plans was $1.2 million less in the nine months ended September 30, 2012.

[0001445305-12-003598:mdna:85]
[same as prior period, unchanged from 0001445305-12-002594:mdna:83]

[0001445305-12-003598:mdna:86]
Except for the Milpitas lease signed in March 2012 and the assumption of the St. Petersburg lease in May 2012, there have been no material changes to our contractual obligations during the nine months ended September 30, 2012. Please refer to our Annual Report on Form 10-K for the year ended December 31, 2011 for a description of our facility leases and contractual obligations and the Notes to the consolidated financial statements included therein.

[0001445305-12-003598:mdna:87]
The following table summarizes our contractual obligations at September 30, 2012 (in thousands):

[0001445305-12-003598:mdna:88]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | More than five years |
| Operating leases (1) (2) (3) (4) | $ | 47,093 |  |  | $ | 5,758 |  |  | $ | 10,633 |  |  | $ | 9,397 |  |  | $ | 21,305 |  |
| Commitments to contract manufacturers and suppliers (5) | 6,301 |  |  | 6,301 |  |  | — |  |  | — |  |  | — |  |
| Total (6) | $ | 53,394 |  |  | $ | 12,059 |  |  | $ | 10,633 |  |  | $ | 9,397 |  |  | $ | 21,305 |  |

[0001445305-12-003598:mdna:89]
[same as prior period, unchanged from 0001445305-12-002594:mdna:87]

[0001445305-12-003598:mdna:90]
(2)       In October 2011, we entered into a lease agreement for approximately 100,000 square feet of office space. Pursuant to the lease agreement, the landlord has constructed a single, three-story building of rentable space located at 590 Middlefield Road in Mountain View, California which we will lease and which will serve as our headquarters. The term of the lease agreement is for a period of ten years, and will commence in November 2012, with a base lease commitment of approximately $40.0 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term.

[0001445305-12-003598:mdna:91]
(3)      In March 2012, we entered into a lease agreement for approximately 46,000 square feet of manufacturing, distribution and office space located at 735 Sycamore Drive in Milpitas, California which commenced in October 2012. The term of the lease agreement is for a period of 60 months, with a base lease commitment of approximately $1.8 million and a single 60 month extension option.

[0001445305-12-003598:mdna:92]
(4)    Commencing with the acquisition of MTS, we assumed responsibility for 132,500 square feet of manufacturing, warehousing and office space in St. Petersburg, Florida. The remaining term of the original 12 year lease agreement expires September 30, 2016, with a remaining base lease commitment of approximately $3.7 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term. In Leeds, United Kingdom, MTS leases an office and distribution center. The remaining term of the original 10 year lease agreement is through June 8, 2021, with no extension options. The remaining base lease commitment, converted from British Pounds at the current conversion rate, is approximately $1.2 million. MTS also has smaller rented offices in Strongsville, Ohio and Germany.

[0001445305-12-003598:mdna:93]
[same as prior period, unchanged from 0001445305-12-002594:mdna:91]

[0001445305-12-003598:mdna:94]
(6)    At September 30, 2012, we have recorded $3.5 million for uncertain tax positions under long term liabilities, in accordance with GAAP, summarized under Note 1, “Organization and Summary of Significant Accounting Policies.” As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend

[0001445305-12-003598:mdna:95]
upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $3.5 million of uncertain tax position liabilities has not been included in the table of commitments above.

[0001445305-12-003598:mdna:96]
[same as prior period, unchanged from 0001445305-12-002594:mdna:93]

[0001445305-12-003598:mdna:97]
As of September 30, 2012, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
