# OMCL note change history — 0001445305-12-002594 → 0001445305-12-003598


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2012-11-09):
[0001445305-12-003598:note_history:1]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of September 30, 2012 or December 31, 2011.
  (was, 2012-08-09, similarity 0.9945):
[0001445305-12-002594:note_history:1]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of June 30, 2012 or December 31, 2011.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-11-09):
[0001445305-12-003598:note_history:2]
On May 21, 2012, we completed our acquisition of MedPak Holdings, Inc. (“MedPak”). MedPak is the parent company of MTS Medication Technologies, Inc. (“MTS”), a worldwide provider of medication adherence packaging systems. This acquisition aligns us with the long-term trends of the healthcare market to manage the health of patients across the continuum of care.  We can now serve both the acute care and non-acute markets. Omnicell and MTS bring capabilities to each other that strengthen the product lines and expand the medication management coverage of both companies. Please refer to Note 14, “Business Acquisition” for more information regarding the transaction.
  (was, 2012-08-09, similarity 0.9783):
[0001445305-12-002594:note_history:2]
On May 21, 2012, we completed our acquisition of MedPak Holdings, Inc. (“MedPak”). MedPak is the parent company of MTS Medication Technologies, Inc. (“MTS”), a worldwide provider of medication adherence packaging systems. This acquisition aligns us with the long-term trends of the healthcare market to manage the health of patients across the continuum of care.  We can now serve both the acute care and non-acute markets. Omnicell and MTS bring capabilities to each other that strengthen the product lines and expand the medication management coverage of both companies. Please refer to Note 14, “Business Acquisition” for more information.

- changed (2012-11-09):
[0001445305-12-003598:note_history:3]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of September 30, 2012, the results of their operations and comprehensive income for the three months and nine months ended September 30, 2012 and 2011 and their cash flows for the nine months ended September 30, 2012 and 2011. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2011.
  (was, 2012-08-09, similarity 0.9471):
[0001445305-12-002594:note_history:3]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of June 30, 2012, the results of their operations and comprehensive income for the three months and six months ended June 30, 2012 and 2011 and their cash flows for the six months ended June 30, 2012 and 2011. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2011.

- added (2012-11-09):
[0001445305-12-003598:note_history:4]
Our results of operations, comprehensive income and cash flows for the three months and nine months ended September 30, 2012 are not necessarily indicative of results that may be expected for the year ending December 31, 2012, or for any future period.

- added (2012-11-09):
[0001445305-12-003598:note_history:5]
At September 30, 2012 and December 31, 2011, our financial assets, measured at fair value on a recurring basis, utilizing Level 1 inputs included cash equivalents. For these items, quoted market prices are readily available and fair value approximates carrying value. At December 31, 2011, we had a short-term investment in California revenue anticipation notes, measured at fair value on a recurring basis, the valuation inputs of which were classified as Level 2. We do not currently have any material financial instruments, measured at fair value on a recurring basis, utilizing Level 3 inputs.

- changed (2012-11-09):
[0001445305-12-003598:note_history:6]
Classification of marketable securities. Securities held as investments for the indefinite future pending future spending requirements are classified as “Available-for-sale” and are carried at their fair value, with any unrealized gain or loss recorded to other comprehensive income until realized. At September 30, 2012 and December 31, 2011, we held $31.9 million and $177.3 million, respectively, of money market mutual funds classified as Available-for-sale cash equivalents. At December 31, 2011, we held $8.1 million of non-U.S. Government securities classified as Available-for-sale short-term investments. We do not hold securities for purposes of trading. Marketable securities for which we have the intent and ability to hold to maturity are classified as “Held-to-maturity” and are carried at their amortized cost, including accrued interest. We had no Held-to-maturity securities at September 30, 2012 and December 31, 2011.
  (was, 2012-08-09, similarity 0.9588):
[0001445305-12-002594:note_history:6]
Classification of marketable securities. Securities held as investments for the indefinite future, pending future spending requirements are classified as “Available-for-sale” and are carried at their fair value, with any unrealized gain or loss recorded to other comprehensive income until realized. At June 30, 2012 and December 31, 2011, we held $33.6 million and $177.3 million, respectively, of money market mutual funds classified as Available-for-sale cash equivalents. At December 31, 2011, we held $8.1 million of non-U.S. Government securities classified as Available-for-sale short-term investments. We do not hold securities for purposes of trading. Marketable securities for which we have the intent and ability to hold to maturity are classified as “Held-to-maturity” and are carried at their amortized cost, including accrued interest. There were no Held-to-maturity securities held at June 30, 2012 and December 31, 2011.

- added (2012-11-09):
[0001445305-12-003598:note_history:7]
Segment information. Beginning with the May 21, 2012 acquisition of MTS, we manage our business on the basis of two operating segments: Acute Care, which primarily includes products and services sold to hospital customers, and Non-Acute Care, which primarily includes products and services sold to customers outside of hospital settings. The historical Omnicell results were reported as a single segment and reporting unit, primarily comprising the Acute Care segment. MTS primarily comprises the Non-Acute Care segment and reporting unit.

- changed (2012-11-09):
[0001445305-12-003598:note_history:8]
Revenue recognition. We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems with related services, which are sold in our principal market, which is the healthcare industry. Our customer arrangements typically include one or more of the following deliverables:
  (was, 2012-08-09, similarity 0.9372):
[0001445305-12-002594:note_history:8]
Revenue recognition. We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems, with related services, which are sold in our principal market, which is the healthcare industry. Our customer arrangements typically include one or more of the following deliverables:

- changed (2012-11-09):
[0001445305-12-003598:note_history:9]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.
  (was, 2012-08-09, similarity 0.996):
[0001445305-12-002594:note_history:9]
Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

- changed (2012-11-09):
[0001445305-12-003598:note_history:10]
Sales of accounts receivable. We record the sale of our accounts receivables as “true sales” in accordance with accounting guidance for transfers and servicing of financial assets. During the three months ended September 30, 2012 and 2011, we transferred non-recourse accounts receivable totaling $14.6 million and $9.0 million, respectively, which approximated fair value, to third-party leasing companies. During the nine months ended September 30, 2012 and 2011, we transferred non-recourse accounts receivable totaling $42.5 million and $32.2 million, respectively, which approximated fair value, to third-party leasing companies. At September 30, 2012 and December 31, 2011, accounts receivable included $0.8 million and $0.2 million, respectively, due from third-party leasing companies for transferred non-recourse accounts receivable.
  (was, 2012-08-09, similarity 0.9532):
[0001445305-12-002594:note_history:10]
Sales of accounts receivable. We record the sale of our accounts receivables as “true sales” in accordance with accounting guidance for transfers and servicing of financial assets. During the three months ended June 30, 2012 and 2011, we transferred non-recourse accounts receivable totaling $15.7 million and $12.2 million, respectively, which approximated fair value, to third-party leasing companies. During the six months ended June 30, 2012 and 2011, we transferred non-recourse accounts receivable totaling $27.8 million and $23.2 million, respectively, which approximated fair value, to third-party leasing companies. At June 30, 2012 and December 31, 2011, accounts receivable included $0.7 million and $0.2 million, respectively, due from third-party leasing companies for transferred non-recourse accounts receivable.

- changed (2012-11-09):
[0001445305-12-003598:note_history:11]
Concentration in revenues and in accounts receivable. There were no customers accounting for 10% or more of revenues in the three months ended September 30, 2012 or 2011. Additionally, there were no customers accounting for 10% or more of revenues in the nine months ended September 30, 2012 or 2011. There were no customers accounting for 10% or more of accounts receivable at September 30, 2012 or at December 31, 2011.
  (was, 2012-08-09, similarity 0.8661):
[0001445305-12-002594:note_history:11]
Concentration in revenues and in accounts receivable. There were no customers accounting for 10% or more of revenues in the three months ended June 30, 2012 or 2011. Additionally, there were no customers accounting for 10% or more of revenues in the six months ended June 30, 2012 or 2011. There were no customers accounting for 10% or more of accounts receivable at June 30, 2012 or at December 31, 2011.

- changed (2012-11-09):
[0001445305-12-003598:note_history:12]
Accounting policy for shipping costs. Outbound freight billed to customers is recorded as product revenue. The related shipping and handling cost is expensed as part of selling, general and administrative expense. Such shipping and handling expenses totaled $1.2 million and $0.7 million for the three months ended September 30, 2012 and 2011, respectively. Shipping and handling expenses totaled $2.7 million and $2.1 million for the nine months ended September 30, 2012 and 2011, respectively.
  (was, 2012-08-09, similarity 0.933):
[0001445305-12-002594:note_history:12]
Accounting policy for shipping costs. Outbound freight billed to customers is recorded as product revenue. The related shipping and handling cost is expensed as part of selling, general and administrative expense. Such shipping and handling expenses totaled $0.8 million and $0.8 million for the three months ended June 30, 2012 and 2011, respectively. Shipping and handling expenses totaled $1.5 million and $1.4 million for the six months ended June 30, 2012 and 2011, respectively

- changed (2012-11-09):
[0001445305-12-003598:note_history:13]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended September 30, 2012 and 2011 were approximately $6.3 million and $4.9 million, respectively. Purchases from this supplier for the nine months ended September 30, 2012 and 2011 were approximately $17.8 million and $16.1 million, respectively.
  (was, 2012-08-09, similarity 0.9527):
[0001445305-12-002594:note_history:13]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended June 30, 2012 and 2011 were approximately $5.2 million and $5.7 million, respectively. Purchases from this supplier for the six months ended June 30, 2012 and 2011 were approximately $11.5 million and $11.2 million, respectively.

- added (2012-11-09):
[0001445305-12-003598:note_history:14]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 41.5% and 40.3% for the nine months ended September 30, 2012 and 2011, respectively. The 2012 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, including non-deductible acquisition costs, all of which were partially offset by the domestic production activities deduction.

- changed (2012-11-09):
[0001445305-12-003598:note_history:15]
The 2011 annual effective tax rate differed from the statutory rate of 35%, primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the federal research and development credit claimed and the domestic production activities deduction. Our projected effective tax rate for 2012, after discrete items recorded through September 30, 2012 and 2011, were approximately 39.6% and 38.4%, respectively.
  (was, 2012-08-09, similarity 0.8347):
[0001445305-12-002594:note_history:15]
The 2011 annual effective tax rate differed from the statutory rate of 35%, primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the federal research and development credit claimed and the domestic production activities deduction. Our effective tax rate, after discrete items, for the six months ended June 30, 2012 and 2011, was approximately 40.4% and 41.0%, respectively.

- added (2012-11-09):
[0001445305-12-003598:note_history:16]
As of September 30, 2012, we had total gross unrecognized tax benefits of approximately $8.4 million, compared with approximately $5.8 million on December 31, 2011, representing an increase of approximately $2.6 million during the nine months ended September 30, 2012. Approximately $1.0 million of the increase was attributable to unrecognized tax benefits recorded as part of the MTS acquisition. Of the total unrecognized tax benefits, $7.1 million and $4.6 million as of September 30, 2012 and December 31, 2011, respectively, if recognized would reduce our effective tax rate in the period of recognition. Gross interest and penalties related to unrecognized tax benefit accrued were immaterial as of September 30, 2012 and December 31, 2011.

- added (2012-11-09):
[0001445305-12-003598:note_history:17]
Recently issued accounting pronouncement. In July 2012, FASB issued ASU 2012-02, Intangibles - Goodwill and Other (Topic 350): Testing Indefinite-lived Intangible Assets for Impairment, which amends the guidance in ASC 350-30 on impairment testing of intangible assets with indefinite lives other than goodwill. This guidance gives an entity the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not that an indefinite-lived asset is impaired. An entity has the option to bypass the qualitative assessment and proceed directly to calculating the fair value of an intangible asset with an indefinite life. This update will be effective for us for interim and annual impairment tests performed beginning in the first quarter of fiscal 2013. We do not anticipate this update will have any significant impact on our financial position, operating results or cash flows, as this update does not change how we calculate impairment loss.

- removed (2012-11-09):
[0001445305-12-002594:note_history:18]
Our results of operations, comprehensive income and cash flows for the three months and six months ended June 30, 2012 are not necessarily indicative of results that may be expected for the year ending December 31, 2012, or for any future period.

- removed (2012-11-09):
[0001445305-12-002594:note_history:19]
At June 30, 2012 and December 31, 2011, our financial assets, measured at fair value on a recurring basis, utilizing Level 1 inputs included cash equivalents. For these items, quoted market prices are readily available and fair value approximates carrying value. At December 31, 2011, we had a short-term investment in California revenue anticipation notes, measured at fair value on a recurring basis, the valuation inputs of which were classified as Level 2. We do not currently have any material financial instruments, measured at fair value on a recurring basis, utilizing Level 3 inputs.

- removed (2012-11-09):
[0001445305-12-002594:note_history:20]
Segment information. Beginning with the May 21, 2012 acquisition of MTS, we manage our business on the basis of two operating segments: Acute Care and Non-Acute Care. The historical Omnicell results reported as a single segment and reporting unit comprise the Acute Care segment. MTS comprises the Non-Acute Care segment and reporting unit.

- removed (2012-11-09):
[0001445305-12-002594:note_history:21]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 40.9% and 41.7% for the six months ended June 30, 2012 and 2011, respectively. The 2012 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.

- removed (2012-11-09):
[0001445305-12-002594:note_history:22]
As of June 30, 2012, we had total gross unrecognized tax benefits of approximately $7.2 million compared with approximately $5.8 million on December 31, 2011, representing an increase of approximately $1.4 million during the six months ended June 30, 2012. Approximately $1.0 million of the increase was attributable to unrecognized tax benefits recorded as part of the MTS acquisition. Of the total unrecognized tax benefits, $6.0 million and $4.6 million as of June 30, 2012 and  December 31, 2011 respectively, if recognized would reduce our effective tax rate in the period of recognition. Gross interest and penalty related to unrecognized tax benefit accrued was immaterial as of June 30, 2012 and December 31, 2011.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2012-11-09):
[0001445305-12-003598:note_history:23]
Revenue recognition. We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems with related services, which are sold in our principal market, which is the healthcare industry. Our customer arrangements typically include one or more of the following deliverables:
  (was, 2012-08-09, similarity 0.9372):
[0001445305-12-002594:note_history:23]
Revenue recognition. We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems, with related services, which are sold in our principal market, which is the healthcare industry. Our customer arrangements typically include one or more of the following deliverables:


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2012-11-09):
[0001445305-12-003598:note_history:24]
Investment in United Kingdom Distributor

- added (2012-11-09):
[0001445305-12-003598:note_history:25]
On September 28, 2012, we entered into an agreement with our distributor in the United Kingdom to purchase 15% of the outstanding equity in the company for approximately $0.9 million in cash. In connection with the investment, Omnicell has the right, under certain circumstances, to appoint a member to our United Kingdom distributor's board of directors as well as certain other voting rights. As a result of these and other factors, we anticipate that we will be accounting for this investment using the equity method.

- removed (2012-11-09):
[0001445305-12-002594:note_history:26]
Treasury Stock Repurchase

- removed (2012-11-09):
[0001445305-12-002594:note_history:27]
In 2008, our Board of Directors established the “2008 Repurchase Program,” authorizing share repurchases of $90.0 million. Subsequent to June 30, 2012, we have continued with share repurchases. Through the date of this filing, $1.1 million remains authorized for future share repurchases due to 314,100 shares repurchased since June 30, 2012, at an average cost of $13.39 per share, including commissions.

- removed (2012-11-09):
[0001445305-12-002594:note_history:28]
On August 1, 2012, our Board of Directors established a new “2012 Repurchase Program”, authorizing share  repurchases of $50.0 million, with no termination date. The timing, price and volume of repurchases will be based on market conditions, relevant securities laws and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions or pursuant to a Rule 10b-18 plan. The stock repurchase program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase program at any time.
