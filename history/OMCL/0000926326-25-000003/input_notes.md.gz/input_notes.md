# OMCL notes — 0000926326-25-000003


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000926326-25-000003:notes:1]
Portions of the registrant’s definitive Proxy Statement for the 2025 Annual Meeting of Stockholders to be filed with the United States Securities and Exchange Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Form 10-K are incorporated by reference in Part III, Items 10-14 of this Form 10-K.


## cyd:CybersecurityRiskManagementPositionsOrCommitteesResponsibleTextBlock

[0000926326-25-000003:notes:2]
As part of its risk oversight function, the Audit Committee of the Company’s Board of Directors is primarily responsible for overseeing and reviewing the Company’s information security and technology risks, including cybersecurity. In this role, the Audit Committee monitors the prevention, detection, mitigation and remediation of cybersecurity incidents through the regular receipt of reports from management on the effectiveness of its cybersecurity programs. These reports include semi-annual cybersecurity updates from the Company’s Chief Information Officer and quarterly reports from the Company’s risk management personnel on the progress of the Company’s broader Enterprise Risk Management (“ERM”) risk mitigation activities. As part of the ERM process, the Audit Committee provides input on key risks for the Company to consider. The Board also provides quarterly input on its views regarding potential emerging risk areas for the Company. The Audit Committee then reports to the full Board on a quarterly basis regarding its oversight activities and the risk management activities of the Company. In addition, the full Board periodically participates in cybersecurity-related table-top exercises and receives incident reports from the SIRT (as defined herein) as significant matters may arise. 
The Company’s IT strategy and implementation is overseen by a dedicated Chief Information Officer with over 20 years of experience in the field, including previously serving a 17-year tenure, most recently as Vice President of Global IT, with a global technology leader of fiber optic subsystems and components. He holds a Bachelor of Science in Computer Science and Engineering from Andhra University in India and an MBA from the Indian School of Business.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000926326-25-000003:notes:3]
Enterprise Risk Management

[0000926326-25-000003:notes:4]
The Company utilizes a structured, biannual ERM process to identify, assess, and address material risks facing the Company, including cybersecurity risks, during which business leaders across the Company are surveyed about current and emerging risk areas. After the ERM survey is completed and risk areas are identified, the results are discussed with the relevant management personnel across the organization in the key risk areas, root causes are analyzed, risk mitigation plans are developed, and key risk indicators are utilized to monitor mitigation efforts. The Chief Information Officer works closely with the Company’s management team in all facets of its ERM risk mitigation activities related to cybersecurity and information security risks.

[0000926326-25-000003:notes:5]
Ongoing Mitigation Efforts

[0000926326-25-000003:notes:6]
The Company has implemented a number of security measures designed to protect its systems and data, including firewalls, antivirus and malware detection tools, patches, log monitors, routine back-ups, system audits, system hardening, penetration testing and privileged access session management. In addition, the Company has continued its efforts to migrate its platforms to cloud-based computing, which is designed to further strengthen its security posture. The Company has focused on its incident response procedures and retained a leading incident response provider. The Company has also recently strengthened its disaster recovery procedures. The Company’s solutions incorporate cybersecurity features that are routinely analyzed. In addition, the Company maintains insurance that responds to cyber-attacks, which coverage limit and cost is discussed and reviewed with the Audit Committee annually.

[0000926326-25-000003:notes:7]
The Company has what it believes are appropriate physical, technical, and administrative controls in place that are designed to protect customers’ data. The Company uses a three-pronged approach focused on further reducing exposure, raising greater security awareness, and further strengthening the Company’s cybersecurity defenses. This approach resulted in the Company further hardening its identity computing environments as part of its progress to a zero trust environment, heightened cybersecurity awareness efforts through increased comprehensive information security awareness training for employees on a quarterly basis, and the strengthening of the Company’s cybersecurity defenses through implementation of multifactor authentication for Privileged Access Management and Endpoint Detection and Response solutions across the Company’s computing environment.

[0000926326-25-000003:notes:8]
Incident Response

[0000926326-25-000003:notes:9]
In the event of a cybersecurity incident, dependent upon the nature of the incident, the Company has a Security Incident Response Team (“SIRT”) that is comprised of employees who have responsibility and authority to act during a cyber incident without delay, including, dependent upon the nature of the incident, the Company’s Chief Legal Officer, Chief Information Security Officer and Chief Information Officer. The SIRT includes individuals responsible for assessing, containing, and responding to incidents, as well as those responsible for assessing the business and legal impacts, reporting incidents as appropriate, communicating to internal and external stakeholders, and engaging with industry and government response partners to coordinate information and resource sharing when needed. During a cybersecurity incident, as warranted, the SIRT keeps the Company’s senior leadership and Board apprised of the response to the incident, any material operational or

[0000926326-25-000003:notes:10]
business impacts, and any material internal or external communications regarding the incident. The SIRT will also seek the input of the Company’s senior leadership and Board, as needed, when addressing a cybersecurity incident. Upon resolution of a cybersecurity incident, generally, the Audit Committee will review the incident, the impact and the mitigation efforts and remediation actions the Company will implement. The Audit Committee then monitors the completion of the remediation actions and mitigation efforts.

[0000926326-25-000003:notes:11]
Cybersecurity Leaders in Management

[0000926326-25-000003:notes:12]
The Company’s IT strategy and implementation is overseen by a dedicated Chief Information Officer with over 20 years of experience in the field, including previously serving a 17-year tenure, most recently as Vice President of Global IT, with a global technology leader of fiber optic subsystems and components. He holds a Bachelor of Science in Computer Science and Engineering from Andhra University in India and an MBA from the Indian School of Business. In addition, the Company has engaged a Chief Information Security Officer (“CISO”) that has built and managed world-class information security programs and technology teams for industry leading global companies. She has deep experience securing healthcare-focused companies in both the provider and supplier space. She holds a Bachelor of Science from the University of Redlands and an MBA from Notre Dame De Namur University along with holding certified information systems security professional (“CISSP”) and certified information security manager (“CISM”) certifications.

[0000926326-25-000003:notes:13]
Third Parties

[0000926326-25-000003:notes:14]
The Company utilizes third-party service providers, such as cloud services, in connection with its operations, and its information security department implements a third-party risk assessment and review process in connection with those services to evaluate security posture and risk. The Company also engages third parties to assist in its cybersecurity management efforts, such as the leading incident response provider mentioned above and another provider to perform continuous monitoring and regular penetration testing of its information security systems and environment. The Company and its personnel also actively engage with a number of other key vendors, industry participants and intelligence and law enforcement communities as part of its information security and cybersecurity efforts.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-25-000003:notes:15]
Organization and Summary of Significant Accounting Policies
Business

[0000926326-25-000003:notes:16]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products and related services are medication management solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States. “Omnicell” or the “Company” refer to Omnicell, Inc. and its subsidiaries, collectively.

[0000926326-25-000003:notes:17]
Basis of Presentation

[0000926326-25-000003:notes:18]
The accompanying Consolidated Financial Statements have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and include all adjustments necessary for the fair presentation of the Company’s consolidated financial position, results of operations, and cash flows for the periods presented.

[0000926326-25-000003:notes:19]
Principles of Consolidation

[0000926326-25-000003:notes:20]
The Consolidated Financial Statements include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000926326-25-000003:notes:21]
Use of Estimates

[0000926326-25-000003:notes:22]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Consolidated Financial Statements and accompanying Notes to Consolidated Financial Statements. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting estimates are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. Those estimates are revenue recognition, inventory valuation, and accounting for income taxes. As of December 31, 2024, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-25-000003:notes:23]
Segment Reporting

[0000926326-25-000003:notes:24]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company at the consolidated level using the Company’s consolidated net income. In addition, the CODM is provided with certain segment assets, primarily those that impact liquidity, as well as certain significant expenses. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment. Refer to Note 2, Segment Information, for further information regarding the Company’s segment disclosures.

[0000926326-25-000003:notes:25]
Foreign Currency Translation and Remeasurement

[0000926326-25-000003:notes:26]
Most of the Company’s foreign subsidiaries use the local currency of their respective countries as their functional currency. The Company translates the assets and liabilities of such non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recorded as foreign currency translation adjustments and included in accumulated other comprehensive income (loss) in stockholders’ equity.

[0000926326-25-000003:notes:27]
Assets and liabilities denominated in a currency other than the functional currency are remeasured into the respective entity’s functional currency. Monetary assets and liabilities are remeasured at exchange rates in effect at the end of each period, and non-monetary assets and liabilities are remeasured at historical rates. Gains and losses from foreign currency remeasurement of monetary assets and liabilities are recorded in interest and other income (expense), net.

[0000926326-25-000003:notes:28]
Revenue Recognition

[0000926326-25-000003:notes:29]
The Company earns revenues from sales of its products and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following revenue categories:

[0000926326-25-000003:notes:30]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements. Solutions in this category include, but are not limited to, XT Series automated dispensing systems and products related to the Central Pharmacy Dispensing Service and IV Compounding Service.

[0000926326-25-000003:notes:31]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, are designed to improve patient engagement and adherence to prescriptions.

[0000926326-25-000003:notes:32]
Technical services. Post-installation technical support and other related services (support and maintenance), including phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.

[0000926326-25-000003:notes:33]
Software as a Service (“SaaS”) and Expert Services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.

[0000926326-25-000003:notes:34]
The following table summarizes revenue recognition for each revenue category:

[0000926326-25-000003:notes:35]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to, or receipt by, customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| SaaS and Expert Services |  |  |  | Over time, as services are provided |  | Service |

[0000926326-25-000003:notes:36]
Prior to recognizing revenue, the Company identifies the contract, performance obligations, and transaction price, and allocates the transaction price to the performance obligations. All identified contracts meet the following required criteria:

[0000926326-25-000003:notes:37]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of the Company’s contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via our online portal, phone, or a purchase order.

[0000926326-25-000003:notes:38]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following the Company’s standard business process and terms.

[0000926326-25-000003:notes:39]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 to 60 days from shipment of tangible product or services performed for customers in the United States. Where a written contract does not exist, the Company’s standard payment terms are net 30 day terms.

[0000926326-25-000003:notes:40]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract). The Company’s agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.

[0000926326-25-000003:notes:41]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. The Company performs a credit check for all significant customers or

[0000926326-25-000003:notes:42]
transactions and where collectability is not probable, payment in full or a substantial down payment prior to shipment is typically required to help ensure the full agreed upon contract price will be collected.

[0000926326-25-000003:notes:43]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation. Where a good or service is determined not to be distinct, the Company combines the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify its performance obligations, the Company considers all products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, the Company considers an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Many of the Company’s sales contain multiple performance obligations, with a combination of hardware systems, software products, support and maintenance, and professional services.

[0000926326-25-000003:notes:44]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of the Company’s commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

[0000926326-25-000003:notes:45]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual technical services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated standalone selling price.

[0000926326-25-000003:notes:46]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service. Determining when control transfers requires management to make judgments that affect the timing of revenues recognized. Generally, for products requiring a complex implementation, control passes when the product is installed and functionally ready for use. For all other products, control generally passes when product has been shipped and title has passed. For support and maintenance contracts and certain other services, including SaaS and Expert Services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term. Time and material services transfer control to the customer at the time the services are provided.

[0000926326-25-000003:notes:47]
The portion of the transaction price allocated to the Company’s unsatisfied performance obligations for which invoicing has occurred is recorded as deferred revenues. Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, but services have not yet been provided. Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term technical and SaaS and Expert Services contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years.

[0000926326-25-000003:notes:48]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and SaaS and Expert Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $392.3 million as of December 31, 2024. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

[0000926326-25-000003:notes:49]
Revenues, contract assets, and contract liabilities are recorded net of associated taxes.

[0000926326-25-000003:notes:50]
The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time. SaaS and Expert Services agreements are generally invoiced periodically on a monthly, quarterly or annual basis over the life of the agreement. In certain circumstances portions of these agreements may be invoiced lump sum.

[0000926326-25-000003:notes:51]
The amount invoiced for equipment and software is typically reflected in both accounts receivable and deferred revenues. The Company typically recognizes product revenue, and correspondingly reduces deferred revenues, for equipment and on-premise software upon written customer acceptance of installation. Consumables are recorded as revenue upon shipment to or receipt by the customer, depending upon contract terms.

[0000926326-25-000003:notes:52]
From time to time, the Company enters into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. The Company’s change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

[0000926326-25-000003:notes:53]
In the normal course of business, the Company typically does not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. The Company establishes provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to the Consolidated Financial Statements for any periods presented.

[0000926326-25-000003:notes:54]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”), each of which functions as a purchasing agent on behalf of member hospitals and other healthcare providers. The Company also has a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”), allowing the Department of Veterans Affairs, the Department of Defense, and other federal government customers to purchase the Company’s products. Pursuant to the terms of GPO agreements and the GSA Contract, each member or agency contracts directly with Omnicell and can purchase the Company’s products at pre-negotiated contract terms and pricing. GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $9.6 million, $11.2 million, and $17.6 million for the years ended December 31, 2024, 2023, and 2022, respectively. The accounts receivable balances are with individual members of the GPOs and federal agencies that purchase under the GSA Contract, and therefore no significant concentration of credit risk exists. During the year ended December 31, 2024, sales to members of the ten largest GPOs and federal agencies that purchase under the GSA Contract accounted for approximately 65% of the Company’s total consolidated revenues.

[0000926326-25-000003:notes:55]
Contract Assets and Contract Liabilities

[0000926326-25-000003:notes:56]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditioned on something other than the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts, and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

[0000926326-25-000003:notes:57]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenues in the normal course of business. The contract modifications entered into during the year ended December 31, 2024 did not have a significant impact on the Company’s contract assets or deferred revenues.

[0000926326-25-000003:notes:58]
Contract Costs

[0000926326-25-000003:notes:59]
The Company has determined that certain incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of: (i) the value of new bookings for connected devices, software products, and SaaS and Expert Services, provided that for SaaS and Expert Services a commission will only be paid on the amount that represents the minimum commitment and (ii) the value of new orders for consumables. Since there are no commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods.

[0000926326-25-000003:notes:60]
The Company applies a practical expedient to account for the incremental costs of obtaining a contract as part of a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio. A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years.

[0000926326-25-000003:notes:61]
Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. In accordance with GAAP, while certain compensation elements are expensed as incurred, a portion of the pool’s capitalized asset is recorded as an expense over the first seven quarters after

[0000926326-25-000003:notes:62]
booking, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining capitalized contract costs are recorded as expense ratably over the ten year estimated initial and renewal service periods. The Company recognized contract cost expense of $19.1 million, $23.3 million, and $30.6 million during the years ended December 31, 2024, 2023, and 2022, respectively. The commission expenses paid or due to be paid as of the consolidated balance sheet date, to be recognized in future periods, are recorded in long-term prepaid commissions on the Consolidated Balance Sheets. Capitalized costs are periodically reviewed for impairment. There was no impairment loss recorded related to capitalized prepaid commissions as of and for the year ended December 31, 2024.

[0000926326-25-000003:notes:63]
Lessor Leases

[0000926326-25-000003:notes:64]
The Company determines if an arrangement is or contains a lease at inception. The transaction price is allocated to separate performance obligations, generally consisting of a combination of hardware systems, software products, support and maintenance, and professional services, proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual technical services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated standalone selling price.

[0000926326-25-000003:notes:65]
Sales-Type Leases

[0000926326-25-000003:notes:66]
The Company enters into non-cancelable sales-type lease arrangements with the leases varying in length from one to ten years, most of which do not have an option to extend the lease term. At the end of the lease term, the customer must either return the equipment or negotiate a new agreement, resulting in a new purchase or lease transaction. Failure of the customer to either return the equipment or negotiate a new agreement results in the contract becoming a month-to-month rental. Certain sales-type leases automatically renew for successive one-year periods at the end of each lease term without written notice from the customer. The Company’s sales-type lease agreements do not contain any material residual value guarantees.

[0000926326-25-000003:notes:67]
For sales-type leases, the Company recognizes revenues for its hardware and software products, net of lease execution costs, post-installation support and maintenance, professional services associated with SaaS and Expert Services offerings, and technical support, at the net present value of the lease payment stream upon customer acceptance. The Company recognizes service revenues associated with sales-type leases ratably over the term of the agreement in service revenues in the Consolidated Statements of Operations. The Company recognizes interest income from sales-type leases using the effective interest method. Both hardware and software revenues, and interest income from sales-types leases are recorded in product revenues in the Consolidated Statements of Operations.

[0000926326-25-000003:notes:68]
The Company optimizes cash flows by selling a majority of its sales-type leases, other than those relating to U.S. government hospitals and SaaS and Expert Services products, including Central Pharmacy Dispensing Service and IV Compounding Service, to third-party leasing finance companies on a non-recourse basis. The Company generally has no obligation to the leasing company once the lease has been sold.

[0000926326-25-000003:notes:69]
Allowance for Credit Losses

[0000926326-25-000003:notes:70]
The Company is exposed to credit losses primarily through sales of its products and services, as well as its sales-type leasing arrangements. The Company performs credit evaluations of its customers’ financial condition in order to assess each customer’s ability to pay. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, and a financial review of the customer. The Company continues to monitor customers’ creditworthiness on an ongoing basis.

[0000926326-25-000003:notes:71]
The Company maintains an allowance for credit losses for accounts receivable, unbilled receivables, and net investment in sales-type leases based on expected credit losses resulting from the inability of its customers to make required payments. The allowance for credit losses is measured using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. Actual collection losses may differ from management’s estimates, and such differences could be material to the Company’s financial position and results of operations.

[0000926326-25-000003:notes:72]
The allowance for credit losses is presented in the Consolidated Balance Sheets as a deduction from the respective asset balance. As of December 31, 2024 and 2023, the allowance for credit losses for long-term unbilled receivables and net investment in sales-type leases were not material.

[0000926326-25-000003:notes:73]
Funds Held for Customers and Customer Fund Liabilities

[0000926326-25-000003:notes:74]
The Company offers certain products and services in which it is customary for pharmacies or insurance payors to owe funds to the Company which are collected on behalf of, and, after a short holding period, disbursed to, the Company’s customers. The Company presents amounts due from pharmacies and amounts due to be disbursed to customers on a gross basis within other current assets and accrued liabilities, respectively, in the Consolidated Balance Sheets, as such amounts are expected to be settled within one year. Generally, any funds received from the pharmacies or insurance payors that are held by the Company are segregated from its other corporate cash accounts. These funds are classified as restricted cash as the Company is contractually obligated to disburse these amounts to customers.

[0000926326-25-000003:notes:75]
Sales of Accounts Receivable

[0000926326-25-000003:notes:76]
The Company records the sale of its accounts receivables in accordance with accounting guidance for transfers and servicing of financial assets. The Company transferred non-recourse accounts receivable totaling $17.3 million, $5.7 million, and $45.3 million during the years ended December 31, 2024, 2023, and 2022, respectively, which approximated fair value, to leasing companies on a non-recourse basis.

[0000926326-25-000003:notes:77]
Cash and Cash Equivalents

[0000926326-25-000003:notes:78]
The Company classifies all highly-liquid investments with original maturities of three months or less as cash equivalents. The Company’s cash and cash equivalent balances include bank accounts and highly-liquid U.S. Government money market funds held in sweep and asset management accounts with financial institutions of high credit quality. The Company continuously monitors the credit worthiness of the financial institutions in which it invests. The Company has not experienced any credit losses from its cash equivalents. Cash and cash equivalents were $369.2 million and $468.0 million as of December 31, 2024 and 2023, respectively. As of December 31, 2024 and 2023, cash equivalents were $328.0 million and $451.0 million, respectively, which consisted of money market funds held in sweep and asset management accounts. The Company recorded interest income on its cash and cash equivalents of $24.9 million, $18.8 million, and $3.5 million for the years ended December 31, 2024, 2023, and 2022, respectively, which is included within interest and other income (expense), net in the Consolidated Statements of Operations.

[0000926326-25-000003:notes:79]
Financial Instruments

[0000926326-25-000003:notes:80]
For assets and liabilities measured at fair value, the amounts are based on an expected exit price representing the amount that would be received from the sale of an asset or paid to transfer a liability in a transaction between market participants. The fair value may be based on assumptions that market participants would use in pricing an asset or liability. ASC 820, Fair Value Measurement, establishes a consistent framework for measuring fair value on either a recurring or nonrecurring basis whereby inputs used in valuation techniques are assigned a hierarchical level, as follows:

[0000926326-25-000003:notes:81]
Level 1 – Observable inputs, such as quoted prices in active markets for identical instruments;

[0000926326-25-000003:notes:82]
Level 2 – Quoted prices for similar instruments in active markets, or quoted prices for identical instruments in inactive markets; and

[0000926326-25-000003:notes:83]
Level 3 – Unobservable inputs for financial instruments reflecting Company’s assumptions.

[0000926326-25-000003:notes:84]
Inventory

[0000926326-25-000003:notes:85]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. The Company regularly monitors inventory quantities on hand and records write-downs for excess and obsolete inventories based on the Company’s estimate of demand for its products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Shipments from suppliers or contract manufacturers before the Company receives them are recorded as in-transit inventory when title and the significant risks and rewards of ownership have passed to the Company.

[0000926326-25-000003:notes:86]
The Company has a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in its hardware products. There are no minimum purchase requirements. The

[0000926326-25-000003:notes:87]
contract with the Company’s supplier may be terminated by either the supplier or by the Company without cause and at any time upon delivery of six months’ notice. Purchases from this supplier were $59.1 million, $65.8 million, and $105.7 million for the years ended December 31, 2024, 2023, and 2022, respectively.

[0000926326-25-000003:notes:88]
Shipping Costs

[0000926326-25-000003:notes:89]
Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general, and administrative expense. Shipping and handling expenses were $15.7 million, $18.6 million, and $24.5 million for the years ended December 31, 2024, 2023, and 2022, respectively.

[0000926326-25-000003:notes:90]
Property and Equipment

[0000926326-25-000003:notes:91]
Property and equipment less accumulated depreciation are stated at historical cost. The Company’s expenditures for property and equipment are primarily for computer equipment and software used in the administration of its business, and for leasehold improvements to its leased facilities. The Company also develops molds and dies used in long-term manufacturing arrangements with suppliers and for production automation equipment used in the manufacturing of consumable blister card components.

[0000926326-25-000003:notes:92]
The Company capitalizes costs related to computer software developed or obtained for internal-use in accordance with ASC 350-40, Internal-Use Software. Software developed or obtained for internal-use includes certain costs for the development of the Company’s subscription and cloud-based offerings sold to its customers, as well as enterprise-level business and finance software that the Company customizes to meet its specific operational needs. Costs incurred in the application development phase are capitalized and amortized over their useful lives, which is generally five years. Costs recognized in the preliminary project phase and the post-implementation phase are expensed as incurred. The Company capitalized $28.5 million and $32.2 million of costs related to the application development of enterprise-level software and its subscription and cloud-based offerings, which are included in property and equipment during the years ended December 31, 2024 and 2023, respectively. Capitalized costs related to computer software developed or obtained for internal-use are included in purchases of property and equipment in the Consolidated Statements of Cash Flows.

[0000926326-25-000003:notes:93]
Depreciation and amortization is computed by use of the straight-line method over the estimated useful lives of the assets as stated below:

[0000926326-25-000003:notes:94]
| Purchased software and internal-use software development costs | 3 - 5 years |
| Leasehold and building improvements | Shorter of the lease term or the estimated useful life |
| Furniture and fixtures | 5 - 7 years |
| Equipment | 2 - 12 years |

[0000926326-25-000003:notes:95]
External-Use Software Development Costs

[0000926326-25-000003:notes:96]
The Company capitalizes certain software development costs in accordance with ASC 985-20, Costs of Software to Be Sold, Leased, or Marketed, under which those costs incurred subsequent to the establishment of technological feasibility may be capitalized and amortized over the estimated lives of the related products. The Company establishes technological feasibility when it completes a detail program design or a working model. The Company amortizes development costs over the estimated lives of the related products, which is generally five years. All development costs prior to the completion of a detail program design or a working model are recognized as research and development expense. The Company capitalized external-use software development costs of $17.2 million and $14.6 million that were included in other long-term assets as of December 31, 2024 and 2023, respectively.

[0000926326-25-000003:notes:97]
Cloud Computing Costs

[0000926326-25-000003:notes:98]
The Company capitalizes certain costs associated with cloud computing arrangements that are associated with service contracts, which are amortized using the straight-line method over the term of the arrangement. As of December 31, 2024 and 2023, capitalized costs associated with cloud computing arrangements, net of accumulated amortization, were $5.0 million and $4.4 million, respectively.

[0000926326-25-000003:notes:99]
Lessee Leases

[0000926326-25-000003:notes:100]
The Company determines if an arrangement is or contains a lease at inception. Operating lease right-of-use assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. As most of its lease contracts do not provide an implicit rate, the Company uses its incremental borrowing rate based on information available at the commencement date in determining the present value of the lease payments. Lease expense is recognized on a straight-line basis over the lease term. The Company does not recognize a right-of-use asset and a lease liability for leases with

[0000926326-25-000003:notes:101]
an initial term of twelve months or less. The Company elected the practical expedient to not separate lease components from nonlease components and applied that practical expedient to all material classes of leased assets.

[0000926326-25-000003:notes:102]
Many of the Company’s operating leases include an option to extend the lease. The specific terms and conditions of the extension options vary from lease to lease, but are consistent with standard industry practices in each area that the Company operates. The Company reviews each of its lease options at a time required by the terms of the lease contract, and notifies the lessor if it chooses to exercise the lease renewal option. Until the Company is reasonably certain that it will extend the lease contract, the renewal option periods will not be recognized as right-of-use assets or lease liabilities.

[0000926326-25-000003:notes:103]
Certain leases include provisions for early termination, which allow the contract parties to terminate their obligations under the lease contract. The terms and conditions of the termination options vary by contract. When the Company has made a decision to exercise an early termination option, the right-of-use assets and associated lease liabilities are remeasured in accordance with the present value of the remaining cash flows under the lease contract.

[0000926326-25-000003:notes:104]
Certain building lease agreements include rental payments subject to change annually based on fluctuations in various indexes (i.e., Consumer Price Index (“CPI”), Retail Price Index, and other international indexes). Certain data center lease agreements include rental payments subject to change based on usage and CPI fluctuations. The changes based on usage and indexes are treated as variable lease costs and recognized in the period in which the obligation for those payments was incurred.

[0000926326-25-000003:notes:105]
The Company’s operating lease agreements do not contain any material residual value guarantees, restrictions, or restriction covenants.

[0000926326-25-000003:notes:106]
Goodwill and Acquired Intangible Assets

[0000926326-25-000003:notes:107]
Goodwill

[0000926326-25-000003:notes:108]
The Company assesses goodwill for impairment on an annual basis on the first day of the fourth quarter of each year at the reporting unit level. This assessment is also performed whenever there is a change in circumstances that indicates the carrying value of goodwill may be impaired. The Company has one reporting unit, which is the same as its operating segment. A qualitative assessment is initially made to determine whether it is necessary to perform quantitative testing. A qualitative assessment includes, among others, consideration of: (i) past, current, and projected future earnings and equity; (ii) recent trends and market conditions; and (iii) valuation metrics involving similar companies that are publicly-traded and acquisitions of similar companies, if available. If this qualitative assessment indicates that it is more likely than not that impairment exists, or if the Company decides to bypass this option, it proceeds to the quantitative assessment. The quantitative assessment involves a comparison between the estimated fair value of the Company’s reporting unit with its carrying amount including goodwill. If the carrying value exceeds estimated fair value, the Company will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill.

[0000926326-25-000003:notes:109]
To determine the reporting unit’s fair value under the quantitative approach, the Company uses a combination of income and market approaches, such as estimated discounted future cash flows of the reporting unit, multiples of earnings or revenues, and analysis of recent sales or offerings of comparable entities. The Company also considers its market capitalization on the date of the analysis to ensure the reasonableness of its reporting unit’s fair value.

[0000926326-25-000003:notes:110]
The Company elected to perform a quantitative impairment assessment as of October 1, 2024 for its reporting unit. The Company determined that the fair value of the reporting unit exceeded the carrying value and thus no impairment was indicated. Based on the result of this analysis, an impairment does not exist as of December 31, 2024, and there were no accumulated impairment losses.

[0000926326-25-000003:notes:111]
Intangible Assets

[0000926326-25-000003:notes:112]
In connection with its acquisitions, the Company generally recognizes assets for customer relationships, acquired technology, backlog, trade names, and non-compete agreements. Intangible assets are carried at cost less accumulated amortization. Such amortization is provided on a straight-line basis or on an accelerated basis based on a pattern of economic benefit that is expected to be obtained over the estimated useful lives of the respective assets. Amortization for acquired technology and backlog is recognized in cost of revenues, and amortization for customer relationships, trade names, non-compete agreements, and patents is recognized in selling, general, and administrative expenses.

[0000926326-25-000003:notes:113]
The Company assesses the impairment of identifiable intangible assets whenever events or changes in circumstances indicate that an asset’s carrying amount may not be recoverable. Recoverability of an asset is measured by the comparison of the carrying amount to the sum of the undiscounted estimated future cash flows the asset is expected to generate, offset by estimated future costs to dispose of the product to which the asset relates. If an asset is considered to be impaired, the amount of such impairment would be measured as the difference between the carrying amount of the asset and its fair value. The

[0000926326-25-000003:notes:114]
Company’s cash flow assumptions are based on historical and forecasted future revenue, operating costs, and other relevant factors. Assumptions and estimates about the remaining useful lives of the Company’s intangible assets are subjective and are affected by changes to its business strategies. If management’s estimates of future operating results change, or if there are changes to other assumptions, the estimate of the fair value of the Company’s assets could change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company’s operating results and financial condition. For the years ended December 31, 2024 and 2023, there were no events or changes in circumstances to indicate that intangible assets carrying amounts may not be recoverable.

[0000926326-25-000003:notes:115]
Convertible Debt

[0000926326-25-000003:notes:116]
The Company accounts for convertible debt and related transactions in accordance with ASC 470-20, Debt with Conversion and Other Options, ASC 815, Derivatives and Hedging, and ASC 480, Distinguishing Liabilities from Equity. The Company evaluates convertible debt instruments and related transactions at inception to determine if those contracts or embedded components of those contracts qualify as derivatives to be separately accounted for.

[0000926326-25-000003:notes:117]
The Company’s convertible senior notes are accounted for as a single liability at face value less unamortized debt issuance costs. Issuance costs are amortized using the effective interest method over the term of the convertible senior notes.

[0000926326-25-000003:notes:118]
Convertible note hedge and warrant transactions associated with convertible debt instruments are accounted for as equity instruments, and are recorded in additional paid-in capital in the Consolidated Balance Sheets.

[0000926326-25-000003:notes:119]
Valuation of Share-Based Compensation

[0000926326-25-000003:notes:120]
The Company accounts for share-based compensation in accordance with ASC 718, Stock Compensation. The Company recognizes compensation expense related to share-based compensation based on the grant date estimated fair value.

[0000926326-25-000003:notes:121]
The fair value of restricted stock units (“RSUs”) and restricted stock awards (“RSAs”) is based on the stock price on the grant date. The RSUs and RSAs are subject to a service vesting condition and are recognized on a straight-line basis over the requisite service period.

[0000926326-25-000003:notes:122]
The fair value of performance-based stock unit awards (“PSUs”) with service and market conditions is estimated using a Monte Carlo simulation model applying a multiple awards approach. Expense is recognized using the accelerated attribution method over the requisite service period.

[0000926326-25-000003:notes:123]
Forfeiture rates are estimated based on the Company’s historical experience with equity awards that were granted and forfeited prior to vesting. The valuation assumptions used in estimating the fair value of employee share-based awards may change in future periods.

[0000926326-25-000003:notes:124]
Accounting for Income Taxes

[0000926326-25-000003:notes:125]
The Company records an income tax provision for (benefit from) the anticipated tax consequences of the reported results of operations. In accordance with ASC 740, Income Taxes, the provision for (benefit from) income taxes is computed using the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the financial statements. Under this method, deferred tax assets and liabilities are determined on the basis of the differences between the financial statement and tax bases of assets and liabilities and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the enacted tax rates in effect for the periods in which those tax assets and liabilities are expected to be realized or settled. In the event that these tax rates change, the Company will incur a benefit or detriment on its income tax expense in the period of enactment. If the Company were to determine that all or part of the net deferred tax assets are not realizable in the future, it will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-25-000003:notes:126]
In accordance with ASC 740, the Company recognizes the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of ASC 740 and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on the Company’s financial condition and operating results.

[0000926326-25-000003:notes:127]
Recently Adopted Authoritative Guidance

[0000926326-25-000003:notes:128]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires public entities to disclose significant segment expenses that are regularly provided to the CODM. Public entities with a single reportable segment are required to apply the disclosure requirements in ASU 2023-07, as well as all existing segment disclosures and reconciliation requirements in ASC 280, Segment Reporting, on an interim and annual basis. The amendments are effective for the Company’s annual periods beginning January 1, 2024, and for interim periods within fiscal years beginning January 1, 2025. The Company adopted ASU 2023-07 for the annual period beginning January 1, 2024. The adoption of ASU 2023-07 did not have a material impact on the Company’s Consolidated Financial Statements, as the changes only include additional disclosures related to the Company’s single reportable segment. Refer to Note 2, Segment Information, for further information regarding the Company’s segment disclosures.

[0000926326-25-000003:notes:129]
There was no other recently adopted authoritative guidance that is expected to have a material impact on the Company’s Consolidated Financial Statements through the reporting date.

[0000926326-25-000003:notes:130]
Recently Issued Authoritative Guidance

[0000926326-25-000003:notes:131]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning January 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact of ASU 2023-09 will have on its consolidated financial statements, which is limited to financial statements disclosures.

[0000926326-25-000003:notes:132]
In March 2024, the SEC issued final rules under SEC Release No. 33-11275, “The Enhancement and Standardization of Climate-Related Disclosures for Investors,” to require registrants to disclose certain climate-related information, including Scope 1 and Scope 2 greenhouse gas emissions and other climate-related topics, if material, in registration statements and annual reports. In April 2024, the SEC voluntarily stayed its climate disclosure rules as a result of pending legal challenges to facilitate an orderly judicial resolution. The Company is currently evaluating the impact the SEC’s rule will have on its consolidated financial statements.

[0000926326-25-000003:notes:133]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosure (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosures of additional information and disaggregation of certain expenses included in the income statement. The amendments are effective for the Company’s annual periods beginning January 1, 2027, and for interim periods within fiscal years beginning January 1, 2028, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2024-03 will have on its consolidated financial statements.

[0000926326-25-000003:notes:134]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Consolidated Financial Statements through the reporting date.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000926326-25-000003:notes:135]
Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. In accordance with GAAP, while certain compensation elements are expensed as incurred, a portion of the pool’s capitalized asset is recorded as an expense over the first seven quarters after 
booking, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining capitalized contract costs are recorded as expense ratably over the ten year estimated initial and renewal service periods.Outbound freight billed to customers is recorded as product revenue. The related shipping and handling costs are expensed as part of selling, general, and administrative expense.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000926326-25-000003:notes:136]
The following table represents the property and equipment balances:

[0000926326-25-000003:notes:137]
|  | December 31, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| Equipment | $ | 99,728 |  |  | $ | 95,996 |  |
| Furniture and fixtures | 4,809 |  |  | 4,500 |  |
| Leasehold improvements | 17,722 |  |  | 17,919 |  |
| Purchased software and internal-use software development costs | 146,287 |  |  | 118,004 |  |
| Construction in progress | 12,539 |  |  | 11,614 |  |
| Property and equipment, gross | 281,085 |  |  | 248,033 |  |
| Accumulated depreciation and amortization | (168,393) |  |  | (139,432) |  |
| Total property and equipment, net | $ | 112,692 |  |  | $ | 108,601 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-25-000003:notes:138]
Segment Information 
The Company’s one reportable segment derives revenues from sales of its products and related services, as described in Note 1, Organization and Summary of Significant Accounting Policies, which are sold in its principal market, the healthcare industry. The accounting policies of the Company’s one reportable segment are the same as those described in the summary of significant accounting policies in Note 1.

[0000926326-25-000003:notes:139]
As the Company has a single reportable segment and is managed on a consolidated basis, the measure of segment profit or loss that the CODM uses to allocate resources and assess performance is consolidated net income as reported on the Consolidated Statements of Operations. The CODM uses this key measure to evaluate income generated from segment assets in deciding how to reinvest profits as well as monitor budget versus actual results.

[0000926326-25-000003:notes:140]
The CODM is also provided with certain segment assets, primarily those that impact liquidity, such as cash and cash equivalents, accounts receivable and inventories, as well as certain liabilities such as accounts payable and outstanding debt. Assets provided to the CODM are consistent with those reported on the Consolidated Balance Sheets. In addition, the CODM is regularly provided with significant expenses, which are adjusted cost of revenues and adjusted operating expenses. These significant expenses are adjusted for certain non-cash charges and expenses that are unrelated to the Company’s ongoing operations. Adjusted cost of revenues include cost of product revenues and cost of service and other revenues, and exclude certain items such as share-based compensation expense, amortization of acquired intangibles, and certain restructuring and severance charges. Adjusted operating expenses include research and development, and selling, general and administrative

[0000926326-25-000003:notes:141]
expenses, and exclude certain items such as share-based compensation expense, amortization of acquired intangibles, and certain restructuring, impairment and severance charges. Depreciation and amortization expense for the Company’s single reportable segment was $82.2 million, $87.3 million, and $86.9 million for the years ended December 31, 2024, 2023, and 2022, respectively.

[0000926326-25-000003:notes:142]
The following table summarizes the Company’s reportable segment revenues and significant expenses, reconciled to the Company’s consolidated net income (loss):

[0000926326-25-000003:notes:143]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Total revenues | $ | 1,112,238 |  |  | $ | 1,147,112 |  |  | $ | 1,295,947 |  |
| Less: |  |  |  |  |  |
| Adjusted cost of revenues | (620,834) |  |  | (627,730) |  |  | (675,451) |  |
| Adjusted operating expenses | (413,280) |  |  | (437,857) |  |  | (479,778) |  |
| Other segment items (1) | (77,787) |  |  | (116,393) |  |  | (143,041) |  |
| Interest and other income (expense), net | 25,256 |  |  | 14,760 |  |  | (130) |  |
| Provision for (benefit from) income taxes | 13,062 |  |  | 263 |  |  | (8,101) |  |
| Net Income (loss) | $ | 12,531 |  |  | $ | (20,371) |  |  | $ | 5,648 |  |

[0000926326-25-000003:notes:144]
_________________________________________________
(1)    Other segment items include certain non-cash charges and expenses that are unrelated to the Company’s ongoing operations. Such charges and expenses consist of items such as share-based compensation, amortization of acquired intangible assets, and certain restructuring, impairment and severance charges.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-25-000003:notes:145]
Revenues
Disaggregation of Revenues

[0000926326-25-000003:notes:146]
The following table summarizes the Company’s revenues disaggregated by revenue type:

[0000926326-25-000003:notes:147]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 539,168 |  |  | $ | 623,584 |  |  | $ | 827,917 |  |
| Consumables | 91,339 |  |  | 84,977 |  |  | 75,305 |  |
| Technical services | 238,211 |  |  | 225,831 |  |  | 206,687 |  |
| SaaS and Expert Services | 243,520 |  |  | 212,720 |  |  | 186,038 |  |
| Total revenues | $ | 1,112,238 |  |  | $ | 1,147,112 |  |  | $ | 1,295,947 |  |

[0000926326-25-000003:notes:148]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location:

[0000926326-25-000003:notes:149]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In thousands) |
| United States | $ | 1,012,373 |  | $ | 1,011,380 |  | $ | 1,168,202 |
| Rest of world | 99,865 |  | 135,732 |  | 127,745 |
| Total revenues | $ | 1,112,238 |  | $ | 1,147,112 |  | $ | 1,295,947 |

[0000926326-25-000003:notes:150]
The following table reflects the Company’s contract assets and contract liabilities:

[0000926326-25-000003:notes:151]
|  | December 31, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 32,917 |  |  | $ | 22,524 |  |
| Long-term unbilled receivables, net (2) | 7,873 |  |  | 11,850 |  |
| Total contract assets | $ | 40,790 |  |  | $ | 34,374 |  |
| Short-term deferred revenues | $ | 141,370 |  |  | $ | 121,734 |  |
| Long-term deferred revenues | 76,123 |  |  | 58,622 |  |
| Total contract liabilities | $ | 217,493 |  |  | $ | 180,356 |  |

[0000926326-25-000003:notes:152]
_________________________________________________

[0000926326-25-000003:notes:153]
(1)     Included in accounts receivable and unbilled receivables in the Consolidated Balance Sheets.

[0000926326-25-000003:notes:154]
(2)    Included in other long-term assets in the Consolidated Balance Sheets.

[0000926326-25-000003:notes:155]
Short-term deferred revenues of $121.7 million as of December 31, 2023 include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.4 million. During the year ended December 31, 2024, the Company recognized revenues of $116.9 million that were included in the corresponding gross short-term deferred revenues balance of $134.1 million as of December 31, 2023.

[0000926326-25-000003:notes:156]
Significant Customers

[0000926326-25-000003:notes:157]
There were no customers that accounted for more than 10% of the Company’s total revenues for the years ended December 31, 2024, 2023, and 2022. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable and unbilled receivables balance as of December 31, 2024 and 2023.


## us-gaap:EarningsPerShareTextBlock

[0000926326-25-000003:notes:158]
Net Income (Loss) Per Share
Basic net income (loss) per share is computed by dividing net income (loss) for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period, using the treasury stock method for share-based awards and warrants, and the if-converted method for convertible senior notes. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units, as well as shares the Company could be obligated to issue from its convertible senior notes and warrants, as described in Note 11, Convertible Senior Notes. In the event of the conversion of the Company’s convertible senior notes, the principal portion will be settled in cash with any conversion consideration in excess of the principal portion settled in cash and/or shares of the Company’s common stock at the Company’s option, therefore, only the amounts expected to be settled in excess of the principal portion are considered dilutive in calculating earnings per share under the if-converted method. Any anti-dilutive weighted-average dilutive shares related to stock award plans, convertible senior notes, and warrants are excluded from the computation of the diluted net income per share.

[0000926326-25-000003:notes:159]
The basic and diluted net income (loss) per share calculations were as follows:

[0000926326-25-000003:notes:160]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | 12,531 |  |  | $ | (20,371) |  |  | $ | 5,648 |  |
| Weighted-average shares outstanding – basic | 46,047 |  |  | 45,212 |  |  | 44,398 |  |
| Effect of dilutive securities from stock award plans | 208 |  |  | — |  |  | 1,019 |  |
| Effect of convertible senior notes | — |  |  | — |  |  | 474 |  |
| Weighted-average shares outstanding – diluted | 46,255 |  |  | 45,212 |  |  | 45,891 |  |
| Net income (loss) per share – basic | $ | 0.27 |  |  | $ | (0.45) |  |  | $ | 0.13 |  |
| Net income (loss) per share – diluted | $ | 0.27 |  |  | $ | (0.45) |  |  | $ | 0.12 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 2,793 |  |  | 3,368 |  |  | 725 |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | 9,622 |  |  | 11,816 |  |  | 5,908 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-25-000003:notes:161]
Fair Value of Financial Instruments
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s credit facility is classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company’s convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. Refer to Note 10, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 11, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.

[0000926326-25-000003:notes:162]
The following table summarizes the carrying amounts, net of unamortized debt issuance costs, and fair values of the convertible senior notes:

[0000926326-25-000003:notes:163]
|  | As of December 31, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| Net carrying amount: |  |  |  |
| 2025 Notes | 174,324 |  |  | 569,662 |  |
| 2029 Notes | 166,397 |  |  | — |  |
| Total net carrying amount | $ | 340,721 |  |  | $ | 569,662 |  |
| Fair value: |  |  |  |
| 2025 Notes | $ | 167,129 |  |  | $ | 527,206 |  |
| 2029 Notes | 181,320 |  |  | — |  |
| Total fair value | $ | 348,449 |  |  | $ | 527,206 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-25-000003:notes:164]
Balance Sheet Components
Balance sheet details are presented in the tables below:

[0000926326-25-000003:notes:165]
|  | December 31, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 33,501 |  |  | $ | 51,439 |  |
| Work in process | 1,515 |  |  | 1,327 |  |
| Finished goods | 53,643 |  |  | 57,333 |  |
| Total inventories | $ | 88,659 |  |  | $ | 110,099 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 47,846 |  |  | $ | 43,649 |  |
| Net investment in sales-type leases, current portion | 12,475 |  |  | 11,867 |  |
| Prepaid income taxes | 1,334 |  |  | 8,279 |  |
| Other current assets (2) | 13,638 |  |  | 7,714 |  |
| Total other current assets | $ | 75,293 |  |  | $ | 71,509 |  |
| Other long-term assets: |  |  |  |
| External-use software development costs, net | $ | 58,436 |  |  | $ | 66,659 |  |
| Unbilled receivables, net | 7,873 |  |  | 11,850 |  |
| Deferred debt issuance costs | 2,940 |  |  | 3,718 |  |
| Other long-term assets | 10,057 |  |  | 8,239 |  |
| Total other long-term assets | $ | 79,306 |  |  | $ | 90,466 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 10,702 |  |  | $ | 10,518 |  |
| Customer fund liabilities | 47,846 |  |  | 43,649 |  |
| Advance payments from customers | 12,760 |  |  | 10,551 |  |
| Rebate liabilities | 49,300 |  |  | 51,277 |  |
| Group purchasing organization fees | 5,167 |  |  | 4,445 |  |
| Taxes payable | 11,443 |  |  | 2,191 |  |
| Other accrued liabilities | 30,677 |  |  | 26,645 |  |
| Total accrued liabilities | $ | 167,895 |  |  | $ | 149,276 |  |

[0000926326-25-000003:notes:166]
(1)    Includes restricted cash of $29.4 million and $33.0 million as of December 31, 2024 and 2023, respectively.

[0000926326-25-000003:notes:167]
(2)    Includes deferred cost of sales of $8.7 million as of December 31, 2024.

[0000926326-25-000003:notes:168]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss), which consisted of foreign currency translation adjustments:

[0000926326-25-000003:notes:169]
|  | (In thousands) |  |
| Balance as of December 31, 2022 | $ | (17,087) |  |  |  |  |  |  |
| Other comprehensive income | 3,655 |  |  |  |  |  |  |
| Balance as of December 31, 2023 | (13,432) |  |  |  |  |  |  |
| Other comprehensive loss | (3,763) |  |  |  |  |  |  |
| Balance as of December 31, 2024 | $ | (17,195) |  |  |  |  |  |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-25-000003:notes:170]
Property and Equipment
The following table represents the property and equipment balances:

[0000926326-25-000003:notes:171]
Depreciation and amortization expense of property and equipment was $34.5 million, $27.0 million, and $22.8 million for the years ended December 31, 2024, 2023, and 2022, respectively.

[0000926326-25-000003:notes:172]
The geographic location of the Company’s property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net:

[0000926326-25-000003:notes:173]
|  | December 31, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| United States | $ | 109,534 |  |  | $ | 104,312 |  |
| Rest of world | 3,158 |  |  | 4,289 |  |
| Total property and equipment, net | $ | 112,692 |  |  | $ | 108,601 |  |


## omcl:CapitalizedComputerSoftwareDisclosureTextBlock

[0000926326-25-000003:notes:174]
External-Use Software Development Costs 
The carrying amounts of external-use software development costs were as follows:

[0000926326-25-000003:notes:175]
|  | December 31, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| Gross carrying amount | $ | 249,335 |  |  | $ | 239,038 |  |
| Accumulated amortization | (190,899) |  |  | (172,379) |  |
| External-use software development costs, net (1) | $ | 58,436 |  |  | $ | 66,659 |  |

[0000926326-25-000003:notes:176]
(1)     Included in other long-term assets in the Consolidated Balance Sheets.

[0000926326-25-000003:notes:177]
The Company recorded $24.9 million, $28.7 million, and $29.0 million to cost of product revenues for amortization of external-use software development costs for the years ended December 31, 2024, 2023, and 2022, respectively.

[0000926326-25-000003:notes:178]
The estimated future amortization expenses for external-use software development costs were as follows:

[0000926326-25-000003:notes:179]
|  | December 31, 2024 |
|  | (In thousands) |
| 2025 | $ | 21,139 |  |
| 2026 | 16,214 |  |
| 2027 | 10,281 |  |
| 2028 | 6,424 |  |
| 2029 | 3,797 |  |
| Thereafter | 581 |  |
| Total | $ | 58,436 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-25-000003:notes:180]
Goodwill and Intangible Assets
Goodwill

[0000926326-25-000003:notes:181]
The following table represents changes in the carrying amount of goodwill:

[0000926326-25-000003:notes:182]
|  |  |  |  |  | (In thousands) |
| Balance as of December 31, 2022 |  |  |  |  | $ | 734,274 |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | 1,536 |  |
| Balance as of December 31, 2023 |  |  |  |  | 735,810 |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | (1,083) |  |
| Balance as of December 31, 2024 |  |  |  |  | $ | 734,727 |  |

[0000926326-25-000003:notes:183]
Intangible Assets, Net

[0000926326-25-000003:notes:184]
The carrying amounts and useful lives of intangible assets were as follows:

[0000926326-25-000003:notes:185]
|  | December 31, 2024 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 307,418 |  |  | $ | (133,111) |  |  | $ | (1,373) |  |  | $ | 172,934 |  |  | 4 - 30 |
| Acquired technology | 46,134 |  |  | (32,421) |  |  | — |  |  | 13,713 |  |  | 4 - 20 |
| Trade names | 2,400 |  |  | (1,580) |  |  | — |  |  | 820 |  |  | 5 |
| Patents | 2,291 |  |  | (1,492) |  |  | — |  |  | 799 |  |  | 2 - 20 |
| Total intangible assets, net | $ | 358,243 |  |  | $ | (168,604) |  |  | $ | (1,373) |  |  | $ | 188,266 |  |  |  |

[0000926326-25-000003:notes:186]
(1)    The differences in gross carrying amounts between periods are primarily due to the write-off of certain fully amortized intangible assets.

[0000926326-25-000003:notes:187]
|  | December 31, 2023 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 307,418 |  |  | $ | (115,232) |  |  | $ | (1,326) |  |  | $ | 190,860 |  |  | 4 - 30 |
| Acquired technology | 84,876 |  |  | (67,033) |  |  | — |  |  | 17,843 |  |  | 4 - 20 |
| Backlog | 1,800 |  |  | (1,800) |  |  | — |  |  | — |  |  | 2 |
| Trade names | 9,200 |  |  | (7,680) |  |  | — |  |  | 1,520 |  |  | 5 - 12 |
| Patents | 2,404 |  |  | (1,454) |  |  | — |  |  | 950 |  |  | 2 - 20 |
| Total intangible assets, net | $ | 405,698 |  |  | $ | (193,199) |  |  | $ | (1,326) |  |  | $ | 211,173 |  |  |  |

[0000926326-25-000003:notes:188]
Amortization expense of intangible assets was $22.8 million, $31.6 million, and $35.2 million for the years ended December 31, 2024, 2023, and 2022, respectively.

[0000926326-25-000003:notes:189]
The estimated future amortization expenses for amortizable intangible assets were as follows:

[0000926326-25-000003:notes:190]
|  | December 31,2024 |
|  | (In thousands) |
| 2025 | $ | 20,999 |  |
| 2026 | 18,068 |  |
| 2027 | 16,218 |  |
| 2028 | 15,183 |  |
| 2029 | 11,490 |  |
| Thereafter | 106,308 |  |
| Total | $ | 188,266 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-25-000003:notes:191]
Debt and Credit Agreement 
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. As referred to herein, “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023, to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 11, Convertible Senior Notes), expand the Company’s flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-25-000003:notes:192]
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-25-000003:notes:193]
Loans under the Current Revolving Credit Facility bear interest, at Omnicell, Inc.’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility Omnicell, Inc. is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

[0000926326-25-000003:notes:194]
The Second A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Second A&R Credit Agreement contains financial covenants that require the Company to not exceed a maximum consolidated secured net leverage ratio (not to exceed 3.00:1) and maintain a minimum consolidated interest coverage ratio (not to be less than 3.00:1). In addition, the Second A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.

[0000926326-25-000003:notes:195]
Omnicell, Inc.’s obligations under the Second A&R Credit Agreement and, at the election of Omnicell, Inc. and the contracting counterparty, any secured swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the Second A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, Omnicell, Inc. and certain of Omnicell, Inc.’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement.

[0000926326-25-000003:notes:196]
The refinancing of the Prior Credit Agreement on October 10, 2023 was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the Second A&R Credit Agreement. The Company incurred and capitalized an additional $3.0 million of debt issuance costs, which are being amortized to interest expense using the straight-line method through 2028.

[0000926326-25-000003:notes:197]
On November 18, 2024, Omnicell, Inc., as borrower, entered into a First Amendment to Second Amended and Restated Credit Agreement (the “Amendment”) with the lenders party thereto from time to time, and Wells Fargo Bank, National Association, as administrative agent for the lenders. Pursuant to the Amendment, effective as of November 19, 2025, the springing maturity for the revolving credit facility that is tied to the outstanding principal amount of Omnicell, Inc.’s existing 0.25% Convertible Senior Notes due 2025 (the “2025 Notes”) will apply only if more than $200 million in the aggregate principal amount of Omnicell, Inc.’s 2025 Notes remain outstanding as of 91 days prior to the maturity date of the 2025 Notes.

[0000926326-25-000003:notes:198]
As of both December 31, 2024 and December 31, 2023, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of December 31, 2024 and 2023, the Company had no outstanding balance under the Prior or Current Revolving Credit Facility. The Company was in compliance with all covenants as of December 31, 2024. 
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-25-000003:notes:199]
On September 25, 2020, Omnicell, Inc. completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “2025 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the 2025 Notes. As referred to herein, “Omnicell, Inc.” or the “Company” refers only to Omnicell, Inc., excluding its subsidiaries. Omnicell, Inc. received proceeds from the issuance of the 2025 Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The 2025 Notes bear interest at a rate

[0000926326-25-000003:notes:200]
of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The 2025 Notes were issued pursuant to an indenture, dated September 25, 2020 (the “2025 Notes Indenture”), between the Company and U.S. Bank National Association, as trustee. The 2025 Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

[0000926326-25-000003:notes:201]
The 2025 Notes are convertible at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2025 Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the 2025 Notes Indenture) per $1,000 principal amount of the 2025 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the 2025 Notes on each such trading day; (iii) if the Company calls such 2025 Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the 2025 Notes called (or deemed called) for redemption; or (iv) upon the occurrence of specified corporate events, as specified in the 2025 Notes Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the 2025 Notes may convert all or any portion of their 2025 Notes at any time, regardless of the foregoing conditions.

[0000926326-25-000003:notes:202]
During the three months ended December 31, 2024 and 2023, none of the conditional conversion features of the 2025 Notes were triggered, and therefore, the 2025 Notes are not convertible during the first quarter of 2025, commencing on January 1, 2025, and were not convertible during the first quarter of 2024, commencing on January 1, 2024. Accordingly, the Company classified the 2025 Notes as a long-term liability in its Consolidated Financial Statements as of December 31, 2023. As the 2025 Notes will mature on September 15, 2025, the Company classified the 2025 Notes as a current liability in its Consolidated Financial Statements as of December 31, 2024.

[0000926326-25-000003:notes:203]
Under the original terms of the 2025 Notes Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the 2025 Notes Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of 2025 Notes of at least $1,000. As a result, for 2025 Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of 2025 Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of 2025 Notes above $1,000. The initial conversion rate for the 2025 Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of 2025 Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the 2025 Notes Indenture. In addition, following certain corporate events that could occur prior to the maturity date of the 2025 Notes or if the Company delivers a notice of redemption in respect of the 2025 Notes, the Company will, under certain circumstances, increase the conversion rate of the 2025 Notes for a holder who elects to convert its 2025 Notes (or any portion thereof) in connection with such a corporate event or convert its 2025 Notes called (or deemed called) for redemption during the related redemption period (as defined in the 2025 Notes Indenture), as the case may be.

[0000926326-25-000003:notes:204]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2025 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2025 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of December 31, 2024, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-25-000003:notes:205]
As of December 31, 2024, the Company may redeem for cash all or any portion of the 2025 Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the 2025 Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2025 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding 2025 Notes, at least $150.0 million aggregate principal amount of the 2025 Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the 2025 Notes.

[0000926326-25-000003:notes:206]
Partial Repurchase of the 2025 Notes

[0000926326-25-000003:notes:207]
In November 2024, the Company entered into separate, privately negotiated transactions with certain holders of the 2025 Notes to repurchase $400.0 million of aggregate principal amount of the 2025 Notes for approximately $391.0 million of cash. The Company accounted for the partial repurchase of 2025 Notes as a debt extinguishment and recorded a $7.2 million gain on extinguishment, which included a partial write-off of previously deferred debt issuance costs of $1.8 million, which is included within interest and other income (expense), net in the Consolidated Statements of Operations.

[0000926326-25-000003:notes:208]
The debt issuance costs associated with the remaining 2025 Notes are being amortized to interest expense over the term of the 2025 Notes using an effective interest rate of 0.80%. As of December 31, 2024, the remaining life of the 2025 Notes and the related issuance cost accretion is approximately 0.7 years.

[0000926326-25-000003:notes:209]
Following the partial repurchase of the 2025 Notes, the maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 1.8 million shares. As of December 31, 2024, the if-converted value of the 2025 Notes did not exceed the principal amount.

[0000926326-25-000003:notes:210]
1.00% Convertible Senior Notes due 2029

[0000926326-25-000003:notes:211]
On November 22, 2024, Omnicell, Inc. completed a private offering of $172.5 million aggregate principal amount of 1.00% Convertible Senior Notes due 2029 (the “2029 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $22.5 million aggregate principal amount of the 2029 Notes. Omnicell, Inc. received proceeds from the issuance of the 2029 Notes of $166.3 million, net of $6.2 million of transaction fees and other debt issuance costs. The 2029 Notes bear interest at a rate of 1.00% per year, payable semiannually in arrears on June 1 and December 1 of each year, beginning on June 1, 2025. The 2029 Notes were issued pursuant to an indenture, dated November 22, 2024 (the “2029 Notes Indenture”), between the Company and U.S. Bank Trust Company, National Association, as trustee. The 2029 Notes are general senior, unsecured obligations of the Company and will mature on December 1, 2029, unless earlier redeemed, purchased, or converted.

[0000926326-25-000003:notes:212]
The 2029 Notes are convertible at any time prior to the close of business on the business day immediately preceding August 1, 2029, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ending on March 31, 2025 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2029 Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the “trading price” (as defined in the 2029 Notes Indenture) per $1,000 principal amount of the 2029 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the 2029 Notes on each such trading day; (iii) if the Company calls such 2029 Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the 2029 Notes called (or deemed called) for redemption; or (iv) upon the occurrence of specified corporate events as set forth in the 2029 Notes Indenture. On or after August 1, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the 2029 Notes may convert all or any portion of their 2029 Notes at any time, regardless of the foregoing conditions. During the year ended December 31, 2024, none of the conditional conversion features of the 2029 Notes were triggered, and therefore, the 2029 Notes are not convertible during the first quarter of 2025.

[0000926326-25-000003:notes:213]
Upon conversion, the Company will pay cash up to the aggregate principal amount of the 2029 Notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination of cash and shares of the Company’s common stock, at the Company’s election, in respect to the remainder, if any, of the Company’s conversion obligation in excess of the aggregate principal amount of the 2029 Notes being converted, in the manner and subject to the terms and conditions provided in the 2029 Notes Indenture.

[0000926326-25-000003:notes:214]
The initial conversion rate for the 2029 Notes is 17.4662 shares of the Company’s common stock per $1,000 principal amount of the 2029 Notes, which is equivalent to an initial conversion price of approximately $57.25 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the 2029 Notes Indenture. In addition, following certain corporate events that occur prior to the maturity date of the 2029 Notes or if the Company delivers a notice of redemption in respect of the 2029 Notes, the Company will, under certain circumstances, increase the conversion rate of the 2029 Notes for a holder who elects to convert its 2029 Notes (or any portion thereof) in connection with such a corporate event or convert its 2029 Notes called (or deemed called) for redemption during the related redemption period (as defined in the 2029 Notes Indenture), as the case may be.

[0000926326-25-000003:notes:215]
If the Company undergoes a fundamental change (as defined in the 2029 Notes Indenture), holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2029 Notes at a fundamental

[0000926326-25-000003:notes:216]
change repurchase price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of December 31, 2024, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-25-000003:notes:217]
The Company may not redeem the 2029 Notes prior to December 6, 2027. The Company may redeem for cash all or any portion of the 2029 Notes, at its option, on or after December 6, 2027, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the 2029 Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. The Company may not redeem less than all of the outstanding 2029 Notes unless at least $100.0 million aggregate principal amount of 2029 Notes are outstanding and not called for redemption as of the time the Company sends the related notice of redemption. No sinking fund is provided for in the 2029 Notes.

[0000926326-25-000003:notes:218]
The debt issuance costs associated with the 2029 Notes are being amortized to interest expense over the term of the 2029 Notes using an effective interest rate of 1.75%. As of December 31, 2024, the remaining life of the 2029 Notes and the related issuance cost accretion is approximately 4.9 years.

[0000926326-25-000003:notes:219]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 3.0 million shares. As of December 31, 2024, the if-converted value of the 2029 Notes did not exceed the principal amount.

[0000926326-25-000003:notes:220]
The 2025 Notes and the 2029 Notes consisted of the following balances:

[0000926326-25-000003:notes:221]
|  | December 31, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| 2025 Notes: |  |  |  |
| Principal amount | $ | 175,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (676) |  |  | (5,338) |  |
| Convertible senior notes, net (1) | $ | 174,324 |  |  | $ | 569,662 |  |
| 2029 Notes: |  |  |  |
| Principal amount | $ | 172,500 |  |  | $ | — |  |
| Unamortized debt issuance costs | (6,103) |  |  | — |  |
| Convertible senior notes, net, noncurrent | $ | 166,397 |  |  | $ | — |  |

[0000926326-25-000003:notes:222]
(1)    Classified as a current liability as of December 31, 2024 and a long-term liability as of December 31, 2023 in the Consolidated Balance Sheets.

[0000926326-25-000003:notes:223]
The following table summarizes the components of interest expense resulting from the 2025 Notes and the 2029 Notes recognized in interest and other income (expense), net in the Consolidated Statements of Operations:

[0000926326-25-000003:notes:224]
|  | Year Ended December 31, |  |  |
|  | 2024 |  | 2023 |  | 2022 |  |  |
|  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 1,332 |  |  | $ | 1,438 |  |  | $ | 1,438 |  |  |  |
| 2029 Notes | $ | 182 |  |  | $ | — |  |  | $ | — |  |  |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes | $ | 2,886 |  |  | $ | 3,091 |  |  | $ | 3,066 |  |  |  |
| 2029 Notes | $ | 125 |  |  | $ | — |  |  | $ | — |  |  |  |

[0000926326-25-000003:notes:225]
Convertible Note Hedge and Warrant Transactions

[0000926326-25-000003:notes:226]
In connection with the issuance of the 2025 Notes in September 2020 and the 2029 Notes in November 2024, the Company entered into convertible note hedges and warrants transactions, respectively, with certain initial purchasers of the 2025 Notes and the 2029 Notes or affiliates thereof and certain other financial institutions (the “option counterparties”).

[0000926326-25-000003:notes:227]
The convertible note hedges related to the 2025 Notes consisted of call options for the Company to purchase, subject to anti-dilution adjustments substantially similar to those applicable to the 2025 Notes, up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2025 Notes at the time of its issuance, at an initial strike price of approximately $97.32 per share. The convertible note hedges related to the 2029 Notes consisted of call options for the Company to purchase up to, subject to anti-dilution adjustments substantially similar to those applicable to the 2029 Notes, approximately 3.0 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2029 Notes at the time of its issuance, at an initial strike price of approximately $57.25 per share. The convertible note hedges will expire upon the maturity of the respective convertible notes, if not earlier exercised or terminated. The cost of the convertible note hedges related to the 2025 Notes and the 2029 Notes was approximately $100.6 million and $40.3 million, respectively, and each was accounted for as an equity instrument, each of which was recorded in additional paid-in capital in the Consolidated Balance Sheets. In addition, the Company recorded a deferred tax asset of $25.8 million and $10.2 million, respectively, at issuance related to the convertible note hedges for the 2025 Notes and the 2029 Notes. The convertible note hedges are expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of the 2025 Notes or the 2029 Notes and/or offset any cash payments the Company may be required to make in excess of the principal amount of the converted 2025 Notes or the 2029 Notes.

[0000926326-25-000003:notes:228]
Separately from the convertible note hedges, in September 2020 and November 2024, the Company entered into warrant transactions to sell to the respective option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock at an initial strike price of approximately $141.56 and approximately 3.0 million shares of its common stock at an initial strike price of approximately $84.82 per share related to the 2025 Notes and the 2029 Notes, respectively. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million and $25.2 million for the issuance of the warrants related to the 2025 Notes and the 2029 Notes, respectively, which was recorded in additional paid-in capital at issuance in the Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock, as measured under the warrants, exceeds the strike price of the warrants.
In November 2024, in connection with the partial repurchase of the 2025 Notes, the Company entered into unwind agreements with the existing option counterparties to the convertible note hedges and warrants related to the 2025 Notes to terminate a portion of the existing convertible note hedges and warrants related to the 2025 Notes at a notional amount corresponding to the amount of the 2025 Notes repurchased, resulting in an immaterial gain.


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000926326-25-000003:notes:229]
Lessor Leases
Sales-Type Leases

[0000926326-25-000003:notes:230]
The following table presents the Company’s income recognized from sales-type leases:

[0000926326-25-000003:notes:231]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 31,624 |  |  | $ | 36,208 |  |  | $ | 38,959 |  |
| Cost of sales-type lease revenues | (18,518) |  |  | (18,093) |  |  | (19,359) |  |
| Selling profit on sales-type lease revenues | $ | 13,106 |  |  | $ | 18,115 |  |  | $ | 19,600 |  |

[0000926326-25-000003:notes:232]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components:

[0000926326-25-000003:notes:233]
|  | December 31, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 77,976 |  |  | $ | 65,017 |  |
| Less: Unearned interest income portion | (12,757) |  |  | (10,196) |  |
| Net investment in sales-type leases | 65,219 |  |  | 54,821 |  |
| Less: Current portion (1) | (12,475) |  |  | (11,867) |  |
| Long-term investment in sales-type leases, net | $ | 52,744 |  |  | $ | 42,954 |  |

[0000926326-25-000003:notes:234]
(1)    The current portion of the net investment in sales-type leases is included in other current assets in the Consolidated Balance Sheets.

[0000926326-25-000003:notes:235]
The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value.

[0000926326-25-000003:notes:236]
The maturity schedule of future minimum lease payments under sales-type leases retained in-house and the reconciliation to the net investment in sales-type leases reported on the Consolidated Balance Sheets was as follows:

[0000926326-25-000003:notes:237]
|  | December 31,2024 |
|  | (In thousands) |
| 2025 | $ | 15,540 |  |
| 2026 | 14,201 |  |
| 2027 | 12,652 |  |
| 2028 | 11,525 |  |
| 2029 | 8,917 |  |
| Thereafter | 15,141 |  |
| Total future minimum sales-type lease payments | 77,976 |  |
| Present value adjustment | (12,757) |  |
| Total net investment in sales-type leases | $ | 65,219 |  |

[0000926326-25-000003:notes:238]
Operating Leases

[0000926326-25-000003:notes:239]
The following table represents the Company’s income recognized from operating leases:

[0000926326-25-000003:notes:240]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Rental income | $ | 3,649 |  |  | $ | 6,591 |  |  | $ | 9,460 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-25-000003:notes:241]
Lessee Leases
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to twelve years. As of December 31, 2024, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-25-000003:notes:242]
The maturity schedule of future minimum lease payments under operating leases and the reconciliation to the operating lease liabilities reported on the Consolidated Balance Sheets was as follows:

[0000926326-25-000003:notes:243]
|  | December 31, 2024 |
|  | (In thousands) |
| 2025 | $ | 12,787 |  |
| 2026 | 12,050 |  |
| 2027 | 10,077 |  |
| 2028 | 8,625 |  |
| 2029 | 1,881 |  |
| Thereafter | 1,532 |  |
| Total operating lease payments | 46,952 |  |
| Present value adjustment | (5,127) |  |
| Total operating lease liabilities (1) | $ | 41,825 |  |

[0000926326-25-000003:notes:244]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $10.7 million and $31.1 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Consolidated Balance Sheets.

[0000926326-25-000003:notes:245]
Operating lease costs were $10.3 million, $10.8 million, and $18.9 million for the years ended December 31, 2024, 2023, and 2022, respectively. Short-term lease costs and variable lease costs were not material for the years ended December 31, 2024, 2023, and 2022. During the year ended December 31, 2023, the Company recorded impairment and abandonment charges to operating lease right-of-use assets of $10.0 million, in connection with restructuring activities to reduce its real estate footprint and for optimization of certain leased facilities. The impairment and abandonment charges were recorded to selling, general, and administrative expenses on the Company’s Consolidated Statements of Operations. Refer to Note 18, Restructuring Expenses, for additional information regarding the Company’s restructuring activities.

[0000926326-25-000003:notes:246]
The following table summarizes supplemental cash flow information related to the Company’s operating leases:

[0000926326-25-000003:notes:247]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 13,193 |  |  | $ | 13,469 |  |  | $ | 16,452 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 9,002 |  |  | $ | 6,431 |  |  | $ | 12,372 |  |

[0000926326-25-000003:notes:248]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases:

[0000926326-25-000003:notes:249]
|  | December 31, |
|  | 2024 |  | 2023 |
| Weighted-average remaining lease term, years | 4.1 |  | 4.6 |
| Weighted-average discount rate, % | 5.8 | % |  | 5.8 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-25-000003:notes:250]
Commitments and Contingencies
Purchase Obligations

[0000926326-25-000003:notes:251]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of December 31, 2024, the Company had non-cancelable purchase commitments of $118.8 million, of which $109.3 million are expected to be paid within the next twelve months.

[0000926326-25-000003:notes:252]
Legal Proceedings

[0000926326-25-000003:notes:253]
The Company is currently involved in various legal proceedings.

[0000926326-25-000003:notes:254]
In December 2023, Omnicell received a civil request for records issued by the U.S. Attorney’s Office for the Eastern District of Washington (the “Government”) related to the Company’s compliance with the pricing terms and conditions of its Federal Supply Schedule (“FSS”) contract with the federal government. In December 2024, the Government presented information identifying certain potential non-compliances with the FSS and associated potential violations of the False Claims Act. Omnicell is engaging in substantive defensive and settlement discussions with the Government regarding the concerns identified. At the time of this filing, those settlement discussions remain ongoing. For any future settlement to be effected, all parties will need to agree on acceptable terms, both monetary and non-monetary.

[0000926326-25-000003:notes:255]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the matter described above or any other current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters either cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.

[0000926326-25-000003:notes:256]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company’s business or operations.

[0000926326-25-000003:notes:257]
Guarantees

[0000926326-25-000003:notes:258]
Under the Company’s certificate of incorporation and bylaws, the Company has agreed to indemnify its directors and executive officers to the fullest extent not prohibited by Delaware and other applicable law, subject to certain exceptions. The Company has entered into individual indemnification agreements with its directors and officers. The term of the indemnification period is for the entirety of the director’s or officer’s service to the Company and continues so long as the director or officer may be subject to any claim, action, or proceeding, and there is no limit on the potential amount of future payments that the Company could be required to make under these indemnification agreements. The Company has purchased a directors’ and officers’ liability insurance policy that may enable it to recover a portion of any future payments that it may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits, and other policy provisions, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability, or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-25-000003:notes:259]
Additionally, the Company undertakes indemnification obligations in its ordinary course of business in connection with, among other things, the sale or licensing of its products and the provision of its support services. In the ordinary course of the Company’s business, the Company has in the past and may in the future agree to indemnify another party, generally its business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, its gross negligence or intentional acts in the performance of services, and violations of laws. The term of these indemnification obligations is generally perpetual, but typically will not extend beyond the applicable statute of limitation pursuant to applicable law. In general, the Company attempts to limit the maximum potential amount of future payments that it may be required to make under these indemnification obligations to the amounts paid to it by a customer, but in some cases the obligation may not be so limited.

[0000926326-25-000003:notes:260]
In addition, the Company has in the past and may in the future warrant to its customers that its products will conform to certain representations, which may include functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that its software media is free from material defects. Sales contracts for certain of the Company’s medication packaging systems may have in the past and may in the future include limited warranties for up to six months, but the periodic activity and ending warranty balances the Company records have historically not been material.

[0000926326-25-000003:notes:261]
From time to time, the Company may also warrant that its professional services will conform to certain representations, which may include that such services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. The Company generally seeks to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality, and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive, or similar damages. In some

[0000926326-25-000003:notes:262]
states, such disclaimers may not be enforceable. If necessary, the Company would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. The Company has not been subject to any significant claims for such losses and has not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, the Company believes it is unlikely that the Company will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of December 31, 2024 and 2023.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-25-000003:notes:263]
Employee Benefits and Share-Based Compensation
Equity Incentive Plans

[0000926326-25-000003:notes:264]
1997 Employee Stock Purchase Plan

[0000926326-25-000003:notes:265]
The Company has an Employee Stock Purchase Plan (“ESPP”), under which employees can purchase shares of its common stock based on a percentage of their compensation, but not greater than 15% of their earnings; provided, however, an eligible employee’s right to purchase shares of the Company’s common stock may not accrue at a rate which exceeds $25,000 of the fair market value of such shares for each calendar year in which such rights are outstanding. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-25-000003:notes:266]
For the years ended December 31, 2024 and 2023, employees purchased approximately 524,000 and 353,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $24.14 and $46.68, respectively.

[0000926326-25-000003:notes:267]
2009 Equity Incentive Plan

[0000926326-25-000003:notes:268]
The 2009 Equity Incentive Plan (“2009 Plan”), as amended, provides for the issuance of incentive stock options, RSAs, RSUs, PSUs, and other stock awards to the Company’s employees, directors, and consultants.

[0000926326-25-000003:notes:269]
RSUs generally vest over periods of up to four years, with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 12 equal quarterly installments thereafter. Awards of restricted stock to non-employee directors are granted on the date of the annual meeting of stockholders and vest in full on the date of the next annual meeting of stockholders, provided such non-employee director remains a director on such date. PSUs granted to the Company’s executives may include performance and market conditions. PSUs become eligible for vesting when certain market or performance conditions are met. PSUs generally vest over periods of up to four years, with one-fourth of the shares vesting approximately one year from the vesting commencement date with respect to initial grants and upon confirmation by the Compensation Committee that the performance target has been met, and the remaining shares generally vesting in equal semi-annual or quarterly installments over the remaining three years. Vesting is contingent upon continued service.

[0000926326-25-000003:notes:270]
Share-Based Compensation Expense

[0000926326-25-000003:notes:271]
The following table sets forth the total share-based compensation expense:

[0000926326-25-000003:notes:272]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 6,373 |  |  | $ | 8,288 |  |  | $ | 9,067 |  |
| Research and development | 4,441 |  |  | 6,941 |  |  | 11,368 |  |
| Selling, general, and administrative | 28,502 |  |  | 40,071 |  |  | 47,812 |  |
| Total share-based compensation expense | $ | 39,316 |  |  | $ | 55,300 |  |  | $ | 68,247 |  |

[0000926326-25-000003:notes:273]
During the years ended December 31, 2024 and 2023, the Company capitalized approximately $3.6 million and $4.4 million, respectively, of non-cash share-based compensation expense to internal-use and external-use software development costs related to internal labor. The Company did not capitalize any material non-cash share-based compensation expense to inventory during the years ended December 31, 2024 and 2023. Income tax benefit (expense) realized from share-based compensation was an expense of $5.4 million and $6.5 million for the years ended December 31, 2024 and 2023, respectively, and a benefit of $5.2 million for the year ended December 31, 2022.

[0000926326-25-000003:notes:274]
Stock Options

[0000926326-25-000003:notes:275]
There were no stock options granted during the years ended December 31, 2024 and 2022. During the year ended December 31, 2023, the Company granted 200,000 shares of options at the weighted-average fair value per share of options of $19.48.

[0000926326-25-000003:notes:276]
The following table summarizes the stock option activity under the 2009 Plan:

[0000926326-25-000003:notes:277]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2023 | 2,023 |  |  | $ | 67.68 |  |  | 4.6 |  | $ | 1,013 |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (24) |  |  | 31.76 |  |  |  |  |  |
| Expired | (216) |  |  | 73.44 |  |  |  |  |  |
| Forfeited | (23) |  |  | 63.99 |  |  |  |  |  |
| Outstanding at December 31, 2024 | 1,760 |  |  | $ | 67.51 |  |  | 3.6 |  | $ | 2,619 |  |
| Exercisable at December 31, 2024 | 1,757 |  |  | $ | 67.33 |  |  | 3.6 |  | $ | 2,619 |  |
| Vested and expected to vest at December 31, 2024 and thereafter | 1,760 |  |  | $ | 67.50 |  |  | 3.6 |  | $ | 2,619 |  |

[0000926326-25-000003:notes:278]
The intrinsic value of options exercised during the years ended December 31, 2024, 2023, and 2022 was $0.3 million, $3.2 million, and $23.9 million, respectively.

[0000926326-25-000003:notes:279]
Restricted Stock Units (“RSUs”)

[0000926326-25-000003:notes:280]
The following table summarizes the RSU activity under the 2009 Plan:

[0000926326-25-000003:notes:281]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2023 | 1,078 |  |  | $ | 84.66 |  |  | 1.5 |  | $ | 40,551 |  |
| Granted | 1,083 |  |  | 40.35 |  |  |  |  |  |
| Vested | (380) |  |  | 89.84 |  |  |  |  |  |
| Forfeited | (167) |  |  | 76.17 |  |  |  |  |  |
| Outstanding and unvested at December 31, 2024 | 1,614 |  |  | $ | 54.58 |  |  | 1.6 |  | $ | 71,849 |  |

[0000926326-25-000003:notes:282]
The weighted-average grant date fair value per share of RSUs granted during the years ended December 31, 2024, 2023, and 2022 was $40.35, $63.74, and $111.12, respectively. The total fair value of RSUs that vested in the years ended December 31, 2024, 2023, and 2022 was $34.1 million, $38.0 million, and $30.7 million, respectively.

[0000926326-25-000003:notes:283]
As of December 31, 2024, total unrecognized compensation cost related to RSUs was $56.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 3.1 years.

[0000926326-25-000003:notes:284]
Restricted Stock Awards (“RSAs”)

[0000926326-25-000003:notes:285]
The following table summarizes the RSA activity under the 2009 Plan:

[0000926326-25-000003:notes:286]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  |  |  |  |  |  |  |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2023 | 24 |  |  | $ | 70.96 |  |  |  |  |  |  |  |  |
| Granted | 51 |  |  | 31.94 |  |  |  |  |  |  |  |  |
| Vested | (26) |  |  | 67.32 |  |  |  |  |  |  |  |  |
| Outstanding and unvested at December 31, 2024 | 49 |  |  | $ | 31.91 |  |  |  |  |  |  |  |  |

[0000926326-25-000003:notes:287]
The weighted-average grant date fair value per share of RSAs granted during the years ended December 31, 2024, 2023, and 2022 was $31.94, $70.96, and $109.39, respectively. The total fair value of RSAs that vested in the years ended December 31, 2024, 2023, and 2022 was $1.8 million, $1.4 million, and $1.6 million, respectively.

[0000926326-25-000003:notes:288]
Performance-Based Stock Unit Awards (“PSUs”)

[0000926326-25-000003:notes:289]
During the year ended December 31, 2023, the Company granted 65,000 PSUs to its executive officers, none of which became eligible for vesting as the achievement of a certain level of shareholder return was not achieved. During the year ended December 31, 2024, the Company granted 177,069 PSUs to its executive officers, of which 0% to 200% may become eligible for vesting depending on the level of shareholder return for the period from March 1, 2024 through March 1, 2025.

[0000926326-25-000003:notes:290]
The number of shares that vest at the end of the performance period depends on the percentile ranking of the total shareholder return for Omnicell stock over the performance period relative to the total shareholder return of certain companies in the healthcare sector of the S&P 400 and S&P 600 indexes. Stock price appreciation is calculated based on the trailing 20-day average stock price just prior to the first trading day of March in the grant year, compared to the trailing 20-day average stock price just prior to the first trading day of March in the year subsequent to the grant year.

[0000926326-25-000003:notes:291]
The following table summarizes the PSU activity under the 2009 Plan:

[0000926326-25-000003:notes:292]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2023 | 75 |  |  | $ | 127.14 |  |
| Granted (Awarded) | 177 |  |  | 28.67 |  |
| Vested (Released) | (10) |  |  | 157.56 |  |
| Forfeited | (65) |  |  | 122.29 |  |
| Outstanding and unvested at December 31, 2024 | 177 |  |  | $ | 28.67 |  |

[0000926326-25-000003:notes:293]
The weighted-average grant date fair value per share of PSUs granted during the years ended December 31, 2024, 2023, and 2022 was $28.67, $122.29, and $155.27, respectively. The total fair value of PSUs that vested in the years ended December 31, 2024, 2023, and 2022 was $1.6 million, $6.1 million, and $15.0 million, respectively.

[0000926326-25-000003:notes:294]
As of December 31, 2024, total unrecognized compensation cost related to PSUs was approximately $2.9 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.4 years.

[0000926326-25-000003:notes:295]
Summary of Shares Reserved for Future Issuance under Equity Incentive Plans

[0000926326-25-000003:notes:296]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of December 31, 2024:

[0000926326-25-000003:notes:297]
|  | Number of Shares |
|  | (In thousands) |
| Stock options outstanding | 1,760 |  |
| Non-vested restricted stock awards | 1,840 |  |
| Shares authorized for future issuance | 3,362 |  |
| ESPP shares available for future issuance | 2,726 |  |
| Total shares reserved for future issuance | 9,688 |  |

[0000926326-25-000003:notes:298]
401(k) Plan
The Company has established a pre-tax savings plan under Section 401(k) of the Internal Revenue Code of 1986, as amended. The 401(k) Plan allows eligible employees in the United States to voluntarily contribute a portion of their pre-tax salary, subject to a maximum limit specified in the Internal Revenue Code. The Company generally matches 50% of employee contributions up to $3,000, annually. The Company’s contributions under this plan were $7.5 million, $7.9 million, and $8.1 million in the years ended December 31, 2024, 2023, and 2022, respectively.


## us-gaap:TreasuryStockTextBlock

[0000926326-25-000003:notes:299]
Stock Repurchase Programs
On August 2, 2016, the Company’s Board of Directors (the “Board”) authorized a stock repurchase program, which does not expire, providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). As of December 31, 2024, the maximum dollar value of shares that may yet be purchased under the 2016 Repurchase Program was $2.7 million.

[0000926326-25-000003:notes:300]
The timing, price, and volume of repurchases are to be based on market conditions, relevant securities laws, and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions, or pursuant to a Rule 10b-18 plan, subject to the terms and conditions of the Second A&R Credit Agreement, as amended. The 2016 Repurchase Program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the 2016 Repurchase Program at any time.

[0000926326-25-000003:notes:301]
During the year ended December 31, 2022, the Company repurchased approximately 389,300 shares of its common stock under the repurchase programs at an average price of $134.11 per share for an aggregate purchase price of approximately $52.2 million. During the years ended December 31, 2024 and 2023, the Company did not repurchase any of its outstanding common stock under the 2016 Repurchase Program.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-25-000003:notes:302]
Income Taxes
The following is a geographical breakdown of income (loss) before income taxes:

[0000926326-25-000003:notes:303]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Domestic | $ | 19,757 |  |  | $ | (28,105) |  |  | $ | 369 |  |
| Foreign | 5,836 |  |  | 7,997 |  |  | (2,822) |  |
| Income (loss) before income taxes | $ | 25,593 |  |  | $ | (20,108) |  |  | $ | (2,453) |  |

[0000926326-25-000003:notes:304]
The provision for (benefit from) income taxes consisted of the following:

[0000926326-25-000003:notes:305]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Current: |  |  |  |  |  |
| Federal | $ | 21,805 |  |  | $ | 8,556 |  |  | $ | 17,973 |  |
| State | 4,964 |  |  | 1,471 |  |  | 8,024 |  |
| Foreign | 846 |  |  | 840 |  |  | 192 |  |
| Total current income taxes | 27,615 |  |  | 10,867 |  |  | 26,189 |  |
| Deferred: |  |  |  |  |  |
| Federal | (14,416) |  |  | (8,002) |  |  | (25,753) |  |
| State | 115 |  |  | (2,261) |  |  | (7,976) |  |
| Foreign | (252) |  |  | (341) |  |  | (561) |  |
| Total deferred income taxes | (14,553) |  |  | (10,604) |  |  | (34,290) |  |
| Total provision for (benefit from) income taxes | $ | 13,062 |  |  | $ | 263 |  |  | $ | (8,101) |  |

[0000926326-25-000003:notes:306]
The provision for (benefit from) income taxes differs from the amount computed by applying the statutory federal tax rate as follows:

[0000926326-25-000003:notes:307]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In thousands) |
| U.S. federal tax provision at statutory rate | $ | 5,375 |  |  | $ | (4,223) |  |  | $ | (515) |  |
| State taxes | 4,037 |  |  | (624) |  |  | 38 |  |
| Section 162(m) limitation | 531 |  |  | 1,286 |  |  | 3,071 |  |
| Non-deductible expenses | 510 |  |  | 531 |  |  | 134 |  |
| Uncertain tax positions | (881) |  |  | (620) |  |  | (776) |  |
| Share-based compensation tax expense (benefit) | 6,078 |  |  | 7,384 |  |  | (3,264) |  |
| Research tax credits | (3,531) |  |  | (4,587) |  |  | (6,948) |  |
| Gain on extinguishment of debt | 477 |  |  | — |  |  | — |  |
| Foreign-derived intangible income deduction | (229) |  |  | (325) |  |  | (753) |  |
| Global intangible low-taxed income inclusion | 826 |  |  | — |  |  | 960 |  |
| Foreign rate differential | 122 |  |  | 219 |  |  | 186 |  |
| Foreign branch taxes | (7) |  |  | 6 |  |  | (51) |  |
| Transaction cost | — |  |  | — |  |  | 68 |  |
| Provision to return true up | (244) |  |  | 697 |  |  | (84) |  |
| State rate true up | — |  |  | 528 |  |  | (135) |  |
| Other | (2) |  |  | (9) |  |  | (32) |  |
| Total provision for (benefit from) income taxes | $ | 13,062 |  |  | $ | 263 |  |  | $ | (8,101) |  |

[0000926326-25-000003:notes:308]
The Organization for Economic Co-Operation and Development (OECD) introduced Base Erosion and Profit Shifting (BEPS) Pillar Two rules that impose a global minimum tax rate of 15% on multi-national corporations. The rules are effective for the Company’s financial year beginning January 1, 2024. Numerous countries have enacted or substantively enacted legislation to implement these rules. While the Company did not have an impact from Pillar Two on its tax provision or effective tax rate as of the year ended December 31, 2024, the Company continues to monitor evolving tax legislation in the jurisdictions in which it operates.

[0000926326-25-000003:notes:309]
Significant components of the Company’s deferred tax assets (liabilities) were as follows:

[0000926326-25-000003:notes:310]
|  | December 31, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| Deferred tax assets (liabilities): |  |  |  |
| Deferred revenues | $ | 23,550 |  |  | $ | 11,343 |  |
| Share-based compensation | 9,915 |  |  | 11,763 |  |
| Inventory-related items | 6,055 |  |  | 5,136 |  |
| Tax credit carryforwards | 12,843 |  |  | 12,505 |  |
| Reserves and accruals | 8,384 |  |  | 5,660 |  |
| Loss carryforwards | 6,493 |  |  | 7,802 |  |
| Lease liability | 10,615 |  |  | 11,457 |  |
| Convertible debt | 11,276 |  |  | 9,649 |  |
| Capitalized research and development | 49,380 |  |  | 41,635 |  |
| Other, net | 1,580 |  |  | 591 |  |
| Gross deferred tax assets | 140,091 |  |  | 117,541 |  |
| Valuation allowance | — |  |  | — |  |
| Total net deferred tax assets | 140,091 |  |  | 117,541 |  |
| Intangibles | (27,057) |  |  | (30,366) |  |
| Depreciation and amortization | (35,759) |  |  | (35,402) |  |
| Prepaid expenses | (14,466) |  |  | (13,858) |  |
| Right-of-use assets | (6,448) |  |  | (6,626) |  |
| Other, net | — |  |  | (8) |  |
| Total deferred tax liabilities | (83,730) |  |  | (86,260) |  |
| Net deferred tax assets | $ | 56,361 |  |  | $ | 31,281 |  |

[0000926326-25-000003:notes:311]
Deferred income tax assets (liabilities) are provided for temporary differences that will result in future tax deductions or future taxable income, as well as the future benefit of tax credit carryforwards. The Company recognizes deferred tax assets to the extent that it believes these assets are more likely than not to be realized. In making such a determination, the Company considers all available positive and negative evidence, including future reversals of existing temporary differences, projected future taxable income, tax planning strategies, and results of recent operations. As of December 31, 2024 and 2023, the Company does not have a valuation allowance against any of its deferred tax assets.

[0000926326-25-000003:notes:312]
As of December 31, 2024, the Company had no federal net operating loss carryforward and $9.5 million of state net operating loss carryforwards. The Company also has $18.7 million of foreign net operating losses carried forward indefinitely. For income tax purposes, the Company had no federal research tax credit carryforward and a California research tax credit carryforward of $21.6 million. California research tax credits are carried forward indefinitely to reduce cash taxes payable.

[0000926326-25-000003:notes:313]
It is the Company’s practice and intention to reinvest the earnings of its non-U.S. subsidiaries in those operations. As of December 31, 2024, the Company has not made a provision for U.S. federal income, withholding, and state income taxes on the outside basis difference related to certain foreign subsidiaries because earnings are intended to be indefinitely reinvested in operations outside the U.S.

[0000926326-25-000003:notes:314]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examinations by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, France, the United Kingdom and India. With few exceptions, as of December 31, 2024, the Company was no longer subject to U.S., state, and foreign tax examinations for years before 2021, 2020, and 2020, respectively.

[0000926326-25-000003:notes:315]
The following table summarizes the aggregate change in the balance of gross unrecognized tax benefit, which excludes interest and penalties:

[0000926326-25-000003:notes:316]
|  | (In thousands) |
| Balance as of December 31, 2021 | $ | 8,961 |  |
| Increases related to tax positions taken during a prior period | 3 |  |
| Decreases related to tax positions taken during the prior period | (59) |  |
| Increases related to tax positions taken during the current period | 1,629 |  |
| Decreases related to expiration of statute of limitations | (1,238) |  |
| Balance as of December 31, 2022 | 9,296 |  |
| Increases related to tax positions taken during a prior period | 750 |  |
| Decreases related to tax positions taken during the prior period | (161) |  |
| Increases related to tax positions taken during the current period | 1,566 |  |
| Decreases related to expiration of statute of limitations | (703) |  |
| Balance as of December 31, 2023 | 10,748 |  |
| Increases related to tax positions taken during a prior period | 4 |  |
| Decreases related to tax positions taken during the prior period | (138) |  |
| Increases related to tax positions taken during the current period | 1,163 |  |
| Decreases related to settlements | (333) |  |
| Decreases related to expiration of statute of limitations | (952) |  |
| Balance as of December 31, 2024 | $ | 10,492 |  |

[0000926326-25-000003:notes:317]
The total amount of gross unrecognized tax benefit that, if realized, would favorably affect the Company’s effective income tax rate in future periods, was $10.5 million and $10.7 million as of December 31, 2024 and 2023, respectively. The Company recognizes interest and penalties related to uncertain tax positions in interest and other income (expense), net in the Consolidated Statements of Operations, accruing $0.3 million, $0.2 million, and $0.2 million for the years ended December 31, 2024, 2023, and 2022, respectively. Accrued interest and penalties are included within other long-term liabilities on the Consolidated Balance Sheets. The combined amount of cumulative accrued interest and penalties was approximately $0.6 million, $0.4 million, and $0.2 million for the years ended December 31, 2024, 2023, and 2022, respectively. The Company does not believe there will be any significant changes in its unrecognized tax positions over the next twelve months.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-25-000003:notes:318]
Restructuring Expenses
During 2022, the Company underwent several restructuring initiatives which consisted of: (i) certain domestic and international restructurings in order to enhance and streamline certain engineering functions for its domestic operations and to realign its international sales organization to better serve its customers in various international markets, (ii) integration and functionalization of certain acquisitions, primarily the 340B Link business acquisition, to further accelerate the expansion of the Company’s pharmacy inventory management capabilities, and (iii) committing to a plan to reduce the Company’s headcount as part of the Company’s expense containment efforts implemented due to ongoing macroeconomic headwinds. During the year ended December 31, 2022, the restructuring plans incurred $22.8 million of employee severance costs and related expenses. As of December 31, 2024 and 2023, there was no unpaid balance related to the 2022 restructuring initiatives.

[0000926326-25-000003:notes:319]
During 2023, due to challenging industry dynamics and macroeconomic conditions, the Company underwent several expense containment measures such as a reduction of its headcount across many of its functions and a reduction of its real estate footprint. During the year ended December 31, 2023, the restructuring initiatives incurred $15.5 million of employee severance costs and related expenses, net of reversals. As of December 31, 2024 and 2023, the unpaid balance related to the 2023 initiatives was $0.6 million and $8.9 million, respectively.

[0000926326-25-000003:notes:320]
On April 26, 2024, the Company’s management committed to the wind down of the Company’s Medimat Robotic Dispensing System (“RDS”) product line, subject to local law and statutory works council consultation requirements. During the year ended December 31, 2024, the Company incurred approximately $6.6 million of employee severance costs and other expenses related to the RDS product line wind down, net of immaterial reversals of previously recognized restructuring expenses. As of December 31, 2024, the unpaid balance related to this restructuring event was $2.5 million. In addition, during the year ended December 31, 2024, the Company incurred $5.4 million of inventory write-down charges related to the RDS product line wind down that were recorded to cost of revenues in the Company’s Consolidated Statements of Operations.

[0000926326-25-000003:notes:321]
Refer to Note 13, Lessee Leases for information regarding the Company’s restructuring activities for the reduction of its real estate footprint and optimization of certain leased facilities.

[0000926326-25-000003:notes:322]
The following table summarizes the total employee-related restructuring expense, net of reversals:

[0000926326-25-000003:notes:323]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2022 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 4,504 |  |  | $ | 3,089 |  |  | $ | 8,018 |  |
| Research and development | 419 |  |  | 3,829 |  |  | 3,615 |  |
| Selling, general, and administrative | 230 |  |  | 8,621 |  |  | 11,170 |  |
| Total restructuring expenses, net of reversals | $ | 5,153 |  |  | $ | 15,539 |  |  | $ | 22,803 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000926326-25-000003:notes:324]
SCHEDULE II

[0000926326-25-000003:notes:325]
VALUATION AND QUALIFYING ACCOUNTS

[0000926326-25-000003:notes:326]
|  | Balance atBeginning of Period (1) |  | Charged (Credited) toCosts and Expenses (2) |  | AmountsWritten Off (3) |  | Other Adjustments (4) |  | Balance atEnd of Period (1) |
|  | (In thousands) |
| Year ended December 31, 2022 |  |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables | $ | 5,272 |  |  | $ | 2,658 |  |  | $ | (2,551) |  |  | $ | (226) |  |  | $ | 5,153 |  |
| Long-term unbilled receivables | 26 |  |  | 9 |  |  | — |  |  | — |  |  | 35 |  |
| Net investment in sales-type leases | 228 |  |  | 80 |  |  | — |  |  | — |  |  | 308 |  |
| Total allowances deducted from assets | $ | 5,526 |  |  | $ | 2,747 |  |  | $ | (2,551) |  |  | $ | (226) |  |  | $ | 5,496 |  |
| Year ended December 31, 2023 |  |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables | $ | 5,153 |  |  | $ | 2,726 |  |  | $ | (2,441) |  |  | $ | 126 |  |  | $ | 5,564 |  |
| Long-term unbilled receivables | 35 |  |  | (4) |  |  | — |  |  |  |  | 31 |  |
| Net investment in sales-type leases | 308 |  |  | (51) |  |  | — |  |  | — |  |  | 257 |  |
| Total allowances deducted from assets | $ | 5,496 |  |  | $ | 2,671 |  |  | $ | (2,441) |  |  | $ | 126 |  |  | $ | 5,852 |  |
| Year ended December 31, 2024 |  |  |  |  |  |  |  |  |  |
| Accounts receivable and unbilled receivables | $ | 5,564 |  |  | $ | 3,943 |  |  | $ | (2,691) |  |  | $ | (171) |  |  | $ | 6,645 |  |
| Long-term unbilled receivables | 31 |  |  | 48 |  |  | — |  |  |  |  | 79 |  |
| Net investment in sales-type leases | 257 |  |  | (116) |  |  | — |  |  | — |  |  | 141 |  |
| Total allowances deducted from assets | $ | 5,852 |  |  | $ | 3,875 |  |  | $ | (2,691) |  |  | $ | (171) |  |  | $ | 6,865 |  |

[0000926326-25-000003:notes:327]
__________________________________________________

[0000926326-25-000003:notes:328]
(1)Allowance for credit losses.

[0000926326-25-000003:notes:329]
(2)Represents amounts charged and credited for provisions for credit losses.

[0000926326-25-000003:notes:330]
(3)Represents amounts written off from the allowance and receivable.

[0000926326-25-000003:notes:331]
(4)Represents other adjustments, such as foreign currency translation adjustments.
