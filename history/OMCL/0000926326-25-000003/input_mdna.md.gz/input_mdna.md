# OMCL MD&A — 0000926326-25-000003


## mdna

[0000926326-25-000003:mdna:1]
ITEM 7.    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000926326-25-000003:mdna:2]
The following discussion and analysis should be read in conjunction with our Consolidated Financial Statements and related Notes to Consolidated Financial Statements in this Annual Report on Form 10-K. This discussion and analysis may contain forward-looking statements based upon our current expectations and assumptions that involve risks and uncertainties.

[0000926326-25-000003:mdna:3]
Our actual results and the timing of selected events could differ materially from those anticipated in these forward-looking statements as a result of several factors, including those set forth under Item 1A, “Risk Factors,” and elsewhere in this Annual Report on Form 10-K. Unless otherwise stated, references in this Annual Report to particular years or quarters refer to our fiscal year and the associated quarters of those fiscal years.

[0000926326-25-000003:mdna:4]
We have elected to omit discussion of the earliest of the three years covered by the Consolidated Financial Statements presented. Such omitted discussion can be found under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” located in our Annual Report on Form 10-K for the fiscal year ended December 31, 2023, filed with the SEC on February 28, 2024, for reference to discussion of the fiscal year ended December 31, 2022, the earliest of the three fiscal years presented.

[0000926326-25-000003:mdna:5]
OVERVIEW

[0000926326-25-000003:mdna:6]
Our Business

[0000926326-25-000003:mdna:7]
Omnicell, a leader in transforming the pharmacy and nursing care delivery model, is committed to solving the critical challenges inherent in medication management and elevating the role of clinicians within healthcare as an essential component of care delivery. Omnicell is focused on helping its customers define and deliver a cost-effective medication management strategy designed to equip and empower pharmacists and nurses to focus on patient care rather than administrative tasks, and to drive improved clinical, operational, and financial outcomes across all care settings. We are doing this with an industry-leading medication management infrastructure which includes robotics and smart devices, software workflows, expert services, and operational and optimization analytics. This comprehensive set of solutions provides the critical foundation for customers to realize the Autonomous Pharmacy, an industry-wide vision defined by pharmacy leaders for improving operational efficiencies and ultimately targeting zero-error medication management.

[0000926326-25-000003:mdna:8]
Omnicell solutions are helping healthcare facilities worldwide to uncover cost savings, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry-defined vision of the Autonomous Pharmacy. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 91% of our total revenues for the year ended December 31, 2024.

[0000926326-25-000003:mdna:9]
Over the past several years, our business has expanded from a single-point solution to a platform of products and services that will help further advance the industry-defined vision of the Autonomous Pharmacy. This expansion has resulted in larger deal sizes across multiple products, services, and implementations for customers and, we believe, more comprehensive, valuable, and enduring relationships. As our business evolves, we continue to evaluate the metrics and methods we use to measure the success of our business.

[0000926326-25-000003:mdna:10]
We utilize bookings as an indicator of the success of our business. During 2024, we defined bookings generally as: (i) the value of non-cancelable contracts for our connected devices, software products, and SaaS and Expert Services (although, for those SaaS and Expert Services contracts without a minimum commitment, bookings only include the amount of revenue that has been recognized once the services have been provided); and (ii) for our consumables, the value of orders placed through our Omnicell Storefront online platform or through written or telephonic orders. We typically exclude technical services and other less significant items ancillary to our products and services, such as freight revenue, from bookings. In addition, dependent upon counterparty or credit risk, which is evaluated at the time of contract signing, for a given multi-year subscription contract we may reduce the portion of the contractual commitment booked at a given time. As noted, the portfolio of products, solutions, and services we offer has evolved. As a result, the ordering process for certain of our solutions has also evolved. For example, orders for certain solutions may not include a purchase order. Connected devices and software license bookings are recorded as revenue upon customer acceptance of the installation or receipt of goods. Revenues from SaaS and Expert Services bookings are recorded over the contractual term. Bookings increased by 8%, from $854 million in 2023 to $923 million in 2024, primarily driven by XT Series upgrades as we complete the XT Series upgrade cycle, as well as better than expected bookings of XTExtend, a core component of the multi-year XT Amplify innovation program.

[0000926326-25-000003:mdna:11]
We generally provide installation planning and consulting as part of most connected device product sales, which is typically included in the initial price of the solution. To help ensure the maximum availability of our systems, our customers typically purchase technical services contracts (support and maintenance) in increments of one to five years. In addition to connected device product sales, we provide a range of services to our customers. We also provide comprehensive service offerings such as Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions, which typically are provided over two to seven years.

[0000926326-25-000003:mdna:12]
2025 Product Bookings and Annual Recurring Revenue

[0000926326-25-000003:mdna:13]
Starting in 2025, we will utilize product bookings and Annual Recurring Revenue (each as further described below) as key performance metrics for our business. We view product bookings as an indicator of the success of certain portions of our business that generate nonrecurring revenue and Annual Recurring Revenue as an indicator of the success of the portion of our business that generates recurring revenues. The definitions and descriptions included below are relevant to these key performance metrics that will replace our prior bookings metric in 2025 and beyond.

[0000926326-25-000003:mdna:14]
Product Bookings

[0000926326-25-000003:mdna:15]
We utilize product bookings as an indicator of the success of certain portions of our business that generate non-recurring revenue. We define product bookings generally as the value of non-cancelable contracts for our connected devices and software licenses. We typically exclude freight revenue and other less significant items ancillary to our products from product bookings. In addition, dependent upon counterparty or credit risk, which is evaluated at the time of contract signing, for a given multi-year subscription contract we may reduce the value of the contractual commitment booked at a given time. Connected devices and software license bookings are recorded as revenue upon customer acceptance of the installation or receipt of goods. Using the new definition of the metric, product bookings were $558 million as of December 31, 2024.

[0000926326-25-000003:mdna:16]
Annual Recurring Revenue

[0000926326-25-000003:mdna:17]
We consider revenues generated from our consumables, technical services, and SaaS and Expert Services to be recurring revenues. For the portions of our business which generate recurring revenues, we utilize Annual Recurring Revenue (“ARR”) as a key metric to measure our progress in growing our recurring revenue business. We define ARR at a measurement date as the revenue we expect to receive from our customers over the course of the following year for providing them with products or services. ARR includes expected revenue from all customers who are using our products or services at the reported date. For technical services and SaaS and Expert Services, solutions are generally on a contractual basis, typically with contracts for a period of 12 months or more, with a high probability of renewal. Probability of renewal is based on historic renewal experience of the individual revenue streams or management’s best estimates if historical renewal experience is not available. Consumables orders are placed by customers through our Omnicell Storefront online platform or through written or telephonic orders and are sold to a customer base who utilize the consumable product and place recurring orders when customer inventory is depleted. ARR is generally calculated based on revenues received in the most recent quarter and changes to expected revenues where solutions were added to or removed from the install or customer base in the quarter. Revenues from technical services and SaaS and Expert Services are recorded ratably over the service term. Revenue from consumables are recorded when the product has shipped and title has passed. Our measure of ARR may be different than that used by other companies. Because ARR is based on expected future revenue, it does not represent revenue recognized during a particular reporting period or revenue to be recognized in future reporting periods. ARR should not be viewed as a substitute for revenues. Under the new metric, ARR was $580 million as of December 31, 2024.

[0000926326-25-000003:mdna:18]
The following table summarizes each revenue category:

[0000926326-25-000003:mdna:19]
| Revenue Category |  | Revenue Type |  | Income Statement Classification |  | Included in Bookings(through 2024) |  | Included in Product Bookings(2025 onwards) |  | Included in ARR(2025 onwards) |
| Connected devices, software licenses, and other |  | Nonrecurring |  | Product |  | Yes (1) |  | Yes (1) |  | No |
| Consumables |  | Recurring |  | Product |  | Yes |  | No |  | Yes |
| Technical services |  | Recurring |  | Service |  | No |  | No |  | Yes |
| SaaS and Expert Services (2) |  | Recurring |  | Service |  | Yes (3) |  | No |  | Yes |

[0000926326-25-000003:mdna:20]
_________________________________________________

[0000926326-25-000003:mdna:21]
(1)    Certain other insignificant revenue streams ancillary to our products and services, such as freight revenue, are not included in bookings.

[0000926326-25-000003:mdna:22]
(2)    Includes Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions.

[0000926326-25-000003:mdna:23]
(3)    For those SaaS and Expert Services contracts without a minimum commitment, bookings only include the amount of revenue that has been recognized once the services have been provided.

[0000926326-25-000003:mdna:24]
Operating Segments

[0000926326-25-000003:mdna:25]
We manage our operations as a single segment for the purposes of assessing performance and making operating decisions. Our Chief Operating Decision Maker (“CODM”) is our Chief Executive Officer. The CODM allocates resources and evaluates the performance of Omnicell at the consolidated level using our consolidated net income. In addition, the CODM is provided with certain segment assets, primarily those that impact liquidity, as well as certain significant expenses. All

[0000926326-25-000003:mdna:26]
significant operating decisions are based upon an analysis of Omnicell as one operating segment, which is the same as our reporting segment.

[0000926326-25-000003:mdna:27]
Our full-time employee headcount was approximately 3,670 on December 31, 2024.

[0000926326-25-000003:mdna:28]
Business Strategy

[0000926326-25-000003:mdna:29]
In 2023, the United States spent $723 billion on prescription drugs, a 13.6% increase from 2022. This was the largest annual spending increase in 20 years and impacted patients in virtually all settings of care. We believe there are significant challenges facing the practice of pharmacy today including, but not limited to, budget constraints, increased healthcare worker turnover rates, labor shortages, drug shortages, drug diversion, manual and error-prone processes, complex compliance requirements, and limited inventory visibility. Each of these challenges may lead to poor medication management outcomes including, but not limited to, medication errors, adverse drug events, lack of patient adherence, and medication waste. We also recognize that these challenges may impact the timing of contracting for, or implementation of, our products, solutions, or services. However, we believe that over time these significant challenges to the practice of pharmacy will drive demand for increased automation, visibility, insights, and improved medication management outcomes that our solutions are designed to enable. Because of this, we believe that our solutions are well-positioned to address the evolving needs of healthcare institutions and therefore present opportunities for long-term growth.

[0000926326-25-000003:mdna:30]
In an effort to address these challenges and deliver solutions to help drive positive medication management outcomes, we continue to make significant investments in our research and development efforts to further advance the industry-defined vision of the Autonomous Pharmacy. Furthermore, we believe a combination of robotics and smart devices, software workflows, expert services, and operational and optimization analytics is needed in every care setting where medications are managed. We are focused on delivering solutions to help our customers realize the industry-defined vision of the Autonomous Pharmacy and drive positive medication management outcomes with outstanding customer experience through a mature channel in four market categories:

[0000926326-25-000003:mdna:31]
•Points of Care.  As a market leader, we expect to continue expansion into this product market as customers increase the use of our dispensing systems in more areas within their hospitals and increasingly in ambulatory care settings. Macroeconomic trends in our target market continue to improve as health system margins and volumes increase and stabilize in the post-pandemic environment. This positive trajectory is expected to drive increased demand for system modernization through automation, software, and analytics. We are seeing customers seek to maximize the value of existing automated dispensing system investments and continue to invest in next-generation enhancements and solutions for points of care. We believe that customers will upgrade their current installed base over time as we deliver these new solutions to market. We also believe there is an opportunity for us to expand this offering and define a new standard for dispensing systems in ambulatory settings. We believe our current solutions for Points of Care and new innovations and services will continue to help customers drive improved clinical and financial outcomes.

[0000926326-25-000003:mdna:32]
•Central Pharmacy and IV Compounding.  This market represents the beginning of the medication management process in acute care settings, and we believe it is a significant automation opportunity for high volumes of manual, repetitive, and error-prone processes that are often common in pharmacies today. Manual medication dispensing processes are usually labor intensive, error-prone, and may lead to excess medication waste and expirations for our healthcare partners. Automating the central pharmacy dispensing process should enable customers to reallocate pharmacy labor, enhance dispensing accuracy and patient safety, and reduce medication waste and expirations. Likewise, the manual compounding of sterile IV preparations can be error-prone and create significant patient safety risks, and outsourcing sterile IV compounding could lead to increased medication costs and lack of access to needed medications due to an inability to source medications when they are required. As a result, we believe IV automation provides a significant opportunity to enhance patient safety and reduce costs. We anticipate that these technology-enabled services will become more critical as health systems continue to face labor shortages, increased financial pressure, and supply chain disruptions.

[0000926326-25-000003:mdna:33]
•Specialty Pharmacy and 340B Program.  We believe that health systems will continue to invest in programs that are intended to improve patient outcomes and drive cost savings by utilizing specialty pharmacies and the federal 340B Drug Pricing Program (the “340B Program”). The 340B Program allows qualifying hospitals and health systems to stretch federal resources and expand patient access to healthcare by requiring manufacturers participating in Medicaid to sell outpatient drugs at discounted prices to eligible healthcare organizations and covered entities. Specialty drugs are used for treatment of complex conditions and often require intensive patient management and specialized workflows for dispensing and care coordination. Specialty medications are projected to account for nearly 60% of U.S. total spending on medications, with total spending projected to be approximately $420 billion in 2025. Specialty pharmacies serve as the connection between patients, prescribing physicians, and payers and work to streamline access and adherence to these specialty drugs. We believe a solution that is designed to help health systems start or optimize

[0000926326-25-000003:mdna:34]
their specialty pharmacy programs and the related pharmaceutical aspects of patient care will help ensure continuity of care and should contribute to the revenue and profitability of those organizations. We believe that a fully optimized specialty pharmacy operation represents one of the largest economic opportunities for hospitals and health systems.

[0000926326-25-000003:mdna:35]
•Ambulatory Care.  We believe ambulatory care, especially the retail and institutional market, represents a significant opportunity as healthcare evolves. Retail pharmacies are expected to fill 4.98 billion prescriptions in 2025 and grow at a compound annual growth rate of around 7.1%, which would result in an approximate $1.2 trillion market valuation by 2032. Additionally, the shift of outpatient care from hospitals and physician offices to other, more convenient settings, such as retail pharmacies and the home continues to be a growing trend. New technologies and increased scope of practice for pharmacists appear to be spurring innovation and expansion of the provision of clinical services by retail pharmacies. We believe this development, combined with the move to value-based care, will drive the adoption of our patient engagement offerings. These solutions are intended to help providers (including pharmacists) engage patients in new ways that are expected to improve outcomes, reduce the total cost of care, and lead to more profitable operations.

[0000926326-25-000003:mdna:36]
CRITICAL ACCOUNTING ESTIMATES

[0000926326-25-000003:mdna:37]
Our discussion and analysis of our financial condition and results of operations are based on our Consolidated Financial Statements, which have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting estimates are affected by significant judgments used in the preparation of our Consolidated Financial Statements:

[0000926326-25-000003:mdna:38]
Revenue Recognition

[0000926326-25-000003:mdna:39]
We earn revenues from sales of our products and related services, which are sold in the healthcare industry, our principal market. Many of our sales contain multiple performance obligations, with a combination of hardware systems, software products, support and maintenance, and professional services.

[0000926326-25-000003:mdna:40]
A significant level of judgment is involved in contractual arrangements with multiple performance obligations to determine appropriate allocation of the transaction price. We allocate the transaction price to separate performance obligations based on the estimated standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price we would charge for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual technical services contracts, our products and services are not generally sold separately. We use an amount discounted from the list price as a best estimated standalone selling price.

[0000926326-25-000003:mdna:41]
Additionally, judgment is required to determine the timing of revenue recognition for each performance obligation based upon when control transfers to a customer. We review our performance obligations in a contract and evaluate when transfer of control occurs. Generally, for products requiring a complex implementation, control passes when the product is installed and functionally ready for use. For all other products, control generally passes when product has been shipped and title has passed. For support and maintenance contracts and certain other services, including SaaS and Expert Services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term. Time and material services transfer control to the customer at the time the services are provided.

[0000926326-25-000003:mdna:42]
These judgments have been applied consistently for all periods presented. Changes in the assumptions or judgements used in determining the standalone selling price or timing of revenue recognition could impact the amount and timing of revenue reported in a particular period.

[0000926326-25-000003:mdna:43]
Inventory

[0000926326-25-000003:mdna:44]
Inventories are stated at the lower of cost, computed using the first-in, first-out method, and net realizable value. We regularly monitor inventory quantities on hand and record write-downs for excess and obsolete inventories based on our estimate of demand for our products, potential obsolescence of technology, product life cycles, and whether pricing trends or forecasts indicate that the carrying value of inventory exceeds its estimated selling price. These factors are impacted by market and economic conditions, technology changes, and new product introductions and require estimates that may include elements that are uncertain. Actual demand may differ from forecasted demand and may have a material effect on gross margins. If inventory is written down, a new cost basis is established that cannot be increased in future periods. Changes in our

[0000926326-25-000003:mdna:45]
assumptions, judgments, or estimates could impact future financial results if additional write-downs for excess and obsolete inventories are needed.

[0000926326-25-000003:mdna:46]
Accounting for Income Taxes

[0000926326-25-000003:mdna:47]
We make certain estimates and judgments in determining income tax expense or benefit for financial statement purposes. These estimates and judgments occur in the calculation of income tax credits, uncertain tax positions, and in the calculation of certain tax assets and liabilities, which arise from differences in the timing of the recognition of certain income and expenses for tax and financial statement purposes. We assess the likelihood of the realization of deferred tax assets and the need for a valuation allowance in each reporting period. In reaching our conclusion, we evaluate certain relevant criteria as provided in ASC 740, Income Taxes, including having sufficient taxable income of the appropriate character in future years. Our judgment regarding future taxable income may change due to future changes in the company’s profitability due to market conditions, changes in U.S. or international tax laws, and other factors. Changes in judgment may require material adjustments to deferred tax assets, which may result in an increase or decrease to our income tax provision in the period of adjustment.

[0000926326-25-000003:mdna:48]
As a global company, we use significant judgment to calculate and provide for income taxes in each of the tax jurisdictions in which we operate. In the ordinary course of business, transactions and calculations occur whose ultimate tax outcome cannot be certain. Some of these uncertainties arise due to transfer pricing for transactions with our subsidiaries and the determination of tax nexus.

[0000926326-25-000003:mdna:49]
We account for uncertain tax positions in accordance with ASC 740. We estimate and recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained upon examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of ASC 740 and complex tax laws.

[0000926326-25-000003:mdna:50]
Although we believe our estimates are reasonable, there is no guarantee that the final tax outcome will not differ from what is reflected in our historical income tax provisions, returns, and accruals. Such differences, or changes in estimates relating to potential differences, could have a material impact on our income tax provision and operating results in the period such determination is made.

[0000926326-25-000003:mdna:51]
Recently Issued Authoritative Guidance

[0000926326-25-000003:mdna:52]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Consolidated Financial Statements in this Annual Report on Form 10-K for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-25-000003:mdna:53]
RESULTS OF OPERATIONS

[0000926326-25-000003:mdna:54]
Total Revenues

[0000926326-25-000003:mdna:55]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2024 |  | 2023 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Product revenues | $ | 630,507 |  |  | $ | 708,561 |  |  | $ | (78,054) |  |  | (11)% |  |  |  |  |  |  |
| Percentage of total revenues | 57% |  | 62% |  |  |  |  |  |  |  |  |  |  |
| Service revenues | 481,731 |  |  | 438,551 |  |  | 43,180 |  |  | 10% |  |  |  |  |  |  |
| Percentage of total revenues | 43% |  | 38% |  |  |  |  |  |  |  |  |  |  |
| Total revenues | $ | 1,112,238 |  |  | $ | 1,147,112 |  |  | $ | (34,874) |  |  | (3)% |  |  |  |  |  |  |

[0000926326-25-000003:mdna:56]
Product revenues represented 57% and 62% of total revenues for the years ended December 31, 2024 and 2023, respectively. Product revenues decreased by $78.1 million, primarily due to a challenging environment through a significant portion of 2024 for some of our health system customers and the timing of our XT Series systems lifecycle, as we are largely through the replacement cycle.

[0000926326-25-000003:mdna:57]
Service revenues represented 43% and 38% of total revenues for the years ended December 31, 2024 and 2023, respectively. Services and other revenues include revenues from technical services and SaaS and Expert Services offerings. Service revenues increased by $43.2 million, primarily due to an increase of $12.4 million in technical services revenues as a

[0000926326-25-000003:mdna:58]
result of growth in our installed customer base and the impact of pricing actions, as well as an increase of $30.8 million in SaaS and Expert Services revenues due to continued customer demand.

[0000926326-25-000003:mdna:59]
Our international sales represented 9% and 12% of total revenues for the years ended December 31, 2024 and 2023, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-25-000003:mdna:60]
Our ability to grow revenues is dependent on our ability to continue to obtain orders from customers, which may be dependent upon customers’ capital equipment budgets and/or capital equipment approval cycles, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, our ability to develop new or enhance existing solutions, and our flexibility in workforce allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules and/or staffing levels allow for installations.

[0000926326-25-000003:mdna:61]
Cost of Revenues and Gross Profit

[0000926326-25-000003:mdna:62]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which account for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product, and overhead costs associated with production; (ii) costs of providing services and installation costs, including costs of personnel and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, provisions for excess and obsolete inventory, and amortization of software development costs and intangibles.

[0000926326-25-000003:mdna:63]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2024 |  | 2023 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 383,025 |  |  | $ | 414,106 |  |  | $ | (31,081) |  |  | (8)% |  |  |  |  |  |  |
| As a percentage of related revenues | 61% |  | 58% |  |  |  |  |  |  |  |  |  |  |
| Cost of service revenues | 258,210 |  |  | 236,166 |  |  | 22,044 |  |  | 9% |  |  |  |  |  |  |
| As a percentage of related revenues | 54% |  | 54% |  |  |  |  |  |  |  |  |  |  |
| Total cost of revenues | $ | 641,235 |  |  | $ | 650,272 |  |  | $ | (9,037) |  |  | (1)% |  |  |  |  |  |  |
| As a percentage of total revenues | 58% |  | 57% |  |  |  |  |  |  |  |  |  |  |
| Gross profit | $ | 471,003 |  |  | $ | 496,840 |  |  | $ | (25,837) |  |  | (5)% |  |  |  |  |  |  |
| Gross margin | 42% |  | 43% |  |  |  |  |  |  |  |  |  |  |

[0000926326-25-000003:mdna:64]
Cost of revenues for the year ended December 31, 2024 compared to the year ended December 31, 2023 decreased by $9.0 million, primarily driven by a $31.1 million decrease in cost of product revenues, partially offset by a $22.0 million increase in cost of service revenues.

[0000926326-25-000003:mdna:65]
The decrease in cost of product revenues was primarily driven by the decrease in product revenues of $78.1 million for the year ended December 31, 2024 compared to the year ended December 31, 2023. The decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues for the year ended December 31, 2024, primarily due to the decrease in revenues of higher margin products as well as the impact of certain fixed costs, such as labor and overhead. In addition, the decrease in cost of product revenues was partially offset by $5.4 million of inventory write-down charges related to the Company’s Medimat Robotic Dispensing System (“RDS”) product line wind down incurred during the year ended December 31, 2024 and an increase of $2.9 million of restructuring costs for the year ended December 31, 2024 compared to the year ended December 31, 2023. The increase in cost of service revenues was primarily driven by the increase in service revenues of $43.2 million for the year ended December 31, 2024 compared to the year ended December 31, 2023.

[0000926326-25-000003:mdna:66]
The overall decrease in gross margin primarily relates to lower product revenues for the year ended December 31, 2024 compared to the year ended December 31, 2023 whereas the decrease in cost of product revenues has not decreased proportionally with the decrease in product revenues, primarily due to the decrease in revenues of higher margin products as well as the impact of certain fixed costs, such as labor and overhead. The decrease in cost of product revenues is partially offset by inventory write-down charges related to the RDS product line wind down and an increase in restructuring costs incurred during the year ended December 31, 2024. Our gross profit for the year ended December 31, 2024 was $471.0 million, as compared to $496.8 million for the year ended December 31, 2023.

[0000926326-25-000003:mdna:67]
Operating Expenses and Interest and Other Income (Expense), Net

[0000926326-25-000003:mdna:68]
|  | Year Ended December 31, |  | Change in |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | $ |  | % |  |  |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 90,412 |  |  | $ | 97,115 |  |  | $ | (6,703) |  |  | (7)% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 380,254 |  |  | 434,593 |  |  | (54,339) |  |  | (13)% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 34% |  | 38% |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 470,666 |  |  | $ | 531,708 |  |  | $ | (61,042) |  |  | (11)% |  |  |  |  |  |  |  |  |
| As a percentage of total revenues | 42% |  | 46% |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other income (expense), net | $ | 25,256 |  |  | $ | 14,760 |  |  | $ | 10,496 |  |  | 71% |  |  |  |  |  |  |  |  |

[0000926326-25-000003:mdna:69]
Research and Development. Research and development expenses decreased by $6.7 million for the year ended December 31, 2024 compared to the year ended December 31, 2023. The decrease was primarily attributed to a decrease of $10.8 million in employee-related expenses primarily as a result of lower headcount and a decrease of $3.4 million in restructuring costs, partially offset by an increase of $3.8 million in cloud hosting services expenses, and an increase of $3.1 million in consulting expenses.

[0000926326-25-000003:mdna:70]
Selling, General, and Administrative. Selling, general, and administrative expenses decreased by $54.3 million for the year ended December 31, 2024 compared to the year ended December 31, 2023. The decrease was primarily due to a decrease of $23.3 million in employee-related expenses primarily as a result of lower headcount, a decrease of $11.0 million in impairment and abandonment charges of operating lease right-of-use and other assets in connection with restructuring activities of certain leased facilities, a decrease of $8.4 million in restructuring costs, a decrease of $4.1 million in commissions expenses, a decrease of $2.9 million in freight out, and a decrease of $2.2 million in executives transition costs.

[0000926326-25-000003:mdna:71]
Interest and Other Income (Expense), Net. Interest and other income (expense), net, changed by $10.5 million for the year ended December 31, 2024 compared to the year ended December 31, 2023, primarily driven by a $12.2 million increase in other income and a $1.7 million increase in other expense. The increase in other income during the year ended December 31, 2024 compared to the year ended December 31, 2023 is primarily attributable to a $7.5 million gain on extinguishment of convertible senior notes and related unwind of note hedges and warrants, as well as higher interest income received due to higher interest rates and higher cash and cash equivalents balances throughout the majority of the year.

[0000926326-25-000003:mdna:72]
Provision for Income Taxes

[0000926326-25-000003:mdna:73]
|  | Year Ended December 31, |  | Change in |  |  |  |  |
|  | 2024 |  | 2023 |  | $ |  | % |  |  |  |  |  |  |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 13,062 |  |  | $ | 263 |  |  | $ | 12,799 |  |  | 4,867% |  |  |  |  |  |  |
| Effective tax rate on earnings | 51% |  | (1)% |  |  |  |  |  |  |  |  |  |  |

[0000926326-25-000003:mdna:74]
We recorded an income tax expense of $13.1 million on an income before income taxes of $25.6 million, which resulted in a positive effective tax rate of 51% for the year ended December 31, 2024, compared to an income tax expense of $0.3 million on a loss before income taxes of $20.1 million, which resulted in a negative effective tax rate of 1% for the year ended December 31, 2023. The 2024 annual effective tax rate differed from the statutory tax rate of 21%, primarily due to an unfavorable impact of non-deductible equity compensation charges partially offset by a favorable impact of research and development credits.

[0000926326-25-000003:mdna:75]
Refer to Note 17, Income Taxes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-25-000003:mdna:76]
LIQUIDITY AND CAPITAL RESOURCES

[0000926326-25-000003:mdna:77]
We had cash and cash equivalents of $369.2 million at December 31, 2024, compared to $468.0 million at December 31, 2023. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with financial institutions of high credit quality.

[0000926326-25-000003:mdna:78]
Our cash position and working capital at December 31, 2024 and 2023 were as follows:

[0000926326-25-000003:mdna:79]
|  | December 31, |
|  | 2024 |  | 2023 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 369,201 |  |  | $ | 467,972 |  |
| Working capital (1) | $ | 219,815 |  |  | $ | 559,779 |  |

[0000926326-25-000003:mdna:80]
(1)    The decrease in working capital as of December 31, 2024 was partially due to the classification of our convertible senior notes as a current rather than long-term liability. Refer to Note 11, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-25-000003:mdna:81]
Our ratio of current assets to current liabilities was 1.4:1 and 2.5:1 at December 31, 2024 and 2023, respectively.

[0000926326-25-000003:mdna:82]
Sources of Cash

[0000926326-25-000003:mdna:83]
Revolving Credit Facility

[0000926326-25-000003:mdna:84]
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023 to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 11, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K), expand our flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-25-000003:mdna:85]
On October 10, 2023, Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-25-000003:mdna:86]
As of December 31, 2024, we had $350.0 million of funds available under the Current Revolving Credit Facility. As of December 31, 2024, there was no outstanding balance under the Current Revolving Credit Facility and we were in full compliance with all covenants.

[0000926326-25-000003:mdna:87]
Refer to Note 10, Debt and Credit Agreement, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-25-000003:mdna:88]
Convertible Senior Notes

[0000926326-25-000003:mdna:89]
On November 22, 2024, Omnicell, Inc. completed a private offering of $172.5 million aggregate principal amount of 1.00% Convertible Senior Notes due 2029 (the “2029 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $22.5 million aggregate principal amount of the 2029 Notes. Omnicell, Inc. received proceeds from the issuance of the 2029 Notes of $166.3 million, net of $6.2 million of transaction fees and other debt issuance costs. The 2029 Notes bear interest at a rate of 1.00% per year, payable semiannually in arrears on June 1 and December 1 of each year, beginning on June 1, 2025. The 2029 Notes are general senior, unsecured obligations of Omnicell, Inc. and will mature on December 1, 2029, unless earlier redeemed, repurchased, or converted. In connection with the issuance of the 2029 Notes, in November 2024, we entered into warrant transactions and received aggregate proceeds from the sale of the warrants of approximately $25.2 million. Refer to Note 11, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-25-000003:mdna:90]
Uses of Cash

[0000926326-25-000003:mdna:91]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, and other contractual obligations. We may also use cash for potential acquisitions and acquisition-related activities, as well as repurchases of our common stock. In addition, we may also use a portion of our cash as we consider various options related to our outstanding debt.

[0000926326-25-000003:mdna:92]
The 2016 Repurchase Program has a total of $2.7 million remaining for future repurchases as of December 31, 2024, which may result in additional use of cash. There were no stock repurchases during the year ended December 31, 2024. Refer to Note 16, Stock Repurchase Programs, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-25-000003:mdna:93]
In November 2024, we completed a partial repurchase of $400.0 million aggregate principal amount of the 2025 Notes for approximately $391.2 million in cash. Refer to Note 11, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-25-000003:mdna:94]
In connection with the issuance of the 2029 Notes, in November 2024, we entered into convertible note hedge transactions and used approximately $40.3 million of the net proceeds from the offering to pay the cost of the convertible note hedges.

[0000926326-25-000003:mdna:95]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, outstanding debt, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the growth of our business.

[0000926326-25-000003:mdna:96]
Cash Flows

[0000926326-25-000003:mdna:97]
The following table summarizes, for the periods indicated, selected items in our Consolidated Statements of Cash Flows:

[0000926326-25-000003:mdna:98]
|  | Year Ended December 31, |
|  | 2024 |  | 2023 |  |  |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |  |  |
| Operating activities | $ | 187,722 |  |  | $ | 181,094 |  |  |  |
| Investing activities | (52,793) |  |  | (55,016) |  |  |  |
| Financing activities | (235,578) |  |  | 23,420 |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,716) |  |  | (1,354) |  |  |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | (102,365) |  |  | $ | 148,144 |  |  |  |

[0000926326-25-000003:mdna:99]
Operating Activities

[0000926326-25-000003:mdna:100]
We expect cash from our operating activities to fluctuate in future periods as a result of a number of factors, including the timing of our billings and collections, our operating results, and the timing of other liability payments.

[0000926326-25-000003:mdna:101]
Net cash provided by operating activities was $187.7 million for the year ended December 31, 2024, primarily consisting of operating inflows of $129.4 million and favorable working capital movements of $58.3 million. Operating inflows consisted of net income of $12.5 million, adjusted for non-cash items of $116.9 million, which consisted primarily of depreciation and amortization expense of $82.2 million, share-based compensation expense of $39.3 million, amortization of operating lease right-of-use assets of $7.5 million, a net gain on extinguishment of convertible senior notes of $7.5 million, inventory write-down charges of $5.4 million, and a change in deferred income taxes of $14.9 million. The favorable working capital was primarily due to an increase in deferred revenues of $29.0 million driven by an increase in billings for certain technical service and SaaS and Expert Services offerings, a decrease in inventories of $15.6 million resulting from inventory management initiatives, an increase in accrued liabilities of $13.9 million due to an increase in taxes payable, a decrease in other current assets of $9.3 million due to a decrease in income taxes receivable, an increase in accrued compensation of $8.6 million, and an increase in accounts payables of $7.2 million. These cash inflows were partially offset by a decrease in operating lease liabilities of $10.7 million, an increase in investment in sales-type leases of $10.4 million primarily due to the acceptance of certain SaaS and Expert Services products under sales-type lease arrangements, and an increase in accounts receivable and unbilled receivables of $5.0 million primarily due to the timing of billings, shipments, and collections.

[0000926326-25-000003:mdna:102]
Net cash provided by operating activities was $181.1 million for the year ended December 31, 2023, primarily consisting of operating inflows of $137.4 million and favorable working capital movements of $43.7 million. Operating inflows consisted of net loss of $20.4 million, adjusted for non-cash items of $157.8 million, which consisted primarily of depreciation and amortization expense of $87.3 million, share-based compensation expense of $55.3 million, impairment and abandonment of operating lease right-of-use assets related to facilities of $10.0 million, amortization of operating lease right-of-use assets of $8.2 million, and a change in deferred income taxes of $11.0 million. The favorable working capital was primarily due to a decrease in accounts receivable and unbilled receivables of $49.2 million primarily due to the timing of billings, shipments, and collections, as well as the impacts of lower revenues, a decrease in inventories of $38.0 million primarily due to management of inventory levels to align with the current forecasted demand, an increase in deferred revenues of $24.1 million primarily due to an increase in billings for certain technical service and SaaS and Expert Services offerings, and a decrease in prepaid commissions of $7.1 million. These cash inflows were partially offset by a decrease in accrued compensation of $21.5 million primarily due to a decrease in the accrual for restructuring initiatives, lower commissions, as well as timing of ESPP purchases, a decrease in accounts payables of $17.5 million primarily due to an overall decrease in spending, as well as timing of payments, a decrease in operating lease liabilities of $10.9 million, an increase in investment in sales-type leases of $10.4 million primarily due to the acceptance of certain SaaS and Expert Services products under sales-type lease arrangements, a decrease in accrued liabilities of $10.3 million, and an increase in other current assets of $6.8 million.

[0000926326-25-000003:mdna:103]
Investing Activities

[0000926326-25-000003:mdna:104]
Net cash used in investing activities was $52.8 million for the year ended December 31, 2024, which consisted of capital expenditures of $36.5 million for property and equipment and $16.3 million for external-use software development costs.

[0000926326-25-000003:mdna:105]
Net cash used in investing activities was $55.0 million for the year ended December 31, 2023, which consisted of capital expenditures of $41.5 million for property and equipment and $13.5 million for external-use software development costs.

[0000926326-25-000003:mdna:106]
Financing Activities

[0000926326-25-000003:mdna:107]
Net cash used in financing activities was $235.6 million for the year ended December 31, 2024, primarily due to the partial repurchase of $400.0 million of aggregate principal amount of the 2025 Notes for approximately $391.0 million and the net cash used in the purchase of the convertible note hedge and sale of warrants in connection with the 2029 Notes of $15.1 million, partially offset by net proceeds from the issuance of the 2029 Notes of $166.3 million and $13.4 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-25-000003:mdna:108]
Net cash provided by financing activities was $23.4 million for the year ended December 31, 2023, primarily due to $23.2 million in proceeds from employee stock option exercises and ESPP purchases and a net change in the customer funds balances of $10.5 million, partially offset by $7.4 million in employees’ taxes paid related to restricted stock unit vesting.

[0000926326-25-000003:mdna:109]
Contractual Obligations

[0000926326-25-000003:mdna:110]
Contractual obligations as of December 31, 2024 were as follows:

[0000926326-25-000003:mdna:111]
|  | Payments Due By Period |
|  | Total |  | 2025 |  | 2026 - 2027 |  | 2028 - 2029 |  | 2030 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 46,952 |  |  | $ | 12,787 |  |  | $ | 22,127 |  |  | $ | 10,506 |  |  | $ | 1,532 |  |
| Purchase obligations (2) | 118,776 |  |  | 109,316 |  |  | 9,439 |  |  | 21 |  |  | — |  |
| Convertible senior notes (3) | 356,606 |  |  | 177,201 |  |  | 3,450 |  |  | 175,955 |  |  | — |  |
| Total (4) | $ | 522,334 |  |  | $ | 299,304 |  |  | $ | 35,016 |  |  | $ | 186,482 |  |  | $ | 1,532 |  |

[0000926326-25-000003:mdna:112]
_________________________________________________

[0000926326-25-000003:mdna:113]
(1)Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 13, Lessee Leases, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-25-000003:mdna:114]
(2)We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. These amounts are associated with agreements that are enforceable and legally binding. The amounts under such contracts are included in the table above because we believe that cancellation of these contracts is unlikely and we expect to make future cash payments according to the contract terms or in similar amounts for similar materials.

[0000926326-25-000003:mdna:115]
(3)We issued the 2025 Notes in September 2020 that are due in September 2025 and issued the 2029 Notes in November 2024 that are due in December 2029. The obligations presented above include both principal and interest these notes. Although these notes mature in 2025 and 2029, respectively, they may be converted into cash and shares of our common stock prior to maturity if certain conditions are met. Any conversion prior to maturity can result in repayment of the principal amounts sooner than the scheduled repayment as indicated in the table above. Refer to Note 11, Convertible Senior Notes, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.

[0000926326-25-000003:mdna:116]
(4)Refer to Note 14, Commitments and Contingencies, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K for additional information.
