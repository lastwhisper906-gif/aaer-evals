# OMCL note change history — 0000926326-24-000027 → 0000926326-24-000032


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0000926326-24-000032:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2024, the Company had non-cancelable purchase commitments of $111.2 million, of which $71.4 million are expected to be paid within the year ending December 31, 2024.
  (was, 2024-08-06, similarity 0.9765):
[0000926326-24-000027:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2024, the Company had non-cancelable purchase commitments of $107.9 million, of which $87.3 million are expected to be paid within the year ending December 31, 2024.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0000926326-24-000032:note_history:2]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2024 and December 31, 2023, the results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2024 and 2023, and cash flows for the nine months ended September 30, 2024 and 2023. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on February 28, 2024. The Company’s results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2024, and cash flows for the nine months ended September 30, 2024 are not necessarily indicative of results that may be expected for the year ending December 31, 2024, or for any future period.
  (was, 2024-08-06, similarity 0.8255):
[0000926326-24-000027:note_history:2]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2024 and December 31, 2023, the results of operations and comprehensive income (loss) for the three and six months ended June 30, 2024 and 2023, and cash flows for the six months ended June 30, 2024 and 2023. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on February 28, 2024. The Company’s results of operations and comprehensive income (loss) for the three and six months ended June 30, 2024, and cash flows for the six months ended June 30, 2024 are not necessarily indicative of results that may be expected for the year ending December 31, 2024, or for any future period.

- added (2024-11-08):
[0000926326-24-000032:note_history:3]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of September 30, 2024, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

- changed (2024-11-08):
[0000926326-24-000032:note_history:4]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires public entities to disclose significant segment expenses that are regularly provided to the CODM. Public entities with a single reportable segment are required to apply the disclosure requirements in ASU 2023-07, as well as all existing segment disclosures and reconciliation requirements in ASC 280, on an interim and annual basis. The amendments are effective for the Company’s annual periods beginning January 1, 2024, and for interim periods within fiscal years beginning January 1, 2025. Retrospective application is required, with early adoption permitted. The Company does not expect the adoption of ASU 2023-07 to have a material impact on its balance sheets, statements of operations, or statements of cash flows, as the anticipated changes will be the inclusion of additional disclosures related to the Company’s single reportable segment.
  (was, 2024-08-06, similarity 0.8089):
[0000926326-24-000027:note_history:4]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires public entities to disclose significant segment expenses that are regularly provided to the CODM. Public entities with a single reportable segment are required to apply the disclosure requirements in ASU 2023-07, as well as all existing segment disclosures and reconciliation requirements in ASC 280, on an interim and annual basis. The amendments are effective for the Company’s annual periods beginning January 1, 2024, and for interim periods within fiscal years beginning January 1, 2025. Retrospective application is required, with early adoption permitted. The Company is currently evaluating the impact ASU 2023-07 will have on its consolidated financial statements.

- removed (2024-11-08):
[0000926326-24-000027:note_history:5]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of June 30, 2024, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0000926326-24-000032:note_history:6]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2024 and 2023:
  (was, 2024-08-06, similarity 0.9055):
[0000926326-24-000027:note_history:6]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2024 and 2023:

- added (2024-11-08):
[0000926326-24-000032:note_history:7]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of debt issuance costs | $ | 780 |  |  | $ | 773 |  |  | $ | 2,335 |  |  | $ | 2,316 |  |

- removed (2024-11-08):
[0000926326-24-000027:note_history:8]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of debt issuance costs | $ | 778 |  |  | $ | 772 |  |  | $ | 1,555 |  |  | $ | 1,543 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0000926326-24-000032:note_history:9]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2024 and December 31, 2023:
  (was, 2024-08-06, similarity 0.9591):
[0000926326-24-000027:note_history:9]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2024 and December 31, 2023:

- changed (2024-11-08):
[0000926326-24-000032:note_history:10]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (3,003) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 571,997 |  |  | $ | 569,662 |  |
  (was, 2024-08-06, similarity 0.9189):
[0000926326-24-000027:note_history:10]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (3,783) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 571,217 |  |  | $ | 569,662 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0000926326-24-000032:note_history:11]
Loans under the Current Revolving Credit Facility bear interest, at Omnicell, Inc.’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility Omnicell, Inc. is permitted to
  (was, 2024-08-06, similarity 0.9456):
[0000926326-24-000027:note_history:11]
Loans under the Current Revolving Credit Facility bear interest, at Omnicell, Inc.’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility Omnicell, Inc. is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current

- changed (2024-11-08):
[0000926326-24-000032:note_history:12]
make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.
  (was, 2024-08-06, similarity 0.7116):
[0000926326-24-000027:note_history:12]
Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

- added (2024-11-08):
[0000926326-24-000032:note_history:13]
As of both September 30, 2024 and December 31, 2023, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of September 30, 2024 and December 31, 2023, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of September 30, 2024.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- changed (2024-11-08):
[0000926326-24-000032:note_history:14]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on
  (was, 2024-08-06, similarity 0.9381):
[0000926326-24-000027:note_history:14]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

- added (2024-11-08):
[0000926326-24-000032:note_history:15]
the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

- added (2024-11-08):
[0000926326-24-000032:note_history:16]
During the three months ended September 30, 2024 and December 31, 2023, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the fourth quarter of 2024, commencing on October 1, 2024, and were not convertible during the first quarter of 2024, commencing on January 1, 2024. As such, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of December 31, 2023. As the Notes will mature on September 15, 2025, the Company classified the Notes as a current liability as of September 30, 2024. Whether the Notes will be convertible following the fourth fiscal quarter of 2024 will depend on the satisfaction of the conversion conditions in the future.

- changed (2024-11-08):
[0000926326-24-000032:note_history:17]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2024, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2024-08-06, similarity 0.8042):
[0000926326-24-000027:note_history:17]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2024, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- changed (2024-11-08):
[0000926326-24-000032:note_history:18]
As of September 30, 2024, the Company may redeem for cash all or any portion of the Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.
  (was, 2024-08-06, similarity 0.993):
[0000926326-24-000027:note_history:18]
As of June 30, 2024, the Company may redeem for cash all or any portion of the Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

- changed (2024-11-08):
[0000926326-24-000032:note_history:19]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of September 30, 2024, the remaining life of the Notes and the related issuance cost accretion is approximately 1.0 year.
  (was, 2024-08-06, similarity 0.9742):
[0000926326-24-000027:note_history:19]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of June 30, 2024, the remaining life of the Notes and the related issuance cost accretion is approximately 1.2 years.

- changed (2024-11-08):
[0000926326-24-000032:note_history:20]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of September 30, 2024, the if-converted value of the Notes did not exceed the principal amount.
  (was, 2024-08-06, similarity 0.7317):
[0000926326-24-000027:note_history:20]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of June 30, 2024, the if-converted value of the Notes did not exceed the principal amount.

- changed (2024-11-08):
[0000926326-24-000032:note_history:21]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2024 and December 31, 2023:
  (was, 2024-08-06, similarity 0.9591):
[0000926326-24-000027:note_history:21]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2024 and December 31, 2023:

- changed (2024-11-08):
[0000926326-24-000032:note_history:22]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (3,003) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 571,997 |  |  | $ | 569,662 |  |
  (was, 2024-08-06, similarity 0.9189):
[0000926326-24-000027:note_history:22]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (3,783) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 571,217 |  |  | $ | 569,662 |  |

- changed (2024-11-08):
[0000926326-24-000032:note_history:23]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2024 and 2023:
  (was, 2024-08-06, similarity 0.9055):
[0000926326-24-000027:note_history:23]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2024 and 2023:

- added (2024-11-08):
[0000926326-24-000032:note_history:24]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of debt issuance costs | $ | 780 |  |  | $ | 773 |  |  | $ | 2,335 |  |  | $ | 2,316 |  |

- removed (2024-11-08):
[0000926326-24-000027:note_history:25]
As of both June 30, 2024 and December 31, 2023, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of June 30, 2024 and December 31, 2023, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of June 30, 2024.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- removed (2024-11-08):
[0000926326-24-000027:note_history:26]
During the three months ended June 30, 2024 and December 31, 2023, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the third quarter of 2024, commencing on July 1, 2024, and were not convertible during the first quarter of 2024, commencing on January 1, 2024. Accordingly, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of both June 30, 2024 and December 31, 2023. Whether the Notes will be convertible following the third fiscal quarter of 2024 will depend on the satisfaction of the conversion conditions in the future.

- removed (2024-11-08):
[0000926326-24-000027:note_history:27]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 719 |  |  | $ | 719 |  |
| Amortization of debt issuance costs | $ | 778 |  |  | $ | 772 |  |  | $ | 1,555 |  |  | $ | 1,543 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-11-08):
[0000926326-24-000032:note_history:28]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.5 million and $3.6 million for the three months ended September 30, 2024 and 2023, respectively, and $6.9 million and $9.5 million for the nine months ended September 30, 2024 and 2023, respectively.
  (was, 2024-08-06, similarity 0.9623):
[0000926326-24-000027:note_history:28]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.4 million and $2.8 million for the three months ended June 30, 2024 and 2023, respectively, and $4.4 million and $5.9 million for the six months ended June 30, 2024 and 2023, respectively.

- changed (2024-11-08):
[0000926326-24-000032:note_history:29]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and nine months ended September 30, 2024 and 2023:
  (was, 2024-08-06, similarity 0.9416):
[0000926326-24-000027:note_history:29]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and six months ended June 30, 2024 and 2023:

- changed (2024-11-08):
[0000926326-24-000032:note_history:30]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 135,672 |  |  | $ | 167,560 |  |  | $ | 381,280 |  |  | $ | 500,182 |  |
| Consumables | 22,689 |  |  | 21,195 |  |  | 66,956 |  |  | 62,724 |  |
| Technical services | 59,583 |  |  | 57,303 |  |  | 177,419 |  |  | 167,851 |  |
| Advanced Services | 64,476 |  |  | 52,605 |  |  | 179,704 |  |  | 157,508 |  |
| Total revenues | $ | 282,420 |  |  | $ | 298,663 |  |  | $ | 805,359 |  |  | $ | 888,265 |  |
  (was, 2024-08-06, similarity 0.9142):
[0000926326-24-000027:note_history:30]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 134,539 |  |  | $ | 167,475 |  |  | $ | 245,608 |  |  | $ | 332,622 |  |
| Consumables | 22,041 |  |  | 20,961 |  |  | 44,267 |  |  | 41,529 |  |
| Technical services | 59,321 |  |  | 57,191 |  |  | 117,836 |  |  | 110,548 |  |
| Advanced Services | 60,887 |  |  | 53,346 |  |  | 115,228 |  |  | 104,903 |  |
| Total revenues | $ | 276,788 |  |  | $ | 298,973 |  |  | $ | 522,939 |  |  | $ | 589,602 |  |

- changed (2024-11-08):
[0000926326-24-000032:note_history:31]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2024 and 2023:
  (was, 2024-08-06, similarity 0.9581):
[0000926326-24-000027:note_history:31]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2024 and 2023:

- changed (2024-11-08):
[0000926326-24-000032:note_history:32]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| United States | $ | 258,177 |  |  | $ | 272,649 |  |  | $ | 731,670 |  |  | $ | 785,794 |  |
| Rest of world (1) | 24,243 |  |  | 26,014 |  |  | 73,689 |  |  | 102,471 |  |
| Total revenues | $ | 282,420 |  |  | $ | 298,663 |  |  | $ | 805,359 |  |  | $ | 888,265 |  |
  (was, 2024-08-06, similarity 0.8752):
[0000926326-24-000027:note_history:32]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| United States | $ | 255,317 |  |  | $ | 257,202 |  |  | $ | 473,493 |  |  | $ | 513,145 |  |
| Rest of world (1) | 21,471 |  |  | 41,771 |  |  | 49,446 |  |  | 76,457 |  |
| Total revenues | $ | 276,788 |  |  | $ | 298,973 |  |  | $ | 522,939 |  |  | $ | 589,602 |  |

- changed (2024-11-08):
[0000926326-24-000032:note_history:33]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 33,722 |  |  | $ | 22,524 |  |
| Long-term unbilled receivables, net (2) | 9,171 |  |  | 11,850 |  |
| Total contract assets | $ | 42,893 |  |  | $ | 34,374 |  |
| Short-term deferred revenues | $ | 152,367 |  |  | $ | 121,734 |  |
| Long-term deferred revenues | 69,811 |  |  | 58,622 |  |
| Total contract liabilities | $ | 222,178 |  |  | $ | 180,356 |  |
  (was, 2024-08-06, similarity 0.9828):
[0000926326-24-000027:note_history:33]
|  | June 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 25,122 |  |  | $ | 22,524 |  |
| Long-term unbilled receivables, net (2) | 9,901 |  |  | 11,850 |  |
| Total contract assets | $ | 35,023 |  |  | $ | 34,374 |  |
| Short-term deferred revenues | $ | 150,316 |  |  | $ | 121,734 |  |
| Long-term deferred revenues | 67,931 |  |  | 58,622 |  |
| Total contract liabilities | $ | 218,247 |  |  | $ | 180,356 |  |

- changed (2024-11-08):
[0000926326-24-000032:note_history:34]
Short-term deferred revenues of $121.7 million as of December 31, 2023 include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.4 million. During the three and nine months ended September 30, 2024, the Company recognized revenues of $21.6 million and $106.6 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.1 million as of December 31, 2023.
  (was, 2024-08-06, similarity 0.9423):
[0000926326-24-000027:note_history:34]
Short-term deferred revenues of $121.7 million as of December 31, 2023 include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.4 million. During the three and six months ended June 30, 2024, the Company recognized revenues of $34.8 million and $85.0 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.1 million as of December 31, 2023.

- changed (2024-11-08):
[0000926326-24-000032:note_history:35]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $403.0 million as of September 30, 2024. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.
  (was, 2024-08-06, similarity 0.9935):
[0000926326-24-000027:note_history:35]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $387.7 million as of June 30, 2024. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

- changed (2024-11-08):
[0000926326-24-000032:note_history:36]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2024 and 2023. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable and unbilled receivables balances as of September 30, 2024 and December 31, 2023.
  (was, 2024-08-06, similarity 0.7436):
[0000926326-24-000027:note_history:36]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2024 and 2023. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of June 30, 2024 and December 31, 2023.
