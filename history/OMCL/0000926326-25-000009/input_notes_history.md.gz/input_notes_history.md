# OMCL note change history — 0000926326-24-000032 → 0000926326-25-000009


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2025-05-07):
[0000926326-25-000009:note_history:1]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any other current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters either cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.

- added (2025-05-07):
[0000926326-25-000009:note_history:2]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company’s financial position or results of operations.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000926326-25-000009:note_history:3]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2025, the Company had non-cancelable purchase commitments of $129.3 million, of which $109.1 million are expected to be paid within the year ending December 31, 2025.
  (was, 2024-11-08, similarity 0.9747):
[0000926326-24-000032:note_history:3]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2024, the Company had non-cancelable purchase commitments of $111.2 million, of which $71.4 million are expected to be paid within the year ending December 31, 2024.

- added (2025-05-07):
[0000926326-25-000009:note_history:4]
In December 2023, Omnicell received a civil request for records issued by the U.S. Attorney’s Office for the Eastern District of Washington (the “Government”) related to the Company’s compliance with the pricing terms and conditions of its previous Federal Supply Schedule (“FSS”) contract with the federal government. In December 2024, the Government presented information identifying certain potential non-compliances with the FSS contract and associated potential violations of the False Claims Act. On May 5, 2025, Omnicell entered into a settlement agreement with the Government to resolve this matter. The settlement, which will require payment of approximately $4.6 million to cover damages and other statutorily provided amounts under the False Claims Act, settles the matter without admission of liability.

- changed (2025-05-07):
[0000926326-25-000009:note_history:5]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any other current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters either cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.
  (was, 2024-11-08, similarity 0.9208):
[0000926326-24-000032:note_history:5]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in such matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000926326-25-000009:note_history:6]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products and related services are medication management solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States. “Omnicell” or the “Company” refer to Omnicell, Inc. and its subsidiaries, collectively.
  (was, 2024-11-08, similarity 0.9893):
[0000926326-24-000032:note_history:6]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products and related services are medication management solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” refer to Omnicell, Inc. and its subsidiaries, collectively.

- changed (2025-05-07):
[0000926326-25-000009:note_history:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2025 and December 31, 2024, and the results of operations, comprehensive loss, and cash flows for the three months ended March 31, 2025 and 2024. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2024, filed with the SEC on February 27, 2025. The Company’s results of operations, comprehensive loss, and cash flows for the three months ended March 31, 2025 are not necessarily indicative of results that may be expected for the year ending December 31, 2025, or for any future period.
  (was, 2024-11-08, similarity 0.8673):
[0000926326-24-000032:note_history:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2024 and December 31, 2023, the results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2024 and 2023, and cash flows for the nine months ended September 30, 2024 and 2023. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on February 28, 2024. The Company’s results of operations and comprehensive income (loss) for the three and nine months ended September 30, 2024, and cash flows for the nine months ended September 30, 2024 are not necessarily indicative of results that may be expected for the year ending December 31, 2024, or for any future period.

- changed (2025-05-07):
[0000926326-25-000009:note_history:8]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes to Condensed Consolidated Financial Statements. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting estimates are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. Those estimates are revenue recognition, inventory valuation, and accounting for income taxes. As of March 31, 2025, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.
  (was, 2024-11-08, similarity 0.6832):
[0000926326-24-000032:note_history:8]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.

- added (2025-05-07):
[0000926326-25-000009:note_history:9]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company at the consolidated level using the Company’s consolidated net income (loss). In addition, the CODM is provided with certain segment assets and liabilities, primarily those that impact liquidity, as well as certain significant expenses. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment. Refer to Note 2, Segment Information, for further information regarding the Company’s segment disclosures.

- changed (2025-05-07):
[0000926326-25-000009:note_history:10]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning January 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2023-09 will have on its consolidated financial statements, which is limited to financial statements disclosures.
  (was, 2024-11-08, similarity 0.8817):
[0000926326-24-000032:note_history:10]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning January 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2023-09 will have on its consolidated financial statements.

- changed (2025-05-07):
[0000926326-25-000009:note_history:11]
In March 2024, the SEC issued final rules under SEC Release No. 33-11275, “The Enhancement and Standardization of Climate-Related Disclosures for Investors,” to require registrants to disclose certain climate-related information, including Scope 1 and Scope 2 greenhouse gas emissions and other climate-related topics, if material, in registration statements and annual reports. In April 2024, the SEC voluntarily stayed its climate disclosure rules as a result of pending legal challenges to facilitate an orderly judicial resolution. In March 2025, the SEC stated that it has ended its defense of the rule. The Company will continue to monitor any developments in the SEC’s rule and related litigation to determine what, if any, impact it will have on its consolidated financial statement disclosures.
  (was, 2024-11-08, similarity 0.7366):
[0000926326-24-000032:note_history:11]
In March 2024, the SEC issued final rules under SEC Release No. 33-11275, “The Enhancement and Standardization of Climate-Related Disclosures for Investors,” to require registrants to disclose certain climate-related information, including Scope 1 and Scope 2 greenhouse gas emissions and other climate-related topics, if material, in registration statements and annual reports. In April 2024, the SEC voluntarily stayed its climate disclosure rules as a result of pending legal challenges to facilitate an orderly judicial resolution. The Company is currently evaluating the impact the SEC’s rule will have on its consolidated financial statements.

- added (2025-05-07):
[0000926326-25-000009:note_history:12]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosure (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosures of additional information and disaggregation of certain expenses included in the income statement. The amendments are effective for the Company’s annual periods beginning January 1, 2027, and for interim periods within fiscal years beginning January 1, 2028, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2024-03 will have on its consolidated financial statements.

- removed (2025-05-07):
[0000926326-24-000032:note_history:13]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of September 30, 2024, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

- removed (2025-05-07):
[0000926326-24-000032:note_history:14]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.

- removed (2025-05-07):
[0000926326-24-000032:note_history:15]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires public entities to disclose significant segment expenses that are regularly provided to the CODM. Public entities with a single reportable segment are required to apply the disclosure requirements in ASU 2023-07, as well as all existing segment disclosures and reconciliation requirements in ASC 280, on an interim and annual basis. The amendments are effective for the Company’s annual periods beginning January 1, 2024, and for interim periods within fiscal years beginning January 1, 2025. Retrospective application is required, with early adoption permitted. The Company does not expect the adoption of ASU 2023-07 to have a material impact on its balance sheets, statements of operations, or statements of cash flows, as the anticipated changes will be the inclusion of additional disclosures related to the Company’s single reportable segment.


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000926326-25-000009:note_history:16]
The following table summarizes the components of interest expense resulting from the 2025 Notes and the 2029 Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations:
  (was, 2024-11-08, similarity 0.8445):
[0000926326-24-000032:note_history:16]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2024 and 2023:

- added (2025-05-07):
[0000926326-25-000009:note_history:17]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes |  |  |  |  | $ | 109 |  |  | $ | 359 |  |
| 2029 Notes |  |  |  |  | 431 |  |  | — |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes |  |  |  |  | $ | 238 |  |  | $ | 777 |  |
| 2029 Notes |  |  |  |  | 303 |  |  | — |  |

- removed (2025-05-07):
[0000926326-24-000032:note_history:18]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of debt issuance costs | $ | 780 |  |  | $ | 773 |  |  | $ | 2,335 |  |  | $ | 2,316 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-05-07):
[0000926326-25-000009:note_history:19]
The 2025 Notes and the 2029 Notes consisted of the following balances:

- added (2025-05-07):
[0000926326-25-000009:note_history:20]
|  | March 31,2025 |  | December 31,2024 |
|  | (In thousands) |
| 2025 Notes: |  |  |  |
| Principal amount | $ | 175,000 |  |  | $ | 175,000 |  |
| Unamortized debt issuance costs | (438) |  |  | (676) |  |
| Convertible senior notes, net, current | $ | 174,562 |  |  | $ | 174,324 |  |
| 2029 Notes: |  |  |  |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (5,800) |  |  | (6,103) |  |
| Convertible senior notes, net, noncurrent | $ | 166,700 |  |  | $ | 166,397 |  |

- removed (2025-05-07):
[0000926326-24-000032:note_history:21]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2024 and December 31, 2023:

- removed (2025-05-07):
[0000926326-24-000032:note_history:22]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (3,003) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 571,997 |  |  | $ | 569,662 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000926326-25-000009:note_history:23]
Debt and Credit Agreement
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. As referred to in this Note 10, “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023, to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 11, Convertible Senior Notes), expand the Company’s flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.
  (was, 2024-11-08, similarity 0.9641):
[0000926326-24-000032:note_history:23]
Debt and Credit Agreement
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. As referred to herein, “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023, to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q), expand the Company’s flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

- changed (2025-05-07):
[0000926326-25-000009:note_history:24]
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The
  (was, 2024-11-08, similarity 0.9165):
[0000926326-24-000032:note_history:24]
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

- added (2025-05-07):
[0000926326-25-000009:note_history:25]
Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

- changed (2025-05-07):
[0000926326-25-000009:note_history:26]
Loans under the Current Revolving Credit Facility bear interest, at Omnicell, Inc.’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility Omnicell, Inc. is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.
  (was, 2024-11-08, similarity 0.8858):
[0000926326-24-000032:note_history:26]
Loans under the Current Revolving Credit Facility bear interest, at Omnicell, Inc.’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility Omnicell, Inc. is permitted to

- added (2025-05-07):
[0000926326-25-000009:note_history:27]
On November 18, 2024, Omnicell, Inc., as borrower, entered into a First Amendment to Second Amended and Restated Credit Agreement (the “Amendment”) with the lenders party thereto from time to time, and Wells Fargo Bank, National Association, as administrative agent for the lenders. Pursuant to the Amendment, effective as of November 19, 2024, the springing maturity for the revolving credit facility that is tied to the outstanding principal amount of Omnicell, Inc.’s existing 0.25% Convertible Senior Notes due 2025 (the “2025 Notes”) will apply only if more than $200 million in the aggregate principal amount of Omnicell, Inc.’s 2025 Notes remain outstanding as of 91 days prior to the maturity date of the 2025 Notes.

- changed (2025-05-07):
[0000926326-25-000009:note_history:28]
As of both March 31, 2025 and December 31, 2024, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of March 31, 2025 and December 31, 2024, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of March 31, 2025.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025
  (was, 2024-11-08, similarity 0.944):
[0000926326-24-000032:note_history:28]
As of both September 30, 2024 and December 31, 2023, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of September 30, 2024 and December 31, 2023, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of September 30, 2024.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- added (2025-05-07):
[0000926326-25-000009:note_history:29]
On September 25, 2020, Omnicell, Inc. completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “2025 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the 2025 Notes. As referred to in this Note 11, “Omnicell, Inc.” or the “Company” refers only to Omnicell, Inc., excluding its subsidiaries. Omnicell, Inc. received proceeds from the issuance of the 2025 Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The 2025 Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The 2025 Notes were issued pursuant to an indenture, dated September 25, 2020 (the “2025 Notes Indenture”), between the Company and U.S. Bank National Association, as trustee. The 2025 Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

- added (2025-05-07):
[0000926326-25-000009:note_history:30]
The 2025 Notes are convertible at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for

- changed (2025-05-07):
[0000926326-25-000009:note_history:31]
at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2025 Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the 2025 Notes Indenture) per $1,000 principal amount of the 2025 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the 2025 Notes on each such trading day; (iii) if the Company calls such 2025 Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the 2025 Notes called (or deemed called) for redemption; or (iv) upon the occurrence of specified corporate events, as specified in the 2025 Notes Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the 2025 Notes may convert all or any portion of their 2025 Notes at any time, regardless of the foregoing conditions.
  (was, 2024-11-08, similarity 0.7615):
[0000926326-24-000032:note_history:31]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on

- added (2025-05-07):
[0000926326-25-000009:note_history:32]
During the three months ended March 31, 2025 and December 31, 2024, none of the conditional conversion features of the 2025 Notes were triggered, and therefore, the 2025 Notes are not convertible during the second quarter of 2025, commencing on April 1, 2025, and were not convertible during the first quarter of 2025, commencing on January 1, 2025. As the 2025 Notes will mature on September 15, 2025, the Company classified the 2025 Notes as a current liability in its Condensed Consolidated Financial Statements as of both March 31, 2025 and December 31, 2024.

- changed (2025-05-07):
[0000926326-25-000009:note_history:33]
Under the original terms of the 2025 Notes Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the 2025 Notes Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of 2025 Notes of at least $1,000. As a result, for 2025 Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of 2025 Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of 2025 Notes above $1,000. The initial conversion rate for the 2025 Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of 2025 Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the 2025 Notes Indenture. In addition, following certain corporate events that could occur prior to the maturity date of the 2025 Notes or if the Company delivers a notice of redemption in respect of the 2025 Notes, the Company will, under certain circumstances, increase the conversion rate of the 2025 Notes for a holder who elects to convert its 2025 Notes (or any portion thereof) in connection with such a corporate event or convert its 2025 Notes called (or deemed called) for redemption during the related redemption period (as defined in the 2025 Notes Indenture), as the case may be.
  (was, 2024-11-08, similarity 0.9451):
[0000926326-24-000032:note_history:33]
Under the original terms of the Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of Notes of at least $1,000. As a result, for Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of Notes above $1,000. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that could occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

- added (2025-05-07):
[0000926326-25-000009:note_history:34]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2025 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2025 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2025, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- changed (2025-05-07):
[0000926326-25-000009:note_history:35]
As of March 31, 2025, the Company may redeem for cash all or any portion of the 2025 Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the 2025 Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2025 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding 2025 Notes, at least $150.0 million aggregate principal amount of the 2025 Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the 2025 Notes.
  (was, 2024-11-08, similarity 0.9841):
[0000926326-24-000032:note_history:35]
As of September 30, 2024, the Company may redeem for cash all or any portion of the Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

- added (2025-05-07):
[0000926326-25-000009:note_history:36]
Partial Repurchase of the 2025 Notes

- added (2025-05-07):
[0000926326-25-000009:note_history:37]
In November 2024, the Company entered into separate, privately negotiated transactions with certain holders of the 2025 Notes to repurchase $400.0 million of aggregate principal amount of the 2025 Notes for approximately $391.0 million of cash. The Company accounted for the partial repurchase of 2025 Notes as a debt extinguishment and recorded a $7.2 million gain on extinguishment, which included a partial write-off of previously deferred debt issuance costs of $1.8 million during the three months ended December 31, 2024.

- changed (2025-05-07):
[0000926326-25-000009:note_history:38]
The debt issuance costs associated with the remaining 2025 Notes are being amortized to interest expense over the term of the 2025 Notes using an effective interest rate of 0.80%. As of March 31, 2025, the remaining life of the 2025 Notes and the related issuance cost accretion is approximately 0.5 years.
  (was, 2024-11-08, similarity 0.9016):
[0000926326-24-000032:note_history:38]
The debt issuance costs associated with the Notes are being amortized to interest expense over the term of the Notes using an effective interest rate of 0.80%. As of September 30, 2024, the remaining life of the Notes and the related issuance cost accretion is approximately 1.0 year.

- added (2025-05-07):
[0000926326-25-000009:note_history:39]
Following the partial repurchase of the 2025 Notes, the maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 1.8 million shares. As of March 31, 2025, the if-converted value of the 2025 Notes did not exceed the principal amount.

- added (2025-05-07):
[0000926326-25-000009:note_history:40]
1.00% Convertible Senior Notes due 2029

- added (2025-05-07):
[0000926326-25-000009:note_history:41]
On November 22, 2024, Omnicell, Inc. completed a private offering of $172.5 million aggregate principal amount of 1.00% Convertible Senior Notes due 2029 (the “2029 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $22.5 million aggregate principal amount of the 2029 Notes. Omnicell, Inc. received proceeds from the issuance of the 2029 Notes of $166.3 million, net of $6.2 million of transaction fees and other debt issuance costs. The 2029 Notes bear interest at a rate of 1.00% per year, payable semiannually in arrears on June 1 and December 1 of each year, beginning on June 1, 2025. The 2029 Notes were issued pursuant to an indenture, dated November 22, 2024 (the “2029 Notes Indenture”), between the Company and U.S. Bank Trust Company, National Association, as trustee. The 2029 Notes are general senior, unsecured obligations of the Company and will mature on December 1, 2029, unless earlier redeemed, purchased, or converted.

- added (2025-05-07):
[0000926326-25-000009:note_history:42]
The 2029 Notes are convertible at any time prior to the close of business on the business day immediately preceding August 1, 2029, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ending on March 31, 2025 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2029 Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the “trading price” (as defined in the 2029 Notes Indenture) per $1,000 principal amount of the 2029 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the 2029 Notes on each such trading day; (iii) if the Company calls such 2029 Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the 2029 Notes called (or deemed called) for redemption; or (iv) upon the occurrence of specified corporate events as set forth in the 2029 Notes Indenture. On or after August 1, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the 2029 Notes may convert all or any portion of their 2029 Notes at any time, regardless of the foregoing conditions.

- added (2025-05-07):
[0000926326-25-000009:note_history:43]
During the three months ended March 31, 2025 and December 31, 2024, none of the conditional conversion features of the 2029 Notes were triggered, and therefore, the 2029 Notes are not convertible during the second quarter of 2025, commencing on April 1, 2025, and were not convertible during the first quarter of 2025, commencing on January 1, 2025.

- added (2025-05-07):
[0000926326-25-000009:note_history:44]
Upon conversion, the Company will pay cash up to the aggregate principal amount of the 2029 Notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination of cash and shares of the Company’s common stock, at the Company’s election, in respect to the remainder, if any, of the Company’s conversion obligation in excess of the aggregate principal amount of the 2029 Notes being converted, in the manner and subject to the terms and conditions provided in the 2029 Notes Indenture.

- added (2025-05-07):
[0000926326-25-000009:note_history:45]
The initial conversion rate for the 2029 Notes is 17.4662 shares of the Company’s common stock per $1,000 principal amount of the 2029 Notes, which is equivalent to an initial conversion price of approximately $57.25 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the 2029 Notes Indenture. In addition, following certain corporate events that occur prior to the maturity date of the 2029 Notes or if the Company delivers a notice of redemption in respect of the 2029 Notes, the Company will, under certain circumstances, increase the conversion rate of the 2029 Notes for a holder who elects to convert its 2029 Notes (or any portion thereof) in connection with such a corporate event or convert its 2029 Notes called (or deemed called) for redemption during the related redemption period (as defined in the 2029 Notes Indenture), as the case may be.

- added (2025-05-07):
[0000926326-25-000009:note_history:46]
If the Company undergoes a fundamental change (as defined in the 2029 Notes Indenture), holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2029 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2025, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- added (2025-05-07):
[0000926326-25-000009:note_history:47]
The Company may not redeem the 2029 Notes prior to December 6, 2027. The Company may redeem for cash all or any portion of the 2029 Notes, at its option, on or after December 6, 2027, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the 2029 Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption

- added (2025-05-07):
[0000926326-25-000009:note_history:48]
at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. The Company may not redeem less than all of the outstanding 2029 Notes unless at least $100.0 million aggregate principal amount of 2029 Notes are outstanding and not called for redemption as of the time the Company sends the related notice of redemption. No sinking fund is provided for in the 2029 Notes.

- added (2025-05-07):
[0000926326-25-000009:note_history:49]
The debt issuance costs associated with the 2029 Notes are being amortized to interest expense over the term of the 2029 Notes using an effective interest rate of 1.75%. As of March 31, 2025, the remaining life of the 2029 Notes and the related issuance cost accretion is approximately 4.7 years.

- changed (2025-05-07):
[0000926326-25-000009:note_history:50]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 3.0 million shares. As of March 31, 2025, the if-converted value of the 2029 Notes did not exceed the principal amount.
  (was, 2024-11-08, similarity 0.9701):
[0000926326-24-000032:note_history:50]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of September 30, 2024, the if-converted value of the Notes did not exceed the principal amount.

- added (2025-05-07):
[0000926326-25-000009:note_history:51]
The 2025 Notes and the 2029 Notes consisted of the following balances:

- added (2025-05-07):
[0000926326-25-000009:note_history:52]
|  | March 31,2025 |  | December 31,2024 |
|  | (In thousands) |
| 2025 Notes: |  |  |  |
| Principal amount | $ | 175,000 |  |  | $ | 175,000 |  |
| Unamortized debt issuance costs | (438) |  |  | (676) |  |
| Convertible senior notes, net, current | $ | 174,562 |  |  | $ | 174,324 |  |
| 2029 Notes: |  |  |  |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (5,800) |  |  | (6,103) |  |
| Convertible senior notes, net, noncurrent | $ | 166,700 |  |  | $ | 166,397 |  |

- changed (2025-05-07):
[0000926326-25-000009:note_history:53]
The following table summarizes the components of interest expense resulting from the 2025 Notes and the 2029 Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations:
  (was, 2024-11-08, similarity 0.8445):
[0000926326-24-000032:note_history:53]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2024 and 2023:

- added (2025-05-07):
[0000926326-25-000009:note_history:54]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes |  |  |  |  | $ | 109 |  |  | $ | 359 |  |
| 2029 Notes |  |  |  |  | 431 |  |  | — |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes |  |  |  |  | $ | 238 |  |  | $ | 777 |  |
| 2029 Notes |  |  |  |  | 303 |  |  | — |  |

- changed (2025-05-07):
[0000926326-25-000009:note_history:55]
In connection with the issuance of the 2025 Notes in September 2020 and the 2029 Notes in November 2024, the Company entered into convertible note hedges and warrants transactions, respectively, with certain initial purchasers of the 2025 Notes and the 2029 Notes or affiliates thereof and certain other financial institutions (the “option counterparties”).
  (was, 2024-11-08, similarity 0.6348):
[0000926326-24-000032:note_history:55]
In connection with the issuance of the Notes in September 2020, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

- added (2025-05-07):
[0000926326-25-000009:note_history:56]
The convertible note hedges related to the 2025 Notes consisted of call options for the Company to purchase, subject to anti-dilution adjustments substantially similar to those applicable to the 2025 Notes, up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2025 Notes at the time of its issuance, at an initial strike price of approximately $97.32 per share. The convertible note hedges related to the 2029 Notes consisted of call options for the Company to purchase up to, subject to anti-dilution adjustments substantially similar to those applicable to the 2029 Notes, approximately 3.0 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2029 Notes at the time of its issuance, at an initial strike price of approximately $57.25 per share. The convertible note hedges will expire upon the maturity of the respective convertible notes, if not earlier exercised or terminated. The cost of the convertible note hedges related to the 2025 Notes and

- added (2025-05-07):
[0000926326-25-000009:note_history:57]
the 2029 Notes was approximately $100.6 million and $40.3 million, respectively, and each was accounted for as an equity instrument, each of which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. In addition, the Company recorded a deferred tax asset of $25.8 million and $10.2 million, respectively, at issuance related to the convertible note hedges for the 2025 Notes and the 2029 Notes. The convertible note hedges are expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of the 2025 Notes or the 2029 Notes and/or offset any cash payments the Company may be required to make in excess of the principal amount of the converted 2025 Notes or the 2029 Notes.

- added (2025-05-07):
[0000926326-25-000009:note_history:58]
Separately from the convertible note hedges, in September 2020 and November 2024, the Company entered into warrant transactions to sell to the respective option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock at an initial strike price of approximately $141.56 and approximately 3.0 million shares of its common stock at an initial strike price of approximately $84.82 per share related to the 2025 Notes and the 2029 Notes, respectively. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million and $25.2 million for the issuance of the warrants related to the 2025 Notes and the 2029 Notes, respectively, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock, as measured under the warrants, exceeds the strike price of the warrants.
In November 2024, in connection with the partial repurchase of the 2025 Notes, the Company entered into unwind agreements with the existing option counterparties to the convertible note hedges and warrants related to the 2025 Notes to terminate a portion of the existing convertible note hedges and warrants related to the 2025 Notes at a notional amount corresponding to the amount of the 2025 Notes repurchased, resulting in an immaterial gain

- removed (2025-05-07):
[0000926326-24-000032:note_history:59]
make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

- removed (2025-05-07):
[0000926326-24-000032:note_history:60]
The refinancing of the Prior Credit Agreement on October 10, 2023 was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the Second A&R Credit Agreement. The Company incurred and capitalized an additional $3.0 million of debt issuance costs which are being amortized to interest expense using the straight-line method through 2028.

- removed (2025-05-07):
[0000926326-24-000032:note_history:61]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

- removed (2025-05-07):
[0000926326-24-000032:note_history:62]
the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

- removed (2025-05-07):
[0000926326-24-000032:note_history:63]
During the three months ended September 30, 2024 and December 31, 2023, none of the conditional conversion features of the Notes were triggered, and therefore, the Notes are not convertible during the fourth quarter of 2024, commencing on October 1, 2024, and were not convertible during the first quarter of 2024, commencing on January 1, 2024. As such, the Company classified the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of December 31, 2023. As the Notes will mature on September 15, 2025, the Company classified the Notes as a current liability as of September 30, 2024. Whether the Notes will be convertible following the fourth fiscal quarter of 2024 will depend on the satisfaction of the conversion conditions in the future.

- removed (2025-05-07):
[0000926326-24-000032:note_history:64]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2024, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- removed (2025-05-07):
[0000926326-24-000032:note_history:65]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2024 and December 31, 2023:

- removed (2025-05-07):
[0000926326-24-000032:note_history:66]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized debt issuance costs | (3,003) |  |  | (5,338) |  |
| Convertible senior notes, net | $ | 571,997 |  |  | $ | 569,662 |  |

- removed (2025-05-07):
[0000926326-24-000032:note_history:67]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  | $ | 1,078 |  |  | $ | 1,078 |  |
| Amortization of debt issuance costs | $ | 780 |  |  | $ | 773 |  |  | $ | 2,335 |  |  | $ | 2,316 |  |

- removed (2025-05-07):
[0000926326-24-000032:note_history:68]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.

- removed (2025-05-07):
[0000926326-24-000032:note_history:69]
Separately from the convertible note hedge, in September 2020, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-05-07):
[0000926326-25-000009:note_history:70]
The following table summarizes the carrying amounts, net of unamortized debt issuance costs, and fair values of the convertible senior notes:

- added (2025-05-07):
[0000926326-25-000009:note_history:71]
|  | March 31,2025 |  | December 31,2024 |
|  | (In thousands) |
| Net carrying amount: |  |  |  |
| 2025 Notes | 174,562 |  |  | 174,324 |  |
| 2029 Notes | 166,700 |  |  | 166,397 |  |
| Total net carrying amount | $ | 341,262 |  |  | $ | 340,721 |  |
| Fair value: |  |  |  |
| 2025 Notes | $ | 170,518 |  |  | $ | 167,129 |  |
| 2029 Notes | 161,546 |  |  | 181,320 |  |
| Total fair value | $ | 332,064 |  |  | $ | 348,449 |  |


## omcl:RevenueFromContractWithCustomerTimingAndClassificationOfRevenueCategoriesTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000926326-25-000009:note_history:72]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to, or receipt by, customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| SaaS and Expert Services |  |  |  | Over time, as services are provided |  | Service |
  (was, 2024-11-08, similarity 0.8217):
[0000926326-24-000032:note_history:72]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to, or receipt by, the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2025-05-07):
[0000926326-25-000009:note_history:73]
The following table summarizes the Company’s revenues disaggregated by revenue type:

- added (2025-05-07):
[0000926326-25-000009:note_history:74]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (In thousands) |
| Connected devices, software licenses, and other |  |  |  |  | $ | 120,077 |  |  | $ | 111,069 |  |
| Consumables |  |  |  |  | 25,091 |  |  | 22,226 |  |
| Technical services |  |  |  |  | 61,379 |  |  | 58,515 |  |
| SaaS and Expert Services |  |  |  |  | 63,121 |  |  | 54,341 |  |
| Total revenues |  |  |  |  | $ | 269,668 |  |  | $ | 246,151 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000926326-25-000009:note_history:75]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, and are designed to improve patient engagement and adherence to prescriptions.
  (was, 2024-11-08, similarity 0.9951):
[0000926326-24-000032:note_history:75]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, are designed to improve patient engagement and adherence to prescriptions.

- changed (2025-05-07):
[0000926326-25-000009:note_history:76]
Technical services. Post-installation technical support and other related services (support and maintenance), including phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.
  (was, 2024-11-08, similarity 0.9591):
[0000926326-24-000032:note_history:76]
Technical services. Post-installation technical support and other related services, including phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.

- changed (2025-05-07):
[0000926326-25-000009:note_history:77]
Software as a Service (“SaaS”) and Expert Services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.
  (was, 2024-11-08, similarity 0.9492):
[0000926326-24-000032:note_history:77]
Advanced Services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.

- changed (2025-05-07):
[0000926326-25-000009:note_history:78]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to, or receipt by, customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| SaaS and Expert Services |  |  |  | Over time, as services are provided |  | Service |
  (was, 2024-11-08, similarity 0.8217):
[0000926326-24-000032:note_history:78]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to, or receipt by, the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000926326-25-000009:note_history:79]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, and are designed to improve patient engagement and adherence to prescriptions.
  (was, 2024-11-08, similarity 0.9951):
[0000926326-24-000032:note_history:79]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, are designed to improve patient engagement and adherence to prescriptions.

- changed (2025-05-07):
[0000926326-25-000009:note_history:80]
Technical services. Post-installation technical support and other related services (support and maintenance), including phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.
  (was, 2024-11-08, similarity 0.9591):
[0000926326-24-000032:note_history:80]
Technical services. Post-installation technical support and other related services, including phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.

- changed (2025-05-07):
[0000926326-25-000009:note_history:81]
Software as a Service (“SaaS”) and Expert Services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.
  (was, 2024-11-08, similarity 0.9492):
[0000926326-24-000032:note_history:81]
Advanced Services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.

- changed (2025-05-07):
[0000926326-25-000009:note_history:82]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to, or receipt by, customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| SaaS and Expert Services |  |  |  | Over time, as services are provided |  | Service |
  (was, 2024-11-08, similarity 0.8217):
[0000926326-24-000032:note_history:82]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to, or receipt by, the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Advanced Services |  |  |  | Over time, as services are provided |  | Service |

- changed (2025-05-07):
[0000926326-25-000009:note_history:83]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.2 million and $2.0 million for the three months ended March 31, 2025 and 2024, respectively.
  (was, 2024-11-08, similarity 0.9322):
[0000926326-24-000032:note_history:83]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.5 million and $3.6 million for the three months ended September 30, 2024 and 2023, respectively, and $6.9 million and $9.5 million for the nine months ended September 30, 2024 and 2023, respectively.

- changed (2025-05-07):
[0000926326-25-000009:note_history:84]
The following table summarizes the Company’s revenues disaggregated by revenue type:
  (was, 2024-11-08, similarity 0.75):
[0000926326-24-000032:note_history:84]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and nine months ended September 30, 2024 and 2023:

- added (2025-05-07):
[0000926326-25-000009:note_history:85]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (In thousands) |
| Connected devices, software licenses, and other |  |  |  |  | $ | 120,077 |  |  | $ | 111,069 |  |
| Consumables |  |  |  |  | 25,091 |  |  | 22,226 |  |
| Technical services |  |  |  |  | 61,379 |  |  | 58,515 |  |
| SaaS and Expert Services |  |  |  |  | 63,121 |  |  | 54,341 |  |
| Total revenues |  |  |  |  | $ | 269,668 |  |  | $ | 246,151 |  |

- changed (2025-05-07):
[0000926326-25-000009:note_history:86]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location:
  (was, 2024-11-08, similarity 0.8278):
[0000926326-24-000032:note_history:86]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2024 and 2023:

- added (2025-05-07):
[0000926326-25-000009:note_history:87]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (In thousands) |
| United States |  |  |  |  | $ | 249,264 |  |  | $ | 218,176 |  |
| Rest of world (1) |  |  |  |  | 20,404 |  |  | 27,975 |  |
| Total revenues |  |  |  |  | $ | 269,668 |  |  | $ | 246,151 |  |

- changed (2025-05-07):
[0000926326-25-000009:note_history:88]
|  | March 31,2025 |  | December 31,2024 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 33,422 |  |  | $ | 32,917 |  |
| Long-term unbilled receivables, net (2) | 6,703 |  |  | 7,873 |  |
| Total contract assets | $ | 40,125 |  |  | $ | 40,790 |  |
| Short-term deferred revenues | $ | 159,995 |  |  | $ | 141,370 |  |
| Long-term deferred revenues | 78,370 |  |  | 76,123 |  |
| Total contract liabilities | $ | 238,365 |  |  | $ | 217,493 |  |
  (was, 2024-11-08, similarity 0.9815):
[0000926326-24-000032:note_history:88]
|  | September 30,2024 |  | December 31,2023 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 33,722 |  |  | $ | 22,524 |  |
| Long-term unbilled receivables, net (2) | 9,171 |  |  | 11,850 |  |
| Total contract assets | $ | 42,893 |  |  | $ | 34,374 |  |
| Short-term deferred revenues | $ | 152,367 |  |  | $ | 121,734 |  |
| Long-term deferred revenues | 69,811 |  |  | 58,622 |  |
| Total contract liabilities | $ | 222,178 |  |  | $ | 180,356 |  |

- added (2025-05-07):
[0000926326-25-000009:note_history:89]
During the three months ended March 31, 2025, the Company recognized revenues of $54.2 million that were included in the corresponding gross short-term deferred revenues balance of $141.4 million as of December 31, 2024.

- added (2025-05-07):
[0000926326-25-000009:note_history:90]
Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, but services have not yet been provided. Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term technical and SaaS and Expert Services contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time. SaaS and Expert Services agreements are generally invoiced periodically on a monthly, quarterly or annual basis over the life of the agreement. In certain circumstances portions of these agreements may be invoiced lump sum.

- changed (2025-05-07):
[0000926326-25-000009:note_history:91]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and SaaS and Expert Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $390.4 million as of March 31, 2025. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.
  (was, 2024-11-08, similarity 0.9815):
[0000926326-24-000032:note_history:91]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and Advanced Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $403.0 million as of September 30, 2024. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

- changed (2025-05-07):
[0000926326-25-000009:note_history:92]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2025 and 2024. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable and unbilled receivables balance as of March 31, 2025 and December 31, 2024.
  (was, 2024-11-08, similarity 0.8026):
[0000926326-24-000032:note_history:92]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2024 and 2023. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable and unbilled receivables balances as of September 30, 2024 and December 31, 2023.

- removed (2025-05-07):
[0000926326-24-000032:note_history:93]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 135,672 |  |  | $ | 167,560 |  |  | $ | 381,280 |  |  | $ | 500,182 |  |
| Consumables | 22,689 |  |  | 21,195 |  |  | 66,956 |  |  | 62,724 |  |
| Technical services | 59,583 |  |  | 57,303 |  |  | 177,419 |  |  | 167,851 |  |
| Advanced Services | 64,476 |  |  | 52,605 |  |  | 179,704 |  |  | 157,508 |  |
| Total revenues | $ | 282,420 |  |  | $ | 298,663 |  |  | $ | 805,359 |  |  | $ | 888,265 |  |

- removed (2025-05-07):
[0000926326-24-000032:note_history:94]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  | (In thousands) |
| United States | $ | 258,177 |  |  | $ | 272,649 |  |  | $ | 731,670 |  |  | $ | 785,794 |  |
| Rest of world (1) | 24,243 |  |  | 26,014 |  |  | 73,689 |  |  | 102,471 |  |
| Total revenues | $ | 282,420 |  |  | $ | 298,663 |  |  | $ | 805,359 |  |  | $ | 888,265 |  |

- removed (2025-05-07):
[0000926326-24-000032:note_history:95]
Short-term deferred revenues of $121.7 million as of December 31, 2023 include deferred revenues from product sales and service contracts, net of deferred cost of sales of $12.4 million. During the three and nine months ended September 30, 2024, the Company recognized revenues of $21.6 million and $106.6 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $134.1 million as of December 31, 2023.

- removed (2025-05-07):
[0000926326-24-000032:note_history:96]
Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, where services have not yet been provided. Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term technical and Advanced Services contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time. Advanced Services agreements are generally invoiced periodically on a monthly, quarterly or annual basis over the life of the agreement. In certain circumstances, portions of these agreements may be invoiced as a lump sum.
