# OMCL MD&A — 0000926326-25-000009


## mdna

[0000926326-25-000009:mdna:1]
[same as prior period, unchanged from 0000926326-24-000032:mdna:1]

[0000926326-25-000009:mdna:2]
[same as prior period, unchanged from 0000926326-24-000032:mdna:2]

[0000926326-25-000009:mdna:3]
The following risks related to our business, among others, could cause actual results to differ materially from those described in the forward-looking statements:

[0000926326-25-000009:mdna:4]
•unfavorable general economic and market conditions;

[0000926326-25-000009:mdna:5]
•our ability to take advantage of growth opportunities and develop and commercialize new solutions and enhance existing solutions, including incorporating artificial intelligence technology;

[0000926326-25-000009:mdna:6]
•reductions in demand in the capital equipment market or reductions in the demand for or adoption of our solutions, systems, or services;

[0000926326-25-000009:mdna:7]
•delays in installations of our medication management solutions or our more complex medication packaging systems;

[0000926326-25-000009:mdna:8]
•transitioning to selling more products and services on a subscription basis;

[0000926326-25-000009:mdna:9]
•our ability to acquire companies, businesses, or technologies and successfully integrate such acquisitions;

[0000926326-25-000009:mdna:10]
•failing to maintain expected service levels when providing our SaaS and Expert Services or retaining our SaaS and Expert Services customers;

[0000926326-25-000009:mdna:11]
•meeting the demands of, or maintain relationships with, institutional, retail, and specialty pharmacy customers;

[0000926326-25-000009:mdna:12]
•investments in new business strategies or initiatives;

[0000926326-25-000009:mdna:13]
•continued and increased competition from current and future competitors in the medication management automation solutions market and the medication adherence solutions market;

[0000926326-25-000009:mdna:14]
•our substantial debt obligations;

[0000926326-25-000009:mdna:15]
•disruptions to our information technology systems and breaches of data security or cyber-attacks on our systems or solutions;

[0000926326-25-000009:mdna:16]
•effectiveness of business continuity plans during any future cybersecurity incidents;

[0000926326-25-000009:mdna:17]
•government regulations, legislative changes, fraud and anti-kickback statues, products liability claims, the outcome of legal proceedings, and other legal obligations related to healthcare, privacy, data protection, and information security, and the costs of compliance with, and potential liability associated with, our actual or perceived failure to comply with such obligations;

[0000926326-25-000009:mdna:18]
•changes to the 340B Program;

[0000926326-25-000009:mdna:19]
•operating in foreign countries, including the potential impact of tariffs;

[0000926326-25-000009:mdna:20]
•covenants in our credit agreement could restrict our business and operations;

[0000926326-25-000009:mdna:21]
•climate change, legal, regulatory or market measures to address climate change and a focus on ESG matters by various stakeholders;

[0000926326-25-000009:mdna:22]
•recruiting and retaining skilled and motivated personnel;

[0000926326-25-000009:mdna:23]
•protecting our intellectual property;

[0000926326-25-000009:mdna:24]
•availability and sources of raw materials and components or price fluctuations, shortages, or interruptions of supply;

[0000926326-25-000009:mdna:25]
•dependence on a limited number of suppliers for certain components, equipment, and raw materials, as well as technologies provided by third-party vendors;

[0000926326-25-000009:mdna:26]
•fluctuations in quarterly and annual operating results;

[0000926326-25-000009:mdna:27]
•failing to meet (or significantly exceeding) our publicly announced financial guidance; and

[0000926326-25-000009:mdna:28]
•other factors set forth under “Risk Factors”.

[0000926326-25-000009:mdna:29]
[same as prior period, unchanged from 0000926326-24-000032:mdna:19]

[0000926326-25-000009:mdna:30]
[same as prior period, unchanged from 0000926326-24-000032:mdna:20]

[0000926326-25-000009:mdna:31]
[same as prior period, unchanged from 0000926326-24-000032:mdna:21]

[0000926326-25-000009:mdna:32]
[same as prior period, unchanged from 0000926326-24-000032:mdna:22]

[0000926326-25-000009:mdna:33]
[same as prior period, unchanged from 0000926326-24-000032:mdna:23]

[0000926326-25-000009:mdna:34]
Omnicell, a leader in transforming the pharmacy and nursing care delivery model, is committed to solving the critical challenges inherent in medication management and elevating the role of clinicians within healthcare as an essential component of care delivery. Omnicell is focused on helping its customers define and deliver a cost-effective medication management strategy designed to equip and empower pharmacists and nurses to focus on patient care rather than administrative tasks, and to drive improved clinical, operational, and financial outcomes across all care settings. We are doing this with an industry-leading medication management infrastructure which includes robotics and smart devices, software workflows, expert services, and operational and optimization analytics. This comprehensive set of solutions provides the critical foundation for customers to realize the Autonomous Pharmacy, an industry-wide vision defined by pharmacy leaders for improving operational efficiencies and ultimately targeting zero-error medication management.

[0000926326-25-000009:mdna:35]
Omnicell solutions are helping healthcare facilities worldwide to uncover cost savings, improve labor efficiency, establish new revenue streams, enhance supply chain control, support compliance, and move closer to the industry-defined vision of the Autonomous Pharmacy. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 92% and 89% of our total revenues for the three months ended March 31, 2025 and 2024, respectively.

[0000926326-25-000009:mdna:36]
Over the past several years, our business has expanded from a single-point solution to a platform of products and services that will help further advance the industry-defined vision of the Autonomous Pharmacy. This expansion has resulted in larger deal sizes across multiple products, services, and implementations for customers and, we believe, more comprehensive, valuable, and enduring relationships. As our business evolves, we continue to evaluate the metrics and methods we use to measure the success of our business.

[0000926326-25-000009:mdna:37]
Global Trade Relations

[0000926326-25-000009:mdna:38]
On April 2, 2025, the current U.S. administration imposed significant tariffs on a wide variety of products manufactured in virtually every foreign jurisdiction, which tariffs were subsequently paused for 90 days on April 10, 2025, excluding tariffs on all imports from China, which were 145% as of April 10, 2025. In response, several foreign countries have imposed reciprocal tariffs on goods manufactured in the United States. Furthermore, the current U.S. administration has also announced, as have other foreign governments, that it may implement other tariffs or increase existing tariffs. We are monitoring ongoing developments surrounding the fluid tariff environment. Although we continue to work to mitigate the impact of current or potential tariffs, there can be no assurance that we will be able to offset any increased costs or other adverse impacts. As a result, we may incorrectly anticipate outcomes, forgo or pass up business opportunities, or fail to appropriately adapt or manage our business strategies in response to these changes. As a result of all of these factors, we may experience direct and indirect adverse effects on our business, operating results, cash flow, or financial condition.

[0000926326-25-000009:mdna:39]
Product Bookings and Annual Recurring Revenue

[0000926326-25-000009:mdna:40]
Starting in 2025, we began utilizing product bookings and Annual Recurring Revenue (“ARR”), each as further described below, as key performance metrics for our business. We view product bookings as an indicator of the success of certain portions of our business that generate nonrecurring revenue and we view ARR as an indicator of the success of the portions of our business that generate recurring revenues. The definitions and descriptions included below are relevant to these key performance metrics. As previously disclosed in our Annual Report on Form 10-K for the year ended December 31, 2024, product bookings and ARR have replaced our prior bookings metric that was in use through 2024.

[0000926326-25-000009:mdna:41]
Product Bookings

[0000926326-25-000009:mdna:42]
We utilize product bookings as an indicator of the success of certain portions of our business that generate non-recurring revenue. We define product bookings generally as the value of non-cancelable contracts for our connected devices and software licenses. We typically exclude freight revenue and other less significant items ancillary to our products from product bookings. In addition, dependent upon counterparty or credit risk, which is evaluated at the time of contract signing, for a given multi-year subscription contract we may reduce the value of the contractual commitment booked at a given time. Connected devices and software license bookings are recorded as revenue upon customer acceptance of the installation or receipt of goods.

[0000926326-25-000009:mdna:43]
As part of most connected device product sales, we generally provide installation planning and consulting, which is typically included in the initial price of the solution.

[0000926326-25-000009:mdna:44]
Annual Recurring Revenue

[0000926326-25-000009:mdna:45]
We consider revenues generated from our consumables, technical services, and SaaS and Expert Services to be recurring revenues. For the portions of our business which generate recurring revenues, we utilize ARR as a key metric to measure our progress in growing our recurring revenue business. We define ARR at a measurement date as the revenue we expect to receive from our customers over the course of the following year for providing them with products or services. ARR includes expected revenue from all customers who are using our products or services at the reported date. For technical services and SaaS and Expert Services, solutions are generally on a contractual basis, typically with contracts for a period of 12 months or more, with a high probability of renewal. Probability of renewal is based on historic renewal experience of the individual revenue streams or management’s best estimates if historical renewal experience is not available. Consumables orders are placed by customers through our Omnicell Storefront online platform or through written or telephonic orders and are sold to a customer base who utilize the consumable product and place recurring orders when customer inventory is depleted. ARR is generally calculated based on revenues received in the most recent quarter and changes to expected revenues where solutions were added to or removed from the install or customer base in the quarter. Revenues from technical services and SaaS and Expert Services are recorded ratably over the service term. As part of our SaaS and Expert Services offerings, we provide a range of services to our customers including Central Pharmacy Dispensing Service (service portion), IV Compounding Service (service portion), EnlivenHealth, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, and other software solutions, which typically are provided over two to seven years. In addition, to help ensure the maximum availability of our systems, our customers typically purchase technical services contracts (support and maintenance) in increments of one to five years. Revenue from consumables are recorded when the product has shipped and title has passed. Our measure of ARR may be different than that used by other companies. Because ARR is based on expected future revenue, it does not represent revenue recognized during a particular reporting period or revenue to be recognized in future reporting periods. ARR should not be viewed as a substitute for revenues.

[0000926326-25-000009:mdna:46]
[same as prior period, unchanged from 0000926326-24-000032:mdna:30]

[0000926326-25-000009:mdna:47]
| Revenue Category |  | Revenue Type |  | Income Statement Classification |  | Included in Product Bookings |  | Included in ARR |
| Connected devices, software licenses, and other |  | Nonrecurring |  | Product |  | Yes (1) |  | No |
| Consumables |  | Recurring |  | Product |  | No |  | Yes |
| Technical services |  | Recurring |  | Service |  | No |  | Yes |
| SaaS and Expert Services (2) |  | Recurring |  | Service |  | No |  | Yes |

[0000926326-25-000009:mdna:48]
[same as prior period, unchanged from 0000926326-24-000032:mdna:32]

[0000926326-25-000009:mdna:49]
[same as prior period, unchanged from 0000926326-24-000032:mdna:33]

[0000926326-25-000009:mdna:50]
[same as prior period, unchanged from 0000926326-24-000032:mdna:34]

[0000926326-25-000009:mdna:51]
[same as prior period, unchanged from 0000926326-24-000032:mdna:37]

[0000926326-25-000009:mdna:52]
We manage our operations as a single segment for the purposes of assessing performance and making operating decisions. Our Chief Operating Decision Maker (“CODM”) is our Chief Executive Officer. The CODM allocates resources and evaluates the performance of Omnicell at the consolidated level using our consolidated net income (loss). In addition, the CODM is provided with certain segment assets and liabilities, primarily those that impact liquidity, as well as certain significant expenses. All significant operating decisions are based upon an analysis of Omnicell as one operating segment, which is the same as our reporting segment.

[0000926326-25-000009:mdna:53]
Our full-time employee headcount was approximately 3,620 and 3,670 on March 31, 2025 and December 31, 2024, respectively.

[0000926326-25-000009:mdna:54]
[same as prior period, unchanged from 0000926326-24-000032:mdna:39]

[0000926326-25-000009:mdna:55]
In 2023, the United States spent $723 billion on prescription drugs, a 13.6% increase from 2022. This was the largest annual spending increase in 20 years and impacted patients in virtually all settings of care. We believe there are significant challenges facing the practice of pharmacy today including, but not limited to, budget constraints, increased healthcare worker turnover rates, labor shortages, drug shortages, drug diversion, manual and error-prone processes, complex compliance requirements, and limited inventory visibility. Each of these challenges may lead to poor medication management outcomes including, but not limited to, medication errors, adverse drug events, lack of patient adherence, and medication waste. We also

[0000926326-25-000009:mdna:56]
recognize that these challenges may impact the timing of contracting for, or implementation of, our products, solutions, or services. However, we believe that over time these significant challenges to the practice of pharmacy will drive demand for increased automation, visibility, insights, and improved medication management outcomes that our solutions are designed to enable. Because of this, we believe that our solutions are well-positioned to address the evolving needs of healthcare institutions and therefore present opportunities for long-term growth.

[0000926326-25-000009:mdna:57]
In an effort to address these challenges and deliver solutions to help drive positive medication management outcomes, we continue to make significant investments in our research and development efforts to further advance the industry-defined vision of the Autonomous Pharmacy. Furthermore, we believe a combination of robotics and smart devices, software workflows, expert services, and operational and optimization analytics is needed in every care setting where medications are managed. We are focused on delivering solutions to help our customers realize the industry-defined vision of the Autonomous Pharmacy and drive positive medication management outcomes with outstanding customer experience through a mature channel in four market categories:

[0000926326-25-000009:mdna:58]
•Points of Care.  As a market leader, we expect to continue expansion into this product market as customers increase the use of our dispensing systems in more areas within their hospitals and increasingly in ambulatory care settings. Macroeconomic trends in our target market continue to improve as health system margins and volumes increase and stabilize in the post-pandemic environment. This positive trajectory is expected to drive increased demand for system modernization through automation, software, and analytics. We are seeing customers seek to maximize the value of existing automated dispensing system investments and continue to invest in next-generation enhancements and solutions for points of care. We believe that customers will upgrade their current installed base over time as we deliver these new solutions to market. We also believe there is an opportunity for us to expand this offering and define a new standard for dispensing systems in ambulatory settings. We believe our current solutions for Points of Care and new innovations and services will continue to help customers drive improved clinical and financial outcomes.

[0000926326-25-000009:mdna:59]
•Central Pharmacy and IV Compounding.   This market represents the beginning of the medication management process in acute care settings, and we believe it is a significant automation opportunity for high volumes of manual, repetitive, and error-prone processes that are often common in pharmacies today. Manual medication dispensing processes are usually labor intensive, error-prone, and may lead to excess medication waste and expirations for our healthcare partners. Automating the central pharmacy dispensing process should enable customers to reallocate pharmacy labor, enhance dispensing accuracy and patient safety, and reduce medication waste and expirations. Likewise, the manual compounding of sterile IV preparations can be error-prone and create significant patient safety risks, and outsourcing sterile IV compounding could lead to increased medication costs and lack of access to needed medications due to an inability to source medications when they are required. As a result, we believe IV automation provides a significant opportunity to enhance patient safety and reduce costs. We anticipate that these technology-enabled services will become more critical as health systems continue to face labor shortages, increased financial pressure, and supply chain disruptions.

[0000926326-25-000009:mdna:60]
[same as prior period, unchanged from 0000926326-24-000032:mdna:45]

[0000926326-25-000009:mdna:61]
33

[0000926326-25-000009:mdna:62]
•Ambulatory Care.  We believe ambulatory care, especially the retail and institutional market, represents a significant opportunity as healthcare evolves. Retail pharmacies are expected to fill 4.98 billion prescriptions in 2025 and grow at a compound annual growth rate of around 7.1%, which would result in an approximate $1.2 trillion market valuation by 2032. Additionally, the shift of outpatient care from hospitals and physician offices to other, more convenient settings, such as retail pharmacies and the home continues to be a growing trend. New technologies and increased scope of practice for pharmacists appear to be spurring innovation and expansion of the provision of clinical services by retail pharmacies. We believe this development, combined with the move to value-based care, will drive the adoption of our patient engagement offerings. These solutions are intended to help providers (including pharmacists) engage patients in new ways that are expected to improve outcomes, reduce the total cost of care, and lead to more profitable operations.

[0000926326-25-000009:mdna:63]
CRITICAL ACCOUNTING ESTIMATES

[0000926326-25-000009:mdna:64]
[same as prior period, unchanged from 0000926326-24-000032:mdna:49]

[0000926326-25-000009:mdna:65]
[same as prior period, unchanged from 0000926326-24-000032:mdna:50]

[0000926326-25-000009:mdna:66]
[same as prior period, unchanged from 0000926326-24-000032:mdna:51]

[0000926326-25-000009:mdna:67]
•Inventory; and

[0000926326-25-000009:mdna:68]
[same as prior period, unchanged from 0000926326-24-000032:mdna:60]

[0000926326-25-000009:mdna:69]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the three months ended March 31, 2025 as compared to those disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” included in our Annual Report on Form 10-K for the year ended December 31, 2024.

[0000926326-25-000009:mdna:70]
[same as prior period, unchanged from 0000926326-24-000032:mdna:62]

[0000926326-25-000009:mdna:71]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-25-000009:mdna:72]
[same as prior period, unchanged from 0000926326-24-000032:mdna:64]

[0000926326-25-000009:mdna:73]
[same as prior period, unchanged from 0000926326-24-000032:mdna:65]

[0000926326-25-000009:mdna:74]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 145,168 |  |  | $ | 133,295 |  |  | $ | 11,873 |  |  | 9% |
| Percentage of total revenues | 54% |  | 54% |  |  |  |  |
| Service revenues | 124,500 |  |  | 112,856 |  |  | $ | 11,644 |  |  | 10% |
| Percentage of total revenues | 46% |  | 46% |  |  |  |  |
| Total revenues | $ | 269,668 |  |  | $ | 246,151 |  |  | $ | 23,517 |  |  | 10% |

[0000926326-25-000009:mdna:75]
Product revenues represented 54% of total revenues for both the three months ended March 31, 2025 and 2024. Product revenues increased by $11.9 million, primarily due to the increase in revenues from our XT Amplify program.

[0000926326-25-000009:mdna:76]
Service revenues represented 46% of total revenues for both the three months ended March 31, 2025 and 2024. Service revenues include revenues from technical services and SaaS and Expert Services offerings. Service revenues increased by $11.6 million, primarily due to an increase of $2.9 million in technical services revenues as a result of growth in our installed customer base and the impact of pricing actions, as well as an increase of $8.8 million in SaaS and Expert Services revenues due to continued customer demand, including an increase in revenues from our Specialty Pharmacy Services offering.

[0000926326-25-000009:mdna:77]
Our international sales represented 8% and 11% of total revenues for the three months ended March 31, 2025 and 2024, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-25-000009:mdna:78]
Our ability to grow revenues is dependent on our ability to continue to obtain orders from customers, which may be dependent upon customers’ capital equipment budgets and/or capital equipment approval cycles, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, our ability to develop new or enhance existing solutions, and our flexibility in workforce allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules and/or staffing levels allow for installations.

[0000926326-25-000009:mdna:79]
[same as prior period, unchanged from 0000926326-24-000032:mdna:76]

[0000926326-25-000009:mdna:80]
[same as prior period, unchanged from 0000926326-24-000032:mdna:77]

[0000926326-25-000009:mdna:81]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 85,585 |  |  | $ | 92,441 |  |  | $ | (6,856) |  |  | (7)% |
| As a percentage of related revenues | 59% |  | 69% |  |  |  |  |
| Cost of service revenues | 73,147 |  |  | 61,087 |  |  | $ | 12,060 |  |  | 20% |
| As a percentage of related revenues | 59% |  | 54% |  |  |  |  |
| Total cost of revenues | $ | 158,732 |  |  | $ | 153,528 |  |  | $ | 5,204 |  |  | 3% |
| As a percentage of total revenues | 59% |  | 62% |  |  |  |  |
| Gross profit | $ | 110,936 |  |  | $ | 92,623 |  |  | $ | 18,313 |  |  | 20% |
| Gross margin | 41% |  | 38% |  |  |  |  |

[0000926326-25-000009:mdna:82]
Cost of revenues for the three months ended March 31, 2025 compared to the three months ended March 31, 2024 increased by $5.2 million, primarily driven by a $12.1 million increase in cost of service revenues, partially offset by a $6.9 million decrease in cost of product revenues.

[0000926326-25-000009:mdna:83]
The decrease in cost of product revenues for the three months ended March 31, 2025 compared to the three months ended March 31, 2024 was primarily driven by the impact of more favorable materials costs during the three months ended March 31, 2025 and a decrease of $2.6 million of restructuring costs, partially offset by an increase in revenues.

[0000926326-25-000009:mdna:84]
The increase in cost of service revenues was primarily driven by the increase in service revenues of $11.6 million for the three months ended March 31, 2025 compared to the three months ended March 31, 2024, including the associated increase in employee-related expenses, and an increase in certain non-recurring costs, including software upgrade expenses.

[0000926326-25-000009:mdna:85]
The overall increase in gross margin primarily relates to higher revenues for the three months ended March 31, 2025 compared to the three months ended March 31, 2024, as well as a decrease in cost of product revenues primarily due to the impact of more favorable materials costs during the three months ended March 31, 2025 and a decrease in restructuring costs, partially offset by an increase in certain non-recurring costs, including software upgrade expenses. Our gross profit for the three months ended March 31, 2025 was $110.9 million, as compared to $92.6 million for the three months ended March 31, 2024.

[0000926326-25-000009:mdna:86]
[same as prior period, unchanged from 0000926326-24-000032:mdna:86]

[0000926326-25-000009:mdna:87]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 20,526 |  |  | $ | 22,056 |  |  | $ | (1,530) |  |  | (7)% |
| As a percentage of total revenues | 8% |  | 9% |  |  |  |  |
| Selling, general, and administrative | 102,029 |  |  | 92,414 |  |  | $ | 9,615 |  |  | 10% |
| As a percentage of total revenues | 38% |  | 38% |  |  |  |  |
| Total operating expenses | $ | 122,555 |  |  | $ | 114,470 |  |  | $ | 8,085 |  |  | 7% |
| As a percentage of total revenues | 45% |  | 47% |  |  |  |  |
| Interest and other income (expense), net | $ | 2,089 |  |  | $ | 4,016 |  |  | $ | (1,927) |  |  | (48)% |

[0000926326-25-000009:mdna:88]
Research and Development. Research and development expenses decreased by $1.5 million for the three months ended March 31, 2025 compared to the three months ended March 31, 2024 primarily due to the timing of capitalized software projects.

[0000926326-25-000009:mdna:89]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $9.6 million for the three months ended March 31, 2025 compared to the three months ended March 31, 2024. The increase was primarily due to an increase of $6.2 million in employee-related expenses primarily as a result of higher headcount, an increase of $2.7 million for legal and regulatory expenses, and an increase of $1.5 million in certain restructuring and severance charges for the three months ended March 31, 2025 compared to the three months ended March 31, 2024.

[0000926326-25-000009:mdna:90]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $1.9 million for the three months ended March 31, 2025 compared to the three months ended March 31, 2024, primarily driven by a $2.1 million decrease in other income and a $0.2 million increase in other expense. The decrease in other income during the three months ended March 31, 2025 as compared to the three months ended March 31, 2024 is primarily attributable to lower interest income received due to lower interest rates and lower cash and cash equivalents balances following the partial repurchase of our convertible senior notes in November 2024.

[0000926326-25-000009:mdna:91]
Benefit from Income Taxes

[0000926326-25-000009:mdna:92]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2025 |  | 2024 |  | $ |  | % |
|  | (Dollars in thousands) |
| Benefit from income taxes | $ | (2,507) |  |  | $ | (2,155) |  |  | $ | (352) |  |  | 16% |

[0000926326-25-000009:mdna:93]
For the three months ended March 31, 2025 and March 31, 2024, we recorded a benefit from income taxes of $2.5 million and $2.2 million, respectively. The change in the benefit from income taxes for the three months ended March 31, 2025 compared to the benefit from income taxes for the same period in 2024 was insignificant, consisting of various offsetting components of annual effective tax rate and discrete income tax expense.

[0000926326-25-000009:mdna:94]
Refer to Note 15, Income Taxes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-25-000009:mdna:95]
[same as prior period, unchanged from 0000926326-24-000032:mdna:101]

[0000926326-25-000009:mdna:96]
We had cash and cash equivalents of $386.8 million at March 31, 2025 compared to $369.2 million at December 31, 2024. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with financial institutions of high credit quality.

[0000926326-25-000009:mdna:97]
Our cash position and working capital at March 31, 2025 and December 31, 2024 were as follows:

[0000926326-25-000009:mdna:98]
|  | March 31,2025 |  | December 31,2024 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 386,826 |  |  | $ | 369,201 |  |
| Working capital | $ | 232,135 |  |  | $ | 219,815 |  |

[0000926326-25-000009:mdna:99]
Our ratio of current assets to current liabilities was 1.4:1 at both March 31, 2025 and December 31, 2024.

[0000926326-25-000009:mdna:100]
[same as prior period, unchanged from 0000926326-24-000032:mdna:108]

[0000926326-25-000009:mdna:101]
Revolving Credit Facility

[0000926326-25-000009:mdna:102]
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023 to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 11, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q), expand our flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-25-000009:mdna:103]
On October 10, 2023, Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-25-000009:mdna:104]
As of March 31, 2025, we had $350.0 million of funds available under the Current Revolving Credit Facility. As of March 31, 2025, there was no outstanding balance under the Current Revolving Credit Facility and we were in full compliance with all covenants.

[0000926326-25-000009:mdna:105]
Refer to Note 10, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information. We expect to use future loans under the Current Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-25-000009:mdna:106]
Convertible Senior Notes

[0000926326-25-000009:mdna:107]
On November 22, 2024, Omnicell, Inc. completed a private offering of $172.5 million aggregate principal amount of 1.00% Convertible Senior Notes due 2029 (the “2029 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $22.5 million aggregate principal amount of the 2029 Notes. Omnicell, Inc. received proceeds from the issuance of the 2029 Notes of $166.3 million, net of $6.2 million of transaction fees and other debt issuance costs. The 2029 Notes bear interest at a rate of 1.00% per year, payable semiannually in arrears on June 1 and December 1 of each year, beginning on June 1, 2025. The 2029 Notes are general senior, unsecured obligations of Omnicell, Inc. and will mature on December 1, 2029, unless earlier redeemed, repurchased, or converted. In connection with the issuance of the 2029 Notes, in November 2024, we entered into warrant transactions and received aggregate proceeds from the sale of the warrants of

[0000926326-25-000009:mdna:108]
approximately $25.2 million. Refer to Note 11, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-25-000009:mdna:109]
[same as prior period, unchanged from 0000926326-24-000032:mdna:114]

[0000926326-25-000009:mdna:110]
Our future uses of cash are expected to be primarily for working capital, capital expenditures, and other contractual obligations. We may also use cash for potential acquisitions and acquisition-related activities, as well as repurchases of our common stock. In addition, we may also use a portion of our cash as we consider various options related to our outstanding debt.

[0000926326-25-000009:mdna:111]
The 2016 Repurchase Program has a total of $2.7 million remaining for future repurchases as of March 31, 2025, which may result in additional use of cash. There were no stock repurchases during the three months ended March 31, 2025. Refer to “Stock Repurchase Programs” under Note 16, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-25-000009:mdna:112]
In November 2024, we completed a partial repurchase of $400.0 million aggregate principal amount of the 2025 Notes for approximately $391.2 million in cash. Refer to Note 11, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-25-000009:mdna:113]
In connection with the issuance of the 2029 Notes, in November 2024, we entered into convertible note hedge transactions and used approximately $40.3 million of the net proceeds from the offering to pay the cost of the convertible note hedges.

[0000926326-25-000009:mdna:114]
Based on our current business plan and backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Current Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, outstanding debt, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the growth of our business.

[0000926326-25-000009:mdna:115]
[same as prior period, unchanged from 0000926326-24-000032:mdna:118]

[0000926326-25-000009:mdna:116]
[same as prior period, unchanged from 0000926326-24-000032:mdna:119]

[0000926326-25-000009:mdna:117]
|  | Three Months Ended March 31, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 25,924 |  |  | $ | 49,953 |  |
| Investing activities | (15,739) |  |  | (12,340) |  |
| Financing activities | 4,038 |  |  | 11,926 |  |
| Effect of exchange rate changes on cash and cash equivalents | 1,565 |  |  | (556) |  |
| Net increase in cash, cash equivalents, and restricted cash | $ | 15,788 |  |  | $ | 48,983 |  |

[0000926326-25-000009:mdna:118]
[same as prior period, unchanged from 0000926326-24-000032:mdna:121]

[0000926326-25-000009:mdna:119]
[same as prior period, unchanged from 0000926326-24-000032:mdna:122]

[0000926326-25-000009:mdna:120]
Net cash provided by operating activities was $25.9 million for the three months ended March 31, 2025, primarily consisting of operating inflows of $22.6 million and favorable working capital movements of $3.3 million. Operating inflows consisted of a net loss of $7.0 million, adjusted for non-cash items of $29.6 million, which consisted primarily of depreciation and amortization expense of $20.0 million and share-based compensation expense of $10.8 million. The favorable working capital was primarily due to an increase in deferred revenues of $20.2 million, driven primarily by an increase in billings for certain technical service and SaaS and Expert Services offerings, and a decrease in accounts receivable and unbilled receivables of $5.5 million, primarily due to the timing of billings, shipments, and collections. The cash inflows were partially offset by a decrease in accrued compensation of $14.2 million, primarily due to the timing of bonus payments, as well as ESPP purchases.

[0000926326-25-000009:mdna:121]
Net cash provided by operating activities was $50.0 million for the three months ended March 31, 2024, primarily consisting of operating inflows of $12.6 million and favorable working capital movements of $37.4 million. Operating inflows

[0000926326-25-000009:mdna:122]
consisted of net loss of $15.7 million, adjusted for non-cash items of $28.2 million, which consisted primarily of depreciation and amortization expense of $21.3 million, and share-based compensation expense of $8.6 million. The favorable working capital was primarily due to an increase in deferred revenues of $34.1 million driven by an increase in billings for certain technical service and SaaS and Expert Services offerings, a decrease in inventories of $6.3 million resulting from the management of inventory levels to align with the current forecasted demand as well as inventory management efforts, and an increase in accrued liabilities of $5.1 million. These cash inflows were partially offset by a decrease in accrued compensation of $10.3 million, primarily due to a decrease in the accrual for restructuring initiatives, as well as timing of payroll and ESPP purchases.

[0000926326-25-000009:mdna:123]
[same as prior period, unchanged from 0000926326-24-000032:mdna:125]

[0000926326-25-000009:mdna:124]
Net cash used in investing activities was $15.7 million for the three months ended March 31, 2025, which consisted of capital expenditures of $11.2 million for property and equipment and $4.6 million for external-use software development costs.

[0000926326-25-000009:mdna:125]
Net cash used in investing activities was $12.3 million for the three months ended March 31, 2024, which consisted of capital expenditures of $9.0 million for property and equipment and $3.4 million for external-use software development costs.

[0000926326-25-000009:mdna:126]
[same as prior period, unchanged from 0000926326-24-000032:mdna:128]

[0000926326-25-000009:mdna:127]
Net cash provided by financing activities was $4.0 million for the three months ended March 31, 2025, primarily due to $8.3 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-25-000009:mdna:128]
Net cash provided by financing activities was $11.9 million for the three months ended March 31, 2024, primarily due to $8.0 million in proceeds from employee stock option exercises and ESPP purchases and a net change in the customer funds balances of $4.6 million.

[0000926326-25-000009:mdna:129]
[same as prior period, unchanged from 0000926326-24-000032:mdna:131]

[0000926326-25-000009:mdna:130]
There have been no significant changes during the three months ended March 31, 2025 to the contractual obligations disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2024.

[0000926326-25-000009:mdna:131]
Contractual obligations as of March 31, 2025 were as follows:

[0000926326-25-000009:mdna:132]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2025 |  | 2026-2027 |  | 2028-2029 |  | 2030 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 49,729 |  |  | $ | 10,332 |  |  | $ | 24,569 |  |  | $ | 12,994 |  |  | $ | 1,834 |  |
| Purchase obligations (2) | $ | 129,254 |  |  | 109,139 |  |  | 20,089 |  |  | 26 |  |  | — |  |
| Convertible senior notes (3) | $ | 356,387 |  |  | 176,982 |  |  | 3,450 |  |  | 175,955 |  |  | — |  |
| Total (4) | $ | 535,370 |  |  | $ | 296,453 |  |  | $ | 48,108 |  |  | $ | 188,975 |  |  | $ | 1,834 |  |

[0000926326-25-000009:mdna:133]
[same as prior period, unchanged from 0000926326-24-000032:mdna:105]

[0000926326-25-000009:mdna:134]
(1)Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 13, Lessee Leases, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-25-000009:mdna:135]
[same as prior period, unchanged from 0000926326-24-000032:mdna:137]

[0000926326-25-000009:mdna:136]
(3)We issued the 2025 Notes in September 2020 that are due in September 2025 and issued the 2029 Notes in November 2024 that are due in December 2029. The obligations presented above include both principal and interest on these notes. Although these notes mature in 2025 and 2029, respectively, they may be converted into cash and shares of our common stock prior to maturity if certain conditions are met. Any conversion prior to maturity can result in repayment of the principal amounts sooner than the scheduled repayment as indicated in the table above. Refer to Note 11, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-25-000009:mdna:137]
(4)Refer to Note 14, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.
