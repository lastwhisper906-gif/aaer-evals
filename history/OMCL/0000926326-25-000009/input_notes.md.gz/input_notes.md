# OMCL notes — 0000926326-25-000009


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-25-000009:notes:1]
[same as prior period, unchanged from 0000926326-24-000032:notes:1]

[0000926326-25-000009:notes:2]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products and related services are medication management solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States. “Omnicell” or the “Company” refer to Omnicell, Inc. and its subsidiaries, collectively.

[0000926326-25-000009:notes:3]
[same as prior period, unchanged from 0000926326-24-000032:notes:3]

[0000926326-25-000009:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2025 and December 31, 2024, and the results of operations, comprehensive loss, and cash flows for the three months ended March 31, 2025 and 2024. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2024, filed with the SEC on February 27, 2025. The Company’s results of operations, comprehensive loss, and cash flows for the three months ended March 31, 2025 are not necessarily indicative of results that may be expected for the year ending December 31, 2025, or for any future period.

[0000926326-25-000009:notes:5]
[same as prior period, unchanged from 0000926326-24-000032:notes:5]

[0000926326-25-000009:notes:6]
[same as prior period, unchanged from 0000926326-24-000032:notes:6]

[0000926326-25-000009:notes:7]
[same as prior period, unchanged from 0000926326-24-000032:notes:7]

[0000926326-25-000009:notes:8]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes to Condensed Consolidated Financial Statements. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting estimates are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. Those estimates are revenue recognition, inventory valuation, and accounting for income taxes. As of March 31, 2025, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-25-000009:notes:9]
[same as prior period, unchanged from 0000926326-24-000032:notes:10]

[0000926326-25-000009:notes:10]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company at the consolidated level using the Company’s consolidated net income (loss). In addition, the CODM is provided with certain segment assets and liabilities, primarily those that impact liquidity, as well as certain significant expenses. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment. Refer to Note 2, Segment Information, for further information regarding the Company’s segment disclosures.

[0000926326-25-000009:notes:11]
[same as prior period, unchanged from 0000926326-24-000032:notes:12]

[0000926326-25-000009:notes:12]
[same as prior period, unchanged from 0000926326-24-000032:notes:13]

[0000926326-25-000009:notes:13]
[same as prior period, unchanged from 0000926326-24-000032:notes:14]

[0000926326-25-000009:notes:14]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning January 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2023-09 will have on its consolidated financial statements, which is limited to financial statements disclosures.

[0000926326-25-000009:notes:15]
In March 2024, the SEC issued final rules under SEC Release No. 33-11275, “The Enhancement and Standardization of Climate-Related Disclosures for Investors,” to require registrants to disclose certain climate-related information, including Scope 1 and Scope 2 greenhouse gas emissions and other climate-related topics, if material, in registration statements and annual reports. In April 2024, the SEC voluntarily stayed its climate disclosure rules as a result of pending legal challenges to facilitate an orderly judicial resolution. In March 2025, the SEC stated that it has ended its defense of the rule. The Company will continue to monitor any developments in the SEC’s rule and related litigation to determine what, if any, impact it will have on its consolidated financial statement disclosures.

[0000926326-25-000009:notes:16]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosure (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosures of additional information and disaggregation of certain expenses included in the income statement. The amendments are effective for the Company’s annual periods beginning January 1, 2027, and for interim periods within fiscal years beginning January 1, 2028, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating the impact ASU 2024-03 will have on its consolidated financial statements.

[0000926326-25-000009:notes:17]
[same as prior period, unchanged from 0000926326-24-000032:notes:18]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-25-000009:notes:18]
Segment Information
The Company’s one reportable segment derives revenues from sales of its products and related services, as described in Note 3, Revenues, which are sold in its principal market, the healthcare industry.

[0000926326-25-000009:notes:19]
As the Company has a single reportable segment and is managed on a consolidated basis, the measure of segment profit or loss that the CODM uses to allocate resources and assess performance is consolidated net income (loss) as reported on the Condensed Consolidated Statements of Operations. The CODM uses this key measure to evaluate income generated from segment assets in deciding how to reinvest profits as well as monitor budget versus actual results.

[0000926326-25-000009:notes:20]
The CODM is also provided with certain segment assets, primarily those that impact liquidity, such as cash and cash equivalents, accounts receivable and inventories, as well as certain liabilities such as accounts payable and outstanding debt. Assets and liabilities provided to the CODM are consistent with those reported on the Condensed Consolidated Balance Sheets. In addition, the CODM is regularly provided with significant expenses, which are adjusted cost of revenues and adjusted operating expenses. These significant expenses are adjusted for certain non-cash charges and expenses that are unrelated to the Company’s ongoing operations. Adjusted cost of revenues include cost of product revenues and cost of service revenues, and exclude certain items such as share-based compensation expense, amortization of acquired intangibles, and certain restructuring and severance charges. Adjusted operating expenses include research and development, and selling, general and administrative expenses, and exclude certain items such as share-based compensation expense, amortization of acquired intangibles, legal and regulatory expenses, and certain restructuring and severance charges. Depreciation and amortization expense for the Company’s single reportable segment was $20.0 million and $21.3 million for the three months ended March 31, 2025 and 2024, respectively.

[0000926326-25-000009:notes:21]
The following table summarizes the Company’s reportable segment revenues and significant expenses, reconciled to the Company’s consolidated net loss:

[0000926326-25-000009:notes:22]
|  |  |  | Three Months Ended March 31, |
|  |  |  | 2025 |  | 2024 |
|  |  |  | (In thousands) |
| Total revenues |  |  | $ | 269,668 |  |  | $ | 246,151 |  |
| Less: |  |  |  |  |  |
| Adjusted cost of revenues |  |  | (156,007) |  |  | (148,157) |  |
| Adjusted operating expenses |  |  | (104,354) |  |  | (101,722) |  |
| Other segment items (1) |  |  | (20,926) |  |  | (18,119) |  |
| Interest and other income (expense), net |  |  | 2,089 |  |  | 4,016 |  |
| Benefit from income taxes |  |  | (2,507) |  |  | (2,155) |  |
| Net loss |  |  | $ | (7,023) |  |  | $ | (15,676) |  |

[0000926326-25-000009:notes:23]
_________________________________________________
(1)    Other segment items include certain non-cash charges and expenses that are unrelated to the Company’s ongoing operations. Such charges and expenses consist of items such as share-based compensation, amortization of acquired intangible assets, legal and regulatory expenses, and certain restructuring and severance charges.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-25-000009:notes:24]
[same as prior period, unchanged from 0000926326-24-000032:notes:19]

[0000926326-25-000009:notes:25]
[same as prior period, unchanged from 0000926326-24-000032:notes:20]

[0000926326-25-000009:notes:26]
[same as prior period, unchanged from 0000926326-24-000032:notes:21]

[0000926326-25-000009:notes:27]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards, which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, and are designed to improve patient engagement and adherence to prescriptions.

[0000926326-25-000009:notes:28]
Technical services. Post-installation technical support and other related services (support and maintenance), including phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.

[0000926326-25-000009:notes:29]
Software as a Service (“SaaS”) and Expert Services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth®, Specialty Pharmacy Services, 340B solutions, Inventory Optimization Service, other software solutions, and services related to the Central Pharmacy Dispensing Service and IV Compounding Service.

[0000926326-25-000009:notes:30]
[same as prior period, unchanged from 0000926326-24-000032:notes:25]

[0000926326-25-000009:notes:31]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to, or receipt by, customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| SaaS and Expert Services |  |  |  | Over time, as services are provided |  | Service |

[0000926326-25-000009:notes:32]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $2.2 million and $2.0 million for the three months ended March 31, 2025 and 2024, respectively.

[0000926326-25-000009:notes:33]
[same as prior period, unchanged from 0000926326-24-000032:notes:28]

[0000926326-25-000009:notes:34]
The following table summarizes the Company’s revenues disaggregated by revenue type:

[0000926326-25-000009:notes:35]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (In thousands) |
| Connected devices, software licenses, and other |  |  |  |  | $ | 120,077 |  |  | $ | 111,069 |  |
| Consumables |  |  |  |  | 25,091 |  |  | 22,226 |  |
| Technical services |  |  |  |  | 61,379 |  |  | 58,515 |  |
| SaaS and Expert Services |  |  |  |  | 63,121 |  |  | 54,341 |  |
| Total revenues |  |  |  |  | $ | 269,668 |  |  | $ | 246,151 |  |

[0000926326-25-000009:notes:36]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location:

[0000926326-25-000009:notes:37]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (In thousands) |
| United States |  |  |  |  | $ | 249,264 |  |  | $ | 218,176 |  |
| Rest of world (1) |  |  |  |  | 20,404 |  |  | 27,975 |  |
| Total revenues |  |  |  |  | $ | 269,668 |  |  | $ | 246,151 |  |

[0000926326-25-000009:notes:38]
[same as prior period, unchanged from 0000926326-24-000032:notes:33]

[0000926326-25-000009:notes:39]
[same as prior period, unchanged from 0000926326-24-000032:notes:34]

[0000926326-25-000009:notes:40]
[same as prior period, unchanged from 0000926326-24-000032:notes:35]

[0000926326-25-000009:notes:41]
[same as prior period, unchanged from 0000926326-24-000032:notes:36]

[0000926326-25-000009:notes:42]
|  | March 31,2025 |  | December 31,2024 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 33,422 |  |  | $ | 32,917 |  |
| Long-term unbilled receivables, net (2) | 6,703 |  |  | 7,873 |  |
| Total contract assets | $ | 40,125 |  |  | $ | 40,790 |  |
| Short-term deferred revenues | $ | 159,995 |  |  | $ | 141,370 |  |
| Long-term deferred revenues | 78,370 |  |  | 76,123 |  |
| Total contract liabilities | $ | 238,365 |  |  | $ | 217,493 |  |

[0000926326-25-000009:notes:43]
[same as prior period, unchanged from 0000926326-24-000032:notes:38]

[0000926326-25-000009:notes:44]
[same as prior period, unchanged from 0000926326-24-000032:notes:39]

[0000926326-25-000009:notes:45]
[same as prior period, unchanged from 0000926326-24-000032:notes:40]

[0000926326-25-000009:notes:46]
During the three months ended March 31, 2025, the Company recognized revenues of $54.2 million that were included in the corresponding gross short-term deferred revenues balance of $141.4 million as of December 31, 2024.

[0000926326-25-000009:notes:47]
Deferred revenues from product sales primarily relate to delivered and invoiced products, pending installation and acceptance. Deferred revenues from service contracts primarily relate to services that have been invoiced, but services have not yet been provided. Short-term deferred revenues are expected to be recognized within the next twelve months. Long-term deferred revenues substantially consist of deferred revenues on long-term technical and SaaS and Expert Services contracts which have been invoiced and are expected to be recognized as revenue beyond twelve months, generally not more than ten years. The Company generally invoices customers for products upon shipment. Invoicing associated with the service portion of agreements is generally periodic and is billed on a monthly, quarterly, or annual basis, and in certain circumstances, multiple years are billed at one time. SaaS and Expert Services agreements are generally invoiced periodically on a monthly, quarterly or annual basis over the life of the agreement. In certain circumstances portions of these agreements may be invoiced lump sum.

[0000926326-25-000009:notes:48]
In addition, the Company has remaining performance obligations associated with contracts for which the associated products have been accepted or associated services have started, but where invoicing has not yet occurred and therefore are not reflected in deferred revenue. These remaining performance obligations are comprised of the non-variable portions of technical services and SaaS and Expert Services provided under non-cancellable contracts with minimum commitments. Remaining performance obligations which are not included in deferred revenues were $390.4 million as of March 31, 2025. Remaining performance obligations are expected to be recognized ratably over the remaining terms of the associated contracts, which terms vary but are generally not more than ten years. Remaining performance obligations do not include product obligations, services where the associated product has not been accepted, services which have not yet started, variable portions of services, and certain other obligations.

[0000926326-25-000009:notes:49]
[same as prior period, unchanged from 0000926326-24-000032:notes:44]

[0000926326-25-000009:notes:50]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2025 and 2024. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable and unbilled receivables balance as of March 31, 2025 and December 31, 2024.


## us-gaap:EarningsPerShareTextBlock

[0000926326-25-000009:notes:51]
Net Loss Per Share
Basic net income (loss) per share is computed by dividing net income (loss) for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period, using the treasury stock method for share-based awards and warrants, and the if-converted method for convertible senior notes. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units, as well as shares the Company could be obligated to issue from its convertible senior notes and warrants, as described in Note 11, Convertible Senior Notes. In the event of the conversion of the Company’s convertible senior notes, the principal portion will be settled in cash with any conversion consideration in excess of the principal portion settled in cash and/or shares of the Company’s common stock at the Company’s option, therefore, only the amounts expected to be settled in excess of the principal portion are considered dilutive in calculating earnings per share under the if-converted method. Any anti-dilutive weighted-average dilutive shares related to stock award plans, convertible senior notes, and warrants are excluded from the computation of the diluted net income per share.

[0000926326-25-000009:notes:52]
The basic and diluted net loss per share calculations were as follows:

[0000926326-25-000009:notes:53]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (In thousands, except per share data) |
| Net loss |  |  |  |  | $ | (7,023) |  |  | $ | (15,676) |  |
| Weighted-average shares outstanding – basic and diluted |  |  |  |  | 46,596 |  |  | 45,732 |  |
| Net loss per share – basic and diluted |  |  |  |  | $ | (0.15) |  |  | $ | (0.34) |  |
| Anti-dilutive weighted-average shares related to stock award plans |  |  |  |  | 3,745 |  |  | 3,276 |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants |  |  |  |  | 9,622 |  |  | 11,816 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-25-000009:notes:54]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $386.8 million and $369.2 million as of March 31, 2025 and December 31, 2024, respectively, consisted of bank accounts and highly-liquid U.S. Government money market funds held in sweep and asset

[0000926326-25-000009:notes:55]
management accounts with financial institutions of high credit quality. As of March 31, 2025 and December 31, 2024, cash equivalents were $341.6 million and $328.0 million, respectively, which consisted of money market funds held in sweep and asset management accounts. The Company recorded interest income on its cash and cash equivalents of $3.6 million and $6.0 million for the three months ended March 31, 2025 and 2024, respectively, which is included within interest and other income (expense), net in the Condensed Consolidated Statements of Operations.

[0000926326-25-000009:notes:56]
Fair Value Hierarchy

[0000926326-25-000009:notes:57]
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s credit facility is classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company’s convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. Refer to Note 10, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 11, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.

[0000926326-25-000009:notes:58]
The following table summarizes the carrying amounts, net of unamortized debt issuance costs, and fair values of the convertible senior notes:

[0000926326-25-000009:notes:59]
|  | March 31,2025 |  | December 31,2024 |
|  | (In thousands) |
| Net carrying amount: |  |  |  |
| 2025 Notes | 174,562 |  |  | 174,324 |  |
| 2029 Notes | 166,700 |  |  | 166,397 |  |
| Total net carrying amount | $ | 341,262 |  |  | $ | 340,721 |  |
| Fair value: |  |  |  |
| 2025 Notes | $ | 170,518 |  |  | $ | 167,129 |  |
| 2029 Notes | 161,546 |  |  | 181,320 |  |
| Total fair value | $ | 332,064 |  |  | $ | 348,449 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-25-000009:notes:60]
Balance Sheet Components
Balance sheet details are presented in the tables below:

[0000926326-25-000009:notes:61]
|  | March 31,2025 |  | December 31,2024 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 34,417 |  |  | $ | 33,501 |  |
| Work in process | 2,255 |  |  | 1,515 |  |
| Finished goods | 54,470 |  |  | 53,643 |  |
| Total inventories | $ | 91,142 |  |  | $ | 88,659 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 51,968 |  |  | $ | 47,846 |  |
| Deferred cost of sales | 10,953 |  |  | 8,704 |  |
| Net investment in sales-type leases, current portion | 12,601 |  |  | 12,475 |  |
| Prepaid income taxes | 2,495 |  |  | 1,334 |  |
| Other current assets | 5,334 |  |  | 4,934 |  |
| Total other current assets | $ | 83,351 |  |  | $ | 75,293 |  |
| Other long-term assets: |  |  |  |
| External-use software development costs, net | $ | 57,535 |  |  | $ | 58,436 |  |
| Unbilled receivables, net | 6,703 |  |  | 7,873 |  |
| Deferred debt issuance costs | 2,746 |  |  | 2,940 |  |
| Other long-term assets | 9,577 |  |  | 10,057 |  |
| Total other long-term assets | $ | 76,561 |  |  | $ | 79,306 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 11,545 |  |  | $ | 10,702 |  |
| Customer fund liabilities | 51,968 |  |  | 47,846 |  |
| Advance payments from customers | 13,092 |  |  | 12,760 |  |
| Rebate liabilities | 47,275 |  |  | 49,300 |  |
| Taxes payable | 12,899 |  |  | 11,443 |  |
| Other accrued liabilities | 36,848 |  |  | 35,844 |  |
| Total accrued liabilities | $ | 173,627 |  |  | $ | 167,895 |  |

[0000926326-25-000009:notes:62]
(1)    Includes restricted cash of $27.6 million and $29.4 million as of March 31, 2025 and December 31, 2024, respectively.

[0000926326-25-000009:notes:63]
The Company capitalizes certain costs associated with cloud computing arrangements that are associated with service contracts, which are amortized using the straight-line method over the term of the arrangement. As of March 31, 2025 and December 31, 2024, capitalized costs associated with cloud computing arrangements, net of accumulated amortization, were $5.2 million and $5.0 million, respectively.

[0000926326-25-000009:notes:64]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss), which consisted of foreign currency translation adjustments:

[0000926326-25-000009:notes:65]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (In thousands) |
| Beginning balance |  |  |  |  | $ | (17,195) |  |  | $ | (13,432) |  |
| Other comprehensive income (loss): |  |  |  |  | 3,388 |  |  | (1,399) |  |
| Ending balance |  |  |  |  | $ | (13,807) |  |  | $ | (14,831) |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-25-000009:notes:66]
Property and Equipment
The following table represents the property and equipment balances:

[0000926326-25-000009:notes:67]
|  | March 31,2025 |  | December 31,2024 |
|  | (In thousands) |
| Equipment | $ | 101,335 |  |  | $ | 99,728 |  |
| Furniture and fixtures | 4,687 |  |  | 4,809 |  |
| Leasehold improvements | 17,075 |  |  | 17,722 |  |
| Purchased software and internal-use software development costs | 152,563 |  |  | 146,287 |  |
| Construction in progress | 16,098 |  |  | 12,539 |  |
| Property and equipment, gross | 291,758 |  |  | 281,085 |  |
| Accumulated depreciation and amortization | (175,972) |  |  | (168,393) |  |
| Total property and equipment, net | $ | 115,786 |  |  | $ | 112,692 |  |

[0000926326-25-000009:notes:68]
Depreciation and amortization expense of property and equipment was $8.6 million for both the three months ended March 31, 2025 and 2024.

[0000926326-25-000009:notes:69]
The geographic location of the Company’s property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net:

[0000926326-25-000009:notes:70]
|  | March 31,2025 |  | December 31,2024 |
|  | (In thousands) |
| United States | $ | 112,344 |  |  | $ | 109,534 |  |
| Rest of world | 3,442 |  |  | 3,158 |  |
| Total property and equipment, net | $ | 115,786 |  |  | $ | 112,692 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwareDisclosureTextBlock

[0000926326-25-000009:notes:71]
External-Use Software Development Costs
The carrying amounts of external-use software development costs were as follows:

[0000926326-25-000009:notes:72]
|  | March 31,2025 |  | December 31,2024 |
|  | (In thousands) |
| Gross carrying amount | $ | 254,111 |  |  | $ | 249,335 |  |
| Accumulated amortization | (196,576) |  |  | (190,899) |  |
| External-use software development costs, net (1) | $ | 57,535 |  |  | $ | 58,436 |  |

[0000926326-25-000009:notes:73]
[same as prior period, unchanged from 0000926326-24-000032:notes:63]

[0000926326-25-000009:notes:74]
The Company recorded $5.7 million and $6.7 million to cost of product revenues for amortization of external-use software development costs for the three months ended March 31, 2025 and 2024, respectively.

[0000926326-25-000009:notes:75]
[same as prior period, unchanged from 0000926326-24-000032:notes:65]

[0000926326-25-000009:notes:76]
|  | March 31,2025 |
|  | (In thousands) |
| Remaining nine months of 2025 | $ | 15,923 |  |
| 2026 | 17,169 |  |
| 2027 | 11,236 |  |
| 2028 | 7,379 |  |
| 2029 | 4,752 |  |
| Thereafter | 1,076 |  |
| Total | $ | 57,535 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-25-000009:notes:77]
[same as prior period, unchanged from 0000926326-24-000032:notes:67]

[0000926326-25-000009:notes:78]
[same as prior period, unchanged from 0000926326-24-000032:notes:68]

[0000926326-25-000009:notes:79]
|  |  |  |  |  | (In thousands) |
| Balance as of December 31, 2024 |  |  |  |  | $ | 734,727 |  |
| Foreign currency exchange rate fluctuations |  |  |  |  | 1,229 |  |
| Balance as of March 31, 2025 |  |  |  |  | $ | 735,956 |  |

[0000926326-25-000009:notes:80]
[same as prior period, unchanged from 0000926326-24-000032:notes:70]

[0000926326-25-000009:notes:81]
The carrying amounts and useful lives of intangible assets were as follows:

[0000926326-25-000009:notes:82]
|  | March 31, 2025 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 307,418 |  |  | $ | (137,712) |  |  | $ | (1,299) |  |  | $ | 168,407 |  |  | 4 - 30 |
| Acquired technology | 46,134 |  |  | (33,428) |  |  | — |  |  | 12,706 |  |  | 4 - 20 |
| Trade names | 2,400 |  |  | (1,700) |  |  | — |  |  | 700 |  |  | 5 |
| Patents | 1,683 |  |  | (944) |  |  | — |  |  | 739 |  |  | 2 - 20 |
| Total intangible assets, net | $ | 357,635 |  |  | $ | (173,784) |  |  | $ | (1,299) |  |  | $ | 182,552 |  |  |  |

[0000926326-25-000009:notes:83]
|  | December 31, 2024 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 307,418 |  |  | $ | (133,111) |  |  | $ | (1,373) |  |  | $ | 172,934 |  |  | 4 - 30 |
| Acquired technology | 46,134 |  |  | (32,421) |  |  | — |  |  | 13,713 |  |  | 4 - 20 |
| Trade names | 2,400 |  |  | (1,580) |  |  | — |  |  | 820 |  |  | 5 |
| Patents | 2,291 |  |  | (1,492) |  |  | — |  |  | 799 |  |  | 2 - 20 |
| Total intangible assets, net | $ | 358,243 |  |  | $ | (168,604) |  |  | $ | (1,373) |  |  | $ | 188,266 |  |  |  |

[0000926326-25-000009:notes:84]
[same as prior period, unchanged from 0000926326-24-000032:notes:74]

[0000926326-25-000009:notes:85]
Amortization expense of intangible assets was $5.8 million and $6.0 million for the three months ended March 31, 2025 and 2024, respectively.

[0000926326-25-000009:notes:86]
[same as prior period, unchanged from 0000926326-24-000032:notes:76]

[0000926326-25-000009:notes:87]
|  | March 31,2025 |
|  | (In thousands) |
| Remaining nine months of 2025 | $ | 15,440 |  |
| 2026 | 18,033 |  |
| 2027 | 16,200 |  |
| 2028 | 15,145 |  |
| 2029 | 13,647 |  |
| Thereafter | 104,087 |  |
| Total | $ | 182,552 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-25-000009:notes:88]
Debt and Credit Agreement
On November 15, 2019, Omnicell, Inc. entered into an Amended and Restated Credit Agreement (as amended, the “Prior A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. As referred to in this Note 10, “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries. The Prior A&R Credit Agreement provided for (a) a five-year revolving credit facility of $500.0 million (the “Prior Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Prior Incremental Facility”). In addition, the Prior A&R Credit Agreement included a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The Prior A&R Credit Agreement was subsequently amended on September 22, 2020 and March 29, 2023, to permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions (as described in Note 11, Convertible Senior Notes), expand the Company’s flexibility to make restricted payments (including common stock repurchases), and replace the total net leverage covenant, as well as to remove and replace the interest rate benchmark based on the London interbank offered rate (“LIBOR”) and related LIBOR-based mechanics with an interest rate benchmark based on the secured overnight financing rate (“SOFR”) as administered by the Federal Reserve Bank of New York and related SOFR-based mechanics.

[0000926326-25-000009:notes:89]
Omnicell, Inc. entered into a Second Amended and Restated Credit Agreement (the “Second A&R Credit Agreement”) on October 10, 2023, with the lenders from time to time party thereto, Wells Fargo Securities, LLC, JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and TD Securities (USA) LLC as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The Second A&R Credit Agreement supersedes the Prior A&R Credit Agreement and provides for (a) a five-year revolving credit facility of $350.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to an amount equal to the sum of (i) the greater of $250.0 million and 100% of the adjusted consolidated EBITDA for the last four quarters and (ii) additional amounts subject to pro forma compliance with certain consolidated secured net leverage ratio (the “Current Incremental Facility”). In addition, the Second A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The

[0000926326-25-000009:notes:90]
Second A&R Credit Agreement has an expiration date of October 10, 2028, subject to acceleration under certain conditions, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-25-000009:notes:91]
Loans under the Current Revolving Credit Facility bear interest, at Omnicell, Inc.’s option, at a rate equal to either (a) the Adjusted Term SOFR (as defined in the Second A&R Credit Agreement), plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Second A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) the Adjusted Term SOFR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. Subject to the terms and conditions of the Current Revolving Credit Facility or Current Incremental Facility Omnicell, Inc. is permitted to make voluntary prepayments at any time without payment of a premium or penalty. The availability of funds under the Current Revolving Credit Facility may be subject to reduction in order to maintain compliance with the financial covenants under the Second A&R Credit Agreement.

[0000926326-25-000009:notes:92]
The Second A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Second A&R Credit Agreement contains financial covenants that require the Company to not exceed a maximum consolidated secured net leverage ratio (not to exceed 3.00:1) and maintain a minimum consolidated interest coverage ratio (not to be less than 3.00:1). In addition, the Second A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy.

[0000926326-25-000009:notes:93]
Omnicell, Inc.’s obligations under the Second A&R Credit Agreement and, at the election of Omnicell, Inc. and the contracting counterparty, any secured swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the Second A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, Omnicell, Inc. and certain of Omnicell, Inc.’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement.

[0000926326-25-000009:notes:94]
On November 18, 2024, Omnicell, Inc., as borrower, entered into a First Amendment to Second Amended and Restated Credit Agreement (the “Amendment”) with the lenders party thereto from time to time, and Wells Fargo Bank, National Association, as administrative agent for the lenders. Pursuant to the Amendment, effective as of November 19, 2024, the springing maturity for the revolving credit facility that is tied to the outstanding principal amount of Omnicell, Inc.’s existing 0.25% Convertible Senior Notes due 2025 (the “2025 Notes”) will apply only if more than $200 million in the aggregate principal amount of Omnicell, Inc.’s 2025 Notes remain outstanding as of 91 days prior to the maturity date of the 2025 Notes.

[0000926326-25-000009:notes:95]
As of both March 31, 2025 and December 31, 2024, the Company had $350.0 million of funds available under the Current Revolving Credit Facility. As of March 31, 2025 and December 31, 2024, the Company had no outstanding balance under the Current Revolving Credit Facility. The Company was in compliance with all covenants as of March 31, 2025.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-25-000009:notes:96]
On September 25, 2020, Omnicell, Inc. completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “2025 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the 2025 Notes. As referred to in this Note 11, “Omnicell, Inc.” or the “Company” refers only to Omnicell, Inc., excluding its subsidiaries. Omnicell, Inc. received proceeds from the issuance of the 2025 Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The 2025 Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The 2025 Notes were issued pursuant to an indenture, dated September 25, 2020 (the “2025 Notes Indenture”), between the Company and U.S. Bank National Association, as trustee. The 2025 Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

[0000926326-25-000009:notes:97]
The 2025 Notes are convertible at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for

[0000926326-25-000009:notes:98]
at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2025 Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the 2025 Notes Indenture) per $1,000 principal amount of the 2025 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the 2025 Notes on each such trading day; (iii) if the Company calls such 2025 Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the 2025 Notes called (or deemed called) for redemption; or (iv) upon the occurrence of specified corporate events, as specified in the 2025 Notes Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the 2025 Notes may convert all or any portion of their 2025 Notes at any time, regardless of the foregoing conditions.

[0000926326-25-000009:notes:99]
During the three months ended March 31, 2025 and December 31, 2024, none of the conditional conversion features of the 2025 Notes were triggered, and therefore, the 2025 Notes are not convertible during the second quarter of 2025, commencing on April 1, 2025, and were not convertible during the first quarter of 2025, commencing on January 1, 2025. As the 2025 Notes will mature on September 15, 2025, the Company classified the 2025 Notes as a current liability in its Condensed Consolidated Financial Statements as of both March 31, 2025 and December 31, 2024.

[0000926326-25-000009:notes:100]
Under the original terms of the 2025 Notes Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the 2025 Notes Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of 2025 Notes of at least $1,000. As a result, for 2025 Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of 2025 Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of 2025 Notes above $1,000. The initial conversion rate for the 2025 Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of 2025 Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the 2025 Notes Indenture. In addition, following certain corporate events that could occur prior to the maturity date of the 2025 Notes or if the Company delivers a notice of redemption in respect of the 2025 Notes, the Company will, under certain circumstances, increase the conversion rate of the 2025 Notes for a holder who elects to convert its 2025 Notes (or any portion thereof) in connection with such a corporate event or convert its 2025 Notes called (or deemed called) for redemption during the related redemption period (as defined in the 2025 Notes Indenture), as the case may be.

[0000926326-25-000009:notes:101]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2025 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2025 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2025, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-25-000009:notes:102]
As of March 31, 2025, the Company may redeem for cash all or any portion of the 2025 Notes, at its option, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the 2025 Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2025 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding 2025 Notes, at least $150.0 million aggregate principal amount of the 2025 Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the 2025 Notes.

[0000926326-25-000009:notes:103]
Partial Repurchase of the 2025 Notes

[0000926326-25-000009:notes:104]
In November 2024, the Company entered into separate, privately negotiated transactions with certain holders of the 2025 Notes to repurchase $400.0 million of aggregate principal amount of the 2025 Notes for approximately $391.0 million of cash. The Company accounted for the partial repurchase of 2025 Notes as a debt extinguishment and recorded a $7.2 million gain on extinguishment, which included a partial write-off of previously deferred debt issuance costs of $1.8 million during the three months ended December 31, 2024.

[0000926326-25-000009:notes:105]
The debt issuance costs associated with the remaining 2025 Notes are being amortized to interest expense over the term of the 2025 Notes using an effective interest rate of 0.80%. As of March 31, 2025, the remaining life of the 2025 Notes and the related issuance cost accretion is approximately 0.5 years.

[0000926326-25-000009:notes:106]
Following the partial repurchase of the 2025 Notes, the maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 1.8 million shares. As of March 31, 2025, the if-converted value of the 2025 Notes did not exceed the principal amount.

[0000926326-25-000009:notes:107]
1.00% Convertible Senior Notes due 2029

[0000926326-25-000009:notes:108]
On November 22, 2024, Omnicell, Inc. completed a private offering of $172.5 million aggregate principal amount of 1.00% Convertible Senior Notes due 2029 (the “2029 Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $22.5 million aggregate principal amount of the 2029 Notes. Omnicell, Inc. received proceeds from the issuance of the 2029 Notes of $166.3 million, net of $6.2 million of transaction fees and other debt issuance costs. The 2029 Notes bear interest at a rate of 1.00% per year, payable semiannually in arrears on June 1 and December 1 of each year, beginning on June 1, 2025. The 2029 Notes were issued pursuant to an indenture, dated November 22, 2024 (the “2029 Notes Indenture”), between the Company and U.S. Bank Trust Company, National Association, as trustee. The 2029 Notes are general senior, unsecured obligations of the Company and will mature on December 1, 2029, unless earlier redeemed, purchased, or converted.

[0000926326-25-000009:notes:109]
The 2029 Notes are convertible at any time prior to the close of business on the business day immediately preceding August 1, 2029, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ending on March 31, 2025 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the 2029 Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the “trading price” (as defined in the 2029 Notes Indenture) per $1,000 principal amount of the 2029 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the 2029 Notes on each such trading day; (iii) if the Company calls such 2029 Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the 2029 Notes called (or deemed called) for redemption; or (iv) upon the occurrence of specified corporate events as set forth in the 2029 Notes Indenture. On or after August 1, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the 2029 Notes may convert all or any portion of their 2029 Notes at any time, regardless of the foregoing conditions.

[0000926326-25-000009:notes:110]
During the three months ended March 31, 2025 and December 31, 2024, none of the conditional conversion features of the 2029 Notes were triggered, and therefore, the 2029 Notes are not convertible during the second quarter of 2025, commencing on April 1, 2025, and were not convertible during the first quarter of 2025, commencing on January 1, 2025.

[0000926326-25-000009:notes:111]
Upon conversion, the Company will pay cash up to the aggregate principal amount of the 2029 Notes to be converted and pay or deliver, as the case may be, cash, shares of the Company’s common stock or a combination of cash and shares of the Company’s common stock, at the Company’s election, in respect to the remainder, if any, of the Company’s conversion obligation in excess of the aggregate principal amount of the 2029 Notes being converted, in the manner and subject to the terms and conditions provided in the 2029 Notes Indenture.

[0000926326-25-000009:notes:112]
The initial conversion rate for the 2029 Notes is 17.4662 shares of the Company’s common stock per $1,000 principal amount of the 2029 Notes, which is equivalent to an initial conversion price of approximately $57.25 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the 2029 Notes Indenture. In addition, following certain corporate events that occur prior to the maturity date of the 2029 Notes or if the Company delivers a notice of redemption in respect of the 2029 Notes, the Company will, under certain circumstances, increase the conversion rate of the 2029 Notes for a holder who elects to convert its 2029 Notes (or any portion thereof) in connection with such a corporate event or convert its 2029 Notes called (or deemed called) for redemption during the related redemption period (as defined in the 2029 Notes Indenture), as the case may be.

[0000926326-25-000009:notes:113]
If the Company undergoes a fundamental change (as defined in the 2029 Notes Indenture), holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their 2029 Notes at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2025, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-25-000009:notes:114]
The Company may not redeem the 2029 Notes prior to December 6, 2027. The Company may redeem for cash all or any portion of the 2029 Notes, at its option, on or after December 6, 2027, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the 2029 Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption

[0000926326-25-000009:notes:115]
at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. The Company may not redeem less than all of the outstanding 2029 Notes unless at least $100.0 million aggregate principal amount of 2029 Notes are outstanding and not called for redemption as of the time the Company sends the related notice of redemption. No sinking fund is provided for in the 2029 Notes.

[0000926326-25-000009:notes:116]
The debt issuance costs associated with the 2029 Notes are being amortized to interest expense over the term of the 2029 Notes using an effective interest rate of 1.75%. As of March 31, 2025, the remaining life of the 2029 Notes and the related issuance cost accretion is approximately 4.7 years.

[0000926326-25-000009:notes:117]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 3.0 million shares. As of March 31, 2025, the if-converted value of the 2029 Notes did not exceed the principal amount.

[0000926326-25-000009:notes:118]
The 2025 Notes and the 2029 Notes consisted of the following balances:

[0000926326-25-000009:notes:119]
|  | March 31,2025 |  | December 31,2024 |
|  | (In thousands) |
| 2025 Notes: |  |  |  |
| Principal amount | $ | 175,000 |  |  | $ | 175,000 |  |
| Unamortized debt issuance costs | (438) |  |  | (676) |  |
| Convertible senior notes, net, current | $ | 174,562 |  |  | $ | 174,324 |  |
| 2029 Notes: |  |  |  |
| Principal amount | $ | 172,500 |  |  | $ | 172,500 |  |
| Unamortized debt issuance costs | (5,800) |  |  | (6,103) |  |
| Convertible senior notes, net, noncurrent | $ | 166,700 |  |  | $ | 166,397 |  |

[0000926326-25-000009:notes:120]
The following table summarizes the components of interest expense resulting from the 2025 Notes and the 2029 Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations:

[0000926326-25-000009:notes:121]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (In thousands) |
| Contractual coupon interest: |  |  |  |  |  |  |  |
| 2025 Notes |  |  |  |  | $ | 109 |  |  | $ | 359 |  |
| 2029 Notes |  |  |  |  | 431 |  |  | — |  |
| Amortization of debt issuance costs: |  |  |  |  |  |  |  |
| 2025 Notes |  |  |  |  | $ | 238 |  |  | $ | 777 |  |
| 2029 Notes |  |  |  |  | 303 |  |  | — |  |

[0000926326-25-000009:notes:122]
Convertible Note Hedge and Warrant Transactions

[0000926326-25-000009:notes:123]
In connection with the issuance of the 2025 Notes in September 2020 and the 2029 Notes in November 2024, the Company entered into convertible note hedges and warrants transactions, respectively, with certain initial purchasers of the 2025 Notes and the 2029 Notes or affiliates thereof and certain other financial institutions (the “option counterparties”).

[0000926326-25-000009:notes:124]
The convertible note hedges related to the 2025 Notes consisted of call options for the Company to purchase, subject to anti-dilution adjustments substantially similar to those applicable to the 2025 Notes, up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2025 Notes at the time of its issuance, at an initial strike price of approximately $97.32 per share. The convertible note hedges related to the 2029 Notes consisted of call options for the Company to purchase up to, subject to anti-dilution adjustments substantially similar to those applicable to the 2029 Notes, approximately 3.0 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the 2029 Notes at the time of its issuance, at an initial strike price of approximately $57.25 per share. The convertible note hedges will expire upon the maturity of the respective convertible notes, if not earlier exercised or terminated. The cost of the convertible note hedges related to the 2025 Notes and

[0000926326-25-000009:notes:125]
the 2029 Notes was approximately $100.6 million and $40.3 million, respectively, and each was accounted for as an equity instrument, each of which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. In addition, the Company recorded a deferred tax asset of $25.8 million and $10.2 million, respectively, at issuance related to the convertible note hedges for the 2025 Notes and the 2029 Notes. The convertible note hedges are expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of the 2025 Notes or the 2029 Notes and/or offset any cash payments the Company may be required to make in excess of the principal amount of the converted 2025 Notes or the 2029 Notes.

[0000926326-25-000009:notes:126]
Separately from the convertible note hedges, in September 2020 and November 2024, the Company entered into warrant transactions to sell to the respective option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock at an initial strike price of approximately $141.56 and approximately 3.0 million shares of its common stock at an initial strike price of approximately $84.82 per share related to the 2025 Notes and the 2029 Notes, respectively. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million and $25.2 million for the issuance of the warrants related to the 2025 Notes and the 2029 Notes, respectively, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock, as measured under the warrants, exceeds the strike price of the warrants.
In November 2024, in connection with the partial repurchase of the 2025 Notes, the Company entered into unwind agreements with the existing option counterparties to the convertible note hedges and warrants related to the 2025 Notes to terminate a portion of the existing convertible note hedges and warrants related to the 2025 Notes at a notional amount corresponding to the amount of the 2025 Notes repurchased, resulting in an immaterial gain


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-25-000009:notes:127]
[same as prior period, unchanged from 0000926326-24-000032:notes:103]

[0000926326-25-000009:notes:128]
The Company enters into non-cancelable sales-type lease arrangements with the leases varying in length from one to ten years. The Company optimizes cash flows by selling a majority of its sales-type leases, other than those relating to U.S. government hospitals and SaaS and Expert Services products, including Central Pharmacy Dispensing Service and IV Compounding Service, to third-party leasing finance companies on a non-recourse basis. The Company generally has no obligation to the leasing company once the lease has been sold.

[0000926326-25-000009:notes:129]
The following table presents the Company’s income recognized from sales-type leases:

[0000926326-25-000009:notes:130]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (In thousands) |
| Sales-type lease revenues |  |  |  |  | $ | 5,818 |  |  | $ | 7,036 |  |
| Cost of sales-type lease revenues |  |  |  |  | (2,937) |  |  | (4,187) |  |
| Selling profit on sales-type lease revenues |  |  |  |  | $ | 2,881 |  |  | $ | 2,849 |  |

[0000926326-25-000009:notes:131]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components:

[0000926326-25-000009:notes:132]
|  | March 31,2025 |  | December 31,2024 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 77,528 |  |  | $ | 77,976 |  |
| Less: Unearned interest income portion | (12,393) |  |  | (12,757) |  |
| Net investment in sales-type leases | 65,135 |  |  | 65,219 |  |
| Less: Current portion (1) | (12,601) |  |  | (12,475) |  |
| Long-term investment in sales-type leases, net | $ | 52,534 |  |  | $ | 52,744 |  |

[0000926326-25-000009:notes:133]
[same as prior period, unchanged from 0000926326-24-000032:notes:109]

[0000926326-25-000009:notes:134]
[same as prior period, unchanged from 0000926326-24-000032:notes:110]

[0000926326-25-000009:notes:135]
[same as prior period, unchanged from 0000926326-24-000032:notes:111]

[0000926326-25-000009:notes:136]
|  | March 31,2025 |
|  | (In thousands) |
| Remaining nine months of 2025 | $ | 12,156 |  |
| 2026 | 14,608 |  |
| 2027 | 13,145 |  |
| 2028 | 12,049 |  |
| 2029 | 9,441 |  |
| Thereafter | 16,129 |  |
| Total future minimum sales-type lease payments | 77,528 |  |
| Present value adjustment | (12,393) |  |
| Total net investment in sales-type leases | $ | 65,135 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-25-000009:notes:137]
Lessee Leases 
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to twelve years. As of March 31, 2025, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-25-000009:notes:138]
[same as prior period, unchanged from 0000926326-24-000032:notes:117]

[0000926326-25-000009:notes:139]
|  | March 31,2025 |
|  | (In thousands) |
| Remaining nine months of 2025 | $ | 10,332 |  |
| 2026 | 13,246 |  |
| 2027 | 11,323 |  |
| 2028 | 9,849 |  |
| 2029 | 3,145 |  |
| Thereafter | 1,834 |  |
| Total operating lease payments | 49,729 |  |
| Present value adjustment | (5,164) |  |
| Total operating lease liabilities (1) | $ | 44,565 |  |

[0000926326-25-000009:notes:140]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $11.5 million and $33.0 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-25-000009:notes:141]
Operating lease costs were $2.4 million and $2.6 million for the three months ended March 31, 2025 and 2024, respectively. Short-term lease costs and variable lease costs were not material for the three months ended March 31, 2025 and 2024.

[0000926326-25-000009:notes:142]
The following table summarizes supplemental cash flow information related to the Company’s operating leases:

[0000926326-25-000009:notes:143]
|  | Three Months Ended March 31, |
|  | 2025 |  | 2024 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 3,381 |  |  | $ | 3,401 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 5,381 |  |  | $ | 3,671 |  |

[0000926326-25-000009:notes:144]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases:

[0000926326-25-000009:notes:145]
|  | March 31,2025 |  | December 31,2024 |
| Weighted-average remaining lease term, years | 4.0 |  | 4.1 |
| Weighted-average discount rate, % | 5.6 | % |  | 5.8 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-25-000009:notes:146]
Commitments and Contingencies
Purchase Obligations

[0000926326-25-000009:notes:147]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2025, the Company had non-cancelable purchase commitments of $129.3 million, of which $109.1 million are expected to be paid within the year ending December 31, 2025.

[0000926326-25-000009:notes:148]
Legal Proceedings

[0000926326-25-000009:notes:149]
The Company is currently involved in various legal proceedings.

[0000926326-25-000009:notes:150]
In December 2023, Omnicell received a civil request for records issued by the U.S. Attorney’s Office for the Eastern District of Washington (the “Government”) related to the Company’s compliance with the pricing terms and conditions of its previous Federal Supply Schedule (“FSS”) contract with the federal government. In December 2024, the Government presented information identifying certain potential non-compliances with the FSS contract and associated potential violations of the False Claims Act. On May 5, 2025, Omnicell entered into a settlement agreement with the Government to resolve this matter. The settlement, which will require payment of approximately $4.6 million to cover damages and other statutorily provided amounts under the False Claims Act, settles the matter without admission of liability.

[0000926326-25-000009:notes:151]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with any other current legal proceedings based on its belief that any potential material loss, while reasonably possible, is not probable. Furthermore, any possible range of loss in these matters either cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of legal proceedings or because of the diversion of management’s attention and the creation of significant expenses, regardless of outcome.

[0000926326-25-000009:notes:152]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company’s financial position or results of operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-25-000009:notes:153]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. For the three months ended March 31, 2025 and March 31, 2024, the Company recorded a benefit from income taxes of $2.5 million and $2.2 million, respectively.

[0000926326-25-000009:notes:154]
The effective tax rate for the three months ended March 31, 2025 differed from the statutory rate of 21% primarily due to the unfavorable impact of state taxes, non-deductible compensation and equity charges, partially offset by the favorable benefit of the research and development credits and a foreign-derived intangible income (“FDII”) benefit deduction. The effective tax rate for the three months ended March 31, 2024 differed from the statutory rate of 21% primarily due to the favorable benefit of the research and development credits and state income taxes, partially offset by the unfavorable impact of Global Intangible Low-Taxed Income (“GILTI”) inclusion and non-deductible compensation and equity charges.

[0000926326-25-000009:notes:155]
The Organization for Economic Co-Operation and Development introduced Base Erosion and Profit Shifting Pillar Two rules that impose a global minimum tax rate of 15% on multi-national corporations. These rules did not have an impact on the Company’s provision for income taxes for the three months ended March 31, 2025.

[0000926326-25-000009:notes:156]
As of March 31, 2025 and December 31, 2024, the Company had gross unrecognized tax benefits of $10.8 million and $10.5 million, respectively. The Company recognizes interest and penalties related to uncertain tax positions in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. Accrued interest and penalties are included within other long-term liabilities on the Condensed Consolidated Balance Sheets. As of March 31, 2025 and December 31, 2024, the amount of accrued interest and penalties was $0.8 million and $0.6 million, respectively.

[0000926326-25-000009:notes:157]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examinations by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, France, the United Kingdom, and India. With few exceptions, as of March 31, 2025, the Company was no longer subject to U.S., state, and foreign tax examinations for years before 2021, 2020, and 2020, respectively.

[0000926326-25-000009:notes:158]
[same as prior period, unchanged from 0000926326-24-000032:notes:136]


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-25-000009:notes:159]
[same as prior period, unchanged from 0000926326-24-000032:notes:137]

[0000926326-25-000009:notes:160]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations:

[0000926326-25-000009:notes:161]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2025 |  | 2024 |
|  |  |  |  |  | (In thousands) |
| Cost of product and service revenues |  |  |  |  | $ | 1,718 |  |  | $ | 1,555 |  |
| Research and development |  |  |  |  | 1,220 |  |  | 1,075 |  |
| Selling, general, and administrative |  |  |  |  | 7,848 |  |  | 6,011 |  |
| Total share-based compensation expense |  |  |  |  | $ | 10,786 |  |  | $ | 8,641 |  |

[0000926326-25-000009:notes:162]
During the three months ended March 31, 2025 and 2024, the Company capitalized approximately $0.8 million and $0.7 million, respectively, of share-based compensation expense to internal-use and external-use software development costs related to internal labor. The Company did not capitalize any material share-based compensation expense to inventory during the three months ended March 31, 2025 and 2024.

[0000926326-25-000009:notes:163]
[same as prior period, unchanged from 0000926326-24-000032:notes:141]

[0000926326-25-000009:notes:164]
The following assumptions were used to value shares under the ESPP for the three months ended March 31, 2025 and 2024:

[0000926326-25-000009:notes:165]
|  | Three Months Ended March 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  |  |  |  |
| Expected volatility, % | 45.8% - 58.7% |  | 33.7% - 57.0% |  |  |  |  |
| Risk-free interest rate, % | 4.1% - 5.2% |  | 1.5% - 5.5% |  |  |  |  |
| Dividend yield, % | — | % |  | — | % |  |  |  |  |

[0000926326-25-000009:notes:166]
For the three months ended March 31, 2025 and 2024, employees purchased approximately 335,000 and 334,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $24.57 and $24.06, respectively.

[0000926326-25-000009:notes:167]
[same as prior period, unchanged from 0000926326-24-000032:notes:145]

[0000926326-25-000009:notes:168]
The following table summarizes the stock option activity under the 2009 Plan:

[0000926326-25-000009:notes:169]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2024 | 1,760 |  |  | $ | 67.51 |  |  | 3.6 |  | $ | 2,619 |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (1) |  |  | 30.92 |  |  |  |  |  |
| Expired | (34) |  |  | 65.41 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Outstanding at March 31, 2025 | 1,725 |  |  | $ | 67.58 |  |  | 3.4 |  | $ | 426 |  |
| Exercisable at March 31, 2025 | 1,723 |  |  | $ | 67.50 |  |  | 3.4 |  | $ | 426 |  |
| Vested and expected to vest at March 31, 2025 and thereafter | 1,725 |  |  | $ | 67.58 |  |  | 3.4 |  | $ | 426 |  |

[0000926326-25-000009:notes:170]
[same as prior period, unchanged from 0000926326-24-000032:notes:151]

[0000926326-25-000009:notes:171]
The following table summarizes the RSU activity under the 2009 Plan:

[0000926326-25-000009:notes:172]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2024 | 1,614 |  |  | $ | 54.58 |  |  | 1.6 |  | $ | 71,849 |  |
| Granted | 160 |  |  | 33.87 |  |  |  |  |  |
| Vested | (110) |  |  | 66.08 |  |  |  |  |  |
| Forfeited | (139) |  |  | 55.85 |  |  |  |  |  |
| Outstanding and unvested at March 31, 2025 | 1,525 |  |  | $ | 51.46 |  |  | 1.5 |  | $ | 53,326 |  |

[0000926326-25-000009:notes:173]
As of March 31, 2025, total unrecognized compensation cost related to RSUs was $49.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.8 years.

[0000926326-25-000009:notes:174]
[same as prior period, unchanged from 0000926326-24-000032:notes:159]

[0000926326-25-000009:notes:175]
The following table summarizes the PSU activity under the 2009 Plan:

[0000926326-25-000009:notes:176]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2024 | 177 |  |  | $ | 28.67 |  |
| Granted (Awarded) | 139 |  |  | 32.66 |  |
| Additional granted based on performance achievement | 135 |  |  | 28.67 |  |
| Vested (Released) | (78) |  |  | 28.67 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at March 31, 2025 | 373 |  |  | $ | 30.16 |  |

[0000926326-25-000009:notes:177]
As of March 31, 2025, total unrecognized compensation cost related to PSUs was approximately $5.6 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.5 years.

[0000926326-25-000009:notes:178]
[same as prior period, unchanged from 0000926326-24-000032:notes:163]

[0000926326-25-000009:notes:179]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of March 31, 2025:

[0000926326-25-000009:notes:180]
|  | Number of Shares |
|  | (In thousands) |
| Stock options outstanding | 1,725 |  |
| Non-vested restricted stock awards | 1,947 |  |
| Shares authorized for future issuance | 2,845 |  |
| ESPP shares available for future issuance | 2,391 |  |
| Total shares reserved for future issuance | 8,908 |  |

[0000926326-25-000009:notes:181]
[same as prior period, unchanged from 0000926326-24-000032:notes:166]

[0000926326-25-000009:notes:182]
On August 2, 2016, the Company’s Board of Directors (the “Board”) authorized a stock repurchase program, which does not expire, providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). As of March 31, 2025, the maximum dollar value of shares that may yet be purchased under the 2016 Repurchase Program was $2.7 million.

[0000926326-25-000009:notes:183]
The timing, price, and volume of repurchases are to be based on market conditions, relevant securities laws, and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions, or

[0000926326-25-000009:notes:184]
pursuant to a Rule 10b-18 plan, subject to the terms and conditions of the Second A&R Credit Agreement, as amended. The 2016 Repurchase Program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the 2016 Repurchase Program at any time.

[0000926326-25-000009:notes:185]
During the three months ended March 31, 2025 and 2024, the Company did not repurchase any of its outstanding common stock under the 2016 Repurchase Program.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-25-000009:notes:186]
Restructuring Expenses
On April 26, 2024, the Company’s management committed to the wind down of the Company’s Medimat Robotic Dispensing System (“RDS”) product line, subject to local law and statutory works council consultation requirements. During the three months ended March 31, 2024, the Company incurred approximately $3.3 million of employee severance costs and other expenses related to the RDS product line wind down.

[0000926326-25-000009:notes:187]
The following table summarizes the total employee-related restructuring expense recognized in the Company’s Condensed Consolidated Statements of Operations:

[0000926326-25-000009:notes:188]
|  |  |  |  |  | Three Months Ended March 31, |
|  |  |  |  |  |  |  | 2024 |
|  |  |  |  |  |  |  | (In thousands) |
| Cost of product and service revenues |  |  |  |  |  |  | $ | 2,696 |  |
| Research and development |  |  |  |  |  |  | 311 |  |
| Selling, general, and administrative |  |  |  |  |  |  | 156 |  |
| Total restructuring expenses |  |  |  |  |  |  | $ | 3,163 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000926326-25-000009:notes:189]
During the three months ended March 31, 2025, Randall A. Lipps, the Company’s President, Chief Executive Officer, and Chairman of the Board of Directors, adopted a new “Rule 10b5-1 trading arrangement” (as defined in Item 408(a) of Regulation S-K) on March 14, 2025, which is intended to satisfy the Rule 10b5-1(c) affirmative defense. Mr. Lipps’ trading plan is effective from September 30, 2025 until the earlier of: (1) September 30, 2026; or (2) the date on which all of the transactions under the trading plan are completed. The trading plan is intended to let Mr. Lipps sell up to 46,750 shares of common stock and exercise and sell up to 28,250 stock options expiring on February 3, 2026. As of the date of this report, none of the shares were sold, nor any options exercised and no other adjustments were made to the trading plan during the current reporting period.
