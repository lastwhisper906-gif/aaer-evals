# OMCL notes — 0000926326-21-000034


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-21-000034:notes:1]
[same as prior period, unchanged from 0000926326-21-000026:notes:1]

[0000926326-21-000034:notes:2]
[same as prior period, unchanged from 0000926326-21-000026:notes:2]

[0000926326-21-000034:notes:3]
[same as prior period, unchanged from 0000926326-21-000026:notes:3]

[0000926326-21-000034:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2021 and December 31, 2020, the results of operations and comprehensive income for the three and nine months ended September 30, 2021 and 2020, and cash flows for the nine months ended September 30, 2021 and 2020. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 24, 2021, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2021, and cash flows for the nine months ended September 30, 2021 are not necessarily indicative of results that may be expected for the year ending December 31, 2021, or for any future period.

[0000926326-21-000034:notes:5]
[same as prior period, unchanged from 0000926326-21-000026:notes:5]

[0000926326-21-000034:notes:6]
[same as prior period, unchanged from 0000926326-21-000026:notes:6]

[0000926326-21-000034:notes:7]
On September 9, 2021, the Company completed its acquisition of RxInnovation Inc., operating as FDS Amplicare (“FDS Amplicare”). The Condensed Consolidated Financial Statements include the results of operations of this recently acquired company, commencing as of the acquisition date. The significant accounting policies of the acquired business have been aligned to conform to the accounting policies of Omnicell.

[0000926326-21-000034:notes:8]
[same as prior period, unchanged from 0000926326-21-000026:notes:7]

[0000926326-21-000034:notes:9]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of revenues for the three and nine months ended September 30, 2020 in Note 3, Revenues. This change was not deemed material and was included to conform with current-period classification and presentation.

[0000926326-21-000034:notes:10]
[same as prior period, unchanged from 0000926326-21-000026:notes:9]

[0000926326-21-000034:notes:11]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.

[0000926326-21-000034:notes:12]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of September 30, 2021, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-21-000034:notes:13]
[same as prior period, unchanged from 0000926326-21-000026:notes:12]

[0000926326-21-000034:notes:14]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company's Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM

[0000926326-21-000034:notes:15]
allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.

[0000926326-21-000034:notes:16]
[same as prior period, unchanged from 0000926326-21-000026:notes:14]

[0000926326-21-000034:notes:17]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The update simplifies the accounting for income taxes by removing certain exceptions to the general principles in Accounting Standards Codification (“ASC”) 740, Income Taxes, as well as improves consistent application of and simplifies the guidance for other areas of ASC 740 by clarifying and amending existing guidance. The Company adopted ASU 2019-12 on January 1, 2021 on a prospective basis. The adoption of this guidance did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000926326-21-000034:notes:18]
[same as prior period, unchanged from 0000926326-21-000026:notes:16]

[0000926326-21-000034:notes:19]
In August 2020, the FASB issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. This update permits the use of either the modified retrospective or fully retrospective method of transition. The Company will adopt ASU 2020-06 on January 1, 2022, and expects to use the modified retrospective method of transition. The Company’s adoption of the update is estimated to result in an increase in convertible senior notes, net of issuance costs, of $75.4 million; a decrease in additional paid-in capital of $72.7 million; a decrease of long-term deferred tax liabilities of $19.8 million; a decrease in long-term deferred tax assets of $0.5 million; and an increase in retained earnings of $16.7 million, all as of January 1, 2022.

[0000926326-21-000034:notes:20]
[same as prior period, unchanged from 0000926326-21-000026:notes:18]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-21-000034:notes:21]
Business Combinations
FDS Amplicare Acquisition

[0000926326-21-000034:notes:22]
On September 9, 2021, the Company completed its acquisition of all of the outstanding equity interests in FDS Amplicare, pursuant to the terms and conditions of the Agreement and Plan of Merger, dated July 25, 2021, by and among FDS Amplicare, Omnicell, Inc., Fleming Acquisition Corp., and the representative of the securityholders for a base purchase price of $177.0 million, prior to post-closing adjustments for closing cash, net working capital, and assumed indebtedness, which is expected to be finalized in the fourth quarter of 2021. The following table summarizes the preliminary purchase price for the FDS Amplicare acquisition:

[0000926326-21-000034:notes:23]
|  | FDS Amplicare |
|  | (In thousands) |
| Base purchase price | $ | 177,000 |  |
| Add: Estimated closing cash | 859 |  |
| Add: Estimated net working capital adjustment | 1,333 |  |
| Less: Assumed indebtedness | (647) |  |
| Total purchase price transferred | $ | 178,545 |  |

[0000926326-21-000034:notes:24]
The FDS Amplicare acquisition adds a comprehensive and complementary suite of software-as-a-services (“SaaS”) financial management, analytics, and population health solutions to Omnicell’s EnlivenHealthTM offering. The results of FDS Amplicare’s operations have been included in the Company’s consolidated results of operations, commencing as of the acquisition date.

[0000926326-21-000034:notes:25]
The Company accounted for the acquisition of FDS Amplicare in accordance with ASC 805, Business Combinations. The tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition date. The preliminary fair values assume management’s best estimates based on information available at the acquisition date and may change over the measurement period, which will end no later than one year from the acquisition date, as additional information is received. The following table represents the preliminary allocation of the purchase price to the assets acquired and the liabilities assumed by the Company as part of the acquisition included in the Company’s Condensed Consolidated Balance Sheets, and is reconciled to the purchase price transferred:

[0000926326-21-000034:notes:26]
|  | FDS Amplicare(Preliminary) |
|  | (In thousands) |
| Cash and cash equivalents | $ | 465 |  |
| Accounts receivable and unbilled receivables | 4,235 |  |
| Prepaid expenses | 506 |  |
| Other current assets | 45 |  |
| Total current assets | 5,251 |  |
| Property and equipment | 444 |  |
| Operating lease right-of-use assets | 2,252 |  |
| Goodwill | 118,846 |  |
| Intangible assets | 69,600 |  |
| Other long-term assets | 51 |  |
| Total assets | 196,444 |  |
| Accounts payable | 950 |  |
| Accrued compensation | 1,312 |  |
| Accrued liabilities | 1,396 |  |
| Deferred revenues | 1,916 |  |
| Long-term deferred tax liabilities | 11,275 |  |
| Long-term operating lease liabilities | 920 |  |
| Other long-term liabilities | 130 |  |
| Total liabilities | 17,899 |  |
| Total purchase price | $ | 178,545 |  |
| Total purchase price, net of cash acquired | $ | 178,080 |  |

[0000926326-21-000034:notes:27]
The $118.8 million of goodwill arising from the FDS Amplicare acquisition is primarily attributed to sales of future SaaS solutions and FDS Amplicare’s assembled workforce. None of the goodwill is expected to be deductible for tax purposes.

[0000926326-21-000034:notes:28]
Intangible assets eligible for recognition separate from goodwill were those that satisfied either the contractual or legal criterion or the separability criterion in the accounting guidance. The identifiable intangible assets acquired and their estimated useful lives for amortization are as follows:

[0000926326-21-000034:notes:29]
|  | FDS Amplicare |
|  | Fair value |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 59,500 |  |  | 23 |
| Acquired technology | 7,700 |  |  | 5 - 7 |
| Trade names | 2,400 |  |  | 5 |
| Total purchased intangible assets | $ | 69,600 |  |  |  |

[0000926326-21-000034:notes:30]
The customer relationships intangible asset represents the fair value of the underlying relationships and agreements with FDS Amplicare’s customers. The acquired technology intangible assets represent the fair value of FDS Amplicare’s portfolio of SaaS solutions that have reached technological feasibility and were part of FDS Amplicare’s offerings at the

[0000926326-21-000034:notes:31]
acquisition date. The trade names intangible asset represents the fair value of brand and name recognition associated with the marketing of certain FDS Amplicare SaaS solutions.

[0000926326-21-000034:notes:32]
The fair value of the customer relationships intangible asset was determined based on the excess earnings method, and the fair values of the acquired technology and trade names intangible assets were determined based on the relief-from-royalty method. The key assumptions used in estimating the fair values of intangible assets included forecasted financial information; customer attrition rates; royalty rates of 10.0% and 2.0% for the acquired technology and trade names intangible assets, respectively; a discount rate of 13.0% for all intangible assets; and certain other assumptions.

[0000926326-21-000034:notes:33]
The customer relationships and acquired technology intangible assets are being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. The trade names intangible asset is being amortized over its estimated useful life using the straight-line method of amortization.

[0000926326-21-000034:notes:34]
The Company believes that the fair values assigned to the assets acquired and liabilities assumed are based on reasonable assumptions and estimates that market participants would use. Actual results may differ from these estimates and assumptions.

[0000926326-21-000034:notes:35]
The Company incurred approximately $4.6 million and $6.6 million in acquisition-related costs related to the FDS Amplicare acquisition during the three and nine months ended September 30, 2021, respectively. These costs were expensed as incurred, and are included in selling, general, and administrative expenses in the Company’s Condensed Consolidated Statements of Operations.

[0000926326-21-000034:notes:36]
340B Link Business Acquisition

[0000926326-21-000034:notes:37]
On October 1, 2020, the Company completed the acquisition of all of the outstanding equity of the 340B Link business (the “340B Link Business”) of Pharmaceutical Strategies Group, LLC pursuant to the terms and conditions of the Equity Purchase Agreement, dated August 11, 2020, as amended, by and among Omnicell, Inc., PSGH, LLC, BW Apothecary Holdings, LLC, the sellers identified therein, and the sellers’ representative for total cash consideration of $225.0 million. The 340B Link Business acquisition adds a comprehensive and differentiated suite of software-enabled services and solutions used by certain eligible hospitals, health systems, clinics, and entities to manage compliance and capture 340B drug cost savings on outpatient prescriptions filled through the eligible entity’s pharmacy or a contracted pharmacy partner. The results of the 340B Link Business’s operations have been included in the Company’s consolidated results of operations, commencing as of the acquisition date.

[0000926326-21-000034:notes:38]
The Company accounted for the acquisition of the 340B Link Business in accordance with ASC 805. The tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition date. The following table represents the allocation of the purchase price to the assets acquired and the liabilities assumed by the Company as part of the acquisition included in the Company’s Condensed Consolidated Balance Sheets, and is reconciled to the purchase price transferred:

[0000926326-21-000034:notes:39]
|  | 340B Link Business |
|  | (In thousands) |
| Accounts receivable and unbilled receivables | $ | 8,197 |  |
| Prepaid expenses | 232 |  |
| Other current assets (1) | 23,040 |  |
| Total current assets | 31,469 |  |
| Property and equipment | 531 |  |
| Operating lease right-of-use assets | 3,138 |  |
| Goodwill (1) | 160,268 |  |
| Intangible assets | 62,800 |  |
| Total assets | 258,206 |  |
| Accounts payable | 568 |  |
| Accrued liabilities (1) | 23,715 |  |
| Long-term deferred tax liabilities (1) | 6,334 |  |
| Long-term operating lease liabilities | 2,589 |  |
| Total liabilities | 33,206 |  |
| Total purchase price | $ | 225,000 |  |

[0000926326-21-000034:notes:40]
_________________________________________________

[0000926326-21-000034:notes:41]
(1)    During the third quarter of 2021, the Company recorded measurement period adjustments of $0.9 million to goodwill, consisting of an increase in other current assets, a decrease in accrued liabilities, and a decrease in long-term deferred tax liabilities of $0.3 million, $0.1 million, and $0.5 million, respectively.

[0000926326-21-000034:notes:42]
The $160.3 million of goodwill arising from the 340B Link Business acquisition is primarily attributed to sales of future software-enabled services and solutions and the 340B Link Business’s assembled workforce. Goodwill that is expected to be deductible for tax purposes is approximately $93.7 million.

[0000926326-21-000034:notes:43]
|  | 340B Link Business |
|  | Fair value |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 53,000 |  |  | 21 |
| Acquired technology | 9,000 |  |  | 5 |
| Trade names | 200 |  |  | 1 |
| Non-compete agreements | 600 |  |  | 3 |
| Total purchased intangible assets | $ | 62,800 |  |  |  |

[0000926326-21-000034:notes:44]
The customer relationships intangible asset represents the fair value of the underlying relationships and agreements with the 340B Link Business’s customers. The acquired technology intangible asset represents the fair value of the 340B Link Business’s portfolio of software and solutions that have reached technological feasibility and were part of the 340B Link Business’s offerings at the acquisition date. The trade names intangible asset represents the fair value of brand and name recognition associated with the marketing of the 340B Link Business’s software-enabled services and solutions. The non-compete agreements intangible asset represents the fair value of non-compete agreements with former key members of the 340B Link Business’s management.

[0000926326-21-000034:notes:45]
[same as prior period, unchanged from 0000926326-21-000026:notes:27]

[0000926326-21-000034:notes:46]
[same as prior period, unchanged from 0000926326-21-000026:notes:28]

[0000926326-21-000034:notes:47]
The Company incurred approximately $3.9 million in acquisition-related costs related to the 340B Link Business acquisition during the nine months ended September 30, 2020. These costs were expensed as incurred, and are included in selling, general, and administrative expenses in the Company’s Condensed Consolidated Statements of Operations.

[0000926326-21-000034:notes:48]
[same as prior period, unchanged from 0000926326-21-000026:notes:30]

[0000926326-21-000034:notes:49]
The following table presents certain unaudited pro forma consolidated financial information for the three and nine months ended September 30, 2021 and 2020 as if the FDS Amplicare acquisition had been completed on January 1, 2020 and the 340B Link Business acquisition had been completed on January 1, 2019. The unaudited pro forma financial information is presented for informational purposes only, and is not indicative of what would have occurred had the FDS Amplicare acquisition and the 340B Link Business acquisition taken place on January 1, 2020 and January 1, 2019, respectively. The unaudited pro forma financial information combines the historical results of the acquisitions with the Company’s consolidated historical results and includes certain adjustments including, but not limited to, amortization and depreciation of intangible assets and property and equipment acquired; imputed interest, interest expense, and amortization of debt issuance costs related to acquisitions, as applicable; and certain acquisition-related costs incurred.

[0000926326-21-000034:notes:50]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Pro forma revenues | $ | 302,114 |  |  | $ | 230,099 |  |  | $ | 840,896 |  |  | $ | 689,208 |  |
| Pro forma net income | $ | 32,050 |  |  | $ | 10,350 |  |  | $ | 65,194 |  |  | $ | 8,476 |  |


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0000926326-21-000034:notes:51]
The following table summarizes the preliminary purchase price for the FDS Amplicare acquisition:

[0000926326-21-000034:notes:52]
The following table represents the preliminary allocation of the purchase price to the assets acquired and the liabilities assumed by the Company as part of the acquisition included in the Company’s Condensed Consolidated Balance Sheets, and is reconciled to the purchase price transferred:

[0000926326-21-000034:notes:53]
The following table represents the allocation of the purchase price to the assets acquired and the liabilities assumed by the Company as part of the acquisition included in the Company’s Condensed Consolidated Balance Sheets, and is reconciled to the purchase price transferred:


## us-gaap:ScheduleOfIndefiniteLivedIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000926326-21-000034:notes:54]
The identifiable intangible assets acquired and their estimated useful lives for amortization are as follows:


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-21-000034:notes:55]
[same as prior period, unchanged from 0000926326-21-000026:notes:33]

[0000926326-21-000034:notes:56]
[same as prior period, unchanged from 0000926326-21-000026:notes:34]

[0000926326-21-000034:notes:57]
[same as prior period, unchanged from 0000926326-21-000026:notes:35]

[0000926326-21-000034:notes:58]
[same as prior period, unchanged from 0000926326-21-000026:notes:36]

[0000926326-21-000034:notes:59]
[same as prior period, unchanged from 0000926326-21-000026:notes:37]

[0000926326-21-000034:notes:60]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth (formerly Population Health

[0000926326-21-000034:notes:61]
Solutions) inclusive of newly acquired FDS Amplicare, 340B solutions, and services associated with Omnicell One™ (formerly Performance Center), Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IV compounding automation solutions.

[0000926326-21-000034:notes:62]
[same as prior period, unchanged from 0000926326-21-000026:notes:39]

[0000926326-21-000034:notes:63]
[same as prior period, unchanged from 0000926326-21-000026:notes:40]

[0000926326-21-000034:notes:64]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $4.4 million and $2.3 million for the three months ended September 30, 2021 and 2020, respectively, and $12.0 million and $6.9 million for the nine months ended September 30, 2021 and 2020, respectively.

[0000926326-21-000034:notes:65]
[same as prior period, unchanged from 0000926326-21-000026:notes:42]

[0000926326-21-000034:notes:66]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and nine months ended September 30, 2021 and 2020:

[0000926326-21-000034:notes:67]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 195,820 |  |  | $ | 135,037 |  |  | $ | 534,582 |  |  | $ | 403,761 |  |
| Technical services | 53,529 |  |  | 51,380 |  |  | 156,321 |  |  | 151,077 |  |
| Consumables | 18,150 |  |  | 16,300 |  |  | 54,424 |  |  | 56,591 |  |
| SaaS, subscription software, and technology-enabled services | 28,903 |  |  | 10,982 |  |  | 75,657 |  |  | 31,577 |  |
| Total revenues | $ | 296,402 |  |  | $ | 213,699 |  |  | $ | 820,984 |  |  | $ | 643,006 |  |

[0000926326-21-000034:notes:68]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2021 and 2020:

[0000926326-21-000034:notes:69]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| United States | $ | 271,276 |  |  | $ | 193,639 |  |  | $ | 738,411 |  |  | $ | 579,425 |  |
| Rest of world (1) | 25,126 |  |  | 20,060 |  |  | 82,573 |  |  | 63,581 |  |
| Total revenues | $ | 296,402 |  |  | $ | 213,699 |  |  | $ | 820,984 |  |  | $ | 643,006 |  |

[0000926326-21-000034:notes:70]
[same as prior period, unchanged from 0000926326-21-000026:notes:48]

[0000926326-21-000034:notes:71]
[same as prior period, unchanged from 0000926326-21-000026:notes:49]

[0000926326-21-000034:notes:72]
[same as prior period, unchanged from 0000926326-21-000026:notes:50]

[0000926326-21-000034:notes:73]
|  | September 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 17,879 |  |  | $ | 13,895 |  |
| Long-term unbilled receivables, net (2) | 14,460 |  |  | 17,205 |  |
| Total contract assets | $ | 32,339 |  |  | $ | 31,100 |  |
| Short-term deferred revenues, net | $ | 114,726 |  |  | $ | 100,053 |  |
| Long-term deferred revenues | 14,141 |  |  | 5,673 |  |
| Total contract liabilities | $ | 128,867 |  |  | $ | 105,726 |  |

[0000926326-21-000034:notes:74]
[same as prior period, unchanged from 0000926326-21-000026:notes:52]

[0000926326-21-000034:notes:75]
[same as prior period, unchanged from 0000926326-21-000026:notes:53]

[0000926326-21-000034:notes:76]
[same as prior period, unchanged from 0000926326-21-000026:notes:54]

[0000926326-21-000034:notes:77]
Short-term deferred revenues of $114.7 million and $100.1 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $24.1 million and $21.0 million, as of September 30, 2021 and December 31, 2020, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and nine months ended September 30, 2021, the Company recognized revenues of $18.9 million and $90.0 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $121.1 million as of December 31, 2020.

[0000926326-21-000034:notes:78]
Long-term deferred revenues include deferred revenues from product and service contracts of $14.1 million and $5.7 million as of September 30, 2021 and December 31, 2020, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.

[0000926326-21-000034:notes:79]
[same as prior period, unchanged from 0000926326-21-000026:notes:57]

[0000926326-21-000034:notes:80]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2021 and 2020. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of September 30, 2021 and December 31, 2020.


## us-gaap:EarningsPerShareTextBlock

[0000926326-21-000034:notes:81]
Net Income Per ShareBasic net income (loss) per share is computed by dividing net income (loss) for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period, using the treasury stock method. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units, as well as shares the Company could be obligated to issue from its convertible senior notes and warrants, as described in Note 10, Convertible Senior Notes. Any anti-dilutive weighted-average dilutive shares related to stock award plans, convertible senior notes, and warrants are excluded from the computation of the diluted net income per share. 
The basic and diluted net income per share calculations for the three and nine months ended September 30, 2021 and 2020 were as follows:

[0000926326-21-000034:notes:82]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands, except per share data) |
| Net income | $ | 29,317 |  |  | $ | 8,805 |  |  | $ | 63,868 |  |  | $ | 15,817 |  |
| Weighted-average shares outstanding – basic | 43,648 |  |  | 42,802 |  |  | 43,293 |  |  | 42,606 |  |
| Effect of dilutive securities from stock award plans | 2,087 |  |  | 889 |  |  | 2,086 |  |  | 1,045 |  |
| Effect of convertible senior notes | 2,156 |  |  | — |  |  | 1,816 |  |  | — |  |
| Effect of warrants | 450 |  |  | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding – diluted | 48,341 |  |  | 43,691 |  |  | 47,195 |  |  | 43,651 |  |
| Net income per share – basic | $ | 0.67 |  |  | $ | 0.21 |  |  | $ | 1.48 |  |  | $ | 0.37 |  |
| Net income per share – diluted | $ | 0.61 |  |  | $ | 0.20 |  |  | $ | 1.35 |  |  | $ | 0.36 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 64 |  |  | 2,328 |  |  | 199 |  |  | 2,076 |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | — |  |  | 11,816 |  |  | 5,908 |  |  | 11,816 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-21-000034:notes:83]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $481.5 million and $485.9 million as of September 30, 2021 and December 31, 2020, respectively, consisted of bank accounts and highly-liquid U.S. Government money market funds held in sweep and asset management accounts with major financial institutions. As of September 30, 2021 and December 31, 2020, cash equivalents were $449.1 million and $447.2 million, respectively, which consisted of money market funds held in sweep and asset management accounts.

[0000926326-21-000034:notes:84]
[same as prior period, unchanged from 0000926326-21-000026:notes:62]

[0000926326-21-000034:notes:85]
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's credit facility is classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company's convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. As of September 30, 2021, the fair value of the convertible senior notes was $917.0 million, compared to their carrying value of $482.8 million, which is net of unamortized discount and debt issuance costs and excludes amounts classified within additional paid-in capital. Refer to Note 9, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 10, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-21-000034:notes:86]
Balance Sheet Components
Balance sheet details as of September 30, 2021 and December 31, 2020 are presented in the tables below:

[0000926326-21-000034:notes:87]
|  | September 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 40,844 |  |  | $ | 28,205 |  |
| Work in process | 7,591 |  |  | 7,973 |  |
| Finished goods | 55,824 |  |  | 60,120 |  |
| Total inventories | $ | 104,259 |  |  | $ | 96,298 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 20,150 |  |  | $ | 18,164 |  |
| Net investment in sales-type leases, current portion | 10,529 |  |  | 10,246 |  |
| Prepaid income taxes | 5,706 |  |  | 10,095 |  |
| Other current assets | 8,032 |  |  | 2,539 |  |
| Total other current assets | $ | 44,417 |  |  | $ | 41,044 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net | $ | 98,559 |  |  | $ | 94,027 |  |
| Unbilled receivables, net | 14,460 |  |  | 17,205 |  |
| Deferred debt issuance costs | 3,430 |  |  | 4,253 |  |
| Other long-term assets | 4,033 |  |  | 3,804 |  |
| Total other long-term assets | $ | 120,482 |  |  | $ | 119,289 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 13,009 |  |  | $ | 12,197 |  |
| Customer fund liabilities | 20,150 |  |  | 18,164 |  |
| Advance payments from customers | 8,201 |  |  | 6,981 |  |
| Rebates and lease buyouts | 39,743 |  |  | 21,815 |  |
| Group purchasing organization fees | 5,940 |  |  | 4,412 |  |
| Taxes payable | 2,049 |  |  | 3,520 |  |
| Other accrued liabilities | 15,144 |  |  | 13,222 |  |
| Total accrued liabilities | $ | 104,236 |  |  | $ | 80,311 |  |

[0000926326-21-000034:notes:88]
(1)    Includes restricted cash of $0.6 million and $4.0 million as of September 30, 2021 and December 31, 2020, respectively.

[0000926326-21-000034:notes:89]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss), which consisted of foreign currency translation adjustments, for the three and nine months ended September 30, 2021 and 2020:

[0000926326-21-000034:notes:90]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Beginning balance | $ | (5,491) |  |  |  |  |  |  | $ | (13,689) |  |  |  |  |  |  | $ | (5,522) |  |  | $ | (9,446) |  |
| Other comprehensive income (loss) | (2,299) |  |  |  |  |  |  | 3,510 |  |  |  |  |  |  | (2,268) |  |  | (733) |  |
| Ending balance | $ | (7,790) |  |  |  |  |  |  | $ | (10,179) |  |  |  |  |  |  | $ | (7,790) |  |  | $ | (10,179) |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-21-000034:notes:91]
Property and Equipment
The following table represents the property and equipment balances as of September 30, 2021 and December 31, 2020:

[0000926326-21-000034:notes:92]
|  | September 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Equipment | $ | 87,061 |  |  | $ | 81,034 |  |
| Furniture and fixtures | 6,999 |  |  | 7,498 |  |
| Leasehold improvements | 20,365 |  |  | 19,517 |  |
| Software | 57,575 |  |  | 50,230 |  |
| Construction in progress | 8,943 |  |  | 7,095 |  |
| Property and equipment, gross | 180,943 |  |  | 165,374 |  |
| Accumulated depreciation and amortization | (115,988) |  |  | (106,301) |  |
| Total property and equipment, net | $ | 64,955 |  |  | $ | 59,073 |  |

[0000926326-21-000034:notes:93]
Depreciation and amortization expense of property and equipment was $5.2 million and $4.6 million for the three months ended September 30, 2021 and 2020, respectively, and $14.9 million and $13.6 million for the nine months ended September 30, 2021 and 2020, respectively.

[0000926326-21-000034:notes:94]
The geographic location of the Company's property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of September 30, 2021 and December 31, 2020:

[0000926326-21-000034:notes:95]
|  | September 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| United States | $ | 60,384 |  |  | $ | 53,203 |  |
| Rest of world (1) | 4,571 |  |  | 5,870 |  |
| Total property and equipment, net | $ | 64,955 |  |  | $ | 59,073 |  |

[0000926326-21-000034:notes:96]
[same as prior period, unchanged from 0000926326-21-000026:notes:74]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-21-000034:notes:97]
[same as prior period, unchanged from 0000926326-21-000026:notes:75]

[0000926326-21-000034:notes:98]
[same as prior period, unchanged from 0000926326-21-000026:notes:76]

[0000926326-21-000034:notes:99]
|  | December 31,2020 |  | Additions (1) |  | 340B Link Business Measurement Period Adjustments (1) |  | Foreign currency exchange rate fluctuations |  | September 30,2021 |
|  | (In thousands) |
| Goodwill | $ | 499,309 |  |  | 118,846 |  |  | (849) |  |  | (919) |  |  | $ | 616,387 |  |

[0000926326-21-000034:notes:100]
(1) Refer to Note 2, Business Combinations, for further information.

[0000926326-21-000034:notes:101]
[same as prior period, unchanged from 0000926326-21-000026:notes:78]

[0000926326-21-000034:notes:102]
The carrying amounts and useful lives of intangible assets as of September 30, 2021 and December 31, 2020 were as follows:

[0000926326-21-000034:notes:103]
|  | September 30, 2021 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 247,389 |  |  | $ | (73,845) |  |  | $ | (916) |  |  | $ | 172,628 |  |  | 10 - 30 |
| Acquired technology | 93,366 |  |  | (52,631) |  |  | 6 |  |  | 40,741 |  |  | 5 - 20 |
| Trade names | 9,400 |  |  | (5,539) |  |  | 14 |  |  | 3,875 |  |  | 1 - 12 |
| Patents | 2,890 |  |  | (1,578) |  |  | — |  |  | 1,312 |  |  | 2 - 20 |
| Non-compete agreements | 600 |  |  | (200) |  |  | — |  |  | 400 |  |  | 3 |
| Total intangibles assets, net | $ | 353,645 |  |  | $ | (133,793) |  |  | $ | (896) |  |  | $ | 218,956 |  |  |  |

[0000926326-21-000034:notes:104]
[same as prior period, unchanged from 0000926326-21-000026:notes:81]

[0000926326-21-000034:notes:105]
(1)     The differences in gross carrying amounts between periods are primarily due to additions of intangible assets in connection with the FDS Amplicare acquisition, partially offset by the write-off of certain fully amortized intangible assets.

[0000926326-21-000034:notes:106]
Amortization expense of intangible assets was $6.3 million and $4.4 million for the three months ended September 30, 2021 and 2020, respectively, and $18.7 million and $13.3 million for the nine months ended September 30, 2021 and 2020, respectively.

[0000926326-21-000034:notes:107]
[same as prior period, unchanged from 0000926326-21-000026:notes:84]

[0000926326-21-000034:notes:108]
|  | September 30,2021 |
|  | (In thousands) |
| Remaining three months of 2021 | $ | 7,818 |  |
| 2022 | 28,772 |  |
| 2023 | 25,580 |  |
| 2024 | 18,462 |  |
| 2025 | 16,670 |  |
| Thereafter | 121,654 |  |
| Total | $ | 218,956 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-21-000034:notes:109]
Debt and Credit Agreement
2019 Revolving Credit Facility

[0000926326-21-000034:notes:110]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility (the “Prior Credit Agreement”) and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-21-000034:notes:111]
Loans under the Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. The applicable margin for, and certain other terms of, any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

[0000926326-21-000034:notes:112]
On September 22, 2020, the parties entered into an amendment (the “Amendment”) to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

[0000926326-21-000034:notes:113]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of September 30, 2021.

[0000926326-21-000034:notes:114]
The refinancing of the Prior Credit Agreement by means of the A&R Credit Agreement was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the A&R Credit Agreement.

[0000926326-21-000034:notes:115]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. In connection with the Amendment on September 22, 2020, the Company incurred and capitalized an additional $0.6 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs for credit agreements was

[0000926326-21-000034:notes:116]
approximately $0.3 million and $0.2 million for the three months ended September 30, 2021 and 2020, respectively, and approximately $0.8 million and $0.7 million for the nine months ended September 30, 2021 and 2020, respectively.

[0000926326-21-000034:notes:117]
The following table represents changes in the balance of the Company's deferred debt issuance costs:

[0000926326-21-000034:notes:118]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (823) |  |
| Balance as of September 30, 2021 | $ | 3,430 |  |

[0000926326-21-000034:notes:119]
As of each of September 30, 2021 and December 31, 2020, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-21-000034:notes:120]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

[0000926326-21-000034:notes:121]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

[0000926326-21-000034:notes:122]
During the three months ended September 30, 2021, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on September 30, 2021, the last trading day of the fiscal quarter. Accordingly, the Notes are convertible, in whole or in part, at the option of the holders during the fourth quarter of 2021. Whether the Notes will be convertible following the fourth fiscal quarter of 2021 will depend on the continued satisfaction of this condition or another conversion condition in the future. The Company continues to classify the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of September 30, 2021 based on contractual settlement provisions.

[0000926326-21-000034:notes:123]
Upon conversion, the Company may satisfy its conversion obligation by paying or delivering, as the case may be, cash, shares of its common stock, or a combination of cash and shares of its common stock, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in

[0000926326-21-000034:notes:124]
connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

[0000926326-21-000034:notes:125]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2021, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-21-000034:notes:126]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

[0000926326-21-000034:notes:127]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represents the debt discount, which the Company will amortize to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions. As of September 30, 2021, the remaining life of the Notes and the related debt discount and issuance cost accretion is approximately 4.0 years.

[0000926326-21-000034:notes:128]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 8.1 million shares. As of September 30, 2021, the if-converted value of the Notes exceeded the principal amount by $302.0 million.

[0000926326-21-000034:notes:129]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2021 and December 31, 2020:

[0000926326-21-000034:notes:130]
|  | September 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (81,870) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (10,308) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 482,822 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |

[0000926326-21-000034:notes:131]
(1)    Included in additional paid-in capital in the Condensed Consolidated Balance Sheets.

[0000926326-21-000034:notes:132]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2021:

[0000926326-21-000034:notes:133]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 20 |  |  | $ | 1,078 |  |  | $ | 20 |  |
| Amortization of discount | $ | 4,679 |  |  | $ | 249 |  |  | $ | 13,874 |  |  | $ | 249 |  |
| Amortization of debt issuance costs | $ | 589 |  |  | $ | 31 |  |  | $ | 1,747 |  |  | $ | 31 |  |

[0000926326-21-000034:notes:134]
Convertible Note Hedge and Warrant Transactions

[0000926326-21-000034:notes:135]
In connection with the issuance of the Notes, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

[0000926326-21-000034:notes:136]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.

[0000926326-21-000034:notes:137]
Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-21-000034:notes:138]
[same as prior period, unchanged from 0000926326-21-000026:notes:114]

[0000926326-21-000034:notes:139]
On a recurring basis, the Company enters into multi-year, sales-type lease agreements, with the majority varying in length from one to five years. The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 69% of the lease receivable balance, are retained in-house.

[0000926326-21-000034:notes:140]
The following table presents the Company’s income recognized from sales-type leases for the three and nine months ended September 30, 2021 and 2020:

[0000926326-21-000034:notes:141]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 3,892 |  |  | $ | 6,033 |  |  | $ | 14,503 |  |  | $ | 19,037 |  |
| Cost of sales-type lease revenues | (1,699) |  |  | (2,486) |  |  | (5,678) |  |  | (7,710) |  |
| Selling profit on sales-type lease revenues | $ | 2,193 |  |  | $ | 3,547 |  |  | $ | 8,825 |  |  | $ | 11,327 |  |
| Interest income on sales-type lease receivables | $ | 453 |  |  | $ | 450 |  |  | $ | 1,389 |  |  | $ | 1,437 |  |

[0000926326-21-000034:notes:142]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at September 30, 2021 and December 31, 2020:

[0000926326-21-000034:notes:143]
|  | September 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 32,109 |  |  | $ | 35,331 |  |
| Less: Unearned interest income portion | (2,393) |  |  | (2,929) |  |
| Net investment in sales-type leases | 29,716 |  |  | 32,402 |  |
| Less: Current portion (1) | (10,529) |  |  | (10,246) |  |
| Long-term investment in sales-type leases, net | $ | 19,187 |  |  | $ | 22,156 |  |

[0000926326-21-000034:notes:144]
[same as prior period, unchanged from 0000926326-21-000026:notes:120]

[0000926326-21-000034:notes:145]
[same as prior period, unchanged from 0000926326-21-000026:notes:121]

[0000926326-21-000034:notes:146]
[same as prior period, unchanged from 0000926326-21-000026:notes:122]

[0000926326-21-000034:notes:147]
|  | September 30,2021 |
|  | (In thousands) |
| Remaining three months of 2021 | $ | 2,876 |  |
| 2022 | 11,012 |  |
| 2023 | 8,123 |  |
| 2024 | 5,347 |  |
| 2025 | 3,409 |  |
| Thereafter | 1,342 |  |
| Total future minimum sales-type lease payments | 32,109 |  |
| Present value adjustment | (2,393) |  |
| Total net investment in sales-type leases | $ | 29,716 |  |

[0000926326-21-000034:notes:148]
[same as prior period, unchanged from 0000926326-21-000026:notes:124]

[0000926326-21-000034:notes:149]
[same as prior period, unchanged from 0000926326-21-000026:notes:125]

[0000926326-21-000034:notes:150]
The following table represents the Company’s income recognized from operating leases for the three and nine months ended September 30, 2021 and 2020:

[0000926326-21-000034:notes:151]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Rental income | $ | 2,474 |  |  | $ | 2,863 |  |  | $ | 8,278 |  |  | $ | 8,864 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-21-000034:notes:152]
Lessee Leases The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to 12 years. As of September 30, 2021, the Company did not have any additional material operating leases that were entered into, but not yet commenced.
The maturity schedule of future minimum lease payments under operating leases and the reconciliation to the operating lease liabilities reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-21-000034:notes:153]
|  | September 30,2021 |
|  | (In thousands) |
| Remaining three months of 2021 | $ | 3,782 |  |
| 2022 | 14,783 |  |
| 2023 | 10,949 |  |
| 2024 | 9,207 |  |
| 2025 | 6,463 |  |
| Thereafter | 17,275 |  |
| Total operating lease payments | 62,459 |  |
| Present value adjustment | (9,014) |  |
| Total operating lease liabilities (1) | $ | 53,445 |  |

[0000926326-21-000034:notes:154]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $13.0 million and $40.4 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-21-000034:notes:155]
Operating lease costs were $3.8 million and $3.5 million for the three months ended September 30, 2021 and 2020, respectively, and $11.1 million and $10.5 million for the nine months ended September 30, 2021 and 2020, respectively. Short-term lease costs and variable lease costs were immaterial for the three and nine months ended September 30, 2021 and 2020.

[0000926326-21-000034:notes:156]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the nine months ended September 30, 2021 and 2020:

[0000926326-21-000034:notes:157]
|  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 11,774 |  |  | $ | 10,543 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 2,804 |  |  | $ | 1,559 |  |

[0000926326-21-000034:notes:158]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of September 30, 2021 and December 31, 2020:

[0000926326-21-000034:notes:159]
|  | September 30,2021 |  | December 31,2020 |
| Weighted-average remaining lease term, years | 5.4 |  | 5.9 |
| Weighted-average discount rate, % | 5.7 | % |  | 5.8 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-21-000034:notes:160]
Commitments and Contingencies
Purchase Obligations

[0000926326-21-000034:notes:161]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2021, the Company had non-cancelable purchase commitments of $130.7 million, of which $88.8 million are expected to be paid within the year ending December 31, 2021.

[0000926326-21-000034:notes:162]
Legal Proceedings

[0000926326-21-000034:notes:163]
The Company is currently involved in various legal proceedings.

[0000926326-21-000034:notes:164]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a

[0000926326-21-000034:notes:165]
motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020. The Company's motion to dismiss is now fully briefed, however a date for oral argument on the motion is not currently scheduled. A status conference in the case has been set for November 12, 2021. The Company intends to defend the lawsuit vigorously.

[0000926326-21-000034:notes:166]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “BD Complaint”). This action (the “BD Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The BD Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees and costs, and pre-judgment and post-judgment interest. On March 17, 2021, the parties filed a joint motion to stay the BD Action, which motion was granted by the Court on June 8, 2021. The stay is in place for no more than 180 days, setting the deadline for filing the Company’s answer to the BD Complaint as December 6, 2021, unless an extension to such stay is mutually agreed to by the parties and approved by the Court. The Company intends to defend the lawsuit vigorously.

[0000926326-21-000034:notes:167]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceedings described above based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to these legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of any of these legal proceedings or because of the diversion of management’s attention and the creation of significant expenses.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-21-000034:notes:168]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 28.2% and 30.1% for the nine months ended September 30, 2021 and 2020, respectively.

[0000926326-21-000034:notes:169]
The Company continued its global operational centralization activities and legal entity rationalization during the third quarter of 2021. The Company recognized an immaterial gain from such activities during the nine months ended September 30, 2021. Due to continuing global operational centralization activities in the third quarter of 2020, the Company recognized a gain on Omnicell Limited transferring its shares in Omnicell GmbH to Omnicell International, LLC, which resulted in an immaterial discrete tax expense during the nine months ended September 30, 2020.

[0000926326-21-000034:notes:170]
The Company recognized a discrete tax benefit related to a release of net uncertain tax benefits of $6.2 million as a result of effective settlement with tax authorities for the nine months ended September 30, 2021, and related to equity compensation in the amount of $14.5 million and $4.2 million for the nine months ended September 30, 2021 and 2020, respectively.

[0000926326-21-000034:notes:171]
The 2021 annual effective tax rate before discrete items differed from the statutory rate of 21% primarily due to the unfavorable impact of state income taxes, non-deductible compensation and equity charges, and non-deductible transaction costs related to merger and acquisition activities, partially offset by the favorable impact of research and development credits and a foreign derived intangible income (“FDII”) benefit deduction. The 2020 annual effective tax rate before discrete items differed from the statutory rate of 21% primarily due to the unfavorable impact of state income taxes, non-deductible compensation and equity charges, and non-deductible expenses, partially offset by the favorable impact of research and development credits and a FDII benefit deduction.

[0000926326-21-000034:notes:172]
On March 11, 2021, the President of the United States signed into law the “American Rescue Plan Act of 2021” (the “ARP Act”), which provides additional economic stimulus and tax credits, including the expansion and modification of the employee retention tax credit enacted by the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) and the refundable tax credits for COVID-related paid sick and family leave enacted by the Family First Act. The Company does not expect these provisions of the ARP Act to have a material impact for income taxes. The ARP Act further provides revenue raising offsets to meet budget reconciliation rules, including the expansion of the “covered employees” definition for purposes of the Internal Revenue Code of 1986, as amended, as well as Section 162(m) limitation on the deduction for excessive employee remuneration rules to be applicable for taxable years beginning after December 31, 2026. The Company will continue to evaluate the impact of these provisions of the ARP Act on income taxes.

[0000926326-21-000034:notes:173]
As of September 30, 2021 and December 31, 2020, the Company had gross unrecognized tax benefits of $9.8 million and $18.2 million, respectively. The $8.4 million decrease in the gross uncertain tax benefits was primarily due to a release of certain unrecognized tax benefits as a result of an effective settlement with the tax authorities in the quarter ended September 30, 2021. It is the Company’s policy to classify accrued interest and penalties as part of unrecognized tax benefits, but to record interest and penalties in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. As of September 30, 2021 and December 31, 2020, the amount of accrued interest and penalties was $1.0 million and $1.4 million, respectively.

[0000926326-21-000034:notes:174]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examinations by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of September 30, 2021, the Company was no longer subject to the U.S., state, and foreign examinations for years before 2017, 2016, and 2016, respectively.

[0000926326-21-000034:notes:175]
[same as prior period, unchanged from 0000926326-21-000026:notes:151]


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-21-000034:notes:176]
[same as prior period, unchanged from 0000926326-21-000026:notes:152]

[0000926326-21-000034:notes:177]
For a detailed explanation of the Company's stock plans, refer to Note 14, Employee Benefits and Share-Based Compensation, of the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 24, 2021.

[0000926326-21-000034:notes:178]
[same as prior period, unchanged from 0000926326-21-000026:notes:154]

[0000926326-21-000034:notes:179]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2021 and 2020:

[0000926326-21-000034:notes:180]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,909 |  |  | $ | 1,758 |  |  | $ | 5,890 |  |  | $ | 5,658 |  |
| Research and development | 1,998 |  |  | 1,577 |  |  | 5,429 |  |  | 5,199 |  |
| Selling, general, and administrative | 9,759 |  |  | 7,689 |  |  | 27,158 |  |  | 22,177 |  |
| Total share-based compensation expense | $ | 13,666 |  |  | $ | 11,024 |  |  | $ | 38,477 |  |  | $ | 33,034 |  |

[0000926326-21-000034:notes:181]
[same as prior period, unchanged from 0000926326-21-000026:notes:157]

[0000926326-21-000034:notes:182]
The following assumptions were used to value shares under the ESPP for the three and nine months ended September 30, 2021 and 2020:

[0000926326-21-000034:notes:183]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |  | 0.5 - 2.0 |
| Expected volatility, % | 27.4% - 46.6% |  | 30.4% - 53.5% |  | 27.4% - 53.5% |  | 30.4% - 53.5% |
| Risk-free interest rate, % | 0.1% - 1.5% |  | 0.1% - 2.7% |  | 0.1% - 2.6% |  | 0.1% - 2.7% |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-21-000034:notes:184]
For the nine months ended September 30, 2021 and 2020, employees purchased approximately 287,000 and 333,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $62.14 and $48.77, respectively. As of September 30, 2021, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $3.1 million and is expected to be recognized over a weighted-average period of 1.5 years.

[0000926326-21-000034:notes:185]
[same as prior period, unchanged from 0000926326-21-000026:notes:161]

[0000926326-21-000034:notes:186]
The following assumptions were used to value stock options granted pursuant to the Company’s 2009 Equity Incentive Plan (as amended, the “2009 Plan”) for the three months ended September 30, 2020, and the nine months ended September 30, 2021 and 2020. There were no stock options granted during the three months ended September 30, 2021.

[0000926326-21-000034:notes:187]
|  |  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  |  | 2020 |  | 2021 |  | 2020 |
| Expected life, years |  |  | 4.7 |  | 4.9 |  | 4.7 |
| Expected volatility, % |  |  | 41.2 | % |  | 30.1 | % |  | 39.0 | % |
| Risk-free interest rate, % |  |  | 0.3 | % |  | 0.6 | % |  | 0.7 | % |
| Estimated forfeiture rate, % |  |  | 5.7 | % |  | 7.9 | % |  | 5.7 | % |
| Dividend yield, % |  |  | — | % |  | — | % |  | — | % |

[0000926326-21-000034:notes:188]
The following table summarizes the stock options activity during the nine months ended September 30, 2021:

[0000926326-21-000034:notes:189]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2020 | 3,932 |  |  | $ | 62.50 |  |  | 7.8 |  | $ | 226,160 |  |
| Granted | 150 |  |  | 125.80 |  |  |  |  |  |
| Exercised | (648) |  |  | 55.70 |  |  |  |  |  |
| Expired | (11) |  |  | 60.64 |  |  |  |  |  |
| Forfeited | (180) |  |  | 74.79 |  |  |  |  |  |
| Outstanding at September 30, 2021 | 3,243 |  |  | $ | 66.11 |  |  | 7.1 |  | $ | 266,946 |  |
| Exercisable at September 30, 2021 | 1,640 |  |  | $ | 51.96 |  |  | 5.8 |  | $ | 158,170 |  |
| Vested and expected to vest at September 30, 2021 and thereafter | 3,104 |  |  | $ | 65.35 |  |  | 7.0 |  | $ | 257,873 |  |

[0000926326-21-000034:notes:190]
The weighted-average fair value per share of options granted during the three months ended September 30, 2020 was $23.75, and the weighted-average fair value per share of options granted during the nine months ended September 30, 2021 and 2020 was $33.89 and $25.30, respectively. The intrinsic value of options exercised during the three months ended September 30, 2021 and 2020 was $26.0 million and $4.1 million, respectively, and during the nine months ended September 30, 2021 and 2020 was $56.8 million and $16.5 million, respectively.

[0000926326-21-000034:notes:191]
As of September 30, 2021, total unrecognized compensation cost related to unvested stock options was $38.4 million, which is expected to be recognized over a weighted-average vesting period of 2.4 years.

[0000926326-21-000034:notes:192]
[same as prior period, unchanged from 0000926326-21-000026:notes:168]

[0000926326-21-000034:notes:193]
The following table summarizes the restricted stock units activity under the 2009 Plan during the nine months ended September 30, 2021:

[0000926326-21-000034:notes:194]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2020 | 580 |  |  | $ | 72.87 |  |  | 1.6 |  | $ | 69,670 |  |
| Granted (Awarded) | 409 |  |  | 145.44 |  |  |  |  |  |
| Vested (Released) | (157) |  |  | 72.39 |  |  |  |  |  |
| Forfeited | (54) |  |  | 74.75 |  |  |  |  |  |
| Outstanding and unvested at September 30, 2021 | 778 |  |  | $ | 111.00 |  |  | 1.7 |  | $ | 115,456 |  |

[0000926326-21-000034:notes:195]
As of September 30, 2021, total unrecognized compensation cost related to RSUs was $73.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 3.1 years.

[0000926326-21-000034:notes:196]
[same as prior period, unchanged from 0000926326-21-000026:notes:172]

[0000926326-21-000034:notes:197]
The following table summarizes the restricted stock awards activity under the 2009 Plan during the nine months ended September 30, 2021:

[0000926326-21-000034:notes:198]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2020 | 21 |  |  | $ | 68.11 |  |
| Granted (Awarded) | 11 |  |  | 137.36 |  |
| Vested (Released) | (21) |  |  | 68.11 |  |
| Outstanding and unvested at September 30, 2021 | 11 |  |  | $ | 137.36 |  |

[0000926326-21-000034:notes:199]
As of September 30, 2021, total unrecognized compensation cost related to RSAs was $1.0 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.7 years.

[0000926326-21-000034:notes:200]
[same as prior period, unchanged from 0000926326-21-000026:notes:176]

[0000926326-21-000034:notes:201]
The following table summarizes the performance-based restricted stock units activity under the 2009 Plan during the nine months ended September 30, 2021:

[0000926326-21-000034:notes:202]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2020 | 155 |  |  | $ | 74.26 |  |
| Granted | 51 |  |  | 156.79 |  |
| Vested | (41) |  |  | 70.68 |  |
| Forfeited | (7) |  |  | 64.06 |  |
| Outstanding and unvested at September 30, 2021 | 158 |  |  | $ | 102.29 |  |

[0000926326-21-000034:notes:203]
As of September 30, 2021, total unrecognized compensation cost related to PSUs was approximately $7.0 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.2 years.

[0000926326-21-000034:notes:204]
[same as prior period, unchanged from 0000926326-21-000026:notes:180]

[0000926326-21-000034:notes:205]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of September 30, 2021:

[0000926326-21-000034:notes:206]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 3,243 |  |
| Non-vested restricted stock awards | 947 |  |
| Shares authorized for future issuance | 1,514 |  |
| ESPP shares available for future issuance | 919 |  |
| Total shares reserved for future issuance | 6,623 |  |

[0000926326-21-000034:notes:207]
[same as prior period, unchanged from 0000926326-21-000026:notes:183]

[0000926326-21-000034:notes:208]
On August 2, 2016, the Company’s Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2014 Repurchase Program”). As of September 30, 2021, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase programs at any time.

[0000926326-21-000034:notes:209]
On September 17, 2020, the Board authorized a one-time stock repurchase transaction providing for the repurchase of up to $75.0 million of the Company’s common stock in privately negotiated transactions concurrently with the issuance of the Notes, described in Note 10, Convertible Senior Notes. In September 2020, the Company repurchased 749,300 shares of its common stock from purchasers of the Notes in the offering in privately negotiated transactions effected through one of the initial purchasers or its affiliate at an average price of $70.78 per share for an aggregate purchase price of approximately $53.0 million. There will be no further repurchases under this one-time authorization.

[0000926326-21-000034:notes:210]
During the three and nine months ended September 30, 2021 and 2020, the Company did not repurchase any of its outstanding common stock, including under the 2014 Repurchase Program and the 2016 Repurchase Program, other than the separately-authorized one-time stock repurchase concurrent with the offering of the Notes in September 2020.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-21-000034:notes:211]
Equity Offerings
On November 3, 2017, the Company entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC, and HSBC Securities (USA) Inc., as its sales agents, pursuant to which the Company was able to offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of the Company’s common stock. Sales of the common stock pursuant to the Distribution Agreement were to be made in negotiated transactions or transactions that were deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, as amended, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange. The registration statement under which the shares that could have been sold pursuant to the Distribution Agreement expired on November 3, 2020, and, accordingly, no additional sales will be made pursuant to the Distribution Agreement.

[0000926326-21-000034:notes:212]
For the three and nine months ended September 30, 2020, the Company did not sell any of its common stock under the Distribution Agreement.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-21-000034:notes:213]
Restructuring Expenses
During 2020, the Company announced a company-wide organizational realignment initiative in order to more effectively align its organizational infrastructure and operations with the strategic vision of the autonomous pharmacy. During the second quarter of 2020, the Company also initiated a restructuring plan to help mitigate the adverse impact of the COVID-19 pandemic on its business and financial results. During the nine months ended September 30, 2020, the Company incurred $10.0 million of employee severance costs and related expenses.

[0000926326-21-000034:notes:214]
In the first quarter of 2021, the Company continued its organizational realignment initiative, incurring $2.0 million of employee severance costs and related expenses. The Company did not incur any additional restructuring expenses during the three months ended September 30, 2021.

[0000926326-21-000034:notes:215]
The following table summarizes the total restructuring expense recognized in the Company’s Condensed Consolidated Statements of Operations for the nine months ended September 30, 2021 and 2020:

[0000926326-21-000034:notes:216]
|  |  |  | Nine Months Ended September 30, |
|  |  |  |  |  | 2021 |  | 2020 |
|  |  |  |  |  | (In thousands) |
| Cost of product and service revenues |  |  |  |  | $ | 389 |  |  | $ | 2,564 |  |
| Research and development |  |  |  |  | 105 |  |  | 3,716 |  |
| Selling, general, and administrative |  |  |  |  | 1,526 |  |  | 3,681 |  |
| Total restructuring expense |  |  |  |  | $ | 2,020 |  |  | $ | 9,961 |  |
