# OMCL MD&A — 0000926326-21-000034


## mdna

[0000926326-21-000034:mdna:1]
[same as prior period, unchanged from 0000926326-21-000026:mdna:1]

[0000926326-21-000034:mdna:2]
[same as prior period, unchanged from 0000926326-21-000026:mdna:2]

[0000926326-21-000034:mdna:3]
•our expectations about the continuing impact of the ongoing COVID-19 pandemic on our workforce and operations (including new variants of the virus) and associated efforts to contain the spread of the pandemic, as well as the continuing impacts on our customers and suppliers, and the anticipated continuing effects of the COVID-19 pandemic and associated containment measures on our business, financial condition, liquidity, and results of operations;

[0000926326-21-000034:mdna:4]
[same as prior period, unchanged from 0000926326-21-000026:mdna:4]

[0000926326-21-000034:mdna:5]
[same as prior period, unchanged from 0000926326-21-000026:mdna:5]

[0000926326-21-000034:mdna:6]
[same as prior period, unchanged from 0000926326-21-000026:mdna:6]

[0000926326-21-000034:mdna:7]
[same as prior period, unchanged from 0000926326-21-000026:mdna:7]

[0000926326-21-000034:mdna:8]
•our ability to acquire companies, businesses, products, or technologies on commercially reasonable terms, integrate such acquisitions effectively, and to realize the potential benefits of acquired businesses;

[0000926326-21-000034:mdna:9]
[same as prior period, unchanged from 0000926326-21-000026:mdna:9]

[0000926326-21-000034:mdna:10]
[same as prior period, unchanged from 0000926326-21-000026:mdna:10]

[0000926326-21-000034:mdna:11]
[same as prior period, unchanged from 0000926326-21-000026:mdna:11]

[0000926326-21-000034:mdna:12]
•our belief that our solutions and vision for fully autonomous medication management are strongly aligned with long-term trends in the healthcare market and well-positioned to address the evolving needs of healthcare institutions;

[0000926326-21-000034:mdna:13]
[same as prior period, unchanged from 0000926326-21-000026:mdna:13]

[0000926326-21-000034:mdna:14]
[same as prior period, unchanged from 0000926326-21-000026:mdna:14]

[0000926326-21-000034:mdna:15]
[same as prior period, unchanged from 0000926326-21-000026:mdna:15]

[0000926326-21-000034:mdna:16]
[same as prior period, unchanged from 0000926326-21-000026:mdna:16]

[0000926326-21-000034:mdna:17]
•the outcome of any legal proceedings to which we are a party;

[0000926326-21-000034:mdna:18]
[same as prior period, unchanged from 0000926326-21-000026:mdna:18]

[0000926326-21-000034:mdna:19]
[same as prior period, unchanged from 0000926326-21-000026:mdna:19]

[0000926326-21-000034:mdna:20]
[same as prior period, unchanged from 0000926326-21-000026:mdna:20]

[0000926326-21-000034:mdna:21]
[same as prior period, unchanged from 0000926326-21-000026:mdna:21]

[0000926326-21-000034:mdna:22]
•our expected future uses of cash, including our expected uses for the remaining proceeds of our convertible senior notes and the sufficiency of our sources of funding; and

[0000926326-21-000034:mdna:23]
[same as prior period, unchanged from 0000926326-21-000026:mdna:23]

[0000926326-21-000034:mdna:24]
In some cases, you can identify forward-looking statements by terms such as “anticipates,” “believes,” “could,” “estimates,” “expects,” “intends,” “seeks,” “may,” “plans,” “potential,” “predicts,” “projects,” “should,” “will,” “would,” and variations of these terms and similar expressions. Forward-looking statements are based on our current expectations and assumptions and are subject to known and unknown risks and uncertainties, many of which are beyond our control, which may cause our actual results, performance, or achievements to be materially different from those expressed or implied in the forward-looking statements.

[0000926326-21-000034:mdna:25]
All references in this Quarterly Report to “Omnicell,” “our,” “us,” “we,” or “the Company” collectively refer to Omnicell, Inc., a Delaware corporation, and its subsidiaries. The term “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries.

[0000926326-21-000034:mdna:26]
We own various registered and unregistered trademarks and service marks used in our business, some of which appear in this report, including Omnicell®. This Quarterly Report may also include the trademarks and service marks of other companies. Such trademarks and service marks are the marks of their respective owners.

[0000926326-21-000034:mdna:27]
[same as prior period, unchanged from 0000926326-21-000026:mdna:27]

[0000926326-21-000034:mdna:28]
[same as prior period, unchanged from 0000926326-21-000026:mdna:28]

[0000926326-21-000034:mdna:29]
[same as prior period, unchanged from 0000926326-21-000026:mdna:29]

[0000926326-21-000034:mdna:30]
Over 7,000 facilities worldwide use our automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 60,000 institutional and retail pharmacies across North America and the United Kingdom leverage our innovative medication adherence and population health

[0000926326-21-000034:mdna:31]
solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 92% and 91% of our total revenues for the three months ended September 30, 2021 and 2020, respectively, and 90% of our total revenues for both the nine months ended September 30, 2021 and 2020.

[0000926326-21-000034:mdna:32]
Over the past several years, our business has expanded from a single-point solution to a platform of products and services that will help to further advance the vision of the autonomous pharmacy. This expansion has resulted in larger deal sizes across multiple products, services, and implementations for customers and, we believe, more comprehensive, valuable, and enduring relationships.

[0000926326-21-000034:mdna:33]
[same as prior period, unchanged from 0000926326-21-000026:mdna:32]

[0000926326-21-000034:mdna:34]
[same as prior period, unchanged from 0000926326-21-000026:mdna:33]

[0000926326-21-000034:mdna:35]
[same as prior period, unchanged from 0000926326-21-000026:mdna:34]

[0000926326-21-000034:mdna:36]
[same as prior period, unchanged from 0000926326-21-000026:mdna:35]

[0000926326-21-000034:mdna:37]
[same as prior period, unchanged from 0000926326-21-000026:mdna:36]

[0000926326-21-000034:mdna:38]
[same as prior period, unchanged from 0000926326-21-000026:mdna:37]

[0000926326-21-000034:mdna:39]
[same as prior period, unchanged from 0000926326-21-000026:mdna:38]

[0000926326-21-000034:mdna:40]
Our full-time employee headcount was approximately 3,370 and 2,860 on September 30, 2021 and December 31, 2020, respectively.

[0000926326-21-000034:mdna:41]
[same as prior period, unchanged from 0000926326-21-000026:mdna:40]

[0000926326-21-000034:mdna:42]
[same as prior period, unchanged from 0000926326-21-000026:mdna:41]

[0000926326-21-000034:mdna:43]
[same as prior period, unchanged from 0000926326-21-000026:mdna:42]

[0000926326-21-000034:mdna:44]
We are committed to being the care provider’s and retail pharmacies’ most trusted partner and executing on the vision of the autonomous pharmacy by delivering automation, intelligence, and advanced services, powered by a single, cloud-based platform. We believe there are significant challenges in pharmacy practice today including, but not limited to, medication errors, drug shortages, medication loss due to drug diversion, significant medication waste and expiration costs, a high level of manual steps in the medication management process, complexity around compliance requirements, high pharmacy employee turnover rates, hospitalizations from adverse drug events in outpatient settings, high variability in outcomes, and limited inventory visibility. We believe that these significant challenges in pharmacy practice drive the demand for increased digitization and virtualization, and that our solutions enable this and represent large opportunities in four market categories:

[0000926326-21-000034:mdna:45]
[same as prior period, unchanged from 0000926326-21-000026:mdna:44]

[0000926326-21-000034:mdna:46]
•Central Pharmacy.  This market represents the beginning of the medication management process in acute care settings, and, we believe, the next big automation opportunity to replace manual and repetitive processes which are common in the pharmacy today. Manual processes, generally, are prone to significant errors, and products such as IVX Workflow, our IV sterile compounding solutions, and our Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, automate these manual processes and are designed to reduce the risk of error for our healthcare partners. We believe new products and innovations in the Central Pharmacy market create opportunities to replace prior generation Central Pharmacy robotics that, when combined with carousels and services, are expected to improve our customers’ patient outcomes. In our view, the Central Pharmacy also represents an opportunity to provide additional technology-enabled services that are designed to reduce the administrative burden on the pharmacy and allow clinicians to operate at the top of their license. Omnicell One, a technology-enabled service, leverages intelligence across the enterprise, including Central Pharmacy, in an effort to provide actionable insights that will assist in improving medication management.

[0000926326-21-000034:mdna:47]
•340B Software-Enabled Services.  This market is targeted to covered entities participating in Section 340B of the Public Health Services Act. The Public Health Services Act requires pharmaceutical manufacturers participating in Medicaid to sell outpatient drugs at discounted prices to health care organizations that care for many uninsured and low-income patients and results in a complex compliance environment. We believe that there are significant opportunities for health systems to improve participation benefits and maximize program savings through software-enabled services and solutions. Our Omnicell 340B platform of technology-enabled services includes split billing software, contract pharmacy administration, specialty contract pharmacy administration, and drug discount access solutions.

[0000926326-21-000034:mdna:48]
•Retail, Institutional, and Payer.  We believe the Retail, Institutional, and Payer market represents a large opportunity as the majority of all prescription drugs are distributed in the non-acute sector. New technology and updated state board regulations are leading to innovation at traditional retail providers, which, combined with the move to value-based care, we believe will incentivize the market to adopt solutions to help providers and payers engage patients in new ways that improve patient care and reduce the total cost of care. We believe adoption of our EnlivenHealth (formerly Population Health Solutions) portfolio of software products and services, along with medication adherence packaging, will increase adherence performance rates, increase prescription volume for our customers, and reduce hospital and emergency room visits due to improved adherence. EnlivenHealth’s portfolio has been expanded with the recent acquisition of RxInnovation Inc., operating as FDS Amplicare (“FDS Amplicare”), a leading provider of financial management, analytics, and population health solutions to the retail pharmacy industry. Serving a nationwide network of more than 15,000 independent and specialty retail pharmacies, FDS Amplicare expands the industry footprint of EnlivenHealth. We believe that, with the combination of EnlivenHealth and FDS Amplicare, Omnicell now provides one of the industry’s most comprehensive offerings of SaaS technology solutions that is designed to help retail pharmacies and health plans grow and thrive in the new era of digital-driven healthcare. As retail pharmacies continue to play an increasingly vital role in population health following the onset of the COVID-19 pandemic, EnlivenHealth and newly acquired FDS Amplicare have extended solutions that should assist with vaccination programs, testing protocols, patient engagement, and Medicare health plan selection support for patients. There are seven areas of focus within this market:

[0000926326-21-000034:mdna:49]
[same as prior period, unchanged from 0000926326-21-000026:mdna:49]

[0000926326-21-000034:mdna:50]
[same as prior period, unchanged from 0000926326-21-000026:mdna:50]

[0000926326-21-000034:mdna:51]
[same as prior period, unchanged from 0000926326-21-000026:mdna:51]

[0000926326-21-000034:mdna:52]
◦Match enables pharmacies to provide new services to patients with a convenient online tool that allows patients to compare and select the Medicare D health plan that best meets their needs and budget.

[0000926326-21-000034:mdna:53]
◦Econcile assists pharmacy staff in managing third-party receivables and payments on prescription claims, all with secure online reporting.

[0000926326-21-000034:mdna:54]
◦MedBill provides retail pharmacies with tools that enable them to bill for the clinical services that are transforming the pharmacy profession and industry.

[0000926326-21-000034:mdna:55]
◦MyDataMart is a comprehensive business intelligence tool that uses pharmacy data to identify potential opportunities to drive better business results and improve patient care.

[0000926326-21-000034:mdna:56]
We believe our technology, services, and solutions within these market categories position us well to address the needs of retail, acute, and post-acute pharmacy providers, and health plans.

[0000926326-21-000034:mdna:57]
[same as prior period, unchanged from 0000926326-21-000026:mdna:54]

[0000926326-21-000034:mdna:58]
We continue to closely monitor the COVID-19 pandemic and ongoing impacts on our Company. During the first half of 2020, as a result of the COVID-19 pandemic, health systems faced financial and operational pressures which we believe led our customers to delay or defer purchasing decisions and/or implementation of our solutions. Beginning in the third quarter of 2020, we began to see our customers returning to pre-pandemic purchasing patterns consistent with long-term strategic investments and this trend has continued through the third quarter of 2021. We believe that the challenges that our customers have faced during the COVID-19 pandemic, including the need for robust visibility throughout their pharmacy supply chains, have increased the strategic relevance of our products and services.

[0000926326-21-000034:mdna:59]
Although COVID-19 vaccines are now available and being widely distributed, there remains significant uncertainty regarding the duration and severity of the continuing impact of the pandemic on the U.S. and world economies, including the impact of new variants of the COVID-19 virus. The ongoing impact of the COVID-19 pandemic on our business remains uncertain, and the duration and scope of such impact cannot currently be predicted. We continue to carefully monitor this dynamic situation and may adjust our outlook as appropriate. The ongoing impact of the COVID-19 pandemic may result in increased borrowing costs and other costs of capital or otherwise adversely affect our business, results of operations, financial condition, and liquidity. However, under current circumstances, we believe that our financial position and resources will allow us to manage the anticipated impact of the COVID-19 pandemic on our business for the foreseeable future.

[0000926326-21-000034:mdna:60]
[same as prior period, unchanged from 0000926326-21-000026:mdna:57]

[0000926326-21-000034:mdna:61]
On September 9, 2021, we completed the acquisition of all of the outstanding equity interests in FDS Amplicare pursuant to the terms and conditions of the Agreement and Plan of Merger, dated July 25, 2021, by and among FDS Amplicare, Omnicell, Inc., Fleming Acquisition Corp., and the representative of the securityholders for a base purchase price of $177.0 million, prior to post-closing adjustments for closing cash, net working capital, and assumed indebtedness, which is expected to be finalized in the fourth quarter of 2021. The FDS Amplicare acquisition adds a comprehensive and complementary suite of SaaS financial management, analytics, and population health solutions to Omnicell’s EnlivenHealth offering. The results of the operations of FDS Amplicare have been included in our consolidated results of operations beginning September 9, 2021.

[0000926326-21-000034:mdna:62]
On October 1, 2020, we completed the acquisition of the 340B Link business (the “340B Link Business”) of Pharmaceutical Strategies Group, LLC pursuant to the terms and conditions of the Equity Purchase Agreement, dated August 11, 2020, as amended, by and among Omnicell, Inc., PSGH, LLC, BW Apothecary Holdings, LLC, the sellers identified therein and the seller’s representative for total cash consideration of $225.0 million. The 340B Link Business acquisition adds a comprehensive and differentiated suite of software-enabled services and solutions used by certain eligible hospitals, health systems, clinics, and entities to manage compliance and capture 340B drug cost savings on outpatient prescriptions filled through the eligible entity’s pharmacy or a contracted pharmacy partner. The results of the operations of the 340B Link Business have been included in our consolidated results of operations beginning October 1, 2020.

[0000926326-21-000034:mdna:63]
[same as prior period, unchanged from 0000926326-21-000026:mdna:61]

[0000926326-21-000034:mdna:64]
[same as prior period, unchanged from 0000926326-21-000026:mdna:62]

[0000926326-21-000034:mdna:65]
[same as prior period, unchanged from 0000926326-21-000026:mdna:63]

[0000926326-21-000034:mdna:66]
[same as prior period, unchanged from 0000926326-21-000026:mdna:64]

[0000926326-21-000034:mdna:67]
[same as prior period, unchanged from 0000926326-21-000026:mdna:65]

[0000926326-21-000034:mdna:68]
[same as prior period, unchanged from 0000926326-21-000026:mdna:66]

[0000926326-21-000034:mdna:69]
[same as prior period, unchanged from 0000926326-21-000026:mdna:67]

[0000926326-21-000034:mdna:70]
[same as prior period, unchanged from 0000926326-21-000026:mdna:68]

[0000926326-21-000034:mdna:71]
[same as prior period, unchanged from 0000926326-21-000026:mdna:69]

[0000926326-21-000034:mdna:72]
[same as prior period, unchanged from 0000926326-21-000026:mdna:70]

[0000926326-21-000034:mdna:73]
[same as prior period, unchanged from 0000926326-21-000026:mdna:71]

[0000926326-21-000034:mdna:74]
[same as prior period, unchanged from 0000926326-21-000026:mdna:72]

[0000926326-21-000034:mdna:75]
[same as prior period, unchanged from 0000926326-21-000026:mdna:73]

[0000926326-21-000034:mdna:76]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the nine months ended September 30, 2021 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the year ended December 31, 2020, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000926326-21-000034:mdna:77]
[same as prior period, unchanged from 0000926326-21-000026:mdna:75]

[0000926326-21-000034:mdna:78]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-21-000034:mdna:79]
[same as prior period, unchanged from 0000926326-21-000026:mdna:77]

[0000926326-21-000034:mdna:80]
[same as prior period, unchanged from 0000926326-21-000026:mdna:78]

[0000926326-21-000034:mdna:81]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 213,970 |  |  | $ | 151,337 |  |  | $ | 62,633 |  |  | 41% |
| Percentage of total revenues | 72% |  | 71% |  |  |  |  |
| Services and other revenues | 82,432 |  |  | 62,362 |  |  | 20,070 |  |  | 32% |
| Percentage of total revenues | 28% |  | 29% |  |  |  |  |
| Total revenues | $ | 296,402 |  |  | $ | 213,699 |  |  | $ | 82,703 |  |  | 39% |

[0000926326-21-000034:mdna:82]
Product revenues represented 72% and 71% of total revenues for the three months ended September 30, 2021 and 2020, respectively. Product revenues increased by $62.6 million, due to increased customer demand, primarily within our automated dispensing systems business. In comparison, the third quarter of 2020 was impacted by the COVID-19 pandemic as health systems were focusing resources on COVID-19 essential activities.

[0000926326-21-000034:mdna:83]
Services and other revenues represented 28% and 29% of total revenues for the three months ended September 30, 2021 and 2020, respectively. Services and other revenues include revenues from technical services; SaaS, subscription software, and technology-enabled services; and other services. Services and other revenues increased by $20.1 million, primarily due to revenues of $14.4 million and $1.8 million from the recent acquisitions of the 340B Link Business and FDS Amplicare, respectively, as well as continued growth in our installed customer base and expanded portfolio of services and solutions.

[0000926326-21-000034:mdna:84]
Our international sales represented 8% and 9% of total revenues for the three months ended September 30, 2021 and 2020, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-21-000034:mdna:85]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 589,006 |  |  | $ | 460,352 |  |  | $ | 128,654 |  |  | 28% |
| Percentage of total revenues | 72% |  | 72% |  |  |  |  |
| Services and other revenues | 231,978 |  |  | 182,654 |  |  | 49,324 |  |  | 27% |
| Percentage of total revenues | 28% |  | 28% |  |  |  |  |
| Total revenues | $ | 820,984 |  |  | $ | 643,006 |  |  | $ | 177,978 |  |  | 28% |

[0000926326-21-000034:mdna:86]
Product revenues represented 72% of total revenues for both the nine months ended September 30, 2021 and 2020. Product revenues increased by $128.7 million, due to increased customer demand, primarily within our automated dispensing systems business. In comparison, the second and third quarters of 2020 were impacted by the COVID-19 pandemic as health systems were focusing resources on COVID-19 essential activities.

[0000926326-21-000034:mdna:87]
Services and other revenues represented 28% of total revenues for both the nine months ended September 30, 2021 and 2020. Services and other revenues include revenues from technical services; SaaS, subscription software, and technology-enabled services; and other services. Services and other revenues increased by $49.3 million, primarily due to revenues of $36.8 million and $1.8 million from the recent acquisitions of the 340B Link Business and FDS Amplicare, respectively, as well as continued growth in our installed customer base and expanded portfolio of services and solutions.

[0000926326-21-000034:mdna:88]
Our international sales represented 10% of total revenues for both the nine months ended September 30, 2021 and 2020, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-21-000034:mdna:89]
Our ability to continue to grow revenues is dependent on our ability to continue to obtain orders from customers, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, our ability to develop new or enhance existing solutions, and our flexibility in workforce allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-21-000034:mdna:90]
[same as prior period, unchanged from 0000926326-21-000026:mdna:89]

[0000926326-21-000034:mdna:91]
[same as prior period, unchanged from 0000926326-21-000026:mdna:90]

[0000926326-21-000034:mdna:92]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 110,743 |  |  | $ | 86,689 |  |  | $ | 24,054 |  |  | 28% |
| As a percentage of related revenues | 52% |  | 57% |  |  |  |  |
| Cost of services and other revenues | 38,880 |  |  | 30,219 |  |  | 8,661 |  |  | 29% |
| As a percentage of related revenues | 47% |  | 48% |  |  |  |  |
| Total cost of revenues | $ | 149,623 |  |  | $ | 116,908 |  |  | $ | 32,715 |  |  | 28% |
| As a percentage of total revenues | 50% |  | 55% |  |  |  |  |
| Gross profit | $ | 146,779 |  |  | $ | 96,791 |  |  | $ | 49,988 |  |  | 52% |
| Gross margin | 50% |  | 45% |  |  |  |  |

[0000926326-21-000034:mdna:93]
Cost of revenues for the three months ended September 30, 2021 compared to the three months ended September 30, 2020 increased by $32.7 million, of which $24.1 million was attributed to the increase in cost of product revenues and $8.7 million was attributed to the increase in cost of services and other revenues.

[0000926326-21-000034:mdna:94]
The increase in cost of product revenues was primarily driven by the increase in product revenues of $62.6 million for the three months ended September 30, 2021 compared to the three months ended September 30, 2020, partially offset by the benefits associated with economies of scale due to higher volumes.

[0000926326-21-000034:mdna:95]
The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $20.1 million, including incremental revenues from the recent acquisitions of the 340B Link Business and FDS Amplicare, for the three months ended September 30, 2021 compared to the three months ended September 30, 2020, as well as additional investments in our service business to support new service solutions.

[0000926326-21-000034:mdna:96]
The overall increase in gross margin primarily relates to higher revenues for the three months ended September 30, 2021 due to increased customer demand, as well as benefits associated with economies of scale due to higher volumes. Gross margin in the third quarter of 2020 was impacted by the COVID-19 pandemic. Our gross profit for the three months ended September 30, 2021 was $146.8 million, as compared to $96.8 million for the three months ended September 30, 2020.

[0000926326-21-000034:mdna:97]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 303,597 |  |  | $ | 262,740 |  |  | $ | 40,857 |  |  | 16% |
| As a percentage of related revenues | 52% |  | 57% |  |  |  |  |
| Cost of services and other revenues | 112,027 |  |  | 90,628 |  |  | 21,399 |  |  | 24% |
| As a percentage of related revenues | 48% |  | 50% |  |  |  |  |
| Total cost of revenues | $ | 415,624 |  |  | $ | 353,368 |  |  | $ | 62,256 |  |  | 18% |
| As a percentage of total revenues | 51% |  | 55% |  |  |  |  |
| Gross profit | $ | 405,360 |  |  | $ | 289,638 |  |  | $ | 115,722 |  |  | 40% |
| Gross margin | 49% |  | 45% |  |  |  |  |

[0000926326-21-000034:mdna:98]
Cost of revenues for the nine months ended September 30, 2021 compared to the nine months ended September 30, 2020 increased by $62.3 million, of which $40.9 million was attributed to the increase in cost of product revenues and $21.4 million was attributed to the increase in cost of services and other revenues.

[0000926326-21-000034:mdna:99]
The increase in cost of product revenues was primarily driven by the increase in product revenues of $128.7 million for the nine months ended September 30, 2021 compared to the nine months ended September 30, 2020, partially offset by the

[0000926326-21-000034:mdna:100]
benefits associated with economies of scale due to higher volumes, as well as the reduction of employee-related expenses for restructuring initiatives.

[0000926326-21-000034:mdna:101]
The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $49.3 million, including incremental revenues from the recent acquisitions of the 340B Link Business and FDS Amplicare, for the nine months ended September 30, 2021 compared to the nine months ended September 30, 2020, as well as additional investments in our service business to support new service solutions.

[0000926326-21-000034:mdna:102]
The overall increase in gross margin primarily relates to higher revenues for the nine months ended September 30, 2021 due to increased customer demand, benefits associated with economies of scale due to higher volumes, as well as the reduction of employee-related expenses for restructuring initiatives. Gross margin in the second and third quarters of 2020 was impacted by the COVID-19 pandemic. Our gross profit for the nine months ended September 30, 2021 was $405.4 million, as compared to $289.6 million for the nine months ended September 30, 2020.

[0000926326-21-000034:mdna:103]
[same as prior period, unchanged from 0000926326-21-000026:mdna:101]

[0000926326-21-000034:mdna:104]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 19,477 |  |  | $ | 15,197 |  |  | $ | 4,280 |  |  | 28% |
| As a percentage of total revenues | 7% |  | 7% |  |  |  |  |
| Selling, general, and administrative | 97,910 |  |  | 71,442 |  |  | 26,468 |  |  | 37% |
| As a percentage of total revenues | 33% |  | 33% |  |  |  |  |
| Total operating expenses | $ | 117,387 |  |  | $ | 86,639 |  |  | $ | 30,748 |  |  | 35% |
| As a percentage of total revenues | 40% |  | 41% |  |  |  |  |
| Interest and other income (expense), net | $ | (6,065) |  |  | $ | 809 |  |  | $ | (6,874) |  |  | (850)% |

[0000926326-21-000034:mdna:105]
Research and Development. Research and development expenses increased by $4.3 million for the three months ended September 30, 2021 compared to the three months ended September 30, 2020. The increase was primarily attributed to an increase of $4.9 million in employee-related expenses as well as other investments in product development, partially offset by various decreases due to the timing of projects. The increase in employee-related expenses is primarily due to increased headcount to support the continued advancement of the product roadmap and the vision of the fully autonomous pharmacy, as well as due to incremental headcount from recent acquisitions.

[0000926326-21-000034:mdna:106]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $26.5 million for the three months ended September 30, 2021 compared to the three months ended September 30, 2020. The increase was largely due to an increase of approximately $15.3 million in employee-related expenses primarily related to increased headcount, including the incremental headcount from the 340B Link Business and FDS Amplicare acquisitions, as well as increases in acquisition-related and commission expenses and higher spending related to travel, trade shows, and other expenses, which were significantly curtailed in 2020 due to the COVID-19 pandemic.

[0000926326-21-000034:mdna:107]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $6.9 million for the three months ended September 30, 2021 compared to the three months ended September 30, 2020, primarily driven by a $5.8 million increase in other expenses and a $1.1 million decrease in other income. The increase in other expenses during the three months ended September 30, 2021 as compared to the three months ended September 30, 2020 is primarily driven by amortization of discount and debt issuance costs as well as interest expense associated with our convertible senior notes issued in September 2020.

[0000926326-21-000034:mdna:108]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 53,770 |  |  | $ | 54,679 |  |  | $ | (909) |  |  | (2)% |
| As a percentage of total revenues | 7% |  | 9% |  |  |  |  |
| Selling, general, and administrative | 273,672 |  |  | 219,647 |  |  | 54,025 |  |  | 25% |
| As a percentage of total revenues | 33% |  | 34% |  |  |  |  |
| Total operating expenses | $ | 327,442 |  |  | $ | 274,326 |  |  | $ | 53,116 |  |  | 19% |
| As a percentage of total revenues | 40% |  | 43% |  |  |  |  |
| Interest and other income (expense), net | $ | (18,715) |  |  | $ | 161 |  |  | $ | (18,876) |  |  | (11,724)% |

[0000926326-21-000034:mdna:109]
Research and Development. Research and development expenses decreased by $0.9 million for the nine months ended September 30, 2021 compared to the nine months ended September 30, 2020. The decrease was primarily attributed to a reduction of $3.6 million in employee-related expenses for restructuring initiatives, as well as various decreases due to the timing of projects, partially offset by an increase of $4.3 million in employee-related expenses due to increased headcount to support the continued advancement of the product roadmap and the vision of the fully autonomous pharmacy, as well as due to incremental headcount from recent acquisitions.

[0000926326-21-000034:mdna:110]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $54.0 million for the nine months ended September 30, 2021 compared to the nine months ended September 30, 2020. The increase was primarily due to an increase of approximately $34.0 million in employee-related expenses primarily related to increased headcount, including the incremental headcount from the 340B Link Business and FDS Amplicare acquisitions, as well as increases in acquisition-related and commission expenses and higher spending related to travel, trade shows, consulting, and other expenses, which were significantly curtailed in 2020 due to the COVID-19 pandemic, partially offset by a reduction in employee-related expenses for restructuring initiatives of $2.2 million.

[0000926326-21-000034:mdna:111]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $18.9 million for the nine months ended September 30, 2021 compared to the nine months ended September 30, 2020, primarily driven by a $17.1 million increase in other expenses and a $1.8 million decrease in other income. The increase in other expenses during the nine months ended September 30, 2021 as compared to the nine months ended September 30, 2020 is primarily driven by amortization of discount and debt issuance costs as well as interest expense associated with our convertible senior notes issued in September 2020.

[0000926326-21-000034:mdna:112]
[same as prior period, unchanged from 0000926326-21-000026:mdna:110]

[0000926326-21-000034:mdna:113]
|  | Three Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (5,990) |  |  | $ | 2,156 |  |  | $ | (8,146) |  |  | (378)% |

[0000926326-21-000034:mdna:114]
|  | Nine Months Ended September 30, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (4,665) |  |  | $ | (344) |  |  | $ | (4,321) |  |  | 1,256% |

[0000926326-21-000034:mdna:115]
Our annual effective tax rate before discrete items was 28.2% and 30.1% for the nine months ended September 30, 2021 and 2020, respectively. The decrease in the estimated annual effective tax rate for the nine months ended September 30, 2021 compared to the same period in 2020 was primarily due to our higher profitability during the period, a decrease in in non-deductible expenses, and an increase in research and development credits.

[0000926326-21-000034:mdna:116]
42

[0000926326-21-000034:mdna:117]
Provision for income taxes for the nine months ended September 30, 2021 included net discrete income tax benefit of $21.4 million, primarily due to a $14.5 million tax benefit from equity compensation and a $6.2 million release of a certain net unrecognized tax benefit as a result of effective settlement with the tax authorities.

[0000926326-21-000034:mdna:118]
Provision for income taxes for the nine months ended September 30, 2020 included net discrete income tax benefit of $5.0 million, primarily due to a $4.2 million tax benefit from equity compensation.

[0000926326-21-000034:mdna:119]
Refer to Note 14, Income Taxes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more details.

[0000926326-21-000034:mdna:120]
[same as prior period, unchanged from 0000926326-21-000026:mdna:117]

[0000926326-21-000034:mdna:121]
We had cash and cash equivalents of $481.5 million at September 30, 2021 compared to $485.9 million at December 31, 2020. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with major financial institutions.

[0000926326-21-000034:mdna:122]
Our cash position and working capital at September 30, 2021 and December 31, 2020 were as follows:

[0000926326-21-000034:mdna:123]
|  | September 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 481,549 |  |  | $ | 485,928 |  |
| Working capital | $ | 550,054 |  |  | $ | 552,991 |  |

[0000926326-21-000034:mdna:124]
Our ratio of current assets to current liabilities was 2.6:1 and 3.0:1 at September 30, 2021 and December 31, 2020, respectively.

[0000926326-21-000034:mdna:125]
[same as prior period, unchanged from 0000926326-21-000026:mdna:122]

[0000926326-21-000034:mdna:126]
Revolving Credit Facility

[0000926326-21-000034:mdna:127]
On November 15, 2019, we entered into an Amended and Restated Credit Agreement (as subsequently amended, as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded our 2016 senior secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.

[0000926326-21-000034:mdna:128]
On September 22, 2020, the parties entered into an amendment (the “Amendment”) to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions described below, expand our flexibility to repurchase our common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires us to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

[0000926326-21-000034:mdna:129]
As of September 30, 2021, there was no outstanding balance for the Revolving Credit Facility and we were in full compliance with all covenants. Refer to Note 9, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more details. We expect to use future loans under the Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-21-000034:mdna:130]
[same as prior period, unchanged from 0000926326-21-000026:mdna:127]

[0000926326-21-000034:mdna:131]
On September 25, 2020, we completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. We received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted. Refer to Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more details.

[0000926326-21-000034:mdna:132]
During the fourth quarter of 2020, we used approximately $49.3 million of the net proceeds from the offering to pay the cost of the convertible note hedge transactions (partially offset by the proceeds we received from the sale of the warrant transactions), approximately $53.0 million of the net proceeds to repurchase shares of our common stock from purchasers of the Notes, $150.0 million of the net proceeds to pay down outstanding borrowings under the Revolving Credit Facility, and $225.0 million for the acquisition of the 340B Link Business. We intend to use the remainder of the net proceeds from this offering for working capital and other general corporate purposes, which may include potential acquisitions, strategic transactions, and potential future repurchases of our common stock.

[0000926326-21-000034:mdna:133]
[same as prior period, unchanged from 0000926326-21-000026:mdna:131]

[0000926326-21-000034:mdna:134]
[same as prior period, unchanged from 0000926326-21-000026:mdna:132]

[0000926326-21-000034:mdna:135]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of September 30, 2021, which may result in additional use of cash. Refer to “Stock Repurchase Program” under Note 15, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more details. In September 2020, we repurchased 749,300 shares of our common stock from purchasers of the Notes in the offering in privately negotiated transactions effected through one of the initial purchasers or its affiliate at an average price of $70.78 per share for an aggregate purchase price of approximately $53.0 million. The repurchases were made concurrently with the issuance of the Notes. The repurchases were separately authorized by the Board of Directors, and did not impact the total remaining for future purchases under the previously authorized stock purchase programs. There were no stock repurchases during the three and nine months ended September 30, 2021 and 2020, including under our stock repurchase programs, other than the separately-authorized one-time stock repurchase concurrent with the offering of the Notes in September 2020.

[0000926326-21-000034:mdna:136]
Based on our current business plan and product backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan (“ESPP”), along with the availability of funds under the Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-21-000034:mdna:137]
[same as prior period, unchanged from 0000926326-21-000026:mdna:135]

[0000926326-21-000034:mdna:138]
[same as prior period, unchanged from 0000926326-21-000026:mdna:136]

[0000926326-21-000034:mdna:139]
|  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 172,177 |  |  | $ | 109,422 |  |
| Investing activities | (220,113) |  |  | (43,174) |  |
| Financing activities | 40,697 |  |  | 435,870 |  |
| Effect of exchange rate changes on cash and cash equivalents | (492) |  |  | (157) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | (7,731) |  |  | $ | 501,961 |  |

[0000926326-21-000034:mdna:140]
[same as prior period, unchanged from 0000926326-21-000026:mdna:138]

[0000926326-21-000034:mdna:141]
[same as prior period, unchanged from 0000926326-21-000026:mdna:139]

[0000926326-21-000034:mdna:142]
Net cash provided by operating activities was $172.2 million for the nine months ended September 30, 2021, primarily consisting of net income of $63.9 million adjusted for non-cash items of $119.2 million, offset by changes in assets and liabilities of $10.9 million. The non-cash items primarily consisted of depreciation and amortization expense of $53.1 million, share-based compensation expense of $38.5 million, amortization of discount on convertible senior notes of $13.9 million, amortization of operating lease right-of-use assets of $8.8 million, amortization of debt issuance costs of $2.6 million, and a change in deferred income taxes of $2.0 million. Changes in assets and liabilities include cash outflows from (i) an increase in

[0000926326-21-000034:mdna:143]
accounts receivable and unbilled receivables of $39.6 million primarily due to an increase in billings driven by overall business growth and the timing of shipments as well as collections, (ii) a decrease in accrued compensation of $12.0 million primarily due to a decrease in accrued commissions and bonuses, (iii) an increase in inventories of $10.1 million to support forecasted sales, including advanced purchases of certain components, and as well as higher costs of inventory, (iv) a decrease in operating lease liabilities of $9.4 million, (v) a decrease in other long-term liabilities of $9.2 million primarily due to $6.2 million release of a certain net unrecognized tax benefit as a result of effective settlement with the tax authorities, (vi) an increase in prepaid expenses of $8.2 million primarily as a result of timing of certain insurance policies and other subscription obligations, (vii) an increase in other current assets of $1.1 million, and (viii) an increase in prepaid commissions of $1.0 million. These cash outflows were partially offset by (i) an increase in accounts payable of $33.1 million primarily due to an overall increase in spending, as well as timing of payments, (ii) an increase in deferred revenues of $21.2 million primarily due to an increase in billings driven by the timing of shipments in order to meet customers’ implementation schedules and recognition of revenues for products requiring installation, (iii) an increase in accrued liabilities of $20.1 million primarily due to an increase in rebates and lease buyout liabilities, (iv) a decrease in investment in sales-type leases of $2.7 million, and (vi) a decrease in other long-term assets of $2.6 million.

[0000926326-21-000034:mdna:144]
Net cash provided by operating activities was $109.4 million for the nine months ended September 30, 2020, primarily consisting of net income of $15.8 million adjusted for non-cash items of $82.0 million and changes in assets and liabilities of $11.6 million. The non-cash items primarily consisted of depreciation and amortization expense of $43.9 million, share-based compensation expense of $33.0 million, amortization of operating lease right-of-use assets of $7.7 million, amortization of debt issuance costs of $0.8 million, amortization of discount on convertible senior notes of $0.2 million, and a change in deferred income taxes of $3.6 million. Changes in assets and liabilities include cash inflows from (i) a decrease in accounts receivable and unbilled receivables of $29.7 million primarily due to timing of collections and a decrease in billings due to timing of shipments, (ii) an increase in deferred revenues of $8.8 million primarily due to the timing of shipments in order to meet customers’ implementation schedules and recognition of revenues for products requiring installation, (iii) an increase in other long-term liabilities of $8.1 million primarily due to the deferral of certain payroll taxes due to the CARES Act, (iv) a decrease in inventories of $4.6 million primarily due to timing of shipments and a focus on supply chain efficiencies, (v) an increase in accrued liabilities of $3.3 million, and (vi) a decrease in prepaid commissions of $2.2 million. These cash inflows were partially offset by (i) a decrease in accounts payable of $8.7 million primarily due to an overall decrease in spending, as well as timing of payments, (ii) a decrease in accrued compensation of $8.4 million primarily due to timing of employee stock plan purchases, as well as a decrease in accrued commissions, (iii) a decrease in operating lease liabilities of $7.8 million, (iv) an increase in other current assets of $6.6 million, (v) an increase in prepaid expenses of $6.3 million, (vi) an increase in other long-term assets of $4.0 million, and (vii) an increase in investment in sales-type leases of $3.3 million.

[0000926326-21-000034:mdna:145]
[same as prior period, unchanged from 0000926326-21-000026:mdna:143]

[0000926326-21-000034:mdna:146]
Net cash used in investing activities was $220.1 million for the nine months ended September 30, 2021, which consisted of $178.1 million consideration paid for the acquisition of FDS Amplicare, net of cash acquired, capital expenditures of $17.9 million for property and equipment, and $24.1 million for costs of software development for external use.

[0000926326-21-000034:mdna:147]
Net cash used in investing activities was $43.2 million for the nine months ended September 30, 2020, which consisted of capital expenditures of $17.3 million for property and equipment, and $25.9 million for costs of software development for external use.

[0000926326-21-000034:mdna:148]
[same as prior period, unchanged from 0000926326-21-000026:mdna:146]

[0000926326-21-000034:mdna:149]
Net cash provided by financing activities was $40.7 million for the nine months ended September 30, 2021, primarily due to $53.9 million in proceeds from employee stock option exercises and ESPP purchases, partially offset by $10.2 million in employees’ taxes paid related to restricted stock unit vesting, and a net decrease in the customer funds balances of $3.1 million.

[0000926326-21-000034:mdna:150]
Net cash provided by financing activities was $435.9 million for the nine months ended September 30, 2020, primarily due to proceeds of $559.7 million from the issuance of the Notes net of issuance costs, proceeds of approximately $51.3 million from the sale of warrants in connection with the issuance of the Notes, $150.0 million of proceeds under the Current Revolving Credit Facility, $33.2 million in proceeds from employee stock option exercises and employee stock plan purchases, partially offset by repayments of $200.0 million of the Current Revolving Credit Facility, approximately $100.6 million for the purchase of the convertible note hedge in connection with the issuance of the Notes, $53.0 million for repurchases of our stock, $4.1 million in employees’ taxes paid related to restricted stock unit vesting, and payments for debt issuance costs related to the Current Revolving Credit Facility of $0.6 million.

[0000926326-21-000034:mdna:151]
[same as prior period, unchanged from 0000926326-21-000026:mdna:149]

[0000926326-21-000034:mdna:152]
There have been no significant changes during the nine months ended September 30, 2021 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2020.

[0000926326-21-000034:mdna:153]
Contractual obligations as of September 30, 2021 were as follows:

[0000926326-21-000034:mdna:154]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2021 |  | 2022 - 2023 |  | 2024 - 2025 |  | 2026 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 62,459 |  |  | $ | 3,782 |  |  | $ | 25,732 |  |  | $ | 15,670 |  |  | $ | 17,275 |  |
| Purchase obligations (2) | 130,720 |  |  | 88,806 |  |  | 40,516 |  |  | 880 |  |  | 518 |  |
| Convertible senior notes (3) | 580,750 |  |  | — |  |  | 2,875 |  |  | 577,875 |  |  | — |  |
| Other (4) | 898 |  |  | 27 |  |  | 430 |  |  | 358 |  |  | 83 |  |
| Total (5) | $ | 774,827 |  |  | $ | 92,615 |  |  | $ | 69,553 |  |  | $ | 594,783 |  |  | $ | 17,876 |  |

[0000926326-21-000034:mdna:155]
[same as prior period, unchanged from 0000926326-21-000026:mdna:153]

[0000926326-21-000034:mdna:156]
(1)Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 12, Lessee Leases, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more details.

[0000926326-21-000034:mdna:157]
[same as prior period, unchanged from 0000926326-21-000026:mdna:155]

[0000926326-21-000034:mdna:158]
(3)We issued convertible senior notes in September 2020 that are due in September 2025. The obligations presented above include both principal and interest for these notes. Although these notes mature in 2025, they may be converted into cash and shares of our common stock prior to maturity if certain conditions are met. Any conversion prior to maturity can result in repayment of the principal amounts sooner than the scheduled repayment as indicated in the table above. Refer to Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more details.

[0000926326-21-000034:mdna:159]
(4)Other commitments include various finance leases and other financing arrangements.

[0000926326-21-000034:mdna:160]
(5)Refer to Note 13, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for more details.

[0000926326-21-000034:mdna:161]
[same as prior period, unchanged from 0000926326-21-000026:mdna:158]

[0000926326-21-000034:mdna:162]
As of September 30, 2021, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Exchange Act and the instructions thereto.
