# OMCL note change history — 0000926326-21-000026 → 0000926326-21-000034


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0000926326-21-000034:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2021, the Company had non-cancelable purchase commitments of $130.7 million, of which $88.8 million are expected to be paid within the year ending December 31, 2021.
  (was, 2021-08-06, similarity 0.9765):
[0000926326-21-000026:note_history:1]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2021, the Company had non-cancelable purchase commitments of $114.4 million, of which $89.5 million are expected to be paid within the year ending December 31, 2021.

- changed (2021-11-05):
[0000926326-21-000034:note_history:2]
motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020. The Company's motion to dismiss is now fully briefed, however a date for oral argument on the motion is not currently scheduled. A status conference in the case has been set for November 12, 2021. The Company intends to defend the lawsuit vigorously.
  (was, 2021-08-06, similarity 0.8537):
[0000926326-21-000026:note_history:2]
motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020. The Company's motion to dismiss is now fully briefed and the Court has scheduled oral argument on the motion for September 17, 2021. The Company intends to defend the lawsuit vigorously.

- changed (2021-11-05):
[0000926326-21-000034:note_history:3]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “BD Complaint”). This action (the “BD Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The BD Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees and costs, and pre-judgment and post-judgment interest. On March 17, 2021, the parties filed a joint motion to stay the BD Action, which motion was granted by the Court on June 8, 2021. The stay is in place for no more than 180 days, setting the deadline for filing the Company’s answer to the BD Complaint as December 6, 2021, unless an extension to such stay is mutually agreed to by the parties and approved by the Court. The Company intends to defend the lawsuit vigorously.
  (was, 2021-08-06, similarity 0.9868):
[0000926326-21-000026:note_history:3]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “Omnicell Complaint”). This action (the “Omnicell Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The Omnicell Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees and costs, and pre-judgment and post-judgment interest. On March 17, 2021, the parties filed a joint motion to stay the Omnicell Action, which motion was granted by the Court on June 8, 2021. The stay is in place for no more than 180 days, setting the deadline for filing the Company’s answer to the Omnicell Complaint as December 6, 2021, unless an extension to such stay is mutually agreed to by the parties and approved by the Court. The Company intends to defend the lawsuit vigorously.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0000926326-21-000034:note_history:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2021 and December 31, 2020, the results of operations and comprehensive income for the three and nine months ended September 30, 2021 and 2020, and cash flows for the nine months ended September 30, 2021 and 2020. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 24, 2021, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2021, and cash flows for the nine months ended September 30, 2021 are not necessarily indicative of results that may be expected for the year ending December 31, 2021, or for any future period.
  (was, 2021-08-06, similarity 0.8204):
[0000926326-21-000026:note_history:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2021 and December 31, 2020, the results of operations and comprehensive income (loss) for the three and six months ended June 30, 2021 and 2020, and cash flows for the six months ended June 30, 2021 and 2020. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 24, 2021, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and six months ended June 30, 2021, and cash flows for the six months ended June 30, 2021 are not necessarily indicative of results that may be expected for the year ending December 31, 2021, or for any future period.

- added (2021-11-05):
[0000926326-21-000034:note_history:5]
On September 9, 2021, the Company completed its acquisition of RxInnovation Inc., operating as FDS Amplicare (“FDS Amplicare”). The Condensed Consolidated Financial Statements include the results of operations of this recently acquired company, commencing as of the acquisition date. The significant accounting policies of the acquired business have been aligned to conform to the accounting policies of Omnicell.

- changed (2021-11-05):
[0000926326-21-000034:note_history:6]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of revenues for the three and nine months ended September 30, 2020 in Note 3, Revenues. This change was not deemed material and was included to conform with current-period classification and presentation.
  (was, 2021-08-06, similarity 0.9375):
[0000926326-21-000026:note_history:6]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of revenues for the three and six months ended June 30, 2020 in Note 3, Revenues. This change was not deemed material and was included to conform with current-period classification and presentation.

- changed (2021-11-05):
[0000926326-21-000034:note_history:7]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.
  (was, 2021-08-06, similarity 0.9954):
[0000926326-21-000026:note_history:7]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.

- added (2021-11-05):
[0000926326-21-000034:note_history:8]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of September 30, 2021, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

- added (2021-11-05):
[0000926326-21-000034:note_history:9]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company's Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM

- changed (2021-11-05):
[0000926326-21-000034:note_history:10]
allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.
  (was, 2021-08-06, similarity 0.6996):
[0000926326-21-000026:note_history:10]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.

- changed (2021-11-05):
[0000926326-21-000034:note_history:11]
In August 2020, the FASB issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. This update permits the use of either the modified retrospective or fully retrospective method of transition. The Company will adopt ASU 2020-06 on January 1, 2022, and expects to use the modified retrospective method of transition. The Company’s adoption of the update is estimated to result in an increase in convertible senior notes, net of issuance costs, of $75.4 million; a decrease in additional paid-in capital of $72.7 million; a decrease of long-term deferred tax liabilities of $19.8 million; a decrease in long-term deferred tax assets of $0.5 million; and an increase in retained earnings of $16.7 million, all as of January 1, 2022.
  (was, 2021-08-06, similarity 0.6204):
[0000926326-21-000026:note_history:11]
In August 2020, the FASB issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. This update permits the use of either the modified retrospective or fully retrospective method of transition. ASU 2020-06 will be effective for the Company beginning January 1, 2022. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. The Company is currently evaluating the impact ASU 2020-06 will have on its Consolidated Financial Statements.

- removed (2021-11-05):
[0000926326-21-000026:note_history:12]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of June 30, 2021, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.


## omcl:ScheduleOfDebtIssuanceCostsNetTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0000926326-21-000034:note_history:13]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (823) |  |
| Balance as of September 30, 2021 | $ | 3,430 |  |
  (was, 2021-08-06, similarity 0.9622):
[0000926326-21-000026:note_history:13]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (549) |  |
| Balance as of June 30, 2021 | $ | 3,704 |  |


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0000926326-21-000034:note_history:14]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2021:
  (was, 2021-08-06, similarity 0.9032):
[0000926326-21-000026:note_history:14]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2021:

- added (2021-11-05):
[0000926326-21-000034:note_history:15]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 20 |  |  | $ | 1,078 |  |  | $ | 20 |  |
| Amortization of discount | $ | 4,679 |  |  | $ | 249 |  |  | $ | 13,874 |  |  | $ | 249 |  |
| Amortization of debt issuance costs | $ | 589 |  |  | $ | 31 |  |  | $ | 1,747 |  |  | $ | 31 |  |

- removed (2021-11-05):
[0000926326-21-000026:note_history:16]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |
|  | 2021 |  |  |  | 2021 |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  |  |  | $ | 719 |  |  |  |
| Amortization of discount | $ | 4,624 |  |  |  |  | $ | 9,195 |  |  |  |
| Amortization of debt issuance costs | $ | 583 |  |  |  |  | $ | 1,158 |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0000926326-21-000034:note_history:17]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2021 and December 31, 2020:
  (was, 2021-08-06, similarity 0.9591):
[0000926326-21-000026:note_history:17]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2021 and December 31, 2020:

- changed (2021-11-05):
[0000926326-21-000034:note_history:18]
|  | September 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (81,870) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (10,308) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 482,822 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |
  (was, 2021-08-06, similarity 0.9818):
[0000926326-21-000026:note_history:18]
|  | June 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (86,549) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (10,897) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 477,554 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0000926326-21-000034:note_history:19]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility (the “Prior Credit Agreement”) and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.
  (was, 2021-08-06, similarity 0.8759):
[0000926326-21-000026:note_history:19]
Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility (the “Prior Credit Agreement”) and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

- changed (2021-11-05):
[0000926326-21-000034:note_history:20]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of September 30, 2021.
  (was, 2021-08-06, similarity 0.9963):
[0000926326-21-000026:note_history:20]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of June 30, 2021.

- changed (2021-11-05):
[0000926326-21-000034:note_history:21]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. In connection with the Amendment on September 22, 2020, the Company incurred and capitalized an additional $0.6 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs for credit agreements was
  (was, 2021-08-06, similarity 0.8408):
[0000926326-21-000026:note_history:21]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. In connection with the Amendment on September 22, 2020, the Company incurred and capitalized an additional $0.6 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs for credit agreements was approximately $0.3 million and $0.2 million for the three months ended June 30, 2021 and 2020, respectively, and approximately $0.5 million for both the six months ended June 30, 2021 and 2020.

- added (2021-11-05):
[0000926326-21-000034:note_history:22]
approximately $0.3 million and $0.2 million for the three months ended September 30, 2021 and 2020, respectively, and approximately $0.8 million and $0.7 million for the nine months ended September 30, 2021 and 2020, respectively.

- changed (2021-11-05):
[0000926326-21-000034:note_history:23]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (823) |  |
| Balance as of September 30, 2021 | $ | 3,430 |  |
  (was, 2021-08-06, similarity 0.9622):
[0000926326-21-000026:note_history:23]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (549) |  |
| Balance as of June 30, 2021 | $ | 3,704 |  |

- changed (2021-11-05):
[0000926326-21-000034:note_history:24]
As of each of September 30, 2021 and December 31, 2020, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025
  (was, 2021-08-06, similarity 0.9674):
[0000926326-21-000026:note_history:24]
As of each of June 30, 2021 and December 31, 2020, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- changed (2021-11-05):
[0000926326-21-000034:note_history:25]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.
  (was, 2021-08-06, similarity 0.9994):
[0000926326-21-000026:note_history:25]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased or converted.

- changed (2021-11-05):
[0000926326-21-000034:note_history:26]
During the three months ended September 30, 2021, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on September 30, 2021, the last trading day of the fiscal quarter. Accordingly, the Notes are convertible, in whole or in part, at the option of the holders during the fourth quarter of 2021. Whether the Notes will be convertible following the fourth fiscal quarter of 2021 will depend on the continued satisfaction of this condition or another conversion condition in the future. The Company continues to classify the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of September 30, 2021 based on contractual settlement provisions.
  (was, 2021-08-06, similarity 0.9618):
[0000926326-21-000026:note_history:26]
During the three months ended June 30, 2021, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on June 30, 2021, the last trading day of the fiscal quarter. Accordingly, the Notes are convertible, in whole or in part, at the option of the holders during the third quarter of 2021. Whether the Notes will be convertible following the third fiscal quarter of 2021 will depend on the continued satisfaction of this condition or another conversion condition in the future. The Company continues to classify the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of June 30, 2021 based on contractual settlement provisions.

- changed (2021-11-05):
[0000926326-21-000034:note_history:27]
Upon conversion, the Company may satisfy its conversion obligation by paying or delivering, as the case may be, cash, shares of its common stock, or a combination of cash and shares of its common stock, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in
  (was, 2021-08-06, similarity 0.9115):
[0000926326-21-000026:note_history:27]
Upon conversion, the Company may satisfy its conversion obligation by paying or delivering, as the case may be, cash, shares of its common stock, or a combination of cash and shares of its common stock, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

- added (2021-11-05):
[0000926326-21-000034:note_history:28]
connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

- changed (2021-11-05):
[0000926326-21-000034:note_history:29]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2021, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2021-08-06, similarity 0.8042):
[0000926326-21-000026:note_history:29]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of June 30, 2021, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- changed (2021-11-05):
[0000926326-21-000034:note_history:30]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represents the debt discount, which the Company will amortize to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions. As of September 30, 2021, the remaining life of the Notes and the related debt discount and issuance cost accretion is approximately 4.0 years.
  (was, 2021-08-06, similarity 0.9939):
[0000926326-21-000026:note_history:30]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represents the debt discount, which the Company will amortize to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions. As of June 30, 2021, the remaining life of the Notes and the related debt discount and issuance cost accretion is approximately 4.2 years.

- changed (2021-11-05):
[0000926326-21-000034:note_history:31]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 8.1 million shares. As of September 30, 2021, the if-converted value of the Notes exceeded the principal amount by $302.0 million.
  (was, 2021-08-06, similarity 0.7614):
[0000926326-21-000026:note_history:31]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 8.1 million shares. As of June 30, 2021, the if-converted value of the Notes exceeded the principal amount by $319.8 million.

- changed (2021-11-05):
[0000926326-21-000034:note_history:32]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2021 and December 31, 2020:
  (was, 2021-08-06, similarity 0.9591):
[0000926326-21-000026:note_history:32]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of June 30, 2021 and December 31, 2020:

- changed (2021-11-05):
[0000926326-21-000034:note_history:33]
|  | September 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (81,870) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (10,308) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 482,822 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |
  (was, 2021-08-06, similarity 0.9818):
[0000926326-21-000026:note_history:33]
|  | June 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (86,549) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (10,897) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 477,554 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |

- changed (2021-11-05):
[0000926326-21-000034:note_history:34]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2021:
  (was, 2021-08-06, similarity 0.9032):
[0000926326-21-000026:note_history:34]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2021:

- added (2021-11-05):
[0000926326-21-000034:note_history:35]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 20 |  |  | $ | 1,078 |  |  | $ | 20 |  |
| Amortization of discount | $ | 4,679 |  |  | $ | 249 |  |  | $ | 13,874 |  |  | $ | 249 |  |
| Amortization of debt issuance costs | $ | 589 |  |  | $ | 31 |  |  | $ | 1,747 |  |  | $ | 31 |  |

- removed (2021-11-05):
[0000926326-21-000026:note_history:36]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo

- removed (2021-11-05):
[0000926326-21-000026:note_history:37]
|  | Three Months Ended June 30, |  |  |  | Six Months Ended June 30, |
|  | 2021 |  |  |  | 2021 |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  |  |  | $ | 719 |  |  |  |
| Amortization of discount | $ | 4,624 |  |  |  |  | $ | 9,195 |  |  |  |
| Amortization of debt issuance costs | $ | 583 |  |  |  |  | $ | 1,158 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0000926326-21-000034:note_history:38]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth (formerly Population Health
  (was, 2021-08-06, similarity 0.6835):
[0000926326-21-000026:note_history:38]
Software-as-a-service (“SaaS”), subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth™ (formerly Population Health Solutions), 340B solutions, and services associated with Omnicell One™ (formerly Performance Center), Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IV compounding automation solutions.

- added (2021-11-05):
[0000926326-21-000034:note_history:39]
Solutions) inclusive of newly acquired FDS Amplicare, 340B solutions, and services associated with Omnicell One™ (formerly Performance Center), Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IV compounding automation solutions.

- added (2021-11-05):
[0000926326-21-000034:note_history:40]
The following table summarizes revenue recognition for each revenue category:

- added (2021-11-05):
[0000926326-21-000034:note_history:41]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| SaaS, subscription software, and technology-enabled services |  |  |  | Over time, as services are provided |  | Service |

- added (2021-11-05):
[0000926326-21-000034:note_history:42]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0000926326-21-000034:note_history:43]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth (formerly Population Health
  (was, 2021-08-06, similarity 0.6835):
[0000926326-21-000026:note_history:43]
Software-as-a-service (“SaaS”), subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth™ (formerly Population Health Solutions), 340B solutions, and services associated with Omnicell One™ (formerly Performance Center), Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IV compounding automation solutions.

- added (2021-11-05):
[0000926326-21-000034:note_history:44]
Solutions) inclusive of newly acquired FDS Amplicare, 340B solutions, and services associated with Omnicell One™ (formerly Performance Center), Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IV compounding automation solutions.

- changed (2021-11-05):
[0000926326-21-000034:note_history:45]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $4.4 million and $2.3 million for the three months ended September 30, 2021 and 2020, respectively, and $12.0 million and $6.9 million for the nine months ended September 30, 2021 and 2020, respectively.
  (was, 2021-08-06, similarity 0.9386):
[0000926326-21-000026:note_history:45]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule contract with the Department of Veterans Affairs (the "GSA Contract"). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee ("IFF") to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $4.2 million and $1.7 million for the three months ended June 30, 2021 and 2020, respectively, and $7.6 million and $4.6 million for the six months ended June 30, 2021 and 2020, respectively.

- changed (2021-11-05):
[0000926326-21-000034:note_history:46]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and nine months ended September 30, 2021 and 2020:
  (was, 2021-08-06, similarity 0.9416):
[0000926326-21-000026:note_history:46]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and six months ended June 30, 2021 and 2020:

- changed (2021-11-05):
[0000926326-21-000034:note_history:47]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 195,820 |  |  | $ | 135,037 |  |  | $ | 534,582 |  |  | $ | 403,761 |  |
| Technical services | 53,529 |  |  | 51,380 |  |  | 156,321 |  |  | 151,077 |  |
| Consumables | 18,150 |  |  | 16,300 |  |  | 54,424 |  |  | 56,591 |  |
| SaaS, subscription software, and technology-enabled services | 28,903 |  |  | 10,982 |  |  | 75,657 |  |  | 31,577 |  |
| Total revenues | $ | 296,402 |  |  | $ | 213,699 |  |  | $ | 820,984 |  |  | $ | 643,006 |  |
  (was, 2021-08-06, similarity 0.9221):
[0000926326-21-000026:note_history:47]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 179,044 |  |  | $ | 121,377 |  |  | $ | 338,762 |  |  | $ | 268,724 |  |
| Technical services | 51,932 |  |  | 50,178 |  |  | 102,792 |  |  | 99,697 |  |
| Consumables | 17,867 |  |  | 17,565 |  |  | 36,274 |  |  | 40,291 |  |
| SaaS, subscription software, and technology-enabled services | 23,896 |  |  | 10,501 |  |  | 46,754 |  |  | 20,595 |  |
| Total revenues | $ | 272,739 |  |  | $ | 199,621 |  |  | $ | 524,582 |  |  | $ | 429,307 |  |

- changed (2021-11-05):
[0000926326-21-000034:note_history:48]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2021 and 2020:
  (was, 2021-08-06, similarity 0.9581):
[0000926326-21-000026:note_history:48]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2021 and 2020:

- changed (2021-11-05):
[0000926326-21-000034:note_history:49]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| United States | $ | 271,276 |  |  | $ | 193,639 |  |  | $ | 738,411 |  |  | $ | 579,425 |  |
| Rest of world (1) | 25,126 |  |  | 20,060 |  |  | 82,573 |  |  | 63,581 |  |
| Total revenues | $ | 296,402 |  |  | $ | 213,699 |  |  | $ | 820,984 |  |  | $ | 643,006 |  |
  (was, 2021-08-06, similarity 0.8752):
[0000926326-21-000026:note_history:49]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| United States | $ | 242,859 |  |  | $ | 178,052 |  |  | $ | 467,135 |  |  | $ | 385,786 |  |
| Rest of world (1) | 29,880 |  |  | 21,569 |  |  | 57,447 |  |  | 43,521 |  |
| Total revenues | $ | 272,739 |  |  | $ | 199,621 |  |  | $ | 524,582 |  |  | $ | 429,307 |  |

- changed (2021-11-05):
[0000926326-21-000034:note_history:50]
|  | September 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 17,879 |  |  | $ | 13,895 |  |
| Long-term unbilled receivables, net (2) | 14,460 |  |  | 17,205 |  |
| Total contract assets | $ | 32,339 |  |  | $ | 31,100 |  |
| Short-term deferred revenues, net | $ | 114,726 |  |  | $ | 100,053 |  |
| Long-term deferred revenues | 14,141 |  |  | 5,673 |  |
| Total contract liabilities | $ | 128,867 |  |  | $ | 105,726 |  |
  (was, 2021-08-06, similarity 0.983):
[0000926326-21-000026:note_history:50]
|  | June 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 12,465 |  |  | $ | 13,895 |  |
| Long-term unbilled receivables, net (2) | 15,074 |  |  | 17,205 |  |
| Total contract assets | $ | 27,539 |  |  | $ | 31,100 |  |
| Short-term deferred revenues, net | $ | 121,305 |  |  | $ | 100,053 |  |
| Long-term deferred revenues | 11,875 |  |  | 5,673 |  |
| Total contract liabilities | $ | 133,180 |  |  | $ | 105,726 |  |

- changed (2021-11-05):
[0000926326-21-000034:note_history:51]
Short-term deferred revenues of $114.7 million and $100.1 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $24.1 million and $21.0 million, as of September 30, 2021 and December 31, 2020, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and nine months ended September 30, 2021, the Company recognized revenues of $18.9 million and $90.0 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $121.1 million as of December 31, 2020.
  (was, 2021-08-06, similarity 0.9535):
[0000926326-21-000026:note_history:51]
Short-term deferred revenues of $121.3 million and $100.1 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $21.4 million and $21.0 million, as of June 30, 2021 and December 31, 2020, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and six months ended June 30, 2021, the Company recognized revenues of $23.8 million and $71.1 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $121.1 million as of December 31, 2020.

- added (2021-11-05):
[0000926326-21-000034:note_history:52]
Long-term deferred revenues include deferred revenues from product and service contracts of $14.1 million and $5.7 million as of September 30, 2021 and December 31, 2020, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.

- changed (2021-11-05):
[0000926326-21-000034:note_history:53]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2021 and 2020. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of September 30, 2021 and December 31, 2020.
  (was, 2021-08-06, similarity 0.8526):
[0000926326-21-000026:note_history:53]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2021 and 2020. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of June 30, 2021 and December 31, 2020.

- removed (2021-11-05):
[0000926326-21-000026:note_history:54]
Long-term deferred revenues include deferred revenues from product and service contracts of $11.9 million and $5.7 million as of June 30, 2021 and December 31, 2020, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-11-05):
[0000926326-21-000026:note_history:55]
Subsequent EventsOn July 26, 2021, the Company announced its acquisition of RxInnovation Inc., a Delaware corporation, operating as FDS Amplicare (“FDS Amplicare”), for total aggregate cash consideration of $177.0 million, subject to customary adjustments. FDS Amplicare is a pharmacy software solutions provider. The transaction, which is expected to close in the second half of 2021, is subject to clearance under the Hart-Scott-Rodino Act and the satisfaction of other customary closing conditions.
