# OMCL 8-K — 0000926326-21-000031 filed 2021-11-02

## item codes, every 8-K on or before 2021-11-05

- 2021-11-02 0000926326-21-000031 — 2.02, 9.01
- 2021-09-09 0000926326-21-000028 — 7.01, 9.01
- 2021-07-29 0000926326-21-000024 — 2.02, 9.01
- 2021-07-26 0000926326-21-000022 — 7.01, 9.01
- 2021-07-12 0000926326-21-000019 — 5.02, 9.01
- 2021-05-28 0000926326-21-000015 — 5.07
- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2021-11-05

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-21-000031:8k_2_02:1]
EX-99.1
2
exhibit991q3-21.htm
EX-99.1

[0000926326-21-000031:8k_2_02:2]
Document

[0000926326-21-000031:8k_2_02:3]
Exhibit 99.1

[0000926326-21-000031:8k_2_02:4]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Vice President, Investor Relations |  | 590 East Middlefield Road |
| 650-435-3318 |  | Mountain View, CA 94043 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0000926326-21-000031:8k_2_02:5]
Omnicell Announces Financial Results for Third Quarter 2021

[0000926326-21-000031:8k_2_02:6]
GAAP and non-GAAP revenues of $296 million

[0000926326-21-000031:8k_2_02:7]
GAAP net income per diluted share of $0.61

[0000926326-21-000031:8k_2_02:8]
Non-GAAP net income per diluted share of $1.08

[0000926326-21-000031:8k_2_02:9]
MOUNTAIN VIEW, Calif. -- November 2, 2021 -- Omnicell, Inc. (NASDAQ:OMCL) (“Omnicell,” “we,” “our,” “us,” “management,” or the “Company”), a leading provider of medication management solutions and adherence tools for healthcare systems and pharmacies, today announced results for its third quarter ended September 30, 2021.

[0000926326-21-000031:8k_2_02:10]
GAAP Results

[0000926326-21-000031:8k_2_02:11]
Total GAAP revenues for the third quarter of 2021 were $296.4 million, up $82.7 million, or 38.7%, from the third quarter of 2020. The increase in GAAP revenues reflects momentum in our commercial business and strong customer implementations as well as recovery from the impact of COVID-19 relative to the third quarter of 2020. Total GAAP revenues for the nine months ended September 30, 2021 were $821.0 million, up $178.0 million, or 27.7%, from the nine months ended September 30, 2020.

[0000926326-21-000031:8k_2_02:12]
GAAP net income for the third quarter of 2021 was $29.3 million, or $0.61 per diluted share. This compares to GAAP net income of $8.8 million, or $0.20 per diluted share, for the third quarter of 2020.

[0000926326-21-000031:8k_2_02:13]
GAAP net income for the nine months ended September 30, 2021 was $63.9 million, or $1.35 per diluted share. This compares to GAAP net income of $15.8 million, or $0.36 per diluted share, for the nine months ended September 30, 2020.

[0000926326-21-000031:8k_2_02:14]
Non-GAAP Results

[0000926326-21-000031:8k_2_02:15]
Total non-GAAP revenues for the third quarter of 2021 were $296.5 million, up $82.8 million, or 38.7%, from the third quarter of 2020. Total non-GAAP revenues for the nine months ended September 30, 2021 were $821.1 million, up $178.1 million, or 27.7%, from the nine months ended September 30, 2020.

[0000926326-21-000031:8k_2_02:16]
Non-GAAP net income for the third quarter of 2021 was $49.9 million, or $1.08 per diluted share. This compares to non-GAAP net income of $26.2 million, or $0.60 per diluted share, for the third quarter of 2020.

[0000926326-21-000031:8k_2_02:17]
Non-GAAP net income for the nine months ended September 30, 2021 was $131.6 million, or $2.90 per diluted share. This compares to non-GAAP net income of $71.1 million, or $1.63 per diluted share, for the nine months ended September 30, 2020.

[0000926326-21-000031:8k_2_02:18]
Non-GAAP EBITDA for the third quarter of 2021 was $65.9 million. This compares to non-GAAP EBITDA of $41.2 million for the third quarter of 2020.

[0000926326-21-000031:8k_2_02:19]
Non-GAAP EBITDA for the nine months ended September 30, 2021 was $177.6 million. This compares to non-GAAP EBITDA of $107.8 million for the nine months ended September 30, 2020.

[0000926326-21-000031:8k_2_02:20]
“Our strong third quarter results reflect the continued momentum in Omnicell’s commercial business and the robust customer adoption of our cloud-based, Advanced Services portfolio,” said Randall Lipps, Chairman, President, Chief Executive Officer, and founder of Omnicell. “I am pleased with the solid execution this quarter and the progress we are making toward our long-term 2025 financial targets. Our strategic focus on advancing the vision of the autonomous pharmacy, combined with our

[0000926326-21-000031:8k_2_02:21]
employees’ dedication to our customers’ success, should position us well for continued value creation for all of our stakeholders.”

[0000926326-21-000031:8k_2_02:22]
During the third quarter of 2021, Omnicell announced that it had completed its acquisition of pharmacy technology provider RxInnovation Inc., operating as FDS Amplicare (“FDS Amplicare”). This strategic acquisition has added a suite of comprehensive and complementary software-as-a-service (“SaaS”) technology solutions, as well as a nationwide network of more than 15,000 independent and specialty retail pharmacies, to expand the broad industry footprint of Omnicell’s EnlivenHealth™ offering. We believe that, with the combination of EnlivenHealth and FDS Amplicare®, Omnicell now provides one of the industry’s most comprehensive offerings of SaaS technology solutions that is designed to help retail pharmacies and health plans grow and thrive in the new era of digital-driven healthcare. The results of operations of FDS Amplicare have been included in our consolidated results of operations beginning September 9, 2021.

[0000926326-21-000031:8k_2_02:23]
In April of 2021, Omnicell published its Corporate Responsibility Report, which outlines the Company’s approach to corporate responsibility, defined through the four strategic pillars of Innovation, Environment, Social, and Governance, and describes Omnicell’s contributions to achieve a more sustainable future. The report details Omnicell’s focus on innovating to drive sustainability across the business by adhering to the Organization for Economic Co-operation and Development guidance for the responsible sourcing of raw materials and elevating our diversity and inclusion initiatives. In addition, the report includes a deeper look at Omnicell’s role in managing the impact of the COVID-19 pandemic on our customers, operations, and employees. For more information on Omnicell’s commitment to sustainability, please visit http://www.omnicell.com/corporate-social-responsibility-esg.

[0000926326-21-000031:8k_2_02:24]
2021 Guidance

[0000926326-21-000031:8k_2_02:25]
For the fourth quarter of 2021, the Company expects total GAAP and non-GAAP revenues to be between $308 million and $313 million. The Company expects fourth quarter GAAP and non-GAAP product revenues to be between $219 million and $222 million, and fourth quarter GAAP and non-GAAP service revenues to be between $89 million and $91 million. The Company expects fourth quarter 2021 non-GAAP EBITDA to be between $58 million and $61 million. The Company expects fourth quarter 2021 non-GAAP earnings to be between $0.90 and $0.95 per share.

[0000926326-21-000031:8k_2_02:26]
For the full year of 2021, the Company expects product bookings to be between $1.130 billion and $1.170 billion. The Company expects full year 2021 total GAAP and non-GAAP revenues to be between $1.129 billion and $1.134 billion. The Company expects full year 2021 GAAP and non-GAAP product revenues to be between $808 million and $811 million, and full year 2021 GAAP and non-GAAP service revenues to be between $321 million and $323 million. The Company expects full year 2021 non-GAAP EBITDA to be between $235 million and $238 million. The Company expects full year 2021 non-GAAP earnings to be between $3.80 and $3.85 per share. Our fourth quarter and full year 2021 guidance includes the anticipated contribution of FDS Amplicare, as well as the anticipated effects of the current inflationary environment.

[0000926326-21-000031:8k_2_02:27]
The table below summarizes Omnicell’s 2021 guidance outlined above.

[0000926326-21-000031:8k_2_02:28]
|  | Q4’21 | FY 2021 |
| Product Bookings | Not provided | $1.130 billion - $1.170 billion |
| Total GAAP and Non-GAAP Revenues | $308 million - $313 million | $1.129 billion - $1.134 billion |
| GAAP and Non-GAAP Product Revenues | $219 million - $222 million | $808 million - $811 million |
| GAAP and Non-GAAP Service Revenues | $89 million - $91 million | $321 million - $323 million |
| Non-GAAP EBITDA | $58 million - $61 million | $235 million - $238 million |
| Non-GAAP Earnings Per Share | $0.90 - $0.95 | $3.80 - $3.85 |

[0000926326-21-000031:8k_2_02:29]
The Company does not provide guidance for GAAP net income or GAAP earnings per share nor a reconciliation of forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures on a forward-looking basis because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These forward-looking non-GAAP financial measures do not include certain items, which may be significant, including, but not limited to, unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-21-000031:8k_2_02:30]
Omnicell Conference Call Information

[0000926326-21-000031:8k_2_02:31]
Omnicell will hold a conference call today, Tuesday, November 2, 2021 at 5:30 a.m. PT to discuss third quarter of 2021 financial results. The conference call can be accessed by dialing 1-855-451-1210 within the U.S. or 1-236-714-3867 for all other locations. The Conference ID # is 5688577. A link to the live and archived webcast will also be available on the Investor Relations section of Omnicell’s website at http://ir.omnicell.com/events-and-presentations/.

[0000926326-21-000031:8k_2_02:32]
About Omnicell

[0000926326-21-000031:8k_2_02:33]
Since 1992, Omnicell has been committed to transforming the pharmacy care delivery model to dramatically improve outcomes and lower costs. Through the vision of the autonomous pharmacy, a combination of automation, intelligence, and technology-enabled services, powered by a cloud data platform, Omnicell supports more efficient ways to manage medications across all care settings.

[0000926326-21-000031:8k_2_02:34]
Over 7,000 facilities worldwide use Omnicell automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 60,000 institutional and retail pharmacies across North America and the United Kingdom leverage Omnicell’s innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-21-000031:8k_2_02:35]
To learn more, visit www.omnicell.com. From time to time, Omnicell may use the Company’s investor relations website and other online social media channels, including its Twitter handle www.twitter.com/omnicell, LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure (“FD”).

[0000926326-21-000031:8k_2_02:36]
OMNICELL and AMPLICARE are registered trademarks and the Omnicell logo and ENLIVENHEALTH are trademarks of Omnicell, Inc. or one of its subsidiaries.

[0000926326-21-000031:8k_2_02:37]
Forward-Looking Statements

[0000926326-21-000031:8k_2_02:38]
Use of Non-GAAP Financial Information

[0000926326-21-000031:8k_2_02:39]
This press release contains financial measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to revenues, gross profit, operating expenses, income from operations, net income, net income per diluted share, diluted shares, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results and metrics because management considers them to be important supplemental measures of Omnicell’s performance and refers to such measures when analyzing Omnicell’s strategy and operations.

[0000926326-21-000031:8k_2_02:40]
Our non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within such period that directly drive operating income in such period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results: non-GAAP revenues excludes from its GAAP equivalent item a) below; non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items a), b), c), and e) below; non-GAAP operating expenses excludes from its GAAP equivalents items b), c), d), e), h), and i) below; non-GAAP income from operations and non-GAAP operating margin exclude from their GAAP equivalents items a), b), c), d), e), h), and i) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through j) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, and amortization. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents items a), b), d), e), f), g), h), and i) below:

[0000926326-21-000031:8k_2_02:41]
a)Acquisition accounting impact related to deferred revenues. In connection with the recent acquisition of FDS Amplicare, we recorded a fair value adjustment to acquired deferred revenues as part of the purchase accounting in accordance with GAAP. The adjustment represents revenues that would have been recognized in the normal course of business by FDS Amplicare if the acquisition had not occurred, but was not recognized due to GAAP purchase accounting requirements. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0000926326-21-000031:8k_2_02:42]
b)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-21-000031:8k_2_02:43]
c)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-21-000031:8k_2_02:44]
d)Acquisition-related expenses. We excluded from our non-GAAP results the expenses related to recent acquisitions. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of acquisition activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of less acquisitive peer companies.

[0000926326-21-000031:8k_2_02:45]
e)Severance-related expenses. We excluded from our non-GAAP results the expenses related to restructuring events. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-21-000031:8k_2_02:46]
f)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of term loan and revolving credit facilities, as well as the issuance of convertible senior notes. The costs include underwriting fees,

[0000926326-21-000031:8k_2_02:47]
original issue discount, ticking fees, and legal fees. These non-cash expenses are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-21-000031:8k_2_02:48]
g)Amortization of discount on convertible senior notes. We excluded from our non-GAAP results the amortization of the imputed discount on our convertible senior notes. Under GAAP, certain convertible debt instruments that may be settled in cash upon conversion are required to be bifurcated into separate liability and equity components in a manner that reflects the issuer’s assumed non-convertible debt borrowing rate. For GAAP purposes, we are required to recognize the imputed interest expense on the difference between our assumed non-convertible debt borrowing rate and the coupon rate on our convertible senior notes. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-21-000031:8k_2_02:49]
h)Intellectual property (“IP”) and legal entities restructuring costs. We excluded from our non-GAAP results the expenses related to IP and legal entities’ restructuring events, such as legal and tax consulting costs. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-21-000031:8k_2_02:50]
i)Certain litigation costs. We excluded non-recurring charges and benefits, including litigation expenses and settlements, related to litigation matters that are outside of the ordinary course of our business or that are not representative of those that we historically have incurred. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-21-000031:8k_2_02:51]
j)Tax impact from IP restructuring. We excluded from our non-GAAP results the tax impact related to the release of a net uncertain tax benefit as a result of effective settlement with the tax authorities related to prior IP restructuring. This impact is unrelated to our ongoing operations, and we do not expect it to occur in the ordinary course of business. We believe that excluding this impact provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-21-000031:8k_2_02:52]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational or non-cash expenses involving stock compensation plans or other items.

[0000926326-21-000031:8k_2_02:53]
We believe that the presentation of non-GAAP revenues, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0000926326-21-000031:8k_2_02:54]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-21-000031:8k_2_02:55]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-21-000031:8k_2_02:56]
c)These non-GAAP financial measures are employed by management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting.

[0000926326-21-000031:8k_2_02:57]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-21-000031:8k_2_02:58]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-21-000031:8k_2_02:59]
i)While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-21-000031:8k_2_02:60]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-21-000031:8k_2_02:61]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0000926326-21-000031:8k_2_02:62]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-21-000031:8k_2_02:63]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-21-000031:8k_2_02:64]
a)Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-21-000031:8k_2_02:65]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-21-000031:8k_2_02:66]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-21-000031:8k_2_02:67]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release as well as in Omnicell’s other reports filed with or furnished to the SEC.

[0000926326-21-000031:8k_2_02:68]
Omnicell, Inc.

[0000926326-21-000031:8k_2_02:69]
Condensed Consolidated Statements of Operations

[0000926326-21-000031:8k_2_02:70]
(Unaudited, in thousands, except per share data)

[0000926326-21-000031:8k_2_02:71]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 213,970 |  |  | $ | 151,337 |  |  | $ | 589,006 |  |  | $ | 460,352 |  |
| Services and other revenues | 82,432 |  |  | 62,362 |  |  | 231,978 |  |  | 182,654 |  |
| Total revenues | 296,402 |  |  | 213,699 |  |  | 820,984 |  |  | 643,006 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 110,743 |  |  | 86,689 |  |  | 303,597 |  |  | 262,740 |  |
| Cost of services and other revenues | 38,880 |  |  | 30,219 |  |  | 112,027 |  |  | 90,628 |  |
| Total cost of revenues | 149,623 |  |  | 116,908 |  |  | 415,624 |  |  | 353,368 |  |
| Gross profit | 146,779 |  |  | 96,791 |  |  | 405,360 |  |  | 289,638 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 19,477 |  |  | 15,197 |  |  | 53,770 |  |  | 54,679 |  |
| Selling, general, and administrative | 97,910 |  |  | 71,442 |  |  | 273,672 |  |  | 219,647 |  |
| Total operating expenses | 117,387 |  |  | 86,639 |  |  | 327,442 |  |  | 274,326 |  |
| Income from operations | 29,392 |  |  | 10,152 |  |  | 77,918 |  |  | 15,312 |  |
| Interest and other income (expense), net | (6,065) |  |  | 809 |  |  | (18,715) |  |  | 161 |  |
| Income before provision for income taxes | 23,327 |  |  | 10,961 |  |  | 59,203 |  |  | 15,473 |  |
| Provision for (benefit from) income taxes | (5,990) |  |  | 2,156 |  |  | (4,665) |  |  | (344) |  |
| Net income | $ | 29,317 |  |  | $ | 8,805 |  |  | $ | 63,868 |  |  | $ | 15,817 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.67 |  |  | $ | 0.21 |  |  | $ | 1.48 |  |  | $ | 0.37 |  |
| Diluted | $ | 0.61 |  |  | $ | 0.20 |  |  | $ | 1.35 |  |  | $ | 0.36 |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 43,648 |  |  | 42,802 |  |  | 43,293 |  |  | 42,606 |  |
| Diluted | 48,341 |  |  | 43,691 |  |  | 47,195 |  |  | 43,651 |  |

[0000926326-21-000031:8k_2_02:72]
7

[0000926326-21-000031:8k_2_02:73]
Omnicell, Inc.

[0000926326-21-000031:8k_2_02:74]
Condensed Consolidated Balance Sheets

[0000926326-21-000031:8k_2_02:75]
(Unaudited, in thousands)

[0000926326-21-000031:8k_2_02:76]
|  | September 30,2021 |  | December 31,2020 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 481,549 |  |  | $ | 485,928 |  |
| Accounts receivable and unbilled receivables, net | 233,729 |  |  | 190,117 |  |
| Inventories | 104,259 |  |  | 96,298 |  |
| Prepaid expenses | 24,762 |  |  | 16,027 |  |
| Other current assets | 44,417 |  |  | 41,044 |  |
| Total current assets | 888,716 |  |  | 829,414 |  |
| Property and equipment, net | 64,955 |  |  | 59,073 |  |
| Long-term investment in sales-type leases, net | 19,187 |  |  | 22,156 |  |
| Operating lease right-of-use assets | 48,973 |  |  | 55,114 |  |
| Goodwill | 616,387 |  |  | 499,309 |  |
| Intangible assets, net | 218,956 |  |  | 168,211 |  |
| Long-term deferred tax assets | 15,866 |  |  | 15,019 |  |
| Prepaid commissions | 57,949 |  |  | 56,919 |  |
| Other long-term assets | 120,482 |  |  | 119,289 |  |
| Total assets | $ | 2,051,471 |  |  | $ | 1,824,504 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 74,656 |  |  | $ | 40,309 |  |
| Accrued compensation | 45,044 |  |  | 55,750 |  |
| Accrued liabilities | 104,236 |  |  | 80,311 |  |
| Deferred revenues, net | 114,726 |  |  | 100,053 |  |
| Total current liabilities | 338,662 |  |  | 276,423 |  |
| Long-term deferred revenues | 14,141 |  |  | 5,673 |  |
| Long-term deferred tax liabilities | 53,313 |  |  | 39,633 |  |
| Long-term operating lease liabilities | 40,436 |  |  | 48,897 |  |
| Other long-term liabilities | 10,761 |  |  | 19,174 |  |
| Convertible senior notes, net | 482,822 |  |  | 467,201 |  |
| Total liabilities | 940,135 |  |  | 857,001 |  |
| Total stockholders’ equity | 1,111,336 |  |  | 967,503 |  |
| Total liabilities and stockholders’ equity | $ | 2,051,471 |  |  | $ | 1,824,504 |  |

[0000926326-21-000031:8k_2_02:77]
Omnicell, Inc.

[0000926326-21-000031:8k_2_02:78]
Condensed Consolidated Statements of Cash Flows

[0000926326-21-000031:8k_2_02:79]
(Unaudited, in thousands)

[0000926326-21-000031:8k_2_02:80]
|  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |
| Operating Activities |  |  |  |
| Net income | $ | 63,868 |  |  | $ | 15,817 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 53,140 |  |  | 43,903 |  |
| Loss on disposal of property and equipment | 297 |  |  | — |  |
| Share-based compensation expense | 38,477 |  |  | 33,034 |  |
| Deferred income taxes | 2,042 |  |  | (3,643) |  |
| Amortization of operating lease right-of-use assets | 8,764 |  |  | 7,692 |  |
| Amortization of debt issuance costs | 2,570 |  |  | 754 |  |
| Amortization of discount on convertible senior notes | 13,874 |  |  | 249 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | (39,561) |  |  | 29,653 |  |
| Inventories | (10,138) |  |  | 4,570 |  |
| Prepaid expenses | (8,229) |  |  | (6,272) |  |
| Other current assets | (1,059) |  |  | (6,617) |  |
| Investment in sales-type leases | 2,686 |  |  | (3,273) |  |
| Prepaid commissions | (1,030) |  |  | 2,213 |  |
| Other long-term assets | 2,567 |  |  | (4,023) |  |
| Accounts payable | 33,111 |  |  | (8,659) |  |
| Accrued compensation | (12,018) |  |  | (8,377) |  |
| Accrued liabilities | 20,149 |  |  | 3,281 |  |
| Deferred revenues | 21,225 |  |  | 8,827 |  |
| Operating lease liabilities | (9,392) |  |  | (7,764) |  |
| Other long-term liabilities | (9,166) |  |  | 8,057 |  |
| Net cash provided by operating activities | 172,177 |  |  | 109,422 |  |
| Investing Activities |  |  |  |
| Software development for external use | (24,141) |  |  | (25,909) |  |
| Purchases of property and equipment | (17,892) |  |  | (17,265) |  |
| Business acquisition, net of cash acquired | (178,080) |  |  | — |  |
| Net cash used in investing activities | (220,113) |  |  | (43,174) |  |
| Financing Activities |  |  |  |
| Proceeds from revolving credit facility | — |  |  | 150,000 |  |
| Repayment of revolving credit facility | — |  |  | (200,000) |  |
| Payments for debt issuance costs for revolving credit facility | — |  |  | (550) |  |
| Proceeds from issuance of convertible senior notes, net of issuance costs | — |  |  | 559,665 |  |
| Purchase of convertible note hedge | — |  |  | (100,625) |  |
| Proceeds from sale of warrants | — |  |  | 51,290 |  |
| Proceeds from issuances under stock-based compensation plans | 53,917 |  |  | 33,226 |  |
| Employees’ taxes paid related to restricted stock units | (10,161) |  |  | (4,101) |  |
| Change in customer funds, net | (3,059) |  |  | — |  |
| Stock repurchases | — |  |  | (53,035) |  |
| Net cash provided by financing activities | 40,697 |  |  | 435,870 |  |
| Effect of exchange rate changes on cash and cash equivalents | (492) |  |  | (157) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | (7,731) |  |  | 501,961 |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 489,920 |  |  | 127,210 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 482,189 |  |  | $ | 629,171 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |
| Cash and cash equivalents | $ | 481,549 |  |  | $ | 629,171 |  |
| Restricted cash included in Other current assets | 640 |  |  | — |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 482,189 |  |  | $ | 629,171 |  |

[0000926326-21-000031:8k_2_02:81]
9

[0000926326-21-000031:8k_2_02:82]
Omnicell, Inc.

[0000926326-21-000031:8k_2_02:83]
Reconciliation of GAAP to Non-GAAP

[0000926326-21-000031:8k_2_02:84]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-21-000031:8k_2_02:85]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Reconciliation of GAAP revenues to non-GAAP revenues: |
| GAAP revenues | $ | 296,402 |  |  | $ | 213,699 |  |  | $ | 820,984 |  |  | $ | 643,006 |  |
| Acquisition accounting impact related to deferred revenues | 95 |  |  | — |  |  | 95 |  |  | — |  |
| Non-GAAP revenues | $ | 296,497 |  |  | $ | 213,699 |  |  | $ | 821,079 |  |  | $ | 643,006 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit | $ | 146,779 |  |  | $ | 96,791 |  |  | $ | 405,360 |  |  | $ | 289,638 |  |
| GAAP gross margin | 49.5% |  | 45.3% |  | 49.4% |  | 45.0% |
| Share-based compensation expense | 1,909 |  |  | 1,758 |  |  | 5,890 |  |  | 5,658 |  |
| Amortization of acquired intangibles | 2,727 |  |  | 2,032 |  |  | 8,210 |  |  | 6,100 |  |
| Acquisition accounting impact related to deferred revenues | 95 |  |  | — |  |  | 95 |  |  | — |  |
| Severance-related expenses | — |  |  | — |  |  | 389 |  |  | 2,564 |  |
| Non-GAAP gross profit | $ | 151,510 |  |  | $ | 100,581 |  |  | $ | 419,944 |  |  | $ | 303,960 |  |
| Non-GAAP gross margin | 51.1% |  | 47.1% |  | 51.1% |  | 47.3% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 117,387 |  |  | $ | 86,639 |  |  | $ | 327,442 |  |  | $ | 274,326 |  |
| GAAP operating expenses % to total revenues | 39.6% |  | 40.5% |  | 39.9% |  | 42.7% |
| Share-based compensation expense | (11,757) |  |  | (9,266) |  |  | (32,587) |  |  | (27,376) |  |
| Amortization of acquired intangibles | (3,518) |  |  | (2,336) |  |  | (10,340) |  |  | (7,056) |  |
| Acquisition-related expenses | (4,772) |  |  | (3,121) |  |  | (6,758) |  |  | (3,121) |  |
| Severance-related and other expenses (a) | — |  |  | (84) |  |  | (2,582) |  |  | (8,272) |  |
| Non-GAAP operating expenses | $ | 97,340 |  |  | $ | 71,832 |  |  | $ | 275,175 |  |  | $ | 228,501 |  |
| Non-GAAP operating expenses as a % of total non-GAAP revenues | 32.8% |  | 33.6% |  | 33.5% |  | 35.5% |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |
| GAAP income from operations | $ | 29,392 |  |  | $ | 10,152 |  |  | $ | 77,918 |  |  | $ | 15,312 |  |
| GAAP operating income % to total revenues | 9.9% |  | 4.8% |  | 9.5% |  | 2.4% |
| Share-based compensation expense | 13,666 |  |  | 11,024 |  |  | 38,477 |  |  | 33,034 |  |
| Amortization of acquired intangibles | 6,245 |  |  | 4,368 |  |  | 18,550 |  |  | 13,156 |  |
| Acquisition accounting impact related to deferred revenues | 95 |  |  | — |  |  | 95 |  |  | — |  |
| Acquisition-related expenses | 4,772 |  |  | 3,121 |  |  | 6,758 |  |  | 3,121 |  |
| Severance-related and other expenses (a) | — |  |  | 84 |  |  | 2,971 |  |  | 10,836 |  |
| Non-GAAP income from operations | $ | 54,170 |  |  | $ | 28,749 |  |  | $ | 144,769 |  |  | $ | 75,459 |  |
| Non-GAAP operating margin (non-GAAP operating income as a % of total non-GAAP revenues) | 18.3% |  | 13.5% |  | 17.6% |  | 11.7% |

[0000926326-21-000031:8k_2_02:86]
Omnicell, Inc.

[0000926326-21-000031:8k_2_02:87]
Reconciliation of GAAP to Non-GAAP

[0000926326-21-000031:8k_2_02:88]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-21-000031:8k_2_02:89]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Reconciliation of GAAP net income to non-GAAP net income: |
| GAAP net income | $ | 29,317 |  |  | $ | 8,805 |  |  | $ | 63,868 |  |  | $ | 15,817 |  |
| Tax impact of IP restructuring | (6,202) |  |  | — |  |  | (6,202) |  |  | — |  |
| Share-based compensation expense | 13,666 |  |  | 11,024 |  |  | 38,477 |  |  | 33,034 |  |
| Amortization of acquired intangibles | 6,245 |  |  | 4,368 |  |  | 18,550 |  |  | 13,156 |  |
| Acquisition accounting impact related to deferred revenues | 95 |  |  | — |  |  | 95 |  |  | — |  |
| Acquisition-related expenses | 4,772 |  |  | 3,121 |  |  | 6,758 |  |  | 3,121 |  |
| Severance-related and other expenses (a) | — |  |  | 84 |  |  | 2,971 |  |  | 10,836 |  |
| Amortization of debt issuance costs | 863 |  |  | 272 |  |  | 2,570 |  |  | 754 |  |
| Amortization of discount on convertible senior notes | 4,679 |  |  | 249 |  |  | 13,874 |  |  | 249 |  |
| Tax effect of the adjustments above (b) | (3,497) |  |  | (1,700) |  |  | (9,411) |  |  | (5,905) |  |
| Non-GAAP net income | $ | 49,938 |  |  | $ | 26,223 |  |  | $ | 131,550 |  |  | $ | 71,062 |  |
| Reconciliation of GAAP net income per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 48,341 |  |  | 43,691 |  |  | 47,195 |  |  | 43,651 |  |
| Shares - diluted non-GAAP (c) | 46,185 |  |  | 43,691 |  |  | 45,379 |  |  | 43,651 |  |
| GAAP net income per share - diluted | $ | 0.61 |  |  | $ | 0.20 |  |  | $ | 1.35 |  |  | $ | 0.36 |  |
| Tax impact of IP restructuring | (0.13) |  |  | — |  |  | (0.14) |  |  | — |  |
| Share-based compensation expense | 0.29 |  |  | 0.25 |  |  | 0.85 |  |  | 0.76 |  |
| Amortization of acquired intangibles | 0.14 |  |  | 0.10 |  |  | 0.41 |  |  | 0.30 |  |
| Acquisition accounting impact related to deferred revenues | 0.00 |  |  | — |  |  | 0.00 |  |  | — |  |
| Acquisition-related expenses | 0.10 |  |  | 0.07 |  |  | 0.15 |  |  | 0.07 |  |
| Severance-related and other expenses | — |  |  | 0.00 |  |  | 0.07 |  |  | 0.25 |  |
| Amortization of debt issuance costs | 0.02 |  |  | 0.01 |  |  | 0.06 |  |  | 0.02 |  |
| Amortization of discount on convertible senior notes | 0.10 |  |  | 0.01 |  |  | 0.31 |  |  | 0.01 |  |
| Non-GAAP dilutive shares impact from convertible note hedge transaction (c) | 0.03 |  |  | — |  |  | 0.05 |  |  | — |  |
| Tax effect of the adjustments above (b) | (0.08) |  |  | (0.04) |  |  | (0.21) |  |  | (0.14) |  |
| Non-GAAP net income per share - diluted | $ | 1.08 |  |  | $ | 0.60 |  |  | $ | 2.90 |  |  | $ | 1.63 |  |
| Reconciliation of GAAP net income to non-GAAP EBITDA(d): |
| GAAP net income | $ | 29,317 |  |  | $ | 8,805 |  |  | $ | 63,868 |  |  | $ | 15,817 |  |
| Share-based compensation expense | 13,666 |  |  | 11,024 |  |  | 38,477 |  |  | 33,034 |  |
| Interest (income) and expense, net | 360 |  |  | 380 |  |  | 520 |  |  | 442 |  |
| Depreciation and amortization expense | 18,175 |  |  | 15,124 |  |  | 53,140 |  |  | 43,903 |  |
| Acquisition accounting impact related to deferred revenues | 95 |  |  | — |  |  | 95 |  |  | — |  |
| Acquisition-related expenses | 4,772 |  |  | 3,121 |  |  | 6,758 |  |  | 3,121 |  |
| Severance-related and other expenses (a) | — |  |  | 84 |  |  | 2,971 |  |  | 10,836 |  |
| Amortization of debt issuance costs | 863 |  |  | 272 |  |  | 2,570 |  |  | 754 |  |
| Amortization of discount on convertible senior notes | 4,679 |  |  | 249 |  |  | 13,874 |  |  | 249 |  |
| Income tax expense (benefit) | (5,990) |  |  | 2,156 |  |  | (4,665) |  |  | (344) |  |
| Non-GAAP EBITDA | $ | 65,937 |  |  | $ | 41,215 |  |  | $ | 177,608 |  |  | $ | 107,812 |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA as a % of total non-GAAP revenues) | 22.2% |  | 19.3% |  | 21.6% |  | 16.8% |

[0000926326-21-000031:8k_2_02:90]
11

[0000926326-21-000031:8k_2_02:91]
_________________________________________________

[0000926326-21-000031:8k_2_02:92]
(a)For the nine months ended September 30, 2021, other expenses included approximately $1.0 million of certain litigation costs. For the nine months ended September 30, 2020, other expenses included approximately $0.9 million of IP and legal entities’ restructuring costs.

[0000926326-21-000031:8k_2_02:93]
(b)Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2021 and 2020.

[0000926326-21-000031:8k_2_02:94]
(c)For the three and nine months ended September 30, 2021, non-GAAP diluted shares exclude approximately 2.2 million and 1.8 million shares, respectively, related to the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction.

[0000926326-21-000031:8k_2_02:95]
(d)Defined as earnings before interest income and expense, taxes, depreciation, amortization, share-based compensation, as well as excluding certain non-GAAP adjustments.

[0000926326-21-000031:8k_2_02:96]
Omnicell, Inc.

[0000926326-21-000031:8k_2_02:97]
Reconciliation of GAAP to Non-GAAP

[0000926326-21-000031:8k_2_02:98]
(Unaudited, in thousands)

[0000926326-21-000031:8k_2_02:99]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Reconciliation of GAAP net cash provided by operating activities to non-GAAP free cash flow: |
| GAAP net cash provided by operating activities | $ | 42,989 |  |  | $ | 36,687 |  |  | $ | 172,177 |  |  | $ | 109,422 |  |
| Software development for external use | (8,726) |  |  | (5,907) |  |  | (24,141) |  |  | (25,909) |  |
| Purchases of property and equipment | (6,825) |  |  | (4,054) |  |  | (17,892) |  |  | (17,265) |  |
| Non-GAAP free cash flow | $ | 27,438 |  |  | $ | 26,726 |  |  | $ | 130,144 |  |  | $ | 66,248 |  |

[0000926326-21-000031:8k_2_02:100]
13
