# OMCL MD&A — 0000926326-16-000077


## mdna

[0000926326-16-000077:mdna:1]
[same as prior period, unchanged from 0000926326-16-000070:mdna:1]

[0000926326-16-000077:mdna:2]
[same as prior period, unchanged from 0000926326-16-000070:mdna:2]

[0000926326-16-000077:mdna:3]
[same as prior period, unchanged from 0000926326-16-000070:mdna:5]

[0000926326-16-000077:mdna:4]
[same as prior period, unchanged from 0000926326-16-000070:mdna:6]

[0000926326-16-000077:mdna:5]
[same as prior period, unchanged from 0000926326-16-000070:mdna:7]

[0000926326-16-000077:mdna:6]
[same as prior period, unchanged from 0000926326-16-000070:mdna:8]

[0000926326-16-000077:mdna:7]
[same as prior period, unchanged from 0000926326-16-000070:mdna:9]

[0000926326-16-000077:mdna:8]
[same as prior period, unchanged from 0000926326-16-000070:mdna:10]

[0000926326-16-000077:mdna:9]
[same as prior period, unchanged from 0000926326-16-000070:mdna:11]

[0000926326-16-000077:mdna:10]
[same as prior period, unchanged from 0000926326-16-000070:mdna:12]

[0000926326-16-000077:mdna:11]
26

[0000926326-16-000077:mdna:12]
[same as prior period, unchanged from 0000926326-16-000070:mdna:13]

[0000926326-16-000077:mdna:13]
[same as prior period, unchanged from 0000926326-16-000070:mdna:14]

[0000926326-16-000077:mdna:14]
[same as prior period, unchanged from 0000926326-16-000070:mdna:15]

[0000926326-16-000077:mdna:15]
[same as prior period, unchanged from 0000926326-16-000070:mdna:16]

[0000926326-16-000077:mdna:16]
We are a leading provider of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum; from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home. Over 4,000 customers worldwide use Omnicell automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence and improve patient safety. The acquisition of Aesynt adds distinct capabilities, particularly in central pharmacy and IV robotics, creating the broadest medication management product portfolio in the industry.

[0000926326-16-000077:mdna:17]
Omnicell Medication Adherence solutions, including our MTS Medication Technologies, SureMed and Surgichem brands, provide innovative medication adherence packaging solutions designed to help reduce costly hospital readmissions. In addition, these solutions help enable approximately 17,000 institutional and retail pharmacies in North America and the United Kingdom to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-16-000077:mdna:18]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 88% and 86% of total revenue for both the three and nine months ended September 30, 2016, respectively. We expect our revenues from international operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-16-000077:mdna:19]
On January 5, 2016, we completed the acquisition of all of the membership interests of Aesynt. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. Adding these solution sets to the Omnicell portfolio is intended to give the combined companies one of the most complete medication management offering in the industry. We are now able to support customers who desire a centralized cartfill or nurse server medication distribution model all the way to fully decentralized dispensing and various combinations along that continuum. We are also able to offer solutions for I.V. preparations, including oncology drugs, which is an area where our combined customers have expressed significant interest. Looking across the entire medication distribution model, Aesynt’s new Enterprise Medication Manager software products give the customer the power to optimize the pharmacy supply chain with tools that help manage their inventory, reduce risks of stock outs, and minimize the cost of expiring medications. In addition, Aesynt has an experienced and skilled workforce whose expertise complements our capabilities. Integrating our two product development groups is expected to lead to innovation and the opportunity to help accelerate innovation. Finally, Aesynt has over 1,200 hospital customers with limited overlap to Omnicell’s existing install base, which we expect will drive a significant increase to our customer install base.

[0000926326-16-000077:mdna:20]
[same as prior period, unchanged from 0000926326-16-000070:mdna:22]

[0000926326-16-000077:mdna:21]
[same as prior period, unchanged from 0000926326-16-000070:mdna:23]

[0000926326-16-000077:mdna:22]
27

[0000926326-16-000077:mdna:23]
[same as prior period, unchanged from 0000926326-16-000070:mdna:24]

[0000926326-16-000077:mdna:24]
[same as prior period, unchanged from 0000926326-16-000070:mdna:25]

[0000926326-16-000077:mdna:25]
[same as prior period, unchanged from 0000926326-16-000070:mdna:26]

[0000926326-16-000077:mdna:26]
The Medication Adherence segment primarily includes the design, manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care and correctional facilities or retail pharmacies serving patients in their local communities.

[0000926326-16-000077:mdna:27]
[same as prior period, unchanged from 0000926326-16-000070:mdna:28]

[0000926326-16-000077:mdna:28]
[same as prior period, unchanged from 0000926326-16-000070:mdna:29]

[0000926326-16-000077:mdna:29]
[same as prior period, unchanged from 0000926326-16-000070:mdna:30]

[0000926326-16-000077:mdna:30]
[same as prior period, unchanged from 0000926326-16-000070:mdna:31]

[0000926326-16-000077:mdna:31]
[same as prior period, unchanged from 0000926326-16-000070:mdna:32]

[0000926326-16-000077:mdna:32]
| • | Expansion of our solutions through acquisitions and partnerships. Our acquisitions have generally been focused on automation of manual workflows or data analytics, which is the enhancement of data for our customers’ decision-making processes. We believe that expansion of our product lines through acquisition and partnerships to meet our customers changing and evolving expectations is a key component to our historical and future success. |

[0000926326-16-000077:mdna:33]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, we began shipping a refresh of our product line in 2011, which we market as G4. The G4 refresh included multiple new products and an upgrade product that allowed existing customers to augment their installations to obtain the most current technology that we provide. The G4 product is updated regularly every 6 to18 months with new software enhancements. Since its introduction in 2011, there have been five major software releases. The G4 product refresh has been a key contributor to our growth, with approximately 85.2% of our automation and analytics installed base ordering upgrades to their existing systems since the announcement of G4. In addition to enhanced capabilities, we have focused on attaining the highest quality and service measurements for G4 in the industry, while marketing the solution to new and existing customers. Our research and development efforts today are designed to bring new products to market beyond the G4 product line that we believe will meet customer needs in years to come.

[0000926326-16-000077:mdna:34]
Consistent with our strategy to enter new markets, we have made investments in our selling, general and administrative expenses to expand our sales team and market to new customers. Our international efforts have focused

[0000926326-16-000077:mdna:35]
28

[0000926326-16-000077:mdna:36]
primarily on five markets: the United Kingdom, Germany, and France, where we sell the full range of our products primarily through a direct sales team; Middle Eastern countries of the Arabian Peninsula where new healthcare facility construction is taking place, and in China where we launched a Mandarin version of our automated dispensing systems. We have also expanded our sales efforts to healthcare customers outside of acute care hospitals in the United States which has allowed us to sell our automated dispensing solutions and medication adherence products into these markets.

[0000926326-16-000077:mdna:37]
[same as prior period, unchanged from 0000926326-16-000070:mdna:37]

[0000926326-16-000077:mdna:38]
[same as prior period, unchanged from 0000926326-16-000070:mdna:38]

[0000926326-16-000077:mdna:39]
[same as prior period, unchanged from 0000926326-16-000070:mdna:39]

[0000926326-16-000077:mdna:40]
[same as prior period, unchanged from 0000926326-16-000070:mdna:40]

[0000926326-16-000077:mdna:41]
[same as prior period, unchanged from 0000926326-16-000070:mdna:41]

[0000926326-16-000077:mdna:42]
[same as prior period, unchanged from 0000926326-16-000070:mdna:42]

[0000926326-16-000077:mdna:43]
In addition to product solution sales, we provide services to our customers. Our healthcare customers expect a high degree of partnership involvement from their technology suppliers throughout their ownership of the products. We provide extensive installation planning and consulting as part of every product sale and included in the initial price of the solution. Our customers' medication control systems are mission critical to their success and our customers require these systems to be functional at all times. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in one or five year increments.  As a result of the growth of our installed base of customers, our service revenues have also grown. We strive to provide the best service possible, as measured by third-party rating agencies and by our own surveys, to assure our customers continue to seek service maintenance from us. Our liabilities include current and long-term deferred revenues of $128.1 million and $87.3 million as of September 30, 2016 and December 31, 2015, respectively. The current deferred revenue of $93.1 million includes deferred revenue from product sales and service contracts, net of deferred cost of sales of $17.9 million as of September 30, 2016. The current deferred revenues from product sales relate to the delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. The long-term deferred revenue of $17.1 million as of September 30, 2016 includes deferred revenue from service contracts in excess of twelve months.

[0000926326-16-000077:mdna:44]
The growth in our Automation and Analytics revenue for the three months ended September 30, 2016 was driven primarily by the expansion through the Aesynt acquisition. To a lesser extent but of equal importance, revenue growth was also driven by our growth in the number of our customer installations. Installed customers in the United States grew to 2,904 hospitals as of September 30, 2016 from 1,975 hospitals as of September 30, 2015, driven primarily by the acquisition of Aesynt. In addition, our success in upgrading installed customers to newer G4 technology, which is in line with our strategy of

[0000926326-16-000077:mdna:45]
29

[0000926326-16-000077:mdna:46]
striving to deliver differentiated innovation in our solutions further attributed to the increase in revenue. Our larger installed base has provided growth opportunities for follow on sales and increased service contracts and, as a result, our service revenues have also grown for the three and nine months ended September 30, 2016.  Medication Adherence revenue has remained relatively consistent as the population of patients living in nursing homes, primarily in the United States market, has remained relatively constant over the past year.

[0000926326-16-000077:mdna:47]
[same as prior period, unchanged from 0000926326-16-000070:mdna:46]

[0000926326-16-000077:mdna:48]
[same as prior period, unchanged from 0000926326-16-000070:mdna:47]

[0000926326-16-000077:mdna:49]
[same as prior period, unchanged from 0000926326-16-000070:mdna:48]

[0000926326-16-000077:mdna:50]
[same as prior period, unchanged from 0000926326-16-000070:mdna:49]

[0000926326-16-000077:mdna:51]
[same as prior period, unchanged from 0000926326-16-000070:mdna:50]

[0000926326-16-000077:mdna:52]
[same as prior period, unchanged from 0000926326-16-000070:mdna:51]

[0000926326-16-000077:mdna:53]
[same as prior period, unchanged from 0000926326-16-000070:mdna:52]

[0000926326-16-000077:mdna:54]
[same as prior period, unchanged from 0000926326-16-000070:mdna:53]

[0000926326-16-000077:mdna:55]
[same as prior period, unchanged from 0000926326-16-000070:mdna:54]

[0000926326-16-000077:mdna:56]
[same as prior period, unchanged from 0000926326-16-000070:mdna:55]

[0000926326-16-000077:mdna:57]
[same as prior period, unchanged from 0000926326-16-000070:mdna:56]

[0000926326-16-000077:mdna:58]
There have been no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the nine months ended September 30, 2016 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2015. Concurrent with our acquisition of Aesynt in January 2016, certain accounting policies of Aesynt were aligned to conform to the accounting policies of Omnicell.

[0000926326-16-000077:mdna:59]
[same as prior period, unchanged from 0000926326-16-000070:mdna:58]

[0000926326-16-000077:mdna:60]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently adopted and  issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial positions and cash flows.

[0000926326-16-000077:mdna:61]
[same as prior period, unchanged from 0000926326-16-000070:mdna:60]

[0000926326-16-000077:mdna:62]
[same as prior period, unchanged from 0000926326-16-000070:mdna:61]

[0000926326-16-000077:mdna:63]
|  | Three months ended September 30, |
|  | 2016 |  | 2015 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 133,621 |  |  | $ | 100,941 |  |  | $ | 32,680 |  |  | 32 | % |
| Percentage of total revenues | 76 | % |  | 81 | % |  |  |  |  |
| Service and other revenues | 43,116 |  |  | 24,293 |  |  | 18,823 |  |  | 77 | % |
| Percentage of total revenues | 24 | % |  | 19 | % |  |  |  |  |
| Total revenues | $ | 176,737 |  |  | $ | 125,234 |  |  | $ | 51,503 |  |  | 41 | % |

[0000926326-16-000077:mdna:64]
30

[0000926326-16-000077:mdna:65]
Product revenues represented 76% and 81% of total revenues for the three months ended September 30, 2016 and September 30, 2015, respectively. Product revenues increased due to increased sales for Automation and Analytics segment of $30.7 million, and increased sales for Medication Adherence segment of $2.0 million. The acquired company, Aesynt, contributed $21.3 million to the product revenue increase in the Automation and Analytics segment. The remaining increase in this segment was attributed to the continued growth of the Automated Dispensing Cabinet business, larger orders received from our existing customers, and higher implementations. The increase in Medication Adherence segment was attributed to higher sales in the consumable product sales compared to the three months ended September 30, 2015.

[0000926326-16-000077:mdna:66]
Service and other revenues represented 24% and 19% of total revenues for the three months ended September 30, 2016 and September 30, 2015, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues increased primarily due to an increase from our Automation and Analytics segment of $18.8 million attributed to the acquired company, Aesynt, and higher service renewal fees driven mainly by an increase in installed customer base. The acquired company contributed $17.4 million to the increase in service revenue of Automation and Analytics segment for the three months ended September 30, 2016 compared to the three months ended September 30, 2015. Service and other revenues from Medication Adherence segment remained flat for the three months ended September 30, 2016 compared to the same period last year.

[0000926326-16-000077:mdna:67]
Our international sales represented 12% and 17% of total revenues for the three months ended September 30, 2016 and September 30, 2015, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. The year over year decrease in the international sales was primarily related to Aesynt which has higher sales in U.S. in comparison to international sales. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-16-000077:mdna:68]
|  | Nine months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $392,190 |  | $284,204 |  | $ | 107,986 |  |  | 38 | % |
| Percentage of total revenues | 75 | % |  | 80 | % |  |  |  |  |
| Service and other revenues | 128,458 |  |  | 70,039 |  |  | 58,419 |  |  | 83 | % |
| Percentage of total revenues | 25 | % |  | 20 | % |  |  |  |  |
| Total revenues | $ | 520,648 |  |  | $ | 354,243 |  |  | $ | 166,405 |  |  | 47 | % |

[0000926326-16-000077:mdna:69]
Product revenues represented 75% and 80% of total revenues for the nine months ended September 30, 2016 and September 30, 2015, respectively. Product revenues increased due to increased sales for our Automation and Analytics segment of $107.3 million and from our Medication Adherence segment of $0.7 million. The acquired companies Aesynt, Mach4 and Avantec contributed approximately $77.0 million to the Automation and Analytics segment for the nine months ended September 30, 2016.  The remaining increase in the Automation and Analytics segment was attributed to customer conversions, larger orders received from our existing customers, and higher implementations, partially offset by decreases in lease renewals.

[0000926326-16-000077:mdna:70]
Service and other revenues represented 25% and 20% of total revenues for the nine months ended September 30, 2016 and September 30, 2015, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues increased primarily due to an increase from our Automation and Analytics segment of $58.3 million. The acquired companies, Aesynt, Mach4 and Avantec contributed approximately $54.3 million to the increase of service revenue of Automation and Analytics segment for the nine months ended September 30, 2016. The remaining increase in the Automation and Analytics segment service revenue was due to increased product sales.

[0000926326-16-000077:mdna:71]
Our international sales represented 14% and 16% of total revenues for the nine months ended September 30, 2016 and September 30, 2015, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-16-000077:mdna:72]
We anticipate our revenues will continue to increase in 2016 compared to the same periods in 2015 as we fulfill our existing orders and based on our growth in bookings in 2015 and in the first nine months of 2016, some of which will be recognized as revenue in 2016. Our ability to continue to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-16-000077:mdna:73]
31

[0000926326-16-000077:mdna:74]
[same as prior period, unchanged from 0000926326-16-000070:mdna:72]

[0000926326-16-000077:mdna:75]
[same as prior period, unchanged from 0000926326-16-000070:mdna:73]

[0000926326-16-000077:mdna:76]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 152,437 |  |  | $ | 102,967 |  |  | $ | 49,470 |  |  | 48 | % |
| Percentage of total revenues | 86 | % |  | 82 | % |  |  |  |  |
| Medication Adherence | 24,300 |  |  | 22,267 |  |  | 2,033 |  |  | 9 | % |
| Percentage of total revenues | 14 | % |  | 18 | % |  |  |  |  |
| Total revenues | $ | 176,737 |  |  | $ | 125,234 |  |  | $ | 51,503 |  |  | 41 | % |

[0000926326-16-000077:mdna:77]
The increase in Automation and Analytics revenues for the three months ended September 30, 2016 in comparison to the three months ended September 30, 2015 was due to an increase in both product revenue and service revenues which contributed $30.6 million and $18.9 million to the increase, respectively. The increase in product and service revenue was primarily due to our acquisition of Aesynt, which contributed $21.3 million and $17.4 million of the increase in product and service revenue, respectively. The remaining increases in product revenue in the three months ended September 30, 2016 were also attributed to the larger deal sizes primarily due to customer conversions and higher implementations, and partially offset by the decreases in lease renewals.

[0000926326-16-000077:mdna:78]
Medication Adherence revenues increased by $2.0 million for the three months ended September 30, 2016 in comparison to the three months ended September 30, 2015.  While consumable product revenue increased quarter over quarter, the increase was offset by a decrease in the equipment sales primarily due to the timing of installations.

[0000926326-16-000077:mdna:79]
|  | Nine months ended September 30, 2016 |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 450,043 |  |  | $ | 284,447 |  |  | $ | 165,596 |  |  | 58 | % |
| Percentage of total revenues | 86 | % |  | 80 | % |  |  |  |  |
| Medication Adherence | 70,605 |  |  | 69,796 |  |  | 809 |  |  | 1 | % |
| Percentage of total revenues | 14 | % |  | 20 | % |  |  |  |  |
| Total revenues | $ | 520,648 |  |  | $ | 354,243 |  |  | $ | 166,405 |  |  | 47 | % |

[0000926326-16-000077:mdna:80]
The increase in Automation and Analytics revenues for the nine months ended September 30, 2016 in comparison to the nine months ended September 30, 2015 was due to an increase in product revenues of $107.3 million primarily due to the acquired companies Aesynt, Mach4 and Avantec which contributed $77.0 million to the product revenue for the nine months ended September 30, 2016. The increases in product revenues were also attributed to the larger deal sizes primarily due to customer conversions and higher implementations, partially offset by the lower lease renewals. The increase in Automation and Analytics service revenue of $58.3 million for the nine months ended September 30, 2016 in comparison to the nine months ended September 30, 2015 was primarily due to the acquired companies, Aesynt, Mach4 and Avantec, which contributed for $54.3 million. The remaining increase was attributed to increased product sales.

[0000926326-16-000077:mdna:81]
Medication Adherence revenues increased by $0.8 million for the nine months ended September 30, 2016 in comparison to the nine months ended September 30, 2015, primarily due to an increase in consumables sales, which is partially offset by lower product revenues.

[0000926326-16-000077:mdna:82]
[same as prior period, unchanged from 0000926326-16-000070:mdna:81]

[0000926326-16-000077:mdna:83]
[same as prior period, unchanged from 0000926326-16-000070:mdna:82]

[0000926326-16-000077:mdna:84]
[same as prior period, unchanged from 0000926326-16-000070:mdna:69]

[0000926326-16-000077:mdna:85]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 77,828 |  |  | $ | 45,668 |  |  | $ | 32,160 |  |  | 70 | % |
| As a percentage of related revenues | 51 | % |  | 44 | % |  |  |  |  |
| Medication Adherence | 17,401 |  |  | 15,863 |  |  | 1,538 |  |  | 10 | % |
| As a percentage of related revenues | 72 | % |  | 71 | % |  |  |  |  |
| Total cost of revenues | $ | 95,229 |  |  | $ | 61,531 |  |  | $ | 33,698 |  |  | 55 | % |
| As a percentage of total revenues | 54 | % |  | 49 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 74,609 |  |  | $ | 57,299 |  |  | $ | 17,310 |  |  | 30 | % |
| Automation and Analytics gross margin | 49 | % |  | 56 | % |  |  |  |  |
| Medication Adherence | 6,899 |  |  | 6,404 |  |  | 495 |  |  | 8 | % |
| Medication Adherence gross margin | 28 | % |  | 29 | % |  |  |  |  |
| Total gross profit | $ | 81,508 |  |  | $ | 63,703 |  |  | $ | 17,805 |  |  | 28 | % |
| Total gross margin | 46 | % |  | 51 | % |  |  |  |  |

[0000926326-16-000077:mdna:86]
|  | Nine months ended September 30, 2016 |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 233,401 |  |  | $ | 123,923 |  |  | $ | 109,478 |  |  | 88 | % |
| As a percentage of related revenues | 60 | % |  | 44 | % |  |  |  |  |
| Medication Adherence | 47,777 |  |  | 47,470 |  |  | 307 |  |  | 1 | % |
| As a percentage of related revenues | 68 | % |  | 68 | % |  |  |  |  |
| Total cost of revenues | $ | 281,178 |  |  | $ | 171,393 |  |  | $ | 109,785 |  |  | 64 | % |
| As a percentage of total revenues | 54 | % |  | 48 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 216,642 |  |  | $ | 160,524 |  |  | $ | 56,118 |  |  | 35 | % |
| Automation and Analytics gross margin | 48 | % |  | 56 | % |  |  |  |  |
| Medication Adherence | 22,828 |  |  | 22,326 |  |  | 502 |  |  | 2 | % |
| Medication Adherence gross margin | 32 | % |  | 32 | % |  |  |  |  |
| Total gross profit | $ | 239,470 |  |  | $ | 182,850 |  |  | $ | 56,620 |  |  | 31 | % |
| Total gross margin | 46 | % |  | 52 | % |  |  |  |  |

[0000926326-16-000077:mdna:87]
[same as prior period, unchanged from 0000926326-16-000070:mdna:86]

[0000926326-16-000077:mdna:88]
Cost of Revenues. The cost of revenues for the three months ended September 30, 2016 compared to the three months ended September 30, 2015 increased by $32.2 million, of which $23.1 million was attributed the increase in product costs and $9.1 million was attributed to the increase in service costs. Of the $23.1 million increase in product costs, the acquired company Aesynt contributed $19.0 million. The product costs incurred by the Aesynt included the amortization expense for developed technology of $1.2 million, amortization of backlog of $3.4 million, and inventory step-up fair value adjustment of $0.9 million resulting from the purchase accounting. The remaining increase in product costs is attributed to product mix, particularly lower lease renewals. Cost of service revenues increased by $9.2 million primarily due to costs related to the acquired company Aesynt, which contributed $8.7 million to the increase in cost of service revenue.

[0000926326-16-000077:mdna:89]
[same as prior period, unchanged from 0000926326-16-000070:mdna:79]

[0000926326-16-000077:mdna:90]
The increase in cost of revenues for the nine months ended September 30, 2016 compared to the nine months ended September 30, 2015 was $109.5 million, $81.2 million of which is attributed to the increase in product costs and $28.3 million was attributed to an increase in service costs. Aesynt, Mach4 and Avantec, contributed $61.7 million to an increase in product costs.  The remaining increase in product cost is attributed to a different mixture of customers, products and overall growth in product sales, and higher product installation costs as result of higher revenue. Cost of service revenues for nine months ended September 30, 2016 increased by $28.3, $28.0 million of which was attributable due to the acquired companies Aesynt, Mach4 and Avantec.

[0000926326-16-000077:mdna:91]
Gross profit for the three and nine months ended September 30, 2016 decreased compared to the three and nine months ended September 30, 2015 as a result of product mix from higher volume of sales of lower margin products, and lower gross margins from the acquired companies Aesynt, Mach4 and Avantec, primarily due to fair value adjustments related to inventory step-up, and amortization of developed technology and backlog intangible assets.

[0000926326-16-000077:mdna:92]
[same as prior period, unchanged from 0000926326-16-000070:mdna:90]

[0000926326-16-000077:mdna:93]
Cost of Revenues. Cost of revenues increased by $1.5 million in the three months ended September 30, 2016 compared to the three months ended September 30, 2015, primarily due to the increase in product cost as result of product mix. For the nine months ended September 30, 2016 compared to the nine months ended September 30, 2015, cost of revenue increased by $0.3 million.

[0000926326-16-000077:mdna:94]
Gross profit for the three and nine months ended September 30, 2016 increased compared to the three and nine months ended September 30, 2015 primarily due to changes in our product mix, partially offset by higher manufacturing cost and higher cost of service.

[0000926326-16-000077:mdna:95]
[same as prior period, unchanged from 0000926326-16-000070:mdna:93]

[0000926326-16-000077:mdna:96]
|  | Three months ended September 30, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 15,264 |  |  | $ | 9,176 |  |  | $ | 6,088 |  |  | 66 | % |
| As a percentage of total revenues | 9 | % |  | 7 | % |  |  |  |  |
| Selling, general and administrative | 61,316 |  |  | 40,668 |  |  | 20,648 |  |  | 51 | % |
| As a percentage of total revenues | 35 | % |  | 32 | % |  |  |  |  |
| Total operating expenses | $ | 76,580 |  |  | $ | 49,844 |  |  | $ | 26,736 |  |  | 54 | % |
| As a percentage of total revenues | 43 | % |  | 40 | % |  |  |  |  |
| Income (loss) from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 25,486 |  |  | $ | 26,671 |  |  | $ | (1,185 | ) |  | (4 | )% |
| Operating margin | 17 | % |  | 26 | % |  |  |  |  |
| Medication Adherence | 762 |  |  | 334 |  |  | 428 |  |  | 128 | % |
| Operating margin | 3 | % |  | 1 | % |  |  |  |  |
| Corporate Expenses | 21,320 |  |  | 13,146 |  |  | 8,174 |  |  | 62 | % |
| Total income from operations | $ | 4,928 |  |  | $ | 13,859 |  |  | $ | (8,931 | ) |  | (64 | )% |
| Total operating margin | 3 | % |  | 11 | % |  |  |  |  |

[0000926326-16-000077:mdna:97]
Research and Development. The increase in research and development expenses of $6.1 million for the three months ended September 30, 2016 compared to three months ended September 30, 2015 was primarily driven by an increase in research and development expenses of $5.9 million in our Automation and Analytics segment and an increase of $0.1 million for Medication Adherence segment research and development expenses. The increase in our Automation and Analytics segment was attributed to the acquired company, Aesynt which accounted for $5.6 million of the increase. The remaining increase is related to higher employees related expenses.

[0000926326-16-000077:mdna:98]
Selling, General and Administrative.  The increase in selling, general and administrative expenses for the three months ended September 30, 2016 compared to the three months ended September 30, 2015 was primarily due to increases from our Automation and Analytics segment of $14.3 million and corporate expenses of $6.5 million. The increase in our Automation

[0000926326-16-000077:mdna:99]
and Analytics segment was primarily attributable to the acquired company Aesynt, which accounted for $16.1 million of the increase, partially offset by a decrease in travel and consulting expenses due to expense control initiatives in the three months ended September 30, 2016. The increase in corporate expenses was mainly related to higher share-based compensation expenses of $1.8 million, and an increase in employee-related expenses of $1.9 million due to an increase in employee headcount.

[0000926326-16-000077:mdna:100]
Operating Income Operating income from our Automation and Analytics segment decreased by $1.2 million due to higher research and development and selling, general and administrative costs of $18.5 million, partially offset by higher gross margin of $17.3 million. Operating income from our Medication Adherence segment increased by $0.4 million due to higher gross margin of approximately $0.5 million, partially offset by a $0.1 million higher selling, general and administrative expenses.

[0000926326-16-000077:mdna:101]
Corporate expense. The increase in corporate expenses for the three months ended September 30, 2016 compared to the three months ended September 30, 2015 was primarily attributable to the acquired companies which accounted for $5.9 million of the increase.

[0000926326-16-000077:mdna:102]
|  | Nine Months EndedSeptember 30, |
|  |  |  |  |  | Change in |
|  | 2016 |  | 2015 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 42,896 |  |  | $ | 25,941 |  |  | $ | 16,955 |  |  | 65 | % |
| As a percentage of total revenues | 8 | % |  | 7 | % |  |  |  |  |
| Selling, general and administrative | 189,912 |  |  | 123,690 |  |  | 66,222 |  |  | 54 | % |
| As a percentage of total revenues | 36 | % |  | 35 | % |  |  |  |  |
| Gain on business combination | — |  |  | (3,443 | ) |  | 3,443 |  |  | (100 | )% |
| As a percentage of total revenues | — | % |  | (1 | )% |  |  |  |  |
| Total operating expenses | $ | 232,808 |  |  | $ | 146,188 |  |  | $ | 86,620 |  |  | 59 | % |
| As a percentage of total revenues | 45 | % |  | 41 | % |  |  |  |  |
| Income from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 65,534 |  |  | $ | 75,329 |  |  | $ | (9,795 | ) |  | (13 | )% |
| Operating margin | 13 | % |  | 21 | % |  |  |  |  |
| Medication Adherence | 5,310 |  |  | 4,005 |  |  | 1,305 |  |  | 33 | % |
| Operating margin | 1 | % |  | 1 | % |  |  |  |  |
| Corporate Expenses | 64,182 |  |  | 42,672 |  |  | 21,510 |  |  | 50 | % |
| Total income from operations | $ | 6,662 |  |  | $ | 36,662 |  |  | $ | (30,000 | ) |  | (82 | )% |
| Total operating margin | 1 | % |  | 10 | % |  |  |  |  |

[0000926326-16-000077:mdna:103]
Research and Development. The increase in research and development expenses of $17.0 million for the nine months ended September 30, 2016 compared to nine months ended September 30, 2015 was driven by an increase in research and development expenses of $17.3 million in our Automation and Analytics segment. This increase was partially offset by a decrease in our Medication Adherence segment research and development expenses of $0.7 million primarily due to lower capitalized software related expenses. The increase in Automation and Analytics segment was attributed to the acquired companies which accounted for $14.4 million of the increase, $2.5 million of higher employee-related expenses due to higher headcount and merit increase, higher consulting expenses of $0.6 million, and $0.3 million of higher IT and facilities related expenses.

[0000926326-16-000077:mdna:104]
Selling, General and Administrative.  The increase in selling, general and administrative expenses for the nine months ended September 30, 2016 compared to the nine months ended September 30, 2015 was primarily due to increases from our Automation and Analytics segment of $46.8 million and corporate expenses of $20.0 million, partially offset by decreases in Medication Adherence segment of $0.2 million. The increase in our Automation and Analytics segment was primarily attributable to the acquired companies.

[0000926326-16-000077:mdna:105]
[same as prior period, unchanged from 0000926326-16-000070:mdna:94]

[0000926326-16-000077:mdna:106]
Operating Income. Operating income for the nine months ended September 30, 2016 from our Automation and Analytics segment decreased by $9.8 million due to higher research and development and selling, general and administrative costs of $65.9 million which includes the amortization expense related to the recently acquired intangible assets, partially offset by higher gross margin of $56.1 million.

[0000926326-16-000077:mdna:107]
Operating income from our Medication Adherence segment increased due to lower research and development and selling, general and administrative costs and higher gross profit due to product mix, partially off-set by higher manufacturing costs, and higher cost of service.

[0000926326-16-000077:mdna:108]
Corporate expense. The increase in corporate expenses for the nine months ended September 30, 2016 compared to the nine months ended September 30, 2015 was primarily attributable to the acquired companies.

[0000926326-16-000077:mdna:109]
[same as prior period, unchanged from 0000926326-16-000070:mdna:107]

[0000926326-16-000077:mdna:110]
|  | Three months ended |
|  |  |  |  |  | Change in |
|  | September 30, 2016 |  | September 30, 2015 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for income taxes | $ | 224 |  |  | $ | 5,177 |  |  | $ | (4,953 | ) |  | (96 | )% |

[0000926326-16-000077:mdna:111]
|  | Nine months ended |
|  |  |  |  |  | Change in |
|  | September 30, 2016 |  | September 30, 2015 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision (benefit) for income taxes | $ | (557 | ) |  | $ | 11,922 |  |  | $ | (12,479 | ) |  | (105 | )% |

[0000926326-16-000077:mdna:112]
Our annual effective tax rate before discrete items was 43.5% and 39.3% for the nine months ended September 30, 2016 and September 30, 2015, respectively. The increase in the estimated annual effective tax rate for the nine months ended September 30, 2016 compared to the same period in 2015 was primarily due to an increase in non-deductible equity charges and other non-deductible expenditures offset by a full year inclusion of the Federal research & development tax credit (which was permanently reinstated on December 18, 2015).

[0000926326-16-000077:mdna:113]
For the three months ended September 30, 2016, the effective tax rate was 10.1%, which was lower than the annual effective tax rate due to favorable discrete tax items in the quarter. For the nine months ended September 30, 2016 the effective tax rate was a benefit of 497.9% which was higher than the annual effective tax rate for those periods due to favorable discrete tax items on a year to date basis on a pre-tax loss.

[0000926326-16-000077:mdna:114]
For the three months ended September 30, 2015, the effective tax rate was 39.2%, which was in line with the annual effective tax rate. For the nine months ended September 30, 2015 the effective tax rate was 34.0% which was lower than the annual effective tax rate primarily due to the Company recording a gain of $3.4 million attributable to the increase in the fair value of Omnicell's 15% minority interest in Avantec which was revalued in conjunction with our purchase of the remaining 85% of Avantec shares. This gain was treated as a discrete item and excluded from profit-before-tax in calculating the annual effective tax rate for the nine months ended September 30, 2015.

[0000926326-16-000077:mdna:115]
[same as prior period, unchanged from 0000926326-16-000070:mdna:112]

[0000926326-16-000077:mdna:116]
[same as prior period, unchanged from 0000926326-16-000070:mdna:113]

[0000926326-16-000077:mdna:117]
We had cash and cash equivalents of $47.3 million at September 30, 2016, compared to $82.2 million at December 31, 2015. All of our cash and cash equivalents are invested in demand deposits and money market funds.

[0000926326-16-000077:mdna:118]
Our cash position and working capital at September 30, 2016 and December 31, 2015 were as follows:

[0000926326-16-000077:mdna:119]
[same as prior period, unchanged from 0000926326-16-000070:mdna:100]

[0000926326-16-000077:mdna:120]
|  | September 30, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Cash | $ | 37,154 |  |  | $ | 72,103 |  |
| Cash equivalents | 10,133 |  |  | 10,114 |  |
| Total | $ | 47,287 |  |  | $ | 82,217 |  |
| Working Capital | $ | 138,896 |  |  | $ | 139,498 |  |

[0000926326-16-000077:mdna:121]
Our ratio of current assets to current liabilities was 1.7:1 at September 30, 2016 compared to 2.1:1 at December 31, 2015.

[0000926326-16-000077:mdna:122]
On January 5, 2016, we entered into a $400 million secured credit facility pursuant to a credit agreement, by and among us, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as sole lead arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200 million term loan facility (the “Term Loan Facility”) and a $200 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). At the closing of the Aesynt acquisition, we borrowed $255 million in secured debt under the Credit Agreement, consisting of $200 million of term loans and $55 million of revolving loans to complete the acquisition of Aesynt and to pay related fees and expenses. In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes. The Credit Agreement replaced our existing Credit Agreement, dated as of September 25, 2013, by and among the Company, the lenders from time to time party thereto and Wells Fargo Bank, National Association, as administrative agent, as amended.

[0000926326-16-000077:mdna:123]
Loans under the Facilities bear interest, at our option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on our Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on our Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on our Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-16-000077:mdna:124]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to us and our subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us and our subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Credit Agreement also includes financial covenants requiring us not to exceed a maximum consolidated total leverage ratio of 3.00:1 (subject to certain exceptions) and to maintain a minimum fixed charge coverage ratio of 1.50:1.

[0000926326-16-000077:mdna:125]
As of September 30, 2016, the outstanding balance from the facilities was $230.0 million. We were in full compliance with all covenants.

[0000926326-16-000077:mdna:126]
[same as prior period, unchanged from 0000926326-16-000070:mdna:124]

[0000926326-16-000077:mdna:127]
[same as prior period, unchanged from 0000926326-16-000070:mdna:125]

[0000926326-16-000077:mdna:128]
On August 2, 2016, our board of directors authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company's common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by our board on November 4, 2014 (the “2014 Repurchase Program”). As of September 30, 2016, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million.

[0000926326-16-000077:mdna:129]
In accordance with the Avantec share purchase agreement, we may pay out a potential earn-out payment of $3.0 million payable after December 31, 2016, based on 2016 bookings. The fair value of this earn-out payment as of September 30, 2016 was $3.0 million. Pursuant to the terms of the agreement, we also held back $1.8 million from the purchase consideration towards any future indemnification claims that we may make by fourth quarter of 2016.

[0000926326-16-000077:mdna:130]
[same as prior period, unchanged from 0000926326-16-000070:mdna:128]

[0000926326-16-000077:mdna:131]
[same as prior period, unchanged from 0000926326-16-000070:mdna:129]

[0000926326-16-000077:mdna:132]
[same as prior period, unchanged from 0000926326-16-000070:mdna:130]

[0000926326-16-000077:mdna:133]
[same as prior period, unchanged from 0000926326-16-000070:mdna:131]

[0000926326-16-000077:mdna:134]
|  | Nine months ended |
|  | September 30, 2016 |  | September 30, 2015 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 24,470 |  |  | $ | 5,932 |  |
| Investing activities | (293,343 | ) |  | (41,312 | ) |
| Financing activities | 235,210 |  |  | (32,699 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (1,267 | ) |  | (52 | ) |
| Net decrease in cash and cash equivalents | $ | (34,930 | ) |  | $ | (68,131 | ) |

[0000926326-16-000077:mdna:135]
[same as prior period, unchanged from 0000926326-16-000070:mdna:133]

[0000926326-16-000077:mdna:136]
[same as prior period, unchanged from 0000926326-16-000070:mdna:134]

[0000926326-16-000077:mdna:137]
Net cash provided by operating activities was $24.5 million for the nine months ended September 30, 2016, primarily as a result of $0.4 million in net income adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $43.9 million, share-based compensation expense of $14.1 million and deferred income taxes of $4.8 million. The cash outflow attributed to changes in assets and liabilities includes i) an increase in accounts receivable of $25.8 million due to increased product shipments late in the quarter, ii) an increase in inventories of $7.7 million to support forecasted sales, iii) increases in long-term investment in sales-type leases of $5.3 million due to two significant lease transactions entered into during the year, iv) increases in prepaid expenses by $5.8 million mainly due to decrease in prepaid commissions and prepaid income taxes, v) a decrease in accrued liabilities of $1.9 million due to timing of payments to employees related liabilities and vi) decreased in the other-long term liabilities by $2.3 million. These amounts were partially offset by an increase in the accounts payables of $5.6 million due to timing of payments, an increase in the deferred revenue of $12.8 million due to timing of orders and revenue being recognized for installed product, and decreases in other long-term assets of $1.2 million.

[0000926326-16-000077:mdna:138]
Net cash provided by operating activities was $5.9 million for the nine months ended September 30, 2015, primarily as a result of $23.1 million in net income adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $18.5 million, share-based compensation expense, of $11.3 million and $3.4 million from our investment gain. This was offset by $42.1 million cash outflow from changes in assets and liabilities resulting primarily from i) an increase in accounts receivable of $26.1 million due to increased product shipments late in the quarter, ii) an increase in inventories of $13.2 million to support forecasted sales, iii) a decrease in deferred gross margin of $1.2 million due to timing of orders, shipments, and revenue being recognized for installed product, and iv) a decrease in accrued compensation of $5.0 million primarily due to lower sales commissions. These amounts were partially offset by a decrease in the prepaid expenses of $5.9 million primarily due to commissions driven by higher bookings in the fourth quarter of 2014 compared to the current year to date period, and an increase in accrued liabilities of $4.6 million primarily due to potential earn-out and contingent payment of $2.9 million related to the Avantec Acquisition.

[0000926326-16-000077:mdna:139]
[same as prior period, unchanged from 0000926326-16-000070:mdna:138]

[0000926326-16-000077:mdna:140]
Net cash used in investing activities was $293.3 million for the nine months ended September 30, 2016, $271.5 million of which was attributable to the acquisition of Aesynt. Capital expenditures related to purchases of property and

[0000926326-16-000077:mdna:141]
[same as prior period, unchanged from 0000926326-16-000070:mdna:120]

[0000926326-16-000077:mdna:142]
equipment, software development costs for external use and, purchases of intangibles contributed $10.0 million, $10.6 million, and $1.3 million, respectively.

[0000926326-16-000077:mdna:143]
Net cash used in investing activities was $41.3 million for the nine months ended September 30, 2015, $25 million of which was attributable to the acquisitions of Mach4 and Avantec, and capital expenditures related to purchases of property and equipment and software development of software costs for external use of $6.1 million and $9.4 million, respectively.

[0000926326-16-000077:mdna:144]
[same as prior period, unchanged from 0000926326-16-000070:mdna:141]

[0000926326-16-000077:mdna:145]
Net cash provided by financing activities was $235.2 million for the nine months ended September 30, 2016 as a result of proceeds from term loan and revolving credit facilities of $247.1 million net of deferred issuance cost of $7.9 million, $16.5 million in proceeds from employee stock option exercises and employee stock plan purchases, and $1.6 million in excess tax benefits from employee stock plans. The increase in cash provided from financing activities was partially offset by repayment of $25.0 million of the credit facilities, payment of contingent consideration of $3.0 million related to the Avantec acquisition, and $1.9 million in employees' taxes paid related to restricted stock units.

[0000926326-16-000077:mdna:146]
Net cash used by financing activities was $32.7 million for the nine months ended September 30, 2015 as a result of $50.0 million in cash used for stock repurchases under our 2012 and 2014 Stock Repurchase Programs and $2.3 million in employees taxes paid in relation to restricted stock units, partially offset by $15.7 million in proceeds from employee stock option exercises and employee stock plan purchases and $3.9 million in excess tax benefits from employee stock plans.

[0000926326-16-000077:mdna:147]
[same as prior period, unchanged from 0000926326-16-000070:mdna:144]

[0000926326-16-000077:mdna:148]
There have been no significant changes during the nine months ended September 30, 2016 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2015.

[0000926326-16-000077:mdna:149]
We had $322.6 million in contractual commitments to third parties for non-cancelable operating leases, commitments to contract manufacturers and suppliers, other purchase commitments and term loan and revolving credit facility as of September 30, 2016 as follows:

[0000926326-16-000077:mdna:150]
|  | Payments due by period |
|  | Total |  | Remainder of 2016 |  | 2017 and 2018 |  | 2019 and 2020 |  | 2021 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 51,555 |  |  | $ | 2,749 |  |  | $ | 21,134 |  |  | $ | 16,586 |  |  | $ | 11,086 |  |
| Purchase obligations (2) | 41,018 |  |  | 39,609 |  |  | 904 |  |  | 27 |  |  | 478 |  |
| Term loan facility | 195,000 |  |  | 2,500 |  |  | 27,500 |  |  | 47,500 |  |  | 117,500 |  |
| Revolving credit facility | 35,000 |  |  | — |  |  | — |  |  | — |  |  | 35,000 |  |
| Total (3) | $ | 322,573 |  |  | $ | 44,858 |  |  | $ | 49,538 |  |  | $ | 64,113 |  |  | $ | 164,064 |  |

[0000926326-16-000077:mdna:151]
[same as prior period, unchanged from 0000926326-16-000070:mdna:149]

[0000926326-16-000077:mdna:152]
[same as prior period, unchanged from 0000926326-16-000070:mdna:150]

[0000926326-16-000077:mdna:153]
[same as prior period, unchanged from 0000926326-16-000070:mdna:151]

[0000926326-16-000077:mdna:154]
| (3) | We have recorded $10.2 million for uncertain tax positions under long-term liabilities as of September 30, 2016 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, $10.2 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-16-000077:mdna:155]
[same as prior period, unchanged from 0000926326-16-000070:mdna:153]

[0000926326-16-000077:mdna:156]
[same as prior period, unchanged from 0000926326-16-000070:mdna:154]

[0000926326-16-000077:mdna:157]
As of September 30, 2016, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
