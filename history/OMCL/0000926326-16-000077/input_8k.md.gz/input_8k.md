# OMCL 8-K — 0000926326-16-000075 filed 2016-10-27

## item codes, every 8-K on or before 2016-11-07

- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2016-11-07

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-16-000075:8k_2_02:1]
EX-99.1
2
exhibit991q316.htm
EXHIBIT 99.1

[0000926326-16-000075:8k_2_02:2]
Exhibit

[0000926326-16-000075:8k_2_02:3]
Exhibit 99.1

[0000926326-16-000075:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6180 |  | Mountain View, CA 94043 |
| Peter.kuipers@omnicell.com |  |  |

[0000926326-16-000075:8k_2_02:5]
Omnicell Achieves Record Revenue in the Third Quarter 2016

[0000926326-16-000075:8k_2_02:6]
Record GAAP revenue of $176.7 million representing 41% year over year growth

[0000926326-16-000075:8k_2_02:7]
Record Non-GAAP revenue of $179.4 million representing 43% year over year growth

[0000926326-16-000075:8k_2_02:8]
MOUNTAIN VIEW, Calif. -- October 27, 2016 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its third quarter ended September 30, 2016.

[0000926326-16-000075:8k_2_02:9]
GAAP results: Revenue for the third quarter of 2016 was $176.7 million, up $3.8 million, or 2.2% from the second quarter of 2016, and up $51.5 million or 41.1% from the third quarter of 2015. Revenue for the nine months ended September 30, 2016 was $520.6 million, up $166.4 million or 47.0% from the nine months ended September 30, 2015.

[0000926326-16-000075:8k_2_02:10]
Third quarter 2016 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $2.0 million, or $0.05 per diluted share. This compares to GAAP net loss of $(1.2) million, or $(0.03) per diluted share, for the second quarter of 2016, and GAAP net income of $8.0 million, or $0.22 per diluted share, for the third quarter of 2015.

[0000926326-16-000075:8k_2_02:11]
GAAP net income for the nine months ended September 30, 2016 was $0.4 million, or $0.01 per diluted share. GAAP net income for the nine months ended September 30, 2015 was $23.1 million, or $0.63 per diluted share, which included a $3.4 million gain on business combination of an equity investment.

[0000926326-16-000075:8k_2_02:12]
Non-GAAP results: Non-GAAP revenue for the third quarter of 2016 was $179.4 million, up $3.8 million, or 2.2% from the second quarter of 2016, and up $54.2 million or 43.3% from the third quarter of 2015.

[0000926326-16-000075:8k_2_02:13]
Non-GAAP net income for the third quarter of 2016 was $14.9 million, or $0.40 per diluted share, excluding $4.7 million of stock-based compensation expense, $5.5 million, net of tax effect of $3.4 million, of intangible assets amortization expense, $0.5 million, net of tax effect of $0.3 million, of acquisition related expenses, and $0.6 million, net of tax effect of $0.3 million, of inventory fair value adjustments. Non-GAAP net income includes the effect of a deferred revenue fair value adjustment of $1.7 million, net of tax effect of $1.0 million. This compares to non-GAAP net income for the second quarter 2016 of $14.0 million, or $0.38 per diluted share, excluding $5.5 million of stock-based compensation expense, $5.6 million, net of tax effect of $3.4 million, of intangible assets amortization expense, $1.9 million, net of tax effect of $1.1 million, of acquisition related expenses and $0.6 million, net of tax effect of $0.3 million, of inventory fair value adjustments. Non-GAAP net income for the second quarter of 2016 also includes the effect of a deferred revenue fair value adjustment of $1.7 million, net of tax effect of $1.0 million. Non-GAAP net income for the third quarter of 2015 was $13.2 million, or $0.36 per diluted share, which excluded $4.0 million of stock-based compensation expense and $1.2 million, net of tax effect of $0.8 million, of amortization expense for all intangible assets associated with past acquisitions.

[0000926326-16-000075:8k_2_02:14]
Non-GAAP net income for the nine months ended September 30, 2016 was $42.0 million, or $1.14 per diluted share, excluding $14.1 million of stock-based compensation expense, $16.8 million, net of tax effect of $10.3 million, of intangible assets amortization expense, $4.0 million, net of tax effect of $2.4 million, of acquisition related expenses and $1.7 million, net of tax

[0000926326-16-000075:8k_2_02:15]
effect of 1.0 million, of inventory fair value adjustments. Non-GAAP net income includes the effect of a deferred revenue fair value adjustment of $5.0 million, net of tax effect of $3.0 million. This compares to non-GAAP net income of $34.2 million, or $0.93 per diluted share for the nine months ended September 30, 2015, which excludes $11.3 million of stock-based compensation expense and $3.3 million, net of tax effect of $1.7 million of amortization expense for intangible assets associated with past acquisitions. Non-GAAP net income for the nine months ended September 30, 2015 also excludes a $3.4 million gain on an equity investment in Avantec Healthcare Ltd.

[0000926326-16-000075:8k_2_02:16]
“Omnicell completed another strong quarter marked by record revenues and market share gains,” said Randall Lipps, Omnicell President, CEO and Chairman. “Omnicell’s continued growth is the result of successfully broadening our product portfolio, expanding the markets we participate in, and partnering with our customers to address medication management across the full continuum of patient care. The Company is well positioned to take advantage of the great opportunities ahead,” Mr. Lipps added.

[0000926326-16-000075:8k_2_02:17]
2016 Guidance

[0000926326-16-000075:8k_2_02:18]
For full year 2016, the Company re-confirms its 2016 total year guidance. The Company continues to expect product bookings to be between $540 million and $560 million. The Company is narrowing the 2016 non-GAAP revenue guidance range to be between $700 million to $710 million. The range was previously $695 million to $715 million. The Company expects 2016 non-GAAP EPS to be in the middle of the range that we previously guided to of $1.50 to $1.60 per share.

[0000926326-16-000075:8k_2_02:19]
Omnicell Conference Call Information

[0000926326-16-000075:8k_2_02:20]
Omnicell will hold a conference call today, Thursday, October 27, 2016 at 1:30 p.m. PT to discuss third quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 4139562. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on December 08, 2016. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 4139562.

[0000926326-16-000075:8k_2_02:21]
About Omnicell

[0000926326-16-000075:8k_2_02:22]
Since 1992, Omnicell (NASDAQ: OMCL) has been inspired to create safer and more efficient ways to manage medications and supplies across all care settings. As a leader in medication and supply dispensing automation, central pharmacy automation, IV robotics, analytics software, and medication adherence and packaging systems, Omnicell is focused on improving care across the entire healthcare continuum-from the acute care hospital setting, to post-acute skilled nursing and long-term care facilities, to the patient’s home.

[0000926326-16-000075:8k_2_02:23]
Over 4,000 customers worldwide use Omnicell automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence and improve patient safety. The recent acquisition of Aesynt adds distinct capabilities, particularly in central pharmacy and IV robotics, creating the broadest medication management product portfolio in the industry.

[0000926326-16-000075:8k_2_02:24]
The Omnicell SureMed solution provides innovative medication adherence packaging to help reduce costly hospital readmissions. These medication adherence solutions are used by over 17,000 institutional and retail pharmacies in North America and the United Kingdom.  These pharmacies are served via the Company’s sales channels and our solutions enable them to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-16-000075:8k_2_02:25]
For more information about Omnicell, Inc. please visit www.omnicell.com.

[0000926326-16-000075:8k_2_02:26]
Forward-Looking Statements

[0000926326-16-000075:8k_2_02:27]
uncertain nature of the forward-looking statements include our ability to take advantage of the growth opportunities in medication management across the spectrum of healthcare settings from long term care to home care, unfavorable general economic and market conditions, risks to growth and acceptance of our products and services, including competitive conversions, and to growth of the clinical automation and workflow automation market generally, the potential of increasing competition, potential regulatory changes, the ability of the company to improve sales productivity to grow product bookings, to develop new products and to acquire and successfully integrate companies, such as Aesynt. These and other risks and uncertainties are described more fully in Omnicell’s most recent filings with the Securities and Exchange Commission. Prospective investors are cautioned not to place undue reliance on forward-looking statements. All forward-looking statements contained in this press release speak only as of the date on which they were made. Omnicell undertakes no obligation to update such statements to reflect events that occur or circumstances that exist after the date on which they were made.

[0000926326-16-000075:8k_2_02:28]
Use of Non-GAAP Financial Information

[0000926326-16-000075:8k_2_02:29]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-16-000075:8k_2_02:30]
3

[0000926326-16-000075:8k_2_02:31]
Our non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-16-000075:8k_2_02:32]
a)  Stock-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-16-000075:8k_2_02:33]
b) Intangible assets amortization from business acquisitions. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-16-000075:8k_2_02:34]
c) Amortization of debt issuance cost. Debt issuance cost represents costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The cost includes underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-16-000075:8k_2_02:35]
d) Acquisition accounting impact related to deferred revenue. In connection with acquisition of Aesynt, business combination rules require us to account for the fair values of arrangements for which acceptance has not been obtained, and post installation support has not been provided in our purchase accounting. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0000926326-16-000075:8k_2_02:36]
e) Inventory fair value adjustments. In connection with acquisition of Aesynt, business combination rules require us to account for the fair values of inventory acquired in our purchase accounting. The non-GAAP adjustment to the cost of revenues is intended to include the impact of such adjustment. We believe the adjustment is useful as a measure of the ongoing performance of our business.

[0000926326-16-000075:8k_2_02:37]
f) Acquisition related expenses. We excluded from the non-GAAP results the expenses which are related to the recent acquisitions. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition related expenses provides more meaningful comparisons of the financial results to our historical operations and forward looking guidance and the financial results of less acquisitive peer companies.

[0000926326-16-000075:8k_2_02:38]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans.

[0000926326-16-000075:8k_2_02:39]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-16-000075:8k_2_02:40]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0000926326-16-000075:8k_2_02:41]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0000926326-16-000075:8k_2_02:42]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0000926326-16-000075:8k_2_02:43]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-16-000075:8k_2_02:44]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-16-000075:8k_2_02:45]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-16-000075:8k_2_02:46]
ii)  We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-16-000075:8k_2_02:47]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as excluding certain non-GAAP adjustments.

[0000926326-16-000075:8k_2_02:48]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-16-000075:8k_2_02:49]
·  Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-16-000075:8k_2_02:50]
·  Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-16-000075:8k_2_02:51]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-16-000075:8k_2_02:52]
Omnicell, Inc.

[0000926326-16-000075:8k_2_02:53]
Condensed Consolidated Statements of Operations

[0000926326-16-000075:8k_2_02:54]
(Unaudited, in thousands, except per share data)

[0000926326-16-000075:8k_2_02:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | September 30, 2016 |  | June 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product | $ | 133,621 |  |  | $ | 130,674 |  |  | $ | 100,941 |  |  | $ | 392,190 |  |  | $ | 284,204 |  |
| Services and other revenues | 43,116 |  |  | 42,233 |  |  | 24,293 |  |  | 128,458 |  |  | 70,039 |  |
| Total revenues | 176,737 |  |  | 172,907 |  |  | 125,234 |  |  | 520,648 |  |  | 354,243 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 76,188 |  |  | 76,306 |  |  | 51,700 |  |  | 224,412 |  |  | 143,319 |  |
| Cost of services and other revenues | 19,041 |  |  | 18,584 |  |  | 9,831 |  |  | 56,766 |  |  | 28,074 |  |
| Total cost of revenues | 95,229 |  |  | 94,890 |  |  | 61,531 |  |  | 281,178 |  |  | 171,393 |  |
| Gross profit | 81,508 |  |  | 78,017 |  |  | 63,703 |  |  | 239,470 |  |  | 182,850 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 15,264 |  |  | 13,794 |  |  | 9,176 |  |  | 42,896 |  |  | 25,941 |  |
| Selling, general and administrative | 61,316 |  |  | 64,341 |  |  | 40,668 |  |  | 189,912 |  |  | 123,690 |  |
| Gain on business combination | — |  |  | — |  |  | — |  |  |  |  | (3,443 | ) |
| Total operating expenses | 76,580 |  |  | 78,135 |  |  | 49,844 |  |  | 232,808 |  |  | 146,188 |  |
| Income (loss) from operations | 4,928 |  |  | (118 | ) |  | 13,859 |  |  | 6,662 |  |  | 36,662 |  |
| Interest and other income (expense), net | (2,721 | ) |  | (1,881 | ) |  | (646 | ) |  | (6,773 | ) |  | (1,635 | ) |
| Income (loss) before provision for income taxes | 2,207 |  |  | (1,999 | ) |  | 13,213 |  |  | (111 | ) |  | 35,027 |  |
| Provision (benefit) for income taxes | 224 |  |  | (840 | ) |  | 5,177 |  |  | (557 | ) |  | 11,922 |  |
| Net income (loss) | $ | 1,983 |  |  | $ | (1,159 | ) |  | $ | 8,036 |  |  | $ | 446 |  |  | $ | 23,105 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.05 |  |  | $ | (0.03 | ) |  | $ | 0.22 |  |  | $ | 0.01 |  |  | $ | 0.64 |  |
| Diluted | $ | 0.05 |  |  | $ | (0.03 | ) |  | $ | 0.22 |  |  | $ | 0.01 |  |  | $ | 0.63 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic | 36,332 |  |  | 35,987 |  |  | 35,806 |  |  | 36,020 |  |  | 35,983 |  |
| Diluted | 37,079 |  |  | 35,987 |  |  | 36,613 |  |  | 36,695 |  |  | 36,870 |  |

[0000926326-16-000075:8k_2_02:56]
6

[0000926326-16-000075:8k_2_02:57]
Omnicell, Inc.

[0000926326-16-000075:8k_2_02:58]
Condensed Consolidated Balance Sheets

[0000926326-16-000075:8k_2_02:59]
(Unaudited, in thousands)

[0000926326-16-000075:8k_2_02:60]
|  | September 30, 2016 |  | December 31, 2015 |
| ASSETS |
| Current assets: |  |  |  |  |
| Cash and cash equivalents | $ | 47,287 |  |  | $ | 82,217 |  |
| Accounts receivable, net | 177,019 |  |  | 107,957 |  |
| Inventories | 74,125 |  |  | 46,594 |  |
| Prepaid expenses | 29,620 |  |  | 19,586 |  |
| Other current assets | 9,016 |  |  | 7,774 |  |
| Total current assets | 337,067 |  |  | 264,128 |  |
| Property and equipment, net | 41,034 |  |  | 32,309 |  |
| Long-term investment in sales-type leases, net | 18,756 |  |  | 14,484 |  |
| Goodwill | 311,420 |  |  | 147,906 |  |
| Intangible assets, net | 187,571 |  |  | 89,665 |  |
| Long-term deferred tax assets | 2,955 |  |  | 2,361 |  |
| Other long-term assets | 32,612 |  |  | 27,894 |  |
| Total assets | $ | 931,415 |  |  | $ | 578,747 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |  |
| Accounts payable | $ | 36,715 |  |  | $ | 22,646 |  |
| Accrued compensation | 27,117 |  |  | 18,195 |  |
| Accrued liabilities | 32,809 |  |  | 30,133 |  |
| Long-term debt, current portion, net | 8,410 |  |  | — |  |
| Deferred revenue, net | 93,120 |  |  | 53,656 |  |
| Total current liabilities | 198,171 |  |  | 124,630 |  |
| Long-term, deferred revenue | 17,096 |  |  | 17,975 |  |
| Long-term deferred tax liabilities | 61,576 |  |  | 21,822 |  |
| Other long-term liabilities | 12,173 |  |  | 11,932 |  |
| Long-term debt, net | 214,834 |  |  | — |  |
| Total liabilities | 503,850 |  |  | 176,359 |  |
| Total stockholders’ equity | 427,565 |  |  | 402,388 |  |
| Total liabilities and stockholders’ equity | $ | 931,415 |  |  | $ | 578,747 |  |

[0000926326-16-000075:8k_2_02:61]
Omnicell, Inc.

[0000926326-16-000075:8k_2_02:62]
Condensed Consolidated Statements of Cash Flows

[0000926326-16-000075:8k_2_02:63]
(Unaudited, in thousands)

[0000926326-16-000075:8k_2_02:64]
|  | Nine months ended September 30, |
|  | 2016 |  | 2015 |
| Operating Activities |  |  |  |
| Net income | $ | 446 |  |  | $ | 23,105 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 43,905 |  |  | 18,457 |  |
| (Gain) loss on disposal of fixed assets | (9 | ) |  | 114 |  |
| Gain on business combination | — |  |  | (3,443 | ) |
| Share-based compensation expense | 14,063 |  |  | 11,267 |  |
| Income tax benefits from employee stock plans | 1,256 |  |  | 3,838 |  |
| Excess tax benefits from employee stock plans | (1,560 | ) |  | (3,942 | ) |
| Deferred income taxes | (4,767 | ) |  | (2,235 | ) |
| Amortization of debt financing fees | 1,192 |  |  | — |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | (25,802 | ) |  | (25,590 | ) |
| Inventories | (7,745 | ) |  | (12,898 | ) |
| Prepaid expenses | (5,782 | ) |  | 5,937 |  |
| Other current assets | (89 | ) |  | 1,019 |  |
| Investment in sales-type leases | (5,296 | ) |  | (3,220 | ) |
| Other long-term assets | 1,153 |  |  | 247 |  |
| Accounts payable | 5,573 |  |  | (127 | ) |
| Accrued compensation | (687 | ) |  | (5,003 | ) |
| Accrued liabilities | (1,901 | ) |  | 4,608 |  |
| Deferred revenue | 12,819 |  |  | (5,369 | ) |
| Other long-term liabilities | (2,299 | ) |  | (833 | ) |
| Net cash provided by operating activities | 24,470 |  |  | 5,932 |  |
| Investing Activities |  |  |  |
| Purchases of intangible assets, intellectual property and patents | (1,311 | ) |  | (331 | ) |
| Software development for external use | (10,569 | ) |  | (9,445 | ) |
| Purchases of property and equipment | (10,005 | ) |  | (6,081 | ) |
| Business acquisition, net of cash acquired | (271,458 | ) |  | (25,455 | ) |
| Net cash used in investing activities | (293,343 | ) |  | (41,312 | ) |
| Financing Activities |  |  |  |
| Proceeds from debt, net | 247,051 |  |  | — |  |
| Repayment of debt and revolving credit facility | (25,000 | ) |  | — |  |
| Payment for contingent consideration | (3,000 | ) |  | — |  |
| Proceeds from issuances under stock-based compensation plans | 16,516 |  |  | 15,665 |  |
| Employees' taxes paid related to restricted stock units | (1,917 | ) |  | (2,285 | ) |
| Excess tax benefits from employee stock plans | 1,560 |  |  | 3,942 |  |
| Common stock repurchases | — |  |  | (50,021 | ) |
| Net cash provided by (used in) financing activities | 235,210 |  |  | (32,699 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (1,267 | ) |  | (52 | ) |
| Net decrease in cash and cash equivalents | (34,930 | ) |  | (68,131 | ) |
| Cash and cash equivalents at beginning of period | 82,217 |  |  | 125,888 |  |
| Cash and cash equivalents at end of period | $ | 47,287 |  |  | $ | 57,757 |  |

[0000926326-16-000075:8k_2_02:65]
8

[0000926326-16-000075:8k_2_02:66]
Omnicell, Inc.

[0000926326-16-000075:8k_2_02:67]
Reconciliation of GAAP to Non-GAAP

[0000926326-16-000075:8k_2_02:68]
(Unaudited, in thousands, except per share data)

[0000926326-16-000075:8k_2_02:69]
|  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  |  | September 30, 2016 |  | June 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Reconciliation of GAAP revenue to non-GAAP revenue: |  |  |  |  |  |  |
| GAAP revenue |  | $ | 176,737 |  |  | $ | 172,907 |  |  | $ | 125,234 |  |  | $ | 520,648 |  |  | $ | 354,243 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 7,989 |  |  | — |  |
| Non-GAAP revenue | $ | 179,400 |  |  | $ | 175,570 |  |  | $ | 125,234 |  |  | $ | 528,637 |  |  | $ | 354,243 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |  |
| GAAP gross profit | $ | 81,508 |  |  | $ | 78,017 |  |  | $ | 63,703 |  |  | $ | 239,470 |  |  | $ | 182,850 |  |
| GAAP gross margin | 46.1% |  | 45.1% |  | 50.9% |  | 46.0% |  | 51.6% |
|  | Share-based compensation expense | 628 |  |  | 644 |  |  | 581 |  |  | 1,821 |  |  | 1,630 |  |
|  | Amortization of acquired intangibles | 5,199 |  |  | 5,214 |  |  | 570 |  |  | 15,624 |  |  | 1,469 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 7,989 |  |  | — |  |
|  | Inventory fair value adjustments | 920 |  |  | 920 |  |  | — |  |  | 2,761 |  |  | — |  |
|  | Acquisitions related expenses | 44 |  |  | 227 |  |  | — |  |  | 271 |  |  | — |  |
| Non-GAAP gross profit | $ | 90,962 |  |  | $ | 87,685 |  |  | $ | 64,854 |  |  | $ | 267,936 |  |  | $ | 185,949 |  |
| Non-GAAP gross margin | 50.7% |  | 49.9% |  | 51.8% |  | 50.7% |  | 52.5% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 76,580 |  |  | $ | 78,135 |  |  | $ | 49,844 |  |  | $ | 232,808 |  |  | $ | 146,188 |  |
| GAAP operating expenses % to total revenue |  | 43.3% |  | 45.2% |  | 39.8% |  | 44.7% |  | 41.3% |
|  | Share-based compensation expense | (4,049 | ) |  | (4,851 | ) |  | (3,385 | ) |  | (12,242 | ) |  | (9,637 | ) |
|  | Amortization of acquired intangibles | (3,714 | ) |  | (3,838 | ) |  | (1,408 | ) |  | (11,500 | ) |  | (3,550 | ) |
|  | Acquisitions related expenses | (342 | ) |  | (1,980 | ) |  | — |  |  | (4,924 | ) |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | — |  |  | 3,443 |  |
| Non-GAAP operating expenses | $ | 68,475 |  |  | $ | 67,466 |  |  | $ | 45,051 |  |  | $ | 204,142 |  |  | $ | 136,444 |  |
| Non-GAAP operating expenses % to total revenue | 38.2% |  | 38.4% |  | 36.0% |  | 38.6% |  | 38.5% |

[0000926326-16-000075:8k_2_02:70]
|  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  |  | September 30, 2016 |  | June 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income from operations: |  |  |  |  |
| GAAP income (loss) from operations | $ | 4,928 |  |  | $ | (118 | ) |  | $ | 13,859 |  |  | $ | 6,662 |  |  | $ | 36,662 |  |
| GAAP operating income % to total revenue |  | 2.8% |  | (0.1)% |  | 11.1% |  | 1.3% |  | 10.3% |
|  | Share-based compensation expense | 4,677 |  |  | 5,495 |  |  | 3,966 |  |  | 14,063 |  |  | 11,267 |  |
|  | Amortization of acquired intangibles | 8,913 |  |  | 9,052 |  |  | 1,978 |  |  | 27,124 |  |  | 5,019 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 7,989 |  |  | — |  |
|  | Inventory fair value adjustments | 920 |  |  | 920 |  |  | — |  |  | 2,761 |  |  | — |  |
|  | Acquisitions related expenses | 386 |  |  | 2,207 |  |  | — |  |  | 5,195 |  |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | — |  |  | (3,443 | ) |
| Non-GAAP income from operations | $ | 22,487 |  |  | $ | 20,219 |  |  | $ | 19,803 |  |  | $ | 63,794 |  |  | $ | 49,505 |  |
| Non-GAAP operating income % to total Non-GAAP revenue | 12.5% |  | 11.5% |  | 15.8% |  | 12.1% |  | 14.0% |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |  |  |  |  |  |  |
| GAAP net income (loss) | $ | 1,983 |  |  | $ | (1,159 | ) |  | $ | 8,036 |  |  | $ | 446 |  |  | $ | 23,105 |  |

[0000926326-16-000075:8k_2_02:71]
|  | Share-based compensation expense | 4,677 |  |  | 5,495 |  |  | 3,966 |  |  | 14,063 |  |  | 11,267 |  |
|  | Amortization of acquired intangibles | 8,913 |  |  | 9,052 |  |  | 1,978 |  |  | 27,124 |  |  | 5,019 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 7,989 |  |  | — |  |
|  | Inventory fair value adjustments | 920 |  |  | 920 |  |  | — |  |  | 2,761 |  |  | — |  |
|  | Acquisitions related expenses(a) | 783 |  |  | 3,002 |  |  | — |  |  | 6,387 |  |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | — |  |  | (3,443 | ) |
|  | Tax effect of the adjustments above(b) | (5,047 | ) |  | (5,942 | ) |  | (775 | ) |  | (16,820 | ) |  | (1,703 | ) |
| Non-GAAP net income | $ | 14,892 |  |  | $ | 14,031 |  |  | $ | 13,205 |  |  | $ | 41,950 |  |  | $ | 34,245 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |  |  |
| Shares - diluted GAAP | 37,079 |  |  | 35,987 |  |  | 36,613 |  |  | 36,695 |  |  | 36,870 |  |
| Shares - diluted Non-GAAP | 37,079 |  |  | 36,649 |  |  | 36,613 |  |  | 36,695 |  |  | 36,870 |  |
| GAAP net income (loss) per share - diluted | $ | 0.05 |  |  | $ | (0.03 | ) |  | $ | 0.22 |  |  | $ | 0.01 |  |  | $ | 0.63 |  |
|  | Share-based compensation expense | 0.13 |  |  | 0.15 |  |  | 0.11 |  |  | 0.38 |  |  | 0.31 |  |
|  | Amortization of acquired intangibles | 0.24 |  |  | 0.25 |  |  | 0.05 |  |  | 0.74 |  |  | 0.14 |  |
|  | Acquisition accounting impact related to deferred revenue | 0.07 |  |  | 0.07 |  |  | — |  |  | 0.22 |  |  | — |  |
|  | Inventory fair value adjustments | 0.02 |  |  | 0.03 |  |  | — |  |  | 0.08 |  |  | — |  |
|  | Acquisitions related expenses(a) | 0.02 |  |  | 0.08 |  |  | — |  |  | 0.17 |  |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | — |  |  | (0.10 | ) |
|  | Tax effect of the adjustments above(b) | (0.13 | ) |  | (0.17 | ) |  | (0.02 | ) |  | (0.46 | ) |  | (0.05 | ) |
| Non-GAAP net income per share - diluted | $ | 0.40 |  |  | $ | 0.38 |  |  | $ | 0.36 |  |  | $ | 1.14 |  |  | $ | 0.93 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP Adjusted EBITDA: |  |  |  |  |  |  |
| GAAP net income (loss) | $ | 1,983 |  |  | $ | (1,159 | ) |  | $ | 8,036 |  |  | $ | 446 |  |  | $ | 23,105 |  |
|  | Share-based compensation expense | 4,677 |  |  | 5,495 |  |  | 3,966 |  |  | 14,063 |  |  | 11,267 |  |
|  | Interest (income) and expense, net | 1,523 |  |  | 1,348 |  |  | 138 |  |  | 4,618 |  |  | 321 |  |
|  | Depreciation and amortization expense | 14,702 |  |  | 14,724 |  |  | 6,482 |  |  | 43,899 |  |  | 18,457 |  |
|  | Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 2,663 |  |  | — |  |  | 7,989 |  |  | — |  |
|  | Inventory fair value adjustments | 920 |  |  | 920 |  |  | — |  |  | 2,761 |  |  | — |  |
|  | Acquisitions related expenses(a) | 783 |  |  | 3,002 |  |  | — |  |  | 6,387 |  |  | — |  |
|  | Gain on business combination | — |  |  | — |  |  | — |  |  | — |  |  | (3,443 | ) |
|  | Income tax expense | 224 |  |  | (840 | ) |  | 5,177 |  |  | (557 | ) |  | 11,922 |  |
| Non-GAAP Adjusted EBITDA (c) | $ | 27,475 |  |  | $ | 26,153 |  |  | $ | 23,799 |  |  | $ | 79,606 |  |  | $ | 61,629 |  |

[0000926326-16-000075:8k_2_02:72]
___________________________________________

[0000926326-16-000075:8k_2_02:73]
(a)Business combination rules require us to account for the fair value of Property, Plant and Equipment (“PPE”) acquired in our purchase accounting.  In connection with the Aesynt acquisition, we recorded approximately $0.3 million of additional depreciation expense related to the fair value step-up of PPE in Q1, Q2, and Q3 2016, respectively.   As these costs represent the expense recognition of fair value adjustments in excess of the historical cost basis of PPE obtained through acquisition, these charges are outside the control of those responsible for the underlying operations of the business.  In connection with Q3’16 and year-to-date Q3’16 presentation, we revised the previously disclosed Non-GAAP measurements by $0.3 million for Q1 and Q2’2016, respectively, for the impact of depreciation expense related to the fair value step-up of PPE.

[0000926326-16-000075:8k_2_02:74]
(b)        Tax effects calculated for all adjustments except share-based compensation expense, using the estimated annual effective tax rate of 38% for fiscal year 2016.

[0000926326-16-000075:8k_2_02:75]
(c)      Defined as earnings before interest income and expense, taxes, depreciation and amortization, share-based compensation expense, as well as excluding certain non-GAAP adjustments.

[0000926326-16-000075:8k_2_02:76]
10

[0000926326-16-000075:8k_2_02:77]
Omnicell, Inc.

[0000926326-16-000075:8k_2_02:78]
Segmented Information

[0000926326-16-000075:8k_2_02:79]
(Unaudited, in thousands, except for percentages)

[0000926326-16-000075:8k_2_02:80]
|  | Three Months Ended September 30, 2016 |  | Three Months Ended September 30, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 152,437 |  |  | $ | 24,300 |  |  | $ | 176,737 |  |  | $ | 102,967 |  |  | $ | 22,267 |  |  | $ | 125,234 |  |
| Cost of revenues | 77,828 |  |  | 17,401 |  |  | 95,229 |  |  | 45,668 |  |  | 15,863 |  |  | 61,531 |  |
| Gross profit | 74,609 |  |  | 6,899 |  |  | 81,508 |  |  | 57,299 |  |  | 6,404 |  |  | 63,703 |  |
| Gross margin % | 48.9% |  | 28.4% |  | 46.1% |  | 55.6% |  | 28.8% |  | 50.9% |
| Operating expenses | 49,123 |  |  | 6,137 |  |  | 55,260 |  |  | 30,628 |  |  | 6,070 |  |  | 36,698 |  |
| Income from segment operations | $ | 25,486 |  |  | $ | 762 |  |  | $ | 26,248 |  |  | $ | 26,671 |  |  | $ | 334 |  |  | $ | 27,005 |  |
| Operating margin % | 16.7% |  | 3.1% |  | 14.9% |  | 25.9% |  | 1.5% |  | 21.6% |
| Corporate costs |  |  |  |  | 21,320 |  |  |  |  |  |  | 13,146 |  |
| Income from operations |  |  |  |  | $ | 4,928 |  |  |  |  |  |  | $ | 13,859 |  |

[0000926326-16-000075:8k_2_02:81]
Omnicell, Inc.

[0000926326-16-000075:8k_2_02:82]
Segmented Information

[0000926326-16-000075:8k_2_02:83]
(Unaudited, in thousands, except for percentages)

[0000926326-16-000075:8k_2_02:84]
|  | Nine Months Ended September 30, 2016 |  | Nine Months Ended September 30, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
| Revenues | $ | 450,043 |  |  | $ | 70,605 |  |  | $ | 520,648 |  |  | $ | 284,447 |  |  | $ | 69,796 |  |  | $ | 354,243 |  |
| Cost of revenues | 233,401 |  |  | 47,777 |  |  | 281,178 |  |  | 123,923 |  |  | 47,470 |  |  | 171,393 |  |
| Gross profit | 216,642 |  |  | 22,828 |  |  | 239,470 |  |  | 160,524 |  |  | 22,326 |  |  | 182,850 |  |
| Gross margin % | 48.1% |  | 32.3% |  | 46.0% |  | 56.4% |  | 32.0% |  | 51.6% |
| Operating expenses | 151,108 |  |  | 17,518 |  |  | 168,626 |  |  | 85,195 |  |  | 18,321 |  |  | 103,516 |  |
| Income from segment operations | $ | 65,534 |  |  | $ | 5,310 |  |  | $ | 70,844 |  |  | $ | 75,329 |  |  | $ | 4,005 |  |  | $ | 79,334 |  |
| Operating margin % | 14.6% |  | 7.5% |  | 13.6% |  | 26.5% |  | 5.7% |  | 22.4% |
| Corporate costs |  |  |  |  | 64,182 |  |  |  |  |  |  | 42,672 |  |
| Income from operations |  |  |  |  | $ | 6,662 |  |  |  |  |  |  | $ | 36,662 |  |

[0000926326-16-000075:8k_2_02:85]
12

[0000926326-16-000075:8k_2_02:86]
Omnicell, Inc.

[0000926326-16-000075:8k_2_02:87]
Segment Information - Non-GAAP Gross Margin and Non-GAAP Operating Margin

[0000926326-16-000075:8k_2_02:88]
(Unaudited, in thousands, except for percentages)

[0000926326-16-000075:8k_2_02:89]
|  | Three Months Ended September 30, 2016 |  |  |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 152,437 |  |  |  |  |  |  | $ | 24,300 |  |  |  |  |  |  | $ | 176,737 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.7% |  | 1.7% |  | — |  | —% |  | —% |  | 2,663 |  |  | 1.5% |  | 1.5% |
| Non-GAAP Revenues | $ | 155,100 |  |  |  |  |  |  | $ | 24,300 |  |  |  |  |  |  | $ | 179,400 |  |  |  |  |  |
| GAAP Gross profit | $ | 74,609 |  |  | 48.9% |  |  |  | $ | 6,899 |  |  | 28.4% |  |  |  | $ | 81,508 |  |  | 46.1% |  | 45.4% |
| Stock-based compensation expense | 511 |  |  | 0.3% |  | 0.3% |  | 117 |  |  | 0.5% |  | 0.5% |  | 628 |  |  | 0.4% |  | 0.4% |
| Amortization expense of acquired intangible assets | 4,867 |  |  | 3.2% |  | 3.1% |  | 332 |  |  | 1.4% |  | 1.4% |  | 5,199 |  |  | 2.9% |  | 2.9% |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.7% |  | 1.7% |  | — |  |  | —% |  | —% |  | 2,663 |  |  | 1.5% |  | 1.5% |
| Inventory fair value adjustments | 920 |  |  | 0.6% |  | 0.6% |  | — |  |  | —% |  | —% |  | 920 |  |  | 0.5% |  | 0.5% |
| Acquisitions related expenses | 44 |  |  | —% |  | —% |  | — |  |  | —% |  | —% |  | 44 |  |  | —% |  | —% |
| Non-GAAP Gross profit | $ | 83,614 |  |  |  |  | 53.9% |  | $ | 7,348 |  |  |  |  | 30.2% |  | $ | 90,962 |  |  |  |  | 50.7% |
| GAAP Operating income | $ | 25,486 |  |  | 16.7% |  |  |  | $ | 762 |  |  | 3.1% |  |  |  | $ | 26,248 |  |  | 14.9% |  |  |
| Stock-based compensation expense | 1,952 |  |  | 1.3% |  | 1.3% |  | 264 |  |  | 1.1% |  | 1.1% |  | 2,216 |  |  | 1.3% |  | 1.2% |
| Amortization expense of acquired intangible assets | 7,623 |  |  | 5.0% |  | 4.9% |  | 1,290 |  |  | 5.3% |  | 5.3% |  | 8,913 |  |  | 5.0% |  | 5.0% |
| Acquisition accounting impact related to deferred revenue | 2,663 |  |  | 1.7% |  | 1.7% |  | — |  |  | —% |  | —% |  | 2,663 |  |  | 1.5% |  | 1.5% |
| Inventory fair value adjustments | 920 |  |  | 0.6% |  | 0.6% |  | — |  |  | —% |  | —% |  | 920 |  |  | 0.5% |  | 0.5% |
| Acquisitions related expenses | 133 |  |  | 0.1% |  | 0.1% |  |  |  |  | —% |  | —% |  | 133 |  |  | 0.1% |  | 0.1% |
| Non-GAAP Operating income | $ | 38,777 |  |  |  |  | 25.0 | % |  | $ | 2,316 |  |  |  |  | 9.5 | % |  | $ | 41,093 |  |  |  |  | 22.9 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 21,320 |  |  | 12.1% |  |  |
| Stock-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | 2,461 |  |  | 1.4% |  | 1.4% |
| Acquisition-related expenses |  |  |  |  |  |  |  |  |  |  |  |  | 253 |  |  | 0.1% |  | 0.1% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 18,606 |  |  |  |  | 10.4% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 22,487 |  |  |  |  | 12.5 | % |

[0000926326-16-000075:8k_2_02:90]
Omnicell, Inc.

[0000926326-16-000075:8k_2_02:91]
Segment Information - Non-GAAP Gross Margin and Non-GAAP Operating Margin

[0000926326-16-000075:8k_2_02:92]
(Unaudited, in thousands, except for percentages)

[0000926326-16-000075:8k_2_02:93]
|  | Three Months Ended September 30, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue* |  | Amount |  | % of GAAP Revenue* |  | Amount |  | % of GAAP Revenue* |
| Revenues | $ | 102,967 |  |  |  |  | $ | 22,267 |  |  |  |  | $ | 125,234 |  |  |  |
| GAAP Gross profit | $ | 57,299 |  |  | 55.6% |  | $ | 6,404 |  |  | 28.8% |  | $ | 63,703 |  |  | 50.9% |
| Stock-based compensation expense | 403 |  |  | 0.4% |  | 178 |  |  | 0.8% |  | 581 |  |  | 0.5% |
| Amortization expense of acquired intangibleassets | 238 |  |  | 0.2% |  | 332 |  |  | 1.5% |  | 570 |  |  | 0.5% |
| Non-GAAP Gross profit | $ | 57,940 |  |  | 56.3% |  | $ | 6,914 |  |  | 31.1% |  | $ | 64,854 |  |  | 51.8% |
| GAAP Operating income | $ | 26,671 |  |  | 25.9% |  | $ | 334 |  |  | 1.5% |  | $ | 27,005 |  |  | 21.6% |
| Stock-based compensation expense | 1,572 |  |  | 1.5% |  | 303 |  |  | 1.4% |  | 1,875 |  |  | 1.5% |
| Amortization expense of acquired intangibleassets | 902 |  |  | 0.9% |  | 1,076 |  |  | 4.8% |  | 1,978 |  |  | 1.6% |
| Non-GAAP Operating income | $ | 29,145 |  |  | 28.3% |  | $ | 1,713 |  |  | 7.7% |  | $ | 30,858 |  |  | 24.6% |
| GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 13,146 |  |  | 10.5% |
| Stock-based compensation expense |  |  |  |  |  |  |  |  | 2,091 |  |  | 1.7% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  | $ | 11,055 |  |  | 8.8% |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  | $ | 19,803 |  |  | 15.8% |

[0000926326-16-000075:8k_2_02:94]
_____________________________________________

[0000926326-16-000075:8k_2_02:95]
* For the three months ended September 30, 2015, there were no differences between GAAP and non-GAAP revenues.

[0000926326-16-000075:8k_2_02:96]
14
