# OMCL notes — 0000926326-16-000077


## omcl:ScheduleofLongTermNetInvestmentinSaleTypeLeasesTableTextBlock

[0000926326-16-000077:notes:1]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at September 30, 2016 and December 31, 2015:

[0000926326-16-000077:notes:2]
|  | September 30, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Minimum lease payments to be received, net | $ | 29,030 |  |  | $ | 22,255 |  |
| Less: Unearned interest income portion | (2,443 | ) |  | (1,014 | ) |
| Investment in sales-type leases, net | 26,587 |  |  | 21,241 |  |
| Less: Short-term investment in sales-type leases, net(1) | (7,831 | ) |  | (6,757 | ) |
| Long-term investment in sales-type leases, net | $ | 18,756 |  |  | $ | 14,484 |  |

[0000926326-16-000077:notes:3]
[same as prior period, unchanged from 0000926326-16-000070:notes:3]


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-16-000077:notes:4]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of September 30, 2016:

[0000926326-16-000077:notes:5]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 2,743 |  |
| Non-vested restricted share awards | 668 |  |
| Shares authorized for future issuance | 2,831 |  |
| ESPP shares available for future issuance | 2,831 |  |
| Total shares reserved for future issuance | 9,073 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-16-000077:notes:6]
[same as prior period, unchanged from 0000926326-16-000070:notes:6]

[0000926326-16-000077:notes:7]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2016 and December 31, 2015, the results of its operations, comprehensive income (loss) and cash flows for the three and nine months ended September 30, 2016 and September 30, 2015. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2015 filed with the SEC on February 26, 2016. The Company's results of operations, comprehensive income (loss) and cash flows for the three and nine months ended September 30, 2016 are not necessarily indicative of results that may be expected for the year ending December 31, 2016, or for any future period.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000926326-16-000077:notes:8]
The following table presents certain unaudited pro forma information for illustrative purposes only, for the nine months ended September 30, 2016 and 2015 as if Aesynt had been acquired on January 1, 2015. The pro forma information is not indicative of what would have occurred had the acquisitions taken place on January 1, 2015. The unaudited pro forma information combines the historical results of the acquisitions with the Company's consolidated historical results and includes certain adjustments reflecting the estimated impact of fair value adjustments for the respective periods. The pro forma adjustments include the impact of fair value adjustment related to deferred revenue, inventory fair value adjustment, amortization of intangible assets, stock-based compensation expense, interest expense and amortization of deferred issuance cost, and certain classification to conform to Omnicell's accounting policies.

[0000926326-16-000077:notes:9]
|  | Nine months ended September 30, |
|  | 2016 |  | 2015 |
|  | (In thousands, except per share data) |
| Pro forma net revenues | $ | 520,648 |  | $ | 492,753 |  |
| Pro forma net income | $ | 446 |  | $ | 2,485 |  |
| Pro forma net income per share basic | $ | 0.01 |  | $ | 0.07 |  |
| Pro forma net income per share diluted | $ | 0.01 |  | $ | 0.07 |  |


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-16-000077:notes:10]
[same as prior period, unchanged from 0000926326-16-000070:notes:10]

[0000926326-16-000077:notes:11]
On a recurring basis, we enter into sales-type lease transactions which vary in length from one to five years. The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at September 30, 2016 and December 31, 2015:

[0000926326-16-000077:notes:12]
The Company evaluates its sales-type leases individually and collectively for impairment.  The allowance for credit losses were $0.3 million and $0.2 million as of September 30, 2016 and of December 31, 2015, respectively.

[0000926326-16-000077:notes:13]
At September 30, 2016, the future minimum lease payments under sales-type leases are as follows:

[0000926326-16-000077:notes:14]
|  | September 30, 2016 |
|  | (In thousands) |
| Remaining three months of 2016 | $ | 2,478 |  |
| 2017 | 8,350 |  |
| 2018 | 6,877 |  |
| 2019 | 5,214 |  |
| 2020 | 3,277 |  |
| Thereafter | 2,834 |  |
| Total | $ | 29,030 |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-16-000077:notes:15]
Commitments and Contingencies

[0000926326-16-000077:notes:16]
Lease commitments

[0000926326-16-000077:notes:17]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment.  At September 30, 2016, the minimum future payments on non-cancelable operating leases were as follows:

[0000926326-16-000077:notes:18]
|  | (In thousands) |
| Remaining three months of 2016 | $ | 2,749 |  |
| 2017 | 10,755 |  |
| 2018 | 10,379 |  |
| 2019 | 10,127 |  |
| 2020 | 6,459 |  |
| Thereafter | 11,086 |  |
| Total minimum future lease payments | $ | 51,555 |  |

[0000926326-16-000077:notes:19]
Purchase obligations

[0000926326-16-000077:notes:20]
During the course of the business, the Company issues purchase orders based on its current manufacturing needs.  At September 30, 2016, the Company had non-cancelable purchase commitments of $41.0 million, which are expected to be paid within the next twelve months.

[0000926326-16-000077:notes:21]
Legal Proceedings

[0000926326-16-000077:notes:22]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in any current matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-16-000077:notes:23]
The Company’s legal proceeding as of September 30, 2016 was as follows:

[0000926326-16-000077:notes:24]
On September 12, 2014, MV Circuit Design, Inc., an Ohio company ("MV Circuit"), brought an action to correct the inventorship of certain patents owned by the Company, as well as related state-law claims against the Company in the Northern District of Ohio (Case No. 1:14-cv-02028-DAP) regarding allegations of fraud in the filing and prosecution of U.S. Patent Nos. 8,180,485, 8,773,270, 8,812,153, PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505 (the “Action”). On November 14, 2014, the Company filed a Motion to Dismiss the Action.  On March 24, 2015, the Court issued an Order granting in part and denying in part the Motion to Dismiss. Specifically, the Court granted the Company's Motion to Dismiss with respect to Counts 4, 5, and 6 (declaratory judgments regarding PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505) and count 13 (civil conspiracy). Following an initial Case Management Conference on April 22, 2015, the Court ordered the parties to conduct limited discovery and actively discuss settlement options. On May 17, 2016 the parties reached a settlement agreement in which MV Circuit would dismiss the remaining claims and Omnicell would assign certain patents related to mobile medical cart to MV Circuit.  Omnicell has retained or secured all rights to continue to develop, manufacture, produce, market, license and sell all of its mobile cart product lines, including our SavvyTM mobile medication workstation. On June 1, 2016, the Court dismissed the case with prejudice.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-16-000077:notes:25]
[same as prior period, unchanged from 0000926326-16-000070:notes:25]

[0000926326-16-000077:notes:26]
[same as prior period, unchanged from 0000926326-16-000070:notes:26]


## us-gaap:DebtDisclosureTextBlock

[0000926326-16-000077:notes:27]
Debt

[0000926326-16-000077:notes:28]
On January 5, 2016, the Company entered into a $400 million senior secured credit facility pursuant to a credit agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200 million (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-16-000077:notes:29]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the 2016 Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-16-000077:notes:30]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-16-000077:notes:31]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio.  The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.  The Company was in full compliance with all covenants as of September 30, 2016.

[0000926326-16-000077:notes:32]
On January 5, 2016, the Company borrowed the full $200 million under the Term Loan Facility and $55 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses. In connection with these Facilities, the Company incurred $7.9 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021.

[0000926326-16-000077:notes:33]
The components of the Company’s debt obligations as of September 30, 2016 and December 31, 2015 are as follows:

[0000926326-16-000077:notes:34]
|  | December 31, 2015 | Borrowings | Repayment/Amortization | September 30, 2016 |
|  | (In thousands) |
| Term loan facility | $ | — |  | $ | 200,000 |  | $ | (5,000 | ) | $ | 195,000 |  |
| Revolving credit facility | — |  | 55,000 |  | (20,000 | ) | 35,000 |  |
| Total debt under the facilities(1) | — |  | 255,000 |  | (25,000 | ) | 230,000 |  |
| Less: Deferred issuance cost | — |  | (7,949 | ) | 1,193 |  | (6,756 | ) |
| Total Debt, net of deferred issuance cost | $ | — |  | $ | 247,051 |  | $ | (23,807 | ) | 223,244 |  |
| Long term debt, current portion, net of deferred issuance cost |  |  |  | 8,410 |  |
| Long term debt, net of deferred issuance cost |  |  |  | $ | 214,834 |  |

[0000926326-16-000077:notes:35]
(1) The fair value of total debt under the facilities approximates the book value as of September 30, 2016.


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-16-000077:notes:36]
[same as prior period, unchanged from 0000926326-16-000070:notes:36]

[0000926326-16-000077:notes:37]
Short-term deferred revenue includes deferred revenue from product sales and service contracts, net of deferred cost of sales of $17.9 million and $15.7 million as of September 30, 2016 and December 31, 2015, respectively. The short-term deferred revenues from product sales relate to the delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

[0000926326-16-000077:notes:38]
Long-term deferred revenue includes deferred revenue from the service contracts of $17.1 million and $18.0 million, as of September 30, 2016 and December 31, 2015, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0000926326-16-000077:notes:39]
Interest rate swap agreements

[0000926326-16-000077:notes:40]
During the second quarter of 2016, the Company entered into interest rate swap agreements. The interest rate swap agreements, at their inception, qualified for and were designated as cash flow hedging instruments. In accordance with the Derivatives and Hedging Topic of the Accounting Standards Codification ("ASC"), the Company records its interest rate swaps on its condensed consolidated balance sheet at fair value. The effective portion of changes in fair value are recorded in accumulated other comprehensive loss and are subsequently reclassified into earnings in the period that the hedged forecasted transaction affects earnings. Any ineffective portion is recognized in earnings. Both at inception and on a quarterly basis, the Company performs an effectiveness test.


## us-gaap:EarningsPerShareTextBlock

[0000926326-16-000077:notes:41]
Net Income Per Share

[0000926326-16-000077:notes:42]
Basic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. Diluted net income per share is computed by dividing net income for the period by the weighted-average number of shares, less shares repurchased, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. The anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net loss per share because their effect would have been anti-dilutive.

[0000926326-16-000077:notes:43]
The calculation of basic and diluted net income  per share is as follows:

[0000926326-16-000077:notes:44]
|  | Three months ended September 30, |  | Nine months ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (In thousands, except per share data) |
| Net income | $ | 1,983 |  |  | $ | 8,036 |  |  | $ | 446 |  |  | $ | 23,105 |  |
| Weighted-average shares outstanding — basic | 36,332 |  |  | 35,806 |  |  | 36,020 |  |  | 35,983 |  |
| Effect of dilutive securities from stock award plans | 747 |  |  | 807 |  |  | 675 |  |  | 887 |  |
| Weighted-average shares outstanding — diluted | $ | 37,079 |  |  | $ | 36,613 |  |  | $ | 36,695 |  |  | $ | 36,870 |  |
| Net income per share — basic | $ | 0.05 |  |  | $ | 0.22 |  |  | $ | 0.01 |  |  | $ | 0.64 |  |
| Net income per share — diluted | $ | 0.05 |  |  | $ | 0.22 |  |  | $ | 0.01 |  |  | $ | 0.63 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 326 |  |  | 478 |  |  | 1,255 |  |  | 380 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-16-000077:notes:45]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of September 30, 2016:

[0000926326-16-000077:notes:46]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Money market fund | $ | 10,133 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,133 |  |
| Interest rate swap contracts | — |  |  | 108 |  |  | — |  |  | 108 |  |
| Total financial assets | $ | 10,133 |  |  | $ | 108 |  |  | $ | — |  |  | $ | 10,241 |  |
| Contingent consideration liability(1) | $ | — |  |  | $ | — |  |  | $ | 2,959 |  |  | $ | 2,959 |  |
| Total financial liabilities | $ | — |  |  | $ | — |  |  | $ | 2,959 |  |  | $ | 2,959 |  |

[0000926326-16-000077:notes:47]
[same as prior period, unchanged from 0000926326-16-000070:notes:45]

[0000926326-16-000077:notes:48]
[same as prior period, unchanged from 0000926326-16-000070:notes:46]

[0000926326-16-000077:notes:49]
[same as prior period, unchanged from 0000926326-16-000070:notes:47]

[0000926326-16-000077:notes:50]
[same as prior period, unchanged from 0000926326-16-000070:notes:48]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000926326-16-000077:notes:51]
The cash and cash equivalents at September 30, 2016 and December 31, 2015 were as follows:

[0000926326-16-000077:notes:52]
|  | September 30, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Cash | $ | 37,154 |  |  | $ | 72,103 |  |
| Money market fund | 10,133 |  |  | 10,114 |  |
| Total cash and cash equivalents | $ | 47,287 |  |  | $ | 82,217 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-16-000077:notes:53]
[same as prior period, unchanged from 0000926326-16-000070:notes:51]

[0000926326-16-000077:notes:54]
Cash and cash equivalents as of September 30, 2016 and December 31, 2015 include cash and money market funds, which have original maturities of three months or less.  Due to the short duration to maturity, the carrying value of such financial instruments approximates the estimated fair value.

[0000926326-16-000077:notes:55]
[same as prior period, unchanged from 0000926326-16-000070:notes:53]

[0000926326-16-000077:notes:56]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's foreign currency contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments. The Company's contingent consideration liability is classified as Level 3 as valuation inputs are unobservable in the market and significant to the instrument’s valuation. During the nine months ended September 30, 2016, the Company paid $3.0 million for contingent consideration and recorded $0.1 million for accrued interest.

[0000926326-16-000077:notes:57]
[same as prior period, unchanged from 0000926326-16-000070:notes:55]

[0000926326-16-000077:notes:58]
Interest Rate Swap Contracts

[0000926326-16-000077:notes:59]
[same as prior period, unchanged from 0000926326-16-000070:notes:60]

[0000926326-16-000077:notes:60]
During 2016, the Company entered into an interest rate swap agreement with a combined notional amount of $100.0 million with one counter-party that is effective beginning on June 30, 2016 and maturing on April 30, 2019. The swap agreement requires the Company to pay a fixed rate of 0.8% and provides that the Company will receive a variable rate based on the one month LIBOR rate subject to LIBOR floor of 0.0%. Amounts payable by or due to the Company will be net settled with the respective counter-party on the last business day of each month, commencing July 31, 2016.

[0000926326-16-000077:notes:61]
The fair value of the interest rate swap agreements at September 30, 2016 were $0.1 million and there were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-16-000077:notes:62]
[same as prior period, unchanged from 0000926326-16-000070:notes:63]

[0000926326-16-000077:notes:63]
[same as prior period, unchanged from 0000926326-16-000070:notes:64]

[0000926326-16-000077:notes:64]
[same as prior period, unchanged from 0000926326-16-000070:notes:65]

[0000926326-16-000077:notes:65]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2015 | $ | 54,316 |  |  | $ | 93,590 |  |  | $ | 147,906 |  |
| Goodwill acquired | 166,334 |  |  | — |  |  | 166,334 |  |
| Foreign currency exchange rate fluctuations | (1,496 | ) |  | (1,324 | ) |  | (2,820 | ) |
| Net balance as of September 30, 2016 | $ | 219,154 |  |  | $ | 92,266 |  |  | $ | 311,420 |  |

[0000926326-16-000077:notes:66]
[same as prior period, unchanged from 0000926326-16-000070:notes:67]

[0000926326-16-000077:notes:67]
The carrying amounts of intangibles assets as of September 30, 2016 and December 31, 2015 are as follows:

[0000926326-16-000077:notes:68]
|  | September 30, 2016 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 124,636 |  |  | $ | (17,833 | ) |  | $ | (140 | ) |  | $ | 106,663 |  |  | 1 - 30 |
| Acquired technology | 70,150 |  |  | (11,405 | ) |  | 33 |  |  | 58,778 |  |  | 3 - 20 |
| Backlog | 20,559 |  |  | (10,605 | ) |  | (1 | ) |  | 9,953 |  |  | 1 - 3 |
| Trade names | 8,558 |  |  | (3,478 | ) |  | 7 |  |  | 5,087 |  |  | 1 - 12 |
| Patents | 2,279 |  |  | (439 | ) |  | — |  |  | 1,840 |  |  | 2 - 20 |
| Non-compete agreements | 1,800 |  |  | (450 | ) |  | — |  |  | 1,350 |  |  | 3 |
| In-process Technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  |  |
| Total intangibles assets, net | $ | 231,882 |  |  | $ | (44,210 | ) |  | $ | (101 | ) |  | $ | 187,571 |  |  |  |

[0000926326-16-000077:notes:69]
[same as prior period, unchanged from 0000926326-16-000070:notes:70]

[0000926326-16-000077:notes:70]
Amortization expense of intangible assets was $8.9 million and $2.0 million for the three months ended September 30, 2016 and September 30, 2015, respectively. Amortization expense of intangible assets was $27.2 million and $5.1 million for the nine months ended September 30, 2016 and September 30, 2015, respectively.

[0000926326-16-000077:notes:71]
[same as prior period, unchanged from 0000926326-16-000070:notes:72]

[0000926326-16-000077:notes:72]
|  | September 30, 2016 |
|  | (In thousands) |
| Remaining three months of 2016 | $ | 8,869 |  |
| 2017 | 22,756 |  |
| 2018 | 21,164 |  |
| 2019 | 16,093 |  |
| 2020 | 15,095 |  |
| Thereafter | 103,594 |  |
| Total | $ | 187,571 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-16-000077:notes:73]
[same as prior period, unchanged from 0000926326-16-000070:notes:74]

[0000926326-16-000077:notes:74]
The Company provides for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 43.5% and 39.3% for the nine months ended September 30, 2016 and 2015, respectively. The 2016 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction and the Federal Research & Development credit, which was permanently reinstated on December 18, 2015. The 2015 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.

[0000926326-16-000077:notes:75]
For the nine months ended September 30, 2015, the Company had recorded a gain of $3.4 million attributable to the increase in the fair value of Omnicell's 15% minority interest in Avantec which was revalued in conjunction with our purchase of the remaining 85% of Avantec shares. This gain was treated as a discrete item and excluded from profit-before-tax in calculating the annual effective tax rate for the nine months ended September 30, 2015.

[0000926326-16-000077:notes:76]
As of September 30, 2016 and December 31, 2015, the Company had gross unrecognized tax benefits of $10.2 million and $7.2 million, respectively. The increase is largely due to unrecognized tax benefits recorded as part of the acquisition of Aesynt. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in operating expense. As of September 30, 2016 and December 31, 2015, the amount of accrued interest and penalties was $1.3 million and $0.2 million, respectively. The increase is attributable to the interest related to Aesynt's reserves.

[0000926326-16-000077:notes:77]
As of September 30, 2016, calendar years 2011 and thereafter are open and subject to potential examination in one or more jurisdictions.  However, because all of the net operating loss and research credit carryforwards that may be used in future years are subject to adjustment, if and when utilized, the Company's federal and California tax years remain open from 1996 and 1992, respectively. The Company is currently under examination by the Internal Revenue Service for the 2011 through 2014 tax years.

[0000926326-16-000077:notes:78]
[same as prior period, unchanged from 0000926326-16-000070:notes:79]


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000926326-16-000077:notes:79]
[same as prior period, unchanged from 0000926326-16-000070:notes:80]

[0000926326-16-000077:notes:80]
|  | September 30, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| United States | $ | 36,017 |  |  | $ | 29,506 |  |
| Rest of world (1) | 5,017 |  |  | 2,803 |  |
| Total property and equipment, net | $ | 41,034 |  |  | $ | 32,309 |  |

[0000926326-16-000077:notes:81]
[same as prior period, unchanged from 0000926326-16-000070:notes:82]

[0000926326-16-000077:notes:82]
[same as prior period, unchanged from 0000926326-16-000070:notes:83]


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000926326-16-000077:notes:83]
[same as prior period, unchanged from 0000926326-16-000070:notes:84]

[0000926326-16-000077:notes:84]
[same as prior period, unchanged from 0000926326-16-000070:notes:85]

[0000926326-16-000077:notes:85]
[same as prior period, unchanged from 0000926326-16-000070:notes:86]

[0000926326-16-000077:notes:86]
[same as prior period, unchanged from 0000926326-16-000070:notes:87]

[0000926326-16-000077:notes:87]
|  | (In thousands) |
| Cash | $ | 8,164 |  |
| Accounts receivable | 44,084 |  |
| Inventory | 19,690 |  |
| Other current assets | 4,381 |  |
| Total current assets | 76,319 |  |
| Property and equipment | 10,389 |  |
| Intangible assets | 123,700 |  |
| Goodwill | 166,334 |  |
| Other non-current assets | 968 |  |
| Total assets | 377,710 |  |
| Current liabilities | 26,132 |  |
| Deferred revenue, net | 25,598 |  |
| Non-current deferred tax liabilities | 43,927 |  |
| Other non-current liabilities | 2,431 |  |
| Total liabilities | 98,088 |  |
| Total purchase price | 279,622 |  |
| Total purchase price, net of cash received | $ | 271,458 |  |

[0000926326-16-000077:notes:88]
The goodwill arising from this acquisition is primarily attributed to sales of future products and services and the assembled workforce of Aesynt. The Aesynt acquisition created one of the broadest product portfolio in the industry with significant offerings in automated dispensing systems, central pharmacy robotics, I.V. robotics and enterprise analytics. Goodwill has been assigned to the Automation & Analytics segment and is not deductible for tax purposes. Goodwill is not being amortized but is reviewed annually for impairment or more frequently if impairment indicators arise, in accordance with authoritative guidance.  Since the acquisition, the Company adjusted the preliminary value assigned to goodwill by $1.5 million to reflect measurement period adjustments related to account receivable, inventory and current liabilities of $0.8 million, $0.4 million and $0.3 million respectively.

[0000926326-16-000077:notes:89]
[same as prior period, unchanged from 0000926326-16-000070:notes:90]

[0000926326-16-000077:notes:90]
[same as prior period, unchanged from 0000926326-16-000070:notes:91]

[0000926326-16-000077:notes:91]
[same as prior period, unchanged from 0000926326-16-000070:notes:92]

[0000926326-16-000077:notes:92]
[same as prior period, unchanged from 0000926326-16-000070:notes:93]

[0000926326-16-000077:notes:93]
The fair value of trade names, acquired developed technology, and acquired IPR&D was determined based on an income approach using the relief-from-royalty method at the royalty rates of 0.5%, 4% to 8% and 12.5%, respectively. The fair value of customer relationships, backlog, and non-compete intangible assets were determined based on an income approach using the discounted cash flow method, at the discounted rates of 13%, 10% and 13%, respectively. The intangible assets, except customer relationship and IPR&D, are being amortized over their estimated useful lives using the straight line method of amortization. The customer relationship intangible asset is being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. In accordance with authoritative guidance, the IPR&D is accounted for as an indefinite-lived intangible asset until completion or abandonment of the associated research and development efforts. IPR&D is tested for impairment during the period it is considered an indefinite lived asset. IPR&D related projects are expected to be completed in two to three years. As of September 30, 2016, none of the IPR&D projects have been completed, and they have progressed as previously estimated.

[0000926326-16-000077:notes:94]
The Company incurred approximately $9.3 million in acquisition-related costs related to the Aesynt acquisition of which $2.9 million and $6.4 million was recognized in three and nine months ended December 31, 2015 and September 30, 2016, respectively. These costs are included in selling, general and administrative expenses in the Company's Condensed Consolidated Statement of Operations.

[0000926326-16-000077:notes:95]
Revenues and losses from operations since the acquisition date through September 30, 2016 for Aesynt were $119.9 million and $(30.6) million, respectively. Losses from operations includes the amortization of intangible assets of $20.9 million for the period presented.

[0000926326-16-000077:notes:96]
[same as prior period, unchanged from 0000926326-16-000070:notes:97]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-16-000077:notes:97]
Recently adopted authoritative guidance

[0000926326-16-000077:notes:98]
In April 2015, the Financial Accounting Standards Board ("FASB") issued ASU 2015-05-Intangibles-Goodwill and Other-Internal-Use Software- Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The Company adopted ASU 2015-05 on a prospective basis beginning on January 1, 2016. The impact of ASU 2015-05 did not have a material impact on the Company's consolidated financial position or results of operations for the three and nine months ended September 30, 2016.

[0000926326-16-000077:notes:99]
In July 2015, the FASB issued ASU No. 2015-11, Simplifying the Measurement of Inventory. This ASU changes the measurement principle for inventory from the lower of cost or market to lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. It applies to entities that measure inventory using a method other than last-in, first-out (LIFO) and the retail inventory method (RIM). The guidance is effective for fiscal years beginning after December 15, 2016. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three and nine months ended September 30, 2016.

[0000926326-16-000077:notes:100]
In September 2015, the FASB issued ASU No. 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments. This ASU requires adjustments to provisional amounts that are identified during the measurement period of a business combination to be recognized in the reporting period in which the adjustment amounts are determined. An acquirer is no longer required to revise comparative information for prior periods as if the accounting for the business combination had been completed as of the acquisition date. The provisions of ASU 2015-16 are effective for reporting periods beginning after December 15, 2015. The adoption of this accounting standard update did not have a material impact on the Company's consolidated financial position or results of operations for the three and nine months ended September 30, 2016.

[0000926326-16-000077:notes:101]
Recently issued authoritative guidance

[0000926326-16-000077:notes:102]
In March 2016, the FASB issued ASU No. 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 are effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted for any entity in any interim or annual period. If an entity early adopts the amendments in an interim period, any adjustments are reflected as of the beginning of the fiscal year that includes that interim period. An entity that elects early adoption must adopt all of the amendments in the same period. The Company is currently in the process of evaluating the impact of the adoption of ASU 2016-09 on its consolidated financial statements.

[0000926326-16-000077:notes:103]
In August 2016, the FASB issued ASU No. 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments. This ASU requires changes in the presentation of certain items including but not limited to debt prepayment or debt extinguishment costs; contingent consideration payments made after a business combination; proceeds from the settlement of insurance claims; proceeds from the settlement of corporate-owned life insurance policies and distributions received from equity method investees. The new guidance will be effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years and should be applied prospectively. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company is currently evaluating the impact ASU 2016-15 will have on its consolidated financial statements.

[0000926326-16-000077:notes:104]
In October 2016, the FASB issued ASU No. 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which reduces the complexity in the accounting standards by allowing the recognition of current and deferred income taxes for an intra-entity asset transfer, other than inventory, when the transfer occurs. Historically, recognition of the income tax consequence was not recognized until the asset was sold to an outside party.  This amendment should be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  ASU 2016-16 is effective for annual periods beginning after December 15, 2017, including interim reporting periods within those annual reporting periods.  Early adoption is permitted for all entities as of the beginning of an annual reporting period for which financial statements (interim or annual) have not been issued or made available for issuance. The Company is currently evaluating the impact ASU 2016-16 will have on its consolidated financial statements.

[0000926326-16-000077:notes:105]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company's Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0000926326-16-000077:notes:106]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards ("RSAs") |  |  |  |
| Outstanding at December 31, 2015 | 31 |  |  | $ | 35.97 |  |
| Granted | 35 |  |  | 31.59 |  |
| Vested | (31 | ) |  | 36.03 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at September 30, 2016 | 35 |  |  | $ | 31.56 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-16-000077:notes:107]
[same as prior period, unchanged from 0000926326-16-000070:notes:116]

[0000926326-16-000077:notes:108]
[same as prior period, unchanged from 0000926326-16-000070:notes:117]

[0000926326-16-000077:notes:109]
[same as prior period, unchanged from 0000926326-16-000070:notes:118]

[0000926326-16-000077:notes:110]
[same as prior period, unchanged from 0000926326-16-000070:notes:119]

[0000926326-16-000077:notes:111]
Certain prior year amounts for the provision for excess and obsolete inventories and provision for receivables allowance have been reclassified/combined with inventories and accounts receivable within net cash provided by operating activities in the Condensed Consolidated Statements of Cash Flows to conform to 2016 presentation. These changes are not material and do not impact previously disclosed net cash provided by operating activities, net cash used in investing activities, and net cash used by financing activities.

[0000926326-16-000077:notes:112]
[same as prior period, unchanged from 0000926326-16-000070:notes:120]

[0000926326-16-000077:notes:113]
[same as prior period, unchanged from 0000926326-16-000070:notes:121]

[0000926326-16-000077:notes:114]
[same as prior period, unchanged from 0000926326-16-000070:notes:122]

[0000926326-16-000077:notes:115]
[same as prior period, unchanged from 0000926326-16-000070:notes:123]

[0000926326-16-000077:notes:116]
The operating results of the acquired Aesynt business are included in the Company's Automation and Analytics reportable segment.

[0000926326-16-000077:notes:117]
[same as prior period, unchanged from 0000926326-16-000070:notes:128]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-16-000077:notes:118]
[same as prior period, unchanged from 0000926326-16-000070:notes:129]

[0000926326-16-000077:notes:119]
In second quarter of 2016, the Company integrated its Sales and Field organizations in North America to better serve its customers which resulted in a reduction in headcount of 36 employees. Accordingly, the Company incurred approximately $1.7 million of restructuring expenses in the nine months ended September 30, 2016, based on agreements with terminated employees covering salary and benefit continuation. As of September 30, 2016 the restructuring program has been concluded. The Company had paid approximately $0.5 million and $1.7 million for the three months and nine months ended September 30, 2016, respectively.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000926326-16-000077:notes:120]
[same as prior period, unchanged from 0000926326-16-000070:notes:131]

[0000926326-16-000077:notes:121]
|  | Three months ended |
|  | September 30, 2016 |  | September 30, 2015 |
|  | (In thousands) |
| United States | $ | 155,989 |  |  | 103,944 |  |
| Rest of world (1) | 20,748 |  |  | 21,290 |  |
| Total revenues | $ | 176,737 |  |  | $ | 125,234 |  |

[0000926326-16-000077:notes:122]
|  | Nine months ended |
|  | September 30, 2016 |  | September 30, 2015 |
|  | (In thousands) |
| United States | $ | 445,470 |  |  | $ | 297,564 |  |
| Rest of world (1) | 75,178 |  |  | 56,679 |  |
| Total revenues | $ | 520,648 |  |  | $ | 354,243 |  |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-16-000077:notes:123]
|  | September 30, 2016 |  | December 31, 2015 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 14,734 |  |  | $ | 11,582 |  |
| Work in process | 9,332 |  |  | 1,653 |  |
| Finished goods | 50,059 |  |  | 33,359 |  |
| Total inventories | $ | 74,125 |  |  | $ | 46,594 |  |
| Property and equipment: |  |  |  |
| Equipment | $ | 57,541 |  |  | $ | 43,533 |  |
| Furniture and fixtures | 6,296 |  |  | 5,897 |  |
| Leasehold improvements | 9,531 |  |  | 9,063 |  |
| Software | 34,144 |  |  | 30,693 |  |
| Construction in progress | 7,469 |  |  | 3,651 |  |
| Property and equipment, gross | 114,981 |  |  | 92,837 |  |
| Accumulated depreciation and amortization | (73,947 | ) |  | (60,528 | ) |
| Total property and equipment, net | $ | 41,034 |  |  | $ | 32,309 |  |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 31,219 |  |  | $ | 26,011 |  |
| Other assets | 1,393 |  |  | 1,883 |  |
| Total other long term assets, net | $ | 32,612 |  |  | $ | 27,894 |  |
| Accrued liabilities: |  |  |  |
| Advance payments from customers | $ | 5,855 |  |  | $ | 8,327 |  |
| Rebates and lease buyouts | 4,577 |  |  | 4,702 |  |
| Group purchasing organization fees | 3,310 |  |  | 2,983 |  |
| Taxes payable | 4,057 |  |  | 2,768 |  |
| Other accrued liabilities | 15,010 |  |  | 11,353 |  |
| Total accrued liabilities | $ | 32,809 |  |  | $ | 30,133 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0000926326-16-000077:notes:124]
[same as prior period, unchanged from 0000926326-16-000070:notes:135]

[0000926326-16-000077:notes:125]
|  | Three months ended |  | Nine months ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 628 |  |  | $ | 581 |  |  | $ | 1,821 |  |  | $ | 1,630 |  |
| Research and development | 825 |  |  | 587 |  |  | 2,267 |  |  | 1,472 |  |
| Selling, general and administrative | 3,224 |  |  | 2,798 |  |  | 9,975 |  |  | 8,165 |  |
| Total share-based compensation expense | $ | 4,677 |  |  | $ | 3,966 |  |  | $ | 14,063 |  |  | $ | 11,267 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0000926326-16-000077:notes:126]
The following table summarizes the restricted stock activity under the Company’s equity incentive plans during the nine months ended September 30, 2016:

[0000926326-16-000077:notes:127]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units ("RSUs") |  |  |  |  |  |  |  |
| Outstanding at December 31, 2015 | 417 |  |  | $ | 28.49 |  |  | 1.6 |  |  |
| Granted | 121 |  |  | 29.19 |  |  |  |  |  |
| Vested | (106 | ) |  | 26.80 |  |  |  |  |  |
| Forfeited | (19 | ) |  | 27.85 |  |  |  |  |  |
| Outstanding and unvested at September 30, 2016 | 413 |  |  | $ | 29.16 |  |  | 1.3 |  | $ | 15,812 |  |


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0000926326-16-000077:notes:128]
[same as prior period, unchanged from 0000926326-16-000070:notes:139]


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-16-000077:notes:129]
[same as prior period, unchanged from 0000926326-16-000070:notes:140]

[0000926326-16-000077:notes:130]
|  | Three months ended |
|  | September 30, 2016 |  | September 30, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 152,437 |  |  | $ | 24,300 |  |  | $ | 176,737 |  |  | $ | 102,967 |  |  | $ | 22,267 |  |  | $ | 125,234 |  |
| Cost of revenues | 77,828 |  |  | 17,401 |  |  | 95,229 |  |  | 45,668 |  |  | 15,863 |  |  | 61,531 |  |
| Gross profit | 74,609 |  |  | 6,899 |  |  | 81,508 |  |  | 57,299 |  |  | 6,404 |  |  | 63,703 |  |
| Operating expenses | 49,123 |  |  | 6,137 |  |  | 55,260 |  |  | 30,628 |  |  | 6,070 |  |  | 36,698 |  |
| Income from segment operations | $ | 25,486 |  |  | $ | 762 |  |  | $ | 26,248 |  |  | $ | 26,671 |  |  | $ | 334 |  |  | $ | 27,005 |  |
| Corporate costs |  |  |  |  | 21,320 |  |  |  |  |  |  | 13,146 |  |
| Income from operations |  |  |  |  | $ | 4,928 |  |  |  |  |  |  | $ | 13,859 |  |

[0000926326-16-000077:notes:131]
|  | Nine months ended |
|  | September 30, 2016 |  | September 30, 2015 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 450,043 |  |  | $ | 70,605 |  |  | $ | 520,648 |  |  | $ | 284,447 |  |  | $ | 69,796 |  |  | $ | 354,243 |  |
| Cost of revenues | 233,401 |  |  | 47,777 |  |  | 281,178 |  |  | 123,923 |  |  | 47,470 |  |  | 171,393 |  |
| Gross profit | 216,642 |  |  | 22,828 |  |  | 239,470 |  |  | 160,524 |  |  | 22,326 |  |  | 182,850 |  |
| Operating expenses | 151,108 |  |  | 17,518 |  |  | 168,626 |  |  | 85,195 |  |  | 18,321 |  |  | 103,516 |  |
| Income from segment operations | $ | 65,534 |  |  | $ | 5,310 |  |  | $ | 70,844 |  |  | $ | 75,329 |  |  | $ | 4,005 |  |  | $ | 79,334 |  |
| Corporate costs |  |  |  |  | 64,182 |  |  |  |  |  |  | 42,672 |  |
| Income from operations |  |  |  |  | $ | 6,662 |  |  |  |  |  |  | $ | 36,662 |  |

[0000926326-16-000077:notes:132]
[same as prior period, unchanged from 0000926326-16-000070:notes:143]


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000926326-16-000077:notes:133]
The following table summarizes the share option activity under the Company’s equity incentive plans during the nine months ended September 30, 2016:

[0000926326-16-000077:notes:134]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value(1) |
|  | (In thousands, except per share data) |
| Stock Options |  |  |  |  |  |  |  |
| Outstanding at December 31, 2015 | 2,688 |  |  | $ | 22.89 |  |  | 6.9 |  |  |
| Granted | 512 |  |  | 29.25 |  |  |  |  |  |
| Exercised | (352 | ) |  | 19.24 |  |  |  |  |  |
| Expired | (5 | ) |  | 28.75 |  |  |  |  |  |
| Forfeited | (100 | ) |  | 29.74 |  |  |  |  |  |
| Outstanding at September 30, 2016 | 2,743 |  |  | $ | 24.30 |  |  | 7.0 |  | $ | 38,482 |  |
| Exercisable at September 30, 2016 | 1,368 |  |  | $ | 19.36 |  |  | 5.2 |  | $ | 25,929 |  |
| Vested and expected to vest at September 30, 2016 and thereafter | 2,597 |  |  | $ | 23.99 |  |  | 6.9 |  | $ | 37,230 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0000926326-16-000077:notes:135]
The following weighted average assumptions are used to value stock options and Employee Stock Purchase Plan ("ESPP") shares issued pursuant to the Company's equity incentive plans for the three and nine months ended September 30, 2016 and September 30, 2015:

[0000926326-16-000077:notes:136]
|  | Three months ended |  | Nine months ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Stock Option Plans |  |  |  |  |  |  |  |
| Expected life, years | 4.92 |  |  | 5.04 |  |  | 4.92 |  |  | 5.04 |  |
| Expected volatility, % | 30.0 | % |  | 29.3 | % |  | 31.4 | % |  | 31.1 | % |
| Risk free interest rate, % | 1.21 | % |  | 1.73 | % |  | 1.34 | % |  | 1.63 | % |
| Estimated forfeiture rate % | 8.6 | % |  | 2.5 | % |  | 8.6 | % |  | 2.5 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-16-000077:notes:137]
|  | Three months ended |  | Nine months ended |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Employee Stock Purchase Plan |  |  |  |  |  |  |  |
| Expected life, years | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |  | 0.5-2.0 |  |
| Expected volatility, % | 25.8-34.8% |  |  | 25.8-34.4% |  |  | 25.8-34.8% |  |  | 25.8-37.5% |  |
| Risk free interest rate, % | 0.41-0.79% |  |  | 0.12-0.79% |  |  | 0.34-0.79% |  |  | 0.03-0.79% |  |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-16-000077:notes:138]
[same as prior period, unchanged from 0000926326-16-000070:notes:149]

[0000926326-16-000077:notes:139]
[same as prior period, unchanged from 0000926326-16-000070:notes:150]

[0000926326-16-000077:notes:140]
[same as prior period, unchanged from 0000926326-16-000070:notes:151]

[0000926326-16-000077:notes:141]
[same as prior period, unchanged from 0000926326-16-000070:notes:152]

[0000926326-16-000077:notes:142]
[same as prior period, unchanged from 0000926326-16-000070:notes:153]

[0000926326-16-000077:notes:143]
The Medication Adherence segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products, which consist of proprietary medication packaging systems and related products for use by institutional pharmacies servicing long-term care, and correctional facilities or retail pharmacies serving patients in their local communities.

[0000926326-16-000077:notes:144]
[same as prior period, unchanged from 0000926326-16-000070:notes:155]

[0000926326-16-000077:notes:145]
There were no customers that accounted for more than 10% of our total revenues for the three and nine months ended September 30, 2016 and September 30, 2015.

[0000926326-16-000077:notes:146]
[same as prior period, unchanged from 0000926326-16-000070:notes:157]

[0000926326-16-000077:notes:147]
[same as prior period, unchanged from 0000926326-16-000070:notes:158]


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0000926326-16-000077:notes:148]
The following table summarizes the performance-based restricted stock activity under the Company’s equity incentive plans during the nine months ended September 30, 2016:

[0000926326-16-000077:notes:149]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Performance-based Restricted Stock Units ("PSUs") |  |  |  |
| Outstanding at December 31, 2015 | 151 |  |  | $ | 23.33 |  |
| Granted | 122 |  |  | 24.66 |  |
| Vested | (52 | ) |  | 23.04 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at September 30, 2016 | 221 |  |  | $ | 24.13 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-16-000077:notes:150]
[same as prior period, unchanged from 0000926326-16-000070:notes:161]

[0000926326-16-000077:notes:151]
[same as prior period, unchanged from 0000926326-16-000070:notes:162]

[0000926326-16-000077:notes:152]
[same as prior period, unchanged from 0000926326-16-000070:notes:163]

[0000926326-16-000077:notes:153]
[same as prior period, unchanged from 0000926326-16-000070:notes:164]

[0000926326-16-000077:notes:154]
[same as prior period, unchanged from 0000926326-16-000070:notes:165]

[0000926326-16-000077:notes:155]
The weighted-average fair value per share of options granted during the three and nine months ended September 30, 2016, was $10.32 and $8.82, respectively, and the weighted-average fair value per share of options granted during the three and nine months ended September 30, 2015 was $10.51 and $10.57, respectively. The intrinsic value of options exercised during the three and nine months ended September 30, 2016 was $2.1 million and $5.0 million, respectively. The intrinsic value of options exercised during the three and nine months ended September 30, 2015 was $3.1 million and $9.7 million, respectively.

[0000926326-16-000077:notes:156]
As of September 30, 2016, total unrecognized compensation cost related to unvested stock options was $10.1 million, which is expected to be recognized over a weighted-average vesting period of 2.8 years.

[0000926326-16-000077:notes:157]
[same as prior period, unchanged from 0000926326-16-000070:notes:168]

[0000926326-16-000077:notes:158]
The weighted-average grant date fair value per share of RSU granted during the nine months ended September 30, 2016 and September 30, 2015 was $29.19 and $34.72, respectively.

[0000926326-16-000077:notes:159]
As of September 30, 2016, total unrecognized compensation expense related to RSUs was $9.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.5 years.

[0000926326-16-000077:notes:160]
As of September 30, 2016, total unrecognized compensation cost related to RSAs was $0.6 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.66 years.

[0000926326-16-000077:notes:161]
[same as prior period, unchanged from 0000926326-16-000070:notes:172]

[0000926326-16-000077:notes:162]
The weighted-average grant date fair value per share of PSUs granted during the nine months ended September 30, 2016 and September 30, 2015 was $24.66 and $29.56, respectively. As of September 30, 2016, total unrecognized compensation cost related to PSUs was $2.1 million, which is expected to be recognized over the remaining weighted-average period of 1.2 years.

[0000926326-16-000077:notes:163]
[same as prior period, unchanged from 0000926326-16-000070:notes:174]

[0000926326-16-000077:notes:164]
As of September 30, 2016, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $5.2 million and is expected to be recognized over a weighted-average period of 2.0 years.

[0000926326-16-000077:notes:165]
[same as prior period, unchanged from 0000926326-16-000070:notes:176]

[0000926326-16-000077:notes:166]
Stock Repurchase Program

[0000926326-16-000077:notes:167]
On August 2, 2016, the Board of Directors (the "Board") of (the “Company”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of September 30, 2016, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million.

[0000926326-16-000077:notes:168]
The timing, price and volume of repurchases are to be based on market conditions, relevant securities laws and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions or pursuant to a Rule 10b-18 plan, subject to the terms and conditions of that certain Credit Agreement, dated as of January 5, 2016, among the Company, the Lenders party thereto, and Wells Fargo Bank, National Association, as administrative agent. The stock repurchase program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase program at any time.

[0000926326-16-000077:notes:169]
During the three and nine months period ended September 30, 2016, the Company did not repurchase any of its outstanding common stock. The Company repurchased approximately1,424 thousand shares under its stock repurchase programs for $50.02 million during the nine months ended September 30, 2015.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-16-000077:notes:170]
[same as prior period, unchanged from 0000926326-16-000070:notes:182]
