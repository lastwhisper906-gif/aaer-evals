# OMCL notes — 0000926326-14-000039


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000926326-14-000039:notes:1]
[same as prior period, unchanged from 0000926326-14-000035:notes:1]

[0000926326-14-000039:notes:2]
|  | Allowance for Credit Losses |  | Recorded Investmentin Sales-type Leases Gross |  | Recorded Investmentin Sales-type Leases Net |
| Credit loss disclosure for September 30, 2014: |  |  |  |  |  |  |  |  |
| Accounts collectively evaluated for impairment | $ | 151 |  |  | $ | 16,539 |  |  | $ | 16,388 |  |
| Ending balances: September 30, 2014 | $ | 151 |  |  | $ | 16,539 |  |  | $ | 16,388 |  |
| Credit loss disclosure for December 31, 2013: |  |  |  |  |  |  |  |  |
| Accounts collectively evaluated for impairment | $ | 167 |  |  | $ | 16,884 |  |  | $ | 16,717 |  |
| Ending balances: December 31, 2013 | $ | 167 |  |  | $ | 16,884 |  |  | $ | 16,717 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-14-000039:notes:3]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and our subsidiaries as of September 30, 2014, the results of our operations and comprehensive income for the three and nine months ended September 30, 2014 and 2013 and our cash flows for the nine months ended September 30, 2014 and 2013. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2013.

[0000926326-14-000039:notes:4]
Our results of operations, comprehensive income for the three and nine months ended September 30, 2014 and cash flows for the nine months ended September 30, 2014 are not necessarily indicative of results that may be expected for the year ending December 31, 2014, or for any future period.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000926326-14-000039:notes:5]
The total acquisition consideration was approximately $20.8 million and the preliminary acquisition price allocation was comprised of the following (in thousands):

[0000926326-14-000039:notes:6]
|  |  | Fair Value Acquired |  |
| Cash |  | $ | 153 |  |
| Accounts receivable |  | 2,462 |  |
| Inventory |  | 2,190 |  |
| Deferred tax assets and other current assets |  | 361 |  |
| Total current assets |  | $ | 5,166 |  |
| Property and equipment |  | 164 |  |
| Intangibles |  | 5,730 |  |
| Goodwill |  | 12,016 |  |
| Total assets |  | $ | 23,076 |  |
| Current liabilities |  | 1,191 |  |
| Non-current deferred tax liabilities |  | 1,104 |  |
| Total purchase price |  | $ | 20,781 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-14-000039:notes:7]
Business Acquisition

[0000926326-14-000039:notes:8]
On August 22, 2014, we completed our acquisition of Surgichem, a wholly-owned subsidiary of Bupa Care Homes (CFG) plc ("Bupa") pursuant to an Agreement by and among Omnicell, Bupa and MTS (the "Share Purchase Agreement"), under which MTS, a wholly-owned subsidiary of Omnicell, purchased the entire issued share capital of Surgichem, with Omnicell acting as guarantor of MTS' obligations thereunder (the "Acquisition"). As a result of the Acquisition, Omnicell paid to Bupa $19.9 million in cash, subject to certain adjustments as provided for in the Share Purchase Agreement. Surgichem is in the process of being integrated with Omnicell’s existing UK business, MTS Medication Technologies Limited, a leading supplier of medication adherence packaging solutions.

[0000926326-14-000039:notes:9]
The Surgichem acquisition primarily was to align Omnicell with the long term trends of the healthcare market to manage the health of patients across the continuum of care, specifically in the UK market. We acquired all outstanding shares of Surgichem.

[0000926326-14-000039:notes:10]
We are accounting for the transaction under the acquisition method of accounting in accordance with the provisions of FASB Accounting Standards Codification ("ASC") Topic 805, Business Combinations. Under the acquisition method, the estimated fair value of the consideration transferred to purchase the acquired company is allocated to the assets acquired and the liabilities assumed based on their fair values. We have made significant estimates and assumptions in determining the allocation of the acquisition consideration. The acquisition consideration of $20.8 million is comprised of $19.9 million in cash at closing plus an estimated $0.9 million net working capital adjustment recorded in accrued liabilities, subject to review by Bupa and possible adjustment.

[0000926326-14-000039:notes:11]
The purchase price allocation is subject to certain post-closing working capital adjustments for the acquired current assets and current liabilities of Surgichem on the acquisition date. The total consideration, and the allocation of consideration to the individual net assets is preliminary, as there are remaining uncertainties to be resolved, including the settlement of the final net working capital adjustment.

[0000926326-14-000039:notes:12]
Acquired intangible assets. The fair value of $5.4 million for acquired customer relationships was determined based on an income approach using the discounted cash flow method. The fair value of $0.3 million for the trade name was determined using the relief-from-royalty approach. The intangible assets are being amortized over their estimated useful lives of 18 years for the customer relationships and just over one year for trade name.

[0000926326-14-000039:notes:13]
Goodwill. Approximately $12.0 million has been allocated to goodwill, which represents sales of future products and services and the assembled workforce of Surgichem. In accordance with FASB ASC Topic 350, Intangibles - Goodwill and Other, goodwill will not be amortized, but instead will be tested for impairment at least annually or more frequently if certain indicators are present. In the event our management determines that the value of goodwill has become impaired, we will incur an accounting charge for the amount of impairment during the quarter in which the determination is made. We believe the Surgichem acquisition enhances Omnicell’s offerings and diversifies its revenue mix providing a more robust product and service solution to its current customers while expanding Omnicell’s international presence. We consider these factors as supporting the amount of goodwill recorded. Note that the amortization of intangible assets, and goodwill is not deductible for tax purposes. For the three months ended September 30, 2014, we incurred approximately $0.2 million in acquisition related costs related to the Surgichem acquisition, offset by a $0.5 million expense reimbursement from Bupa. For the nine months ended September 30, 2014, we incurred approximately $1.1 million in acquisition related costs related to the Surgichem acquisition, offset by a $0.5 million expense reimbursement from Bupa.These costs are included in selling, general and administrative expenses in our Condensed Consolidated Statement of Operations.

[0000926326-14-000039:notes:14]
During the three months ended September 30, 2014, the acquired Surgichem operations (consolidated since the August 22, 2014 acquisition date) generated approximately $1.4 million of revenue and impact on income from operations was $0.1 million.

[0000926326-14-000039:notes:15]
The total revenues of Surgichem for the nine months ended September 30, 2014 and 2013, were approximately $10.1 million (including the $1.4 million mentioned above) and $8.7 million, respectively. Results of operations for Surgichem have been included in our condensed consolidated financial statements subsequent to the date of acquisition and pro forma results of operations in accordance with authoritative guidance for prior periods have not been presented because the effect of the acquisition was not material to our prior period consolidated financial results.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0000926326-14-000039:notes:16]
[same as prior period, unchanged from 0000926326-14-000035:notes:5]

[0000926326-14-000039:notes:17]
Cash and cash equivalents consist of the following significant asset investment classes as of September 30, 2014 and December 31, 2013 (in thousands):

[0000926326-14-000039:notes:18]
|  | September 30, 2014 |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | SecurityClassification |
| Cash | $ | 42,522 |  |  | $ | — |  |  | $ | — |  |  | $ | 42,522 |  |  | $ | 42,522 |  |  | N/A |
| Money market fund | 61,665 |  |  | — |  |  | — |  |  | 61,665 |  |  | 61,665 |  |  | Available-for-sale |
| Total cash and cash equivalents | $ | 104,187 |  |  | $ | — |  |  | $ | — |  |  | $ | 104,187 |  |  | $ | 104,187 |  |  |  |

[0000926326-14-000039:notes:19]
| c | December 31, 2013 |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | SecurityClassification |
| Cash | $ | 38,823 |  |  | $ | — |  |  | $ | — |  |  | $ | 38,823 |  |  | $ | 38,823 |  |  | N/A |
| Money market fund | 65,708 |  |  | — |  |  | — |  |  | 65,708 |  |  | 65,708 |  |  | Available-for-sale |
| Total cash and cash equivalents | $ | 104,531 |  |  | $ | — |  |  | $ | — |  |  | $ | 104,531 |  |  | $ | 104,531 |  |  |  |

[0000926326-14-000039:notes:20]
The money market fund is a daily-traded cash equivalent with a price of $1.00, making it a Level 1 asset class, and its carrying cost closely approximates fair value. As demand deposit (cash) balances vary with the timing of collections and payments, the money market fund can cover any surplus or deficit, and thus is considered available-for-sale.  We did not hold any Level 2 and Level 3 assets or liabilities as of September 30, 2014 and December 31, 2013.

[0000926326-14-000039:notes:21]
[same as prior period, unchanged from 0000926326-14-000035:notes:10]

[0000926326-14-000039:notes:22]
|  | Quoted Prices in ActiveMarkets for IdenticalInstruments (Level 1) |  | Total FairValue |
| Money market fund at September 30, 2014 | $ | 61,665 |  |  | $ | 61,665 |  |
| Money market fund at December 31, 2013 | $ | 65,708 |  |  | $ | 65,708 |  |


## us-gaap:CommitmentsDisclosureTextBlock

[0000926326-14-000039:notes:23]
[same as prior period, unchanged from 0000926326-14-000035:notes:12]

[0000926326-14-000039:notes:24]
[same as prior period, unchanged from 0000926326-14-000035:notes:13]

[0000926326-14-000039:notes:25]
At September 30, 2014, the minimum payments under our operating leases for each of the five succeeding fiscal years were as follows (in thousands):

[0000926326-14-000039:notes:26]
| Remainder of 2014 | $ | 1,448 |  |
| 2015 | 5,604 |  |
| 2016 | 5,192 |  |
| 2017 | 4,468 |  |
| 2018 | 4,298 |  |
| Thereafter | 16,976 |  |
| Total | $ | 37,986 |  |

[0000926326-14-000039:notes:27]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. Our near-term commitments to our contract manufacturers and suppliers totaled $10.9 million as of September 30, 2014.


## us-gaap:DebtDisclosureTextBlock

[0000926326-14-000039:notes:28]
Credit Agreement

[0000926326-14-000039:notes:29]
In September 2013, we entered into a credit agreement (the "Credit Agreement") with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time thereto. The Credit Agreement provides for a $75.0 million revolving credit facility with a $10.0 million letter of credit sub-limit. Loans under the Credit Agreement mature on September 25, 2018. The Credit Agreement permits us to request one or more increases in the aggregate commitments provided that such increases do not exceed $25.0 million in the aggregate. We expect to use the proceeds from any revolving loans under the credit facility for general corporate purposes, including future acquisitions. Our obligations under the Credit Agreement are guaranteed by certain of our domestic subsidiaries and secured by substantially all of our and the subsidiary guarantors’ assets.

[0000926326-14-000039:notes:30]
Amounts drawn under the Credit Agreement bear interest, at our election, at a Eurodollar rate plus a margin of 1.75% per annum, or an alternate base rate equal to the highest of (a) the prime rate, (b) the federal funds rate plus 0.50%, and (c) LIBOR for an interest period of one month plus 1.75%. We are required to pay a commitment fee of 0.25% per annum on the aggregate undrawn amount of the commitments under the credit facility.

[0000926326-14-000039:notes:31]
The Credit Agreement contains customary affirmative and negative covenants, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each fiscal quarter.

[0000926326-14-000039:notes:32]
To date, we have not yet drawn any funds under the credit facility. We were in full compliance with all covenants at September 30, 2014 and for all periods since the commencement of the Credit Agreement.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000926326-14-000039:notes:33]
[same as prior period, unchanged from 0000926326-14-000035:notes:22]

[0000926326-14-000039:notes:34]
[same as prior period, unchanged from 0000926326-14-000035:notes:23]

[0000926326-14-000039:notes:35]
[same as prior period, unchanged from 0000926326-14-000035:notes:24]

[0000926326-14-000039:notes:36]
[same as prior period, unchanged from 0000926326-14-000035:notes:25]

[0000926326-14-000039:notes:37]
At September 30, 2014, 2,238,383 shares of common stock were reserved for future issuance our 2009 Equity Incentive Plan, as amended (the "2009 Plan"), and $5.8 million of total unrecognized compensation cost related to non-vested stock options was expected to be recognized over a weighted average period of 2.6 years.

[0000926326-14-000039:notes:38]
A summary of option activity under the 2009 Plan for the nine months ended September 30, 2014 is presented below:

[0000926326-14-000039:notes:39]
| Options: |  | Number of Shares |  | Weighted-Average Exercise Price |
|  |  | (in thousands) |  |  |
| Outstanding at December 31, 2013 |  | 3,143 |  |  | $15.82 |
| Granted |  | 397 |  |  | $26.14 |
| Exercised |  | (786 | ) |  | $14.44 |
| Forfeited |  | (72 | ) |  | $18.96 |
| Expired |  | (12 | ) |  | $19.88 |
| Outstanding at September 30, 2014 |  | 2,670 |  |  | $17.66 |
| Vested and expected to vest at September 30, 2014 |  | 2,638 |  |  | $17.60 |
| Exercisable at September 30, 2014 |  | 1,612 |  |  | $15.47 |

[0000926326-14-000039:notes:40]
The aggregate intrinsic value of options exercised under our stock plans for the three and nine months ended September 30, 2014 was $2.5 million and $10.4 million, respectively, determined as of the date of option exercise.

[0000926326-14-000039:notes:41]
[same as prior period, unchanged from 0000926326-14-000035:notes:30]

[0000926326-14-000039:notes:42]
A summary of activity of both restricted stock and restricted stock units ("RSUs") for the nine months ended September 30, 2014 is presented below:

[0000926326-14-000039:notes:43]
|  | Restricted Stock |  | Restricted Stock Units |
|  | Number ofShares |  | Weighted-AverageGrant DateFair Value PerShare |  | Number ofShares |  | Weighted-AverageGrant DateFair Value PerShare |
|  | (in thousands) |  |  |  | (in thousands) |  |  |
| Non-vested, December 31, 2013 | 52 |  |  | $18.43 |  | 362 |  |  | $17.15 |
| Granted | 38 |  |  | $25.16 |  | 127 |  |  | $25.73 |
| Vested | (54 | ) |  | $17.78 |  | (118 | ) |  | $16.70 |
| Forfeited | — |  |  | — |  |  | (18 | ) |  | $16.15 |
| Non-vested, September 30, 2014 | 36 |  |  | $26.47 |  | 353 |  |  | $20.42 |

[0000926326-14-000039:notes:44]
The fair value of restricted stock is the product of the number of shares granted and the closing market price of our common stock on the grant date. Our unrecognized compensation cost related to non-vested restricted stock is approximately $6.8 million and is expected to be recognized over a weighted-average period of 2.5 years.

[0000926326-14-000039:notes:45]
[same as prior period, unchanged from 0000926326-14-000035:notes:34]

[0000926326-14-000039:notes:46]
Performance-based restricted stock units ("PSUs") are an element of our executive compensation plans. In 2012, we granted 125,000 PSUs to our executive officers, of which 62,500 became eligible for vesting upon the achievement of a certain level of shareholder return for 2012 as described below. In 2013, we granted 137,500 PSUs to our executive officers, all of which became eligible for vesting upon the achievement of a certain level of shareholder return for the period from January 1, 2013 through February 28, 2014, as described below. In 2014, we granted 152,500 PSUs to our executive officers, all, none or a portion of which may become eligible for vesting depending on the level of shareholder return for 2014 and eligible for further time-based vesting based on the ranking of our total shareholder return. For a more detailed explanation of our PSUs and subsequent changes, please refer to Note 16, Stock Option Plans, Share-Based Compensation and 401(k) Plan on our Annual Report on Form 10-K for the year ended December 31, 2013.

[0000926326-14-000039:notes:47]
Our unrecognized compensation cost related to non-vested performance-based restricted stock units at September 30, 2014 was approximately $1.8 million and is expected to be recognized over a weighted-average period of 1.3 years. For the three months ended September 30, 2014 and 2013, we recognized $0.5 million and $0.4 million, respectively, of compensation expense for the PSUs. For the nine months ended September 30, 2014 and 2013, we recognized $1.5 million and $1.2 million, respectively, of compensation expense for the PSUs.

[0000926326-14-000039:notes:48]
[same as prior period, unchanged from 0000926326-14-000035:notes:37]

[0000926326-14-000039:notes:49]
[same as prior period, unchanged from 0000926326-14-000035:notes:38]

[0000926326-14-000039:notes:50]
[same as prior period, unchanged from 0000926326-14-000035:notes:39]

[0000926326-14-000039:notes:51]
[same as prior period, unchanged from 0000926326-14-000035:notes:40]

[0000926326-14-000039:notes:52]
[same as prior period, unchanged from 0000926326-14-000035:notes:41]

[0000926326-14-000039:notes:53]
[same as prior period, unchanged from 0000926326-14-000035:notes:42]

[0000926326-14-000039:notes:54]
The following table shows the percent of PSUs granted in 2014 eligible for further time-based vesting based on our percentile placement:

[0000926326-14-000039:notes:55]
A summary of activity of the PSUs for the nine months ended September 30, 2014 is presented below:

[0000926326-14-000039:notes:56]
| Performance-based Stock Units | Number of Shares |  | Weighted-AverageGrant Date Fair Value PerShare |
|  | (in thousands) |  |  |
| Non-vested, December 31, 2013 | 225 |  |  | $13.32 |
| Granted | 155 |  |  | $14.36 |
| Vested | (74 | ) |  | $13.66 |
| Forfeited | (28 | ) |  | $3.07 |
| Non-vested, September 30, 2014 | 278 |  |  | $14.84 |

[0000926326-14-000039:notes:57]
[same as prior period, unchanged from 0000926326-14-000035:notes:45]

[0000926326-14-000039:notes:58]
We have an Employee Stock Purchase Plan (the “ESPP”) under which eligible employees can purchase shares of our common stock based on a percentage of their compensation, but not greater than 15% of their earnings; provided, however, an eligible employees' right to purchase shares of our common stock may not accrue at a rate which exceeds $25,000 of the fair market value of such shares for each calendar year in which such rights are outstanding. The purchase price per share is equal to the lower of 85% of the fair market value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period.

[0000926326-14-000039:notes:59]
At the 2009 Annual Meeting of Stockholders, the stockholders approved an amendment to the ESPP, which added 2,622,426 shares to the reserve for future issuance. As of September 30, 2014, there were 619,616 shares reserved for future issuance under the ESPP. For the three months ended September 30, 2014, 227,275 shares of common stock were purchased under the ESPP. For the nine months ended September 30, 2014, 481,284 shares of common stock were purchased under the ESPP.

[0000926326-14-000039:notes:60]
As of September 30, 2014, our unrecognized compensation cost related to the shares to be purchased under our ESPP was approximately $2.6 million and is expected to be recognized over a weighted average period of approximately 1.0 year.

[0000926326-14-000039:notes:61]
[same as prior period, unchanged from 0000926326-14-000035:notes:49]

[0000926326-14-000039:notes:62]
[same as prior period, unchanged from 0000926326-14-000035:notes:50]

[0000926326-14-000039:notes:63]
[same as prior period, unchanged from 0000926326-14-000035:notes:51]

[0000926326-14-000039:notes:64]
[same as prior period, unchanged from 0000926326-14-000035:notes:52]

[0000926326-14-000039:notes:65]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Cost of revenues | $ | 441 |  |  | $ | 325 |  |  | $ | 973 |  |  | $ | 955 |  |
| Research and development | 407 |  |  | 405 |  |  | 1,156 |  |  | 1,019 |  |
| Selling, general and administrative | 2,313 |  |  | 2,080 |  |  | 6,481 |  |  | 6,449 |  |
| Total share-based compensation expenses | $ | 3,161 |  |  | $ | 2,810 |  |  | $ | 8,610 |  |  | $ | 8,423 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0000926326-14-000039:notes:66]
Basic net income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Since their impact is anti-dilutive, we excluded 426,974 and 364,450 shares, respectively, from the calculations of diluted net income per share for the three and nine months ended September 30, 2014 and 465,301 and 1,178,755 shares, respectively, from the same calculations for the three and nine months ended September 30, 2013.


## us-gaap:EarningsPerShareTextBlock

[0000926326-14-000039:notes:67]
[same as prior period, unchanged from 0000926326-14-000035:notes:55]

[0000926326-14-000039:notes:68]
[same as prior period, unchanged from 0000926326-14-000035:notes:56]

[0000926326-14-000039:notes:69]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Basic: |  |  |  |  |  |  |  |  |  |
| Net income | $ | 7,300 |  |  | $ | 7,755 |  |  | $ | 21,282 |  |  | $ | 17,156 |  |
| Weighted average shares outstanding — basic | 35,994 |  |  | 35,133 |  |  | 35,634 |  |  | 34,499 |  |
| Net income per share — basic | $ | 0.20 |  |  | $ | 0.22 |  |  | $ | 0.60 |  |  | $ | 0.50 |  |
| Diluted: |  |  |  |  |  |  |  |  |  |
| Net income | $ | 7,300 |  |  | $ | 7,755 |  |  | $ | 21,282 |  |  | $ | 17,156 |  |
| Weighted average shares outstanding — basic | 35,994 |  |  | 35,133 |  |  | 35,634 |  |  | 34,499 |  |
| Add: Dilutive effect of employee stock plans | 838 |  |  | 1,057 |  |  | 983 |  |  | 967 |  |
| Weighted average shares outstanding — diluted | 36,832 |  |  | 36,190 |  |  | $ | 36,617 |  |  | 35,466 |  |
| Net income per share — diluted | $ | 0.20 |  |  | $ | 0.21 |  |  | $ | 0.58 |  |  | $ | 0.48 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-14-000039:notes:70]
[same as prior period, unchanged from 0000926326-14-000035:notes:58]

[0000926326-14-000039:notes:71]
[same as prior period, unchanged from 0000926326-14-000035:notes:59]

[0000926326-14-000039:notes:72]
[same as prior period, unchanged from 0000926326-14-000035:notes:60]

[0000926326-14-000039:notes:73]
During the nine months ended September 30, 2014, we noted no indications of impairment or triggering events to cause us to perform a goodwill impairment analysis.

[0000926326-14-000039:notes:74]
Goodwill by reporting unit, which is the same for our operating segments, is as follows (in thousands):

[0000926326-14-000039:notes:75]
|  | Goodwill at December 31, 2013 |  | Goodwill Acquired |  | Translation Adjustments |  | Goodwill at September 30, 2014 |
| Reporting units: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 28,543 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,543 |  |
| Medication Adherence | 82,800 |  |  | 12,016 |  |  | (269 | ) |  | 94,547 |  |
| Total | $ | 111,343 |  |  | $ | 12,016 |  |  | $ | (269 | ) |  | $ | 123,090 |  |

[0000926326-14-000039:notes:76]
[same as prior period, unchanged from 0000926326-14-000035:notes:64]

[0000926326-14-000039:notes:77]
There were no indefinite-lived intangible assets as of September 30, 2014 or December 31, 2013. Finite-lived intangible assets consist of the following (in thousands):

[0000926326-14-000039:notes:78]
|  | September 30, 2014 |  | December 31, 2013 |  |  |
|  | Gross |  |  |  | Net |  | Gross |  |  |  | Net |  |  |
|  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | AmortizationLife |
| Finite-lived intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 60,062 |  |  | $ | 6,919 |  |  | $ | 53,143 |  |  | $ | 54,730 |  |  | $ | 5,236 |  |  | $ | 49,494 |  |  | 5-30 years |
| Acquired technology | 27,580 |  |  | 3,700 |  |  | 23,880 |  |  | 27,580 |  |  | 2,598 |  |  | 24,982 |  |  | 3-20 years |
| Patents | 1,658 |  |  | 338 |  |  | 1,320 |  |  | 1,493 |  |  | 254 |  |  | 1,239 |  |  | 20 years |
| Trade name | 7,193 |  |  | 1,461 |  |  | 5,732 |  |  | 6,890 |  |  | 1,003 |  |  | 5,887 |  |  | 1-12 years |
| Non-compete agreements | 60 |  |  | 60 |  |  | — |  |  | 60 |  |  | 60 |  |  | — |  |  | 3 years |
| Total finite-lived intangibles | $ | 96,553 |  |  | $ | 12,478 |  |  | $ | 84,075 |  |  | $ | 90,753 |  |  | $ | 9,151 |  |  | $ | 81,602 |  |  |  |

[0000926326-14-000039:notes:79]
Amortization expense for the intangible assets presented above was $1.2 million and $1.1 million for the three months ended September 30, 2014 and 2013, respectively, and $3.3 million and $3.2 million for the nine months ended September 30, 2014 and 2013, respectively. The amortization of acquired technology is included within product cost of sales and amortization of other acquired intangibles is included within selling, general and administrative expenses.

[0000926326-14-000039:notes:80]
[same as prior period, unchanged from 0000926326-14-000035:notes:68]

[0000926326-14-000039:notes:81]
| Remainder of 2014 | $ | 1,289 |  |
| 2015 | 4,980 |  |
| 2016 | 4,355 |  |
| 2017 | 4,267 |  |
| 2018 | 4,113 |  |
| Thereafter | 65,071 |  |
| Total | $ | 84,075 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-14-000039:notes:82]
[same as prior period, unchanged from 0000926326-14-000035:notes:70]

[0000926326-14-000039:notes:83]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 40.4% and 38.1% for the nine months ended September 30, 2014 and 2013, respectively. The increase in the estimated annual effective tax rate for the nine months ended September 30, 2014 compared to the same period in 2013 was primarily due to the expiration of the federal research and development credit as of December 31, 2013. The 2014 annual effective tax rate differed from the statutory rate of 35.0% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.

[0000926326-14-000039:notes:84]
The 2013 annual effective tax rate differed from the statutory rate of 35.0% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the federal research and development credit claimed and the domestic production activities deduction.


## us-gaap:InventoryDisclosureTextBlock

[0000926326-14-000039:notes:85]
[same as prior period, unchanged from 0000926326-14-000035:notes:73]

[0000926326-14-000039:notes:86]
[same as prior period, unchanged from 0000926326-14-000035:notes:74]

[0000926326-14-000039:notes:87]
|  | September 30, 2014 |  | December 31, 2013 |
| Raw materials | $ | 11,158 |  |  | $ | 10,765 |  |
| Work in process | 883 |  |  | 534 |  |
| Finished goods | 19,806 |  |  | 20,158 |  |
| Total | $ | 31,847 |  |  | $ | 31,457 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000926326-14-000039:notes:88]
Contingencies

[0000926326-14-000039:notes:89]
Legal Proceedings

[0000926326-14-000039:notes:90]
On September 12, 2014, MV Circuit Design, Inc., an Ohio company, brought an action to correct the inventorship of certain patents owned by Omnicell, as well as related state-law claims against the Company in the Northern District of Ohio (Case No. 1:14-cv-02028-DAP) regarding allegations of fraud in the filing and prosecution of U.S. Patent Nos. 8,180,485, 8,773,270, 8,812,153, PCT/US2007/003765, PCT/US2011/063597, and PCT/US2011/0635505. Omnicell has been granted an extension to respond to the Original Complaint on  November 14, 2014. No schedule has yet been set by the court. Omnicell is currently evaluating a response to this complaint and intends to defend the matter vigorously.

[0000926326-14-000039:notes:91]
As required under ASC 450, "Contingencies," we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We believe that we have valid defenses with respect to legal proceedings pending against us. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-14-000039:notes:92]
Guarantees

[0000926326-14-000039:notes:93]
As permitted under Delaware law and our certificate of incorporation and bylaws, we have agreed to indemnify our directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become our directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that we could be required to make under these indemnification agreements. We have purchased a directors’ and officers’ liability insurance policy that may enable us to recover a portion of any future payments that we may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-14-000039:notes:94]
Additionally, we undertake indemnification obligations in our ordinary course of business in connection with, among other things, the licensing of our products and the provision of our support services. In the ordinary course of our business, we have in the past and may in the future agree to indemnify another party, generally our business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, our gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, we attempt to limit the maximum potential amount of future payments that we may be required to make under these indemnification obligations to the amounts paid to us by a customer, but in some cases the obligation may not be so limited. In addition, we have in the past and may in the future warrant to our customers that our products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that our software media is free from material defects. Sales contracts for certain of our medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances we record have historically been immaterial.

[0000926326-14-000039:notes:95]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of September 30, 2014 or December 31, 2013.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-14-000039:notes:96]
Recently Adopted Accounting Standards

[0000926326-14-000039:notes:97]
In July 2013, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2013-11, Income Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists ("ASU 2013-11"). ASU 2013-11 requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except as follows: to the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit should be presented in the financial statements as a liability and should not be combined with deferred tax assets. We adopted the amendments in ASU 2013-11 in the first quarter of 2014. This update did not have a significant impact on our financial position, operating results or cash flows.

[0000926326-14-000039:notes:98]
Recently Issued Accounting Standards

[0000926326-14-000039:notes:99]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers: Topic 606 ("ASU 2014-09").  ASU 2014-09  supersedes nearly all existing revenue recognition guidance under GAAP.  The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, in doing so, it is possible more judgment and estimates may be required within the revenue recognition process than required under existing GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. Companies may use either of two methods: (i) full retrospective application to each prior reporting period presented with the option to elect certain practical expedients defined within ASU 2014-09; or (ii) modified retrospective application with the cumulative effect of initially applying ASU 2014-09 recognized at the date of initial application and providing certain additional disclosures as defined per ASU 2014-09. ASU 2014-09 is effective for us in the first quarter of 2017 and we are currently evaluating the impact of our pending adoption on our consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000926326-14-000039:notes:100]
[same as prior period, unchanged from 0000926326-14-000035:notes:87]

[0000926326-14-000039:notes:101]
[same as prior period, unchanged from 0000926326-14-000035:notes:88]

[0000926326-14-000039:notes:102]
In 2012, we acquired Medication Technologies, Inc. ("MTS"), a provider of automated and semi-automated equipment to assist institutional and retail pharmacists in filling medication orders into blister cards, the primary method of medication control in non-acute care settings. MTS is part of our Medication Adherence segment which consists of all the products we sell to fulfill medication adherence needs through blister cards, blister card packaging equipment, and related software.

[0000926326-14-000039:notes:103]
In August of 2014, we acquired Surgichem Limited ("Surgichem"), a provider of medication adherence solutions to the non-acute care market in the United Kingdom ("UK"). Surgichem supplies its monitored dosage systems to a network of over 3,200 independent pharmacies and UK pharmacy chains. Surgichem is expected to complement our Medication Adherence segment. For further information, please see Note 7, Business Acquisition.

[0000926326-14-000039:notes:104]
[same as prior period, unchanged from 0000926326-14-000035:notes:89]

[0000926326-14-000039:notes:105]
[same as prior period, unchanged from 0000926326-14-000035:notes:90]

[0000926326-14-000039:notes:106]
Concentration of credit risk. Financial instruments that may potentially subject us to concentrations of credit risk consist principally of cash equivalents and accounts receivable. Cash equivalents are maintained with several financial institutions and may exceed the amount of insurance provided on such balances. The majority of our accounts receivable are derived from sales to customers for commercial applications. We perform ongoing credit evaluations of our customers’ financial condition and limit the amount of credit extended when deemed necessary but generally require no collateral. We maintain reserves for potential credit losses. Our products are broadly distributed and there was no single customer accounting for 10% or more of revenues in the three and nine months ended September 30, 2014 and 2013. Additionally, there was no single customer accounting for 10% or more of accounts receivable at September 30, 2014 or December 31, 2013. We believe that we have no significant concentrations of credit risk at September 30, 2014.

[0000926326-14-000039:notes:107]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended September 30, 2014 and 2013 totaled approximately $11.0 million and $8.6 million, respectively, and $28.2 million and $22.5 million for the nine months ended September 30, 2014 and 2013, respectively.

[0000926326-14-000039:notes:108]
There have been no material changes in our significant accounting policies as of and for the three and nine months ended September 30, 2014, compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2013.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-14-000039:notes:109]
[same as prior period, unchanged from 0000926326-14-000035:notes:94]

[0000926326-14-000039:notes:110]
[same as prior period, unchanged from 0000926326-14-000035:notes:95]

[0000926326-14-000039:notes:111]
|  | September 30, 2014 |  | December 31, 2013 |
| Equipment | $ | 42,738 |  |  | $ | 40,180 |  |
| Furniture and fixtures | 5,663 |  |  | 5,260 |  |
| Leasehold improvements | 8,214 |  |  | 7,394 |  |
| Software | 25,536 |  |  | 20,199 |  |
| Construction in process | 3,935 |  |  | 2,649 |  |
| Total property and equipment | 86,086 |  |  | 75,682 |  |
| Accumulated depreciation and amortization | (48,398 | ) |  | (40,428 | ) |
| Total property and equipment, net | $ | 37,688 |  |  | $ | 35,254 |  |

[0000926326-14-000039:notes:112]
Depreciation and amortization expense for property and equipment was approximately $2.9 million and $2.6 million for the three months ended September 30, 2014 and 2013, respectively, and $8.2 million and $8.2 million for the nine months ended September 30, 2014 and 2013, respectively.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000926326-14-000039:notes:113]
[same as prior period, unchanged from 0000926326-14-000035:notes:98]

[0000926326-14-000039:notes:114]
|  | Three Months Ended September 30, 2014 |  | Three Months Ended September 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Total revenues | $ | 89,546 |  |  | $ | 22,997 |  |  | $ | 112,543 |  |  | $ | 75,110 |  |  | $ | 18,929 |  |  | $ | 94,039 |  |
| Cost of revenues | 38,412 |  |  | 14,585 |  |  | 52,997 |  |  | 30,240 |  |  | 11,759 |  |  | 41,999 |  |
| Gross profit | $ | 51,134 |  |  | $ | 8,412 |  |  | $ | 59,546 |  |  | $ | 44,870 |  |  | $ | 7,170 |  |  | $ | 52,040 |  |
| Gross margin % | 57.1 | % |  | 36.6 | % |  | 52.9 | % |  | 59.7 | % |  | 37.9 | % |  | 55.3 | % |
| Operating expenses | 38,662 |  |  | 7,287 |  |  | 45,949 |  |  | 35,052 |  |  | 6,271 |  |  | 41,323 |  |
| Income from operations | $ | 12,472 |  |  | $ | 1,125 |  |  | $ | 13,597 |  |  | $ | 9,818 |  |  | $ | 899 |  |  | $ | 10,717 |  |
| Operating margin % | 13.9 | % |  | 4.9 | % |  | 12.1 | % |  | 13.1 | % |  | 4.7 | % |  | 11.4 | % |
| Interest and other income (expense), net |  |  |  |  | (706 | ) |  |  |  |  |  | 25 |  |
| Income before provision for income taxes |  |  |  |  | 12,891 |  |  |  |  |  |  | 10,742 |  |
| Provision for income taxes |  |  |  |  | 5,591 |  |  |  |  |  |  | 2,987 |  |
| Net income |  |  |  |  | $ | 7,300 |  |  |  |  |  |  | $ | 7,755 |  |

[0000926326-14-000039:notes:115]
|  | Nine Months Ended September 30, 2014 |  | Nine Months Ended September 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Total revenues | $ | 255,747 |  |  | $ | 63,612 |  |  | $ | 319,359 |  |  | $ | 217,688 |  |  | $ | 57,147 |  |  | $ | 274,835 |  |
| Cost of revenues | 109,345 |  |  | 39,933 |  |  | 149,278 |  |  | 92,465 |  |  | 35,595 |  |  | 128,060 |  |
| Gross profit | $ | 146,402 |  |  | $ | 23,679 |  |  | $ | 170,081 |  |  | $ | 125,223 |  |  | $ | 21,552 |  |  | $ | 146,775 |  |
| Gross margin % | 57.2 | % |  | 37.2 | % |  | 53.3 | % |  | 57.5 | % |  | 37.7 | % |  | 53.4 | % |
| Operating expenses | 112,572 |  |  | 21,400 |  |  | 133,972 |  |  | 101,425 |  |  | 21,106 |  |  | 122,531 |  |
| Income from operations | $ | 33,830 |  |  | $ | 2,279 |  |  | $ | 36,109 |  |  | $ | 23,798 |  |  | $ | 446 |  |  | $ | 24,244 |  |
| Operating margin % | 13.2 | % |  | 3.6 | % |  | 11.3 | % |  | 10.9 | % |  | 0.8 | % |  | 8.8 | % |
| Interest and other income (expense), net |  |  |  |  | (1,003 | ) |  |  |  |  |  | (134 | ) |
| Income before provision for income taxes |  |  |  |  | 35,106 |  |  |  |  |  |  | 24,110 |  |
| Provision for income taxes |  |  |  |  | 13,824 |  |  |  |  |  |  | 6,954 |  |
| Net income |  |  |  |  | $ | 21,282 |  |  |  |  |  |  | $ | 17,156 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000926326-14-000039:notes:116]
[same as prior period, unchanged from 0000926326-14-000035:notes:101]

[0000926326-14-000039:notes:117]
|  | September 30, 2014 |  | December 31, 2013 |
| Rebates and lease buyouts | $ | 4,202 |  |  | $ | 1,699 |  |
| Advance payments from customers | 3,749 |  |  | 4,971 |  |
| Accrued Group Purchasing Organization (GPO) fees(1) | 3,314 |  |  | 2,324 |  |
| Technology license purchase obligation, current portion | 250 |  |  | 1,500 |  |
| Taxes payable | 3,159 |  |  | 1,664 |  |
| Other | 2,399 |  |  | 1,588 |  |
| Total | $ | 17,073 |  |  | $ | 13,746 |  |


## us-gaap:ScheduleOfCreditLossesRelatedToFinancingReceivablesNoncurrentTableTextBlock

[0000926326-14-000039:notes:118]
[same as prior period, unchanged from 0000926326-14-000035:notes:103]

[0000926326-14-000039:notes:119]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Allowance for credit losses, beginning of period | $ | 157 |  |  | $ | 184 |  |  | $ | 167 |  |  | $ | 607 |  |
| Current period provision (reversal) | (6 | ) |  | 15 |  |  | (16 | ) |  | 34 |  |
| Direct write-downs charged against the allowance | — |  |  | — |  |  | — |  |  | (413 | ) |
| Recoveries of amounts previously charged off | — |  |  | (25 | ) |  | — |  |  | (54 | ) |
| Allowance for credit losses, end of period | $ | 151 |  |  | $ | 174 |  |  | $ | 151 |  |  | $ | 174 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000926326-14-000039:notes:120]
The minimum lease payments under sales-type leases as of September 30, 2014 were as follows (in thousands):

[0000926326-14-000039:notes:121]
| Remainder of 2014 | $ | 1,614 |  |
| 2015 | 5,746 |  |
| 2016 | 4,412 |  |
| 2017 | 3,465 |  |
| 2018 | 1,889 |  |
| Thereafter | 370 |  |
| Total | $ | 17,496 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-14-000039:notes:122]
[same as prior period, unchanged from 0000926326-14-000035:notes:107]

[0000926326-14-000039:notes:123]
|  | Three Months Ended September 30, 2014 |  | Three Months Ended September 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Depreciation and amortization | $ | 3,460 |  |  | $ | 1,854 |  |  | $ | 5,314 |  |  | $ | 2,805 |  |  | $ | 1,683 |  |  | $ | 4,488 |  |
| Capital expenditures | $ | 2,635 |  |  | $ | 785 |  |  | $ | 3,420 |  |  | $ | 1,311 |  |  | $ | 745 |  |  | $ | 2,056 |  |

[0000926326-14-000039:notes:124]
|  | Nine Months Ended September 30, 2014 |  | Nine Months Ended September 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Depreciation and amortization | $ | 9,402 |  |  | $ | 5,303 |  |  | $ | 14,705 |  |  | $ | 8,351 |  |  | $ | 5,381 |  |  | $ | 13,732 |  |
| Capital expenditures | $ | 8,802 |  |  | $ | 1,953 |  |  | $ | 10,755 |  |  | $ | 3,329 |  |  | $ | 4,478 |  |  | $ | 7,807 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-14-000039:notes:125]
[same as prior period, unchanged from 0000926326-14-000035:notes:110]

[0000926326-14-000039:notes:126]
Prior to the first quarter of 2014, we organized our business into two operating business segments, the Acute Care and Non-Acute Care segments, which were based on the target customers for our products. The Acute Care segment primarily included products and services sold to hospital customers, and the Non-Acute Care segment primarily included products and services sold to customers outside of hospital settings.

[0000926326-14-000039:notes:127]
[same as prior period, unchanged from 0000926326-14-000035:notes:112]

[0000926326-14-000039:notes:128]
[same as prior period, unchanged from 0000926326-14-000035:notes:113]

[0000926326-14-000039:notes:129]
[same as prior period, unchanged from 0000926326-14-000035:notes:114]

[0000926326-14-000039:notes:130]
[same as prior period, unchanged from 0000926326-14-000035:notes:115]

[0000926326-14-000039:notes:131]
[same as prior period, unchanged from 0000926326-14-000035:notes:116]

[0000926326-14-000039:notes:132]
[same as prior period, unchanged from 0000926326-14-000035:notes:117]

[0000926326-14-000039:notes:133]
In August of 2014, we acquired Surgichem. Based in Stockport, UK, Surgichem is a provider of medication adherence packaging solutions to the UK care home and domiciliary care markets since 1989. Surgichem supplies its monitored dosage systems to a network of over 3,200 independent pharmacies and UK pharmacy chains. Surgichem is part of our Medication Adherence segment.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-14-000039:notes:134]
[same as prior period, unchanged from 0000926326-14-000035:notes:118]

[0000926326-14-000039:notes:135]
[same as prior period, unchanged from 0000926326-14-000035:notes:119]

[0000926326-14-000039:notes:136]
[same as prior period, unchanged from 0000926326-14-000035:notes:120]

[0000926326-14-000039:notes:137]
On August 1, 2012, our Board of Directors established a stock repurchase program (the “2012 Repurchase Program”) authorizing share repurchases of up to $50.0 million of our common stock, with no termination date. The timing, price and volume of repurchases are to be based on market conditions, relevant securities laws and other factors. The stock repurchases may be made from time to time on the open market, in privately negotiated transactions or pursuant to a Rule 10b-18 plan. The 2012 Repurchase Program does not obligate us to repurchase any specific number of shares, and we may terminate or suspend the repurchase program at any time.

[0000926326-14-000039:notes:138]
For the nine months ended September 30, 2014, we repurchased a total of $19.6 million, or 721,101 shares, at an average cost of $27.23, including commissions. Of the repurchase activity, $2.6 million settled in October of 2014. For details regarding the 2012 Repurchase Program, please refer to Note 15, Stockholders' Equity, of our Annual Report on Form 10-K for the year ended December 31, 2013.

[0000926326-14-000039:notes:139]
From the inception of the 2012 Repurchase Program, we have repurchased a total of $40.6 million, or 1,605,746 shares at an average cost of $25.28 per share, including commissions. As of September 30, 2014, the maximum dollar value of shares that may yet be purchased under the plan is $9.4 million.


## omcl:AccruedLiabilitiesTextBlock

[0000926326-14-000039:notes:140]
[same as prior period, unchanged from 0000926326-14-000035:notes:124]

[0000926326-14-000039:notes:141]
[same as prior period, unchanged from 0000926326-14-000035:notes:125]


## omcl:DeferredGrossProfitTableTextBlock

[0000926326-14-000039:notes:142]
[same as prior period, unchanged from 0000926326-14-000035:notes:126]

[0000926326-14-000039:notes:143]
|  | September 30, 2014 |  | December 31, 2013 |
| Sales of medication and supply dispensing systems and packaging equipment(1) | $ | 48,669 |  |  | $ | 29,040 |  |
| Cost of revenues, excluding installation costs | (13,127 | ) |  | (9,083 | ) |
| Deferred gross profit | $ | 35,542 |  |  | $ | 19,957 |  |


## omcl:DeferredGrossProfitTextBlock

[0000926326-14-000039:notes:144]
[same as prior period, unchanged from 0000926326-14-000035:notes:128]

[0000926326-14-000039:notes:145]
[same as prior period, unchanged from 0000926326-14-000035:notes:129]


## omcl:ImpairmentofSoftwareDevelopmentCostsTextBlock

[0000926326-14-000039:notes:146]
[same as prior period, unchanged from 0000926326-14-000035:notes:130]

[0000926326-14-000039:notes:147]
[same as prior period, unchanged from 0000926326-14-000035:notes:131]

[0000926326-14-000039:notes:148]
As part of the continuing integration of MTS, in the first quarter of 2013, we reorganized our management team, including the software development department, within the Medication Adherence segment (formerly known as our Non-Acute segment). Through the end of the first quarter of 2013, the Medication Adherence segment had capitalized approximately $1.8 million of software development costs associated with a software solution under development which was intended to assist pharmacies in manual packaging of prescriptions. In connection with our financial statement close process for the quarter ended March 31, 2013, our management reassessed the viability of this project and the net realizable value of capitalized costs in light of its decision to change the related product road map and redesign this product based on evolving market demands. As part of this redesign process, new functionality and capabilities will need to be added to the product before commercialization. This redesign is intended to provide a more robust global platform providing larger scalability and significant functionality not contained in our current beta version. As such, we determined we can no longer support the technological feasibility of this project in conjunction with our software capitalization policy. Therefore, we charged these costs, in the amount of $1.8 million, ($0.03 per diluted share, net of tax), to expense as a component of research and development in the accompanying condensed consolidated statement of operations.


## omcl:NetInvestmentsInSalesTypeLeasesTextBlock

[0000926326-14-000039:notes:149]
[same as prior period, unchanged from 0000926326-14-000035:notes:133]

[0000926326-14-000039:notes:150]
[same as prior period, unchanged from 0000926326-14-000035:notes:134]

[0000926326-14-000039:notes:151]
|  | September 30, 2014 |  | December 31, 2013 |
| Net minimum lease payments to be received | $ | 17,496 |  |  | $ | 18,172 |  |
| Less unearned interest income portion | (1,108 | ) |  | (1,455 | ) |
| Net investment in sales-type leases | 16,388 |  |  | 16,717 |  |
| Less current portion | (5,565 | ) |  | (5,232 | ) |
| Non-current net investment in sales-type leases | $ | 10,823 |  |  | $ | 11,485 |  |
