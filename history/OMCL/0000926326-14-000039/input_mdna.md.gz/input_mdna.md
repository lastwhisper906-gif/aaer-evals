# OMCL MD&A — 0000926326-14-000039


## mdna

[0000926326-14-000039:mdna:1]
[same as prior period, unchanged from 0000926326-14-000035:mdna:1]

[0000926326-14-000039:mdna:2]
[same as prior period, unchanged from 0000926326-14-000035:mdna:2]

[0000926326-14-000039:mdna:3]
[same as prior period, unchanged from 0000926326-14-000035:mdna:3]

[0000926326-14-000039:mdna:4]
[same as prior period, unchanged from 0000926326-14-000035:mdna:4]

[0000926326-14-000039:mdna:5]
[same as prior period, unchanged from 0000926326-14-000035:mdna:5]

[0000926326-14-000039:mdna:6]
[same as prior period, unchanged from 0000926326-14-000035:mdna:6]

[0000926326-14-000039:mdna:7]
[same as prior period, unchanged from 0000926326-14-000035:mdna:7]

[0000926326-14-000039:mdna:8]
[same as prior period, unchanged from 0000926326-14-000035:mdna:8]

[0000926326-14-000039:mdna:9]
[same as prior period, unchanged from 0000926326-14-000035:mdna:9]

[0000926326-14-000039:mdna:10]
[same as prior period, unchanged from 0000926326-14-000035:mdna:10]

[0000926326-14-000039:mdna:11]
[same as prior period, unchanged from 0000926326-14-000035:mdna:11]

[0000926326-14-000039:mdna:12]
[same as prior period, unchanged from 0000926326-14-000035:mdna:12]

[0000926326-14-000039:mdna:13]
[same as prior period, unchanged from 0000926326-14-000035:mdna:13]

[0000926326-14-000039:mdna:14]
[same as prior period, unchanged from 0000926326-14-000035:mdna:14]

[0000926326-14-000039:mdna:15]
We are a leading provider of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum, from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home. Our Omnicell Automation and Analytic customers worldwide have utilized medication automation, supply chain and analytics solutions to enable them to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety.

[0000926326-14-000039:mdna:16]
Omnicell Medication Adherence solutions, including the MTS brand, provide innovative medication adherence packaging solutions that can help reduce costly hospital readmissions and enable institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0000926326-14-000039:mdna:17]
We sell our product and consumable solutions together with related service offerings. Total revenue for the United States and Canada generated approximately 90% of our total revenues and we expect our revenues from international operations to increase in future periods as we continue to grow our international business. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-14-000039:mdna:18]
[same as prior period, unchanged from 0000926326-14-000035:mdna:16]

[0000926326-14-000039:mdna:19]
[same as prior period, unchanged from 0000926326-14-000035:mdna:17]

[0000926326-14-000039:mdna:20]
Our Automation and Analytics segment has been the predominant market for our products since our inception in 1992 and today comprises approximately 80% of our overall business. The Medication Adherence segment became a significant portion of our business in May 2012, when we completed our acquisition of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems. The acquisition aligned us with the long-term trends of the healthcare market to manage the health of patients across the continuum of care. The combination of Omnicell and MTS brought capabilities to each other that strengthened the product lines and expanded the medication management coverage of both companies. As our business evolves, we will continue to assess our segments which could result in future modifications to the current presentation.

[0000926326-14-000039:mdna:21]
[same as prior period, unchanged from 0000926326-14-000035:mdna:19]

[0000926326-14-000039:mdna:22]
| • | Development of differentiated products. We invest in the development of products that we believe bring patient safety and workflow efficiency to our customers’ operations that they cannot get from other competing solutions. These differentiators may be as small as how a transaction operates or the information provided on a report or as large as the entire automation of a workflow that would otherwise be completed manually. We intend to continue our focus on differentiating our products, and we carefully assess our investments regularly as we strive to assure those investments provide the solutions most valuable to our customers. |

[0000926326-14-000039:mdna:23]
| • | Deliver our solutions to new markets. Areas of healthcare where work is done manually may benefit from our existing solutions. These areas include hospitals that continue to use manual operations, healthcare segments of the US market outside hospitals, and markets outside the United States. We weigh the cost of entering these new markets against the expected benefits, and focus on the markets that we believe are most likely to adopt our products. |

[0000926326-14-000039:mdna:24]
| • | Expansion of our solutions through acquisitions and partnerships. Our acquisitions have generally been focused on automation of manual workflows or on data analytics, which is the enhancement of data for our customers’ decision-making processes. We believe that expansion of our product lines through acquisition and partnerships to meet our customers changing and evolving expectations is a key aspect to our historical and future success. |

[0000926326-14-000039:mdna:25]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, we began shipping a refresh of our product line in 2011, which we market as G4. The G4 refresh included multiple new products and an upgrade product that allowed existing customers to augment their installations to obtain the most current technology that we provide. The G4 product refresh has been a key contributor to our growth, with 54% of our automation and analytics installed base ordering upgrades to their existing systems since the announcement of G4. In addition to enhanced capabilities, we have focused on attaining the highest quality and service measurements for G4 in the industry, while marketing the solution to new and existing customers. Our research and development efforts today are designed to bring new products to market beyond the G4 product line that we believe will meet customer needs in years to come.

[0000926326-14-000039:mdna:26]
Consistent with our strategy to enter new markets, we have made investments in our selling, general and administrative expenses to expand our sales team and market to new customers. Our international efforts have focused primarily on three markets: China, where we made a Mandarin version of our automated dispensing systems available in 2011,

[0000926326-14-000039:mdna:27]
the Middle Eastern countries of the Arabian Peninsula where new healthcare facility construction is taking place, and in the United Kingdom where, in the third quarter of 2012, we purchased 15% of our United Kingdom distributor’s outstanding equity for approximately $0.9 million in cash to accelerate the adoption of medication and supply automation. In connection with the investment, we have the right, under certain circumstances, to appoint a member to this company's board of directors as well as certain other voting rights and, therefore, we believe we have the ability to exert significant influence over this distributor's operations. Our proportionate equity share of the income of this distributor recognized in our financial statements for the three and nine months ended September 30, 2014 was immaterial. We have also expanded our sales efforts to medication adherence customers in the United States which has allowed us to sell our automated dispensing solutions and other products to this market.

[0000926326-14-000039:mdna:28]
Expansion of our solutions through acquisitions and partnerships include our acquisition of MTS in 2012 and our acquisition of Surgichem Limited ("Surgichem") in August 2014. Surgichem is a provider of medication adherence products in the United Kingdom. The Surgichem acquisition is expected to enable both Omnicell and Surgichem to sell their lines of proven multi- and single-dose products across a broader medication adherence packaging market in the United Kingdom. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-14-000039:mdna:29]
[same as prior period, unchanged from 0000926326-14-000035:mdna:28]

[0000926326-14-000039:mdna:30]
| • | Our expectation that the overall market demand for healthcare services will increase as the population grows, life expectancies continue to increase, and the quality and availability of healthcare services increases; |

[0000926326-14-000039:mdna:31]
| • | Our expectation that the environment of increased patient safety awareness, increased regulatory control, increased demand for innovative products that improve the care experience, and increased need for workflow efficiency through the adoption of technology in the healthcare industry will make our solutions a priority in the capital budgets of healthcare facilities; and |

[0000926326-14-000039:mdna:32]
[same as prior period, unchanged from 0000926326-14-000035:mdna:31]

[0000926326-14-000039:mdna:33]
[same as prior period, unchanged from 0000926326-14-000035:mdna:32]

[0000926326-14-000039:mdna:34]
[same as prior period, unchanged from 0000926326-14-000035:mdna:33]

[0000926326-14-000039:mdna:35]
The growth in our Automation and Analytics revenue for the three and nine months ended September 30, 2014 was driven primarily by our success in consistently growing the number of our customer installations. Installed customers grew from 1,806 hospitals as of September 30, 2013 to 1,897 hospitals as of September 30, 2014. To a lesser extent, but of equal importance, revenue growth was also driven by our success in upgrading installed customers to newer G4 technology, which is in line with our strategy of striving to deliver differentiated innovation in our solutions. Our larger installed base has provided growth opportunities and, as a result, our service revenues have also grown for the nine months ended September 30, 2014.

[0000926326-14-000039:mdna:36]
The growth in our Medication Adherence revenue for the three and nine months ended September 30, 2014 was driven primarily by increased sales of our OnDemand medication packaging systems in the United States market and increased adoption of multi-medication adherence solutions used by patients in assisted living or home care in Europe. This growth is in line with our strategy to deliver solutions to markets outside the United States. On a geographic basis, the United States market did not contribute to, nor erode, the growth in our Medication Adherence business as the population of patients living in nursing homes in the United States has remained relatively constant over the past twelve months.

[0000926326-14-000039:mdna:37]
We strive to provide the best service possible, as measured by third party rating agencies and by our own surveys. Our long-term liabilities include long-term deferred service revenue of $20 million and $18 million as of September 30, 2014 and

[0000926326-14-000039:mdna:38]
December 31, 2013, respectively. Our deferred service revenue will be amortized to service revenue as the service contracts are performed upon.

[0000926326-14-000039:mdna:39]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but our focus will remain on improving healthcare with solutions that improve patient and provider outcomes. We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue. For the remainder of 2014, we also intend to continue to manage our business to operating profit margins similar to what we have achieved in the nine months ended September 30, 2014.

[0000926326-14-000039:mdna:40]
33

[0000926326-14-000039:mdna:41]
[same as prior period, unchanged from 0000926326-14-000035:mdna:40]

[0000926326-14-000039:mdna:42]
The table below shows the components of our consolidated results of operations as percentages of total revenues for the three and nine months ended September 30, 2014 and 2013 (in thousands, except percentages):

[0000926326-14-000039:mdna:43]
|  | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
|  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 92,229 |  |  | 82.0 | % |  | $ | 75,508 |  |  | 80.3 | % |
| Service and other revenues | 20,314 |  |  | 18.0 | % |  | 18,531 |  |  | 19.7 | % |
| Total revenues | 112,543 |  |  | 100.0 | % |  | 94,039 |  |  | 100.0 | % |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 44,510 |  |  | 39.6 | % |  | 33,977 |  |  | 36.1 | % |
| Cost of service and other revenues | 8,487 |  |  | 7.5 | % |  | 8,022 |  |  | 8.5 | % |
| Total cost of revenues | 52,997 |  |  | 47.1 | % |  | 41,999 |  |  | 44.6 | % |
| Gross profit | 59,546 |  |  | 52.9 | % |  | 52,040 |  |  | 55.4 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 7,078 |  |  | 6.3 | % |  | 6,561 |  |  | 7.0 | % |
| Selling, general and administrative | 38,871 |  |  | 34.5 | % |  | 34,762 |  |  | 37.0 | % |
| Total operating expenses | 45,949 |  |  | 40.8 | % |  | 41,323 |  |  | 44.0 | % |
| Income from operations | 13,597 |  |  | 12.1 | % |  | 10,717 |  |  | 11.4 | % |
| Interest and other income (expense), net | (706 | ) |  | (0.6 | )% |  | 25 |  |  | — | % |
| Income before provision for income taxes | 12,891 |  |  | 11.5 | % |  | 10,742 |  |  | 11.4 | % |
| Provision for income taxes | 5,591 |  |  | 5.0 | % |  | 2,987 |  |  | 3.2 | % |
| Net income | $ | 7,300 |  |  | 6.5 | % |  | $ | 7,755 |  |  | 8.2 | % |

[0000926326-14-000039:mdna:44]
|  | Nine Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
|  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 260,053 |  |  | 81.4 | % |  | $ | 220,325 |  |  | 80.2 | % |
| Service and other revenues | 59,306 |  |  | 18.6 | % |  | 54,510 |  |  | 19.8 | % |
| Total revenues | 319,359 |  |  | 100.0 | % |  | 274,835 |  |  | 100.0 | % |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 124,413 |  |  | 39.0 | % |  | 103,810 |  |  | 37.8 | % |
| Cost of service and other revenues | 24,865 |  |  | 7.7 | % |  | 24,250 |  |  | 8.8 | % |
| Total cost of revenues | 149,278 |  |  | 46.7 | % |  | 128,060 |  |  | 46.6 | % |
| Gross profit | 170,081 |  |  | 53.3 | % |  | 146,775 |  |  | 53.4 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 19,670 |  |  | 6.2 | % |  | 21,665 |  |  | 7.9 | % |
| Selling, general and administrative | 114,302 |  |  | 35.8 | % |  | 100,866 |  |  | 36.7 | % |
| Total operating expenses | 133,972 |  |  | 42.0 | % |  | 122,531 |  |  | 44.6 | % |
| Income from operations | 36,109 |  |  | 11.3 | % |  | 24,244 |  |  | 8.9 | % |
| Interest and other income (expense), net | (1,003 | ) |  | (0.3 | )% |  | (134 | ) |  | — | % |
| Income before provision for income taxes | 35,106 |  |  | 11.0 | % |  | 24,110 |  |  | 8.9 | % |
| Provision for income taxes | 13,824 |  |  | 4.3 | % |  | 6,954 |  |  | 2.5 | % |
| Net income | $ | 21,282 |  |  | 6.7 | % |  | $ | 17,156 |  |  | 6.4 | % |

[0000926326-14-000039:mdna:45]
[same as prior period, unchanged from 0000926326-14-000035:mdna:45]

[0000926326-14-000039:mdna:46]
35

[0000926326-14-000039:mdna:47]
Operations by Segment During the Three and Nine Months Ended September 30, 2014

[0000926326-14-000039:mdna:48]
|  | Three Months Ended September 30, 2014 |  | Three Months Ended September 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Total revenues | $ | 89,546 |  |  | $ | 22,997 |  |  | $ | 112,543 |  |  | $ | 75,110 |  |  | $ | 18,929 |  |  | $ | 94,039 |  |
| Cost of revenues | 38,412 |  |  | 14,585 |  |  | 52,997 |  |  | 30,240 |  |  | 11,759 |  |  | 41,999 |  |
| Gross profit | 51,134 |  |  | 8,412 |  |  | 59,546 |  |  | 44,870 |  |  | 7,170 |  |  | 52,040 |  |
| Gross margin % | 57.1 | % |  | 36.6 | % |  | 52.9 | % |  | 59.7 | % |  | 37.9 | % |  | 55.3 | % |
| Operating expenses | 38,662 |  |  | 7,287 |  |  | 45,949 |  |  | 35,052 |  |  | 6,271 |  |  | 41,323 |  |
| Income from operations | $ | 12,472 |  |  | $ | 1,125 |  |  | $ | 13,597 |  |  | $ | 9,818 |  |  | $ | 899 |  |  | $ | 10,717 |  |
| Operating margin % | 13.9 | % |  | 4.9 | % |  | 12.1 | % |  | 13.1 | % |  | 4.7 | % |  | 11.4 | % |

[0000926326-14-000039:mdna:49]
Total revenues grew approximately 19.7% for the three months ended September 30, 2014 compared with the same period last year. Overall product and service gross margins decreased by approximately 2.4% for the three months ended September 30, 2014 compared to the same period in 2013 primarily due to the timing of installations of larger, lower margin new customers. Income from operations increased primarily due to increase in revenues and improved efficiency in operating expenses.

[0000926326-14-000039:mdna:50]
|  | Nine Months Ended September 30, 2014 |  | Nine Months Ended September 30, 2013 |
|  | Automation and Analytics |  | Medication Adherence |  | Total |  | Automation and Analytics |  | Medication Adherence |  | Total |
| Total revenues | $ | 255,747 |  |  | $ | 63,612 |  |  | $ | 319,359 |  |  | $ | 217,688 |  |  | $ | 57,147 |  |  | $ | 274,835 |  |
| Cost of revenues | 109,345 |  |  | 39,933 |  |  | 149,278 |  |  | 92,465 |  |  | 35,595 |  |  | 128,060 |  |
| Gross profit | 146,402 |  |  | 23,679 |  |  | 170,081 |  |  | 125,223 |  |  | 21,552 |  |  | 146,775 |  |
| Gross margin % | 57.2 | % |  | 37.2 | % |  | 53.3 | % |  | 57.5 | % |  | 37.7 | % |  | 53.4 | % |
| Operating expenses | 112,572 |  |  | 21,400 |  |  | 133,972 |  |  | 101,425 |  |  | 21,106 |  |  | 122,531 |  |
| Income from operations | $ | 33,830 |  |  | $ | 2,279 |  |  | $ | 36,109 |  |  | $ | 23,798 |  |  | $ | 446 |  |  | $ | 24,244 |  |
| Operating margin % | 13.2 | % |  | 3.6 | % |  | 11.3 | % |  | 10.9 | % |  | 0.8 | % |  | 8.8 | % |

[0000926326-14-000039:mdna:51]
Total revenues grew approximately 16.2% for the nine months ended September 30, 2014 compared with the same period last year. Overall product and service gross margins decreased by approximately 0.1 % for the nine months ended September 30, 2014 compared to the same period in 2013. Income from operations increased by $11.9 million, primarily through increased sales and efficiency in operating expense.

[0000926326-14-000039:mdna:52]
[same as prior period, unchanged from 0000926326-14-000035:mdna:52]

[0000926326-14-000039:mdna:53]
Management's discussion and analysis of our financial condition and results of operations are based on our consolidated financial statements, which have been prepared in accordance with U.S. GAAP. The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe that the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our condensed consolidated financial statements:

[0000926326-14-000039:mdna:54]
[same as prior period, unchanged from 0000926326-14-000035:mdna:56]

[0000926326-14-000039:mdna:55]
[same as prior period, unchanged from 0000926326-14-000035:mdna:57]

[0000926326-14-000039:mdna:56]
[same as prior period, unchanged from 0000926326-14-000035:mdna:58]

[0000926326-14-000039:mdna:57]
[same as prior period, unchanged from 0000926326-14-000035:mdna:59]

[0000926326-14-000039:mdna:58]
[same as prior period, unchanged from 0000926326-14-000035:mdna:60]

[0000926326-14-000039:mdna:59]
During the nine months ended September 30, 2014, there were no significant changes in our critical accounting policies and estimates.

[0000926326-14-000039:mdna:60]
[same as prior period, unchanged from 0000926326-14-000035:mdna:62]

[0000926326-14-000039:mdna:61]
[same as prior period, unchanged from 0000926326-14-000035:mdna:63]

[0000926326-14-000039:mdna:62]
[same as prior period, unchanged from 0000926326-14-000035:mdna:64]

[0000926326-14-000039:mdna:63]
38

[0000926326-14-000039:mdna:64]
[same as prior period, unchanged from 0000926326-14-000035:mdna:66]

[0000926326-14-000039:mdna:65]
[same as prior period, unchanged from 0000926326-14-000035:mdna:67]

[0000926326-14-000039:mdna:66]
[same as prior period, unchanged from 0000926326-14-000035:mdna:68]

[0000926326-14-000039:mdna:67]
|  |  | Three Months Ended September 30, |  | Change in |  |
|  |  | 2014 |  | 2013 |  | $ |  | % |  |
| Product Revenue |  | $ | 69,942 |  |  | $ | 57,385 |  |  | $ | 12,557 |  |  | 21.9 |  | % |
| Service Revenue |  | 19,604 |  |  | 17,725 |  |  | 1,879 |  |  | 10.6 |  | % |
| Total revenues |  | 89,546 |  |  | 75,110 |  |  | 14,436 |  |  | 19.2 |  | % |
| Product Cost |  | 30,594 |  |  | 22,794 |  |  | 7,800 |  |  | 34.2 |  | % |
| Service Cost |  | 7,818 |  |  | 7,446 |  |  | 372 |  |  | 5.0 |  | % |
| Total cost of revenues |  | 38,412 |  |  | 30,240 |  |  | 8,172 |  |  | 27.0 |  | % |
| Product Margin |  | 39,348 |  |  | 34,590 |  |  | 4,758 |  |  | 13.8 |  | % |
| Service Margin |  | 11,786 |  |  | 10,279 |  |  | 1,507 |  |  | 14.7 |  | % |
| Gross profit |  | $ | 51,134 |  |  | $ | 44,870 |  |  | $ | 6,264 |  |  | 14.0 |  | % |
| Gross margin % |  | 57.1 | % |  | 59.7 | % |  |  |  | (2.6 | ) |  |

[0000926326-14-000039:mdna:68]
|  |  | Nine Months Ended September 30, |  | Change in |  |
|  |  | 2014 |  | 2013 |  | $ |  | % |  |
| Product Revenue |  | $ | 198,785 |  |  | $ | 165,544 |  |  | $ | 33,241 |  |  | 20.1 |  | % |
| Service Revenue |  | 56,962 |  |  | 52,144 |  |  | 4,818 |  |  | 9.2 |  | % |
| Total revenues |  | 255,747 |  |  | 217,688 |  |  | 38,059 |  |  | 17.5 |  | % |
| Product Cost |  | 86,326 |  |  | 69,978 |  |  | 16,348 |  |  | 23.4 |  | % |
| Service Cost |  | 23,019 |  |  | 22,487 |  |  | 532 |  |  | 2.4 |  | % |
| Total cost of revenues |  | 109,345 |  |  | 92,465 |  |  | 16,880 |  |  | 18.3 |  | % |
| Product Margin |  | 112,459 |  |  | 95,566 |  |  | 16,893 |  |  | 17.7 |  | % |
| Service Margin |  | 33,943 |  |  | 29,657 |  |  | 4,286 |  |  | 14.5 |  | % |
| Gross profit |  | $ | 146,402 |  |  | $ | 125,223 |  |  | $ | 21,179 |  |  | 16.9 |  | % |
| Gross margin % |  | 57.2 | % |  | 57.5 | % |  |  |  | (0.3 | ) |  |

[0000926326-14-000039:mdna:69]
[same as prior period, unchanged from 0000926326-14-000035:mdna:71]

[0000926326-14-000039:mdna:70]
The year over year growth in total revenues in our Automation and Analytics segment was driven primarily by our success in growing the number of our customer installations. We have historically measured the growth in our customer installations by the number of hospital installations. In the United States, our hospital installations grew from 1,806 as of September 30, 2013 to 1,897 as of September 30, 2014. To a lesser extent, but of equal importance, the segment's revenue growth was driven by success in upgrading installed customers to newer G4 technology, which is in line with our strategy of continually striving to deliver differentiated innovation in our solutions. Our larger installed base has provided growth opportunities for expansion of installations and, as a result, our service revenues have also grown for the nine months ended September 30, 2014.

[0000926326-14-000039:mdna:71]
The growth in product revenue for the three months ended September 30, 2014 was primarily driven by a $10.5 million increase due to new installations of medication cabinets and, to a lesser extent, of supply cabinets, a $1.0 million increase in revenue associated with freight due to the aforementioned increase in installations of medication cabinets, and a $0.7 million increase in revenues from other software products and lease renewals. The growth in service revenue for the three months ended September 30, 2014 was driven by the increase in our installed base.

[0000926326-14-000039:mdna:72]
The growth in product revenue for the nine months ended September 30, 2014 was primarily driven by a $25.3 million increase in new installations of medication cabinets as we continue to see a robust pipeline and increase in bookings as compared to same period last year and a $4.8 million increase in revenue from supply cabinets due to increased demand, a $1.3 million increase in revenue associated with freight due to the aforementioned increase in installations of medication cabinets, a $1.2 million increase in revenue from other software products and a $0.8 million net increase associated with other product sales. The growth in service revenue for the nine months ended September 30, 2014 was driven by the increase in our installed base which led to an increase in service renewal.

[0000926326-14-000039:mdna:73]
Cost of Revenues. Cost of revenues and related margins have slight variations between products. Product cost of revenue has three general categories: (i) standard product costs - accounts for the majority of the product cost of revenues that are provided to customers and are inclusive of purchased material, labor to build the product, and overhead costs associated with production; (ii) installation costs - because Omnicell installs its equipment at the customer site, these are costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs - these costs include variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory and amortization of software development costs as product costs.

[0000926326-14-000039:mdna:74]
The increase in product costs for the three months ended September 30, 2014 was primarily driven by increased revenue due to the growth in customer installations, which accounted for $5.8 million of the increase. To a lesser extent, the increase in product costs was due to a change in customer mix, as we installed more competitive conversion customers, which typically carry a lower gross margin. Installation costs also increased by $0.8 million and amortization of capitalized software increased by $1.2 million. Service costs decreased slightly for the three months ended September 30, 2014 compared to the same period last year.

[0000926326-14-000039:mdna:75]
The increase in product costs for the nine months ended September 30, 2014 was primarily driven by increased revenue due to the growth in customer installations, which accounted for $13.6 million of the increase. To a lesser extent, the increase in product costs was due to a change in customer mix, as we installed more competitive conversion customers, which carry a lower gross margin. Installation costs also increased by $2.2 million and amortization of capitalized software increased by $0.8 million. Service costs remained relatively flat for the nine months ended September 30, 2014, as we were able to service a larger installed base with the same resources.

[0000926326-14-000039:mdna:76]
Gross Profit. Gross profit dollars on product revenue increased during the three months ended September 30, 2014 as a result of the overall increase in product revenue offset by a higher mix of large competitive conversion installations, which typically carry a lower gross margin. The increase in gross profit on service revenue for the three months ended September 30, 2014 reflects higher service revenues without a consistent increase in service staffing or spare parts usage. This increased efficiency is a result of higher reliability rates of our G4 product platform as compared to previous products.

[0000926326-14-000039:mdna:77]
Gross profit on product revenue increased during the nine months ended September 30, 2014 as a result of the overall increase in product revenue and a relatively consistent growth in costs. The increase in gross profit on service revenue for the nine months ended September 30, 2014 reflects higher service revenues without a consistent increase in service staffing or spare parts usage. This improved efficiency is a result of higher reliability rates of our G4 product platform as compared to previous products.

[0000926326-14-000039:mdna:78]
[same as prior period, unchanged from 0000926326-14-000035:mdna:80]

[0000926326-14-000039:mdna:79]
[same as prior period, unchanged from 0000926326-14-000035:mdna:81]

[0000926326-14-000039:mdna:80]
|  |  | Three Months Ended September 30, |  | Change in |  |
|  |  | 2014 |  | 2013 |  | $ |  | % |  |
| Product Revenue |  | $ | 22,287 |  |  | $ | 18,124 |  |  | $ | 4,163 |  |  | 23.0 |  | % |
| Service Revenue |  | 710 |  |  | 806 |  |  | (96 | ) |  | (11.9 | ) | % |
| Total revenues |  | 22,997 |  |  | 18,929 |  |  | 4,068 |  |  | 21.5 |  | % |
| Product Cost |  | 13,916 |  |  | 11,183 |  |  | 2,733 |  |  | 24.4 |  | % |
| Service Cost |  | 669 |  |  | 576 |  |  | 93 |  |  | 16.1 |  | % |
| Total cost of revenues |  | 14,585 |  |  | 11,759 |  |  | 2,826 |  |  | 24.0 |  | % |
| Product Margin |  | 8,371 |  |  | 6,941 |  |  | 1,430 |  |  | 20.6 |  | % |
| Service Margin |  | 41 |  |  | 230 |  |  | (189 | ) |  | (82.2 | ) | % |
| Gross profit |  | $ | 8,412 |  |  | $ | 7,170 |  |  | $ | 1,242 |  |  | 17.3 |  | % |
| Gross margin % |  | 36.6 | % |  | 37.9 | % |  |  |  | (1.3 | ) |  |

[0000926326-14-000039:mdna:81]
|  |  | Nine Months Ended September 30, |  | Change in |  |
|  |  | 2014 |  | 2013 |  | $ |  | % |  |
| Product Revenue |  | $ | 61,268 |  |  | $ | 54,781 |  |  | $ | 6,487 |  |  | 11.8 |  | % |
| Service Revenue |  | 2,344 |  |  | 2,366 |  |  | (22 | ) |  | (0.9 | ) | % |
| Total revenues |  | 63,612 |  |  | 57,147 |  |  | 6,465 |  |  | 11.3 |  | % |
| Product Cost |  | 38,087 |  |  | 33,832 |  |  | 4,255 |  |  | 12.6 |  | % |
| Service Cost |  | 1,846 |  |  | 1,763 |  |  | 83 |  |  | 4.7 |  | % |
| Total cost of revenues |  | 39,933 |  |  | 35,595 |  |  | 4,338 |  |  | 12.2 |  | % |
| Product Margin |  | 23,181 |  |  | 20,949 |  |  | 2,232 |  |  | 10.7 |  | % |
| Service Margin |  | 498 |  |  | 603 |  |  | (105 | ) |  | (17.4 | ) | % |
| Gross profit |  | $ | 23,679 |  |  | $ | 21,552 |  |  | $ | 2,127 |  |  | 9.9 |  | % |
| Gross margin % |  | 37.2 | % |  | 37.7 | % |  |  |  |  | (0.5 | ) |  |

[0000926326-14-000039:mdna:82]
[same as prior period, unchanged from 0000926326-14-000035:mdna:84]

[0000926326-14-000039:mdna:83]
The increase in product revenue for the three months ended September 30, 2014 was primarily due to a $2.8 million increase in sales of our multi-medication consumable products in Europe, a $0.3 million increase in sales of packaging equipment and a $1.0 million increase in sales of medication adherence consumables in the United States, which we believe to be driven by customer timing of orders. Service revenue was down slightly due to the transition of a number of customers from annual service contracts to service by time and material, which we expect to provide less consistent stream of service revenue.

[0000926326-14-000039:mdna:84]
The growth in product revenues for the nine months ended September 30, 2014 was primarily due to a $4.6 million increase in adoption of our multi-medication consumable products in Europe, an approximately $1.3 million increase in sales of OnDemand medication packaging systems, and a $0.5 million increase in other sales medication adherence consumable products. Service revenue remained relatively flat and was commensurate with the modest growth in our installed based.

[0000926326-14-000039:mdna:85]
Cost of Revenues. The increase in product costs for the three and nine months ended September 30, 2014 was attributable to product revenue growth, initial costs of ramping up new production equipment and changes in product mix. Service costs remained relatively flat.

[0000926326-14-000039:mdna:86]
41

[0000926326-14-000039:mdna:87]
Gross Profit. The increase in gross profit overall for the three and nine months ended September 30, 2014 was primarily due to the increase in product revenue in Europe. Gross profit on service revenue for the three and nine months ended September 30, 2014 declined due to the transition of a number of customers from annual service contracts to service by time and material, which we expect to provide a less consistent stream of service revenue.

[0000926326-14-000039:mdna:88]
[same as prior period, unchanged from 0000926326-14-000035:mdna:91]

[0000926326-14-000039:mdna:89]
[same as prior period, unchanged from 0000926326-14-000035:mdna:92]

[0000926326-14-000039:mdna:90]
The tables below show our Automation and Analytics segment's operating expenses for the three and nine months ended September 30, 2014 and 2013 and the change between those periods (in thousands, except percentages):

[0000926326-14-000039:mdna:91]
|  | Three Months Ended September 30, |  | Change in |  |
|  | 2014 |  | 2013 |  | $ |  | % |  |
| Gross profit | $ | 51,134 |  |  | $ | 44,870 |  |  | $ | 6,264 |  |  | 14.0 | % |
| Research and development | 5,765 |  |  | 5,404 |  |  | 361 |  |  | 6.7 | % |
| Selling, general and administrative | 32,897 |  |  | 29,648 |  |  | 3,249 |  |  | 11.0 | % |
| Total operating expenses | 38,662 |  |  | 35,052 |  |  | 3,610 |  |  | 10.3 | % |
| Operating income | $ | 12,472 |  |  | $ | 9,818 |  |  | $ | 2,654 |  |  | 27.0 | % |
| Operating margin | 13.9 | % |  | 13.1 | % |  |  |  | 0.8 |  |

[0000926326-14-000039:mdna:92]
|  | Nine Months Ended September 30, |  | Change in |  |
|  | 2014 |  | 2013 |  | $ |  | % |  |
| Gross profit | $ | 146,402 |  |  | $ | 125,223 |  |  | $ | 21,179 |  |  | 16.9 |  | % |
| Research and development | 15,784 |  |  | 16,739 |  |  | (955 | ) |  | (5.7 | ) | % |
| Selling, general and administrative | 96,788 |  |  | 84,686 |  |  | 12,102 |  |  | 14.3 |  | % |
| Total operating expenses | 112,572 |  |  | 101,425 |  |  | 11,147 |  |  | 11.0 |  | % |
| Operating income | $ | 33,830 |  |  | $ | 23,798 |  |  | $ | 10,032 |  |  | 42.2 |  | % |
| Operating margin | 13.2 | % |  | 10.9 | % |  |  |  | 2.3 |  |  |

[0000926326-14-000039:mdna:93]
Research and Development. The increase in research and development expenses for the three months ended September 30, 2014 was primarily driven by increases of $0.5 million in employee-related expenses due to increased staffing and higher year over year benefit costs, and $0.2 million in consulting-related expense driven by expanded research and development activities, offset by a $0.3 million decrease in capitalized software costs due to the lower level of post-feasibility beta testing which therefore does not reduce our research and development expenses.

[0000926326-14-000039:mdna:94]
The decrease in research and development expenses for the nine months ended September 30, 2014 was primarily driven by a $2.2 million increase in capitalized software costs due to the higher level of post-feasibility beta testing which therefore decreases our research and development expenses, an increase of $1.2 million in employee-related expenses due to increased staffing and higher year over year benefit costs and a $0.1 million increase in consulting-related expense.

[0000926326-14-000039:mdna:95]
[same as prior period, unchanged from 0000926326-14-000035:mdna:98]

[0000926326-14-000039:mdna:96]
Selling, General and Administrative. The increase in selling, general and administrative expenses for the three months ended September 30, 2014 was comprised of  $1.1 million associated with higher sales volumes and $2.0 million associated with increased investment in sales, marketing, and administrative efforts. The $1.1 million of higher sales volume-related expenses were driven by a $0.4 million increase in freight costs due to a higher volume of shipments this quarter, $0.4 million increase in Group Purchasing Organization fees due to increased invoicing and collections and $0.3 million in bad debt expense due to an increase in specific reserves. The $2.0 million of increased investment was driven by $1.0 million in employee-related expenses due to an increased headcount and higher year over year benefit costs, $0.6 million in sales meetings and marketing for our mobile truck tour and, $0.4 million in consulting and professional fees driven by merger and acquisition-related activities and increased accounting and auditing fees.

[0000926326-14-000039:mdna:97]
The increase in selling, general and administrative expenses for the nine months ended September 30, 2014 was comprised of $5.8 million associated with higher sales volumes and $5.8 million associated with increased investment in sales, marketing, and administrative efforts. The $5.8 million of higher sales volume related expenses were driven by $1.4 million in commission expenses associated with increased revenues and increased bookings, $1.3 million in increased freight costs due to

[0000926326-14-000039:mdna:98]
a higher volume of shipments this year as compared to last year, $0.9 million in Group Purchasing Organization fees due to increased invoicing, $0.7 million in bad debt expense due to an increase in specific reserves and the remainder was for various travel and entertainment, property tax, merger and acquisition and temporary labor, all to support our current growth. The $5.8 million of increased investment was driven by $4.2 million in employee-related expenses due to increased staffing and higher year over year benefit costs, including a $1.1 million increase in variable compensation expense which was due to achieving our company goals in the current year, compared to missing our company goals in the quarter ended March 31, 2013, $1.0 million in consulting and professional fees driven by merger and acquisition-related activities and increased accounting and auditing fees and $0.9 million in sales meetings and marketing for our mobile truck tour.

[0000926326-14-000039:mdna:99]
[same as prior period, unchanged from 0000926326-14-000035:mdna:103]

[0000926326-14-000039:mdna:100]
[same as prior period, unchanged from 0000926326-14-000035:mdna:104]

[0000926326-14-000039:mdna:101]
The tables below show our Medication Adherence segment's operating expenses for the three and nine months ended September 30, 2014 and 2013 and the change between those periods (in thousands, except percentages):

[0000926326-14-000039:mdna:102]
|  | Three Months Ended September 30, |  | Change in |  |
|  | 2014 |  | 2013 |  | $ |  | % |  |
| Gross profit | $ | 8,412 |  |  | $ | 7,170 |  |  | $ | 1,242 |  |  | 17.3 | % |
| Research and development | 1,313 |  |  | 1,157 |  |  | 156 |  |  | 13.5 | % |
| Selling, general and administrative | 5,974 |  |  | 5,114 |  |  | 860 |  |  | 16.8 | % |
| Total operating expenses | 7,287 |  |  | 6,271 |  |  | 1,016 |  |  | 16.2 | % |
| Operating income | $ | 1,125 |  |  | $ | 899 |  |  | $ | 226 |  |  | 25.1 | % |
| Operating margin | 4.9 | % |  | 4.7 | % |  |  |  | 0.2 | pps |

[0000926326-14-000039:mdna:103]
|  | Nine Months Ended September 30, |  | Change in |  |
|  | 2014 |  | 2013 |  | $ |  | % |  |
| Gross profit | $ | 23,679 |  |  | $ | 21,552 |  |  | $ | 2,127 |  |  | 9.9 |  | % |
| Research and development | 3,886 |  |  | 4,926 |  |  | (1,040 | ) |  | (21.1 | ) | % |
| Selling, general and administrative | 17,514 |  |  | 16,180 |  |  | 1,334 |  |  | 8.2 |  | % |
| Total operating expenses | 21,400 |  |  | 21,106 |  |  | 294 |  |  | 1.4 |  | % |
| Operating income | $ | 2,279 |  |  | $ | 446 |  |  | $ | 1,833 |  |  | 411.0 |  | % |
| Operating margin | 3.6 | % |  | 0.8 | % |  |  |  | 2.8 |  | pps |

[0000926326-14-000039:mdna:104]
Research and Development. The increase in research and development expenses for the three months ended September 30, 2014 was due to increased staffing.

[0000926326-14-000039:mdna:105]
The decrease in research and development expenses for the nine months ended September 30, 2014 was primarily due to a one-time $1.8 million write-off of previously capitalized software development costs in the first quarter of 2013, partially offset by a $0.4 million increase in headcount and personnel-related costs, which includes salaries for new hires, stock-based compensation and a $0.3 million increase for consulting services, to continue our efforts to develop additional functionality for our existing products.

[0000926326-14-000039:mdna:106]
[same as prior period, unchanged from 0000926326-14-000035:mdna:110]

[0000926326-14-000039:mdna:107]
Selling, General and Administrative. The increase in selling, general and administrative expenses for the three months ended September 30, 2014 was attributable to $0.3 million in consulting to further our product research, a $0.2 million increase in expenses due to the Surgichem acquisition and a $0.1 million increase in headcount and personnel-related costs.

[0000926326-14-000039:mdna:108]
The increase in selling, general and administrative expenses for the nine months ended September 30, 2014 was attributable to a $0.3 million in consulting to further our product research, a $0.2 million increase in headcount expenses, a $0.2 million increase in commissions due to a change in the commission plan and a $0.2 million increase in expenses due to the  Surgichem acquisition.

[0000926326-14-000039:mdna:109]
[same as prior period, unchanged from 0000926326-14-000035:mdna:113]

[0000926326-14-000039:mdna:110]
[same as prior period, unchanged from 0000926326-14-000035:mdna:114]

[0000926326-14-000039:mdna:111]
The annual effective tax rate before discrete items was 40.4% and 38.1% for the three and nine months ended September 30, 2014 and 2013, respectively. The increase in the estimated annual effective tax rate for the nine months ended September 30, 2014 compared to the same period in 2013 was primarily due to the expiration of the federal research and development credit as of December 31, 2013.  This increase was partially offset by a decrease in other non-deductible expenditures. The impacts of these amounts were 2.2% and 0.2%, respectively. The effective tax rate was 43.4% and 39.4% for the three and nine months ended September 30, 2014 compared to an effective tax rate of 27.8% and 28.9% for the three and nine months ended September 30, 2013. The increases in the rates for both three and nine months ended September 30, 2014 is primarily due to disqualifying of stock options and R&D tax credits in 2013 that were not present in 2014

[0000926326-14-000039:mdna:112]
[same as prior period, unchanged from 0000926326-14-000035:mdna:116]

[0000926326-14-000039:mdna:113]
We had cash and cash equivalents of $104.2 million at September 30, 2014, compared to $104.5 million at December 31, 2013. All of our cash and cash equivalents are invested in demand deposits and money market funds.

[0000926326-14-000039:mdna:114]
In September 2013, we entered into a Credit Agreement with Wells Fargo Bank, National Association, as administrative agent, and the lenders from time to time thereto, which provides for a $75.0 million revolving credit facility to be used for general corporate purposes, including future acquisitions. The Credit Agreement permits us to request one or more increases in the aggregate commitment provided such increases do not exceed $25.0 million in the aggregate. The Credit Agreement contains affirmative, negative and financial covenants that require us to, among other things, maintain a maximum consolidated total leverage ratio and a minimum consolidated fixed charge coverage ratio, in each case, as of the last day of each fiscal quarter. We were in full compliance with all covenants at September 30, 2014 and for the all periods since the commencement of the Credit Agreement. For additional details, refer to Note 17, Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000926326-14-000039:mdna:115]
[same as prior period, unchanged from 0000926326-14-000035:mdna:119]

[0000926326-14-000039:mdna:116]
Cash flows for the nine months ended September 30, 2014 and 2013, and the change between those periods, are as follows (in thousands):

[0000926326-14-000039:mdna:117]
|  | Nine Months Ended September 30, |  |  |
|  | 2014 |  | 2013 |  | Change |
| Net cash provided by operating activities | $ | 34,315 |  |  | $ | 40,737 |  |  | $ | (6,422 | ) |
| Net cash used in investing activities | (38,061 | ) |  | (13,736 | ) |  | (24,325 | ) |
| Net cash provided by financing activities | 3,538 |  |  | 26,847 |  |  | (23,309 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (136 | ) |  | 29 |  |  | (165 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | (344 | ) |  | $ | 53,877 |  |  | $ | (54,221 | ) |

[0000926326-14-000039:mdna:118]
Operating activities. During the nine months ended September 30, 2014, cash provided by operating activities consisted of net income of $21.3 million and non-cash charges of $25.8 million, offset by a $12.7 million decrease in net operating assets and liabilities.

[0000926326-14-000039:mdna:119]
Our non-cash charges consisted primarily of depreciation and amortization for our fixed and intangible assets of $14.7 million, stock-based compensation expense of $8.6 million, income tax benefits from employee stock plans of $4.1 million and deferred income taxes of $1.3 million, partially offset by $4.5 million in excess tax benefits from employee stock plans.

[0000926326-14-000039:mdna:120]
The main drivers in the change in our net operating assets and liabilities were a $35.0 million increase in accounts receivable due to increased shipments under purchase contracts of medication and supply cabinets, a $6.5 million decrease in accrued compensation primarily due to incentive bonus payouts, and lower accrued commissions due to higher bookings in the fourth quarter of 2013 as compared to the nine months ended September 30, 2014, offset by a $15.6 million increase in deferred gross profit due to an increase in products shipped but not yet installed, a $5.4 million increase in trade accounts payable due to growth in our business activities, a $2.7 million increase in deferred service revenues associated with new third-party leases generated and billed, a $1.4 million decrease in other current assets due to receipt of a tax refund, a $1.0 million decrease in prepaid expenses primarily due to a decrease in commissions driven by higher bookings in the fourth quarter of 2013 as compared to the nine months ended September 30, 2014, and a $0.8 million increase in other long-term tax liabilities.

[0000926326-14-000039:mdna:121]
During the nine months ended September 30, 2013, cash provided by operating activities consisted of net income of $17.2 million and non-cash charges of $23.3 million, offset by a $0.3 million decrease in net operating assets and liabilities. Our non-cash charges consisted primarily of depreciation and amortization of $13.7 million, stock-based compensation of $8.4 million, $1.8 million asset impairment charges related a software development project, offset by $2.8 million in excess tax benefits from employee stock plans. The main drivers in the change in our net operating assets and liabilities were a $9.0 million increase in accounts receivable due to increased shipments, $6.5 million increase primarily in trade accounts payable due to growth in our business activities, $4.7 million increase in inventory, $0.4 million decrease in deferred service revenue, offset by $4.4 million increase in deferred gross profit and $2.0 million increase in accrued liabilities.

[0000926326-14-000039:mdna:122]
Investing activities. Net cash used in investing activities for the nine months ended September 30, 2014 consisted primarily of $19.7 million for the acquisition of Surgichem, $10.2 million for purchases of property and equipment, primarily for software licenses and software upgrades, and $7.9 million expended for capitalized software development costs.

[0000926326-14-000039:mdna:123]
Net cash used in investing activities for the nine months ended September 30, 2013 consisted primarily of $7.8 million for purchases of property and equipment, and $5.7 million expended for capitalized software development costs.

[0000926326-14-000039:mdna:124]
Financing activities. Net cash provided by financing activities during the nine months ended September 30, 2014 consisted of $18.2 million in proceeds from employee stock option exercises and employee stock plan purchases, $4.5 million in excess tax benefits from employee stock plans, offset by $17.1 million in cash used for stock repurchases under our 2012 Stock Repurchase Program and $2.0 million in employees' taxes paid related to restricted stock units.

[0000926326-14-000039:mdna:125]
Net cash provided by financing activities during the nine months ended September 30, 2013 consisted primarily of $24.0 million in proceeds from the employee stock option exercises and employee stock plan purchases and $2.8 million in excess tax benefits from employee stock plans.

[0000926326-14-000039:mdna:126]
[same as prior period, unchanged from 0000926326-14-000035:mdna:128]

[0000926326-14-000039:mdna:127]
There were no material changes to our contractual obligations during the nine months ended September 30, 2014. For a description of our facility leases and contractual obligations, please refer to our Annual Report on Form 10-K for the year ended December 31, 2013 and the Notes to the Consolidated Financial Statements included therein.

[0000926326-14-000039:mdna:128]
The following table summarizes our contractual obligations at September 30, 2014 (in thousands):

[0000926326-14-000039:mdna:129]
|  | Total |  | Less than one year |  | One to three years |  | Four to five years |  | More than five years |
| Operating leases (1) | $ | 37,986 |  |  | $ | 1,448 |  |  | 10,796 |  |  | $ | 8,766 |  |  | $ | 16,976 |  |
| Commitments to contract manufacturers and suppliers (2) | 10,942 |  |  | 10,942 |  |  | — |  |  | — |  |  | — |  |
| Total (3) | $ | 48,928 |  |  | $ | 12,390 |  |  | $ | 10,796 |  |  | $ | 8,766 |  |  | $ | 16,976 |  |

[0000926326-14-000039:mdna:130]
| (1) | Commitments under operating leases relate primarily to leasehold property and office equipment. |

[0000926326-14-000039:mdna:131]
| (2) | We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. |

[0000926326-14-000039:mdna:132]
| (3) | At September 30, 2014, we have recorded $5.8 million for uncertain tax positions under long term liabilities, in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, a $5.8 million of uncertain tax position liability has not been included in the contractual obligations table. |

[0000926326-14-000039:mdna:133]
[same as prior period, unchanged from 0000926326-14-000035:mdna:137]

[0000926326-14-000039:mdna:134]
As of September 30, 2014, we had no off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
