# OMCL 10-Q controls and the auditor's report


## item_4_controls

[0000926326-14-000039:item_4_controls:1]
| Item 4. | CONTROLS AND PROCEDURES |

[0000926326-14-000039:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000926326-14-000039:item_4_controls:3]
Our management, with the participation of our principal executive officer and principal financial officer, has evaluated the effectiveness of our disclosure controls and procedures (as such term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) as of September 30, 2014. Based on such evaluation, our principal executive officer and principal financial officer have concluded that, as of September 30, 2014, our disclosure controls and procedures were effective.

[0000926326-14-000039:item_4_controls:4]
Changes in Internal Control Over Financial Reporting

[0000926326-14-000039:item_4_controls:5]
There were no changes in the Company's internal control over financial reporting during the most recent fiscal quarter that have materially affected, or are reasonably likely to materially affect, the Company's internal control over financial reporting.

[0000926326-14-000039:item_4_controls:6]
On May 14, 2013, the Committee of Sponsoring Organizations of the Treadway Commission ("COSO") issued an updated version of its Internal Control - Integrated Framework (the "2013 Framework"). Originally issued in 1992 (the "1992 Framework"), the framework helps organizations design, implement and evaluate the effectiveness of internal control concepts

[0000926326-14-000039:item_4_controls:7]
47

[0000926326-14-000039:item_4_controls:8]
and simplify their use and application. The 1992 Framework remains available during the transition period, which extends to December 15, 2014, after which time COSO will consider it superseded by the 2013 Framework. As of September 30, 2014, the Company continues to utilize the 1992 Framework during the transition to the 2013 Framework which will be completed by the end of 2014.
