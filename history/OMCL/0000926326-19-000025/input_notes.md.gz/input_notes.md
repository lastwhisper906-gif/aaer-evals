# OMCL notes — 0000926326-19-000025


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-19-000025:notes:1]
Organization and Summary of Significant Accounting Policies 
Business

[0000926326-19-000025:notes:2]
[same as prior period, unchanged from 0000926326-19-000013:notes:124]

[0000926326-19-000025:notes:3]
Basis of Presentation

[0000926326-19-000025:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2019 and December 31, 2018, the results of operations and comprehensive income for the three and six months ended June 30, 2019 and 2018, and cash flows for the six months ended June 30, 2019 and 2018. Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States Generally Accepted Accounting Principles (“U.S. GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2018 filed with the SEC on February 27, 2019, except as discussed in the sections entitled “Lessor Leases”, “Lessee Leases”, and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and six months ended June 30, 2019 and cash flows for the six months ended June 30, 2019 are not necessarily indicative of results that may be expected for the year ending December 31, 2019, or for any future period.

[0000926326-19-000025:notes:5]
Principles of Consolidation

[0000926326-19-000025:notes:6]
The Condensed Consolidated Financial Statements include the accounts of the Company and its subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000926326-19-000025:notes:7]
[same as prior period, unchanged from 0000926326-19-000013:notes:126]

[0000926326-19-000025:notes:8]
[same as prior period, unchanged from 0000926326-19-000013:notes:127]

[0000926326-19-000025:notes:9]
[same as prior period, unchanged from 0000926326-19-000013:notes:128]

[0000926326-19-000025:notes:10]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases;

[0000926326-19-000025:notes:11]
operating lease right-of-use assets and liabilities; inventory valuation; capitalized software development costs; impairment of goodwill; purchased intangibles and long-lived assets; share-based compensation; and accounting for income taxes.

[0000926326-19-000025:notes:12]
Lessor Leases

[0000926326-19-000025:notes:13]
The Company determines if an arrangement is a lease at inception. The transaction price is allocated to separate performance obligations, generally consisting of hardware and software products, installation, and post-installation technical support, proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an amount discounted from the list price as a best estimated selling price.

[0000926326-19-000025:notes:14]
Sales-Type Leases

[0000926326-19-000025:notes:15]
The Company enters into non-cancelable sales-type lease arrangements, most of which do not have an option to extend the lease term. At the end of the lease term, the customer must either return the equipment or negotiate a new agreement, resulting in a new purchase or lease transaction. Failure of the customer to either return the equipment or negotiate a new agreement results in the contract becoming a month-to-month rental. Certain sales-type leases automatically renew for successive one year periods at the end of each lease term with written notice from the customer. The Company’s sales-type lease agreements do not contain any material residual value guarantees.

[0000926326-19-000025:notes:16]
For sales-type leases, the Company recognizes revenues for its hardware and software products, net of lease execution costs, post-installation product maintenance, and technical support, at the net present value of the lease payment stream upon customer acceptance. The Company recognizes service revenues associated with the sales-type leases ratably over the term of the agreement in service revenues on the Condensed Consolidated Statements of Operations. The Company recognizes interest income from sales-type leases using the effective interest method. Both hardware and software revenues, and interest income from sales-types leases are recorded in product revenues on the Condensed Consolidated Statements of Operations.

[0000926326-19-000025:notes:17]
The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 50% of the lease receivable balance, are retained in-house.

[0000926326-19-000025:notes:18]
Operating Leases

[0000926326-19-000025:notes:19]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of the new lease accounting standard. Those agreements in place prior to January 1, 2019 will continue to be treated as operating leases, however any new leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with the new lease accounting standard. The operating lease arrangements entered into prior to January 1, 2019 are non-cancelable, and most automatically renew for successive one year periods at the end of each lease term absent written notice from the customer. The Company’s operating lease agreements do not contain any material residual value guarantees.

[0000926326-19-000025:notes:20]
For operating leases, rental income is generally recognized on a straight-line basis over the term of the associated lease, and recorded in services and other revenues in the Condensed Consolidated Statements of Operations. Leased assets under operating leases are carried at amortized cost net of accumulated depreciation in property and equipment, net on the Condensed Consolidated Balance Sheets. The depreciation expense of the leased assets is recognized on a straight-line basis over the contractual term of the associated lease, and recorded in cost of revenues in the Condensed Consolidated Statements of Operations.

[0000926326-19-000025:notes:21]
Lessee Leases

[0000926326-19-000025:notes:22]
The Company determines if an arrangement is a lease at inception. Operating lease right-of-use assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. As most of our lease contracts do not provide an implicit rate, the Company uses its incremental borrowing rate based on information available at the commencement date in determining the present value of the lease payments.

[0000926326-19-000025:notes:23]
Many of the Company’s operating leases include an option to extend the lease. The specific terms and conditions of the extension options vary from lease to lease, but are consistent with standard industry practices in each area that the Company operates. The Company reviews each of its lease options at a time required by the terms of the lease contract, and notifies the lessor if it chooses to exercise the lease renewal option. Until the Company is reasonably certain that it will extend the lease contract, the renewal option periods will not be recognized as right-of-use assets or lease liabilities.

[0000926326-19-000025:notes:24]
Certain leases include provisions for early termination, which allows the contract parties to terminate their obligations under the lease contract. The terms and conditions of the termination options vary by contract. When the Company has made a decision to exercise an early termination option, the right-of-use assets and associated lease liabilities are remeasured in accordance with the present value of the remaining cash flows under the lease contract.

[0000926326-19-000025:notes:25]
Certain building lease agreements include rental payments subject to change annually based on fluctuations in various indexes (i.e. Consumer Price Index (“CPI”), Retail Price Index, and other international indexes). Certain data center lease agreements include rental payments subject to change based on usage and CPI fluctuations. The changes based on usage and indexes are treated as variable lease costs and recognized in the period in which the obligation for those payments was incurred.

[0000926326-19-000025:notes:26]
The Company’s operating lease agreements do not contain any material residual value guarantees, restrictions, or restriction covenants.

[0000926326-19-000025:notes:27]
Recently Adopted Authoritative Guidance

[0000926326-19-000025:notes:28]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842). The FASB amended lease accounting requirements to begin recording assets and liabilities arising from most leases on the balance sheet. The new guidance also requires significant additional disclosures about the amount and timing of cash flows from leases. The Company adopted this new guidance on January 1, 2019. In July 2018, the FASB issued amendments in ASU 2018-11, which provide a transition election to not restate comparative periods for the effects of applying the new standard. This transition election permits entities to change the date of initial application to the beginning of the year of adoption and to recognize the effects of applying the new standard as a cumulative-effect adjustment to the opening balance of retained earnings. The Company has elected this transition approach as well as elected the package of practical expedients permitted under the transition guidance within the new standard, which will allow the Company to carry forward the historical lease classification of contracts entered into prior to January 1, 2019. As a result of electing the package of practical expedients described above, existing leases and related initial direct costs have not been reassessed prior to the effective date, and therefore, adoption of the lease standard did not have an impact on the Company’s previously reported consolidated statements.

[0000926326-19-000025:notes:29]
The Company also elected the following practical expedients: (i) combining lease and non-lease components, (ii) leases with an initial term of 12 months or less are not recorded in the Condensed Consolidated Balance Sheets, and the associated lease payments are recognized in the Condensed Consolidated Statements of Operations on a straight-line basis over the lease term, and (iii) applying discount rates to operating leases using a portfolio approach.

[0000926326-19-000025:notes:30]
From a lessor perspective, certain agreements that were previously classified as operating leases are classified as sales-type leases under the new lease accounting standard. The agreements in place prior to the adoption of the new lease accounting standard on January 1, 2019 will continue to be treated as operating leases.

[0000926326-19-000025:notes:31]
The Company’s adoption of the new standard impacted the Condensed Consolidated Balance Sheets at the beginning of the period of adoption as follows:

[0000926326-19-000025:notes:32]
|  | January 1, 2019 |
|  | Pre-ASC 842 Balances |  | ASC 842 Adoption Impact |  | Post-ASC 842 Balances |
|  | (In thousands) |
| Operating lease right-of-use assets | $ | — |  |  | $ | 66,008 |  |  | $ | 66,008 |  |
| Accrued liabilities (1) | 43,047 |  |  | 10,067 |  |  | 53,114 |  |
| Long-term operating lease liabilities | — |  |  | 59,791 |  |  | 59,791 |  |
| Other long-term liabilities (2) | 9,562 |  |  | (3,850 | ) |  | 5,712 |  |

[0000926326-19-000025:notes:33]
_________________________________________________

[0000926326-19-000025:notes:34]
| (1) | Adjustment represents the current portion of the operating lease liabilities of $10.3 million, and reclassification of exit cost obligations and deferred rent of $0.1 million and $0.1 million, respectively, to reduce the operating lease right-of-use assets. |

[0000926326-19-000025:notes:35]
| (2) | Adjustment represents the reclassification of deferred rent to reduce the operating lease right-of-use assets. |

[0000926326-19-000025:notes:36]
Adoption of the standard did not have an impact on the Company’s stockholders’ equity, Condensed Consolidated Statements of Operations, and Condensed Consolidated Statements of Cash Flows as of January 1, 2019.

[0000926326-19-000025:notes:37]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects.” ASU 2018-02 is effective for the Company beginning January 1, 2019. The adoption of

[0000926326-19-000025:notes:38]
this guidance did not have a material effect on the Company’s consolidated financial statements and therefore no adjustment to retained earnings was made.

[0000926326-19-000025:notes:39]
Recently Issued Authoritative Guidance

[0000926326-19-000025:notes:40]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). ASU 2018-15 will be effective for the Company beginning January 1, 2020. The Company is currently evaluating the impact ASU 2018-15 will have on its consolidated financial statements.

[0000926326-19-000025:notes:41]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments-Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans, and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans and held-to-maturity debt securities, the standard will replace the current “incurred loss” approach with an “expected loss” model. Entities will be required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. ASU 2016-13 will be effective for the Company beginning January 1, 2020. The Company is currently evaluating the impact ASU 2016-13 will have on its consolidated financial statements.

[0000926326-19-000025:notes:42]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-19-000025:notes:43]
Revenues
Revenue Recognition

[0000926326-19-000025:notes:44]
[same as prior period, unchanged from 0000926326-19-000013:notes:140]

[0000926326-19-000025:notes:45]
[same as prior period, unchanged from 0000926326-19-000013:notes:141]

[0000926326-19-000025:notes:46]
[same as prior period, unchanged from 0000926326-19-000013:notes:142]

[0000926326-19-000025:notes:47]
[same as prior period, unchanged from 0000926326-19-000013:notes:143]

[0000926326-19-000025:notes:48]
[same as prior period, unchanged from 0000926326-19-000013:notes:144]

[0000926326-19-000025:notes:49]
[same as prior period, unchanged from 0000926326-19-000013:notes:145]

[0000926326-19-000025:notes:50]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.6 million and $2.1 million for the three months ended June 30, 2019 and 2018, respectively, and $4.8 million and $4.0 million for the six months ended June 30, 2019 and 2018, respectively.

[0000926326-19-000025:notes:51]
[same as prior period, unchanged from 0000926326-19-000013:notes:147]

[0000926326-19-000025:notes:52]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and six months ended June 30, 2019 and 2018:

[0000926326-19-000025:notes:53]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Hardware and software | $ | 135,022 |  |  | $ | 112,031 |  |  | $ | 255,243 |  |  | $ | 219,482 |  |
| Consumables | 19,416 |  |  | 19,670 |  |  | 40,503 |  |  | 39,108 |  |
| Other | 3,941 |  |  | 2,935 |  |  | 8,243 |  |  | 6,705 |  |
| Total product revenues | $ | 158,379 |  |  | $ | 134,636 |  |  | $ | 303,989 |  |  | $ | 265,295 |  |

[0000926326-19-000025:notes:54]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2019 and 2018:

[0000926326-19-000025:notes:55]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| United States | $ | 195,811 |  |  | $ | 163,645 |  |  | $ | 375,831 |  |  | $ | 321,847 |  |
| Rest of world (1) | 21,602 |  |  | 25,028 |  |  | 44,099 |  |  | 49,445 |  |
| Total revenues | $ | 217,413 |  |  | $ | 188,673 |  |  | $ | 419,930 |  |  | $ | 371,292 |  |

[0000926326-19-000025:notes:56]
| (1) | No individual country represented more than 10% of the respective totals. |

[0000926326-19-000025:notes:57]
[same as prior period, unchanged from 0000926326-19-000013:notes:152]

[0000926326-19-000025:notes:58]
The following table reflects the Company’s contract assets and contract liabilities:

[0000926326-19-000025:notes:59]
|  | June 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 10,667 |  |  | $ | 9,191 |  |
| Long-term unbilled receivables - included in other long-term assets | 13,630 |  |  | 16,481 |  |
| Total contract assets | $ | 24,297 |  |  | $ | 25,672 |  |
| Short-term deferred revenues, net | $ | 83,012 |  |  | $ | 81,835 |  |
| Long-term deferred revenues | 9,658 |  |  | 10,582 |  |
| Total contract liabilities | $ | 92,670 |  |  | $ | 92,417 |  |

[0000926326-19-000025:notes:60]
The portion of the transaction price allocated to the Company’s unsatisfied performance obligations for which invoicing has occurred is recorded as deferred revenues.

[0000926326-19-000025:notes:61]
Short-term deferred revenues of $83.0 million and $81.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales, of $12.0 million and $11.1 million as of June 30, 2019 and December 31, 2018, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and six months ended June 30, 2019, the Company recognized revenues of $25.7 million and $65.0 million that were included in the corresponding gross short-term deferred revenues balance of $92.9 million as of December 31, 2018.

[0000926326-19-000025:notes:62]
Long-term deferred revenues include deferred revenues from service contracts of $9.7 million and $10.6 million as of June 30, 2019 and December 31, 2018, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-19-000025:notes:63]
[same as prior period, unchanged from 0000926326-19-000013:notes:156]

[0000926326-19-000025:notes:64]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2019 and 2018. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable as of June 30, 2019 and December 31, 2018.


## us-gaap:EarningsPerShareTextBlock

[0000926326-19-000025:notes:65]
Net Income Per Share
Basic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units computed using the treasury stock method. Any anti-dilutive weighted-average dilutive shares related to stock award plans are excluded from the computation of the diluted net income per share.

[0000926326-19-000025:notes:66]
The basic and diluted net income per share calculations for the three and six months ended June 30, 2019 and 2018 were as follows:

[0000926326-19-000025:notes:67]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands, except per share data) |
| Net income | $ | 15,976 |  |  | $ | 6,588 |  |  | $ | 19,260 |  |  | $ | 9,308 |  |
| Weighted-average shares outstanding — basic | 41,371 |  |  | 38,970 |  |  | 41,033 |  |  | 38,804 |  |
| Effect of dilutive securities from stock award plans | 1,574 |  |  | 1,030 |  |  | 1,613 |  |  | 1,050 |  |
| Weighted-average shares outstanding — diluted | 42,945 |  |  | 40,000 |  |  | 42,646 |  |  | 39,854 |  |
| Net income per share - basic | $ | 0.39 |  |  | $ | 0.17 |  |  | $ | 0.47 |  |  | $ | 0.24 |  |
| Net income per share - diluted | $ | 0.37 |  |  | $ | 0.16 |  |  | $ | 0.45 |  |  | $ | 0.23 |  |
| Anti-dilutive weighted-average shares related to stock award plans | 741 |  |  | 1,264 |  |  | 748 |  |  | 1,249 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-19-000025:notes:68]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $87.5 million and $67.2 million as of June 30, 2019 and December 31, 2018, respectively, consisted of bank accounts with major financial institutions.

[0000926326-19-000025:notes:69]
[same as prior period, unchanged from 0000926326-19-000013:notes:41]

[0000926326-19-000025:notes:70]
[same as prior period, unchanged from 0000926326-19-000013:notes:42]

[0000926326-19-000025:notes:71]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of December 31, 2018:

[0000926326-19-000025:notes:72]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 562 |  |  | $ | — |  |  | $ | 562 |  |
| Total financial assets | $ | — |  |  | $ | 562 |  |  | $ | — |  |  | $ | 562 |  |

[0000926326-19-000025:notes:73]
The Company’s interest rate swap agreement matured during the second quarter of 2019.

[0000926326-19-000025:notes:74]
[same as prior period, unchanged from 0000926326-19-000013:notes:43]

[0000926326-19-000025:notes:75]
The Company uses interest rate swap agreements to protect the Company against adverse fluctuations in interest rates by reducing its exposure to variability in cash flows relating to interest payments on a portion of its outstanding debt. The

[0000926326-19-000025:notes:76]
Company’s interest rate swaps, which are designated as cash flow hedges, involve the receipt of variable amounts from counterparties in exchange for the Company making fixed-rate payments over the life of the agreements. The Company does not hold or issue any derivative financial instruments for speculative trading purposes.

[0000926326-19-000025:notes:77]
During 2016, the Company entered into an interest rate swap agreement with a combined notional amount of $100.0 million with one counterparty that became effective on June 30, 2016 and matured on April 30, 2019. The swap agreement required the Company to pay a fixed rate of 0.8% and provided that the Company receive a variable rate based on the one month LIBOR rate subject to a LIBOR floor of 0.0%. Amounts payable by or due to the Company were net settled with the respective counterparty on the last business day of each month, commencing July 31, 2016.

[0000926326-19-000025:notes:78]
The fair value of the interest rate swap agreement at December 31, 2018 was $0.6 million. There were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-19-000025:notes:79]
Balance Sheet Components
Balance sheet details as of June 30, 2019 and December 31, 2018 are presented in the tables below:

[0000926326-19-000025:notes:80]
|  | June 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 34,867 |  |  | $ | 32,511 |  |
| Work in process | 7,867 |  |  | 8,726 |  |
| Finished goods | 61,172 |  |  | 59,631 |  |
| Total inventories | $ | 103,906 |  |  | $ | 100,868 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net | $ | 71,434 |  |  | $ | 56,819 |  |
| Unbilled receivables | 13,630 |  |  | 16,481 |  |
| Other assets | 1,103 |  |  | 1,313 |  |
| Total other long-term assets, net | $ | 86,167 |  |  | $ | 74,613 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 10,286 |  |  | $ | — |  |
| Advance payments from customers | 6,494 |  |  | 8,993 |  |
| Rebates and lease buyouts | 13,031 |  |  | 11,076 |  |
| Group purchasing organization fees | 4,668 |  |  | 4,455 |  |
| Taxes payable | 4,038 |  |  | 5,885 |  |
| Other accrued liabilities | 16,053 |  |  | 12,638 |  |
| Total accrued liabilities | $ | 54,570 |  |  | $ | 43,047 |  |

[0000926326-19-000025:notes:81]
The following tables summarize the changes in accumulated balances of other comprehensive income (loss) for the three and six months ended June 30, 2019 and 2018:

[0000926326-19-000025:notes:82]
|  | Three months ended June 30, |
|  | 2019 |  | 2018 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (10,605 | ) |  | $ | 103 |  |  | $ | (10,502 | ) |  | $ | (4,482 | ) |  | $ | 1,043 |  |  | $ | (3,439 | ) |
| Other comprehensive income (loss) before reclassifications | (971 | ) |  | 48 |  |  | (923 | ) |  | (4,414 | ) |  | 195 |  |  | (4,219 | ) |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (151 | ) |  | (151 | ) |  | — |  |  | (285 | ) |  | (285 | ) |
| Net current-period other comprehensive income (loss), net of tax | (971 | ) |  | (103 | ) |  | (1,074 | ) |  | (4,414 | ) |  | (90 | ) |  | (4,504 | ) |
| Ending balance | $ | (11,576 | ) |  | $ | — |  |  | $ | (11,576 | ) |  | $ | (8,896 | ) |  | $ | 953 |  |  | $ | (7,943 | ) |

[0000926326-19-000025:notes:83]
|  | Six months ended June 30, |
|  | 2019 |  | 2018 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (11,274 | ) |  | $ | 420 |  |  | $ | (10,854 | ) |  | $ | (6,954 | ) |  | $ | 841 |  |  | $ | (6,113 | ) |
| Other comprehensive income (loss) before reclassifications | (302 | ) |  | 148 |  |  | (154 | ) |  | (1,942 | ) |  | 596 |  |  | (1,346 | ) |
| Amounts reclassified from other comprehensive income (loss), net of tax | — |  |  | (568 | ) |  | (568 | ) |  | — |  |  | (484 | ) |  | (484 | ) |
| Net current-period other comprehensive income (loss), net of tax | (302 | ) |  | (420 | ) |  | (722 | ) |  | (1,942 | ) |  | 112 |  |  | (1,830 | ) |
| Ending balance | $ | (11,576 | ) |  | $ | — |  |  | $ | (11,576 | ) |  | $ | (8,896 | ) |  | $ | 953 |  |  | $ | (7,943 | ) |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-19-000025:notes:84]
Property and Equipment 
The following table represents the property and equipment balances as of June 30, 2019 and December 31, 2018:

[0000926326-19-000025:notes:85]
|  | June 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Equipment | $ | 77,676 |  |  | $ | 75,417 |  |
| Furniture and fixtures | 8,441 |  |  | 7,844 |  |
| Leasehold improvements | 18,103 |  |  | 16,274 |  |
| Software | 47,408 |  |  | 42,048 |  |
| Construction in progress | 8,394 |  |  | 10,706 |  |
| Property and equipment, gross | 160,022 |  |  | 152,289 |  |
| Accumulated depreciation and amortization | (107,175 | ) |  | (100,789 | ) |
| Total property and equipment, net | $ | 52,847 |  |  | $ | 51,500 |  |

[0000926326-19-000025:notes:86]
Depreciation and amortization expense of property and equipment was $4.4 million and $3.8 million for the three months ended June 30, 2019 and 2018, respectively. Depreciation and amortization expense of property and equipment was $8.4 million and $7.3 million for the six months ended June 30, 2019 and 2018, respectively.

[0000926326-19-000025:notes:87]
The geographic location of the Company's property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of June 30, 2019 and December 31, 2018:

[0000926326-19-000025:notes:88]
|  | June 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| United States | $ | 46,813 |  |  | $ | 44,684 |  |
| Rest of world (1) | 6,034 |  |  | 6,816 |  |
| Total property and equipment, net | $ | 52,847 |  |  | $ | 51,500 |  |

[0000926326-19-000025:notes:89]
(1) 
No individual country represented more than 10% of the respective totals.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-19-000025:notes:90]
Goodwill and Intangible Assets
Goodwill

[0000926326-19-000025:notes:91]
[same as prior period, unchanged from 0000926326-19-000013:notes:49]

[0000926326-19-000025:notes:92]
|  | December 31, 2018 |  | Additions |  | Foreign currency exchange rate fluctuations |  | June 30, 2019 |
|  | (In thousands) |
| Goodwill | $ | 335,887 |  |  | $ | — |  |  | $ | (188 | ) |  | $ | 335,699 |  |

[0000926326-19-000025:notes:93]
[same as prior period, unchanged from 0000926326-19-000013:notes:51]

[0000926326-19-000025:notes:94]
The carrying amounts and useful lives of intangible assets as of June 30, 2019 and December 31, 2018 were as follows:

[0000926326-19-000025:notes:95]
|  | June 30, 2019 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 135,234 |  |  | $ | (49,999 | ) |  | $ | (1,215 | ) |  | $ | 84,020 |  |  | 1 - 30 |
| Acquired technology | 77,142 |  |  | (32,230 | ) |  | 25 |  |  | 44,937 |  |  | 3 - 20 |
| Backlog | 1,150 |  |  | (647 | ) |  | — |  |  | 503 |  |  | 4 |
| Trade names | 7,650 |  |  | (4,699 | ) |  | 14 |  |  | 2,965 |  |  | 1 - 12 |
| Patents | 3,217 |  |  | (1,543 | ) |  | 2 |  |  | 1,676 |  |  | 2 - 20 |
| Total intangibles assets, net | $ | 224,393 |  |  | $ | (89,118 | ) |  | $ | (1,174 | ) |  | $ | 134,101 |  |  |  |

[0000926326-19-000025:notes:96]
[same as prior period, unchanged from 0000926326-19-000013:notes:54]

[0000926326-19-000025:notes:97]
| (1) | The differences in gross carrying amounts between periods are primarily due to the write-off of fully amortized intangible assets. |

[0000926326-19-000025:notes:98]
Amortization expense of intangible assets was $4.7 million and $6.0 million for the three months ended June 30, 2019 and 2018, respectively. Amortization expense of intangible assets was $9.5 million and $12.0 million for the six months ended June 30, 2019 and 2018, respectively.

[0000926326-19-000025:notes:99]
[same as prior period, unchanged from 0000926326-19-000013:notes:58]

[0000926326-19-000025:notes:100]
|  | June 30, 2019 |
|  | (In thousands) |
| Remaining six months of 2019 | $ | 9,171 |  |
| 2020 | 17,499 |  |
| 2021 | 16,171 |  |
| 2022 | 14,819 |  |
| 2023 | 13,705 |  |
| Thereafter | 62,736 |  |
| Total | $ | 134,101 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-19-000025:notes:101]
Debt and Credit Agreements
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-19-000025:notes:102]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s consolidated total net leverage ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-19-000025:notes:103]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is

[0000926326-19-000025:notes:104]
required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain permitted asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-19-000025:notes:105]
The Credit Agreement contains customary representations and warranties, and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Company’s obligations under the Credit Agreement, and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender), are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.

[0000926326-19-000025:notes:106]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement (the “Amended Credit Agreement”). Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant, and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

[0000926326-19-000025:notes:107]
On December 26, 2017, the parties entered into an amendment (the “Amendment”) to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million, and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.

[0000926326-19-000025:notes:108]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $0.9 million and $1.9 million for the three months ended June 30, 2019 and 2018, respectively, and approximately $2.2 million and $3.8 million for the six months ended June 30, 2019 and 2018, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million and $0.6 million for the three months ended June 30, 2019 and 2018, respectively, and approximately $1.1 million and $1.1 million for the six months ended June 30, 2019 and 2018, respectively. The Company was in compliance with all covenants as of June 30, 2019 and December 31, 2018.

[0000926326-19-000025:notes:109]
During the six months ended June 30, 2019, the Company repaid $60.0 million under these Facilities.

[0000926326-19-000025:notes:110]
The components of the Company’s debt obligations as of June 30, 2019 and December 31, 2018 were as follows:

[0000926326-19-000025:notes:111]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | June 30, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (60,000 | ) |  | $ | 80,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (60,000 | ) |  | 80,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 1,145 |  |  | (3,438 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (58,855 | ) |  | $ | 76,562 |  |

[0000926326-19-000025:notes:112]
As of June 30, 2019, the carrying amount of debt of $80.0 million approximates the comparable fair value of $80.2 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of June 30, 2019 as compared to December 31, 2018.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-19-000025:notes:113]
Lessor Leases
Sales-Type Leases

[0000926326-19-000025:notes:114]
On a recurring basis, the Company enters into multi-year, sales-type lease agreements, with the majority varying in length from one to five years. The following table presents the Company’s income recognized from sales-type leases for the three and six months ended June 30, 2019 and 2018:

[0000926326-19-000025:notes:115]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Sales-type lease revenues | $ | 13,309 |  |  | $ | 7,533 |  |  | $ | 24,816 |  |  | $ | 17,390 |  |
| Interest income on sales-type lease receivables | $ | 399 |  |  | $ | 314 |  |  | 808 |  |  | 581 |  |

[0000926326-19-000025:notes:116]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at June 30, 2019 and December 31, 2018:

[0000926326-19-000025:notes:117]
|  | June 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 33,279 |  |  | $ | 28,295 |  |
| Less: Unearned interest income portion | (3,047 | ) |  | (2,477 | ) |
| Net investment in sales-type leases | 30,232 |  |  | 25,818 |  |
| Less: Current portion (1) | (9,191 | ) |  | (8,736 | ) |
| Long-term net investment in sales-type leases | $ | 21,041 |  |  | $ | 17,082 |  |

[0000926326-19-000025:notes:118]
[same as prior period, unchanged from 0000926326-19-000013:notes:97]

[0000926326-19-000025:notes:119]
The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value.

[0000926326-19-000025:notes:120]
The Company evaluates its sales-type leases individually and collectively for impairment. The allowance for credit losses was $0.2 million as of both June 30, 2019 and December 31, 2018.

[0000926326-19-000025:notes:121]
[same as prior period, unchanged from 0000926326-19-000013:notes:100]

[0000926326-19-000025:notes:122]
|  | June 30, 2019 |
|  | (In thousands) |
| Remaining six months of 2019 | $ | 6,138 |  |
| 2020 | 9,088 |  |
| 2021 | 6,714 |  |
| 2022 | 6,017 |  |
| 2023 | 4,027 |  |
| Thereafter | 1,295 |  |
| Total future minimum sales-type lease payments | $ | 33,279 |  |
| Present value adjustment | (3,047 | ) |
| Total net investment in sales-type leases | $ | 30,232 |  |

[0000926326-19-000025:notes:123]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of the new lease accounting standard. These agreements in place prior to January 1, 2019 will continue to be treated as operating leases, however any new leasing agreements entered into on or after January 1, 2019 under these programs are classified and

[0000926326-19-000025:notes:124]
accounted for as sales-type leases in accordance with the new lease accounting standard. The operating lease arrangements generally have initial terms of one to seven years. The following table represents the Company’s income recognized from operating leases for the three and six months ended June 30, 2019 and 2018:

[0000926326-19-000025:notes:125]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Rental income | $ | 3,365 |  |  | $ | 3,011 |  |  | $ | 6,652 |  |  | $ | 5,801 |  |

[0000926326-19-000025:notes:126]
The net carrying value of the leased equipment under operating leases was $2.4 million and $2.6 million, which includes accumulated depreciation of $1.3 million and $1.2 million, as of June 30, 2019 and December 31, 2018, respectively. Depreciation expense of the leased equipment for the three months ended June 30, 2019 and 2018 was $0.3 million and $0.1 million, respectively, and depreciation expense of the leased equipment for the six months ended June 30, 2019 and 2018 was $0.4 million and $0.2 million, respectively.

[0000926326-19-000025:notes:127]
The maturity schedule of future minimum lease payments under operating leases was as follows:

[0000926326-19-000025:notes:128]
|  | June 30, 2019 |
|  | (In thousands) |
| Remaining six months of 2019 | 6,790 |  |
| 2020 | 9,332 |  |
| 2021 | 7,033 |  |
| 2022 | 5,051 |  |
| 2023 | 2,901 |  |
| Thereafter | 1,197 |  |
| Total future minimum operating lease payments | $ | 32,304 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-19-000025:notes:129]
Lessee Leases 
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to 12 years. As of June 30, 2019, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-19-000025:notes:130]
The maturity schedule of future minimum lease payments under operating leases and the reconciliation to the operating lease liabilities reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-19-000025:notes:131]
|  | June 30, 2019 |
|  | (In thousands) |
| Remaining six months of 2019 | $ | 7,239 |  |
| 2020 | 13,458 |  |
| 2021 | 12,866 |  |
| 2022 | 11,802 |  |
| 2023 | 8,409 |  |
| Thereafter | 27,809 |  |
| Total operating lease payments | $ | 81,583 |  |
| Present value adjustment | (16,060 | ) |
| Total operating lease liabilities (1) | $ | 65,523 |  |

[0000926326-19-000025:notes:132]
| (1) | Amount consists of a current and long-term portion of operating lease liabilities of $10.3 million and $55.2 million, respectively. The short-term portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets. |

[0000926326-19-000025:notes:133]
[same as prior period, unchanged from 0000926326-19-000013:notes:79]

[0000926326-19-000025:notes:134]
[same as prior period, unchanged from 0000926326-19-000013:notes:80]

[0000926326-19-000025:notes:135]
Operating lease costs were $3.6 million and $7.3 million for the three and six months ended June 30, 2019, respectively. Short-term lease costs and variable lease costs were immaterial for the three and six months ended June 30, 2019.

[0000926326-19-000025:notes:136]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the six months ended June 30, 2019:

[0000926326-19-000025:notes:137]
|  | Six months ended June 30, 2019 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 7,391 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | 557 |  |

[0000926326-19-000025:notes:138]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of June 30, 2019:

[0000926326-19-000025:notes:139]
|  | June 30, 2019 |
| Weighted-average remaining lease term, years | 6.8 |  |
| Weighted-average discount rate, % | 6.4 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-19-000025:notes:140]
Commitments and Contingencies
Purchase Obligations

[0000926326-19-000025:notes:141]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2019, the Company had non-cancelable purchase commitments of $61.3 million, of which $53.9 million are expected to be paid within the year ended December 31, 2019.

[0000926326-19-000025:notes:142]
Legal Proceedings

[0000926326-19-000025:notes:143]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

[0000926326-19-000025:notes:144]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint seeks monetary recovery of compensatory and punitive damages in addition to

[0000926326-19-000025:notes:145]
certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice.

[0000926326-19-000025:notes:146]
On June 6, 2018, a class action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint sought class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint was held in abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The Illinois Supreme Court issued its decision in that case on January 25, 2019. On April 10, 2019, subsequent to the court’s issuance of an order granting the plaintiff leave to file an amended complaint, the plaintiff filed an amended complaint adding a second named plaintiff and an affiliate of the Company’s customer as an additional defendant and, in addition to making other modifications to the complaint, removing the separate cause of action directed to negligence. The court established a deadline of May 13, 2019 for the defendants to answer or otherwise respond to the amended complaint. On May 10, 2019, defendants Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, and Northwestern Memorial Hospital removed the case to the United States District Court for the Northern District of Illinois, Eastern Division. Subsequently, on May 17, 2019, the Company and the other defendants in the case each filed a motion to dismiss the complaint for failure to state a cause of action upon which relief could be granted. On June 14, 2019, plaintiffs filed a motion to remand the case to state court. The Court then entered an order, on June 19, 2019, denying plaintiffs’ motion to remand, granting defendants’ motions to dismiss with respect to the additionally-named plaintiff, and continuing the motions to dismiss with respect to the originally-named plaintiff. On July 2, 2019, the Court entered an order remanding the case to state court and denying the defendants’ motions to dismiss without prejudice to renewal of the motions in state court. The Company intends to defend the lawsuit vigorously.

[0000926326-19-000025:notes:147]
A declaratory judgment action was filed against the Company, on August 30, 2018, in the United States District Court for the Northern District of California, captioned Zurich American Insurance Company; American Guarantee & Liability Company v. Omnicell, Inc. and Does 1-10, inclusive, Case No. 3:18-CV-05345. The complaint seeks a declaration that the plaintiffs have no duty to defend or indemnify the Company in connection with the underlying litigation, the Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161 pending in the Circuit Court of Cook County, Illinois, Chancery Division (“Underlying Action”), disclosed above, together with claims for reimbursement and unjust enrichment relating to the defense of the Underlying Action in the form of attorneys’ fees and other related costs. The Company has not responded to the complaint. On February 12, 2019, the court stayed the action pending the outcome of the Underlying Action and administratively closed the case. The Company intends to defend the lawsuit vigorously.

[0000926326-19-000025:notes:148]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of BIPA, and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. The Company must file a response to the complaint by August 14, 2019. The Court has scheduled a case management conference for October 3, 2019. The Company intends to defend the lawsuit vigorously.

[0000926326-19-000025:notes:149]
On July 18, 2019, a putative class action lawsuit was filed against the Company and certain of its officers in the U.S. District Court for the Northern District of California. The complaint, captioned Bursick v. Omnicell, Inc. et al., Case No. 3:19-cv-04150, alleges that the defendants violated federal securities laws by making materially false and misleading statements beginning in October 2018 regarding revenue recognition, customer concerns about implementation issues, and a purported need to write off inventory. The plaintiff seeks unspecified monetary damages and other relief. The Company intends to defend the lawsuit vigorously.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-19-000025:notes:150]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 24.8% and 16.5% for the six months ended June 30, 2019 and 2018, respectively.

[0000926326-19-000025:notes:151]
As a result of global operational centralization activities during the six months ended June 30, 2018, the Company recognized $4.2 million of a discrete tax benefit associated with making a check-the-box election to treat Aesynt Holding Coöperatief U.A. (Netherlands) as a U.S. disregarded entity beginning in the first quarter of 2018. Due to continuing global operational centralization activities during the first quarter of 2019, the Company recognized gain on the sale of certain intellectual property rights by Aesynt Holding Coöperatief U.A. to Omnicell, Inc., which resulted in a discrete tax expense in the amount of $9.6 million during the six months ended June 30, 2019. The Company also recognized a discrete tax benefit related to equity compensation in the amount of $7.0 million and $2.6 million for the six months ended June 30, 2019 and June 30, 2018, respectively.

[0000926326-19-000025:notes:152]
[same as prior period, unchanged from 0000926326-19-000013:notes:63]

[0000926326-19-000025:notes:153]
As of June 30, 2019 and December 31, 2018, the Company had gross unrecognized tax benefits of $14.2 million and $10.0 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in Interest and other income (expense), net in the Condensed Consolidated Statements of Operations. As of June 30, 2019 and December 31, 2018, the amount of accrued interest and penalties was $1.6 million and $1.4 million, respectively.

[0000926326-19-000025:notes:154]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of June 30, 2019, the Company is no longer subject to U.S., state, and foreign examination for years before 2015, 2014, and 2014, respectively.

[0000926326-19-000025:notes:155]
[same as prior period, unchanged from 0000926326-19-000013:notes:66]


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-19-000025:notes:156]
Employee Benefits and Share-Based Compensation
Stock-Based Plans

[0000926326-19-000025:notes:157]
[same as prior period, unchanged from 0000926326-19-000013:notes:174]

[0000926326-19-000025:notes:158]
[same as prior period, unchanged from 0000926326-19-000013:notes:175]

[0000926326-19-000025:notes:159]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three and six months ended June 30, 2019 and 2018:

[0000926326-19-000025:notes:160]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,416 |  |  | $ | 1,177 |  |  | $ | 2,878 |  |  | $ | 2,196 |  |
| Research and development | 1,584 |  |  | 1,437 |  |  | 3,286 |  |  | 2,671 |  |
| Selling, general, and administrative | 5,260 |  |  | 4,624 |  |  | 10,506 |  |  | 8,899 |  |
| Total share-based compensation expense | $ | 8,260 |  |  | $ | 7,238 |  |  | $ | 16,670 |  |  | $ | 13,766 |  |

[0000926326-19-000025:notes:161]
In the first quarter of 2019, the Company modified the terms of its stock options by extending the post-employment exercise period for certain employees. The Company recorded share-based compensation expense related to this option modification of approximately $0.1 million and $0.3 million during the three and six months ended June 30, 2019. The Company will incur an additional $0.7 million of share-based compensation expense for the impacted options over the remaining weighted-average vesting period of 1.9 years.

[0000926326-19-000025:notes:162]
[same as prior period, unchanged from 0000926326-19-000013:notes:177]

[0000926326-19-000025:notes:163]
The following assumptions were used to value stock options and Employee Stock Purchase Plan (“ESPP”) shares granted pursuant to the Company’s equity incentive plans for the three and six months ended June 30, 2019 and 2018:

[0000926326-19-000025:notes:164]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Stock options |  |  |  |  |  |  |  |
| Expected life, years | 4.3 |  |  | 4.8 |  |  | 4.4 |  |  | 4.8 |  |
| Expected volatility, % | 33.2 | % |  | 30.6 | % |  | 33.2 | % |  | 31.4 | % |
| Risk-free interest rate, % | 2.1 | % |  | 2.8 | % |  | 2.3 | % |  | 2.7 | % |
| Estimated forfeiture rate, % | 7.2 | % |  | 6.9 | % |  | 7.2 | % |  | 6.9 | % |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-19-000025:notes:165]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Employee stock purchase plan shares |  |  |  |  |  |  |  |
| Expected life, years | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |  | 0.5 - 2.0 |  |
| Expected volatility, % | 28.2% - 38.4% |  |  | 27.7% - 33.8% |  |  | 28.2% - 38.4% |  |  | 27.7% - 33.8% |  |
| Risk-free interest rate, % | 1.3% - 2.7% |  |  | 0.7% - 2.3% |  |  | 1.3% - 2.7% |  |  | 0.7% - 2.3% |  |
| Dividend yield, % | — | % |  | — | % |  | — | % |  | — | % |

[0000926326-19-000025:notes:166]
[same as prior period, unchanged from 0000926326-19-000013:notes:178]

[0000926326-19-000025:notes:167]
The following table summarizes the share option activity under the Company’s equity incentive plans during the six months ended June 30, 2019:

[0000926326-19-000025:notes:168]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2018 | 3,748 |  |  | $ | 41.27 |  |  | 7.6 |  | $ | 78,365 |  |
| Granted | 479 |  |  | 77.79 |  |  |  |  |  |
| Exercised | (525 | ) |  | 32.19 |  |  |  |  |  |
| Expired | (4 | ) |  | 40.26 |  |  |  |  |  |
| Forfeited | (178 | ) |  | 44.86 |  |  |  |  |  |
| Outstanding at June 30, 2019 | 3,520 |  |  | $ | 47.41 |  |  | 7.7 |  | $ | 135,949 |  |
| Exercisable at June 30, 2019 | 1,337 |  |  | $ | 32.48 |  |  | 6.3 |  | $ | 71,596 |  |
| Vested and expected to vest at June 30, 2019 and thereafter | 3,520 |  |  | $ | 47.41 |  |  | 7.7 |  | $ | 135,949 |  |

[0000926326-19-000025:notes:169]
The weighted-average fair value per share of options granted during the three months ended June 30, 2019 and 2018 was $24.40 and $14.43, respectively, and the weighted-average fair value per share of options granted during the six months ended June 30, 2019 and 2018 was $24.20 and $14.29, respectively. The intrinsic value of options exercised during the three months ended June 30, 2019 and 2018 was $7.2 million and $6.5 million, respectively, and the intrinsic value of options exercised during the six months ended June 30, 2019 and 2018 was $24.3 million and $8.5 million, respectively.

[0000926326-19-000025:notes:170]
As of June 30, 2019, total unrecognized compensation cost related to unvested stock options was $33.2 million, which is expected to be recognized over a weighted-average vesting period of 2.8 years.

[0000926326-19-000025:notes:171]
[same as prior period, unchanged from 0000926326-19-000013:notes:181]

[0000926326-19-000025:notes:172]
For the six months ended June 30, 2019 and 2018, employees purchased approximately 210,000 and 289,000 shares of common stock, respectively, under the ESPP at weighted average prices of $40.20 and $26.30, respectively. As of June 30,

[0000926326-19-000025:notes:173]
2019, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $2.6 million and is expected to be recognized over a weighted-average period of 1.3 years.

[0000926326-19-000025:notes:174]
[same as prior period, unchanged from 0000926326-19-000013:notes:183]

[0000926326-19-000025:notes:175]
Summaries of the restricted stock activity under the Company’s 2009 Equity Incentive Plan, as amended (the “2009 Plan”) are presented below for the six months ended June 30, 2019:

[0000926326-19-000025:notes:176]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted stock units |  |  |  |  |  |  |  |
| Outstanding at December 31, 2018 | 538 |  |  | $ | 51.52 |  |  | 1.6 |  | $ | 32,935 |  |
| Granted (Awarded) | 64 |  |  | 78.95 |  |  |  |  |  |
| Vested (Released) | (87 | ) |  | 40.43 |  |  |  |  |  |
| Forfeited | (36 | ) |  | 44.49 |  |  |  |  |  |
| Outstanding and unvested at June 30, 2019 | 479 |  |  | $ | 57.79 |  |  | 1.4 |  | $ | 41,201 |  |

[0000926326-19-000025:notes:177]
As of June 30, 2019, total unrecognized compensation cost related to RSUs was $23.0 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.7 years.

[0000926326-19-000025:notes:178]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted stock awards |  |  |  |
| Outstanding at December 31, 2018 | 21 |  |  | $ | 46.60 |  |
| Granted (Awarded) | 17 |  |  | 81.86 |  |
| Vested (Released) | (21 | ) |  | 46.96 |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at June 30, 2019 | 17 |  |  | $ | 81.92 |  |

[0000926326-19-000025:notes:179]
As of June 30, 2019, total unrecognized compensation cost related to RSAs was $1.1 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.9 years.

[0000926326-19-000025:notes:180]
[same as prior period, unchanged from 0000926326-19-000013:notes:186]

[0000926326-19-000025:notes:181]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below for the six months ended June 30, 2019:

[0000926326-19-000025:notes:182]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2018 | 197 |  |  | $ | 34.83 |  |
| Granted | 71 |  |  | 73.38 |  |
| Vested | (58 | ) |  | 34.38 |  |
| Forfeited | (33 | ) |  | 33.84 |  |
| Outstanding and unvested at June 30, 2019 | 177 |  |  | $ | 50.67 |  |

[0000926326-19-000025:notes:183]
As of June 30, 2019, total unrecognized compensation cost related to PSUs was approximately $4.9 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.5 years.

[0000926326-19-000025:notes:184]
[same as prior period, unchanged from 0000926326-19-000013:notes:188]

[0000926326-19-000025:notes:185]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of June 30, 2019:

[0000926326-19-000025:notes:186]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 3,520 |  |
| Non-vested restricted share awards | 673 |  |
| Shares authorized for future issuance | 3,820 |  |
| ESPP shares available for future issuance | 1,703 |  |
| Total shares reserved for future issuance | 9,716 |  |

[0000926326-19-000025:notes:187]
[same as prior period, unchanged from 0000926326-19-000013:notes:189]

[0000926326-19-000025:notes:188]
On August 2, 2016, the Company's Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of June 30, 2019, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase programs at any time. 
During the three and six months ended June 30, 2019 and 2018, the Company did not repurchase any of its outstanding common stock.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-19-000025:notes:189]
Equity Offerings
On November 3, 2017, the Company entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC, and HSBC Securities (USA) Inc., as its sales agents, pursuant to which the Company may offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of the Company’s common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange.

[0000926326-19-000025:notes:190]
For the three months ended June 30, 2019, the Company received gross proceeds of $17.9 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.3 million on sales of approximately 217,000 shares of its common stock at an average price of approximately $82.51 per share.

[0000926326-19-000025:notes:191]
For the six months ended June 30, 2019, the Company received gross proceeds of $38.5 million from sales of its common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 460,000 shares of its common stock at an average price of approximately $83.81 per share.

[0000926326-19-000025:notes:192]
For the three and six months ended June 30, 2018, the Company did not sell any of its common stock under the Distribution Agreement.

[0000926326-19-000025:notes:193]
As of June 30, 2019, the Company had an aggregate of $31.5 million available to be offered under the Distribution Agreement.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-19-000025:notes:194]
Restructuring Expenses
In the fourth quarter of 2018, the Company announced a company-wide organizational realignment initiative in order to align its organizational infrastructure for future expected growth. During the year ended December 31, 2018, the Company incurred and accrued for $1.3 million of restructuring expenses, which includes severance and consulting-related expenses. As of June 30, 2019, there was no unpaid balance related to this restructuring plan.

[0000926326-19-000025:notes:195]
On March 2, 2018, the Company initiated the realignment of its Automation and Analytics commercial group in North America and France. During the six months ended June 30, 2018, the Company accrued $3.0 million of employee severance

[0000926326-19-000025:notes:196]
cost and related expenses, and paid out $1.9 million. As of December 31, 2018, there was no unpaid balance related to this restructuring program.
