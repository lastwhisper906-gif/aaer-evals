# OMCL MD&A — 0000926326-19-000025


## mdna

[0000926326-19-000025:mdna:1]
[same as prior period, unchanged from 0000926326-19-000013:mdna:1]

[0000926326-19-000025:mdna:2]
[same as prior period, unchanged from 0000926326-19-000013:mdna:2]

[0000926326-19-000025:mdna:3]
[same as prior period, unchanged from 0000926326-19-000013:mdna:3]

[0000926326-19-000025:mdna:4]
[same as prior period, unchanged from 0000926326-19-000013:mdna:4]

[0000926326-19-000025:mdna:5]
[same as prior period, unchanged from 0000926326-19-000013:mdna:5]

[0000926326-19-000025:mdna:6]
[same as prior period, unchanged from 0000926326-19-000013:mdna:6]

[0000926326-19-000025:mdna:7]
[same as prior period, unchanged from 0000926326-19-000013:mdna:7]

[0000926326-19-000025:mdna:8]
[same as prior period, unchanged from 0000926326-19-000013:mdna:8]

[0000926326-19-000025:mdna:9]
| • | our ability to deliver on our vision of the Autonomous Pharmacy, as well as our plans to integrate our current offerings and technologies on cloud infrastructure and invest in certain key areas as we execute on this vision; |

[0000926326-19-000025:mdna:10]
[same as prior period, unchanged from 0000926326-19-000013:mdna:10]

[0000926326-19-000025:mdna:11]
[same as prior period, unchanged from 0000926326-19-000013:mdna:11]

[0000926326-19-000025:mdna:12]
[same as prior period, unchanged from 0000926326-19-000013:mdna:12]

[0000926326-19-000025:mdna:13]
[same as prior period, unchanged from 0000926326-19-000013:mdna:13]

[0000926326-19-000025:mdna:14]
[same as prior period, unchanged from 0000926326-19-000013:mdna:14]

[0000926326-19-000025:mdna:15]
[same as prior period, unchanged from 0000926326-19-000013:mdna:15]

[0000926326-19-000025:mdna:16]
[same as prior period, unchanged from 0000926326-19-000013:mdna:16]

[0000926326-19-000025:mdna:17]
| • | the expected impacts of new accounting standards or changes to existing accounting standards; |

[0000926326-19-000025:mdna:18]
| • | our expected future uses of cash and the sufficiency of our sources of funding; and |

[0000926326-19-000025:mdna:19]
[same as prior period, unchanged from 0000926326-19-000013:mdna:19]

[0000926326-19-000025:mdna:20]
In some cases, you can identify forward-looking statements by terms such as "anticipates," "believes," "could," "estimates," "expects," "intends," "seeks," "may," "plans," "potential," "predicts," "projects," "should," "will," "would," “vision,” and variations of these terms and similar expressions. Forward-looking statements are based on our current expectations and assumptions and are subject to known and unknown risks and uncertainties, which may cause our actual results, performance, or achievements to be materially different from those expressed or implied in the forward-looking statements.

[0000926326-19-000025:mdna:21]
Such risks and uncertainties include those described throughout this quarterly report, particularly in Part II - Item 1A. “Risk Factors” below. Given these risks and uncertainties, you should not place undue reliance on these forward-looking statements. You should carefully read this quarterly report and the documents that we reference in this quarterly report and

[0000926326-19-000025:mdna:22]
[same as prior period, unchanged from 0000926326-19-000013:mdna:22]

[0000926326-19-000025:mdna:23]
[same as prior period, unchanged from 0000926326-19-000013:mdna:23]

[0000926326-19-000025:mdna:24]
[same as prior period, unchanged from 0000926326-19-000013:mdna:24]

[0000926326-19-000025:mdna:25]
[same as prior period, unchanged from 0000926326-19-000013:mdna:25]

[0000926326-19-000025:mdna:26]
[same as prior period, unchanged from 0000926326-19-000013:mdna:26]

[0000926326-19-000025:mdna:27]
We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 90% and 87% of our total revenues for the three months ended June 30, 2019 and 2018, respectively, and 89% and 87% of our total revenues for the six months ended June 30, 2019 and 2018, respectively. We have not in the past sold, and have no future plans to sell, our products, either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, or those subject to economic sanctions and export controls.

[0000926326-19-000025:mdna:28]
[same as prior period, unchanged from 0000926326-19-000013:mdna:28]

[0000926326-19-000025:mdna:29]
[same as prior period, unchanged from 0000926326-19-000013:mdna:29]

[0000926326-19-000025:mdna:30]
[same as prior period, unchanged from 0000926326-19-000013:mdna:30]

[0000926326-19-000025:mdna:31]
The healthcare market is experiencing a period of substantive change. In recent years, healthcare providers and facilities have faced increased spending on medication management, rising pharmaceutical costs, and substantial increases in healthcare administration. These factors, combined with continuing consolidation in the healthcare industry, have increased the need for the efficient delivery of healthcare in order to control costs and improve patient safety, and have elevated the strategic importance of medication management across the continuum of care. Furthermore, the adoption of electronic healthcare records, new regulatory constraints, and changes in reimbursement arrangements have caused healthcare institutions to re-examine their operating structures, re-prioritize their investments, and seek efficiencies. We believe the evolving operating

[0000926326-19-000025:mdna:32]
environments of our customers create challenges for any supplier, but also afford opportunities for suppliers that are able to partner with customers to help them meet the changing demands. We have invested, and intend to continue to invest in the strategies that we believe have generated, and will continue to generate, our revenue and earnings growth, while supporting initiatives and needs of our customers. These strategies include:

[0000926326-19-000025:mdna:33]
[same as prior period, unchanged from 0000926326-19-000013:mdna:32]

[0000926326-19-000025:mdna:34]
[same as prior period, unchanged from 0000926326-19-000013:mdna:33]

[0000926326-19-000025:mdna:35]
[same as prior period, unchanged from 0000926326-19-000013:mdna:34]

[0000926326-19-000025:mdna:36]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced generally by a non-cancelable contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are generally installable within twelve months and, other than sales based on subscription services, generally recorded as revenue upon customer receipt of goods or acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month.

[0000926326-19-000025:mdna:37]
In addition to product solution sales, we provide services to our customers. We provide installation planning and consulting as part of most product sales which is included in the initial price of the solution. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in increments of one to five years. As a result of the growth of our installed base of customers, our service revenues have also grown.

[0000926326-19-000025:mdna:38]
[same as prior period, unchanged from 0000926326-19-000013:mdna:37]

[0000926326-19-000025:mdna:39]
Our full-time headcount was approximately 2,560 and 2,480 on June 30, 2019 and December 31, 2018, respectively.

[0000926326-19-000025:mdna:40]
[same as prior period, unchanged from 0000926326-19-000013:mdna:39]

[0000926326-19-000025:mdna:41]
[same as prior period, unchanged from 0000926326-19-000013:mdna:40]

[0000926326-19-000025:mdna:42]
[same as prior period, unchanged from 0000926326-19-000013:mdna:41]

[0000926326-19-000025:mdna:43]
[same as prior period, unchanged from 0000926326-19-000013:mdna:42]

[0000926326-19-000025:mdna:44]
[same as prior period, unchanged from 0000926326-19-000013:mdna:43]

[0000926326-19-000025:mdna:45]
[same as prior period, unchanged from 0000926326-19-000013:mdna:44]

[0000926326-19-000025:mdna:46]
[same as prior period, unchanged from 0000926326-19-000013:mdna:45]

[0000926326-19-000025:mdna:47]
[same as prior period, unchanged from 0000926326-19-000013:mdna:46]

[0000926326-19-000025:mdna:48]
[same as prior period, unchanged from 0000926326-19-000013:mdna:47]

[0000926326-19-000025:mdna:49]
[same as prior period, unchanged from 0000926326-19-000013:mdna:48]

[0000926326-19-000025:mdna:50]
[same as prior period, unchanged from 0000926326-19-000013:mdna:49]

[0000926326-19-000025:mdna:51]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the six months ended June 30, 2019 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2018, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report.

[0000926326-19-000025:mdna:52]
[same as prior period, unchanged from 0000926326-19-000013:mdna:51]

[0000926326-19-000025:mdna:53]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-19-000025:mdna:54]
[same as prior period, unchanged from 0000926326-19-000013:mdna:53]

[0000926326-19-000025:mdna:55]
[same as prior period, unchanged from 0000926326-19-000013:mdna:54]

[0000926326-19-000025:mdna:56]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 158,379 |  |  | $ | 134,636 |  |  | $ | 23,743 |  |  | 18% |
| Percentage of total revenues | 73% |  | 71% |  |  |  |  |
| Services and other revenues | 59,034 |  |  | 54,037 |  |  | 4,997 |  |  | 9% |
| Percentage of total revenues | 27% |  | 29% |  |  |  |  |
| Total revenues | $ | 217,413 |  |  | $ | 188,673 |  |  | $ | 28,740 |  |  | 15% |

[0000926326-19-000025:mdna:57]
Product revenues represented 73% and 71% of total revenues for the three months ended June 30, 2019 and 2018, respectively. Product revenues increased by $23.7 million, primarily due to an increase in our Automated Dispensing Cabinet business, driven primarily by the growth of XT series products, as well as increases in revenues from IV solutions.

[0000926326-19-000025:mdna:58]
Services and other revenues represented 27% and 29% of total revenues for the three months ended June 30, 2019 and 2018, respectively. Services and other revenues include revenues from service and maintenance contracts, and rentals of automation systems. Services and other revenues increased by $5.0 million, primarily due to higher service renewal fees, driven mainly by an increase in our installed customer base, as well as an increase in revenues from Population Health Solutions.

[0000926326-19-000025:mdna:59]
Our international sales represented 10% and 13% of total revenues for the three months ended June 30, 2019 and 2018, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-19-000025:mdna:60]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 303,989 |  |  | $ | 265,295 |  |  | $ | 38,694 |  |  | 15% |
| Percentage of total revenues | 72% |  | 71% |  |  |  |  |
| Services and other revenues | 115,941 |  |  | 105,997 |  |  | 9,944 |  |  | 9% |
| Percentage of total revenues | 28% |  | 29% |  |  |  |  |
| Total revenues | $ | 419,930 |  |  | $ | 371,292 |  |  | $ | 48,638 |  |  | 13% |

[0000926326-19-000025:mdna:61]
Product revenues represented 72% and 71% of total revenues for the six months ended June 30, 2019 and 2018, respectively. Product revenues increased by $38.7 million, primarily due to an increase in our Automated Dispensing Cabinet business, driven primarily by the growth of XT series products, as well as an increase in revenues from consumables.

[0000926326-19-000025:mdna:62]
Services and other revenues represented 28% and 29% of total revenues for the six months ended June 30, 2019 and 2018, respectively. Services and other revenues include revenues from service and maintenance contracts, and rentals of automation systems. Services and other revenues increased by $9.9 million, primarily due to higher service renewal fees, driven mainly by an increase in our installed customer base, as well as an increase in revenues from Population Health Solutions.

[0000926326-19-000025:mdna:63]
Our international sales represented 11% and 13% of total revenues for the six months ended June 30, 2019 and 2018, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-19-000025:mdna:64]
Our ability to continue to grow revenues is dependent on our ability to continue to obtain orders from customers, our ability to produce quality products and consumables to fulfill customer demand, the volume of installations we are able to complete, our ability to meet customer needs by providing a quality installation experience, and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-19-000025:mdna:65]
[same as prior period, unchanged from 0000926326-19-000013:mdna:60]

[0000926326-19-000025:mdna:66]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs, which accounts for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site and include costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory, and amortization of software development costs and intangibles.

[0000926326-19-000025:mdna:67]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 84,583 |  |  | $ | 75,076 |  |  | $ | 9,507 |  |  | 13% |
| As a percentage of related revenues | 53% |  | 56% |  |  |  |  |
| Cost of services and other revenues | 28,785 |  |  | 24,814 |  |  | 3,971 |  |  | 16% |
| As a percentage of related revenues | 49% |  | 46% |  |  |  |  |
| Total cost of revenues | $ | 113,368 |  |  | $ | 99,890 |  |  | $ | 13,478 |  |  | 13% |
| As a percentage of total revenues | 52% |  | 53% |  |  |  |  |
| Gross profit | $ | 104,045 |  |  | $ | 88,783 |  |  | $ | 15,262 |  |  | 17% |
| Gross margin | 48% |  | 47% |  |  |  |  |

[0000926326-19-000025:mdna:68]
Cost of revenues for the three months ended June 30, 2019 compared to the three months ended June 30, 2018 increased by $13.5 million, of which $9.5 million was attributed to the increase in cost of product revenues and $4.0 million was attributed to the increase in cost of services and other revenues. The increase in cost of product revenues is primarily driven

[0000926326-19-000025:mdna:69]
by the increase in product revenues of $23.7 million for the three months ended June 30, 2019 compared to the three months ended June 30, 2018, partially offset by sales of product portfolios with higher margins. The increase in cost of services and other revenues is primarily driven by increase in services and other revenues of $5.0 million for the three months ended June 30, 2019 compared to the three months ended June 30, 2018, as well as product mix with lower margins.

[0000926326-19-000025:mdna:70]
The overall increase in gross margin primarily relates to lower costs associated with the XT series manufacturing ramp up and economies of scale. Our gross profit for the three months ended June 30, 2019 was $104.0 million, as compared to $88.8 million for the three months ended June 30, 2018.

[0000926326-19-000025:mdna:71]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 163,394 |  |  | $ | 150,493 |  |  | $ | 12,901 |  |  | 9% |
| As a percentage of related revenues | 54% |  | 57% |  |  |  |  |
| Cost of services and other revenues | 55,374 |  |  | 49,561 |  |  | 5,813 |  |  | 12% |
| As a percentage of related revenues | 48% |  | 47% |  |  |  |  |
| Total cost of revenues | $ | 218,768 |  |  | $ | 200,054 |  |  | $ | 18,714 |  |  | 9% |
| As a percentage of total revenues | 52% |  | 54% |  |  |  |  |
| Gross profit | $ | 201,162 |  |  | $ | 171,238 |  |  | $ | 29,924 |  |  | 17% |
| Gross margin | 48% |  | 46% |  |  |  |  |

[0000926326-19-000025:mdna:72]
Cost of revenues for the six months ended June 30, 2019 compared to the six months ended June 30, 2018 increased by $18.7 million, of which $12.9 million was attributed to the increase in cost of product revenues and $5.8 million was attributed to the increase in cost of services and other revenues. The increase in cost of product revenues is primarily driven by the increase in product revenues of $38.7 million for the six months ended June 30, 2019 compared to the six months ended June 30, 2018, partially offset by sales of product portfolios with higher margins. The increase in cost of services and other revenues is consistent with the increase in services and other revenues of $9.9 million for the six months ended June 30, 2019 compared to the six months ended June 30, 2018.

[0000926326-19-000025:mdna:73]
The overall increase in gross margin primarily relates to lower costs associated with the XT series manufacturing ramp up and economies of scale. Our gross profit for the six months ended June 30, 2019 was $201.2 million, as compared to $171.2 million for the six months ended June 30, 2018.

[0000926326-19-000025:mdna:74]
Operating Expenses and Interest and Other Income (Expense), Net

[0000926326-19-000025:mdna:75]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 16,848 |  |  | $ | 15,512 |  |  | $ | 1,336 |  |  | 9% |
| As a percentage of total revenues | 8% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 68,434 |  |  | 65,937 |  |  | 2,497 |  |  | 4% |
| As a percentage of total revenues | 31% |  | 35% |  |  |  |  |
| Total operating expenses | $ | 85,282 |  |  | $ | 81,449 |  |  | $ | 3,833 |  |  | 5% |
| As a percentage of total revenues | 39% |  | 43% |  |  |  |  |
| Interest and other income (expense), net | $ | (1,629 | ) |  | $ | (896 | ) |  | $ | (733 | ) |  | 82% |

[0000926326-19-000025:mdna:76]
Research and Development. Research and development expenses increased by $1.3 million for the three months ended June 30, 2019 compared to the three months ended June 30, 2018. The increase was primarily attributed to increased spend on

[0000926326-19-000025:mdna:77]
33

[0000926326-19-000025:mdna:78]
consulting expenses, as well as a higher headcount in the research and development function. This increase was partially offset by several research and development projects reaching capitalization stage during the three months ended June 30, 2019, decreasing research and development expenses, as we are allocating additional resources to software projects.

[0000926326-19-000025:mdna:79]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $2.5 million for the three months ended June 30, 2019 compared to the three months ended June 30, 2018, primarily due to growth of operations, substantially attributed to higher consulting and employee-related expenses.

[0000926326-19-000025:mdna:80]
Interest and Other Income (Expense), Net. Interest and other income (expense), net increased by $0.7 million for the three months ended June 30, 2019 compared to the three months ended June 30, 2018, primarily driven by a $2.2 million decrease in other income and a $1.5 million decrease in other expenses. The decrease in other income is primarily due to the $2.5 million contingent gain recognized during the three months ended June 30, 2018 related to a settlement agreement associated with the Ateb acquisition. The decrease in other expenses is primarily due to lower interest expense as a result of significant debt repayments during the year ended December 31, 2018 and six months ended June 30, 2019, as well as favorable foreign currency fluctuations during the period.

[0000926326-19-000025:mdna:81]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 32,926 |  |  | $ | 32,049 |  |  | $ | 877 |  |  | 3% |
| As a percentage of total revenues | 8% |  | 9% |  |  |  |  |
| Selling, general, and administrative | 136,712 |  |  | 131,222 |  |  | 5,490 |  |  | 4% |
| As a percentage of total revenues | 33% |  | 35% |  |  |  |  |
| Total operating expenses | $ | 169,638 |  |  | $ | 163,271 |  |  | $ | 6,367 |  |  | 4% |
| As a percentage of total revenues | 40% |  | 44% |  |  |  |  |
| Interest and other income (expense), net | $ | (3,039 | ) |  | $ | (3,625 | ) |  | $ | 586 |  |  | (16)% |

[0000926326-19-000025:mdna:82]
Research and Development. Research and development expenses increased by $0.9 million for the six months ended June 30, 2019 compared to the six months ended June 30, 2018. The increase was primarily attributed to increased spend on consulting expenses, as well as a higher headcount in the research and development function. This increase was partially offset by several research and development projects reaching capitalization stage during the six months ended June 30, 2019, decreasing research and development expenses, as we are allocating additional resources to software projects.

[0000926326-19-000025:mdna:83]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $5.5 million for the six months ended June 30, 2019 compared to the six months ended June 30, 2018, primarily due to growth of operations, substantially attributed to higher consulting and employee-related expenses.

[0000926326-19-000025:mdna:84]
Interest and Other Income (Expense), Net. Interest and other income (expense), net decreased by $0.6 million for the six months ended June 30, 2019 compared to the six months ended June 30, 2018, primarily driven by a $2.7 million decrease in other expenses and a $2.1 million decrease in other income. The decrease in other expenses is primarily due to lower interest expense as a result of significant debt repayments during the year ended December 31, 2018 and six months ended June 30, 2019, as well as favorable foreign currency fluctuations during the period. The decrease in other income is primarily due to the $2.5 million contingent gain recognized during the six months ended June 30, 2018 related to a settlement agreement associated with the Ateb acquisition.

[0000926326-19-000025:mdna:85]
[same as prior period, unchanged from 0000926326-19-000013:mdna:71]

[0000926326-19-000025:mdna:86]
|  | Three months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 1,158 |  |  | $ | (150 | ) |  | $ | 1,308 |  |  | (872)% |

[0000926326-19-000025:mdna:87]
|  | Six months ended June 30, |
|  |  |  |  |  | Change in |
|  | 2019 |  | 2018 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | 9,225 |  |  | $ | (4,966 | ) |  | $ | 14,191 |  |  | (286)% |

[0000926326-19-000025:mdna:88]
Our annual effective tax rate before discrete items was 24.8% and 16.5% for the six months ended June 30, 2019 and 2018, respectively. The increase in the estimated annual effective tax rate for the six months ended June 30, 2019 compared to the same period in 2018 was primarily due to state income taxes and non-deductible equity charges.

[0000926326-19-000025:mdna:89]
Provision for income taxes for the six months ended June 30, 2019 included net discrete income tax expense of $2.2 million. The net discrete income tax expense is primarily related to recognized gain on a sale of certain intellectual property rights by Aesynt Holdings Coöperatief U.A. to Omnicell, Inc. in the first quarter of 2019 offset by discrete income tax benefit of $7.0 million related to equity compensation.

[0000926326-19-000025:mdna:90]
Provision for income taxes for the six months ended June 30, 2018 included net discrete income tax benefit of $5.7 million. The net discrete income tax benefit was primarily associated with a recognized benefit of making a check-the-box election to treat Aesynt Holdings Coöperatief U.A. as a U.S. disregarded entity beginning the first quarter of 2018 and discrete income tax benefit of $2.6 million related to equity compensation.

[0000926326-19-000025:mdna:91]
Refer to Note 12, Income Taxes, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report for more details.

[0000926326-19-000025:mdna:92]
[same as prior period, unchanged from 0000926326-19-000013:mdna:74]

[0000926326-19-000025:mdna:93]
We had cash and cash equivalents of $87.5 million at June 30, 2019 compared to $67.2 million at December 31, 2018. All of our cash and cash equivalents are invested in bank accounts with major financial institutions.

[0000926326-19-000025:mdna:94]
Our cash position and working capital at June 30, 2019 and December 31, 2018 were as follows:

[0000926326-19-000025:mdna:95]
|  | June 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Cash | $ | 87,482 |  |  | $ | 67,192 |  |
| Working capital | $ | 218,455 |  |  | $ | 192,554 |  |

[0000926326-19-000025:mdna:96]
Our ratio of current assets to current liabilities was 2.0:1 at June 30, 2019 and 1.9:1 at December 31, 2018.

[0000926326-19-000025:mdna:97]
[same as prior period, unchanged from 0000926326-19-000013:mdna:79]

[0000926326-19-000025:mdna:98]
[same as prior period, unchanged from 0000926326-19-000013:mdna:80]

[0000926326-19-000025:mdna:99]
On January 5, 2016, we entered into a $400.0 million secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200.0 million term loan facility (the “Term Loan Facility”), and prior to the amendment discussed below, a $200.0 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million.

[0000926326-19-000025:mdna:100]
On December 26, 2017 and April 11, 2017, we entered into amendments to the Credit Agreement. Under these amendments, the Revolving Credit Facility was increased from $200.0 million to $315.0 million and certain other modifications were made. Refer to Note 8, Debt and Credit Agreements, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes, including acquisitions.

[0000926326-19-000025:mdna:101]
As of June 30, 2019, the outstanding balance from the Facilities was $80.0 million and we were in compliance with all covenants.

[0000926326-19-000025:mdna:102]
[same as prior period, unchanged from 0000926326-19-000013:mdna:84]

[0000926326-19-000025:mdna:103]
On November 3, 2017, we entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC and HSBC Securities (USA) Inc., as our sales agents, pursuant to which we may

[0000926326-19-000025:mdna:104]
offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of our common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange. We intend to use the net proceeds from the sale, if any, of common stock in the offering for general corporate purposes, which may include, without limitation, the acquisition of complementary businesses, the repayment of outstanding indebtedness, capital expenditures and working capital.

[0000926326-19-000025:mdna:105]
For the three months ended June 30, 2019, we received gross proceeds of $17.9 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.3 million on sales of approximately 217,000 shares of our common stock at an average price of approximately $82.51 per share.

[0000926326-19-000025:mdna:106]
For the six months ended June 30, 2019, we received gross proceeds of $38.5 million from sales of our common stock under the Distribution Agreement and incurred issuance costs of $0.7 million on sales of approximately 460,000 shares of our common stock at an average price of approximately $83.81 per share.

[0000926326-19-000025:mdna:107]
For the three and six months ended June 30, 2018, we did not sell any of our common stock under the Distribution Agreement.

[0000926326-19-000025:mdna:108]
As of June 30, 2019, we had an aggregate of $31.5 million available to be offered under the Distribution Agreement.

[0000926326-19-000025:mdna:109]
[same as prior period, unchanged from 0000926326-19-000013:mdna:88]

[0000926326-19-000025:mdna:110]
[same as prior period, unchanged from 0000926326-19-000013:mdna:89]

[0000926326-19-000025:mdna:111]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of June 30, 2019, which may result in additional use of cash. See “Stock Repurchase Program” under Note 13, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. There were no stock repurchases during the six months ended June 30, 2019 and 2018.

[0000926326-19-000025:mdna:112]
[same as prior period, unchanged from 0000926326-19-000013:mdna:91]

[0000926326-19-000025:mdna:113]
[same as prior period, unchanged from 0000926326-19-000013:mdna:92]

[0000926326-19-000025:mdna:114]
[same as prior period, unchanged from 0000926326-19-000013:mdna:93]

[0000926326-19-000025:mdna:115]
|  | Six months ended June 30, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 53,760 |  |  | $ | 40,727 |  |
| Investing activities | (31,950 | ) |  | (28,076 | ) |
| Financing activities | (1,583 | ) |  | 555 |  |
| Effect of exchange rate changes on cash and cash equivalents | 63 |  |  | 538 |  |
| Net increase in cash and cash equivalents | $ | 20,290 |  |  | $ | 13,744 |  |

[0000926326-19-000025:mdna:116]
[same as prior period, unchanged from 0000926326-19-000013:mdna:95]

[0000926326-19-000025:mdna:117]
[same as prior period, unchanged from 0000926326-19-000013:mdna:96]

[0000926326-19-000025:mdna:118]
Net cash provided by operating activities was $53.8 million for the six months ended June 30, 2019, primarily consisting of net income of $19.3 million adjusted for non-cash items of $53.1 million, offset by changes in assets and

[0000926326-19-000025:mdna:119]
liabilities of $18.6 million. The non-cash items primarily consisted of depreciation and amortization expense of $25.9 million, share-based compensation expense of $16.7 million, amortization of operating lease right-of-use asset amortization of $5.2 million, debt financing fees of $1.1 million, and a decrease in deferred income taxes of $3.8 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $9.2 million primarily due to an increase in billings, (ii) a decrease in accrued compensation of $8.0 million primarily due to a decrease in accrued commissions and restructuring expenses, as well as timing of payroll, (iii) a decrease in operating lease liabilities of $5.3 million, (iv) an increase in inventories of $4.5 million for inventory buildup in support of forecasted sales of new and existing products, and (v) an increase in investment in sales-type leases of $4.4 million. These cash outflows were partially offset by (i) an increase in other long-term liabilities of $3.9 million, (ii) a decrease in other long-term assets of $3.1 million, (iii) an increase in accounts payable of $2.1 million, (iv) an increase in accrued liabilities of $1.8 million, (v) a decrease in prepaid commissions of $1.5 million, and (vi) a decrease in prepaid expenses of $1.0 million.

[0000926326-19-000025:mdna:120]
Net cash provided by operating activities was $40.7 million for the six months ended June 30, 2018, primarily consisting of net income of $9.3 million adjusted for non-cash items of $33.1 million and changes in assets and liabilities of $1.7 million. The non-cash items primarily consisted of depreciation and amortization expense of $24.8 million, share-based compensation expense of $13.8 million, amortization of debt financing fees of $1.1 million, and an increase in deferred income taxes of $6.7 million. Changes in assets and liabilities include cash outflows from (i) a decrease in accounts payable of $12.2 million, primarily due to the timing of payments, (ii) an increase in inventories of $9.8 million due to inventory buildup in support of forecasted sales, (iii) an increase in other long-term assets of $2.8 million as a result of the increase in unbilled receivables, (iv) a decrease in accrued liabilities of $2.6 million, (v) an increase in other current assets of $2.3 million, and (vi) an increase in investment in sales-type leases of $1.8 million. These cash outflows were partially offset by (i) a decrease in accounts receivable and unbilled receivables of $15.5 million primarily due to an increase in collections and a decrease in billings, (ii) an increase in deferred revenues of $5.3 million due to timing of orders and revenues being recognized for installed product, (iii) an increase in accrued compensation of $3.9 million, (iv) a decrease in prepaid commissions of $2.8 million, and (v) a decrease in prepaid expenses of $2.1 million.

[0000926326-19-000025:mdna:121]
[same as prior period, unchanged from 0000926326-19-000013:mdna:99]

[0000926326-19-000025:mdna:122]
Net cash used in investing activities was $32.0 million for the six months ended June 30, 2019, which consisted of capital expenditures of $9.4 million for property and equipment, and $22.6 million for costs of software development for external use.

[0000926326-19-000025:mdna:123]
Net cash used in investing activities was $28.1 million for the six months ended June 30, 2018, which consisted of capital expenditures of $15.0 million for property and equipment and $13.1 million for costs of software development for external use.

[0000926326-19-000025:mdna:124]
[same as prior period, unchanged from 0000926326-19-000013:mdna:102]

[0000926326-19-000025:mdna:125]
Net cash used in financing activities was $1.6 million for the six months ended June 30, 2019, primarily due to the repayment of $60.0 million of the Facilities and $4.7 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $25.3 million in proceeds from employee stock option exercises and employee stock plan purchases, and proceeds of $37.8 million from sales of our common stock under the Distribution Agreement.

[0000926326-19-000025:mdna:126]
Net cash provided by financing activities was $0.6 million for the six months ended June 30, 2018, primarily from $16.1 million of proceeds from employee stock option exercises and employee stock plan purchases, partially offset by the repayment of $12.5 million of the Facilities and $3.1 million in employees’ taxes paid related to restricted stock unit vesting.

[0000926326-19-000025:mdna:127]
[same as prior period, unchanged from 0000926326-19-000013:mdna:105]

[0000926326-19-000025:mdna:128]
There have been no significant changes during the six months ended June 30, 2019 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2018.

[0000926326-19-000025:mdna:129]
Contractual obligations as of June 30, 2019 were as follows:

[0000926326-19-000025:mdna:130]
|  | Payments due by period |
|  | Total |  | Remainder of 2019 |  | 2020 - 2021 |  | 2022 - 2023 |  | 2024 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 81,583 |  |  | $ | 7,239 |  |  | $ | 26,324 |  |  | $ | 20,211 |  |  | $ | 27,809 |  |
| Purchase obligations (2) | 61,252 |  |  | 53,884 |  |  | 7,076 |  |  | 128 |  |  | 164 |  |
| Term loan facility (3) | 80,000 |  |  | — |  |  | 80,000 |  |  | — |  |  | — |  |
| Total (4) (5) | $ | 222,835 |  |  | $ | 61,123 |  |  | $ | 113,400 |  |  | $ | 20,339 |  |  | $ | 27,973 |  |

[0000926326-19-000025:mdna:131]
[same as prior period, unchanged from 0000926326-19-000013:mdna:109]

[0000926326-19-000025:mdna:132]
[same as prior period, unchanged from 0000926326-19-000013:mdna:110]

[0000926326-19-000025:mdna:133]
[same as prior period, unchanged from 0000926326-19-000013:mdna:111]

[0000926326-19-000025:mdna:134]
[same as prior period, unchanged from 0000926326-19-000013:mdna:112]

[0000926326-19-000025:mdna:135]
| (4) | We have recorded $9.8 million for uncertain tax positions under long-term liabilities as of June 30, 2019 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $9.8 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-19-000025:mdna:136]
| (5) | Refer to Note 11, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. |

[0000926326-19-000025:mdna:137]
[same as prior period, unchanged from 0000926326-19-000013:mdna:115]

[0000926326-19-000025:mdna:138]
As of June 30, 2019, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
