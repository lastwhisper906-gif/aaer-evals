# OMCL note change history — 0000926326-19-000013 → 0000926326-19-000025


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0000926326-19-000025:note_history:1]
Commitments and Contingencies
Purchase Obligations
  (was, 2019-05-03, similarity 0.7342):
[0000926326-19-000013:note_history:1]
Commitments and Contingencies

- changed (2019-08-02):
[0000926326-19-000025:note_history:2]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of June 30, 2019, the Company had non-cancelable purchase commitments of $61.3 million, of which $53.9 million are expected to be paid within the year ended December 31, 2019.
  (was, 2019-05-03, similarity 0.9835):
[0000926326-19-000013:note_history:2]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2019, the Company had non-cancelable purchase commitments of $71.0 million, of which $65.5 million are expected to be paid within the year ended December 31, 2019.

- changed (2019-08-02):
[0000926326-19-000025:note_history:3]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint seeks monetary recovery of compensatory and punitive damages in addition to
  (was, 2019-05-03, similarity 0.628):
[0000926326-19-000013:note_history:3]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint seeks monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt have not yet been served with the complaint. The Company intends to defend the lawsuit vigorously.

- added (2019-08-02):
[0000926326-19-000025:note_history:4]
certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice.

- changed (2019-08-02):
[0000926326-19-000025:note_history:5]
On June 6, 2018, a class action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint sought class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint was held in abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The Illinois Supreme Court issued its decision in that case on January 25, 2019. On April 10, 2019, subsequent to the court’s issuance of an order granting the plaintiff leave to file an amended complaint, the plaintiff filed an amended complaint adding a second named plaintiff and an affiliate of the Company’s customer as an additional defendant and, in addition to making other modifications to the complaint, removing the separate cause of action directed to negligence. The court established a deadline of May 13, 2019 for the defendants to answer or otherwise respond to the amended complaint. On May 10, 2019, defendants Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, and Northwestern Memorial Hospital removed the case to the United States District Court for the Northern District of Illinois, Eastern Division. Subsequently, on May 17, 2019, the Company and the other defendants in the case each filed a motion to dismiss the complaint for failure to state a cause of action upon which relief could be granted. On June 14, 2019, plaintiffs filed a motion to remand the case to state court. The Court then entered an order, on June 19, 2019, denying plaintiffs’ motion to remand, granting defendants’ motions to dismiss with respect to the additionally-named plaintiff, and continuing the motions to dismiss with respect to the originally-named plaintiff. On July 2, 2019, the Court entered an order remanding the case to state court and denying the defendants’ motions to dismiss without prejudice to renewal of the motions in state court. The Company intends to defend the lawsuit vigorously.
  (was, 2019-05-03, similarity 0.7598):
[0000926326-19-000013:note_history:5]
On June 6, 2018, a class-action lawsuit was filed against a customer of the Company, the customer’s parent company and two vendors of medication dispensing systems, one of which is the Company, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Yana Mazya, individually and on behalf of all others similarly situated v. Northwestern Lake Forest Hospital, Northwestern Memorial Healthcare, Omnicell, Inc. and Becton Dickinson, Case No. 2018-CH-07161. The complaint sought class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA and of negligence by the defendants. The complaint was served on the Company on June 15, 2018. The Company’s obligation to respond to the complaint was held in abeyance pending a decision of the Illinois Supreme Court in a separate case involving BIPA issues. The Illinois Supreme Court issued its decision in that case on January 25, 2019. On April 10, 2019, subsequent to the court’s issuance of an order granting the plaintiff leave to file an amended complaint, the plaintiff filed an amended complaint adding a second named plaintiff and an affiliate of the Company’s customer as an additional defendant and, in addition to making other modifications to the complaint, removing the separate cause of action directed to negligence. The court established a deadline of May 13, 2019 for the defendants to answer or otherwise respond to the amended complaint. The Company intends to defend the lawsuit vigorously.

- added (2019-08-02):
[0000926326-19-000025:note_history:6]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of BIPA, and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. The Company must file a response to the complaint by August 14, 2019. The Court has scheduled a case management conference for October 3, 2019. The Company intends to defend the lawsuit vigorously.

- added (2019-08-02):
[0000926326-19-000025:note_history:7]
On July 18, 2019, a putative class action lawsuit was filed against the Company and certain of its officers in the U.S. District Court for the Northern District of California. The complaint, captioned Bursick v. Omnicell, Inc. et al., Case No. 3:19-cv-04150, alleges that the defendants violated federal securities laws by making materially false and misleading statements beginning in October 2018 regarding revenue recognition, customer concerns about implementation issues, and a purported need to write off inventory. The plaintiff seeks unspecified monetary damages and other relief. The Company intends to defend the lawsuit vigorously.

- removed (2019-08-02):
[0000926326-19-000013:note_history:8]
Purchase Obligations


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0000926326-19-000025:note_history:9]
Organization and Summary of Significant Accounting Policies 
Business
  (was, 2019-05-03, similarity 0.9291):
[0000926326-19-000013:note_history:9]
Organization and Summary of Significant Accounting Policies

- changed (2019-08-02):
[0000926326-19-000025:note_history:10]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of June 30, 2019 and December 31, 2018, the results of operations and comprehensive income for the three and six months ended June 30, 2019 and 2018, and cash flows for the six months ended June 30, 2019 and 2018. Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States Generally Accepted Accounting Principles (“U.S. GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2018 filed with the SEC on February 27, 2019, except as discussed in the sections entitled “Lessor Leases”, “Lessee Leases”, and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and six months ended June 30, 2019 and cash flows for the six months ended June 30, 2019 are not necessarily indicative of results that may be expected for the year ending December 31, 2019, or for any future period.
  (was, 2019-05-03, similarity 0.8153):
[0000926326-19-000013:note_history:10]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2019 and December 31, 2018, and the results of operations, comprehensive income, and cash flows for the three months ended March 31, 2019 and 2018. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2018 filed with the SEC on February 27, 2019, except as discussed in the sections entitled “Lessor Leases”, “Lessee Leases’, and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations, comprehensive income, and cash flows for the three months ended March 31, 2019 are not necessarily indicative of results that may be expected for the year ending December 31, 2019, or for any future period.

- changed (2019-08-02):
[0000926326-19-000025:note_history:11]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases;
  (was, 2019-05-03, similarity 0.8733):
[0000926326-19-000013:note_history:11]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition; accounts receivable and notes receivable from investment in sales-type leases; operating lease right-of-use assets and liabilities; inventory valuation; capitalized software development costs; impairment of goodwill; purchased intangibles and long-lived assets; share-based compensation; and accounting for income taxes.

- added (2019-08-02):
[0000926326-19-000025:note_history:12]
operating lease right-of-use assets and liabilities; inventory valuation; capitalized software development costs; impairment of goodwill; purchased intangibles and long-lived assets; share-based compensation; and accounting for income taxes.

- changed (2019-08-02):
[0000926326-19-000025:note_history:13]
For operating leases, rental income is generally recognized on a straight-line basis over the term of the associated lease, and recorded in services and other revenues in the Condensed Consolidated Statements of Operations. Leased assets under operating leases are carried at amortized cost net of accumulated depreciation in property and equipment, net on the Condensed Consolidated Balance Sheets. The depreciation expense of the leased assets is recognized on a straight-line basis over the contractual term of the associated lease, and recorded in cost of revenues in the Condensed Consolidated Statements of Operations.
  (was, 2019-05-03, similarity 0.9845):
[0000926326-19-000013:note_history:13]
For operating leases, rental income is generally recognized on a straight-line basis over the term of the associated lease, and recorded in revenues in the Condensed Consolidated Statements of Operations. Leased assets under operating leases are carried at amortized cost net of accumulated depreciation in property and equipment, net on the Condensed Consolidated Balance Sheets. The depreciation expense of the leased assets is recognized on a straight-line basis over the contractual term of the associated lease, and recorded in cost of revenues in the Condensed Consolidated Statements of Operations.

- changed (2019-08-02):
[0000926326-19-000025:note_history:14]
The Company’s adoption of the new standard impacted the Condensed Consolidated Balance Sheets at the beginning of the period of adoption as follows:
  (was, 2019-05-03, similarity 0.9966):
[0000926326-19-000013:note_history:14]
The Company’s adoption of the new standard impacted the Condensed Consolidated Balances Sheets at the beginning of the period of adoption as follows:

- changed (2019-08-02):
[0000926326-19-000025:note_history:15]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects.” ASU 2018-02 is effective for the Company beginning January 1, 2019. The adoption of
  (was, 2019-05-03, similarity 0.8534):
[0000926326-19-000013:note_history:15]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 (the “Tax Act”) on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects.” ASU 2018-02 is effective for the Company beginning January 1, 2019. The adoption of this guidance did not have a material effect on the Company’s consolidated financial statements and therefore no adjustment to retained earnings was made.

- added (2019-08-02):
[0000926326-19-000025:note_history:16]
this guidance did not have a material effect on the Company’s consolidated financial statements and therefore no adjustment to retained earnings was made.

- added (2019-08-02):
[0000926326-19-000025:note_history:17]
In June 2016, the FASB issued ASU No. 2016-13, Financial Instruments-Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans, and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans and held-to-maturity debt securities, the standard will replace the current “incurred loss” approach with an “expected loss” model. Entities will be required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. ASU 2016-13 will be effective for the Company beginning January 1, 2020. The Company is currently evaluating the impact ASU 2016-13 will have on its consolidated financial statements.

- removed (2019-08-02):
[0000926326-19-000013:note_history:18]
Business

- removed (2019-08-02):
[0000926326-19-000013:note_history:19]
The Company reclassified $0.6 million from services and other revenues to product revenues for the three months ended March 31, 2018 related to software term-license sales to conform with current period presentation. This reclassification did not have a material impact on the condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0000926326-19-000025:note_history:20]
Debt and Credit Agreements
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.
  (was, 2019-05-03, similarity 0.985):
[0000926326-19-000013:note_history:20]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

- added (2019-08-02):
[0000926326-19-000025:note_history:21]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is

- changed (2019-08-02):
[0000926326-19-000025:note_history:22]
required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain permitted asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.
  (was, 2019-05-03, similarity 0.8973):
[0000926326-19-000013:note_history:22]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

- changed (2019-08-02):
[0000926326-19-000025:note_history:23]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $0.9 million and $1.9 million for the three months ended June 30, 2019 and 2018, respectively, and approximately $2.2 million and $3.8 million for the six months ended June 30, 2019 and 2018, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million and $0.6 million for the three months ended June 30, 2019 and 2018, respectively, and approximately $1.1 million and $1.1 million for the six months ended June 30, 2019 and 2018, respectively. The Company was in compliance with all covenants as of June 30, 2019 and December 31, 2018.
  (was, 2019-05-03, similarity 0.7367):
[0000926326-19-000013:note_history:23]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.3 million and $1.9 million for the three months ended March 31, 2019 and 2018, respectively. Amortization expense related to fees and issuance cost was approximately $0.6 million for both the three months ended March 31, 2019 and 2018. The Company was in compliance with all covenants as of March 31, 2019 and December 31, 2018.

- changed (2019-08-02):
[0000926326-19-000025:note_history:24]
During the six months ended June 30, 2019, the Company repaid $60.0 million under these Facilities.
  (was, 2019-05-03, similarity 0.9071):
[0000926326-19-000013:note_history:24]
During the three months ended March 31, 2019, the Company repaid $39.0 million under these Facilities.

- changed (2019-08-02):
[0000926326-19-000025:note_history:25]
The components of the Company’s debt obligations as of June 30, 2019 and December 31, 2018 were as follows:
  (was, 2019-05-03, similarity 0.9538):
[0000926326-19-000013:note_history:25]
The components of the Company’s debt obligations as of March 31, 2019 and December 31, 2018 were as follows:

- changed (2019-08-02):
[0000926326-19-000025:note_history:26]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | June 30, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (60,000 | ) |  | $ | 80,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (60,000 | ) |  | 80,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 1,145 |  |  | (3,438 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (58,855 | ) |  | $ | 76,562 |  |
  (was, 2019-05-03, similarity 0.9905):
[0000926326-19-000013:note_history:26]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | March 31, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (39,000 | ) |  | $ | 101,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (39,000 | ) |  | 101,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 573 |  |  | (4,010 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (38,427 | ) |  | $ | 96,990 |  |

- changed (2019-08-02):
[0000926326-19-000025:note_history:27]
As of June 30, 2019, the carrying amount of debt of $80.0 million approximates the comparable fair value of $80.2 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of June 30, 2019 as compared to December 31, 2018.
  (was, 2019-05-03, similarity 0.9232):
[0000926326-19-000013:note_history:27]
As of March 31, 2019, the carrying amount of debt of $101.0 million approximates the comparable fair value of $103.5 million. The Company’s debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments and long-term credit ratings. There have been no significant changes in the assumptions used as of March 31, 2019 as compared to December 31, 2018.

- removed (2019-08-02):
[0000926326-19-000013:note_history:28]
Debt and Credit Agreements


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0000926326-19-000025:note_history:29]
The components of the Company’s debt obligations as of June 30, 2019 and December 31, 2018 were as follows:
  (was, 2019-05-03, similarity 0.9538):
[0000926326-19-000013:note_history:29]
The components of the Company’s debt obligations as of March 31, 2019 and December 31, 2018 were as follows:

- changed (2019-08-02):
[0000926326-19-000025:note_history:30]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | June 30, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (60,000 | ) |  | $ | 80,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (60,000 | ) |  | 80,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 1,145 |  |  | (3,438 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (58,855 | ) |  | $ | 76,562 |  |
  (was, 2019-05-03, similarity 0.9905):
[0000926326-19-000013:note_history:30]
|  | December 31, 2018 |  | Borrowings |  | Repayment / Amortization |  | March 31, 2019 |
|  | (In thousands) |
| Term loan facility | $ | 140,000 |  |  | $ | — |  |  | $ | (39,000 | ) |  | $ | 101,000 |  |
| Revolving credit facility | — |  |  | — |  |  | — |  |  | — |  |
| Total debt under the facilities | 140,000 |  |  | — |  |  | (39,000 | ) |  | 101,000 |  |
| Less: Deferred issuance cost | (4,583 | ) |  | — |  |  | 573 |  |  | (4,010 | ) |
| Total long-term debt, net of deferred issuance cost | $ | 135,417 |  |  | $ | — |  |  | $ | (38,427 | ) |  | $ | 96,990 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0000926326-19-000025:note_history:31]
Revenues
Revenue Recognition
  (was, 2019-05-03, similarity 0.8085):
[0000926326-19-000013:note_history:31]
Revenue Recognition

- changed (2019-08-02):
[0000926326-19-000025:note_history:32]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.6 million and $2.1 million for the three months ended June 30, 2019 and 2018, respectively, and $4.8 million and $4.0 million for the six months ended June 30, 2019 and 2018, respectively.
  (was, 2019-05-03, similarity 0.9054):
[0000926326-19-000013:note_history:32]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.2 million and $1.9 million for the three months ended March 31, 2019 and 2018, respectively.

- changed (2019-08-02):
[0000926326-19-000025:note_history:33]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and six months ended June 30, 2019 and 2018:
  (was, 2019-05-03, similarity 0.9386):
[0000926326-19-000013:note_history:33]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three months ended March 31, 2019 and 2018:

- changed (2019-08-02):
[0000926326-19-000025:note_history:34]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Hardware and software | $ | 135,022 |  |  | $ | 112,031 |  |  | $ | 255,243 |  |  | $ | 219,482 |  |
| Consumables | 19,416 |  |  | 19,670 |  |  | 40,503 |  |  | 39,108 |  |
| Other | 3,941 |  |  | 2,935 |  |  | 8,243 |  |  | 6,705 |  |
| Total product revenues | $ | 158,379 |  |  | $ | 134,636 |  |  | $ | 303,989 |  |  | $ | 265,295 |  |
  (was, 2019-05-03, similarity 0.7387):
[0000926326-19-000013:note_history:34]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Hardware and software | $ | 120,221 |  |  | $ | 107,451 |  |
| Consumables | 21,087 |  |  | 19,438 |  |
| Other | 4,302 |  |  | 3,770 |  |
| Total product revenues | $ | 145,610 |  |  | $ | 130,659 |  |

- changed (2019-08-02):
[0000926326-19-000025:note_history:35]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and six months ended June 30, 2019 and 2018:
  (was, 2019-05-03, similarity 0.9539):
[0000926326-19-000013:note_history:35]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2019 and 2018:

- changed (2019-08-02):
[0000926326-19-000025:note_history:36]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| United States | $ | 195,811 |  |  | $ | 163,645 |  |  | $ | 375,831 |  |  | $ | 321,847 |  |
| Rest of world (1) | 21,602 |  |  | 25,028 |  |  | 44,099 |  |  | 49,445 |  |
| Total revenues | $ | 217,413 |  |  | $ | 188,673 |  |  | $ | 419,930 |  |  | $ | 371,292 |  |
  (was, 2019-05-03, similarity 0.7601):
[0000926326-19-000013:note_history:36]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| United States | $ | 180,020 |  |  | $ | 158,202 |  |
| Rest of world (1) | 22,497 |  |  | 24,417 |  |
| Total revenues | $ | 202,517 |  |  | $ | 182,619 |  |

- changed (2019-08-02):
[0000926326-19-000025:note_history:37]
|  | June 30, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 10,667 |  |  | $ | 9,191 |  |
| Long-term unbilled receivables - included in other long-term assets | 13,630 |  |  | 16,481 |  |
| Total contract assets | $ | 24,297 |  |  | $ | 25,672 |  |
| Short-term deferred revenues, net | $ | 83,012 |  |  | $ | 81,835 |  |
| Long-term deferred revenues | 9,658 |  |  | 10,582 |  |
| Total contract liabilities | $ | 92,670 |  |  | $ | 92,417 |  |
  (was, 2019-05-03, similarity 0.9903):
[0000926326-19-000013:note_history:37]
|  | March 31, 2019 |  | December 31, 2018 |
|  | (In thousands) |
| Short-term unbilled receivables - included in accounts receivable and unbilled receivables | $ | 8,708 |  |  | $ | 9,191 |  |
| Long-term unbilled receivables - included in other long-term assets | 11,423 |  |  | 16,481 |  |
| Total contract assets | $ | 20,131 |  |  | $ | 25,672 |  |
| Short-term deferred revenues, net | $ | 90,104 |  |  | $ | 81,835 |  |
| Long-term deferred revenues | 10,302 |  |  | 10,582 |  |
| Total contract liabilities | $ | 100,406 |  |  | $ | 92,417 |  |

- changed (2019-08-02):
[0000926326-19-000025:note_history:38]
The portion of the transaction price allocated to the Company’s unsatisfied performance obligations for which invoicing has occurred is recorded as deferred revenues.
  (was, 2019-05-03, similarity 0.8896):
[0000926326-19-000013:note_history:38]
The portion of the transaction price allocated to the Company’s unsatisfied performance obligations is recorded as deferred revenues.

- changed (2019-08-02):
[0000926326-19-000025:note_history:39]
Short-term deferred revenues of $83.0 million and $81.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales, of $12.0 million and $11.1 million as of June 30, 2019 and December 31, 2018, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and six months ended June 30, 2019, the Company recognized revenues of $25.7 million and $65.0 million that were included in the corresponding gross short-term deferred revenues balance of $92.9 million as of December 31, 2018.
  (was, 2019-05-03, similarity 0.7834):
[0000926326-19-000013:note_history:39]
Short-term deferred revenues of $90.1 million and $81.8 million include deferred revenues from product sales and service contracts, net of deferred cost of sales, of $12.2 million and $11.1 million as of March 31, 2019 and December 31, 2018, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three months ended March 31, 2019, the Company recognized revenues of $39.3 million that were included in the corresponding gross short-term deferred revenues balance of $92.9 million as of December 31, 2018.

- changed (2019-08-02):
[0000926326-19-000025:note_history:40]
Long-term deferred revenues include deferred revenues from service contracts of $9.7 million and $10.6 million as of June 30, 2019 and December 31, 2018, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.
  (was, 2019-05-03, similarity 0.9864):
[0000926326-19-000013:note_history:40]
Long-term deferred revenues include deferred revenues from service contracts of $10.3 million and $10.6 million as of March 31, 2019 and December 31, 2018, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

- changed (2019-08-02):
[0000926326-19-000025:note_history:41]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and six months ended June 30, 2019 and 2018. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable as of June 30, 2019 and December 31, 2018.
  (was, 2019-05-03, similarity 0.9019):
[0000926326-19-000013:note_history:41]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2019 and 2018. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable as of March 31, 2019 and December 31, 2018.

- removed (2019-08-02):
[0000926326-19-000013:note_history:42]
Revenues


## us-gaap:RevenueRecognitionMultipleDeliverableArrangementsTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0000926326-19-000025:note_history:43]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and six months ended June 30, 2019 and 2018:
  (was, 2019-05-03, similarity 0.9386):
[0000926326-19-000013:note_history:43]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three months ended March 31, 2019 and 2018:

- changed (2019-08-02):
[0000926326-19-000025:note_history:44]
|  | Three months ended June 30, |  | Six months ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | (In thousands) |
| Hardware and software | $ | 135,022 |  |  | $ | 112,031 |  |  | $ | 255,243 |  |  | $ | 219,482 |  |
| Consumables | 19,416 |  |  | 19,670 |  |  | 40,503 |  |  | 39,108 |  |
| Other | 3,941 |  |  | 2,935 |  |  | 8,243 |  |  | 6,705 |  |
| Total product revenues | $ | 158,379 |  |  | $ | 134,636 |  |  | $ | 303,989 |  |  | $ | 265,295 |  |
  (was, 2019-05-03, similarity 0.7387):
[0000926326-19-000013:note_history:44]
|  | Three months ended March 31, |
|  | 2019 |  | 2018 |
|  | (In thousands) |
| Hardware and software | $ | 120,221 |  |  | $ | 107,451 |  |
| Consumables | 21,087 |  |  | 19,438 |  |
| Other | 4,302 |  |  | 3,770 |  |
| Total product revenues | $ | 145,610 |  |  | $ | 130,659 |  |
