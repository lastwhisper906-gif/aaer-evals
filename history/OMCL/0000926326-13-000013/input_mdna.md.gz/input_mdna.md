# OMCL MD&A — 0000926326-13-000013


## mdna

[0000926326-13-000013:mdna:1]
[same as prior period, unchanged from 0000926326-13-000010:mdna:1]

[0000926326-13-000013:mdna:2]
[same as prior period, unchanged from 0000926326-13-000010:mdna:2]

[0000926326-13-000013:mdna:3]
[same as prior period, unchanged from 0000926326-13-000010:mdna:3]

[0000926326-13-000013:mdna:4]
[same as prior period, unchanged from 0000926326-13-000010:mdna:4]

[0000926326-13-000013:mdna:5]
[same as prior period, unchanged from 0000926326-13-000010:mdna:5]

[0000926326-13-000013:mdna:6]
[same as prior period, unchanged from 0000926326-13-000010:mdna:6]

[0000926326-13-000013:mdna:7]
[same as prior period, unchanged from 0000926326-13-000010:mdna:7]

[0000926326-13-000013:mdna:8]
[same as prior period, unchanged from 0000926326-13-000010:mdna:8]

[0000926326-13-000013:mdna:9]
[same as prior period, unchanged from 0000926326-13-000010:mdna:9]

[0000926326-13-000013:mdna:10]
[same as prior period, unchanged from 0000926326-13-000010:mdna:10]

[0000926326-13-000013:mdna:11]
[same as prior period, unchanged from 0000926326-13-000010:mdna:11]

[0000926326-13-000013:mdna:12]
[same as prior period, unchanged from 0000926326-13-000010:mdna:12]

[0000926326-13-000013:mdna:13]
In some cases, you can identify forward-looking statements by terms such as "anticipates," "believes," "could," "estimates," "expects," "intends," "may," "plans," "potential," "predicts," "projects," "should," "will," "would" and similar expressions intended to identify forward-looking statements. Forward-looking statements reflect our current views with respect to future events, are based on assumptions and are subject to risks and uncertainties.  We discuss many of these risks in this Quarterly Report on Form 10-Q in greater detail in Part II - Section 1A. “Risk Factors” below. Given these uncertainties, you should not place undue reliance on these forward-looking statements. Also, forward-looking statements represent our estimates

[0000926326-13-000013:mdna:14]
and assumptions only as of the date of this Quarterly Report on Form 10-Q. You should also read our Annual Report on Form 10-K and the documents that we reference in the Annual Report on Form 10-K and have filed as exhibits, completely and with the understanding that our actual future results may be materially different from what we expect.  All references in this report to "Omnicell, Inc.," "Omnicell," "our," "us," "we," or the "Company" collectively refer to Omnicell, Inc., a Delaware corporation, and its subsidiaries.

[0000926326-13-000013:mdna:15]
[same as prior period, unchanged from 0000926326-13-000010:mdna:14]

[0000926326-13-000013:mdna:16]
[same as prior period, unchanged from 0000926326-13-000010:mdna:15]

[0000926326-13-000013:mdna:17]
Approximately 2,800 hospitals use one or more of our products, of which more than 1,700 hospitals in the United States have installed our automated hardware/software solutions for controlling, dispensing, acquiring, verifying, tracking and analyzing medications and medical and surgical supplies. Approximately 6,000 institutional and retail pharmacies use our medication adherence packaging solutions.

[0000926326-13-000013:mdna:18]
The medical industry has become increasingly aware that human factors inevitably create the risk of medication administration errors in the course of patient care.

[0000926326-13-000013:mdna:19]
[same as prior period, unchanged from 0000926326-13-000010:mdna:18]

[0000926326-13-000013:mdna:20]
[same as prior period, unchanged from 0000926326-13-000010:mdna:19]

[0000926326-13-000013:mdna:21]
[same as prior period, unchanged from 0000926326-13-000010:mdna:20]

[0000926326-13-000013:mdna:22]
[same as prior period, unchanged from 0000926326-13-000010:mdna:21]

[0000926326-13-000013:mdna:23]
[same as prior period, unchanged from 0000926326-13-000010:mdna:22]

[0000926326-13-000013:mdna:24]
In acute care facilities, our solutions use advanced, software‑based medication control and tracking algorithms that interact with hardware security features, resulting in a system that provides both the pharmacist and the nurse real-time safety controls. Our solutions also go a step further by providing medication bar code verification at every step of the medication administration process, from entry to the hospital through to administration to a patient. Our systems enable our customers to reduce or eliminate inefficiencies such as manual tracking and reconciliations, nursing time spent in obtaining medications and in performing inventory control and extraneous process steps.

[0000926326-13-000013:mdna:25]
Similar to our medication solutions, our medical and surgical supply systems provide acute care hospitals control over consumable supplies critical to providing quality healthcare. Our solutions provide inventory control software that is designed to ensure critical supplies are always stocked in the right locations. At the same time, usage tracking helps hospital administrators to ensure that money is not wasted on excessive stores of supplies and helps optimize reimbursement by

[0000926326-13-000013:mdna:26]
improving charge capture. Our systems automate the tracking of activities in perioperative areas such as the operating room and catheter lab, including tracking implantable tissue grafts for additional patient safety and regulatory compliance.

[0000926326-13-000013:mdna:27]
Additionally, we offer analytics and reporting software for pharmacists and material managers to more easily manage inventory flow, tracking and optimization. These reports are often used to identify hospital employees who may be improperly diverting pharmaceuticals stored in the automated dispensing cabinets. Such diversion or theft, especially of controlled substances, could result in black market sales or other illicit uses.

[0000926326-13-000013:mdna:28]
[same as prior period, unchanged from 0000926326-13-000010:mdna:26]

[0000926326-13-000013:mdna:29]
Our Non-Acute Care product lines were primarily added to our solutions through the acquisition of MedPak Holdings, Inc. ("MedPak") in May 2012. MedPak is the parent company of MTS Medication Technologies, Inc. ("MTS"), a worldwide provider of medication adherence packaging systems, and a wholly-owned Omnicell subsidiary. MTS manufactures proprietary medication dispensing systems and related products for use by medication prescription providers: primarily institutional pharmacies servicing long-term care and correctional facilities. These systems use consumable medication punch cards and specialized machines that allow the pharmacies to automatically or semi-automatically assemble, fill and seal drugs into medication punch cards representing a weekly or monthly supply of a patient's medication. The use of these cards and machines provides a cost-effective customized package personalized to the patient. The punch card medication dispensing system provides tamper evident packaging and promotes medication compliance.

[0000926326-13-000013:mdna:30]
[same as prior period, unchanged from 0000926326-13-000010:mdna:28]

[0000926326-13-000013:mdna:31]
[same as prior period, unchanged from 0000926326-13-000010:mdna:29]

[0000926326-13-000013:mdna:32]
Our solutions are aligned with the long-term trends of the healthcare market to assist in the management of patient health across the continuum of care.

[0000926326-13-000013:mdna:33]
[same as prior period, unchanged from 0000926326-13-000010:mdna:31]

[0000926326-13-000013:mdna:34]
| • | Further penetrating the existing market through providing differentiated, innovative solutions, which includes: |

[0000926326-13-000013:mdna:35]
[same as prior period, unchanged from 0000926326-13-000010:mdna:33]

[0000926326-13-000013:mdna:36]
•Maintaining our flexibility in customer product design and in the installation process to provide solutions tailored to our customers.

[0000926326-13-000013:mdna:37]
| • | Increasing penetration of new markets by: |

[0000926326-13-000013:mdna:38]
[same as prior period, unchanged from 0000926326-13-000010:mdna:36]

[0000926326-13-000013:mdna:39]
•Bringing new products and technologies to market that address currently unsolved problems;

[0000926326-13-000013:mdna:40]
[same as prior period, unchanged from 0000926326-13-000010:mdna:37]

[0000926326-13-000013:mdna:41]
| • | Partnering with companies that have sales, distribution or other capabilities that we do not possess; and |

[0000926326-13-000013:mdna:42]
[same as prior period, unchanged from 0000926326-13-000010:mdna:39]

[0000926326-13-000013:mdna:43]
[same as prior period, unchanged from 0000926326-13-000010:mdna:40]

[0000926326-13-000013:mdna:44]
Operations During the Three and Six Months Ended June 30, 2013

[0000926326-13-000013:mdna:45]
The consolidated operating results presented for the six months ended June 30, 2013 and the six months ended June 30, 2012, reflect the impact of the acquisition of MTS since May 21, 2012 as a part of the Non-Acute Care segment.

[0000926326-13-000013:mdna:46]
Revenues grew year-over-year for both product and services, with overall revenue growth of 24.3%, comparing $93.7 million for the second quarter of 2013 with $75.4 million for the second quarter of 2012. Overall revenue growth was 29.6% for the six months ended June 30, 2013 comparing $180.8 million with $139.5 million for the same period in 2012. Much of the growth was a result of the acquisition of MTS, which now comprises a substantial portion of the Non-Acute Care segment, and whose prior year operating results were not included in our consolidated operating results prior to the date of acquisition, May 21, 2012.

[0000926326-13-000013:mdna:47]
For the three months ended June 30, 2013, the Non-Acute Care segment contributed $24.3 million and $1.2 million to the overall product and service revenue, respectively as compared to $10.3 million and $0.7 million during the same period in 2012. The Acute Care segment contributed revenues of $51.2 million and $16.9 million to product and service revenue respectively, for the three months ended June 30, 2013 as compared to $48.9 million and $15.4 million during the same period in 2012. Overall product and service margins increased by $10.0 million, or 25.4% for the three months ended June 30, 2013 as compared to the same period in 2012.

[0000926326-13-000013:mdna:48]
For the six months ended June 30, 2013, the Non-Acute Care segment contributed $44.2 million and $2.5 million to the overall product and service revenue, respectively as compared to $11.5 million and $1.1 million during the same period in 2012. The Acute Care segment contributed revenues of $100.6 million and $33.5 million to product and service revenue, respectively, for the six months ended June 30, 2013 as compared to $96.3 million and $30.6 million during the same period in 2012. Overall product and service margins increased by $19.6 million, or 26.1% for the six months ended June 30, 2013 as compared to the same period in 2012.

[0000926326-13-000013:mdna:49]
During the three months ended June 30, 2013, we recognized an increase of $6.6 million, or 7.5% in total revenues from the three months ended March 31, 2013. Product revenue increased by $6.3 million, or 9.2%, while service revenue increased slightly, by 1.3%. Overall gross margins for the second quarter of 2013 increased slightly to 52.7% from 52.1% in the three months ended March 31, 2013. Product gross margins increased to 52.0% on revenue of $75.6 million for the three months ended June 30, 2013 as compared with 51.5% on revenue of $69.2 million during the first quarter of 2013. Service gross margins also increased, to 55.6% on revenue of $18.1 million as compared to 54.1% margins on $17.9 million in revenue during the first quarter of 2013.

[0000926326-13-000013:mdna:50]
Cash, cash equivalents and short-term investments increased by $25.0 million during the six months ended June 30, 2013, to $87.3 million from $62.3 million at December 31, 2012 primarily due to increased profitability, increased collection activity and cash received for shares issued under our stock option and employee stock purchase plans.

[0000926326-13-000013:mdna:51]
During the six months ended June 30, 2013, we implemented a reorganization within our Non-Acute Care segment. This reorganization reduced headcount slightly and as a result, we incurred $0.7 million in severance and related expenses and an additional $0.4 million related to accelerated stock option vesting in the three months ended March 31, 2013. This reorganization is intended to promote a stronger integration strategy, customer and segment focus, and future growth. As part of this reorganization, we are reassessing the current composition of our operating segments which could result in future modifications to the current segment presentation.

[0000926326-13-000013:mdna:52]
[same as prior period, unchanged from 0000926326-13-000010:mdna:48]

[0000926326-13-000013:mdna:53]
[same as prior period, unchanged from 0000926326-13-000010:mdna:49]

[0000926326-13-000013:mdna:54]
[same as prior period, unchanged from 0000926326-13-000010:mdna:50]

[0000926326-13-000013:mdna:55]
[same as prior period, unchanged from 0000926326-13-000010:mdna:51]

[0000926326-13-000013:mdna:56]
[same as prior period, unchanged from 0000926326-13-000010:mdna:52]

[0000926326-13-000013:mdna:57]
[same as prior period, unchanged from 0000926326-13-000010:mdna:53]

[0000926326-13-000013:mdna:58]
[same as prior period, unchanged from 0000926326-13-000010:mdna:54]

[0000926326-13-000013:mdna:59]
[same as prior period, unchanged from 0000926326-13-000010:mdna:55]

[0000926326-13-000013:mdna:60]
During the six months ended June 30, 2013, there were no significant changes in our critical accounting policies and estimates.

[0000926326-13-000013:mdna:61]
[same as prior period, unchanged from 0000926326-13-000010:mdna:57]

[0000926326-13-000013:mdna:62]
Recently Adopted Accounting Standards

[0000926326-13-000013:mdna:63]
[same as prior period, unchanged from 0000926326-13-000010:mdna:59]

[0000926326-13-000013:mdna:64]
[same as prior period, unchanged from 0000926326-13-000010:mdna:60]

[0000926326-13-000013:mdna:65]
Effective in the second quarter of fiscal 2013, management changed its methodology for allocating certain expenses to its reportable segments. We have reclassified segment operating results for the three and six months ended June 30, 2012 to conform to the fiscal 2013 presentation. The table below shows the components of our consolidated results of operations as percentages of total revenues for the three months and six months ended June 30, 2013 and 2012 (in thousands, except

[0000926326-13-000013:mdna:66]
percentages):

[0000926326-13-000013:mdna:67]
|  | Three Months Ended June 30, |  |
|  | 2013 |  | 2012 |  |
|  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 75,581 |  |  | 80.7 | % |  | $ | 59,269 |  |  | 78.6 | % |  |
| Service and other revenues | 18,105 |  |  | 19.3 | % |  | 16,115 |  |  | 21.4 | % |  |
| Total revenues | 93,686 |  |  | 100.0 | % |  | 75,384 |  |  | 100.0 | % |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 36,286 |  |  | 38.7 | % |  | 28,600 |  |  | 38.0 | % |  |
| Cost of service and other revenues | 8,032 |  |  | 8.6 | % |  | 7,408 |  |  | 9.8 | % |  |
| Total cost of revenues | 44,318 |  |  | 47.3 | % |  | 36,008 |  |  | 47.8 | % |  |
| Gross profit | 49,368 |  |  | 52.7 | % |  | 39,376 |  |  | 52.2 | % |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 7,150 |  |  | 7.6 | % |  | 5,499 |  |  | 7.3 | % |  |
| Selling, general and administrative | 32,859 |  |  | 35.1 | % |  | 31,446 |  |  | 41.7 | % |  |
| Total operating expenses | 40,009 |  |  | 42.7 | % |  | 36,945 |  |  | 49.0 | % |  |
| Income from operations | 9,359 |  |  | 10.0 | % |  | 2,431 |  |  | 3.2 | % |  |
| Interest and other income (expense), net | 63 |  |  | 0.1 | % |  | (73 | ) |  | (0.1 | )% |  |
| Income before provision for income taxes | 9,422 |  |  | 10.1 | % |  | 2,358 |  |  | 3.1 | % |  |
| Provision for income taxes | 3,406 |  |  | 3.6 | % |  | 983 |  |  | 1.3 | % |  |
| Net income | $ | 6,016 |  |  | 6.5 | % |  | $ | 1,375 |  |  | 1.8 | % |  |

[0000926326-13-000013:mdna:68]
33

[0000926326-13-000013:mdna:69]
|  | Six Months Ended June 30, |
|  | 2013 |  | 2012 |
|  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product revenue | $ | 144,817 |  |  | 80.1 | % |  | $ | 107,793 |  |  | 77.3 | % |
| Service and other revenues | 35,979 |  |  | 19.9 | % |  | 31,734 |  |  | 22.7 | % |
| Total revenues | 180,796 |  |  | 100.0 | % |  | 139,527 |  |  | 100.0 | % |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 69,833 |  |  | 38.6 | % |  | 48,896 |  |  | 35.0 | % |
| Cost of service and other revenues | 16,228 |  |  | 9.0 | % |  | 15,506 |  |  | 11.1 | % |
| Total cost of revenues | 86,061 |  |  | 47.6 | % |  | 64,402 |  |  | 46.1 | % |
| Gross profit | 94,735 |  |  | 52.4 | % |  | 75,125 |  |  | 53.9 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 15,104 |  |  | 8.4 | % |  | 11,993 |  |  | 8.6 | % |
| Selling, general and administrative | 66,104 |  |  | 36.6 | % |  | 57,066 |  |  | 40.9 | % |
| Total operating expenses | 81,208 |  |  | 45.0 | % |  | 69,059 |  |  | 49.5 | % |
| Income from operations | 13,527 |  |  | 7.5 | % |  | 6,066 |  |  | 4.4 | % |
| Interest and other income (expense), net | (159 | ) |  | (0.1 | )% |  | 23 |  |  | — | % |
| Income before provision for income taxes | 13,368 |  |  | 7.4 | % |  | 6,089 |  |  | 4.4 | % |
| Provision for income taxes | 3,967 |  |  | 2.2 | % |  | 2,363 |  |  | 1.7 | % |
| Net income | $ | 9,401 |  |  | 5.2 | % |  | $ | 3,726 |  |  | 2.7 | % |

[0000926326-13-000013:mdna:70]
The consolidated results presented above include the operating results of MTS since May 21, 2012, the date of acquisition and are included as part of the Non-Acute Care segment.

[0000926326-13-000013:mdna:71]
[same as prior period, unchanged from 0000926326-13-000010:mdna:64]

[0000926326-13-000013:mdna:72]
The table below shows our consolidated product revenues, cost of product revenues and gross profit for the three months and six months ended June 30, 2013 and 2012 and the percentage changes between those periods (in thousands, except percentages):

[0000926326-13-000013:mdna:73]
|  | Three Months Ended June 30, |
|  | 2013 |  | 2012 |  | % Change |
| Product revenues | $ | 75,581 |  |  | $ | 59,269 |  |  | 27.5 | % |
| Cost of product revenues | 36,286 |  |  | 28,600 |  |  | 26.9 | % |
| Gross profit | $ | 39,295 |  |  | $ | 30,669 |  |  | 28.1 | % |
| Gross margin | 52.0 | % |  | 51.7 | % |  | 0.3 | % |

[0000926326-13-000013:mdna:74]
|  | Six Months Ended June 30, |
|  | 2013 |  | 2012 |  | % Change |
| Product revenues | $ | 144,817 |  |  | $ | 107,793 |  |  | 34.3 | % |
| Cost of product revenues | 69,833 |  |  | 48,896 |  |  | 42.8 | % |
| Gross profit | $ | 74,984 |  |  | $ | 58,897 |  |  | 27.3 | % |
| Gross margin | 51.8 | % |  | 54.6 | % |  | (2.8 | )% |

[0000926326-13-000013:mdna:75]
Product revenues increased by $16.3 million, or 27.5%, in the three months ended June 30, 2013 as compared to the same period in 2012. Product revenues increased by $37.0 million, or 34.3%, in the six months ended June 30, 2013 as compared to the same period in 2012. The overall increase in product revenues for the three months ended June 30, 2013 was

[0000926326-13-000013:mdna:76]
primarily driven by a combination of increased installations of our automation products and a full three month contribution of  MTS sales as a part of our Non-Acute Care segment. The Non-Acute Care segment contributed $24.3 million, of which $5.3 million was from medication cabinet sales. Our Acute Care segment contributed $51.2 million in product revenue for the three months ended June 30, 2013 and $48.9 million as compared to the same period in 2012. The overall increase in product revenues for the six months ended June 30, 2013 was primarily driven by a full six month contribution of MTS activities as a part of our Non-Acute Care segment. The Non-Acute Care segment contributed $44.2 million, of which $7.6 million of revenues was from medication cabinet sales. This compares to $11.5 million in the same six month period last year. Our Acute Care segment contributed $100.6 million in product revenue for the six months ended June 30, 2013 compared to $96.3 million in the same six month period last year.

[0000926326-13-000013:mdna:77]
We anticipate our revenues will continue to increase in 2013 compared to the same periods in 2012, as we fulfill our existing orders. Additionally, year over year revenue growth for the remainder of 2013, will continue to benefit from the contribution of our Non-Acute Care segment, including those of MTS, which we began to consolidate on May 21, 2012. Our ability to grow revenue is dependent on our ability to continue to obtain orders from customers, our ability to produce quality consumables to fulfill customer demand, the volume of installations we are able to complete and our ability to meet customer needs by providing a quality installation experience and our flexibility in manpower allocations among customers to complete installations on a timely basis. The timing of our product revenues for equipment is primarily dependent on when our customers’ schedules allow for installations.

[0000926326-13-000013:mdna:78]
Cost of product revenues increased by $7.7 million, or 26.9%, in the three months ended June 30, 2013 as compared to the same period in 2012. Cost of product revenues increased by $20.9 million, or 42.8%, in the six months ended June 30, 2013 as compared to the same period in 2012. These increases were primarily a result of the previously discussed full three months of MTS sales as part of our Non-Acute Care segment. The Non-Acute Care segment contributed product costs of $13.9 million for the three months ended June 30, 2013, of which $2.1 million was from costs associated with the Non-Acute Care medication cabinets noted above. Our Acute Care product cost increased $1.4 million, which is primarily a function of revenue and product mix. The increase in cost of product revenues for the six months ended June 30, 2013 was primarily a result of six full months of Non-Acute Care product costs of $25.8 million, of which $3.2 million of costs related to the Non-Acute Care medication cabinets. Our Acute Care product cost increased by $3.4 million for the six months ended June 30, 2013 as a result of revenue and product mix.

[0000926326-13-000013:mdna:79]
Gross profit on product revenue increased by $8.6 million, or 28.1%, in the three months ended June 30, 2013 as compared to the same period in 2012. Gross profit on product revenue increased by $16.1 million, or 27.3%, in the six months ended June 30, 2013 as compared to the same period in 2012.This increase was primarily a result of the contribution from our Non-Acute Care segment of $10.4 million, and $18.4 million for the three months and six months ended June 30, 2013, respectively. Our Acute Care gross profit on product revenue increased by $0.9 million for both the three months and six months ended June 30, 2013 as compared to the same period in 2012.

[0000926326-13-000013:mdna:80]
[same as prior period, unchanged from 0000926326-13-000010:mdna:70]

[0000926326-13-000013:mdna:81]
The table below shows our service and other revenues, cost of service and other revenues and gross profit for the three months and six months ended June 30, 2013 and 2012 and the percentage change between those periods (in thousands, except percentages):

[0000926326-13-000013:mdna:82]
|  | Three Months Ended June 30, |
|  | 2013 |  | 2012 |  | % Change |
| Service and other revenues | $ | 18,105 |  |  | $ | 16,115 |  |  | 12.3 | % |
| Cost of service and other revenues | 8,032 |  |  | 7,408 |  |  | 8.4 | % |
| Gross profit | $ | 10,073 |  |  | $ | 8,707 |  |  | 15.7 | % |
| Gross margin | 55.6 | % |  | 54.0 | % |  | 1.6 | % |

[0000926326-13-000013:mdna:83]
|  | Six Months Ended June 30, |
|  | 2013 |  | 2012 |  | % Change |
| Service and other revenues | $ | 35,979 |  |  | $ | 31,734 |  |  | 13.4 | % |
| Cost of service and other revenues | 16,228 |  |  | 15,506 |  |  | 4.7 | % |
| Gross profit | $ | 19,751 |  |  | $ | 16,228 |  |  | 21.7 | % |
| Gross margin | 54.9 | % |  | 51.1 | % |  | 3.8 | % |

[0000926326-13-000013:mdna:84]
Service and other revenues include revenues from service and maintenance contracts, rentals of automation systems, and training and professional services. Service and other revenues increased by $2.0 million, or 12.3%, in the three months ended June 30, 2013 as compared to the same period in 2012. Service and other revenues increased by $4.2 million, or 13.4%, in the six months ended June 30, 2013 as compared to the same period in 2012. The increase in service and other revenues was primarily the result of an expansion in our installed base of automation systems and higher training revenues and service revenues attributable to three full months of our Non-Acute Care segment of $1.2 million, of which $0.4 million was from medication cabinet services and other revenues for the three months ended June 30, 2013. Our Acute Care segment contributed $16.9 million in services and other revenues for the three months ended June 30, 2013 and $15.4 million as compared to the same period in 2012. Our Non-Acute Care segment contributed six full months in services and other revenues of $2.5 million for the six months ended June 30, 2013 of which $0.9 million was from medication cabinet revenues. Our Acute Care segment contributed $33.5 million in service and other revenues for the six months ended June 30, 2013 and $30.6 million for the same period in 2012.

[0000926326-13-000013:mdna:85]
Cost of service and other revenues increased by $0.6 million, or 8.4%, in the three months ended June 30, 2013 as compared to the same period in 2012, primarily driven by a full three months of costs attributable to our Non-Acute Care segment of $0.6 million. Our Acute Care cost of service and other revenues increased $0.2 million in support of the expanded installed base. Cost of service and other revenues increased by $0.7 million, or 4.7%, in the six months ended June 30, 2013 as compared to the same period in 2012, primarily driven by a full six  months of costs attributable to our Non-Acute Care segment of $1.1 million, offset by a decrease in costs attributable to our Acute Care segment of $0.2 million as a result of cost reduction efforts.

[0000926326-13-000013:mdna:86]
Gross profit on service and other revenues increased by $1.4 million, or 15.7%, in the three months ended June 30, 2013 as compared to the same period in 2012. Gross profit on service and other revenues increased by $3.5 million, or 21.7%, in the six months ended June 30, 2013 as compared to the same period in 2012. The increase in gross profit on service and other revenues was primarily due to increased revenues from an expanded installed base with a decrease in service cost attributable to our Acute Care segment as a result of the service cost reduction efforts throughout the period. Gross profit on service and other revenues from our Non-Acute Care segment was $0.6 million and $9.4 million from our Acute Care segment in the three months ended June 30, 2013. Our Acute Care gross profit on service and other revenues increased by $1.4 million and $3.5 million for the three months and six months ended June 30, 2013, respectively as compared to the same period in 2012.

[0000926326-13-000013:mdna:87]
[same as prior period, unchanged from 0000926326-13-000010:mdna:76]

[0000926326-13-000013:mdna:88]
[same as prior period, unchanged from 0000926326-13-000010:mdna:77]

[0000926326-13-000013:mdna:89]
The table below shows our operating expenses for the three months and six months ended June 30, 2013 and 2012 and the percentage changes between those periods (in thousands, except percentages):

[0000926326-13-000013:mdna:90]
|  | Three Months Ended June 30, |
|  | 2013 |  | 2012 |  | % Change |
| Research and development | $ | 7,150 |  |  | $ | 5,499 |  |  | 30.0 | % |
| Selling, general and administrative | 32,859 |  |  | 31,446 |  |  | 4.4 | % |
| Total operating expenses | $ | 40,009 |  |  | $ | 36,945 |  |  | 8.3 | % |

[0000926326-13-000013:mdna:91]
|  | Six Months Ended June 30, |
|  | 2013 |  | 2012 |  | % Change |
| Research and development | $ | 15,104 |  |  | $ | 11,993 |  |  | 25.9 | % |
| Selling, general and administrative | 66,104 |  |  | 57,066 |  |  | 15.8 | % |
| Total operating expenses | $ | 81,208 |  |  | $ | 69,059 |  |  | 17.6 | % |

[0000926326-13-000013:mdna:92]
Research and Development. Research and development expenses increased by $1.7 million, or 30.0%, in the three months ended June 30, 2013 as compared to the same period in 2012 and represented 7.6% and 7.3% of total revenues in the three months ended June 30, 2013 and 2012, respectively. The overall increase in research and development expenses is primarily due to a $1.3 million increase in research and development expenses attributable to the Non-Acute Care segment including an increase of $0.7 million related to medication cabinets and an additional $0.7 million increase in headcount and

[0000926326-13-000013:mdna:93]
consulting related expenses primarily due to the inclusion of MTS  for a full three months in the 2013 period as compared with activities since May 21, 2012, the date of acquisition, in the same period in 2012.

[0000926326-13-000013:mdna:94]
Research and development expenses increased by $3.1 million, or 25.9%, in the six months ended June 30, 2013 as compared to the same period in 2012 and represented 8.4% and 8.6% of total revenues in the six months ended June 30, 2013 and 2012, respectively. The overall increase in research and development expenses reflects a $4.2 million increase in research and development expenses attributable to the Non-Acute Care segment, of which $1.8 million is due to the write-off of previously capitalized software development costs, discussed further in Note 16, "Asset Impairment", a $0.3 million charge related to the previously mentioned reorganization, and  the inclusion of MTS headcount, consulting and other related activities for a full six months in the 2013 period as compared with, the inclusion of less than two months in the same period in 2012. These increases were offset by a $1.1 million decrease in the Acute Care segment which was comprised of an increase of capitalization software effort of $2.0 million in connection with a higher level of post-feasibility beta testing offset by approximately $1.0 million increases in headcount and consulting related expenses. The overall decrease as a percentage of revenue is primarily a reflection of the overall growth in revenue without a corresponding increase in research and development spending.

[0000926326-13-000013:mdna:95]
[same as prior period, unchanged from 0000926326-13-000010:mdna:81]

[0000926326-13-000013:mdna:96]
Selling, General and Administrative. Selling, general and administrative expenses increased by $1.4 million, or 4.4%, in the three months ended June 30, 2013 as compared to the same period in 2012. Selling, general and administrative expenses represented 35.1% and 41.7% of total revenues in the three months ended June 30, 2013 and 2012, respectively. The increase in expenses was primarily due to the increase of Non-Acute Care selling, general and administrative expenses of $3.8 million of which $2.0 million relates to the medication cabinet costs and the balance the result of overall expenses incurred due to the inclusion of MTS for a full three months in the 2013 period as compared to less than two months  in the same period in 2012. These expenses include headcount-related expenses, travel and entertainment expenses, and other normal operating expenses.  The increase was offset by a decrease of $2.4 million from the Acute Care segment primarily attributable to $3.2 million of MTS acquisition related costs incurred in the year-ago period, $0.6 million of bad debt, and $0.5 million in commission expense offset by increases in facilities and depreciation of $1.2 million due to our new office buildings and increases in freight of $0.7 million.

[0000926326-13-000013:mdna:97]
Selling, general and administrative expenses increased by $9.0 million, or 15.8%, in the six months ended June 30, 2013 as compared to the same period in 2012. Selling, general and administrative expenses represented 36.6% and 40.9% of total revenues in the six months ended June 30, 2013 and 2012, respectively. The increase was primarily due to an increase in the Non-Acute Care selling, general and administrative expenses of $9.9 million, of which of which $2.5 million relates to the medication cabinet costs and primarily the result of overall expenses incurred due to the inclusion of MTS activities for a full six months in the 2013 period as compared to less than two months in the same period in 2012. These expenses included headcount and consulting related expenses, travel and entertainment expenses, and other normal operating expenses. These increases were offset by a $0.8 million decrease from the Acute Care segment primarily comprised of the aforementioned decreases of $3.2 million of MTS acquisition related costs, $1.0 million in commissions due to changes in our 2013 commission plans coupled with the attainment of certain sales incentives in the same period in 2012, $0.3 million of bad debt, offset by increases in facilities and depreciation of $2.8 million due to our new office buildings and increases in freight of $1.4 million.

[0000926326-13-000013:mdna:98]
The decrease in selling, general and administrative expenses as a percentage of total revenue for both the three months and six months ended June 30, 2013 as compared to the same period in 2012 is a reflection of revenue growth out pacing corresponding increases in spending in this area.

[0000926326-13-000013:mdna:99]
[same as prior period, unchanged from 0000926326-13-000010:mdna:83]

[0000926326-13-000013:mdna:100]
Share-based Compensation. The effect of share-based compensation on functional expenses within our operating results for the three months and six months ended June 30, 2013 and 2012 is presented in Note 13, “Stock Option Plans and Share-Based Compensation.”

[0000926326-13-000013:mdna:101]
[same as prior period, unchanged from 0000926326-13-000010:mdna:85]

[0000926326-13-000013:mdna:102]
The annual effective tax rate before discrete items was 38.7% and 40.9% for the six months ended June 30, 2013 and 2012, respectively. The decrease in the estimated annual effective tax rate for the six months ended June 30, 2013 as compared to the same period in 2012 was primarily due to the reinstatement of the federal research and development credit in January of 2013 along with a decrease in other non-deductible expenditures.

[0000926326-13-000013:mdna:103]
[same as prior period, unchanged from 0000926326-13-000010:mdna:87]

[0000926326-13-000013:mdna:104]
We had cash and cash equivalents of $87.3 million at June 30, 2013, as compared to $62.3 million at December 31, 2012. All of our cash is invested in short term money market funds or demand deposits. We did not hold any short or long term investments as of June 30, 2013. While in the future we may need to seek additional financing to meet our working capital needs and to finance capital expenditures, as well as to fund operations or potential acquisitions, we believe our current cash and cash equivalent balances and cash flows generated by operations will be sufficient to satisfy our anticipated cash needs for working capital and capital expenditures for at least the next twelve months.

[0000926326-13-000013:mdna:105]
Cash flows for the six months ended June 30, 2013 and 2012 consisted of the following (in thousands):

[0000926326-13-000013:mdna:106]
|  | Six Months Ended June 30, |
|  | 2013 |  | 2012 |
| Net cash provided by operating activities | $ | 21,228 |  |  | $ | 18,758 |  |
| Net cash used in investing activities | (8,969 | ) |  | (153,940 | ) |
| Net cash provided by (used in) financing activities | 12,807 |  |  | (2,532 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (45 | ) |  | 23 |  |
| Net increase in cash and cash equivalents | $ | 25,021 |  |  | $ | (137,691 | ) |

[0000926326-13-000013:mdna:107]
Operating activities provided $21.2 million of cash during the six months ended June 30, 2013 as compared to $18.8 million for the same period in 2012. The main drivers of this increase were a $5.7 million increase in net income,  a $5.4 million increase in accrued liabilities, a $4.3 million increase in deferred gross profit, and $1.2 million increase in share-based compensation expense. These amounts were partially offset by a $8.5 million increase in accounts receivable, a $6.4 million decrease in accrued compensation, and a $4.6 million increase in inventory. Also impacting operating cash flows are non-cash adjustments which include a $3.9 million increase in depreciation and amortization and a $1.8 million asset impairment charge related to a software development project.

[0000926326-13-000013:mdna:108]
Cash used in investing activities totaled $9.0 million during the six months ended June 30, 2013, as compared to $153.9 million cash used in investing activities during the same period in 2012. This $145.0 million decrease in cash used primarily reflects a decrease of $156.3 million of net cash used to acquire MTS in May of 2012. This is offset in part by an increase of $1.8 million of capitalized software development costs and $1.6 million for purchases of property and equipment during the six months ended June 30, 2013.

[0000926326-13-000013:mdna:109]
Cash provided by financing activities was $12.8 million during the six months ended June 30, 2013, as compared to $2.5 million used during the same period in 2012, resulting in a difference of $15.3 million. The increase is primarily due to an increase of $7.9 million in cash generated from shares issued under stock option and employee stock purchase plans during the six months ended June 30, 2013 as compared to the same period in 2012 and no stock repurchases made during the six months ended June 30, 2013 compared to $7.1 million of stock repurchase activity during the six months ended June 30, 2012.

[0000926326-13-000013:mdna:110]
[same as prior period, unchanged from 0000926326-13-000010:mdna:94]

[0000926326-13-000013:mdna:111]
There have been no material changes to our contractual obligations during the six months ended June 30, 2013. Please refer to our Annual Report on Form 10-K for the year ended December 31, 2012 for a description of our facility leases and contractual obligations and the Notes to the consolidated financial statements included therein.

[0000926326-13-000013:mdna:112]
The following table summarizes our contractual obligations at June 30, 2013 (in thousands):

[0000926326-13-000013:mdna:113]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | More than five years |
| Operating leases (1) (2) | $ | 44,520 |  |  | $ | 5,790 |  |  | $ | 10,812 |  |  | $ | 9,172 |  |  | $ | 18,746 |  |
| Commitments to contract manufacturers and suppliers (3) | 7,972 |  |  | 7,972 |  |  | — |  |  | — |  |  | — |  |
| Total (4) | $ | 52,492 |  |  | $ | 13,762 |  |  | $ | 10,812 |  |  | $ | 9,172 |  |  | $ | 18,746 |  |

[0000926326-13-000013:mdna:114]
[same as prior period, unchanged from 0000926326-13-000010:mdna:98]

[0000926326-13-000013:mdna:115]
[same as prior period, unchanged from 0000926326-13-000010:mdna:99]

[0000926326-13-000013:mdna:116]
[same as prior period, unchanged from 0000926326-13-000010:mdna:100]

[0000926326-13-000013:mdna:117]
| (4) | At June 30, 2013, we have recorded $4.4 million for uncertain tax positions under long term liabilities, in accordance with GAAP, summarized under Note 1, “Organization and Summary of Significant Accounting Policies.” As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the current balance of the uncertain tax position liabilities has not been included in the table of commitments above. |

[0000926326-13-000013:mdna:118]
[same as prior period, unchanged from 0000926326-13-000010:mdna:102]

[0000926326-13-000013:mdna:119]
As of June 30, 2013, we had no off-balance sheet arrangements as defined in Regulation S-K 303(a)(4)(ii) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
