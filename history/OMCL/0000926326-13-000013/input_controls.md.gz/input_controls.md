# OMCL 10-Q controls and the auditor's report


## item_4_controls

[0000926326-13-000013:item_4_controls:1]
| Item 4. | CONTROLS AND PROCEDURES |

[0000926326-13-000013:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000926326-13-000013:item_4_controls:3]
Our management, with the participation of our principal executive officer and principal financial officer, has evaluated the effectiveness of our disclosure controls and procedures (as such term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) as of June 30, 2013. Based on such evaluation, our principal executive officer and principal financial officer have concluded that, as of June 30, 2013, our disclosure controls and procedures were effective.

[0000926326-13-000013:item_4_controls:4]
Changes in Internal Control Over Financial Reporting

[0000926326-13-000013:item_4_controls:5]
There were no changes in our internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the three months ended June 30, 2013 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0000926326-13-000013:item_4_controls:6]
39
