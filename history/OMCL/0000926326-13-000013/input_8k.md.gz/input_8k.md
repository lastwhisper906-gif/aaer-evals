# OMCL 8-K — 0001104659-13-058959 filed 2013-08-01

## item codes, every 8-K on or before 2013-08-09

- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2013-08-09

- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0001104659-13-058959:8k_2_02:1]
EX-99.1
2
a13-17713_1ex99d1.htm
EX-99.1

[0001104659-13-058959:8k_2_02:2]
Exhibit 99.1

[0001104659-13-058959:8k_2_02:3]
| Contact: |  |  |
| Rob Seim |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664, ext. 6478 |  | Mountain View, CA 94043 |
| rob.seim@omnicell.com |  |  |

[0001104659-13-058959:8k_2_02:4]
Omnicell Announces Second Quarter 2013 Results

[0001104659-13-058959:8k_2_02:5]
Results include record revenues and profit larger than expectations

[0001104659-13-058959:8k_2_02:6]
MOUNTAIN VIEW, Calif. — August 1, 2013— Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its quarter ended June 30, 2013.

[0001104659-13-058959:8k_2_02:7]
GAAP results: Revenue for the second quarter of 2013 was $93.7 million, up $6.6 million or 7.5% from the first quarter of 2013, and up $18.3 million or 24.3% from the second quarter of 2012. Revenue for the six months ended June 30, 2013 was $180.8 million, up $41.3 million or 29.6% from the six months ended June 30, 2012.

[0001104659-13-058959:8k_2_02:8]
Second quarter 2013 net income as reported in accordance with U.S. generally accepted accounting principles (GAAP) was $6.0 million, or $0.17 per diluted share. This compares to net income of $3.4 million, or $0.10 per diluted share, in the first quarter of 2013 and net income of $1.4 million, or $0.04 per diluted share, in the second quarter of 2012. For the six months ended June 30, 2013, net income was $9.4 million, or $0.27 per diluted share. This compares to net income of $3.7 million, or $0.11 per diluted share, for the six months ended June 30, 2012.

[0001104659-13-058959:8k_2_02:9]
Non-GAAP results: Non-GAAP net income was $9.4 million for the second quarter of 2013, or $0.27 per diluted share. Non-GAAP net income for the second quarter excludes $2.7 million of stock-based compensation expense and $1.1 million ($0.7 million net of the $0.4 million tax effect) of amortization expense for all intangible assets associated with acquisitions made by Omnicell in 2012 and earlier. This compares to non-GAAP net income of $6.7 million, or $0.20 per diluted share for the second quarter of 2012, excluding $2.2 million of stock-based compensation expense, $4.9 million of acquisition transaction and integration costs ($2.9 million net of the $2.0 million tax effect), and $0.5 million ($0.3 million net of the $0.2 million tax effect) of amortization expense for all intangible assets associated with prior acquisitions. Second quarter 2013 results compare to non-GAAP net income of $7.4 million, or $0.21 per diluted share for the first quarter of 2013. Non-GAAP net income for the first quarter excluded $2.9 million of stock-based compensation expense and $0.7 million ($0.4 million net of the $0.3 million tax effect) of reorganization costs related to the continued integration of MTS medication technologies, which was acquired in May of 2012, and $1.1 million ($0.6 million net of the $0.5 million tax effect) of amortization expense for all intangible assets associated with acquisitions.

[0001104659-13-058959:8k_2_02:10]
For the six months ended June 30, 2013, non-GAAP net income was $16.8 million, or $0.48 per diluted share. Non-GAAP net income for the six months ended June 30, 2013 excludes $5.6 million of stock-based compensation expense and $2.1 million ($1.3 million net of the $0.8 million tax effect) of amortization expense for all intangible assets associated with acquisitions.  For the six months ended June 30, 2012, non-GAAP net income was $11.3 million, or $0.33 per diluted share. Non-GAAP net income for the six months ended June 30, 2012 excludes $4.4 million of stock-based compensation expense, $4.9 million of acquisition transaction and integration costs ($2.9 million net of the $2.0 million tax effect), and $0.5 million ($0.3 million net of the $0.2 million tax effect) of amortization expense for all intangible assets associated with acquisitions.

[0001104659-13-058959:8k_2_02:11]
“Omnicell is on track for a strong fiscal 2013 with record revenue in the second quarter,” said Randall Lipps, Omnicell president, chairman and CEO.

[0001104659-13-058959:8k_2_02:12]
“By all measures, Omnicell continues to perform well against competition. Thirty percent of bookings were from competitive conversions such as the 14-hospital Baptist Memorial Health Care system, Wisconsin’s ProHealth Care and other first-time customers,” added Mr. Lipps. “And recently KLAS, a leading independent healthcare research firm, named Omnicell the 2013 number one overall pharmacy equipment vendor. Further validating Omnicell value, our automated medication dispensing system achieved the top ranking, ‘Best in KLAS’, for the eighth consecutive year, and the company’s central pharmacy products received top ratings in three categories.”

[0001104659-13-058959:8k_2_02:13]
Omnicell Conference Call Information

[0001104659-13-058959:8k_2_02:14]
Omnicell will hold a conference call today at 1:30 p.m. PT to discuss second quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 19881764. Internet users can access the conference call at http://ir.omnicell.com/events.cfm. A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 12:00 p.m. PT on August 15. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, conference code # 19881764.

[0001104659-13-058959:8k_2_02:15]
About Omnicell

[0001104659-13-058959:8k_2_02:16]
For over 20 years, the mission of Omnicell (NASDAQ: OMCL) has been creating new efficiencies to help improve patient care, anywhere it is delivered. Omnicell is a leading supplier of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum, from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home.

[0001104659-13-058959:8k_2_02:17]
Since 1992, more than 2,600 Acute Care customers worldwide have utilized Omnicell’s medication automation, supply chain and analytics solutions to enable them to increase operational efficiency, reduce errors, deliver actionable intelligence and improve patient safety. Omnicell Non-Acute Care solutions, including its MTS Medication Technologies brand, provide innovative medication adherence packaging solutions that can help reduce costly hospital readmissions and enable approximately 6,000 institutional and retail pharmacies worldwide to maintain high accuracy and quality standards in medication dispensing and administration while optimizing productivity and controlling costs.

[0001104659-13-058959:8k_2_02:18]
For more information about Omnicell, please visit www.omnicell.com.

[0001104659-13-058959:8k_2_02:19]
Forward-Looking Statements

[0001104659-13-058959:8k_2_02:20]
To the extent any statements contained in this release deal with information that is not historical, these statements are necessarily forward-looking. As such, they are subject to the occurrence of many events outside Omnicell’s control and are subject to various risk factors that could cause actual results to differ materially from those expressed or implied in any forward-looking statement. The risk factors are described in the Company’s Securities and Exchange Commission (SEC) filings and include, the potential failure to realize the anticipated benefits of the MTS acquisition, including our ability to take advantage of the growth opportunities in medication management across the spectrum of healthcare settings from long term care to home care, unfavorable general economic and market conditions, risks to growth and acceptance of our products and services, including competitive conversions, and to growth of the clinical automation and workflow automation market generally, the potential of increasing competition, potential regulatory changes, and the ability of the company to improve sales productivity to grow product backlog and to develop new products and integrate acquired companies. Prospective investors are cautioned not to place undue reliance on forward-looking statements.

[0001104659-13-058959:8k_2_02:21]
Use of Non-GAAP Financial Information

[0001104659-13-058959:8k_2_02:22]
This press release contains financial measures that are not calculated in accordance with U.S. generally accepted accounting principles (GAAP). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0001104659-13-058959:8k_2_02:23]
Our non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0001104659-13-058959:8k_2_02:24]
a)  Stock-based compensation expense impact of Accounting Standards Codification (ASC) 718. We recognize equity plan-related compensation expenses, which represent the fair value of all share-based payments to employees, including grants of employee stock options, as required under ASC 718, “Stock Compensation” as non-GAAP adjustments in each period.

[0001104659-13-058959:8k_2_02:25]
b)  Reorganization costs. During the six months ended June 30, 2013, we recorded $0.7 million of reorganization costs related to our Non-Acute Care segment ($0.4 million net of the $0.3 million tax effect). This charge is not expected to be recurring and, as such, the financial impact is excluded from our non-GAAP results.

[0001104659-13-058959:8k_2_02:26]
c)  Acquisition-related transaction and integration expenses. In connection with our acquisition of MTS, we recorded $4.9 million of acquisition transaction and integration costs ($2.9 million net of the $2.0 million tax effect) in the second quarter of 2012. This charge is not expected to be recurring and, as such, the financial impact is excluded from our non-GAAP results.

[0001104659-13-058959:8k_2_02:27]
d)  Intangible assets amortization from business acquisitions. We excluded from our non-GAAP results the amortization expense resulting from the MTS acquisition as well as earlier Omnicell acquisitions. This impacts the second quarter of fiscal 2013 non-GAAP results by $1.1 million ($0.7 million net of the $0.4 million tax effect) and the first quarter of fiscal 2013 non-GAAP results by $1.1 million ($0.6 million net of the $0.5 million tax effect). This impacts the June 30, 2013 year-to-date non-GAAP results by $2.1 million ($1.3 million net of $0.8 million tax effect) and impacts June 30, 2012 second quarter and year-to-date non-GAAP results by $0.5 million ($0.3 million net of the $0.2 million tax effect).These non-cash charges are not, considered by management, to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0001104659-13-058959:8k_2_02:28]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock option grants.

[0001104659-13-058959:8k_2_02:29]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0001104659-13-058959:8k_2_02:30]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0001104659-13-058959:8k_2_02:31]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0001104659-13-058959:8k_2_02:32]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0001104659-13-058959:8k_2_02:33]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0001104659-13-058959:8k_2_02:34]
Set forth below are additional reasons why share-based compensation expense related to ASC 718 is excluded from our non-GAAP financial measures:

[0001104659-13-058959:8k_2_02:35]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0001104659-13-058959:8k_2_02:36]
ii)  We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0001104659-13-058959:8k_2_02:37]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense.

[0001104659-13-058959:8k_2_02:38]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0001104659-13-058959:8k_2_02:39]
· Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0001104659-13-058959:8k_2_02:40]
· Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0001104659-13-058959:8k_2_02:41]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0001104659-13-058959:8k_2_02:42]
Omnicell, Inc.

[0001104659-13-058959:8k_2_02:43]
Condensed Consolidated Statements of Operations

[0001104659-13-058959:8k_2_02:44]
(in thousands, except per share data, unaudited)

[0001104659-13-058959:8k_2_02:45]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | June 30, 2013 |  | March 31, 2013 |  | June 30, 2012 |  | June 30, 2013 |  | June 30, 2012 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 75,581 |  | $ | 69,236 |  | $ | 59,269 |  | $ | 144,817 |  | $ | 107,793 |  |
| Services and other revenues |  | 18,105 |  | 17,874 |  | 16,115 |  | 35,979 |  | 31,734 |  |
| Total revenue |  | 93,686 |  | 87,110 |  | 75,384 |  | 180,796 |  | 139,527 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues |  | 36,286 |  | 33,547 |  | 28,600 |  | 69,833 |  | 48,896 |  |
| Cost of services and other revenues |  | 8,032 |  | 8,196 |  | 7,408 |  | 16,228 |  | 15,506 |  |
| Total cost of revenues |  | 44,318 |  | 41,743 |  | 36,008 |  | 86,061 |  | 64,402 |  |
| Gross profit |  | 49,368 |  | 45,367 |  | 39,376 |  | 94,735 |  | 75,125 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 7,150 |  | 7,954 |  | 5,499 |  | 15,104 |  | 11,993 |  |
| Selling, general, and administrative |  | 32,859 |  | 33,244 |  | 31,446 |  | 66,104 |  | 57,066 |  |
| Total operating expenses |  | 40,009 |  | 41,198 |  | 36,945 |  | 81,208 |  | 69,059 |  |
| Income from operations |  | 9,359 |  | 4,169 |  | 2,431 |  | 13,527 |  | 6,066 |  |
| Other income and (expense), net |  | 63 |  | (223 | ) | (73 | ) | (159 | ) | 23 |  |
| Income before provision for income taxes |  | 9,422 |  | 3,946 |  | 2,358 |  | 13,368 |  | 6,089 |  |
| Provision for income taxes |  | 3,406 |  | 561 |  | 983 |  | 3,967 |  | 2,363 |  |
| Net income |  | $ | 6,016 |  | $ | 3,385 |  | $ | 1,375 |  | $ | 9,401 |  | $ | 3,726 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.17 |  | $ | 0.10 |  | $ | 0.04 |  | $ | 0.28 |  | $ | 0.11 |  |
| Diluted |  | $ | 0.17 |  | $ | 0.10 |  | $ | 0.04 |  | $ | 0.27 |  | $ | 0.11 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 34,450 |  | 33,900 |  | 33,390 |  | 34,177 |  | 33,377 |  |
| Diluted |  | 35,374 |  | 34,820 |  | 34,316 |  | 35,099 |  | 34,329 |  |

[0001104659-13-058959:8k_2_02:46]
Omnicell, Inc.

[0001104659-13-058959:8k_2_02:47]
Condensed Consolidated Balance Sheets

[0001104659-13-058959:8k_2_02:48]
(In thousands)

[0001104659-13-058959:8k_2_02:49]
|  |  | June 30, |  | December 31, |  |
|  |  | 2013 |  | 2012 |  |
|  |  | (unaudited) |  | (1) |  |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 87,334 |  | $ | 62,313 |  |
| Short-term investments |  | — |  | — |  |
| Accounts receivable, net |  | 63,840 |  | 55,116 |  |
| Inventories |  | 26,360 |  | 26,903 |  |
| Prepaid expenses |  | 15,928 |  | 15,392 |  |
| Deferred tax assets |  | 11,860 |  | 11,860 |  |
| Other current assets |  | 7,899 |  | 9,172 |  |
| Total current assets |  | 213,221 |  | 180,756 |  |
| Property and equipment, net |  | 34,114 |  | 34,107 |  |
| Non-current net investment in sales-type leases |  | 13,222 |  | 13,228 |  |
| Goodwill |  | 111,343 |  | 111,407 |  |
| Other intangible assets |  | 83,468 |  | 85,550 |  |
| Non-current deferred tax assets |  | 985 |  | 993 |  |
| Other assets |  | 15,775 |  | 15,778 |  |
| Total assets |  | $ | 472,128 |  | $ | 441,819 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |
| Accounts payable |  | $ | 17,459 |  | $ | 18,255 |  |
| Accrued compensation |  | 11,239 |  | 11,613 |  |
| Accrued liabilities |  | 14,053 |  | 11,988 |  |
| Deferred service revenue |  | 20,434 |  | 20,449 |  |
| Deferred gross profit |  | 25,350 |  | 20,772 |  |
| Total current liabilities |  | 88,535 |  | 83,077 |  |
| Non-current deferred service revenue |  | 18,598 |  | 19,892 |  |
| Non-current deferred tax liabilities |  | 26,225 |  | 26,491 |  |
| Other long-term liabilities |  | 5,039 |  | 4,809 |  |
| Total liabilities |  | 138,397 |  | 134,269 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Total stockholders’ equity |  | 333,731 |  | 307,550 |  |
| Total liabilities and stockholders’ equity |  | $ | 472,128 |  | $ | 441,819 |  |

[0001104659-13-058959:8k_2_02:50]
(1)         Information derived from our December 31, 2012 audited Consolidated Financial Statements.

[0001104659-13-058959:8k_2_02:51]
Omnicell, Inc.

[0001104659-13-058959:8k_2_02:52]
Reconciliation of GAAP to Non-GAAP

[0001104659-13-058959:8k_2_02:53]
(In thousands, except per share data, unaudited)

[0001104659-13-058959:8k_2_02:54]
|  |  | Three months ended |  |
|  |  | June 30, 2013 |  | March 31, 2013 |  | June 30, 2012 |  |
|  |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  |
| GAAP |  | $ | 6,016 |  | $ | 0.17 |  | $ | 3,385 |  | $ | 0.10 |  | $ | 1,375 |  | $ | 0.04 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Business acquisition costs |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reorganization costs (a) |  | — |  |  |  | 732 |  |  |  | — |  |  |  |
| Transaction and integration costs for acquisitions (b) |  | — |  |  |  | — |  |  |  | 4,855 |  |  |  |
| Amortization of intangible assets acquired by acquisition (c) |  | 1,060 |  |  |  | 1,060 |  |  |  | 558 |  |  |  |
| Subtotal pretax adjustments |  | 1,060 |  |  |  | 1,792 |  |  |  | 5,413 |  |  |  |
| Income tax effect of non-GAAP adjustments (d) |  | (382 | ) |  |  | (716 | ) |  |  | (2,256 | ) |  |  |
| Subtotal after-tax adjustments |  | 678 |  |  |  | 1,076 |  |  |  | 3,157 |  |  |  |
| ASC 718 share-based compensation adjustment (e) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 325 |  |  |  | 305 |  |  |  | 233 |  |  |  |
| Operating expenses |  | 2,362 |  |  |  | 2,621 |  |  |  | 1,980 |  |  |  |
| Total after-tax adjustments |  | 3,365 |  | 0.10 |  | 4,002 |  | 0.11 |  | 5,370 |  | 0.16 |  |
| Non-GAAP |  | $ | 9,381 |  | $ | 0.27 |  | $ | 7,387 |  | $ | 0.21 |  | $ | 6,745 |  | $ | 0.20 |  |

[0001104659-13-058959:8k_2_02:55]
(a)             This adjustment is for reorganization costs related to our Non-Acute Care segment for the three months ended March 31, 2013.

[0001104659-13-058959:8k_2_02:56]
(b)             This adjustment is for the incurrence of transaction and integration costs related to our acquisition of MTS in May 2012.

[0001104659-13-058959:8k_2_02:57]
(c)              Beginning with the second quarter of 2012, we are recognizing the amortization expense resulting from all intangible assets recorded from business acquisitions as a non-GAAP adjustment, including MTS and prior acquisitions.

[0001104659-13-058959:8k_2_02:58]
(d)             Tax effects are calculated using the effective tax rates for the respective periods presented.

[0001104659-13-058959:8k_2_02:59]
(e)               This adjustment reflects the accounting impact of non-cash stock-based compensation expense related to the impact of ASC 718 for the periods shown

[0001104659-13-058959:8k_2_02:60]
Omnicell, Inc.

[0001104659-13-058959:8k_2_02:61]
Reconciliation of GAAP to Non-GAAP

[0001104659-13-058959:8k_2_02:62]
(In thousands, except per share data, unaudited)

[0001104659-13-058959:8k_2_02:63]
|  |  | Six months ended |  |
|  |  | June 30, 2013 |  | June 30, 2012 |  |
|  |  | Net income |  | Net income per share- diluted |  | Net income |  | Net income per share- diluted |  |
| GAAP |  | $ | 9,401 |  | $ | 0.27 |  | $ | 3,726 |  | $ | 0.11 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Business acquisition costs |  |  |  |  |  |  |  |  |  |
| Reorganization costs (a) |  | 732 |  |  |  | — |  |  |  |
| Transaction and integration costs for acquisitions (b) |  | — |  |  |  | 4,855 |  |  |  |
| Amortization of intangible assets acquired by acquisition (c) |  | 2,120 |  |  |  | 558 |  |  |  |
| Subtotal pretax adjustments |  | 2,852 |  |  |  | 5,413 |  |  |  |
| Income tax effect of non-GAAP adjustments (d) |  | (1,099 | ) |  |  | (2,256 | ) |  |  |
| Subtotal after-tax adjustments |  | 1,753 |  |  |  | 3,157 |  |  |  |
| ASC 718 share-based compensation adjustment (e) |  |  |  |  |  |  |  |  |  |
| Gross profit |  | 629 |  |  |  | 501 |  |  |  |
| Operating expenses |  | 4,984 |  |  |  | 3,919 |  |  |  |
| Total after tax adjustments |  | 7,366 |  | 0.21 |  | 7,577 |  | 0.22 |  |
| Non-GAAP |  | $ | 16,767 |  | $ | 0.48 |  | $ | 11,303 |  | $ | 0.33 |  |

[0001104659-13-058959:8k_2_02:64]
(a)             This adjustment is for reorganization costs related to our Non-Acute Care segment for the six months ended June 30, 2013.

[0001104659-13-058959:8k_2_02:65]
(b)             This adjustment is for the incurrence of transaction and integration costs related to our acquisition of MTS in May 2012.

[0001104659-13-058959:8k_2_02:66]
(c)              Beginning with the second quarter of 2012, we are recognizing the amortization expense resulting from all intangible assets recorded from business acquisitions as a non-GAAP adjustment, including MTS and prior acquisitions.

[0001104659-13-058959:8k_2_02:67]
(d)             Tax effects are calculated using the effective tax rates for the respective periods presented.

[0001104659-13-058959:8k_2_02:68]
(e)               This adjustment reflects the accounting impact of non-cash stock-based compensation expense related to the impact of ASC 718 for the periods shown

[0001104659-13-058959:8k_2_02:69]
Omnicell, Inc.

[0001104659-13-058959:8k_2_02:70]
Calculation of Adjusted EBITDA (1)

[0001104659-13-058959:8k_2_02:71]
(In thousands, unaudited)

[0001104659-13-058959:8k_2_02:72]
|  |  | Three Months Ended |  | Six months ended |  |
|  |  | June 30, 2013 |  | March 31, 2013 |  | June 30, 2012 |  | June 30, 2013 |  | June 30, 2012 |  |
| GAAP net income |  | $ | 6,016 |  | $ | 3,385 |  | $ | 1,375 |  | $ | 9,401 |  | $ | 3,726 |  |
| Add back: |  |  |  |  |  |  |  |  |  |  |  |
| ASC 718 stock compensation expense |  | 2,687 |  | 2,926 |  | 2,213 |  | 5,613 |  | 4,420 |  |
| Reorganization costs |  |  |  | 732 |  |  |  | 732 |  |  |  |
| Transaction and integration costs for acquisitions, pre-tax |  | — |  | — |  | 4,855 |  | — |  | 4,885 |  |
| Interest |  | (7 | ) | 106 |  | (24 | ) | 99 |  | (55 | ) |
| Depreciation and amortization expense |  | 4,773 |  | 4,471 |  | 2,998 |  | 9,244 |  | 5,333 |  |
| Income tax expense |  | 3,406 |  | 561 |  | 983 |  | 3,967 |  | 2,363 |  |
| Non-GAAP adjusted EBITDA (1) |  | $ | 16,875 |  | $ | 12,181 |  | $ | 12,400 |  | $ | 29,056 |  | $ | 20,672 |  |

[0001104659-13-058959:8k_2_02:73]
(1) Defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including stock compensation expense, per ASC 718, as well excluding certain non-GAAP adjustments. The non-GAAP adjustments for the quarter ended March 31, 2013 and six months ended June 30, 2013 exclude transaction and integration costs for MTS, acquired in May 2012. The non-GAAP adjustments for the three and six months ended June 30, 2012 also exclude transaction and integration costs for MTS, acquired in May 2012.
