# OMCL notes — 0000926326-13-000013


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000926326-13-000013:notes:1]
The following table summarizes the credit losses and recorded investment in sales-type leases, excluding unearned interest (in thousands):

[0000926326-13-000013:notes:2]
|  | Allowance for Credit Losses |  | Recorded Investmentin Sales-type Leases Gross |  | Recorded Investmentin Sales-type Leases Net |
| Credit loss disclosure for June 30, 2013: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | 47 |  |  | $ | 47 |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 137 |  |  | 18,892 |  |  | 18,755 |  |
| Ending balances: June 30, 2013 | $ | 184 |  |  | $ | 18,939 |  |  | $ | 18,755 |  |
| Credit loss disclosure for December 31, 2012: |  |  |  |  |  |  |  |  |
| Accounts individually evaluated for impairment | $ | 489 |  |  | $ | 489 |  |  | $ | — |  |
| Accounts collectively evaluated for impairment | 118 |  |  | 18,578 |  |  | 18,460 |  |
| Ending balances: December 31, 2012 | $ | 607 |  |  | $ | 19,067 |  |  | $ | 18,460 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-13-000013:notes:3]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of June 30, 2013, the results of their operations and comprehensive income for the three and six months ended June 30, 2013 and 2012 and their cash flows for the six months ended June 30, 2013 and 2012. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2012.

[0000926326-13-000013:notes:4]
Our results of operations, comprehensive income and cash flows for the six months ended June 30, 2013 are not necessarily indicative of results that may be expected for the year ending December 31, 2013, or for any future period.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-13-000013:notes:5]
[same as prior period, unchanged from 0000926326-13-000010:notes:5]

[0000926326-13-000013:notes:6]
[same as prior period, unchanged from 0000926326-13-000010:notes:6]

[0000926326-13-000013:notes:7]
[same as prior period, unchanged from 0000926326-13-000010:notes:7]

[0000926326-13-000013:notes:8]
[same as prior period, unchanged from 0000926326-13-000010:notes:8]

[0000926326-13-000013:notes:9]
We have accounted for the transaction under the acquisition method of accounting in accordance with the provisions of FASB ASC Topic 805, Business Combinations. Under the acquisition method, the estimated fair value of the consideration transferred to purchase the acquired company is allocated to the assets acquired and the liabilities assumed based on their fair values. We have made significant estimates and assumptions in determining the allocation of the acquisition consideration.

[0000926326-13-000013:notes:10]
[same as prior period, unchanged from 0000926326-13-000010:notes:10]

[0000926326-13-000013:notes:11]
[same as prior period, unchanged from 0000926326-13-000010:notes:11]

[0000926326-13-000013:notes:12]
[same as prior period, unchanged from 0000926326-13-000010:notes:12]

[0000926326-13-000013:notes:13]
The total revised acquisition price was approximately $158.3 million and was allocated as follows (in thousands):

[0000926326-13-000013:notes:14]
[same as prior period, unchanged from 0000926326-13-000010:notes:14]

[0000926326-13-000013:notes:15]
[same as prior period, unchanged from 0000926326-13-000010:notes:15]

[0000926326-13-000013:notes:16]
[same as prior period, unchanged from 0000926326-13-000010:notes:16]

[0000926326-13-000013:notes:17]
[same as prior period, unchanged from 0000926326-13-000010:notes:17]

[0000926326-13-000013:notes:18]
[same as prior period, unchanged from 0000926326-13-000010:notes:18]

[0000926326-13-000013:notes:19]
[same as prior period, unchanged from 0000926326-13-000010:notes:19]

[0000926326-13-000013:notes:20]
Goodwill. Approximately $82.8 million has been allocated to goodwill. Goodwill represents the excess of the fair value of the consideration transferred over the fair value of the underlying net tangible and identifiable intangible assets on the acquisition date. In accordance with ASC Topic 350, Intangibles - Goodwill and Other, goodwill will not be amortized, but instead will be tested for impairment at least annually or more frequently if certain indicators are present. We believe the MTS acquisition enhances our offerings and diversifies our revenue mix, providing a more robust product and service solution to our current customers while expanding our international presence. We consider these factors as supporting the amount of goodwill recorded.

[0000926326-13-000013:notes:21]
For three and six months ended June 30, 2013, we did not incur any acquisition-related costs in connection with the MTS acquisition. For the three and six months ended June 30, 2012, we incurred approximately $3.2 million in acquisition related costs related to the MTS acquisition. These costs are included in selling, general and administrative expenses on our Condensed Consolidated Statement of Operations.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0000926326-13-000013:notes:22]
[same as prior period, unchanged from 0000926326-13-000010:notes:28]

[0000926326-13-000013:notes:23]
Cash and cash equivalents and short-term investments consist of the following significant investment asset classes, with disclosure of amortized cost, gross unrealized gains and losses and fair value as of June 30, 2013 and December 31, 2012 (in thousands):

[0000926326-13-000013:notes:24]
|  | June 30, 2013 |  |  |
|  | AmortizedCost |  | UnrealizedGains |  | UnrealizedLosses |  | Fair Value |  | Cash / CashEquivalents |  | Short-termInvestments |  | SecurityClassification |
| Cash | $ | 34,364 |  |  | $ | — |  |  | $ | — |  |  | $ | 34,364 |  |  | $ | 34,364 |  |  | $ | — |  |  | N/A |
| Money market funds | 52,970 |  |  | — |  |  | — |  |  | 52,970 |  |  | 52,970 |  |  | — |  |  | Available for sale |
| Total cash, cash equivalents and short-term investments | $ | 87,334 |  |  | $ | — |  |  | $ | — |  |  | $ | 87,334 |  |  | $ | 87,334 |  |  | $ | — |  |  |  |

[0000926326-13-000013:notes:25]
[same as prior period, unchanged from 0000926326-13-000010:notes:31]

[0000926326-13-000013:notes:26]
[same as prior period, unchanged from 0000926326-13-000010:notes:32]

[0000926326-13-000013:notes:27]
The following table displays the financial assets measured at fair value, on a recurring basis, with money market funds recorded within cash and cash equivalents (in thousands):

[0000926326-13-000013:notes:28]
|  | Quoted Prices in ActiveMarkets for IdenticalInstruments (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant UnobservableInputs(Level 3) |  | Total FairValue |
| At June 30, 2013 |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 52,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 52,970 |  |
| Total | $ | 52,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 52,970 |  |
| At December 31, 2012 |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 38,891 |  |  | $ | — |  |  | $ | — |  |  | $ | 38,891 |  |
| Total | $ | 38,891 |  |  | $ | — |  |  | $ | — |  |  | $ | 38,891 |  |

[0000926326-13-000013:notes:29]
[same as prior period, unchanged from 0000926326-13-000010:notes:35]


## us-gaap:CommitmentsDisclosureTextBlock

[0000926326-13-000013:notes:30]
[same as prior period, unchanged from 0000926326-13-000010:notes:36]

[0000926326-13-000013:notes:31]
At June 30, 2013, the minimum payments under our operating leases for each of the five succeeding fiscal years were as follows (in thousands):

[0000926326-13-000013:notes:32]
| 2013 (remaining six months) | $ | 2,922 |  |
| 2014 | 5,688 |  |
| 2015 | 5,439 |  |
| 2016 | 5,139 |  |
| 2017 | 4,458 |  |
| 2018 | 4,289 |  |
| Thereafter | 16,585 |  |
| Total | $ | 44,520 |  |

[0000926326-13-000013:notes:33]
[same as prior period, unchanged from 0000926326-13-000010:notes:39]

[0000926326-13-000013:notes:34]
[same as prior period, unchanged from 0000926326-13-000010:notes:40]

[0000926326-13-000013:notes:35]
In connection with the acquisition of MTS, we assumed responsibility for 132,500 square feet of manufacturing, warehousing and office space in St. Petersburg, Florida. The remaining term of the original twelve year lease agreement, which expires in September 2016 and at the time of the MTS acquisition, with a base lease commitment of approximately $3.9 million. We have two options to extend the term of the lease agreement at market rates. Each extension is for an additional 60 month term.

[0000926326-13-000013:notes:36]
[same as prior period, unchanged from 0000926326-13-000010:notes:42]

[0000926326-13-000013:notes:37]
We also have smaller rented offices in Strongsville, Ohio, Nashville, Tennessee, Waukegan, Illinois, the United Arab Emirates, the People's Republic of China and the Federal Republic of Germany.

[0000926326-13-000013:notes:38]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. During the normal course of business, we issue purchase orders with estimates of our requirements several months ahead of the delivery dates. Our near-term commitments to our contract manufacturers and suppliers totaled $8.0 million as of June 30, 2013.

[0000926326-13-000013:notes:39]
At June 30, 2013, we have recorded $4.4 million for uncertain tax positions under long term liabilities in accordance with GAAP, summarized under Note 1, “Organization and Summary of Significant Accounting Policies.” As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, we do not present this in a commitments table.


## us-gaap:DerivativesPolicyTextBlock

[0000926326-13-000013:notes:40]
Currency forward contracts. From time to time we enter into foreign currency forward contracts to protect our business from the risk that exchange rates may affect the eventual cash flows resulting from intercompany transactions between Omnicell and our foreign subsidiaries. These transactions primarily arise as a result of products manufactured in the U.S. and sold to foreign subsidiaries in U.S. dollars rather than the subsidiaries' functional currencies. These forward contracts are considered to be financial derivative instruments and are recorded at fair value in the balance sheet. Changes in fair value of these financial derivative instruments are either recognized in other comprehensive income (a component of stockholders' equity) or net income depending on whether the derivative has been designated and qualifies as a highly effective hedging instrument. At June 30, 2013 and December 31, 2012, we had no foreign currency forward contracts which qualify for hedge accounting.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000926326-13-000013:notes:41]
[same as prior period, unchanged from 0000926326-13-000010:notes:47]

[0000926326-13-000013:notes:42]
[same as prior period, unchanged from 0000926326-13-000010:notes:48]

[0000926326-13-000013:notes:43]
[same as prior period, unchanged from 0000926326-13-000010:notes:49]

[0000926326-13-000013:notes:44]
Equity Incentive Plan

[0000926326-13-000013:notes:45]
On May 19, 2009, at our 2009 Annual Meeting of Stockholders (the "2009 Annual Meeting") our stockholders approved the Omnicell, Inc. 2009 Equity Incentive Plan (the "2009 Plan") which authorized 2,100,000 shares to be issued. The 2009 Plan provides for the issuance of incentive stock options, non-statutory stock options, stock appreciation rights, restricted stock awards, restricted stock unit awards, performance stock awards, performance cash awards and other stock awards to our employees, directors and consultants.

[0000926326-13-000013:notes:46]
[same as prior period, unchanged from 0000926326-13-000010:notes:51]

[0000926326-13-000013:notes:47]
On December 16, 2010, at a Special Meeting of Stockholders, our stockholders approved an amendment to increase the number of shares of common stock authorized for issuance under the 2009 Plan by 2,600,000 shares and to provide that the number of common stock shares available for issuance under the 2009 Plan be reduced by 1.8 shares for each share granted as a full-value award granted on and after October 1, 2010. For each share granted as a full-value award granted prior to October 1, 2010, future shares available for grants under the 2009 Plan were reduced by 1.4 shares. Awards granted as stock options and stock appreciation rights continue to reduce the number of shares available for issuance under the 2009 Plan on a one-for-one basis. On May 21, 2013, at our Annual Meeting of Stockholders, our stockholders approved an amendment to increase the number of shares of common stock authorized for issuance under the 2009 Plan by 2,500,000 shares.

[0000926326-13-000013:notes:48]
Options granted under the 2009 Plan generally become exercisable over periods of up to four years , generally with one-fourth of the shares vesting one year from the vesting commencement date with respect to initial grants, and the remaining shares vesting in 36 equal monthly installments thereafter; however our board of directors may impose different vesting terms at its discretion on any award. Options under the 2009 Plan generally expire 10 years from the date of grant. We also grant both restricted stock and restricted stock units to participants under the 2009 Plan. The Board of Directors determines the award amount, the vesting provisions and the expiration period (not to exceed ten years) for each grant. Grants of restricted stock to non-employee directors are granted on the date of our annual meeting of stockholders and vest in full on the date of our next annual meeting of stockholders, provided such non-employee director remains a director on such date. The fair value of the stock on the date of issuance is amortized to expense from the date of grant to the date of vesting. RSUs granted to employees generally vest over a period of four years and are expensed ratably on a straight-line basis over the vesting period. We consider the dilutive impact of options, restricted stock and restricted stock units in our diluted net income per share calculation.

[0000926326-13-000013:notes:49]
[same as prior period, unchanged from 0000926326-13-000010:notes:54]

[0000926326-13-000013:notes:50]
[same as prior period, unchanged from 0000926326-13-000010:notes:55]

[0000926326-13-000013:notes:51]
At June 30, 2013, a total of 3,646,006 shares of common stock were reserved for future issuance under the 2009 Plan. At June 30, 2013, $6.4 million of total unrecognized compensation cost related to non-vested stock options was expected to be recognized over a weighted average period of 2.6 years .

[0000926326-13-000013:notes:52]
A summary of aggregate option activity for the six months ended June 30, 2013 is presented below:

[0000926326-13-000013:notes:53]
| Options: |  | Number of Shares |  | Weighted- Average Exercise Price |
|  |  | (in thousands) |  |  |
| Outstanding at December 31, 2012 |  | 4,470 |  |  | $ | 14.06 |  |
| Granted |  | 243 |  |  | $ | 17.21 |  |
| Exercised |  | (849 | ) |  | $ | 11.18 |  |
| Forfeited |  | (59 | ) |  | $ | 14.21 |  |
| Expired |  | (51 | ) |  | $ | 14.98 |  |
| Outstanding at June 30, 2013 |  | 3,754 |  |  | $ | 14.90 |  |
| Exercisable at June 30, 2013 |  | 2,686 |  |  | $ | 14.84 |  |

[0000926326-13-000013:notes:54]
[same as prior period, unchanged from 0000926326-13-000010:notes:59]

[0000926326-13-000013:notes:55]
The non-employee members of our Board of Directors are granted restricted stock on the day of our annual meeting of stockholders and such shares of restricted stock vest on the date of the subsequent year’s annual meeting of stockholders, provided such non-employee director remains a director on such date. Restricted stock units (“RSUs”) are granted to certain of our employees and generally vest over a period of four years and are expensed ratably on a straight-line basis over the vesting period. The fair value of both restricted stock and RSUs granted pursuant to our stock option plans is the product of the number of shares granted and the grant date fair value of our common stock. Our unrecognized compensation cost related to non-vested restricted stock at June 30, 2013 was approximately $0.8 million and is expected to be recognized over a weighted-average period of 0.9 years . Expected future compensation expense relating to RSUs outstanding on June 30, 2013 is $5.2 million over a weighted-average period of 2.5 years .

[0000926326-13-000013:notes:56]
A summary of activity of both restricted stock and RSUs for the six months ended June 30, 2013 is presented below:

[0000926326-13-000013:notes:57]
|  | Restricted Stock |  | Restricted Stock Units |
|  |  |  | Weighted - |  |  |  | Weighted - |
|  | Number ofShares |  | AverageGrant DateFair Value PerShare |  | Number ofShares |  | AverageGrant DateFair Value PerShare |
|  | (in thousands) |  |  |  | (in thousands) |  |  |
| Non-vested, December 31, 2012 | 58 |  |  | $ | 14.19 |  |  | 389 |  |  | $ | 14.09 |  |
| Granted | 55 |  |  | $ | 18.20 |  |  | 103 |  |  | $ | 17.46 |  |
| Vested | (61 | ) |  | $ | 14.23 |  |  | (80 | ) |  | $ | 13.95 |  |
| Forfeited | — |  |  | $ | — |  |  | (19 | ) |  | $ | 13.88 |  |
| Non-vested, June 30, 2013 | 52 |  |  | $ | 18.43 |  |  | 393 |  |  | $ | 15.01 |  |

[0000926326-13-000013:notes:58]
[same as prior period, unchanged from 0000926326-13-000010:notes:63]

[0000926326-13-000013:notes:59]
In 2011, we began incorporating performance-based restricted stock units ("PSUs") as an element of our executive compensation plans. For 2011, we granted 100,000 PSUs; however, pursuant to their terms, 120,000 PSUs ultimately became eligible for vesting based on the achievement of a certain level of shareholder return for 2011 as described below. In 2012, we granted 125,000 PSUs of which 62,500 became eligible for vesting based on the achievement of a certain level of stockholder return for 2012 as described below.

[0000926326-13-000013:notes:60]
Our unrecognized compensation cost related to non-vested performance-based restricted stock units at June 30, 2013 was approximately $1.9 million and is expected to be recognized over a weighted-average period of 1.6 years . For the three months ended June 30, 2013 and 2012, we recognized $0.4 million and $0.3 million, respectively of compensation expense for the performance-based restricted stock units. For the six months ended June 30, 2013, we recognized $0.8 million and $0.5 million of compensation expense for the performance-based restricted stock units.

[0000926326-13-000013:notes:61]
[same as prior period, unchanged from 0000926326-13-000010:notes:66]

[0000926326-13-000013:notes:62]
The fair value of a PSU award is the average of trial-specific values of the award over each of one million Monte Carlo trials. Each trial-specific value is the market value of the award at the end of the one-year performance period discounted back to the grant date. The market value of the award for each trial at the end of the performance period is the product of (a) the per share value of Omnicell stock at the end of the performance period and (b) the number of shares that vest. The number of shares that vest at the end of the performance period depends on the percentile ranking of the total stockholder return for Omnicell stock over the performance period relative to the total stockholder return of each of the other companies in the NASDAQ Healthcare Index (the "Index") as shown in the tables below.

[0000926326-13-000013:notes:63]
Vesting for the PSU awards is based on the percentile placement of our total stockholder return among the companies listed in the Index and time-based vesting. We calculate total stockholder return based on the one year annualized rates of return reflecting price appreciation plus reinvestment of dividends. For PSU awards granted on February 5, 2013 and on March 5, 2013, stock price appreciation is calculated based on the average closing prices of our common stock for the last 20 trading days leading to February 28, 2014. For PSU awards granted in 2011 and 2012, stock price appreciation is calculated based on the average closing prices of the applicable company's common stock for the 20 trading days ending on the last trading day of the year prior to the date of grant as compared to the average closing prices for the 20 trading days ended on the last trading day of the year of grant.

[0000926326-13-000013:notes:64]
[same as prior period, unchanged from 0000926326-13-000010:notes:69]

[0000926326-13-000013:notes:65]
| Percentile Placement of Our Total Stockholder Return |  | % of PSUs Eligible for Time-Based Vesting |
| Below the 35th percentile |  | —% |
| At least the 35th percentile, but below the 50th percentile |  | 50% |
| At least the 50th percentile, but below the 65th percentile |  | 100% |
| At least the 65th percentile, but below the 75th percentile (1) |  | 110% to 119% |
| At or above the 75th percentile |  | 120% |

[0000926326-13-000013:notes:66]
[same as prior period, unchanged from 0000926326-13-000010:notes:71]

[0000926326-13-000013:notes:67]
[same as prior period, unchanged from 0000926326-13-000010:notes:72]

[0000926326-13-000013:notes:68]
[same as prior period, unchanged from 0000926326-13-000010:notes:73]

[0000926326-13-000013:notes:69]
[same as prior period, unchanged from 0000926326-13-000010:notes:74]

[0000926326-13-000013:notes:70]
[same as prior period, unchanged from 0000926326-13-000010:notes:75]

[0000926326-13-000013:notes:71]
[same as prior period, unchanged from 0000926326-13-000010:notes:76]

[0000926326-13-000013:notes:72]
For the year ended December 31, 2012, in addition to the 125,000 PSUs granted in 2012, an additional 10,000 PSUs were deemed granted and vested as a result of Omnicell’s 2011 total stockholder return which caused 120% of the 2011 PSUs to become eligible for further time-based vesting. These 2011 PSUs had a time-based vesting on June 15, 2013. The 120% payout caused an additional 2,500 shares to be deemed granted and vested on June 15, 2013, which is reflected in the six months ended June 30, 2013 PSU activity table presented below.

[0000926326-13-000013:notes:73]
On February 5 and March 5 2013, the Compensation Committee approved PSU awards of 125,000 shares and 12,500 shares, respectively. If the minimum performance threshold is met as determined by the Compensation Committee of the Board of Directors in 2014, the eligible performance-based restricted stock unit awards will vest as follows: 25% of the eligible shares will vest immediately, with the remaining eligible awards vesting in equal increments, semi-annually, over the subsequent three year period beginning on June 15th and December 15th of the year after the date of grant and each subsequent year. Vesting is contingent upon continued service.

[0000926326-13-000013:notes:74]
A summary of activity of the PSUs for the six months ended June 30, 2013 is presented below:

[0000926326-13-000013:notes:75]
| Performance-based Stock Units | Number of Units |  | Weighted-AverageGrant DateFair Value PerUnit |
|  | (in thousands) |  |  |
| Non-vested, December 31, 2012 | 175 |  |  | $ | 11.00 |  |
| Granted | 140 |  |  | $ | 14.74 |  |
| Vested | (38 | ) |  | $ | 11.02 |  |
| Forfeited | (24 | ) |  | $ | — |  |
| Non-vested, June 30, 2013 | 253 |  |  | $ | 13.07 |  |

[0000926326-13-000013:notes:76]
[same as prior period, unchanged from 0000926326-13-000010:notes:81]

[0000926326-13-000013:notes:77]
We have an Employee Stock Purchase Plan (“ESPP”) under which employees can purchase shares of our common stock based on a percentage of their compensation, but not greater than 15% of their earnings, up to a maximum of $25,000 of fair value per year. The purchase price per share must be equal to the lower of 85% of the fair value of the common stock at the beginning of a 24-month offering period or the end of each six-month purchasing period. As of June 30, 2013, 4,039,838 shares had been issued under the ESPP. As of June 30, 2013 there were a total of 1,291,717 shares reserved for future issuance under the ESPP. For the three months and six months ended June 30, 2013, zero and 256,994 shares respectively, of common stock were purchased under the ESPP.

[0000926326-13-000013:notes:78]
[same as prior period, unchanged from 0000926326-13-000010:notes:83]

[0000926326-13-000013:notes:79]
[same as prior period, unchanged from 0000926326-13-000010:notes:84]

[0000926326-13-000013:notes:80]
The impact on our results for share-based compensation for the three and six months ended June 30, 2013 and 2012 was as follows (in thousands):

[0000926326-13-000013:notes:81]
|  | Three Months Ended June 30, | Six Months Ended June 30, |
|  | 2013 |  | 2012 | 2013 |  | 2012 |
| Cost of product and service revenues | $ | 324 |  |  | $ | 233 |  | $ | 629 |  |  | $ | 501 |  |
| Research and development expenses | 326 |  |  | 211 |  | 615 |  |  | 454 |  |
| Selling, general and administrative expenses | 2,037 |  |  | 1,769 |  | 4,369 |  |  | 3,465 |  |
| Total share-based compensation expenses | $ | 2,687 |  |  | $ | 2,213 |  | $ | 5,613 |  |  | $ | 4,420 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0000926326-13-000013:notes:82]
[same as prior period, unchanged from 0000926326-13-000010:notes:87]


## us-gaap:EarningsPerShareTextBlock

[0000926326-13-000013:notes:83]
[same as prior period, unchanged from 0000926326-13-000010:notes:88]

[0000926326-13-000013:notes:84]
Basic net income per share is computed by dividing net income for the period by the weighted average number of shares outstanding during the period, less shares subject to repurchase. Diluted net income per share is computed by dividing net income for the period by the weighted average number of shares, less shares subject to repurchase, plus, if dilutive, potential common stock outstanding during the period. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards and restricted stock units computed using the treasury stock method. Since their impact is anti-dilutive, we excluded 1,581,335 and 2,103,021 shares from the calculations of diluted net income per share for the six months ended June 30, 2013 and 2012, respectively.

[0000926326-13-000013:notes:85]
[same as prior period, unchanged from 0000926326-13-000010:notes:90]

[0000926326-13-000013:notes:86]
|  | Three Months Ended June 30, | Six Months Ended June 30, |
|  | 2013 |  | 2012 | 2013 |  | 2012 |
| Basic: |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 6,016 |  |  | $ | 1,375 |  | $ | 9,401 |  |  | $ | 3,726 |  |
| Weighted average shares outstanding — basic | 34,450 |  |  | 33,390 |  | 34,177 |  |  | 33,377 |  |
| Net income per share — basic | $ | 0.17 |  |  | $ | 0.04 |  | $ | 0.28 |  |  | $ | 0.11 |  |
| Diluted: |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 6,016 |  |  | $ | 1,375 |  | $ | 9,401 |  |  | $ | 3,726 |  |
| Weighted average shares outstanding — basic | 34,450 |  |  | 33,390 |  | 34,177 |  |  | 33,377 |  |
| Add: Dilutive effect of employee stock plans | 924 |  |  | 926 |  | 922 |  |  | 952 |  |
| Weighted average shares outstanding — diluted | 35,374 |  |  | 34,316 |  | 35,099 |  |  | 34,329 |  |
| Net income per share — diluted | $ | 0.17 |  |  | $ | 0.04 |  | $ | 0.27 |  |  | $ | 0.11 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000926326-13-000013:notes:87]
[same as prior period, unchanged from 0000926326-13-000010:notes:92]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-13-000013:notes:88]
[same as prior period, unchanged from 0000926326-13-000010:notes:93]

[0000926326-13-000013:notes:89]
[same as prior period, unchanged from 0000926326-13-000010:notes:94]

[0000926326-13-000013:notes:90]
Activity in goodwill by reporting units, which are the same as our operating segments, for the six months ended June 30, 2013 consists of the following (in thousands):

[0000926326-13-000013:notes:91]
|  | Goodwill at December 31, 2012 |  | Adjustments to Goodwill |  | Goodwill at June 30, 2013 |
| Reporting units: |  |  |  |  |  |
| Acute Care | $ | 28,543 |  |  | $ | — |  |  | $ | 28,543 |  |
| Non-Acute Care | 82,864 |  |  | (64 | ) |  | 82,800 |  |
| Total | $ | 111,407 |  |  | $ | (64 | ) |  | $ | 111,343 |  |

[0000926326-13-000013:notes:92]
Goodwill acquired reflects the May 21, 2012 acquisition of MedPak by Omnicell. MedPak is the parent company of MTS, a worldwide provider of medication adherence packaging systems. The acquired goodwill was assigned to the new reporting unit called Non-Acute Care, created as a result of the MTS acquisition. During the first quarter of 2013, we reduced goodwill by approximately $0.1 million due to the adjustment to the fair value of an acquired foreign currency forward contract previously carried in a component of stockholder's equity.

[0000926326-13-000013:notes:93]
There were no indefinite-life intangibles at either June 30, 2013 or December 31, 2012. Finite-life intangible assets  consist of the following (in thousands):

[0000926326-13-000013:notes:94]
|  | June 30, 2013 |  | December 31, 2012 |  |  |
|  | Gross |  |  |  | Net |  | Gross |  |  |  | Net |  |  |
|  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | CarryingAmount |  | AccumulatedAmortization |  | CarryingAmount |  | AmortizationLife |
| Finite-lived intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 54,730 |  |  | $ | 4,159 |  |  | $ | 50,571 |  |  | $ | 54,730 |  |  | $ | 3,081 |  |  | $ | 51,649 |  |  | 5-30 years |
| Acquired technology | 27,580 |  |  | 1,863 |  |  | 25,717 |  |  | 27,580 |  |  | 1,128 |  |  | 26,452 |  |  | 3-20 years |
| Patents | 1,216 |  |  | 219 |  |  | 997 |  |  | 1,217 |  |  | 259 |  |  | 958 |  |  | 20 years |
| Trade name | 6,890 |  |  | 712 |  |  | 6,178 |  |  | 6,890 |  |  | 414 |  |  | 6,476 |  |  | 3-12 years |
| Non-compete agreements | 60 |  |  | 55 |  |  | 5 |  |  | 60 |  |  | 45 |  |  | 15 |  |  | 3 years |
| Total finite-lived intangibles | $ | 90,476 |  |  | $ | 7,008 |  |  | $ | 83,468 |  |  | $ | 90,477 |  |  | $ | 4,927 |  |  | $ | 85,550 |  |  |  |

[0000926326-13-000013:notes:95]
Amortization expense totaled $1.1 million and $0.6 million for the three months ended June 30, 2013 and 2012, respectively. Amortization expense totaled $2.1 million and $0.7 million for the six months ended June 30, 2013 and 2012, respectively. The amortization of acquired technology is included within product cost of sales; other acquired intangibles are usually amortized within selling, general and administrative expenses.

[0000926326-13-000013:notes:96]
Estimated annual expected amortization expense of the finite-lived intangible assets at June 30, 2013 was as follows (in thousands):

[0000926326-13-000013:notes:97]
| 2013 (remaining six months) | $ | 2,129 |  |
| 2014 | 4,228 |  |
| 2015 | 4,204 |  |
| 2016 | 3,854 |  |
| 2017 | 3,818 |  |
| 2018 | 3,712 |  |
| Thereafter | 61,523 |  |
| Total | $ | 83,468 |  |


## us-gaap:IncomeTaxPolicyTextBlock

[0000926326-13-000013:notes:98]
Income taxes. We record an income tax provision for the anticipated tax consequences of the reported results of operations. In accordance with GAAP, the provision for income taxes is computed using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates expected to apply in the periods in which those tax assets and liabilities are expected to be realized. In the event that we determine all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

[0000926326-13-000013:notes:99]
[same as prior period, unchanged from 0000926326-13-000010:notes:104]

[0000926326-13-000013:notes:100]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 38.7% and 40.9% for the six months ended June 30, 2013 and 2012, respectively. The 2013 annual effective tax rate differed from the statutory rate of 35.0% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the federal research and development credit claimed and the domestic production activities deduction. The 2012 annual effective tax rate differed from the statutory rate of 35.0% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.


## us-gaap:InventoryDisclosureTextBlock

[0000926326-13-000013:notes:101]
[same as prior period, unchanged from 0000926326-13-000010:notes:109]

[0000926326-13-000013:notes:102]
[same as prior period, unchanged from 0000926326-13-000010:notes:110]

[0000926326-13-000013:notes:103]
|  | June 30, 2013 | December 31, 2012 |
| Raw materials | $ | 9,842 |  | $ | 9,994 |  |
| Work in process | 848 |  | 385 |  |
| Finished goods | 15,670 |  | 16,524 |  |
| Total | $ | 26,360 |  | $ | 26,903 |  |


## us-gaap:LegalMattersAndContingenciesTextBlock

[0000926326-13-000013:notes:104]
Contingencies

[0000926326-13-000013:notes:105]
Legal Proceedings

[0000926326-13-000013:notes:106]
On March 8, 2013, Bobbi Polanco (“Polanco”) filed a putative class action complaint in the United States District Court for the District of New Jersey against Omnicell and certain of our customers (Case No. 1:13-cv-01417-NLH-KLM) alleging breach of state security notification laws, violations of state consumer fraud laws, fraud, negligence and conspiracy relating to the theft of an Omnicell electronic device containing medication dispensing cabinet log files, including certain patient health information, and subsequent notification of this unauthorized disclosure of personal health information. Polanco is seeking an injunction against the defendants to prevent each of them from committing the acts complained of in the future and monetary damages, costs and expenses. On May 2, 2013, the United States District Court for the District of New Jersey entered an order to show cause which provided, in relevant part, that Polanco is required to show cause as to why the case should not be dismissed for lack of subject matter jurisdiction. On May 13, 2013, Polanco filed an amended complaint. On  May 31, 2013, Omnicell filed a motion to dismiss the complaint on the grounds that Polanco failed to satisfy constitutional standing requirements and that she failed to state a claim against Omnicell  for violating  state data breach notification statutes, consumer fraud, common law fraud, negligence and conspiracy. Omnicell also joined in the arguments of the other defendants seeking dismissal. On July 1, 2013, Polanco filed an opposition to the motions to dismiss. On July 15, 2013, Omnicell filed its reply to the opposition from Polanco. Omnicell is currently awaiting a decision from the court and intends to defend the matter vigorously.

[0000926326-13-000013:notes:107]
As required under ASC 450, "Contingencies," we accrue for contingencies when we believe that a loss is probable and that we can reasonably estimate the amount of any such loss. We have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. We believe that we have valid defenses with respect to legal proceedings pending against us. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-13-000013:notes:108]
Guarantees

[0000926326-13-000013:notes:109]
As permitted under Delaware law and our certificate of incorporation and bylaws, we have agreed to indemnify our directors and officers against certain losses that they may suffer by reason of the fact that such persons are, were or become our directors or officers. The term of the indemnification period is for the director’s or officer’s lifetime and there is no limit on the potential amount of future payments that we could be required to make under these indemnification agreements. We have purchased a directors’ and officers’ liability insurance policy that may enable us to recover a portion of any future payments that we may be required to make under these indemnification agreements. Assuming the applicability of coverage and the willingness of the insurer to assume coverage and subject to certain retention, loss limits and other policy provisions, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations. However, no assurances can be given that the insurers will not attempt to dispute the validity, applicability or amount of coverage without expensive and time-consuming litigation against the insurers.

[0000926326-13-000013:notes:110]
Additionally, we undertake indemnification obligations in our ordinary course of business in connection with, among other things, the licensing of our products and the provision of our support services. In the ordinary course of our business, we have in the past and may in the future agree to indemnify another party, generally our business affiliates or customers, against certain losses suffered or incurred by the indemnified party in connection with various types of claims, which may include, without limitation, claims of intellectual property infringement, certain tax liabilities, our gross negligence or intentional acts in the performance of support services and violations of laws. The term of these indemnification obligations is generally perpetual. In general, we attempt to limit the maximum potential amount of future payments that we may be required to make under these indemnification obligations to the amounts paid to us by a customer, but in some cases the obligation may not be so limited. In addition, we have in the past and may in the future warrant to our customers that our products will conform to functional specifications for a limited period of time following the date of installation (generally not exceeding 30 days) or that our software media is free from material defects. Sales contracts for certain of our medication packaging systems often include limited warranties for up to six months, but the periodic activity and ending warranty balances we record have historically been immaterial.

[0000926326-13-000013:notes:111]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of June 30, 2013 or December 31, 2012.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-13-000013:notes:112]
Recently Adopted Accounting Standards

[0000926326-13-000013:notes:113]
In February 2013, the Financial Accounting Standards Board (“FASB”) issued 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income (AOCI), which aims to improve the reporting of reclassifications out of AOCI. This update requires an entity to report the effect of significant reclassifications out of AOCI on the respective line items in net income if the amount being reclassified is required under GAAP to be reclassified in its entirety to net income. For other amounts that are not required under GAAP to be reclassified in their entirety to net income in the same reporting period, an entity is required to cross-reference other disclosures required under GAAP that provide additional detail about those amounts. The amendments do not change the current requirements for reporting net income or other comprehensive income in financial statements. For public entities, the amendments are effective prospectively for reporting periods beginning after December 15, 2012. We adopted this guidance in the first quarter of 2013. This update did not have any significant impact on our financial position, operating results or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000926326-13-000013:notes:114]
[same as prior period, unchanged from 0000926326-13-000010:notes:120]

[0000926326-13-000013:notes:115]
[same as prior period, unchanged from 0000926326-13-000010:notes:121]


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-13-000013:notes:116]
[same as prior period, unchanged from 0000926326-13-000010:notes:154]

[0000926326-13-000013:notes:117]
[same as prior period, unchanged from 0000926326-13-000010:notes:155]

[0000926326-13-000013:notes:118]
|  | June 30, 2013 |  | December 31, 2012 |
| Equipment | $ | 34,716 |  |  | $ | 32,528 |  |
| Furniture and fixtures | 5,104 |  |  | 5,126 |  |
| Leasehold improvements | 7,139 |  |  | 6,992 |  |
| Purchased software | 19,735 |  |  | 19,870 |  |
| Capital in process | 2,812 |  |  | 2,693 |  |
|  | 69,506 |  |  | 67,209 |  |
| Accumulated depreciation and amortization | (35,392 | ) |  | (33,102 | ) |
| Property and equipment, net | $ | 34,114 |  |  | $ | 34,107 |  |

[0000926326-13-000013:notes:119]
Depreciation and amortization of property and equipment totaled approximately $2.9 million and $1.9 million for the three months ended June 30, 2013 and 2012, respectively. Depreciation and amortization of property and equipment totaled approximately $5.6 million and $3.5 million for the six months ended June 30, 2013 and 2012, respectively.


## us-gaap:ReceivablesPolicyTextBlock

[0000926326-13-000013:notes:120]
Accounts receivable and notes receivable (net investment in sales type leases). We actively manage our accounts receivable to minimize credit risk. We typically sell to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer's impaired ability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position. Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

[0000926326-13-000013:notes:121]
The retained in-house leases discussed above are considered financing receivables. Our credit policies and evaluation of credit risk and write-off policies are applied alike to trade receivables and the net-investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class. Financing receivables which are reserved are generally transferred to cash-basis accounting so that revenue is recognized only as cash is received. However, the cash basis accounts continue to accrue interest.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000926326-13-000013:notes:122]
For the three and six months ended June 30, 2013 and 2012, the contributions of our segments to net revenues and income from operations, and the reconciliation to total net income, were as follows (amounts in thousands):

[0000926326-13-000013:notes:123]
|  | Three Months Ended June 30, 2013 |  | Three Months Ended June 30, 2012 |
|  | Acute Care |  | Non-Acute Care |  | Total |  | Acute Care |  | Non-Acute Care (1) |  | Total |
| Net revenues from external customers | $ | 68,112 |  |  | $ | 25,574 |  |  | $ | 93,686 |  |  | $ | 64,309 |  |  | 11,075 |  |  | $ | 75,384 |  |
| Cost of revenues | 29,819 |  |  | 14,499 |  |  | 44,318 |  |  | 28,249 |  |  | 7,759 |  |  | 36,008 |  |
| Gross profit | $ | 38,293 |  |  | $ | 11,075 |  |  | $ | 49,368 |  |  | $ | 36,060 |  |  | $ | 3,316 |  |  | $ | 39,376 |  |
| Gross margin % | 56.2 | % |  | 43.3 | % |  | 52.7 | % |  | 56.1 | % |  | 29.9 | % |  | 52.2 | % |
| Operating expenses | 31,206 |  |  | 8,803 |  |  | 40,009 |  |  | 33,249 |  |  | 3,696 |  |  | 36,945 |  |
| Income from operations | $ | 7,087 |  |  | $ | 2,272 |  |  | $ | 9,359 |  |  | $ | 2,811 |  |  | (380 | ) |  | $ | 2,431 |  |
| Operating margin % | 10.4 | % |  | 8.9 | % |  | 10.0 | % |  | 4.4 | % |  | (16.7 | )% |  | 3.2 | % |
| Interest and other income (expense), net |  |  |  |  | 63 |  |  |  |  |  |  | (73 | ) |
| Income before provision for income taxes |  |  |  |  | 9,422 |  |  |  |  |  |  | 2,358 |  |
| Provision for income taxes |  |  |  |  | 3,406 |  |  |  |  |  |  | 983 |  |
| Net income |  |  |  |  | $ | 6,016 |  |  |  |  |  |  | $ | 1,375 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the date of acquisition. |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000926326-13-000013:notes:124]
Revenue recognition. We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems with related services, which are sold in our principal market, which is the healthcare industry. Revenues related to consumable products are reported net of discounts provided to our customers. Our customer arrangements typically include one or more of the following deliverables:

[0000926326-13-000013:notes:125]
| • | Products—Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies. |

[0000926326-13-000013:notes:126]
| • | Software—Additional software applications that enable incremental functionality of our equipment. |

[0000926326-13-000013:notes:127]
| • | Installation—Installation of equipment as integrated systems at customers' sites. |

[0000926326-13-000013:notes:128]
| • | Post-installation technical support—Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available. |

[0000926326-13-000013:notes:129]
| • | Professional services—Other customer services such as training and consulting. |

[0000926326-13-000013:notes:130]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

[0000926326-13-000013:notes:131]
| • | Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for equipment leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement. |

[0000926326-13-000013:notes:132]
| • | Delivery has occurred. Equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installed installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. We recognize revenue from sales of products to distributors upon delivery, when no contractual obligations for installation exists, assuming all other revenue criteria are met since we do not allow for rights of return or refund. For sales to distributors where we assume contractual installation obligations or new distributors whom we have not fully trained to install our products, the equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period, and we recognize revenue on training and professional services as those services are performed. |

[0000926326-13-000013:notes:133]
| • | Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services. |

[0000926326-13-000013:notes:134]
| • | Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable. |

[0000926326-13-000013:notes:135]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. We allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support services and professional services. When VSOE of fair value is not available, third-party evidence ("TPE") of fair value for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE, TPE and BESP information and obtain formal approval by appropriate levels of management.

[0000926326-13-000013:notes:136]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable on the basis of its estimated selling price. In addition, the amount recognized for any delivered items cannot exceed that which is not contingent upon delivery of any remaining items in the arrangement.

[0000926326-13-000013:notes:137]
We also use the residual method of allocating the arrangement consideration in certain circumstances. We use the residual method to allocate total arrangement consideration between delivered and undelivered items for any arrangements entered into prior to January 1, 2011 and not subsequently materially-modified. The use of the residual method is required by software revenue recognition rules that applied to sales of most of our products and services until the adoption of the new revenue recognition guidance. We also use the residual method to allocate revenue between the software products that enable incremental equipment functionality and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

[0000926326-13-000013:notes:138]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000926326-13-000013:notes:139]
[same as prior period, unchanged from 0000926326-13-000010:notes:160]

[0000926326-13-000013:notes:140]
|  | June 30, 2013 | December 31, 2012 |
| Rebates and lease buyouts | $ | 3,657 |  | $ | 3,179 |  |
| Advance payments from customers | 3,686 |  | 2,829 |  |
| Accrued Group Purchasing Organization (GPO) fees | 2,304 |  | 2,278 |  |
| Technology license purchase obligation, current portion | 1,500 |  | 1,750 |  |
| Taxes payable | 1,196 |  | 555 |  |
| Other | 1,710 |  | 1,397 |  |
| Total | $ | 14,053 |  | $ | 11,988 |  |


## us-gaap:ScheduleOfCreditLossesRelatedToFinancingReceivablesNoncurrentTableTextBlock

[0000926326-13-000013:notes:141]
The following table summarizes the activity for the allowance for credit losses for the investment in sales-type leases for the three and six months ended June 30, 2013 and 2012 (in thousands):

[0000926326-13-000013:notes:142]
|  | Three Months Ended June 30, | Six Months Ended June 30 |
|  | 2013 |  | 2012 | 2013 |  | 2012 |
| Allowance for credit losses, beginning of period | $ | 190 |  |  | $ | 257 |  | $ | 607 |  |  | $ | 284 |  |
| Current period provision (reversal) | 6 |  |  | 422 |  | 19 |  |  | 422 |  |
| Direct write-downs charged against the allowance | — |  |  | — |  | (413 | ) |  | — |  |
| Recoveries of amounts previously charged off | (12 | ) |  | (20 | ) | (29 | ) |  | (47 | ) |
| Allowance for credit losses, end of period | $ | 184 |  |  | $ | 659 |  | $ | 184 |  |  | $ | 659 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000926326-13-000013:notes:143]
The minimum lease payments under sales-type leases as of June 30, 2013 were as follows (in thousands):

[0000926326-13-000013:notes:144]
| 2013 (remaining six months) | $ | 3,165 |  |
| 2014 | 5,589 |  |
| 2015 | 4,499 |  |
| 2016 | 3,238 |  |
| 2017 | 2,493 |  |
| Thereafter | 935 |  |
| Total | $ | 19,919 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-13-000013:notes:145]
At June 30, 2013, segment assets were as follows (amounts in thousands):

[0000926326-13-000013:notes:146]
|  | June 30, 2013 |  | December 31, 2012 |
|  | Acute Care |  | Non-Acute Care |  | Total |  | Acute Care |  | Non-Acute Care (1) |  | Total |
| Segment Assets | $ | 256,858 |  |  | $ | 215,270 |  |  | $ | 472,128 |  |  | $ | 235,186 |  |  | $ | 206,633 |  |  | $ | 441,819 |  |

[0000926326-13-000013:notes:147]
At three and six months ended June 30, 2013 and 2012, segment depreciation/amortization, and capital expenditures were as follows (amounts in thousands):

[0000926326-13-000013:notes:148]
|  | Three Months Ended June 30, 2013 |  | Three Months Ended June 30, 2012 |
|  | Acute Care |  | Non-Acute Care |  | Total |  | Acute Care |  | Non-Acute Care (1) | Total |
| Depreciation/Amortization | $ | 2,804 |  |  | $ | 1,968 |  |  | $ | 4,772 |  |  | $ | 2,131 |  |  | $ | 867 |  | $ | 2,998 |  |
| Capital Expenditures | 1,018 |  |  | 1,395 |  |  | 2,413 |  |  | $ | 2,569 |  |  | $ | 80 |  | $ | 2,649 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the date of acquisition. |  |

[0000926326-13-000013:notes:149]
|  | Six Months Ended June 30, 2013 |  | Six Months Ended June 30, 2012 |
|  | Acute Care |  | Non-Acute Care |  | Total |  | Acute Care |  | Non-Acute Care (1) | Total |
| Depreciation/Amortization | $ | 5,546 |  |  | $ | 3,698 |  |  | $ | 9,244 |  |  | $ | 4,466 |  |  | $ | 867 |  | 5,333 |  |
| Capital Expenditures | 2,018 |  |  | 3,733 |  |  | 5,751 |  |  | $ | 4,007 |  |  | $ | 80 |  | $ | 4,087 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the date of acquisition. |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-13-000013:notes:150]
[same as prior period, unchanged from 0000926326-13-000010:notes:170]

[0000926326-13-000013:notes:151]
[same as prior period, unchanged from 0000926326-13-000010:notes:171]

[0000926326-13-000013:notes:152]
The Acute Care segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems. The Non-Acute Care segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services, but also includes medication dispensing systems sold to non-acute care pharmacies and facilities. We report segment information based on the management approach. The management approach designates the internal reporting used by the Chief Operating Decision Maker (the "CODM") for making decisions and assessing performance as the source of our operating segments. The CODM is our Chief Executive Officer. The CODM allocates resources to and assesses the performance of each operating segment, using information about its revenues, gross profit and income (loss) from operations.

[0000926326-13-000013:notes:153]
[same as prior period, unchanged from 0000926326-13-000010:notes:172]

[0000926326-13-000013:notes:154]
[same as prior period, unchanged from 0000926326-13-000010:notes:173]

[0000926326-13-000013:notes:155]
During 2012, we realigned our management reporting structure to report sales of Omnicell's dispensing systems and other related business transactions into long-term care pharmacies and facilities. Accordingly, the operations of this portion of our activities are now being reflected as a part of the Non-Acute Care segment for three and six months ended June 30, 2013.

[0000926326-13-000013:notes:156]
[same as prior period, unchanged from 0000926326-13-000010:notes:175]

[0000926326-13-000013:notes:157]
Effective in the second quarter of fiscal 2013, management changed its methodology for allocating certain expenses to its reportable segments. We have reclassified segment operating results for the three and six months ended June 30, 2012 to conform to the fiscal 2013 presentation. For the three and six months ended June 30, 2013 and 2012, the contributions of our segments to net revenues and income from operations, and the reconciliation to total net income, were as follows (amounts in thousands):

[0000926326-13-000013:notes:158]
|  | Six Months Ended June 30, 2013 |  | Six Months Ended June 30, 2012 |
|  | Acute Care |  | Non-Acute Care |  | Total |  | Acute Care |  | Non-Acute Care (1) |  | Total |
| Net revenues from external customers | $ | 134,110 |  |  | $ | 46,686 |  |  | $ | 180,796 |  |  | $ | 126,900 |  |  | $ | 12,627 |  |  | $ | 139,527 |  |
| Cost of revenues | 59,122 |  |  | 26,939 |  |  | 86,061 |  |  | 55,938 |  |  | 8,464 |  |  | 64,402 |  |
| Gross profit | $ | 74,988 |  |  | $ | 19,747 |  |  | $ | 94,735 |  |  | $ | 70,962 |  |  | $ | 4,163 |  |  | $ | 75,125 |  |
| Gross margin % | 55.9 | % |  | 42.3 | % |  | 52.4 | % |  | 55.9 | % |  | 33.0 | % |  | 53.8 | % |
| Operating expenses | 63,140 |  |  | 18,068 |  |  | 81,208 |  |  | 65,098 |  |  | 3,961 |  |  | 69,059 |  |
| Income from operations | $ | 11,848 |  |  | $ | 1,679 |  |  | $ | 13,527 |  |  | $ | 5,864 |  |  | 202 |  |  | $ | 6,066 |  |
| Operating margin % | 8.8 | % |  | 3.6 | % |  | 7.5 | % |  | 4.6 | % |  | (16.7 | )% |  | 4.3 | % |
| Interest and other income (expense), net |  |  |  |  | (159 | ) |  |  |  |  |  | 23 |  |
| Income before provision for income taxes |  |  |  |  | 13,368 |  |  |  |  |  |  | 6,089 |  |
| Provision for income taxes |  |  |  |  | 3,967 |  |  |  |  |  |  | 2,363 |  |
| Net income |  |  |  |  | $ | 9,401 |  |  |  |  |  |  | $ | 3,726 |  |
| (1) Non-Acute Care segment includes MTS results from May 21, 2012, the date of acquisition. |


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0000926326-13-000013:notes:159]
Segment information. Prior to the acquisition of MTS, we managed our business on the basis of a single operating segment, and a single reporting unit within that segment per ASC 280, Segment Reporting. Beginning with the acquisition of MTS, which we completed in May 2012, we have organized our business into two operating business segments: Acute Care, which primarily includes products and services sold to hospital customers, and Non-Acute Care, which primarily includes products and services sold to customers outside of the hospital setting.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0000926326-13-000013:notes:160]
Accounting policy for shipping costs. Outbound freight billed to customers is recorded as product revenue. The related shipping and handling cost is expensed as part of selling, general and administrative expense.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-13-000013:notes:161]
[same as prior period, unchanged from 0000926326-13-000010:notes:176]

[0000926326-13-000013:notes:162]
[same as prior period, unchanged from 0000926326-13-000010:notes:177]

[0000926326-13-000013:notes:163]
[same as prior period, unchanged from 0000926326-13-000010:notes:178]

[0000926326-13-000013:notes:164]
[same as prior period, unchanged from 0000926326-13-000010:notes:179]

[0000926326-13-000013:notes:165]
There were no shares repurchased during both the three and six months ended June 30, 2013 in connection with the 2008 Repurchase Program. During the three months ended June 30, 2012, we repurchased 505,137 shares through the stock repurchase program at an average cost of $13.98 per share, including commissions, compared to zero shares repurchased in the three months ended March 31, 2012.

[0000926326-13-000013:notes:166]
From the inception of the 2008 Repurchase Program in February 2008 through June 30, 2013, we have repurchased a total of 5,853,975 shares at an average cost of $15.37 per share through open market purchases. As of June 30, 2013, we have completed the 2008 Repurchase Program having repurchased $90.0 million of our common stock.

[0000926326-13-000013:notes:167]
[same as prior period, unchanged from 0000926326-13-000010:notes:182]

[0000926326-13-000013:notes:168]
[same as prior period, unchanged from 0000926326-13-000010:notes:183]

[0000926326-13-000013:notes:169]
Through June 30, 2013, we have not repurchased any shares through the 2012 Repurchase Program.


## omcl:AccruedLiabilitiesTextBlock

[0000926326-13-000013:notes:170]
[same as prior period, unchanged from 0000926326-13-000010:notes:185]


## omcl:DeferredGrossProfitTableTextBlock

[0000926326-13-000013:notes:171]
[same as prior period, unchanged from 0000926326-13-000010:notes:186]

[0000926326-13-000013:notes:172]
|  | June 30, 2013 |  | December 31, 2012 |
| Sales of medication and supply dispensing systems and packaging equipment, which have been delivered and invoiced but not yet installed | $ | 38,481 |  |  | $ | 30,138 |  |
| Cost of revenues, excluding installation costs | (13,131 | ) |  | (9,366 | ) |
| Deferred gross profit | $ | 25,350 |  |  | $ | 20,772 |  |


## omcl:DeferredGrossProfitTextBlock

[0000926326-13-000013:notes:173]
[same as prior period, unchanged from 0000926326-13-000010:notes:188]


## omcl:ImpairmentOfSoftwareDevelopmentCostsTableTextBlock

[0000926326-13-000013:notes:174]
[same as prior period, unchanged from 0000926326-13-000010:notes:189]

[0000926326-13-000013:notes:175]
[same as prior period, unchanged from 0000926326-13-000010:notes:190]

[0000926326-13-000013:notes:176]
[same as prior period, unchanged from 0000926326-13-000010:notes:191]


## omcl:NetInvestmentsInSalesTypeLeasesTextBlock

[0000926326-13-000013:notes:177]
[same as prior period, unchanged from 0000926326-13-000010:notes:192]

[0000926326-13-000013:notes:178]
Our sales-type leases are for terms generally up to five years. Sales-type lease receivables are collateralized by the underlying equipment. The components of our net investment in sales-type leases are as follows (in thousands):

[0000926326-13-000013:notes:179]
|  | June 30, 2013 |  | December 31, 2012 |
| Net minimum lease payments to be received | $ | 19,919 |  |  | $ | 19,665 |  |
| Less unearned interest income portion | 1,164 |  |  | 1,205 |  |
| Net investment in sales-type leases | 18,755 |  |  | 18,460 |  |
| Less current portion(1) | 5,533 |  |  | 5,232 |  |
| Non-current net investment in sales-type leases(2) | $ | 13,222 |  |  | $ | 13,228 |  |

[0000926326-13-000013:notes:180]
(1)     A component of other current assets. This amount is net of allowance for doubtful accounts of $0.1 million as of June 30, 2013 and $0.5 million as of December 31, 2012.

[0000926326-13-000013:notes:181]
(2)     This amount is net of allowance for doubtful accounts of $0.1 million as of June 30, 2013 and $0.1 million as of December 31, 2012.
