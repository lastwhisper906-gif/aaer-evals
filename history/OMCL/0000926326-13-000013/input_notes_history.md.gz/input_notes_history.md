# OMCL note change history — 0000926326-13-000010 → 0000926326-13-000013


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-08-09):
[0000926326-13-000013:note_history:1]
On March 8, 2013, Bobbi Polanco (“Polanco”) filed a putative class action complaint in the United States District Court for the District of New Jersey against Omnicell and certain of our customers (Case No. 1:13-cv-01417-NLH-KLM) alleging breach of state security notification laws, violations of state consumer fraud laws, fraud, negligence and conspiracy relating to the theft of an Omnicell electronic device containing medication dispensing cabinet log files, including certain patient health information, and subsequent notification of this unauthorized disclosure of personal health information. Polanco is seeking an injunction against the defendants to prevent each of them from committing the acts complained of in the future and monetary damages, costs and expenses. On May 2, 2013, the United States District Court for the District of New Jersey entered an order to show cause which provided, in relevant part, that Polanco is required to show cause as to why the case should not be dismissed for lack of subject matter jurisdiction. On May 13, 2013, Polanco filed an amended complaint. On  May 31, 2013, Omnicell filed a motion to dismiss the complaint on the grounds that Polanco failed to satisfy constitutional standing requirements and that she failed to state a claim against Omnicell  for violating  state data breach notification statutes, consumer fraud, common law fraud, negligence and conspiracy. Omnicell also joined in the arguments of the other defendants seeking dismissal. On July 1, 2013, Polanco filed an opposition to the motions to dismiss. On July 15, 2013, Omnicell filed its reply to the opposition from Polanco. Omnicell is currently awaiting a decision from the court and intends to defend the matter vigorously.
  (was, 2013-05-09, similarity 0.7281):
[0000926326-13-000010:note_history:1]
On March 8, 2013, Bobbi Polanco (“Polanco”) filed a putative class action complaint in the United States District Court for the District of New Jersey against Omnicell and certain of our customers (Case No. 1:13-cv-01417-NLH-KLM) alleging breach of state security notification laws, violations of state consumer fraud laws, fraud, negligence and conspiracy relating to the theft of an Omnicell electronic device containing medication dispensing cabinet log files, including certain patient health information, and subsequent notification of this unauthorized disclosure of personal health information. Polanco is seeking an injunction against the defendants to prevent each of them from committing the acts complained of in the future and monetary damages, costs and expenses.On May 2, 2013, the United States District Court for the District of New Jersey entered an order to show cause which provided, in relevant part, that Polanco is required to show cause as to why the case should not be dismissed for lack of subject matter jurisdiction. Omnicell is currently evaluating a response to this complaint and intends to defend the matter vigorously.

- changed (2013-08-09):
[0000926326-13-000013:note_history:2]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of June 30, 2013 or December 31, 2012.
  (was, 2013-05-09, similarity 0.9962):
[0000926326-13-000010:note_history:2]
From time to time, we may also warrant that our professional services will be performed in a good and workmanlike manner or in a professional manner consistent with industry standards. We generally seek to disclaim most warranties, including any implied or statutory warranties such as warranties of merchantability, fitness for a particular purpose, title, quality and non-infringement, as well as any liability with respect to incidental, consequential, special, exemplary, punitive or similar damages. In some states, such disclaimers may not be enforceable. If necessary, we would provide for the estimated cost of product and service warranties based on specific warranty claims and claim history. We have not been subject to any significant claims for such losses and have not incurred any material costs in defending or settling claims related to these indemnification obligations. Accordingly, we believe it is unlikely that we will be required to pay any material amounts pursuant to these indemnification obligations or potential warranty claims and, therefore, no material liabilities have been recorded for such indemnification obligations as of March 31, 2013 or December 31, 2012.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-08-09):
[0000926326-13-000013:note_history:3]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of June 30, 2013, the results of their operations and comprehensive income for the three and six months ended June 30, 2013 and 2012 and their cash flows for the six months ended June 30, 2013 and 2012. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2012.
  (was, 2013-05-09, similarity 0.9521):
[0000926326-13-000010:note_history:3]
Basis of presentation. These interim condensed consolidated financial statements are unaudited but reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of Omnicell and its subsidiaries as of March 31, 2013, the results of their operations and comprehensive income for the three months ended March 31, 2013 and 2012 and their cash flows for the three months ended March 31, 2013 and 2012. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited condensed consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the year ended December 31, 2012.

- removed (2013-08-09):
[0000926326-13-000010:note_history:4]
Our results of operations, comprehensive income and cash flows for the three months ended March 31, 2013 are not necessarily indicative of results that may be expected for the year ending December 31, 2013, or for any future period.

- removed (2013-08-09):
[0000926326-13-000010:note_history:5]
Use of estimates. GAAP requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management's best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, share-based compensation, inventory valuation, valuation of goodwill and purchased intangibles, valuation of long-lived assets and accounting for income taxes.

- removed (2013-08-09):
[0000926326-13-000010:note_history:6]
Principles of consolidation. The condensed consolidated financial statements include the accounts of our wholly-owned subsidiaries. All significant inter-company accounts and transactions have been eliminated in consolidation.

- removed (2013-08-09):
[0000926326-13-000010:note_history:7]
Reclassifications. Certain reclassifications have been made to the prior year consolidated balance sheet to conform to the current period presentation. None of these reclassifications are material to the consolidated financial statements.

- removed (2013-08-09):
[0000926326-13-000010:note_history:8]
Foreign currency translation. We translate the assets and liabilities of our non-U.S. dollar functional currency subsidiaries into U.S. dollars using exchange rates in effect at the end of each period. Revenue and expenses for these subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recorded as foreign currency translation adjustments and included in accumulated other comprehensive income in stockholders’ equity.

- removed (2013-08-09):
[0000926326-13-000010:note_history:9]
Fair value of financial instruments. We value our financial assets and liabilities on a recurring basis using the fair value hierarchy established in Accounting Standards Codification ("ASC") 820, Fair Value Measurements and Disclosures. ASC 820 describes three levels of inputs that may be used to measure fair value, as follows:

- removed (2013-08-09):
[0000926326-13-000010:note_history:10]
Level 1 inputs, which include quoted prices in active markets for identical assets or liabilities;

- removed (2013-08-09):
[0000926326-13-000010:note_history:11]
Level 2 inputs, which include observable inputs other than Level 1 inputs, such as quoted prices for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the asset or liability; and

- removed (2013-08-09):
[0000926326-13-000010:note_history:12]
Level 3 inputs, which include unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the underlying asset or liability. Level 3 assets and liabilities include those whose fair value measurements are determined using pricing models, discounted cash flow methodologies or similar valuation techniques, as well as significant management judgment or estimation.

- removed (2013-08-09):
[0000926326-13-000010:note_history:13]
At March 31, 2013 and December 31, 2012, our financial assets, measured at fair value on a recurring basis, utilizing Level 1 inputs included money market funds, classified as cash equivalents. For these items, quoted market prices are readily available and fair value approximates carrying value. We do not currently have any material financial instruments, measured at fair value on a recurring basis, utilizing Level 2 or Level 3 inputs.

- removed (2013-08-09):
[0000926326-13-000010:note_history:14]
Classification of marketable securities. Securities held as investments for the indefinite future pending future spending requirements are classified as “Available-for-sale” and are carried at their fair value, with any unrealized gain or loss recorded to other comprehensive income until realized. At March 31, 2013 and December 31, 2012, we held $40.4 million and $38.9 million, respectively, of money market mutual funds classified as Available-for-sale cash equivalents. We do not hold securities for purposes of trading. Marketable securities for which we have the intent and ability to hold to maturity are classified as “Held-to-maturity” and are carried at their amortized cost, including accrued interest. We had no Held-to-maturity securities at March 31, 2013 and December 31, 2012.

- removed (2013-08-09):
[0000926326-13-000010:note_history:15]
Currency forward contracts. From time to time we enter into foreign currency forward contracts to protect our business from the risk that exchange rates may affect the eventual cash flows resulting from intercompany transactions between Omnicell and our foreign subsidiaries. These transactions primarily arise as a result of products manufactured in the U.S. and sold to foreign subsidiaries in U.S. dollars rather than the subsidiaries' functional currencies. These forward contracts are considered to be financial derivative instruments and are recorded at fair value in the balance sheet. Changes in fair values of these financial derivative instruments are either recognized in other comprehensive income (a component of stockholders' equity) or net income depending on whether the derivative has been designated and qualifies as a highly effective hedging instrument. At March 31, 2013 and December 31, 2012, we had no foreign currency forward contracts which qualify for hedge accounting.

- removed (2013-08-09):
[0000926326-13-000010:note_history:16]
Segment information. Prior to the acquisition of MTS, we managed our business on the basis of a single operating segment, and a single reporting unit within that segment per ASC 280, Segment Reporting. Beginning with the acquisition of MTS, which we completed in May 2012, we have organized our business into two operating business segments: Acute Care, which primarily includes products and services sold to hospital customers, and Non-Acute Care, which primarily includes products and services sold to customers outside of the hospital setting.

- removed (2013-08-09):
[0000926326-13-000010:note_history:17]
The Acute Care segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems. The Non-Acute Care segment includes primarily the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services, but also includes medication dispensing systems sold to non-acute care pharmacies and facilities. We report segment information based on the management approach. The management approach designates the internal reporting used by the Chief Operating Decision Maker (the "CODM") for making decisions and assessing performance as the source of our operating segments. The CODM is our Chief Executive Officer. The CODM allocates resources to and assesses the performance of each operating segment, using information about its revenues, gross profit and income (loss) from operations.

- removed (2013-08-09):
[0000926326-13-000010:note_history:18]
Revenue recognition. We earn revenues from sales of our medication control systems together with related consumables and services, and medical/surgical supply control systems with related services, which are sold in our principal market, which is the healthcare industry. Revenues related to consumable products are reported net of discounts provided to our customers. Our customer arrangements typically include one or more of the following deliverables:

- removed (2013-08-09):
[0000926326-13-000010:note_history:19]
| • | Products—Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies. |

- removed (2013-08-09):
[0000926326-13-000010:note_history:20]
| • | Software—Additional software applications that enable incremental functionality of our equipment. |

- removed (2013-08-09):
[0000926326-13-000010:note_history:21]
| • | Installation—Installation of equipment as integrated systems at customers' sites. |

- removed (2013-08-09):
[0000926326-13-000010:note_history:22]
| • | Post-installation technical support—Phone support, on-site service, parts and access to unspecified software upgrades and enhancements, if and when available. |

- removed (2013-08-09):
[0000926326-13-000010:note_history:23]
| • | Professional services—Other customer services such as training and consulting. |

- removed (2013-08-09):
[0000926326-13-000010:note_history:24]
We recognize revenue when the earnings process is complete, based upon our evaluation of whether the following four criteria have been met:

- removed (2013-08-09):
[0000926326-13-000010:note_history:25]
| • | Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement. |

- removed (2013-08-09):
[0000926326-13-000010:note_history:26]
| • | Delivery has occurred. Equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter, providing evidence that we have delivered what a customer ordered. In instances of a customer self-installed installation, product delivery is deemed to have occurred upon receipt of a signed and dated customer confirmation letter. If a sale does not require installation, we recognize revenue on delivery of products to the customer, including transfer of title and risk of loss, assuming all other revenue criteria are met. We recognize revenue from sales of products to distributors upon delivery, when no contractual obligations for installation exists, assuming all other revenue criteria are met since we do not allow for rights of return or refund. For sales to distributors where we assume contractual installation obligations or new distributors whom we have not fully trained to install our products, the equipment and software product delivery is deemed to occur upon successful installation and receipt of a signed and dated customer confirmation of installation letter. For the sale of consumable blister cards, we recognize revenue when title and risk of loss of the products shipped have transferred to the customer, which usually occurs upon shipment from our facilities. Assuming all other revenue criteria are met, we recognize revenue for support services ratably over the related support services contract period, and we recognize revenue on training and professional services as those services are performed. |

- removed (2013-08-09):
[0000926326-13-000010:note_history:27]
| • | Fee is fixed or determinable. We assess whether a fee is fixed or determinable at the outset of the arrangement based on the payment terms associated with the transaction. We have established a history of collecting under the original contract without providing concessions on payments, products or services. |

- removed (2013-08-09):
[0000926326-13-000010:note_history:28]
| • | Collection is probable. We assess the probability of collecting from each customer at the outset of the arrangement based on a number of factors, including the customer's payment history and its current creditworthiness. If, in our judgment, collection of a fee is not probable, we defer the revenue until the uncertainty is removed, which generally means revenue is recognized upon our receipt of cash payment assuming all other revenue criteria are met. Our historical experience has been that collection from our customers is generally probable. |

- removed (2013-08-09):
[0000926326-13-000010:note_history:29]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. Effective for new or modified arrangements entered into beginning on January 1, 2011, the date we adopted the revised revenue recognition guidance for arrangements with multiple deliverables on a prospective basis, we allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support services and professional services. When VSOE of fair value is not available, third-party evidence ("TPE") of fair value for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE, TPE and BESP information and obtain formal approval by appropriate levels of management.

- removed (2013-08-09):
[0000926326-13-000010:note_history:30]
The relative selling price method allocates total arrangement consideration proportionally to each deliverable on the basis of its estimated selling price. In addition, the amount recognized for any delivered items cannot exceed that which is not contingent upon delivery of any remaining items in the arrangement.

- removed (2013-08-09):
[0000926326-13-000010:note_history:31]
We also use the residual method of allocating the arrangement consideration in certain circumstances. We use the residual method to allocate total arrangement consideration between delivered and undelivered items for any arrangements entered into prior to January 1, 2011 and not subsequently materially-modified. The use of the residual method is required by software revenue recognition rules that applied to sales of most of our products and services until the adoption of the new revenue recognition guidance. We also use the residual method to allocate revenue between the software products that enable incremental equipment functionality and thus are not deemed to deliver its essential functionality, and the related post-installation technical support, as these products and services continue to be accounted for under software revenue recognition rules. Under the residual method, the amount allocated to the undelivered elements equals VSOE of fair value of these elements. Any remaining amounts are attributed to the delivered items and are recognized when those items are delivered.

- removed (2013-08-09):
[0000926326-13-000010:note_history:32]
A portion of our sales are made through multi-year lease agreements. Under sales-type leases, we recognize revenue for our hardware and software products net of lease execution costs such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once our installation obligations have been met. We optimize cash flows by selling a majority of our non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. We have no obligation to the leasing company once the lease has been sold. Some of our sales-type leases, mostly those relating to U.S. government hospitals, are retained in-house. Interest income in these leases is recognized in product revenue using the effective interest method.

- removed (2013-08-09):
[0000926326-13-000010:note_history:33]
Accounts receivable and notes receivable (net investment in sales type leases). We actively manage our accounts receivable to minimize credit risk. We typically sell to customers for which there is a history of successful collection. New customers are subject to a credit review process, which evaluates that customer's financial position and ability to pay. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for doubtful accounts when we become aware of a specific customer's impaired ability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position. Uncollectible amounts are charged off against trade receivables and the allowance for doubtful accounts when we make a final determination that there is no reasonable expectation of recovery. Estimates are used in determining our allowances for all other customers based on factors such as current trends, the length of time the receivables are past due and historical collection experience. While we believe that our allowance for doubtful accounts receivable is adequate and that the judgment applied is appropriate, such estimated amounts could differ materially from what will actually be uncollectible in the future.

- removed (2013-08-09):
[0000926326-13-000010:note_history:34]
The retained in-house leases discussed above are considered financing receivables. Our credit policies and evaluation of credit risk and write-off policies are applied alike to trade receivables and the net-investment in sales-type leases. For both, an account is generally past due after thirty days. The financing receivables also have customer-specific reserves for accounts identified for specific impairment and a non-specific reserve applied to the remaining population, based on factors such as current trends, the length of time the receivables are past due and historical collection experience. The retained in-house leases are not stratified by portfolio or class. Financing receivables which are reserved are generally transferred to cash-basis accounting so that revenue is recognized only as cash is received. However, the cash basis accounts continue to accrue interest.

- removed (2013-08-09):
[0000926326-13-000010:note_history:35]
Sales of accounts receivable. We record the sale of our accounts receivables as “true sales” in accordance with accounting guidance for transfers and servicing of financial assets. During the three months ended March 31, 2013 and 2012, we transferred non-recourse accounts receivable totaling $10.2 million and $12.1 million, respectively, which approximated fair value, to third-party leasing companies. At March 31, 2013 and December 31, 2012, accounts receivable included $0.7 million and $0.7 million, respectively, due from third-party leasing companies for transferred non-recourse accounts receivable.

- removed (2013-08-09):
[0000926326-13-000010:note_history:36]
Concentration in revenues and in accounts receivable. There was no single customer accounting for 10% or more of revenues in the three months ended March 31, 2013 or 2012. At March 31, 2013, one customer accounted for 12.9% of our total gross accounts receivable, and there was no single customer accounting for 10% or more of accounts receivable at December 31, 2012. At March 31, 2013, we believe that we have no significant concentration of credit risk.

- removed (2013-08-09):
[0000926326-13-000010:note_history:37]
Accounting policy for shipping costs. Outbound freight billed to customers is recorded as product revenue. The related shipping and handling cost is expensed as part of selling, general and administrative expense. Such shipping and handling expenses totaled $1.4 million and $0.7 million for the three months ended March 31, 2013 and 2012, respectively.

- removed (2013-08-09):
[0000926326-13-000010:note_history:38]
Dependence on suppliers. We have a supply agreement with one primary supplier for construction and supply of several sub-assemblies and inventory management of sub-assemblies used in our hardware products. There are no minimum purchase requirements. The contract may be terminated by either the supplier or by us without cause and at any time upon delivery of two months’ notice. Purchases from this supplier for the three months ended March 31, 2013 and 2012 totaled approximately $7.2 million and $6.2 million, respectively.

- removed (2013-08-09):
[0000926326-13-000010:note_history:39]
Income taxes. We record an income tax provision for the anticipated tax consequences of the reported results of operations. In accordance with GAAP, the provision for income taxes is computed using the liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carry forwards. Deferred tax assets and liabilities are measured using the enacted tax rates expected to apply in the periods in which those tax assets and liabilities are expected to be realized. In the event that we determine all or part of the net deferred tax assets are not realizable in the future, we will record a valuation allowance that would be charged to earnings in the period such determination is made.

- removed (2013-08-09):
[0000926326-13-000010:note_history:40]
In accordance with ASC 740, Tax Provisions, we recognize the tax benefit from an uncertain tax position if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, based on the technical merits of the position. The tax benefits recognized in the financial statements from such positions are then measured based on the largest benefit that has a greater than 50% likelihood of being realized upon ultimate settlement. The calculation of tax liabilities involves significant judgment in estimating the impact of uncertainties in the application of GAAP and complex tax laws. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.

- removed (2013-08-09):
[0000926326-13-000010:note_history:41]
We provide for income taxes for each interim period based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rates before discrete items were 37.4% and 39.6% for the three months ended March 31, 2013 and 2012, respectively. The 2013 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the federal research and development credit claimed and the  domestic production activities deduction. The income tax provision for the three months ended March 31, 2013 also reflected a discrete net benefit of $0.7 million, or 18.0% of pre-tax income, related to 2012 federal research and development (“R&D”) credit which was retroactively reinstated in the three months ended March 31, 2013. No federal R&D credit benefit was recorded in the income tax provision for the three months ended March 31, 2012.

- removed (2013-08-09):
[0000926326-13-000010:note_history:42]
The 2012 annual effective tax rate differed from the statutory rate of 35%, primarily due to the unfavorable impact of state income taxes, non-deductible equity charges, and other non-deductible expenditures, which were partially offset by the domestic production activities deduction.

- removed (2013-08-09):
[0000926326-13-000010:note_history:43]
Recently Adopted Accounting Standards

- removed (2013-08-09):
[0000926326-13-000010:note_history:44]
In February 2013, the Financial Accounting Standards Board (“FASB”) issued 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income (AOCI), which aims to improve the reporting of reclassifications out of AOCI. This update requires an entity to report the effect of significant reclassifications out of AOCI on the respective line items in net income if the amount being reclassified is required under GAAP to be reclassified in its entirety to net income. For other amounts that are not required under GAAP to be reclassified in their entirety to net income in the same reporting period, an entity is required to cross-reference other disclosures required under GAAP that provide additional detail about those amounts. The amendments do not change the current requirements for reporting net income or other comprehensive income in financial statements. For public entities, the amendments are effective prospectively for reporting periods beginning after December 15, 2012. We adopted this guidance in the first quarter of 2013. This update did not have any significant impact on our financial position, operating results or cash flows.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2013-08-09):
[0000926326-13-000013:note_history:45]
| • | Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for equipment leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement. |
  (was, 2013-05-09, similarity 0.9828):
[0000926326-13-000010:note_history:45]
| • | Persuasive evidence of an arrangement exists. We use signed customer contracts and signed customer purchase orders as evidence of an arrangement for leases and sales. For service engagements, we use a signed services agreement and a statement of work to evidence an arrangement. |

- changed (2013-08-09):
[0000926326-13-000013:note_history:46]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. We allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support services and professional services. When VSOE of fair value is not available, third-party evidence ("TPE") of fair value for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE, TPE and BESP information and obtain formal approval by appropriate levels of management.
  (was, 2013-05-09, similarity 0.9435):
[0000926326-13-000010:note_history:46]
In arrangements with multiple deliverables, assuming all other revenue criteria are met, we recognize revenue for individual delivered items if they have value to the customer on a standalone basis. Effective for new or modified arrangements entered into beginning on January 1, 2011, the date we adopted the revised revenue recognition guidance for arrangements with multiple deliverables on a prospective basis, we allocate arrangement consideration at the inception of the arrangement to all deliverables using the relative selling price method. This method requires us to determine the selling price at which each deliverable could be sold if it were sold regularly on a standalone basis. When available, we use vendor-specific objective evidence ("VSOE") of fair value as the selling price. VSOE represents the price charged for a deliverable when it is sold separately or for a deliverable not yet being sold separately, the price established by management with the relevant authority. We consider VSOE to exist when approximately 80% or more of our standalone sales of an item are priced within a reasonably narrow pricing range (plus or minus 15% of the median rates). We have established VSOE of fair value for our post-installation technical support services and professional services. When VSOE of fair value is not available, third-party evidence ("TPE") of fair value for similar products and services is acceptable; however, our offerings and market strategy differ from those of our competitors, such that we cannot obtain sufficient comparable information about third parties' prices. If neither VSOE nor TPE are available, we use our best estimates of selling prices ("BESP"). We determine BESP considering factors such as market conditions, sales channels, internal costs and product margin objectives and pricing practices. We regularly review and update our VSOE, TPE and BESP information and obtain formal approval by appropriate levels of management.
