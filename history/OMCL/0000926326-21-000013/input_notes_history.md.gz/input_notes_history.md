# OMCL note change history — 0000926326-20-000034 → 0000926326-21-000013


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2021-05-04):
[0000926326-21-000013:note_history:1]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceedings described above based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to these legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of any of these legal proceedings or because of the diversion of management’s attention and the creation of significant expenses.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0000926326-21-000013:note_history:2]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2021, the Company had non-cancelable purchase commitments of $82.8 million, of which $78.8 million are expected to be paid within the year ending December 31, 2021.
  (was, 2020-10-30, similarity 0.9747):
[0000926326-20-000034:note_history:2]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2020, the Company had non-cancelable purchase commitments of $66.4 million, of which $49.3 million are expected to be paid within the year ending December 31, 2020.

- added (2021-05-04):
[0000926326-21-000013:note_history:3]
The Company is currently involved in various legal proceedings.

- added (2021-05-04):
[0000926326-21-000013:note_history:4]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020. The Company's motion to dismiss is now fully briefed and the Court has scheduled oral argument on the motion for June 4, 2021. The Company intends to defend the lawsuit vigorously.

- added (2021-05-04):
[0000926326-21-000013:note_history:5]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “Omnicell Complaint”). This action (the “Omnicell Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The Omnicell Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees

- added (2021-05-04):
[0000926326-21-000013:note_history:6]
and costs, and pre-judgment and post-judgment interest. On March 17, 2021, the parties filed a joint motion to stay the Omnicell Action, which motion remains pending with the Court. On April 30, 2021, pending the decision from the Court regarding the joint motion to stay the Omnicell Action, the Company filed a consent motion for extension of time supported by BD to file the Company’s answer to the Omnicell Complaint. The consent motion was granted by the Court on April 30, 2021, and the Company’s answer to the Omnicell Complaint is now due June 3, 2021. The Company intends to defend the lawsuit vigorously.

- added (2021-05-04):
[0000926326-21-000013:note_history:7]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceedings described above based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to these legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of any of these legal proceedings or because of the diversion of management’s attention and the creation of significant expenses.

- removed (2021-05-04):
[0000926326-20-000034:note_history:8]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management’s attention and the creation of significant expenses.

- removed (2021-05-04):
[0000926326-20-000034:note_history:9]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies, and corporate entities, including the Company and one of its former subsidiaries, Aesynt Incorporated (“Aesynt”), which, through a series of mergers, has been merged into the Company, in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al., Case No. CL18-152-1. The complaint sought monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies, and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, retention, and training; and, as against the Company and Aesynt, claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. Upon motion of the plaintiff, the Court issued an order on February 21, 2019 nonsuiting (dismissing) the case without prejudice. On August 21, 2019, a new lawsuit was filed against the Company and Aesynt, in the Circuit Court for the County of Albemarle, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Aesynt Incorporated, et al., Case No CL19-1301. The complaint sought monetary recovery of damages based upon claims of product liability, negligence, and breach of implied warranties. The Company and Aesynt were never served with the complaint. On August 25, 2020, the Company and Aesynt filed a motion to dismiss for failure of the plaintiff to serve the complaint within one year of its filing date. On September 30, 2020, the Court dismissed the complaint with prejudice.

- removed (2021-05-04):
[0000926326-20-000034:note_history:10]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817. The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the Company’s dismissal from the Mazya Action. The Company filed a motion to dismiss the complaint on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the complaint on October 28, 2020. A status conference is currently set for November 5, 2020. The Company intends to defend the lawsuit vigorously.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-05-04):
[0000926326-21-000013:note_history:11]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products and related services are medication management automation solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.

- changed (2021-05-04):
[0000926326-21-000013:note_history:12]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2021 and December 31, 2020, and the results of operations, comprehensive income, and cash flows for the three months ended March 31, 2021 and 2020. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 24, 2021, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations, comprehensive income, and cash flows for the three months ended March 31, 2021 are not necessarily indicative of results that may be expected for the year ending December 31, 2021, or for any future period.
  (was, 2020-10-30, similarity 0.8693):
[0000926326-20-000034:note_history:12]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2020 and December 31, 2019, the results of operations and comprehensive income for the three and nine months ended September 30, 2020 and 2019, and cash flows for the nine months ended September 30, 2020 and 2019. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2019 filed with the SEC on February 26, 2020, except as discussed in the sections entitled “Allowance for Credit Losses” and “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2020 and cash flows for the nine months ended September 30, 2020 are not necessarily indicative of results that may be expected for the year ending December 31, 2020, or for any future period.

- changed (2021-05-04):
[0000926326-21-000013:note_history:13]
The Condensed Consolidated Financial Statements include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.
  (was, 2020-10-30, similarity 0.995):
[0000926326-20-000034:note_history:13]
The Condensed Consolidated Financial Statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

- changed (2021-05-04):
[0000926326-21-000013:note_history:14]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of revenues for the three months ended March 31, 2020 in Note 3, Revenues. This change was not deemed material and was included to conform with current-period classification and presentation.
  (was, 2020-10-30, similarity 0.9259):
[0000926326-20-000034:note_history:14]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of product revenues for the three and nine months ended September 30, 2019 in Note 2, Revenues. This change was not deemed material and was included to conform with current-period classification and presentation.

- changed (2021-05-04):
[0000926326-21-000013:note_history:15]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.
  (was, 2020-10-30, similarity 0.9244):
[0000926326-20-000034:note_history:15]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable, including any potential impacts arising from the novel coronavirus (“COVID-19”) pandemic. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.

- added (2021-05-04):
[0000926326-21-000013:note_history:16]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of March 31, 2021, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

- added (2021-05-04):
[0000926326-21-000013:note_history:17]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The update simplifies the accounting for income taxes by removing certain exceptions to the general principles in Accounting Standards Codification (“ASC”) 740, Income Taxes, as well as improves consistent application of and simplifies the guidance for other areas of ASC 740 by clarifying and amending existing guidance. The Company adopted ASU 2019-12 on January 1, 2021 on a prospective basis. The adoption of this guidance did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

- changed (2021-05-04):
[0000926326-21-000013:note_history:18]
In August 2020, the FASB issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. This update permits the use of either the modified retrospective or fully retrospective method of transition. ASU 2020-06 will be effective for the Company beginning January 1, 2022. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. The Company is currently evaluating the impact ASU 2020-06 will have on its Condensed Consolidated Financial Statements.
  (was, 2020-10-30, similarity 0.6356):
[0000926326-20-000034:note_history:18]
In August 2020, the FASB issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves

- removed (2021-05-04):
[0000926326-20-000034:note_history:19]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products are medication management automation solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.

- removed (2021-05-04):
[0000926326-20-000034:note_history:20]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective or complex judgments by management. As of September 30, 2020, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities. Given the ongoing uncertainty surrounding the COVID-19 pandemic, events or circumstances may arise that could result in a change in estimates, judgments, or revisions to the carrying value of the Company’s assets or liabilities.

- removed (2021-05-04):
[0000926326-20-000034:note_history:21]
Allowance for Credit Losses

- removed (2021-05-04):
[0000926326-20-000034:note_history:22]
The Company is exposed to credit losses primarily through sales of its products and services, as well as its sales-type leasing arrangements. The Company performs credit evaluations of its customers’ financial condition in order to assess each customer’s ability to pay. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, and a financial review of the customer. The Company continues to monitor customers’ creditworthiness on an ongoing basis.

- removed (2021-05-04):
[0000926326-20-000034:note_history:23]
The Company maintains an allowance for credit losses for accounts receivable, unbilled receivables, and net investment in sales-type leases based on expected credit losses resulting from the inability of its customers to make required payments. The allowance for credit losses is measured using a loss rate method, considering factors such as customers’ credit risk, historical loss experience, current conditions, and forecasts. The allowance for credit losses is measured on a collective (pool) basis by aggregating customer balances with similar risk characteristics. The Company also records a specific allowance based on an analysis of individual past due balances or customer-specific information, such as a decline in creditworthiness or bankruptcy. Actual collection losses may differ from management’s estimates, and such differences could be material to the Company’s financial position and results of operations.

- removed (2021-05-04):
[0000926326-20-000034:note_history:24]
The allowance for credit losses is presented in the Condensed Consolidated Balance Sheets as a deduction from the respective asset balance. The following table summarizes the Company’s allowance for credit losses by asset type:

- removed (2021-05-04):
[0000926326-20-000034:note_history:25]
|  | September 30,2020 |  | December 31,2019 |
|  | (In thousands) |
| Allowance for credit losses: |  |  |  |
| Accounts receivable and unbilled receivables | $ | 3,839 |  |  | $ | 3,227 |  |
| Long-term unbilled receivables (1) | 30 |  |  | — |  |
| Net investment in sales-type leases (2) | 269 |  |  | 225 |  |

- removed (2021-05-04):
[0000926326-20-000034:note_history:26]
_________________________________________________

- removed (2021-05-04):
[0000926326-20-000034:note_history:27]
(1)    Included in other long-term assets in the Condensed Consolidated Balance Sheets.

- removed (2021-05-04):
[0000926326-20-000034:note_history:28]
(2)    Includes both current and long-term portions presented in other current assets and long-term investment in sales-type leases, net, respectively.

- removed (2021-05-04):
[0000926326-20-000034:note_history:29]
Changes in the allowances were not significant for the three and nine months ended September 30, 2020 and 2019.

- removed (2021-05-04):
[0000926326-20-000034:note_history:30]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract, to align the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include an internal-use software license). The Company adopted ASU 2018-15 on January 1, 2020 on a prospective basis. The adoption of this guidance did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

- removed (2021-05-04):
[0000926326-20-000034:note_history:31]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326), Measurement of Credit Losses on Financial Instruments, that modifies or replaces existing models for trade and other receivables, debt securities, loans, and certain other financial instruments. For instruments measured at amortized cost, including trade and lease receivables, loans, and held-to-maturity debt securities, the standard replaced the current “incurred loss” approach with an “expected loss” model. Entities are required to estimate expected credit losses over the life of the instrument, considering available relevant information about the collectibility of cash flows, including information about past events, current conditions, and reasonable and supportable forecasts. The Company adopted the new standard on January 1, 2020 using the modified retrospective transition method, which resulted in the recognition of an immaterial cumulative-effect adjustment to retained earnings.

- removed (2021-05-04):
[0000926326-20-000034:note_history:32]
disclosures for convertible instruments and earnings per share guidance. This update permits the use of either the modified retrospective or fully retrospective method of transition. ASU 2020-06 will be effective for the Company beginning January 1, 2022. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. The Company is currently evaluating the impact ASU 2020-06 will have on its Condensed Consolidated Financial Statements.


## omcl:ScheduleOfDebtIssuanceCostsNetTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0000926326-21-000013:note_history:33]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (274) |  |
| Balance as of March 31, 2021 | $ | 3,979 |  |
  (was, 2020-10-30, similarity 0.9589):
[0000926326-20-000034:note_history:33]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | 550 |  |
| Amortization | (723) |  |
| Balance as of September 30, 2020 | $ | 4,527 |  |


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0000926326-21-000013:note_history:34]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2021:
  (was, 2020-10-30, similarity 0.8998):
[0000926326-20-000034:note_history:34]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2020:

- changed (2021-05-04):
[0000926326-21-000013:note_history:35]
|  | Three Months Ended |  |  |  |  |
|  | March 31, 2021 |  |  |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  |  |  |  |  |  |
| Amortization of discount | $ | 4,571 |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 575 |  |  |  |  |  |  |  |
  (was, 2020-10-30, similarity 0.823):
[0000926326-20-000034:note_history:35]
|  | Three and Nine Months EndedSeptember 30, 2020 |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 20 |  |  |  |  |  |  |  |
| Amortization of discount | $ | 249 |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 31 |  |  |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0000926326-21-000013:note_history:36]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2021 and December 31, 2020:
  (was, 2020-10-30, similarity 0.9249):
[0000926326-20-000034:note_history:36]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2020:

- added (2021-05-04):
[0000926326-21-000013:note_history:37]
|  | March 31,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (91,173) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (11,480) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 472,347 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |

- removed (2021-05-04):
[0000926326-20-000034:note_history:38]
|  | September 30,2020 |
|  | (In thousands) |
| Liability: |  |
| Principal amount | $ | 575,000 |  |
| Unamortized discount | (100,261) |  |
| Unamortized debt issuance costs | (12,624) |  |
| Convertible senior notes, liability component | $ | 462,115 |  |
| Equity: |  |
| Embedded conversion option | $ | 100,510 |  |
| Debt issuance costs | (2,680) |  |
| Deferred tax impact | (25,098) |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0000926326-21-000013:note_history:39]
Debt and Credit Agreement
2019 Revolving Credit Facility
  (was, 2020-10-30, similarity 0.8654):
[0000926326-20-000034:note_history:39]
Debt and Credit Agreements
2016 Senior Credit Facility

- added (2021-05-04):
[0000926326-21-000013:note_history:40]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility (the “Prior Credit Agreement”) and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit

- added (2021-05-04):
[0000926326-21-000013:note_history:41]
Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

- changed (2021-05-04):
[0000926326-21-000013:note_history:42]
Loans under the Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. The applicable margin for, and certain other terms of, any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.
  (was, 2020-10-30, similarity 0.7645):
[0000926326-20-000034:note_history:42]
(ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Current Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Current Revolving Credit Facility. The applicable margin for and certain other terms of any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

- changed (2021-05-04):
[0000926326-21-000013:note_history:43]
On September 22, 2020, the parties entered into an amendment (the “Amendment”) to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.
  (was, 2020-10-30, similarity 0.9986):
[0000926326-20-000034:note_history:43]
On September 22, 2020, the parties entered into an amendment (the “Amendment”) to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions as described in Note 9, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020 and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

- changed (2021-05-04):
[0000926326-21-000013:note_history:44]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of March 31, 2021.
  (was, 2020-10-30, similarity 0.9905):
[0000926326-20-000034:note_history:44]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of September 30, 2020.

- changed (2021-05-04):
[0000926326-21-000013:note_history:45]
The refinancing of the Prior Credit Agreement by means of the A&R Credit Agreement was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the A&R Credit Agreement.
  (was, 2020-10-30, similarity 0.9573):
[0000926326-20-000034:note_history:45]
The refinancing of the Prior Credit Agreement was evaluated in accordance with Accounting Standards Codification (“ASC”) 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the A&R Credit Agreement.

- added (2021-05-04):
[0000926326-21-000013:note_history:46]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. In connection with the Amendment on September 22, 2020, the Company incurred and capitalized an additional $0.6 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs for credit agreements was approximately $0.3 million and $0.2 million for the three months ended March 31, 2021 and 2020, respectively.

- changed (2021-05-04):
[0000926326-21-000013:note_history:47]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (274) |  |
| Balance as of March 31, 2021 | $ | 3,979 |  |
  (was, 2020-10-30, similarity 0.9589):
[0000926326-20-000034:note_history:47]
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 4,700 |  |
| Additions | 550 |  |
| Amortization | (723) |  |
| Balance as of September 30, 2020 | $ | 4,527 |  |

- added (2021-05-04):
[0000926326-21-000013:note_history:48]
As of each of March 31, 2021 and December 31, 2020, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- changed (2021-05-04):
[0000926326-21-000013:note_history:49]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.
  (was, 2020-10-30, similarity 0.9985):
[0000926326-20-000034:note_history:49]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ending on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

- added (2021-05-04):
[0000926326-21-000013:note_history:50]
During the three months ended March 31, 2021, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on March 31, 2021, the last trading day of the fiscal quarter. Accordingly, the Notes are convertible, in whole or in part, at the option of the holders during the second quarter of 2021. Whether the Notes will be convertible following the second fiscal quarter of 2021 will depend on the continued satisfaction of this condition or another conversion condition in the future. The Company continues to classify the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of March 31, 2021 based on contractual settlement provisions.

- changed (2021-05-04):
[0000926326-21-000013:note_history:51]
amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2021, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2020-10-30, similarity 0.9708):
[0000926326-20-000034:note_history:51]
amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2020, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- changed (2021-05-04):
[0000926326-21-000013:note_history:52]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represents the debt discount, which the Company will amortize to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions. As of March 31, 2021, the remaining life of the Notes and the related debt discount and issuance cost accretion is approximately 4.5 years.
  (was, 2020-10-30, similarity 0.992):
[0000926326-20-000034:note_history:52]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. Accordingly, at issuance the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represents the debt discount, which the Company will amortize to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions. As of September 30, 2020, the remaining life of the Notes and the related debt discount and issuance cost accretion is approximately 5.0 years.

- changed (2021-05-04):
[0000926326-21-000013:note_history:53]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 8.1 million shares. As of March 31, 2021, the if-converted value of the Notes exceeded the principal amount by $192.3 million.
  (was, 2020-10-30, similarity 0.784):
[0000926326-20-000034:note_history:53]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 8.1 million shares.

- changed (2021-05-04):
[0000926326-21-000013:note_history:54]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2021 and December 31, 2020:
  (was, 2020-10-30, similarity 0.9249):
[0000926326-20-000034:note_history:54]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2020:

- added (2021-05-04):
[0000926326-21-000013:note_history:55]
|  | March 31,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (91,173) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (11,480) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 472,347 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |

- changed (2021-05-04):
[0000926326-21-000013:note_history:56]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2021:
  (was, 2020-10-30, similarity 0.8998):
[0000926326-20-000034:note_history:56]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2020:

- changed (2021-05-04):
[0000926326-21-000013:note_history:57]
|  | Three Months Ended |  |  |  |  |
|  | March 31, 2021 |  |  |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  |  |  |  |  |  |
| Amortization of discount | $ | 4,571 |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 575 |  |  |  |  |  |  |  |
  (was, 2020-10-30, similarity 0.823):
[0000926326-20-000034:note_history:57]
|  | Three and Nine Months EndedSeptember 30, 2020 |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 20 |  |  |  |  |  |  |  |
| Amortization of discount | $ | 249 |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 31 |  |  |  |  |  |  |  |

- changed (2021-05-04):
[0000926326-21-000013:note_history:58]
In connection with the issuance of the Notes, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.
  (was, 2020-10-30, similarity 0.9104):
[0000926326-20-000034:note_history:58]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.
Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid in capital in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.

- removed (2021-05-04):
[0000926326-20-000034:note_history:59]
On January 5, 2016, the Company entered into a $400.0 million senior secured credit facility pursuant to a credit agreement with certain lenders, Wells Fargo Securities, LLC as sole lead arranger, and Wells Fargo Bank, National Association as administrative agent (as subsequently amended as discussed below, the “Prior Credit Agreement”). The Prior Credit Agreement provided for (a) a five-year revolving credit facility of $200.0 million, which was subsequently increased pursuant to the amendment discussed below (the “Prior Revolving Credit Facility”) and (b) a five-year $200.0 million term loan facility (the “Prior Term Loan Facility” and together with the Prior Revolving Credit Facility, the “Prior Facilities”). In addition, the Prior Credit Agreement included a letter of credit sub-limit of up to $10.0 million and a swing line loan sub-limit of up to $10.0 million. The Prior Credit Agreement had an expiration date of January 5, 2021, upon which date all remaining outstanding borrowings were due and payable.

- removed (2021-05-04):
[0000926326-20-000034:note_history:60]
Loans under the Prior Facilities bore interest, at the Company’s option, at a rate equal to either (a) LIBOR, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Prior Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the Prior Credit Agreement). Undrawn commitments under the Prior Revolving Credit Facility were subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Prior Revolving Credit Facility.

- removed (2021-05-04):
[0000926326-20-000034:note_history:61]
On each of April 11, 2017 and December 26, 2017, the parties entered into amendments to the Prior Credit Agreement. Under these amendments, the Prior Revolving Credit Facility was increased from $200.0 million to $315.0 million, and certain other modifications were made. In connection with the December 2017 amendment, the Company incurred and capitalized an additional $2.1 million of debt issuance costs.

- removed (2021-05-04):
[0000926326-20-000034:note_history:62]
2019 Revolving Credit Facility

- removed (2021-05-04):
[0000926326-20-000034:note_history:63]
On November 15, 2019, the Company refinanced the Prior Credit Agreement and entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement replaced the Prior Credit Agreement and provides for (a) a five-year revolving credit facility of $500.0 million (the “Current Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

- removed (2021-05-04):
[0000926326-20-000034:note_history:64]
On November 15, 2019, the $80.0 million outstanding term loan balance under the Prior Facilities was transferred to the Current Revolving Credit Facility.

- removed (2021-05-04):
[0000926326-20-000034:note_history:65]
Loans under the Current Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) LIBOR, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate,

- removed (2021-05-04):
[0000926326-20-000034:note_history:66]
In connection with the A&R Credit Agreement on November 15, 2019, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. In connection with the Amendment on September 22, 2020, the Company incurred and capitalized an additional $0.6 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs for credit agreements was approximately $0.2 million and $0.6 million for the three months ended September 30, 2020 and 2019, respectively, and approximately $0.7 million and $1.7 million for the nine months ended September 30, 2020 and 2019, respectively.

- removed (2021-05-04):
[0000926326-20-000034:note_history:67]
Interest expense (exclusive of fees and debt issuance cost amortization) was approximately $0.3 million and $0.8 million for the three months ended September 30, 2020 and 2019, and approximately $0.5 million and $3.0 million for the nine months ended September 30, 2020 and 2019, respectively.

- removed (2021-05-04):
[0000926326-20-000034:note_history:68]
The following table represents changes in the carrying amount of the Company’s debt obligations:

- removed (2021-05-04):
[0000926326-20-000034:note_history:69]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | 150,000 |  |
| Repayments | (200,000) |  |
| Balance as of September 30, 2020 | $ | — |  |

- removed (2021-05-04):
[0000926326-20-000034:note_history:70]
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- removed (2021-05-04):
[0000926326-20-000034:note_history:71]
|  | September 30,2020 |
|  | (In thousands) |
| Liability: |  |
| Principal amount | $ | 575,000 |  |
| Unamortized discount | (100,261) |  |
| Unamortized debt issuance costs | (12,624) |  |
| Convertible senior notes, liability component | $ | 462,115 |  |
| Equity: |  |
| Embedded conversion option | $ | 100,510 |  |
| Debt issuance costs | (2,680) |  |
| Deferred tax impact | (25,098) |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |

- removed (2021-05-04):
[0000926326-20-000034:note_history:72]
In connection with the issuance of the Notes, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2021-05-04):
[0000926326-20-000034:note_history:73]
The following table represents changes in the carrying amount of the Company’s debt obligations:

- removed (2021-05-04):
[0000926326-20-000034:note_history:74]
|  | Current Revolving Credit Facility |
|  | (In thousands) |
| Balance as of December 31, 2019 | $ | 50,000 |  |
| Proceeds | 150,000 |  |
| Repayments | (200,000) |  |
| Balance as of September 30, 2020 | $ | — |  |


## omcl:RevenueFromContractWithCustomerTimingAndClassificationOfRevenueCategoriesTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2021-05-04):
[0000926326-21-000013:note_history:75]
The following table summarizes revenue recognition for each revenue category:

- added (2021-05-04):
[0000926326-21-000013:note_history:76]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| SaaS, subscription software, and technology-enabled services |  |  |  | Over time, as services are provided |  | Service |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0000926326-21-000013:note_history:77]
The Company earns revenues from sales of its products and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following revenue categories:
  (was, 2020-10-30, similarity 0.9246):
[0000926326-20-000034:note_history:77]
The Company earns revenues from sales of its products and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following performance obligations:

- added (2021-05-04):
[0000926326-21-000013:note_history:78]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements with multi-year co-development plans. Solutions in this category include, but are not limited to, XT Series automated dispensing systems, the XR2 Automated Central Pharmacy system, and IV compounding automation solutions.

- changed (2021-05-04):
[0000926326-21-000013:note_history:79]
Technical services. Post-installation technical support and other related services, including phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.
  (was, 2020-10-30, similarity 0.681):
[0000926326-20-000034:note_history:79]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.

- added (2021-05-04):
[0000926326-21-000013:note_history:80]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, and are designed to improve patient engagement and adherence to prescriptions.

- added (2021-05-04):
[0000926326-21-000013:note_history:81]
Software-as-a-service (“SaaS”), subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth™ (formerly Population Health Solutions), 340B solutions, and services associated with Omnicell One™ (formerly Performance Center), Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy system, and Central Pharmacy Compounding Services, including IV compounding automation solutions.

- removed (2021-05-04):
[0000926326-20-000034:note_history:82]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

- removed (2021-05-04):
[0000926326-20-000034:note_history:83]
Software. On premise or cloud-based subscription solutions that improve medication management and adherence outcomes or enable incremental functionality of the Company’s equipment.

- removed (2021-05-04):
[0000926326-20-000034:note_history:84]
Installation. Installation of equipment as integrated systems at customer sites.

- removed (2021-05-04):
[0000926326-20-000034:note_history:85]
Professional services. Other customer services, such as technology-enabled services, training, and consulting.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0000926326-21-000013:note_history:86]
The Company earns revenues from sales of its products and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following revenue categories:
  (was, 2020-10-30, similarity 0.9246):
[0000926326-20-000034:note_history:86]
The Company earns revenues from sales of its products and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following performance obligations:

- added (2021-05-04):
[0000926326-21-000013:note_history:87]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements with multi-year co-development plans. Solutions in this category include, but are not limited to, XT Series automated dispensing systems, the XR2 Automated Central Pharmacy system, and IV compounding automation solutions.

- changed (2021-05-04):
[0000926326-21-000013:note_history:88]
Technical services. Post-installation technical support and other related services, including phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.
  (was, 2020-10-30, similarity 0.681):
[0000926326-20-000034:note_history:88]
Post-installation technical support. Phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available.

- added (2021-05-04):
[0000926326-21-000013:note_history:89]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, and are designed to improve patient engagement and adherence to prescriptions.

- added (2021-05-04):
[0000926326-21-000013:note_history:90]
Software-as-a-service (“SaaS”), subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth™ (formerly Population Health Solutions), 340B solutions, and services associated with Omnicell One™ (formerly Performance Center), Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy system, and Central Pharmacy Compounding Services, including IV compounding automation solutions.

- added (2021-05-04):
[0000926326-21-000013:note_history:91]
The following table summarizes revenue recognition for each revenue category:

- added (2021-05-04):
[0000926326-21-000013:note_history:92]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| SaaS, subscription software, and technology-enabled services |  |  |  | Over time, as services are provided |  | Service |

- added (2021-05-04):
[0000926326-21-000013:note_history:93]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule contract with the Department of Veterans Affairs (the "GSA Contract"). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee ("IFF") to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $3.4 million and $2.9 million for the three months ended March 31, 2021 and 2020, respectively.

- changed (2021-05-04):
[0000926326-21-000013:note_history:94]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three months ended March 31, 2021 and 2020:
  (was, 2020-10-30, similarity 0.9018):
[0000926326-20-000034:note_history:94]
The following table summarizes the Company’s product revenues disaggregated by revenue type for the three and nine months ended September 30, 2020 and 2019:

- added (2021-05-04):
[0000926326-21-000013:note_history:95]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 159,718 |  |  | $ | 147,347 |  |  |  |  |  |
| Technical services | 50,860 |  |  | 49,519 |  |  |  |  |  |
| Consumables | 18,407 |  |  | 22,726 |  |  |  |  |  |
| SaaS, subscription software, and technology-enabled services | 22,858 |  |  | 10,094 |  |  |  |  |  |
| Total revenues | $ | 251,843 |  |  | $ | 229,686 |  |  |  |  |  |

- changed (2021-05-04):
[0000926326-21-000013:note_history:96]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2021 and 2020:
  (was, 2020-10-30, similarity 0.9493):
[0000926326-20-000034:note_history:96]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2020 and 2019:

- changed (2021-05-04):
[0000926326-21-000013:note_history:97]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (In thousands) |
| United States | $ | 224,276 |  |  | $ | 207,734 |  |  |  |  |  |
| Rest of world (1) | 27,567 |  |  | 21,952 |  |  |  |  |  |
| Total revenues | $ | 251,843 |  |  | $ | 229,686 |  |  |  |  |  |
  (was, 2020-10-30, similarity 0.695):
[0000926326-20-000034:note_history:97]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |
| United States | $ | 193,639 |  |  | $ | 206,709 |  |  | $ | 579,425 |  |  | $ | 582,540 |  |
| Rest of world (1) | 20,060 |  |  | 22,096 |  |  | 63,581 |  |  | 66,195 |  |
| Total revenues | $ | 213,699 |  |  | $ | 228,805 |  |  | $ | 643,006 |  |  | $ | 648,735 |  |

- changed (2021-05-04):
[0000926326-21-000013:note_history:98]
|  | March 31,2021 |  | December 31,2020 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 12,184 |  |  | $ | 13,895 |  |
| Long-term unbilled receivables, net (2) | 14,856 |  |  | 17,205 |  |
| Total contract assets | $ | 27,040 |  |  | $ | 31,100 |  |
| Short-term deferred revenues, net | $ | 119,588 |  |  | $ | 100,053 |  |
| Long-term deferred revenues | 7,887 |  |  | 5,673 |  |
| Total contract liabilities | $ | 127,475 |  |  | $ | 105,726 |  |
  (was, 2020-10-30, similarity 0.9817):
[0000926326-20-000034:note_history:98]
|  | September 30,2020 |  | December 31,2019 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 8,344 |  |  | $ | 11,707 |  |
| Long-term unbilled receivables, net (2) | 15,379 |  |  | 12,260 |  |
| Total contract assets | $ | 23,723 |  |  | $ | 23,967 |  |
| Short-term deferred revenues, net | $ | 101,641 |  |  | $ | 90,894 |  |
| Long-term deferred revenues | 5,163 |  |  | 7,083 |  |
| Total contract liabilities | $ | 106,804 |  |  | $ | 97,977 |  |

- changed (2021-05-04):
[0000926326-21-000013:note_history:99]
Short-term deferred revenues of $119.6 million and $100.1 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $20.8 million and $21.0 million, as of March 31, 2021 and December 31, 2020, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three months ended March 31, 2021, the Company recognized revenues of $47.3 million that were included in the corresponding gross short-term deferred revenues balance of $121.1 million as of December 31, 2020.
  (was, 2020-10-30, similarity 0.9272):
[0000926326-20-000034:note_history:99]
Short-term deferred revenues of $101.6 million and $90.9 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $24.2 million and $13.1 million, as of September 30, 2020 and December 31, 2019, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and nine months ended September 30, 2020, the Company recognized revenues of $13.2 million and $77.5 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $104.0 million as of December 31, 2019.

- added (2021-05-04):
[0000926326-21-000013:note_history:100]
Long-term deferred revenues include deferred revenues from product and service contracts of $7.9 million and $5.7 million as of March 31, 2021 and December 31, 2020, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.

- changed (2021-05-04):
[0000926326-21-000013:note_history:101]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2021 and 2020. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2021 and December 31, 2020.
  (was, 2020-10-30, similarity 0.8115):
[0000926326-20-000034:note_history:101]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2020 and 2019. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of September 30, 2020 and December 31, 2019.

- removed (2021-05-04):
[0000926326-20-000034:note_history:102]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

- removed (2021-05-04):
[0000926326-20-000034:note_history:103]
Software. On premise or cloud-based subscription solutions that improve medication management and adherence outcomes or enable incremental functionality of the Company’s equipment.

- removed (2021-05-04):
[0000926326-20-000034:note_history:104]
Installation. Installation of equipment as integrated systems at customer sites.

- removed (2021-05-04):
[0000926326-20-000034:note_history:105]
Professional services. Other customer services, such as technology-enabled services, training, and consulting.

- removed (2021-05-04):
[0000926326-20-000034:note_history:106]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $2.3 million and $2.8 million for the three months ended September 30, 2020 and 2019, respectively, and $6.9 million and $7.6 million for the nine months ended September 30, 2020 and 2019, respectively.

- removed (2021-05-04):
[0000926326-20-000034:note_history:107]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  | (In thousands) |
| Hardware and software | $ | 130,046 |  |  | $ | 142,424 |  |  | $ | 389,398 |  |  | $ | 394,243 |  |
| Consumables | 16,840 |  |  | 22,204 |  |  | 58,173 |  |  | 67,706 |  |
| Other | 4,451 |  |  | 3,860 |  |  | 12,781 |  |  | 10,528 |  |
| Total product revenues | $ | 151,337 |  |  | $ | 168,488 |  |  | $ | 460,352 |  |  | $ | 472,477 |  |

- removed (2021-05-04):
[0000926326-20-000034:note_history:108]
Long-term deferred revenues include deferred revenues from service contracts of $5.2 million and $7.1 million as of September 30, 2020 and December 31, 2019, respectively. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-05-04):
[0000926326-20-000034:note_history:109]
Subsequent Events On October 1, 2020, the Company completed the acquisition of the 340B Link Business of Pharmaceutical Strategies Group, LLC pursuant to the terms and conditions of the Equity Purchase Agreement, dated August 11, 2020, as amended, by and among the Company, PSGH, LLC, BW Apothecary Holdings, LLC, the sellers identified therein and the sellers’ representative (the “Purchase Agreement”). The purchase price was $225.0 million, subject to certain adjustments as provided for in the Purchase Agreement. The acquisition was funded with proceeds from the issuance of the Notes. Refer to Note 9, Convertible Senior Notes, for further information regarding the issuance of the Notes. The Company is in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation.
