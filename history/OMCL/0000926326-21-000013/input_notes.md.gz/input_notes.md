# OMCL notes — 0000926326-21-000013


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-21-000013:notes:1]
[same as prior period, unchanged from 0000926326-20-000034:notes:1]

[0000926326-21-000013:notes:2]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products and related services are medication management automation solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.

[0000926326-21-000013:notes:3]
[same as prior period, unchanged from 0000926326-20-000034:notes:3]

[0000926326-21-000013:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2021 and December 31, 2020, and the results of operations, comprehensive income, and cash flows for the three months ended March 31, 2021 and 2020. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s annual report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 24, 2021, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations, comprehensive income, and cash flows for the three months ended March 31, 2021 are not necessarily indicative of results that may be expected for the year ending December 31, 2021, or for any future period.

[0000926326-21-000013:notes:5]
[same as prior period, unchanged from 0000926326-20-000034:notes:5]

[0000926326-21-000013:notes:6]
The Condensed Consolidated Financial Statements include the accounts of the Company and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000926326-21-000013:notes:7]
[same as prior period, unchanged from 0000926326-20-000034:notes:7]

[0000926326-21-000013:notes:8]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of revenues for the three months ended March 31, 2020 in Note 3, Revenues. This change was not deemed material and was included to conform with current-period classification and presentation.

[0000926326-21-000013:notes:9]
[same as prior period, unchanged from 0000926326-20-000034:notes:9]

[0000926326-21-000013:notes:10]
The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.

[0000926326-21-000013:notes:11]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of March 31, 2021, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-21-000013:notes:12]
[same as prior period, unchanged from 0000926326-20-000034:notes:12]

[0000926326-21-000013:notes:13]
[same as prior period, unchanged from 0000926326-20-000034:notes:13]

[0000926326-21-000013:notes:14]
[same as prior period, unchanged from 0000926326-20-000034:notes:23]

[0000926326-21-000013:notes:15]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The update simplifies the accounting for income taxes by removing certain exceptions to the general principles in Accounting Standards Codification (“ASC”) 740, Income Taxes, as well as improves consistent application of and simplifies the guidance for other areas of ASC 740 by clarifying and amending existing guidance. The Company adopted ASU 2019-12 on January 1, 2021 on a prospective basis. The adoption of this guidance did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

[0000926326-21-000013:notes:16]
[same as prior period, unchanged from 0000926326-20-000034:notes:26]

[0000926326-21-000013:notes:17]
In August 2020, the FASB issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. This update permits the use of either the modified retrospective or fully retrospective method of transition. ASU 2020-06 will be effective for the Company beginning January 1, 2022. Early adoption is permitted, but no earlier than fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. The Company is currently evaluating the impact ASU 2020-06 will have on its Condensed Consolidated Financial Statements.

[0000926326-21-000013:notes:18]
[same as prior period, unchanged from 0000926326-20-000034:notes:29]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-21-000013:notes:19]
Business Combinations
340B Link Business Acquisition

[0000926326-21-000013:notes:20]
On October 1, 2020, the Company completed the acquisition of all of the outstanding equity of the 340B Link business (the “340B Link Business”) of Pharmaceutical Strategies Group, LLC pursuant to the terms and conditions of the Equity Purchase Agreement, dated August 11, 2020, as amended, by and among the Company, PSGH, LLC, BW Apothecary Holdings, LLC, the sellers identified therein and the sellers’ representative for total cash consideration of $225.0 million. The 340B Link Business acquisition adds a comprehensive and differentiated suite of software-enabled services and solutions used by certain eligible hospitals, health systems, clinics, and entities to manage compliance and capture 340B drug cost savings on outpatient prescriptions filled through the eligible entity’s pharmacy or a contracted pharmacy partner. The results of the 340B Link Business's operations have been included in the Company's consolidated results of operations, commencing as of the acquisition date.

[0000926326-21-000013:notes:21]
The Company accounted for the acquisition of the 340B Link Business in accordance with ASC 805, Business Combinations. The tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition date. The preliminary fair values assume management's best estimates based on information available at the acquisition date and may change over the measurement period, which will end no later than one year from the acquisition date, as additional information is received. The following table represents the preliminary allocation of the purchase price to the assets acquired and the liabilities assumed by the Company as part of the acquisition included in the Company's Condensed Consolidated Balance Sheets, and is reconciled to the purchase price transferred:

[0000926326-21-000013:notes:22]
|  | 340B Link Business(Preliminary) |
|  | (In thousands) |
| Accounts receivable and unbilled receivables | $ | 8,197 |  |
| Prepaid expenses | 232 |  |
| Other current assets | 22,747 |  |
| Total current assets | 31,176 |  |
| Property and equipment | 531 |  |
| Operating lease right-of-use assets | 3,138 |  |
| Goodwill | 161,117 |  |
| Intangible assets | 62,800 |  |
| Total assets | 258,762 |  |
| Accounts payable | 568 |  |
| Accrued liabilities | 23,787 |  |
| Long-term deferred tax liabilities | 6,818 |  |
| Long-term operating lease liabilities | 2,589 |  |
| Total liabilities | 33,762 |  |
| Total purchase price | $ | 225,000 |  |

[0000926326-21-000013:notes:23]
The $161.1 million of goodwill arising from the 340B Link Business acquisition is primarily attributed to sales of future software-enabled services and solutions and the 340B Link Business’s assembled workforce. Goodwill that is expected to be deductible for tax purposes is approximately $93.9 million.

[0000926326-21-000013:notes:24]
Intangible assets eligible for recognition separate from goodwill were those that satisfied either the contractual/legal criterion or the separability criterion in the accounting guidance. The identifiable intangible assets acquired and their estimated useful lives for amortization are as follows:

[0000926326-21-000013:notes:25]
|  | 304B Link Business |
|  | Fair value |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 53,000 |  |  | 21 |
| Acquired technology | 9,000 |  |  | 5 |
| Trade names | 200 |  |  | 1 |
| Non-compete agreements | 600 |  |  | 3 |
| Total purchased intangible assets | $ | 62,800 |  |  |  |

[0000926326-21-000013:notes:26]
The customer relationships intangible asset represents the fair value of the underlying relationships and agreements with the 340B Link Business’s customers. The acquired technology intangible asset represents the fair value of the 340B Link Business's portfolio of software and solutions that have reached technological feasibility and were part of the 340B Link Business’s offerings at the date of acquisition. The trade names intangible asset represents the fair value of brand and name recognition associated with the marketing of the 340B Link Business's software-enabled services and solutions. The non-compete agreements intangible asset represents the fair value of non-compete agreements with former key members of the 340B Link Business's management.

[0000926326-21-000013:notes:27]
The fair value of the customer relationships intangible asset was determined based on the excess earnings method; the fair values of the acquired technology and trade names intangible assets were determined based on the relief-from-royalty

[0000926326-21-000013:notes:28]
method; and the fair value of the non-compete agreements intangible asset was determined based on the lost profits method. The key assumptions used in estimating the fair values of intangible assets included forecasted financial information; customer attrition rates; royalty rates of 10.0% and 0.5% for the acquired technology and trade names intangible assets, respectively; a discount rate of 14.0% for all intangible assets; and certain other assumptions.

[0000926326-21-000013:notes:29]
The customer relationships and acquired technology intangible assets are being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. The trade names and non-compete agreements are being amortized over their estimated useful lives using the straight-line method of amortization.

[0000926326-21-000013:notes:30]
The Company believes that the fair value assigned to the assets acquired and liabilities assumed are based on reasonable assumptions and estimates that market participants would use. Actual results may differ from these estimates and assumptions.

[0000926326-21-000013:notes:31]
Pro Forma Financial Information

[0000926326-21-000013:notes:32]
The following table presents certain unaudited pro forma information for illustrative purposes only, for the three months ended March 31, 2020 as if this acquisition had been completed on January 1, 2019. The pro forma information is not indicative of what would have occurred had the acquisition taken place on January 1, 2019. The unaudited pro forma information combines the historical results of the acquisition with the Company’s consolidated historical results and includes certain adjustments including, but not limited to, amortization and depreciation of intangible assets and property and equipment acquired; imputed interest, interest expense, and amortization of debt issuance costs for the indebtedness incurred to complete the acquisition; and acquisition-related costs incurred.

[0000926326-21-000013:notes:33]
|  | Three Months Ended |
|  | March 31, 2020 |
|  | (In thousands, except per share data) |
| Pro forma revenues | $ | 238,647 |  |
| Pro forma net income | $ | 10,694 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-21-000013:notes:34]
[same as prior period, unchanged from 0000926326-20-000034:notes:30]

[0000926326-21-000013:notes:35]
The Company earns revenues from sales of its products and related services, which are sold in the healthcare industry, its principal market. The Company’s customer arrangements typically include one or more of the following revenue categories:

[0000926326-21-000013:notes:36]
Connected devices, software licenses, and other. Software-enabled connected devices and software licenses that manage and regulate the storage and dispensing of pharmaceuticals, consumables blister cards, and packaging equipment and other supplies. This revenue category is often sold through long-term, sole-source agreements with multi-year co-development plans. Solutions in this category include, but are not limited to, XT Series automated dispensing systems, the XR2 Automated Central Pharmacy system, and IV compounding automation solutions.

[0000926326-21-000013:notes:37]
Technical services. Post-installation technical support and other related services, including phone support, on-site service, parts, and access to unspecified software updates and enhancements, if and when available. This revenue category is often supported by multi-year or annual contractual agreements.

[0000926326-21-000013:notes:38]
Consumables. Medication adherence packaging, labeling, and other one-time use packaging including multimed adherence packaging and single dose blister cards which are used by retail, community, and outpatient pharmacies, as well as by institutional pharmacies serving long-term care and other sites outside the acute care hospital, and are designed to improve patient engagement and adherence to prescriptions.

[0000926326-21-000013:notes:39]
Software-as-a-service (“SaaS”), subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth™ (formerly Population Health Solutions), 340B solutions, and services associated with Omnicell One™ (formerly Performance Center), Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy system, and Central Pharmacy Compounding Services, including IV compounding automation solutions.

[0000926326-21-000013:notes:40]
The following table summarizes revenue recognition for each revenue category:

[0000926326-21-000013:notes:41]
| Revenue Category |  |  |  | Timing of Revenue Recognition |  | Income Statement Classification |
| Connected devices, software licenses, and other |  |  |  | Point in time, as transfer of control occurs, generally upon installation and acceptance by the customer |  | Product |
| Technical services |  |  |  | Over time, as services are provided, typically ratably over the service term |  | Service |
| Consumables |  |  |  | Point in time, as transfer of control occurs, generally upon shipment to or receipt by customer |  | Product |
| SaaS, subscription software, and technology-enabled services |  |  |  | Over time, as services are provided |  | Service |

[0000926326-21-000013:notes:42]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule contract with the Department of Veterans Affairs (the "GSA Contract"). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee ("IFF") to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $3.4 million and $2.9 million for the three months ended March 31, 2021 and 2020, respectively.

[0000926326-21-000013:notes:43]
[same as prior period, unchanged from 0000926326-20-000034:notes:38]

[0000926326-21-000013:notes:44]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three months ended March 31, 2021 and 2020:

[0000926326-21-000013:notes:45]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 159,718 |  |  | $ | 147,347 |  |  |  |  |  |
| Technical services | 50,860 |  |  | 49,519 |  |  |  |  |  |
| Consumables | 18,407 |  |  | 22,726 |  |  |  |  |  |
| SaaS, subscription software, and technology-enabled services | 22,858 |  |  | 10,094 |  |  |  |  |  |
| Total revenues | $ | 251,843 |  |  | $ | 229,686 |  |  |  |  |  |

[0000926326-21-000013:notes:46]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2021 and 2020:

[0000926326-21-000013:notes:47]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (In thousands) |
| United States | $ | 224,276 |  |  | $ | 207,734 |  |  |  |  |  |
| Rest of world (1) | 27,567 |  |  | 21,952 |  |  |  |  |  |
| Total revenues | $ | 251,843 |  |  | $ | 229,686 |  |  |  |  |  |

[0000926326-21-000013:notes:48]
_________________________________________________

[0000926326-21-000013:notes:49]
[same as prior period, unchanged from 0000926326-20-000034:notes:43]

[0000926326-21-000013:notes:50]
[same as prior period, unchanged from 0000926326-20-000034:notes:44]

[0000926326-21-000013:notes:51]
[same as prior period, unchanged from 0000926326-20-000034:notes:45]

[0000926326-21-000013:notes:52]
|  | March 31,2021 |  | December 31,2020 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 12,184 |  |  | $ | 13,895 |  |
| Long-term unbilled receivables, net (2) | 14,856 |  |  | 17,205 |  |
| Total contract assets | $ | 27,040 |  |  | $ | 31,100 |  |
| Short-term deferred revenues, net | $ | 119,588 |  |  | $ | 100,053 |  |
| Long-term deferred revenues | 7,887 |  |  | 5,673 |  |
| Total contract liabilities | $ | 127,475 |  |  | $ | 105,726 |  |

[0000926326-21-000013:notes:53]
[same as prior period, unchanged from 0000926326-20-000034:notes:47]

[0000926326-21-000013:notes:54]
[same as prior period, unchanged from 0000926326-20-000034:notes:48]

[0000926326-21-000013:notes:55]
[same as prior period, unchanged from 0000926326-20-000034:notes:49]

[0000926326-21-000013:notes:56]
Short-term deferred revenues of $119.6 million and $100.1 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $20.8 million and $21.0 million, as of March 31, 2021 and December 31, 2020, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three months ended March 31, 2021, the Company recognized revenues of $47.3 million that were included in the corresponding gross short-term deferred revenues balance of $121.1 million as of December 31, 2020.

[0000926326-21-000013:notes:57]
Long-term deferred revenues include deferred revenues from product and service contracts of $7.9 million and $5.7 million as of March 31, 2021 and December 31, 2020, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.

[0000926326-21-000013:notes:58]
[same as prior period, unchanged from 0000926326-20-000034:notes:52]

[0000926326-21-000013:notes:59]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2021 and 2020. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2021 and December 31, 2020.


## us-gaap:EarningsPerShareTextBlock

[0000926326-21-000013:notes:60]
Net Income Per ShareBasic net income per share is computed by dividing net income for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period, using the treasury stock method. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units, as well as shares the Company could be obligated to issue from its convertible senior notes and warrants, as described in Note 10, Convertible Senior Notes. Any anti-dilutive weighted-average dilutive shares related to stock award plans, convertible senior notes, and warrants are excluded from the computation of the diluted net income per share. 
The basic and diluted net income per share calculations for the three months ended March 31, 2021 and 2020 were as follows:

[0000926326-21-000013:notes:61]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (In thousands, except per share data) |
| Net income | $ | 14,127 |  |  | $ | 11,311 |  |  |  |  |  |
| Weighted-average shares outstanding – basic | 42,962 |  |  | 42,357 |  |  |  |  |  |
| Effect of dilutive securities from stock award plans | 1,980 |  |  | 1,264 |  |  |  |  |  |
| Effect of convertible senior notes | 1,425 |  |  | — |  |  |  |  |  |
| Weighted-average shares outstanding – diluted | 46,367 |  |  | 43,621 |  |  |  |  |  |
| Net income per share – basic | $ | 0.33 |  |  | $ | 0.27 |  |  |  |  |  |
| Net income per share – diluted | $ | 0.30 |  |  | $ | 0.26 |  |  |  |  |  |
| Anti-dilutive weighted-average shares related to stock award plans | 287 |  |  | 1,744 |  |  |  |  |  |
| Anti-dilutive weighted-average shares related to warrants | 5,908 |  |  | — |  |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-21-000013:notes:62]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $548.1 million and $485.9 million as of March 31, 2021 and December 31, 2020, respectively, consisted of bank accounts and highly-liquid U.S. Government money market funds held in sweep accounts with major financial institutions. As of March 31, 2021 and December 31, 2020, cash equivalents were $502.3 million and $447.2 million, respectively, which consisted of money market funds held in sweep accounts.

[0000926326-21-000013:notes:63]
[same as prior period, unchanged from 0000926326-20-000034:notes:57]

[0000926326-21-000013:notes:64]
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's credit facility is classified within Level 2 as the valuation inputs are based on quoted prices or market observable data of similar instruments. The Company's convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. As of March 31, 2021, the fair value of the convertible senior notes was $816.8 million, compared to their carrying value of $472.3 million, which is net of unamortized discount and debt issuance costs and excludes amounts classified within additional paid-in capital. Refer to Note 9, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 10, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-21-000013:notes:65]
Balance Sheet Components
Balance sheet details as of March 31, 2021 and December 31, 2020 are presented in the tables below:

[0000926326-21-000013:notes:66]
|  | March 31,2021 |  | December 31,2020 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 30,331 |  |  | $ | 28,205 |  |
| Work in process | 6,961 |  |  | 7,973 |  |
| Finished goods | 58,916 |  |  | 60,120 |  |
| Total inventories | $ | 96,208 |  |  | $ | 96,298 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 17,228 |  |  | $ | 18,164 |  |
| Net investment in sales-type leases, current portion | 10,222 |  |  | 10,246 |  |
| Prepaid income taxes | 7,071 |  |  | 10,095 |  |
| Other current assets | 2,435 |  |  | 2,539 |  |
| Total other current assets | $ | 36,956 |  |  | $ | 41,044 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net | $ | 95,632 |  |  | $ | 94,027 |  |
| Unbilled receivables, net | 14,856 |  |  | 17,205 |  |
| Deferred debt issuance costs | 3,979 |  |  | 4,253 |  |
| Other long-term assets | 3,976 |  |  | 3,804 |  |
| Total other long-term assets | $ | 118,443 |  |  | $ | 119,289 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 12,236 |  |  | $ | 12,197 |  |
| Customer fund liabilities | 17,228 |  |  | 18,164 |  |
| Advance payments from customers | 7,426 |  |  | 6,981 |  |
| Rebates and lease buyouts | 24,838 |  |  | 21,815 |  |
| Group purchasing organization fees | 4,802 |  |  | 4,412 |  |
| Taxes payable | 3,544 |  |  | 3,520 |  |
| Other accrued liabilities | 14,001 |  |  | 13,222 |  |
| Total accrued liabilities | $ | 84,075 |  |  | $ | 80,311 |  |

[0000926326-21-000013:notes:67]
(1)    Includes restricted cash of $1.4 million and $4.0 million as of March 31, 2021 and December 31, 2020, respectively.

[0000926326-21-000013:notes:68]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the three months ended March 31, 2021 and 2020:

[0000926326-21-000013:notes:69]
|  | Three Months Ended March 31, |
|  | 2021 |  | 2020 |
|  | Foreign currency translation adjustments |  |  |  |  |  | Foreign currency translation adjustments |  |  |  |  |
|  | (In thousands) |
| Beginning balance | $ | (5,522) |  |  |  |  |  |  | $ | (9,446) |  |  |  |  |  |
| Other comprehensive loss | (621) |  |  |  |  |  |  | (4,694) |  |  |  |  |  |
| Ending balance | $ | (6,143) |  |  |  |  |  |  | $ | (14,140) |  |  |  |  |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-21-000013:notes:70]
Property and Equipment 
The following table represents the property and equipment balances as of March 31, 2021 and December 31, 2020:

[0000926326-21-000013:notes:71]
|  | March 31,2021 |  | December 31,2020 |
|  | (In thousands) |
| Equipment | $ | 85,724 |  |  | $ | 81,034 |  |
| Furniture and fixtures | 7,422 |  |  | 7,498 |  |
| Leasehold improvements | 20,025 |  |  | 19,517 |  |
| Software | 51,992 |  |  | 50,230 |  |
| Construction in progress | 6,366 |  |  | 7,095 |  |
| Property and equipment, gross | 171,529 |  |  | 165,374 |  |
| Accumulated depreciation and amortization | (110,991) |  |  | (106,301) |  |
| Total property and equipment, net | $ | 60,538 |  |  | $ | 59,073 |  |

[0000926326-21-000013:notes:72]
Depreciation and amortization expense of property and equipment was $4.8 million and $4.3 million for the three months ended March 31, 2021 and 2020, respectively.

[0000926326-21-000013:notes:73]
The geographic location of the Company's property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of March 31, 2021 and December 31, 2020:

[0000926326-21-000013:notes:74]
|  | March 31,2021 |  | December 31,2020 |
|  | (In thousands) |
| United States | $ | 55,227 |  |  | $ | 53,203 |  |
| Rest of world (1) | 5,311 |  |  | 5,870 |  |
| Total property and equipment, net | $ | 60,538 |  |  | $ | 59,073 |  |

[0000926326-21-000013:notes:75]
[same as prior period, unchanged from 0000926326-20-000034:notes:72]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-21-000013:notes:76]
[same as prior period, unchanged from 0000926326-20-000034:notes:73]

[0000926326-21-000013:notes:77]
[same as prior period, unchanged from 0000926326-20-000034:notes:74]

[0000926326-21-000013:notes:78]
|  | December 31,2020 |  | Additions |  | Foreign currency exchange rate fluctuations |  | March 31,2021 |
|  | (In thousands) |
| Goodwill | $ | 499,309 |  |  | — |  |  | (244) |  |  | $ | 499,065 |  |

[0000926326-21-000013:notes:79]
[same as prior period, unchanged from 0000926326-20-000034:notes:76]

[0000926326-21-000013:notes:80]
The carrying amounts and useful lives of intangible assets as of March 31, 2021 and December 31, 2020 were as follows:

[0000926326-21-000013:notes:81]
|  | March 31, 2021 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 187,889 |  |  | $ | (67,464) |  |  | $ | (816) |  |  | $ | 119,609 |  |  | 10 - 30 |
| Acquired technology | 86,029 |  |  | (47,600) |  |  | 6 |  |  | 38,435 |  |  | 5 - 20 |
| Backlog | 1,150 |  |  | (1,150) |  |  | — |  |  | — |  |  | 4 |
| Trade names | 7,850 |  |  | (5,985) |  |  | 14 |  |  | 1,879 |  |  | 1 - 12 |
| Patents | 2,899 |  |  | (1,507) |  |  | 1 |  |  | 1,393 |  |  | 2 - 20 |
| Non-compete agreements | 600 |  |  | (100) |  |  | — |  |  | 500 |  |  | 3 |
| Total intangibles assets, net | $ | 286,417 |  |  | $ | (123,806) |  |  | $ | (795) |  |  | $ | 161,816 |  |  |  |

[0000926326-21-000013:notes:82]
|  | December 31, 2020 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 187,889 |  |  | $ | (64,254) |  |  | $ | (777) |  |  | $ | 122,858 |  |  | 10 - 30 |
| Acquired technology | 86,029 |  |  | (44,851) |  |  | 6 |  |  | 41,184 |  |  | 5 - 20 |
| Backlog | 1,150 |  |  | (1,078) |  |  | — |  |  | 72 |  |  | 4 |
| Trade names | 7,850 |  |  | (5,794) |  |  | 14 |  |  | 2,070 |  |  | 1 - 12 |
| Patents | 2,930 |  |  | (1,455) |  |  | 2 |  |  | 1,477 |  |  | 2 - 20 |
| Non-compete agreements | 600 |  |  | (50) |  |  | — |  |  | 550 |  |  | 3 |
| Total intangibles assets, net | $ | 286,448 |  |  | $ | (117,482) |  |  | $ | (755) |  |  | $ | 168,211 |  |  |  |

[0000926326-21-000013:notes:83]
Amortization expense of intangible assets was $6.3 million and $4.5 million for the three months ended March 31, 2021 and 2020, respectively.

[0000926326-21-000013:notes:84]
[same as prior period, unchanged from 0000926326-20-000034:notes:82]

[0000926326-21-000013:notes:85]
|  | March 31,2021 |
|  | (In thousands) |
| Remaining nine months of 2021 | $ | 17,675 |  |
| 2022 | 21,167 |  |
| 2023 | 19,145 |  |
| 2024 | 12,856 |  |
| 2025 | 11,586 |  |
| Thereafter | 79,387 |  |
| Total | $ | 161,816 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-21-000013:notes:86]
Debt and Credit Agreement
2019 Revolving Credit Facility

[0000926326-21-000013:notes:87]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility (the “Prior Credit Agreement”) and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit

[0000926326-21-000013:notes:88]
Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-21-000013:notes:89]
Loans under the Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. The applicable margin for, and certain other terms of, any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

[0000926326-21-000013:notes:90]
On September 22, 2020, the parties entered into an amendment (the “Amendment”) to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

[0000926326-21-000013:notes:91]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of March 31, 2021.

[0000926326-21-000013:notes:92]
The refinancing of the Prior Credit Agreement by means of the A&R Credit Agreement was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the A&R Credit Agreement.

[0000926326-21-000013:notes:93]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. In connection with the Amendment on September 22, 2020, the Company incurred and capitalized an additional $0.6 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs for credit agreements was approximately $0.3 million and $0.2 million for the three months ended March 31, 2021 and 2020, respectively.

[0000926326-21-000013:notes:94]
The following table represents changes in the balance of the Company's deferred debt issuance costs:

[0000926326-21-000013:notes:95]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (274) |  |
| Balance as of March 31, 2021 | $ | 3,979 |  |

[0000926326-21-000013:notes:96]
As of each of March 31, 2021 and December 31, 2020, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-21-000013:notes:97]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased or converted.

[0000926326-21-000013:notes:98]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

[0000926326-21-000013:notes:99]
During the three months ended March 31, 2021, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on March 31, 2021, the last trading day of the fiscal quarter. Accordingly, the Notes are convertible, in whole or in part, at the option of the holders during the second quarter of 2021. Whether the Notes will be convertible following the second fiscal quarter of 2021 will depend on the continued satisfaction of this condition or another conversion condition in the future. The Company continues to classify the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of March 31, 2021 based on contractual settlement provisions.

[0000926326-21-000013:notes:100]
Upon conversion, the Company may satisfy its conversion obligation by paying or delivering, as the case may be, cash, shares of its common stock, or a combination of cash and shares of its common stock, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

[0000926326-21-000013:notes:101]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal

[0000926326-21-000013:notes:102]
amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2021, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-21-000013:notes:103]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

[0000926326-21-000013:notes:104]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represents the debt discount, which the Company will amortize to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions. As of March 31, 2021, the remaining life of the Notes and the related debt discount and issuance cost accretion is approximately 4.5 years.

[0000926326-21-000013:notes:105]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 8.1 million shares. As of March 31, 2021, the if-converted value of the Notes exceeded the principal amount by $192.3 million.

[0000926326-21-000013:notes:106]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2021 and December 31, 2020:

[0000926326-21-000013:notes:107]
|  | March 31,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (91,173) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (11,480) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 472,347 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |

[0000926326-21-000013:notes:108]
(1)    Included in additional paid-in capital in the Condensed Consolidated Balance Sheets.

[0000926326-21-000013:notes:109]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2021:

[0000926326-21-000013:notes:110]
|  | Three Months Ended |  |  |  |  |
|  | March 31, 2021 |  |  |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  |  |  |  |  |  |
| Amortization of discount | $ | 4,571 |  |  |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 575 |  |  |  |  |  |  |  |

[0000926326-21-000013:notes:111]
Convertible Note Hedge and Warrant Transactions

[0000926326-21-000013:notes:112]
In connection with the issuance of the Notes, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-21-000013:notes:113]
Lessor Leases
Sales-Type Leases

[0000926326-21-000013:notes:114]
On a recurring basis, the Company enters into multi-year, sales-type lease agreements, with the majority varying in length from one to five years. The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 66% of the lease receivable balance, are retained in-house.

[0000926326-21-000013:notes:115]
The following table presents the Company’s income recognized from sales-type leases for the three months ended March 31, 2021 and 2020:

[0000926326-21-000013:notes:116]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (In thousands) |
| Sales-type lease revenues | $ | 5,963 |  |  | $ | 6,392 |  |  |  |  |  |
| Cost of sales-type lease revenues | (2,366) |  |  | (2,569) |  |  |  |  |  |
| Selling profit on sales-type lease revenues | $ | 3,597 |  |  | $ | 3,823 |  |  |  |  |  |
| Interest income on sales-type lease receivables | $ | 497 |  |  | $ | 461 |  |  |  |  |  |

[0000926326-21-000013:notes:117]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at March 31, 2021 and December 31, 2020:

[0000926326-21-000013:notes:118]
|  | March 31,2021 |  | December 31,2020 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 34,256 |  |  | $ | 35,331 |  |
| Less: Unearned interest income portion | (2,779) |  |  | (2,929) |  |
| Net investment in sales-type leases | 31,477 |  |  | 32,402 |  |
| Less: Current portion (1) | (10,222) |  |  | (10,246) |  |
| Long-term investment in sales-type leases, net | $ | 21,255 |  |  | $ | 22,156 |  |

[0000926326-21-000013:notes:119]
(1)    The current portion of the net investment in sales-type leases is included in other current assets in the Condensed Consolidated Balance Sheets.

[0000926326-21-000013:notes:120]
The carrying amount of the Company’s sales-type lease receivables is a reasonable estimate of fair value.

[0000926326-21-000013:notes:121]
The maturity schedule of future minimum lease payments under sales-type leases retained in-house and the reconciliation to the net investment in sales-type leases reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-21-000013:notes:122]
|  | March 31,2021 |
|  | (In thousands) |
| Remaining nine months of 2021 | $ | 8,485 |  |
| 2022 | 10,002 |  |
| 2023 | 7,629 |  |
| 2024 | 4,826 |  |
| 2025 | 2,907 |  |
| Thereafter | 407 |  |
| Total future minimum sales-type lease payments | 34,256 |  |
| Present value adjustment | (2,779) |  |
| Total net investment in sales-type leases | $ | 31,477 |  |

[0000926326-21-000013:notes:123]
Operating Leases

[0000926326-21-000013:notes:124]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of ASC 842, Leases. These agreements in place prior to January 1, 2019 continue to be treated as operating leases, however any leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with ASC 842. The operating lease arrangements generally have initial terms of one to seven years. The following table represents the Company’s income recognized from operating leases for the three months ended March 31, 2021 and 2020:

[0000926326-21-000013:notes:125]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (In thousands) |
| Rental income | $ | 2,611 |  |  | $ | 2,977 |  |  |  |  |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-21-000013:notes:126]
Lessee Leases 
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to 12 years. As of March 31, 2021, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-21-000013:notes:127]
The maturity schedule of future minimum lease payments under operating leases and the reconciliation to the operating lease liabilities reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-21-000013:notes:128]
|  | March 31,2021 |
|  | (In thousands) |
| Remaining nine months of 2021 | $ | 11,305 |  |
| 2022 | 14,088 |  |
| 2023 | 10,199 |  |
| 2024 | 8,847 |  |
| 2025 | 6,413 |  |
| Thereafter | 17,293 |  |
| Total operating lease payments | 68,145 |  |
| Present value adjustment | (10,474) |  |
| Total operating lease liabilities (1) | $ | 57,671 |  |

[0000926326-21-000013:notes:129]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $12.2 million and $45.4 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-21-000013:notes:130]
Operating lease costs were $3.7 million and $3.6 million for the three months ended March 31, 2021 and 2020, respectively. Short-term lease costs and variable lease costs were immaterial for the three months ended March 31, 2021 and 2020.

[0000926326-21-000013:notes:131]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the three months ended March 31, 2021 and 2020:

[0000926326-21-000013:notes:132]
|  | Three Months Ended March 31, |
|  | 2021 |  | 2020 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 3,972 |  |  | $ | 3,735 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 541 |  |  | $ | 792 |  |

[0000926326-21-000013:notes:133]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of March 31, 2021 and December 31, 2020:

[0000926326-21-000013:notes:134]
|  | March 31,2021 |  | December 31,2020 |
| Weighted-average remaining lease term, years | 5.8 |  | 5.9 |
| Weighted-average discount rate, % | 5.8 | % |  | 5.8 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-21-000013:notes:135]
Commitments and Contingencies
Purchase Obligations

[0000926326-21-000013:notes:136]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2021, the Company had non-cancelable purchase commitments of $82.8 million, of which $78.8 million are expected to be paid within the year ending December 31, 2021.

[0000926326-21-000013:notes:137]
Legal Proceedings

[0000926326-21-000013:notes:138]
The Company is currently involved in various legal proceedings.

[0000926326-21-000013:notes:139]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated, v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020. The Company's motion to dismiss is now fully briefed and the Court has scheduled oral argument on the motion for June 4, 2021. The Company intends to defend the lawsuit vigorously.

[0000926326-21-000013:notes:140]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “Omnicell Complaint”). This action (the “Omnicell Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The Omnicell Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees

[0000926326-21-000013:notes:141]
and costs, and pre-judgment and post-judgment interest. On March 17, 2021, the parties filed a joint motion to stay the Omnicell Action, which motion remains pending with the Court. On April 30, 2021, pending the decision from the Court regarding the joint motion to stay the Omnicell Action, the Company filed a consent motion for extension of time supported by BD to file the Company’s answer to the Omnicell Complaint. The consent motion was granted by the Court on April 30, 2021, and the Company’s answer to the Omnicell Complaint is now due June 3, 2021. The Company intends to defend the lawsuit vigorously.

[0000926326-21-000013:notes:142]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceedings described above based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to these legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of any of these legal proceedings or because of the diversion of management’s attention and the creation of significant expenses.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-21-000013:notes:143]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 26.7% and 26.6% for the three months ended March 31, 2021 and 2020, respectively.

[0000926326-21-000013:notes:144]
The Company continued its global operational centralization activities and legal entity rationalization during the first quarter of 2021. The Company did not recognize any gains or losses from such activities during the three months ended March 31, 2020 and 2021. The Company recognized a discrete tax benefit related to equity compensation in the amount of $4.1 million and $2.8 million for the three months ended March 31, 2021 and 2020, respectively.

[0000926326-21-000013:notes:145]
The 2021 annual effective tax rate before discrete items differed from the statutory rate of 21% primarily due to the unfavorable impact of state income taxes and non-deductible compensation and equity charges, partially offset by the favorable impact of research and development credits and foreign derived intangible income (“FDII”) benefit deduction. The 2020 annual effective tax rate before discrete items differed from the statutory rate of 21% primarily due to the unfavorable impact of state income taxes, non-deductible compensation and equity charges, and non-deductible expenses, partially offset by the favorable impact of research and development credits and FDII benefit deduction.

[0000926326-21-000013:notes:146]
On March 11, 2021, the President of the United States signed into law the “American Rescue Plan Act of 2021” (the “ARP Act”), which provides additional economic stimulus and tax credits, including the expansion and modification of the employee retention tax credit enacted by the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) and the refundable tax credits for COVID-related paid sick and family leave enacted by the Family First Act. The Company does not expect these provisions of the ARP Act to have a material impact for income taxes. The ARP Act further provides revenue raising offsets to meet budget reconciliation rules, including the expansion of “covered employees” for purposes of the section 162(m) limitation on the deduction for excessive employee remuneration rules to be applicable for taxable years beginning after December 31, 2026. The Company will continue to evaluate the impact of these provisions of the ARP Act on income taxes.

[0000926326-21-000013:notes:147]
As of March 31, 2021 and December 31, 2020, the Company had gross unrecognized tax benefits of $17.7 million and $18.2 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. As of March 31, 2021 and December 31, 2020, the amount of accrued interest and penalties was $1.1 million and $1.4 million, respectively.

[0000926326-21-000013:notes:148]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of March 31, 2021, the Company was no longer subject to U.S., state, and foreign examination for years before 2017, 2016, and 2016, respectively.

[0000926326-21-000013:notes:149]
[same as prior period, unchanged from 0000926326-20-000034:notes:154]


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-21-000013:notes:150]
[same as prior period, unchanged from 0000926326-20-000034:notes:155]

[0000926326-21-000013:notes:151]
For a detailed explanation of the Company's stock plans, refer to Note 14, Employee Benefits and Share-Based Compensation, of the Company's annual report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 24, 2021.

[0000926326-21-000013:notes:152]
[same as prior period, unchanged from 0000926326-20-000034:notes:157]

[0000926326-21-000013:notes:153]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three months ended March 31, 2021 and 2020:

[0000926326-21-000013:notes:154]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,937 |  |  | $ | 1,770 |  |  |  |  |  |
| Research and development | 1,700 |  |  | 1,768 |  |  |  |  |  |
| Selling, general, and administrative | 8,135 |  |  | 7,121 |  |  |  |  |  |
| Total share-based compensation expense | $ | 11,772 |  |  | $ | 10,659 |  |  |  |  |  |

[0000926326-21-000013:notes:155]
[same as prior period, unchanged from 0000926326-20-000034:notes:160]

[0000926326-21-000013:notes:156]
The following assumptions were used to value stock options and Employee Stock Purchase Plan (“ESPP”) shares granted pursuant to the Company’s equity incentive plans for the three months ended March 31, 2021 and 2020:

[0000926326-21-000013:notes:157]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Stock options |  |  |  |  |  |  |  |
| Expected life, years | 4.9 |  | 4.7 |  |  |  |  |
| Expected volatility, % | 30.1 | % |  | 33.6 | % |  |  |  |  |
| Risk-free interest rate, % | 0.6 | % |  | 1.4 | % |  |  |  |  |
| Estimated forfeiture rate, % | 7.9 | % |  | 5.7 | % |  |  |  |  |
| Dividend yield, % | — | % |  | — | % |  |  |  |  |

[0000926326-21-000013:notes:158]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Employee stock purchase plan shares |  |  |  |  |  |  |  |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  |  |  |  |
| Expected volatility, % | 27.4% - 53.5% |  | 30.4% - 39.9% |  |  |  |  |
| Risk-free interest rate, % | 0.1% - 2.6% |  | 1.4% - 2.7% |  |  |  |  |
| Dividend yield, % | — | % |  | — | % |  |  |  |  |

[0000926326-21-000013:notes:159]
[same as prior period, unchanged from 0000926326-20-000034:notes:164]

[0000926326-21-000013:notes:160]
The following table summarizes the share option activity under the Company’s 2009 Equity Incentive Plan (the “2009 Plan”), as amended, during the three months ended March 31, 2021:

[0000926326-21-000013:notes:161]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2020 | 3,932 |  |  | $ | 62.50 |  |  | 7.8 |  | $ | 226,160 |  |
| Granted | 150 |  |  | 125.80 |  |  |  |  |  |
| Exercised | (196) |  |  | 58.49 |  |  |  |  |  |
| Expired | (6) |  |  | 78.32 |  |  |  |  |  |
| Forfeited | (60) |  |  | 72.27 |  |  |  |  |  |
| Outstanding at March 31, 2021 | 3,820 |  |  | $ | 65.02 |  |  | 7.5 |  | $ | 247,796 |  |
| Exercisable at March 31, 2021 | 1,608 |  |  | $ | 47.83 |  |  | 5.8 |  | $ | 131,946 |  |
| Vested and expected to vest at March 31, 2021 and thereafter | 3,598 |  |  | $ | 64.01 |  |  | 7.4 |  | $ | 237,072 |  |

[0000926326-21-000013:notes:162]
The weighted-average fair value per share of options granted during the three months ended March 31, 2021 and 2020 was $33.89 and $26.31, respectively. The intrinsic value of options exercised during the three months ended March 31, 2021 and 2020 was $14.0 million and $9.9 million, respectively.

[0000926326-21-000013:notes:163]
As of March 31, 2021, total unrecognized compensation cost related to unvested stock options was $49.1 million, which is expected to be recognized over a weighted-average vesting period of 2.7 years.

[0000926326-21-000013:notes:164]
[same as prior period, unchanged from 0000926326-20-000034:notes:169]

[0000926326-21-000013:notes:165]
For the three months ended March 31, 2021 and 2020, employees purchased approximately 156,000 and 217,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $59.75 and $43.51, respectively. As of March 31, 2021, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $4.4 million and is expected to be recognized over a weighted-average period of 1.5 years.

[0000926326-21-000013:notes:166]
[same as prior period, unchanged from 0000926326-20-000034:notes:171]

[0000926326-21-000013:notes:167]
Summaries of the restricted stock activity under the 2009 Plan are presented below for the three months ended March 31, 2021:

[0000926326-21-000013:notes:168]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted stock units |  |  |  |  |  |  |  |
| Outstanding at December 31, 2020 | 580 |  |  | $ | 72.87 |  |  | 1.6 |  | $ | 69,670 |  |
| Granted (Awarded) | 96 |  |  | 129.97 |  |  |  |  |  |
| Vested (Released) | (37) |  |  | 72.71 |  |  |  |  |  |
| Forfeited | (17) |  |  | 70.59 |  |  |  |  |  |
| Outstanding and unvested at March 31, 2021 | 622 |  |  | $ | 81.79 |  |  | 1.6 |  | $ | 80,723 |  |

[0000926326-21-000013:notes:169]
As of March 31, 2021, total unrecognized compensation cost related to RSUs was $44.8 million, which is expected to be recognized over the remaining weighted-average vesting period of 3.0 years.

[0000926326-21-000013:notes:170]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted stock awards |  |  |  |
| Outstanding at December 31, 2020 | 21 |  |  | $ | 68.11 |  |
| Granted (Awarded) | — |  |  | — |  |
| Vested (Released) | — |  |  | — |  |
| Outstanding and unvested at March 31, 2021 | 21 |  |  | $ | 68.11 |  |

[0000926326-21-000013:notes:171]
As of March 31, 2021, total unrecognized compensation cost related to RSAs was $0.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.2 years.

[0000926326-21-000013:notes:172]
[same as prior period, unchanged from 0000926326-20-000034:notes:177]

[0000926326-21-000013:notes:173]
A summary of the performance-based restricted stock activity under the 2009 Plan is presented below for the three months ended March 31, 2021:

[0000926326-21-000013:notes:174]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2020 | 155 |  |  | $ | 74.26 |  |
| Granted | 51 |  |  | 156.79 |  |
| Vested | (17) |  |  | 82.35 |  |
| Forfeited | (6) |  |  | 63.20 |  |
| Outstanding and unvested at March 31, 2021 | 183 |  |  | $ | 96.94 |  |

[0000926326-21-000013:notes:175]
As of March 31, 2021, total unrecognized compensation cost related to PSUs was approximately $10.4 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.5 years.

[0000926326-21-000013:notes:176]
[same as prior period, unchanged from 0000926326-20-000034:notes:181]

[0000926326-21-000013:notes:177]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of March 31, 2021:

[0000926326-21-000013:notes:178]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 3,820 |  |
| Non-vested restricted stock awards | 826 |  |
| Shares authorized for future issuance | 872 |  |
| ESPP shares available for future issuance | 1,050 |  |
| Total shares reserved for future issuance | 6,568 |  |

[0000926326-21-000013:notes:179]
[same as prior period, unchanged from 0000926326-20-000034:notes:184]

[0000926326-21-000013:notes:180]
On August 2, 2016, the Company's Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2014 Repurchase Program”). As of March 31, 2021, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase programs at any time.
During the three months ended March 31, 2021 and 2020, the Company did not repurchase any of its outstanding common stock


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-21-000013:notes:181]
Equity Offerings
On November 3, 2017, the Company entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC, and HSBC Securities (USA) Inc., as its sales agents, pursuant to which the Company was able to offer and sell from time to time through the sales agents up to $125.0 million maximum aggregate offering price of the Company’s common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange.

[0000926326-21-000013:notes:182]
For the three months ended March 31, 2020, the Company did not sell any of its common stock under the Distribution Agreement.

[0000926326-21-000013:notes:183]
The registration statement under which the shares that could have been sold pursuant to the Distribution Agreement expired on November 3, 2020, and, accordingly, no additional sales will be made pursuant to the Distribution Agreement.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-21-000013:notes:184]
Restructuring Expenses
During 2020, the Company announced a company-wide organizational realignment initiative in order to more effectively align its organizational infrastructure and operations with the strategic vision of the autonomous pharmacy. In the first quarter of 2021, the Company continued its organizational realignment initiative. During the three months ended March 31, 2021 and 2020, the Company incurred $2.0 million and $3.6 million of employee severance costs and related expenses, respectively. As of March 31, 2021, the unpaid balance related to this restructuring plan was $1.2 million.

[0000926326-21-000013:notes:185]
The following table summarizes the total restructuring expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three months ended March 31, 2021 and 2020:

[0000926326-21-000013:notes:186]
|  |  |  |  |  | Three Months Ended March 31, |
|  |  |  | 2021 |  | 2020 |
|  |  |  |  |  | (In thousands) |
| Cost of product and service revenues |  |  |  |  | $ | 389 |  |  | $ | 75 |  |
| Research and development |  |  |  |  | 105 |  |  | 798 |  |
| Selling, general, and administrative |  |  |  |  | 1,526 |  |  | 2,732 |  |
| Total restructuring expense |  |  |  |  | $ | 2,020 |  |  | $ | 3,605 |  |
