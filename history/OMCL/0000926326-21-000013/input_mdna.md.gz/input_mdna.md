# OMCL MD&A — 0000926326-21-000013


## mdna

[0000926326-21-000013:mdna:1]
[same as prior period, unchanged from 0000926326-20-000034:mdna:1]

[0000926326-21-000013:mdna:2]
[same as prior period, unchanged from 0000926326-20-000034:mdna:2]

[0000926326-21-000013:mdna:3]
•our expectations about the continuing impact of the ongoing COVID-19 pandemic (including efforts to contain the spread of the pandemic) on our workforce and operations, as well as the continuing impacts on our customers and suppliers, and the anticipated continuing effects of the pandemic and associated containment measures on our business, financial condition, liquidity, and results of operations;

[0000926326-21-000013:mdna:4]
•our expectations regarding our future sales pipeline and product bookings;

[0000926326-21-000013:mdna:5]
[same as prior period, unchanged from 0000926326-20-000034:mdna:5]

[0000926326-21-000013:mdna:6]
[same as prior period, unchanged from 0000926326-20-000034:mdna:6]

[0000926326-21-000013:mdna:7]
•our beliefs about drivers of demand for our solutions, market opportunities in certain product categories, and continued expansion in these product categories, as well as our belief that our technology, services, and solutions within these categories position us well to address the needs of retail, acute, and post-acute pharmacy providers;

[0000926326-21-000013:mdna:8]
•our ability to acquire companies, businesses, products, or technologies on commercially reasonable terms and integrate such acquisitions effectively;

[0000926326-21-000013:mdna:9]
[same as prior period, unchanged from 0000926326-20-000034:mdna:9]

[0000926326-21-000013:mdna:10]
[same as prior period, unchanged from 0000926326-20-000034:mdna:10]

[0000926326-21-000013:mdna:11]
[same as prior period, unchanged from 0000926326-20-000034:mdna:11]

[0000926326-21-000013:mdna:12]
[same as prior period, unchanged from 0000926326-20-000034:mdna:12]

[0000926326-21-000013:mdna:13]
[same as prior period, unchanged from 0000926326-20-000034:mdna:13]

[0000926326-21-000013:mdna:14]
[same as prior period, unchanged from 0000926326-20-000034:mdna:14]

[0000926326-21-000013:mdna:15]
[same as prior period, unchanged from 0000926326-20-000034:mdna:15]

[0000926326-21-000013:mdna:16]
•the outcome of any legal proceedings to which we are a party;

[0000926326-21-000013:mdna:17]
•the bookings, revenues, non-GAAP EBITDA, non-GAAP operating margin, or non-GAAP earnings per share goals we may set;

[0000926326-21-000013:mdna:18]
•our projected target long-term revenues and revenue growth rates, long-term non-GAAP operating margin targets, long-term non-GAAP EBITDA margin targets, and free cash flow conversion;

[0000926326-21-000013:mdna:19]
•our ability to protect our intellectual property and operate our business without infringing, misappropriating, or otherwise violating the intellectual property rights of others;

[0000926326-21-000013:mdna:20]
[same as prior period, unchanged from 0000926326-20-000034:mdna:21]

[0000926326-21-000013:mdna:21]
•our expected future uses of cash, including our expected uses for the remaining proceeds of our convertible senior notes, and the sufficiency of our sources of funding; and

[0000926326-21-000013:mdna:22]
[same as prior period, unchanged from 0000926326-20-000034:mdna:23]

[0000926326-21-000013:mdna:23]
[same as prior period, unchanged from 0000926326-20-000034:mdna:24]

[0000926326-21-000013:mdna:24]
All references in this report to “Omnicell,” “our,” “us,” “we,” or “the Company” collectively refer to Omnicell, Inc., a Delaware corporation, and its subsidiaries. The term “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries.

[0000926326-21-000013:mdna:25]
We own various registered and unregistered trademarks and service marks used in our business, some of which appear in this report. The most important of these marks include Omnicell® and the Omnicell logo. This report may also

[0000926326-21-000013:mdna:26]
include the trademarks and service marks of other companies. Such trademarks and service marks are the marks of their respective owners.

[0000926326-21-000013:mdna:27]
[same as prior period, unchanged from 0000926326-20-000034:mdna:27]

[0000926326-21-000013:mdna:28]
[same as prior period, unchanged from 0000926326-20-000034:mdna:28]

[0000926326-21-000013:mdna:29]
We are a leader in transforming the pharmacy care delivery model. Our medication management automation solutions and adherence tools empower healthcare systems and pharmacies to focus on clinical care, rather than administrative tasks. Our solutions support the vision of a fully autonomous pharmacy, a roadmap designed to improve operational efficiencies through a fully automated, medication management infrastructure. Our vision is to transform the pharmacy care delivery model through automation designed to replace manual, error-prone processes, combined with a single, cloud-based platform and advanced services offerings. We believe our connected devices, products, and solutions will help our customers harness the power of data and analytics, and deliver improved patient outcomes.

[0000926326-21-000013:mdna:30]
Over 7,000 facilities worldwide use our automation and analytics solutions which are designed to improve pharmacy workflows, increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 50,000 institutional and retail pharmacies across North America and the United Kingdom leverage our innovative medication adherence and population health solutions to improve patient engagement, and adherence to prescriptions and vaccine scheduling, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 89% and 90% of our total revenues for the three months ended March 31, 2021 and 2020, respectively.

[0000926326-21-000013:mdna:31]
[same as prior period, unchanged from 0000926326-20-000034:mdna:31]

[0000926326-21-000013:mdna:32]
We utilize product bookings as an indicator of the success of our business. Product bookings generally consist of all firm orders other than for technical services and other less significant items, as evidenced generally by a non-cancelable contract and purchase order for equipment and software products, and by a purchase order for consumables. A majority of our connected devices and software license product bookings are installable within twelve months of booking, and are recorded as revenue upon customer acceptance of the installation or receipt of goods. Revenues from software-as-a-service (“SaaS”), subscription software, and technology-enabled services product bookings are recorded over the contractual term.

[0000926326-21-000013:mdna:33]
In addition to product solution sales, we provide services to our customers. We provide installation planning and consulting as part of most product sales which is generally included in the initial price of the solution. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in increments of one to five years. As a result of the growth of our installed base of customers and expanded service offerings, our service revenues have also grown.

[0000926326-21-000013:mdna:34]
The following table summarizes each revenue category:

[0000926326-21-000013:mdna:35]
| Revenue Category |  | Revenue Type (1) |  | Income Statement Classification |  | Included in Product Bookings |
| Connected devices, software licenses, and other |  | High visibility/Nonrecurring |  | Product |  | Yes (2) |
| Technical services |  | High visibility/Recurring |  | Service |  | No |
| Consumables |  | High visibility/Recurring |  | Product |  | Yes |
| SaaS, subscription software, and technology-enabled services |  | High visibility/Recurring |  | Service |  | Yes |

[0000926326-21-000013:mdna:36]
[same as prior period, unchanged from 0000926326-20-000034:mdna:150]

[0000926326-21-000013:mdna:37]
(1)    All revenue types are highly visible from long-term, sole-source agreements, backlog, or the recurring nature of the revenue stream.

[0000926326-21-000013:mdna:38]
(2)    Freight revenue and certain other insignificant revenue streams are not included in product bookings.

[0000926326-21-000013:mdna:39]
Our full-time employee headcount was approximately 2,970 and 2,860 on March 31, 2021 and December 31, 2020, respectively.

[0000926326-21-000013:mdna:40]
[same as prior period, unchanged from 0000926326-20-000034:mdna:36]

[0000926326-21-000013:mdna:41]
We manage our operations as a single segment for the purposes of assessing performance and making operating decisions. Our Chief Operating Decision Maker ("CODM") is our Chief Executive Officer. The CODM allocates resources and evaluates the performance of Omnicell at the consolidated level using information about our revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of Omnicell as one operating segment, which is the same as our reporting segment.

[0000926326-21-000013:mdna:42]
[same as prior period, unchanged from 0000926326-20-000034:mdna:38]

[0000926326-21-000013:mdna:43]
We are committed to being the care provider’s most trusted partner and executing on the vision of the autonomous pharmacy by delivering automation, intelligence, and advanced services, powered by a single, cloud-based platform. We believe there are significant challenges in pharmacy practice including, but not limited to, medication errors, drug shortages, medication loss due to drug diversion, significant medication waste and expiration costs, a high level of manual steps in the medication management automation process, complexity around compliance requirements, high pharmacy employee turnover rates, hospitalizations from adverse drug events in outpatient settings, high variability in outcomes, and limited inventory visibility. We believe that these significant challenges in pharmacy practice drive the demand for increased digitization and virtualization, and that our solutions enable this and represent large opportunities in four market categories:

[0000926326-21-000013:mdna:44]
•Point of Care.  As a market leader, we expect to continue expansion of this product category as customers increase use of our dispensing systems in more areas within their hospitals. In addition, we are early in the replacement, upgrade, and expansion cycle of our XT Series automated dispensing systems which we believe is a significant market opportunity and we expect to continue to focus on further penetrating markets through competitive conversions. We believe our current portfolio within the Point of Care market and new innovation and services will continue to drive improved outcomes and lower costs for our customers.

[0000926326-21-000013:mdna:45]
•Central Pharmacy.  This market represents the beginning of the medication management process in acute care settings, and, we believe, the next big automation opportunity to replace manual and repetitive processes which are common in the pharmacy today. Manual processes are prone to significant errors, and products such as IVX Workflow, our IV sterile compounding solutions, and the XR2 Automated Central Pharmacy system automate these manual processes and are designed to reduce the risk of error for our healthcare partners. We believe new products and innovations, including Omnicell One, in the Central Pharmacy market create opportunities to replace prior generation Central Pharmacy robotics and carousels. The Central Pharmacy also represents an opportunity to provide technology-enabled services designed to reduce the administrative burden on the pharmacy and allow clinicians to operate at the top of their license.

[0000926326-21-000013:mdna:46]
•340B Software-Enabled Services.  This market is targeted to covered entities participating in Section 340B of the Public Health Services Act. The act requires pharmaceutical manufacturers participating in Medicaid to sell outpatient drugs at discounted prices to health care organizations that care for many uninsured and low-income patients and results in a complex compliance environment. We believe that there are significant opportunities for health systems to improve participation benefits and maximize program savings through software-enabled services and solutions. Our Omnicell 340B platform of technology-enabled services includes split billing software, contract pharmacy administration, specialty contract pharmacy administration, and drug discount access solutions.

[0000926326-21-000013:mdna:47]
•Retail, Institutional, and Payer.  We believe the Retail, Institutional, and Payer market represents a large opportunity as the majority of drugs are distributed in the non-acute sector. New technology and updated state board regulations are leading to innovation at traditional retail providers, which, combined with the move to value-based care, we believe will incentivize the market to adopt solutions to help providers and payers engage patients in new ways that lower the total cost of care. We believe adoption of our EnlivenHealth (formerly Population Health Solutions) portfolio of software products and services, along with medication adherence packaging, will increase adherence performance rates, increase prescription volume for our customers, and reduce hospital and emergency room visits due to improved adherence. As retail pharmacies play an increasingly vital role in population health following the onset of the COVID-19 pandemic, EnlivenHealth has extended solutions to assist with vaccination programs, testing protocols, and patient engagement efforts. There are three main areas of focus:

[0000926326-21-000013:mdna:48]
◦CareScheduler is an exclusive digital solution that automates the scheduling, reporting, and patient outreach for administering the COVID-19 vaccine and other vaccines and testing procedures.

[0000926326-21-000013:mdna:49]
◦Medication Synchronization is an appointment-based solution that aligns a patient's medications to a single refill date, designed to improve medication adherence and reduce hospital readmissions.

[0000926326-21-000013:mdna:50]
◦Medication Therapy Management is a platform that offers intuitive workflow with high-level decision support for efficiently completing CMS-compliant Comprehensive Medication Reviews using pharmacy claims data.

[0000926326-21-000013:mdna:51]
We believe our technology, services, and solutions within these market categories position us well to address the needs of retail, acute, and post-acute pharmacy providers.

[0000926326-21-000013:mdna:52]
COVID-19 Update

[0000926326-21-000013:mdna:53]
We continue to closely monitor the COVID-19 pandemic and ongoing impacts on our Company. During the first half of 2020, as a result of the COVID-19 pandemic, health systems faced financial and operational pressures which we believe led our customers to delay or defer purchasing decisions and/or implementation of our solutions. However, starting in the third quarter of 2020, we began to see our customers returning to pre-pandemic purchasing patterns consistent with long-term strategic investments. We believe that the challenges that our customers have faced during the COVID-19 pandemic, including the need for robust visibility throughout their pharmacy supply chains, have increased the strategic relevance of our products and services.

[0000926326-21-000013:mdna:54]
Although COVID-19 vaccines are now available and being widely distributed, there remains significant uncertainty regarding the duration and severity of the continuing impact of the pandemic on the U.S. and world economies, including the impact of new variants of the COVID-19 virus. The ongoing impact on our business remains uncertain, the duration and scope of which cannot currently be predicted, and may result in increased borrowing costs and other costs of capital or otherwise adversely affect our business, results of operations, financial condition, and liquidity. However, under current circumstances, we believe that our financial position and resources will allow us to manage the anticipated impact of the COVID-19 pandemic on our business for the foreseeable future.

[0000926326-21-000013:mdna:55]
[same as prior period, unchanged from 0000926326-20-000034:mdna:50]

[0000926326-21-000013:mdna:56]
On October 1, 2020, we completed the acquisition of the 340B Link business (the “340B Link Business”) of Pharmaceutical Strategies Group, LLC pursuant to the terms and conditions of the Equity Purchase Agreement, dated August 11, 2020, as amended, by and among the Company, PSGH, LLC, BW Apothecary Holdings, LLC, the sellers identified therein and the seller’s representative for total cash consideration of $225.0 million. The acquisition adds a comprehensive and differentiated suite of software-enabled services and solutions used by certain eligible hospitals, health systems, clinics, and entities to manage compliance and capture 340B drug cost savings on outpatient prescriptions filled through the eligible entity’s pharmacy or a contracted pharmacy partner. The results of the operations of the 340B Link Business have been included in our consolidated results of operations beginning October 1, 2020.

[0000926326-21-000013:mdna:57]
[same as prior period, unchanged from 0000926326-20-000034:mdna:52]

[0000926326-21-000013:mdna:58]
[same as prior period, unchanged from 0000926326-20-000034:mdna:53]

[0000926326-21-000013:mdna:59]
[same as prior period, unchanged from 0000926326-20-000034:mdna:54]

[0000926326-21-000013:mdna:60]
[same as prior period, unchanged from 0000926326-20-000034:mdna:55]

[0000926326-21-000013:mdna:61]
[same as prior period, unchanged from 0000926326-20-000034:mdna:56]

[0000926326-21-000013:mdna:62]
[same as prior period, unchanged from 0000926326-20-000034:mdna:57]

[0000926326-21-000013:mdna:63]
[same as prior period, unchanged from 0000926326-20-000034:mdna:58]

[0000926326-21-000013:mdna:64]
[same as prior period, unchanged from 0000926326-20-000034:mdna:59]

[0000926326-21-000013:mdna:65]
•Valuation and impairment of goodwill and intangible assets;

[0000926326-21-000013:mdna:66]
•Business combinations;

[0000926326-21-000013:mdna:67]
[same as prior period, unchanged from 0000926326-20-000034:mdna:61]

[0000926326-21-000013:mdna:68]
[same as prior period, unchanged from 0000926326-20-000034:mdna:62]

[0000926326-21-000013:mdna:69]
[same as prior period, unchanged from 0000926326-20-000034:mdna:63]

[0000926326-21-000013:mdna:70]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the three months ended March 31, 2021 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2020, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q.

[0000926326-21-000013:mdna:71]
[same as prior period, unchanged from 0000926326-20-000034:mdna:65]

[0000926326-21-000013:mdna:72]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-21-000013:mdna:73]
[same as prior period, unchanged from 0000926326-20-000034:mdna:67]

[0000926326-21-000013:mdna:74]
[same as prior period, unchanged from 0000926326-20-000034:mdna:68]

[0000926326-21-000013:mdna:75]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 178,125 |  |  | $ | 170,073 |  |  | $ | 8,052 |  |  | 5% |
| Percentage of total revenues | 71% |  | 74% |  |  |  |  |
| Services and other revenues | 73,718 |  |  | 59,613 |  |  | 14,105 |  |  | 24% |
| Percentage of total revenues | 29% |  | 26% |  |  |  |  |
| Total revenues | $ | 251,843 |  |  | $ | 229,686 |  |  | $ | 22,157 |  |  | 10% |

[0000926326-21-000013:mdna:76]
Product revenues represented 71% and 74% of total revenues for the three months ended March 31, 2021 and 2020, respectively. Product revenues increased by $8.1 million, due to increased customer demand, primarily within our automated dispensing systems business.

[0000926326-21-000013:mdna:77]
Services and other revenues represented 29% and 26% of total revenues for the three months ended March 31, 2021 and 2020, respectively. Services and other revenues include revenues from technical services, SaaS, subscription software, and technology-enabled services, and other services. Services and other revenues increased by $14.1 million, primarily due to revenues of $10.9 million from the newly-acquired 340B Link Business, as well as continued growth in our installed customer base.

[0000926326-21-000013:mdna:78]
Our international sales represented 11% and 10% of total revenues for the three months ended March 31, 2021 and 2020, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-21-000013:mdna:79]
[same as prior period, unchanged from 0000926326-20-000034:mdna:77]

[0000926326-21-000013:mdna:80]
[same as prior period, unchanged from 0000926326-20-000034:mdna:80]

[0000926326-21-000013:mdna:81]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which account for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product, and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site and include costs of the field installation personnel, including labor, travel expenses, and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory, and amortization of software development costs and intangibles.

[0000926326-21-000013:mdna:82]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 92,627 |  |  | $ | 90,272 |  |  | $ | 2,355 |  |  | 3% |
| As a percentage of related revenues | 52% |  | 53% |  |  |  |  |
| Cost of services and other revenues | 36,933 |  |  | 29,792 |  |  | 7,141 |  |  | 24% |
| As a percentage of related revenues | 50% |  | 50% |  |  |  |  |
| Total cost of revenues | $ | 129,560 |  |  | $ | 120,064 |  |  | $ | 9,496 |  |  | 8% |
| As a percentage of total revenues | 51% |  | 52% |  |  |  |  |
| Gross profit | $ | 122,283 |  |  | $ | 109,622 |  |  | $ | 12,661 |  |  | 12% |
| Gross margin | 49% |  | 48% |  |  |  |  |

[0000926326-21-000013:mdna:83]
Cost of revenues for the three months ended March 31, 2021 compared to the three months ended March 31, 2020 increased by $9.5 million, of which $2.4 million was attributed to the increase in cost of product revenues and $7.1 million was attributed to the increase in cost of services and other revenues.

[0000926326-21-000013:mdna:84]
The increase in cost of product revenues was primarily driven by the increase in product revenues of $8.1 million for the three months ended March 31, 2021 compared to the three months ended March 31, 2020.

[0000926326-21-000013:mdna:85]
The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $14.1 million, including incremental revenues from the newly-acquired 340B Link Business, for the three months ended March 31, 2021 compared to the three months ended March 31, 2020, as well as additional investments in our service business to support new product offerings.

[0000926326-21-000013:mdna:86]
The overall increase in gross margin primarily relates to higher revenues due to increased customer demand. Our gross profit for the three months ended March 31, 2021 was $122.3 million, as compared to $109.6 million for the three months ended March 31, 2020.

[0000926326-21-000013:mdna:87]
[same as prior period, unchanged from 0000926326-20-000034:mdna:90]

[0000926326-21-000013:mdna:88]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 16,080 |  |  | $ | 18,652 |  |  | $ | (2,572) |  |  | (14)% |
| As a percentage of total revenues | 6% |  | 8% |  |  |  |  |
| Selling, general, and administrative | 86,593 |  |  | 78,819 |  |  | 7,774 |  |  | 10% |
| As a percentage of total revenues | 34% |  | 34% |  |  |  |  |
| Total operating expenses | $ | 102,673 |  |  | $ | 97,471 |  |  | $ | 5,202 |  |  | 5% |
| As a percentage of total revenues | 41% |  | 42% |  |  |  |  |
| Interest and other income (expense), net | $ | (6,691) |  |  | $ | (822) |  |  | $ | (5,869) |  |  | 714% |

[0000926326-21-000013:mdna:89]
Research and Development. Research and development expenses decreased by $2.6 million for the three months ended March 31, 2021 compared to the three months ended March 31, 2020. The decrease was primarily attributed to a decrease in employee-related expenses, including $0.7 million lower restructuring expenses.

[0000926326-21-000013:mdna:90]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $7.8 million for the three months ended March 31, 2021 compared to the three months ended March 31, 2020. The increase was primarily due to an increase of approximately $6.7 million in employee-related expenses primarily related to increased headcount, including the incremental headcount from the 340B Link Business acquisition, as well as higher consulting expenses, partially offset by certain cost savings, including reduced travel costs, and $1.2 million lower restructuring expenses.

[0000926326-21-000013:mdna:91]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $5.9 million for the three months ended March 31, 2021 compared to the three months ended March 31, 2020, primarily driven by a $5.1 million increase in other expenses and a $0.8 million decrease in other income. The increase in other expenses during the three months ended March 31, 2021 as compared to the three months ended March 31, 2020 is primarily driven by amortization of discount and debt issuance costs as well as interest expense associated with our convertible senior notes issued in September 2020.

[0000926326-21-000013:mdna:92]
[same as prior period, unchanged from 0000926326-20-000034:mdna:100]

[0000926326-21-000013:mdna:93]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2021 |  | 2020 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (1,208) |  |  | $ | 18 |  |  | $ | (1,226) |  |  | (6,811)% |

[0000926326-21-000013:mdna:94]
Our annual effective tax rate before discrete items was 26.7% and 26.6% for the three months ended March 31, 2021 and 2020, respectively. The increase in the estimated annual effective tax rate for the three months ended March 31, 2021 compared to the same period in 2020 was primarily due to an increase in non-deductible compensation and equity charges and a decrease in foreign derived intangible income (“FDII”) benefit, partially offset by an increase in research and development credits.

[0000926326-21-000013:mdna:95]
Benefit from income taxes for the three months ended March 31, 2021 included net discrete income tax benefit of $4.7 million, primarily due to a $4.1 million tax benefit from equity compensation.

[0000926326-21-000013:mdna:96]
Provision for income taxes for the three months ended March 31, 2020 included net discrete income tax benefit of $3.0 million, primarily due to a $2.8 million tax benefit from equity compensation.

[0000926326-21-000013:mdna:97]
Refer to Note 14, Income Taxes, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q for more details.

[0000926326-21-000013:mdna:98]
[same as prior period, unchanged from 0000926326-20-000034:mdna:107]

[0000926326-21-000013:mdna:99]
We had cash and cash equivalents of $548.1 million at March 31, 2021 compared to $485.9 million at December 31, 2020. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep accounts with major financial institutions.

[0000926326-21-000013:mdna:100]
Our cash position and working capital at March 31, 2021 and December 31, 2020 were as follows:

[0000926326-21-000013:mdna:101]
|  | March 31,2021 |  | December 31,2020 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 548,055 |  |  | $ | 485,928 |  |
| Working capital | $ | 611,726 |  |  | $ | 552,991 |  |

[0000926326-21-000013:mdna:102]
Our ratio of current assets to current liabilities was 3.1:1 and 3.0:1 at March 31, 2021 and December 31, 2020, respectively.

[0000926326-21-000013:mdna:103]
[same as prior period, unchanged from 0000926326-20-000034:mdna:112]

[0000926326-21-000013:mdna:104]
Revolving Credit Facility

[0000926326-21-000013:mdna:105]
On November 15, 2019, we entered into an Amended and Restated Credit Agreement (as subsequently amended, as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded our 2016 senior secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.

[0000926326-21-000013:mdna:106]
On September 22, 2020, the parties entered into an amendment (the “Amendment”) to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions described below, expand our flexibility to repurchase our common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires us to maintain a consolidated

[0000926326-21-000013:mdna:107]
secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

[0000926326-21-000013:mdna:108]
As of March 31, 2021, there was no outstanding balance for the Revolving Credit Facility and we were in full compliance with all covenants. Refer to Note 9, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q. We expect to use future loans under the Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-21-000013:mdna:109]
[same as prior period, unchanged from 0000926326-20-000034:mdna:119]

[0000926326-21-000013:mdna:110]
On September 25, 2020, we completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. We received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted. Refer to Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q.

[0000926326-21-000013:mdna:111]
During the fourth quarter of 2020, we used approximately $49.3 million of the net proceeds from the offering to pay the cost of the convertible note hedge transactions (partially offset by the proceeds we received from the sale of the warrant transactions), approximately $53.0 million of the net proceeds to repurchase shares of our common stock from purchasers of the Notes, $150.0 million of the net proceeds to pay down outstanding borrowings under the Revolving Credit Facility, and $225.0 million for the acquisition of the 340B Link Business. We intend to use the remainder of the net proceeds from this offering for working capital and other general corporate purposes, which may include potential acquisitions, strategic transactions, and potential future repurchases of our common stock.

[0000926326-21-000013:mdna:112]
[same as prior period, unchanged from 0000926326-20-000034:mdna:127]

[0000926326-21-000013:mdna:113]
[same as prior period, unchanged from 0000926326-20-000034:mdna:128]

[0000926326-21-000013:mdna:114]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of March 31, 2021, which may result in additional use of cash. Refer to “Stock Repurchase Program” under Note 15, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q. There were no stock repurchases during the three months ended March 31, 2021 and 2020.

[0000926326-21-000013:mdna:115]
Based on our current business plan and product backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our employee stock purchase plan (“ESPP”), along with the availability of funds under the Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-21-000013:mdna:116]
[same as prior period, unchanged from 0000926326-20-000034:mdna:132]

[0000926326-21-000013:mdna:117]
[same as prior period, unchanged from 0000926326-20-000034:mdna:133]

[0000926326-21-000013:mdna:118]
|  | Three Months Ended March 31, |
|  | 2021 |  | 2020 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 57,415 |  |  | $ | 25,231 |  |
| Investing activities | (13,132) |  |  | (13,775) |  |
| Financing activities | 15,599 |  |  | (33,766) |  |
| Effect of exchange rate changes on cash and cash equivalents | (386) |  |  | (820) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | 59,496 |  |  | $ | (23,130) |  |

[0000926326-21-000013:mdna:119]
[same as prior period, unchanged from 0000926326-20-000034:mdna:135]

[0000926326-21-000013:mdna:120]
[same as prior period, unchanged from 0000926326-20-000034:mdna:136]

[0000926326-21-000013:mdna:121]
Net cash provided by operating activities was $57.4 million for the three months ended March 31, 2021, primarily consisting of net income of $14.1 million adjusted for non-cash items of $36.8 million and changes in assets and liabilities of $6.5 million. The non-cash items primarily consisted of depreciation and amortization expense of $17.6 million, share-based compensation expense of $11.8 million, amortization of operating lease right-of-use assets of $2.9 million, amortization of debt issuance costs of $0.8 million, amortization of discount on convertible senior notes of $4.6 million, and a change in deferred income taxes of $0.9 million. Changes in assets and liabilities include cash inflows from (i) an increase in deferred revenues of $21.7 million primarily due to an increase in billings driven by the timing of shipments in order to meet customers’ implementation schedules and recognition of revenues for products requiring installation, (ii) an increase in accounts payable of $10.4 million primarily due to an overall increase in spending, as well as timing of payments, (iii) an increase in accrued liabilities of $4.7 million, (iv) a decrease in other current assets of $3.1 million, (v) a decrease in prepaid commissions of $2.7 million, and (vi) a decrease in other long-term assets of $2.2 million. These cash inflows were partially offset by (i) a decrease in accrued compensation of $17.9 million primarily due to a decrease in accrued commissions and bonuses, as well as timing of ESPP purchases, (ii) an increase in accounts receivable and unbilled receivables of $15.4 million primarily due to an increase in billings driven by the timing of shipments as well as collections, (iii) a decrease in operating lease liabilities of $3.1 million, (iv) an increase in prepaid expenses of $1.1 million, and (v) an increase in inventories of $1.0 million.

[0000926326-21-000013:mdna:122]
Net cash provided by operating activities was $25.2 million for the three months ended March 31, 2020, primarily consisting of net income of $11.3 million adjusted for non-cash items of $26.5 million, offset by changes in assets and liabilities of $12.6 million. The non-cash items primarily consisted of depreciation and amortization expense of $14.0 million, share-based compensation expense of $10.7 million, amortization of operating lease right-of-use assets of $2.7 million, amortization of debt issuance costs of $0.2 million, and a change in deferred income taxes of $1.1 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $16.1 million primarily due to an increase in billings late in the quarter as well as timing of collections, (ii) a decrease in accrued compensation of $9.2 million primarily due to a decrease in accrued commissions and bonuses, as well as timing of payroll and ESPP purchases, (iii) an increase in inventories of $5.7 million to support higher production for forecasted sales and to fulfill order backlog, (iv) an increase in other long-term assets of $2.8 million; and (v) a decrease in operating lease liabilities of $2.8 million. These cash outflows were partially offset by (i) an increase in deferred revenues of $16.9 million primarily due to the timing of order shipments and recognition of revenues for product requiring installation, (ii) a decrease in prepaid commissions of $2.9 million, (iii) an increase in accrued liabilities of $2.7 million, and (iv) a decrease in other current assets of $1.0 million.

[0000926326-21-000013:mdna:123]
[same as prior period, unchanged from 0000926326-20-000034:mdna:140]

[0000926326-21-000013:mdna:124]
Net cash used in investing activities was $13.1 million for the three months ended March 31, 2021, which consisted of capital expenditures of $5.1 million for property and equipment, and $8.0 million for costs of software development for external use.

[0000926326-21-000013:mdna:125]
Net cash used in investing activities was $13.8 million for the three months ended March 31, 2020, which consisted of capital expenditures of $3.2 million for property and equipment, and $10.6 million for costs of software development for external use.

[0000926326-21-000013:mdna:126]
[same as prior period, unchanged from 0000926326-20-000034:mdna:143]

[0000926326-21-000013:mdna:127]
Net cash provided by financing activities was $15.6 million for the three months ended March 31, 2021, primarily due to $20.8 million in proceeds from employee stock option exercises and ESPP purchases, partially offset by $2.6 million in employees’ taxes paid related to restricted stock unit vesting, and a net decrease in the customer funds balances of $2.6 million.

[0000926326-21-000013:mdna:128]
Net cash used in financing activities was $33.8 million for the three months ended March 31, 2020, primarily due to the repayment of $50.0 million under the Revolving Credit Facility and $1.4 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $17.7 million in proceeds from employee stock option exercises and ESPP purchases.

[0000926326-21-000013:mdna:129]
[same as prior period, unchanged from 0000926326-20-000034:mdna:146]

[0000926326-21-000013:mdna:130]
There have been no significant changes during the three months ended March 31, 2021 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2020.

[0000926326-21-000013:mdna:131]
Contractual obligations as of March 31, 2021 were as follows:

[0000926326-21-000013:mdna:132]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2021 |  | 2022 - 2023 |  | 2024 - 2025 |  | 2026 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 68,145 |  |  | $ | 11,305 |  |  | $ | 24,287 |  |  | $ | 15,260 |  |  | $ | 17,293 |  |
| Purchase obligations (2) | 82,829 |  |  | 78,848 |  |  | 3,378 |  |  | 560 |  |  | 43 |  |
| Convertible senior notes (3) | 581,469 |  |  | 719 |  |  | 2,875 |  |  | 577,875 |  |  | — |  |
| Total (4) | $ | 732,443 |  |  | $ | 90,872 |  |  | $ | 30,540 |  |  | $ | 593,695 |  |  | $ | 17,336 |  |

[0000926326-21-000013:mdna:133]
_________________________________________________

[0000926326-21-000013:mdna:134]
(1)Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 12, Lessee Leases, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q.

[0000926326-21-000013:mdna:135]
[same as prior period, unchanged from 0000926326-20-000034:mdna:152]

[0000926326-21-000013:mdna:136]
(3)We issued convertible senior notes in September 2020 that are due in September 2025. The obligations presented above include both principal and interest for these notes. Although these notes mature in 2025, they may be converted into cash and shares of our common stock prior to maturity if certain conditions are met. Any conversion prior to maturity can result in repayment of the principal amounts sooner than the scheduled repayment as indicated in the table above. Refer to Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q.

[0000926326-21-000013:mdna:137]
(4)Refer to Note 13, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report on Form 10-Q.

[0000926326-21-000013:mdna:138]
[same as prior period, unchanged from 0000926326-20-000034:mdna:155]

[0000926326-21-000013:mdna:139]
As of March 31, 2021, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Exchange Act and the instructions thereto.
