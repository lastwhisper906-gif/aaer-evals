# OMCL 8-K — 0000926326-21-000011 filed 2021-04-29

## item codes, every 8-K on or before 2021-05-04

- 2021-04-29 0000926326-21-000011 — 2.02, 9.01
- 2021-02-01 0000926326-21-000004 — 2.02, 9.01
- 2021-01-26 0000926326-21-000002 — 5.02
- 2021-01-13 0001104659-21-003672 — 2.02, 7.01, 9.01
- 2020-10-27 0000926326-20-000032 — 2.02, 9.01
- 2020-10-01 0000926326-20-000029 — 7.01, 9.01
- 2020-09-25 0001104659-20-108924 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2020-09-22 0001104659-20-107176 — 1.01, 8.01, 9.01
- 2020-08-12 0000926326-20-000027 — 2.03
- 2020-08-12 0000926326-20-000025 — 1.01, 5.03, 7.01, 9.01
- 2020-07-28 0000926326-20-000021 — 2.02, 9.01
- 2020-05-27 0000926326-20-000017 — 5.07
- 2020-05-07 0000926326-20-000012 — 2.02, 9.01
- 2020-02-18 0000926326-20-000007 — 5.02, 9.01
- 2020-02-13 0000926326-20-000005 — 8.01
- 2020-02-06 0000926326-20-000003 — 2.02, 9.01
- 2019-12-06 0001104659-19-070339 — 8.01
- 2019-11-18 0000926326-19-000035 — 1.01, 2.03, 9.01
- 2019-10-24 0000926326-19-000028 — 2.02, 9.01
- 2019-07-25 0000926326-19-000021 — 2.02, 9.01
- 2019-05-15 0000926326-19-000015 — 5.07
- 2019-04-25 0000926326-19-000011 — 2.02, 9.01
- 2019-03-08 0000926326-19-000009 — 5.02, 9.01
- 2019-02-19 0000926326-19-000005 — 5.02, 9.01
- 2019-02-07 0000926326-19-000003 — 2.02, 9.01
- 2018-10-25 0000926326-18-000028 — 2.02, 9.01
- 2018-09-14 0001104659-18-056929 — 5.02, 9.01
- 2018-07-26 0000926326-18-000022 — 2.02, 9.01
- 2018-06-06 0000926326-18-000019 — 5.02, 9.01
- 2018-05-16 0001104659-18-033801 — 5.07
- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2021-05-04

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-21-000011:8k_2_02:1]
EX-99.1
2
exhibit991q1-21.htm
EX-99.1

[0000926326-21-000011:8k_2_02:2]
Document

[0000926326-21-000011:8k_2_02:3]
Exhibit 99.1

[0000926326-21-000011:8k_2_02:4]
| Contact: |  |  |
| Kathleen Nemeth |  | Omnicell, Inc. |
| Vice President, Investor Relations |  | 590 East Middlefield Road |
| 650-435-3318 |  | Mountain View, CA 94043 |
| Kathleen.Nemeth@Omnicell.com |  |  |

[0000926326-21-000011:8k_2_02:5]
Omnicell Announces Financial Results for First Quarter 2021

[0000926326-21-000011:8k_2_02:6]
Record revenues of $252 million, an increase of 10% from the prior year period

[0000926326-21-000011:8k_2_02:7]
GAAP net income per diluted share of $0.30, Non-GAAP net income per diluted share of $0.83

[0000926326-21-000011:8k_2_02:8]
Added new long-term, sole-source partnership agreements with Top 300 U.S. Health Systems

[0000926326-21-000011:8k_2_02:9]
MOUNTAIN VIEW, Calif. -- April 29, 2021 -- Omnicell, Inc. (NASDAQ:OMCL), a leading provider of medication management solutions and adherence tools for healthcare systems and pharmacies, today announced results for its first quarter ended March 31, 2021.

[0000926326-21-000011:8k_2_02:10]
GAAP Results

[0000926326-21-000011:8k_2_02:11]
Total revenues for the first quarter of 2021 were $251.8 million, up $22.2 million, or 9.6%, from the first quarter of 2020.

[0000926326-21-000011:8k_2_02:12]
First quarter 2021 GAAP net income was $14.1 million, or $0.30 per diluted share. This compares to GAAP net income of $11.3 million, or $0.26 per diluted share, for the first quarter of 2020.

[0000926326-21-000011:8k_2_02:13]
Non-GAAP Results

[0000926326-21-000011:8k_2_02:14]
Non-GAAP net income for the first quarter of 2021 was $37.5 million, or $0.83 per diluted share. This compares to non-GAAP net income of $28.9 million, or $0.66 per diluted share, for the first quarter of 2020.

[0000926326-21-000011:8k_2_02:15]
Non-GAAP net income for each period excludes, when applicable, the effect of share-based compensation expense, amortization expense of acquired intangible assets, restructuring and severance-related expenses, amortization of debt issuance costs, amortization of discount on convertible senior notes, and certain litigation costs.

[0000926326-21-000011:8k_2_02:16]
“We delivered an exceptionally strong first quarter, exceeding our first quarter guidance and achieving record revenue for the quarter,” said Randall Lipps, Chairman, President, Chief Executive Officer, and founder of Omnicell. “We continue to make tremendous progress advancing the vision of the autonomous pharmacy, and we continue to see robust and growing demand for our solutions as providers work to optimize and automate pharmacy workflows in response to the evolving healthcare landscape. Underscoring our momentum, we were pleased to increase the number of long-term, sole-source agreements with top 300 U.S. health systems. We are also very pleased with the strong reception of our Advanced Services portfolio during the quarter. We remain focused on supporting our healthcare systems partners on their journey to the Autonomous Pharmacy, driving growth and creating value for our shareholders, partners, and the communities we serve.”

[0000926326-21-000011:8k_2_02:17]
2021 Guidance

[0000926326-21-000011:8k_2_02:18]
For the second quarter of 2021, the Company expects total revenues to be between $265 million and $270 million. The Company expects product revenues to be between $192 million and $195 million, and service revenues to be between $73 million and $75 million. The Company expects second quarter 2021 non-GAAP EBITDA to be between $53 million and $56 million. The Company expects second quarter 2021 non-GAAP earnings to be between $0.80 and $0.85 per share.

[0000926326-21-000011:8k_2_02:19]
For the full year 2021, the Company expects product bookings to be between $1.090 billion and $1.150 billion. The Company expects total revenues to be between $1.085 billion and $1.105 billion. The Company expects product revenues to be between $770 million and $785 million, and service revenues to be between $315 million and $320 million. The Company expects 2021

[0000926326-21-000011:8k_2_02:20]
non-GAAP EBITDA to be between $231 million and $243 million. The Company expects 2021 non-GAAP earnings to be between $3.50 and $3.70 per share.

[0000926326-21-000011:8k_2_02:21]
The table below summarizes Omnicell’s 2021 guidance outlined above.

[0000926326-21-000011:8k_2_02:22]
|  | Q2 2021 | 2021 |
| Product Bookings | Not provided | $1.090 billion - $1.150 billion |
| Total Revenues | $265 million - $270 million | $1.085 billion - $1.105 billion |
| Product Revenues | $192 million - $195 million | $770 million - $785 million |
| Service Revenues | $73 million - $75 million | $315 million - $320 million |
| Non-GAAP EBITDA | $53 million - $56 million | $231 million - $243 million |
| Non-GAAP Earnings Per Share | $0.80 - $0.85 | $3.50 - $3.70 |

[0000926326-21-000011:8k_2_02:23]
The Company does not provide guidance for GAAP net income or GAAP earnings per share nor a reconciliation of forward-looking non-GAAP financial measures to the most directly comparable GAAP financial measures on a forward-looking basis because it is unable to predict certain items contained in the GAAP measures without unreasonable efforts. These non-GAAP financial measures do not include certain items, which may be significant, including, but not limited to, unusual gains and losses, costs associated with future restructurings, acquisition-related expenses, and certain tax and litigation outcomes.

[0000926326-21-000011:8k_2_02:24]
Omnicell Conference Call Information

[0000926326-21-000011:8k_2_02:25]
Omnicell will hold a conference call today, Thursday, April 29, 2021 at 1:30 p.m. PT to discuss first quarter 2021 financial results. The conference call can be monitored by dialing 1-855-451-1210 within the U.S. or 1-236-714-3867 for all other locations. The Conference ID # is 9828247. A link to the live and archived webcast will also be available on the Investor Relations section of Omnicell's website at http://ir.omnicell.com/events-and-presentations/.

[0000926326-21-000011:8k_2_02:26]
About Omnicell

[0000926326-21-000011:8k_2_02:27]
Since 1992, Omnicell has been committed to transforming the pharmacy care delivery model to dramatically improve outcomes and lower costs. Through the vision of the autonomous pharmacy, a combination of automation, intelligence, and technology-enabled services, powered by a cloud data platform, Omnicell supports more efficient ways to manage medications across all care settings.

[0000926326-21-000011:8k_2_02:28]
Over 7,000 facilities worldwide use Omnicell automation and analytics solutions to help increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. More than 50,000 institutional and retail pharmacies across North America and the United Kingdom leverage Omnicell's innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-21-000011:8k_2_02:29]
To learn more, visit www.omnicell.com. From time to time, Omnicell may use the Company's investor relations site and other online social media channels, including its Twitter handle www.twitter.com/omnicell, LinkedIn page www.linkedin.com/company/omnicell, and Facebook page www.facebook.com/omnicellinc, to disclose material non-public information and comply with its disclosure obligations under Regulation Fair Disclosure (“FD”).

[0000926326-21-000011:8k_2_02:30]
Omnicell is a registered trademark and the Omnicell logo is a trademark of Omnicell, Inc. in the United States and other countries.

[0000926326-21-000011:8k_2_02:31]
Forward-Looking Statements

[0000926326-21-000011:8k_2_02:32]
general economic and market conditions, including due to economic disruption caused by public health crises such as the COVID-19 pandemic, (iii) Omnicell's ability to take advantage of the growth opportunities in medication management across all care settings, (iv) Omnicell's ability to develop and commercialize new products and enhance existing products, (v) Omnicell's ability to deliver on the vision of the autonomous pharmacy and the impact that advanced automation, data intelligence, and expert services will have on patient care, (vi) risks to growth and acceptance of Omnicell's products and services, including competitive conversions, and growth in the overall demand for medication management and supply chain solutions and medication adherence solutions generally, (vii) risks presented by the transition to selling more products and services on a subscription basis, (viii) potential increased competition, (ix) potential regulatory changes, (x) Omnicell's ability to improve sales productivity to grow product bookings, (xi) Omnicell's ability to acquire companies, businesses, or technologies and successfully integrate such acquisitions, and (xii) other risks and uncertainties described in the Risk Factors section of Omnicell’s most recent annual report on Form 10-K and quarterly report on Form 10-Q, filed with the United States Securities and Exchange Commission (“SEC”). Forward-looking statements should be considered in light of these risks and uncertainties. Investors are cautioned not to place undue reliance on forward-looking statements. All forward-looking statements contained in this press release speak only as of the date of this press release. Omnicell undertakes no obligation to update such statements, whether as a result of changed circumstances, new information, future events, or otherwise, except as required by law.

[0000926326-21-000011:8k_2_02:33]
Use of Non-GAAP Financial Information

[0000926326-21-000011:8k_2_02:34]
This press release contains financial measures that are not calculated in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”). Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP diluted shares, non-GAAP EBITDA, non-GAAP EBITDA margin, and non-GAAP free cash flow. These non-GAAP results and metrics should not be considered as an alternative to gross profit, operating expenses, income from operations, net income, net income per diluted share, diluted shares, net cash provided by operating activities, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results and metrics because management considers them to be important supplemental measures of Omnicell’s performance and refers to such measures when analyzing Omnicell's strategy and operations.

[0000926326-21-000011:8k_2_02:35]
Our non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period-to-period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we believe we should invest in research and development, fund infrastructure growth, and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, non-GAAP gross profit and non-GAAP gross margin exclude from their GAAP equivalents items a), b), and c) below; non-GAAP operating expenses, non-GAAP operating margin, and non-GAAP income from operations exclude from their GAAP equivalents items a), b), c), f), and g) below; and non-GAAP net income and non-GAAP net income per diluted share exclude from their GAAP equivalents items a) through g) below. Non-GAAP EBITDA is defined as earnings before interest income and expense, taxes, depreciation, and amortization. Non-GAAP EBITDA and non-GAAP EBITDA margin exclude from their GAAP equivalents items a), c), d), e), f), and g) below:

[0000926326-21-000011:8k_2_02:36]
a)Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-21-000011:8k_2_02:37]
b)Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-21-000011:8k_2_02:38]
c)Severance-related expenses. We excluded from our non-GAAP results the expenses which are related to restructuring events. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-21-000011:8k_2_02:39]
d)Amortization of debt issuance costs. Debt issuance costs represent costs associated with the issuance of term loan and revolving credit facilities, as well as the issuance of convertible senior notes. The costs include underwriting fees,

[0000926326-21-000011:8k_2_02:40]
original issue discount, ticking fees, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-21-000011:8k_2_02:41]
e)Amortization of discount on convertible senior notes. We excluded from our non-GAAP results the amortization of the imputed discount on our convertible senior notes. Under GAAP, certain convertible debt instruments that may be settled in cash upon conversion are required to be bifurcated into separate liability and equity components in a manner that reflects the issuer's assumed non-convertible debt borrowing rate. For GAAP purposes, we are required to recognize the imputed interest expense on the difference between our assumed non-convertible debt borrowing rate and the coupon rate on our convertible senior notes. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-21-000011:8k_2_02:42]
f)Intellectual property ("IP") and legal entities restructuring costs. We excluded from our non-GAAP results the expenses which are related to IP and legal entities restructuring events, such as legal and tax consulting costs. These expenses are unrelated to our ongoing operations, vary in size and frequency, and are subject to significant fluctuations from period to period due to varying levels of restructuring activity. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-21-000011:8k_2_02:43]
g)Certain litigation costs. We exclude non-recurring charges and benefits, including litigation expenses and settlements, related to litigation matters that are outside of the ordinary course of our business or that are not representative of those that we historically have incurred. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance, and to the financial results of peer companies.

[0000926326-21-000011:8k_2_02:44]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans or other items.

[0000926326-21-000011:8k_2_02:45]
We believe that the presentation of non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP EBITDA, and non-GAAP EBITDA margin is warranted for several reasons:

[0000926326-21-000011:8k_2_02:46]
a)Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business.

[0000926326-21-000011:8k_2_02:47]
b)Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods.

[0000926326-21-000011:8k_2_02:48]
c)These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision-making processes, such as budget planning and forecasting.

[0000926326-21-000011:8k_2_02:49]
d)These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which also use non-GAAP financial measures to supplement their GAAP results (although these companies may calculate non-GAAP financial measures differently than Omnicell does), thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-21-000011:8k_2_02:50]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-21-000011:8k_2_02:51]
i)While share-based compensation calculated in accordance with Accounting Standards Codification (“ASC”) 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of share-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-21-000011:8k_2_02:52]
ii)We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties, the tax effect related

[0000926326-21-000011:8k_2_02:53]
to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-21-000011:8k_2_02:54]
Non-GAAP diluted shares is defined as our GAAP diluted shares, excluding the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction. We believe non-GAAP diluted shares is a useful non-GAAP metric because it provides insight into the offsetting economic effect of the hedge transaction against potential conversion of the convertible senior notes.

[0000926326-21-000011:8k_2_02:55]
Non-GAAP free cash flow is defined as net cash provided by operating activities less cash used for software development for external use and purchases of property and equipment. We believe free cash flow is important to enable investors to better understand and evaluate our ongoing operating results and allows for greater transparency in the review and understanding of our overall financial, operational, and economic performance, because free cash flow takes into account certain capital expenditures and cash used for software development necessary to operate our business.

[0000926326-21-000011:8k_2_02:56]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-21-000011:8k_2_02:57]
a)Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718.

[0000926326-21-000011:8k_2_02:58]
b)Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure.

[0000926326-21-000011:8k_2_02:59]
c)A limitation of the utility of free cash flow as a measure of financial performance is that it does not represent the total increase or decrease in Omnicell’s cash balance for the period.

[0000926326-21-000011:8k_2_02:60]
A detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-21-000011:8k_2_02:61]
Omnicell, Inc.

[0000926326-21-000011:8k_2_02:62]
Condensed Consolidated Statements of Operations

[0000926326-21-000011:8k_2_02:63]
(Unaudited, in thousands, except per share data)

[0000926326-21-000011:8k_2_02:64]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Revenues: |  |  |  |  |  |  |  |
| Product revenues | $ | 178,125 |  |  | $ | 170,073 |  |  |  |  |  |
| Services and other revenues | 73,718 |  |  | 59,613 |  |  |  |  |  |
| Total revenues | 251,843 |  |  | 229,686 |  |  |  |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | 92,627 |  |  | 90,272 |  |  |  |  |  |
| Cost of services and other revenues | 36,933 |  |  | 29,792 |  |  |  |  |  |
| Total cost of revenues | 129,560 |  |  | 120,064 |  |  |  |  |  |
| Gross profit | 122,283 |  |  | 109,622 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 16,080 |  |  | 18,652 |  |  |  |  |  |
| Selling, general, and administrative | 86,593 |  |  | 78,819 |  |  |  |  |  |
| Total operating expenses | 102,673 |  |  | 97,471 |  |  |  |  |  |
| Income from operations | 19,610 |  |  | 12,151 |  |  |  |  |  |
| Interest and other income (expense), net | (6,691) |  |  | (822) |  |  |  |  |  |
| Income before provision for income taxes | 12,919 |  |  | 11,329 |  |  |  |  |  |
| Provision for (benefit from) income taxes | (1,208) |  |  | 18 |  |  |  |  |  |
| Net income | $ | 14,127 |  |  | $ | 11,311 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.33 |  |  | $ | 0.27 |  |  |  |  |  |
| Diluted | $ | 0.30 |  |  | $ | 0.26 |  |  |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |
| Basic | 42,962 |  |  | 42,357 |  |  |  |  |  |
| Diluted | 46,367 |  |  | 43,621 |  |  |  |  |  |

[0000926326-21-000011:8k_2_02:65]
6

[0000926326-21-000011:8k_2_02:66]
Omnicell, Inc.

[0000926326-21-000011:8k_2_02:67]
Condensed Consolidated Balance Sheets

[0000926326-21-000011:8k_2_02:68]
(Unaudited, in thousands)

[0000926326-21-000011:8k_2_02:69]
|  | March 31,2021 |  | December 31,2020 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 548,055 |  |  | $ | 485,928 |  |
| Accounts receivable and unbilled receivables, net | 205,658 |  |  | 190,117 |  |
| Inventories | 96,208 |  |  | 96,298 |  |
| Prepaid expenses | 17,122 |  |  | 16,027 |  |
| Other current assets | 36,956 |  |  | 41,044 |  |
| Total current assets | 903,999 |  |  | 829,414 |  |
| Property and equipment, net | 60,538 |  |  | 59,073 |  |
| Long-term investment in sales-type leases, net | 21,255 |  |  | 22,156 |  |
| Operating lease right-of-use assets | 51,922 |  |  | 55,114 |  |
| Goodwill | 499,065 |  |  | 499,309 |  |
| Intangible assets, net | 161,816 |  |  | 168,211 |  |
| Long-term deferred tax assets | 15,376 |  |  | 15,019 |  |
| Prepaid commissions | 54,209 |  |  | 56,919 |  |
| Other long-term assets | 118,443 |  |  | 119,289 |  |
| Total assets | $ | 1,886,623 |  |  | $ | 1,824,504 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 50,759 |  |  | $ | 40,309 |  |
| Accrued compensation | 37,851 |  |  | 55,750 |  |
| Accrued liabilities | 84,075 |  |  | 80,311 |  |
| Deferred revenues, net | 119,588 |  |  | 100,053 |  |
| Total current liabilities | 292,273 |  |  | 276,423 |  |
| Long-term deferred revenues | 7,887 |  |  | 5,673 |  |
| Long-term deferred tax liabilities | 39,128 |  |  | 39,633 |  |
| Long-term operating lease liabilities | 45,435 |  |  | 48,897 |  |
| Other long-term liabilities | 18,542 |  |  | 19,174 |  |
| Convertible senior notes, net | 472,347 |  |  | 467,201 |  |
| Total liabilities | 875,612 |  |  | 857,001 |  |
| Total stockholders’ equity | 1,011,011 |  |  | 967,503 |  |
| Total liabilities and stockholders’ equity | $ | 1,886,623 |  |  | $ | 1,824,504 |  |

[0000926326-21-000011:8k_2_02:70]
Omnicell, Inc.

[0000926326-21-000011:8k_2_02:71]
Condensed Consolidated Statements of Cash Flows

[0000926326-21-000011:8k_2_02:72]
(Unaudited, in thousands)

[0000926326-21-000011:8k_2_02:73]
|  | Three Months Ended March 31, |
|  | 2021 |  | 2020 |
| Operating Activities |  |  |  |
| Net income | $ | 14,127 |  |  | $ | 11,311 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 17,575 |  |  | 14,043 |  |
| Share-based compensation expense | 11,772 |  |  | 10,659 |  |
| Deferred income taxes | (862) |  |  | (1,149) |  |
| Amortization of operating lease right-of-use assets | 2,895 |  |  | 2,682 |  |
| Amortization of debt issuance costs | 849 |  |  | 241 |  |
| Amortization of discount on convertible senior notes | 4,571 |  |  | — |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable and unbilled receivables | (15,427) |  |  | (16,052) |  |
| Inventories | (1,035) |  |  | (5,734) |  |
| Prepaid expenses | (1,095) |  |  | 323 |  |
| Other current assets | 3,128 |  |  | 968 |  |
| Investment in sales-type leases | 925 |  |  | (268) |  |
| Prepaid commissions | 2,710 |  |  | 2,881 |  |
| Other long-term assets | 2,177 |  |  | (2,844) |  |
| Accounts payable | 10,368 |  |  | 208 |  |
| Accrued compensation | (17,899) |  |  | (9,165) |  |
| Accrued liabilities | 4,661 |  |  | 2,734 |  |
| Deferred revenues | 21,749 |  |  | 16,868 |  |
| Operating lease liabilities | (3,142) |  |  | (2,784) |  |
| Other long-term liabilities | (632) |  |  | 309 |  |
| Net cash provided by operating activities | 57,415 |  |  | 25,231 |  |
| Investing Activities |  |  |  |
| Software development for external use | (8,043) |  |  | (10,602) |  |
| Purchases of property and equipment | (5,089) |  |  | (3,173) |  |
| Net cash used in investing activities | (13,132) |  |  | (13,775) |  |
| Financing Activities |  |  |  |
| Repayment of revolving credit facility | — |  |  | (50,000) |  |
| Proceeds from issuances under stock-based compensation plans | 20,826 |  |  | 17,659 |  |
| Employees’ taxes paid related to restricted stock units | (2,596) |  |  | (1,425) |  |
| Change in customer funds, net | (2,631) |  |  | — |  |
| Net cash provided by (used in) financing activities | 15,599 |  |  | (33,766) |  |
| Effect of exchange rate changes on cash and cash equivalents | (386) |  |  | (820) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | 59,496 |  |  | (23,130) |  |
| Cash, cash equivalents, and restricted cash at beginning of period | 489,920 |  |  | 127,210 |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 549,416 |  |  | $ | 104,080 |  |
| Reconciliation of cash, cash equivalents, and restricted cash to the Condensed Consolidated Balance Sheets: |
| Cash and cash equivalents | $ | 548,055 |  |  | $ | 104,080 |  |
| Restricted cash included in Other current assets | 1,361 |  |  | — |  |
| Cash, cash equivalents, and restricted cash at end of period | $ | 549,416 |  |  | $ | 104,080 |  |

[0000926326-21-000011:8k_2_02:74]
8

[0000926326-21-000011:8k_2_02:75]
Omnicell, Inc.

[0000926326-21-000011:8k_2_02:76]
Reconciliation of GAAP to Non-GAAP

[0000926326-21-000011:8k_2_02:77]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-21-000011:8k_2_02:78]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |  |  |  |
| GAAP gross profit | $ | 122,283 |  |  | $ | 109,622 |  |  |  |  |  |
| GAAP gross margin | 48.6% |  | 47.7% |  |  |  |  |
| Share-based compensation expense | 1,937 |  |  | 1,770 |  |  |  |  |  |
| Amortization of acquired intangibles | 2,816 |  |  | 2,035 |  |  |  |  |  |
| Severance-related expenses | 389 |  |  | 75 |  |  |  |  |  |
| Non-GAAP gross profit | $ | 127,425 |  |  | $ | 113,502 |  |  |  |  |  |
| Non-GAAP gross margin | 50.6% |  | 49.4% |  |  |  |  |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |  |  |  |  |
| GAAP operating expenses | $ | 102,673 |  |  | $ | 97,471 |  |  |  |  |  |
| GAAP operating expenses % to total revenues | 40.8% |  | 42.4% |  |  |  |  |
| Share-based compensation expense | (9,835) |  |  | (8,889) |  |  |  |  |  |
| Amortization of acquired intangibles | (3,456) |  |  | (2,395) |  |  |  |  |  |
| Severance-related and other expenses (a) | (2,582) |  |  | (4,026) |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 86,800 |  |  | $ | 82,161 |  |  |  |  |  |
| Non-GAAP operating expenses % to total revenues | 34.5% |  | 35.8% |  |  |  |  |
| Reconciliation of GAAP income from operations to non-GAAP income from operations: |
| GAAP income from operations | $ | 19,610 |  |  | $ | 12,151 |  |  |  |  |  |
| GAAP operating income % to total revenues | 7.8% |  | 5.3% |  |  |  |  |
| Share-based compensation expense | 11,772 |  |  | 10,659 |  |  |  |  |  |
| Amortization of acquired intangibles | 6,272 |  |  | 4,430 |  |  |  |  |  |
| Severance-related and other expenses (a) | 2,971 |  |  | 4,101 |  |  |  |  |  |
| Non-GAAP income from operations | $ | 40,625 |  |  | $ | 31,341 |  |  |  |  |  |
| Non-GAAP operating margin (non-GAAP operating income % to total revenues) | 16.1% |  | 13.6% |  |  |  |  |

[0000926326-21-000011:8k_2_02:79]
Omnicell, Inc.

[0000926326-21-000011:8k_2_02:80]
Reconciliation of GAAP to Non-GAAP

[0000926326-21-000011:8k_2_02:81]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-21-000011:8k_2_02:82]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Reconciliation of GAAP net income to non-GAAP net income: |
| GAAP net income | $ | 14,127 |  |  | $ | 11,311 |  |  |  |  |  |
| Share-based compensation expense | 11,772 |  |  | 10,659 |  |  |  |  |  |
| Amortization of acquired intangibles | 6,272 |  |  | 4,430 |  |  |  |  |  |
| Severance-related and other expenses (a) | 2,971 |  |  | 4,101 |  |  |  |  |  |
| Amortization of debt issuance costs | 849 |  |  | 241 |  |  |  |  |  |
| Amortization of discount on convertible senior notes | 4,571 |  |  | — |  |  |  |  |  |
| Tax effect of the adjustments above (b) | (3,079) |  |  | (1,842) |  |  |  |  |  |
| Non-GAAP net income | $ | 37,483 |  |  | $ | 28,900 |  |  |  |  |  |
| Reconciliation of GAAP net income per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 46,367 |  |  | 43,621 |  |  |  |  |  |
| Dilution offset from convertible note hedge transaction (c) | (1,425) |  |  | — |  |  |  |  |  |
| Shares - diluted non-GAAP | 44,942 |  |  | 43,621 |  |  |  |  |  |
| GAAP net income per share - diluted | $ | 0.30 |  |  | $ | 0.26 |  |  |  |  |  |
| Share-based compensation expense | 0.27 |  |  | 0.24 |  |  |  |  |  |
| Amortization of acquired intangibles | 0.14 |  |  | 0.10 |  |  |  |  |  |
| Severance-related and other expenses | 0.07 |  |  | 0.09 |  |  |  |  |  |
| Amortization of debt issuance costs | 0.02 |  |  | 0.01 |  |  |  |  |  |
| Amortization of discount on convertible senior notes | 0.10 |  |  | — |  |  |  |  |  |
| Tax effect of the adjustments above (b) | (0.07) |  |  | (0.04) |  |  |  |  |  |
| Non-GAAP net income per share - diluted | $ | 0.83 |  |  | $ | 0.66 |  |  |  |  |  |
| Reconciliation of GAAP net income to non-GAAP EBITDA(d): |
| GAAP net income | $ | 14,127 |  |  | $ | 11,311 |  |  |  |  |  |
| Share-based compensation expense | 11,772 |  |  | 10,659 |  |  |  |  |  |
| Interest (income) and expense, net | (30) |  |  | (14) |  |  |  |  |  |
| Depreciation and amortization expense | 17,575 |  |  | 14,043 |  |  |  |  |  |
| Severance-related and other expenses | 2,971 |  |  | 4,101 |  |  |  |  |  |
| Amortization of debt issuance costs | 849 |  |  | 241 |  |  |  |  |  |
| Amortization of discount on convertible senior notes | 4,571 |  |  | — |  |  |  |  |  |
| Income tax expense (benefit) | (1,208) |  |  | 18 |  |  |  |  |  |
| Non-GAAP EBITDA | $ | 50,627 |  |  | $ | 40,359 |  |  |  |  |  |
| Non-GAAP EBITDA margin (non-GAAP EBITDA % to total revenues) | 20.1% |  | 17.6% |  |  |  |  |

[0000926326-21-000011:8k_2_02:83]
_________________________________________________

[0000926326-21-000011:8k_2_02:84]
(a)For the three months ended March 31, 2021, other expenses included approximately $1.0 million of certain litigation costs. For the three months ended March 31, 2020, other expenses included approximately $0.5 million of IP and legal entities restructuring costs.

[0000926326-21-000011:8k_2_02:85]
(b)Tax effects calculated for all adjustments except share-based compensation expense, using an estimated annual effective tax rate of 21% for both fiscal years 2021 and 2020.

[0000926326-21-000011:8k_2_02:86]
(c)Non-GAAP diluted shares exclude the impact of dilutive convertible senior notes for which the Company is economically hedged through its anti-dilutive convertible note hedge transaction.

[0000926326-21-000011:8k_2_02:87]
(d)Defined as earnings before interest income and expense, taxes, depreciation, amortization, share-based compensation, as well as excluding certain non-GAAP adjustments.

[0000926326-21-000011:8k_2_02:88]
Omnicell, Inc.

[0000926326-21-000011:8k_2_02:89]
Reconciliation of GAAP to Non-GAAP

[0000926326-21-000011:8k_2_02:90]
(Unaudited, in thousands)

[0000926326-21-000011:8k_2_02:91]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  |  |  | 2020 |  |  |  |  |
| Reconciliation of GAAP net cash provided by operating activities to non-GAAP free cash flow: |
| GAAP net cash provided by operating activities | $ | 57,415 |  |  |  |  | $ | 25,231 |  |  |  |  |  |
| Software development for external use | (8,043) |  |  |  |  | (10,602) |  |  |  |  |  |
| Purchases of property and equipment | (5,089) |  |  |  |  | (3,173) |  |  |  |  |  |
| Non-GAAP free cash flow | $ | 44,283 |  |  |  |  | $ | 11,456 |  |  |  |  |  |

[0000926326-21-000011:8k_2_02:92]
11
