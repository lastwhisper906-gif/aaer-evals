# OMCL MD&A — 0000926326-18-000015


## mdna

[0000926326-18-000015:mdna:1]
[same as prior period, unchanged from 0000926326-17-000038:mdna:1]

[0000926326-18-000015:mdna:2]
[same as prior period, unchanged from 0000926326-17-000038:mdna:2]

[0000926326-18-000015:mdna:3]
This quarterly report on Form 10-Q contains forward-looking statements. The forward-looking statements are contained principally in the sections entitled “Risk Factors” and “Management's Discussion and Analysis of Financial Condition and Results of Operations.” Forward-looking statements include, but are not limited to, statements about:

[0000926326-18-000015:mdna:4]
[same as prior period, unchanged from 0000926326-17-000038:mdna:3]

[0000926326-18-000015:mdna:5]
| • | the extent and timing of future revenues, including the amounts of our current backlog; |

[0000926326-18-000015:mdna:6]
[same as prior period, unchanged from 0000926326-17-000038:mdna:6]

[0000926326-18-000015:mdna:7]
[same as prior period, unchanged from 0000926326-17-000038:mdna:4]

[0000926326-18-000015:mdna:8]
| • | our continued investment in, and ability to deliver on, our key business strategies of developing differentiated solutions, increasing penetration of new markets, and expanding our solutions through acquisitions and partnerships; |

[0000926326-18-000015:mdna:9]
| • | our ability to deliver on our goals of advancing our platform with new product introductions annually, producing solutions that support fully automated central pharmacy operations and helping to lead the digital healthcare transformation with solutions that meet customer needs; |

[0000926326-18-000015:mdna:10]
| • | our belief that continued investment in our key business strategies will continue to generate our revenue and earnings growth, as well as our expectations about the trends and other factors we believe will be critical to the success of our strategies; |

[0000926326-18-000015:mdna:11]
| • | the bookings, revenue and margin opportunity presented by new products, emerging markets and international markets; |

[0000926326-18-000015:mdna:12]
[same as prior period, unchanged from 0000926326-17-000038:mdna:8]

[0000926326-18-000015:mdna:13]
[same as prior period, unchanged from 0000926326-17-000038:mdna:9]

[0000926326-18-000015:mdna:14]
| • | our ability to protect our intellectual property and operate our business without infringing upon the intellectual property rights of others; |

[0000926326-18-000015:mdna:15]
| • | our expected future uses of cash and the sufficiency of our sources of funding; |

[0000926326-18-000015:mdna:16]
| • | the expected impacts of new accounting standards or changes to existing accounting standards; |

[0000926326-18-000015:mdna:17]
| • | the impacts of the U.S. Tax Cuts and Jobs Act of 2017; and |

[0000926326-18-000015:mdna:18]
[same as prior period, unchanged from 0000926326-17-000038:mdna:11]

[0000926326-18-000015:mdna:19]
In some cases, you can identify forward-looking statements by terms such as "anticipates," "believes," "could," "estimates," "expects," "intends," "seeks," "may," "plans," "potential," "predicts," "projects," "should," "will," "would" and variations of these terms and similar expressions. Forward-looking statements are based on our current expectations and

[0000926326-18-000015:mdna:20]
24

[0000926326-18-000015:mdna:21]
assumptions and are subject to known and unknown risks and uncertainties, which may cause our actual results, performance or achievements to be materially different from those expressed or implied in the forward-looking statements.

[0000926326-18-000015:mdna:22]
We own various trademarks and service marks used in our business, including the following registered and unregistered marks which appear in this report: Omnicell®, the Omnicell logo,  SureMed®, Ateb®, Time My Meds®,  Aesynt®, AcuDose-Rx®, Connect-Rx®, MACH4®, Anesthesia WorkstationTM and Performance CenterTM. This report also includes the trademarks and service marks of other companies. All other trademarks and service marks used in this report are the marks of their respective holders.

[0000926326-18-000015:mdna:23]
[same as prior period, unchanged from 0000926326-17-000038:mdna:15]

[0000926326-18-000015:mdna:24]
[same as prior period, unchanged from 0000926326-17-000038:mdna:16]

[0000926326-18-000015:mdna:25]
We are a leading provider of comprehensive automation and business analytics software solutions for patient-centric medication and supply management across the entire healthcare continuum, from the acute care hospital setting to post-acute skilled nursing and long-term care facilities to the home.

[0000926326-18-000015:mdna:26]
[same as prior period, unchanged from 0000926326-17-000038:mdna:20]

[0000926326-18-000015:mdna:27]
We manage our business as two operating segments, Automation and Analytics and Medication Adherence.

[0000926326-18-000015:mdna:28]
| • | Automation and Analytics. The Automation and Analytics segment is organized around the design, manufacturing, selling, and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. Our Automation and Analytics products are designed to enable our customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, our systems can be tailored to specific customer needs. |

[0000926326-18-000015:mdna:29]
| • | Medication Adherence. The Medication Adherence segment primarily includes the development, manufacturing and selling of solutions to assist patients to remain adherent to their medication regimens. These solutions are comprised of a variety of tools and aids that may be directly used by a pharmacist or a healthcare provider in their direct care for a patient, or the patient themselves, and include software based systems and medication adherence packaging, packaging equipment and ancillary products and services. These products are used to manage medication administration outside of the hospital setting and include medication adherence products sold under the brand names MTS, SureMed, Ateb, and Omnicell. |

[0000926326-18-000015:mdna:30]
For further description of our operating segments, please refer to Note 14, Segment and Geographical Information, of the Notes to the Condensed Consolidated Financial Statements in this quarterly report.

[0000926326-18-000015:mdna:31]
We sell our product and consumable solutions together with related service offerings. Revenue generated in the United States represented 87% and 88% of our total revenues for the three months ended March 31, 2018 and 2017, respectively. We have not sold in the past, and have no future plans to sell our products either directly or indirectly, to customers located in countries that are identified as state sponsors of terrorism by the U.S. Department of State, and are subject to economic sanctions and export controls.

[0000926326-18-000015:mdna:32]
[same as prior period, unchanged from 0000926326-17-000038:mdna:27]

[0000926326-18-000015:mdna:33]
The healthcare market is experiencing a period of substantive change. The adoption of electronic healthcare records, new regulatory constraints, and changes in the reimbursement structure have caused healthcare institutions to re-examine their operating structures, re-prioritize their investments, and seek efficiencies. We believe our customers’ evolving operating

[0000926326-18-000015:mdna:34]
[same as prior period, unchanged from 0000926326-17-000038:mdna:14]

[0000926326-18-000015:mdna:35]
environment creates challenges for any supplier, but also affords opportunities for suppliers that are able to partner with customers to help them meet the changing demands. We have, and intend to continue to, invest in the strategies which we believe have generated and will continue to generate our revenue and earnings growth, while supporting our customers’ initiatives and needs. These strategies include:

[0000926326-18-000015:mdna:36]
| • | Development of a differentiated platform. We invest in the development of products that we believe bring patient safety and workflow efficiency to our customers’ operations that they cannot get from other competing solutions. These differentiators may be as small as how a transaction operates or information provided on a report or as large as the entire automation of a workflow that would otherwise be completed manually. We intend to continue our focus on differentiating our products, and we carefully assess our investments regularly as we strive to ensure those investments provide the solutions most valuable to our customers. |

[0000926326-18-000015:mdna:37]
[same as prior period, unchanged from 0000926326-17-000038:mdna:31]

[0000926326-18-000015:mdna:38]
| • | Expansion of our solutions through acquisitions and partnerships. Our acquisitions have generally been focused on automation of manual workflows or data analytics, which is the enhancement of data for our customers’ decision-making processes. We believe that expansion of our product lines through acquisitions and partnerships to meet our customers changing and evolving expectations is a key component to our historical and future success. |

[0000926326-18-000015:mdna:39]
Our investments have been consistent with the strategies outlined above. To differentiate our solutions from others available in the market, in December 2016 we announced the XT Series, our new generation of medication and supply automation that is fully integrated on our Unity enterprise platform. The XT Series includes automated medication and supply dispensing cabinets, the Anesthesia Workstation, and Controlled Substance Manager. The XT Automated Medication Cabinets have been integrated with Connect-Rx® from Aesynt, so customers in the United States and Canada who use AcuDose-Rx® cabinets can take advantage of the new hardware without changing their software or server infrastructure. As part of this product introduction, we developed a new hardware and electronics architecture for the XT Series. The new design enables more medications to be stocked within the same footprint-the XT cabinets offer up to 50% more capacity compared with similar units on the market. In November 2017, we introduced our new IVX Workflow Solution. This new solution powered by IVX Cloud services helps enable pharmacies to safely and efficiently compound and prepare IV treatments. In December 2017, we announced our XR2 Central Pharmacy Automated System, allowing customers to more fully automate their central pharmacies.

[0000926326-18-000015:mdna:40]
Consistent with our strategy to enter new markets, we have made investments in our selling, general and administrative expenses to expand our sales team and market to new customers. Our international efforts have focused primarily on two markets: Western Europe, where we sell solutions through a direct sales team in the United Kingdom, France, and Germany and through resellers in other markets; and in the Middle Eastern countries of the Arabian Peninsula. We have also expanded our sales efforts to medication adherence customers in the United States which has allowed us to sell our automated dispensing solutions and other products to this market.

[0000926326-18-000015:mdna:41]
Expansion of our solutions through acquisitions and partnerships include our acquisition of Aesynt in January 2016, our acquisition of Ateb in December 2016, and most recently, our acquisition of InPharmics in April 2017. Aesynt is a provider of automated medication management systems, including dispensing robots with storage solutions, medication storage and dispensing carts and cabinets, I.V. sterile preparation robotics and software, including software related to medication management. Ateb is a provider of pharmacy-based patient care solutions and medication synchronization to independent and chain retail pharmacies. InPharmics is a provider of advanced pharmacy informatics solutions to hospital pharmacies. We have also developed relationships with major providers of hospital information management systems with the goal of enhancing the interoperability of our products with their systems. We believe that enhanced interoperability will help reduce implementation costs, time, and maintenance for shared clients, while providing new clinical workflows designed to enhance efficiency and patient safety.

[0000926326-18-000015:mdna:42]
[same as prior period, unchanged from 0000926326-17-000038:mdna:36]

[0000926326-18-000015:mdna:43]
[same as prior period, unchanged from 0000926326-17-000038:mdna:37]

[0000926326-18-000015:mdna:44]
26

[0000926326-18-000015:mdna:45]
[same as prior period, unchanged from 0000926326-17-000038:mdna:38]

[0000926326-18-000015:mdna:46]
[same as prior period, unchanged from 0000926326-17-000038:mdna:40]

[0000926326-18-000015:mdna:47]
Among other financial measures, we utilize product bookings to assess the current success of our strategies. Product bookings consist of all firm orders, as evidenced generally by a non-cancellable contract and purchase order for equipment and software, and by a purchase order for consumables. Equipment and software bookings are generally installable within twelve months and, other than subscription based sales, generally recorded as revenue upon customer acceptance of the installation. Consumables are recorded as revenue upon shipment to a customer or receipt by the customer, depending upon contract terms. Consumable bookings are generally recorded as revenue within one month.

[0000926326-18-000015:mdna:48]
In addition to product solution sales, we provide services to our customers. We provide installation planning and consulting as part of every product sale which is included in the initial price of the solution. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in increments of one to five years. As a result of the growth of our installed base of customers, our service revenues have also grown.

[0000926326-18-000015:mdna:49]
The growth in the Medication Adherence revenue was primarily driven by further market penetration and adoption of our automated and semi-automated packaging equipment within the United States and Europe, Middle East and Africa ("EMEA"), as well as modest price increases across the product lines.

[0000926326-18-000015:mdna:50]
In the future, we expect our strategies to evolve as the business environment of our customers evolves, but for our focus to remain on improving healthcare with solutions that help change the practices in ways that improve patient and provider outcomes. We expect our investment in differentiated products, new markets, and acquisitions and partnerships to continue.

[0000926326-18-000015:mdna:51]
In fiscal year 2017, we created Centers of Excellence (“COE”) for product development, engineering and manufacturing, with the Point of Use COE located at our facilities in California, the Robotics and Central Pharmacy COE located at our facilities near Pittsburgh, Pennsylvania, and the Medication Adherence Consumables COE located at our facilities in St. Petersburg, Florida. As part of this initiative, we reduced our workforce in the first half of 2017 by approximately 100 full-time employees, or about 4% of the total headcount, and closed our Nashville, Tennessee and Slovenia facilities.

[0000926326-18-000015:mdna:52]
Our full-time headcount was approximately 2,370 and 2,350 on March 31, 2018 on December 31, 2017, respectively.

[0000926326-18-000015:mdna:53]
2017 Acquisitions

[0000926326-18-000015:mdna:54]
[same as prior period, unchanged from 0000926326-17-000038:mdna:48]

[0000926326-18-000015:mdna:55]
[same as prior period, unchanged from 0000926326-17-000038:mdna:50]

[0000926326-18-000015:mdna:56]
Our discussion and analysis of our financial condition and results of operations are based on our Condensed Consolidated Financial Statements, which have been prepared in accordance with United States Generally Accepted Accounting Principles ("U.S. GAAP"). The preparation of these financial statements requires us to make certain estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of any contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. We regularly review our estimates and assumptions, which are based on historical experience and various other factors that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of certain assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates and assumptions. We believe the following critical accounting policies are affected by significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements:

[0000926326-18-000015:mdna:57]
[same as prior period, unchanged from 0000926326-17-000038:mdna:52]

[0000926326-18-000015:mdna:58]
| • | Allowance for doubtful accounts and notes receivable from investment in sales-type leases; |

[0000926326-18-000015:mdna:59]
| • | Inventory; |

[0000926326-18-000015:mdna:60]
| • | Software development costs; |

[0000926326-18-000015:mdna:61]
[same as prior period, unchanged from 0000926326-17-000038:mdna:57]

[0000926326-18-000015:mdna:62]
[same as prior period, unchanged from 0000926326-17-000038:mdna:56]

[0000926326-18-000015:mdna:63]
| • | Goodwill and acquired intangible assets |

[0000926326-18-000015:mdna:64]
| • | Share-based compensation; and |

[0000926326-18-000015:mdna:65]
[same as prior period, unchanged from 0000926326-17-000038:mdna:59]

[0000926326-18-000015:mdna:66]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the three months ended March 31, 2018 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our annual report on Form 10-K for the year ended December 31, 2017, except as discussed in "Recently adopted authoritative guidance" in Note 1 to the Condensed Consolidated Financial Statements in this quarterly report.

[0000926326-18-000015:mdna:67]
Recently issued authoritative guidance

[0000926326-18-000015:mdna:68]
Refer to Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this quarterly report for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position and cash flows.

[0000926326-18-000015:mdna:69]
[same as prior period, unchanged from 0000926326-17-000038:mdna:63]

[0000926326-18-000015:mdna:70]
[same as prior period, unchanged from 0000926326-17-000038:mdna:64]

[0000926326-18-000015:mdna:71]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 130,104 |  |  | $ | 98,702 |  |  | $ | 31,402 |  |  | 32 | % |
| Percentage of total revenues | 71 | % |  | 66 | % |  |  |  |  |
| Service and other revenues | 52,515 |  |  | 49,851 |  |  | 2,664 |  |  | 5 | % |
| Percentage of total revenues | 29 | % |  | 34 | % |  |  |  |  |
| Total revenues | $ | 182,619 |  |  | $ | 148,553 |  |  | $ | 34,066 |  |  | 23 | % |

[0000926326-18-000015:mdna:72]
Product revenues represented 71% and 66% of total revenues for the three months ended March 31, 2018 and March 31, 2017, respectively. Product revenues increased by $31.4 million due to increased sales for the Medication Adherence segment of $5.5 million and increased sales for the Automation and Analytics segment of $25.9 million. The increase in the Automation and Analytics segment was attributed to an increase in sales of XT series products of $24.0 million as the sales for the three months period ended March 31, 2017 had a slower conversion of bookings and backlog into revenue due to the introduction of the new XT series of products in the fourth quarter of 2016. The remainder of the increase in the Automation and Analytics segment was attributed to an increase in sales from IV solutions and Performance Center. The increase in the Medication Adherence segment was primarily attributed to higher completed installations of our VBM products compared to the three months ended March 31, 2017.

[0000926326-18-000015:mdna:73]
Service and other revenues represented 29% and 34% of total revenues for the three months ended March 31, 2018 and March 31, 2017, respectively. Service and other revenues include revenues from service and maintenance contracts and rentals of automation systems. Service and other revenues increased by $2.7 million primarily due to an increase from our Automation and Analytics segment of $3.3 million attributed to an increase in our installed customer base.

[0000926326-18-000015:mdna:74]
Our international sales represented 13% and 12% of total revenues for the three months ended March 31, 2018 and 2017, respectively, and are expected to be affected by foreign currency exchange rates fluctuations. We are unable to predict the extent to which revenue in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-18-000015:mdna:75]
[same as prior period, unchanged from 0000926326-17-000038:mdna:75]

[0000926326-18-000015:mdna:76]
[same as prior period, unchanged from 0000926326-17-000038:mdna:77]

[0000926326-18-000015:mdna:77]
[same as prior period, unchanged from 0000926326-17-000038:mdna:78]

[0000926326-18-000015:mdna:78]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
| Revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 151,406 |  |  | $ | 122,170 |  |  | $ | 29,236 |  |  | 24 | % |
| Percentage of total revenues | 83 | % |  | 82 | % |  |  |  |  |
| Medication Adherence | 31,213 |  |  | 26,383 |  |  | 4,830 |  |  | 18 | % |
| Percentage of total revenues | 17 | % |  | 18 | % |  |  |  |  |
| Total revenues | $ | 182,619 |  |  | $ | 148,553 |  |  | $ | 34,066 |  |  | 23 | % |

[0000926326-18-000015:mdna:79]
The $29.2 million increase in Automation and Analytics revenues for the three months ended March 31, 2018 in comparison to the three months ended March 31, 2017 was due to an increase in product revenue of $25.9 million and an increase in service revenues of $3.3 million. The increase in product revenue in the Automation and Analytics segment was attributed to an increase in sales of XT series products of $24.0 million as the sales for the three months period ended March 31, 2017 had a slower conversion of bookings and backlog into revenue due to the introduction of the new XT series of products in the fourth quarter of 2016. The remainder of the increase in product revenue in the Automation and Analytics segment was attributed to increases in sales from IV solutions and Performance Center. The service revenue increase of $3.3 million was primarily attributed to an increase in our installed customer base.

[0000926326-18-000015:mdna:80]
Medication Adherence revenues increased by $4.8 million for the three months ended March 31, 2018 in comparison to the three months ended March 31, 2017. The increase in revenue was due to an increase in product revenue of $5.5 million, offset by a decrease in service revenue of $0.6 million. The product revenue increase of $5.5 million was attributed primarily to higher completed installations of our VBM products compared to the three months ended March 31, 2017.

[0000926326-18-000015:mdna:81]
[same as prior period, unchanged from 0000926326-17-000038:mdna:85]

[0000926326-18-000015:mdna:82]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which account for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product and overhead costs associated with production; (ii) installation costs as we install our equipment at the customer site and include costs of the field installation personnel, including labor, travel expense, and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory and amortization of software development costs and intangibles.

[0000926326-18-000015:mdna:83]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
| Cost of revenues: | (Dollars in thousands) |
| Automation and Analytics | $ | 78,242 |  |  | $ | 68,761 |  |  | $ | 9,481 |  |  | 14 | % |
| As a percentage of related revenues | 52 | % |  | 56 | % |  |  |  |  |
| Medication Adherence | 21,922 |  |  | 17,601 |  |  | 4,321 |  |  | 25 | % |
| As a percentage of related revenues | 70 | % |  | 67 | % |  |  |  |  |
| Total cost of revenues | $ | 100,164 |  |  | $ | 86,362 |  |  | $ | 13,802 |  |  | 16 | % |
| As a percentage of total revenues | 55 | % |  | 58 | % |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 73,164 |  |  | $ | 53,409 |  |  | $ | 19,755 |  |  | 37 | % |
| Automation and Analytics gross margin | 48 | % |  | 44 | % |  |  |  |  |
| Medication Adherence | 9,291 |  |  | 8,782 |  |  | 509 |  |  | 6 | % |
| Medication Adherence gross margin | 30 | % |  | 33 | % |  |  |  |  |
| Total gross profit | $ | 82,455 |  |  | $ | 62,191 |  |  | $ | 20,264 |  |  | 33 | % |
| Total gross margin | 45 | % |  | 42 | % |  |  |  |  |

[0000926326-18-000015:mdna:84]
[same as prior period, unchanged from 0000926326-17-000038:mdna:68]

[0000926326-18-000015:mdna:85]
Cost of Revenues. Cost of revenues for the three months ended March 31, 2018 compared to the three months ended March 31, 2017 increased by $13.8 million, of which $9.5 million was attributed to the increase of cost of revenue in our Automation and Analytics segment and $4.3 million was attributed to the increase of cost of revenue in our Medication Adherence segment. The increase of the cost of revenue in the Automation and Analytics is consistent with the increase of revenue of $29.2 million in the Automation and Analytics for the three months ended March 31, 2018 compared to the three months ended March 31, 2017. The increase of the cost of revenue in the Medication Adherence segment is consistent with the increase of revenue of $4.8 million in the Medication Adherence segment for the three months ended March 31, 2018 compared to the three months ended March 31, 2017. Overall changes to gross margin primarily relate to product mix from sales for the periods presented.

[0000926326-18-000015:mdna:86]
Operating Expenses and Income (Loss) from Operations

[0000926326-18-000015:mdna:87]
|  | Three months ended March 31, |
|  |  |  |  |  | Change in |
|  | 2018 |  | 2017 |  | $ |  | % |
| Operating expenses: | (Dollars in thousands) |
| Research and development | $ | 16,537 |  |  | $ | 16,803 |  |  | $ | (266 | ) |  | (2 | )% |
| As a percentage of total revenues | 9 | % |  | 11 | % |  |  |  |  |
| Selling, general and administrative | 65,285 |  |  | 61,940 |  |  | 3,345 |  |  | 5 | % |
| As a percentage of total revenues | 36 | % |  | 42 | % |  |  |  |  |
| Total operating expenses | $ | 81,822 |  |  | $ | 78,743 |  |  | $ | 3,079 |  |  | 4 | % |
| As a percentage of total revenues | 45 | % |  | 53 | % |  |  |  |  |
| Income (loss) from operations: |  |  |  |  |  |  |  |
| Automation and Analytics | $ | 24,774 |  |  | $ | 5,347 |  |  | $ | 19,427 |  |  | 363 | % |
| Operating margin | 16 | % |  | 4 | % |  |  |  |  |
| Medication Adherence | (908 | ) |  | (2,414 | ) |  | 1,506 |  |  | (62 | )% |
| Operating margin | (3 | )% |  | (9 | )% |  |  |  |  |
| Corporate Expenses | 23,233 |  |  | 19,485 |  |  | 3,748 |  |  | 19 | % |
| Total income (loss) from operations | $ | 633 |  |  | $ | (16,552 | ) |  | $ | 17,185 |  |  | (104 | )% |
| Total operating margin | — | % |  | (11 | )% |  |  |  |  |

[0000926326-18-000015:mdna:88]
Research and Development. The $0.3 million decrease in research and development expenses for the three months ended March 31, 2018 compared to three months ended March 31, 2017 was primarily driven by a decrease in research and development expenses of $1.1 million in our Automation and Analytics segment, offset by an increase of $0.6 million in our Medication Adherence segment. The decrease in the Automation and Analytics segment is primarily attributed to a one-time restructuring expense of $0.8 million included in the three months ended March 31, 2017. The increase in the Medication Adherence segment is attributed to continued investments in product development.

[0000926326-18-000015:mdna:89]
Selling, General and Administrative.  The $3.3 million increase in selling, general and administrative expenses for the three months ended March 31, 2018 compared to the three months ended March 31, 2017 was primarily due to the increase in corporate-related expenses of $3.6 million as a result of an increase in employee-related expenses due to the increase in headcount.

[0000926326-18-000015:mdna:90]
Provision for (Benefit from) Income Taxes

[0000926326-18-000015:mdna:91]
|  | Three months ended |
|  |  |  |  |  | Change in |
|  | March 31, 2018 |  | March 31, 2017 |  | $ |  | % |
|  | (Dollars in thousands) |
| Provision for (benefit from) income taxes | $ | (4,816 | ) |  | $ | (8,673 | ) |  | $ | 3,857 |  |  | (44 | )% |
| Effective tax rate on earnings |  |  |  |  |  |  |  |

[0000926326-18-000015:mdna:92]
[same as prior period, unchanged from 0000926326-17-000038:mdna:76]

[0000926326-18-000015:mdna:93]
Our annual effective tax rate before discrete items was 18.3% and 39.1% for the three months ended March 31, 2018 and 2017, respectively. The decrease in the estimated annual effective tax rate for the three months ended March 31, 2018 compared to the same period in 2017 was primarily due to U.S. tax reform legislation that reduced the statutory corporate income tax rate from 35% to 21%, increase in Federal Research & Development credits and company jurisdictional restructuring.

[0000926326-18-000015:mdna:94]
[same as prior period, unchanged from 0000926326-17-000038:mdna:109]

[0000926326-18-000015:mdna:95]
We had cash and cash equivalents of $43.8 million at March 31, 2018 compared to $32.4 million at December 31, 2017. All of our cash and cash equivalents are invested in demand deposits only.

[0000926326-18-000015:mdna:96]
Our cash position and working capital at March 31, 2018 and December 31, 2017 were as follows:

[0000926326-18-000015:mdna:97]
|  | March 31, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Cash | 43,773 |  |  | 32,424 |  |
| Working Capital | $ | 150,804 |  |  | $ | 147,066 |  |

[0000926326-18-000015:mdna:98]
All of our cash and cash equivalents for these periods were invested in bank demand deposits. Our ratio of current assets to current liabilities was 1.7:1 at March 31, 2018 and 1.7:1 at December 31, 2017.

[0000926326-18-000015:mdna:99]
[same as prior period, unchanged from 0000926326-17-000038:mdna:113]

[0000926326-18-000015:mdna:100]
Credit Agreement

[0000926326-18-000015:mdna:101]
On January 5, 2016, we entered into a $400 million secured credit facility pursuant to a credit agreement, by and among us, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as sole lead arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for a $200 million term loan facility (the “Term Loan Facility”), and prior to the amendment discussed below, a $200 million revolving credit facility (the “Revolving Credit Facility” and together with the Term Loan Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million.

[0000926326-18-000015:mdna:102]
On December 26, 2017 and April 11, 2017, we entered into the amendments to the Credit Agreement. Under these amendments, the Revolving Credit Facility was increased from $200 million to $315 million and certain other modifications were made. Refer to Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this quarterly report. We expect to use future loans under the Revolving Credit Facility, if any, for general corporate purposes, including acquisitions.

[0000926326-18-000015:mdna:103]
As of March 31, 2018, the outstanding balance from the Facilities was $214.5 million and we were in compliance with all covenants.

[0000926326-18-000015:mdna:104]
Distribution Agreement

[0000926326-18-000015:mdna:105]
On November 3, 2017, we entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC and HSBC Securities (USA) Inc., as our sales agents (collectively, the “Sales Agents”), pursuant to which we may offer and sell from time to time through the Sales Agents up to $125 million maximum aggregate offering price of our common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act, including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange. We intend to use the net proceeds from the sale, if any, of common stock in the offering for general corporate purposes, which may include, without limitation, the acquisition of complementary businesses, the repayment of outstanding indebtedness, capital expenditures and working capital.

[0000926326-18-000015:mdna:106]
For the three months ended March 31, 2018, we did not sell any common stock under the Distribution Agreement.

[0000926326-18-000015:mdna:107]
[same as prior period, unchanged from 0000926326-17-000038:mdna:120]

[0000926326-18-000015:mdna:108]
[same as prior period, unchanged from 0000926326-17-000038:mdna:121]

[0000926326-18-000015:mdna:109]
Our stock repurchase programs have a total of $54.9 million remaining for future repurchases as of March 31, 2018, which may result in additional use of cash.  See "Stock Repurchase Program" under Note 12. Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this quarterly report. There were no stock repurchases during the three months ended March 31, 2018 and 2017.

[0000926326-18-000015:mdna:110]
[same as prior period, unchanged from 0000926326-17-000038:mdna:124]

[0000926326-18-000015:mdna:111]
[same as prior period, unchanged from 0000926326-17-000038:mdna:125]

[0000926326-18-000015:mdna:112]
The following table summarizes, for the periods indicated, selected items in our Condensed Consolidated Statements of Cash Flows:

[0000926326-18-000015:mdna:113]
|  | Three months ended |
|  | March 31, 2018 |  | March 31, 2017 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | 18,856 |  |  | $ | 28,182 |  |
| Investing activities | (14,540 | ) |  | (6,837 | ) |
| Financing activities | 5,741 |  |  | (30,136 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 1,292 |  |  | 651 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 11,349 |  |  | $ | (8,140 | ) |

[0000926326-18-000015:mdna:114]
[same as prior period, unchanged from 0000926326-17-000038:mdna:128]

[0000926326-18-000015:mdna:115]
[same as prior period, unchanged from 0000926326-17-000038:mdna:129]

[0000926326-18-000015:mdna:116]
Net cash provided by operating activities was $18.9 million for the three months ended March 31, 2018, primarily as a result of the net income of $2.7 million adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $12.3 million, and share-based compensation expense of $6.5 million, deferred income taxes of $5.1 million and $0.6 million of amortization of debt financing fees. The net cash outflow which was contributed to changes in assets and liabilities include (i) an increase in accounts receivable and unbilled receivable, net of $0.6 million due to the increase in unbilled receivable balances offset by an increase in collections, (ii) an increase in inventories of $6.9 million for inventory buildup in support of forecasted sales, (iii) a decrease in accounts payable of $9.4 million primarily due to the timing of payments, (iv) an increase in the investment in sales-type leases of $1.5 million, (v) an increase in other current assets of $1.0 million, (iv) an increase in other long-term assets of $1.7 million. These outflows were offset by an increase in deferred revenue of $15.1 million due to the timing of orders and revenue being recognized for installed product, an increase in other accrued liabilities of $4.3 million, a decrease in prepaid expenses of $0.8 million, and an increase in accrued compensation of $2.4 million.

[0000926326-18-000015:mdna:117]
Net cash provided by operating activities was $28.2 million for the three months ended March 31, 2017, primarily as a result of the net loss of $10.3 million adjusted for non-cash items and changes in assets and liabilities. The non-cash items primarily consisted of depreciation and amortization expense of $12.4 million, share-based compensation expense of $5.5 million, deferred income taxes of $8.8 million and $0.4 million of amortization of debt financing fees. The cash inflow attributed to changes in assets and liabilities includes (i) a decrease in accounts receivable of $21.6 million due to timing of collections, (ii) an increase in accrued compensation of $2.0 million, as a result of the restructuring plan, (iii) an increase in deferred revenue of $8.5 million due to timing of orders and revenue being recognized on installed product, (iv) a decrease in net investment in sales-type leases of $1.1 million, and (v) an increase in accounts payable of $11.1 million primarily due to the timing of payments. These inflows were partially offset by an increase in inventories of $6.9 million for inventory buildup in support of forecasted sales, particularly for the XT series and an increase in other long-term assets of $9.4 million.

[0000926326-18-000015:mdna:118]
[same as prior period, unchanged from 0000926326-17-000038:mdna:134]

[0000926326-18-000015:mdna:119]
[same as prior period, unchanged from 0000926326-17-000038:mdna:91]

[0000926326-18-000015:mdna:120]
Net cash used in investing activities was $14.5 million for the three months ended March 31, 2018, which consisted of capital expenditures of $9.3 million for property and equipment and $5.3 million for costs of software development.

[0000926326-18-000015:mdna:121]
Net cash used in investing activities was $6.8 million for the three months ended March 31, 2017, which consisted of capital expenditures of $2.5 million for property and equipment and $4.4 million for costs of software development mainly related to the Performance Center offering and purchase of intangibles.

[0000926326-18-000015:mdna:122]
[same as prior period, unchanged from 0000926326-17-000038:mdna:137]

[0000926326-18-000015:mdna:123]
Net cash provided by financing activities was $5.7 million for the three months ended March 31, 2018, primarily from $9.5 million in proceeds from employee stock option exercises and employee stock plan purchases, partially offset by the repayment of $2.5 million of the credit facilities and $1.3 million in employees' taxes paid related to restricted stock unit vesting.

[0000926326-18-000015:mdna:124]
Net cash used in financing activities was $30.1 million for the three months ended March 31, 2017 primarily from repayment of $40.0 million of the credit facilities and $1.1 million in employees' taxes paid related to restricted stock units, partially offset by $10.9 million in proceeds from employee stock option exercises and employee stock plan purchases.

[0000926326-18-000015:mdna:125]
[same as prior period, unchanged from 0000926326-17-000038:mdna:140]

[0000926326-18-000015:mdna:126]
There have been no significant changes during the three months ended March 31, 2018 to the contractual obligations disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations, set forth in Part II, Item 7, of our annual report on Form 10-K for the year ended December 31, 2017.

[0000926326-18-000015:mdna:127]
Contractual obligations as of March 31, 2018 are as follows:

[0000926326-18-000015:mdna:128]
|  | Payments due by period |
|  | Total |  | Remainder of 2018 |  | 2019 and 2020 |  | 2021 and 2022 |  | Thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 77,178 |  |  | $ | 8,896 |  |  | $ | 22,566 |  |  | $ | 19,333 |  |  | $ | 26,383 |  |
| Purchase obligations (2) | 55,424 |  |  | 51,293 |  |  | 3,001 |  |  | 1,104 |  |  | 26 |  |
| Term loan facility (3) | 180,000 |  |  | 15,000 |  |  | 47,500 |  |  | 117,500 |  |  | — |  |
| Revolving credit facility (3) | 34,500 |  |  | — |  |  | — |  |  | 34,500 |  |  | — |  |
| Total (4) (5) | $ | 347,102 |  |  | $ | 75,189 |  |  | $ | 73,067 |  |  | $ | 172,437 |  |  | $ | 26,409 |  |

[0000926326-18-000015:mdna:129]
[same as prior period, unchanged from 0000926326-17-000038:mdna:144]

[0000926326-18-000015:mdna:130]
[same as prior period, unchanged from 0000926326-17-000038:mdna:145]

[0000926326-18-000015:mdna:131]
[same as prior period, unchanged from 0000926326-17-000038:mdna:146]

[0000926326-18-000015:mdna:132]
| (3) | Amounts shown for term loan and revolving credit facility are principal repayments only. Due to use of interest rate swaps, the cash interest expense is partly variable and partly fixed, and is not reflected in the above table. Refer to Note 8, Debt, of the Notes to the Condensed Consolidated Financial Statements included in this quarterly report. |

[0000926326-18-000015:mdna:133]
| (4) | We have recorded $7.1 million for uncertain tax positions under long-term liabilities as of March 31, 2018 in accordance with U.S. GAAP. As these liabilities do not reflect actual tax assessments, the timing and amount of payments we might be required to make will depend upon a number of factors. Accordingly, as the timing and amount of payment cannot be estimated, the $7.1 million in uncertain tax position liabilities have not been included in the table above. |

[0000926326-18-000015:mdna:134]
| (5) | Refer to Note 10, Commitments and Contingencies, of the Notes to the Condensed Consolidated Financial Statements included in this quarterly report. |

[0000926326-18-000015:mdna:135]
[same as prior period, unchanged from 0000926326-17-000038:mdna:149]

[0000926326-18-000015:mdna:136]
33

[0000926326-18-000015:mdna:137]
As of March 31, 2018, we had no off-balance sheet arrangements as defined under Regulation S-K 303(a)(4) of the Securities Exchange Act of 1934, as amended, and the instructions thereto.
