# OMCL 8-K — 0000926326-18-000013 filed 2018-04-26

## item codes, every 8-K on or before 2018-05-04

- 2018-04-26 0000926326-18-000013 — 2.02, 9.01
- 2018-03-02 0001104659-18-014497 — 5.02
- 2018-02-08 0000926326-18-000007 — 5.02
- 2018-02-02 0000926326-18-000005 — 5.02
- 2018-02-01 0000926326-18-000003 — 2.02, 9.01
- 2017-12-26 0000926326-17-000041 — 1.01, 2.03, 9.01
- 2017-11-03 0001104659-17-066102 — 1.01, 8.01, 9.01
- 2017-10-26 0000926326-17-000035 — 2.02, 9.01
- 2017-08-03 0000926326-17-000028 — 5.07 — amendment, the index does not say of what
- 2017-07-27 0000926326-17-000026 — 2.02, 9.01
- 2017-07-25 0000926326-17-000023 — 5.02, 9.01
- 2017-05-24 0000926326-17-000019 — 5.07
- 2017-05-04 0001628280-17-004851 — 2.02, 9.01
- 2017-02-15 0000926326-17-000010 — 2.05
- 2017-02-15 0000926326-17-000008 — 2.02, 9.01
- 2017-02-13 0000926326-17-000002 — 5.02
- 2016-12-08 0001104659-16-161330 — 2.01, 2.03, 9.01
- 2016-12-06 0001104659-16-160709 — 7.01
- 2016-11-29 0001104659-16-159456 — 1.01, 7.01, 9.01
- 2016-10-27 0000926326-16-000075 — 2.02, 9.01
- 2016-10-07 0000926326-16-000072 — 5.02, 8.01
- 2016-08-05 0000926326-16-000068 — 8.01
- 2016-07-28 0000926326-16-000066 — 2.02, 9.01
- 2016-06-13 0001104659-16-126854 — 5.02
- 2016-05-25 0000926326-16-000060 — 5.07
- 2016-04-28 0000926326-16-000054 — 2.02, 9.01
- 2016-03-21 0001104659-16-106649 — 8.01, 9.01
- 2016-03-17 0000926326-16-000051 — 7.01, 9.01
- 2016-03-17 0000926326-16-000049 — 9.01 — amendment of 0000926326-16-000051
- 2016-02-10 0001104659-16-095486 — 5.02, 9.01
- 2016-02-04 0000926326-16-000041 — 2.02, 9.01
- 2016-01-06 0001104659-16-088299 — 1.01, 2.01, 2.03, 9.01
- 2015-12-10 0000926326-15-000038 — 8.01, 9.01
- 2015-10-29 0001104659-15-074138 — 1.01, 9.01
- 2015-10-29 0000926326-15-000031 — 2.02, 9.01
- 2015-08-20 0001104659-15-061135 — 5.02, 9.01
- 2015-07-30 0000926326-15-000024 — 2.02, 9.01
- 2015-05-22 0001104659-15-040440 — 5.07
- 2015-05-01 0001104659-15-032846 — 5.02
- 2015-05-01 0001104659-15-032844 — 7.01
- 2015-04-30 0000926326-15-000015 — 9.01
- 2015-04-22 0001104659-15-029356 — 8.01, 9.01
- 2015-03-20 0001104659-15-021435 — 3.01
- 2015-03-18 0001104659-15-020699 — 7.01
- 2015-03-17 0001104659-15-020483 — 8.01, 9.01
- 2015-03-02 0001104659-15-015802 — 1.01, 9.01
- 2015-02-12 0001104659-15-009234 — 5.02, 9.01
- 2015-02-03 0000926326-15-000003 — 9.01
- 2015-01-15 0001104659-15-002635 — 5.02
- 2014-11-07 0001104659-14-078398 — 1.01, 8.01, 9.01
- 2014-10-30 0000926326-14-000037 — 2.02, 9.01
- 2014-08-25 0001104659-14-062772 — 8.01, 9.01
- 2014-07-31 0000926326-14-000032 — 2.02, 9.01
- 2014-05-21 0001104659-14-040744 — 5.07
- 2014-05-01 0000926326-14-000008 — 2.02, 9.01
- 2014-04-08 0001104659-14-026441 — 4.01, 9.01
- 2014-04-02 0001104659-14-025179 — 5.02
- 2014-02-07 0001104659-14-007552 — 5.02, 9.01
- 2014-02-04 0001104659-14-006352 — 2.02, 9.01
- 2013-12-09 0001104659-13-088980 — 1.01, 9.01
- 2013-12-02 0001104659-13-087877 — 5.02
- 2013-10-31 0001104659-13-079660 — 2.02, 9.01
- 2013-09-26 0001104659-13-072435 — 1.01, 2.03, 9.01
- 2013-08-01 0001104659-13-058959 — 2.02, 9.01
- 2013-05-23 0001104659-13-044317 — 5.07
- 2013-05-02 0001104659-13-036605 — 2.02, 9.01
- 2013-03-11 0001104659-13-019143 — 8.01
- 2013-02-07 0001104659-13-008477 — 5.02, 9.01
- 2013-01-31 0001104659-13-006446 — 2.02, 9.01
- 2012-11-02 0001104659-12-073697 — 5.02
- 2012-10-25 0001104659-12-071211 — 2.02, 9.01
- 2012-08-06 0001104659-12-054635 — 8.01
- 2012-08-03 0001104659-12-054214 — 2.01, 9.01 — amendment of 0001104659-12-038888
- 2012-08-01 0001104659-12-053005 — 2.02, 9.01
- 2012-06-12 0001104659-12-042936 — 8.01, 9.01
- 2012-05-23 0001104659-12-039459 — 5.07
- 2012-05-22 0001104659-12-038888 — 2.01, 9.01
- 2012-05-02 0001104659-12-032048 — 2.02, 9.01
- 2012-05-02 0001104659-12-032036 — 1.01, 9.01
- 2012-04-04 0001104659-12-023883 — 5.02, 8.01
- 2012-03-20 0001104659-12-019462 — 1.01, 9.01
- 2012-02-13 0001104659-12-009353 — 5.02, 9.01
- 2012-01-26 0001104659-12-004244 — 2.02, 9.01
- 2011-10-27 0001104659-11-058464 — 2.02, 9.01
- 2011-10-25 0001104659-11-057721 — 1.01
- 2011-07-28 0001104659-11-041505 — 2.02, 9.01
- 2011-05-27 0001104659-11-032006 — 5.07
- 2011-05-02 0001104659-11-024908 — 2.02, 9.01
- 2011-04-15 0001104659-11-020407 — 5.02, 9.01 — amendment of 0001104659-11-005638
- 2011-02-08 0001104659-11-005638 — 5.02, 9.01
- 2011-01-27 0001104659-11-003419 — 2.02, 9.01
- 2010-12-22 0001104659-10-064003 — 5.02, 5.07, 9.01
- 2010-10-27 0001104659-10-054036 — 2.02, 9.01
- 2010-10-05 0001104659-10-051173 — 8.01
- 2010-07-22 0001104659-10-039126 — 2.02, 9.01
- 2010-07-09 0001104659-10-037594 — 2.05
- 2010-05-28 0001104659-10-031607 — 5.07
- 2010-04-26 0001104659-10-021797 — 2.02, 9.01
- 2010-03-17 0001104659-10-014849 — 5.02, 9.01
- 2010-02-08 0001104659-10-005457 — 5.02, 9.01
- 2010-01-28 0001104659-10-003627 — 2.02, 9.01
- 2009-10-22 0001104659-09-059972 — 2.02, 9.01
- 2009-07-23 0001104659-09-044508 — 2.02, 9.01
- 2009-05-20 0001104659-09-033938 — 5.02, 9.01
- 2009-04-30 0001104659-09-027707 — 2.02, 9.01
- 2009-03-10 0001104659-09-016178 — 5.02, 9.01
- 2009-02-09 0001104659-09-007692 — 5.02, 9.01
- 2009-01-29 0001104659-09-005022 — 2.02, 2.05, 9.01
- 2009-01-21 0001104659-09-003180 — 2.02, 8.01, 9.01
- 2009-01-06 0001104659-09-000625 — 5.02
- 2008-10-23 0001104659-08-065475 — 2.02, 9.01
- 2008-07-21 0001104659-08-046690 — 2.02, 9.01
- 2008-05-16 0001104659-08-034035 — 8.01, 9.01
- 2008-04-28 0001104659-08-027379 — 7.01, 9.01
- 2008-04-21 0001104659-08-025616 — 2.02, 9.01
- 2008-03-12 0001104659-08-016939 — 7.01, 9.01
- 2008-02-26 0001104659-08-012840 — 7.01, 9.01
- 2008-02-12 0001104659-08-009382 — 5.02, 9.01
- 2008-01-31 0001104659-08-006199 — 2.02, 9.01
- 2007-12-05 0001104659-07-087191 — 1.01, 9.01
- 2007-10-18 0001104659-07-075654 — 2.02, 9.01
- 2007-07-27 0001104659-07-056886 — 5.03, 9.01
- 2007-07-19 0001104659-07-054924 — 2.02, 9.01
- 2007-05-23 0001104659-07-042287 — 8.01, 9.01
- 2007-05-07 0001104659-07-036172 — 1.01, 5.02, 9.01
- 2007-04-24 0001104659-07-030578 — 2.02, 9.01 — amendment, the index does not say of what
- 2007-04-24 0001104659-07-030547 — 2.02, 9.01
- 2007-04-10 0001104659-07-027465 — 5.02, 9.01
- 2007-03-23 0001104659-07-021969 — 2.02, 4.02, 9.01
- 2007-01-30 0001104659-07-005772 — 2.02, 9.01
- 2007-01-09 0001104659-07-001600 — 5.02, 9.01
- 2006-10-30 0001104659-06-069612 — 1.01
- 2006-10-19 0001104659-06-067549 — 2.02, 9.01
- 2006-07-20 0001104659-06-048020 — 2.02, 4.02, 9.01
- 2006-05-17 0001104659-06-035522 — 1.01, 9.01 — amendment of 0001104659-05-011155
- 2006-05-09 0001104659-06-032706 — 1.01, 9.01
- 2006-04-25 0001104659-06-027438 — 2.02, 9.01
- 2006-04-04 0001104659-06-022204 — 1.01, 9.01
- 2006-03-15 0001104659-06-016861 — 1.01, 9.01
- 2006-01-30 0001104659-06-004749 — 2.02, 9.01
- 2006-01-24 0001104659-06-003504 — 1.01, 5.02, 9.01
- 2005-12-13 0001104659-05-060532 — 1.01, 9.01
- 2005-11-10 0001104659-05-054663 — 2.02, 9.01
- 2005-07-21 0001104659-05-033464 — 2.02, 9.01
- 2005-06-22 0001104659-05-029255 — 1.01
- 2005-05-16 0001104659-05-023473 — 2.02, 9.01 — amendment of 0001104659-05-018173
- 2005-05-16 0001104659-05-023471 — 2.02, 9.01 — amendment of 0001104659-05-017382
- 2005-05-10 0001104659-05-022127 — 1.01
- 2005-04-26 0001104659-05-018173 — 2.02, 9.01
- 2005-04-21 0001104659-05-017382 — 2.02, 9.01
- 2005-04-06 0001104659-05-015401 — 5.02
- 2005-03-15 0001104659-05-011155 — 1.01, 9.01
- 2005-03-08 0001104659-05-009975 — 1.01, 9.01
- 2005-02-03 0001104659-05-003943 — 2.02, 9.01
- 2005-01-13 0001104659-05-001314 — 5.02, 9.01
- 2004-10-21 0001104659-04-031413 — 2.02, 9.01
- 2004-07-22 0001104659-04-020572 — 12, 7
- 2004-04-14 0001104659-04-010039 — 12, 7
- 2004-04-05 0001104659-04-009437 — 12, 7
- 2004-01-26 0001104659-04-001655 — 12, 7
- 2003-10-16 0001104659-03-022990 — 12, 7
- 2003-07-17 0001104659-03-015053 — 9
- 2003-04-18 0001104659-03-006823 — 7, 9
- 2003-02-14 0001104659-03-002607 — 5, 7

## late-filing notifications on or before 2018-05-04

- 2015-03-02 0000926326-15-000006 — NT 10-K, for the period ended 2014-12-31
- 2007-03-16 0001104659-07-020094 — NT 10-K, for the period ended 2006-12-31

## item 2.02 — earnings release, exhibit 99.1

[0000926326-18-000013:8k_2_02:1]
EX-99.1
2
exhibit991q118.htm
EXHIBIT 99.1

[0000926326-18-000013:8k_2_02:2]
Exhibit

[0000926326-18-000013:8k_2_02:3]
Exhibit 99.1

[0000926326-18-000013:8k_2_02:4]
| Contact: |  |  |
| Peter Kuipers |  | Omnicell, Inc. |
| Chief Financial Officer |  | 590 East Middlefield Road |
| 800-850-6664 |  | Mountain View, CA 94043 |
| Peter.kuipers@omnicell.com |  |  |

[0000926326-18-000013:8k_2_02:5]
Omnicell Announces First Quarter 2018 Results

[0000926326-18-000013:8k_2_02:6]
GAAP revenue of $183 million, up 23% year-over-year

[0000926326-18-000013:8k_2_02:7]
GAAP net income per diluted share of $0.07, up $0.35 year-over-year

[0000926326-18-000013:8k_2_02:8]
Non-GAAP revenue of $183 million, up 23% year-over-year

[0000926326-18-000013:8k_2_02:9]
Non-GAAP net income per diluted share of $0.29, up $0.22 year-over-year

[0000926326-18-000013:8k_2_02:10]
MOUNTAIN VIEW, Calif. -- April 26, 2018 -- Omnicell, Inc. (NASDAQ: OMCL), a leading provider of medication and supply management solutions to healthcare systems, today announced results for its first quarter ended March 31, 2018.

[0000926326-18-000013:8k_2_02:11]
GAAP results: GAAP revenue for the first quarter of 2018 was $182.6 million, up $34.1 million, or 23% from the first quarter of 2017.

[0000926326-18-000013:8k_2_02:12]
First quarter 2018 GAAP net income as reported was $2.7 million, or $0.07 per diluted share. This compares to GAAP net loss of $10.3 million, or $0.28 per diluted share, for the first quarter of 2017.

[0000926326-18-000013:8k_2_02:13]
Non-GAAP results: Non-GAAP revenue for the first quarter of 2018 was $182.6 million, up $33.8 million, or 23% from the first quarter of 2017.

[0000926326-18-000013:8k_2_02:14]
Non-GAAP net income for the first quarter of 2018 was $11.5 million, or $0.29 per diluted share. This compares to non-GAAP net income of $2.5 million, or $0.07 per diluted share, for the first quarter of 2017.

[0000926326-18-000013:8k_2_02:15]
Non-GAAP net income for each period excludes, when applicable, the effect of stock-based compensation expense, amortization expense of acquired intangible assets, acquisition-related expenses, fair value adjustments related to business acquisitions, restructuring and severance-related expenses, tax reform and restructuring benefits, and amortization of debt issuance cost.

[0000926326-18-000013:8k_2_02:16]
Effective January 1, 2018, the Company adopted the new revenue recognition accounting standard, ASC 606, "Revenue from Contracts with Customers", utilizing the full retrospective transition method. All 2017 financial results have been adjusted to reflect the change.

[0000926326-18-000013:8k_2_02:17]
“We are pleased to report this very strong start of 2018, which demonstrates that the market continues to see value in our industry-leading medication management platform,” said Randall Lipps, chairman, president, chief executive officer, and founder of Omnicell.  “As the complexities of healthcare evolve, we believe we are uniquely positioned to help lead the digital healthcare transformation with solutions that meet customer needs and grow market share for our business.”

[0000926326-18-000013:8k_2_02:18]
2018 Guidance:

[0000926326-18-000013:8k_2_02:19]
For the second quarter of 2018, the Company expects non-GAAP revenue to be between $185 million and $190 million. The Company expects second quarter 2018 non-GAAP earnings to be between $0.36 and $0.42 per share.

[0000926326-18-000013:8k_2_02:20]
For the year 2018, the Company expects product bookings to be between $625 million and $660 million. The Company expects non-GAAP revenue to be between $780 million and $800 million, and non-GAAP earnings to be between $1.85 and $2.05 per share.

[0000926326-18-000013:8k_2_02:21]
The table below summarizes 2018 guidance outlined above.

[0000926326-18-000013:8k_2_02:22]
|  | Q2'18 | Total Year 2018 |
| Product Bookings | Not provided | $625 million - $660 million |
| Non-GAAP Revenue | $185 million - $190 million | $780 million - $800 million |
| Non-GAAP EPS | $0.36 - $0.42 | $1.85 - $2.05 |

[0000926326-18-000013:8k_2_02:23]
Omnicell Conference Call Information

[0000926326-18-000013:8k_2_02:24]
Omnicell will hold a conference call today, Thursday, April 26, 2018 at 1:30 p.m. PT to discuss first quarter financial results. The conference call can be monitored by dialing 1-800-696-5518 within the U.S. or 1-706-758-4883 for all other locations. The Conference ID # is 9755479. Internet users can access the conference call at http://ir.omnicell.com/events.cfm.  A replay of the call will be available today at approximately 4:30 p.m. PT and will be available until 11:59 p.m. PT on June 7, 2018. The replay access numbers are 1-855-859-2056 within the U.S. and 1-404-537-3406 for all other locations, Conference ID # is 9755479.

[0000926326-18-000013:8k_2_02:25]
About Omnicell

[0000926326-18-000013:8k_2_02:26]
Since 1992, Omnicell (NASDAQ: OMCL) has been inspired to create safer and more efficient ways to manage medications and supplies across all care settings. As a leader in medication and supply dispensing automation, central pharmacy automation, IV robotics, analytics software, and medication adherence and packaging systems, Omnicell is focused on improving care across the entire healthcare continuum - from the acute care hospital setting, to post-acute skilled nursing and long-term care facilities, to the patient’s home.

[0000926326-18-000013:8k_2_02:27]
Over 4,500 facilities worldwide use Omnicell® automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence and improve patient safety.

[0000926326-18-000013:8k_2_02:28]
Omnicell’s innovative medication adherence solutions, used by over 32,000 institutional and retail pharmacies in North America and the United Kingdom, are designed to improve patient adherence to prescriptions, helping to reduce costly hospital readmissions.

[0000926326-18-000013:8k_2_02:29]
Recent Omnicell acquisitions add distinct capabilities, particularly in central pharmacy, IV robotics, and pharmacy software, creating the broadest medication management product portfolio in the industry.

[0000926326-18-000013:8k_2_02:30]
For more information about Omnicell, Inc. please visit www.omnicell.com.

[0000926326-18-000013:8k_2_02:31]
Omnicell and the Omnicell logo are registered trademarks of Omnicell, Inc. in the United States and other countries.

[0000926326-18-000013:8k_2_02:32]
Forward-Looking Statements

[0000926326-18-000013:8k_2_02:33]
described more fully in Omnicell’s most recent filings with the Securities and Exchange Commission (SEC). Prospective investors are cautioned not to place undue reliance on forward-looking statements. All forward-looking statements contained in this press release speak only as of the date on which they were made. Omnicell undertakes no obligation to update such statements to reflect events that occur or circumstances that exist after the date on which they were made.

[0000926326-18-000013:8k_2_02:34]
Use of Non-GAAP Financial Information

[0000926326-18-000013:8k_2_02:35]
This press release contains financial measures that are not calculated in accordance with GAAP. Our management evaluates and makes operating decisions using various performance measures. In addition to Omnicell’s GAAP results, we also consider non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income, and non-GAAP net income per diluted share. Additionally, we calculate Adjusted EBITDA (another non-GAAP measure) by means of adjustments to GAAP Net Income. These non-GAAP results should not be considered as an alternative to gross profit, operating expenses, net income, net income per diluted share, or any other performance measure derived in accordance with GAAP. We present these non-GAAP results because we consider them to be important supplemental measures of Omnicell’s performance.

[0000926326-18-000013:8k_2_02:36]
Our non-GAAP revenue, non-GAAP gross profit, non-GAAP operating expenses, non-GAAP net income and non-GAAP net income per diluted share are exclusive of certain items to facilitate management’s review of the comparability of Omnicell’s core operating results on a period to period basis because such items are not related to Omnicell’s ongoing core operating results as viewed by management. We define our “core operating results” as those revenues recorded in a particular period and the expenses incurred within that period that directly drive operating income in that period. Management uses these non-GAAP financial measures in making operating decisions because, in addition to meaningful supplemental information regarding operating performance, the measures give us a better understanding of how we should invest in research and development, fund infrastructure growth and evaluate the effectiveness of marketing strategies. In calculating the above non-GAAP results, management specifically adjusted for the following excluded items:

[0000926326-18-000013:8k_2_02:37]
a)  Share-based compensation expense. We excluded from our non-GAAP results the expense related to equity-based compensation plans as they represent expenses that do not require cash settlement from Omnicell.

[0000926326-18-000013:8k_2_02:38]
b) Amortization of acquired intangible assets. We excluded from our non-GAAP results the intangible assets amortization expense resulting from our past acquisitions. These non-cash charges are not considered by management to reflect the core cash-generating performance of the business and therefore are excluded from our non-GAAP results.

[0000926326-18-000013:8k_2_02:39]
c) Amortization of debt issuance cost. Debt issuance cost represents costs associated with the issuance of Term Loan and Revolving Line of Credit facilities. The cost includes underwriting fees, original issue discount, ticking fee, and legal fees. This non-cash expense is not considered by management to reflect the core cash-generating performance of the business and therefore is excluded from our non-GAAP results.

[0000926326-18-000013:8k_2_02:40]
d) Acquisition accounting impact related to deferred revenue. In connection with recent acquisitions, business combination rules require us to account for the fair values of arrangements for which acceptance has not been obtained, and post installation support has not been provided in our purchase accounting. The non-GAAP adjustment to our revenues is intended to include the full amounts of such revenues. We believe the adjustment to these revenues is useful as a measure of the ongoing performance of our business.

[0000926326-18-000013:8k_2_02:41]
e) Inventory fair value adjustments. In connection with the acquisition of Aesynt, business combination rules require us to account for the fair values of inventory acquired in our purchase accounting. The non-GAAP adjustment to the cost of revenues is intended to include the impact of such adjustment. We believe the adjustment is useful as a measure of the ongoing performance of our business.

[0000926326-18-000013:8k_2_02:42]
f) Acquisition-related expenses. We excluded from the non-GAAP results the expenses which are related to recent acquisitions. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these acquisition-related expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance and the financial results of less acquisitive peer companies.

[0000926326-18-000013:8k_2_02:43]
g) Severance and other related expenses. We excluded from our non-GAAP results the expenses which are related to restructuring events. These expenses are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these expenses provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance and the financial results of peer companies.

[0000926326-18-000013:8k_2_02:44]
h) Tax reform impact. We excluded from our non-GAAP results the net one-time benefits related to the Tax Cuts and Jobs Act of 2017 based on the estimated impact of the revaluation of deferred tax assets and liabilities. These net benefits are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these net benefits provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance and the financial results of peer companies.

[0000926326-18-000013:8k_2_02:45]
i) Tax impact from restructuring activity. We excluded from our non-GAAP results the tax impacts related to restructuring activity. These impacts are unrelated to our ongoing operations and we do not expect them to occur in the ordinary course of business. We believe that excluding these impacts provides more meaningful comparisons of the financial results to our historical operations and forward-looking guidance and the financial results of peer companies.

[0000926326-18-000013:8k_2_02:46]
Management adjusts for the above items because management believes that, in general, these items possess one or more of the following characteristics: their magnitude and timing is largely outside of Omnicell’s control; they are unrelated to the ongoing operation of the business in the ordinary course; they are unusual and we do not expect them to occur in the ordinary course of business; or they are non-operational, or non-cash expenses involving stock compensation plans or other items.

[0000926326-18-000013:8k_2_02:47]
We believe that the presentation of these non-GAAP financial measures is warranted for several reasons:

[0000926326-18-000013:8k_2_02:48]
1) Such non-GAAP financial measures provide an additional analytical tool for understanding Omnicell’s financial performance by excluding the impact of items which may obscure trends in the core operating results of the business;

[0000926326-18-000013:8k_2_02:49]
2) Since we have historically reported non-GAAP results to the investment community, we believe the inclusion of non-GAAP numbers provides consistency and enhances investors’ ability to compare our performance across financial reporting periods;

[0000926326-18-000013:8k_2_02:50]
3) These non-GAAP financial measures are employed by Omnicell’s management in its own evaluation of performance and are utilized in financial and operational decision making processes, such as budget planning and forecasting; and

[0000926326-18-000013:8k_2_02:51]
4) These non-GAAP financial measures facilitate comparisons to the operating results of other companies in our industry, which use similar financial measures to supplement their GAAP results, thus enhancing the perspective of investors who wish to utilize such comparisons in their analysis of our performance.

[0000926326-18-000013:8k_2_02:52]
Set forth below are additional reasons why share-based compensation expense is excluded from our non-GAAP financial measures:

[0000926326-18-000013:8k_2_02:53]
i)  While share-based compensation calculated in accordance with ASC 718 constitutes an ongoing and recurring expense of Omnicell, it is not an expense that requires cash settlement by Omnicell. We therefore exclude these charges for purposes of evaluating core operating results. Thus, our non-GAAP measurements are presented exclusive of stock-based compensation expense to assist management and investors in evaluating our core operating results.

[0000926326-18-000013:8k_2_02:54]
ii) We present ASC 718 share-based payment compensation expense in our reconciliation of non-GAAP financial measures on a pre-tax basis because the exact tax differences related to the timing and deductibility of share-based compensation, under ASC 718 are dependent upon the trading price of Omnicell’s common stock and the timing and exercise by employees of their stock options. As a result of these timing and market uncertainties the tax effect related to share-based compensation expense would be inconsistent in amount and frequency and is therefore excluded from our non-GAAP results.

[0000926326-18-000013:8k_2_02:55]
Our Adjusted EBITDA calculation is defined as earnings before interest income and expense, taxes, depreciation and amortization, and non-cash expenses, including ASC 718 stock compensation expense, as well as certain non-GAAP adjustments.

[0000926326-18-000013:8k_2_02:56]
As stated above, we present non-GAAP financial measures because we consider them to be important supplemental measures of performance. However, non-GAAP financial measures have limitations as an analytical tool and should not be considered in isolation or as a substitute for Omnicell’s GAAP results. In the future, we expect to incur expenses similar to certain of the non-GAAP adjustments described above and expect to continue reporting non-GAAP financial measures excluding such items. Some of the limitations in relying on non-GAAP financial measures are:

[0000926326-18-000013:8k_2_02:57]
| • | Omnicell’s stock option and stock purchase plans are important components of incentive compensation arrangements and will be reflected as expenses in Omnicell’s GAAP results for the foreseeable future under ASC 718. |

[0000926326-18-000013:8k_2_02:58]
| • | Other companies, including companies in Omnicell’s industry, may calculate non-GAAP financial measures differently than Omnicell, limiting their usefulness as a comparative measure. |

[0000926326-18-000013:8k_2_02:59]
Pursuant to the requirements of SEC Regulation G, a detailed reconciliation between Omnicell’s non-GAAP and GAAP financial results is set forth in the financial tables at the end of this press release. Investors are advised to carefully review and consider this information strictly as a supplement to the GAAP results that are contained in this press release and in Omnicell’s SEC filings.

[0000926326-18-000013:8k_2_02:60]
With respect to the Company’s expectations under “2018 Guidance” above, and regarding certain projections discussed on today’s teleconference, reconciliation of non-GAAP earnings ranges per share guidance for 2018, to the closest corresponding GAAP measures is not available without unreasonable efforts as we are unable to predict with reasonable certainty the matters we would allocate to “certain items,” including unusual gains and losses, costs associated with future restructurings,  acquisition-related expenses and litigation outcomes. These items are uncertain, complex, depend on various factors, have low visibility and could have a material impact on GAAP EPS in future periods.

[0000926326-18-000013:8k_2_02:61]
5

[0000926326-18-000013:8k_2_02:62]
Omnicell, Inc.

[0000926326-18-000013:8k_2_02:63]
Condensed Consolidated Statements of Operations

[0000926326-18-000013:8k_2_02:64]
(Unaudited, in thousands, except per share data)

[0000926326-18-000013:8k_2_02:65]
|  | Three Months Ended |
|  | March 31, 2018 |  | December 31, 2017 |  | March 31, 2017 |
|  |  |  | As Adjusted* |  | As Reported |  | Change |  | As Adjusted* |  | As Reported |  | Change |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 130,104 |  |  | $ | 144,109 |  |  | $ | 144,120 |  |  | $ | (11 | ) |  | $ | 98,702 |  |  | $ | 98,930 |  |  | $ | (228 | ) |
| Services and other revenues | 52,515 |  |  | 52,262 |  |  | 53,824 |  |  | (1,562 | ) |  | 49,851 |  |  | 51,624 |  |  | (1,773 | ) |
| Total revenues | 182,619 |  |  | 196,371 |  |  | 197,944 |  |  | (1,573 | ) |  | 148,553 |  |  | 150,554 |  |  | (2,001 | ) |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product revenues | 75,417 |  |  | 79,791 |  |  | 79,791 |  |  | — |  |  | 63,588 |  |  | 63,588 |  |  | — |  |
| Cost of services and other revenues | 24,747 |  |  | 23,085 |  |  | 23,085 |  |  | — |  |  | 22,774 |  |  | 22,774 |  |  | — |  |
| Total cost of revenues | 100,164 |  |  | 102,876 |  |  | 102,876 |  |  | — |  |  | 86,362 |  |  | 86,362 |  |  | — |  |
| Gross profit | 82,455 |  |  | 93,495 |  |  | 95,068 |  |  | (1,573 | ) |  | 62,191 |  |  | 64,192 |  |  | (2,001 | ) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 16,537 |  |  | 15,894 |  |  | 15,894 |  |  | — |  |  | 16,803 |  |  | 16,803 |  |  | — |  |
| Selling, general and administrative | 65,285 |  |  | 61,401 |  |  | 63,494 |  |  | (2,093 | ) |  | 61,940 |  |  | 64,625 |  |  | (2,685 | ) |
| Total operating expenses | 81,822 |  |  | 77,295 |  |  | 79,388 |  |  | (2,093 | ) |  | 78,743 |  |  | 81,428 |  |  | (2,685 | ) |
| Income (loss) from operations | 633 |  |  | 16,200 |  |  | 15,680 |  |  | 520 |  |  | (16,552 | ) |  | (17,236 | ) |  | 684 |  |
| Interest and other income (expense), net | (2,729 | ) |  | (1,641 | ) |  | (1,641 | ) |  | — |  |  | (2,456 | ) |  | (2,456 | ) |  | — |  |
| Income (loss) before provision for income taxes | (2,096 | ) |  | 14,559 |  |  | 14,039 |  |  | 520 |  |  | (19,008 | ) |  | (19,692 | ) |  | 684 |  |
| Provision for (benefit from) income taxes | (4,816 | ) |  | (16,665 | ) |  | (10,252 | ) |  | (6,413 | ) |  | (8,673 | ) |  | (8,938 | ) |  | 265 |  |
| Net income (loss) | $ | 2,720 |  |  | $ | 31,224 |  |  | $ | 24,291 |  |  | $ | 6,933 |  |  | $ | (10,335 | ) |  | $ | (10,754 | ) |  | $ | 419 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.07 |  |  | $ | 0.82 |  |  | $ | 0.64 |  |  | $ | 0.18 |  |  | $ | (0.28 | ) |  | $ | (0.29 | ) |  | $ | 0.01 |  |
| Diluted | $ | 0.07 |  |  | $ | 0.79 |  |  | $ | 0.62 |  |  | $ | 0.17 |  |  | $ | (0.28 | ) |  | $ | (0.29 | ) |  | $ | 0.01 |  |
| Weighted average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 38,635 |  |  | 38,127 |  |  | 38,127 |  |  |  |  | 36,840 |  |  | 36,840 |  |  |  |
| Diluted | 39,691 |  |  | 39,482 |  |  | 39,482 |  |  |  |  | 36,840 |  |  | 36,840 |  |  |  |

[0000926326-18-000013:8k_2_02:66]
* As adjusted for full retrospective adoption of Accounting Standard Codification ("ASC") 606, "Revenue from Contracts with Customers".

[0000926326-18-000013:8k_2_02:67]
Omnicell, Inc.

[0000926326-18-000013:8k_2_02:68]
Condensed Consolidated Balance Sheets

[0000926326-18-000013:8k_2_02:69]
(Unaudited, in thousands)

[0000926326-18-000013:8k_2_02:70]
|  | March 31, 2018 |  | December 31, 2017 |
|  |  |  | As Adjusted* |  | As Reported |  | Change |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 43,773 |  |  | $ | 32,424 |  |  | $ | 32,424 |  |  | $ | — |  |
| Accounts receivable and unbilled, net | 190,678 |  |  | 190,046 |  |  | 189,227 |  |  | 819 |  |
| Inventories | 101,868 |  |  | 96,137 |  |  | 96,137 |  |  | — |  |
| Prepaid expenses | 21,161 |  |  | 20,392 |  |  | 36,060 |  |  | (15,668 | ) |
| Other current assets | 14,751 |  |  | 13,273 |  |  | 13,273 |  |  | — |  |
| Total current assets | 372,231 |  |  | 352,272 |  |  | 367,121 |  |  | (14,849 | ) |
| Property and equipment, net | 48,290 |  |  | 42,595 |  |  | 42,595 |  |  | — |  |
| Long-term investment in sales-type leases, net | 16,444 |  |  | 15,435 |  |  | 15,435 |  |  | — |  |
| Goodwill | 338,948 |  |  | 337,751 |  |  | 337,751 |  |  | — |  |
| Intangible assets, net | 162,458 |  |  | 168,107 |  |  | 168,107 |  |  | — |  |
| Long-term deferred tax assets | 9,456 |  |  | 9,454 |  |  | 9,454 |  |  | — |  |
| Prepaid commissions | 39,636 |  |  | 41,432 |  |  | — |  |  | 41,432 |  |
| Other long-term assets | 53,492 |  |  | 49,316 |  |  | 39,841 |  |  | 9,475 |  |
| Total assets | $ | 1,040,955 |  |  | $ | 1,016,362 |  |  | $ | 980,304 |  |  | $ | 36,058 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable | $ | 37,859 |  |  | $ | 48,290 |  |  | $ | 48,290 |  |  | $ | — |  |
| Accrued compensation | 29,632 |  |  | 27,241 |  |  | 27,241 |  |  | — |  |
| Accrued liabilities | 40,519 |  |  | 35,693 |  |  | 35,693 |  |  | — |  |
| Long-term debt, current portion, net | 17,708 |  |  | 15,208 |  |  | 15,208 |  |  | — |  |
| Deferred revenue, net | 95,709 |  |  | 78,774 |  |  | 86,104 |  |  | (7,330 | ) |
| Total current liabilities | 221,427 |  |  | 205,206 |  |  | 212,536 |  |  | (7,330 | ) |
| Long-term, deferred revenue | 8,806 |  |  | 10,623 |  |  | 17,244 |  |  | (6,621 | ) |
| Long-term deferred tax liabilities | 36,320 |  |  | 41,446 |  |  | 28,579 |  |  | 12,867 |  |
| Other long-term liabilities | 9,410 |  |  | 9,829 |  |  | 9,829 |  |  | — |  |
| Long-term debt, net | 190,490 |  |  | 194,917 |  |  | 194,917 |  |  | — |  |
| Total liabilities | 466,453 |  |  | 462,021 |  |  | 463,105 |  |  | (1,084 | ) |
| Total stockholders’ equity | 574,502 |  |  | 554,341 |  |  | 517,199 |  |  | 37,142 |  |
| Total liabilities and stockholders’ equity | $ | 1,040,955 |  |  | $ | 1,016,362 |  |  | $ | 980,304 |  |  | $ | 36,058 |  |

[0000926326-18-000013:8k_2_02:71]
* As adjusted for full retrospective adoption of Accounting Standard Codification ("ASC") 606, "Revenue from Contracts with Customers".

[0000926326-18-000013:8k_2_02:72]
7

[0000926326-18-000013:8k_2_02:73]
Omnicell, Inc.

[0000926326-18-000013:8k_2_02:74]
Condensed Consolidated Statements of Cash Flows

[0000926326-18-000013:8k_2_02:75]
(Unaudited, in thousands)

[0000926326-18-000013:8k_2_02:76]
|  | Three months ended March 31, |
|  | 2018 |  | 2017* |
| Operating Activities |  |  |  |
| Net income (loss) | $ | 2,720 |  |  | $ | (10,335 | ) |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 12,310 |  |  | 12,448 |  |
| Share-based compensation expense | 6,528 |  |  | 5,511 |  |
| Income tax benefits from employee stock plans | — |  |  | 11 |  |
| Deferred income taxes | (5,128 | ) |  | (8,826 | ) |
| Amortization of debt financing fees | 573 |  |  | 397 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | (632 | ) |  | 21,642 |  |
| Inventories | (6,881 | ) |  | (6,933 | ) |
| Prepaid expenses | (769 | ) |  | 79 |  |
| Other current assets | (997 | ) |  | 374 |  |
| Investment in sales-type leases | (1,491 | ) |  | 1,120 |  |
| Prepaid commissions | 1,796 |  |  | 208 |  |
| Other long-term assets | (1,673 | ) |  | (9,435 | ) |
| Accounts payable | (9,416 | ) |  | 11,104 |  |
| Accrued compensation | 2,391 |  |  | 1,955 |  |
| Accrued liabilities | 4,276 |  |  | (115 | ) |
| Deferred revenue | 15,118 |  |  | 8,471 |  |
| Other long-term liabilities | 131 |  |  | 506 |  |
| Net cash provided by operating activities | 18,856 |  |  | 28,182 |  |
| Investing Activities |  |  |  |
| Purchases of intangible assets, intellectual property and patents | — |  |  | (160 | ) |
| Software development for external use | (5,272 | ) |  | (4,225 | ) |
| Purchases of property and equipment | (9,268 | ) |  | (2,452 | ) |
| Net cash used in investing activities | (14,540 | ) |  | (6,837 | ) |
| Financing Activities |  |  |  |
| Repayment of debt and revolving credit facility | (2,500 | ) |  | (40,000 | ) |
| Proceeds from issuances under stock-based compensation plans | 9,541 |  |  | 10,916 |  |
| Employees' taxes paid related to restricted stock units | (1,300 | ) |  | (1,052 | ) |
| Net cash provided by (used in) financing activities | 5,741 |  |  | (30,136 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 1,292 |  |  | 651 |  |
| Net increase (decrease) in cash and cash equivalents | 11,349 |  |  | (8,140 | ) |
| Cash and cash equivalents at beginning of period | 32,424 |  |  | 54,488 |  |
| Cash and cash equivalents at end of period | $ | 43,773 |  |  | $ | 46,348 |  |

[0000926326-18-000013:8k_2_02:77]
* As adjusted for full retrospective adoption of Accounting Standard Codification ("ASC") 606, "Revenue from Contracts with Customers".

[0000926326-18-000013:8k_2_02:78]
Omnicell, Inc.

[0000926326-18-000013:8k_2_02:79]
Reconciliation of GAAP to Non-GAAP

[0000926326-18-000013:8k_2_02:80]
(Unaudited, in thousands, except per share data and percentage)

[0000926326-18-000013:8k_2_02:81]
|  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  |  | March 31, 2018 |  | December 31, 2017* |  | March 31, 2017* |
| Reconciliation of GAAP revenue to non-GAAP revenue: |  |  |
| GAAP revenue |  | $ | 182,619 |  |  | $ | 196,371 |  |  | $ | 148,553 |  |
|  | Acquisition accounting impact related to deferred revenue | — |  |  | 313 |  |  | 313 |  |
| Non-GAAP revenue | $ | 182,619 |  |  | $ | 196,684 |  |  | $ | 148,866 |  |
| Reconciliation of GAAP gross profit to non-GAAP gross profit: |  |  |
| GAAP gross profit | $ | 82,455 |  |  | $ | 93,495 |  |  | $ | 62,191 |  |
| GAAP gross margin | 45.2% |  | 47.6% |  | 41.9% |
|  | Share-based compensation expense | 1,019 |  |  | 834 |  |  | 982 |  |
|  | Amortization of acquired intangibles | 2,791 |  |  | 2,818 |  |  | 2,837 |  |
|  | Acquisition accounting impact related to deferred revenue | — |  |  | 313 |  |  | 313 |  |
|  | Severance and other expenses | — |  |  | 234 |  |  | 1,697 |  |
| Non-GAAP gross profit | $ | 86,265 |  |  | $ | 97,694 |  |  | $ | 68,020 |  |
| Non-GAAP gross margin | 47.2% |  | 49.7% |  | 45.7% |
| Reconciliation of GAAP operating expenses to non-GAAP operating expenses: |
| GAAP operating expenses | $ | 81,822 |  |  | $ | 77,295 |  |  | $ | 78,743 |  |
| GAAP operating expenses % to total revenue |  | 44.8% |  | 39.4% |  | 53.0% |
|  | Share-based compensation expense | (5,509 | ) |  | (4,708 | ) |  | (4,529 | ) |
|  | Amortization of acquired intangibles | (3,238 | ) |  | (3,348 | ) |  | (3,653 | ) |
|  | Acquisitions related expenses | — |  |  | — |  |  | (126 | ) |
|  | Severance and other expenses | (1,512 | ) |  | (233 | ) |  | (2,332 | ) |
| Non-GAAP operating expenses | $ | 71,563 |  |  | $ | 69,006 |  |  | $ | 68,103 |  |
| Non-GAAP operating expenses % to total revenue | 39.2% |  | 35.1% |  | 45.7% |

[0000926326-18-000013:8k_2_02:82]
* As adjusted for full retrospective adoption of Accounting Standard Codification ("ASC") 606, "Revenue from Contracts with Customers".

[0000926326-18-000013:8k_2_02:83]
9

[0000926326-18-000013:8k_2_02:84]
|  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  |  | March 31, 2018 |  | December 31, 2017* |  | March 31, 2017* |
| Reconciliation of GAAP income (loss) from operations to non-GAAP income (loss) from operations: |
| GAAP income (loss) from operations | $ | 633 |  |  | $ | 16,200 |  |  | $ | (16,552 | ) |
| GAAP operating income (loss) % to total revenue |  | 0.3% |  | 8.2% |  | (11.1)% |
|  | Share-based compensation expense | 6,528 |  |  | 5,542 |  |  | 5,511 |  |
|  | Amortization of acquired intangibles | 6,029 |  |  | 6,166 |  |  | 6,490 |  |
|  | Acquisition accounting impact related to deferred revenue | — |  |  | 313 |  |  | 313 |  |
|  | Acquisitions related expenses | — |  |  | — |  |  | 126 |  |
|  | Severance and other expenses | 1,512 |  |  | 467 |  |  | 4,029 |  |
| Non-GAAP income (loss) from operations | $ | 14,702 |  |  | $ | 28,688 |  |  | $ | (83 | ) |
| Non-GAAP operating income (loss) % to total Non-GAAP revenue | 8.1% |  | 14.6% |  | (0.1)% |
| Reconciliation of GAAP net income (loss) to non-GAAP net income: |  |  |
| GAAP net income (loss) | $ | 2,720 |  |  | $ | 31,224 |  |  | $ | (10,335 | ) |
|  | Tax reform benefit impact | — |  |  | (20,005 | ) |  | — |  |
|  | Tax benefit for restructuring activity | (4,205 | ) |  | — |  |  | — |  |
|  | Share-based compensation expense | 6,528 |  |  | 5,542 |  |  | 5,511 |  |
|  | Amortization of acquired intangibles | 6,029 |  |  | 6,166 |  |  | 6,490 |  |
|  | Acquisition accounting impact related to deferred revenue | — |  |  | 313 |  |  | 313 |  |
|  | Acquisitions related expenses(c) | 397 |  |  | 397 |  |  | 523 |  |
|  | Severance and other expenses | 1,688 |  |  | 467 |  |  | 4,029 |  |
|  | Tax effect of the adjustments above(a) | (1,703 | ) |  | (2,570 | ) |  | (4,019 | ) |
| Non-GAAP net income | $ | 11,454 |  |  | $ | 21,534 |  |  | $ | 2,512 |  |
| Reconciliation of GAAP net income (loss) per share - diluted to non-GAAP net income per share - diluted: |
| Shares - diluted GAAP | 39,691 |  |  | 39,482 |  |  | 36,840 |  |
| Shares - diluted Non-GAAP | 39,691 |  |  | 39,482 |  |  | 37,782 |  |
| GAAP net income (loss) per share - diluted | $ | 0.07 |  |  | $ | 0.79 |  |  | $ | (0.28 | ) |
|  | Tax reform benefit impact | — |  |  | (0.50 | ) |  | — |  |
|  | Tax benefit for restructuring activity | (0.10 | ) |  | — |  |  | — |  |
|  | Share-based compensation expense | 0.16 |  |  | 0.14 |  |  | 0.15 |  |
|  | Amortization of acquired intangibles | 0.15 |  |  | 0.16 |  |  | 0.17 |  |
|  | Acquisition accounting impact related to deferred revenue | — |  |  | 0.01 |  |  | 0.01 |  |
|  | Acquisition related expenses | 0.01 |  |  | 0.01 |  |  | 0.01 |  |
|  | Severance and other expenses | 0.04 |  |  | 0.01 |  |  | 0.11 |  |
|  | Tax effect of the adjustments above(a) | (0.04 | ) |  | (0.07 | ) |  | (0.10 | ) |
| Non-GAAP net income per share - diluted | $ | 0.29 |  |  | $ | 0.55 |  |  | $ | 0.07 |  |
| Reconciliation of GAAP net income (loss) to non-GAAP Adjusted EBITDA(b): |  |  |
| GAAP net income (loss) | $ | 2,720 |  |  | $ | 31,224 |  |  | $ | (10,335 | ) |
|  | Share-based compensation expense | 6,528 |  |  | 5,542 |  |  | 5,511 |  |
|  | Interest (income) and expense, net | 1,772 |  |  | 1,202 |  |  | 1,432 |  |
|  | Depreciation and amortization expense | 12,310 |  |  | 12,969 |  |  | 12,448 |  |
|  | Acquisition accounting impact related to deferred revenue | — |  |  | 313 |  |  | 313 |  |
|  | Acquisitions related expenses | 397 |  |  | 397 |  |  | 523 |  |
|  | Severance expense | 1,688 |  |  | 213 |  |  | 3,765 |  |
|  | Income tax expense | (4,816 | ) |  | (16,665 | ) |  | (8,673 | ) |
| Non-GAAP Adjusted EBITDA | $ | 20,599 |  |  | $ | 35,195 |  |  | $ | 4,984 |  |

[0000926326-18-000013:8k_2_02:85]
(a) Tax effects calculated for all adjustments except tax benefits and share-based compensation expense, using an estimated annual effective tax rate of 21% for fiscal year 2018 and 35% for fiscal year 2017.

[0000926326-18-000013:8k_2_02:86]
(b) Defined as earnings before interest income and expense, taxes, depreciation and amortization, as well as excluding certain non-GAAP adjustments.

[0000926326-18-000013:8k_2_02:87]
(c) Includes amortization of debt financing fees associated with our debt facilities.

[0000926326-18-000013:8k_2_02:88]
Omnicell, Inc.

[0000926326-18-000013:8k_2_02:89]
Segmented Information

[0000926326-18-000013:8k_2_02:90]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000013:8k_2_02:91]
|  | Three Months Ended March 31, 2018 |  | Three Months Ended March 31, 2017 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics * |  | MedicationAdherence |  | Total* |
| Revenues | $ | 151,406 |  |  | $ | 31,213 |  |  | $ | 182,619 |  |  | $ | 122,170 |  |  | $ | 26,383 |  |  | $ | 148,553 |  |
| Cost of revenues | 78,242 |  |  | 21,922 |  |  | 100,164 |  |  | 68,761 |  |  | 17,601 |  |  | 86,362 |  |
| Gross profit | 73,164 |  |  | 9,291 |  |  | 82,455 |  |  | 53,409 |  |  | 8,782 |  |  | 62,191 |  |
| Gross margin % | 48.3% |  | 29.8% |  | 45.2% |  | 43.7% |  | 33.3% |  | 41.9% |
| Operating expenses | 48,390 |  |  | 10,199 |  |  | 58,589 |  |  | 48,062 |  |  | 11,196 |  |  | 59,258 |  |
| Income (loss) from segment operations | $ | 24,774 |  |  | $ | (908 | ) |  | $ | 23,866 |  |  | $ | 5,347 |  |  | $ | (2,414 | ) |  | $ | 2,933 |  |
| Operating margin % | 16.4% |  | (2.9)% |  | 13.1% |  | 4.4% |  | (9.1)% |  | 2.0% |
| Corporate costs |  |  |  |  | 23,233 |  |  |  |  |  |  | 19,485 |  |
| Income (loss) from operations |  |  |  |  | $ | 633 |  |  |  |  |  |  | $ | (16,552 | ) |

[0000926326-18-000013:8k_2_02:92]
* As adjusted for full retrospective adoption of Accounting Standard Codification ("ASC") 606, "Revenue from Contracts with Customers".

[0000926326-18-000013:8k_2_02:93]
11

[0000926326-18-000013:8k_2_02:94]
Omnicell, Inc.

[0000926326-18-000013:8k_2_02:95]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-18-000013:8k_2_02:96]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000013:8k_2_02:97]
|  | Three Months Ended March 31, 2018 |  |  |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 151,406 |  |  |  |  |  |  | $ | 31,213 |  |  |  |  |  |  | $ | 182,619 |  |  |  |  |  |
| Non-GAAP Revenues | $ | 151,406 |  |  |  |  |  |  | $ | 31,213 |  |  |  |  |  |  | $ | 182,619 |  |  |  |  |  |
| GAAP Gross profit | $ | 73,164 |  |  | 48.3 | % |  |  |  | $ | 9,291 |  |  | 29.8 | % |  |  |  | $ | 82,455 |  |  | 45.2 | % |  |  |
| Share-based compensation expense | 873 |  |  | 0.6 | % |  | 0.6 | % |  | 146 |  |  | 0.5 | % |  | 0.5 | % |  | 1,019 |  |  | 0.6 | % |  | 0.6 | % |
| Amortization expense of acquired intangible assets | 2,247 |  |  | 1.5 | % |  | 1.5 | % |  | 544 |  |  | 1.7 | % |  | 1.7 | % |  | 2,791 |  |  | 1.5 | % |  | 1.5 | % |
| Non-GAAP Gross profit | $ | 76,284 |  |  |  |  | 50.4 | % |  | $ | 9,981 |  |  |  |  | 32.0 | % |  | $ | 86,265 |  |  |  |  | 47.2 | % |
| GAAP Operating income (loss) | $ | 24,774 |  |  | 16.4 | % |  |  |  | $ | (908 | ) |  | (2.9 | )% |  |  |  | $ | 23,866 |  |  | 13.1 | % |  |  |
| Share-based compensation expense | 2,730 |  |  | 1.8 | % |  | 1.8 | % |  | 446 |  |  | 1.4 | % |  | 1.4 | % |  | 3,176 |  |  | 1.7 | % |  | 1.7 | % |
| Amortization expense of acquired intangible assets | 4,302 |  |  | 2.8 | % |  | 2.8 | % |  | 1,727 |  |  | 5.5 | % |  | 5.5 | % |  | 6,029 |  |  | 3.3 | % |  | 3.3 | % |
| Severance and other expenses | 375 |  |  | 0.2 | % |  | 0.2 | % |  | 71 |  |  | 0.2 | % |  | 0.2 | % |  | 446 |  |  | 0.2 | % |  | 0.2 | % |
| Non-GAAP Operating income | $ | 32,181 |  |  |  |  | 21.3 | % |  | $ | 1,336 |  |  |  |  | 4.3 | % |  | $ | 33,517 |  |  |  |  | 18.4 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 23,233 |  |  | 12.7 | % |  |  |
| Share-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (3,352 | ) |  | (1.8 | )% |  | (1.8 | )% |
| Severance and other expenses |  |  |  |  |  |  |  |  |  |  |  |  | (1,066 | ) |  | (0.6 | )% |  | (0.6 | )% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 18,815 |  |  |  |  | 10.3 | % |
| Non-GAAP Income from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | 14,702 |  |  |  |  | 8.1 | % |

[0000926326-18-000013:8k_2_02:98]
Omnicell, Inc.

[0000926326-18-000013:8k_2_02:99]
Segment Information - Non-GAAP Gross Profit and Non-GAAP Operating Margin

[0000926326-18-000013:8k_2_02:100]
(Unaudited, in thousands, except for percentages)

[0000926326-18-000013:8k_2_02:101]
|  | Three Months Ended March 31, 2017 |  |  |
|  | Automation andAnalytics* |  | MedicationAdherence |  | Total* |
|  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |  | Amount |  | % of GAAP Revenue |  | % of Non-GAAP Revenue |
| Revenues | $ | 122,170 |  |  |  |  |  |  | $ | 26,383 |  |  |  |  |  |  | $ | 148,553 |  |  |  |  |  |
| Acquisition accounting impact related to deferred revenue | — |  |  | — | % |  | — | % |  | 313 |  |  | 1.2 | % |  | 1.2 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Non-GAAP Revenues | $ | 122,170 |  |  |  |  |  |  | $ | 26,696 |  |  |  |  |  |  | $ | 148,866 |  |  |  |  |  |
| GAAP Gross profit | $ | 53,409 |  |  | 43.7 | % |  |  |  | $ | 8,782 |  |  | 33.3 | % |  |  |  | $ | 62,191 |  |  | 41.9 | % |  |  |
| Stock-based compensation expense | 863 |  |  | 0.7 | % |  | 0.7 | % |  | 119 |  |  | 0.5 | % |  | 0.4 | % |  | 982 |  |  | 0.7 | % |  | 0.7 | % |
| Amortization expense of acquired intangible assets | 2,187 |  |  | 1.8 | % |  | 1.8 | % |  | 650 |  |  | 2.5 | % |  | 2.4 | % |  | 2,837 |  |  | 1.9 | % |  | 1.9 | % |
| Acquisition accounting impact related to deferred revenue | — |  |  | — | % |  | — | % |  | 313 |  |  | 1.2 | % |  | 1.2 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Severance and other expenses | 1,266 |  |  | 1.0 | % |  | 1.0 | % |  | 431 |  |  | 1.6 | % |  | 1.6 | % |  | 1,697 |  |  | 1.1 | % |  | 1.1 | % |
| Non-GAAP Gross profit | $ | 57,725 |  |  |  |  | 47.2 | % |  | $ | 10,295 |  |  |  |  | 38.6 | % | $ | — |  | $ | 68,020 |  |  |  |  | 45.7 | % |
| GAAP Operating income (loss) | $ | 5,347 |  |  | 4.4 | % |  |  |  | $ | (2,414 | ) |  | (9.1 | )% |  |  |  | $ | 2,933 |  |  | 2.0 | % |  |  |
| Stock-based compensation expense | 2,500 |  |  | 2.0 | % |  | 2.0 | % |  | 366 |  |  | 1.4 | % |  | 1.4 | % |  | 2,866 |  |  | 1.9 | % |  | 1.9 | % |
| Amortization expense of acquired intangible assets | 4,506 |  |  | 3.7 | % |  | 3.7 | % |  | 1,984 |  |  | 7.5 | % |  | 7.4 | % |  | 6,490 |  |  | 4.4 | % |  | 4.4 | % |
| Acquisition accounting impact related to deferred revenue | — |  |  | — | % |  | — | % |  | 313 |  |  | 1.2 | % |  | 1.2 | % |  | 313 |  |  | 0.2 | % |  | 0.2 | % |
| Acquisitions related expenses | 18 |  |  | — | % |  | — | % |  | — |  |  | — | % |  | — | % |  | 18 |  |  | — | % |  | — | % |
| Severance and other expenses | 2,752 |  |  | 2.3 | % |  | 2.3 | % |  | 596 |  |  | 2.3 | % |  | 2.2 | % |  | 3,348 |  |  | 2.3 | % |  | 2.2 | % |
| Non-GAAP Operating income | $ | 15,123 |  |  |  |  | 12.4 | % |  | $ | 845 |  |  |  |  | 3.2 | % |  | $ | 15,968 |  |  |  |  | 10.7 | % |
| GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 19,485 |  |  | 13.1 | % |  |  |
| Stock-based compensation expense |  |  |  |  |  |  |  |  |  |  |  |  | (2,645 | ) |  | (1.8 | )% |  | (1.8 | )% |
| Acquisition related expenses |  |  |  |  |  |  |  |  |  |  |  |  | (108 | ) |  | (0.1 | )% |  | (0.1 | )% |
| Severance and other expenses |  |  |  |  |  |  |  |  |  |  |  |  | (681 | ) |  | (0.5 | )% |  | (0.5 | )% |
| Non-GAAP Corporate costs |  |  |  |  |  |  |  |  |  |  |  |  | $ | 16,051 |  |  |  |  | 10.8 | % |
| Non-GAAP loss from operations |  |  |  |  |  |  |  |  |  |  |  |  | $ | (83 | ) |  |  |  | (0.1 | )% |

[0000926326-18-000013:8k_2_02:102]
* As adjusted for full retrospective adoption of Accounting Standard Codification ("ASC") 606, "Revenue from Contracts with Customers".

[0000926326-18-000013:8k_2_02:103]
13
