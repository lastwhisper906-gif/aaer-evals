# OMCL note change history — 0000926326-17-000038 → 0000926326-18-000015


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-04):
[0000926326-18-000015:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At March 31, 2018, the minimum future payments on non-cancelable operating leases were as follows:
  (was, 2017-11-03, similarity 0.9513):
[0000926326-17-000038:note_history:1]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At September 30, 2017, the minimum future payments on non-cancelable operating leases were as follows:

- changed (2018-05-04):
[0000926326-18-000015:note_history:2]
|  | (In thousands) |
| Remaining nine months of 2018 | $ | 8,896 |  |
| 2019 | 11,763 |  |
| 2020 | 10,803 |  |
| 2021 | 10,515 |  |
| 2022 | 8,818 |  |
| Thereafter | 26,383 |  |
| Total minimum future lease payments | $ | 77,178 |  |
  (was, 2017-11-03, similarity 0.9806):
[0000926326-17-000038:note_history:2]
|  | (In thousands) |
| Remaining three months of 2017 | $ | 3,203 |  |
| 2018 | 12,447 |  |
| 2019 | 12,270 |  |
| 2020 | 10,972 |  |
| 2021 | 10,316 |  |
| Thereafter | 31,168 |  |
| Total minimum future lease payments | $ | 80,376 |  |

- changed (2018-05-04):
[0000926326-18-000015:note_history:3]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At March 31, 2018, the Company had non-cancelable purchase commitments of $55.4 million, which are expected to be paid within the next twelve months.
  (was, 2017-11-03, similarity 0.9725):
[0000926326-17-000038:note_history:3]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At September 30, 2017, the Company had non-cancelable purchase commitments of $59.9 million, which are expected to be paid within the next twelve months.

- added (2018-05-04):
[0000926326-18-000015:note_history:4]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

- added (2018-05-04):
[0000926326-18-000015:note_history:5]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al. (Case No. CL18-152-1). The complaint seeks monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention and training and, as against the Company and Aesynt, claims of product liability, negligence and breach of implied warranties. The Company and Aesynt have not yet been served with the complaint. The Company intends to defend the lawsuit vigorously.

- removed (2018-05-04):
[0000926326-17-000038:note_history:6]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with any current legal proceedings based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

- removed (2018-05-04):
[0000926326-17-000038:note_history:7]
The Company is not a party to any legal proceedings that management believes may have a material impact on the Company's financial position or results of operations.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-05-04):
[0000926326-18-000015:note_history:8]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company's major products are automated medication, supply control systems and medication adherence solutions which are sold in its principal market, which is the healthcare industry. The Company's market is primarily located in the United States and Europe. "Omnicell" or the "Company" collectively refer to Omnicell, Inc. and its subsidiaries.
  (was, 2017-11-03, similarity 0.9425):
[0000926326-17-000038:note_history:8]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. Our major products are automated medication, supply control systems and medication adherence solutions which are sold in our principal market, which is the healthcare industry. Our market is primarily located in the United States and Europe. "Omnicell", "our", "us", "we" or the "Company" collectively refer to Omnicell, Inc. and its subsidiaries.

- changed (2018-05-04):
[0000926326-18-000015:note_history:9]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2018 and December 31, 2017, the results of its operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2018 and March 31, 2017. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2017 filed with the SEC on February 27, 2018, except as discussed in the "Revenue recognition" below. The Company's results of operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2018 are not necessarily indicative of results that may be expected for the year ending December 31, 2018, or for any future period.
  (was, 2017-11-03, similarity 0.7435):
[0000926326-17-000038:note_history:9]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2017 and December 31, 2016, the results of its operations, comprehensive income (loss) and cash flows for the three and nine months ended September 30, 2017 and September 30, 2016. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2016 filed with the SEC on February 28, 2017. The Company's results of operations, comprehensive income (loss) and cash flows for the three and nine months ended September 30, 2017 are not necessarily indicative of results that may be expected for the year ending December 31, 2017, or for any future period.

- added (2018-05-04):
[0000926326-18-000015:note_history:10]
Certain prior year amounts have been adjusted to conform with the adoption of ASC 606, Revenue from Contracts with Customers ("ASC 606"), which became effective for the Company beginning on January 1, 2018. Refer to "Recently adopted authoritative guidance" for the effects of adoption of ASC 606 and the section below for the updated revenue recognition policy.

- added (2018-05-04):
[0000926326-18-000015:note_history:11]
Revenue recognition

- added (2018-05-04):
[0000926326-18-000015:note_history:12]
The Company earns revenues from sales of its medication and medical and surgical supply automation systems along with consumables and related services, which are sold in the healthcare industry, our principal market. The transaction price of each contract with a customer is allocated to identified performance obligations based on the relative fair value of each obligation. The Company's customer arrangements typically include one or more of the following performance obligations:

- added (2018-05-04):
[0000926326-18-000015:note_history:13]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

- added (2018-05-04):
[0000926326-18-000015:note_history:14]
Software. Additional software applications that enable incremental functionality of its equipment.

- added (2018-05-04):
[0000926326-18-000015:note_history:15]
Installation. Installation of equipment as integrated systems at customers' sites.

- added (2018-05-04):
[0000926326-18-000015:note_history:16]
Post-installation technical support. Phone support, on-site service, parts and access to unspecified software updates and enhancements, if and when available.

- added (2018-05-04):
[0000926326-18-000015:note_history:17]
Professional services. Other customer services, such as training and consulting.

- added (2018-05-04):
[0000926326-18-000015:note_history:18]
Prior to recognizing revenue, the Company identifies the contract, performance obligations, and transaction price, and allocates the transaction price to the performance obligations. All identified contracts meet the following required criteria:

- added (2018-05-04):
[0000926326-18-000015:note_history:19]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of the Company’s contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via phone or a manual purchase order.

- added (2018-05-04):
[0000926326-18-000015:note_history:20]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following our standard business process and terms.

- added (2018-05-04):
[0000926326-18-000015:note_history:21]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 days from shipment of tangible product or services performed. Where a written contract does not exist, the Company’s standard payment terms are net 30 day terms.

- added (2018-05-04):
[0000926326-18-000015:note_history:22]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract.) The Company's agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.

- added (2018-05-04):
[0000926326-18-000015:note_history:23]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. The Company performs a credit check for all significant customers or transactions and where collectability is not probable, payment in full or a substantial down payment is typically required to help assure the full agreed upon contract price will be collected.

- added (2018-05-04):
[0000926326-18-000015:note_history:24]
The Company often enters into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. The Company’s change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

- added (2018-05-04):
[0000926326-18-000015:note_history:25]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation.  Where a good or service is determined not to be distinct, the Company combines the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify its performance obligations, the Company considers all of the products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, the Company considers an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of the Company’s sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, consumables and software products, support and maintenance, and professional services.

- added (2018-05-04):
[0000926326-18-000015:note_history:26]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of the Company’s commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

- added (2018-05-04):
[0000926326-18-000015:note_history:27]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an expected cost plus a margin approach to identify the standalone selling price of goods where separate sales transactions do not exist. For software and services which do not have a specific identifiable product cost, the Company uses a discounted from the list price amount as a best estimated selling price.

- added (2018-05-04):
[0000926326-18-000015:note_history:28]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service.  Determining when control transfers requires management to make judgments that affect the timing of revenue recognized.  Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligation at March 31, 2018 and December 31, 2017 was $104.5 million and $89.4 million, respectively, of which $95.7 million and $78.8 million, respectively, was expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

- added (2018-05-04):
[0000926326-18-000015:note_history:29]
Revenues, contract assets and contract liabilities are recorded net of associated taxes.

- added (2018-05-04):
[0000926326-18-000015:note_history:30]
The payment terms associated with the Company’s contracts vary, however, payment terms for product revenue are generally based on milestones tied to contract signing, shipment of products and/or customer acceptance. Payment terms associated with the service portion of agreements are generally periodic and can be billed on a monthly, quarterly or annual basis. In certain circumstances multiple years are billed at one time. The portion of these contract liabilities not expected to be recognized as revenue within twelve months of the balance sheet date are considered long term.

- added (2018-05-04):
[0000926326-18-000015:note_history:31]
In the normal course of business, the Company typically does not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. The Company establishes provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to the Condensed Consolidated Financial Statements for any periods presented.

- added (2018-05-04):
[0000926326-18-000015:note_history:32]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 40% of the lease receivable balance, are retained in-house. Revenue from sales-type leases of $9.8 million and $3.2 million for the three months ended March 31, 2018 and 2017, respectively, is included in product revenue in the Condensed Consolidated Statements of Operations. Interest income in these leases is recognized in product revenue using the effective interest method.

- added (2018-05-04):
[0000926326-18-000015:note_history:33]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations ("GPOs"). GPOs are often owned fully or in part by the Company’s customers and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $1.9 million and $2.1 million for the quarters ended March 31, 2018 and 2017, respectively.

- added (2018-05-04):
[0000926326-18-000015:note_history:34]
Contract assets and contract liabilities

- added (2018-05-04):
[0000926326-18-000015:note_history:35]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

- added (2018-05-04):
[0000926326-18-000015:note_history:36]
The following table reflects the Company’s contract assets and contract liabilities:

- added (2018-05-04):
[0000926326-18-000015:note_history:37]
|  | March 31, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Short-term unbilled receivable - included in accounts receivable and unbilled | $ | 4,859 |  |  | $ | 4,590 |  |
| Long-term unbilled receivable - included in other long-term assets | 10,877 |  |  | 9,475 |  |
| Total contract assets | $ | 15,736 |  |  | $ | 14,065 |  |
| Short-term deferred revenue | $ | 95,709 |  |  | $ | 78,774 |  |
| Long-term deferred revenue | 8,806 |  |  | 10,623 |  |
| Total contract liabilities | $ | 104,515 |  |  | $ | 89,397 |  |

- added (2018-05-04):
[0000926326-18-000015:note_history:38]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenue in the normal course of business. Unbilled contract assets which were invoiced during the three months ended March 31, 2018 as a result of the right to invoice for the transaction consideration becoming unconditional were not material. The contract modifications entered into during the three months ended March 31, 2018, did not have a significant impact on the Company’s contract assets or deferred revenues. During the three months ended March 31, 2018, the Company recognized revenue of $46.6 million that was included in the corresponding deferred revenue balance as of December 31, 2017.

- added (2018-05-04):
[0000926326-18-000015:note_history:39]
Contract costs

- added (2018-05-04):
[0000926326-18-000015:note_history:40]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio.  A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods. During the three months ended March 31, 2018 and March 31, 2017, the Company recognized contract cost expense of $5.6 million and $4.1 million, respectively. The portion of commission expenses paid as of the balance sheet date to be recognized in future periods is recorded in long term prepaid commissions expense on the Condensed Consolidated Balance Sheets. There was no impairment loss in relation to the costs capitalized during the three months ended March 31, 2018.

- added (2018-05-04):
[0000926326-18-000015:note_history:41]
In May 2014, the Financial Accounting Standards Board ("FASB") issued ASC 606, Revenue from Contracts with Customers, a new standard related to revenue recognition. Under the new standard, revenue is recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In addition, the standard requires disclosure of the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method). We adopted the standard using the full retrospective method effective beginning January 1, 2018.

- added (2018-05-04):
[0000926326-18-000015:note_history:42]
Under the ASC 606 guidance, fees paid to GPOs are now presented as a reduction of Product Revenue, whereas these fees were considered a part of Selling, General and Administrative costs under the previous guidance. The majority of the incremental costs incurred to obtain a contract, primarily commission expense, are recognized during the first year with the balance recognized ratably over a period of ten years. Additionally, revenue on term software licenses is recognized upon installation of the license rather than ratably over the life of the term license. Finally, the Company no longer defers the contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price. Adoption of the standard related to revenue recognition impacted our reported results for the three months period, as follows:

- added (2018-05-04):
[0000926326-18-000015:note_history:43]
|  | March 31, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenue |  |  |  |  |  |
| Automation and Analytics | $ | 124,171 |  |  | $ | (2,001 | ) |  | $ | 122,170 |  |
| Medication Adherence | 26,383 |  |  | — |  |  | 26,383 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 55,410 |  |  | (2,001 | ) |  | 53,409 |  |
| Medication Adherence | 8,782 |  |  | — |  |  | 8,782 |  |
| Selling, general and administrative expenses | 64,625 |  |  | (2,685 | ) |  | 61,940 |  |
| Provision for income taxes | (8,938 | ) |  | 265 |  |  | (8,673 | ) |
| Net income | $ | (10,754 | ) |  | $ | 419 |  |  | $ | (10,335 | ) |
| Earnings per share | $ | (0.29 | ) |  | $ | 0.01 |  |  | $ | (0.28 | ) |

- added (2018-05-04):
[0000926326-18-000015:note_history:44]
|  | December 31, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Accounts receivable and unbilled, net | $ | 189,227 |  |  | $ | 819 |  |  | $ | 190,046 |  |
| Prepaid expenses | 36,060 |  |  | (15,668 | ) |  | 20,392 |  |
| Prepaid commissions | — |  |  | 41,432 |  |  | 41,432 |  |
| Other long-term assets | 39,841 |  |  | 9,475 |  |  | 49,316 |  |
| Deferred revenue, net | 86,104 |  |  | (7,330 | ) |  | 78,774 |  |
| Long-term, deferred revenue | 17,244 |  |  | (6,621 | ) |  | 10,623 |  |
| Long-term, deferred tax liabilities | 28,579 |  |  | 12,867 |  |  | 41,446 |  |
| Stockholders' equity | 517,199 |  |  | 37,142 |  |  | 554,341 |  |

- added (2018-05-04):
[0000926326-18-000015:note_history:45]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects”. ASU 2018-02 will be effective for the Company beginning January 1, 2019. The Company is currently in the process of evaluating the impact of adoption on the consolidated financial statements.

- removed (2018-05-04):
[0000926326-17-000038:note_history:46]
Certain prior year amounts have been reclassified to conform to the 2017 presentation with the adoption of ASU 2016-09, Compensation—Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. Additionally, see "Recently adopted authoritative guidance" for the effects of first quarter adoption of ASU 2016-09.

- removed (2018-05-04):
[0000926326-17-000038:note_history:47]
In March 2016, the FASB issued ASU No. 2016-09. This ASU simplifies several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The provision of ASU No. 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. The Company adopted the standard effective January 1, 2017.  The impact of adoption was the recording of excess tax benefits within income tax expense, rather than in Additional Paid in Capital of $2.1 million and $4.7 million for the three and nine months ended September 30, 2017, respectively.  Additionally, in the first quarter of 2017, the Company recognized the previously unrecognized excess tax benefits using the modified retrospective transition method, which resulted in a cumulative-effect adjustment of $1.6 million to retained earnings.

- removed (2018-05-04):
[0000926326-17-000038:note_history:48]
In January 2017, the FASB issued ASU 2017-04, Intangibles-Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment, which simplifies the accounting for goodwill impairment for all entities by requiring impairment charges to be based on the first step in today’s two-step impairment test under ASC 350, “Intangibles-Goodwill and Other.” Under the new guidance, if a reporting unit’s carrying amount exceeds its fair value, an entity will record an impairment charge based on that difference. The impairment charge will be limited to the amount of goodwill allocated to that reporting unit. The standard eliminates the current ASC 350 requirement to calculate a goodwill impairment charge using Step 2. ASU 2017-04 is effective for annual and interim impairment tests performed in periods beginning after December 15, 2019. Early adoption is permitted for annual and interim goodwill impairment testing dates after January 1, 2017. The Company adopted ASU 2017-04 effective January 1, 2017. The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the periods presented.

- removed (2018-05-04):
[0000926326-17-000038:note_history:49]
In January 2017, the FASB issued ASU 2017-01, Business Combinations, which clarifies the definition of a business and provides a screen to determine when a set of assets and activities is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set is not a business. This screen reduces the number of transactions that need to be further evaluated. ASU 2017-01 is effective for fiscal years beginning after December 15, 2017, with early adoption permitted.  The Company adopted ASU 2017-01 effective January 1, 2017.  The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the periods presented.

- removed (2018-05-04):
[0000926326-17-000038:note_history:50]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815), which simplifies the application of the hedge accounting guidance and improves the financial reporting, specifically simplifies designation and measurement for qualifying hedging relationships and the presentation of hedge results. ASU 2017-12 is effective for annual periods beginning after December 15, 2018 and interim periods within those annual periods with early adoption permitted. The Company adopted ASU 2017-12 effective August 1, 2017. The adoption of this authoritative guidance did not have impact on the Company's Condensed Consolidated Financial Statements or related disclosures for the periods presented.

- removed (2018-05-04):
[0000926326-17-000038:note_history:51]
In May 2014, the FASB issued ASU 2014-09-Revenue from Contracts with Customers, which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five step process to achieve this core principle and, accordingly, it is possible more judgment and estimates may be required within the revenue recognition process than is required under existing U.S. GAAP, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. The FASB has recently issued several amendments to ASU 2014-09, including clarification on accounting for licenses of intellectual property and identifying performance obligations. ASU 2014-09 will be effective for the Company beginning January 1, 2018.

- removed (2018-05-04):
[0000926326-17-000038:note_history:52]
The two permitted transition methods under ASU 2014-09 are the full retrospective method, in which case ASU 2014-09 would be applied to each prior reporting period presented and the cumulative effect of applying ASU 2014-09 would be recognized at the earliest period shown, or the modified retrospective method, in which case the cumulative effect of applying ASU 2014-09 would be recognized at the date of initial application. While the Company currently expects to apply the full retrospective method, the Company is continuing to evaluate the availability of information and resources necessary and may decide the benefit of applying the full retrospective method is not significant enough to support the cost.

- removed (2018-05-04):
[0000926326-17-000038:note_history:53]
Currently, the Company is in the process of reviewing its historical contracts to quantify the impact on its consolidated financial statements. The most significant impact of the standard relates to accounting for term software license revenue, contingent income, and commission expense.  Specifically, under the standard the Company expects to recognize revenue on term software licenses upon installation of the license rather than ratably over the life of the term license.  Additionally, the standard no longer requires deferral of contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price which will result in earlier recognition of revenue.  Finally, the standard requires expense to be recognized for incremental costs incurred to obtain a contract, primarily commission expense, on a systematic basis that is consistent with the transfer to the customer of the product and services to which the cost relates, including an estimate of the period of service renewals for the transaction. Currently, the Company recognizes commission expense at the time of recognizing the related product revenue. The Company is also in the process of assessing the appropriate changes to its business processes and upgrading its systems and controls to support recognition and disclosure under ASU 2014-09. The Company expects to complete its assessment process within the last quarter of 2017.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-04):
[0000926326-18-000015:note_history:54]
On January 5, 2016, the Company entered into a $400 million senior secured credit facility pursuant to a credit agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200 million, which was subsequently increased pursuant to the amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.
  (was, 2017-11-03, similarity 0.9578):
[0000926326-17-000038:note_history:54]
On January 5, 2016, the Company entered into a $400 million senior secured credit facility pursuant to a credit agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200 million (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

- changed (2018-05-04):
[0000926326-18-000015:note_history:55]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement (the "Amended Credit Agreement"). Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.
  (was, 2017-11-03, similarity 0.9589):
[0000926326-17-000038:note_history:55]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement. Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

- added (2018-05-04):
[0000926326-18-000015:note_history:56]
On December 26, 2017, the parties entered into another amendment (the "Amendment") to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.

- changed (2018-05-04):
[0000926326-18-000015:note_history:57]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.9 million and $1.5 million for the three months ended March 31, 2018 and 2017, respectively. Amortization expense related to fees and issuance cost was approximately$0.6 million and $0.4 million for the three months ended March 31, 2018 and 2017, respectively. The Company was in compliance with all covenants as of March 31, 2018 and December 31, 2017.
  (was, 2017-11-03, similarity 0.8486):
[0000926326-17-000038:note_history:57]
In connection with these Facilities, the Company incurred $7.9 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.6 million and $1.2 million for the three months ended September 30, 2017 and 2016, respectively. Interest expense (exclusive of fees and issuance cost amortization) was approximately $4.6 million and $4.0 million for the nine months ended September 30, 2017 and 2016, respectively. The Company was in full compliance with all covenants as of September 30, 2017 and December 31, 2016.

- added (2018-05-04):
[0000926326-18-000015:note_history:58]
As of March 31, 2018 the Company has repaid $139.5 million borrowed under these Facilities, which includes $2.5 million repaid during the three months ended March 31, 2018. The components of the Company’s debt obligations as of March 31, 2018 and December 31, 2017 are as follows:

- added (2018-05-04):
[0000926326-18-000015:note_history:59]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | March 31, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (2,500 | ) |  | $ | 180,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | — |  |  | 34,500 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (2,500 | ) |  | 214,500 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 573 |  |  | (6,302 | ) |
| Total Debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (1,927 | ) |  | $ | 208,198 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 190,490 |  |

- changed (2018-05-04):
[0000926326-18-000015:note_history:60]
As of March 31, 2018, the carrying amount of debt of $214.5 million approximates the comparable fair value of $217.6 million. The Company's debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments, and long-term credit ratings.
  (was, 2017-11-03, similarity 0.9838):
[0000926326-17-000038:note_history:60]
As of September 30, 2017, the carrying amount of debt of $197.5 million approximates the comparable fair value of $199.2 million. The Company's debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments, and long-term credit ratings.

- removed (2018-05-04):
[0000926326-17-000038:note_history:61]
On January 5, 2016, the Company borrowed the full $200.0 million under the Term Loan Facility and $55.0 million under the Revolving Credit Facility to complete the Aesynt acquisition and pay related fees and expenses. On December 2, 2016, the Company borrowed $40.0 million under the Revolving Credit Facility to complete the Ateb acquisition and pay related fees and expenses. On April 3, 2017, the Company borrowed an additional $10.0 million under the Revolving Credit Facility to pay for the InPharmics acquisition and fund its operations. On July 7, 2017 and July 31, 2017, the Company borrowed an additional $15.0 million and $12.0 million, respectively, under the Revolving Credit Facility to fund its operations. As of September 30, 2017 the Company has repaid $134.5 million borrowed under these Facilities, which includes $100.0 million repaid during the nine months ended September 30, 2017.

- removed (2018-05-04):
[0000926326-17-000038:note_history:62]
The components of the Company’s debt obligations for the nine months ended September 30, 2017 are as follows:

- removed (2018-05-04):
[0000926326-17-000038:note_history:63]
|  | December 31, 2016 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2017 |
|  | (In thousands) |
| Term loan facility | $ | 192,500 |  |  | $ | — |  |  | $ | (7,500 | ) |  | $ | 185,000 |  |
| Revolving credit facility | 68,000 |  |  | 37,000 |  |  | (92,500 | ) |  | 12,500 |  |
| Total debt under the facilities | 260,500 |  |  | 37,000 |  |  | (100,000 | ) |  | 197,500 |  |
| Less: Deferred issuance cost | (6,359 | ) |  | — |  |  | 1,192 |  |  | (5,167 | ) |
| Total Debt, net of deferred issuance cost | $ | 254,141 |  |  | $ | 37,000 |  |  | $ | (98,808 | ) |  | $ | 192,333 |  |
| Long term debt, current portion, net of deferred issuance cost | 8,410 |  |  |  |  |  |  | 13,410 |  |
| Long term debt, net of deferred issuance cost | $ | 245,731 |  |  |  |  |  |  | $ | 178,923 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-04):
[0000926326-18-000015:note_history:64]
The components of the Company’s debt obligations as of March 31, 2018 and December 31, 2017 are as follows:
  (was, 2017-11-03, similarity 0.796):
[0000926326-17-000038:note_history:64]
The components of the Company’s debt obligations for the nine months ended September 30, 2017 are as follows:

- added (2018-05-04):
[0000926326-18-000015:note_history:65]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | March 31, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (2,500 | ) |  | $ | 180,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | — |  |  | 34,500 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (2,500 | ) |  | 214,500 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 573 |  |  | (6,302 | ) |
| Total Debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (1,927 | ) |  | $ | 208,198 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 190,490 |  |

- removed (2018-05-04):
[0000926326-17-000038:note_history:66]
|  | December 31, 2016 |  | Borrowings |  | Repayment / Amortization |  | September 30, 2017 |
|  | (In thousands) |
| Term loan facility | $ | 192,500 |  |  | $ | — |  |  | $ | (7,500 | ) |  | $ | 185,000 |  |
| Revolving credit facility | 68,000 |  |  | 37,000 |  |  | (92,500 | ) |  | 12,500 |  |
| Total debt under the facilities | 260,500 |  |  | 37,000 |  |  | (100,000 | ) |  | 197,500 |  |
| Less: Deferred issuance cost | (6,359 | ) |  | — |  |  | 1,192 |  |  | (5,167 | ) |
| Total Debt, net of deferred issuance cost | $ | 254,141 |  |  | $ | 37,000 |  |  | $ | (98,808 | ) |  | $ | 192,333 |  |
| Long term debt, current portion, net of deferred issuance cost | 8,410 |  |  |  |  |  |  | 13,410 |  |
| Long term debt, net of deferred issuance cost | $ | 245,731 |  |  |  |  |  |  | $ | 178,923 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-05-04):
[0000926326-18-000015:note_history:67]
On April 30, 2018, the Company entered into a settlement agreement related to certain contingencies associated with the Ateb 2016 acquisition. The settlement, which will be recognized in the second quarter of 2018, is for approximately $2.5 million.

- removed (2018-05-04):
[0000926326-17-000038:note_history:68]
On October 2, 2017 and October 10, 2017, the Company borrowed $12.0 million and $10.0 million, respectively, under the Revolving Credit Facility to fund its operations.
