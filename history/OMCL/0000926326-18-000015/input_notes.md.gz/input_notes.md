# OMCL notes — 0000926326-18-000015


## omcl:ContractwithCustomerAssetandLiabilityTableTextBlock

[0000926326-18-000015:notes:1]
The following table reflects the Company’s contract assets and contract liabilities:

[0000926326-18-000015:notes:2]
|  | March 31, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Short-term unbilled receivable - included in accounts receivable and unbilled | $ | 4,859 |  |  | $ | 4,590 |  |
| Long-term unbilled receivable - included in other long-term assets | 10,877 |  |  | 9,475 |  |
| Total contract assets | $ | 15,736 |  |  | $ | 14,065 |  |
| Short-term deferred revenue | $ | 95,709 |  |  | $ | 78,774 |  |
| Long-term deferred revenue | 8,806 |  |  | 10,623 |  |
| Total contract liabilities | $ | 104,515 |  |  | $ | 89,397 |  |


## omcl:ScheduleofLongTermNetInvestmentinSaleTypeLeasesTableTextBlock

[0000926326-18-000015:notes:3]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at March 31, 2018 and December 31, 2017:

[0000926326-18-000015:notes:4]
|  | March 31, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 26,789 |  |  | $ | 25,899 |  |
| Less: Unearned interest income portion | (2,056 | ) |  | (1,695 | ) |
| Net investment in sales-type leases | 24,733 |  |  | 24,204 |  |
| Less: Short-term portion(1) | (8,289 | ) |  | (8,769 | ) |
| Long-term net investment in sales-type leases | $ | 16,444 |  |  | $ | 15,435 |  |

[0000926326-18-000015:notes:5]
[same as prior period, unchanged from 0000926326-17-000038:notes:3]


## omcl:ScheduleofSharebasedCompensationFutureIssuanceofSharesTableTextBlock

[0000926326-18-000015:notes:6]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of March 31, 2018:

[0000926326-18-000015:notes:7]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 3,674 |  |
| Non-vested restricted share awards | 833 |  |
| Shares authorized for future issuance | 730 |  |
| ESPP shares available for future issuance | 2,077 |  |
| Total shares reserved for future issuance | 7,314 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000926326-18-000015:notes:8]
[same as prior period, unchanged from 0000926326-17-000038:notes:6]

[0000926326-18-000015:notes:9]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2018 and December 31, 2017, the results of its operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2018 and March 31, 2017. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the year ended December 31, 2017 filed with the SEC on February 27, 2018, except as discussed in the "Revenue recognition" below. The Company's results of operations, comprehensive income (loss) and cash flows for the three months ended March 31, 2018 are not necessarily indicative of results that may be expected for the year ending December 31, 2018, or for any future period.


## us-gaap:CapitalLeasesInFinancialStatementsOfLessorDisclosureTextBlock

[0000926326-18-000015:notes:10]
[same as prior period, unchanged from 0000926326-17-000038:notes:8]

[0000926326-18-000015:notes:11]
On a recurring basis, we enter into sales-type lease transactions with the majority varying in length from one to five years. The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at March 31, 2018 and December 31, 2017:

[0000926326-18-000015:notes:12]
The Company evaluates its sales-type leases individually and collectively for impairment.  The allowance for credit losses were $0.2 million as of March 31, 2018 and December 31, 2017.

[0000926326-18-000015:notes:13]
At March 31, 2018, the future minimum lease payments under sales-type leases were as follows:

[0000926326-18-000015:notes:14]
|  | March 31, 2018 |
|  | (In thousands) |
| Remaining nine months of 2018 | $ | 5,293 |  |
| 2019 | 7,872 |  |
| 2020 | 1,938 |  |
| 2021 | 5,203 |  |
| 2022 | 3,386 |  |
| Thereafter | 3,097 |  |
| Total | $ | 26,789 |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-18-000015:notes:15]
Commitments and Contingencies

[0000926326-18-000015:notes:16]
Lease commitments

[0000926326-18-000015:notes:17]
The Company leases office space and office equipment under operating leases. Commitments under operating leases primarily relate to leasehold property and office equipment. At March 31, 2018, the minimum future payments on non-cancelable operating leases were as follows:

[0000926326-18-000015:notes:18]
|  | (In thousands) |
| Remaining nine months of 2018 | $ | 8,896 |  |
| 2019 | 11,763 |  |
| 2020 | 10,803 |  |
| 2021 | 10,515 |  |
| 2022 | 8,818 |  |
| Thereafter | 26,383 |  |
| Total minimum future lease payments | $ | 77,178 |  |

[0000926326-18-000015:notes:19]
Purchase obligations

[0000926326-18-000015:notes:20]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. At March 31, 2018, the Company had non-cancelable purchase commitments of $55.4 million, which are expected to be paid within the next twelve months.

[0000926326-18-000015:notes:21]
Legal Proceedings

[0000926326-18-000015:notes:22]
The Company is currently involved in various legal proceedings. As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any accrual for contingent liabilities associated with the legal proceedings described below based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time. The Company believes that it has valid defenses with respect to legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of this contingency or because of the diversion of management's attention and the creation of significant expenses.

[0000926326-18-000015:notes:23]
On January 10, 2018, a lawsuit was filed against a number of individuals, governmental agencies and corporate entities, including the Company and one of its subsidiaries, Aesynt Incorporated (“Aesynt”), in the Circuit Court for the City of Richmond, Virginia, captioned Ruth Ann Warner, as Guardian of Jonathan James Brewster Warner v. Centra Health, Inc., et al. (Case No. CL18-152-1). The complaint seeks monetary recovery of compensatory and punitive damages in addition to certain declaratory relief based upon, as against the individuals, governmental agencies and corporate entities other than the Company and Aesynt, allegations of the use of excessive force, unlawful detention, false imprisonment, battery, simple and gross negligence and negligent hiring, detention and training and, as against the Company and Aesynt, claims of product liability, negligence and breach of implied warranties. The Company and Aesynt have not yet been served with the complaint. The Company intends to defend the lawsuit vigorously.


## us-gaap:ConsolidationPolicyTextBlock

[0000926326-18-000015:notes:24]
[same as prior period, unchanged from 0000926326-17-000038:notes:22]

[0000926326-18-000015:notes:25]
[same as prior period, unchanged from 0000926326-17-000038:notes:23]


## us-gaap:DebtDisclosureTextBlock

[0000926326-18-000015:notes:26]
Debt

[0000926326-18-000015:notes:27]
On January 5, 2016, the Company entered into a $400 million senior secured credit facility pursuant to a credit agreement, by and among the Company, the lenders from time to time party thereto, Wells Fargo Securities, LLC, as Sole Lead Arranger and Wells Fargo Bank, National Association, as administrative agent (the “Credit Agreement”). The Credit Agreement provides for (a) a five-year revolving credit facility of $200 million, which was subsequently increased pursuant to the amendment discussed below (the “Revolving Credit Facility”) and (b) a five-year $200 million term loan facility (the “Term Loan Facility” and together with the Revolving Credit Facility, the “Facilities”). In addition, the Credit Agreement includes a letter of credit sub-limit of up to $10 million and a swing line loan sub-limit of up to $10 million. The Credit Agreement expires on January 5, 2021, upon which date all remaining outstanding borrowings are due and payable.

[0000926326-18-000015:notes:28]
Loans under the Facilities bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month, plus an applicable margin ranging from 0.50% to 1.25% per annum based on the Company’s consolidated total net leverage ratio (as defined in the 2016 Credit Agreement). Undrawn commitments under the Revolving Credit Facility will be subject to a commitment fee ranging from 0.20% to 0.35% per annum based on the Company’s consolidated total net leverage ratio on the average daily unused portion of the Revolving Credit Facility. A letter of credit participation fee ranging from 1.50% to 2.25% per annum based on the Company’s consolidated total net leverage ratio will accrue on the average daily amount of letter of credit exposure.

[0000926326-18-000015:notes:29]
The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty, except for any amounts relating to the LIBOR breakage indemnity described in the Credit Agreement. The Company is required to make mandatory prepayments under the Term Loan Facility with (a) net cash proceeds from any issuances of debt (other than certain permitted debt) and (b) net cash proceeds from certain asset dispositions (other than certain asset dispositions) and insurance and condemnation events (subject to reinvestment rights and certain other exceptions). Loans under the Term Loan Facility will amortize in quarterly installments, equal to 5% per annum of the original principal amount thereof during the first two years, which shall increase to 10% per annum during the third and fourth years, and 15% per annum during the fifth year, with the remaining balance payable on January 5, 2021. The Company is required to make mandatory prepayments under the Revolving Credit Facility if at any time the aggregate outstanding principal amount of loans together with the total amount of outstanding letters of credit exceeds the aggregate commitments, with such mandatory prepayment to be equal to the amount of such excess.

[0000926326-18-000015:notes:30]
The Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends and other distributions. The Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum consolidated total leverage ratio and maintain a minimum fixed charge coverage ratio. The Company’s obligations under the Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and the subsidiary guarantors’ assets. In connection with entering into the Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a collateral agreement and subsidiary guaranty agreement.

[0000926326-18-000015:notes:31]
On April 11, 2017, the parties entered into the First Amendment to Credit Agreement and Collateral Agreement (the "Amended Credit Agreement"). Under this amendment, (i) the maximum capital expenditures limit in any fiscal year for property, plant and equipment and software development increased from $35.0 million to $45.0 million, and (ii) the maximum limit for non-permitted investments increased from $10.0 million to $20.0 million.

[0000926326-18-000015:notes:32]
On December 26, 2017, the parties entered into another amendment (the "Amendment") to the Amended Credit Agreement. Pursuant to the Amendment, the Revolving Credit Facility provided for under the Amended Credit Agreement, was increased from $200.0 million to $315.0 million and certain other modifications to the Amended Credit Agreement were made, including amendments to certain negative covenants.

[0000926326-18-000015:notes:33]
In connection with these Facilities, the Company incurred $10.1 million of debt issuance costs. The debt issuance costs were capitalized and presented as a direct deduction from the carrying amount of that debt liability in accordance with the accounting guidance. The debt issuance costs are being amortized to interest expense using the straight line method from issuance date through 2021. Interest expense (exclusive of fees and issuance cost amortization) was approximately $1.9 million and $1.5 million for the three months ended March 31, 2018 and 2017, respectively. Amortization expense related to fees and issuance cost was approximately$0.6 million and $0.4 million for the three months ended March 31, 2018 and 2017, respectively. The Company was in compliance with all covenants as of March 31, 2018 and December 31, 2017.

[0000926326-18-000015:notes:34]
As of March 31, 2018 the Company has repaid $139.5 million borrowed under these Facilities, which includes $2.5 million repaid during the three months ended March 31, 2018. The components of the Company’s debt obligations as of March 31, 2018 and December 31, 2017 are as follows:

[0000926326-18-000015:notes:35]
|  | December 31, 2017 |  | Borrowings |  | Repayment / Amortization |  | March 31, 2018 |
|  | (In thousands) |
| Term loan facility | $ | 182,500 |  |  | $ | — |  |  | $ | (2,500 | ) |  | $ | 180,000 |  |
| Revolving credit facility | 34,500 |  |  | — |  |  | — |  |  | 34,500 |  |
| Total debt under the facilities | 217,000 |  |  | — |  |  | (2,500 | ) |  | 214,500 |  |
| Less: Deferred issuance cost | (6,875 | ) |  | — |  |  | 573 |  |  | (6,302 | ) |
| Total Debt, net of deferred issuance cost | $ | 210,125 |  |  | $ | — |  |  | $ | (1,927 | ) |  | $ | 208,198 |  |
| Long term debt, current portion, net of deferred issuance cost | 15,208 |  |  |  |  |  |  | 17,708 |  |
| Long term debt, net of deferred issuance cost | $ | 194,917 |  |  |  |  |  |  | $ | 190,490 |  |

[0000926326-18-000015:notes:36]
As of March 31, 2018, the carrying amount of debt of $214.5 million approximates the comparable fair value of $217.6 million. The Company's debt facilities are classified as a Level 3 in the fair value hierarchy. The calculation of the fair value is based on a discounted cash flow model using observable market inputs and taking into consideration variables such as interest rate changes, comparable instruments, and long-term credit ratings.


## us-gaap:DeferredRevenueDisclosureTextBlock

[0000926326-18-000015:notes:37]
[same as prior period, unchanged from 0000926326-17-000038:notes:35]

[0000926326-18-000015:notes:38]
Short-term deferred revenue of $95.7 million and $78.8 million includes deferred revenue from product sales and service contracts, net of deferred cost of sales of $15.7 million and $16.9 million as of March 31, 2018 and December 31, 2017, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months.

[0000926326-18-000015:notes:39]
Long-term deferred revenue includes deferred revenue from service contracts of $8.8 million and $10.6 million, as of March 31, 2018 and December 31, 2017, respectively.


## us-gaap:EarningsPerShareTextBlock

[0000926326-18-000015:notes:40]
[same as prior period, unchanged from 0000926326-17-000038:notes:38]

[0000926326-18-000015:notes:41]
[same as prior period, unchanged from 0000926326-17-000038:notes:39]

[0000926326-18-000015:notes:42]
The basic and diluted net income (loss) per share calculation for the three months ended March 31, 2018 and 2017 was as follows:

[0000926326-18-000015:notes:43]
|  | Three months ended March 31, |
|  | 2018 |  | 2017 |
|  | (In thousands, except per share data) |
| Net income (loss) | $ | 2,720 |  |  | $ | (10,335 | ) |
| Weighted-average shares outstanding — basic | 38,635 |  |  | 36,840 |  |
| Effect of dilutive securities from stock award plans | 1,056 |  |  | — |  |
| Weighted-average shares outstanding — diluted | $ | 39,691 |  |  | $ | 36,840 |  |
| Net income (loss) per share - basic | $ | 0.07 |  |  | $ | (0.28 | ) |
| Net income (loss) per share - diluted | $ | 0.07 |  |  | $ | (0.28 | ) |
| Anti-dilutive weighted-average shares related to stock award plans | 1,113 |  |  | 4,236 |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0000926326-18-000015:notes:44]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of March 31, 2018:

[0000926326-18-000015:notes:45]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 1,464 |  |  | $ | — |  |  | $ | 1,464 |  |
| Total financial assets | $ | — |  |  | $ | 1,464 |  |  | $ | — |  |  | $ | 1,464 |  |

[0000926326-18-000015:notes:46]
There were no transfers between fair value measurement levels during the three months ended March 31, 2018 and March 31, 2017.

[0000926326-18-000015:notes:47]
The following table represents the fair value hierarchy of the Company’s financial assets and financial liabilities measured at fair value as of December 31, 2017:

[0000926326-18-000015:notes:48]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Interest rate swap contracts | $ | — |  |  | $ | 1,378 |  |  | $ | — |  |  | $ | 1,378 |  |
| Total financial assets | $ | — |  |  | $ | 1,378 |  |  | $ | — |  |  | $ | 1,378 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-18-000015:notes:49]
[same as prior period, unchanged from 0000926326-17-000038:notes:47]

[0000926326-18-000015:notes:50]
Cash and cash equivalents of $43.8 million and $32.4 million as of March 31, 2018 and December 31, 2017, respectively, consisted of demand deposits only.

[0000926326-18-000015:notes:51]
[same as prior period, unchanged from 0000926326-17-000038:notes:52]

[0000926326-18-000015:notes:52]
[same as prior period, unchanged from 0000926326-17-000038:notes:53]

[0000926326-18-000015:notes:53]
[same as prior period, unchanged from 0000926326-17-000038:notes:54]

[0000926326-18-000015:notes:54]
The fair value of the interest rate swap agreements at March 31, 2018 and December 31, 2017 was $1.5 million and $1.4 million, respectively. There were no amounts reclassified into current earnings due to ineffectiveness during the periods presented.

[0000926326-18-000015:notes:55]
[same as prior period, unchanged from 0000926326-17-000038:notes:49]

[0000926326-18-000015:notes:56]
The Company measures its financial instruments at fair value. The Company’s cash equivalents are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company's interest rate swap contracts and foreign currency contracts are classified within Level 2 as the valuation inputs are based on quoted prices and market observable data of similar instruments.

[0000926326-18-000015:notes:57]
[same as prior period, unchanged from 0000926326-17-000038:notes:51]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-18-000015:notes:58]
[same as prior period, unchanged from 0000926326-17-000038:notes:59]

[0000926326-18-000015:notes:59]
[same as prior period, unchanged from 0000926326-17-000038:notes:60]

[0000926326-18-000015:notes:60]
[same as prior period, unchanged from 0000926326-17-000038:notes:61]

[0000926326-18-000015:notes:61]
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Net balance as of December 31, 2017 | $ | 220,851 |  |  | $ | 116,900 |  |  | $ | 337,751 |  |
| Foreign currency exchange rate fluctuations | 831 |  |  | 366 |  |  | 1,197 |  |
| Net balance as of March 31, 2018 | $ | 221,682 |  |  | $ | 117,266 |  |  | $ | 338,948 |  |

[0000926326-18-000015:notes:62]
[same as prior period, unchanged from 0000926326-17-000038:notes:64]

[0000926326-18-000015:notes:63]
The carrying amounts of intangible assets as of March 31, 2018 and December 31, 2017 were as follows:

[0000926326-18-000015:notes:64]
|  | March 31, 2018 |
|  | Grosscarryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 133,950 |  |  | $ | (36,356 | ) |  | $ | 314 |  |  | $ | 97,908 |  |  | 1 - 30 |
| Acquired technology | 74,371 |  |  | (23,359 | ) |  | 203 |  |  | 51,215 |  |  | 3 - 20 |
| Backlog | 21,712 |  |  | (18,424 | ) |  | — |  |  | 3,288 |  |  | 1 - 4 |
| Trade names | 8,662 |  |  | (4,861 | ) |  | 38 |  |  | 3,839 |  |  | 1 - 12 |
| Patents | 3,236 |  |  | (1,390 | ) |  | 12 |  |  | 1,858 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (1,450 | ) |  | — |  |  | 450 |  |  | 3 |
| In-process technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | — |
| Total intangibles assets, net | $ | 247,731 |  |  | $ | (85,840 | ) |  | $ | 567 |  |  | $ | 162,458 |  |  |  |

[0000926326-18-000015:notes:65]
|  | December 31, 2017 |
|  | Gross carryingamount |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 133,913 |  |  | $ | (33,526 | ) |  | $ | 65 |  |  | $ | 100,452 |  |  | 1 - 30 |
| Acquired technology | 74,593 |  |  | (21,523 | ) |  | 34 |  |  | 53,104 |  |  | 3 - 20 |
| Backlog | 21,712 |  |  | (17,544 | ) |  | — |  |  | 4,168 |  |  | 1 - 5 |
| Trade names | 8,716 |  |  | (4,719 | ) |  | 6 |  |  | 4,003 |  |  | 1 - 12 |
| Patents | 3,296 |  |  | (1,418 | ) |  | 2 |  |  | 1,880 |  |  | 2 - 20 |
| Non-compete agreements | 1,900 |  |  | (1,300 | ) |  | — |  |  | 600 |  |  | 3 |
| In-process technology | 3,900 |  |  | — |  |  | — |  |  | 3,900 |  |  | — |
| Total intangibles assets, net | $ | 248,030 |  |  | $ | (80,030 | ) |  | $ | 107 |  |  | $ | 168,107 |  |  |  |

[0000926326-18-000015:notes:66]
Amortization expense of intangible assets was $6.0 million and $6.5 million for the three months ended March 31, 2018 and 2017, respectively.

[0000926326-18-000015:notes:67]
[same as prior period, unchanged from 0000926326-17-000038:notes:69]

[0000926326-18-000015:notes:68]
|  | March 31, 2018 |
|  | (In thousands) |
| Remaining nine months of 2018 | $ | 17,463 |  |
| 2019 | 18,036 |  |
| 2020 | 16,832 |  |
| 2021 | 15,378 |  |
| 2022 | 14,009 |  |
| Thereafter (excluding in-process technology) | 76,840 |  |
| Total | $ | 158,558 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-18-000015:notes:69]
[same as prior period, unchanged from 0000926326-17-000038:notes:71]

[0000926326-18-000015:notes:70]
On December 22, 2017, the Tax Cuts and Jobs Act (the "Act") was signed into law, most provisions of which became effective starting in 2018, including the reduction of the statutory corporate income tax rate from 35% to 21%. As of March 31, 2018, the Company has not completed the accounting for the tax effects of enactment of the Act; however, in the fourth quarter of 2017, the Company made a reasonable estimate of the effects on the existing deferred tax balances and the one-time transition tax. No adjustments to the provisional amounts recorded in the fourth quarter of 2017 have been made during the three months ended March 31, 2018. In the current quarter, the Company assessed the effect of certain international provisions of the Act that became effective January 1, 2018, and determined that these provisions had an immaterial impact, therefore, the Company did not record any impact as a result of the assessment. The Company will continue to analyze the provision for income taxes under the Act as future guidance is issued. Any revisions will be treated in accordance with the measurement period guidance outlined in Staff Accounting Bulletin No. 118.

[0000926326-18-000015:notes:71]
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 18% and 39% for the three months ended March 31, 2018 and March 31, 2017, respectively.

[0000926326-18-000015:notes:72]
The 2018 annual effective tax rate differed from the statutory rate of 21% primarily due to the unfavorable impact of state income taxes, non-deductible expenses and non-deductible equity charges, which were partially offset by the favorable impact of the Research & Development credits and foreign rate differential. The 2017 annual effective tax rate differed from the statutory rate of 35% primarily due to the unfavorable impact of state income taxes, foreign rate differential, and non-deductible equity charges, which were partially offset by the domestic production activities deduction and the Research & Development credits.

[0000926326-18-000015:notes:73]
As of March 31, 2018 and December 31, 2017, the Company had gross unrecognized tax benefits of $11.6 million and $10.7 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of the unrecognized tax benefits, but to record interest and penalties in operating expense. As of March 31, 2018 and December 31, 2017, the amount of accrued interest and penalties was $1.5 million and $1.4 million, respectively.

[0000926326-18-000015:notes:74]
The Company files income tax returns in the United States and various states and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands and the United Kingdom. With few exceptions, as of March 31, 2018, the Company is no longer subject to U.S., state, and foreign examination for years before 2014, 2013, and 2014.

[0000926326-18-000015:notes:75]
[same as prior period, unchanged from 0000926326-17-000038:notes:76]


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0000926326-18-000015:notes:76]
[same as prior period, unchanged from 0000926326-17-000038:notes:77]

[0000926326-18-000015:notes:77]
|  | March 31, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| United States | $ | 40,116 |  |  | $ | 34,899 |  |
| Rest of world (1) | 8,174 |  |  | 7,696 |  |
| Total property and equipment, net | $ | 48,290 |  |  | $ | 42,595 |  |

[0000926326-18-000015:notes:78]
[same as prior period, unchanged from 0000926326-17-000038:notes:79]

[0000926326-18-000015:notes:79]
[same as prior period, unchanged from 0000926326-17-000038:notes:80]


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000926326-18-000015:notes:80]
[same as prior period, unchanged from 0000926326-17-000038:notes:81]

[0000926326-18-000015:notes:81]
[same as prior period, unchanged from 0000926326-17-000038:notes:82]

[0000926326-18-000015:notes:82]
On April 12, 2017, the Company completed the acquisition of all of the membership interest of Dixie Drawl, LLC d/b/a InPharmics ("InPharmics").  InPharmics is a technology and services company that provides advanced pharmacy informatics solutions to hospital pharmacies. The total consideration for the transaction was $5.0 million, net of cash acquired of $0.3 million, and includes $0.5 million holdback for potential settlement of performance obligations. At March 31, 2018, this amount has been presented as a short-term liability. The Company accounted for the acquisition of InPharmics in accordance with the authoritative guidance on business combinations; therefore, the tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the acquisition date. The purchase price was preliminary allocated to intangible assets in the amount of $1.9 million, which included developed technology and customer contracts, with the remainder allocated to goodwill. The results of the InPharmics' operations have been included in our consolidated results of operations, and presented as part of the Automation and Analytics segment.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000926326-18-000015:notes:83]
Recently adopted authoritative guidance

[0000926326-18-000015:notes:84]
In May 2014, the Financial Accounting Standards Board ("FASB") issued ASC 606, Revenue from Contracts with Customers, a new standard related to revenue recognition. Under the new standard, revenue is recognized when a customer obtains control of promised goods or services in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In addition, the standard requires disclosure of the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method). We adopted the standard using the full retrospective method effective beginning January 1, 2018.

[0000926326-18-000015:notes:85]
Under the ASC 606 guidance, fees paid to GPOs are now presented as a reduction of Product Revenue, whereas these fees were considered a part of Selling, General and Administrative costs under the previous guidance. The majority of the incremental costs incurred to obtain a contract, primarily commission expense, are recognized during the first year with the balance recognized ratably over a period of ten years. Additionally, revenue on term software licenses is recognized upon installation of the license rather than ratably over the life of the term license. Finally, the Company no longer defers the contingent revenue in transactions where the amount charged to the customer for a particular performance obligation is less than the allocation of standalone selling price. Adoption of the standard related to revenue recognition impacted our reported results for the three months period, as follows:

[0000926326-18-000015:notes:86]
|  | March 31, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Revenue |  |  |  |  |  |
| Automation and Analytics | $ | 124,171 |  |  | $ | (2,001 | ) |  | $ | 122,170 |  |
| Medication Adherence | 26,383 |  |  | — |  |  | 26,383 |  |
| Gross profit |  |  |  |  |  |
| Automation and Analytics | 55,410 |  |  | (2,001 | ) |  | 53,409 |  |
| Medication Adherence | 8,782 |  |  | — |  |  | 8,782 |  |
| Selling, general and administrative expenses | 64,625 |  |  | (2,685 | ) |  | 61,940 |  |
| Provision for income taxes | (8,938 | ) |  | 265 |  |  | (8,673 | ) |
| Net income | $ | (10,754 | ) |  | $ | 419 |  |  | $ | (10,335 | ) |
| Earnings per share | $ | (0.29 | ) |  | $ | 0.01 |  |  | $ | (0.28 | ) |

[0000926326-18-000015:notes:87]
|  | December 31, 2017 |
|  | As reported |  | Adjustment |  | As adjusted |
|  | (In thousands) |
| Accounts receivable and unbilled, net | $ | 189,227 |  |  | $ | 819 |  |  | $ | 190,046 |  |
| Prepaid expenses | 36,060 |  |  | (15,668 | ) |  | 20,392 |  |
| Prepaid commissions | — |  |  | 41,432 |  |  | 41,432 |  |
| Other long-term assets | 39,841 |  |  | 9,475 |  |  | 49,316 |  |
| Deferred revenue, net | 86,104 |  |  | (7,330 | ) |  | 78,774 |  |
| Long-term, deferred revenue | 17,244 |  |  | (6,621 | ) |  | 10,623 |  |
| Long-term, deferred tax liabilities | 28,579 |  |  | 12,867 |  |  | 41,446 |  |
| Stockholders' equity | 517,199 |  |  | 37,142 |  |  | 554,341 |  |

[0000926326-18-000015:notes:88]
Recently issued authoritative guidance

[0000926326-18-000015:notes:89]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which permits the reclassification of the income tax effects of the Tax Cuts and Jobs Act of 2017 on items within accumulated other comprehensive income to retained earnings. These amounts are commonly referred to as “stranded tax effects”. ASU 2018-02 will be effective for the Company beginning January 1, 2019. The Company is currently in the process of evaluating the impact of adoption on the consolidated financial statements.


## us-gaap:NonvestedRestrictedStockSharesActivityTableTextBlock

[0000926326-18-000015:notes:90]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Restricted Stock Awards ("RSAs") |  |  |  |
| Outstanding at December 31, 2017 | 23 |  |  | $ | 41.07 |  |
| Granted | — |  |  | — |  |
| Vested | — |  |  | — |  |
| Forfeited | — |  |  | — |  |
| Outstanding and unvested at March 31, 2018 | 23 |  |  | $ | 41.08 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-18-000015:notes:91]
[same as prior period, unchanged from 0000926326-17-000038:notes:110]

[0000926326-18-000015:notes:92]
[same as prior period, unchanged from 0000926326-17-000038:notes:111]

[0000926326-18-000015:notes:93]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company's major products are automated medication, supply control systems and medication adherence solutions which are sold in its principal market, which is the healthcare industry. The Company's market is primarily located in the United States and Europe. "Omnicell" or the "Company" collectively refer to Omnicell, Inc. and its subsidiaries.

[0000926326-18-000015:notes:94]
Certain prior year amounts have been adjusted to conform with the adoption of ASC 606, Revenue from Contracts with Customers ("ASC 606"), which became effective for the Company beginning on January 1, 2018. Refer to "Recently adopted authoritative guidance" for the effects of adoption of ASC 606 and the section below for the updated revenue recognition policy.

[0000926326-18-000015:notes:95]
Revenue recognition

[0000926326-18-000015:notes:96]
The Company earns revenues from sales of its medication and medical and surgical supply automation systems along with consumables and related services, which are sold in the healthcare industry, our principal market. The transaction price of each contract with a customer is allocated to identified performance obligations based on the relative fair value of each obligation. The Company's customer arrangements typically include one or more of the following performance obligations:

[0000926326-18-000015:notes:97]
Products. Software-enabled equipment that manages and regulates the storage and dispensing of pharmaceuticals, consumable blister cards and packaging equipment and other medical supplies.

[0000926326-18-000015:notes:98]
Software. Additional software applications that enable incremental functionality of its equipment.

[0000926326-18-000015:notes:99]
Installation. Installation of equipment as integrated systems at customers' sites.

[0000926326-18-000015:notes:100]
Post-installation technical support. Phone support, on-site service, parts and access to unspecified software updates and enhancements, if and when available.

[0000926326-18-000015:notes:101]
Professional services. Other customer services, such as training and consulting.

[0000926326-18-000015:notes:102]
Prior to recognizing revenue, the Company identifies the contract, performance obligations, and transaction price, and allocates the transaction price to the performance obligations. All identified contracts meet the following required criteria:

[0000926326-18-000015:notes:103]
Parties to the contract have approved the contract (in writing, orally, or in accordance with other customary business practices) and are committed to perform their respective obligations. A majority of the Company’s contracts are evidenced by a non-cancelable written agreement. Contracts for consumable products are generally evidenced by an order placed via phone or a manual purchase order.

[0000926326-18-000015:notes:104]
Entity can identify each party’s rights regarding the goods or services to be transferred. Contract terms are documented within the written agreements. Where a written contract does not exist, such as for consumable products, the rights of each party are understood as following our standard business process and terms.

[0000926326-18-000015:notes:105]
The entity can identify the payment terms for the goods or services to be transferred. Payment terms are documented within the agreement and are generally net 30 days from shipment of tangible product or services performed. Where a written contract does not exist, the Company’s standard payment terms are net 30 day terms.

[0000926326-18-000015:notes:106]
The contract has commercial substance (that is the risk, timing, or amount of the entity’s future cash flows is expected to change as a result of the contract.) The Company's agreements are an exchange of cash for a combination of products and services which result in changes in the amount of the Company’s future cash flows.

[0000926326-18-000015:notes:107]
It is probable the entity will collect the consideration to which it will be entitled in exchange for the goods or services that will be transferred to the customer. The Company performs a credit check for all significant customers or transactions and where collectability is not probable, payment in full or a substantial down payment is typically required to help assure the full agreed upon contract price will be collected.

[0000926326-18-000015:notes:108]
The Company often enters into change orders which modify the product to be received by the customer pursuant to certain contracts. Changes to any contract are accounted for as a modification of the existing contract to the extent the goods and services to be delivered as part of the contract are generally consistent with the nature and type of those to be provided under the terms of the original contract. Examples of such change orders include the addition or removal of units of equipment or changes to the configuration of the equipment where the overall nature of the contract remains intact. The Company’s change orders generally result in the change being accounted for as modifications of existing contracts given the nature of the impacted orders.

[0000926326-18-000015:notes:109]
Distinct goods or services are identified as performance obligations. A series of distinct goods or services that are substantially the same and that have the same pattern of transfer to the customer are considered a single performance obligation.  Where a good or service is determined not to be distinct, the Company combines the good or service with other promised goods or services until a bundle of goods or services that is distinct is identified. To identify its performance obligations, the Company considers all of the products or services promised in the contract regardless of whether they are explicitly stated or are implied by customary business practices. When performance obligations are included in separate contracts, the Company considers an entire customer arrangement to determine if separate contracts should be considered combined for the purposes of revenue recognition. Most of the Company’s sales, other than renewals of support and maintenance, contain multiple performance obligations, with a combination of hardware systems, consumables and software products, support and maintenance, and professional services.

[0000926326-18-000015:notes:110]
The transaction price of a contract is determined based on the fixed consideration, net of an estimate for variable consideration such as various discounts or rebates provided to customers. As a result of the Company’s commercial selling practices, contract prices are generally fixed with minimal, if any, variable consideration.

[0000926326-18-000015:notes:111]
The transaction price is allocated to separate performance obligations proportionally based on the standalone selling price of each performance obligation. Standalone selling price is best evidenced by the price the Company charges for the good or service when selling it separately in similar circumstances to similar customers. Other than for the renewal of annual support services contracts, the Company’s products and services are not generally sold separately. The Company uses an expected cost plus a margin approach to identify the standalone selling price of goods where separate sales transactions do not exist. For software and services which do not have a specific identifiable product cost, the Company uses a discounted from the list price amount as a best estimated selling price.

[0000926326-18-000015:notes:112]
The Company recognizes revenue when the performance obligation has been satisfied by transferring a promised good or service to a customer. The good or service is transferred when or as the customer obtains control of the good or service.  Determining when control transfers requires management to make judgments that affect the timing of revenue recognized.  Generally, for products requiring a complex implementation, control passes when the product is installed and ready for use. For all other products, control generally passes when product has been shipped and title has passed. For maintenance contracts and certain other services provided on a subscription basis, control passes to the customer over time, generally ratably over the service term as the Company provides a stand-ready service to service the customer’s equipment. Time and material services transfer control to the customer at the time the services are provided. The portion of the transaction price allocated to the Company’s unsatisfied performance obligation at March 31, 2018 and December 31, 2017 was $104.5 million and $89.4 million, respectively, of which $95.7 million and $78.8 million, respectively, was expected to be completed within one year. Remaining performance obligations primarily relate to maintenance contracts and are recognized ratably over the remaining term of the contract, generally not more than five years.

[0000926326-18-000015:notes:113]
Revenues, contract assets and contract liabilities are recorded net of associated taxes.

[0000926326-18-000015:notes:114]
The payment terms associated with the Company’s contracts vary, however, payment terms for product revenue are generally based on milestones tied to contract signing, shipment of products and/or customer acceptance. Payment terms associated with the service portion of agreements are generally periodic and can be billed on a monthly, quarterly or annual basis. In certain circumstances multiple years are billed at one time. The portion of these contract liabilities not expected to be recognized as revenue within twelve months of the balance sheet date are considered long term.

[0000926326-18-000015:notes:115]
In the normal course of business, the Company typically does not accept product returns unless the item is defective as manufactured or the configuration of the product is incorrect. The Company establishes provisions for estimated returns based on historical product returns. The allowance for sales returns is not material to the Condensed Consolidated Financial Statements for any periods presented.

[0000926326-18-000015:notes:116]
A portion of the Company's sales are made through multi-year lease agreements. Under sales-type leases, the Company recognizes revenue for its hardware and software products net of lease execution costs, such as post-installation product maintenance and technical support, at the net present value of the lease payment stream once its installation obligations have been met. The Company optimizes cash flows by selling a majority of its non-U.S. government leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company's sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 40% of the lease receivable balance, are retained in-house. Revenue from sales-type leases of $9.8 million and $3.2 million for the three months ended March 31, 2018 and 2017, respectively, is included in product revenue in the Condensed Consolidated Statements of Operations. Interest income in these leases is recognized in product revenue using the effective interest method.

[0000926326-18-000015:notes:117]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations ("GPOs"). GPOs are often owned fully or in part by the Company’s customers and the Company pays fees to the GPO on completed contracts. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs were $1.9 million and $2.1 million for the quarters ended March 31, 2018 and 2017, respectively.

[0000926326-18-000015:notes:118]
Contract assets and contract liabilities

[0000926326-18-000015:notes:119]
A contract asset is a right to consideration in exchange for goods or services that the Company has transferred to a customer when that right is conditional and is not just subject to the passage of time. A receivable will be recorded on the balance sheet when the Company has unconditional rights to consideration. A contract liability is an obligation to transfer goods or services for which the Company has received consideration, or for which an amount of consideration is due from the customer. Contract liabilities include customer deposits under non-cancelable contracts and current and non-current deferred revenue balances. The Company’s contract balances are reported in a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

[0000926326-18-000015:notes:120]
Significant changes in the contract assets and the contract liabilities balances during the period are the result of the issuance of invoices and recognition of deferred revenue in the normal course of business. Unbilled contract assets which were invoiced during the three months ended March 31, 2018 as a result of the right to invoice for the transaction consideration becoming unconditional were not material. The contract modifications entered into during the three months ended March 31, 2018, did not have a significant impact on the Company’s contract assets or deferred revenues. During the three months ended March 31, 2018, the Company recognized revenue of $46.6 million that was included in the corresponding deferred revenue balance as of December 31, 2017.

[0000926326-18-000015:notes:121]
Contract costs

[0000926326-18-000015:notes:122]
The Company has determined that the incentive portions of its sales commission plans require capitalization since these payments are directly related to sales achieved during a time period. These commissions are earned on the basis of the total purchase order value of new product bookings. Since there are not commensurate commissions earned on renewal of the service bookings, the Company concluded that the capitalized asset is related to services provided under both the initial contract and renewal periods. The Company applies a practical expedient to account for the incremental costs of obtaining a contract to a portfolio of contracts with similar characteristics as the Company expects the effect on the financial statements of applying the practical expedient would not differ materially from applying the accounting guidance to the individual contracts within the portfolio.  A pool of contracts is defined as all contracts booked in a particular quarter. The amortization for the capitalized asset is an estimate of the pool’s original contract term, generally one to five years, plus an estimate of future customer renewal periods resulting in a total amortization period of ten years. Costs to obtain a contract are allocated amongst performance obligations and recognized as sales and marketing expense consistent with the pattern of revenue recognition. Capitalized costs are periodically reviewed for impairment. A portion of the pool’s capitalized asset is recorded as an expense after two quarters, which represents the estimated period during which the product revenue associated with the contract is recorded. The remaining contract cost is recorded as expense ratably over the ten year estimated initial and renewal service periods. During the three months ended March 31, 2018 and March 31, 2017, the Company recognized contract cost expense of $5.6 million and $4.1 million, respectively. The portion of commission expenses paid as of the balance sheet date to be recognized in future periods is recorded in long term prepaid commissions expense on the Condensed Consolidated Balance Sheets. There was no impairment loss in relation to the costs capitalized during the three months ended March 31, 2018.

[0000926326-18-000015:notes:123]
[same as prior period, unchanged from 0000926326-17-000038:notes:114]

[0000926326-18-000015:notes:124]
[same as prior period, unchanged from 0000926326-17-000038:notes:115]

[0000926326-18-000015:notes:125]
[same as prior period, unchanged from 0000926326-17-000038:notes:116]

[0000926326-18-000015:notes:126]
The Company's Chief Operating Decision Maker ("CODM") is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company's segments using information about its revenues, gross profit, and income from operations. Such evaluation excludes general corporate-level costs that are not specific to either of the reportable segments and are managed separately at the corporate level. Corporate-level costs include expenses related to executive management, finance and accounting, human resources, legal, training and development, and certain other administrative expenses.  See Note 14, Segment and Geographical Information, for additional information on segment reporting.

[0000926326-18-000015:notes:127]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company's Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-18-000015:notes:128]
[same as prior period, unchanged from 0000926326-17-000038:notes:118]

[0000926326-18-000015:notes:129]
On March 2, 2018, the Company initiated the realignment of its Automation and Analytics commercial group in North American and France. The total estimated cost for the plan was $1.5 million and consists primarily of employee severance cost. As of March 31, 2018, the unpaid balance is $1.4 million and is presented as a component of accrued compensation liabilities in the Condensed Consolidated Balance Sheet.

[0000926326-18-000015:notes:130]
On February 15, 2017, the Company announced its plan to reduce its workforce by approximately 100 full-time employees and close the Company’s Nashville, Tennessee and Slovenia facilities. The plan was completed in fiscal year 2017. During the three months ended March 31, 2017, the Company accrued $3.8 million of expenses, primarily for employee severance and related expenses, and paid out $2.1 million. The remaining unpaid balance of $1.7 million accrued expenses is presented as a component of accrued compensation in the Condensed Consolidated Balance Sheet. There were no facility-related costs incurred during the three months ended March 31, 2017.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0000926326-18-000015:notes:131]
[same as prior period, unchanged from 0000926326-17-000038:notes:124]

[0000926326-18-000015:notes:132]
|  | Three months ended March 31, |
|  | 2018 |  | 2017 |
|  | (In thousands) |
| United States | $ | 158,202 |  |  | $ | 130,279 |  |
| Rest of world (1) | 24,417 |  |  | 18,274 |  |
| Total revenues | $ | 182,619 |  |  | $ | 148,553 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000926326-18-000015:notes:133]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the three months ended March 31, 2018 and 2017:

[0000926326-18-000015:notes:134]
|  | Three months ended March 31, |
|  | 2018 |  | 2017 |
|  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |  | Foreign currency translation adjustments |  | Unrealized gain (loss) on interest rate swap hedges |  | Total |
|  | (In thousands) |
| Beginning balance | $ | (6,954 | ) |  | $ | 841 |  |  | $ | (6,113 | ) |  | $ | (10,764 | ) |  | $ | 1,245 |  |  | $ | (9,519 | ) |
| Other comprehensive income (loss) before reclassifications | 2,472 |  |  | 401 |  |  | 2,873 |  |  | 923 |  |  | 176 |  |  | 1,099 |  |
| Amounts reclassified from other comprehensive income (loss), net of tax |  |  | (199 | ) |  | (199 | ) |  | — |  |  | 6 |  |  | 6 |  |
| Net current-period other comprehensive income (loss), net of tax | 2,472 |  |  | 202 |  |  | 2,674 |  |  | 923 |  |  | 182 |  |  | 1,105 |  |
| Ending balance | $ | (4,482 | ) |  | $ | 1,043 |  |  | $ | (3,439 | ) |  | $ | (9,841 | ) |  | $ | 1,427 |  |  | $ | (8,414 | ) |


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0000926326-18-000015:notes:135]
Balance sheet details as of March 31, 2018 and December 31, 2017 are presented in the tables below:

[0000926326-18-000015:notes:136]
|  | March 31, 2018 |  | December 31, 2017 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 25,103 |  |  | $ | 22,750 |  |
| Work in process | 9,959 |  |  | 9,818 |  |
| Finished goods and service parts | 66,806 |  |  | 63,569 |  |
| Total inventories | $ | 101,868 |  |  | $ | 96,137 |  |
| Property and equipment: |  |  |  |
| Equipment | $ | 72,122 |  |  | $ | 69,550 |  |
| Furniture and fixtures | 6,750 |  |  | 6,534 |  |
| Leasehold improvements | 14,540 |  |  | 10,976 |  |
| Software | 38,840 |  |  | 37,168 |  |
| Construction in progress | 11,334 |  |  | 9,813 |  |
| Property and equipment, gross | 143,586 |  |  | 134,041 |  |
| Accumulated depreciation and amortization | (95,296 | ) |  | (91,446 | ) |
| Total property and equipment, net | $ | 48,290 |  |  | $ | 42,595 |  |
| Other long term assets: |  |  |  |
| Capitalized software, net | $ | 41,146 |  |  | $ | 38,599 |  |
| Unbilled receivable | 10,877 |  |  | 9,475 |  |
| Other assets | 1,469 |  |  | 1,242 |  |
| Total other long term assets, net | $ | 53,492 |  |  | $ | 49,316 |  |

[0000926326-18-000015:notes:137]
|  | March 31, 2018 |  | December 31, 2017 |
| Accrued liabilities: |  |  |  |
| Advance payments from customers | $ | 6,879 |  |  | $ | 7,779 |  |
| Rebates and lease buyouts | 5,342 |  |  | 5,428 |  |
| Group purchasing organization fees | 3,439 |  |  | 3,449 |  |
| Taxes payable | 12,135 |  |  | 9,183 |  |
| Other accrued liabilities | 12,724 |  |  | 9,854 |  |
| Total accrued liabilities | $ | 40,519 |  |  | $ | 35,693 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0000926326-18-000015:notes:138]
[same as prior period, unchanged from 0000926326-17-000038:notes:133]

[0000926326-18-000015:notes:139]
|  | Three months ended |
|  | March 31, 2018 |  | March 31, 2017 |
|  | (In thousands) |
| Cost of product and service revenues | $ | 1,019 |  |  | $ | 982 |  |
| Research and development | 1,234 |  |  | 897 |  |
| Selling, general and administrative | 4,275 |  |  | 3,632 |  |
| Total share-based compensation expense | $ | 6,528 |  |  | $ | 5,511 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0000926326-18-000015:notes:140]
Summaries of restricted stock activity under the Company's 2009 Equity Incentive Plan, as amended (the "2009 Plan") are presented below:

[0000926326-18-000015:notes:141]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Restricted Stock Units ("RSUs") |  |  |  |  |  |  |  |
| Outstanding at December 31, 2017 | 501 |  |  | $ | 38.90 |  |  | 1.5 |  | $ | 24,293 |  |
| Granted | 71 |  |  | 44.32 |  |  |  |  |  |
| Vested | (50 | ) |  | 33.70 |  |  |  |  |  |
| Forfeited | (14 | ) |  | 39.05 |  |  |  |  |  |
| Outstanding and unvested at March 31, 2018 | 508 |  |  | $ | 40.16 |  |  | 1.5 |  | $ | 22,041 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000926326-18-000015:notes:142]
[same as prior period, unchanged from 0000926326-17-000038:notes:137]

[0000926326-18-000015:notes:143]
|  | Three months ended March 31, |
|  | 2018 |  | 2017 |
|  | Automation andAnalytics |  | MedicationAdherence |  | Total |  | Automation andAnalytics |  | MedicationAdherence |  | Total |
|  | (In thousands) |
| Revenues | $ | 151,406 |  |  | $ | 31,213 |  |  | $ | 182,619 |  |  | $ | 122,170 |  |  | $ | 26,383 |  |  | $ | 148,553 |  |
| Cost of revenues | 78,242 |  |  | 21,922 |  |  | 100,164 |  |  | 68,761 |  |  | 17,601 |  |  | 86,362 |  |
| Gross profit | 73,164 |  |  | 9,291 |  |  | 82,455 |  |  | 53,409 |  |  | 8,782 |  |  | 62,191 |  |
| Operating expenses | 48,390 |  |  | 10,199 |  |  | 58,589 |  |  | 48,062 |  |  | 11,196 |  |  | 59,258 |  |
| Income from operations | $ | 24,774 |  |  | $ | (908 | ) |  | $ | 23,866 |  |  | $ | 5,347 |  |  | $ | (2,414 | ) |  | $ | 2,933 |  |
| Corporate costs |  |  |  |  | 23,233 |  |  |  |  |  |  | 19,485 |  |
| Income from operations |  |  |  |  | $ | 633 |  |  |  |  |  |  | $ | (16,552 | ) |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0000926326-18-000015:notes:144]
The following table summarizes the share option activity under the Company’s equity incentive plans during the three months ended March 31, 2018:

[0000926326-18-000015:notes:145]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Stock Options |  |  |  |  |  |  |  |
| Outstanding at December 31, 2017 | 3,323 |  |  | $ | 32.72 |  |  | 7.6 |  | $ | 53,953 |  |
| Granted | 482 |  |  | 44.38 |  |  |  |  |  |
| Exercised | (87 | ) |  | 22.50 |  |  |  |  |  |
| Expired | (1 | ) |  | 24.09 |  |  |  |  |  |
| Forfeited | (43 | ) |  | 37.14 |  |  |  |  |  |
| Outstanding at March 31, 2018 | 3,674 |  |  | $ | 34.45 |  |  | 7.3 |  | $ | 37,607 |  |
| Exercisable at March 31, 2018 | 1,474 |  |  | $ | 25.36 |  |  | 5.3 |  | $ | 26,596 |  |
| Vested and expected to vest at March 31, 2018 and thereafter | 3,456 |  |  | $ | 33.94 |  |  | 7.2 |  | $ | 36,818 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0000926326-18-000015:notes:146]
|  | Three months ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Employee Stock Purchase Plan |  |  |  |
| Expected life, years | 0.5-2.0 |  |  | 0.5-2.0 |  |
| Expected volatility, % | 27.7-33.8% |  |  | 25.8-32.8% |  |
| Risk free interest rate, % | 0.70-2.25% |  |  | 0.52-1.31% |  |
| Dividend yield, % | — | % |  | — | % |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0000926326-18-000015:notes:147]
The following assumptions were used to value share options and Employee Stock Purchase Plan ("ESPP") shares granted pursuant to the Company's equity incentive plans for the three months ended March 31, 2018 and 2017:

[0000926326-18-000015:notes:148]
|  | Three months ended |
|  | March 31, 2018 |  | March 31, 2017 |
| Stock Option Plans |  |  |  |
| Expected life, years | 4.79 |  |  | 4.67 |  |
| Expected volatility, % | 32.2 | % |  | 31.1 | % |
| Risk free interest rate, % | 2.57 | % |  | 1.89 | % |
| Estimated forfeiture rate % | 6.9 | % |  | 7.7 | % |
| Dividend yield, % | — | % |  | — | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000926326-18-000015:notes:149]
[same as prior period, unchanged from 0000926326-17-000038:notes:145]

[0000926326-18-000015:notes:150]
[same as prior period, unchanged from 0000926326-17-000038:notes:146]

[0000926326-18-000015:notes:151]
[same as prior period, unchanged from 0000926326-17-000038:notes:147]

[0000926326-18-000015:notes:152]
The Automation and Analytics segment is organized around the design, manufacturing, selling and servicing of medication and supply dispensing systems, pharmacy inventory management systems, and related software. The Automation and Analytics products are designed to enable the Company's customers to enhance and improve the effectiveness of the medication-use process, the efficiency of the medical-surgical supply chain, overall patient care and clinical and financial outcomes of medical facilities. Through modular configuration and upgrades, the Company's systems can be tailored to specific customer needs. The financial results of InPharmics acquired in the second quarter of 2017 are included in the Automation and Analytics segment.

[0000926326-18-000015:notes:153]
[same as prior period, unchanged from 0000926326-17-000038:notes:149]

[0000926326-18-000015:notes:154]
The Medication Adherence segment includes solutions to assist patients to remain adherent to their medication regimens. These solutions are comprised of a variety of tools and aids that may be directly used by a pharmacist or a healthcare provider in their direct care for a patient, or the patient themselves, and include software based systems and medication adherence packaging. Software solutions primarily operate on the Patient Management Access Portal (PMAP), a subscription based software system which provides an environment for patient engagement by clinicians. Services running on PMAP include Time My Meds® medication synchronization, immunization management, and a number of tools used by clinicians to manage patient engagement workflows. Medication Adherence packaging is designed either for patient use in care environments where there is a caregiver present or for environments where the patient cares for him or herself and includes the manufacturing and selling of consumable medication blister cards, packaging equipment and ancillary products and services.

[0000926326-18-000015:notes:155]
[same as prior period, unchanged from 0000926326-17-000038:notes:151]

[0000926326-18-000015:notes:156]
There were no customers that accounted for more than 10% of our total revenues for the three months ended March 31, 2018 and 2017. Also, there were no customers that accounted for more than 10% of our accounts receivable as of March 31, 2018 and December 31, 2017.

[0000926326-18-000015:notes:157]
[same as prior period, unchanged from 0000926326-17-000038:notes:153]

[0000926326-18-000015:notes:158]
[same as prior period, unchanged from 0000926326-17-000038:notes:154]


## us-gaap:ShareBasedCompensationPerformanceSharesAwardUnvestedActivityTableTextBlock

[0000926326-18-000015:notes:159]
A summary of the performance-based restricted stock activity under the 2009 Plan during the three months ended March 31, 2018 is presented below:

[0000926326-18-000015:notes:160]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Performance-based Restricted Stock Units ("PSUs") |  |  |  |
| Outstanding at December 31, 2017 | 225 |  |  | $ | 31.18 |  |
| Granted | 110 |  |  | 38.03 |  |
| Vested | (32 | ) |  | 32.37 |  |
| Forfeited | (1 | ) |  | 43.20 |  |
| Outstanding and unvested at March 31, 2018 | 302 |  |  | $ | 33.51 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000926326-18-000015:notes:161]
[same as prior period, unchanged from 0000926326-17-000038:notes:157]

[0000926326-18-000015:notes:162]
[same as prior period, unchanged from 0000926326-17-000038:notes:158]

[0000926326-18-000015:notes:163]
For a detailed explanation of the Company's stock plans and subsequent changes, please refer to Note 11, Employee Benefits and Share-Based Compensation, of the Company's Annual Report on Form 10-K for the year ended December 31, 2017 filed with the SEC on February 27, 2018.

[0000926326-18-000015:notes:164]
[same as prior period, unchanged from 0000926326-17-000038:notes:160]

[0000926326-18-000015:notes:165]
Stock Options and ESPP Shares

[0000926326-18-000015:notes:166]
Stock Options activity

[0000926326-18-000015:notes:167]
The weighted-average fair value per share of options granted during the three months ended March 31, 2018 and 2017 was $14.22 and $10.86, respectively. The intrinsic value of options exercised during the three months ended March 31, 2018 and 2017 was $2.0 million and $2.9 million, respectively.

[0000926326-18-000015:notes:168]
As of March 31, 2018, total unrecognized compensation cost related to unvested stock options was $23.1 million, which is expected to be recognized over a weighted-average vesting period of 3.0 years.

[0000926326-18-000015:notes:169]
[same as prior period, unchanged from 0000926326-17-000038:notes:170]

[0000926326-18-000015:notes:170]
For the three months ending March 31, 2018 and 2017, employees purchased approximately 289,000 and 259,000 shares of common stock under the ESPP at weighted average prices of $26.30 and $25.51, respectively. As of March 31, 2018, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $6.5 million and is expected to be recognized over a weighted-average period of 1.4 years.

[0000926326-18-000015:notes:171]
Restricted Stock Units and Restricted Stock Awards

[0000926326-18-000015:notes:172]
The weighted-average grant date fair value per share of RSUs granted during the three months ended March 31, 2018 and March 31, 2017 was $44.32 and $36.57, respectively.

[0000926326-18-000015:notes:173]
As of March 31, 2018, total unrecognized compensation expense related to RSUs was $17.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 2.8 years.

[0000926326-18-000015:notes:174]
As of March 31, 2018, total unrecognized compensation cost related to RSAs was $0.1 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.1 years.

[0000926326-18-000015:notes:175]
Performance-based Restricted Stock Units

[0000926326-18-000015:notes:176]
The weighted-average grant date fair value per share of PSUs granted during the three months ended March 31, 2018 and 2017 was $38.03 and $32.37, respectively. As of March 31, 2018, total unrecognized compensation cost related to PSUs was $5.4 million, which is expected to be recognized over the remaining weighted-average period of 1.5 years.

[0000926326-18-000015:notes:177]
Summary of Shares Reserved for Future Issuance under Equity Incentive Plans

[0000926326-18-000015:notes:178]
[same as prior period, unchanged from 0000926326-17-000038:notes:173]

[0000926326-18-000015:notes:179]
On August 2, 2016, the Company's Board of Directors (the "Board") authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 (the “2014 Repurchase Program”). As of March 31, 2018, the maximum dollar value of shares that may yet be purchased under the two repurchase programs was $54.9 million. The stock repurchase programs do not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the repurchase program at any time.

[0000926326-18-000015:notes:180]
During the three months ended March 31, 2018 and 2017, the Company did not repurchase any of its outstanding common stock.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000926326-18-000015:notes:181]
Equity Offerings

[0000926326-18-000015:notes:182]
On November 3, 2017, the Company entered into a Distribution Agreement (the “Distribution Agreement”) with J.P. Morgan Securities LLC, Wells Fargo Securities, LLC and HSBC Securities (USA) Inc., as its sales agents, pursuant to which the Company may offer and sell from time to time through the sales agents up to $125 million maximum aggregate offering price of the Company’s common stock. Sales of the common stock pursuant to the Distribution Agreement may be made in negotiated transactions or transactions that are deemed to be “at the market” offerings as defined in Rule 415 under the Securities Act of 1933, as amended (the "Securities Act"), including sales made directly on the Nasdaq Stock Market, or sales made to or through a market maker other than on an exchange.

[0000926326-18-000015:notes:183]
For the three months ended March 31, 2018, the Company did not sell any of its common stock under the Distribution Agreement.


## us-gaap:SubsequentEventsTextBlock

[0000926326-18-000015:notes:184]
Subsequent Event

[0000926326-18-000015:notes:185]
On April 30, 2018, the Company entered into a settlement agreement related to certain contingencies associated with the Ateb 2016 acquisition. The settlement, which will be recognized in the second quarter of 2018, is for approximately $2.5 million.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-18-000015:notes:186]
[same as prior period, unchanged from 0000926326-17-000038:notes:178]
