# OMCL note change history — 0000926326-21-000034 → 0000926326-22-000014


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-09):
[0000926326-22-000014:note_history:1]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceedings described above based on its belief that any potential material loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to these legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of any of these legal proceedings or because of the diversion of management’s attention and the creation of significant expenses.
  (was, 2021-11-05, similarity 0.9953):
[0000926326-21-000034:note_history:1]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceedings described above based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to these legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of any of these legal proceedings or because of the diversion of management’s attention and the creation of significant expenses.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-09):
[0000926326-22-000014:note_history:2]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2022, the Company had non-cancelable purchase commitments of $227.1 million, of which $194.5 million are expected to be paid within the year ending December 31, 2022.
  (was, 2021-11-05, similarity 0.9747):
[0000926326-21-000034:note_history:2]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of September 30, 2021, the Company had non-cancelable purchase commitments of $130.7 million, of which $88.8 million are expected to be paid within the year ending December 31, 2021.

- added (2022-05-09):
[0000926326-22-000014:note_history:3]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020, which was fully briefed, but the Court had not heard oral argument on the motion. The parties entered into a settlement agreement on January 25, 2022. On February 1, 2022, the Court granted preliminary approval of the settlement. The Court has scheduled a status conference for June 1, 2022. Subject to final approval of the settlement, the Company intends to defend the lawsuit vigorously.

- changed (2022-05-09):
[0000926326-22-000014:note_history:4]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “BD Complaint”). This action (the “BD Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly
  (was, 2021-11-05, similarity 0.6146):
[0000926326-21-000034:note_history:4]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “BD Complaint”). This action (the “BD Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The BD Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees and costs, and pre-judgment and post-judgment interest. On March 17, 2021, the parties filed a joint motion to stay the BD Action, which motion was granted by the Court on June 8, 2021. The stay is in place for no more than 180 days, setting the deadline for filing the Company’s answer to the BD Complaint as December 6, 2021, unless an extension to such stay is mutually agreed to by the parties and approved by the Court. The Company intends to defend the lawsuit vigorously.

- added (2022-05-09):
[0000926326-22-000014:note_history:5]
downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The BD Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees and costs, and pre-judgment and post-judgment interest. On March 8, 2022, the parties entered into a confidential settlement agreement. Omnicell is currently in the process of effectuating certain obligations under the agreement prior to dismissal of the BD Complaint.

- changed (2022-05-09):
[0000926326-22-000014:note_history:6]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceedings described above based on its belief that any potential material loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to these legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of any of these legal proceedings or because of the diversion of management’s attention and the creation of significant expenses.
  (was, 2021-11-05, similarity 0.9953):
[0000926326-21-000034:note_history:6]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceedings described above based on its belief that any potential loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to these legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of any of these legal proceedings or because of the diversion of management’s attention and the creation of significant expenses.

- removed (2022-05-09):
[0000926326-21-000034:note_history:7]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a

- removed (2022-05-09):
[0000926326-21-000034:note_history:8]
motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020. The Company's motion to dismiss is now fully briefed, however a date for oral argument on the motion is not currently scheduled. A status conference in the case has been set for November 12, 2021. The Company intends to defend the lawsuit vigorously.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-09):
[0000926326-22-000014:note_history:9]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products and related services are medication management solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” refer to Omnicell, Inc. and its subsidiaries, collectively.
  (was, 2021-11-05, similarity 0.9619):
[0000926326-21-000034:note_history:9]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products and related services are medication management automation solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” collectively refer to Omnicell, Inc. and its subsidiaries.

- changed (2022-05-09):
[0000926326-22-000014:note_history:10]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2022 and December 31, 2021, and the results of operations, comprehensive income, and cash flows for the three months ended March 31, 2022 and 2021. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations, comprehensive income, and cash flows for the three months ended March 31, 2022 are not necessarily indicative of results that may be expected for the year ending December 31, 2022, or for any future period.
  (was, 2021-11-05, similarity 0.8884):
[0000926326-21-000034:note_history:10]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of September 30, 2021 and December 31, 2020, the results of operations and comprehensive income for the three and nine months ended September 30, 2021 and 2020, and cash flows for the nine months ended September 30, 2021 and 2020. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 24, 2021, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations and comprehensive income for the three and nine months ended September 30, 2021, and cash flows for the nine months ended September 30, 2021 are not necessarily indicative of results that may be expected for the year ending December 31, 2021, or for any future period.

- changed (2022-05-09):
[0000926326-22-000014:note_history:11]
On January 10, 2022, the Company completed its acquisition of Hub and Spoke Innovations Limited (“Hub and Spoke Innovations”). The Condensed Consolidated Financial Statements include the results of operations of this recently acquired company, commencing as of the acquisition date. The significant accounting policies of the acquired business have been aligned to conform to the accounting policies of Omnicell.
  (was, 2021-11-05, similarity 0.8256):
[0000926326-21-000034:note_history:11]
On September 9, 2021, the Company completed its acquisition of RxInnovation Inc., operating as FDS Amplicare (“FDS Amplicare”). The Condensed Consolidated Financial Statements include the results of operations of this recently acquired company, commencing as of the acquisition date. The significant accounting policies of the acquired business have been aligned to conform to the accounting policies of Omnicell.

- changed (2022-05-09):
[0000926326-22-000014:note_history:12]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.
  (was, 2021-11-05, similarity 0.933):
[0000926326-21-000034:note_history:12]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.

- changed (2022-05-09):
[0000926326-22-000014:note_history:13]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of March 31, 2022, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.
  (was, 2021-11-05, similarity 0.981):
[0000926326-21-000034:note_history:13]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of September 30, 2021, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

- added (2022-05-09):
[0000926326-22-000014:note_history:14]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.

- added (2022-05-09):
[0000926326-22-000014:note_history:15]
In August 2020, the Financial Accounting Standards Board (“FASB“) issued Accounting Standards Update (“ASU“) 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method is no longer permitted for convertible instruments. This update permits the use of either the modified retrospective or fully retrospective method of transition. The Company adopted ASU 2020-06 on January 1, 2022, using the modified retrospective method of transition. Upon adoption of ASU 2020-06, the previously separated equity component and associated debt issuance costs for the Company’s outstanding convertible senior notes were reclassified to the liability component, thereby eliminating the subsequent amortization of the debt discount as interest expense. In addition, the Company derecognized the deferred tax liability related to the equity component.

- added (2022-05-09):
[0000926326-22-000014:note_history:16]
In December 2021, the Company made an irrevocable election under the indenture to require the principal portion of the Company’s convertible senior notes to be settled in cash and any conversion consideration in excess of the principal portion in cash and/or shares of the Company’s common stock at the Company’s option upon conversion. Following the irrevocable election, only the amounts expected to be settled in excess of the principal portion are considered dilutive in calculating earnings per share under the if-converted method.

- added (2022-05-09):
[0000926326-22-000014:note_history:17]
The Company’s adoption of the update impacted the Condensed Consolidated Balance Sheets at the beginning of the period of adoption as follows:

- added (2022-05-09):
[0000926326-22-000014:note_history:18]
|  | January 1, 2022 |
|  | Pre-ASU 2020-06 Balances |  | ASU 2020-06 Adoption Impact |  | Post-ASU 2020-06 Balances |
|  | (In thousands) |
| Long-term deferred tax assets | $ | 15,883 |  |  | $ | (452) |  |  | $ | 15,431 |  |
| Convertible senior notes, net | 488,152 |  |  | 75,353 |  |  | 563,505 |  |
| Long-term deferred tax liabilities | 51,705 |  |  | (19,572) |  |  | 32,133 |  |
| Additional paid-in capital | 1,024,580 |  |  | (72,742) |  |  | 951,838 |  |
| Retained earnings | 368,571 |  |  | 16,509 |  |  | 385,080 |  |

- added (2022-05-09):
[0000926326-22-000014:note_history:19]
Adoption of the update did not have an impact on the Company’s Condensed Consolidated Statements of Operations or Condensed Consolidated Statements of Cash Flows as of January 1, 2022. Refer to Note 10, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.

- added (2022-05-09):
[0000926326-22-000014:note_history:20]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The update addresses diversity in practice by requiring that an acquirer recognize and measure contract assets and liabilities acquired in a business combination in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The guidance will be applied prospectively to acquisitions occurring on or after the effective date. ASU 2021-08 will be effective for the Company beginning January 1, 2023, and early adoption is permitted. The Company is currently evaluating the impact ASU 2021-08 will have on its Condensed Consolidated Financial Statements.

- changed (2022-05-09):
[0000926326-22-000014:note_history:21]
No other recently issued and effective authoritative guidance is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.
  (was, 2021-11-05, similarity 0.9616):
[0000926326-21-000034:note_history:21]
There was no other recently issued and effective authoritative guidance that is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.

- removed (2022-05-09):
[0000926326-21-000034:note_history:22]
Reclassifications and Adjustments

- removed (2022-05-09):
[0000926326-21-000034:note_history:23]
Certain prior-year amounts have been reclassified to conform with current-period presentation. This reclassification was a change in the presentation of certain items in the disaggregation of revenues for the three and nine months ended September 30, 2020 in Note 3, Revenues. This change was not deemed material and was included to conform with current-period classification and presentation.

- removed (2022-05-09):
[0000926326-21-000034:note_history:24]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company's Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM

- removed (2022-05-09):
[0000926326-21-000034:note_history:25]
allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.

- removed (2022-05-09):
[0000926326-21-000034:note_history:26]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The update simplifies the accounting for income taxes by removing certain exceptions to the general principles in Accounting Standards Codification (“ASC”) 740, Income Taxes, as well as improves consistent application of and simplifies the guidance for other areas of ASC 740 by clarifying and amending existing guidance. The Company adopted ASU 2019-12 on January 1, 2021 on a prospective basis. The adoption of this guidance did not have a material impact on the Company’s Condensed Consolidated Financial Statements.

- removed (2022-05-09):
[0000926326-21-000034:note_history:27]
In August 2020, the FASB issued ASU 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. This update permits the use of either the modified retrospective or fully retrospective method of transition. The Company will adopt ASU 2020-06 on January 1, 2022, and expects to use the modified retrospective method of transition. The Company’s adoption of the update is estimated to result in an increase in convertible senior notes, net of issuance costs, of $75.4 million; a decrease in additional paid-in capital of $72.7 million; a decrease of long-term deferred tax liabilities of $19.8 million; a decrease in long-term deferred tax assets of $0.5 million; and an increase in retained earnings of $16.7 million, all as of January 1, 2022.


## omcl:ScheduleOfDebtIssuanceCostsNetTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2022-05-09):
[0000926326-21-000034:note_history:28]
The following table represents changes in the balance of the Company's deferred debt issuance costs:

- removed (2022-05-09):
[0000926326-21-000034:note_history:29]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (823) |  |
| Balance as of September 30, 2021 | $ | 3,430 |  |


## omcl:ScheduleOfInterestExpenseDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-09):
[0000926326-22-000014:note_history:30]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2022 and 2021:
  (was, 2021-11-05, similarity 0.8889):
[0000926326-21-000034:note_history:30]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2021:

- changed (2022-05-09):
[0000926326-22-000014:note_history:31]
|  | Three Months Ended March 31, |  |  |
|  | 2022 (1) |  | 2021 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of discount | $ | — |  |  | $ | 4,571 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 764 |  |  | $ | 575 |  |  |  |  |  |
  (was, 2021-11-05, similarity 0.6127):
[0000926326-21-000034:note_history:31]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 20 |  |  | $ | 1,078 |  |  | $ | 20 |  |
| Amortization of discount | $ | 4,679 |  |  | $ | 249 |  |  | $ | 13,874 |  |  | $ | 249 |  |
| Amortization of debt issuance costs | $ | 589 |  |  | $ | 31 |  |  | $ | 1,747 |  |  | $ | 31 |  |

- added (2022-05-09):
[0000926326-22-000014:note_history:32]
_________________________________________________

- added (2022-05-09):
[0000926326-22-000014:note_history:33]
(1)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-09):
[0000926326-22-000014:note_history:34]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2022 and December 31, 2021:
  (was, 2021-11-05, similarity 0.963):
[0000926326-21-000034:note_history:34]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2021 and December 31, 2020:

- changed (2022-05-09):
[0000926326-22-000014:note_history:35]
|  | March 31,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (10,731) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 564,269 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |
  (was, 2021-11-05, similarity 0.8883):
[0000926326-21-000034:note_history:35]
|  | September 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (81,870) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (10,308) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 482,822 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |

- added (2022-05-09):
[0000926326-22-000014:note_history:36]
_________________________________________________

- added (2022-05-09):
[0000926326-22-000014:note_history:37]
(1)    Classified as a current liability as of both March 31, 2022 and December 31, 2021 in the Condensed Consolidated Balance Sheets.

- added (2022-05-09):
[0000926326-22-000014:note_history:38]
(2)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.

- removed (2022-05-09):
[0000926326-21-000034:note_history:39]
_________________________________________________
(1)    Included in additional paid-in capital in the Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-09):
[0000926326-22-000014:note_history:40]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.
  (was, 2021-11-05, similarity 0.984):
[0000926326-21-000034:note_history:40]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility (the “Prior Credit Agreement”) and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

- changed (2022-05-09):
[0000926326-22-000014:note_history:41]
On September 22, 2020, the parties entered into an amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.
  (was, 2021-11-05, similarity 0.9869):
[0000926326-21-000034:note_history:41]
On September 22, 2020, the parties entered into an amendment (the “Amendment”) to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

- changed (2022-05-09):
[0000926326-22-000014:note_history:42]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of March 31, 2022.
  (was, 2021-11-05, similarity 0.9957):
[0000926326-21-000034:note_history:42]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of September 30, 2021.

- changed (2022-05-09):
[0000926326-22-000014:note_history:43]
As of each of March 31, 2022 and December 31, 2021, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025
  (was, 2021-11-05, similarity 0.9704):
[0000926326-21-000034:note_history:43]
As of each of September 30, 2021 and December 31, 2020, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

- changed (2022-05-09):
[0000926326-22-000014:note_history:44]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank
  (was, 2021-11-05, similarity 0.882):
[0000926326-21-000034:note_history:44]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

- added (2022-05-09):
[0000926326-22-000014:note_history:45]
National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

- changed (2022-05-09):
[0000926326-22-000014:note_history:46]
During the three months ended March 31, 2022, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on March 31, 2022, the last trading day of the fiscal quarter. Accordingly, the Notes are convertible, in whole or in part, at the option of the holders during the second quarter of 2022. Whether the Notes will be convertible following the second fiscal quarter of 2022 will depend on the continued satisfaction of this condition or another conversion condition in the future. The Company continues to classify the Notes as a current liability in its Condensed Consolidated Financial Statements as of March 31, 2022 based on its irrevocable election to settle the principal amount in cash as discussed below.
  (was, 2021-11-05, similarity 0.8845):
[0000926326-21-000034:note_history:46]
During the three months ended September 30, 2021, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on September 30, 2021, the last trading day of the fiscal quarter. Accordingly, the Notes are convertible, in whole or in part, at the option of the holders during the fourth quarter of 2021. Whether the Notes will be convertible following the fourth fiscal quarter of 2021 will depend on the continued satisfaction of this condition or another conversion condition in the future. The Company continues to classify the Notes as a long-term liability in its Condensed Consolidated Financial Statements as of September 30, 2021 based on contractual settlement provisions.

- added (2022-05-09):
[0000926326-22-000014:note_history:47]
Under the original terms of the Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of Notes of at least $1,000. As a result, for Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of Notes above $1,000. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

- changed (2022-05-09):
[0000926326-22-000014:note_history:48]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2022, none of the criteria for a fundamental change or a conversion rate adjustment had been met.
  (was, 2021-11-05, similarity 0.9854):
[0000926326-21-000034:note_history:48]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of September 30, 2021, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

- added (2022-05-09):
[0000926326-22-000014:note_history:49]
Prior to the adoption of ASU 2020-06, convertible debt instruments that could be settled in cash were required to be separated into liability and equity components. The allocation to the liability component was based on the fair value of a similar

- changed (2022-05-09):
[0000926326-22-000014:note_history:50]
instrument that did not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs were then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represented the debt discount, which the Company amortized to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions.
  (was, 2021-11-05, similarity 0.7552):
[0000926326-21-000034:note_history:50]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represents the debt discount, which the Company will amortize to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions. As of September 30, 2021, the remaining life of the Notes and the related debt discount and issuance cost accretion is approximately 4.0 years.

- added (2022-05-09):
[0000926326-22-000014:note_history:51]
Upon adoption of ASU 2020-06, effective January 1, 2022, the Notes are no longer separated into liability and equity components, and are accounted for as a single liability measured at its amortized cost. Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information.

- added (2022-05-09):
[0000926326-22-000014:note_history:52]
As of March 31, 2022, the remaining life of the Notes and the related issuance cost accretion is approximately 3.5 years.

- changed (2022-05-09):
[0000926326-22-000014:note_history:53]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of March 31, 2022, the if-converted value of the Notes exceeded the principal amount by $190.1 million.
  (was, 2021-11-05, similarity 0.9745):
[0000926326-21-000034:note_history:53]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 8.1 million shares. As of September 30, 2021, the if-converted value of the Notes exceeded the principal amount by $302.0 million.

- changed (2022-05-09):
[0000926326-22-000014:note_history:54]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2022 and December 31, 2021:
  (was, 2021-11-05, similarity 0.963):
[0000926326-21-000034:note_history:54]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of September 30, 2021 and December 31, 2020:

- changed (2022-05-09):
[0000926326-22-000014:note_history:55]
|  | March 31,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (10,731) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 564,269 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |
  (was, 2021-11-05, similarity 0.8883):
[0000926326-21-000034:note_history:55]
|  | September 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | (81,870) |  |  | (95,744) |  |
| Unamortized debt issuance costs | (10,308) |  |  | (12,055) |  |
| Convertible senior notes, liability component | $ | 482,822 |  |  | $ | 467,201 |  |
| Convertible senior notes, equity component (1) | $ | 72,732 |  |  | $ | 72,732 |  |

- changed (2022-05-09):
[0000926326-22-000014:note_history:56]
(1)    Classified as a current liability as of both March 31, 2022 and December 31, 2021 in the Condensed Consolidated Balance Sheets.
  (was, 2021-11-05, similarity 0.6029):
[0000926326-21-000034:note_history:56]
(1)    Included in additional paid-in capital in the Condensed Consolidated Balance Sheets.

- added (2022-05-09):
[0000926326-22-000014:note_history:57]
(2)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.

- changed (2022-05-09):
[0000926326-22-000014:note_history:58]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2022 and 2021:
  (was, 2021-11-05, similarity 0.8889):
[0000926326-21-000034:note_history:58]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three and nine months ended September 30, 2021:

- changed (2022-05-09):
[0000926326-22-000014:note_history:59]
|  | Three Months Ended March 31, |  |  |
|  | 2022 (1) |  | 2021 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of discount | $ | — |  |  | $ | 4,571 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 764 |  |  | $ | 575 |  |  |  |  |  |
  (was, 2021-11-05, similarity 0.6127):
[0000926326-21-000034:note_history:59]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 20 |  |  | $ | 1,078 |  |  | $ | 20 |  |
| Amortization of discount | $ | 4,679 |  |  | $ | 249 |  |  | $ | 13,874 |  |  | $ | 249 |  |
| Amortization of debt issuance costs | $ | 589 |  |  | $ | 31 |  |  | $ | 1,747 |  |  | $ | 31 |  |

- added (2022-05-09):
[0000926326-22-000014:note_history:60]
_________________________________________________

- added (2022-05-09):
[0000926326-22-000014:note_history:61]
(1)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.

- added (2022-05-09):
[0000926326-22-000014:note_history:62]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of

- added (2022-05-09):
[0000926326-22-000014:note_history:63]
the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.

- removed (2022-05-09):
[0000926326-21-000034:note_history:64]
The refinancing of the Prior Credit Agreement by means of the A&R Credit Agreement was evaluated in accordance with ASC 470-50, Debt - Modifications and Extinguishments. In determining whether the refinancing was to be accounted for as a debt extinguishment or a debt modification, the Company considered whether lenders within the syndicate remained the same or changed and whether the changes in debt terms were substantial. This assessment was performed on an individual lender basis within the syndicate. As a result, the refinancing was accounted for as a modification with the exception of certain lenders that exited the syndicate. The exit of certain lenders resulted in an immaterial write-off of existing unamortized debt issuance costs. The remaining unamortized debt issuance costs related to debt modification, along with the new deferred costs, will be amortized over the remaining term of the A&R Credit Agreement.

- removed (2022-05-09):
[0000926326-21-000034:note_history:65]
In connection with the A&R Credit Agreement, the Company incurred and capitalized an additional $2.3 million of debt issuance costs. In connection with the Amendment on September 22, 2020, the Company incurred and capitalized an additional $0.6 million of debt issuance costs. The debt issuance costs are being amortized to interest expense using the straight-line method through 2024. Amortization expense related to debt issuance costs for credit agreements was

- removed (2022-05-09):
[0000926326-21-000034:note_history:66]
approximately $0.3 million and $0.2 million for the three months ended September 30, 2021 and 2020, respectively, and approximately $0.8 million and $0.7 million for the nine months ended September 30, 2021 and 2020, respectively.

- removed (2022-05-09):
[0000926326-21-000034:note_history:67]
The following table represents changes in the balance of the Company's deferred debt issuance costs:

- removed (2022-05-09):
[0000926326-21-000034:note_history:68]
|  | (In thousands) |
| Balance as of December 31, 2020 | $ | 4,253 |  |
| Additions | — |  |
| Amortization | (823) |  |
| Balance as of September 30, 2021 | $ | 3,430 |  |

- removed (2022-05-09):
[0000926326-21-000034:note_history:69]
Upon conversion, the Company may satisfy its conversion obligation by paying or delivering, as the case may be, cash, shares of its common stock, or a combination of cash and shares of its common stock, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in

- removed (2022-05-09):
[0000926326-21-000034:note_history:70]
connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

- removed (2022-05-09):
[0000926326-21-000034:note_history:71]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-05-09):
[0000926326-22-000014:note_history:72]
Prior to the adoption of ASU 2020-06, convertible debt instruments that could be settled in cash were required to be separated into liability and equity components. The allocation to the liability component was based on the fair value of a similar instrument that did not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs were then allocated to the liability and equity components in a similar manner.Upon adoption of ASU 2020-06, effective January 1, 2022, the Notes are no longer separated into liability and equity components, and are accounted for as a single liability measured at its amortized cost.

- removed (2022-05-09):
[0000926326-21-000034:note_history:73]
Convertible debt instruments that may be settled in cash are required to be separated into liability and equity components. The allocation to the liability component is based on the fair value of a similar instrument that does not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs are then allocated to the liability and equity components in a similar manner.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-09):
[0000926326-22-000014:note_history:74]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, ReCept management services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IV compounding automation solutions.
  (was, 2021-11-05, similarity 0.6481):
[0000926326-21-000034:note_history:74]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth (formerly Population Health

- changed (2022-05-09):
[0000926326-22-000014:note_history:75]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue.
  (was, 2021-11-05, similarity 0.9703):
[0000926326-21-000034:note_history:75]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue.

- removed (2022-05-09):
[0000926326-21-000034:note_history:76]
Solutions) inclusive of newly acquired FDS Amplicare, 340B solutions, and services associated with Omnicell One™ (formerly Performance Center), Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IV compounding automation solutions.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-09):
[0000926326-22-000014:note_history:77]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, ReCept management services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IV compounding automation solutions.
  (was, 2021-11-05, similarity 0.6481):
[0000926326-21-000034:note_history:77]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth (formerly Population Health

- changed (2022-05-09):
[0000926326-22-000014:note_history:78]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $4.5 million and $3.4 million for the three months ended March 31, 2022 and 2021, respectively.
  (was, 2021-11-05, similarity 0.9086):
[0000926326-21-000034:note_history:78]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often owned fully or in part by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $4.4 million and $2.3 million for the three months ended September 30, 2021 and 2020, respectively, and $12.0 million and $6.9 million for the nine months ended September 30, 2021 and 2020, respectively.

- changed (2022-05-09):
[0000926326-22-000014:note_history:79]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three months ended March 31, 2022 and 2021:
  (was, 2021-11-05, similarity 0.9288):
[0000926326-21-000034:note_history:79]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three and nine months ended September 30, 2021 and 2020:

- changed (2022-05-09):
[0000926326-22-000014:note_history:80]
|  | Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 208,078 |  |  | $ | 159,718 |  |  |  |  |  |
| Technical services | 49,169 |  |  | 50,860 |  |  |  |  |  |
| Consumables | 17,797 |  |  | 18,407 |  |  |  |  |  |
| SaaS, subscription software, and technology-enabled services | 43,784 |  |  | 22,858 |  |  |  |  |  |
| Total revenues | $ | 318,828 |  |  | $ | 251,843 |  |  |  |  |  |
  (was, 2021-11-05, similarity 0.7939):
[0000926326-21-000034:note_history:80]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 195,820 |  |  | $ | 135,037 |  |  | $ | 534,582 |  |  | $ | 403,761 |  |
| Technical services | 53,529 |  |  | 51,380 |  |  | 156,321 |  |  | 151,077 |  |
| Consumables | 18,150 |  |  | 16,300 |  |  | 54,424 |  |  | 56,591 |  |
| SaaS, subscription software, and technology-enabled services | 28,903 |  |  | 10,982 |  |  | 75,657 |  |  | 31,577 |  |
| Total revenues | $ | 296,402 |  |  | $ | 213,699 |  |  | $ | 820,984 |  |  | $ | 643,006 |  |

- changed (2022-05-09):
[0000926326-22-000014:note_history:81]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2022 and 2021:
  (was, 2021-11-05, similarity 0.9493):
[0000926326-21-000034:note_history:81]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three and nine months ended September 30, 2021 and 2020:

- changed (2022-05-09):
[0000926326-22-000014:note_history:82]
|  | Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In thousands) |
| United States | $ | 287,577 |  |  | $ | 224,276 |  |  |  |  |  |
| Rest of world (1) | 31,251 |  |  | 27,567 |  |  |  |  |  |
| Total revenues | $ | 318,828 |  |  | $ | 251,843 |  |  |  |  |  |
  (was, 2021-11-05, similarity 0.695):
[0000926326-21-000034:note_history:82]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  | (In thousands) |
| United States | $ | 271,276 |  |  | $ | 193,639 |  |  | $ | 738,411 |  |  | $ | 579,425 |  |
| Rest of world (1) | 25,126 |  |  | 20,060 |  |  | 82,573 |  |  | 63,581 |  |
| Total revenues | $ | 296,402 |  |  | $ | 213,699 |  |  | $ | 820,984 |  |  | $ | 643,006 |  |

- changed (2022-05-09):
[0000926326-22-000014:note_history:83]
|  | March 31,2022 |  | December 31,2021 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 17,348 |  |  | $ | 17,208 |  |
| Long-term unbilled receivables, net (2) | 16,316 |  |  | 18,084 |  |
| Total contract assets | $ | 33,664 |  |  | $ | 35,292 |  |
| Short-term deferred revenues, net | $ | 127,998 |  |  | $ | 112,196 |  |
| Long-term deferred revenues | 24,037 |  |  | 20,194 |  |
| Total contract liabilities | $ | 152,035 |  |  | $ | 132,390 |  |
  (was, 2021-11-05, similarity 0.9817):
[0000926326-21-000034:note_history:83]
|  | September 30,2021 |  | December 31,2020 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 17,879 |  |  | $ | 13,895 |  |
| Long-term unbilled receivables, net (2) | 14,460 |  |  | 17,205 |  |
| Total contract assets | $ | 32,339 |  |  | $ | 31,100 |  |
| Short-term deferred revenues, net | $ | 114,726 |  |  | $ | 100,053 |  |
| Long-term deferred revenues | 14,141 |  |  | 5,673 |  |
| Total contract liabilities | $ | 128,867 |  |  | $ | 105,726 |  |

- changed (2022-05-09):
[0000926326-22-000014:note_history:84]
Short-term deferred revenues of $128.0 million and $112.2 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $20.3 million and $22.4 million, as of March 31, 2022 and December 31, 2021, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three months ended March 31, 2022, the Company recognized revenues of $66.6 million, that were included in the corresponding gross short-term deferred revenues balance of $134.6 million as of December 31, 2021.
  (was, 2021-11-05, similarity 0.928):
[0000926326-21-000034:note_history:84]
Short-term deferred revenues of $114.7 million and $100.1 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $24.1 million and $21.0 million, as of September 30, 2021 and December 31, 2020, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three and nine months ended September 30, 2021, the Company recognized revenues of $18.9 million and $90.0 million, respectively, that were included in the corresponding gross short-term deferred revenues balance of $121.1 million as of December 31, 2020.

- added (2022-05-09):
[0000926326-22-000014:note_history:85]
Long-term deferred revenues include deferred revenues from product and service contracts of $24.0 million and $20.2 million as of March 31, 2022 and December 31, 2021, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.

- changed (2022-05-09):
[0000926326-22-000014:note_history:86]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2022 and 2021. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2022 and December 31, 2021.
  (was, 2021-11-05, similarity 0.8115):
[0000926326-21-000034:note_history:86]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three and nine months ended September 30, 2021 and 2020. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of September 30, 2021 and December 31, 2020.

- removed (2022-05-09):
[0000926326-21-000034:note_history:87]
Solutions) inclusive of newly acquired FDS Amplicare, 340B solutions, and services associated with Omnicell One™ (formerly Performance Center), Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IV compounding automation solutions.

- removed (2022-05-09):
[0000926326-21-000034:note_history:88]
Long-term deferred revenues include deferred revenues from product and service contracts of $14.1 million and $5.7 million as of September 30, 2021 and December 31, 2020, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2022-05-09):
[0000926326-22-000014:note_history:89]
Subsequent EventsOn May 4, 2022, the Company determined that certain of its information technology systems were affected by ransomware impacting certain internal systems. There is an impact on certain of the Company’s products and services, as well as certain of its internal systems. Upon detecting the security event, the Company took immediate steps designed to contain the incident and implement its business continuity plans to restore and support continued operations. The Company has notified appropriate law enforcement authorities. The Company is also working closely with cybersecurity experts and legal counsel. The Company is in the early stages of its investigation and assessment of the security event and cannot determine, at this time, the extent of the impact from such event on our business, results of operations or financial condition or whether such impact will have a material adverse effect.
