# OMCL notes — 0000926326-22-000014


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000926326-22-000014:notes:1]
[same as prior period, unchanged from 0000926326-21-000034:notes:1]

[0000926326-22-000014:notes:2]
Omnicell, Inc. was incorporated in California in 1992 under the name Omnicell Technologies, Inc. and reincorporated in Delaware in 2001 as Omnicell, Inc. The Company’s major products and related services are medication management solutions and adherence tools for healthcare systems and pharmacies, which are sold in its principal market, the healthcare industry. The Company’s market is primarily located in the United States and Europe. “Omnicell” or the “Company” refer to Omnicell, Inc. and its subsidiaries, collectively.

[0000926326-22-000014:notes:3]
[same as prior period, unchanged from 0000926326-21-000034:notes:3]

[0000926326-22-000014:notes:4]
The accompanying unaudited Condensed Consolidated Financial Statements reflect, in the opinion of management, all adjustments, consisting of normal recurring adjustments and accruals, necessary to present fairly the financial position of the Company as of March 31, 2022 and December 31, 2021, and the results of operations, comprehensive income, and cash flows for the three months ended March 31, 2022 and 2021. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) have been condensed or omitted in accordance with the rules and regulations of the U.S. Securities and Exchange Commission (“SEC”). These unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022, except as discussed in the section entitled “Recently Adopted Authoritative Guidance” below. The Company’s results of operations, comprehensive income, and cash flows for the three months ended March 31, 2022 are not necessarily indicative of results that may be expected for the year ending December 31, 2022, or for any future period.

[0000926326-22-000014:notes:5]
[same as prior period, unchanged from 0000926326-21-000034:notes:5]

[0000926326-22-000014:notes:6]
[same as prior period, unchanged from 0000926326-21-000034:notes:6]

[0000926326-22-000014:notes:7]
On January 10, 2022, the Company completed its acquisition of Hub and Spoke Innovations Limited (“Hub and Spoke Innovations”). The Condensed Consolidated Financial Statements include the results of operations of this recently acquired company, commencing as of the acquisition date. The significant accounting policies of the acquired business have been aligned to conform to the accounting policies of Omnicell.

[0000926326-22-000014:notes:8]
[same as prior period, unchanged from 0000926326-21-000034:notes:10]

[0000926326-22-000014:notes:9]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s Condensed Consolidated Financial Statements and accompanying Notes. These estimates are based on historical experience and various other assumptions that management believes to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.

[0000926326-22-000014:notes:10]
The Company’s critical accounting policies are those that affect its financial statements materially and involve difficult, subjective, or complex judgments by management. As of March 31, 2022, the Company is not aware of any events or circumstances that would require an update to its estimates, judgments, or revisions to the carrying value of its assets or liabilities.

[0000926326-22-000014:notes:11]
[same as prior period, unchanged from 0000926326-21-000034:notes:13]

[0000926326-22-000014:notes:12]
The Company manages its operations as a single segment for the purposes of assessing performance and making operating decisions. The Company’s Chief Operating Decision Maker (“CODM”) is its Chief Executive Officer. The CODM allocates resources and evaluates the performance of the Company at the consolidated level using information about its revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of the Company as one operating segment, which is the same as its reporting segment.

[0000926326-22-000014:notes:13]
[same as prior period, unchanged from 0000926326-21-000034:notes:16]

[0000926326-22-000014:notes:14]
In August 2020, the Financial Accounting Standards Board (“FASB“) issued Accounting Standards Update (“ASU“) 2020-06, Debt-Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging-Contracts in Entity’s Own Equity (Subtopic 815-40). The update simplifies the accounting for convertible debt instruments by reducing the number of accounting models and the number of embedded conversion features that could be recognized separately from the primary contract. ASU 2020-06 also enhances transparency and improves disclosures for convertible instruments and earnings per share guidance. ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method is no longer permitted for convertible instruments. This update permits the use of either the modified retrospective or fully retrospective method of transition. The Company adopted ASU 2020-06 on January 1, 2022, using the modified retrospective method of transition. Upon adoption of ASU 2020-06, the previously separated equity component and associated debt issuance costs for the Company’s outstanding convertible senior notes were reclassified to the liability component, thereby eliminating the subsequent amortization of the debt discount as interest expense. In addition, the Company derecognized the deferred tax liability related to the equity component.

[0000926326-22-000014:notes:15]
In December 2021, the Company made an irrevocable election under the indenture to require the principal portion of the Company’s convertible senior notes to be settled in cash and any conversion consideration in excess of the principal portion in cash and/or shares of the Company’s common stock at the Company’s option upon conversion. Following the irrevocable election, only the amounts expected to be settled in excess of the principal portion are considered dilutive in calculating earnings per share under the if-converted method.

[0000926326-22-000014:notes:16]
The Company’s adoption of the update impacted the Condensed Consolidated Balance Sheets at the beginning of the period of adoption as follows:

[0000926326-22-000014:notes:17]
|  | January 1, 2022 |
|  | Pre-ASU 2020-06 Balances |  | ASU 2020-06 Adoption Impact |  | Post-ASU 2020-06 Balances |
|  | (In thousands) |
| Long-term deferred tax assets | $ | 15,883 |  |  | $ | (452) |  |  | $ | 15,431 |  |
| Convertible senior notes, net | 488,152 |  |  | 75,353 |  |  | 563,505 |  |
| Long-term deferred tax liabilities | 51,705 |  |  | (19,572) |  |  | 32,133 |  |
| Additional paid-in capital | 1,024,580 |  |  | (72,742) |  |  | 951,838 |  |
| Retained earnings | 368,571 |  |  | 16,509 |  |  | 385,080 |  |

[0000926326-22-000014:notes:18]
Adoption of the update did not have an impact on the Company’s Condensed Consolidated Statements of Operations or Condensed Consolidated Statements of Cash Flows as of January 1, 2022. Refer to Note 10, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.

[0000926326-22-000014:notes:19]
[same as prior period, unchanged from 0000926326-21-000034:notes:18]

[0000926326-22-000014:notes:20]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The update addresses diversity in practice by requiring that an acquirer recognize and measure contract assets and liabilities acquired in a business combination in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The guidance will be applied prospectively to acquisitions occurring on or after the effective date. ASU 2021-08 will be effective for the Company beginning January 1, 2023, and early adoption is permitted. The Company is currently evaluating the impact ASU 2021-08 will have on its Condensed Consolidated Financial Statements.

[0000926326-22-000014:notes:21]
No other recently issued and effective authoritative guidance is expected to have a material impact on the Company’s Condensed Consolidated Financial Statements through the reporting date.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000926326-22-000014:notes:22]
Business CombinationsThe Company accounted for its acquisitions in accordance with ASC 805, Business Combinations. The tangible and intangible assets acquired and liabilities assumed were recorded at fair value on the respective acquisition dates. Intangible assets eligible for recognition separate from goodwill were those that satisfied either the contractual or legal criterion or the separability criterion, each as set forth in the accounting guidance. The preliminary fair values reflect management’s best estimates based on information available at the respective acquisition dates and may change as additional information is received over the measurement period, which will end no later than one year from the respective acquisition date. The Company 
believes that the fair values assigned to the assets acquired and liabilities assumed are based on reasonable assumptions and estimates that market participants would use. Actual results may differ from these estimates and assumptions.

[0000926326-22-000014:notes:23]
The Company’s Condensed Consolidated Financial Statements include the results of operations of each acquired company, commencing as of their respective acquisition dates. Acquisition-related costs were expensed as incurred, and are included in selling, general, and administrative expenses in the Company’s Condensed Consolidated Statements of Operations.

[0000926326-22-000014:notes:24]
2022 Acquisition

[0000926326-22-000014:notes:25]
Hub and Spoke Innovations

[0000926326-22-000014:notes:26]
On January 10, 2022, the Company completed the acquisition of all of the outstanding equity interests in Hub and Spoke Innovations, pursuant to the terms and conditions of the Share Purchase Agreement, dated January 10, 2022, by and among Omnicell Limited (a wholly-owned subsidiary of the Company), Hub and Spoke Innovations Limited, and certain beneficial stockholders specified therein for a base purchase price of £2.5 million (approximately $3.4 million based on the exchange rate in effect at the acquisition date), prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The preliminary purchase price transferred for the transaction, net of cash acquired, was £2.5 million (approximately $3.4 million based on the exchange rate in effect at the acquisition date). Of the purchase price transferred, £1.9 million (approximately $2.5 million based on the exchange rate in effect at the acquisition date) was allocated to goodwill; £0.8 million (approximately $1.1 million based on the exchange rate in effect at the acquisition date) was allocated to intangible assets, which included customer relationships; and the remainder was allocated to net assets acquired. The Hub and Spoke Innovations acquisition is expected to complement Omnicell’s total solution technology portfolio for retail pharmacy in the United Kingdom to help pharmacies improve workflows, offer patients 24/7 access to their medications and provide enhanced patient care.

[0000926326-22-000014:notes:27]
2021 Acquisitions

[0000926326-22-000014:notes:28]
MarkeTouch Media

[0000926326-22-000014:notes:29]
On December 31, 2021, the Company completed the acquisition of all of the outstanding equity interests in MarkeTouch Media, LLC (“MarkeTouch Media”) pursuant to the terms and conditions of the Unit Purchase Agreement, dated December 31, 2021, by and among ateb, Inc. (a wholly-owned subsidiary of the Company), MarkeTouch Media, LLC, MarkeTouch Holdings, Inc., Toucan Enterprises, Inc., and certain beneficial stockholders specified therein for a base purchase price of $82.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The MarkeTouch Media acquisition adds mobile and web-based technology and patient engagement solutions, which is expected to expand the footprint of EnlivenHealth® across the retail pharmacy sector, while enhancing potential growth opportunities in new market segments like specialty pharmacy and pharmacy benefits management.

[0000926326-22-000014:notes:30]
ReCept

[0000926326-22-000014:notes:31]
On December 29, 2021, the Company completed the acquisition of all outstanding equity securities of ReCept Holdings, Inc. (“ReCept”) pursuant to the terms and conditions of the Agreement and Plan of Merger, dated December 1, 2021, by and among Omnicell, Inc., ReCept Holdings, Inc., Redfish Acquisition Corp, and the representative of the securityholders for a base purchase price of $100.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The addition of ReCept’s specialty pharmacy management services for health systems, provider groups, and federally qualified health centers expands Omnicell’s Advanced Services portfolio in an effort to address the growing and complex specialty pharmacy market.

[0000926326-22-000014:notes:32]
FDS Amplicare

[0000926326-22-000014:notes:33]
On September 9, 2021, the Company completed the acquisition of all of the outstanding equity interests in RxInnovation, Inc., operating as FDS Amplicare (“FDS Amplicare”), pursuant to the terms and conditions of the Agreement and Plan of Merger, dated July 25, 2021, by and among RxInnovation Inc., Omnicell, Inc., Fleming Acquisition Corp., and the representative of the securityholders for a base purchase price of $177.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The FDS Amplicare® acquisition adds a comprehensive and complementary suite of Software-as-a-Service (“SaaS”) financial management, analytics, and population health solutions to the Company’s EnlivenHealth offering.

[0000926326-22-000014:notes:34]
The following tables represent the preliminary allocation of the respective purchase price to the assets acquired and the liabilities assumed by the Company as part of each acquisition included in the Company’s Consolidated Balance Sheets, and is reconciled to the respective purchase price transferred:

[0000926326-22-000014:notes:35]
|  | FDS Amplicare (1) |  | ReCept(Preliminary) (2) |  | MarkeTouch Media(Preliminary) |
|  | (In thousands) |
| Purchase price transferred: |  |  |  |  |  |
| Base purchase price | $ | 177,000 |  |  | $ | 100,000 |  |  | $ | 82,000 |  |
| Add: Closing cash | 465 |  |  | 6,664 |  |  | 191 |  |
| Add: Net working capital adjustment | 1,654 |  |  | (2,296) |  |  | 448 |  |
| Less: Assumed indebtedness | (653) |  |  | (1,902) |  |  | (13) |  |
| Total purchase price transferred | $ | 178,466 |  |  | $ | 102,466 |  |  | $ | 82,626 |  |
|  | FDS Amplicare (Preliminary) (1) |  | ReCept(Preliminary) (2) |  | MarkeTouch Media(Preliminary) |
| Fair value of assets acquired and liabilities assumed: |  |  |  |  |  |
| Cash and cash equivalents | $ | 465 |  |  | $ | — |  |  | $ | 237 |  |
| Accounts receivable and unbilled receivables | 5,330 |  |  | 2,383 |  |  | 2,302 |  |
| Prepaid expenses | 506 |  |  | 192 |  |  | 96 |  |
| Other current assets | 45 |  |  | 13,955 |  |  | — |  |
| Total current assets | 6,346 |  |  | 16,530 |  |  | 2,635 |  |
| Property and equipment | 444 |  |  | 172 |  |  | 177 |  |
| Operating lease right-of-use assets | 2,252 |  |  | 773 |  |  | 602 |  |
| Goodwill | 117,374 |  |  | 81,588 |  |  | 42,530 |  |
| Intangible assets | 70,000 |  |  | 28,100 |  |  | 38,000 |  |
| Other long-term assets | 51 |  |  | 200 |  |  | 2,850 |  |
| Total assets | 196,467 |  |  | 127,363 |  |  | 86,794 |  |
| Accounts payable | 950 |  |  | 219 |  |  | 473 |  |
| Accrued compensation | 1,312 |  |  | 1,756 |  |  | — |  |
| Accrued liabilities | 1,396 |  |  | 18,499 |  |  | 292 |  |
| Deferred revenues | 1,916 |  |  | 222 |  |  | 347 |  |
| Long-term deferred tax liabilities | 11,377 |  |  | 3,587 |  |  | — |  |
| Long-term operating lease liabilities | 920 |  |  | 614 |  |  | 206 |  |
| Other long-term liabilities | 130 |  |  | — |  |  | 2,850 |  |
| Total liabilities | 18,001 |  |  | 24,897 |  |  | 4,168 |  |
| Total purchase price | $ | 178,466 |  |  | $ | 102,466 |  |  | $ | 82,626 |  |
| Total purchase price, net of cash acquired | $ | 178,001 |  |  | $ | 95,897 |  |  | $ | 82,389 |  |

[0000926326-22-000014:notes:36]
[same as prior period, unchanged from 0000926326-21-000034:notes:40]

[0000926326-22-000014:notes:37]
(1)    During the fourth quarter of 2021, the Company recorded measurement period adjustments of $1.5 million to goodwill, consisting of an increase in intangible assets, accounts receivable and unbilled receivables, and long-term deferred tax liabilities of $0.4 million, $1.1 million, and $0.1 million, respectively, and a net working capital adjustment of $0.1 million.

[0000926326-22-000014:notes:38]
(2)    Closing cash is included in other current assets due to its restrictive nature as cash held for customers.

[0000926326-22-000014:notes:39]
The $117.4 million of goodwill arising from the FDS Amplicare acquisition is primarily attributed to future sales of SaaS solutions and FDS Amplicare’s assembled workforce. None of the FDS Amplicare goodwill is expected to be deductible for tax purposes. The $81.6 million of goodwill arising from the ReCept acquisition is primarily attributed to future sales of its offerings and services and ReCept’s assembled workforce. None of the ReCept goodwill is expected to be deductible for tax purposes. The $42.5 million of goodwill arising from the MarkeTouch Media acquisition is primarily attributed to future sales of SaaS solutions and MarkeTouch Media’s assembled workforce. The full amount of the MarkeTouch Media goodwill is expected to be deductible for tax purposes.

[0000926326-22-000014:notes:40]
The identifiable intangible assets acquired and their estimated useful lives for amortization are as follows:

[0000926326-22-000014:notes:41]
|  | FDS Amplicare (1) |  | ReCept |  | MarkeTouch Media |
|  | Fair value |  | Useful life(years) |  | Fair value |  | Useful life(years) |  | Fair value |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 59,900 |  |  | 23 |  | $ | 28,100 |  |  | 23 |  | $ | 34,100 |  |  | 26 |
| Acquired technology | 7,700 |  |  | 5 - 7 |  | — |  |  | — |  | 2,100 |  |  | 4 |
| Backlog | — |  |  | — |  | — |  |  | — |  | 1,800 |  |  | 2 |
| Trade names | 2,400 |  |  | 5 |  | — |  |  | — |  | — |  |  | — |
| Total purchased intangible assets | $ | 70,000 |  |  |  |  | $ | 28,100 |  |  |  |  | $ | 38,000 |  |  |  |

[0000926326-22-000014:notes:42]
(1)    During the fourth quarter of 2021, the Company recorded a measurement period adjustment of $0.4 million in customer relationships.

[0000926326-22-000014:notes:43]
The customer relationships intangible assets represent the fair values of the underlying relationships and agreements with each acquired company’s customers. The acquired technology intangible assets represent the fair values of the portfolio of SaaS solutions that have reached technological feasibility and were part of the respective acquired company’s offerings at their respective acquisition dates. The backlog intangible asset represents contractually committed future billings associated with MarkeTouch Media customer contracts. The trade names intangible asset represents the fair value of brand and name recognition associated with the marketing of certain FDS Amplicare SaaS solutions.

[0000926326-22-000014:notes:44]
The fair values of the customer relationships and backlog intangible assets were determined based on the excess earnings method, and the fair values of the acquired technology and trade names intangible assets were determined based on the relief-from-royalty method. The key assumptions used in estimating the fair values of intangible assets included forecasted financial information; customer attrition rates; royalty rate of 10.0% for the acquired technology intangible assets for both FDS Amplicare and MarkeTouch Media; royalty rate of 2.0% for the FDS Amplicare trade names intangible asset; discount rate of 13.0% for the FDS Amplicare acquisition; discount rate of 15.0% for the ReCept acquisition; discount rate of 11.5% for the MarkeTouch Media acquisition; and certain other assumptions.

[0000926326-22-000014:notes:45]
The customer relationships and acquired technology intangible assets are being amortized using a double-declining method of amortization as such method better represents the economic benefits to be obtained. The backlog and trade names intangible assets are being amortized over their respective estimated useful lives using the straight-line method of amortization.

[0000926326-22-000014:notes:46]
[same as prior period, unchanged from 0000926326-21-000034:notes:48]

[0000926326-22-000014:notes:47]
The following table presents certain unaudited pro forma consolidated financial information for the three months ended March 31, 2021 as if the FDS Amplicare, ReCept, and MarkeTouch Media acquisitions had been completed on January 1, 2020. The pro forma effects of the Hub and Spoke Innovations acquisition were not material to the Company’s consolidated results of operations. The unaudited pro forma financial information is presented for informational purposes only, and is not indicative of what would have occurred had the acquisitions taken place on those respective dates. The unaudited pro forma financial information combines the historical results of the acquisitions with the Company’s consolidated historical results and includes certain adjustments including, but not limited to, amortization and depreciation of intangible assets and property and equipment acquired; and certain acquisition-related costs incurred.

[0000926326-22-000014:notes:48]
|  | Three Months Ended March 31, |  |  |
|  | 2021 |  |  |  |  |  |  |
|  | (In thousands) |
| Pro forma revenues | $ | 268,921 |  |  |  |  |  |  |  |
| Pro forma net income | $ | 13,066 |  |  |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000926326-22-000014:notes:49]
[same as prior period, unchanged from 0000926326-21-000034:notes:55]

[0000926326-22-000014:notes:50]
[same as prior period, unchanged from 0000926326-21-000034:notes:56]

[0000926326-22-000014:notes:51]
[same as prior period, unchanged from 0000926326-21-000034:notes:57]

[0000926326-22-000014:notes:52]
[same as prior period, unchanged from 0000926326-21-000034:notes:58]

[0000926326-22-000014:notes:53]
[same as prior period, unchanged from 0000926326-21-000034:notes:59]

[0000926326-22-000014:notes:54]
SaaS, subscription software, and technology-enabled services. Emerging software and service solutions which are offered on a subscription basis with fees typically based either on transaction volume or a fee over a specified period of time. Solutions in this category include, but are not limited to, EnlivenHealth inclusive of FDS Amplicare and MarkeTouch Media, 340B solutions, ReCept management services, and services associated with Omnicell One™, Central Pharmacy Dispensing Services, including the XR2 Automated Central Pharmacy System, and Central Pharmacy Compounding Services, including IV compounding automation solutions.

[0000926326-22-000014:notes:55]
[same as prior period, unchanged from 0000926326-21-000034:notes:62]

[0000926326-22-000014:notes:56]
[same as prior period, unchanged from 0000926326-21-000034:notes:63]

[0000926326-22-000014:notes:57]
A portion of the Company’s sales are made to customers who are members of Group Purchasing Organizations (“GPOs”) and Federal agencies that purchase under a Federal Supply Schedule Contract with the Department of Veterans Affairs (the “GSA Contract”). GPOs are often fully or partially owned by the Company’s customers, and the Company pays fees to the GPO on completed contracts. The Company also pays the Industrial Funding Fee (“IFF”) to the Department of Veterans Affairs under the GSA Contract. The Company considers these fees consideration paid to customers and records them as reductions to revenue. Fees to GPOs and the IFF were $4.5 million and $3.4 million for the three months ended March 31, 2022 and 2021, respectively.

[0000926326-22-000014:notes:58]
[same as prior period, unchanged from 0000926326-21-000034:notes:65]

[0000926326-22-000014:notes:59]
The following table summarizes the Company’s revenues disaggregated by revenue type for the three months ended March 31, 2022 and 2021:

[0000926326-22-000014:notes:60]
|  | Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In thousands) |
| Connected devices, software licenses, and other | $ | 208,078 |  |  | $ | 159,718 |  |  |  |  |  |
| Technical services | 49,169 |  |  | 50,860 |  |  |  |  |  |
| Consumables | 17,797 |  |  | 18,407 |  |  |  |  |  |
| SaaS, subscription software, and technology-enabled services | 43,784 |  |  | 22,858 |  |  |  |  |  |
| Total revenues | $ | 318,828 |  |  | $ | 251,843 |  |  |  |  |  |

[0000926326-22-000014:notes:61]
The following table summarizes the Company’s revenues disaggregated by geographic region, which is determined based on customer location, for the three months ended March 31, 2022 and 2021:

[0000926326-22-000014:notes:62]
|  | Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In thousands) |
| United States | $ | 287,577 |  |  | $ | 224,276 |  |  |  |  |  |
| Rest of world (1) | 31,251 |  |  | 27,567 |  |  |  |  |  |
| Total revenues | $ | 318,828 |  |  | $ | 251,843 |  |  |  |  |  |

[0000926326-22-000014:notes:63]
[same as prior period, unchanged from 0000926326-21-000034:notes:70]

[0000926326-22-000014:notes:64]
[same as prior period, unchanged from 0000926326-21-000034:notes:71]

[0000926326-22-000014:notes:65]
[same as prior period, unchanged from 0000926326-21-000034:notes:72]

[0000926326-22-000014:notes:66]
|  | March 31,2022 |  | December 31,2021 |
|  | (In thousands) |
| Short-term unbilled receivables, net (1) | $ | 17,348 |  |  | $ | 17,208 |  |
| Long-term unbilled receivables, net (2) | 16,316 |  |  | 18,084 |  |
| Total contract assets | $ | 33,664 |  |  | $ | 35,292 |  |
| Short-term deferred revenues, net | $ | 127,998 |  |  | $ | 112,196 |  |
| Long-term deferred revenues | 24,037 |  |  | 20,194 |  |
| Total contract liabilities | $ | 152,035 |  |  | $ | 132,390 |  |

[0000926326-22-000014:notes:67]
[same as prior period, unchanged from 0000926326-21-000034:notes:74]

[0000926326-22-000014:notes:68]
[same as prior period, unchanged from 0000926326-21-000034:notes:75]

[0000926326-22-000014:notes:69]
[same as prior period, unchanged from 0000926326-21-000034:notes:76]

[0000926326-22-000014:notes:70]
Short-term deferred revenues of $128.0 million and $112.2 million include deferred revenues from product sales and service contracts, net of deferred cost of sales of $20.3 million and $22.4 million, as of March 31, 2022 and December 31, 2021, respectively. The short-term deferred revenues from product sales relate to delivered and invoiced products, pending installation and acceptance, expected to occur within the next twelve months. During the three months ended March 31, 2022, the Company recognized revenues of $66.6 million, that were included in the corresponding gross short-term deferred revenues balance of $134.6 million as of December 31, 2021.

[0000926326-22-000014:notes:71]
Long-term deferred revenues include deferred revenues from product and service contracts of $24.0 million and $20.2 million as of March 31, 2022 and December 31, 2021, respectively. Remaining performance obligations are primarily recognized ratably over the remaining term of the contract, generally not more than ten years.

[0000926326-22-000014:notes:72]
[same as prior period, unchanged from 0000926326-21-000034:notes:79]

[0000926326-22-000014:notes:73]
There were no customers that accounted for more than 10% of the Company’s total revenues for the three months ended March 31, 2022 and 2021. Also, there were no customers that accounted for more than 10% of the Company’s accounts receivable balance as of March 31, 2022 and December 31, 2021.


## us-gaap:EarningsPerShareTextBlock

[0000926326-22-000014:notes:74]
Net Income Per Share
Basic net income (loss) per share is computed by dividing net income (loss) for the period by the weighted-average number of shares outstanding during the period. In periods of net loss, all potential common shares are anti-dilutive, so diluted net loss per share equals the basic net loss per share. In periods of net income, diluted net income per share is computed by dividing net income for the period by the basic weighted-average number of shares plus any dilutive potential common stock outstanding during the period, using the treasury stock method. Potential common stock includes the effect of outstanding dilutive stock options, restricted stock awards, and restricted stock units, as well as shares the Company could be obligated to issue from its convertible senior notes and warrants, as described in Note 10, Convertible Senior Notes (pre-ASU 2020-06 adoption). For periods prior to the adoption of ASU 2020-06 on January 1, 2022, the Company applied the treasury stock method to calculate the dilutive impact of the convertible senior notes. Upon adoption of ASU 2020-06, effective January 1 2022, the Company is required to apply the if-converted method for calculating the dilutive impact of the convertible senior notes. Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information. Any anti-dilutive weighted-average dilutive shares related to stock award plans, convertible senior notes, and warrants are excluded from the computation of the diluted net income per share.

[0000926326-22-000014:notes:75]
The basic and diluted net income per share calculations for the three months ended March 31, 2022 and 2021 were as follows:

[0000926326-22-000014:notes:76]
|  | Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In thousands, except per share data) |
| Net income | $ | 8,213 |  |  | $ | 14,127 |  |  |  |  |  |
| Weighted-average shares outstanding – basic | 44,249 |  |  | 42,962 |  |  |  |  |  |
| Effect of dilutive securities from stock award plans | 1,646 |  |  | 1,980 |  |  |  |  |  |
| Effect of convertible senior notes | 1,918 |  |  | 1,425 |  |  |  |  |  |
| Effect of warrants | 105 |  |  | — |  |  |  |  |  |
| Weighted-average shares outstanding – diluted | 47,918 |  |  | 46,367 |  |  |  |  |  |
| Net income per share – basic | $ | 0.19 |  |  | $ | 0.33 |  |  |  |  |  |
| Net income per share – diluted | $ | 0.17 |  |  | $ | 0.30 |  |  |  |  |  |
| Anti-dilutive weighted-average shares related to stock award plans | 336 |  |  | 287 |  |  |  |  |  |
| Anti-dilutive weighted-average shares related to convertible senior notes and warrants | — |  |  | 5,908 |  |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000926326-22-000014:notes:77]
Cash and Cash Equivalents and Fair Value of Financial Instruments
Cash and cash equivalents of $265.0 million and $349.1 million as of March 31, 2022 and December 31, 2021, respectively, consisted of bank accounts and highly-liquid U.S. Government money market funds held in sweep and asset management accounts with major financial institutions. As of March 31, 2022 and December 31, 2021, cash equivalents were $224.8 million and $320.2 million, respectively, which consisted of money market funds held in sweep and asset management accounts.

[0000926326-22-000014:notes:78]
[same as prior period, unchanged from 0000926326-21-000034:notes:84]

[0000926326-22-000014:notes:79]
The Company measures its financial instruments at fair value. The Company’s cash, cash equivalents, and restricted cash are classified within Level 1 of the fair value hierarchy as they are valued primarily using quoted market prices utilizing market observable inputs. The Company’s credit facility is classified within Level 2 as the valuation inputs are based on quoted 
prices or market observable data of similar instruments. The Company’s convertible senior notes are classified within Level 2 as the valuation inputs are based on quoted prices in an inactive market on the last day in the reporting period. As of March 31, 2022, the fair value of the convertible senior notes was $810.5 million, compared to their carrying value of $564.3 million, which is net of unamortized debt issuance costs. Refer to Note 9, Debt and Credit Agreement, for further information regarding the Company’s credit facility and Note 10, Convertible Senior Notes, for further information regarding the Company’s convertible senior notes.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000926326-22-000014:notes:80]
Balance Sheet Components
Balance sheet details as of March 31, 2022 and December 31, 2021 are presented in the tables below:

[0000926326-22-000014:notes:81]
|  | March 31,2022 |  | December 31,2021 |
|  | (In thousands) |
| Inventories: |  |  |  |
| Raw materials | $ | 60,238 |  |  | $ | 48,215 |  |
| Work in process | 9,483 |  |  | 11,009 |  |
| Finished goods | 67,335 |  |  | 60,700 |  |
| Total inventories | $ | 137,056 |  |  | $ | 119,924 |  |
| Other current assets: |  |  |  |
| Funds held for customers, including restricted cash (1) | $ | 38,426 |  |  | $ | 20,405 |  |
| Net investment in sales-type leases, current portion | 11,103 |  |  | 10,665 |  |
| Prepaid income taxes | 5,265 |  |  | 6,656 |  |
| Other current assets | 4,049 |  |  | 10,608 |  |
| Total other current assets | $ | 58,843 |  |  | $ | 48,334 |  |
| Other long-term assets: |  |  |  |
| Capitalized software, net | $ | 94,108 |  |  | $ | 96,995 |  |
| Unbilled receivables, net | 16,316 |  |  | 18,084 |  |
| Deferred debt issuance costs | 2,882 |  |  | 3,156 |  |
| Other long-term assets | 8,811 |  |  | 9,284 |  |
| Total other long-term assets | $ | 122,117 |  |  | $ | 127,519 |  |
| Accrued liabilities: |  |  |  |
| Operating lease liabilities, current portion | $ | 11,809 |  |  | $ | 12,947 |  |
| Customer fund liabilities | 38,426 |  |  | 31,727 |  |
| Advance payments from customers | 10,337 |  |  | 8,191 |  |
| Rebate liabilities | 40,344 |  |  | 44,644 |  |
| Group purchasing organization fees | 6,503 |  |  | 7,115 |  |
| Taxes payable | 5,487 |  |  | 3,771 |  |
| Other accrued liabilities | 26,923 |  |  | 24,772 |  |
| Total accrued liabilities | $ | 139,829 |  |  | $ | 133,167 |  |

[0000926326-22-000014:notes:82]
(1)    Includes restricted cash of $23.4 million and $6.6 million as of March 31, 2022 and December 31, 2021, respectively.

[0000926326-22-000014:notes:83]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss), which consisted of foreign currency translation adjustments, for the three months ended March 31, 2022 and 2021:

[0000926326-22-000014:notes:84]
|  | Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In thousands) |
| Beginning balance | $ | (8,407) |  |  |  |  |  |  | $ | (5,522) |  |  |  |  |  |  |  |  |  |
| Other comprehensive loss | (2,555) |  |  |  |  |  |  | (621) |  |  |  |  |  |  |  |  |  |
| Ending balance | $ | (10,962) |  |  |  |  |  |  | $ | (6,143) |  |  |  |  |  |  |  |  |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000926326-22-000014:notes:85]
Property and Equipment
The following table represents the property and equipment balances as of March 31, 2022 and December 31, 2021:

[0000926326-22-000014:notes:86]
|  | March 31,2022 |  | December 31,2021 |
|  | (In thousands) |
| Equipment | $ | 90,930 |  |  | $ | 89,272 |  |
| Furniture and fixtures | 7,432 |  |  | 7,580 |  |
| Leasehold improvements | 20,913 |  |  | 20,623 |  |
| Software | 67,795 |  |  | 60,856 |  |
| Construction in progress | 16,217 |  |  | 14,757 |  |
| Property and equipment, gross | 203,287 |  |  | 193,088 |  |
| Accumulated depreciation and amortization | (126,225) |  |  | (121,947) |  |
| Total property and equipment, net | $ | 77,062 |  |  | $ | 71,141 |  |

[0000926326-22-000014:notes:87]
Depreciation and amortization expense of property and equipment was $5.3 million and $4.8 million for the three months ended March 31, 2022 and 2021, respectively.

[0000926326-22-000014:notes:88]
The geographic location of the Company’s property and equipment, net, is based on the physical location in which it is located. The following table summarizes the geographic information for property and equipment, net, as of March 31, 2022 and December 31, 2021:

[0000926326-22-000014:notes:89]
|  | March 31,2022 |  | December 31,2021 |
|  | (In thousands) |
| United States | $ | 72,803 |  |  | $ | 66,788 |  |
| Rest of world (1) | 4,259 |  |  | 4,353 |  |
| Total property and equipment, net | $ | 77,062 |  |  | $ | 71,141 |  |

[0000926326-22-000014:notes:90]
[same as prior period, unchanged from 0000926326-21-000034:notes:96]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000926326-22-000014:notes:91]
[same as prior period, unchanged from 0000926326-21-000034:notes:97]

[0000926326-22-000014:notes:92]
[same as prior period, unchanged from 0000926326-21-000034:notes:98]

[0000926326-22-000014:notes:93]
|  | December 31,2021 |  | Additions (1) |  |  |  | Foreign currency exchange rate fluctuations |  | March 31,2022 |
|  | (In thousands) |
| Goodwill | $ | 738,900 |  |  | 2,549 |  |  |  |  | (1,023) |  |  | $ | 740,426 |  |

[0000926326-22-000014:notes:94]
(1)     Refer to Note 2, Business Combinations, for further information.

[0000926326-22-000014:notes:95]
[same as prior period, unchanged from 0000926326-21-000034:notes:101]

[0000926326-22-000014:notes:96]
The carrying amounts and useful lives of intangible assets as of March 31, 2022 and December 31, 2021 were as follows:

[0000926326-22-000014:notes:97]
|  | March 31, 2022 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 311,089 |  |  | $ | (83,571) |  |  | $ | (1,106) |  |  | $ | 226,412 |  |  | 4 - 30 |
| Acquired technology | 92,066 |  |  | (55,492) |  |  | — |  |  | 36,574 |  |  | 4 - 20 |
| Backlog | 1,800 |  |  | (225) |  |  | — |  |  | 1,575 |  |  | 2 |
| Trade names | 9,200 |  |  | (5,848) |  |  | — |  |  | 3,352 |  |  | 5 - 12 |
| Patents | 2,430 |  |  | (1,216) |  |  | — |  |  | 1,214 |  |  | 2 - 20 |
| Non-compete agreements | 600 |  |  | (300) |  |  | — |  |  | 300 |  |  | 3 |
| Total intangibles assets, net | $ | 417,185 |  |  | $ | (146,652) |  |  | $ | (1,106) |  |  | $ | 269,427 |  |  |  |

[0000926326-22-000014:notes:98]
|  | December 31, 2021 |
|  | Gross carryingamount (1) |  | Accumulatedamortization |  | Foreign currency exchange rate fluctuations |  | Net carryingamount |  | Useful life(years) |
|  | (In thousands, except for years) |
| Customer relationships | $ | 309,989 |  |  | $ | (78,093) |  |  | $ | (933) |  |  | $ | 230,963 |  |  | 10 - 30 |
| Acquired technology | 95,466 |  |  | (55,859) |  |  | 6 |  |  | 39,613 |  |  | 4 - 20 |
| Backlog | 1,800 |  |  | — |  |  | — |  |  | 1,800 |  |  | 2 |
| Trade names | 9,200 |  |  | (5,600) |  |  | 14 |  |  | 3,614 |  |  | 5 - 12 |
| Patents | 2,462 |  |  | (1,186) |  |  | — |  |  | 1,276 |  |  | 2 - 20 |
| Non-compete agreements | 600 |  |  | (250) |  |  | — |  |  | 350 |  |  | 3 |
| Total intangibles assets, net | $ | 419,517 |  |  | $ | (140,988) |  |  | $ | (913) |  |  | $ | 277,616 |  |  |  |

[0000926326-22-000014:notes:99]
(1)     The differences in gross carrying amounts between periods are primarily due to the write-off of certain fully amortized intangible assets, partially offset by additions of intangible assets in connection with the Hub and Spoke Innovations acquisition.

[0000926326-22-000014:notes:100]
Amortization expense of intangible assets was $9.1 million and $6.3 million for the three months ended March 31, 2022 and 2021, respectively.

[0000926326-22-000014:notes:101]
[same as prior period, unchanged from 0000926326-21-000034:notes:107]

[0000926326-22-000014:notes:102]
|  | March 31,2022 |
|  | (In thousands) |
| Remaining nine months of 2022 | $ | 26,204 |  |
| 2023 | 31,594 |  |
| 2024 | 23,139 |  |
| 2025 | 21,086 |  |
| 2026 | 18,099 |  |
| Thereafter | 149,305 |  |
| Total | $ | 269,427 |  |


## us-gaap:DebtDisclosureTextBlock

[0000926326-22-000014:notes:103]
Debt and Credit Agreement
2019 Revolving Credit Facility

[0000926326-22-000014:notes:104]
On November 15, 2019, the Company entered into an Amended and Restated Credit Agreement (as subsequently amended as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded the Company’s 2016 secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million (the “Incremental Facility”). In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million. The A&R Credit Agreement has an expiration date of November 15, 2024, upon which date all remaining outstanding borrowings will be due and payable.

[0000926326-22-000014:notes:105]
Loans under the Revolving Credit Facility bear interest, at the Company’s option, at a rate equal to either (a) the LIBOR Rate, plus an applicable margin ranging from 1.25% to 2.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio (as defined in the A&R Credit Agreement), or (b) an alternate base rate equal to the highest of (i) the prime rate, (ii) the federal funds rate plus 0.50%, and (iii) LIBOR for an interest period of one month plus 1.00%, plus an applicable margin ranging from 0.25% to 1.00% per annum based on the Company’s Consolidated Total Net Leverage Ratio. Undrawn commitments under the Revolving Credit Facility are subject to a commitment fee ranging from 0.15% to 0.30% per annum based on the Company’s Consolidated Total Net Leverage Ratio on the average daily unused portion of the Revolving Credit Facility. The applicable margin for, and certain other terms of, any term loans under the Incremental Facility will be determined prior to the incurrence of such loans. The Company is permitted to make voluntary prepayments at any time without payment of a premium or penalty.

[0000926326-22-000014:notes:106]
On September 22, 2020, the parties entered into an amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions, as described in Note 10, Convertible Senior Notes, expand the Company’s flexibility to repurchase its common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that requires the Company to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and 3.00:1 for the calendar quarters ending thereafter.

[0000926326-22-000014:notes:107]
The A&R Credit Agreement contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries, including, among other things, restrictions on indebtedness, liens, investments, mergers, dispositions, dividends, and other distributions. The A&R Credit Agreement contains financial covenants that require the Company and its subsidiaries to not exceed a maximum total secured net leverage ratio (as described above) and maintain a minimum interest coverage ratio. In addition, the A&R Credit Agreement contains certain customary events of default including, but not limited to, failure to pay interest, principal, and fees, or other amounts when due, material misrepresentations or misstatements in any representation or warranty, covenant defaults, certain cross defaults to other material indebtedness, certain judgment defaults, and events of bankruptcy. The Company’s obligations under the A&R Credit Agreement and any swap obligations and banking services obligations owing to a lender (or an affiliate of a lender) are guaranteed by certain of its domestic subsidiaries and secured by substantially all of its and such subsidiary guarantors’ assets. In connection with entering into the A&R Credit Agreement, and as a condition precedent to borrowing loans thereunder, the Company and certain of the Company’s other direct and indirect subsidiaries have entered into certain ancillary agreements, including, but not limited to, a reaffirmation agreement, which amends certain terms of the existing collateral agreement and reaffirms their obligations under the existing guaranty agreement. The Company was in full compliance with all covenants as of March 31, 2022.

[0000926326-22-000014:notes:108]
As of each of March 31, 2022 and December 31, 2021, there was no outstanding balance for the Revolving Credit Facility.
Convertible Senior Notes
0.25% Convertible Senior Notes due 2025

[0000926326-22-000014:notes:109]
On September 25, 2020, the Company completed a private offering of $575.0 million aggregate principal amount of 0.25% convertible senior notes (the “Notes”), including the exercise in full of the initial purchasers’ option to purchase up to an additional $75.0 million principal amount of the Notes. The Company received proceeds from the issuance of the Notes of $559.7 million, net of $15.3 million of transaction fees and other debt issuance costs. The Notes bear interest at a rate of 0.25% per year, payable semiannually in arrears on March 15 and September 15 of each year, beginning on March 15, 2021. The Notes were issued pursuant to an indenture, dated September 25, 2020 (the “Indenture”), between the Company and U.S. Bank

[0000926326-22-000014:notes:110]
National Association, as trustee. The Notes are general senior, unsecured obligations of the Company and will mature on September 15, 2025, unless earlier redeemed, repurchased, or converted.

[0000926326-22-000014:notes:111]
The Notes are convertible at the option of the holders at any time prior to the close of business on the business day immediately preceding May 15, 2025, only under the following circumstances: (i) during any fiscal quarter commencing after the fiscal quarter ended on December 31, 2020 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price for the Notes on each applicable trading day; (ii) during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price (as defined in the Indenture) per $1,000 principal amount of the Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate for the Notes on each such trading day; (iii) if the Company calls such Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the Notes called (or deemed called) for redemption; and (iv) upon the occurrence of specified corporate events, as specified in the Indenture. On or after May 15, 2025 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders of the Notes may convert all or any portion of their Notes at any time, regardless of the foregoing conditions.

[0000926326-22-000014:notes:112]
During the three months ended March 31, 2022, the conditional conversion feature of the Notes was triggered, based on the price of the Company’s common stock, as the last reported sale price of the Company’s common stock was greater than or equal to 130% of the then applicable conversion price for the Notes for at least 20 trading days during the period of 30 consecutive trading days ending on March 31, 2022, the last trading day of the fiscal quarter. Accordingly, the Notes are convertible, in whole or in part, at the option of the holders during the second quarter of 2022. Whether the Notes will be convertible following the second fiscal quarter of 2022 will depend on the continued satisfaction of this condition or another conversion condition in the future. The Company continues to classify the Notes as a current liability in its Condensed Consolidated Financial Statements as of March 31, 2022 based on its irrevocable election to settle the principal amount in cash as discussed below.

[0000926326-22-000014:notes:113]
Under the original terms of the Indenture, upon conversion, the Company could satisfy its conversion obligation by paying or delivering cash, shares of its common stock, or a combination thereof, at the Company’s election, in the manner and subject to the terms and conditions provided in the Indenture. On December 13, 2021, the Company irrevocably elected to fix its settlement method to a combination of cash and shares of the Company’s common stock with the specified cash amount per $1,000 principal amount of Notes of at least $1,000. As a result, for Notes converted on or after December 13, 2021, a converting noteholder will receive (i) up to $1,000 in cash per $1,000 principal amount of Notes and (ii) cash and/or shares of the Company’s common stock, at the Company’s option for any conversion consideration in excess of $1,000. In addition, the Company continues to have the ability to set the specified cash amount per $1,000 principal amount of Notes above $1,000. The initial conversion rate for the Notes is 10.2751 shares of the Company’s common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $97.32 per share of the Company’s common stock, subject to adjustment under certain circumstances in accordance with the terms of the Indenture. In addition, following certain corporate events that occur prior to the maturity date of the Notes or if the Company delivers a notice of redemption in respect of the Notes, the Company will, under certain circumstances, increase the conversion rate of the Notes for a holder who elects to convert its Notes (or any portion thereof) in connection with such a corporate event or convert its Notes called (or deemed called) for redemption during the related redemption period (as defined in the Indenture), as the case may be.

[0000926326-22-000014:notes:114]
If the Company undergoes a fundamental change, holders may require, subject to certain exceptions, the Company to repurchase for cash all or any portion of their Notes at a fundamental change repurchase price equal to 100% of the principal amount of the Notes to be repurchased, plus accrued and unpaid interest to, but excluding, the fundamental change repurchase date. As of March 31, 2022, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0000926326-22-000014:notes:115]
The Company may not redeem the Notes prior to September 20, 2023. The Company may redeem for cash all or any portion of the Notes, at its option, on or after September 20, 2023, if the last reported sale price of the Company’s common stock has been at least 130% of the conversion price for the Notes then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. If the Company redeems less than all of the outstanding Notes, at least $150.0 million aggregate principal amount of Notes must be outstanding and not subject to redemption as of the date of the relevant notice of redemption. No sinking fund is provided for in the Notes.

[0000926326-22-000014:notes:116]
Prior to the adoption of ASU 2020-06, convertible debt instruments that could be settled in cash were required to be separated into liability and equity components. The allocation to the liability component was based on the fair value of a similar

[0000926326-22-000014:notes:117]
instrument that did not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs were then allocated to the liability and equity components in a similar manner. Accordingly, at issuance, the Company allocated $461.8 million to the debt liability and $72.7 million to additional paid-in capital, net of applicable issuance costs and deferred taxes. The difference between the principal amount of the Notes and the liability component, inclusive of issuance costs, represented the debt discount, which the Company amortized to interest expense over the term of the Notes using an effective interest rate of 4.18%. The determination of the discount rate required certain estimates and assumptions.

[0000926326-22-000014:notes:118]
Upon adoption of ASU 2020-06, effective January 1, 2022, the Notes are no longer separated into liability and equity components, and are accounted for as a single liability measured at its amortized cost. Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information.

[0000926326-22-000014:notes:119]
As of March 31, 2022, the remaining life of the Notes and the related issuance cost accretion is approximately 3.5 years.

[0000926326-22-000014:notes:120]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to other conversion rate adjustments, would be 5.9 million shares. As of March 31, 2022, the if-converted value of the Notes exceeded the principal amount by $190.1 million.

[0000926326-22-000014:notes:121]
The Notes consisted of the following balances reported in the Condensed Consolidated Balance Sheets as of March 31, 2022 and December 31, 2021:

[0000926326-22-000014:notes:122]
|  | March 31,2022 (2) |  | December 31,2021 |
|  | (In thousands) |
| Liability: |  |  |  |
| Principal amount | $ | 575,000 |  |  | $ | 575,000 |  |
| Unamortized discount | — |  |  | (77,136) |  |
| Unamortized debt issuance costs | (10,731) |  |  | (9,712) |  |
| Convertible senior notes, liability component (1) | $ | 564,269 |  |  | $ | 488,152 |  |
| Convertible senior notes, equity component | $ | — |  |  | $ | 72,732 |  |

[0000926326-22-000014:notes:123]
(1)    Classified as a current liability as of both March 31, 2022 and December 31, 2021 in the Condensed Consolidated Balance Sheets.

[0000926326-22-000014:notes:124]
(2)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.

[0000926326-22-000014:notes:125]
The following table summarizes the components of interest expense resulting from the Notes recognized in interest and other income (expense), net in the Condensed Consolidated Statements of Operations for the three months ended March 31, 2022 and 2021:

[0000926326-22-000014:notes:126]
|  | Three Months Ended March 31, |  |  |
|  | 2022 (1) |  | 2021 |  |  |  |  |
|  | (In thousands) |
| Contractual coupon interest | $ | 359 |  |  | $ | 359 |  |  |  |  |  |
| Amortization of discount | $ | — |  |  | $ | 4,571 |  |  |  |  |  |
| Amortization of debt issuance costs | $ | 764 |  |  | $ | 575 |  |  |  |  |  |

[0000926326-22-000014:notes:127]
(1)    Refer to Note 1, Organization and Summary of Significant Accounting Policies, for further information regarding the impact of the adoption of ASU 2020-06, effective January 1, 2022.

[0000926326-22-000014:notes:128]
Convertible Note Hedge and Warrant Transactions

[0000926326-22-000014:notes:129]
In connection with the issuance of the Notes, the Company entered into convertible note hedge and warrant transactions with an affiliate of one of the initial purchasers of the Notes and certain other financial institutions (the “option counterparties”) with respect to the Company’s common stock.

[0000926326-22-000014:notes:130]
The convertible note hedge consists of an option for the Company to purchase up to approximately 5.9 million shares of the Company’s common stock, which is equal to the number of shares of the Company’s common stock underlying the Notes, at an initial strike price of approximately $97.32 per share. The convertible note hedge will expire upon the maturity of

[0000926326-22-000014:notes:131]
the Notes, if not earlier exercised or terminated. The cost of the convertible note hedge was approximately $100.6 million and was accounted for as an equity instrument, which was recorded in additional paid-in capital in the Condensed Consolidated Balance Sheets. The Company recorded a deferred tax asset of $25.8 million at issuance related to the convertible note hedge transaction. The convertible note hedge is expected generally to reduce the potential dilution to the Company’s common stock upon any conversion of Notes and/or offset any cash payments the Company is required to make in excess of the principal amount of converted Notes.

[0000926326-22-000014:notes:132]
Separately from the convertible note hedge, the Company entered into warrant transactions to sell to the option counterparties warrants to acquire, subject to customary anti-dilution adjustments, up to approximately 5.9 million shares of its common stock in the aggregate at an initial strike price of $141.56 per share. The warrants require net share or net cash settlement upon the Company’s election. The Company received aggregate proceeds of approximately $51.3 million for the issuance of the warrants, which was recorded in additional paid-in capital at issuance in the Condensed Consolidated Balance Sheets. The warrants could separately have a dilutive effect to the Company’s common stock to the extent that the market price per share of its common stock exceeds the strike price of the warrants.


## us-gaap:DebtPolicyTextBlock

[0000926326-22-000014:notes:133]
Prior to the adoption of ASU 2020-06, convertible debt instruments that could be settled in cash were required to be separated into liability and equity components. The allocation to the liability component was based on the fair value of a similar instrument that did not contain an equity conversion option. Based on this debt-to-equity ratio, debt issuance costs were then allocated to the liability and equity components in a similar manner.Upon adoption of ASU 2020-06, effective January 1, 2022, the Notes are no longer separated into liability and equity components, and are accounted for as a single liability measured at its amortized cost.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000926326-22-000014:notes:134]
[same as prior period, unchanged from 0000926326-21-000034:notes:138]

[0000926326-22-000014:notes:135]
On a recurring basis, the Company enters into multi-year, sales-type lease agreements, with the majority varying in length from one to five years. The Company optimizes cash flows by selling a majority of its non-U.S. government sales-type leases to third-party leasing finance companies on a non-recourse basis. The Company has no obligation to the leasing company once the lease has been sold. Some of the Company’s sales-type leases, mostly those relating to U.S. government hospitals which comprise approximately 62% of the lease receivable balance, are retained in-house.

[0000926326-22-000014:notes:136]
The following table presents the Company’s income recognized from sales-type leases for the three months ended March 31, 2022 and 2021:

[0000926326-22-000014:notes:137]
|  | Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In thousands) |
| Sales-type lease revenues | $ | 6,505 |  |  | $ | 5,963 |  |  |  |  |  |
| Cost of sales-type lease revenues | (3,078) |  |  | (2,366) |  |  |  |  |  |
| Selling profit on sales-type lease revenues | $ | 3,427 |  |  | $ | 3,597 |  |  |  |  |  |

[0000926326-22-000014:notes:138]
The receivables as a result of these types of transactions are collateralized by the underlying equipment leased and consist of the following components at March 31, 2022 and December 31, 2021:

[0000926326-22-000014:notes:139]
|  | March 31,2022 |  | December 31,2021 |
|  | (In thousands) |
| Net minimum lease payments to be received | $ | 32,690 |  |  | $ | 31,444 |  |
| Less: Unearned interest income portion | (2,536) |  |  | (2,388) |  |
| Net investment in sales-type leases | 30,154 |  |  | 29,056 |  |
| Less: Current portion (1) | (11,103) |  |  | (10,665) |  |
| Long-term investment in sales-type leases, net | $ | 19,051 |  |  | $ | 18,391 |  |

[0000926326-22-000014:notes:140]
[same as prior period, unchanged from 0000926326-21-000034:notes:144]

[0000926326-22-000014:notes:141]
[same as prior period, unchanged from 0000926326-21-000034:notes:145]

[0000926326-22-000014:notes:142]
[same as prior period, unchanged from 0000926326-21-000034:notes:146]

[0000926326-22-000014:notes:143]
|  | March 31,2022 |
|  | (In thousands) |
| Remaining nine months of 2022 | $ | 9,024 |  |
| 2023 | 9,301 |  |
| 2024 | 6,300 |  |
| 2025 | 4,365 |  |
| 2026 | 1,972 |  |
| Thereafter | 1,728 |  |
| Total future minimum sales-type lease payments | 32,690 |  |
| Present value adjustment | (2,536) |  |
| Total net investment in sales-type leases | $ | 30,154 |  |

[0000926326-22-000014:notes:144]
[same as prior period, unchanged from 0000926326-21-000034:notes:148]

[0000926326-22-000014:notes:145]
The Company entered into certain leasing agreements that were classified as operating leases prior to the adoption of ASC 842, Leases. These agreements in place prior to January 1, 2019 continue to be treated as operating leases; however, any leasing agreements entered into on or after January 1, 2019 under these programs are classified and accounted for as sales-type leases in accordance with ASC 842. The operating lease arrangements generally have initial terms of one to seven years.

[0000926326-22-000014:notes:146]
The following table represents the Company’s income recognized from operating leases for the three months ended March 31, 2022 and 2021:

[0000926326-22-000014:notes:147]
|  | Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In thousands) |
| Rental income | $ | 2,472 |  |  | $ | 2,611 |  |  |  |  |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000926326-22-000014:notes:148]
Lessee Leases 
The Company has operating leases for office buildings, data centers, office equipment, and vehicles. The Company’s leases have initial terms of one to 12 years. As of March 31, 2022, the Company did not have any additional material operating leases that were entered into, but not yet commenced.

[0000926326-22-000014:notes:149]
The maturity schedule of future minimum lease payments under operating leases and the reconciliation to the operating lease liabilities reported on the Condensed Consolidated Balance Sheets was as follows:

[0000926326-22-000014:notes:150]
|  | March 31,2022 |
|  | (In thousands) |
| Remaining nine months of 2022 | $ | 11,244 |  |
| 2023 | 11,459 |  |
| 2024 | 9,859 |  |
| 2025 | 6,909 |  |
| 2026 | 6,457 |  |
| Thereafter | 10,882 |  |
| Total operating lease payments | 56,810 |  |
| Present value adjustment | (7,728) |  |
| Total operating lease liabilities (1) | $ | 49,082 |  |

[0000926326-22-000014:notes:151]
(1)    Amount consists of a current and long-term portion of operating lease liabilities of $11.8 million and $37.3 million, respectively. The current portion of the operating lease liabilities is included in accrued liabilities in the Condensed Consolidated Balance Sheets.

[0000926326-22-000014:notes:152]
Operating lease costs were $4.1 million and $3.7 million for the three months ended March 31, 2022 and 2021, respectively. Short-term lease costs and variable lease costs were immaterial for the three months ended March 31, 2022 and 2021. During the three months ended March 31, 2022, the Company recorded an impairment of operating lease right-of-use assets of $1.8 million in connection with restructuring activities for optimization of certain leased facilities. The impairment charge was recorded to selling, general, and administrative expenses on the Company’s Condensed Consolidated Statements of Operations.

[0000926326-22-000014:notes:153]
The following table summarizes supplemental cash flow information related to the Company’s operating leases for the three months ended March 31, 2022 and 2021:

[0000926326-22-000014:notes:154]
|  | Three Months Ended March 31, |
|  | 2022 |  | 2021 |
|  | (In thousands) |
| Cash paid for amounts included in the measurement of lease liabilities | $ | 4,193 |  |  | $ | 3,972 |  |
| Right-of-use assets obtained in exchange for new lease liabilities | $ | 497 |  |  | $ | 541 |  |

[0000926326-22-000014:notes:155]
The following table summarizes the weighted-average remaining lease term and weighted-average discount rate related to the Company’s operating leases as of March 31, 2022 and December 31, 2021:

[0000926326-22-000014:notes:156]
|  | March 31,2022 |  | December 31,2021 |
| Weighted-average remaining lease term, years | 5.2 |  | 5.2 |
| Weighted-average discount rate, % | 5.6 | % |  | 5.5 | % |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000926326-22-000014:notes:157]
Commitments and Contingencies
Purchase Obligations

[0000926326-22-000014:notes:158]
In the ordinary course of business, the Company issues purchase orders based on its current manufacturing needs. As of March 31, 2022, the Company had non-cancelable purchase commitments of $227.1 million, of which $194.5 million are expected to be paid within the year ending December 31, 2022.

[0000926326-22-000014:notes:159]
Legal Proceedings

[0000926326-22-000014:notes:160]
The Company is currently involved in various legal proceedings.

[0000926326-22-000014:notes:161]
A class action lawsuit was filed against the Company, on June 5, 2019, in the Circuit Court of Cook County, Illinois, Chancery Division, captioned Corey Heard, individually and on behalf of all others similarly situated v. Omnicell, Inc., Case No. 2019-CH-06817 (the “Heard Action”). The complaint seeks class certification, monetary damages in the form of statutory damages for willful and/or reckless or, in the alternative, negligent violation of the Illinois Biometric Information Privacy Act (“BIPA”), and certain declaratory, injunctive, and other relief based on causes of action directed to allegations of violation of BIPA by the Company. The complaint was served on the Company on June 13, 2019. On July 31, 2019, the Company filed a motion to stay or consolidate the case with the action Yana Mazya, et al. v. Northwestern Lake Forest Hospital, et al., Case No. 2018-CH-07161, pending in the Circuit Court of Cook County, Illinois, Chancery Division (the “Mazya Action”). The Court subsequently, on October 10, 2019, denied the motion, without prejudice, as being moot in view of the dismissal of the claims against the Company in the Mazya Action. The Company filed a motion to dismiss the complaint in the Heard Action on October 31, 2019. The hearing on the Company’s motion to dismiss was held on September 2, 2020. The Court ruled from the bench and dismissed the complaint without prejudice giving plaintiff leave to file an amended complaint by September 30, 2020. Plaintiff filed an amended complaint on September 30, 2020 and the Company subsequently filed a motion to dismiss the amended complaint on October 28, 2020, which was fully briefed, but the Court had not heard oral argument on the motion. The parties entered into a settlement agreement on January 25, 2022. On February 1, 2022, the Court granted preliminary approval of the settlement. The Court has scheduled a status conference for June 1, 2022. Subject to final approval of the settlement, the Company intends to defend the lawsuit vigorously.

[0000926326-22-000014:notes:162]
On December 21, 2020, Becton, Dickinson and Company (“BD”) filed a complaint against the Company in the United States District Court for the Middle District of North Carolina, asserting claims of misappropriation under the Defend Trade Secrets Act, misappropriation under the North Carolina Trade Secrets Protection Act, unfair competition, and unfair/deceptive trade practices in violation of North Carolina law (the “BD Complaint”). This action (the “BD Action”) was commenced in relation to another action brought by BD, in the same Court (the “Related Matter”) against a former BD employee who is also a former Company employee (the “Former Employee”) alleging that the Former Employee had violated the Former Employee’s legal obligations to BD regarding BD’s confidential and trade secret information when the Former Employee allegedly

[0000926326-22-000014:notes:163]
downloaded certain documents from BD’s information technology system following the end of the Former Employee’s employment with BD. In connection with the Related Matter, BD, the Former Employee, and the Company entered into a protocol with the purpose of facilitating the return to BD of any BD documents that may have been resident, as a result of the Former Employee’s actions, on any devices belonging to the Former Employee or the Company. The BD Complaint seeks injunctive relief and monetary damages in the form of compensatory, punitive, and exemplary damages, attorneys’ fees and costs, and pre-judgment and post-judgment interest. On March 8, 2022, the parties entered into a confidential settlement agreement. Omnicell is currently in the process of effectuating certain obligations under the agreement prior to dismissal of the BD Complaint.

[0000926326-22-000014:notes:164]
As required under ASC 450, Contingencies, the Company accrues for contingencies when it believes that a loss is probable and that it can reasonably estimate the amount of any such loss. The Company has not recorded any material accrual for contingent liabilities associated with the legal proceedings described above based on its belief that any potential material loss, while reasonably possible, is not probable. Further, any possible range of loss in these matters cannot be reasonably estimated at this time or is not deemed material. The Company believes that it has valid defenses with respect to these legal proceedings pending against it. However, litigation is inherently unpredictable, and it is possible that cash flows or results of operations could be materially affected in any particular period by the unfavorable resolution of any of these legal proceedings or because of the diversion of management’s attention and the creation of significant expenses.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000926326-22-000014:notes:165]
Income Taxes 
The Company generally provides for income taxes in interim periods based on the estimated annual effective tax rate for the year, adjusting for discrete items in the quarter in which they arise. The annual effective tax rate before discrete items was 26.4% and 26.7% for the three months ended March 31, 2022 and 2021, respectively.

[0000926326-22-000014:notes:166]
The Company has executed various global operational centralization activities and legal entity rationalization in recent years. The Company did not recognize any gains or losses from such activities during the three months ended March 31, 2022 and 2021. The Company recognized a discrete tax benefit related to equity compensation in the amount of $4.4 million and $4.1 million for the three months ended March 31, 2022 and 2021, respectively.

[0000926326-22-000014:notes:167]
The 2022 annual effective tax rate before discrete items differed from the statutory rate of 21% primarily due to the unfavorable impact of state income taxes, non-deductible compensation and equity charges, and Global Intangible Low-Taxed Income tax inclusion, partially offset by the favorable impact of research and development credits and a foreign derived intangible income (“FDII”) benefit deduction. The 2021 annual effective tax rate before discrete items differed from the statutory rate of 21% primarily due to the unfavorable impact of state income taxes, non-deductible compensation and equity charges, and non-deductible expenses, partially offset by the favorable impact of research and development credits and a FDII benefit deduction.

[0000926326-22-000014:notes:168]
On March 11, 2021, the President of the United States signed into law the “American Rescue Plan Act of 2021” (the “ARP Act”), which provides additional economic stimulus and tax credits, including the expansion and modification of the employee retention tax credit enacted by the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) and the refundable tax credits for COVID-related paid sick and family leave enacted by the Family First Act. The ARP Act further expands the “covered employees” definition for purposes of Section 162(m) of the Internal Revenue Code of 1986, as amended, used in determining the limitation on the deduction for excessive employee remuneration rules to be applicable for taxable years beginning after December 31, 2026. The provisions of the ARP Act did not have a material impact on the Company’s income taxes.

[0000926326-22-000014:notes:169]
As of March 31, 2022 and December 31, 2021, the Company had gross unrecognized tax benefits of $9.3 million and $9.0 million, respectively. It is the Company’s policy to classify accrued interest and penalties as part of unrecognized tax benefits, but to record interest and penalties in interest and other income (expense), net in the Condensed Consolidated Statements of Operations. As of both March 31, 2022 and December 31, 2021, the amount of accrued interest and penalties was $0.6 million.

[0000926326-22-000014:notes:170]
The Company files income tax returns in the United States and various state and foreign jurisdictions. In the normal course of business, the Company is subject to examinations by taxing authorities, including major jurisdictions such as the United States, Germany, Italy, Netherlands, and the United Kingdom. With few exceptions, as of March 31, 2022, the Company was no longer subject to U.S., state, and foreign tax examinations for years before 2018, 2017, and 2017, respectively.

[0000926326-22-000014:notes:171]
[same as prior period, unchanged from 0000926326-21-000034:notes:175]


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000926326-22-000014:notes:172]
[same as prior period, unchanged from 0000926326-21-000034:notes:176]

[0000926326-22-000014:notes:173]
For a detailed explanation of the Company’s stock plans, refer to Note 14, Employee Benefits and Share-Based Compensation, of the audited Consolidated Financial Statements and accompanying Notes included in the Company’s Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022.

[0000926326-22-000014:notes:174]
[same as prior period, unchanged from 0000926326-21-000034:notes:178]

[0000926326-22-000014:notes:175]
The following table sets forth the total share-based compensation expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three months ended March 31, 2022 and 2021:

[0000926326-22-000014:notes:176]
|  | Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
|  | (In thousands) |
| Cost of product and service revenues | $ | 2,244 |  |  | $ | 1,937 |  |  |  |  |  |
| Research and development | 2,264 |  |  | 1,700 |  |  |  |  |  |
| Selling, general, and administrative | 11,700 |  |  | 8,135 |  |  |  |  |  |
| Total share-based compensation expense | $ | 16,208 |  |  | $ | 11,772 |  |  |  |  |  |

[0000926326-22-000014:notes:177]
[same as prior period, unchanged from 0000926326-21-000034:notes:181]

[0000926326-22-000014:notes:178]
The following assumptions were used to value shares under the ESPP for the three months ended March 31, 2022 and 2021:

[0000926326-22-000014:notes:179]
|  | Three Months Ended March 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Expected life, years | 0.5 - 2.0 |  | 0.5 - 2.0 |  |  |  |  |
| Expected volatility, % | 28.8% - 45.6% |  | 27.4% - 53.5% |  |  |  |  |
| Risk-free interest rate, % | 0.1% - 1.5% |  | 0.1% - 2.6% |  |  |  |  |
| Dividend yield, % | — | % |  | — | % |  |  |  |  |

[0000926326-22-000014:notes:180]
For the three months ended March 31, 2022 and 2021, employees purchased approximately 175,000 and 156,000 shares of common stock, respectively, under the ESPP at a weighted-average price of $66.81 and $59.75, respectively. As of March 31, 2022, the unrecognized compensation cost related to the shares to be purchased under the ESPP was approximately $3.6 million and is expected to be recognized over a weighted-average period of 1.4 years.

[0000926326-22-000014:notes:181]
[same as prior period, unchanged from 0000926326-21-000034:notes:185]

[0000926326-22-000014:notes:182]
The following assumptions were used to value stock options granted pursuant to the Company’s 2009 Equity Incentive Plan, as amended, (the “2009 Plan”) for the three months ended March 31, 2021. There were no stock options granted during the three months ended March 31, 2022.

[0000926326-22-000014:notes:183]
|  |  |  | Three Months Ended March 31, |  |  |
|  |  |  | 2021 |  |  |  |  |
| Expected life, years |  |  | 4.9 |  |  |  |  |
| Expected volatility, % |  |  | 30.1 | % |  |  |  |  |
| Risk-free interest rate, % |  |  | 0.6 | % |  |  |  |  |
| Estimated forfeiture rate, % |  |  | 7.9 | % |  |  |  |  |
| Dividend yield, % |  |  | — | % |  |  |  |  |

[0000926326-22-000014:notes:184]
The following table summarizes the stock option activity during the three months ended March 31, 2022:

[0000926326-22-000014:notes:185]
|  | Number ofShares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2021 | 2,954 |  |  | $ | 67.35 |  |  | 6.9 |  | $ | 334,119 |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (141) |  |  | 51.47 |  |  |  |  |  |
| Expired | (1) |  |  | 68.74 |  |  |  |  |  |
| Forfeited | (33) |  |  | 80.32 |  |  |  |  |  |
| Outstanding at March 31, 2022 | 2,779 |  |  | $ | 68.00 |  |  | 6.8 |  | $ | 171,505 |  |
| Exercisable at March 31, 2022 | 1,699 |  |  | $ | 58.65 |  |  | 6.0 |  | $ | 120,394 |  |
| Vested and expected to vest at March 31, 2022 and thereafter | 2,683 |  |  | $ | 67.36 |  |  | 6.7 |  | $ | 167,177 |  |

[0000926326-22-000014:notes:186]
The weighted-average fair value per share of options granted during the three months ended March 31, 2021 was $33.89. The intrinsic value of options exercised during the three months ended March 31, 2022 and 2021 was $12.7 million and $14.0 million, respectively.

[0000926326-22-000014:notes:187]
As of March 31, 2022, total unrecognized compensation cost related to unvested stock options was $28.4 million, which is expected to be recognized over a weighted-average vesting period of 2.0 years.

[0000926326-22-000014:notes:188]
[same as prior period, unchanged from 0000926326-21-000034:notes:192]

[0000926326-22-000014:notes:189]
The following table summarizes the RSU activity under the 2009 Plan during the three months ended March 31, 2022:

[0000926326-22-000014:notes:190]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |  | Weighted-AverageRemaining Years |  | AggregateIntrinsic Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2021 | 763 |  |  | $ | 119.93 |  |  | 1.6 |  | $ | 137,696 |  |
| Granted (Awarded) | 150 |  |  | 147.90 |  |  |  |  |  |
| Vested (Released) | (43) |  |  | 84.74 |  |  |  |  |  |
| Forfeited | (26) |  |  | 119.49 |  |  |  |  |  |
| Outstanding and unvested at March 31, 2022 | 844 |  |  | $ | 126.70 |  |  | 1.6 |  | $ | 109,317 |  |

[0000926326-22-000014:notes:191]
As of March 31, 2022, total unrecognized compensation cost related to RSUs was $85.5 million, which is expected to be recognized over the remaining weighted-average vesting period of 3.0 years.

[0000926326-22-000014:notes:192]
[same as prior period, unchanged from 0000926326-21-000034:notes:196]

[0000926326-22-000014:notes:193]
The following table summarizes the RSA activity under the 2009 Plan during the three months ended March 31, 2022:

[0000926326-22-000014:notes:194]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2021 | 11 |  |  | $ | 137.36 |  |
| Granted (Awarded) | — |  |  | — |  |
| Vested (Released) | — |  |  | — |  |
| Outstanding and unvested at March 31, 2022 | 11 |  |  | $ | 137.36 |  |

[0000926326-22-000014:notes:195]
As of March 31, 2022, total unrecognized compensation cost related to RSAs was $0.2 million, which is expected to be recognized over the remaining weighted-average vesting period of 0.2 years.

[0000926326-22-000014:notes:196]
Performance-Based Stock Unit Awards (“PSUs”)

[0000926326-22-000014:notes:197]
The following table summarizes the PSU activity under the 2009 Plan during the three months ended March 31, 2022:

[0000926326-22-000014:notes:198]
|  | Number ofShares |  | Weighted-AverageGrant Date Fair Value Per Unit |
|  | (In thousands, except per share data) |
| Outstanding at December 31, 2021 | 144 |  |  | $ | 118.71 |  |
| Granted | 75 |  |  | 156.82 |  |
| Additional granted based on performance achievement | 51 |  |  | 156.79 |  |
| Vested | (57) |  |  | 119.09 |  |
| Forfeited | (1) |  |  | 178.81 |  |
| Outstanding and unvested at March 31, 2022 | 212 |  |  | $ | 141.05 |  |

[0000926326-22-000014:notes:199]
As of March 31, 2022, total unrecognized compensation cost related to PSUs was approximately $13.7 million, which is expected to be recognized over the remaining weighted-average vesting period of 1.5 years.

[0000926326-22-000014:notes:200]
[same as prior period, unchanged from 0000926326-21-000034:notes:204]

[0000926326-22-000014:notes:201]
The Company had the following ordinary shares reserved for future issuance under its equity incentive plans as of March 31, 2022:

[0000926326-22-000014:notes:202]
|  | Number of Shares |
|  | (In thousands) |
| Share options outstanding | 2,779 |  |
| Non-vested restricted stock awards | 1,067 |  |
| Shares authorized for future issuance | 1,154 |  |
| ESPP shares available for future issuance | 744 |  |
| Total shares reserved for future issuance | 5,744 |  |

[0000926326-22-000014:notes:203]
Stock Repurchase Programs

[0000926326-22-000014:notes:204]
On August 2, 2016, the Company’s Board of Directors (the “Board”) authorized a stock repurchase program providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2016 Repurchase Program”). The 2016 Repurchase Program is in addition to the stock repurchase program approved by the Board on November 4, 2014 providing for the repurchase of up to $50.0 million of the Company’s common stock (the “2014 Repurchase Program”). As of March 31, 2022, the 2014 Repurchase Program was completed, and the maximum dollar value of shares that may yet be purchased under the 2016 Repurchase Program was $2.7 million. The 2016 Repurchase Program does not obligate the Company to repurchase any specific number of shares, and the Company may terminate or suspend the 2016 Repurchase Program at any time.
During the three months ended March 31, 2022, the Company repurchased approximately 389,300 shares of its common stock under the repurchase programs at an average price of $134.11 per share for an aggregate purchase price of approximately $52.2 million. During the three months ended March 31, 2021, the Company did not repurchase any of its outstanding common stock under the r


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000926326-22-000014:notes:205]
Restructuring Expenses
During 2020, the Company announced a company-wide organizational realignment initiative in order to more effectively align its organizational infrastructure and operations with the industry vision of the Autonomous Pharmacy. In the first quarter of 2021, the Company continued its organizational realignment initiative, incurring $2.0 million of employee severance costs and related expenses.

[0000926326-22-000014:notes:206]
During the first quarter of 2022, the Company initiated certain domestic and international restructuring initiatives, in order to enhance and streamline certain engineering functions for its domestic operations, and to realign its international sales organization to better serve its customers in various international markets. During the three months ended March 31, 2022, the restructuring plans incurred $3.5 million of employee severance costs and related expenses. As of March 31, 2022 the unpaid balance related to these restructuring plans was $1.8 million.

[0000926326-22-000014:notes:207]
The following table summarizes the total restructuring expense recognized in the Company’s Condensed Consolidated Statements of Operations for the three months ended March 31, 2022 and 2021:

[0000926326-22-000014:notes:208]
|  |  |  | Three Months Ended March 31, |
|  |  |  |  |  | 2022 |  | 2021 |
|  |  |  |  |  | (In thousands) |
| Cost of product and service revenues |  |  |  |  | $ | 156 |  |  | $ | 389 |  |
| Research and development |  |  |  |  | 1,594 |  |  | 105 |  |
| Selling, general, and administrative |  |  |  |  | 1,777 |  |  | 1,526 |  |
| Total restructuring expense |  |  |  |  | $ | 3,527 |  |  | $ | 2,020 |  |


## us-gaap:SubsequentEventsTextBlock

[0000926326-22-000014:notes:209]
Subsequent EventsOn May 4, 2022, the Company determined that certain of its information technology systems were affected by ransomware impacting certain internal systems. There is an impact on certain of the Company’s products and services, as well as certain of its internal systems. Upon detecting the security event, the Company took immediate steps designed to contain the incident and implement its business continuity plans to restore and support continued operations. The Company has notified appropriate law enforcement authorities. The Company is also working closely with cybersecurity experts and legal counsel. The Company is in the early stages of its investigation and assessment of the security event and cannot determine, at this time, the extent of the impact from such event on our business, results of operations or financial condition or whether such impact will have a material adverse effect.
