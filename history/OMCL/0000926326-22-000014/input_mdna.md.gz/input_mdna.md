# OMCL MD&A — 0000926326-22-000014


## mdna

[0000926326-22-000014:mdna:1]
[same as prior period, unchanged from 0000926326-21-000034:mdna:1]

[0000926326-22-000014:mdna:2]
[same as prior period, unchanged from 0000926326-21-000034:mdna:2]

[0000926326-22-000014:mdna:3]
[same as prior period, unchanged from 0000926326-21-000034:mdna:3]

[0000926326-22-000014:mdna:4]
[same as prior period, unchanged from 0000926326-21-000034:mdna:4]

[0000926326-22-000014:mdna:5]
[same as prior period, unchanged from 0000926326-21-000034:mdna:5]

[0000926326-22-000014:mdna:6]
[same as prior period, unchanged from 0000926326-21-000034:mdna:6]

[0000926326-22-000014:mdna:7]
[same as prior period, unchanged from 0000926326-21-000034:mdna:7]

[0000926326-22-000014:mdna:8]
•our expectation to continue to acquire companies, businesses, products, or technologies;

[0000926326-22-000014:mdna:9]
•our goal of advancing our platform with new product introductions;

[0000926326-22-000014:mdna:10]
•our goal to deliver on the industry vision of the Autonomous Pharmacy, as well as our plan to integrate our current offerings and technologies on a cloud infrastructure and invest in broadening our solutions across certain key areas as we execute on this vision;

[0000926326-22-000014:mdna:11]
•continued investment in the industry vision of the Autonomous Pharmacy, our beliefs about the anticipated benefits of such investments, and our expectations regarding continued growth in current and future subscription and cloud-based offerings as we execute on this vision;

[0000926326-22-000014:mdna:12]
[same as prior period, unchanged from 0000926326-21-000034:mdna:12]

[0000926326-22-000014:mdna:13]
•opportunities presented by new products, services, and markets;

[0000926326-22-000014:mdna:14]
[same as prior period, unchanged from 0000926326-21-000034:mdna:14]

[0000926326-22-000014:mdna:15]
[same as prior period, unchanged from 0000926326-21-000034:mdna:16]

[0000926326-22-000014:mdna:16]
[same as prior period, unchanged from 0000926326-21-000034:mdna:18]

[0000926326-22-000014:mdna:17]
[same as prior period, unchanged from 0000926326-21-000034:mdna:19]

[0000926326-22-000014:mdna:18]
•our expected future uses of cash, including our expected uses for the remaining proceeds of our convertible senior notes, and the sufficiency of our sources of funding; and

[0000926326-22-000014:mdna:19]
[same as prior period, unchanged from 0000926326-21-000034:mdna:23]

[0000926326-22-000014:mdna:20]
In some cases, you can identify forward-looking statements by terms such as “anticipates,” “believes,” “could,” “estimates,” “expects,” “intends,” “seeks,” “may,” “plans,” “potential,” “predicts,” “projects,” “should,” “will,” “would,” and variations of these terms and similar expressions. Forward-looking statements are based on our current expectations and assumptions, and are subject to known and unknown risks and uncertainties, many of which are beyond our control, which may cause our actual results, performance, or achievements to be materially different from those expressed or implied in the forward-looking statements.

[0000926326-22-000014:mdna:21]
Other Information

[0000926326-22-000014:mdna:22]
All references in this Quarterly Report on Form 10-Q to “Omnicell,” “our,” “us,” “we,” or “the Company” refer to Omnicell, Inc., a Delaware corporation, and its subsidiaries, collectively. The term “Omnicell, Inc.” refers only to Omnicell, Inc., excluding its subsidiaries.

[0000926326-22-000014:mdna:23]
We own various registered and unregistered trademarks and service marks used in our business, some of which appear in this Quarterly Report, including Omnicell®. This Quarterly Report may also include the trademarks and service marks of other companies. Such trademarks and service marks are the marks of their respective owners.

[0000926326-22-000014:mdna:24]
[same as prior period, unchanged from 0000926326-21-000034:mdna:27]

[0000926326-22-000014:mdna:25]
[same as prior period, unchanged from 0000926326-21-000034:mdna:28]

[0000926326-22-000014:mdna:26]
Omnicell, a leader in transforming the pharmacy care delivery model, is committed to elevating the role of pharmacy within healthcare and transforming medication management as an essential component of the pharmacy care delivery model. We are doing so with an industry-leading comprehensive intelligent infrastructure, bringing together technology, analytics, and expert services to equip and empower pharmacists and pharmacies to focus on clinical care rather than administrative tasks. We believe this intelligent infrastructure provides the critical foundation for realizing the industry vision of the Autonomous Pharmacy, a vision defined by pharmacy leaders for improving operational efficiencies and ultimately targeting zero-error medication management.

[0000926326-22-000014:mdna:27]
Facilities worldwide use our automation and analytics solutions to increase operational efficiency, reduce medication errors, deliver actionable intelligence, and improve patient safety. Institutional and retail pharmacies across North America, the

[0000926326-22-000014:mdna:28]
United Kingdom, Germany, and Australia leverage our innovative medication adherence and population health solutions to improve patient engagement and adherence to prescriptions, helping to reduce costly hospital readmissions. We sell our product and consumable solutions together with related service offerings. Revenues generated in the United States represented 90% and 89% of our total revenues for the three months ended March 31, 2022 and 2021, respectively.

[0000926326-22-000014:mdna:29]
Over the past several years, our business has expanded from a single-point solution to a platform of products and services that will help to further advance the industry vision of the Autonomous Pharmacy. This expansion has resulted in larger deal sizes across multiple products, services, and implementations for customers and, we believe, more comprehensive, valuable, and enduring relationships.

[0000926326-22-000014:mdna:30]
We utilize product bookings as an indicator of the success of our business. Product bookings generally consist of all firm orders other than for technical services and other less significant items, as evidenced generally by a non-cancelable contract and purchase order for equipment, software products, and Advanced Services, and by a purchase order or through our Omnicell Storefront online ordering platform for consumables. A majority of our connected devices and software license product bookings are installable within twelve months of booking, and are recorded as revenue upon customer acceptance of the installation or receipt of goods. Revenues from software-as-a-service (“SaaS”), subscription software, and technology-enabled services product bookings are recorded over the contractual term.

[0000926326-22-000014:mdna:31]
In addition to product solution sales, we provide a range of services to our customers. We provide installation planning and consulting as part of most product sales which is generally included in the initial price of the solution. We also provide Advanced Services such as Omnicell One, EnlivenHealth, 340B solutions, Central Pharmacy Dispensing Services, and Central Pharmacy Compounding Services. To help assure the maximum availability of our systems, our customers typically purchase maintenance and support contracts in increments of one to five years. As a result of the growth of our installed base of customers and expanded service offerings, our service revenues have also grown.

[0000926326-22-000014:mdna:32]
[same as prior period, unchanged from 0000926326-21-000034:mdna:35]

[0000926326-22-000014:mdna:33]
[same as prior period, unchanged from 0000926326-21-000034:mdna:36]

[0000926326-22-000014:mdna:34]
[same as prior period, unchanged from 0000926326-21-000034:mdna:37]

[0000926326-22-000014:mdna:35]
[same as prior period, unchanged from 0000926326-21-000034:mdna:38]

[0000926326-22-000014:mdna:36]
[same as prior period, unchanged from 0000926326-21-000034:mdna:39]

[0000926326-22-000014:mdna:37]
Our full-time employee headcount was approximately 3,890 and 3,800 on March 31, 2022 and December 31, 2021, respectively.

[0000926326-22-000014:mdna:38]
[same as prior period, unchanged from 0000926326-21-000034:mdna:41]

[0000926326-22-000014:mdna:39]
We manage our operations as a single segment for the purposes of assessing performance and making operating decisions. Our Chief Operating Decision Maker (“CODM”) is our Chief Executive Officer. The CODM allocates resources and evaluates the performance of Omnicell at the consolidated level using information about our revenues, gross profit, income from operations, and other key financial data. All significant operating decisions are based upon an analysis of Omnicell as one operating segment, which is the same as our reporting segment.

[0000926326-22-000014:mdna:40]
Business Strategy

[0000926326-22-000014:mdna:41]
We are committed to being the care providers’ and retail pharmacies’ most trusted partner and executing on the industry vision of the Autonomous Pharmacy by developing and delivering an intelligent medication management infrastructure composed of devices, digital workflows, analytics, and experts, all powered by the cloud. We believe there are significant challenges facing the pharmacy practice today including, but not limited to, labor shortages, medication errors, drug shortages, medication loss due to drug diversion, significant medication waste and expiration costs, a high level of manual steps in the medication management process, complexity around compliance requirements, high pharmacy employee turnover rates affecting tenure and expertise, hospitalizations from adverse drug events in outpatient settings, high variability in outcomes, and

[0000926326-22-000014:mdna:42]
limited inventory visibility. We believe that these significant challenges to the pharmacy practice drive the demand for increased digitization, visibility, and insights that our solutions enable, and represent large opportunities in four market categories:

[0000926326-22-000014:mdna:43]
•Point of Care.  As a market leader, we expect to continue expansion of this product category as customers increase use of our dispensing systems in more areas within their hospitals. We are more than halfway through the replacement, upgrade, and expansion cycle of older models of automated dispensing systems with our XT Series automated dispensing systems within our own customer base, which we believe is a significant market opportunity. We have been successful penetrating markets through competitive conversions and expect this success to continue. We also believe there is an opportunity for us to define a new standard of care for dispensing systems in perioperative settings. We believe our current portfolio within the Point of Care market and new innovation and services will continue to drive improved outcomes and lower costs for our customers.

[0000926326-22-000014:mdna:44]
•Central Pharmacy.  This market represents the beginning of the medication management process in acute care settings, and, we believe, the next big automation opportunity to replace high volumes of manual and repetitive processes that are common in pharmacies today. Manual processes are prone to significant errors, and products such as IVX Workflow, our IV Sterile Compounding Service (including IV robotics), and our Central Pharmacy Dispensing Service (including the XR2 Automated Central Pharmacy System), automate these manual processes and are designed to reduce the risk of error for our healthcare partners. Because automation adoption in the Central Pharmacy is still nascent, we believe that the adoption of solutions will be accelerated by bundling those solutions with technology-enabled services that are designed to deliver specific outcomes and leverage intelligence across the enterprise for more actionable insights, and are expected to reduce administrative burden, allowing clinicians to operate at the top of their license. We think that these bundled solutions are becoming more critical than ever as health systems appear to face increasing labor shortages and supply chain disruption following the COVID-19 pandemic. Additionally, we believe new products, innovations and our expertise in the Central Pharmacy market create opportunities to replace prior generation Central Pharmacy robotics, especially when combining those robotics with carousels and technology-enabled services to increase the percentage of medication managed through the intelligent infrastructure.

[0000926326-22-000014:mdna:45]
•Specialty Pharmacy and 340B Program.  We believe that health systems will invest in more revenue generating activities that improve patient outcomes, and pharmacy will be at the center with specialty pharmacies and the 340B Drug Pricing Program.

[0000926326-22-000014:mdna:46]
Studies have shown that specialty medications represent over 50% of the country’s total spending on retail, mail-order, and provider-administered drugs. Used for treatment of complex conditions, these medications often require intensive patient management and specialized workflows for dispensing and care coordination. Specialty pharmacies serve as the connection between patients, prescribing physicians, and payors to ensure streamlined access and adherence to these specialty drugs, helping to maintain continuity of care throughout the process, and are expected to improve margin and profitability for the health system. The newly acquired ReCept Holdings, Inc. (“ReCept”) solution provides implementation and managed services for health systems and other provider organizations to optimize their specialty pharmacy programs and the related pharmaceutical aspects of patient care.

[0000926326-22-000014:mdna:47]
The 340B market is targeted to covered entities participating in Section 340B of the Public Health Services Act. The Public Health Services Act requires pharmaceutical manufacturers participating in Medicaid to sell outpatient drugs at discounted prices to healthcare organizations that care for many uninsured and low-income patients and creates a complex compliance environment. According to the Health Resources and Services Administration, which is responsible for administering the 340B program, enrolled hospitals and other covered entities can achieve an average savings of 25% to 50% in pharmaceutical purchases. Due to the complexities of adhering to the administrative process of the 340B program, we believe that there are significant opportunities for health systems to improve participation benefits and maximize program savings through our 340B technology-enabled services.

[0000926326-22-000014:mdna:48]
•Retail, Institutional, and Payer.  We believe the retail, institutional, and payer market represents a significant opportunity as healthcare evolves. A majority of all prescription drugs are distributed in the non-acute sector. The COVID-19 pandemic accelerated the shift of primary healthcare settings from hospitals and doctors’ offices to other convenient channels like the home, digital, and retail pharmacies. New technology and updated state board regulations are leading to innovation at traditional retail providers, which, combined with the move to value-based care, we believe will incentivize the market to adopt solutions to help providers and payers engage patients in new ways that improve patient care and reduce the total cost of care. We believe adoption of our EnlivenHealth portfolio of software products and services, along with medication adherence packaging, will increase adherence performance rates, increase prescription volume for our customers, and reduce hospital and emergency room visits

[0000926326-22-000014:mdna:49]
due to improved adherence. Our EnlivenHealth portfolio has been expanded with two recent acquisitions that will assist in adoption and drive innovation. RxInnovation Inc., operating as FDS Amplicare (“FDS Amplicare”), is a leading provider of financial management, analytics, and population health solutions to the retail pharmacy industry, including independent pharmacies. MarkeTouch Media, LLC (“MarkeTouch Media”) has longstanding pharmacy chain relationships that further broaden EnlivenHealth’s national pharmacy network.

[0000926326-22-000014:mdna:50]
We believe our technology, services, and solutions within these market categories position us well to address the needs of acute, post-acute, ambulatory, and retail pharmacy providers and health plans.

[0000926326-22-000014:mdna:51]
[same as prior period, unchanged from 0000926326-21-000034:mdna:57]

[0000926326-22-000014:mdna:52]
We continue to closely monitor the COVID-19 pandemic and ongoing impacts on the Company. At the outset of the COVID-19 pandemic, many health systems faced financial and operational pressures which we believe led our customers to delay or defer purchasing decisions and/or implementation of our solutions. However, our customers have generally returned to pre-pandemic purchasing patterns consistent with long-term strategic investments. We believe that the challenges that our customers have faced during the COVID-19 pandemic, including the need for robust visibility throughout their pharmacy supply chains, have increased the strategic relevance of our products and services.

[0000926326-22-000014:mdna:53]
COVID-19 vaccines are now available and being widely distributed. Despite this, there remains uncertainty regarding the duration and severity of the continuing impact of the pandemic, including the impact of new variants of the COVID-19 virus, on the U.S. and world economies, as well as on our business. We continue to carefully monitor this dynamic situation and may adjust our outlook as appropriate. The ongoing impact of the COVID-19 pandemic may adversely affect our business, results of operations, financial condition, and liquidity (including increased borrowing costs or other costs of capital). However, under current circumstances, we believe that our financial position and resources will allow us to manage the anticipated impact of the COVID-19 pandemic on our business for the foreseeable future.

[0000926326-22-000014:mdna:54]
[same as prior period, unchanged from 0000926326-21-000034:mdna:60]

[0000926326-22-000014:mdna:55]
On January 10, 2022, we completed the acquisition of Hub and Spoke Innovations, pursuant to the terms and conditions of the Share Purchase Agreement, dated January 10, 2022, by and among Omnicell Limited (a wholly-owned subsidiary of the Company), Hub and Spoke Innovations Limited, and certain beneficial stockholders specified therein for a base purchase price of £2.5 million (approximately $3.4 million based on the exchange rate in effect at the acquisition date), prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The Hub and Spoke Innovations acquisition is expected to complement Omnicell’s total solution technology portfolio for retail pharmacy in the United Kingdom to help pharmacies improve workflows, offer patients 24/7 access to their medications and provide enhanced patient care. The results of the operations of Hub and Spoke Innovations have been included in our consolidated results of operations beginning January 10, 2022.

[0000926326-22-000014:mdna:56]
On December 31, 2021, we completed the acquisition of MarkeTouch Media pursuant to the terms and conditions of the Unit Purchase Agreement, dated December 31, 2021, by and among ateb, Inc. (a wholly-owned subsidiary of the Company), MarkeTouch Media, LLC, MarkeTouch Holdings, Inc., Toucan Enterprises, Inc., and certain beneficial stockholders specified therein for a base purchase price of $82.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The MarkeTouch Media acquisition adds mobile and web-based technology and patient engagement solutions, which is expected to expand the footprint of EnlivenHealth across the retail pharmacy sector, while enhancing potential growth opportunities in new market segments like specialty pharmacy and pharmacy benefits management. The results of the operations of MarkeTouch Media have been included in our consolidated results of operations beginning December 31, 2021.

[0000926326-22-000014:mdna:57]
On December 29, 2021, we completed the acquisition of ReCept pursuant to the terms and conditions of the Agreement and Plan of Merger, dated December 1, 2021, by and among Omnicell, Inc., ReCept Holdings, Inc., Redfish Acquisition Corp, and the representative of the securityholders for a base purchase price of $100.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The addition of ReCept’s specialty pharmacy management services for health systems, provider groups, and federally qualified health centers expands Omnicell’s Advanced Services portfolio in an effort to address the growing and complex specialty pharmacy market. The results of the operations of ReCept have been included in our consolidated results of operations beginning December 29, 2021.

[0000926326-22-000014:mdna:58]
On September 9, 2021, we completed the acquisition of FDS Amplicare pursuant to the terms and conditions of the Agreement and Plan of Merger, dated July 25, 2021, by and among RxInnovation Inc., Omnicell, Inc., Fleming Acquisition Corp., and the representative of the securityholders for a base purchase price of $177.0 million, prior to customary adjustments for closing cash, net working capital, and assumed indebtedness. The FDS Amplicare acquisition adds a comprehensive and complementary suite of SaaS financial management, analytics, and population health solutions to our EnlivenHealth offering.

[0000926326-22-000014:mdna:59]
The results of the operations of FDS Amplicare have been included in our consolidated results of operations beginning September 9, 2021.

[0000926326-22-000014:mdna:60]
[same as prior period, unchanged from 0000926326-21-000034:mdna:63]

[0000926326-22-000014:mdna:61]
[same as prior period, unchanged from 0000926326-21-000034:mdna:64]

[0000926326-22-000014:mdna:62]
[same as prior period, unchanged from 0000926326-21-000034:mdna:65]

[0000926326-22-000014:mdna:63]
[same as prior period, unchanged from 0000926326-21-000034:mdna:66]

[0000926326-22-000014:mdna:64]
•Allowance for credit losses for accounts receivable and unbilled receivables;

[0000926326-22-000014:mdna:65]
[same as prior period, unchanged from 0000926326-21-000034:mdna:68]

[0000926326-22-000014:mdna:66]
[same as prior period, unchanged from 0000926326-21-000034:mdna:69]

[0000926326-22-000014:mdna:67]
[same as prior period, unchanged from 0000926326-21-000034:mdna:70]

[0000926326-22-000014:mdna:68]
[same as prior period, unchanged from 0000926326-21-000034:mdna:71]

[0000926326-22-000014:mdna:69]
[same as prior period, unchanged from 0000926326-21-000034:mdna:72]

[0000926326-22-000014:mdna:70]
[same as prior period, unchanged from 0000926326-21-000034:mdna:73]

[0000926326-22-000014:mdna:71]
[same as prior period, unchanged from 0000926326-21-000034:mdna:74]

[0000926326-22-000014:mdna:72]
[same as prior period, unchanged from 0000926326-21-000034:mdna:75]

[0000926326-22-000014:mdna:73]
There were no material changes in the matters for which we make critical accounting estimates in the preparation of our Condensed Consolidated Financial Statements during the three months ended March 31, 2022 as compared to those disclosed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the year ended December 31, 2021, except as discussed in “Recently Adopted Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q.

[0000926326-22-000014:mdna:74]
[same as prior period, unchanged from 0000926326-21-000034:mdna:77]

[0000926326-22-000014:mdna:75]
Refer to “Recently Issued Authoritative Guidance” in Note 1, Organization and Summary of Significant Accounting Policies, of the Notes to Condensed Consolidated Financial Statements in this Quarterly Report on Form 10-Q for a description of recently issued accounting pronouncements, including the expected dates of adoption and estimated effects on our results of operations, financial position, and cash flows.

[0000926326-22-000014:mdna:76]
34

[0000926326-22-000014:mdna:77]
[same as prior period, unchanged from 0000926326-21-000034:mdna:79]

[0000926326-22-000014:mdna:78]
[same as prior period, unchanged from 0000926326-21-000034:mdna:80]

[0000926326-22-000014:mdna:79]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Product revenues | $ | 225,875 |  |  | $ | 178,125 |  |  | $ | 47,750 |  |  | 27% |
| Percentage of total revenues | 71% |  | 71% |  |  |  |  |
| Services and other revenues | 92,953 |  |  | 73,718 |  |  | 19,235 |  |  | 26% |
| Percentage of total revenues | 29% |  | 29% |  |  |  |  |
| Total revenues | $ | 318,828 |  |  | $ | 251,843 |  |  | $ | 66,985 |  |  | 27% |

[0000926326-22-000014:mdna:80]
Product revenues represented 71% of total revenues for both the three months ended March 31, 2022 and 2021. Product revenues increased by $47.8 million, due to increased customer demand, primarily within our automated dispensing systems business.

[0000926326-22-000014:mdna:81]
Services and other revenues represented 29% of total revenues for both the three months ended March 31, 2022 and 2021. Services and other revenues include revenues from technical services; SaaS, subscription software, and technology-enabled services; and other services. Services and other revenues increased by $19.2 million, primarily due to revenues from our recent acquisitions of FDS Amplicare, ReCept, and MarkeTouch Media.

[0000926326-22-000014:mdna:82]
Our international sales represented 10% and 11% of total revenues for the three months ended March 31, 2022 and 2021, respectively, and are expected to be affected by foreign currency exchange rate fluctuations. We are unable to predict the extent to which revenues in future periods will be impacted by changes in foreign currency exchange rates.

[0000926326-22-000014:mdna:83]
[same as prior period, unchanged from 0000926326-21-000034:mdna:89]

[0000926326-22-000014:mdna:84]
[same as prior period, unchanged from 0000926326-21-000034:mdna:90]

[0000926326-22-000014:mdna:85]
Cost of revenues is primarily comprised of three general categories: (i) standard product costs which account for the majority of the product cost of revenues that are provided to customers, and are inclusive of purchased material, labor to build the product, and overhead costs associated with production; (ii) costs of providing services and installation costs, including costs of personnel and other expenses; and (iii) other costs, including variances in standard costs and overhead, scrap costs, rework, warranty, provisions for excess and obsolete inventory, and amortization of software development costs and intangibles.

[0000926326-22-000014:mdna:86]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product revenues | $ | 118,338 |  |  | $ | 92,627 |  |  | $ | 25,711 |  |  | 28% |
| As a percentage of related revenues | 52% |  | 52% |  |  |  |  |
| Cost of services and other revenues | 50,443 |  |  | 36,933 |  |  | 13,510 |  |  | 37% |
| As a percentage of related revenues | 54% |  | 50% |  |  |  |  |
| Total cost of revenues | $ | 168,781 |  |  | $ | 129,560 |  |  | $ | 39,221 |  |  | 30% |
| As a percentage of total revenues | 53% |  | 51% |  |  |  |  |
| Gross profit | $ | 150,047 |  |  | $ | 122,283 |  |  | $ | 27,764 |  |  | 23% |
| Gross margin | 47% |  | 49% |  |  |  |  |

[0000926326-22-000014:mdna:87]
Cost of revenues for the three months ended March 31, 2022 compared to the three months ended March 31, 2021 increased by $39.2 million, of which $25.7 million was attributed to the increase in cost of product revenues and $13.5 million was attributed to the increase in cost of services and other revenues.

[0000926326-22-000014:mdna:88]
The increase in cost of product revenues was primarily driven by the increase in product revenues of $47.8 million for the three months ended March 31, 2022 compared to the three months ended March 31, 2021, as well as increased inventory-related costs due to inflationary impacts. The increase was partially offset by the benefits associated with economies of scale due to higher volumes during the three months ended March 31, 2022 compared to the three months ended March 31, 2021.

[0000926326-22-000014:mdna:89]
The increase in cost of services and other revenues was primarily driven by the increase in services and other revenues of $19.2 million, including incremental revenues from our recent acquisitions, for the three months ended March 31, 2022 compared to the three months ended March 31, 2021, as well as additional investments in our service business to support new service solutions.

[0000926326-22-000014:mdna:90]
The overall decrease in gross margin primarily relates to additional investments in our business, including our service solutions, as well as inflationary impacts on inventory-related costs. The decrease is partially offset by higher revenues for the three months ended March 31, 2022 due to increased customer demand as well as benefits associated with economies of scale due to higher volumes. Our gross profit for the three months ended March 31, 2022 was $150.0 million, as compared to $122.3 million for the three months ended March 31, 2021.

[0000926326-22-000014:mdna:91]
[same as prior period, unchanged from 0000926326-21-000034:mdna:103]

[0000926326-22-000014:mdna:92]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 25,030 |  |  | $ | 16,080 |  |  | $ | 8,950 |  |  | 56% |
| As a percentage of total revenues | 8% |  | 6% |  |  |  |  |
| Selling, general, and administrative | 119,933 |  |  | 86,593 |  |  | 33,340 |  |  | 39% |
| As a percentage of total revenues | 38% |  | 34% |  |  |  |  |
| Total operating expenses | $ | 144,963 |  |  | $ | 102,673 |  |  | $ | 42,290 |  |  | 41% |
| As a percentage of total revenues | 45% |  | 41% |  |  |  |  |
| Interest and other income (expense), net | $ | (114) |  |  | $ | (6,691) |  |  | $ | 6,577 |  |  | (98)% |

[0000926326-22-000014:mdna:93]
Research and Development. Research and development expenses increased by $9.0 million for the three months ended March 31, 2022 compared to the three months ended March 31, 2021. The increase was primarily attributed to an increase in employee-related expenses of approximately $7.4 million due to increased headcount to support the continued development of

[0000926326-22-000014:mdna:94]
our intelligent infrastructure and incremental headcount from recent acquisitions, as well as an increase of $1.5 million in employee-related expenses for restructuring initiatives.

[0000926326-22-000014:mdna:95]
Selling, General, and Administrative. Selling, general, and administrative expenses increased by $33.3 million for the three months ended March 31, 2022 compared to the three months ended March 31, 2021. The increase was primarily due to an increase of approximately $17.5 million in employee-related expenses primarily related to increased headcount, including the incremental headcount from recent acquisitions, as well as an increase in spending on travel and meetings of $2.8 million, an increase in intangible asset amortization expense of $2.3 million, and a $1.8 million impairment of operating lease right-of-use assets.

[0000926326-22-000014:mdna:96]
Interest and Other Income (Expense), Net. Interest and other income (expense), net changed by $6.6 million for the three months ended March 31, 2022 compared to the three months ended March 31, 2021, primarily driven by a $5.1 million decrease in other expenses and a $1.4 million increase in other income. The decrease in other expenses during the three months ended March 31, 2022 as compared to the three months ended March 31, 2021 is primarily due to the adoption of ASU 2020-06, effective January 1, 2022, which eliminated the imputed interest expense recognized on our convertible senior notes (refer to Note 1, Organization and Summary of Significant Accounting Policies, for additional information). The increase in other income during the three months ended March 31, 2022 as compared to the three months ended March 31, 2021 is primarily attributable to benefits from certain arrangements outside of our normal course of business.

[0000926326-22-000014:mdna:97]
[same as prior period, unchanged from 0000926326-21-000034:mdna:112]

[0000926326-22-000014:mdna:98]
|  | Three Months Ended March 31, |
|  |  |  |  |  | Change in |
|  | 2022 |  | 2021 |  | $ |  | % |
|  | (Dollars in thousands) |
| Benefit from income taxes | $ | (3,243) |  |  | $ | (1,208) |  |  | $ | (2,035) |  |  | 168% |

[0000926326-22-000014:mdna:99]
Our annual effective tax rate before discrete items was 26.4% and 26.7% for the three months ended March 31, 2022 and 2021, respectively. The slight decrease in the estimated annual effective tax rate for the three months ended March 31, 2022 compared to the same period in 2021 was primarily due to an increase in research and development credits.

[0000926326-22-000014:mdna:100]
Benefit from income taxes for the three months ended March 31, 2022 included net discrete income tax benefit of $4.6 million, primarily due to a $4.4 million tax benefit from equity compensation.

[0000926326-22-000014:mdna:101]
Benefit from income taxes for the three months ended March 31, 2021 included net discrete income tax benefit of $4.7 million, primarily due to a $4.1 million tax benefit from equity compensation.

[0000926326-22-000014:mdna:102]
Effective January 1, 2022, the Tax Cuts and Jobs Act of 2017 eliminated the ability to deduct research and development expenditures and required those expenditures to be amortized. While this change has not materially impacted our effective tax rate, it could potentially impact our cash flows and increase the amount of cash taxes we pay.

[0000926326-22-000014:mdna:103]
Refer to Note 14, Income Taxes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-22-000014:mdna:104]
[same as prior period, unchanged from 0000926326-21-000034:mdna:120]

[0000926326-22-000014:mdna:105]
We had cash and cash equivalents of $265.0 million at March 31, 2022 compared to $349.1 million at December 31, 2021. All of our cash and cash equivalents are invested in bank accounts and money market funds held in sweep and asset management accounts with major financial institutions.

[0000926326-22-000014:mdna:106]
Our cash position and working capital at March 31, 2022 and December 31, 2021 were as follows:

[0000926326-22-000014:mdna:107]
|  | March 31,2022 |  | December 31,2021 |
|  | (In thousands) |
| Cash and cash equivalents | $ | 265,008 |  |  | $ | 349,051 |  |
| Working capital (deficit) (1) | $ | (175,408) |  |  | $ | (95,456) |  |

[0000926326-22-000014:mdna:108]
[same as prior period, unchanged from 0000926326-21-000034:mdna:155]

[0000926326-22-000014:mdna:109]
(1)    The working capital deficit balances as of March 31, 2022 and December 31, 2021 were primarily due to the reclassification of our convertible senior notes as a current rather than long-term liability. Refer to Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-22-000014:mdna:110]
Our ratio of current assets to current liabilities was 0.8:1 and 0.9:1 at March 31, 2022 and December 31, 2021, respectively.

[0000926326-22-000014:mdna:111]
[same as prior period, unchanged from 0000926326-21-000034:mdna:125]

[0000926326-22-000014:mdna:112]
Revolving Credit Facility

[0000926326-22-000014:mdna:113]
On November 15, 2019, we entered into an Amended and Restated Credit Agreement (as subsequently amended, as discussed below, the “A&R Credit Agreement”) with the lenders from time to time party thereto, Wells Fargo Securities, LLC, Citizens Bank, N.A., and JPMorgan Chase Bank, N.A., as joint lead arrangers, and Wells Fargo Bank, National Association, as administrative agent. The A&R Credit Agreement superseded our 2016 senior secured credit facility and provides for (a) a five-year revolving credit facility of $500.0 million (the “Revolving Credit Facility”) and (b) an uncommitted incremental loan facility of up to $250.0 million. In addition, the A&R Credit Agreement includes a letter of credit sub-limit of up to $15.0 million and a swing line loan sub-limit of up to $25.0 million.

[0000926326-22-000014:mdna:114]
On September 22, 2020, the parties entered into an amendment to the A&R Credit Agreement to, among other changes, permit the issuance of the convertible senior notes and the purchase of the convertible note hedge transactions described below, expand our flexibility to repurchase our common stock and make other restricted payments, and replace the total net leverage covenant with a new secured net leverage covenant that required us to maintain a consolidated secured net leverage ratio not to exceed 3.50:1 for the calendar quarters ending September 30, 2020, December 31, 2020, and March 31, 2021 and requires us to maintain a consolidated secured net leverage ratio not to exceed 3.00:1 for the calendar quarters ending thereafter.

[0000926326-22-000014:mdna:115]
As of March 31, 2022, there was no outstanding balance for the Revolving Credit Facility and we were in full compliance with all covenants. Refer to Note 9, Debt and Credit Agreement, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information. We expect to use future loans under the Revolving Credit Facility, if any, for working capital, potential acquisitions, and other general corporate purposes.

[0000926326-22-000014:mdna:116]
[same as prior period, unchanged from 0000926326-21-000034:mdna:133]

[0000926326-22-000014:mdna:117]
[same as prior period, unchanged from 0000926326-21-000034:mdna:134]

[0000926326-22-000014:mdna:118]
The 2016 Repurchase Program has a total of $2.7 million remaining for future repurchases as of March 31, 2022, which may result in additional use of cash. As of March 31, 2022, the 2014 Repurchase Program was completed. During the three months ended March 31, 2022, we repurchased approximately 389,300 shares of our common stock under our repurchase programs at an average price of $134.11 per share for an aggregate purchase price of approximately $52.2 million. Refer to “Stock Repurchase Programs” under Note 15, Employee Benefits and Share-Based Compensation, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-22-000014:mdna:119]
Based on our current business plan and product backlog, we believe that our existing cash and cash equivalents, our anticipated cash flows from operations, cash generated from the exercise of employee stock options and purchases under our Employee Stock Purchase Plan (“ESPP”), along with the availability of funds under the Revolving Credit Facility will be sufficient to meet our cash needs for working capital, capital expenditures, potential acquisitions, and other contractual obligations for at least the next twelve months. For periods beyond the next twelve months, we also anticipate that our net operating cash flows plus existing balances of cash and cash equivalents will suffice to fund the continued growth of our business.

[0000926326-22-000014:mdna:120]
[same as prior period, unchanged from 0000926326-21-000034:mdna:137]

[0000926326-22-000014:mdna:121]
[same as prior period, unchanged from 0000926326-21-000034:mdna:138]

[0000926326-22-000014:mdna:122]
|  | Three Months Ended March 31, |
|  | 2022 |  | 2021 |
|  | (In thousands) |
| Net cash provided by (used in): |  |  |  |
| Operating activities | $ | (15,996) |  |  | $ | 57,415 |  |
| Investing activities | (18,733) |  |  | (13,132) |  |
| Financing activities | (32,119) |  |  | 15,599 |  |
| Effect of exchange rate changes on cash and cash equivalents | (411) |  |  | (386) |  |
| Net increase (decrease) in cash, cash equivalents, and restricted cash | $ | (67,259) |  |  | $ | 59,496 |  |

[0000926326-22-000014:mdna:123]
[same as prior period, unchanged from 0000926326-21-000034:mdna:140]

[0000926326-22-000014:mdna:124]
[same as prior period, unchanged from 0000926326-21-000034:mdna:141]

[0000926326-22-000014:mdna:125]
Net cash used in operating activities was $16.0 million for the three months ended March 31, 2022, primarily consisting of net income of $8.2 million adjusted for non-cash items of $38.6 million, offset by changes in assets and liabilities of $62.8 million. The non-cash items primarily consisted of depreciation and amortization expense of $21.1 million, share-based compensation expense of $16.2 million, amortization of operating lease right-of-use assets of $3.3 million, impairment of operating lease right-of-use assets of $1.8 million, amortization of debt issuance costs of $1.0 million, and a change in deferred income taxes of $4.9 million. Changes in assets and liabilities include cash outflows from (i) an increase in accounts receivable and unbilled receivables of $50.0 million primarily due to an increase in billings driven by overall business growth and the timing of shipments and collections, (ii) a decrease in accrued compensation of $23.9 million primarily due to a decrease in accrued commissions and bonuses as well as timing of ESPP purchases, (iii) an increase in inventories of $17.3 million to support forecasted sales, including advanced purchases of certain components, as well as higher costs of inventory, (iv) a decrease in operating lease liabilities of $3.5 million, (v) an increase in prepaid expenses of $1.7 million, and (vi) an increase in investment in sales-type leases of $1.1 million. These cash outflows were partially offset by (i) an increase in deferred revenues of $19.8 million primarily due to an increase in billings driven by the timing of annual maintenance renewals, the billing of other ongoing service commitments, and shipments of product in order to meet customers’ implementation schedules and recognition of revenues for products requiring installation, (ii) a decrease in other current assets, net of funds held for customers, of $8.0 million, (iii) a decrease in prepaid commissions of $4.2 million, and (iv) a decrease in other long-term assets of $2.2 million.

[0000926326-22-000014:mdna:126]
Net cash provided by operating activities was $57.4 million for the three months ended March 31, 2021, primarily consisting of net income of $14.1 million adjusted for non-cash items of $36.8 million and changes in assets and liabilities of $6.5 million. The non-cash items primarily consisted of depreciation and amortization expense of $17.6 million, share-based compensation expense of $11.8 million, amortization of operating lease right-of-use assets of $2.9 million, amortization of debt issuance costs of $0.8 million, amortization of discount on convertible senior notes of $4.6 million, and a change in deferred income taxes of $0.9 million. Changes in assets and liabilities include cash inflows from (i) an increase in deferred revenues of $21.7 million primarily due to an increase in billings driven by the timing of shipments in order to meet customers’ implementation schedules and recognition of revenues for products requiring installation, (ii) an increase in accounts payable of $10.4 million primarily due to an overall increase in spending, as well as timing of payments, (iii) an increase in accrued liabilities of $4.7 million, (iv) a decrease in other current assets of $3.1 million, (v) a decrease in prepaid commissions of $2.7 million, and (vi) a decrease in other long-term assets of $2.2 million. These cash inflows were partially offset by (i) a decrease in accrued compensation of $17.9 million primarily due to a decrease in accrued commissions and bonuses, as well as timing of ESPP purchases, (ii) an increase in accounts receivable and unbilled receivables of $15.4 million primarily due to an increase in billings driven by the timing of shipments as well as collections, (iii) a decrease in operating lease liabilities of $3.1 million, (iv) an increase in prepaid expenses of $1.1 million, and (v) an increase in inventories of $1.0 million.

[0000926326-22-000014:mdna:127]
[same as prior period, unchanged from 0000926326-21-000034:mdna:145]

[0000926326-22-000014:mdna:128]
Net cash used in investing activities was $18.7 million for the three months ended March 31, 2022, which consisted of $3.4 million consideration paid for the acquisition of Hub and Spoke Innovations, net of cash acquired, capital expenditures of $11.5 million for property and equipment, and $3.9 million for costs of software development for external use.

[0000926326-22-000014:mdna:129]
Net cash used in investing activities was $13.1 million for the three months ended March 31, 2021, which consisted of capital expenditures of $5.1 million for property and equipment, and $8.0 million for costs of software development for external use.

[0000926326-22-000014:mdna:130]
[same as prior period, unchanged from 0000926326-21-000034:mdna:148]

[0000926326-22-000014:mdna:131]
Net cash used in financing activities was $32.1 million for the three months ended March 31, 2022, primarily due to $52.2 million for repurchases of our stock and $4.3 million in employees’ taxes paid related to restricted stock unit vesting, partially offset by $19.0 million in proceeds from employee stock option exercises and ESPP purchases, and a net increase in the customer funds balances of $5.5 million.

[0000926326-22-000014:mdna:132]
Net cash provided by financing activities was $15.6 million for the three months ended March 31, 2021, primarily due to $20.8 million in proceeds from employee stock option exercises and ESPP purchases, partially offset by $2.6 million in employees’ taxes paid related to restricted stock unit vesting, and a net decrease in the customer funds balances of $2.6 million.

[0000926326-22-000014:mdna:133]
[same as prior period, unchanged from 0000926326-21-000034:mdna:151]

[0000926326-22-000014:mdna:134]
There have been no significant changes during the three months ended March 31, 2022 to the contractual obligations disclosed in “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” set forth in Part II, Item 7, of our Annual Report on Form 10-K for the year ended December 31, 2021.

[0000926326-22-000014:mdna:135]
Contractual obligations as of March 31, 2022 were as follows:

[0000926326-22-000014:mdna:136]
|  | Payments Due By Period |
|  | Total |  | Remainder of 2022 |  | 2023 - 2024 |  | 2025 - 2026 |  | 2027 and thereafter |
|  | (In thousands) |
| Operating leases (1) | $ | 56,810 |  |  | $ | 11,244 |  |  | $ | 21,318 |  |  | $ | 13,366 |  |  | $ | 10,882 |  |
| Purchase obligations (2) | 227,135 |  |  | 194,461 |  |  | 32,318 |  |  | 322 |  |  | 34 |  |
| Convertible senior notes (3) | 580,032 |  |  | 719 |  |  | 2,875 |  |  | 576,438 |  |  | — |  |
| Other (4) | 844 |  |  | 156 |  |  | 440 |  |  | 248 |  |  | — |  |
| Total (5) | $ | 864,821 |  |  | $ | 206,580 |  |  | $ | 56,951 |  |  | $ | 590,374 |  |  | $ | 10,916 |  |

[0000926326-22-000014:mdna:137]
_________________________________________________

[0000926326-22-000014:mdna:138]
(1)Commitments under operating leases relate primarily to leased office buildings, data centers, office equipment, and vehicles. Refer to Note 12, Lessee Leases, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-22-000014:mdna:139]
[same as prior period, unchanged from 0000926326-21-000034:mdna:157]

[0000926326-22-000014:mdna:140]
(3)We issued convertible senior notes in September 2020 that are due in September 2025. The obligations presented above include both principal and interest for these notes. Although these notes mature in 2025, they may be converted into cash and shares of our common stock prior to maturity if certain conditions are met. Any conversion prior to maturity can result in repayment of the principal amounts sooner than the scheduled repayment as indicated in the table above. Refer to Note 10, Convertible Senior Notes, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.

[0000926326-22-000014:mdna:141]
[same as prior period, unchanged from 0000926326-21-000034:mdna:159]

[0000926326-22-000014:mdna:142]
(5)Refer to Note 13, Commitments and Contingencies, of the Notes to Condensed Consolidated Financial Statements included in this Quarterly Report on Form 10-Q for additional information.
