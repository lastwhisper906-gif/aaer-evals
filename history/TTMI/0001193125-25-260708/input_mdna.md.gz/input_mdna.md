# TTMI MD&A — 0001193125-25-260708


## mdna

[0001193125-25-260708:mdna:1]
[same as prior period, unchanged from 0000950170-25-102042:mdna:1]

[0001193125-25-260708:mdna:2]
[same as prior period, unchanged from 0000950170-25-102042:mdna:2]

[0001193125-25-260708:mdna:3]
This Quarterly Report on Form 10-Q (Report) contains forward-looking statements regarding future events or our future financial and operational performance. Forward-looking statements include statements regarding markets for our products; trends in net sales, gross profits, and estimated expense levels; liquidity and anticipated cash needs and availability; and any statement that contains the words “anticipate,” “believe,” “plan,” “forecast,” “foresee,” “estimate,” “project,” “expect,” “seek,” “target,” “intend,” “goal,” and other similar expressions. The forward-looking statements included in this Report reflect our current expectations and beliefs, and we do not undertake publicly to update or revise these statements, even if experience or future changes make it clear that any projected results expressed in this Report or future quarterly reports to stockholders, press releases, or company statements will not be realized. In addition, the inclusion of any statement in this Report does not constitute an admission by us that the events or circumstances described in such statement are material. Furthermore, we wish to caution and advise readers that these statements are based on assumptions that may not materialize and may involve risks and uncertainties, many of which are beyond our control, that could cause actual events or performance to differ materially from those contained or implied in these forward-looking statements. These risks and uncertainties include the risks identified under the heading "Risk Factors" in our Annual Report on Form 10-K for the fiscal year ended December 30, 2024, as updated by our other filings with the SEC, and described elsewhere in this Report. The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated condensed financial statements and the related notes and the other financial information included in this Report, as well as the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” set forth in our Annual Report on Form 10-K for the fiscal year ended December 30, 2024, filed with the SEC.

[0001193125-25-260708:mdna:4]
[same as prior period, unchanged from 0000950170-25-102042:mdna:4]

[0001193125-25-260708:mdna:5]
We are a leading global manufacturer of technology products, including mission systems, RF components, RF microwave/microelectronic assemblies, and technologically advanced PCBs. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering, and manufacturing solution to our customers. This solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,400 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial, and instrumentation, and networking. Our customers include OEMs, EMS providers, ODMs, distributors, and government agencies (both domestic and allied foreign governments).

[0001193125-25-260708:mdna:6]
[same as prior period, unchanged from 0000950170-25-102042:mdna:6]

[0001193125-25-260708:mdna:7]
[same as prior period, unchanged from 0000950170-25-102042:mdna:7]

[0001193125-25-260708:mdna:8]
We previously announced we are in the process of constructing a new advanced technology PCB manufacturing facility in Syracuse, New York. We expect that our new facility will bring advanced technology capability for our domestic high-volume production of ultra‑high‑density interconnect (HDI) PCBs in support of national security requirements. The building construction is complete, equipment is arriving, and we are beginning to install and test equipment setups. Volume production in this facility is expected to commence in the second half of 2026.

[0001193125-25-260708:mdna:9]
[same as prior period, unchanged from 0000950170-25-102042:mdna:9]

[0001193125-25-260708:mdna:10]
[same as prior period, unchanged from 0000950170-25-102042:mdna:10]

[0001193125-25-260708:mdna:11]
Our customers include both OEMs and EMS providers. We sell to OEMs both directly and indirectly through EMS providers. For such indirect sales, we measure customers based on OEM companies as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 56% and 55% of our net sales for the quarter and three quarters ended September 29, 2025, respectively. Sales to our ten largest customers collectively accounted for 54% and 53% of our net sales for the quarter and three quarters ended September 30, 2024, respectively.

[0001193125-25-260708:mdna:12]
[same as prior period, unchanged from 0000950170-25-102042:mdna:12]

[0001193125-25-260708:mdna:13]
|  |  | For the Quarter Ended |  | For the Three Quarters Ended |
|  |  | September 29, 2025 |  | September 30, 2024 (1) |  | September 29, 2025 (1) |  | September 30, 2024 (1) |
| End Markets (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  |  | 45 |  | % |  |  | 45 |  | % |  |  | 45 |  | % |  |  | 46 |  | % |
| Automotive |  |  | 11 |  |  |  |  | 14 |  |  |  |  | 11 |  |  |  |  | 14 |  |  |
| Data Center Computing |  |  | 23 |  |  |  |  | 20 |  |  |  |  | 22 |  |  |  |  | 20 |  |  |
| Medical/Industrial/Instrumentation |  |  | 14 |  |  |  |  | 14 |  |  |  |  | 14 |  |  |  |  | 14 |  |  |
| Networking |  |  | 7 |  |  |  |  | 7 |  |  |  |  | 8 |  |  |  |  | 6 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001193125-25-260708:mdna:14]
[same as prior period, unchanged from 0000950170-25-102042:mdna:14]

[0001193125-25-260708:mdna:15]
[same as prior period, unchanged from 0000950170-25-102042:mdna:15]

[0001193125-25-260708:mdna:16]
[same as prior period, unchanged from 0000950170-25-102042:mdna:23]

[0001193125-25-260708:mdna:17]
Our consolidated condensed financial statements included in this Report have been prepared in accordance with U.S. GAAP. The preparation of these consolidated condensed financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001193125-25-260708:mdna:18]
[same as prior period, unchanged from 0000950170-25-102042:mdna:26]

[0001193125-25-260708:mdna:19]
[same as prior period, unchanged from 0000950170-25-102042:mdna:27]

[0001193125-25-260708:mdna:20]
[same as prior period, unchanged from 0000950170-25-102042:mdna:18]

[0001193125-25-260708:mdna:21]
[same as prior period, unchanged from 0000950170-25-102042:mdna:28]

[0001193125-25-260708:mdna:22]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2025 |  |  | September 30, 2024 |  |  | September 29, 2025 |  |  | September 30, 2024 |  |
|  |  | (In thousands, except margin rates) |  |
| Net sales |  | $ | 752,736 |  |  | $ | 616,538 |  |  | $ | 2,132,025 |  |  | $ | 1,791,788 |  |
| Cost of goods sold |  |  | 596,000 |  |  |  | 486,650 |  |  |  | 1,696,208 |  |  |  | 1,440,954 |  |
| Gross profit |  |  | 156,736 |  |  |  | 129,888 |  |  |  | 435,817 |  |  |  | 350,834 |  |
| Gross margin |  |  | 20.8 | % |  |  | 21.1 | % |  |  | 20.4 | % |  |  | 19.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 21,796 |  |  |  | 19,961 |  |  |  | 64,383 |  |  |  | 60,053 |  |
| General and administrative |  |  | 48,598 |  |  |  | 42,567 |  |  |  | 142,091 |  |  |  | 124,841 |  |
| Research and development |  |  | 7,038 |  |  |  | 8,054 |  |  |  | 22,111 |  |  |  | 23,922 |  |
| Amortization of definite-lived intangibles |  |  | 6,889 |  |  |  | 6,951 |  |  |  | 20,666 |  |  |  | 28,636 |  |
| Restructuring charges |  |  | 509 |  |  |  | 1,393 |  |  |  | 2,631 |  |  |  | 6,367 |  |
| Total operating expenses |  |  | 84,830 |  |  |  | 78,926 |  |  |  | 251,882 |  |  |  | 243,819 |  |
| Operating income |  |  | 71,906 |  |  |  | 50,962 |  |  |  | 183,935 |  |  |  | 107,015 |  |
| Operating margin |  |  | 9.6 | % |  |  | 8.3 | % |  |  | 8.6 | % |  |  | 6.0 | % |
| Total other expense, net |  |  | (10,093 | ) |  |  | (25,945 | ) |  |  | (35,606 | ) |  |  | (37,397 | ) |
| Income tax provision |  |  | (8,758 | ) |  |  | (10,706 | ) |  |  | (21,566 | ) |  |  | (18,489 | ) |
| Net income |  | $ | 53,055 |  |  | $ | 14,311 |  |  | $ | 126,763 |  |  | $ | 51,129 |  |

[0001193125-25-260708:mdna:23]
The following discussion and analysis is for the quarter and three quarters ended September 29, 2025, compared to the quarter and three quarters ended September 30, 2024, unless otherwise stated.

[0001193125-25-260708:mdna:24]
[same as prior period, unchanged from 0000950170-25-102042:mdna:31]

[0001193125-25-260708:mdna:25]
Total net sales increased $136.2 million, or 22.1%, to $752.7 million for the quarter ended September 29, 2025, from $616.5 million for the quarter ended September 30, 2024. The primary driver of this increase was strong demand in our aerospace and defense, data center computing, and networking end markets, the latter two being driven by generative AI. In addition, our medical, industrial, and instrumentation end market was also stronger as inventories and demand have normalized in this end market.

[0001193125-25-260708:mdna:26]
Total net sales increased $340.2 million, or 19.0%, to $2,132.0 million for the three quarters ended September 29, 2025, from $1,791.8 million for the three quarters ended September 30, 2024. The primary drivers of the increase were as discussed in the paragraph above.

[0001193125-25-260708:mdna:27]
[same as prior period, unchanged from 0000950170-25-102042:mdna:34]

[0001193125-25-260708:mdna:28]
Gross profit increased $26.8 million to $156.7 million for the quarter ended September 29, 2025, from $129.9 million for the quarter ended September 30, 2024, primarily due to higher sales. Gross margin rate decreased slightly to 20.8% for the quarter ended September 29, 2025, from 21.1% for the quarter ended September 30, 2024. This decrease was primarily due to ramp‑up costs incurred in the third quarter of 2025 in connection with our fabrication plant in Penang, Malaysia as compared to the third quarter of 2024.

[0001193125-25-260708:mdna:29]
Gross profit increased $85.0 million to $435.8 million for the three quarters ended September 29, 2025, from $350.8 million for the three quarters ended September 30, 2024, primarily due to higher sales. Gross margin rate increased to 20.4% for the three quarters ended September 29, 2025, from 19.6% for the three quarters ended September 30, 2024. The increase was primarily due to improved operational execution, favorable product mix, and increased volume of PCB shipments as compared to the same period of 2024.

[0001193125-25-260708:mdna:30]
[same as prior period, unchanged from 0000950170-25-102042:mdna:37]

[0001193125-25-260708:mdna:31]
Operating expenses increased $5.9 million to $84.8 million for the quarter ended September 29, 2025, from $78.9 million for the quarter ended September 30, 2024, primarily due to higher incentive compensation expense, stock-based compensation, and outside services costs.

[0001193125-25-260708:mdna:32]
Operating expenses increased $8.1 million to $251.9 million for the three quarters ended September 29, 2025, from $243.8 million for the three quarters ended September 30, 2024, primarily due to the absence of gains on the sale of assets primarily related to the sale of two buildings vacated with the closure of our Anaheim and Santa Clara plants of $14.4 million that occurred in the three quarters ended September 30, 2024, partially offset by the write down of our Hong Kong building of $6.1 million that occurred in the three quarters ended September 30, 2024. In addition, increased stock-based compensation and incentive compensation expense contributed to the higher operating expenses, partially offset by a decrease in amortization of definite-lived intangibles.

[0001193125-25-260708:mdna:33]
[same as prior period, unchanged from 0000950170-25-102042:mdna:40]

[0001193125-25-260708:mdna:34]
Operating income increased $20.9 million to $71.9 million for the quarter ended September 29, 2025, from $51.0 million for the quarter ended September 30, 2024. Operating margin rate increased to 9.6% for the quarter ended September 29, 2025, from 8.3% for the quarter ended September 30, 2024. The primary drivers of these increases are discussed above in the variance explanations for Gross Profit and Margin Rate and Operating Expenses.

[0001193125-25-260708:mdna:35]
Operating income increased $76.9 million to $183.9 million for the three quarters ended September 29, 2025, from $107.0 million for the three quarters ended September 30, 2024. Operating margin rate increased to 8.6% for the three quarters ended September 29, 2025, from 6.0% for the three quarters ended September 30, 2024. The primary drivers of these increases are discussed above in the variance explanations for Gross Profit and Margin Rate and Operating Expenses.

[0001193125-25-260708:mdna:36]
[same as prior period, unchanged from 0000950170-25-102042:mdna:43]

[0001193125-25-260708:mdna:37]
Total other expense, net decreased $15.9 million to $10.1 million for the quarter ended September 29, 2025, from $25.9 million for the quarter ended September 30, 2024, primarily as a result of lower unrealized foreign exchange losses during the quarter ended September 29, 2025. We utilize the Chinese Renminbi (RMB) and Malaysian Ringgit (MYR) at our China and Malaysia facilities, respectively, for employee‑related and other costs of running our operations in foreign countries. There was an unrealized loss from foreign exchange of $0.5 million during the quarter ended September 29, 2025, compared to $16.2 million during the quarter ended September 30, 2024. This unrealized loss was related to the translation of our China and Malaysia balance sheets from their local currencies into the U.S. dollar functional currency, resulting from weakening RMB and MYR during the quarter ended September 29, 2025 as compared to the quarter ended September 30, 2024.

[0001193125-25-260708:mdna:38]
Total other expense, net decreased $1.8 million to $35.6 million for the three quarters ended September 29, 2025, from $37.4 million for the three quarters ended September 30, 2024, primarily as a result of lower unrealized foreign exchange losses during the three quarters ended September 29, 2025. There was an unrealized loss from foreign exchange of $8.5 million during the three quarters ended September 29, 2025, compared to $12.0 million during the three quarters ended September 30, 2024. This decrease was primarily due to the foreign currency impacts discussed in the paragraph above.

[0001193125-25-260708:mdna:39]
22

[0001193125-25-260708:mdna:40]
[same as prior period, unchanged from 0000950170-25-102042:mdna:46]

[0001193125-25-260708:mdna:41]
Income tax expense decreased $1.9 million to $8.8 million for the quarter ended September 29, 2025, from $10.7 million for the quarter ended September 30, 2024, primarily due to the OBBBA tax impact, as discussed below, and an income tax benefit from the deduction of stock-based compensation, partially offset by accruals for potential assessments and uncertain tax positions in various jurisdictions.

[0001193125-25-260708:mdna:42]
Income tax expense increased $3.1 million to $21.6 million for the three quarters ended September 29, 2025, from $18.5 million for the three quarters ended September 30, 2024, primarily due to an increase in income before income taxes for the three quarters ended September 29, 2025 and income tax accruals for potential assessments and uncertain tax positions in various jurisdictions, partially offset by the OBBBA tax impact, as discussed below, and an income tax benefit from the deduction of stock‑based compensation.

[0001193125-25-260708:mdna:43]
On July 4, 2025, the OBBBA was enacted, introducing amendments to U.S. tax laws with various effective dates from 2025 to 2027. The OBBBA includes provisions such as the permanent extension of certain provisions of the Tax Cuts and Jobs Act that were set to expire at the end of 2025 and modifications to the international tax framework. Topic 740 requires the effects of changes in tax rates and laws on deferred tax balances to be recognized in the period in which the legislation is enacted. Accordingly, our tax provisions for the quarter and three quarters ended September 29, 2025 incorporated the estimated effects of the tax law changes including the accelerated depreciation of qualified property and the immediate expensing of U.S. research and development expenditure paid or incurred for tax years beginning after December 31, 2024. We recorded a $5.2 million benefit from the decrease in the U.S. valuation allowance resulting from the OBBBA impact to our deferred tax assets.

[0001193125-25-260708:mdna:44]
Our effective tax rate is primarily impacted by the mix of foreign and U.S. income, tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax liability of $41.9 million and $40.4 million as of September 29, 2025 and September 30, 2024, respectively.

[0001193125-25-260708:mdna:45]
23

[0001193125-25-260708:mdna:46]
[same as prior period, unchanged from 0000950170-25-102042:mdna:51]

[0001193125-25-260708:mdna:47]
[same as prior period, unchanged from 0000950170-25-102042:mdna:52]

[0001193125-25-260708:mdna:48]
During the quarter ended June 30, 2025, in connection with our change in organizational structure to enhance clarity in sector performance, accountability, and operating costs, our management finalized its assessment of our operating segments and concluded that we now have three reportable segments: A&D, Commercial, and RF&S Components. As a result, certain prior period amounts have been reclassified to conform with this new presentation. See Part I, Item 1, Note 4, Segment Information, of the Notes to Consolidated Condensed Financial Statements in this Report for further information.

[0001193125-25-260708:mdna:49]
[same as prior period, unchanged from 0000950170-25-102042:mdna:54]

[0001193125-25-260708:mdna:50]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2025 |  |  | September 30, 2024 |  |  | September 29, 2025 |  |  | September 30, 2024 |  |
|  |  | (In thousands, except margin rates) |  |
| Segment sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| A&D |  | $ | 336,841 |  |  | $ | 279,533 |  |  | $ | 974,553 |  |  | $ | 833,798 |  |
| Commercial |  |  | 408,920 |  |  |  | 329,382 |  |  |  | 1,137,249 |  |  |  | 936,440 |  |
| RF&S Components |  |  | 10,444 |  |  |  | 9,780 |  |  |  | 29,342 |  |  |  | 27,196 |  |
| Total |  | $ | 756,205 |  |  | $ | 618,695 |  |  | $ | 2,141,144 |  |  | $ | 1,797,434 |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |
| A&D |  | $ | 52,884 |  |  | $ | 40,279 |  |  | $ | 138,943 |  |  | $ | 100,252 |  |
| Commercial |  |  | 60,031 |  |  |  | 51,105 |  |  |  | 163,749 |  |  |  | 130,858 |  |
| RF&S Components |  |  | 3,126 |  |  |  | 2,426 |  |  |  | 7,581 |  |  |  | 6,139 |  |
| Total |  |  | 116,041 |  |  |  | 93,810 |  |  |  | 310,273 |  |  |  | 237,249 |  |
| Segment operating margin rate: |  |  |  |  |  |  |  |  |  |  |  |  |
| A&D |  |  | 15.7 | % |  |  | 14.4 | % |  |  | 14.3 | % |  |  | 12.0 | % |
| Commercial |  |  | 14.7 | % |  |  | 15.5 | % |  |  | 14.4 | % |  |  | 14.0 | % |
| RF&S Components |  |  | 29.9 | % |  |  | 24.8 | % |  |  | 25.8 | % |  |  | 22.6 | % |
| Total |  |  | 15.3 | % |  |  | 15.2 | % |  |  | 14.5 | % |  |  | 13.2 | % |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  | (509 | ) |  |  | (1,393 | ) |  |  | (2,631 | ) |  |  | (6,367 | ) |
| Gain on sale of property, plant, and equipment |  | — |  |  | — |  |  | — |  |  |  | 14,420 |  |
| Acquisition-related and other charges |  |  | (15 | ) |  |  | (2,867 | ) |  |  | (15 | ) |  |  | (12,939 | ) |
| Stock-based compensation |  |  | (11,611 | ) |  |  | (8,330 | ) |  |  | (29,586 | ) |  |  | (21,697 | ) |
| Other corporate expenses |  |  | (22,775 | ) |  |  | (20,972 | ) |  |  | (66,433 | ) |  |  | (68,009 | ) |
| Amortization of definite-lived intangibles (1) |  |  | (9,225 | ) |  |  | (9,286 | ) |  |  | (27,673 | ) |  |  | (35,642 | ) |
| Operating income |  | $ | 71,906 |  |  | $ | 50,962 |  |  | $ | 183,935 |  |  | $ | 107,015 |  |

[0001193125-25-260708:mdna:51]
(1)
Amortization of definite-lived intangibles relates to the A&D, Commercial, and RF&S Components reportable segments, but is not reviewed separately by the CODM. For the quarter and three quarters ended September 29, 2025, amortization expense of $2,336 and $7,007, respectively, is included in cost of goods sold for the A&D reportable segment. For the quarter and three quarters ended September 30, 2024, amortization expense of $2,335 and $7,006, respectively, is included in cost of goods sold for the A&D reportable segment.

[0001193125-25-260708:mdna:52]
Segment operating income, as reconciled in Part I, Item 1, Note 4, Segment Information, of the Notes to Consolidated Condensed Financial Statements in this Report, and segment operating margin rate (segment operating income divided by segment sales) are presented in conformity with Accounting Standards Codification (ASC) Topic 280, Segment Reporting. These measures are reported to the CODM, who is the President and Chief Executive Officer, for purposes of making decisions about allocating resources to the segments and assessing their performance. For these reasons, these measures are excluded from the definition of non‑GAAP financial measures under the SEC's Regulation G and Item 10(e) of Regulation S-K.

[0001193125-25-260708:mdna:53]
[same as prior period, unchanged from 0000950170-25-102042:mdna:58]

[0001193125-25-260708:mdna:54]
[same as prior period, unchanged from 0000950170-25-102042:mdna:59]

[0001193125-25-260708:mdna:55]
Segment sales for the A&D reportable segment increased $57.3 million, or 20.5%, to $336.8 million for the quarter ended September 29, 2025, from $279.5 million for the quarter ended September 30, 2024. The primary drivers of this increase were improved spending in previous defense budgets, our strong strategic program alignment, and key bookings for ongoing franchise programs,

[0001193125-25-260708:mdna:56]
including restricted programs. These increases were driven by increased sales related to missiles and munitions as well as strong demand in our mission systems and specialty assembly businesses.

[0001193125-25-260708:mdna:57]
Segment sales for the A&D reportable segment increased $140.8 million, or 16.9%, to $974.6 million for the three quarters ended September 29, 2025, from $833.8 million for the three quarters ended September 30, 2024. The primary drivers of the increase were as discussed in the paragraph above.

[0001193125-25-260708:mdna:58]
[same as prior period, unchanged from 0000950170-25-102042:mdna:63]

[0001193125-25-260708:mdna:59]
Segment operating income for the A&D reportable segment increased $12.6 million to $52.9 million for the quarter ended September 29, 2025, from $40.3 million for the quarter ended September 30, 2024. Segment operating margin rate for the A&D reportable segment increased to 15.7% for the quarter ended September 29, 2025, from 14.4% for the quarter ended September 30, 2024. The primary drivers of these increases were higher sales volume, as discussed above, favorable product mix, and improved operational execution.

[0001193125-25-260708:mdna:60]
Segment operating income for the A&D reportable segment increased $38.7 million to $138.9 million for the three quarters ended September 29, 2025, from $100.3 million for the three quarters ended September 30, 2024. Segment operating margin rate for the A&D reportable segment increased to 14.3% for the three quarters ended September 29, 2025, from 12.0% for the three quarters ended September 30, 2024. The primary drivers of these increases were higher sales volume, as discussed above, favorable product mix, and improved operational execution.

[0001193125-25-260708:mdna:61]
[same as prior period, unchanged from 0000950170-25-102042:mdna:66]

[0001193125-25-260708:mdna:62]
[same as prior period, unchanged from 0000950170-25-102042:mdna:67]

[0001193125-25-260708:mdna:63]
Segment sales for the Commercial reportable segment increased $79.5 million, or 24.1%, to $408.9 million for the quarter ended September 29, 2025, from $329.4 million for the quarter ended September 30, 2024. The primary driver of this increase was strong demand in our data center computing and networking end markets driven by generative AI.

[0001193125-25-260708:mdna:64]
Segment sales for the Commercial reportable segment increased $200.8 million, or 21.4%, to $1,137.2 million for the three quarters ended September 29, 2025, from $936.4 million for the three quarters ended September 30, 2024. The primary driver of this increase was strong demand in our data center computing and networking end markets driven by generative AI, as well as normalized demand and increased AI-related demand in our medical, industrial, and instrumentation end market.

[0001193125-25-260708:mdna:65]
[same as prior period, unchanged from 0000950170-25-102042:mdna:70]

[0001193125-25-260708:mdna:66]
Segment operating income for the Commercial reportable segment increased $8.9 million to $60.0 million for the quarter ended September 29, 2025, from $51.1 million for the quarter ended September 30, 2024. Segment operating margin rate for the Commercial reportable segment decreased to 14.7% for the quarter ended September 29, 2025, from 15.5% for the quarter ended September 30, 2024. The primary driver of the increase in segment operating income was higher sales volume as discussed above, while the segment operating margin rate decreased due to increased ramp-up costs in connection with our fabrication plant in Penang, Malaysia, as well as product mix change.

[0001193125-25-260708:mdna:67]
Segment operating income for the Commercial reportable segment increased $32.9 million to $163.7 million for the three quarters ended September 29, 2025, from $130.9 million for the three quarters ended September 30, 2024. Segment operating margin rate for the Commercial reportable segment increased to 14.4% for the three quarters ended September 29, 2025, from 14.0% for the three quarters ended September 30, 2024. The primary drivers of these increases were higher sales volume as discussed above, and improved operational execution.

[0001193125-25-260708:mdna:68]
[same as prior period, unchanged from 0000950170-25-102042:mdna:73]

[0001193125-25-260708:mdna:69]
[same as prior period, unchanged from 0000950170-25-102042:mdna:74]

[0001193125-25-260708:mdna:70]
Segment sales for the RF&S Components reportable segment increased $0.7 million, or 6.8%, to $10.4 million for the quarter ended September 29, 2025, from $9.8 million for the quarter ended September 30, 2024. The primary driver of this increase was stronger demand across the networking and medical, industrial, and instrumentation end markets.

[0001193125-25-260708:mdna:71]
Segment sales for the RF&S Components reportable segment increased $2.1 million, or 7.9%, to $29.3 million for the three quarters ended September 29, 2025, from $27.2 million for the three quarters ended September 30, 2024. The primary driver of this increase was stronger demand across the networking and medical, industrial, and instrumentation end markets.

[0001193125-25-260708:mdna:72]
[same as prior period, unchanged from 0000950170-25-102042:mdna:77]

[0001193125-25-260708:mdna:73]
Segment operating income for the RF&S Components reportable segment increased $0.7 million to $3.1 million for the quarter ended September 29, 2025, from $2.4 million for the quarter ended September 30, 2024. Segment operating margin rate for the RF&S Components reportable segment increased to 29.9% for the quarter ended September 29, 2025, from 24.8% for the quarter ended

[0001193125-25-260708:mdna:74]
September 30, 2024. The primary drivers of these increases were higher sales volume as discussed above, and improved operational execution.

[0001193125-25-260708:mdna:75]
Segment operating income for the RF&S Components reportable segment increased $1.4 million to $7.6 million for the three quarters ended September 29, 2025, from $6.1 million for the three quarters ended September 30, 2024. Segment operating margin rate for the RF&S Components reportable segment increased to 25.8% for the three quarters ended September 29, 2025, from 22.6% for the three quarters ended September 30, 2024. The primary drivers of these increases were higher sales volume as discussed above, and improved operational execution.

[0001193125-25-260708:mdna:76]
[same as prior period, unchanged from 0000950170-25-102042:mdna:81]

[0001193125-25-260708:mdna:77]
[same as prior period, unchanged from 0000950170-25-102042:mdna:82]

[0001193125-25-260708:mdna:78]
Cash flow provided by operating activities during the first three quarters of 2025 was $229.0 million as compared to cash flow provided by operating activities of $150.8 million in the same period in 2024. The increase in cash flow was primarily due to an increase in net income of $75.6 million.

[0001193125-25-260708:mdna:79]
Net cash used in investing activities during the first three quarters of 2025 was $222.7 million, primarily resulting from the use of $223.2 million for net purchases of property, plant, and equipment and other assets. Net cash used in investing activities during the first three quarters of 2024 was $93.4 million, primarily resulting from the use of $129.7 million for purchases of property, plant, and equipment and other assets. This was partially offset by the receipt of $29.6 million of proceeds from the sale of property, plant, and equipment and other assets primarily related to the sale of two buildings vacated by the closure of our Anaheim and Santa Clara plants and $6.7 million of proceeds from the sale of property associated with our Shanghai E‑MS subsidiary.

[0001193125-25-260708:mdna:80]
Net cash used in financing activities during the first three quarters of 2025 was $19.2 million, reflecting the use of $17.9 million for repurchases of our common stock and $2.8 million for the repayment of long-term debt borrowings, less customer deposits of $1.5 million. Net cash used in financing activities during the first three quarters of 2024 was $38.2 million, reflecting the use of $34.5 million for repurchases of common stock, $8.7 million for the repayment of long-term debt borrowings, and $1.1 million for payment of debt issuance costs, partially offset by $6.1 million of proceeds from long-term debt borrowings related to the refinancing of our Term Loan Facility.

[0001193125-25-260708:mdna:81]
As of September 29, 2025, we had cash and cash equivalents of approximately $491.1 million, of which approximately $196.6 million was held by our foreign subsidiaries, primarily in China, and $199.4 million of available borrowing capacity under our revolving credit facilities. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax expenses not previously accrued for the repatriation of this cash.

[0001193125-25-260708:mdna:82]
Our total 2025 capital expenditures are expected to be in the range of $265.0 million to $285.0 million, of which approximately $54.0 million relate to construction of our new plant in Syracuse, New York.

[0001193125-25-260708:mdna:83]
[same as prior period, unchanged from 0000950170-25-102042:mdna:88]

[0001193125-25-260708:mdna:84]
On May 8, 2025, our Board of Directors authorized the 2025 Repurchase Program, under which we may repurchase up to $100.0 million in value of our common stock from time to time through May 7, 2027. We did not repurchase any shares of our common stock during the quarter ended September 29, 2025. During the three quarters ended September 29, 2025, under our previous two-year repurchase program that expired on May 3, 2025, we repurchased approximately 0.7 million shares of our common stock for a total cost of $17.9 million (including commissions). As of September 29, 2025, the remaining amount in value available to be repurchased under the 2025 Repurchase Program was $100.0 million.

[0001193125-25-260708:mdna:85]
[same as prior period, unchanged from 0000950170-25-102042:mdna:90]

[0001193125-25-260708:mdna:86]
As of September 29, 2025, we had $916.6 million of outstanding debt, net of discount and issuance costs, composed of $497.2 million of Senior Notes due 2029, $337.4 million under the Term Loan Facility, $80.0 million under the Asia ABL, and $2.1 million of other loans.

[0001193125-25-260708:mdna:87]
Pursuant to the terms of the Senior Notes due 2029 and Term Loan Facility, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments. Under the ABL Revolving Loans, we are also subject to various financial covenants, including leverage and fixed-charge coverage ratios. As of September 29, 2025, we were in compliance with the covenants under the Senior Notes due 2029, Term Loan Facility, and ABL Revolving Loans.

[0001193125-25-260708:mdna:88]
Based on our current level of operations, we believe that cash generated from operations, cash on hand, and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next 12 months. Additional information regarding our indebtedness, including information about the credit available under our debt facilities, interest rates, and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 7, Long‑term Debt and Letters of Credit, of the Notes to Consolidated Condensed Financial Statements included in this Report.

[0001193125-25-260708:mdna:89]
[same as prior period, unchanged from 0000950170-25-102042:mdna:94]

[0001193125-25-260708:mdna:90]
We have agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $12.2 million and $17.2 million as of September 29, 2025 and December 30, 2024, respectively.

[0001193125-25-260708:mdna:91]
[same as prior period, unchanged from 0000950170-25-102042:mdna:96]

[0001193125-25-260708:mdna:92]
As part of our ongoing operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, derivative liabilities, purchase obligations, and leases. As of September 29, 2025, there were no material changes outside the ordinary course of business since December 30, 2024 to our contractual obligations and commitments and the related cash requirements.

[0001193125-25-260708:mdna:93]
[same as prior period, unchanged from 0000950170-25-102042:mdna:98]

[0001193125-25-260708:mdna:94]
[same as prior period, unchanged from 0000950170-25-102042:mdna:99]

[0001193125-25-260708:mdna:95]
Recently Issued Accounting Standards

[0001193125-25-260708:mdna:96]
[same as prior period, unchanged from 0000950170-25-102042:mdna:101]
