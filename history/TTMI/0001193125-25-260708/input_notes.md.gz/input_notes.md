# TTMI notes — 0001193125-25-260708


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001193125-25-260708:notes:1]
[same as prior period, unchanged from 0000950170-25-102042:notes:1]

[0001193125-25-260708:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology products, including mission systems, radio frequency (RF) components, RF microwave/microelectronic assemblies, and technologically advanced printed circuit boards (PCBs). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001193125-25-260708:notes:3]
[same as prior period, unchanged from 0000950170-25-102042:notes:3]

[0001193125-25-260708:notes:4]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflicts between Russia and Ukraine, as well as other global regions and the imposition of, or changes to, tariffs by the United States as well as retaliatory tariffs or measures by other countries, the global economy and financial markets have been volatile in recent periods. As such, the Company has considered information available to it as of the date of issuance of these consolidated condensed financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

[0001193125-25-260708:notes:5]
Recently Issued Accounting Standards Not Yet Adopted

[0001193125-25-260708:notes:6]
In September 2025, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2025-06, Targeted Improvements to the Accounting for Internal-Use Software, which amends the existing standard to remove all references to prescriptive and sequential software development project stages. Under this guidance, eligible software development costs will begin capitalization when management has authorized and committed to funding the software project, and it is probable that the project will be completed and the software will be used to perform the function intended. The ASU is effective for annual periods beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period. The guidance may be applied on a prospective basis, a modified basis, or a retrospective basis. The Company is currently evaluating the timing of the adoption and the impact of this ASU on its consolidated financial statements and related disclosures.

[0001193125-25-260708:notes:7]
In July 2025, the FASB issued ASU 2025-05, Measurement of Credit Losses for Accounts Receivable and Contract Assets, which provides a practical expedient to measure credit losses on accounts receivable and contract assets. The ASU is effective for annual periods beginning after December 15, 2025, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the timing of the adoption and the impact of this ASU on its consolidated financial statements and related disclosures.

[0001193125-25-260708:notes:8]
In November 2024, the FASB issued ASU 2024-03, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosure in the notes to the financial statements of specified information about certain costs and expenses. In January 2025, the FASB issued ASU 2025-01, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which amends the effective date of ASU 2024-03 to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027. Early adoption of ASU 2024-03 is permitted. ASU 2024-03 should be applied either prospectively to financial statements issued for reporting periods after the effective date or retrospectively to any or all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

[0001193125-25-260708:notes:9]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. The update will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted for annual financial statements not yet issued or made available for issuance. The Company will adopt ASU 2023-09 in its 2025 fiscal year Form 10-K. This ASU will impact only the Company's disclosures with no impacts to the results of operations, cash flows, and financial condition.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-25-260708:notes:10]
(2) Revenues

[0001193125-25-260708:notes:11]
As of September 29, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations for long‑term contracts was $418,620. The Company expects to recognize revenue on approximately 57% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.

[0001193125-25-260708:notes:12]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of September 29, 2025 and December 30, 2024 were $32,275 and $36,976, respectively.

[0001193125-25-260708:notes:13]
Revenue recognized for the three quarters ended September 29, 2025 from amounts recorded as contract liabilities as of December 30, 2024 was $82,722. Revenue recognized for the three quarters ended September 30, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $33,331.

[0001193125-25-260708:notes:14]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for both the quarter and three quarters ended September 29, 2025 and September 30, 2024.

[0001193125-25-260708:notes:15]
[same as prior period, unchanged from 0000950170-25-102042:notes:23]

[0001193125-25-260708:notes:16]
|  |  | For the Quarter Ended |  |
|  |  | September 29, 2025 |  |  | September 30, 2024 |  |
|  |  | Aerospace and Defense (A&D) |  |  | Commercial |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 333,556 |  |  | $ | — |  |  | $ | — |  |  | $ | 333,556 |  |  | $ | 277,604 |  |  | $ | — |  |  | $ | — |  |  | $ | 277,604 |  |
| Automotive |  |  | — |  |  |  | 79,355 |  |  |  | — |  |  |  | 79,355 |  |  |  | — |  |  |  | 86,773 |  |  |  | — |  |  |  | 86,773 |  |
| Data Center Computing |  |  | — |  |  |  | 175,302 |  |  |  | 33 |  |  |  | 175,335 |  |  |  | — |  |  |  | 121,767 |  |  |  | 201 |  |  |  | 121,968 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 107,289 |  |  |  | 1,128 |  |  |  | 108,417 |  |  |  | — |  |  |  | 87,968 |  |  |  | 579 |  |  |  | 88,547 |  |
| Networking |  |  | — |  |  |  | 46,790 |  |  |  | 9,283 |  |  |  | 56,073 |  |  |  | — |  |  |  | 32,681 |  |  |  | 8,965 |  |  |  | 41,646 |  |
| Total |  | $ | 333,556 |  |  | $ | 408,736 |  |  | $ | 10,444 |  |  | $ | 752,736 |  |  | $ | 277,604 |  |  | $ | 329,189 |  |  | $ | 9,745 |  |  | $ | 616,538 |  |

[0001193125-25-260708:notes:17]
|  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2025 |  |  | September 30, 2024 |  |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 966,066 |  |  | $ | — |  |  | $ | — |  |  | $ | 966,066 |  |  | $ | 828,908 |  |  | $ | — |  |  | $ | — |  |  | $ | 828,908 |  |
| Automotive |  |  | — |  |  |  | 232,133 |  |  |  | — |  |  |  | 232,133 |  |  |  | — |  |  |  | 239,681 |  |  |  | — |  |  |  | 239,681 |  |
| Data Center Computing |  |  | — |  |  |  | 460,291 |  |  |  | 979 |  |  |  | 461,270 |  |  |  | — |  |  |  | 359,680 |  |  |  | 323 |  |  |  | 360,003 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 299,397 |  |  |  | 3,046 |  |  |  | 302,443 |  |  |  | — |  |  |  | 249,532 |  |  |  | 2,035 |  |  |  | 251,567 |  |
| Networking |  |  | — |  |  |  | 144,826 |  |  |  | 25,287 |  |  |  | 170,113 |  |  |  | — |  |  |  | 86,940 |  |  |  | 24,689 |  |  |  | 111,629 |  |
| Total |  | $ | 966,066 |  |  | $ | 1,136,647 |  |  | $ | 29,312 |  |  | $ | 2,132,025 |  |  | $ | 828,908 |  |  | $ | 935,833 |  |  | $ | 27,047 |  |  | $ | 1,791,788 |  |

[0001193125-25-260708:notes:18]
(1)
The end market revenue for the A&D and Commercial reportable segments prior to the quarter ended June 30, 2025 has been recast to reflect certain adjustments to allocations resulting from the segment reorganization. The end market revenue excludes intersegment sales totaling $3,469 and $9,119 for the quarter and three quarters ended September 29, 2025, respectively, and $2,157 and $5,646 for the quarter and three quarters ended September 30, 2024, respectively. See Note 4, Segment Information, for further information.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-25-260708:notes:19]
[same as prior period, unchanged from 0000950170-25-102042:notes:12]

[0001193125-25-260708:notes:20]
[same as prior period, unchanged from 0000950170-25-102042:notes:13]

[0001193125-25-260708:notes:21]
The Company had cash and cash equivalents held by its foreign subsidiaries of $196,603 and $207,909 as of September 29, 2025 and December 30, 2024, respectively. The Company maintains its cash and cash equivalents with major financial institutions and such balances exceed Federal Deposit Insurance Corporation insurance limits. The Company has not experienced any losses in such accounts and believes it is not exposed to any significant risk on cash and cash equivalents.

[0001193125-25-260708:notes:22]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. As of September 29, 2025, one customer accounted for 14% of the Company's accounts receivable. There were no customers that accounted for 10% or more of the Company's accounts receivable as of December 30, 2024.

[0001193125-25-260708:notes:23]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.
For the quarter and three quarters ended September 29, 2025, two customers collectively accounted for approximately 23% and 22% of the Company's net sales, respectively. For the quarter and three quarters ended September 30, 2024, one customer accounted for approximately 11% of the Company's net sales.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-25-260708:notes:24]
(4) Segment Information

[0001193125-25-260708:notes:25]
[same as prior period, unchanged from 0000950170-25-102042:notes:58]

[0001193125-25-260708:notes:26]
[same as prior period, unchanged from 0000950170-25-102042:notes:59]

[0001193125-25-260708:notes:27]
The A&D reportable segment consists of PCBs, value-added assemblies, microelectronics, RF/microwave components and assemblies, and integrated mission systems. These highly engineered electronics products include the manufacture and test of customer‑supplied designs as well as long-term contracts to design, develop, manufacture, and test new products. The products in the A&D reportable segment support surveillance, intelligence, communications, and other critical missions for customers in the aerospace and defense industry. The Commercial reportable segment consists of PCBs using customer-supplied engineering and design plans supporting customers in the automotive, medical, industrial, and instrumentation, networking, and data center computing end markets. The RF&S Components reportable segment consists of TTM designed RF components for commercial customers in the telecommunications, industrial, and instrumentation markets, as well as commercial off-the-shelf (COTS) components for certain aerospace and defense customers.

[0001193125-25-260708:notes:28]
[same as prior period, unchanged from 0000950170-25-102042:notes:61]

[0001193125-25-260708:notes:29]
|  |  | For the Quarter Ended September 29, 2025 |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Eliminations |  |  | Total |
|  |  | (In thousands, except margin rates) |
| Net sales |  | $ | 333,556 |  |  | $ | 408,736 |  |  | $ | 10,444 |  |  | $ | — |  |  | $ | 752,736 |  |  |
| Intersegment sales |  |  | 3,285 |  |  |  | 184 |  |  |  | — |  |  |  | (3,469 | ) |  |  | — |  |  |
| Segment sales |  | $ | 336,841 |  |  | $ | 408,920 |  |  | $ | 10,444 |  |  | $ | (3,469 | ) |  | $ | 752,736 |  |  |
|  |  | Net Sales |  |  | Cost of Goods Sold |  |  | Operating Expenses |  |  | Operating Income |  |  | Operating Margin |
| A&D |  | $ | 336,841 |  |  | $ | (255,033 | ) |  | $ | (28,924 | ) |  | $ | 52,884 |  |  |  | 15.7 |  | % |
| Commercial |  |  | 408,920 |  |  |  | (330,183 | ) |  |  | (18,706 | ) |  |  | 60,031 |  |  |  | 14.7 |  |  |
| RF&S Components |  |  | 10,444 |  |  |  | (5,032 | ) |  |  | (2,286 | ) |  |  | 3,126 |  |  |  | 29.9 |  |  |
| Total segment |  |  | 756,205 |  |  |  | (590,248 | ) |  |  | (49,916 | ) |  |  | 116,041 |  |  |  | 15.3 |  |  |
| Eliminations |  |  | (3,469 | ) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  |  |  |  | (509 | ) |  |  |  |  |
| Acquisition-related and other charges |  |  |  |  |  |  |  |  |  |  |  | (15 | ) |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  |  |  |  | (11,611 | ) |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  |  |  |  |  |  | (22,775 | ) |  |  |  |  |
| Amortization of definite-lived intangibles |  |  |  |  |  |  |  |  |  |  |  | (9,225 | ) |  |  |  |  |
| Consolidated |  | $ | 752,736 |  |  |  |  |  |  |  |  |  | 71,906 |  |  |  | 9.6 |  | % |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  | (10,399 | ) |  |  |  |  |
| Other, net |  |  |  |  |  |  |  |  |  |  |  | 306 |  |  |  |  |  |
| Income before income taxes |  |  |  |  |  |  |  |  |  |  | $ | 61,813 |  |  |  |  |  |

[0001193125-25-260708:notes:30]
|  |  | For the Quarter Ended September 30, 2024 |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Eliminations |  |  | Total |
|  |  | (In thousands, except margin rates) |
| Net sales |  | $ | 277,604 |  |  | $ | 329,189 |  |  | $ | 9,745 |  |  | $ | — |  |  | $ | 616,538 |  |  |
| Intersegment sales |  |  | 1,929 |  |  |  | 193 |  |  |  | 35 |  |  |  | (2,157 | ) |  |  | — |  |  |
| Segment sales |  | $ | 279,533 |  |  | $ | 329,382 |  |  | $ | 9,780 |  |  | $ | (2,157 | ) |  | $ | 616,538 |  |  |
|  |  | Net Sales |  |  | Cost of Goods Sold |  |  | Operating Expenses |  |  | Operating Income |  |  | Operating Margin |
| A&D |  | $ | 279,533 |  |  | $ | (211,536 | ) |  | $ | (27,718 | ) |  | $ | 40,279 |  |  |  | 14.4 |  | % |
| Commercial |  |  | 329,382 |  |  |  | (262,147 | ) |  |  | (16,130 | ) |  |  | 51,105 |  |  |  | 15.5 |  |  |
| RF&S Components |  |  | 9,780 |  |  |  | (4,871 | ) |  |  | (2,483 | ) |  |  | 2,426 |  |  |  | 24.8 |  |  |
| Total segment |  |  | 618,695 |  |  |  | (478,554 | ) |  |  | (46,331 | ) |  |  | 93,810 |  |  |  | 15.2 |  |  |
| Eliminations |  |  | (2,157 | ) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  |  |  |  | (1,393 | ) |  |  |  |  |
| Acquisition-related and other charges |  |  |  |  |  |  |  |  |  |  |  | (2,867 | ) |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  |  |  |  | (8,330 | ) |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  |  |  |  |  |  | (20,972 | ) |  |  |  |  |
| Amortization of definite-lived intangibles |  |  |  |  |  |  |  |  |  |  |  | (9,286 | ) |  |  |  |  |
| Consolidated |  | $ | 616,538 |  |  |  |  |  |  |  |  |  | 50,962 |  |  |  | 8.3 |  | % |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  | (11,768 | ) |  |  |  |  |
| Other, net |  |  |  |  |  |  |  |  |  |  |  | (14,177 | ) |  |  |  |  |
| Income before income taxes |  |  |  |  |  |  |  |  |  |  | $ | 25,017 |  |  |  |  |  |

[0001193125-25-260708:notes:31]
|  |  | For the Three Quarters Ended September 29, 2025 |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Eliminations |  |  | Total |
|  |  | (In thousands, except margin rates) |
| Net sales |  | $ | 966,066 |  |  | $ | 1,136,647 |  |  | $ | 29,312 |  |  | $ | — |  |  | $ | 2,132,025 |  |  |
| Intersegment sales |  |  | 8,487 |  |  |  | 602 |  |  |  | 30 |  |  |  | (9,119 | ) |  |  | — |  |  |
| Segment sales |  | $ | 974,553 |  |  | $ | 1,137,249 |  |  | $ | 29,342 |  |  | $ | (9,119 | ) |  | $ | 2,132,025 |  |  |
|  |  | Net Sales |  |  | Cost of Goods Sold |  |  | Operating Expenses |  |  | Operating Income |  |  | Operating Margin |
| A&D |  | $ | 974,553 |  |  | $ | (745,008 | ) |  | $ | (90,602 | ) |  | $ | 138,943 |  |  |  | 14.3 |  | % |
| Commercial |  |  | 1,137,249 |  |  |  | (916,920 | ) |  |  | (56,580 | ) |  |  | 163,749 |  |  |  | 14.4 |  |  |
| RF&S Components |  |  | 29,342 |  |  |  | (14,665 | ) |  |  | (7,096 | ) |  |  | 7,581 |  |  |  | 25.8 |  |  |
| Total segment |  |  | 2,141,144 |  |  |  | (1,676,593 | ) |  |  | (154,278 | ) |  |  | 310,273 |  |  |  | 14.5 |  |  |
| Eliminations |  |  | (9,119 | ) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  |  |  |  | (2,631 | ) |  |  |  |  |
| Acquisition-related and other charges |  |  |  |  |  |  |  |  |  |  |  | (15 | ) |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  |  |  |  | (29,586 | ) |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  |  |  |  |  |  | (66,433 | ) |  |  |  |  |
| Amortization of definite-lived intangibles |  |  |  |  |  |  |  |  |  |  |  | (27,673 | ) |  |  |  |  |
| Consolidated |  | $ | 2,132,025 |  |  |  |  |  |  |  |  |  | 183,935 |  |  |  | 8.6 |  | % |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  | (32,958 | ) |  |  |  |  |
| Other, net |  |  |  |  |  |  |  |  |  |  |  | (2,648 | ) |  |  |  |  |
| Income before income taxes |  |  |  |  |  |  |  |  |  |  | $ | 148,329 |  |  |  |  |  |

[0001193125-25-260708:notes:32]
|  |  | For the Three Quarters Ended September 30, 2024 |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Eliminations |  |  | Total |
|  |  | (In thousands, except margin rates) |
| Net sales |  | $ | 828,908 |  |  | $ | 935,833 |  |  | $ | 27,047 |  |  | $ | — |  |  | $ | 1,791,788 |  |  |
| Intersegment sales |  |  | 4,890 |  |  |  | 607 |  |  |  | 149 |  |  |  | (5,646 | ) |  |  | — |  |  |
| Segment sales |  | $ | 833,798 |  |  | $ | 936,440 |  |  | $ | 27,196 |  |  | $ | (5,646 | ) |  | $ | 1,791,788 |  |  |
|  |  | Net Sales |  |  | Cost of Goods Sold |  |  | Operating Expenses |  |  | Operating Income |  |  | Operating Margin |
| A&D |  | $ | 833,798 |  |  | $ | (648,883 | ) |  | $ | (84,663 | ) |  | $ | 100,252 |  |  |  | 12.0 |  | % |
| Commercial |  |  | 936,440 |  |  |  | (755,231 | ) |  |  | (50,351 | ) |  |  | 130,858 |  |  |  | 14.0 |  |  |
| RF&S Components |  |  | 27,196 |  |  |  | (13,861 | ) |  |  | (7,196 | ) |  |  | 6,139 |  |  |  | 22.6 |  |  |
| Total segment |  |  | 1,797,434 |  |  |  | (1,417,975 | ) |  |  | (142,210 | ) |  |  | 237,249 |  |  |  | 13.2 |  |  |
| Eliminations |  |  | (5,646 | ) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  |  |  |  | (6,367 | ) |  |  |  |  |
| Gain on sale of property, plant, and equipment |  |  |  |  |  |  |  |  |  |  |  | 14,420 |  |  |  |  |  |
| Acquisition-related and other charges |  |  |  |  |  |  |  |  |  |  |  | (12,939 | ) |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  |  |  |  | (21,697 | ) |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  |  |  |  |  |  | (68,009 | ) |  |  |  |  |
| Amortization of definite-lived intangibles |  |  |  |  |  |  |  |  |  |  |  | (35,642 | ) |  |  |  |  |
| Consolidated |  | $ | 1,791,788 |  |  |  |  |  |  |  |  |  | 107,015 |  |  |  | 6.0 |  | % |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  | (36,311 | ) |  |  |  |  |
| Other, net |  |  |  |  |  |  |  |  |  |  |  | (1,086 | ) |  |  |  |  |
| Income before income taxes |  |  |  |  |  |  |  |  |  |  | $ | 69,618 |  |  |  |  |  |

[0001193125-25-260708:notes:33]
Amortization of definite-lived intangibles relates to the A&D, Commercial, and RF&S Components reportable segments, but is not reviewed separately by the CODM. For the quarter and three quarters ended September 29, 2025, amortization expense of $2,336 and $7,007, respectively, is included in cost of goods sold for the A&D reportable segment. For the quarter and three quarters ended September 30, 2024, amortization expense of $2,335 and $7,006, respectively, is included in cost of goods sold for the A&D reportable segment.

[0001193125-25-260708:notes:34]
[same as prior period, unchanged from 0000950170-25-102042:notes:67]

[0001193125-25-260708:notes:35]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2025 |  |  | September 30, 2024 |  |  | September 29, 2025 |  |  | September 30, 2024 |  |
|  |  | (In thousands) |  |
| A&D |  | $ | 7,985 |  |  | $ | 8,868 |  |  | $ | 25,718 |  |  | $ | 27,882 |  |
| Commercial |  |  | 17,536 |  |  |  | 14,938 |  |  |  | 50,881 |  |  |  | 42,902 |  |
| RF&S Components |  |  | 453 |  |  |  | 404 |  |  |  | 1,319 |  |  |  | 1,290 |  |
| Segment total |  |  | 25,974 |  |  |  | 24,210 |  |  |  | 77,918 |  |  |  | 72,074 |  |
| Corporate |  |  | 1,606 |  |  |  | 3,620 |  |  |  | 4,217 |  |  |  | 6,635 |  |
| Total |  | $ | 27,580 |  |  | $ | 27,830 |  |  | $ | 82,135 |  |  | $ | 78,709 |  |

[0001193125-25-260708:notes:36]
The Company markets and sells its products in approximately 50 countries. For the quarter and three quarters ended September 29, 2025, the Company did not conduct business in any country other than the United States in which its net sales in that country exceeded 10% of the Company’s total net sales. For the quarter and three quarters ended September 30, 2024, net sales in Taiwan also exceeded 10% of the Company’s total net sales. Net sales are attributed to countries by the invoiced location and were as follows:

[0001193125-25-260708:notes:37]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2025 |  |  | September 30, 2024 |  |  | September 29, 2025 |  |  | September 30, 2024 |  |
|  |  | (In thousands) |  |
| United States |  | $ | 407,222 |  |  | $ | 316,508 |  |  | $ | 1,146,649 |  |  | $ | 926,241 |  |
| Taiwan |  |  | 62,384 |  |  |  | 63,607 |  |  |  | 167,396 |  |  |  | 206,462 |  |
| Other |  |  | 283,130 |  |  |  | 236,423 |  |  |  | 817,980 |  |  |  | 659,085 |  |
| Total net sales |  | $ | 752,736 |  |  | $ | 616,538 |  |  | $ | 2,132,025 |  |  | $ | 1,791,788 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-25-260708:notes:38]
[same as prior period, unchanged from 0000950170-25-102042:notes:27]

[0001193125-25-260708:notes:39]
|  |  | As of |  |
|  |  | September 29, 2025 |  |  | December 30, 2024 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 198,073 |  |  | $ | 178,066 |  |
| Work-in-process |  |  | 50,840 |  |  |  | 45,580 |  |
| Finished goods |  |  | 4,774 |  |  |  | 1,339 |  |
| Inventories |  | $ | 253,687 |  |  | $ | 224,985 |  |
| Property, plant, and equipment, net: |  |  |  |  |  |  |
| Land and land-use rights |  | $ | 70,075 |  |  | $ | 69,788 |  |
| Buildings and improvements |  |  | 554,679 |  |  |  | 515,773 |  |
| Machinery and equipment |  |  | 1,181,531 |  |  |  | 1,116,658 |  |
| Furniture and fixtures and other |  |  | 11,492 |  |  |  | 11,115 |  |
| Construction-in-progress |  |  | 156,982 |  |  |  | 75,502 |  |
| Property, plant, and equipment, gross |  |  | 1,974,759 |  |  |  | 1,788,836 |  |
| Less: Accumulated depreciation |  |  | (982,566 | ) |  |  | (918,879 | ) |
| Property, plant, and equipment, net |  | $ | 992,193 |  |  | $ | 869,957 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | $ | 22,395 |  |  | $ | 15,919 |  |
| Sales return and allowances |  |  | 12,668 |  |  |  | 10,777 |  |
| Accrued facility operating costs |  |  | 11,000 |  |  |  | 8,925 |  |
| Warranty |  |  | 10,223 |  |  |  | 7,685 |  |
| Housing fund |  |  | 8,515 |  |  |  | 7,927 |  |
| Operating leases |  |  | 8,326 |  |  |  | 7,556 |  |
| Interest |  |  | 3,867 |  |  |  | 9,054 |  |
| Accrued professional fees |  |  | 3,212 |  |  |  | 3,606 |  |
| Other |  |  | 34,340 |  |  |  | 48,525 |  |
| Other current liabilities |  | $ | 114,546 |  |  | $ | 119,974 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 42,835 |  |  | $ | 41,362 |  |
| Customer deposits |  |  | 30,105 |  |  |  | 28,390 |  |
| Finance leases |  |  | 15,916 |  |  |  | 11,985 |  |
| Other |  |  | 27,652 |  |  |  | 26,011 |  |
| Other long-term liabilities |  | $ | 116,508 |  |  | $ | 107,748 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-25-260708:notes:40]
(6) Goodwill and Definite-lived Intangibles

[0001193125-25-260708:notes:41]
Goodwill

[0001193125-25-260708:notes:42]
In connection with the Company’s assessment of its operating segments, effective during the quarter ended June 30, 2025, the Company determined that its operating segments were also its reporting units and reallocated its PCB goodwill between A&D and Commercial based on the estimated relative fair values of the reporting units. In connection with the reallocation of goodwill, management performed a goodwill impairment assessment for each segment and concluded no impairment indicators as of June 30, 2025.

[0001193125-25-260708:notes:43]
Goodwill by reportable segment was as follows:

[0001193125-25-260708:notes:44]
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| As of September 29, 2025 and December 30, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 256,199 |  |  | $ | 382,636 |  |  | $ | 177,200 |  |  | $ | 816,035 |  |
| Accumulated impairment losses |  |  | — |  |  |  | — |  |  |  | (145,900 | ) |  |  | (145,900 | ) |
| Carrying amount |  | $ | 256,199 |  |  | $ | 382,636 |  |  | $ | 31,300 |  |  | $ | 670,135 |  |

[0001193125-25-260708:notes:45]
Definite-lived Intangibles

[0001193125-25-260708:notes:46]
The components of definite-lived intangibles were as follows:

[0001193125-25-260708:notes:47]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| As of September 29, 2025 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 323,500 |  |  | $ | (182,376 | ) |  | $ | 141,124 |  |  |  | 11.8 |  |
| Technology |  |  | 66,650 |  |  |  | (43,628 | ) |  |  | 23,022 |  |  |  | 8.2 |  |
| Total |  | $ | 390,150 |  |  | $ | (226,004 | ) |  | $ | 164,146 |  |  |  |  |
| As of December 30, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 323,500 |  |  | $ | (161,710 | ) |  | $ | 161,790 |  |  |  | 11.8 |  |
| Technology |  |  | 66,650 |  |  |  | (36,621 | ) |  |  | 30,029 |  |  |  | 8.2 |  |
| Total |  | $ | 390,150 |  |  | $ | (198,331 | ) |  | $ | 191,819 |  |  |  |  |

[0001193125-25-260708:notes:48]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $9,225 and $27,673 for the quarter and three quarters ended September 29, 2025, respectively, and $9,286 and $35,642 for the quarter and three quarters ended September 30, 2024, respectively. For the quarter and three quarters ended September 29, 2025, $2,336 and $7,007, respectively, of amortization expense was included in cost of goods sold. For the quarter and three quarters ended September 30, 2024, $2,335 and $7,006, respectively, of amortization expense was included in cost of goods sold.

[0001193125-25-260708:notes:49]
Estimated aggregate amortization for definite-lived intangible assets for the next five years and thereafter is as follows:

[0001193125-25-260708:notes:50]
|  |  | (In thousands) |  |
| Remaining 2025 |  | $ | 9,224 |  |
| 2026 |  |  | 36,897 |  |
| 2027 |  |  | 34,543 |  |
| 2028 |  |  | 30,997 |  |
| 2029 |  |  | 22,355 |  |
| Thereafter |  |  | 30,130 |  |
| Total |  | $ | 164,146 |  |


## us-gaap:LongTermDebtTextBlock

[0001193125-25-260708:notes:51]
(7) Long-term Debt and Letters of Credit

[0001193125-25-260708:notes:52]
Long-term debt was as follows:

[0001193125-25-260708:notes:53]
|  |  | As of |  |
|  |  | September 29, 2025 |  |  | December 30, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 6.38 |  |  |  |  | 343,035 |  |  |  | 6.59 |  |  |  |  | 345,634 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 5.43 |  |  |  |  | 80,000 |  |  |  | 5.64 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 2,065 |  |  |  | 5.99 |  |  |  |  | 2,311 |  |
| Total debt |  |  |  |  |  |  | 925,100 |  |  |  |  |  |  |  | 927,945 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (5,957 | ) |  |  |  |  |  |  | (6,951 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,498 | ) |  |  |  |  |  |  | (2,840 | ) |
| Subtotal |  |  |  |  |  |  | 916,645 |  |  |  |  |  |  |  | 918,154 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,810 | ) |  |  |  |  |  |  | (3,795 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 912,835 |  |  |  |  |  |  | $ | 914,359 |  |

[0001193125-25-260708:notes:54]
Debt Covenants

[0001193125-25-260708:notes:55]
Borrowings under the Senior Notes due 2029 and Term Loan Facility due 2030 (Term Loan Facility) are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

[0001193125-25-260708:notes:56]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans) are subject to various financial covenants, including leverage and fixed-charge coverage ratios.

[0001193125-25-260708:notes:57]
Debt Issuance Costs and Debt Discount

[0001193125-25-260708:notes:58]
Remaining unamortized debt issuance costs and debt discount were as follows:

[0001193125-25-260708:notes:59]
|  |  | As of |
|  |  | September 29, 2025 |  | December 30, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 2,799 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 3,362 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,158 |  |  |  | 2,498 |  |  |  | 8.01 |  |  |  |  | 3,589 |  |  |  | 2,840 |  |  |  | 8.01 |  |  |
| Total |  | $ | 5,957 |  |  | $ | 2,498 |  |  |  |  |  |  | $ | 6,951 |  |  | $ | 2,840 |  |  |  |  |  |

[0001193125-25-260708:notes:60]
The above debt issuance costs and debt discount are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001193125-25-260708:notes:61]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $966 and $1,239 as of September 29, 2025 and December 30, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0001193125-25-260708:notes:62]
As of September 29, 2025, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 4.1 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-25-260708:notes:63]
(8) Income Taxes

[0001193125-25-260708:notes:64]
[same as prior period, unchanged from 0000950170-25-102042:notes:52]

[0001193125-25-260708:notes:65]
During the quarter and three quarters ended September 29, 2025, the Company’s effective tax rate was impacted by a net discrete benefit of $37 and $3,321, respectively, and the One Big Beautiful Bill Act (OBBBA) tax impact, as discussed below. The net discrete benefit was primarily related to the deduction of stock‑based compensation, partially offset by accruals for potential assessments and uncertain tax positions in various jurisdictions.

[0001193125-25-260708:notes:66]
[same as prior period, unchanged from 0000950170-25-102042:notes:54]

[0001193125-25-260708:notes:67]
OBBBA

[0001193125-25-260708:notes:68]
On July 4, 2025, the OBBBA was enacted, introducing amendments to U.S. tax laws with various effective dates from 2025 to 2027. The OBBBA includes provisions such as the permanent extension of certain provisions of the Tax Cuts and Jobs Act that were set to expire at the end of 2025 and modifications to the international tax framework. Because Topic 740 requires the effects of changes in tax rates and laws on deferred tax balances to be recognized in the period in which the legislation is enacted, the Company’s tax provisions for the quarter and three quarters ended September 29, 2025 incorporated the estimated effects of the tax law changes including the accelerated depreciation of qualified property and the immediate expensing of U.S. research and development expenditure paid or incurred for tax years beginning after December 31, 2024. The Company recorded a $5,186 benefit from the decrease in the U.S. valuation allowance resulting from the OBBBA impact to its deferred tax assets.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-25-260708:notes:69]
(9) Earnings Per Share, Share Repurchase Program, and Accumulated Other Comprehensive Loss

[0001193125-25-260708:notes:70]
Earnings Per Share

[0001193125-25-260708:notes:71]
The reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share is as follows:

[0001193125-25-260708:notes:72]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2025 |  |  | September 30, 2024 |  |  | September 29, 2025 |  |  | September 30, 2024 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income |  | $ | 53,055 |  |  | $ | 14,311 |  |  | $ | 126,763 |  |  | $ | 51,129 |  |
| Basic weighted average shares |  |  | 103,321 |  |  |  | 101,958 |  |  |  | 102,337 |  |  |  | 101,704 |  |
| Dilutive effect of performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock options |  |  | 2,491 |  |  |  | 1,870 |  |  |  | 2,724 |  |  |  | 2,224 |  |
| Diluted shares |  |  | 105,812 |  |  |  | 103,828 |  |  |  | 105,061 |  |  |  | 103,928 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 0.51 |  |  | $ | 0.14 |  |  | $ | 1.24 |  |  | $ | 0.50 |  |
| Diluted earnings per share |  |  | 0.50 |  |  |  | 0.14 |  |  |  | 1.21 |  |  |  | 0.49 |  |

[0001193125-25-260708:notes:73]
PRUs and RSUs to purchase 161 and 220 shares of common stock for the quarter and three quarters ended September 29, 2025, respectively, and PRUs, RSUs, and stock options to purchase 144 and 166 shares of common stock for the quarter and three quarters ended September 30, 2024, respectively, were not included in the computation of diluted earnings per share because the impact would be anti-dilutive. The PRUs would have had an anti-dilutive impact because the performance conditions had not been met during the applicable quarter and three quarters. The RSUs and stock options would have had an anti-dilutive impact because the total expected proceeds under the treasury stock method or the options’ exercise prices were greater than the average market price of common stock during the applicable quarter and three quarters.

[0001193125-25-260708:notes:74]
Share Repurchase Program

[0001193125-25-260708:notes:75]
On May 8, 2025, the Company's Board of Directors authorized a new share repurchase program (2025 Repurchase Program), under which the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through May 7, 2027. The Company’s previous two-year repurchase program expired on May 3, 2025. The Company may repurchase shares through open market purchases, privately‑negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (Exchange Act), which sets certain restrictions on the method, timing, price, and volume of open market stock repurchases. In addition, the Company adopted one trading plan in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price, and amount of any repurchases will be determined at the Company’s discretion, and the share repurchase program may be suspended, terminated, or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.

[0001193125-25-260708:notes:76]
During the quarter ended September 29, 2025, the Company did not repurchase any shares. During the three quarters ended September 29, 2025, the Company repurchased 700 shares of common stock for a total cost of $17,875 (including commissions) under the Company’s previous repurchase program. As of September 29, 2025, the remaining amount in value available to be repurchased under the 2025 Repurchase Program was $100,000.

[0001193125-25-260708:notes:77]
Accumulated Other Comprehensive Loss

[0001193125-25-260708:notes:78]
The components of accumulated other comprehensive loss, net of tax, were as follows:

[0001193125-25-260708:notes:79]
|  |  | As of |  |
|  |  | September 29, 2025 |  |  | December 30, 2024 |  |
|  |  | (In thousands) |  |
| Foreign currency translation |  | $ | (33,549 | ) |  | $ | (33,757 | ) |
| Pension obligation |  |  | 4,786 |  |  |  | 3,612 |  |
| Cash flow hedges |  |  | 31 |  |  |  | 2,263 |  |
| Total |  | $ | (28,732 | ) |  | $ | (27,882 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-25-260708:notes:80]
(10) Fair Value Measures

[0001193125-25-260708:notes:81]
[same as prior period, unchanged from 0000950170-25-102042:notes:79]

[0001193125-25-260708:notes:82]
[same as prior period, unchanged from 0000950170-25-102042:notes:80]

[0001193125-25-260708:notes:83]
|  |  | As of |  |
|  |  | September 29, 2025 |  |  | December 30, 2024 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 1,666 |  |  | $ | 1,666 |  |  | $ | 1,765 |  |  | $ | 1,765 |  |
| Derivative assets, non-current |  |  | — |  |  |  | — |  |  |  | 1,326 |  |  |  | 1,326 |  |
| Derivative liabilities, current |  |  | — |  |  |  | — |  |  |  | 667 |  |  |  | 667 |  |
| Derivative liabilities, non-current |  |  | 429 |  |  |  | 429 |  |  |  | — |  |  |  | — |  |
| Senior Notes due March 2029 |  |  | 497,201 |  |  |  | 481,695 |  |  |  | 496,638 |  |  |  | 464,325 |  |
| Term Loan due May 2030 |  |  | 337,379 |  |  |  | 344,966 |  |  |  | 339,205 |  |  |  | 346,930 |  |
| ABL Revolving Loans |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |
| Other loan |  |  | 2,065 |  |  |  | 2,065 |  |  |  | 2,311 |  |  |  | 2,311 |  |

[0001193125-25-260708:notes:84]
[same as prior period, unchanged from 0000950170-25-102042:notes:82]

[0001193125-25-260708:notes:85]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of September 29, 2025 and December 30, 2024, which are considered Level 2 inputs.

[0001193125-25-260708:notes:86]
As of September 29, 2025 and December 30, 2024, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value.

[0001193125-25-260708:notes:87]
[same as prior period, unchanged from 0000950170-25-102042:notes:85]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-25-260708:notes:88]
(11) Commitments and Contingencies

[0001193125-25-260708:notes:89]
Legal Matters

[0001193125-25-260708:notes:90]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 29, 2025 and December 30, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0001193125-25-260708:notes:91]
Supplier Finance Program Obligations

[0001193125-25-260708:notes:92]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $12,195 and $17,218 as of September 29, 2025 and December 30, 2024, respectively.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001193125-25-260708:notes:93]
During the quarter ended September 29, 2025, our directors and/or officers (as defined in Rule 16a-1(f) under the Exchange Act) adopted or terminated the contracts, instructions, or written plans for the purchase or sale of our securities set forth in the table below.

[0001193125-25-260708:notes:94]
| Name and Title |  | Action |  | Adoption / Termination Date |  | Rule 10b5-1 (1) |  | Non-Rule 10b5-1 (2) |  | Total Number of Shares of Common Stock to be Sold (3) |  | Expiration Date |
| Daniel L. Boehle(Executive Vice President and CFO) |  | Adoption |  | August 8, 2025 |  | X |  |  |  | Indeterminable (4) |  | August 31, 2026 |
| Thomas Clapprood(President, Radar Systems and Sensors Business Unit) |  | Adoption |  | August 27, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Thomas T. Edman(Director) |  | Adoption |  | August 20, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Thomas T. Edman(Director) |  | Adoption |  | August 25, 2025 |  | X |  |  |  | Up to 84,000 |  | May 29, 2026 |
| Robert Farrell(President, Communication and Computing Business Unit) |  | Adoption |  | August 15, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Catherine A. Gridley(Executive Vice President and President, Aerospace & Defense Sector) |  | Adoption |  | August 27, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Dale Knecht(Senior Vice President of Global Information Technology) |  | Adoption |  | August 8, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Shawn Powers(Executive Vice President and Chief Human Resources Officer) |  | Adoption |  | August 29, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |

[0001193125-25-260708:notes:95]
| Name and Title |  | Action |  | Adoption / Termination Date |  | Rule 10b5-1 (1) |  | Non-Rule 10b5-1 (2) |  | Total Number of Shares of Common Stock to be Sold (3) |  | Expiration Date |
| Shawn Powers(Executive Vice President and Chief Human Resources Officer) |  | Adoption |  | August 29, 2025 |  | X |  |  |  | Up to 15,000 |  | November 30, 2026 |
| Douglas L. Soder(Executive Vice President and President, Commercial Sector) |  | Adoption |  | August 21, 2025 |  | X |  |  |  | Up to 25,000 |  | November 30, 2026 |
| Douglas L. Soder(Executive Vice President and President, Commercial Sector) |  | Adoption |  | August 21, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Steven Spoto (President, Integrated Electronics Business Unit) |  | Adoption |  | August 22, 2025 |  | X |  |  |  | Indeterminable (4) |  | August 12, 2026 |
| James P. Walsh (Chief Operating Officer) |  | Adoption |  | August 11, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |
| Daniel J. Weber(Executive Vice President, Chief Legal Officer and Secretary) |  | Adoption |  | August 6, 2025 |  | X |  |  |  | Indeterminable (4) |  | June 30, 2026 |

[0001193125-25-260708:notes:96]
(1)
Contract, instruction, or written plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act.

[0001193125-25-260708:notes:97]
(2)
“Non-Rule 10b5-1 trading arrangement” as defined in Item 408(c) of Regulation S-K under the Exchange Act.

[0001193125-25-260708:notes:98]
(3)
Represents the maximum number of shares that may be sold pursuant to the 10b5-1 arrangement. The number of shares sold will be dependent on the satisfaction of certain conditions as set forth in the trading plan.

[0001193125-25-260708:notes:99]
(4)
Rule 10b5-1 trading arrangement that is intended to provide for “eligible sell-to-cover transactions” (as described in Rule 10b5-1(c)(1)(ii)(D)(3) under the Exchange Act) to satisfy tax withholding obligations arising exclusively from vesting of RSUs or PRUs. The number of shares subject to covered RSUs or PRUs that will be sold to satisfy applicable tax withholding obligations upon vesting is not currently determinable as the number will vary based on the market price of our common stock and the extent to which vesting conditions are satisfied. This sell-to-cover arrangement provides solely for the automatic sale of shares that would otherwise be issuable in respect of a covered RSU or PRU in an amount sufficient to satisfy the applicable withholding obligation, with the proceeds of the sale delivered to the Company in satisfaction of the applicable withholding obligation.
