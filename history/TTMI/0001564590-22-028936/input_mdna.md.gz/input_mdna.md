# TTMI MD&A — 0001564590-22-028936


## mdna

[0001564590-22-028936:mdna:1]
[same as prior period, unchanged from 0001564590-22-019520:mdna:1]

[0001564590-22-028936:mdna:2]
[same as prior period, unchanged from 0001564590-22-019520:mdna:2]

[0001564590-22-028936:mdna:3]
We are a leading global manufacturer of technology solutions including engineered systems, radio frequency (RF) components and RF microwave/microelectronic assemblies, and printed circuit boards (PCB). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering, and manufacturing solution to our customers. This one-stop design, engineering, and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,000 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-22-028936:mdna:4]
[same as prior period, unchanged from 0001564590-22-019520:mdna:4]

[0001564590-22-028936:mdna:5]
On June 27, 2022, we completed our acquisition of all of the issued and outstanding common stock of Gritel Holding Co., Inc. (Gritel) and ISC Farmingdale Corp. for a preliminary total consideration of $299.2 million in cash. Telephonics Corporation is wholly-owned by Gritel, and as a result of the acquisition, became an indirect, wholly-owned subsidiary of the Company (collectively with ISC Farmingdale Corp., Telephonics). Telephonics is recognized globally as a leading provider of highly sophisticated military intelligence, surveillance and communications solutions that are deployed across a wide range of land, sea, and air applications. Because the acquisition closed shortly prior to the end of our second fiscal quarter, the results of operations of Telephonics since the acquisition date were not material to our consolidated condensed financial statements.

[0001564590-22-028936:mdna:6]
On March 1, 2022, we announced that we will open a new highly automated PCB manufacturing facility in Penang, Malaysia. We recently commenced construction, which we expect will take 12 to 15 months, with equipment installation in late 2023. We expect that the total capital spending for this facility will be approximately $130.0 million and this investment will be spread from 2022 through 2025.

[0001564590-22-028936:mdna:7]
The coronavirus (COVID-19) pandemic initially caused business disruption to our operations in China in January 2020. By March 2020, the situation escalated as the scope of the COVID-19 pandemic worsened outside of the Asia-Pacific region, with Europe and North America being affected by the pandemic. With the development and deployment of vaccines, certain of the adverse societal and economic effects of the pandemic have declined. However, as new variants of the virus emerge and evolve, we could see a rebound in the severity of the adverse effects of the pandemic. As a result, we expect continued impacts on our production, as well as ongoing significant uncertainty relating to the actual and potential impacts of the COVID-19 pandemic, and we cannot reasonably estimate its duration or severity. For example, during the first quarter of the 2022 fiscal year, an outbreak in Mainland China forced temporary lockdown orders in several cities in which we operate. Further, in North America, there was a surge in cases resulting from the Omicron variant from December 2021 through January 2022 which resulted in production inefficiencies caused by a combination of quarantine impacts and direct labor shortages on our overall production. The COVID-19 pandemic has created and continues to create various global macroeconomic, customer demand, operational and supply chain risks and has contributed to high inflation, each of which could have a material and adverse impact on our business going forward. See Item 1A, Risk Factors, of Part II below for further information related to the COVID-19 pandemic.

[0001564590-22-028936:mdna:8]
[same as prior period, unchanged from 0001564590-22-019520:mdna:6]

[0001564590-22-028936:mdna:9]
[same as prior period, unchanged from 0001564590-22-019520:mdna:7]

[0001564590-22-028936:mdna:10]
We also continue to see challenges in attracting and retaining labor in North America. We actively seek to demonstrate employees’ value to our business through a combination of financial and non-financial methods. However, a number of factors may continue to adversely affect the labor force available to us, including high employment levels, government regulations, and wage inflation. An overall labor shortage, lack of skilled labor, increased turnover or labor inflation could have a material adverse impact on our business.

[0001564590-22-028936:mdna:11]
[same as prior period, unchanged from 0001564590-22-019520:mdna:12]

[0001564590-22-028936:mdna:12]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 41% and 43% of our net sales for the quarter and two quarters ended July 4, 2022, respectively. Sales to our ten largest customers accounted for 40% and 42% of our net sales for the quarter and two quarters ended June 28, 2021, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-22-028936:mdna:13]
[same as prior period, unchanged from 0001564590-22-019520:mdna:14]

[0001564590-22-028936:mdna:14]
|  |  | Quarter Ended |  |  |  | Two Quarters Ended |  |  |
| End Markets (1) |  | July 4, 2022 |  |  |  | June 28, 2021 |  |  |  | July 4, 2022 |  |  |  | June 28, 2021 |  |  |
| Aerospace and Defense |  |  | 30 |  | % |  |  | 33 |  | % |  |  | 30 |  | % |  |  | 34 |  | % |
| Automotive |  |  | 18 |  |  |  |  | 18 |  |  |  |  | 19 |  |  |  |  | 18 |  |  |
| Data Center Computing |  |  | 17 |  |  |  |  | 14 |  |  |  |  | 16 |  |  |  |  | 14 |  |  |
| Medical/Industrial/Instrumentation |  |  | 21 |  |  |  |  | 19 |  |  |  |  | 21 |  |  |  |  | 18 |  |  |
| Networking/Communications |  |  | 14 |  |  |  |  | 15 |  |  |  |  | 14 |  |  |  |  | 15 |  |  |
| Other (2) |  |  | — |  |  |  |  | 1 |  |  |  |  | — |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-22-028936:mdna:15]
[same as prior period, unchanged from 0001564590-22-019520:mdna:16]

[0001564590-22-028936:mdna:16]
[same as prior period, unchanged from 0001564590-22-019520:mdna:17]

[0001564590-22-028936:mdna:17]
[same as prior period, unchanged from 0001564590-22-019520:mdna:18]

[0001564590-22-028936:mdna:18]
[same as prior period, unchanged from 0001564590-22-019520:mdna:19]

[0001564590-22-028936:mdna:19]
[same as prior period, unchanged from 0001564590-22-019520:mdna:20]

[0001564590-22-028936:mdna:20]
[same as prior period, unchanged from 0001564590-22-019520:mdna:21]

[0001564590-22-028936:mdna:21]
[same as prior period, unchanged from 0001564590-22-019520:mdna:22]

[0001564590-22-028936:mdna:22]
[same as prior period, unchanged from 0001564590-22-019520:mdna:23]

[0001564590-22-028936:mdna:23]
[same as prior period, unchanged from 0001564590-22-019520:mdna:24]

[0001564590-22-028936:mdna:24]
[same as prior period, unchanged from 0001564590-22-019520:mdna:26]

[0001564590-22-028936:mdna:25]
[same as prior period, unchanged from 0001564590-22-019520:mdna:27]

[0001564590-22-028936:mdna:26]
[same as prior period, unchanged from 0001564590-22-019520:mdna:28]

[0001564590-22-028936:mdna:27]
[same as prior period, unchanged from 0001564590-22-019520:mdna:29]

[0001564590-22-028936:mdna:28]
[same as prior period, unchanged from 0001564590-22-019520:mdna:30]

[0001564590-22-028936:mdna:29]
|  |  | Quarter Ended |  | Two Quarters Ended |
|  |  | July 4, 2022 |  |  |  | June 28, 2021 |  |  |  | July 4, 2022 |  |  |  | June 28, 2021 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 81.3 |  |  |  |  | 82.4 |  |  |  |  | 82.8 |  |  |  |  | 83.4 |  |  |
| Gross profit |  |  | 18.7 |  |  |  |  | 17.6 |  |  |  |  | 17.2 |  |  |  |  | 16.6 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.8 |  |  |  |  | 2.6 |  |  |  |  | 2.9 |  |  |  |  | 2.8 |  |  |
| General and administrative |  |  | 7.8 |  |  |  |  | 5.5 |  |  |  |  | 6.8 |  |  |  |  | 5.7 |  |  |
| Research and development |  |  | 0.9 |  |  |  |  | 0.7 |  |  |  |  | 0.9 |  |  |  |  | 0.8 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.3 |  |  |  |  | 1.6 |  |  |  |  | 1.4 |  |  |  |  | 1.7 |  |  |
| Total operating expenses |  |  | 12.8 |  |  |  |  | 10.4 |  |  |  |  | 12.0 |  |  |  |  | 11.0 |  |  |
| Operating income |  |  | 5.9 |  |  |  |  | 7.2 |  |  |  |  | 5.2 |  |  |  |  | 5.6 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (1.7 | ) |  |  |  | (2.0 | ) |  |  |  | (1.8 | ) |  |  |  | (2.1 | ) |  |
| Loss on extinguishment of debt |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |  |  | (1.4 | ) |  |
| Other, net |  |  | 1.3 |  |  |  |  | 0.1 |  |  |  |  | 0.8 |  |  |  |  | 0.3 |  |  |
| Total other expense, net |  |  | (0.4 | ) |  |  |  | (1.9 | ) |  |  |  | (1.0 | ) |  |  |  | (3.2 | ) |  |
| Income before income taxes |  |  | 5.5 |  |  |  |  | 5.3 |  |  |  |  | 4.2 |  |  |  |  | 2.4 |  |  |
| Income tax provision |  |  | (1.1 | ) |  |  |  | (0.3 | ) |  |  |  | (0.5 | ) |  |  |  | (0.1 | ) |  |
| Net income |  |  | 4.4 |  | % |  |  | 5.0 |  | % |  |  | 3.7 |  | % |  |  | 2.3 |  | % |

[0001564590-22-028936:mdna:30]
[same as prior period, unchanged from 0001564590-22-019520:mdna:32]

[0001564590-22-028936:mdna:31]
Total net sales increased $58.2 million, or 10.3%, to $625.6 million for the second quarter of 2022 from $567.4 million for the second quarter of 2021. The primary driver for the increase in total net sales was an increase in net sales for the PCB reportable segment of $55.9 million, or 10.1%, to $609.4 million for the second quarter of 2022 from $553.5 million for the second quarter of 2021, which was primarily due to strong growth in most of our commercial end markets. The increase in PCB net sales also benefitted from an 18.6% increase in the average price per square foot driven mainly by better pricing, higher levels of quick-turn revenue and a favorable shift in product mix, partially offset by a 7.3% decrease in the volume of PCB shipments as compared to the second quarter of 2021. Additionally, there was an increase in net sales for the RF&S Components reportable segment of $2.2 million, or 16.0%, to $16.1 million for the second quarter of 2022 from $13.9 million for the second quarter of 2021, which was primarily due to higher demand in our Networking/Communications end market.

[0001564590-22-028936:mdna:32]
Total net sales increased $113.0 million, or 10.3%, to $1,206.8 million for the first two quarters of 2022 from $1,093.8 million for the first two quarters of 2021. This increase in total net sales primarily resulted from an increase in net sales for the PCB reportable segment of $111.5 million, or 10.5%, to $1,175.4 million for the first two quarters of 2022 from $1,064.0 million for the first two quarters of 2021 primarily due to strong growth in most of our commercial end markets, partially offset by lower demand in our Aerospace and Defense end market. The increase in PCB net sales also benefitted from an 11.0% increase in the average price per square foot driven mainly by better pricing, higher levels of quick-turn revenue and a favorable shift in product mix. Volume was essentially unchanged. Additionally, there was an increase in net sales for the RF&S Components reportable segment of $4.7 million, or 17.7%, to $31.3 million for the first two quarters of 2022 from $26.6 million for the first two quarters of 2021 primarily due to higher demand in our Networking/Communications end market.

[0001564590-22-028936:mdna:33]
[same as prior period, unchanged from 0001564590-22-019520:mdna:34]

[0001564590-22-028936:mdna:34]
Overall gross margin increased to 18.7% for the second quarter of 2022 from 17.6% for the second quarter of 2021. Gross margin for the PCB reportable segment increased to 19.6% for the second quarter of 2022 from 17.4% for the second quarter of 2021. This increase was primarily due to price increases, higher levels of quick-turn revenue, higher sales, and improved product mix, partially offset by higher labor and material costs. Gross margin for the RF&S Components reportable segment increased to 60.2% for the second quarter of 2022 from 52.4% for the second quarter of 2021, primarily due to higher sales.

[0001564590-22-028936:mdna:35]
Overall gross margin increased to 17.2% for the first two quarters of 2022 from 16.6% for the first two quarters of 2021. Gross margin for the PCB reportable segment increased to 17.2% for the first two quarters of 2022 from 16.6% for the first two quarters of 2021. This increase was primarily due to price increases, higher levels of quick-turn revenue, higher sales, and improved product mix, partially offset by higher labor and material costs. Gross margin for the RF&S Components reportable segment increased to 60.3% for the first two quarters of 2022 from 52.0% for the first two quarters of 2021, primarily due to higher sales.

[0001564590-22-028936:mdna:36]
Capacity utilization is a key driver for us, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the second quarter of 2022 in our Asia and North America PCB facilities was 88% and 42%, respectively, compared to 88% and 49%, respectively, for the second quarter of 2021. Capacity utilization for the first two quarters of 2022 in our Asia and North America PCB facilities was 86% and 44%, respectively, compared to 84% and 52%, respectively, for the first two quarters of 2021. The increase in capacity utilization in our Asia PCB facilities during the first two quarters of 2022 was due to an increase in production resulting from increased sales in our commercial end markets. The decrease in our capacity utilization in our North America PCB facilities was primarily due to increased capacity resulting from additional plating capacity, bottlenecks in non-plating processes and direct labor shortages in certain regions.

[0001564590-22-028936:mdna:37]
[same as prior period, unchanged from 0001564590-22-019520:mdna:38]

[0001564590-22-028936:mdna:38]
Selling and marketing expense increased $3.0 million, to $17.6 million for the second quarter of 2022 from $14.6 million for the second quarter of 2021. As a percentage of net sales, selling and marketing expense was 2.8% for the second quarter of 2022, as compared to 2.6% for the second quarter of 2021. The increase in selling and marketing expenses was primarily due to an increase in commission expense and labor costs.

[0001564590-22-028936:mdna:39]
Selling and marketing expenses increased $4.9 million, to $35.8 million for the first two quarters of 2022 from $30.9 million for the first two quarters of 2021. As a percentage of net sales, selling and marketing expenses was 2.9% for the first two quarters of 2022, as compared to 2.8% for the first two quarters of 2021. The increase in selling and marketing expense for the first two quarters of 2022 was primarily due to an increase in commission expense and labor costs.

[0001564590-22-028936:mdna:40]
[same as prior period, unchanged from 0001564590-22-019520:mdna:40]

[0001564590-22-028936:mdna:41]
General and administrative expense increased $17.6 million to $48.8 million, or 7.8% of net sales, for the second quarter of 2022 from $31.2 million, or 5.5% of net sales, for the second quarter of 2021. The increase in expense primarily resulted from $9.9 million of costs incurred in connection with the acquisition of Telephonics on June 27, 2022. In addition, there were increases in labor costs, incentive compensation, and other general and administrative spending.

[0001564590-22-028936:mdna:42]
General and administrative expenses increased $19.0 million to $81.8 million, or 6.8% of net sales, for the first two quarters of 2022 from $62.7 million, or 5.7% of net sales, for the first two quarters of 2021. The increase in expense primarily resulted from $10.7 million of costs incurred in connection with the acquisition of Telephonics on June 27, 2022. In addition, there were increases in labor costs, incentive compensation, bad debt, and other general and administrative spending. These increases were partially offset by the decrease in restructuring charges of $3.2 million associated with the restructuring of our E-M Solutions business unit during the first two quarters of 2021.

[0001564590-22-028936:mdna:43]
[same as prior period, unchanged from 0001564590-22-019520:mdna:42]

[0001564590-22-028936:mdna:44]
Other expense, net decreased $7.7 million to $3.1 million for the second quarter of 2022 from $10.8 million for the second quarter of 2021. This decrease was primarily the result of foreign currency gains due to the weakening of the Chinese Renminbi (RMB) in the second quarter of 2022 compared to the second quarter of 2021. We utilize the RMB at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China.

[0001564590-22-028936:mdna:45]
Other expense, net decreased $22.4 million to $12.5 million for the first two quarters of 2022 from $34.9 million for the first two quarters of 2021. This decrease was primarily the result of the absence of $15.2 million of loss on extinguishment of debt. In addition, there were foreign currency gains due to the weakening of the RMB in the first two quarters of 2022 compared to the first two quarters of 2021, partially offset by lower government subsidies.

[0001564590-22-028936:mdna:46]
[same as prior period, unchanged from 0001564590-22-019520:mdna:44]

[0001564590-22-028936:mdna:47]
Income tax expense increased by $4.5 million to $6.3 million of tax expense for the second quarter of 2022 from $1.8 million of tax expense for the second quarter of 2021. The increase in income tax expense for the second quarter of 2022 was primarily due

[0001564590-22-028936:mdna:48]
to an increase in pre-tax income and a lower uncertain tax position release benefit, which resulted from the expiration of the statute of limitation in foreign jurisdictions.

[0001564590-22-028936:mdna:49]
Income tax expense increased by $4.8 million to $5.6 million of tax expense for the first two quarters of 2022 from $0.8 million of tax expense for the first two quarters of 2021. The increase in income tax expense for the first two quarters of 2022 was primarily due to an increase in pre-tax income for the first two quarters of 2022 and a lower uncertain tax position release benefit, which resulted from the expiration of the statute of limitation in foreign jurisdictions, partially offset by the approval of the Company’s renewal application for High and New Enterprise status for two of the Company’s manufacturing subsidiaries in China in the current year.

[0001564590-22-028936:mdna:50]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax liability of approximately $20.7 million and a net deferred income tax asset of approximately $15.2 million as of July 4, 2022 and June 28, 2021, respectively. The decrease in the deferred income tax asset was primarily due to recording of a deferred income tax liability of $27.9 million related to the tax impact of the Telephonics’ opening balance sheet.

[0001564590-22-028936:mdna:51]
[same as prior period, unchanged from 0001564590-22-019520:mdna:47]

[0001564590-22-028936:mdna:52]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our Revolving Credit Facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, to repay debt obligations, and to repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, and servicing debt will be the principal demands on our cash in the future.

[0001564590-22-028936:mdna:53]
Cash flow provided by operating activities during the first two quarters of 2022 was $115.3 million as compared to cash flow provided by operating activities of $98.1 million in the same period in 2021. The increase in cash flow was primarily due to an increase in net income of $20.0 million.

[0001564590-22-028936:mdna:54]
Net cash used in investing activities was approximately $349.0 million for the first two quarters of 2022, primarily reflecting $299.2 million for the acquisition of Telephonics and $49.9 million for purchases of property, plant and equipment and other assets. Net cash used in investing activities was approximately $43.7 million for the first two quarters of 2021, reflecting $44.6 million for purchases of property, plant and equipment and other assets less $0.9 million for proceeds from sale of property, plant and equipment and other assets.

[0001564590-22-028936:mdna:55]
Net cash used in financing activities during the first two quarters of 2022 was $36.3 million, primarily reflecting repurchases of common stock of $35.4 million and cash used to settle warrants of $0.9 million. Net cash provided by financing activities during the first two quarters of 2021 was $52.0 million, primarily reflecting proceeds from long-term debt borrowing of $500.0 million, less the repayment of long-term debt borrowings of $425.8 million, capital equipment financing of $7.1 million, repurchases of common stock of $6.1 million, payment of debt issuance costs of $5.8 million, and cash used to settle warrants of $3.1 million.

[0001564590-22-028936:mdna:56]
As of July 4, 2022, we had cash and cash equivalents of approximately $266.5 million, of which approximately $199.4 million was held by our foreign subsidiaries, primarily in Hong Kong. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for the repatriation of this cash.

[0001564590-22-028936:mdna:57]
[same as prior period, unchanged from 0001564590-22-019520:mdna:53]

[0001564590-22-028936:mdna:58]
[same as prior period, unchanged from 0001564590-22-019520:mdna:54]

[0001564590-22-028936:mdna:59]
On February 3, 2021, our board of directors authorized a share repurchase program allowing us to repurchase up to $100.0 million of our common stock. During the second quarter of 2022, we repurchased a total of 0.4 million shares of our common stock for $5.2 million (including commissions) and during the two quarters ended July 4, 2022, we repurchased a total of 2.7 million shares of our common stock for a total cost of $35.4 million (including commissions). As of July 4, 2022, there are no amounts available for repurchase. We repurchased a total of 7.5 million shares of our common stock for $100.0 million under the share repurchase program.

[0001564590-22-028936:mdna:60]
[same as prior period, unchanged from 0001564590-22-019520:mdna:56]

[0001564590-22-028936:mdna:61]
As of July 4, 2022, we had $928.6 million of outstanding debt, net of discount and debt issuance costs, composed of $494.9 million of Senior Notes due March 2029, $403.7 million of a Term Loan due September 2024, and $30.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL).

[0001564590-22-028936:mdna:62]
Pursuant to the terms of the Term Loan Facility and Senior Notes due 2029, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of July 4, 2022, we were in compliance with the covenants under the Term Loan Facility, Senior Notes due 2029 and ABL Revolving Loans.

[0001564590-22-028936:mdna:63]
[same as prior period, unchanged from 0001564590-22-019520:mdna:59]

[0001564590-22-028936:mdna:64]
[same as prior period, unchanged from 0001564590-22-019520:mdna:60]

[0001564590-22-028936:mdna:65]
As part of our ongoing operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, purchase obligations, and leases as of July 4, 2022. As of the date of this report, our contractual obligations have not changed materially since January 3, 2022, except for additional purchase obligations resulting from the Telephonics acquisition. As of July 4, 2022, additional purchase obligations resulting from the Telephonics acquisition amounted to $121.1 million, which are expected to be settled as follows: $109.3 million within 1 year, $11.7 million within 1-3 years, and $0.1 million within 4-5 years.

[0001564590-22-028936:mdna:66]
[same as prior period, unchanged from 0001564590-22-019520:mdna:62]

[0001564590-22-028936:mdna:67]
[same as prior period, unchanged from 0001564590-22-019520:mdna:63]

[0001564590-22-028936:mdna:68]
Recently Issued Accounting Standards

[0001564590-22-028936:mdna:69]
For a description of recently adopted and issued accounting standards, including the respective dates of adoption and the expected effects on our results of operations and financial condition, see Part I, Item 1, Note 1, Nature of Operations and Basis of Presentation, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q.
