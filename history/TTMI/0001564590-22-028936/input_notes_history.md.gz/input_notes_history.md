# TTMI note change history — 0001564590-22-019520 → 0001564590-22-028936


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-08-10):
[0001564590-22-028936:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 4, 2022 and January 3, 2022. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2022-05-11, similarity 0.9753):
[0001564590-22-019520:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 4, 2022 and January 3, 2022. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-08-10):
[0001564590-22-028936:note_history:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions including engineered systems, radio frequency (RF) components and RF microwave/microelectronic assemblies, and printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This one-stop design, engineering, and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- changed (2022-08-10):
[0001564590-22-028936:note_history:3]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the on-going coronavirus (COVID-19) global pandemic, the global economy and financial markets have been volatile, and the pandemic has contributed to disruptions in global supply chains, labor shortages and high inflation, and there is a significant amount of uncertainty about the length and severity of the consequences caused by the ongoing pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.
  (was, 2022-05-11, similarity 0.9986):
[0001564590-22-019520:note_history:3]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the on-going coronavirus (COVID-19) global pandemic, the global economy and financial markets have been volatile, and the pandemic has contributed to disruptions in global supply chains and labor shortages and high inflation, and there is a significant amount of uncertainty about the length and severity of the consequences caused by the ongoing pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

- changed (2022-08-10):
[0001564590-22-028936:note_history:4]
In October 2021, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires that an acquirer recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers, as if it had originated the contracts. Prior to this ASU, an acquirer generally recognizes contract assets acquired and contract liabilities assumed that arose from contracts with customers at fair value on the acquisition date. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The ASU is to be applied prospectively to business combinations occurring on or after the effective date of the amendment (or if adopted early as of an interim period, as of the beginning of the fiscal year that includes the interim period of early application). The Company early adopted ASU 2021-08 on April 4, 2022 and did not have an impact on its consolidated condensed financial statements and related disclosures. The new guidance will be applied to the acquisition of Gritel Holding Co., Inc. (Gritel) and ISC Farmingdale Corp.
  (was, 2022-05-11, similarity 0.8651):
[0001564590-22-019520:note_history:4]
In October 2021, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires that an acquirer recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers, as if it had originated the contracts. Prior to this ASU, an acquirer generally recognizes contract assets acquired and contract liabilities assumed that arose from contracts with customers at fair value on the acquisition date. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The ASU is to be applied prospectively to business combinations occurring on or after the effective date of the amendment (or if adopted early as of an interim period, as of the beginning of the fiscal year that includes the interim period of early application). The Company early adopted ASU 2021-08 on April 4, 2022 and any impact on the condensed consolidated financial statements will be dependent on the magnitude and nature of future acquired entities.

- removed (2022-08-10):
[0001564590-22-019520:note_history:5]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave/microelectronics components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This one-stop design, engineering, and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-10):
[0001564590-22-028936:note_history:6]
As of July 4, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:
  (was, 2022-05-11, similarity 0.9776):
[0001564590-22-019520:note_history:6]
As of April 4, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

- changed (2022-08-10):
[0001564590-22-028936:note_history:7]
|  |  | As of July 4, 2022 |  |  | As of January 3, 2022 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 5,114 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,658 |  |  |  | 502 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 6,772 |  |  | $ | 502 |  |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |  |
  (was, 2022-05-11, similarity 0.9932):
[0001564590-22-019520:note_history:7]
|  |  | As of April 4, 2022 |  |  | As of January 3, 2022 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 5,280 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,834 |  |  |  | 555 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 7,114 |  |  | $ | 555 |  |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-10):
[0001564590-22-028936:note_history:8]
The following table summarizes the long-term debt of the Company as of July 4, 2022 and January 3, 2022:
  (was, 2022-05-11, similarity 0.9637):
[0001564590-22-019520:note_history:8]
The following table summarizes the long-term debt of the Company as of April 4, 2022 and January 3, 2022:

- changed (2022-08-10):
[0001564590-22-028936:note_history:9]
|  |  | Interest Rate as of July 4, 2022 |  |  | Principal Outstanding as of July 4, 2022 |  |  | Interest Rate as of January 3, 2022 |  |  | Principal Outstanding as of January 3, 2022 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | 4.00 |  | % | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 4.28 |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 3.18 |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (502 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (6,772 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 928,605 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 928,605 |  |  |  |  |  |  | $ | 927,818 |  |
  (was, 2022-05-11, similarity 0.8801):
[0001564590-22-019520:note_history:9]
|  |  | Interest Rate as of April 4, 2022 |  |  | Principal Outstanding as of April 4, 2022 |  |  | Interest Rate as of January 3, 2022 |  |  | Principal Outstanding as of January 3, 2022 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | 4.00 |  | % | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 2.93 |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.83 |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (555 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (7,114 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 928,210 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 928,210 |  |  |  |  |  |  | $ | 927,818 |  |

- changed (2022-08-10):
[0001564590-22-028936:note_history:10]
As of July 4, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:
  (was, 2022-05-11, similarity 0.9776):
[0001564590-22-019520:note_history:10]
As of April 4, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

- changed (2022-08-10):
[0001564590-22-028936:note_history:11]
|  |  | As of July 4, 2022 |  |  | As of January 3, 2022 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 5,114 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,658 |  |  |  | 502 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 6,772 |  |  | $ | 502 |  |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |  |
  (was, 2022-05-11, similarity 0.9932):
[0001564590-22-019520:note_history:11]
|  |  | As of April 4, 2022 |  |  | As of January 3, 2022 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 5,280 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,834 |  |  |  | 555 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 7,114 |  |  | $ | 555 |  |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |  |

- changed (2022-08-10):
[0001564590-22-028936:note_history:12]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,073 and $1,355 as of July 4, 2022 and January 3, 2022, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2022-05-11, similarity 0.985):
[0001564590-22-019520:note_history:12]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,214 and $1,355 as of April 4, 2022 and January 3, 2022, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2022-08-10):
[0001564590-22-028936:note_history:13]
As of July 4, 2022, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.9 years.
  (was, 2022-05-11, similarity 0.9744):
[0001564590-22-019520:note_history:13]
As of April 4, 2022, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 5.1 years.

- added (2022-08-10):
[0001564590-22-028936:note_history:14]
During the two quarters ended June 28, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.

- removed (2022-08-10):
[0001564590-22-019520:note_history:15]
During the quarter ended March 29, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-10):
[0001564590-22-028936:note_history:16]
The following table summarizes the long-term debt of the Company as of July 4, 2022 and January 3, 2022:
  (was, 2022-05-11, similarity 0.9637):
[0001564590-22-019520:note_history:16]
The following table summarizes the long-term debt of the Company as of April 4, 2022 and January 3, 2022:

- changed (2022-08-10):
[0001564590-22-028936:note_history:17]
|  |  | Interest Rate as of July 4, 2022 |  |  | Principal Outstanding as of July 4, 2022 |  |  | Interest Rate as of January 3, 2022 |  |  | Principal Outstanding as of January 3, 2022 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | 4.00 |  | % | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 4.28 |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 3.18 |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (502 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (6,772 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 928,605 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 928,605 |  |  |  |  |  |  | $ | 927,818 |  |
  (was, 2022-05-11, similarity 0.8801):
[0001564590-22-019520:note_history:17]
|  |  | Interest Rate as of April 4, 2022 |  |  | Principal Outstanding as of April 4, 2022 |  |  | Interest Rate as of January 3, 2022 |  |  | Principal Outstanding as of January 3, 2022 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | 4.00 |  | % | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 2.93 |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.83 |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (555 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (7,114 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 928,210 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 928,210 |  |  |  |  |  |  | $ | 927,818 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-10):
[0001564590-22-028936:note_history:18]
|  |  | Quarter Ended July 4, 2022 |  |  | Quarter Ended June 28, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 189,676 |  |  | $ | — |  |  | $ | 189,676 |  |  | $ | 185,152 |  |  | $ | 6 |  |  | $ | 185,158 |  |  |
| Automotive |  |  | 111,778 |  |  |  | — |  |  |  | 111,778 |  |  |  | 102,893 |  |  |  | — |  |  |  | 102,893 |  |  |
| Data Center Computing |  |  | 106,188 |  |  |  | 20 |  |  |  | 106,208 |  |  |  | 82,230 |  |  |  | 24 |  |  |  | 82,254 |  |  |
| Medical/Industrial/Instrumentation |  |  | 131,061 |  |  |  | 2,246 |  |  |  | 133,307 |  |  |  | 104,012 |  |  |  | 1,067 |  |  |  | 105,079 |  |  |
| Networking/Communications |  |  | 69,766 |  |  |  | 15,109 |  |  |  | 84,875 |  |  |  | 75,728 |  |  |  | 11,950 |  |  |  | 87,678 |  |  |
| Other |  |  | 960 |  |  |  | (1,254 | ) |  |  | (294 | ) |  |  | 3,465 |  |  |  | 856 |  |  |  | 4,321 |  |  |
| Total |  | $ | 609,429 |  |  | $ | 16,121 |  |  | $ | 625,550 |  |  | $ | 553,480 |  |  | $ | 13,903 |  |  | $ | 567,383 |  |  |
  (was, 2022-05-11, similarity 0.6137):
[0001564590-22-019520:note_history:18]
|  |  | Quarter Ended March 29, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 186,539 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 186,545 |  |  |
| Automotive |  |  | 91,792 |  |  |  | — |  |  |  | 3,642 |  |  |  | 95,434 |  |  |
| Data Center Computing |  |  | 71,759 |  |  |  | 432 |  |  |  | — |  |  |  | 72,191 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,770 |  |  |  | 1,081 |  |  |  | 25 |  |  |  | 91,876 |  |  |
| Networking/Communications |  |  | 66,938 |  |  |  | 10,653 |  |  |  | 1 |  |  |  | 77,592 |  |  |
| Other |  |  | 2,688 |  |  |  | 518 |  |  |  | (412 | ) |  |  | 2,794 |  |  |
| Total |  | $ | 510,486 |  |  | $ | 12,690 |  |  | $ | 3,256 |  |  | $ | 526,432 |  |  |

- added (2022-08-10):
[0001564590-22-028936:note_history:19]
|  |  | Two Quarters Ended July 4, 2022 |  |  | Two Quarters Ended June 28, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 361,856 |  |  | $ | — |  |  | $ | 361,856 |  |  | $ | 371,691 |  |  | $ | 12 |  |  | $ | — |  |  | $ | 371,703 |  |  |
| Automotive |  |  | 227,014 |  |  |  | — |  |  |  | 227,014 |  |  |  | 194,685 |  |  |  | — |  |  |  | 3,642 |  |  |  | 198,327 |  |  |
| Data Center Computing |  |  | 197,972 |  |  |  | 20 |  |  |  | 197,992 |  |  |  | 153,989 |  |  |  | 456 |  |  |  | — |  |  |  | 154,445 |  |  |
| Medical/Industrial/Instrumentation |  |  | 251,423 |  |  |  | 3,784 |  |  |  | 255,207 |  |  |  | 194,782 |  |  |  | 2,148 |  |  |  | 25 |  |  |  | 196,955 |  |  |
| Networking/Communications |  |  | 133,409 |  |  |  | 28,866 |  |  |  | 162,275 |  |  |  | 142,666 |  |  |  | 22,603 |  |  |  | 1 |  |  |  | 165,270 |  |  |
| Other |  |  | 3,825 |  |  |  | (1,359 | ) |  |  | 2,466 |  |  |  | 6,153 |  |  |  | 1,374 |  |  |  | (412 | ) |  |  | 7,115 |  |  |
| Total |  | $ | 1,175,499 |  |  | $ | 31,311 |  |  | $ | 1,206,810 |  |  | $ | 1,063,966 |  |  | $ | 26,593 |  |  | $ | 3,256 |  |  | $ | 1,093,815 |  |  |

- removed (2022-08-10):
[0001564590-22-019520:note_history:20]
|  |  | Quarter Ended April 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 172,180 |  |  | $ | — |  |  | $ | 172,180 |  |  |
| Automotive |  |  | 115,236 |  |  |  | — |  |  |  | 115,236 |  |  |
| Data Center Computing |  |  | 91,784 |  |  |  | — |  |  |  | 91,784 |  |  |
| Medical/Industrial/Instrumentation |  |  | 120,362 |  |  |  | 1,538 |  |  |  | 121,900 |  |  |
| Networking/Communications |  |  | 63,643 |  |  |  | 13,757 |  |  |  | 77,400 |  |  |
| Other |  |  | 2,865 |  |  |  | (105 | ) |  |  | 2,760 |  |  |
| Total |  | $ | 566,070 |  |  | $ | 15,190 |  |  | $ | 581,260 |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-10):
[0001564590-22-028936:note_history:21]
As of July 4, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $308,915. The Company expects to recognize revenue on approximately 64% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.
  (was, 2022-05-11, similarity 0.9854):
[0001564590-22-019520:note_history:21]
As of April 4, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $11,877. The Company expects to recognize revenue on approximately 48% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.

- changed (2022-08-10):
[0001564590-22-028936:note_history:22]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and two quarters ended July 4, 2022, and 98% and 2%, respectively, of the Company’s revenue for the quarter and two quarters ended June 28, 2021.
  (was, 2022-05-11, similarity 0.6241):
[0001564590-22-019520:note_history:22]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter ended April 4, 2022, and 98% and 2%, respectively, of the Company’s revenue for the quarter ended March 29, 2021.

- changed (2022-08-10):
[0001564590-22-028936:note_history:23]
|  |  | Quarter Ended July 4, 2022 |  |  | Quarter Ended June 28, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 189,676 |  |  | $ | — |  |  | $ | 189,676 |  |  | $ | 185,152 |  |  | $ | 6 |  |  | $ | 185,158 |  |  |
| Automotive |  |  | 111,778 |  |  |  | — |  |  |  | 111,778 |  |  |  | 102,893 |  |  |  | — |  |  |  | 102,893 |  |  |
| Data Center Computing |  |  | 106,188 |  |  |  | 20 |  |  |  | 106,208 |  |  |  | 82,230 |  |  |  | 24 |  |  |  | 82,254 |  |  |
| Medical/Industrial/Instrumentation |  |  | 131,061 |  |  |  | 2,246 |  |  |  | 133,307 |  |  |  | 104,012 |  |  |  | 1,067 |  |  |  | 105,079 |  |  |
| Networking/Communications |  |  | 69,766 |  |  |  | 15,109 |  |  |  | 84,875 |  |  |  | 75,728 |  |  |  | 11,950 |  |  |  | 87,678 |  |  |
| Other |  |  | 960 |  |  |  | (1,254 | ) |  |  | (294 | ) |  |  | 3,465 |  |  |  | 856 |  |  |  | 4,321 |  |  |
| Total |  | $ | 609,429 |  |  | $ | 16,121 |  |  | $ | 625,550 |  |  | $ | 553,480 |  |  | $ | 13,903 |  |  | $ | 567,383 |  |  |
  (was, 2022-05-11, similarity 0.6137):
[0001564590-22-019520:note_history:23]
|  |  | Quarter Ended March 29, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 186,539 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 186,545 |  |  |
| Automotive |  |  | 91,792 |  |  |  | — |  |  |  | 3,642 |  |  |  | 95,434 |  |  |
| Data Center Computing |  |  | 71,759 |  |  |  | 432 |  |  |  | — |  |  |  | 72,191 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,770 |  |  |  | 1,081 |  |  |  | 25 |  |  |  | 91,876 |  |  |
| Networking/Communications |  |  | 66,938 |  |  |  | 10,653 |  |  |  | 1 |  |  |  | 77,592 |  |  |
| Other |  |  | 2,688 |  |  |  | 518 |  |  |  | (412 | ) |  |  | 2,794 |  |  |
| Total |  | $ | 510,486 |  |  | $ | 12,690 |  |  | $ | 3,256 |  |  | $ | 526,432 |  |  |

- added (2022-08-10):
[0001564590-22-028936:note_history:24]
|  |  | Two Quarters Ended July 4, 2022 |  |  | Two Quarters Ended June 28, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 361,856 |  |  | $ | — |  |  | $ | 361,856 |  |  | $ | 371,691 |  |  | $ | 12 |  |  | $ | — |  |  | $ | 371,703 |  |  |
| Automotive |  |  | 227,014 |  |  |  | — |  |  |  | 227,014 |  |  |  | 194,685 |  |  |  | — |  |  |  | 3,642 |  |  |  | 198,327 |  |  |
| Data Center Computing |  |  | 197,972 |  |  |  | 20 |  |  |  | 197,992 |  |  |  | 153,989 |  |  |  | 456 |  |  |  | — |  |  |  | 154,445 |  |  |
| Medical/Industrial/Instrumentation |  |  | 251,423 |  |  |  | 3,784 |  |  |  | 255,207 |  |  |  | 194,782 |  |  |  | 2,148 |  |  |  | 25 |  |  |  | 196,955 |  |  |
| Networking/Communications |  |  | 133,409 |  |  |  | 28,866 |  |  |  | 162,275 |  |  |  | 142,666 |  |  |  | 22,603 |  |  |  | 1 |  |  |  | 165,270 |  |  |
| Other |  |  | 3,825 |  |  |  | (1,359 | ) |  |  | 2,466 |  |  |  | 6,153 |  |  |  | 1,374 |  |  |  | (412 | ) |  |  | 7,115 |  |  |
| Total |  | $ | 1,175,499 |  |  | $ | 31,311 |  |  | $ | 1,206,810 |  |  | $ | 1,063,966 |  |  | $ | 26,593 |  |  | $ | 3,256 |  |  | $ | 1,093,815 |  |  |

- removed (2022-08-10):
[0001564590-22-019520:note_history:25]
|  |  | Quarter Ended April 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 172,180 |  |  | $ | — |  |  | $ | 172,180 |  |  |
| Automotive |  |  | 115,236 |  |  |  | — |  |  |  | 115,236 |  |  |
| Data Center Computing |  |  | 91,784 |  |  |  | — |  |  |  | 91,784 |  |  |
| Medical/Industrial/Instrumentation |  |  | 120,362 |  |  |  | 1,538 |  |  |  | 121,900 |  |  |
| Networking/Communications |  |  | 63,643 |  |  |  | 13,757 |  |  |  | 77,400 |  |  |
| Other |  |  | 2,865 |  |  |  | (105 | ) |  |  | 2,760 |  |  |
| Total |  | $ | 566,070 |  |  | $ | 15,190 |  |  | $ | 581,260 |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2022-08-10):
[0001564590-22-019520:note_history:26]
(18) Subsequent Events

- removed (2022-08-10):
[0001564590-22-019520:note_history:27]
On April 18, 2022, the Company entered into a definitive share purchase agreement to purchase all of the issued and outstanding capital stock of Telephonics Corporation and ISC Farmingdale Corp. for an aggregate purchase price of $330,000 in cash, subject to customary working capital and certain other adjustments. The transaction is expected to close in the second quarter of 2022.
