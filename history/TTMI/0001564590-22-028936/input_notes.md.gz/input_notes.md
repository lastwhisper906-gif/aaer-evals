# TTMI notes — 0001564590-22-028936


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-22-028936:notes:1]
[same as prior period, unchanged from 0001564590-22-019520:notes:1]

[0001564590-22-028936:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions including engineered systems, radio frequency (RF) components and RF microwave/microelectronic assemblies, and printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This one-stop design, engineering, and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001564590-22-028936:notes:3]
[same as prior period, unchanged from 0001564590-22-019520:notes:3]

[0001564590-22-028936:notes:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the on-going coronavirus (COVID-19) global pandemic, the global economy and financial markets have been volatile, and the pandemic has contributed to disruptions in global supply chains, labor shortages and high inflation, and there is a significant amount of uncertainty about the length and severity of the consequences caused by the ongoing pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

[0001564590-22-028936:notes:5]
[same as prior period, unchanged from 0001564590-22-019520:notes:5]

[0001564590-22-028936:notes:6]
Recently Adopted Accounting Standards

[0001564590-22-028936:notes:7]
In October 2021, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires that an acquirer recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers, as if it had originated the contracts. Prior to this ASU, an acquirer generally recognizes contract assets acquired and contract liabilities assumed that arose from contracts with customers at fair value on the acquisition date. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The ASU is to be applied prospectively to business combinations occurring on or after the effective date of the amendment (or if adopted early as of an interim period, as of the beginning of the fiscal year that includes the interim period of early application). The Company early adopted ASU 2021-08 on April 4, 2022 and did not have an impact on its consolidated condensed financial statements and related disclosures. The new guidance will be applied to the acquisition of Gritel Holding Co., Inc. (Gritel) and ISC Farmingdale Corp.

[0001564590-22-028936:notes:8]
Recently Issued Accounting Standards Not Yet Adopted

[0001564590-22-028936:notes:9]
In November 2021, the FASB issued ASU 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance, which provides guidance on disclosures for transactions with a government that are accounted for by applying a grant or contribution accounting model by analogy. The guidance is effective for annual periods beginning after December 15, 2021. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on the consolidated financial statements and related disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-22-028936:notes:10]
(2) Acquisition of Gritel and ISC Farmingdale Corp.

[0001564590-22-028936:notes:11]
On June 27, 2022, the Company completed its acquisition of all of the issued and outstanding capital stock of Gritel and ISC Farmingdale Corp. for a preliminary total consideration of $299,212 in cash. Telephonics Corporation is wholly-owned by Gritel, and as a result of the acquisition, became an indirect, wholly-owned subsidiary of the Company (collectively with ISC Farmingdale Corp., Telephonics).

[0001564590-22-028936:notes:12]
For the quarter and two quarters ended July 4, 2022, bank fees and legal, accounting, and other professional service costs associated with the acquisition of $9,854 and $10,708, respectively, have been expensed and recorded as general and administrative expense in the consolidated condensed financial statements. There were no bank fees or legal, accounting, or other professional service costs associated with the acquisition for the quarter and two quarters ended June 28, 2021.

[0001564590-22-028936:notes:13]
Preliminary Purchase Price Allocation

[0001564590-22-028936:notes:14]
The purchase price was allocated to tangible and intangible assets acquired, and liabilities assumed based on preliminary estimates of fair value at the date of the acquisition, June 27, 2022. The excess of the purchase price over the fair value of net assets acquired was allocated to goodwill. The fair values were based on management’s analysis, including work performed by third-party valuation specialists.

[0001564590-22-028936:notes:15]
The fair values assigned are based on reasonable methods applicable to the nature of the assets acquired and liabilities assumed. The following summarizes the preliminary estimated fair values of net assets acquired:

[0001564590-22-028936:notes:16]
|  |  |  | (In thousands) |  |  |
| Accounts receivable |  |  | $ | 53,695 |  |  |
| Contract assets |  |  |  | 33,122 |  |  |
| Inventories |  |  |  | 76,257 |  |  |
| Prepaid expenses and other current assets |  |  |  | 7,270 |  |  |
| Property, plant and equipment |  |  |  | 70,685 |  |  |
| Operating lease right-of-use assets |  |  |  | 3,466 |  |  |
| Goodwill |  |  |  | 78,267 |  |  |
| Identifiable intangible assets |  |  |  | 90,750 |  |  |
| Deposits and other non-current assets |  |  |  | 1,813 |  |  |
| Accounts payable |  |  |  | (16,026 | ) |  |
| Contract liabilities |  |  |  | (51,810 | ) |  |
| Accrued salaries, wages and benefits |  |  |  | (10,553 | ) |  |
| Other current liabilities |  |  |  | (7,379 | ) |  |
| Operating lease liabilities |  |  |  | (2,392 | ) |  |
| Non-current deferred tax liabilities |  |  |  | (27,912 | ) |  |
| Other long-term liabilities |  |  |  | (41 | ) |  |
| Total |  |  | $ | 299,212 |  |  |

[0001564590-22-028936:notes:17]
Because the acquisition closed shortly prior to the end of the Company’s second fiscal quarter, the magnitude of the transaction, and the significant information to be obtained and analyzed, the Company’s fair value estimates for all of the acquired assets and liabilities are preliminary and may change during the allowable measurement period, which is up to the point the Company obtains and analyzes the information that existed as of the date of the acquisition necessary to determine the fair values of the assets acquired and liabilities assumed, but in no case to exceed more than one year from the date of acquisition. Any subsequent changes to the purchase price allocation during the measurement period will be recorded in the reporting period in which the adjustment amounts are determined. Any changes in the fair values of the assets acquired and liabilities assumed during the measurement period may result in material adjustments to goodwill.

[0001564590-22-028936:notes:18]
Goodwill represents the excess of the purchase price over the fair value of assets acquired and liabilities assumed. The Company believes that the acquisition of Telephonics will strengthen the Company’s differentiated position in the Aerospace and Defense market and complement existing RF and microwave business. The Company believes that these factors support the amount of goodwill recognized as a result of the purchase price paid for Telephonics, in relation to other acquired tangible and intangible assets. The goodwill acquired in the acquisition is not deductible for income tax purposes.

[0001564590-22-028936:notes:19]
The results of operations of Telephonics since the acquisition date are not material to the Company’s consolidated condensed financial statements.

[0001564590-22-028936:notes:20]
Preliminary Pro forma Financial Information

[0001564590-22-028936:notes:21]
The unaudited preliminary pro forma financial information below gives effect to this acquisition as if it had occurred at the beginning of fiscal 2021, or December 29, 2020. The preliminary pro forma financial information presented includes the effects of adjustments related to the amortization of acquired identifiable intangible assets and other non-recurring transactions costs directly associated with the acquisition such as legal, accounting and banking fees. The Company will include the full pro forma financial information and historical financial statements of Telephonics as required by SEC rules by filing an amendment to its Current Report on Form 8-K dated June 27, 2022.

[0001564590-22-028936:notes:22]
The preliminary pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the actual results that would have been achieved had the acquisition occurred at the beginning of the earliest period presented, or the results that may be achieved in future periods.

[0001564590-22-028936:notes:23]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 4, 2022 |  |  | June 28, 2021 |  |  | July 4, 2022 |  |  | June 28, 2021 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net sales |  | $ | 676,344 |  |  | $ | 629,957 |  |  | $ | 1,313,878 |  |  | $ | 1,216,540 |  |
| Net income |  |  | 35,314 |  |  |  | 28,485 |  |  |  | 52,124 |  |  |  | 23,312 |  |
| Basic earnings per share |  | $ | 0.35 |  |  | $ | 0.27 |  |  | $ | 0.51 |  |  | $ | 0.22 |  |
| Diluted earnings per share |  | $ | 0.34 |  |  | $ | 0.26 |  |  | $ | 0.50 |  |  | $ | 0.21 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-22-028936:notes:24]
[same as prior period, unchanged from 0001564590-22-019520:notes:13]

[0001564590-22-028936:notes:25]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases and finance leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments, and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the right-of-use (ROU) asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-22-028936:notes:26]
[same as prior period, unchanged from 0001564590-22-019520:notes:15]

[0001564590-22-028936:notes:27]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 4, 2022 |  |  | June 28, 2021 |  |  | July 4, 2022 |  |  | June 28, 2021 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 1,792 |  |  | $ | 1,924 |  |  | $ | 3,676 |  |  | $ | 4,132 |  |
| Variable lease cost |  |  | 208 |  |  |  | 140 |  |  |  | 454 |  |  |  | 374 |  |
| Short-term lease cost |  |  | 174 |  |  |  | 55 |  |  |  | 314 |  |  |  | 109 |  |
| Finance lease costs: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  | 344 |  |  |  | — |  |  |  | 687 |  |  |  | — |  |
| Interest on lease liabilities |  |  | 99 |  |  |  | — |  |  |  | 197 |  |  |  | — |  |

[0001564590-22-028936:notes:28]
[same as prior period, unchanged from 0001564590-22-019520:notes:17]

[0001564590-22-028936:notes:29]
|  |  | Two Quarters Ended |  |
|  |  | July 4, 2022 |  |  | June 28, 2021 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |
| Operating cash flows for operating leases |  | $ | 3,654 |  |  | $ | 4,104 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 5,368 |  |  |  | 802 |  |

[0001564590-22-028936:notes:30]
[same as prior period, unchanged from 0001564590-22-019520:notes:19]

[0001564590-22-028936:notes:31]
|  |  |  |  | As of |  |
|  |  | Balance Sheet Location |  | July 4, 2022 |  |  | January 3, 2022 |  |
|  |  |  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease right-of-use assets |  | $ | 22,618 |  |  | $ | 20,802 |  |
| Finance leases |  | Property, plant and equipment, net |  |  | 14,072 |  |  |  | 14,759 |  |
| Total lease assets |  |  |  | $ | 36,690 |  |  | $ | 35,561 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 7,606 |  |  | $ | 6,362 |  |
| Finance leases |  | Other current liabilities |  |  | 706 |  |  |  | 698 |  |
| Long-term: |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease liabilities |  |  | 15,832 |  |  |  | 15,252 |  |
| Finance leases |  | Other long-term liabilities |  |  | 13,959 |  |  |  | 14,317 |  |
| Total lease liabilities |  |  |  | $ | 38,103 |  |  | $ | 36,629 |  |

[0001564590-22-028936:notes:32]
|  |  | As of |  |
|  |  | July 4, 2022 |  |  | January 3, 2022 |  |
| Weighted average remaining lease term (years): |  |  |  |  |  |  |  |  |
| Operating leases |  | 3.7 |  |  | 3.9 |  |
| Finance leases |  | 14.1 |  |  | 14.6 |  |
| Weighted average discount rate: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 3.00 | % |  |  | 2.56 | % |
| Finance leases |  |  | 2.68 | % |  |  | 2.68 | % |

[0001564590-22-028936:notes:33]
[same as prior period, unchanged from 0001564590-22-019520:notes:22]

[0001564590-22-028936:notes:34]
|  |  | Operating Leases (1) |  |  | Finance Leases |  |
|  |  | (In thousands) |  |
| Less than one year |  | $ | 8,186 |  |  | $ | 1,089 |  |
| 1 - 2 years |  |  | 7,008 |  |  |  | 1,133 |  |
| 2 - 3 years |  |  | 5,488 |  |  |  | 1,128 |  |
| 3 - 4 years |  |  | 2,226 |  |  |  | 1,171 |  |
| 4 - 5 years |  |  | 966 |  |  |  | 1,175 |  |
| Thereafter |  |  | 987 |  |  |  | 12,068 |  |
| Total lease payments |  |  | 24,861 |  |  |  | 17,764 |  |
| Less imputed interest |  |  | (1,423 | ) |  |  | (3,099 | ) |
| Total |  | $ | 23,438 |  |  | $ | 14,665 |  |

[0001564590-22-028936:notes:35]
|  | (1) | Excludes $884 of legally binding minimum lease payments for leases signed but not yet commenced. |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-22-028936:notes:36]
[same as prior period, unchanged from 0001564590-22-019520:notes:25]

[0001564590-22-028936:notes:37]
As of July 4, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $308,915. The Company expects to recognize revenue on approximately 64% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.

[0001564590-22-028936:notes:38]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and two quarters ended July 4, 2022, and 98% and 2%, respectively, of the Company’s revenue for the quarter and two quarters ended June 28, 2021.

[0001564590-22-028936:notes:39]
[same as prior period, unchanged from 0001564590-22-019520:notes:28]

[0001564590-22-028936:notes:40]
|  |  | Quarter Ended July 4, 2022 |  |  | Quarter Ended June 28, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 189,676 |  |  | $ | — |  |  | $ | 189,676 |  |  | $ | 185,152 |  |  | $ | 6 |  |  | $ | 185,158 |  |  |
| Automotive |  |  | 111,778 |  |  |  | — |  |  |  | 111,778 |  |  |  | 102,893 |  |  |  | — |  |  |  | 102,893 |  |  |
| Data Center Computing |  |  | 106,188 |  |  |  | 20 |  |  |  | 106,208 |  |  |  | 82,230 |  |  |  | 24 |  |  |  | 82,254 |  |  |
| Medical/Industrial/Instrumentation |  |  | 131,061 |  |  |  | 2,246 |  |  |  | 133,307 |  |  |  | 104,012 |  |  |  | 1,067 |  |  |  | 105,079 |  |  |
| Networking/Communications |  |  | 69,766 |  |  |  | 15,109 |  |  |  | 84,875 |  |  |  | 75,728 |  |  |  | 11,950 |  |  |  | 87,678 |  |  |
| Other |  |  | 960 |  |  |  | (1,254 | ) |  |  | (294 | ) |  |  | 3,465 |  |  |  | 856 |  |  |  | 4,321 |  |  |
| Total |  | $ | 609,429 |  |  | $ | 16,121 |  |  | $ | 625,550 |  |  | $ | 553,480 |  |  | $ | 13,903 |  |  | $ | 567,383 |  |  |

[0001564590-22-028936:notes:41]
|  |  | Two Quarters Ended July 4, 2022 |  |  | Two Quarters Ended June 28, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 361,856 |  |  | $ | — |  |  | $ | 361,856 |  |  | $ | 371,691 |  |  | $ | 12 |  |  | $ | — |  |  | $ | 371,703 |  |  |
| Automotive |  |  | 227,014 |  |  |  | — |  |  |  | 227,014 |  |  |  | 194,685 |  |  |  | — |  |  |  | 3,642 |  |  |  | 198,327 |  |  |
| Data Center Computing |  |  | 197,972 |  |  |  | 20 |  |  |  | 197,992 |  |  |  | 153,989 |  |  |  | 456 |  |  |  | — |  |  |  | 154,445 |  |  |
| Medical/Industrial/Instrumentation |  |  | 251,423 |  |  |  | 3,784 |  |  |  | 255,207 |  |  |  | 194,782 |  |  |  | 2,148 |  |  |  | 25 |  |  |  | 196,955 |  |  |
| Networking/Communications |  |  | 133,409 |  |  |  | 28,866 |  |  |  | 162,275 |  |  |  | 142,666 |  |  |  | 22,603 |  |  |  | 1 |  |  |  | 165,270 |  |  |
| Other |  |  | 3,825 |  |  |  | (1,359 | ) |  |  | 2,466 |  |  |  | 6,153 |  |  |  | 1,374 |  |  |  | (412 | ) |  |  | 7,115 |  |  |
| Total |  | $ | 1,175,499 |  |  | $ | 31,311 |  |  | $ | 1,206,810 |  |  | $ | 1,063,966 |  |  | $ | 26,593 |  |  | $ | 3,256 |  |  | $ | 1,093,815 |  |  |

[0001564590-22-028936:notes:42]
[same as prior period, unchanged from 0001564590-22-019520:notes:31]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-22-028936:notes:43]
[same as prior period, unchanged from 0001564590-22-019520:notes:32]

[0001564590-22-028936:notes:44]
|  |  | As of |  |
|  |  | July 4, 2022 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 168,919 |  |  | $ | 114,653 |  |
| Work-in-process |  |  | 37,468 |  |  |  | 9,620 |  |
| Finished goods |  |  | 3,573 |  |  |  | 3,339 |  |
|  |  | $ | 209,960 |  |  | $ | 127,612 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 62,898 |  |  | $ | 62,015 |  |
| Buildings and improvements |  |  | 475,809 |  |  |  | 429,344 |  |
| Machinery and equipment |  |  | 954,619 |  |  |  | 891,925 |  |
| Furniture and fixtures and other |  |  | 11,417 |  |  |  | 10,360 |  |
| Construction-in-progress |  |  | 36,730 |  |  |  | 25,554 |  |
|  |  |  | 1,541,473 |  |  |  | 1,419,198 |  |
| Less: Accumulated depreciation |  |  | (793,034 | ) |  |  | (753,443 | ) |
|  |  | $ | 748,439 |  |  | $ | 665,755 |  |
| Other current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | $ | 19,185 |  |  | $ | 7,162 |  |
| Sales return and allowances |  |  | 12,508 |  |  |  | 12,853 |  |
| Operating lease |  |  | 7,606 |  |  |  | 6,362 |  |
| Interest |  |  | 7,016 |  |  |  | 8,741 |  |
| Derivative liabilities |  |  | 3,649 |  |  |  | 4,295 |  |
| Finance leases |  |  | 706 |  |  |  | 698 |  |
| Other |  |  | 62,252 |  |  |  | 52,918 |  |
|  |  | $ | 112,922 |  |  | $ | 93,029 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 31,533 |  |  | $ | 28,361 |  |
| Finance leases |  |  | 13,959 |  |  |  | 14,317 |  |
| Defined benefit pension plan liability |  |  | 4,747 |  |  |  | 5,276 |  |
| Other |  |  | 23,586 |  |  |  | 20,958 |  |
|  |  | $ | 73,825 |  |  | $ | 68,912 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-22-028936:notes:45]
[same as prior period, unchanged from 0001564590-22-019520:notes:34]

[0001564590-22-028936:notes:46]
As of July 4, 2022 and January 3, 2022, goodwill by reportable segment was as follows:

[0001564590-22-028936:notes:47]
|  |  | PCB |  | RF&S Components |  | Unallocated Telephonics Goodwill |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 3, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 700,724 |  | $ | 177,200 |  | $ | — |  | $ | 877,924 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (69,200 | ) |  | — |  |  | (240,600 | ) |
|  |  |  | 529,324 |  |  | 108,000 |  |  | — |  |  | 637,324 |  |
| Goodwill recognized during the two quarters ended July 4, 2022 |  |  | — |  |  | — |  |  | 78,267 |  |  | 78,267 |  |
| Balance as of July 4, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  |  | 700,724 |  |  | 177,200 |  |  | 78,267 |  |  | 956,191 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (69,200 | ) |  | — |  |  | (240,600 | ) |
|  |  | $ | 529,324 |  | $ | 108,000 |  | $ | 78,267 |  | $ | 715,591 |  |

[0001564590-22-028936:notes:48]
The assignment of goodwill related to the Telephonics acquisition to the Company’s reporting units has not yet been completed. See Note 2, Acquisition of Gritel and ISC Farmingdale Corp. and Note 17, Segment Information, for further information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-22-028936:notes:49]
[same as prior period, unchanged from 0001564590-22-019520:notes:37]

[0001564590-22-028936:notes:50]
As of July 4, 2022 and January 3, 2022, the components of definite-lived intangibles were as follows:

[0001564590-22-028936:notes:51]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| July 4, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 366,071 |  |  | $ | (171,010 | ) |  | $ | 195,061 |  |  |  | 11.3 |  |
| Technology |  |  | 47,650 |  |  |  | (22,109 | ) |  |  | 25,541 |  |  |  | 9.5 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 82,500 |  |  |  | — |  |  |  | 82,500 |  |  |  | 13.0 |  |
| Trade names |  |  | 8,250 |  |  |  | — |  |  |  | 8,250 |  |  |  | 5.0 |  |
|  |  | $ | 504,471 |  |  | $ | (193,119 | ) |  | $ | 311,352 |  |  |  |  |  |
| January 3, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 366,071 |  |  | $ | (154,461 | ) |  | $ | 211,610 |  |  |  | 11.3 |  |
| Technology |  |  | 47,650 |  |  |  | (19,342 | ) |  |  | 28,308 |  |  |  | 9.5 |  |
|  |  | $ | 413,721 |  |  | $ | (173,803 | ) |  | $ | 239,918 |  |  |  |  |  |

[0001564590-22-028936:notes:52]
The Company has acquired customer relationships and trade names as a result of the acquisition. See Note 2, Acquisition of Gritel and ISC Farmingdale Corp., for further information.

[0001564590-22-028936:notes:53]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $9,658 and $10,425 for the quarters ended July 4, 2022 and June 28, 2021, respectively, and $19,316 and $21,330 for the two quarters ended July 4, 2022 and June 28, 2021, respectively. For the quarter and two quarters ended July 4, 2022, $1,383 and $2,767, respectively, of amortization expense is included in cost of goods sold. For the quarter and two quarters ended June 28, 2021, $1,383 and $2,767, respectively, of amortization expense is included in cost of goods sold.

[0001564590-22-028936:notes:54]
[same as prior period, unchanged from 0001564590-22-019520:notes:41]

[0001564590-22-028936:notes:55]
|  |  | (In thousands) |  |
| Remaining 2022 |  | $ | 23,314 |  |
| 2023 |  |  | 44,695 |  |
| 2024 |  |  | 37,513 |  |
| 2025 |  |  | 33,393 |  |
| 2026 |  |  | 33,393 |  |
| Thereafter |  |  | 139,044 |  |
|  |  | $ | 311,352 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-22-028936:notes:56]
(8) Long-term Debt and Letters of Credit

[0001564590-22-028936:notes:57]
The following table summarizes the long-term debt of the Company as of July 4, 2022 and January 3, 2022:

[0001564590-22-028936:notes:58]
|  |  | Interest Rate as of July 4, 2022 |  |  | Principal Outstanding as of July 4, 2022 |  |  | Interest Rate as of January 3, 2022 |  |  | Principal Outstanding as of January 3, 2022 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | 4.00 |  | % | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 4.28 |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 3.18 |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (502 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (6,772 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 928,605 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 928,605 |  |  |  |  |  |  | $ | 927,818 |  |

[0001564590-22-028936:notes:59]
Debt Covenants

[0001564590-22-028936:notes:60]
Borrowings under the Senior Notes due 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-22-028936:notes:61]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0001564590-22-028936:notes:62]
Debt Issuance and Debt Discount

[0001564590-22-028936:notes:63]
As of July 4, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

[0001564590-22-028936:notes:64]
|  |  | As of July 4, 2022 |  |  | As of January 3, 2022 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 5,114 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,658 |  |  |  | 502 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 6,772 |  |  | $ | 502 |  |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |  |

[0001564590-22-028936:notes:65]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-22-028936:notes:66]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,073 and $1,355 as of July 4, 2022 and January 3, 2022, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0001564590-22-028936:notes:67]
As of July 4, 2022, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.9 years.

[0001564590-22-028936:notes:68]
Loss on Extinguishment of Debt

[0001564590-22-028936:notes:69]
During the two quarters ended June 28, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-22-028936:notes:70]
[same as prior period, unchanged from 0001564590-22-019520:notes:57]

[0001564590-22-028936:notes:71]
The Company’s effective tax rate is impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items. No tax benefit was recorded on the losses incurred in certain foreign jurisdictions as a result of corresponding increases in the valuation allowances in these jurisdictions.

[0001564590-22-028936:notes:72]
During the quarter and two quarters ended July 4, 2022, the Company’s effective tax rate was impacted by a net discrete expense of $1,222 and a net discrete benefit of $825, respectively. This is mainly related to the approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China and a windfall tax benefit of the stock-based compensation releases, which were partially offset by accrued interest expense on existing uncertain tax positions.

[0001564590-22-028936:notes:73]
The Company has various foreign subsidiaries formed or acquired to conduct or support its business outside the U.S. The Company expects its earnings attributable to most foreign subsidiaries may be repatriated back to the U.S. and so a deferred tax liability has been recorded for foreign withholding taxes and the estimated federal/state tax impact on any repatriation. For those other companies with earnings currently being reinvested outside of the U.S., no deferred tax liabilities on undistributed earnings are recorded.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-22-028936:notes:74]
[same as prior period, unchanged from 0001564590-22-019520:notes:61]

[0001564590-22-028936:notes:75]
[same as prior period, unchanged from 0001564590-22-019520:notes:62]

[0001564590-22-028936:notes:76]
[same as prior period, unchanged from 0001564590-22-019520:notes:63]

[0001564590-22-028936:notes:77]
The Company’s business is exposed to risk resulting from fluctuations in interest rates on certain LIBOR-based variable rate debt. Increases in interest rates increase interest expenses relating to the outstanding variable rate borrowings and increase the cost of debt. Fluctuations in interest rates can also lead to significant fluctuations in the fair value of the debt obligations.

[0001564590-22-028936:notes:78]
On May 15, 2018, the Company entered into a four-year pay-fixed, receive floating (1-month LIBOR), interest rate swap arrangement with a notional amount of $400,000 for the period beginning June 1, 2018 and ended on June 1, 2022. During the term of the interest rate swap, the Company paid a fixed rate of 2.84% against a portion of its LIBOR-based debt and received floating 1-month LIBOR during the swap period.

[0001564590-22-028936:notes:79]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax, in the Company’s consolidated condensed balance sheets. No ineffectiveness was recognized for the quarter and two quarters ended July 4, 2022 and June 28, 2021. The interest rate swap increased interest expense by $1,399 and $2,763 for the quarters ended July 4, 2022 and June 28, 2021, respectively, and $4,105 and $5,503 for the two quarters ended July 4, 2022 and June 28, 2021, respectively.

[0001564590-22-028936:notes:80]
[same as prior period, unchanged from 0001564590-22-019520:notes:67]

[0001564590-22-028936:notes:81]
The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts as of July 4, 2022 was approximately $1,625 (Euro (EUR) 1.4 million). There were no foreign exchange contracts as of January 3, 2022.

[0001564590-22-028936:notes:82]
[same as prior period, unchanged from 0001564590-22-019520:notes:69]

[0001564590-22-028936:notes:83]
The Company uses various raw materials in the manufacturing of PCBs. In particular, the Company has been experiencing increasing prices and lead times of copper clad laminates (CCLs), a key raw material for the manufacture of PCBs. CCLs are made from epoxy resin, glass cloth and copper foil, all of which are seeing limited supply and resulting increased prices. The Company only buys a small amount of copper directly. However, copper is a major driver of laminate cost. As such, the Company enters into commodity contracts to hedge copper as a proxy for hedging laminate. As of July 4, 2022, the Company has commodity contracts with a notional quantity of (i) 0.6 metric tonnes for the period beginning June 30, 2022 and ending on October 3, 2022, (ii) 0.7 metric tonnes for the period beginning October 4, 2022 and ending on January 3, 2023 (iii) 0.7 metric tonnes for the period beginning January 1, 2023 and ending on March 31, 2023, and (iv) 0.7 metric tonnes for the period beginning April 1, 2023 and ending on June 30, 2023. As of July 4, 2022, the fair value of the commodity contracts was recorded as a liability in the amount of $3,511 and included as a component of other current liabilities. The changes in the fair value of these commodity contracts are recorded in cost of goods sold in the consolidated condensed statements of operations. The commodity contracts increased cost of goods sold by

[0001564590-22-028936:notes:84]
$5,209 and $3,807 for the quarter and two quarters ended July 4, 2022, respectively. The commodity contracts decreased cost of goods sold by $99 for both the quarter and two quarters ended June 28, 2021. These commodity contracts are not designated as accounting hedges.

[0001564590-22-028936:notes:85]
[same as prior period, unchanged from 0001564590-22-019520:notes:71]

[0001564590-22-028936:notes:86]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | July 4, 2022 |  |  | January 3, 2022 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other current liabilities |  | $ | (138 | ) |  | $ | — |  |
| Interest rate swap |  | Other current liabilities |  |  | — |  |  |  | (4,295 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Commodity contracts |  | Prepaid expenses and other current assets |  |  | — |  |  |  | 297 |  |
| Commodity contracts |  | Other current liabilities |  |  | (3,511 | ) |  |  | — |  |

[0001564590-22-028936:notes:87]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the quarter and two quarters ended July 4, 2022 and June 28, 2021:

[0001564590-22-028936:notes:88]
|  |  |  | Quarter Ended July 4, 2022 |  |  | Quarter Ended June 28, 2021 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (14 | ) |  | $ | (1,399 | ) |  | $ | (184 | ) |  | $ | (2,763 | ) |  |

[0001564590-22-028936:notes:89]
|  |  |  | Two Quarters Ended July 4, 2022 |  |  | Two Quarters Ended June 28, 2021 |  |  |
|  |  | Financial Statement Caption | Gain Recognized in Other Comprehensive Income |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | 190 |  |  | $ | (4,105 | ) |  | $ | (535 | ) |  | $ | (5,503 | ) |  |

[0001564590-22-028936:notes:90]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the two quarters ended July 4, 2022 and June 28, 2021:

[0001564590-22-028936:notes:91]
|  |  | Two Quarters Ended |
|  |  | July 4, |  |  | June 28, |  |  |
|  |  | 2022 |  |  | 2021 |  |  |
|  |  | (In thousands) |
| Beginning balance, net of tax |  | $ | (3,223 | ) |  | $ | (11,231 | ) |  |
| Changes in fair value gain (loss), net of tax |  |  | 24 |  |  |  | (203 | ) |  |
| Reclassification to earnings |  |  | 3,087 |  |  |  | 3,984 |  |  |
| Ending balance, net of tax |  | $ | (112 | ) |  | $ | (7,450 | ) |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-22-028936:notes:92]
[same as prior period, unchanged from 0001564590-22-019520:notes:78]

[0001564590-22-028936:notes:93]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of July 4, 2022 and January 3, 2022:

[0001564590-22-028936:notes:94]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | (Losses) Gains on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of January 3, 2022 |  | $ | (23,899 | ) |  | $ | (133 | ) |  | $ | (3,223 | ) |  | $ | (27,255 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (1,736 | ) |  |  | — |  |  |  | 24 |  |  |  | (1,712 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | 3,087 |  |  |  | 3,087 |  |
| Other comprehensive (loss) income |  |  | (1,736 | ) |  |  | — |  |  |  | 3,111 |  |  |  | 1,375 |  |
| Ending balance as of July 4, 2022 |  | $ | (25,635 | ) |  | $ | (133 | ) |  | $ | (112 | ) |  | $ | (25,880 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-22-028936:notes:95]
[same as prior period, unchanged from 0001564590-22-019520:notes:81]

[0001564590-22-028936:notes:96]
[same as prior period, unchanged from 0001564590-22-019520:notes:82]

[0001564590-22-028936:notes:97]
[same as prior period, unchanged from 0001564590-22-019520:notes:83]

[0001564590-22-028936:notes:98]
For the quarter and two quarters ended July 4, 2022, one customer accounted for approximately 11% and 10% of the Company’s net sales, respectively. There were no customers that accounted for 10% or more of net sales for the quarter ended June 28, 2021. For the two quarters ended June 28, 2021, one customer accounted for approximately 11% of the Company’s net sales.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-22-028936:notes:99]
[same as prior period, unchanged from 0001564590-22-019520:notes:85]

[0001564590-22-028936:notes:100]
[same as prior period, unchanged from 0001564590-22-019520:notes:86]

[0001564590-22-028936:notes:101]
The carrying amount and estimated fair value of the Company’s financial instruments as of July 4, 2022 and January 3, 2022 were as follows:

[0001564590-22-028936:notes:102]
|  |  | As of |  |  | As of |  |
|  |  | July 4, 2022 |  |  | January 3, 2022 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | — |  |  | $ | — |  |  | $ | 297 |  |  | $ | 297 |  |
| Derivative liabilities, current |  |  | 3,649 |  |  |  | 3,649 |  |  |  | 4,295 |  |  |  | 4,295 |  |
| Senior Notes due March 2029 |  |  | 494,886 |  |  |  | 420,005 |  |  |  | 494,556 |  |  |  | 498,200 |  |
| Term Loan due September 2024 |  |  | 403,719 |  |  |  | 401,569 |  |  |  | 403,262 |  |  |  | 406,135 |  |
| ABL Revolving Loans |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |

[0001564590-22-028936:notes:103]
[same as prior period, unchanged from 0001564590-22-019520:notes:89]

[0001564590-22-028936:notes:104]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of July 4, 2022 and January 3, 2022, which are considered Level 2 inputs.

[0001564590-22-028936:notes:105]
As of July 4, 2022 and January 3, 2022, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of July 4, 2022 consisted of $67,175 held in the U.S., with the remaining $199,371 held by foreign subsidiaries.

[0001564590-22-028936:notes:106]
[same as prior period, unchanged from 0001564590-22-019520:notes:92]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-22-028936:notes:107]
(14) Commitments and Contingencies

[0001564590-22-028936:notes:108]
Legal Matters

[0001564590-22-028936:notes:109]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 4, 2022 and January 3, 2022. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:EarningsPerShareTextBlock

[0001564590-22-028936:notes:110]
(15) Earnings Per Share

[0001564590-22-028936:notes:111]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the quarter and two quarters ended July 4, 2022 and June 28, 2021:

[0001564590-22-028936:notes:112]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 4, 2022 |  |  | June 28, 2021 |  |  | July 4, 2022 |  |  | June 28, 2021 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income |  | $ | 27,792 |  |  | $ | 28,261 |  |  | $ | 45,038 |  |  | $ | 25,069 |  |
| Basic weighted average shares |  |  | 101,270 |  |  |  | 107,148 |  |  |  | 101,941 |  |  |  | 106,987 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,951 |  |  |  | 1,845 |  |  |  | 1,818 |  |  |  | 1,862 |  |
| Dilutive effect of outstanding warrants |  |  | — |  |  |  | 802 |  |  |  | 3 |  |  |  | 401 |  |
| Diluted shares |  |  | 103,221 |  |  |  | 109,795 |  |  |  | 103,762 |  |  |  | 109,250 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.27 |  |  | $ | 0.26 |  |  | $ | 0.44 |  |  | $ | 0.23 |  |
| Diluted |  | $ | 0.27 |  |  | $ | 0.26 |  |  | $ | 0.43 |  |  | $ | 0.23 |  |

[0001564590-22-028936:notes:113]
Performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock options to purchase 1,054 and 1,014 shares of common stock for the quarter and two quarters ended July 4, 2022, respectively, and 1,452 and 802 shares of common stock for the quarter and two quarters ended June 28, 2021, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met at July 4, 2022 and June 28, 2021, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common stock during the applicable quarter and two quarters and, as a result, the impact would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-22-028936:notes:114]
[same as prior period, unchanged from 0001564590-22-019520:notes:102]

[0001564590-22-028936:notes:115]
[same as prior period, unchanged from 0001564590-22-019520:notes:103]

[0001564590-22-028936:notes:116]
|  |  | Quarter Ended |  | Two Quarters Ended |
|  |  | July 4, |  |  | June 28, |  |  |  | July 4, |  |  | June 28, |  |  |
|  |  | 2022 |  |  | 2021 |  |  |  | 2022 |  |  | 2021 |  |  |
|  |  | (In thousands) |
| Cost of goods sold |  | $ | 1,172 |  |  | $ | 861 |  |  |  | $ | 2,448 |  |  | $ | 2,026 |  |  |
| Selling and marketing |  |  | 620 |  |  |  | 442 |  |  |  |  | 1,270 |  |  |  | 1,088 |  |  |
| General and administrative |  |  | 2,396 |  |  |  | 2,015 |  |  |  |  | 4,449 |  |  |  | 4,370 |  |  |
| Research and development |  |  | 239 |  |  |  | 32 |  |  |  |  | 494 |  |  |  | 75 |  |  |
| Stock-based compensation expense recognized |  | $ | 4,427 |  |  | $ | 3,350 |  |  |  | $ | 8,661 |  |  | $ | 7,559 |  |  |

[0001564590-22-028936:notes:117]
[same as prior period, unchanged from 0001564590-22-019520:notes:105]

[0001564590-22-028936:notes:118]
The following is a summary of total unrecognized compensation costs as of July 4, 2022:

[0001564590-22-028936:notes:119]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 38,698 |  |  |  | 1.7 |  |
| PRU awards |  |  | 3,506 |  |  |  | 1.8 |  |
| Stock options |  |  | 11 |  |  |  | 0.3 |  |
|  |  | $ | 42,215 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-22-028936:notes:120]
[same as prior period, unchanged from 0001564590-22-019520:notes:108]

[0001564590-22-028936:notes:121]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. On June 27, 2022, the Company completed its acquisition of Telephonics. As of July 4, 2022, the chief operating decision maker is still in the process of determining how to allocate resources and assess performance in relation to the acquisition of Telephonics.

[0001564590-22-028936:notes:122]
[same as prior period, unchanged from 0001564590-22-019520:notes:110]

[0001564590-22-028936:notes:123]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |  |
|  |  | July 4, 2022 |  |  | June 28, 2021 |  |  | July 4, 2022 |  |  | June 28, 2021 |  |  |
|  |  | (In thousands) |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 609,429 |  |  | $ | 553,480 |  |  | $ | 1,175,499 |  |  | $ | 1,063,966 |  |  |
| RF&S Components |  |  | 16,121 |  |  |  | 13,903 |  |  |  | 31,311 |  |  |  | 26,593 |  |  |
| Other (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,256 |  |  |
| Total net sales |  | $ | 625,550 |  |  | $ | 567,383 |  |  | $ | 1,206,810 |  |  | $ | 1,093,815 |  |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 91,908 |  |  | $ | 73,055 |  |  | $ | 148,448 |  |  | $ | 130,287 |  |  |
| RF&S Components |  |  | 6,678 |  |  |  | 4,730 |  |  |  | 12,428 |  |  |  | 8,592 |  |  |
| Corporate and Other (1) |  |  | (51,726 | ) |  |  | (26,472 | ) |  |  | (78,490 | ) |  |  | (56,861 | ) |  |
| Total operating segment income |  |  | 46,860 |  |  |  | 51,313 |  |  |  | 82,386 |  |  |  | 82,018 |  |  |
| Amortization of definite-lived intangibles (2) |  |  | (9,658 | ) |  |  | (10,425 | ) |  |  | (19,316 | ) |  |  | (21,330 | ) |  |
| Total operating income |  |  | 37,202 |  |  |  | 40,888 |  |  |  | 63,070 |  |  |  | 60,688 |  |  |
| Total other expense |  |  | (3,073 | ) |  |  | (10,773 | ) |  |  | (12,464 | ) |  |  | (34,872 | ) |  |
| Income before income taxes |  | $ | 34,129 |  |  | $ | 30,115 |  |  | $ | 50,606 |  |  | $ | 25,816 |  |  |

[0001564590-22-028936:notes:124]
|  |  | As of |  |
|  |  | July 4, 2022 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,744,414 |  |  | $ | 1,655,401 |  |
| RF&S Components |  |  | 211,136 |  |  |  | 216,737 |  |
| Corporate and Other (1) |  |  | 1,259,101 |  |  |  | 1,153,409 |  |
| Total assets |  | $ | 3,214,651 |  |  | $ | 3,025,547 |  |

[0001564590-22-028936:notes:125]
| (1) | Other represents results from the now closed SH E-MS and SZ facilities. As of July 4, 2022, Other includes assets acquired from the acquisition of Telephonics. |

[0001564590-22-028936:notes:126]
| (2) | Amortization of definite-lived intangibles primarily relates to the PCB and RF&S Components reportable segments. For the quarter and two quarters ended July 4, 2022, $1,383 and $2,767, respectively, of amortization expense is included in cost of goods sold. For the quarter and two quarters ended June 28, 2021, $1,383 and $2,767, respectively, of amortization expense is included in cost of goods sold. |

[0001564590-22-028936:notes:127]
[same as prior period, unchanged from 0001564590-22-019520:notes:115]

[0001564590-22-028936:notes:128]
[same as prior period, unchanged from 0001564590-22-019520:notes:116]

[0001564590-22-028936:notes:129]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |  |
|  |  | July 4, 2022 |  |  | June 28, 2021 |  |  | July 4, 2022 |  |  | June 28, 2021 |  |  |
|  |  | (In thousands) |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 274,480 |  |  | $ | 260,944 |  |  | $ | 538,881 |  |  | $ | 529,411 |  |  |
| China |  |  | 75,771 |  |  |  | 80,160 |  |  |  | 152,976 |  |  |  | 161,869 |  |  |
| Other |  |  | 275,299 |  |  |  | 226,279 |  |  |  | 514,953 |  |  |  | 402,535 |  |  |
| Total net sales |  | $ | 625,550 |  |  | $ | 567,383 |  |  | $ | 1,206,810 |  |  | $ | 1,093,815 |  |  |

[0001564590-22-028936:notes:130]
[same as prior period, unchanged from 0001564590-22-019520:notes:118]


## us-gaap:TreasuryStockTextBlock

[0001564590-22-028936:notes:131]
(18) Share Repurchase Program

[0001564590-22-028936:notes:132]
On February 3, 2021, the Company’s Board of Directors authorized and approved a share repurchase program. Under the program, the Company was authorized to repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through February 3, 2023. The program permitted the Company to repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (the Exchange Act) which sets certain restrictions on the method, timing, price, and volume of open market stock repurchases. In addition, the Company adopted a trading plan, which may be amended from time to time, in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases effected under the share repurchase program. The timing, manner, price, and amount of any repurchases were determined at the Company’s discretion. The repurchase program did not obligate the Company to acquire any specific number of shares.

[0001564590-22-028936:notes:133]
During the quarter ended July 4, 2022, the Company repurchased 374 shares of common stock for a total cost of $5,192 (including commissions) and during the two quarters ended July 4, 2022, the Company has repurchased a total of 2,747 shares of common stock for a total cost of $35,424 (including commissions). As of July 4, 2022, there are no amounts available for repurchase.
