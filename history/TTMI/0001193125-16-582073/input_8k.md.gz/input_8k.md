# TTMI 8-K — 0001171843-16-009432 filed 2016-04-27

## item codes, every 8-K on or before 2016-05-06

- 2016-04-27 0001171843-16-009432 — 2.02, 9.01
- 2016-03-08 0001193125-16-495457 — 5.03, 7.01, 9.01
- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2016-05-06

- none on or before 2016-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001171843-16-009432:8k_2_02:1]
EX-99.1
2
exh_991.htm
PRESS RELEASE

[0001171843-16-009432:8k_2_02:2]
EdgarFiling
EXHIBIT 99.1

[0001171843-16-009432:8k_2_02:3]
TTM Technologies, Inc. Reports First Quarter 2016 Results

[0001171843-16-009432:8k_2_02:4]
Strong Execution Drives Year on Year Improvement in Non-GAAP Net Income

[0001171843-16-009432:8k_2_02:5]
COSTA MESA, Calif., April  27, 2016  (GLOBE NEWSWIRE) -- TTM Technologies, Inc. (Nasdaq:TTMI), a major global printed circuit board (“PCB”) manufacturer, today reported results for the first quarter 2016, which ended March 28, 2016.  Our results include the contribution from the Viasystems Group, Inc. ("Viasystems") acquisition, which was completed on May 31, 2015.

[0001171843-16-009432:8k_2_02:6]
First Quarter 2016 Highlights

[0001171843-16-009432:8k_2_02:7]
Net sales were $583.3 million

[0001171843-16-009432:8k_2_02:8]
GAAP net loss attributable to stockholders was $7.3 million, or $0.07 per share

[0001171843-16-009432:8k_2_02:9]
Non-GAAP net income attributable to stockholders was $13.9 million, or $0.14 per diluted share

[0001171843-16-009432:8k_2_02:10]
Adjusted EBITDA was $74.5 million

[0001171843-16-009432:8k_2_02:11]
First Quarter 2016 Financial Results 
Net sales for the first quarter of 2016 were $583.3 million, compared to $329.2 million in the first quarter of 2015 and $668.9 million in the fourth quarter.

[0001171843-16-009432:8k_2_02:12]
GAAP operating income for the first quarter of 2016 was $18.9 million, compared to operating income of $8.3 million in the first quarter of 2015 and $36.5 million in the fourth quarter.

[0001171843-16-009432:8k_2_02:13]
GAAP net loss attributable to stockholders for the first quarter of 2016 was $7.3 million, or $0.07 per share.  This compares to GAAP net income of $3.4 million, or $0.04 per diluted share, in the first quarter of 2015 and $9.5 million, or $0.09 per diluted share, in the fourth quarter.  The GAAP results were negatively impacted by approximately $6.0 million of expenses related to the acquisition and integration of Viasystems.

[0001171843-16-009432:8k_2_02:14]
On a non-GAAP basis, net income attributable to stockholders for the first quarter of 2016 was $13.9 million, or $0.14 per diluted share.  This compares to non-GAAP net income of $10.8 million, or $0.13 per diluted share, for the first quarter of 2015 and $31.5 million, or $0.31 per diluted share, in the fourth quarter of last year.

[0001171843-16-009432:8k_2_02:15]
Adjusted EBITDA for the first quarter of 2016 was $74.5 million, or 12.8 percent of net sales, compared to adjusted EBITDA of $42.5 million, or 12.9 percent of net sales, for the first quarter of 2015 and $95.8 million, or 14.3 percent of net sales, for the fourth quarter of 2015.

[0001171843-16-009432:8k_2_02:16]
“Our first quarter results marked a solid start to the year and demonstrated the benefits of our diversification initiative,” said Tom Edman, CEO of TTM.  “Strong operational execution across all of our business units drove non-GAAP earnings above the high end of our guidance.  Relative strength in the aerospace and defense, automotive and computing end markets helped offset a softer demand environment in the cellular phone end market.”

[0001171843-16-009432:8k_2_02:17]
“We continue to deliver on our integration milestones and have now implemented or announced actions that represent more than 90% of our $55 million annualized synergy target.  The new market focused business unit structure put in place at the beginning of the year has already begun to yield operational benefits.  We believe a larger and more diverse TTM with focus on key end markets such as Aerospace & Defense and Automotive is an important differentiator in the PCB market,” concluded Mr. Edman.

[0001171843-16-009432:8k_2_02:18]
Business Outlook 
For the second quarter of 2016, TTM estimates that revenue will be in the range of $580 million to $620 million, and non-GAAP net income will be in the range of $0.16 to $0.22 per diluted share.

[0001171843-16-009432:8k_2_02:19]
To Access the Live Webcast/Conference Call
TTM will host a conference call and webcast to discuss first quarter 2016 results and second quarter 2016 outlook on Wednesday, April 27, 2016, at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time).  The conference call may include forward-looking statements.

[0001171843-16-009432:8k_2_02:20]
Telephone access is available by dialing domestic 888-417-8516 or international 719-325-2354 (ID 1413218).  The conference call also will be webcast on TTM’s website at www.ttm.com.

[0001171843-16-009432:8k_2_02:21]
To Access a Replay of the Webcast
The replay of the webcast will remain accessible for one week following the live event on TTM’s website at www.ttm.com.

[0001171843-16-009432:8k_2_02:22]
About TTM
TTM Technologies, Inc. is a major global printed circuit board manufacturer, focusing on quick-turn and technologically advanced PCBs, backplane assemblies and electro-mechanical solutions. TTM stands for time-to-market, representing how TTM's time-critical, one-stop manufacturing services enable customers to shorten the time required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001171843-16-009432:8k_2_02:23]
Forward-Looking Statements 
This release contains forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These statements reflect TTM's current expectations, and TTM does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond TTM's control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, the successful integration of Viasystems, including, the planned plant combinations and closure, general market and economic conditions, including interest rates, currency exchange rates and consumer spending, demand for TTM's products, market pressures on prices of TTM's products, warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements, TTM's dependence upon a small number of customers and other factors set forth in the "Risk Factors" and "Management's Discussion and Analysis of Financial Condition and Results of Operations" sections of the Company's public reports filed with the SEC.

[0001171843-16-009432:8k_2_02:24]
About Our Non-GAAP Financial Measures
This release includes information about TTM’s adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing financial performance.

[0001171843-16-009432:8k_2_02:25]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar non-GAAP financial measures used by other companies.  TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliation to the most directly comparable GAAP financial measure.  However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001171843-16-009432:8k_2_02:26]
- Tables Follow -

[0001171843-16-009432:8k_2_02:27]
| TTM TECHNOLOGIES, INC. |
| Selected Unaudited Financial Information |
| (In thousands, except per share data) |
|  |  |  |  |  |  | First Quarter |  | Fourth Quarter |  |
|  |  |  |  |  |  |  | 2016 |  |  |  | 2015 |  |  |  | 2015 |  |  |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |  |  |
|  | Net sales |  |  | $ | 583,258 |  |  | $ | 329,164 |  |  | $ | 668,874 |  |  |
|  | Cost of goods sold |  |  | 499,695 |  |  |  | 277,605 |  |  |  | 560,604 |  |  |
|  | Gross profit |  |  | 83,563 |  |  |  | 51,559 |  |  |  | 108,270 |  |  |
|  | Operating expenses: |  |  |  |  |  |  |  |
|  |  | Selling and marketing |  |  | 17,306 |  |  |  | 9,455 |  |  |  | 17,963 |  |  |
|  |  | General and administrative |  |  | 36,149 |  |  |  | 33,990 |  |  |  | 41,654 |  |  |
|  |  | Amortization of definite-lived intangibles |  |  | 5,947 |  |  |  | 1,874 |  |  |  | 6,683 |  |  |
|  |  | Restructuring charges |  |  | 1,913 |  |  |  | 479 |  |  |  | 5,429 |  |  |
|  |  | Impairment of long-lived assets |  |  | 3,346 |  |  |  | - |  |  |  | - |  |  |
|  |  | Gain on sale of asset |  |  | - |  |  |  | (2,504 | ) |  |  | - |  |  |
|  |  |  | Total operating expenses |  |  | 64,661 |  |  |  | 43,294 |  |  |  | 71,729 |  |  |
|  | Operating income (loss) |  |  | 18,902 |  |  |  | 8,265 |  |  |  | 36,541 |  |  |
|  | Interest expense |  |  | (21,784 | ) |  |  | (5,765 | ) |  |  | (20,208 | ) |  |
|  | Other, net |  |  |  | 1,209 |  |  |  | (415 | ) |  |  | 3,925 |  |  |
|  | Income (loss) before income taxes |  |  | (1,673 | ) |  |  | 2,085 |  |  |  | 20,258 |  |  |
|  | Income tax (provision) benefit |  |  | (5,477 | ) |  |  | 1,361 |  |  |  | (10,601 | ) |  |
|  | Net income (loss) |  | $ | (7,150 | ) |  | $ | 3,446 |  |  | $ | 9,657 |  |  |
|  | Net income attributable to noncontrolling interest |  |  | (114 | ) |  |  | - |  |  |  | (136 | ) |  |
|  | Net income (loss) attributable to stockholders |  | $ | (7,264 | ) |  | $ | 3,446 |  |  | $ | 9,521 |  |  |
|  | Earnings (loss) per share attributable to stockholders: |  |  |  |  |  |  |  |
|  |  | Basic |  |  | $ | (0.07 | ) |  | $ | 0.04 |  |  | $ | 0.10 |  |  |
|  |  | Diluted |  |  | $ | (0.07 | ) |  | $ | 0.04 |  |  | $ | 0.09 |  |  |
|  | Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |
|  |  | Basic |  |  |  | 99,596 |  |  |  | 83,603 |  |  |  | 99,134 |  |  |
|  |  | Diluted |  |  |  | 99,596 |  |  |  | 84,465 |  |  |  | 126,329 |  |  |
|  | Reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share: |  |  |  |
|  | Net income attributable to stockholders |  |  |  |  |  | $ | 9,521 |  |  |
|  |  | Add back items: interest expense, net of tax |  |  |  |  |  |  | 2,009 |  |  |
|  | Adjusted net income attributable to stockholders |  |  |  |  |  | $ | 11,530 |  |  |
|  | Weighted-average shares outstanding |  |  |  |  |  |  | 99,134 |  |  |
|  | Dilutive effect of convertible debt |  |  |  |  |  |  | 25,940 |  |  |
|  | Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  |  |  |  |  | 1,255 |  |  |
|  | Diluted shares |  |  |  |  |  |  | 126,329 |  |  |
|  | Earnings per share attributable to stockholders: |  |  |  |  |  |  |  |
|  |  | Basic |  |  |  |  |  |  | $ | 0.10 |  |  |
|  |  | Diluted |  |  |  |  |  |  | $ | 0.09 |  |  |
| SELECTED BALANCE SHEET DATA |  |  |  |  |  |  |  |
|  |  |  |  |  |  | March 28, 2016 |  | December 28, 2015 |  |  |  |
|  | Cash and cash equivalents, including restricted cash |  | $ | 183,678 |  |  | $ | 262,630 |  |  |  |  |
|  | Accounts and notes receivable, net |  |  | 431,276 |  |  |  | 454,001 |  |  |  |  |
|  | Inventories |  |  |  | 264,555 |  |  |  | 268,923 |  |  |  |  |
|  | Total current assets |  |  | 908,210 |  |  |  | 1,022,520 |  |  |  |  |
|  | Property, plant and equipment, net |  |  | 1,075,613 |  |  |  | 1,103,067 |  |  |  |  |
|  | Other non-current assets |  |  | 512,009 |  |  |  | 545,717 |  |  |  |  |
|  | Total assets |  |  | 2,495,832 |  |  |  | 2,640,133 |  |  |  |  |
|  | Short-term debt, including current portion of long-term debt |  | $ | 80,358 |  |  | $ | 157,375 |  |  |  |  |
|  | Accounts payable |  |  | 308,156 |  |  |  | 347,916 |  |  |  |  |
|  | Total current liabilities |  |  | 598,406 |  |  |  | 744,994 |  |  |  |  |
|  | Debt, net of discount |  |  | 1,021,866 |  |  |  | 1,013,411 |  |  |  |  |
|  | Total long-term liabilities |  |  | 1,079,499 |  |  |  | 1,068,470 |  |  |  |  |
|  | Total equity |  |  | 817,927 |  |  |  | 826,669 |  |  |  |  |
|  | Total liabilities and equity |  |  | 2,495,832 |  |  |  | 2,640,133 |  |  |  |  |
| SUPPLEMENTAL DATA |  |  |  |  |  |  |  |
|  |  |  |  |  |  | First Quarter |  | Fourth Quarter |  |
|  |  |  |  |  |  |  | 2016 |  |  |  | 2015 |  |  |  | 2015 |  |  |
|  | Gross margin |  |  | 14.3 | % |  |  | 15.7 | % |  |  | 16.2 | % |  |
|  | Operating margin |  |  | 3.2 | % |  |  | 2.5 | % |  |  | 5.5 | % |  |
|  | End Market Breakdown: |  |  |  |  |  |  |  |
|  |  |  |  |  |  | First Quarter |  | Fourth Quarter |  |
|  |  |  |  |  |  |  | 2016 |  |  |  | 2015 |  |  |  | 2015 |  |  |
|  |  | Aerospace/Defense |  |  | 15 | % |  |  | 15 | % |  |  | 13 | % |  |
|  |  | Automotive |  |  | 21 | % |  |  | 3 | % |  |  | 18 | % |  |
|  |  | Cellular Phone |  |  | 9 | % |  |  | 30 | % |  |  | 18 | % |  |
|  |  | Computing/Storage/Peripherals |  |  | 13 | % |  |  | 11 | % |  |  | 12 | % |  |
|  |  | Medical/Industrial/Instrumentation |  |  | 16 | % |  |  | 9 | % |  |  | 13 | % |  |
|  |  | Networking/Communications |  |  | 24 | % |  |  | 29 | % |  |  | 23 | % |  |
|  |  | Other |  |  |  | 2 | % |  |  | 3 | % |  |  | 3 | % |  |
|  | Stock-based Compensation: |  |  |  |  |  |  |  |
|  |  |  |  |  |  | First Quarter |  | Fourth Quarter |  |
|  |  |  |  |  |  |  | 2016 |  |  |  | 2015 |  |  |  | 2015 |  |  |
|  |  | Amount included in: |  |  |  |  |  |  |  |
|  |  |  | Cost of goods sold |  | $ | 320 |  |  | $ | 225 |  |  | $ | 327 |  |  |
|  |  |  | Selling and marketing |  |  | 210 |  |  |  | 271 |  |  |  | 301 |  |  |
|  |  |  | General and administrative |  |  | 1,716 |  |  |  | 1,544 |  |  |  | 2,007 |  |  |
|  |  |  | Total stock-based compensation expense |  | $ | 2,246 |  |  | $ | 2,040 |  |  | $ | 2,635 |  |  |
|  | Operating Segment Data: |  |  |  |  |  |  |  |
|  |  |  |  |  |  | First Quarter |  | Fourth Quarter |  |
|  |  | Net sales: |  |  | 2016 |  |  |  | 2015 |  |  |  | 2015 |  |  |
|  |  | PCB |  |  | $ | 529,945 |  |  | $ | 310,324 |  |  | $ | 611,045 |  |  |
|  |  | E-M Solutions |  |  | 56,478 |  |  |  | 19,462 |  |  |  | 61,021 |  |  |
|  |  | Corporate |  |  | - |  |  |  | - |  |  |  | - |  |  |
|  |  |  | Total sales |  |  | 586,423 |  |  |  | 329,786 |  |  |  | 672,066 |  |  |
|  |  | Inter-segment sales |  |  | (3,165 | ) |  |  | (622 | ) |  |  | (3,192 | ) |  |
|  |  |  | Total net sales |  | $ | 583,258 |  |  | $ | 329,164 |  |  | $ | 668,874 |  |  |
|  |  | Operating segment income: |  |  |  |  |  |  |  |
|  |  | PCB |  |  | $ | 49,367 |  |  | $ | 23,260 |  |  | $ | 66,320 |  |  |
|  |  | E-M Solutions |  |  | 387 |  |  |  | 651 |  |  |  | 2,612 |  |  |
|  |  | Corporate |  |  | (24,905 | ) |  |  | (13,772 | ) |  |  | (25,708 | ) |  |
|  |  |  | Total operating segment income |  |  | 24,849 |  |  |  | 10,139 |  |  |  | 43,224 |  |  |
|  |  | Amortization of definite-lived intangibles |  |  | (5,947 | ) |  |  | (1,874 | ) |  |  | (6,683 | ) |  |
|  |  |  | Total operating income |  |  | 18,902 |  |  |  | 8,265 |  |  |  | 36,541 |  |  |
|  |  | Total other expense |  |  | (20,575 | ) |  |  | (6,180 | ) |  |  | (16,283 | ) |  |
|  |  | Income before income taxes |  | $ | (1,673 | ) |  | $ | 2,085 |  |  | $ | 20,258 |  |  |
| RECONCILIATIONS1 |  |  |  |  |  |  |  |
|  |  |  |  |  |  | First Quarter |  | Fourth Quarter |  |
|  |  |  |  |  |  |  | 2016 |  |  |  | 2015 |  |  |  | 2015 |  |  |
|  | Non-GAAP gross profit reconciliation2: |  |  |  |  |  |  |  |
|  |  | GAAP gross profit |  | $ | 83,563 |  |  | $ | 51,559 |  |  | $ | 108,270 |  |  |
|  |  | Add back item: |  |  |  |  |  |  |  |
|  |  |  | Inventory markup and PP&E step up |  |  | - |  |  |  | - |  |  |  | 598 |  |  |
|  |  |  | Stock-based compensation |  |  | 320 |  |  |  | 225 |  |  |  | 327 |  |  |
|  |  | Non-GAAP gross profit |  | $ | 83,883 |  |  | $ | 51,784 |  |  | $ | 109,195 |  |  |
|  |  | Non-GAAP gross margin |  |  | 14.4 | % |  |  | 15.7 | % |  |  | 16.3 | % |  |
|  | Non-GAAP operating income reconciliation3: |  |  |  |  |  |  |  |
|  |  | GAAP operating income (loss) |  | $ | 18,902 |  |  | $ | 8,265 |  |  | $ | 36,541 |  |  |
|  |  | Add back items: |  |  |  |  |  |  |  |
|  |  |  | Amortization of definite-lived intangibles |  |  | 5,947 |  |  |  | 1,874 |  |  |  | 6,683 |  |  |
|  |  |  | Stock-based compensation |  |  | 2,246 |  |  |  | 2,040 |  |  |  | 2,635 |  |  |
|  |  |  | Gain on sale of asset |  |  | - |  |  |  | (2,504 | ) |  |  | - |  |  |
|  |  |  | Acquisition-related costs |  |  | 691 |  |  |  | 8,235 |  |  |  | 1,521 |  |  |
|  |  |  | Inventory markup and PP&E step up |  |  | - |  |  |  | - |  |  |  | 598 |  |  |
|  |  |  | Impairments and restructuring charges |  |  | 5,259 |  |  |  | 479 |  |  |  | 5,429 |  |  |
|  |  | Non-GAAP operating income |  | $ | 33,045 |  |  | $ | 18,389 |  |  | $ | 53,407 |  |  |
|  |  | Non-GAAP operating margin |  |  | 5.7 | % |  |  | 5.6 | % |  |  | 8.0 | % |  |
|  | Non-GAAP net income and EPS attributable to stockholders reconciliation4: |  |  |  |  |  |  |  |
|  |  | GAAP net income (loss) attributable to stockholders |  | $ | (7,264 | ) |  | $ | 3,446 |  |  | $ | 9,521 |  |  |
|  |  | Add back items: |  |  |  |  |  |  |  |
|  |  |  | Amortization of definite-lived intangibles |  |  | 5,947 |  |  |  | 1,874 |  |  |  | 6,683 |  |  |
|  |  |  | Stock-based compensation |  |  | 2,246 |  |  |  | 2,040 |  |  |  | 2,635 |  |  |
|  |  |  | Non-cash interest expense |  |  | 6,154 |  |  |  | 2,625 |  |  |  | 4,893 |  |  |
|  |  |  | Gain on sale of asset |  |  | - |  |  |  | (2,504 | ) |  |  | - |  |  |
|  |  |  | Acquisition-related costs |  |  | 691 |  |  |  | 8,235 |  |  |  | 1,521 |  |  |
|  |  |  | Inventory markup and PP&E step up |  |  | - |  |  |  | - |  |  |  | 598 |  |  |
|  |  |  | Impairments, restructuring and other charges |  |  | 5,259 |  |  |  | 479 |  |  |  | 5,429 |  |  |
|  |  |  | Income taxes |  |  | 821 |  |  |  | (5,366 | ) |  |  | 247 |  |  |
|  |  | Non-GAAP net income attributable to stockholders |  | $ | 13,854 |  |  | $ | 10,829 |  |  | $ | 31,527 |  |  |
|  |  | Non-GAAP earnings per diluted share attributable to stockholders |  | $ | 0.14 |  |  | $ | 0.13 |  |  | $ | 0.31 |  |  |
|  | Non-GAAP diluted number of shares5: |  |  |  |  |  |  |  |
|  |  | Diluted shares |  |  | 99,596 |  |  |  | 84,465 |  |  |  | 126,329 |  |  |
|  |  | Dilutive effect of convertible debt |  |  | - |  |  |  | - |  |  |  | (25,940 | ) |  |
|  |  | Non-GAAP diluted number of shares |  |  | 99,596 |  |  |  | 84,465 |  |  |  | 100,389 |  |  |
|  | Adjusted EBITDA reconciliation6: |  |  |  |  |  |  |  |
|  |  | GAAP net income (loss) |  | $ | (7,150 | ) |  | $ | 3,446 |  |  | $ | 9,657 |  |  |
|  |  | Add back items: |  |  |  |  |  |  |  |
|  |  |  | Income tax provision (benefit) |  |  | 5,477 |  |  |  | (1,361 | ) |  |  | 10,601 |  |  |
|  |  |  | Interest expense |  |  | 21,784 |  |  |  | 5,765 |  |  |  | 20,208 |  |  |
|  |  |  | Amortization of definite-lived intangibles |  |  | 5,947 |  |  |  | 1,874 |  |  |  | 6,683 |  |  |
|  |  |  | Depreciation expense |  |  | 40,227 |  |  |  | 24,536 |  |  |  | 39,105 |  |  |
|  |  |  | Stock-based compensation |  |  | 2,246 |  |  |  | 2,040 |  |  |  | 2,635 |  |  |
|  |  |  | Gain on sale of asset |  |  | - |  |  |  | (2,504 | ) |  |  | - |  |  |
|  |  |  | Acquisition-related costs |  |  | 691 |  |  |  | 8,235 |  |  |  | 1,521 |  |  |
|  |  |  | Impairments, restructuring and other charges |  |  | 5,259 |  |  |  | 479 |  |  |  | 5,429 |  |  |
|  |  | Adjusted EBITDA |  | $ | 74,481 |  |  | $ | 42,510 |  |  | $ | 95,839 |  |  |
|  |  | Adjusted EBITDA margin |  |  | 12.8 | % |  |  | 12.9 | % |  |  | 14.3 | % |  |
|  | Free cash flow reconciliation: |  |  |  |  |  |  |  |
|  |  | Operating cash flow |  |  | 17,892 |  |  |  | 67,354 |  |  |  | 139,829 |  |  |
|  |  | Add back items: |  |  |  |  |  |  |  |
|  |  |  | Payment of acquisition-related costs |  |  | 2,324 |  |  |  | 4,720 |  |  |  | 1,522 |  |  |
|  |  | Adjusted operating cash flow |  |  | 20,216 |  |  |  | 72,074 |  |  |  | 141,351 |  |  |
|  |  | Capital expenditures, net |  |  | (20,116 | ) |  |  | (22,776 | ) |  |  | (22,967 | ) |  |
|  |  | Free cash flow |  | $ | 100 |  |  | $ | 49,298 |  |  | $ | 118,384 |  |  |

[0001171843-16-009432:8k_2_02:28]
| 1 This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income attributable to stockholders, non-GAAP EPS attributable to stockholders, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |
| 2 Non-GAAP gross profit and gross margin measures exclude stock-based compensation expense, inventory markup and PP&E step up. |
| 3 Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges. |
| 4 This information provides non-GAAP net income attributable to stockholders and non-GAAP EPS attributable to stockholders, which are non-GAAP financial measures. Management believes that both measures -- which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items -- provide additional useful information to investors regarding the Company's ongoing financial condition and results of operations. |
| 5 Non-GAAP diluted number of shares used in computing non-GAAP earnings per share attributable to stockholders excludes the dilutive effect of convertible debt. |
| 6 Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |

[0001171843-16-009432:8k_2_02:29]
Contact:
Sameer Desai,
Senior Director, Corporate 
Development & Investor Relations
sameer.desai@ttmtech.com 
714-327-3050
