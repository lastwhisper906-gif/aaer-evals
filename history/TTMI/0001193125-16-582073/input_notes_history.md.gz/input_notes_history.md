# TTMI note change history — 0001193125-15-366187 → 0001193125-16-582073


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001193125-16-582073:note_history:1]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of March 28, 2016 and
 December 28, 2015. However, these amounts are not material to
 the consolidated condensed financial statements of the
 Company.
  (was, 2015-11-04, similarity 0.9907):
[0001193125-15-366187:note_history:1]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of September 28, 2015 and
 December 29, 2014. However, these amounts are not material to
 the consolidated condensed financial statements of the
 Company.

- changed (2016-05-06):
[0001193125-16-582073:note_history:2]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States, Canada and Mexico comply in all
 material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted new
 rules and regulations governing environmental issues. An update to
 the Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the updated environmental regulations. The Company believes it
 has developed plans acceptable to the Chinese government and is in
 the process of implementing these plans. The Company does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan related to the efforts to come into full
 compliance with the new regulations. The 2016 capital expenditure
 costs expected for these plans are included in the Company’s
 capital expenditure projections.
  (was, 2015-11-04, similarity 0.9936):
[0001193125-15-366187:note_history:2]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States, Canada and Mexico comply in all
 material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted
 new rules and regulations governing environmental issues. An
 update to the Chinese environmental waste water law was issued in
 late 2012, but allows for an interim period in which plants subject
 to such law may install equipment that meets the new regulatory
 regime. Some of the Company’s plants in China are not yet in
 full compliance with the updated environmental
 regulations. The Company believes it has developed plans
 acceptable to the Chinese government and is in the process of
 implementing these plans. The Company does not anticipate any
 immediate risk of government fines or temporary closure of its
 Chinese plants. The Company has established and enacted an
 investment plan related to the efforts to come into full compliance
 with the new regulations. The 2015 capital expenditure costs
 expected for these plans are included in the Company’s
 capital expenditure projections.

- removed (2016-05-06):
[0001193125-15-366187:note_history:3]
Class Action Complaints
 related to Viasystems Acquisition

- removed (2016-05-06):
[0001193125-15-366187:note_history:4]
Since
 the public announcement on September 22, 2014 of the execution
 of the Merger Agreement, Viasystems, TTM, and the members of the
 Viasystems Board have been named as defendants in two putative
 class action complaints challenging the acquisition of Viasystems.
 The first lawsuit, filed in the Circuit Court of St. Louis County,
 Missouri on September 30, 2014 (the Missouri Lawsuit), and the
 second lawsuit, filed in the Court of Chancery of the State of
 Delaware on October 13, 2014 (the Delaware Lawsuit and,
 together with the Missouri Lawsuit, the Lawsuits), generally allege
 that the Merger fails to properly value Viasystems, that the
 individual defendants breached their fiduciary duties in approving
 the Merger Agreement, and that those breaches were aided and
 abetted by TTM and Viasystems.

- removed (2016-05-06):
[0001193125-15-366187:note_history:5]
The
 Delaware Lawsuit specifically alleges, among other allegations,
 that (1) the Viasystems Board breached its fiduciary duties
 by: (a) agreeing to the Merger for grossly inadequate
 consideration, (b) agreeing to lock up the Merger with deal
 protection devices that prevent other bidders from making a
 successful competing offer for Viasystems, and
 (c) participating in a transaction where the loyalties of the
 Viasystems Board and management are divided; (2) the voting
 agreements entered into between the Company and certain of
 Viasystems’ significant stockholders prevent Viasystems
 stockholders from providing a meaningful vote on the proposal to
 adopt the Merger; and (3) that those breaches of fiduciary
 duties were aided and abetted by TTM, Merger Sub, and Viasystems.
 Further, the Missouri Lawsuit specifically alleges, among other
 allegations, that (1) the proposed Merger is unfair and the
 consideration to be paid in connection with the Merger is
 inadequate; (2) the Viasystems Board and Viasystems’
 management have a conflict of interest due to the cash pool bonus
 and change in control payments to be made to certain executive
 officers and key employees if the Merger is consummated; and
 (3) the Merger Agreement contains impermissible deal
 protection devices.

- removed (2016-05-06):
[0001193125-15-366187:note_history:6]
The
 Lawsuits seek injunctive relief to enjoin the defendants from
 completing the Merger on the agreed-upon terms, rescinding, to the
 extent already implemented, the Merger Agreement or any of the
 terms therein, costs and disbursements and attorneys’ and
 experts’ fees and costs, as well as other equitable relief as
 the respective court deems proper. The Delaware Lawsuit also seeks:
 (1) in the event the Merger is consummated prior to the entry
 of the court’s final judgment, rescissory damages as an
 alternative to rescission, and (2) an accounting by all
 defendants to the plaintiff and other members of the class for all
 damages caused by the defendants and for all profits and any
 special benefits obtained as a result of their alleged breaches of
 their fiduciary duties.

- removed (2016-05-06):
[0001193125-15-366187:note_history:7]
On
 January 6, 2015, the parties to the Missouri Lawsuit entered
 into a Memorandum of Understanding (MOU) with respect to a proposed
 settlement that will terminate both Lawsuits upon entry of the
 final judgment. Pursuant to the terms of the MOU, the parties
 entered into a stipulation of settlement on May 22, 2015, that
 remains subject to customary conditions, including court approval.
 The settlement agreement does not require the defendants to pay any
 monetary consideration to the proposed settlement class. The
 settlement agreement provides for payment of attorneys’ fees
 of the plaintiffs and reimbursement of expenses, in the amount to
 be determined by the court, but not to exceed $550. If the
 stipulation of settlement is approved by the court, it will fully
 and finally resolve all of the claims asserted, or that could have
 been asserted, in the Lawsuit against the defendants, and provide a
 release by the proposed settlement class of all claims against the
 defendants and their respective affiliates and agents in connection
 with the Merger.

- removed (2016-05-06):
[0001193125-15-366187:note_history:8]
The
 proposed settlement is subject to the preliminary approval of the
 court as well as the court’s final approval after notice of
 the terms of the settlement has been provided to the proposed
 settlement class. Timing of the approval process is dependent on
 the court’s calendar. Members of the proposed settlement
 class will have the right to object to the settlement in writing to
 the court once the court has set a hearing for final
 approval.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001193125-16-582073:note_history:9]
TTM
 Technologies, Inc. (the Company or TTM) is a major global printed
 circuit board (PCB) manufacturer, focusing on quick-turn and
 technologically advanced PCBs and electro-mechanical solutions (E-M
 Solutions). The Company provides time-to-market and advanced
 technology products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final volume production. This one-stop manufacturing solution
 allows the Company to align technology developments with the
 diverse needs of the Company’s customers and to enable them
 to reduce the time required to develop new products and bring them
 to market.
  (was, 2015-11-04, similarity 0.9835):
[0001193125-15-366187:note_history:9]
TTM
 Technologies, Inc. (the Company or TTM) is a major global printed
 circuit board (PCB) manufacturer, focusing on quick-turn and
 technologically advanced PCBs, backplane assemblies and
 electro-mechanical solutions (E-M Solutions). The Company provides
 time-to-market and advanced technology products and offers a
 one-stop manufacturing solution to customers from engineering
 support to prototype development through final volume production.
 This one-stop manufacturing solution allows the Company to align
 technology developments with the diverse needs of the
 Company’s customers and to enable them to reduce the time
 required to develop new products and bring them to
 market.

- changed (2016-05-06):
[0001193125-16-582073:note_history:10]
The
 Company serves a diversified customer base in various markets
 throughout the world, including manufacturers of
 networking/communications infrastructure products, tablets and
 smartphones, as well as the aerospace and defense, automotive
 controls and information systems, high-end computing, and medical,
 industrial and instrumentation related products. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.
  (was, 2015-11-04, similarity 0.8618):
[0001193125-15-366187:note_history:10]
The
 Company serves a diversified customer base in various markets
 throughout the world, including manufacturers of
 networking/communications infrastructure products, touchscreen
 tablets and smartphones, as well as the aerospace and defense,
 automotive, high-end computing, and industrial/medical industries.
 The Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

- changed (2016-05-06):
[0001193125-16-582073:note_history:11]
Recently Adopted and
 Issued Accounting Standards
  (was, 2015-11-04, similarity 0.8571):
[0001193125-15-366187:note_history:11]
Recently Issued
 Accounting Standards

- added (2016-05-06):
[0001193125-16-582073:note_history:12]
In
 March 2016, the Financial Accounting Standards Board (FASB) issued
 Accounting Standards Update (ASU) 2016-09, Stock Compensation
 (Topic 718): Improvements to Employee Share-Based Payment
 Accounting. The objective of this update is to simplify several
 aspects of the accounting for employee share-based payment
 transactions, including the income tax consequences, classification
 of awards as either equity or liabilities, and classification on
 the statement of cash flows. This ASU is effective for fiscal years
 beginning after December 15, 2016, including interim periods within
 those fiscal years. Early adoption is permitted. The Company is
 currently evaluating the new guidance to determine the impact it
 may have on its consolidated condensed financial statements and
 related disclosures.

- added (2016-05-06):
[0001193125-16-582073:note_history:13]
In
 February 2016, the FASB issued ASU 2016-02, Leases (Topic
 842). The objective of this update is to increase transparency
 and comparability among organizations by recognizing lease assets
 and lease liabilities on the balance sheet and disclosing key
 information about leasing arrangements. This ASU is effective for
 fiscal years beginning after December 15, 2018, including interim
 periods within those annual periods and is to be applied utilizing
 a modified retrospective approach. The Company is currently
 evaluating the new guidance to determine the impact it may have on
 its consolidated financial statements and related
 disclosures.

- added (2016-05-06):
[0001193125-16-582073:note_history:14]
In
 April 2015, the FASB issued ASU 2015-03, Imputation of
 Interest, as amended, which requires an entity to record debt
 issuance costs related to debt reported in the balance sheet as a
 direct deduction from the face amount of that debt. The update is
 effective for annual periods ending after December 15, 2015.
 Early application is permitted. The standard requires the use of
 the retrospective transition method. In the first quarter ended
 March 28, 2016, the Company adopted the new standard. Accordingly,
 as of March 28, 2016, approximately $29,230 of unamortized debt
 issuance costs were presented as a reduction of long-term debt on
 the Company’s consolidated condensed balance sheets.
 Furthermore, the Company reclassified approximately $31,171 of
 unamortized debt issuance costs that had been presented as other
 non-current assets as of December 28, 2015.

- added (2016-05-06):
[0001193125-16-582073:note_history:15]
In May
 2014, the FASB issued ASU 2014-09, Revenue from Contracts with
 Customers, as amended, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. The ASU will
 replace most existing revenue recognition guidance in U.S. GAAP
 when it becomes effective. The new standard is effective for the
 Company at the beginning of fiscal year 2018, however application
 of the standard is allowed as early as the beginning of fiscal
 2017. The standard permits the use of either the retrospective or
 cumulative effect transition method. The Company is evaluating the
 effect that ASU 2014-09 will have on its consolidated condensed
 financial statements and related disclosures. The Company has not
 yet selected a transition method nor has it determined the effect
 of the standard on its ongoing financial reporting.

- removed (2016-05-06):
[0001193125-15-366187:note_history:16]
In
 September 2015, the Financial Accounting Standards Board (FASB)
 issued Accounting Standard Update (ASU) 2015-16, Simplifying the
 Accounting for Measurement-Period Adjustments, which requires
 that an acquirer recognize adjustments to provisional values of
 assets acquired and liabilities assumed in a business combination
 in the reporting period in which the adjustment amounts are
 determined. This update requires that the acquirer record, in the
 same period’s financial statements, the effect on earnings of
 changes in depreciation, amortization, or other income effects, if
 any, as a result of the change to the provisional amounts,
 calculated as if the accounting had been completed at the
 acquisition date. This update also requires an entity to present
 separately on the face of the income statement or disclose in the
 notes the portion of the amount recorded in current-period earnings
 by line item that would have been recorded in previous reporting
 periods if the adjustment to the provisional amounts had been
 recognized as of the acquisition date. The Company adopted ASU
 2015-16 in the third quarter of 2015, and the Company’s
 adoption did not have an impact on its ongoing
 reporting.

- removed (2016-05-06):
[0001193125-15-366187:note_history:17]
In
 April 2015, the FASB issued ASU 2015-03, Interest-Imputation of
 Interest, which requires an entity to record debt issuance
 costs related to a note reported in the balance sheet as a direct
 deduction from the face amount of that note. The update is
 effective for annual periods ending after December 15, 2015.
 Early application is permitted. The standard requires the use of
 the retrospective transition method. The impact on the
 Company’s consolidated financial statements is not expected
 to be material.

- removed (2016-05-06):
[0001193125-15-366187:note_history:18]
In
 August 2014, the FASB issued ASU 2014-15, Disclosure of
 Uncertainties About an Entity’s Ability to Continue as a
 Going Concern, which provides guidance on determining when and
 how to disclose going concern uncertainties in the financial
 statements. The new standard requires management to perform interim
 and annual assessments of an entity’s ability to continue as
 a going concern. The update is effective for annual periods ending
 after December 15, 2016, and interim periods thereafter. Early
 adoption is permitted. The Company adopted ASU 2014-15 at the
 beginning of 2015, and the Company’s adoption did not have an
 impact on its ongoing reporting.

- removed (2016-05-06):
[0001193125-15-366187:note_history:19]
In
 May 2014, the FASB issued ASU 2014-09, Revenue from
 Contracts with Customers, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. ASU 2014-09
 will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2018, however
 application of the standard is allowed as early as the beginning of
 fiscal 2017. The standard permits the use of either the
 retrospective or cumulative effect transition method. The Company
 is evaluating the effect that ASU 2014-09 will have on its
 consolidated financial statements and related disclosures. The
 Company has not yet selected a transition method, nor has the
 Company determined the effect of the standard on its ongoing
 financial reporting.


## ttmi:ConvertibleSeniorNotesTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2016-05-06):
[0001193125-15-366187:note_history:20]
(7) Convertible Senior
 Notes

- removed (2016-05-06):
[0001193125-15-366187:note_history:21]
Convertible Senior
 Notes due 2020

- removed (2016-05-06):
[0001193125-15-366187:note_history:22]
The Company issued 1.75% convertible senior notes due
 December 15, 2020, in a public offering for an aggregate
 principal amount of $250,000. The convertible senior notes bear
 interest at a rate of 1.75% per annum. Interest is payable
 semiannually in arrears on June 15 and December 15 of
 each year. The convertible senior notes are senior unsecured
 obligations and rank equally to the Company’s future
 unsecured senior indebtedness and are senior in right of payment to
 any of the Company’s future subordinated
 indebtedness.

- removed (2016-05-06):
[0001193125-15-366187:note_history:23]
Convertible Senior
 Notes due 2015

- removed (2016-05-06):
[0001193125-15-366187:note_history:24]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015, in a public offering for an aggregate principal
 amount of $175,000. During the three quarters ended
 September 28, 2015, the outstanding principal of $32,395 plus
 accrued interest was paid in full.

- removed (2016-05-06):
[0001193125-15-366187:note_history:25]
As of September 28, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:

- removed (2016-05-06):
[0001193125-15-366187:note_history:26]
|  |  | As of September 28, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (47,355 | ) |  | $ | 202,645 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 250,000 |  |  | $ | (47,355 | ) |  | $ | 202,645 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |
|  |  | As of September 28, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
| Total |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |

- removed (2016-05-06):
[0001193125-15-366187:note_history:27]
The components of interest expense resulting from the
 convertible senior notes for the quarter and three quarters ended
 September 28, 2015 and September 29, 2014 were as
 follows:

- removed (2016-05-06):
[0001193125-15-366187:note_history:28]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 28, 2015 |  |  | September 29, 2014 |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,273 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 263 |  |  |  | 395 |  |  |  | 790 |  |
|  |  | $ | 1,094 |  |  | $ | 1,357 |  |  | $ | 3,676 |  |  | $ | 4,063 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,898 |  |  | $ | 1,779 |  |  | $ | 5,603 |  |  | $ | 5,294 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 352 |  |  |  | 554 |  |  |  | 1,036 |  |
|  |  | $ | 1,898 |  |  | $ | 2,131 |  |  | $ | 6,157 |  |  | $ | 6,330 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 190 |  |  | $ | 178 |  |  | $ | 561 |  |  | $ | 531 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 36 |  |  |  | 56 |  |  |  | 104 |  |
|  |  | $ | 190 |  |  | $ | 214 |  |  | $ | 617 |  |  | $ | 635 |  |

- removed (2016-05-06):
[0001193125-15-366187:note_history:29]
As of September 28, 2015 and December 29, 2014,
 remaining unamortized debt issuance costs included in other
 non-current assets were $4,746 and $5,363, respectively. The debt
 issuance costs and debt discount are being amortized to interest
 expense over the term of the convertible senior notes using the
 effective interest rate method. At September 28, 2015, the
 remaining weighted average amortization period for the unamortized
 senior convertible note discount and debt issuance costs was
 5.2 years.

- removed (2016-05-06):
[0001193125-15-366187:note_history:30]
For the quarter and three quarters ended September 28,
 2015 and September 29, 2014, the amortization of debt discount
 and debt issuance costs for the 2020 convertible senior notes and
 the 2015 convertible senior notes was based on an effective
 interest rate of 6.48% and 8.37%, respectively.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001193125-16-582073:note_history:31]
The
 components of interest expense resulting from the convertible
 senior notes for the quarters ended March 28, 2016 and
 March 30, 2015 are as follows:
  (was, 2015-11-04, similarity 0.8673):
[0001193125-15-366187:note_history:31]
The
 components of interest expense resulting from the convertible
 senior notes for the quarter and three quarters ended
 September 28, 2015 and September 29, 2014 were as
 follows:

- changed (2016-05-06):
[0001193125-16-582073:note_history:32]
|  |  | For the Quarter Ended |  |
|  |  | March 28, 2016 |  |  | March 30, 2015 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 263 |  |
|  |  | $ | 1,094 |  |  | $ | 1,357 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,960 |  |  | $ | 1,838 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 367 |  |
|  |  | $ | 1,960 |  |  | $ | 2,205 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 196 |  |  | $ | 184 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 37 |  |
|  |  | $ | 196 |  |  | $ | 221 |  |
  (was, 2015-11-04, similarity 0.7457):
[0001193125-15-366187:note_history:32]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 28, 2015 |  |  | September 29, 2014 |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,273 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 263 |  |  |  | 395 |  |  |  | 790 |  |
|  |  | $ | 1,094 |  |  | $ | 1,357 |  |  | $ | 3,676 |  |  | $ | 4,063 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,898 |  |  | $ | 1,779 |  |  | $ | 5,603 |  |  | $ | 5,294 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 352 |  |  |  | 554 |  |  |  | 1,036 |  |
|  |  | $ | 1,898 |  |  | $ | 2,131 |  |  | $ | 6,157 |  |  | $ | 6,330 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 190 |  |  | $ | 178 |  |  | $ | 561 |  |  | $ | 531 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 36 |  |  |  | 56 |  |  |  | 104 |  |
|  |  | $ | 190 |  |  | $ | 214 |  |  | $ | 617 |  |  | $ | 635 |  |


## ttmi:ScheduleOfLiabilityAndEquityComponentsOfConvertibleNotesTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2016-05-06):
[0001193125-15-366187:note_history:33]
As of September 28, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:

- removed (2016-05-06):
[0001193125-15-366187:note_history:34]
|  |  | As of September 28, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (47,355 | ) |  | $ | 202,645 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 250,000 |  |  | $ | (47,355 | ) |  | $ | 202,645 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |
|  |  | As of September 28, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
| Total |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2016-05-06):
[0001193125-16-582073:note_history:35]
As of
 March 28, 2016 and December 28, 2015, the following summarizes
 the equity components of the convertible senior notes included in
 additional paid-in capital:

- added (2016-05-06):
[0001193125-16-582073:note_history:36]
|  |  | As of March 28, 2016 and December 28, 2015 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001193125-16-582073:note_history:37]
The following table summarizes the long-term debt of the
 Company as of March 28, 2016 and December 28, 2015:
  (was, 2015-11-04, similarity 0.95):
[0001193125-15-366187:note_history:37]
The following table summarizes the long-term debt of the
 Company as of September 28, 2015 and December 29,
 2014:

- added (2016-05-06):
[0001193125-16-582073:note_history:38]
|  |  | Average Effective Interest Rate as of March 28, 2016 |  | March 28, 2016 |  |  | Average Effective Interest Rate as of December 28, 2015 |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  | 6.00% |  | $ | 871,143 |  |  | 6.00% |  | $ | 947,625 |  |
| U.S. ABL revolving loan due May 2020 |  | 2.19% |  |  | 80,000 |  |  | 2.17% |  |  | 80,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  | 250,000 |  |  | 1.75% |  |  | 250,000 |  |
| Capital lease |  | 6.43% |  |  | 2,038 |  |  |  |  |  | — |  |
|  |  |  |  |  | 1,203,181 |  |  |  |  |  | 1,277,625 |  |
| Less: Long-term debt unamortized discount |  |  |  |  | (71,727 | ) |  |  |  |  | (75,668 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  | (29,230 | ) |  |  |  |  | (31,171 | ) |
|  |  |  |  |  | 1,102,224 |  |  |  |  |  | 1,170,786 |  |
| Less: current maturities |  |  |  |  | (80,358 | ) |  |  |  |  | (157,375 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 1,021,866 |  |  |  |  | $ | 1,013,411 |  |

- added (2016-05-06):
[0001193125-16-582073:note_history:39]
Term and Revolving
 Loans

- changed (2016-05-06):
[0001193125-16-582073:note_history:40]
The Term Loan was issued at a discount at 96.5% and bears
 interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus
 an applicable interest margin of 5.0%, or JP Morgan Chase
 Bank’s prime rate, with a 2% floor, plus a margin of 4%, at
 the Company’s option. At March 28, 2016, the weighted
 average interest rate on the outstanding borrowings under the Term
 Loan was 6.0%. There is no provision, other than an event of
 default, for the interest margin to increase. The Term Loan will
 mature on May 31, 2021. The Term Loan is secured by a
 significant amount of the assets of the Company and its domestic
 subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and is structurally
 senior to the Company’s convertible senior notes. See
 Convertible Senior Notes below.
  (was, 2015-11-04, similarity 0.983):
[0001193125-15-366187:note_history:40]
The Term Loan was issued at a discount at 96.5% and bears
 interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus
 an applicable interest margin of 5.0%, or JP Morgan Chase
 Bank’s prime rate, with a 2% floor, plus a margin of 4%, at
 the Company’s option. At September 28, 2015, the
 weighted average interest rate on the outstanding borrowings under
 the Term Loan was 6.0%. There is no provision, other than an event
 of default, for the interest margin to increase. The Term Loan will
 mature on May 31, 2021. The Term Loan is secured by a
 significant amount of the assets of the Company and its domestic
 subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and is structurally
 senior to the Company’s convertible senior notes. See Note 7
 Convertible Senior Notes.

- changed (2016-05-06):
[0001193125-16-582073:note_history:41]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $150,000, a letter of credit
 facility of up to $75,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $150,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 175 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 75 basis points, at the Company’s option. At March
 28, 2016, the weighted average interest rate on the outstanding
 borrowings under the U.S. ABL was 2.19%. Beginning in 2016, the
 applicable margin can vary based on the remaining availability of
 the facility, from 150 to 200 basis points for LIBOR-based loans or
 from 50 to 100 basis points for JP Morgan Chase Bank’s prime
 rate-based loans. Other than availability and an event of default,
 there are no other provisions for the interest margin to increase.
 The U.S. ABL will mature on May 31, 2020. Loans made under the
 U.S. ABL are secured first by all of the Company’s domestic
 cash, receivables and inventories as well as by a second position
 against a significant amount of the assets of the Company and its
 domestic subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and are
 structurally senior to the Company’s convertible senior
 notes. See Convertible Senior Notes below. At March 28, 2016,
 $80,000 of the U.S. ABL was outstanding and classified as
 short-term debt.
  (was, 2015-11-04, similarity 0.9674):
[0001193125-15-366187:note_history:41]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $150,000, a letter of credit
 facility of up to $75,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $150,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 175 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 75 basis points, at the Company’s option. At
 September 28, 2015, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 1.9%. Beginning in
 2016, the applicable margin can vary based on the remaining
 availability of the facility, from 150 to 200 basis points for
 LIBOR-based loans and from 50 to 100 basis points for JP Morgan
 Chase Bank’s prime rate-based loans. Other than availability
 and an event of default, there are no other provisions for the
 interest margin to increase. The U.S. ABL will mature on
 May 31, 2020. Loans made under the U.S. ABL are secured first
 by all of the Company’s domestic cash, receivables and
 inventories as well as by a second position against a significant
 amount of the assets of the Company and its domestic subsidiaries
 and a pledge of 65% of voting stock of the Company’s first
 tier foreign subsidiaries and are structurally senior to the
 Company’s convertible senior notes. See Note 7 Convertible
 Senior Notes. At September 28, 2015, $80,000 of the U.S. ABL
 was outstanding and classified as short-term debt.

- changed (2016-05-06):
[0001193125-16-582073:note_history:42]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of the Company’s Asia Pacific cash and
 receivables and are structurally senior to the Company’s
 domestic obligations, including the convertible senior notes. See
 Convertible Senior Notes below. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At March 28, 2016, none of the Asia ABL
 was outstanding.
  (was, 2015-11-04, similarity 0.7792):
[0001193125-15-366187:note_history:42]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of the Company’s Asia Pacific cash and
 receivables and are structurally senior to the Company’s
 domestic obligations, including the convertible senior notes. See
 Note 7 Convertible Senior Notes. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At September 28, 2015, none of the
 Asia ABL was outstanding.

- changed (2016-05-06):
[0001193125-16-582073:note_history:43]
The Company is required to make scheduled payments of the
 outstanding Term Loan balance on a quarterly basis which began on
 October 1, 2015. Based on certain parameters defined in the
 Term Loan agreement, the Company may be required to make an
 additional principal payment on an annual basis. Any additional
 annual payments reduce future required quarterly scheduled
 payments. During the quarter ended March 28, 2016, the Company made
 debt principal payments totaling $76,482 representing normally
 scheduled principal payments as well as an additional prepayment of
 principal. Any other outstanding balances under the Term Loan are
 due at the maturity date of May 31, 2021. Borrowings under the
 Term Loan are subject to various financial and operating covenants
 including maintaining a maximum total leverage ratio. Under the
 occurrence of certain events, the U.S. ABL and the Asia ABL are
 subject to various financial and operational covenants, including
 maintaining minimum fixed charge coverage ratios. At March 28,
 2016, the Company was in compliance with the covenants under the
 Term Loan, the U.S. ABL and the Asia ABL.
  (was, 2015-11-04, similarity 0.6677):
[0001193125-15-366187:note_history:43]
The Company is required to make scheduled payments of the
 outstanding Term Loan balance on a quarterly basis beginning
 October 1, 2015. On October 1, 2015, the first scheduled
 principal payment of $2,375 was made. Based on certain parameters
 defined in the Term Loan agreement, the Company may be required to
 make an additional principal payment on an annual basis. Any other
 outstanding balances under the Term Loan are due at the maturity
 date of May 31, 2021. Borrowings under the Term Loan are
 subject to various financial and operating covenants including
 maintaining a maximum total leverage ratio. Under the occurrence of
 certain events, the U.S. ABL and the Asia ABL are subject to
 various financial and operational covenants, including maintaining
 minimum fixed charge coverage ratios. At September 28, 2015,
 the Company was in compliance with the covenants under the Term
 Loan, the U.S. ABL and the Asia ABL.

- added (2016-05-06):
[0001193125-16-582073:note_history:44]
As of March 28, 2016 and December 28, 2015, remaining
 unamortized debt discount of $28,261 and $30,242, respectively, and
 debt issuance costs of $24,874 and $26,619, respectively, related
 to the Term Loan. These debt discount and debt issuance costs are
 recorded as a reduction of the Term Loan and are amortized over the
 duration of the Term Loan into interest expense using an effective
 interest rate of 7.50%.

- added (2016-05-06):
[0001193125-16-582073:note_history:45]
Additionally, remaining unamortized debt issuance costs related
 to the ABL Revolving Loans were $4,060 and $4,303 as of March 28,
 2016 and December 28, 2015, respectively. These debt issuance costs
 are included in other non-current assets and are amortized to
 interest expense over the duration of the ABL Revolving Loans using
 the straight line method of amortization.

- added (2016-05-06):
[0001193125-16-582073:note_history:46]
At March 28, 2016, the remaining amortization period for the
 unamortized debt discount and debt issuance costs for both the Term
 Loan and the ABL Revolving Loans was 5.1 years.

- changed (2016-05-06):
[0001193125-16-582073:note_history:47]
The Company is required to pay a commitment fee of
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The U.S. ABL commitment fee may vary from 0.25% to 0.375%
 based on utilization levels. Additionally, the Company also paid
 commitment fees of 0.5% per annum on the unused portion of the
 $90,000 senior secured revolving loan associated with the
 terminated 2012 credit agreement for the quarter ended March 30,
 2015. The Company incurred total commitment fees related to unused
 borrowing availability of $194 and $173 for the quarters ended
 March 28, 2016 and March 30, 2015, respectively. As of March 28,
 2016, the outstanding amount of the Term Loan was $871,143, all of
 which is included as long-term debt. Additionally, $80,000 of the
 U.S. ABL and none of the Asia ABL was outstanding as of March 28,
 2016. Available borrowing capacity under the U.S. ABL and Asia ABL
 was $63,033 and $141,128, which considers letters of credit
 outstanding of $6,967 and $8,872 mentioned below, respectively, at
 March 28, 2016.
  (was, 2015-11-04, similarity 0.7648):
[0001193125-15-366187:note_history:47]
The Company is required to pay a commitment fee of
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The U.S. ABL commitment fee may vary from 0.25% to 0.375%
 based on utilization levels. Additionally, the Company also paid
 commitment fees of 0.5% per annum on the unused portion of the
 $90,000 senior secured revolving loan associated with the
 terminated 2012 credit agreement during the quarter and two
 quarters ended June 29, 2015. The Company incurred total
 commitment fees related to unused borrowing availability of $200
 and $155 for the quarters ended September 28, 2015 and
 September 29, 2014, respectively, and $565 and $439 for the
 three quarters ended September 28, 2015 and September 29,
 2014, respectively. As of September 28, 2015, the outstanding
 amount of the Term Loan was $950,000, of which $9,500 is due for
 repayment within one year and is included as short-term debt, with
 the remaining $940,500 included as long-term debt. Additionally,
 $80,000 of the U.S. ABL and none of the Asia ABL was outstanding as
 of September 28, 2015. Available borrowing capacity under the
 U.S. ABL and Asia ABL was $65,444 and $142,224, which considers the
 letter of credit outstanding of $4,556 and $7,776 mentioned below,
 respectively, at September 28, 2015.

- added (2016-05-06):
[0001193125-16-582073:note_history:48]
The Company has up to $75,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of March 28, 2016, letters of credit in the
 amount of $6,967 were outstanding under the U.S. ABL and $8,872
 were outstanding under the Asia ABL with various expiration dates
 through February 2017.

- added (2016-05-06):
[0001193125-16-582073:note_history:49]
At December 28, 2015, certain letters of credit were
 securitized by cash collateral. As such the Company had recorded
 such cash as restricted cash on the consolidated condensed balance
 sheet as of December 28, 2015. As of March 28, 2016, none of the
 letters of credit are securitized by cash collateral.

- added (2016-05-06):
[0001193125-16-582073:note_history:50]
Convertible Senior
 Notes

- added (2016-05-06):
[0001193125-16-582073:note_history:51]
Convertible Senior
 Notes due 2020

- added (2016-05-06):
[0001193125-16-582073:note_history:52]
The Company issued 1.75% convertible senior notes due
 December 15, 2020, in a public offering for an aggregate
 principal amount of $250,000 in 2013. The convertible senior notes
 bear interest at a rate of 1.75% per annum. Interest is
 payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and are senior
 in right of payment to any of the Company’s future
 subordinated indebtedness.

- added (2016-05-06):
[0001193125-16-582073:note_history:53]
Convertible Senior
 Notes due 2015

- added (2016-05-06):
[0001193125-16-582073:note_history:54]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015, in a public offering for an aggregate principal
 amount of $175,000. In May 2015 the outstanding principal of
 $32,395 plus accrued interest was paid in full.

- added (2016-05-06):
[0001193125-16-582073:note_history:55]
As of March 28, 2016 and December 28, 2015, the following
 summarizes the equity components of the convertible senior notes
 included in additional paid-in capital:

- added (2016-05-06):
[0001193125-16-582073:note_history:56]
|  |  | As of March 28, 2016 and December 28, 2015 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |

- added (2016-05-06):
[0001193125-16-582073:note_history:57]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended March 28, 2016 and
 March 30, 2015 are as follows:

- added (2016-05-06):
[0001193125-16-582073:note_history:58]
|  |  | For the Quarter Ended |  |
|  |  | March 28, 2016 |  |  | March 30, 2015 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 263 |  |
|  |  | $ | 1,094 |  |  | $ | 1,357 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,960 |  |  | $ | 1,838 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 367 |  |
|  |  | $ | 1,960 |  |  | $ | 2,205 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 196 |  |  | $ | 184 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 37 |  |
|  |  | $ | 196 |  |  | $ | 221 |  |

- added (2016-05-06):
[0001193125-16-582073:note_history:59]
As of March 28, 2016 and December 28, 2015, remaining
 unamortized debt discount of $43,466 and $45,426, respectively, and
 debt issuance costs of $4,356 and $4,552, respectively, related to
 the convertible senior notes. These debt discount and debt discount
 issuance costs are recorded as a reduction of the convertible
 senior notes and are being amortized to interest expense over the
 term of the convertible senior notes using the effective interest
 rate method. At March 28, 2016, the remaining weighted average
 amortization period for the unamortized senior convertible note
 discount and debt issuance costs was 4.7 years.

- added (2016-05-06):
[0001193125-16-582073:note_history:60]
For the quarters ended March 28, 2016 and March 30, 2015, the
 amortization of the convertible senior notes due 2020 debt discount
 and debt issuance costs is based on an effective interest rate of
 6.48%. For the quarter ended March 30, 2015, the amortization of
 the convertible senior notes due 2015 debt discount and debt
 issuance costs is based on an effective interest rate of
 8.37%.

- changed (2016-05-06):
[0001193125-16-582073:note_history:61]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $35,300 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2016. As of March 28, 2016, the Chinese Revolver had not been
 drawn upon.
  (was, 2015-11-04, similarity 0.9861):
[0001193125-15-366187:note_history:61]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $36,100 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2015. As of September 28, 2015, the Chinese Revolver had not
 been drawn upon.

- removed (2016-05-06):
[0001193125-15-366187:note_history:62]
|  |  | Average Effective Interest Rate as of September 28, 2015 |  | September 28, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  | 6.0% |  | $ | 950,000 |  |  | — |  |  | — |  |
| U.S. ABL revolving loan due May 2020 |  | 1.9% |  |  | 80,000 |  |  | — |  |  | — |  |
| Term loan due September 2016 |  | — |  |  | — |  |  | 2.5% |  | $ | 273,800 |  |
| Other |  | — |  |  | — |  |  | 6.0% |  |  | 4 |  |
|  |  |  |  |  | 1,030,000 |  |  |  |  |  | 273,804 |  |
| Less: Unamortized discount |  |  |  |  | (31,545 | ) |  |  |  |  | — |  |
|  |  |  |  |  | 998,455 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (89,500 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 908,955 |  |  |  |  | $ | 177,600 |  |

- removed (2016-05-06):
[0001193125-15-366187:note_history:63]
New
 borrowings

- removed (2016-05-06):
[0001193125-15-366187:note_history:64]
As of September 28, 2015, remaining unamortized debt
 discount and debt issuance costs were $31,545 and $32,168,
 respectively. The debt discount is recorded as a reduction of the
 Term Loan and is amortized over the duration of the Term Loan. The
 debt issuance costs are included in other non-current assets and
 are amortized to interest expense over the duration of the Term
 Loan and ABL Revolving Loans. The debt discount and the debt
 issuance costs related to the Term Loan are amortized into interest
 expense using an effective interest rate of 7.49%. The debt
 issuance costs related to the ABL Revolving Loans are amortized
 into interest expense using the straight line method of
 amortization over the duration of the ABL Revolving Loans. At
 September 28, 2015, the remaining amortization period for the
 unamortized debt discount and debt issuance costs was 5.6
 years.

- removed (2016-05-06):
[0001193125-15-366187:note_history:65]
The Company has up to $75,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of September 28, 2015, letters of credit
 in the amount of $4,556 were outstanding under the U.S. ABL and
 $7,776 were outstanding under the Asia ABL. The Company has other
 standby letters of credit outstanding in the amount of $4,832,
 which expire between October 4, 2015 and May 16, 2016.
 These other standby letters of credit are securitized by cash
 collateral. As such, the Company has recorded such cash as
 restricted on the consolidated condensed balance sheet as of
 September 28, 2015. There were no such arrangements at
 December 29, 2014.

- removed (2016-05-06):
[0001193125-15-366187:note_history:66]
Loss on
 Extinguishment of Debt

- removed (2016-05-06):
[0001193125-15-366187:note_history:67]
The Company became a party to its current Term Loan and ABL
 Revolving Loans during the second quarter ended June 29, 2015
 in order to refinance and pay in full the remaining outstanding
 amount of $225,700 under an existing 2012 credit agreement, as well
 as to finance the acquisition of Viasystems and refinance
 Viasystems’ outstanding debt. As a result, the Company
 recognized losses of approximately $802 during the three quarters
 ended September 28, 2015 resulting from the write off of the
 remaining unamortized debt issuance costs associated with the
 terminated 2012 credit agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001193125-16-582073:note_history:68]
The following table summarizes the long-term debt of the
 Company as of March 28, 2016 and December 28, 2015:
  (was, 2015-11-04, similarity 0.95):
[0001193125-15-366187:note_history:68]
The
 following table summarizes the long-term debt of the Company as of
 September 28, 2015 and December 29, 2014:

- added (2016-05-06):
[0001193125-16-582073:note_history:69]
|  |  | Average Effective Interest Rate as of March 28, 2016 |  | March 28, 2016 |  |  | Average Effective Interest Rate as of December 28, 2015 |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  | 6.00% |  | $ | 871,143 |  |  | 6.00% |  | $ | 947,625 |  |
| U.S. ABL revolving loan due May 2020 |  | 2.19% |  |  | 80,000 |  |  | 2.17% |  |  | 80,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  | 250,000 |  |  | 1.75% |  |  | 250,000 |  |
| Capital lease |  | 6.43% |  |  | 2,038 |  |  |  |  |  | — |  |
|  |  |  |  |  | 1,203,181 |  |  |  |  |  | 1,277,625 |  |
| Less: Long-term debt unamortized discount |  |  |  |  | (71,727 | ) |  |  |  |  | (75,668 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  | (29,230 | ) |  |  |  |  | (31,171 | ) |
|  |  |  |  |  | 1,102,224 |  |  |  |  |  | 1,170,786 |  |
| Less: current maturities |  |  |  |  | (80,358 | ) |  |  |  |  | (157,375 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 1,021,866 |  |  |  |  | $ | 1,013,411 |  |

- removed (2016-05-06):
[0001193125-15-366187:note_history:70]
|  |  | Average Effective Interest Rate as of September 28, 2015 |  | September 28, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  | 6.0% |  | $ | 950,000 |  |  | — |  |  | — |  |
| U.S. ABL revolving loan due May 2020 |  | 1.9% |  |  | 80,000 |  |  | — |  |  | — |  |
| Term loan due September 2016 |  | — |  |  | — |  |  | 2.5% |  | $ | 273,800 |  |
| Other |  | — |  |  | — |  |  | 6.0% |  |  | 4 |  |
|  |  |  |  |  | 1,030,000 |  |  |  |  |  | 273,804 |  |
| Less: Unamortized discount |  |  |  |  | (31,545 | ) |  |  |  |  | — |  |
|  |  |  |  |  | 998,455 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (89,500 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 908,955 |  |  |  |  | $ | 177,600 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2016-05-06):
[0001193125-16-582073:note_history:71]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 For the quarters ended March 28, 2016 and March 30, 2015, the
 Company’s foreign subsidiaries purchased $15,998 and $9,945,
 respectively, of laminate and prepreg from these related
 parties.
  (was, 2015-11-04, similarity 0.6002):
[0001193125-15-366187:note_history:71]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $21,167 and $11,469 for the quarters ended
 September 28, 2015 and September 29, 2014, respectively,
 and $43,335 and $36,647 for the three quarters ended
 September 28, 2015 and September 29, 2014,
 respectively.

- added (2016-05-06):
[0001193125-16-582073:note_history:72]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCBs to SYE and purchases PCBs including various
 services relating to PCB manufacturing from SYE. Sales to SYE for
 the quarters ended March 28, 2016 and March 30, 2015 were $311 and
 $1,481, respectively. Purchases of PCBs including various services
 relating to PCB manufacturing for the quarters ended March 28, 2016
 and March 30, 2015 were $28 and $439, respectively.

- added (2016-05-06):
[0001193125-16-582073:note_history:73]
As of
 March 28, 2016 and December 28, 2015, the Company’s
 consolidated condensed balance sheets included $19,886 and $29,306,
 respectively, in accounts payable due to related parties for
 purchases of laminate and prepreg and various PCB manufacturing
 services and such balances are included as a component of accounts
 payable on the consolidated condensed balance sheets. Additionally,
 the Company’s consolidated condensed balance sheets included
 $976 and $1,999, respectively, in accounts receivable due from a
 related party for sales of PCBs to SYE, as mentioned above, and
 such balances are included as a component of accounts receivable,
 net on the consolidated condensed balance sheets.

- removed (2016-05-06):
[0001193125-15-366187:note_history:74]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCB’s to SYE and purchases PCB’s
 including various services in relation to PCB manufacturing from
 SYE. Sales to SYE for the quarters ended September 28, 2015
 and September 29, 2014 were $1,042 and $2,282, respectively,
 and $3,867 and $21,535 for the three quarters ended
 September 28, 2015 and September 29, 2014, respectively.
 Purchases of PCB including various services in relation to PCB
 manufacturing for the quarters ended September 28, 2015 and
 September 29, 2014 were $344 and $78, respectively, and $1,840
 and $550 for the three quarters ended September 28, 2015 and
 September 29, 2014, respectively.

- removed (2016-05-06):
[0001193125-15-366187:note_history:75]
As of
 September 28, 2015 and December 29, 2014, the
 Company’s consolidated balance sheets included $31,425 and
 $17,950, respectively, in accounts payable due to, and $2,025 and
 $4,934, respectively, in accounts receivable due from a related
 party for the purchase of laminate and prepreg and various PCB
 manufacturing services, and sales of PCBs to SYE, as mentioned
 above.
