# TTMI notes — 0001193125-16-582073


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-16-582073:notes:1]
(6) Definite-lived
 Intangibles

[0001193125-16-582073:notes:2]
As of
 March 28, 2016 and December 28, 2015, the components of
 definite-lived intangibles were as follows:

[0001193125-16-582073:notes:3]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| March 28, 2016: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (60,936 | ) |  | $ | 116 |  |  | $ | 142,743 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (827 | ) |  |  | — |  |  |  | 2,173 |  |  |  | 3.0 |  |
|  |  | $ | 206,563 |  |  | $ | (61,763 | ) |  | $ | 116 |  |  | $ | 144,916 |  |  |  |  |  |
| December 28, 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 91,492 |  |  | $ | (80,152 | ) |  | $ | 426 |  |  | $ | 11,766 |  |  |  | 9.2 |  |
| Trade name |  |  | 10,302 |  |  |  | (10,313 | ) |  |  | 11 |  |  |  | — |  |  |  | 6.0 |  |
| Acquired intangibles from Viasystems acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 147,500 |  |  |  | (10,815 | ) |  |  | — |  |  |  | 136,685 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (577 | ) |  |  | — |  |  |  | 2,423 |  |  |  | 3.0 |  |
|  |  | $ | 252,294 |  |  | $ | (101,857 | ) |  | $ | 437 |  |  | $ | 150,874 |  |  |  |  |  |

[0001193125-16-582073:notes:4]
The
 March 28, 2016 and December 28, 2015 definite-lived intangible
 balances include foreign currency translation adjustments related
 to foreign subsidiaries with functional currencies other than the
 U.S. Dollar.

[0001193125-16-582073:notes:5]
Definite-lived intangibles are generally amortized using the
 straight line method of amortization over the useful life, with the
 exception of certain customer relationship intangibles, which are
 amortized using an accelerated method of amortization based on
 estimated cash flows. Amortization expense was $5,947 and $1,874,
 for the quarters ended March 28, 2016 and March 30, 2015,
 respectively.

[0001193125-16-582073:notes:6]
Estimated aggregate amortization for definite-lived intangible
 assets for the next five years and thereafter is as
 follows:

[0001193125-16-582073:notes:7]
|  |  | (In thousands) |  |
| Remaining 2016 |  | $ | 17,924 |  |
| 2017 |  |  | 23,647 |  |
| 2018 |  |  | 22,889 |  |
| 2019 |  |  | 18,746 |  |
| 2020 |  |  | 18,746 |  |
| Thereafter |  |  | 42,964 |  |
|  |  | $ | 144,916 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-16-582073:notes:8]
The
 Company accounts for inter-segment sales and transfers consistent
 with the Company’s revenue recognition policy. The
 inter-segment sales for the quarters ended March 28, 2016 and March
 30, 2015, are sales primarily from the PCB to the E-M Solutions
 operating segment.

[0001193125-16-582073:notes:9]
|  |  | For the Quarters Ended |  |
|  |  | March 28, 2016 |  |  | March 30, 2015 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 529,945 |  |  | $ | 310,324 |  |
| E-M Solutions |  |  | 56,478 |  |  |  | 19,462 |  |
| Total sales |  |  | 586,423 |  |  |  | 329,786 |  |
| Inter-segment sales |  |  | (3,165 | ) |  |  | (622 | ) |
| Total net sales |  | $ | 583,258 |  |  | $ | 329,164 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |
| PCB |  | $ | 49,367 |  |  | $ | 23,260 |  |
| E-M Solutions |  |  | 387 |  |  |  | 651 |  |
| Corporate |  |  | (24,905 | ) |  |  | (13,772 | ) |
| Total operating segment income |  |  | 24,849 |  |  |  | 10,139 |  |
| Amortization of definite-lived intangibles |  |  | (5,947 | ) |  |  | (1,874 | ) |
| Total operating income |  |  | 18,902 |  |  |  | 8,265 |  |
| Total other expense |  |  | (20,575 | ) |  |  | (6,180 | ) |
| (Loss) income before income taxes |  | $ | (1,673 | ) |  | $ | 2,085 |  |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-16-582073:notes:10]
(10) Significant
 Customers and Concentration of Credit Risk

[0001193125-16-582073:notes:11]
In the
 normal course of business, the Company extends credit to its
 customers, which are concentrated primarily in the computer,
 networking and communications and aerospace and defense industries.
 Most customers to which the Company extends credit are located
 outside the United States, with the exception of certain customers
 in the aerospace and defense industries. The Company performs
 ongoing credit evaluations of customers, does not require
 collateral, and considers the credit risk profile of the entity
 from which the receivable is due in further evaluating collection
 risk.

[0001193125-16-582073:notes:12]
[same as prior period, unchanged from 0001193125-15-366187:notes:5]

[0001193125-16-582073:notes:13]
For
 the quarters ended March 28, 2016 and March 30, 2015, one
 customer accounted for approximately 10% and 27%, respectively, of
 the Company’s net sales. There were no other customers that
 accounted for 10% or more of net sales for the quarters ended March
 28, 2016 and March 30, 2015.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-16-582073:notes:14]
The
 following is a reconciliation of the numerator and denominator used
 to calculate basic (loss) earnings per share and diluted (loss)
 earnings per share for the quarters ended March 28, 2016 and
 March 30, 2015:

[0001193125-16-582073:notes:15]
|  |  | Quarter Ended |  |
|  |  | March 28, 2016 |  |  | March 30, 2015 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net (loss) income |  | $ | (7,264 | ) |  | $ | 3,446 |  |
| Weighted average shares outstanding |  |  | 99,596 |  |  |  | 83,603 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | — |  |  |  | 862 |  |
| Diluted shares |  |  | 99,596 |  |  |  | 84,465 |  |
| (Loss) earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.07 | ) |  | $ | 0.04 |  |
| Diluted |  | $ | (0.07 | ) |  | $ | 0.04 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-16-582073:notes:16]
[same as prior period, unchanged from 0001193125-15-366187:notes:9]

[0001193125-16-582073:notes:17]
Inventories as of March 28, 2016 and December 28,
 2015 consist of the following:

[0001193125-16-582073:notes:18]
|  |  | As of |  |
|  |  | March 28, 2016 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 67,823 |  |  | $ | 70,577 |  |
| Work-in-process |  |  | 105,699 |  |  |  | 97,193 |  |
| Finished goods |  |  | 91,033 |  |  |  | 101,153 |  |
|  |  | $ | 264,555 |  |  | $ | 268,923 |  |


## us-gaap:ScheduleOfShareBasedCompensationArrangementByShareBasedPaymentAwardPerformanceBasedUnitsVestedAndExpectedToVestTableTextBlock

[0001193125-16-582073:notes:19]
PRUs activity for the quarter ended March 28, 2016 was as
 follows:

[0001193125-16-582073:notes:20]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding target shares at December 28, 2015 |  |  | 301 |  |  | $ | 8.58 |  |
| Granted |  |  | 347 |  |  |  | 6.46 |  |
| Change in units due to annual financial target performance achievement |  |  | — |  |  |  | — |  |
| Outstanding target shares at March 28, 2016 |  |  | 648 |  |  | $ | 7.45 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-16-582073:notes:21]
(14) Stock-Based
 Compensation

[0001193125-16-582073:notes:22]
[same as prior period, unchanged from 0001193125-15-366187:notes:15]

[0001193125-16-582073:notes:23]
|  |  | Quarter Ended |  |
|  |  | March 28, 2016 |  |  | March 30, 2015 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 320 |  |  | $ | 225 |  |
| Selling and marketing |  |  | 210 |  |  |  | 271 |  |
| General and administrative |  |  | 1,716 |  |  |  | 1,544 |  |
| Stock-based compensation expense recognized |  | $ | 2,246 |  |  | $ | 2,040 |  |

[0001193125-16-582073:notes:24]
Performance-based
 Restricted Stock Units

[0001193125-16-582073:notes:25]
[same as prior period, unchanged from 0001193125-15-366187:notes:18]

[0001193125-16-582073:notes:26]
The Company records stock-based compensation expense for PRU
 awards granted based on management’s periodic assessment of
 the probability of the PRU awards vesting. For the quarter ended
 March 28, 2016, management determined that vesting of the PRU
 awards was probable. PRUs activity for the quarter ended
 March 28, 2016 was as follows:

[0001193125-16-582073:notes:27]
The fair value for PRUs granted is calculated using a Monte
 Carlo simulation model, as the TSR modifier contains a market
 condition. For the quarters ended March 28, 2016 and
 March 30, 2015 the following assumptions were used in
 determining the fair value:

[0001193125-16-582073:notes:28]
|  |  | March 28, 20161 |  |  | March 30, 20152 |  |
| Weighted-average fair value |  | $ | 6.46 |  |  | $ | 7.22 |  |
| Risk-free interest rate |  |  | 0.84 | % |  |  | 0.5 | % |
| Dividend yield |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 40 | % |  |  | 37 | % |
| Expected term in months |  |  | 24 |  |  |  | 22 |  |

[0001193125-16-582073:notes:29]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2014, second year of the three-year performance period applicable to PRUs granted in 2015 and first year of the three-year performance period applicable to PRUs granted in 2016. |

[0001193125-16-582073:notes:30]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2013, second year of the three-year performance period applicable to PRUs granted in 2014 and first year of the three-year performance period applicable to PRUs granted in 2015. |

[0001193125-16-582073:notes:31]
Restricted Stock
 Units

[0001193125-16-582073:notes:32]
The Company granted 1,683 and 970 RSUs during the quarters
 ended March 28, 2016 and March 30, 2015, respectively. The
 RSUs granted have a weighted-average fair value per unit of $6.75
 and $8.80 for the quarters ended March 28, 2016 and March 30,
 2015, respectively. The fair value for RSUs granted is based on the
 closing share price of the Company’s common stock on the date
 of grant.

[0001193125-16-582073:notes:33]
[same as prior period, unchanged from 0001193125-15-366187:notes:22]

[0001193125-16-582073:notes:34]
The Company did not grant any stock option awards during the
 quarters ended March 28, 2016 and March 30, 2015.

[0001193125-16-582073:notes:35]
Summary of Unrecognized
 Compensation Costs

[0001193125-16-582073:notes:36]
The following is a summary of total unrecognized compensation
 costs as of March 28, 2016:

[0001193125-16-582073:notes:37]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |
|  |  | (In thousands) |  |  | (years) |
| RSU awards |  | $ | 17,882 |  |  | 1.7 |
| PRU awards |  |  | 3,110 |  |  | 1.9 |
|  |  | $ | 20,992 |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-16-582073:notes:38]
(15) Segment
 Information

[0001193125-16-582073:notes:39]
The
 operating segments reported below are the Company’s segments
 for which separate financial information is available and upon
 which operating results are evaluated by the chief operating
 decision maker to assess performance and to allocate resources. As
 a result of the acquisition of Viasystems and the new business
 structure implemented in the quarter ended March 28, 2016, the
 Company has reassessed its reportable operating segments and
 determined that it has two reportable operating segments: PCB and
 E-M Solutions. This determination was made based on the criteria of
 earning revenues and incurring expenses, the Company’s
 organizational structure which has segment managers who report to
 the chief operating decision maker and discrete financial
 information, and the aggregation of similar operating segments into
 reportable operating segments. Factors considered to determine
 whether operating segments can be aggregated into reportable
 segments included similarity regarding economic characteristics,
 products, production processes, type or classes of customers,
 distribution methods and regulatory environments. All prior-period
 amounts have been adjusted retrospectively to reflect our
 reportable segment changes.

[0001193125-16-582073:notes:40]
The
 Company, including the chief operating decision maker, evaluates
 segment performance based on operating segment income, which is
 operating income before amortization of intangibles. Interest
 expense and interest income are not presented by segment since they
 are not included in the measure of segment profitability reviewed
 by the chief operating decision maker. All inter-segment
 transactions have been eliminated.

[0001193125-16-582073:notes:41]
The
 Corporate category includes operating expenses that are not
 included in the segment operating performance measures. Corporate
 consists primarily of corporate governance functions such as
 finance, accounting, information technology, facilities and human
 resources personnel, as well as global sales and marketing
 personnel and acquisition and integration costs associated with the
 acquisition of Viasystems. Bank fees and legal, accounting, and
 other professional service costs associated with the acquisition of
 Viasystems of $691 and $8,235 for the quarters ended March 28,
 2016 and March 30, 2015, respectively, are included in
 Corporate.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-16-582073:notes:42]
(5)
 Goodwill

[0001193125-16-582073:notes:43]
As of
 March 28, 2016 and December 28, 2015, goodwill was as
 follows:

[0001193125-16-582073:notes:44]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 28, 2015 |  | $ | 346,990 |  |
| Foreign currency translation adjustment and other |  |  | 24 |  |
| Balance as of March 28, 2016 |  | $ | 347,014 |  |

[0001193125-16-582073:notes:45]
All
 goodwill relates to the Company’s PCB reportable segment. The
 assignment of goodwill related to the acquisition of Viasystems is
 preliminary and will be completed in conjunction with the final
 purchase price allocation.

[0001193125-16-582073:notes:46]
Goodwill balances include foreign currency translation
 adjustments related to foreign subsidiaries with functional
 currencies other than the U.S. Dollar.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001193125-16-582073:notes:47]
(17) Sale of Suzhou,
 China Manufacturing Facility

[0001193125-16-582073:notes:48]
During
 the quarter ended March 30, 2015, the Company sold its Meadville
 Aspocomp (Suzhou) Electronic Co., Ltd. subsidiary, which held its
 Suzhou, China manufacturing facility, for $21,275 and recognized a
 gain of $2,504. This subsidiary was included in the Company’s
 PCB operating segment.


## us-gaap:ConvertibleDebtTableTextBlock

[0001193125-16-582073:notes:49]
As of
 March 28, 2016 and December 28, 2015, the following summarizes
 the equity components of the convertible senior notes included in
 additional paid-in capital:

[0001193125-16-582073:notes:50]
|  |  | As of March 28, 2016 and December 28, 2015 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-16-582073:notes:51]
(11) Fair Value
 Measures

[0001193125-16-582073:notes:52]
[same as prior period, unchanged from 0001193125-15-366187:notes:36]

[0001193125-16-582073:notes:53]
The
 carrying amount and estimated fair value of the Company’s
 financial instruments at March 28, 2016 and December 28,
 2015 were as follows:

[0001193125-16-582073:notes:54]
|  |  | March 28, 2016 |  |  | December 28, 2015 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Term and Revolving Loans |  | $ | 898,008 |  |  | $ | 907,586 |  |  | $ | 970,764 |  |  | $ | 935,000 |  |
| Convertible senior notes due 2020 |  |  | 202,178 |  |  |  | 220,350 |  |  |  | 200,022 |  |  |  | 230,950 |  |
| Capital lease |  |  | 2,038 |  |  |  | 2,038 |  |  |  | — |  |  |  | — |  |

[0001193125-16-582073:notes:55]
The
 fair value of the long-term debt was estimated based on quoted
 market prices or discounting the debt over its life using current
 market rates for similar debt as of March 28, 2016 and
 December 28, 2015, which are considered Level 1 and Level 2
 inputs.

[0001193125-16-582073:notes:56]
[same as prior period, unchanged from 0001193125-15-366187:notes:41]

[0001193125-16-582073:notes:57]
As of
 March 28, 2016 and December 28, 2015, the Company’s
 other financial instruments also included cash and cash
 equivalents, accounts receivable, accounts payable and equipment
 payables. Due to short-term maturities, the carrying amount of
 these instruments approximates fair value. Our cash and cash
 equivalents at March 28, 2016 consisted of $41,640 held in the
 U.S., with the remaining $142,038 held by foreign
 subsidiaries.

[0001193125-16-582073:notes:58]
The
 majority of the Company’s non-financial assets and
 liabilities, which include goodwill, intangible assets,
 inventories, and property, plant and equipment, are not required to
 be carried at fair value on a recurring basis. However, if certain
 triggering events occur (or are tested at least annually for
 goodwill) such that a non-financial instrument is required to be
 evaluated for impairment, based upon a comparison of the
 non-financial instrument’s fair value to its carrying value,
 an impairment is recorded to reduce the carrying value to the fair
 value, if the carrying value exceeds the fair value.

[0001193125-16-582073:notes:59]
For
 the quarter ended March 28, 2016, the following assets were
 measured at fair value on a nonrecurring basis using the type of
 inputs shown:

[0001193125-16-582073:notes:60]
|  |  |  |  |  | Fair Value Measurements Using: |  |
|  |  | March 28, 2016 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |  | Total Losses for the Quarter Ended March 28, 2016 |  |
|  |  | (In thousands) |  |
| Assets held for sale |  | $ | 155 |  |  | $ | — |  |  | $ | 155 |  |  | $ | — |  |  | $ | 1,393 |  |
| Long-lived assets held and use |  |  | 2,254 |  |  |  | — |  |  |  | — |  |  |  | 2,254 |  |  |  | 1,953 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3,346 |  |

[0001193125-16-582073:notes:61]
There
 was no impairment of long-lived assets recognized in the quarter
 ended March 30, 2015.

[0001193125-16-582073:notes:62]
The
 fair values of assets held for sale were primarily determined using
 appraisals and comparable prices of similar assets, which are
 considered to be Level 2 inputs.

[0001193125-16-582073:notes:63]
Additionally, the Company has capitalized software costs in
 accordance with U.S. GAAP. During the first quarter ended March 28,
 2016, the Company determined that certain capitalized costs no
 longer had benefit primarily as a result of the Viasystems
 acquisition. Because the primary determination of fair value was
 based on management’s assumptions and estimates of
 capitalized costs to dispose, the resulting fair value is
 considered a Level 3 input.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-16-582073:notes:64]
The
 fiscal calendar maturities of long-term debt through 2020 and
 thereafter are as follows:

[0001193125-16-582073:notes:65]
|  |  | (In thousands) |  |
| Remaining 2016 |  | $ | 80,358 |  |
| 2017 |  |  | 377 |  |
| 2018 |  |  | 28,419 |  |
| 2019 |  |  | 47,927 |  |
| 2020 |  |  | 297,975 |  |
| Thereafter |  |  | 748,125 |  |
|  |  | $ | 1,203,181 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-16-582073:notes:66]
Recently Adopted and
 Issued Accounting Standards

[0001193125-16-582073:notes:67]
In
 March 2016, the Financial Accounting Standards Board (FASB) issued
 Accounting Standards Update (ASU) 2016-09, Stock Compensation
 (Topic 718): Improvements to Employee Share-Based Payment
 Accounting. The objective of this update is to simplify several
 aspects of the accounting for employee share-based payment
 transactions, including the income tax consequences, classification
 of awards as either equity or liabilities, and classification on
 the statement of cash flows. This ASU is effective for fiscal years
 beginning after December 15, 2016, including interim periods within
 those fiscal years. Early adoption is permitted. The Company is
 currently evaluating the new guidance to determine the impact it
 may have on its consolidated condensed financial statements and
 related disclosures.

[0001193125-16-582073:notes:68]
In
 February 2016, the FASB issued ASU 2016-02, Leases (Topic
 842). The objective of this update is to increase transparency
 and comparability among organizations by recognizing lease assets
 and lease liabilities on the balance sheet and disclosing key
 information about leasing arrangements. This ASU is effective for
 fiscal years beginning after December 15, 2018, including interim
 periods within those annual periods and is to be applied utilizing
 a modified retrospective approach. The Company is currently
 evaluating the new guidance to determine the impact it may have on
 its consolidated financial statements and related
 disclosures.

[0001193125-16-582073:notes:69]
In
 April 2015, the FASB issued ASU 2015-03, Imputation of
 Interest, as amended, which requires an entity to record debt
 issuance costs related to debt reported in the balance sheet as a
 direct deduction from the face amount of that debt. The update is
 effective for annual periods ending after December 15, 2015.
 Early application is permitted. The standard requires the use of
 the retrospective transition method. In the first quarter ended
 March 28, 2016, the Company adopted the new standard. Accordingly,
 as of March 28, 2016, approximately $29,230 of unamortized debt
 issuance costs were presented as a reduction of long-term debt on
 the Company’s consolidated condensed balance sheets.
 Furthermore, the Company reclassified approximately $31,171 of
 unamortized debt issuance costs that had been presented as other
 non-current assets as of December 28, 2015.

[0001193125-16-582073:notes:70]
In May
 2014, the FASB issued ASU 2014-09, Revenue from Contracts with
 Customers, as amended, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. The ASU will
 replace most existing revenue recognition guidance in U.S. GAAP
 when it becomes effective. The new standard is effective for the
 Company at the beginning of fiscal year 2018, however application
 of the standard is allowed as early as the beginning of fiscal
 2017. The standard permits the use of either the retrospective or
 cumulative effect transition method. The Company is evaluating the
 effect that ASU 2014-09 will have on its consolidated condensed
 financial statements and related disclosures. The Company has not
 yet selected a transition method nor has it determined the effect
 of the standard on its ongoing financial reporting.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-16-582073:notes:71]
[same as prior period, unchanged from 0001193125-15-366187:notes:53]

[0001193125-16-582073:notes:72]
On
 May 31, 2015, the Company completed the acquisition of
 Viasystems Group, Inc. (Viasystems), for total consideration of
 $248,824 in cash and 15,082 shares of TTM common stock with a fair
 value of $149,006, to acquire all of the outstanding shares of
 capital stock and other equity rights of Viasystems. Additionally,
 in connection with the completion of the acquisition, the Company
 assumed and refinanced Viasystems’ debt, which was
 approximately $669,024 as of May 31, 2015. Viasystems was a
 worldwide provider of complex multi-layer rigid, flexible, and
 rigid-flex PCBs and custom electronic assemblies.

[0001193125-16-582073:notes:73]
Bank
 fees and legal, accounting, and other professional service costs
 associated with the acquisition of Viasystems of $691
 and $8,235 for the quarters ended March 28, 2016 and
 March 30, 2015, respectively, have been expensed and recorded as
 general and administrative expense in the consolidated
 condensed statements of operations.

[0001193125-16-582073:notes:74]
[same as prior period, unchanged from 0001193125-15-366187:notes:59]

[0001193125-16-582073:notes:75]
The
 purchase price of the Viasystems acquisition was allocated to
 tangible and intangible assets acquired, liabilities assumed and
 noncontrolling interest based on preliminary estimates the fair
 value at the date of the acquisition (May 31, 2015). The excess of
 the purchase price over the fair value of net assets acquired and
 noncontrolling interest was allocated to goodwill. The fair value
 assigned to intangible assets acquired was based on estimates and
 assumptions made by management at the time of
 acquisition.

[0001193125-16-582073:notes:76]
Due to
 the magnitude of the transaction and as significant information to
 be obtained and analyzed resides in a foreign jurisdiction, the
 Company’s fair value estimates for the purchase price
 allocation are preliminary and may change during the allowable
 measurement period, which is up to the point the Company obtains
 and analyzes the information that existed as of the date of the
 acquisition necessary to determine the fair values of the assets
 acquired, liabilities assumed and noncontrolling interest, but in
 no case to exceed more than one year from the date of acquisition.
 As of March 28, 2016, the Company had not finalized the
 determination of fair values allocated to certain foreign tax
 liabilities and other liabilities. Any changes in the fair values
 of the liabilities assumed during the measurement period may result
 in material adjustments to goodwill.

[0001193125-16-582073:notes:77]
The
 goodwill acquired in the acquisition is not deductible for income
 tax purposes.

[0001193125-16-582073:notes:78]
[same as prior period, unchanged from 0001193125-15-366187:notes:91]

[0001193125-16-582073:notes:79]
The
 unaudited pro forma financial information in the table below gives
 effect to this acquisition as if it had occurred at the beginning
 of fiscal 2015. The pro forma financial information presented
 includes the effects of adjustments related to the fair value step
 up of acquired inventory, amortization of acquired intangible
 assets and depreciation of acquired fixed assets, and other
 non-recurring transactions costs directly associated with the
 acquisitions such as legal, accounting and banking fees.

[0001193125-16-582073:notes:80]
|  |  | For the Quarter Ended March 30, 2015 |  |
|  |  | (In thousands, except |  |
|  |  | per share data) |  |
| Net sales |  | $ | 633,792 |  |
| Net loss attributable to TTM Technologies, Inc. stockholders |  | $ | (27,538 | ) |
| Basic loss per share |  | $ | (0.28 | ) |
| Dilutive loss per share |  | $ | (0.28 | ) |

[0001193125-16-582073:notes:81]
The
 pro forma financial information as presented above is for
 informational purposes only and is not necessarily indicative of
 the actual results that would have been achieved had the Viasystems
 acquisition occurred at the beginning of the period presented, or
 the results that may be achieved in future periods.


## us-gaap:ScheduleOfRestructuringAndRelatedCostsTextBlock

[0001193125-16-582073:notes:82]
The below table shows the utilization of the accrued
 restructuring costs during the quarter ended March 28,
 2016:

[0001193125-16-582073:notes:83]
|  |  | Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued at December 28, 2015 |  | $ | 6,044 |  |  | $ | 535 |  |  | $ | 6,579 |  |
| Charged to expense |  |  | 726 |  |  |  | 1,130 |  |  |  | 1,856 |  |
| Amount paid |  |  | (3,250 | ) |  |  | (1,085 | ) |  |  | (4,335 | ) |
| Accrued at March 28, 2016 |  | $ | 3,520 |  |  | $ | 580 |  |  | $ | 4,100 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001193125-16-582073:notes:84]
(3) Consolidation Plan,
 Restructuring and Impairment Charges

[0001193125-16-582073:notes:85]
On September 29, 2015, the Company announced a
 consolidation plan that will result in the closure of the
 Company’s facilities in Cleveland, Ohio, Milpitas, California
 and Juarez, Mexico (the Consolidation Plan) and the layoff of
 approximately 480 employees at these sites. The Consolidation Plan
 is part of the Company’s integration strategy to improve
 total plant utilization, operational performance and customer focus
 following its recent acquisition of Viasystems. In accordance with
 the Consolidation Plan, the Company will combine its Cleveland and
 Milpitas facilities into its North Jackson, Ohio and Silicon
 Valley, California facilities, respectively, and close its Juarez
 facility.

[0001193125-16-582073:notes:86]
In connection with the Consolidation Plan and other global
 realignment restructuring efforts, the Company recognized a total
 of $726 in employee separation costs for the quarter ended March
 28, 2016. These costs were classified as restructuring charges in
 the consolidated condensed statement of operations. The Company
 recognized $570 of employee separation costs in its PCB operating
 segment and $156 in its E-M Solutions operating segment. As of
 March 28, 2016, $3,520 of accrued separation costs remain for
 employees yet to be separated and are included as a component of
 accrued salaries, wages and benefits in the consolidated condensed
 balance sheet. The Company expects the remaining employees to be
 separated and the remaining accrued restructuring costs to be
 substantially paid out by June 2016.

[0001193125-16-582073:notes:87]
Additionally, during the first quarter ended March 28,
 2016, the Company incurred $1,130 in contract termination and other
 costs which primarily represented plant closure costs for
 Cleveland, Ohio, Milpitas, California, and Juarez, Mexico. The
 Company recognized $611 of contract termination and other costs in
 its PCB operating segment and $519 in its E-M Solutions operating
 segment. These remaining unpaid estimated contract termination and
 other costs as of March 28, 2016 are included as a component of
 other accrued expenses in the consolidated condensed balance
 sheet.

[0001193125-16-582073:notes:88]
As of March 28, 2016, the Company has incurred approximately
 $9,237 of restructuring charges since the September 29, 2015
 announcement and estimates that it will incur total charges of
 approximately $10,000 to $15,000 related to these
 closures.

[0001193125-16-582073:notes:89]
The Company also recognized $3,346 in impairment charges during
 the quarter ended March 28, 2016. As a result of the above
 mentioned plant closures and other plant realignment efforts,
 $1,393 of impairment charges were recognized in the consolidated
 condensed statement of operations related to machinery and
 equipment in the PCB operating segment. Additionally during
 the quarter ended March 28, 2016, the Company expensed $1,953 of
 capitalized software costs in the Corporate operating
 segment.


## us-gaap:EarningsPerShareTextBlock

[0001193125-16-582073:notes:90]
(13) Earnings Per
 Share

[0001193125-16-582073:notes:91]
For
 the quarter ended March 28, 2016, potential shares of common
 stock, consisting of stock options to purchase approximately 387
 shares of common stock at exercise prices ranging from $5.78 to
 $16.82 per share, 3,118 restricted stock units (RSUs), and 301
 performance-based restricted stock units (PRUs) were not included
 in the computation of diluted earnings per share because the
 Company incurred a net loss and, as a result, the impact would be
 anti-dilutive.

[0001193125-16-582073:notes:92]
For
 the quarter ended March 30, 2015, PRUs, RSUs, and stock
 options to purchase 438 of shares of common stock were not
 considered in calculating diluted earnings per share because the
 options’ exercise prices or the total assumed proceeds under
 the treasury stock method for PRUs, RSUs, or stock options was
 greater than the average market price of common shares during the
 applicable year and, therefore, the effect would be
 anti-dilutive.

[0001193125-16-582073:notes:93]
Additionally, for the quarter ended March 28, 2016, the effect
 of shares of common stock related to the Company’s
 convertible senior notes, based on the if-converted method, were
 not included in the computation of dilutive earnings per share
 because the Company incurred a net loss from operations and, as a
 result, the impact would be anti-dilutive.

[0001193125-16-582073:notes:94]
For
 the quarter ended March 30, 2015, the effect of shares of common
 stock related to the Company’s convertible senior notes,
 based on the treasury stock method, were not included in the
 computation of dilutive earnings per share because the conversion
 price of the convertible senior notes were greater than the average
 market price of common shares during the quarter, and therefore,
 the effect would be anti-dilutive.

[0001193125-16-582073:notes:95]
Outstanding warrants for the quarters ended March 28, 2016 and
 March 30, 2015, to purchase common stock of 25,940 and 27,970,
 respectively, were not included in the computation of dilutive
 earnings per share because the strike price of the warrants to
 purchase the Company’s common stock were greater than the
 average market price of common shares during the applicable
 quarter, and therefore, the effect would be
 anti-dilutive.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-16-582073:notes:96]
The following table summarizes the long-term debt of the
 Company as of March 28, 2016 and December 28, 2015:

[0001193125-16-582073:notes:97]
|  |  | Average Effective Interest Rate as of March 28, 2016 |  | March 28, 2016 |  |  | Average Effective Interest Rate as of December 28, 2015 |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  | 6.00% |  | $ | 871,143 |  |  | 6.00% |  | $ | 947,625 |  |
| U.S. ABL revolving loan due May 2020 |  | 2.19% |  |  | 80,000 |  |  | 2.17% |  |  | 80,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  | 250,000 |  |  | 1.75% |  |  | 250,000 |  |
| Capital lease |  | 6.43% |  |  | 2,038 |  |  |  |  |  | — |  |
|  |  |  |  |  | 1,203,181 |  |  |  |  |  | 1,277,625 |  |
| Less: Long-term debt unamortized discount |  |  |  |  | (71,727 | ) |  |  |  |  | (75,668 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  | (29,230 | ) |  |  |  |  | (31,171 | ) |
|  |  |  |  |  | 1,102,224 |  |  |  |  |  | 1,170,786 |  |
| Less: current maturities |  |  |  |  | (80,358 | ) |  |  |  |  | (157,375 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 1,021,866 |  |  |  |  | $ | 1,013,411 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-16-582073:notes:98]
(9) Accumulated Other
 Comprehensive Income (Loss)

[0001193125-16-582073:notes:99]
The following provides a summary of the components of
 accumulated other comprehensive income (loss) as of March 28,
 2016 and December 28, 2015:

[0001193125-16-582073:notes:100]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 28, 2015 |  | $ | 2,895 |  |  | $ | (1,272 | ) |  | $ | 1,623 |  |
| Other comprehensive loss before reclassifications |  |  | (3,873 | ) |  |  | (7 | ) |  |  | (3,880 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 42 |  |  |  | 42 |  |
| Other comprehensive (loss) income |  |  | (3,873 | ) |  |  | 35 |  |  |  | (3,838 | ) |
| Ending balance at March 28, 2016 |  | $ | (978 | ) |  | $ | (1,237 | ) |  | $ | (2,215 | ) |

[0001193125-16-582073:notes:101]
The following provides a summary of reclassifications out of
 accumulated other comprehensive income (loss) for the quarters
 ended March 28, 2016 and March 30, 2015:

[0001193125-16-582073:notes:102]
|  |  |  |  | Amount Reclassified from Accumulated Other Comprehensive Income For the Quarter Ended |  |
| Details about Accumulated Other Comprehensive Income Components |  | Statement of Operations Location |  | March 28, 2016 |  |  | March 30, 2015 |  |
|  |  |  |  | (In thousands) |  |
| Gain on foreign currency translation |  | Gain on sale of assets, net of tax |  | $ | — |  |  | $ | (1,786 | ) |
| Loss on cash flow hedges |  | Depreciation expense, net of tax |  | $ | 42 |  |  | $ | 42 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-16-582073:notes:103]
[same as prior period, unchanged from 0001193125-15-366187:notes:133]

[0001193125-16-582073:notes:104]
TTM
 Technologies, Inc. (the Company or TTM) is a major global printed
 circuit board (PCB) manufacturer, focusing on quick-turn and
 technologically advanced PCBs and electro-mechanical solutions (E-M
 Solutions). The Company provides time-to-market and advanced
 technology products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final volume production. This one-stop manufacturing solution
 allows the Company to align technology developments with the
 diverse needs of the Company’s customers and to enable them
 to reduce the time required to develop new products and bring them
 to market.

[0001193125-16-582073:notes:105]
The
 Company serves a diversified customer base in various markets
 throughout the world, including manufacturers of
 networking/communications infrastructure products, tablets and
 smartphones, as well as the aerospace and defense, automotive
 controls and information systems, high-end computing, and medical,
 industrial and instrumentation related products. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

[0001193125-16-582073:notes:106]
[same as prior period, unchanged from 0001193125-15-366187:notes:136]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-16-582073:notes:107]
[same as prior period, unchanged from 0001193125-15-366187:notes:137]

[0001193125-16-582073:notes:108]
[same as prior period, unchanged from 0001193125-15-366187:notes:138]

[0001193125-16-582073:notes:109]
During
 the quarter ended March 28, 2016, the Company’s
 effective tax rate was impacted by a net discrete benefit of $351
 related to a tax holiday and accrued interest on existing uncertain
 tax positions. Additionally, no tax benefit was recorded on the
 losses incurred in the U.S. and certain foreign jurisdictions as a
 result of corresponding increases in the valuation allowances in
 these jurisdictions. The Company’s foreign earnings
 attributable to certain subsidiaries in China will be indefinitely
 reinvested in such foreign jurisdictions and, therefore, no
 deferred tax liabilities for U.S. income taxes on undistributed
 earnings are recorded.

[0001193125-16-582073:notes:110]
Certain entities in China operated under tax incentives
 effective through 2016. The tax incentives decreased Chinese taxes
 by $1,664, which increased both basic and diluted earnings per
 share by $0.02 for the quarter ended March 28,
 2016.

[0001193125-16-582073:notes:111]
As of
 March 28, 2016, the Company had not finalized the
 determination of fair values allocated to various assets and
 liabilities, including, deferred taxes, tax uncertainties, and
 income taxes payable related to the acquisition of Viasystems. Any
 changes in the fair values of these liabilities assumed during the
 measurement period may result in material adjustments to
 goodwill.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-16-582073:notes:112]
(12) Commitments and
 Contingencies

[0001193125-16-582073:notes:113]
Legal
 Matters

[0001193125-16-582073:notes:114]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of March 28, 2016 and
 December 28, 2015. However, these amounts are not material to
 the consolidated condensed financial statements of the
 Company.

[0001193125-16-582073:notes:115]
Environmental
 Matters

[0001193125-16-582073:notes:116]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States, Canada and Mexico comply in all
 material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted new
 rules and regulations governing environmental issues. An update to
 the Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the updated environmental regulations. The Company believes it
 has developed plans acceptable to the Chinese government and is in
 the process of implementing these plans. The Company does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan related to the efforts to come into full
 compliance with the new regulations. The 2016 capital expenditure
 costs expected for these plans are included in the Company’s
 capital expenditure projections.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-16-582073:notes:117]
(16) Related Party
 Transactions

[0001193125-16-582073:notes:118]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 For the quarters ended March 28, 2016 and March 30, 2015, the
 Company’s foreign subsidiaries purchased $15,998 and $9,945,
 respectively, of laminate and prepreg from these related
 parties.

[0001193125-16-582073:notes:119]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCBs to SYE and purchases PCBs including various
 services relating to PCB manufacturing from SYE. Sales to SYE for
 the quarters ended March 28, 2016 and March 30, 2015 were $311 and
 $1,481, respectively. Purchases of PCBs including various services
 relating to PCB manufacturing for the quarters ended March 28, 2016
 and March 30, 2015 were $28 and $439, respectively.

[0001193125-16-582073:notes:120]
As of
 March 28, 2016 and December 28, 2015, the Company’s
 consolidated condensed balance sheets included $19,886 and $29,306,
 respectively, in accounts payable due to related parties for
 purchases of laminate and prepreg and various PCB manufacturing
 services and such balances are included as a component of accounts
 payable on the consolidated condensed balance sheets. Additionally,
 the Company’s consolidated condensed balance sheets included
 $976 and $1,999, respectively, in accounts receivable due from a
 related party for sales of PCBs to SYE, as mentioned above, and
 such balances are included as a component of accounts receivable,
 net on the consolidated condensed balance sheets.


## us-gaap:LongTermDebtTextBlock

[0001193125-16-582073:notes:121]
(7) Long-term Debt and
 Letters of Credit

[0001193125-16-582073:notes:122]
The fiscal calendar maturities of long-term debt through 2020
 and thereafter are as follows:

[0001193125-16-582073:notes:123]
Term and Revolving
 Loans

[0001193125-16-582073:notes:124]
On May 31, 2015, in conjunction with the acquisition of
 Viasystems, the Company entered into a $950,000 Term Loan Credit
 Agreement (Term Loan). Additionally, the Company entered into a
 $150,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and a
 $150,000 Asia Asset-Based Lending Credit agreement (Asia ABL)
 (collectively the ABL Revolving Loans). The Company drew $80,000 of
 the U.S. ABL at the closing of the acquisition of
 Viasystems.

[0001193125-16-582073:notes:125]
The Term Loan was issued at a discount at 96.5% and bears
 interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus
 an applicable interest margin of 5.0%, or JP Morgan Chase
 Bank’s prime rate, with a 2% floor, plus a margin of 4%, at
 the Company’s option. At March 28, 2016, the weighted
 average interest rate on the outstanding borrowings under the Term
 Loan was 6.0%. There is no provision, other than an event of
 default, for the interest margin to increase. The Term Loan will
 mature on May 31, 2021. The Term Loan is secured by a
 significant amount of the assets of the Company and its domestic
 subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and is structurally
 senior to the Company’s convertible senior notes. See
 Convertible Senior Notes below.

[0001193125-16-582073:notes:126]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $150,000, a letter of credit
 facility of up to $75,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $150,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 175 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 75 basis points, at the Company’s option. At March
 28, 2016, the weighted average interest rate on the outstanding
 borrowings under the U.S. ABL was 2.19%. Beginning in 2016, the
 applicable margin can vary based on the remaining availability of
 the facility, from 150 to 200 basis points for LIBOR-based loans or
 from 50 to 100 basis points for JP Morgan Chase Bank’s prime
 rate-based loans. Other than availability and an event of default,
 there are no other provisions for the interest margin to increase.
 The U.S. ABL will mature on May 31, 2020. Loans made under the
 U.S. ABL are secured first by all of the Company’s domestic
 cash, receivables and inventories as well as by a second position
 against a significant amount of the assets of the Company and its
 domestic subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and are
 structurally senior to the Company’s convertible senior
 notes. See Convertible Senior Notes below. At March 28, 2016,
 $80,000 of the U.S. ABL was outstanding and classified as
 short-term debt.

[0001193125-16-582073:notes:127]
The Company and its domestic subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Term
 Loan and U.S. ABL related obligations.

[0001193125-16-582073:notes:128]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of the Company’s Asia Pacific cash and
 receivables and are structurally senior to the Company’s
 domestic obligations, including the convertible senior notes. See
 Convertible Senior Notes below. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At March 28, 2016, none of the Asia ABL
 was outstanding.

[0001193125-16-582073:notes:129]
The Company is required to make scheduled payments of the
 outstanding Term Loan balance on a quarterly basis which began on
 October 1, 2015. Based on certain parameters defined in the
 Term Loan agreement, the Company may be required to make an
 additional principal payment on an annual basis. Any additional
 annual payments reduce future required quarterly scheduled
 payments. During the quarter ended March 28, 2016, the Company made
 debt principal payments totaling $76,482 representing normally
 scheduled principal payments as well as an additional prepayment of
 principal. Any other outstanding balances under the Term Loan are
 due at the maturity date of May 31, 2021. Borrowings under the
 Term Loan are subject to various financial and operating covenants
 including maintaining a maximum total leverage ratio. Under the
 occurrence of certain events, the U.S. ABL and the Asia ABL are
 subject to various financial and operational covenants, including
 maintaining minimum fixed charge coverage ratios. At March 28,
 2016, the Company was in compliance with the covenants under the
 Term Loan, the U.S. ABL and the Asia ABL.

[0001193125-16-582073:notes:130]
As of March 28, 2016 and December 28, 2015, remaining
 unamortized debt discount of $28,261 and $30,242, respectively, and
 debt issuance costs of $24,874 and $26,619, respectively, related
 to the Term Loan. These debt discount and debt issuance costs are
 recorded as a reduction of the Term Loan and are amortized over the
 duration of the Term Loan into interest expense using an effective
 interest rate of 7.50%.

[0001193125-16-582073:notes:131]
Additionally, remaining unamortized debt issuance costs related
 to the ABL Revolving Loans were $4,060 and $4,303 as of March 28,
 2016 and December 28, 2015, respectively. These debt issuance costs
 are included in other non-current assets and are amortized to
 interest expense over the duration of the ABL Revolving Loans using
 the straight line method of amortization.

[0001193125-16-582073:notes:132]
At March 28, 2016, the remaining amortization period for the
 unamortized debt discount and debt issuance costs for both the Term
 Loan and the ABL Revolving Loans was 5.1 years.

[0001193125-16-582073:notes:133]
The Company is required to pay a commitment fee of
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The U.S. ABL commitment fee may vary from 0.25% to 0.375%
 based on utilization levels. Additionally, the Company also paid
 commitment fees of 0.5% per annum on the unused portion of the
 $90,000 senior secured revolving loan associated with the
 terminated 2012 credit agreement for the quarter ended March 30,
 2015. The Company incurred total commitment fees related to unused
 borrowing availability of $194 and $173 for the quarters ended
 March 28, 2016 and March 30, 2015, respectively. As of March 28,
 2016, the outstanding amount of the Term Loan was $871,143, all of
 which is included as long-term debt. Additionally, $80,000 of the
 U.S. ABL and none of the Asia ABL was outstanding as of March 28,
 2016. Available borrowing capacity under the U.S. ABL and Asia ABL
 was $63,033 and $141,128, which considers letters of credit
 outstanding of $6,967 and $8,872 mentioned below, respectively, at
 March 28, 2016.

[0001193125-16-582073:notes:134]
Letters of
 Credit

[0001193125-16-582073:notes:135]
The Company has up to $75,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of March 28, 2016, letters of credit in the
 amount of $6,967 were outstanding under the U.S. ABL and $8,872
 were outstanding under the Asia ABL with various expiration dates
 through February 2017.

[0001193125-16-582073:notes:136]
At December 28, 2015, certain letters of credit were
 securitized by cash collateral. As such the Company had recorded
 such cash as restricted cash on the consolidated condensed balance
 sheet as of December 28, 2015. As of March 28, 2016, none of the
 letters of credit are securitized by cash collateral.

[0001193125-16-582073:notes:137]
Convertible Senior
 Notes

[0001193125-16-582073:notes:138]
Convertible Senior
 Notes due 2020

[0001193125-16-582073:notes:139]
The Company issued 1.75% convertible senior notes due
 December 15, 2020, in a public offering for an aggregate
 principal amount of $250,000 in 2013. The convertible senior notes
 bear interest at a rate of 1.75% per annum. Interest is
 payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and are senior
 in right of payment to any of the Company’s future
 subordinated indebtedness.

[0001193125-16-582073:notes:140]
Convertible Senior
 Notes due 2015

[0001193125-16-582073:notes:141]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015, in a public offering for an aggregate principal
 amount of $175,000. In May 2015 the outstanding principal of
 $32,395 plus accrued interest was paid in full.

[0001193125-16-582073:notes:142]
As of March 28, 2016 and December 28, 2015, the following
 summarizes the equity components of the convertible senior notes
 included in additional paid-in capital:

[0001193125-16-582073:notes:143]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended March 28, 2016 and
 March 30, 2015 are as follows:

[0001193125-16-582073:notes:144]
|  |  | For the Quarter Ended |  |
|  |  | March 28, 2016 |  |  | March 30, 2015 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 263 |  |
|  |  | $ | 1,094 |  |  | $ | 1,357 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,960 |  |  | $ | 1,838 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 367 |  |
|  |  | $ | 1,960 |  |  | $ | 2,205 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 196 |  |  | $ | 184 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 37 |  |
|  |  | $ | 196 |  |  | $ | 221 |  |

[0001193125-16-582073:notes:145]
As of March 28, 2016 and December 28, 2015, remaining
 unamortized debt discount of $43,466 and $45,426, respectively, and
 debt issuance costs of $4,356 and $4,552, respectively, related to
 the convertible senior notes. These debt discount and debt discount
 issuance costs are recorded as a reduction of the convertible
 senior notes and are being amortized to interest expense over the
 term of the convertible senior notes using the effective interest
 rate method. At March 28, 2016, the remaining weighted average
 amortization period for the unamortized senior convertible note
 discount and debt issuance costs was 4.7 years.

[0001193125-16-582073:notes:146]
For the quarters ended March 28, 2016 and March 30, 2015, the
 amortization of the convertible senior notes due 2020 debt discount
 and debt issuance costs is based on an effective interest rate of
 6.48%. For the quarter ended March 30, 2015, the amortization of
 the convertible senior notes due 2015 debt discount and debt
 issuance costs is based on an effective interest rate of
 8.37%.

[0001193125-16-582073:notes:147]
Other Credit
 Facility

[0001193125-16-582073:notes:148]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $35,300 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2016. As of March 28, 2016, the Chinese Revolver had not been
 drawn upon.
