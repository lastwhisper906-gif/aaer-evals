# TTMI MD&A — 0001193125-16-582073


## mdna

[0001193125-16-582073:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial
Condition and Results of Operations

[0001193125-16-582073:mdna:2]
This
discussion and analysis should be read in conjunction with “Management’s Discussion and Analysis of Financial Condition and Results of Operations” set forth in our Annual Report on Form 10-K for the fiscal year ended December 28,
2015, filed with the SEC.

[0001193125-16-582073:mdna:3]
[same as prior period, unchanged from 0001193125-15-366187:mdna:3]

[0001193125-16-582073:mdna:4]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and technologically advanced PCBs and electro-mechanical solutions (E-M Solutions). We focus on providing
time-to-market and advanced technology products and offer a one-stop manufacturing solution to our customers from engineering support to prototype development through final volume production. This one-stop manufacturing solution allows us to align
technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,500 customers in
various markets throughout the world, including manufacturers of networking/communications infrastructure products, smartphones, tablets and ultra notebooks, as well as the aerospace and defense, automotive controls and information systems, high-end
computing, and medical, industrial and instrumentation related products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001193125-16-582073:mdna:5]
On May 31, 2015, we completed the acquisition of Viasystems Group, Inc. (Viasystems), for total consideration of
$248.8 million in cash and 15.1 million shares of TTM common stock with a fair value of $149.0 million, to acquire all of the outstanding shares of capital stock and other equity rights of Viasystems. Additionally, in connection with the completion
of the acquisition, we assumed and refinanced Viasystems’ debt, which was approximately $669.0 million as of May 31, 2015. Viasystems was a worldwide provider of complex multi-layer rigid, flexible, and rigid-flex PCBs and custom
electronic assemblies.

[0001193125-16-582073:mdna:6]
While our customers include both OEMs and EMS providers, we measure customers based on
OEM companies, as they are the ultimate end customers. Sales to our 10 largest customers accounted for 41% and 59% of our net sales for the quarters ended March 28, 2016 and March 30, 2015, respectively. We sell to OEMs both directly and
indirectly through EMS providers.

[0001193125-16-582073:mdna:7]
The following table shows the percentage of our net sales attributable to
each of the principal end markets we served for the periods indicated:

[0001193125-16-582073:mdna:8]
|  |  | Quarter Ended |  |
| End Markets(1)(2) |  | March 28,2016 (4) |  |  | March 30,2015 |  |
| Aerospace and Defense |  |  | 15 | % |  |  | 15 | % |
| Automotive(2) |  |  | 21 |  |  |  | 3 |  |
| Cellular Phone(3) |  |  | 9 |  |  |  | 30 |  |
| Computing/Storage/Peripherals(3) |  |  | 13 |  |  |  | 11 |  |
| Medical/Industrial/Instrumentation/Other. |  |  | 16 |  |  |  | 9 |  |
| Networking/Communications |  |  | 24 |  |  |  | 29 |  |
| Other(2)(3) |  |  | 2 |  |  |  | 3 |  |
| Total |  |  | 100 | % |  |  | 100 | % |

[0001193125-16-582073:mdna:9]
[same as prior period, unchanged from 0001193125-15-366187:mdna:14]

[0001193125-16-582073:mdna:10]
| (2) | Certain reclassifications of prior year end market percentages have been made to conform to the current year presentation. Beginning 2015, Automotive has been reclassified from the Other end market. |

[0001193125-16-582073:mdna:11]
| (3) | Smartphones are included in the Cellular Phone end market, tablets are included in the Computing/Storage/Peripherals end market and other mobile devices such as e-readers are included in the Other end market. |

[0001193125-16-582073:mdna:12]
| (4) | Amounts includes activity of Viasystems, which we acquired on May 31, 2015. |

[0001193125-16-582073:mdna:13]
21

[0001193125-16-582073:mdna:14]
We derive revenues primarily from the sale of PCBs and custom electronic
assemblies using customer-supplied engineering and design plans. We recognize revenues when persuasive evidence of a sales arrangement exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is
reasonably assured — generally when products are shipped to the customer. Net sales consist of gross sales less an allowance for returns, which typically have been less than 3% of gross sales. We provide our customers a limited right of return
for defective PCBs and backplane assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results. Purchase orders may be cancelled prior to shipment. We generally charge customers a fee, based on
the percentage completed, if an order is cancelled once it has entered production.

[0001193125-16-582073:mdna:15]
Cost of goods sold
consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a
component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. We generally do not participate in any significant long-term contracts with suppliers, and we believe
there are a number of potential suppliers for the raw materials we use.

[0001193125-16-582073:mdna:16]
Selling and marketing expenses
consist primarily of salaries, labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0001193125-16-582073:mdna:17]
General and administrative costs primarily include the salaries for executive, finance, accounting,
information technology, facilities and human resources personnel, as well as insurance expenses, expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and
equipment.

[0001193125-16-582073:mdna:18]
[same as prior period, unchanged from 0001193125-15-366187:mdna:21]

[0001193125-16-582073:mdna:19]
Our consolidated condensed financial statements included in this report have been prepared in accordance with U.S. GAAP.
The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001193125-16-582073:mdna:20]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of
Operation, in our Annual Report on Form 10-K for the fiscal year ended December 28, 2015 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates
since December 28, 2015.

[0001193125-16-582073:mdna:21]
[same as prior period, unchanged from 0001193125-15-366187:mdna:24]

[0001193125-16-582073:mdna:22]
The Viasystems acquisition occurred on May 31, 2015. Accordingly, the results of operations of Viasystems are not
included in our fiscal quarter end March 30, 2015. The acquisition has had and will continue to have a significant effect on our operations as discussed below.

[0001193125-16-582073:mdna:23]
The following table sets forth the relationship of various items to net sales in our consolidated condensed statements of operations:

[0001193125-16-582073:mdna:24]
|  |  | Quarter Ended |  |
|  |  | March 28, 2016 |  |  | March 30, 2015 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 85.7 |  |  |  | 84.3 |  |
| Gross profit |  |  | 14.3 |  |  |  | 15.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.0 |  |  |  | 2.9 |  |
| General and administrative |  |  | 6.2 |  |  |  | 10.5 |  |
| Amortization of definite-lived intangibles |  |  | 1.0 |  |  |  | 0.6 |  |
| Impairment of long-lived assets |  |  | 0.6 |  |  |  | — |  |
| Restructuring charges |  |  | 0.3 |  |  |  | — |  |
| Gain on sale of assets |  |  | — |  |  |  | (0.8 | ) |
| Total operating expenses |  |  | 11.1 |  |  |  | 13.2 |  |
| Operating income |  |  | 3.2 |  |  |  | 2.5 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (3.7 | ) |  |  | (1.8 | ) |
| Other, net |  |  | 0.2 |  |  |  | (0.1 | ) |
| Total other expense, net |  |  | (3.5 | ) |  |  | (1.9 | ) |
| (Loss) income before income taxes |  |  | (0.3 | ) |  |  | 0.6 |  |
| Income tax (provision) benefit |  |  | (0.9 | ) |  |  | 0.4 |  |
| Net (loss) income |  |  | (1.2 | ) |  |  | 1.0 |  |
| Less: Net income attributable to the non-controlling interest |  |  | — |  |  |  | — |  |
| Net (loss) income attributable to TTM Technologies, Inc. stockholders |  |  | (1.2 | )% |  |  | 1.0 | % |

[0001193125-16-582073:mdna:25]
As a result of the acquisition of Viasystems and the new business structure implemented
in the quarter ended March 28, 2016, we have reassessed our reportable operating segments and determined that we have two reportable operating segments: PCB and E-M Solutions. This determination was made based on the criteria of earning revenues and
incurring expenses, our organizational structure which has segment managers who report to the chief operating decision maker and discrete financial information, and the aggregation of similar operating segments into reportable operating segments.

[0001193125-16-582073:mdna:26]
The following table compares net sales by reportable segment for the quarters ended March 28, 2016 and
March 30, 2015:

[0001193125-16-582073:mdna:27]
|  |  | For the Quarters Ended |  |
|  |  | March 28, 2016 |  |  | March 30, 2015 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 529,945 |  |  | $ | 310,324 |  |
| E-M Solutions |  |  | 56,478 |  |  |  | 19,462 |  |
| Total sales |  |  | 586,423 |  |  |  | 329,786 |  |
| Inter-segment sales |  |  | (3,165 | ) |  |  | (622 | ) |
| Total net sales |  | $ | 583,258 |  |  | $ | 329,164 |  |

[0001193125-16-582073:mdna:28]
23

[0001193125-16-582073:mdna:29]
[same as prior period, unchanged from 0001193125-15-366187:mdna:31]

[0001193125-16-582073:mdna:30]
Total net sales increased $254.1 million, or 77.2%, from $329.2 million for the quarter ended March 30, 2015 to
$583.3 million for the quarter ended March 28, 2016.

[0001193125-16-582073:mdna:31]
Net sales for the PCB operating segment, excluding
inter-segment sales, increased $217.0 million, or 70.0%, from $309.8 million for the quarter ended March 30, 2015 to $526.8 million for the quarter ended March 28, 2016. This increase is primarily due to the additional sales resulting from the
acquisition of Viasystems, which accounted for $241.1 million in PCB sales for the quarter ended March 28, 2016, partially offset by lower demand in our Cellular Phone end market. These changes, including the sales from Viasystems, resulted in
a 181.9% increase in PCB shipments as compared to the quarter ended March 30, 2015, partially offset by an average PCB selling price decrease of 38.7%, which was driven by a product mix shift resulting from the acquisition.

[0001193125-16-582073:mdna:32]
Net sales for the E-M Solutions operating segment increased $37.1 million from $19.4 million for the quarter ended March
30, 2015 to $56.5 million for the quarter ended March 28, 2016. This increase is due to the additional sales resulting from the acquisition of Viasystems, which accounted for $37.2 million in E-M Solutions sales for the quarter ended March 28,
2016.

[0001193125-16-582073:mdna:33]
[same as prior period, unchanged from 0001193125-15-366187:mdna:34]

[0001193125-16-582073:mdna:34]
Overall gross margin decreased from 15.7% for the quarter ended March 30, 2015 to 14.3% for the quarter ended March 28, 2016.

[0001193125-16-582073:mdna:35]
Gross margin for the PCB operating segment decreased from 16.2% for the quarter ended March 30, 2015 to 15.6% for the
quarter ended March 28, 2016 primarily due to lower utilization at our advanced technology plants.

[0001193125-16-582073:mdna:36]
Gross
margin for the E-M Solutions operating segment decreased from 7.7% for the quarter ended March 30, 2015 to 6.6% for the quarter ended March 28, 2016 primarily due to the acquisition of Viasystems with lower margins than our existing business.

[0001193125-16-582073:mdna:37]
[same as prior period, unchanged from 0001193125-15-366187:mdna:36]

[0001193125-16-582073:mdna:38]
Selling and marketing expenses increased $7.8 million, from $9.5 million for the quarter ended March 30, 2015 to $17.3 million for the quarter ended March 28, 2016. As a percentage of net sales, selling
and marketing expenses were 2.9% for the quarter ended March 30, 2015, as compared to 3.0% for the quarter ended March 28, 2016. The increase in selling and marketing expense primarily relates to increased selling and marketing expense incurred by
Viasystems, partially offset by workforce reductions associated with global realignment efforts.

[0001193125-16-582073:mdna:39]
[same as prior period, unchanged from 0001193125-15-366187:mdna:38]

[0001193125-16-582073:mdna:40]
General and administrative expenses increased $1.7 million from $34.5 million, or 10.5% of net sales,
for the quarter ended March 30, 2015 to $36.2 million, or 6.2% of net sales, for the quarter ended March 28, 2016. The increase in expense primarily relates to increased general and administrative expense incurred related to Viasystems, partially
offset by a $7.5 million decrease in acquisition related costs. The decrease in general and administrative expense as percentage of net sales is primarily due to higher net sales.

[0001193125-16-582073:mdna:41]
Impairment of Long-Lived Assets and Restructuring Charges

[0001193125-16-582073:mdna:42]
For the quarter ended March 28, 2016, we incurred restructuring charges of $1.9 million which primarily related to the September 29, 2015 announced consolidation plan that will result in the closure
of our facilities in Cleveland, Ohio, Milpitas, California, Juarez, Mexico (the Consolidation Plan). These charges primarily represent severance and contract termination and other costs. Approximately $1.2 million of these restructuring charges
were recognized in our PCB operating segment and $0.7 million in our E-M Solutions operating segment. As of March 28, 2016, we have incurred approximately $9.2 million of such charges since the September 29, 2015 announcement and estimate that we
will incur total charges of approximately $10.0 million to $15.0 million related to these closures.

[0001193125-16-582073:mdna:43]
Additionally, as a result of the above mentioned plant closures and other plant realignment efforts, we also recognized
$3.3 million in impairment charges during the quarter ended March 28, 2016, of which $1.4 million related to our PCB operating segment and $1.9 million related to the Corporate operating segment. The impairment charge for the PCB operating
segment related to machinery and equipment while the impairment charge for the Corporate operating segment related to the write-off of capitalized software costs.

[0001193125-16-582073:mdna:44]
If forecasts and assumptions used to support the realizability of our long-lived assets change in the future, significant
impairment or restructuring charges could result that would adversely affect our results of operations and financial condition.

[0001193125-16-582073:mdna:45]
24

[0001193125-16-582073:mdna:46]
[same as prior period, unchanged from 0001193125-15-366187:mdna:40]

[0001193125-16-582073:mdna:47]
Other expense, net increased $14.4 million from $6.2 million for the quarter ended March 30, 2015 to $20.6 million for the
quarter ended March 28, 2016. The increase in other expense, net was primarily due to an increase in interest expense related to the Term Loan and U.S. ABL, currently totaling $951.1 million at a weighted average interest rate of 5.7%, which was
entered into on May 31, 2015 in connection with the acquisition of Viasystems. The increase in other expense, net was partially offset by $1.1 million higher foreign currency transaction gains for the quarter ended March 28, 2016 due to the
devaluation of the Renminbi, which is utilized at certain of our Asia operations.

[0001193125-16-582073:mdna:48]
[same as prior period, unchanged from 0001193125-15-366187:mdna:43]

[0001193125-16-582073:mdna:49]
The provision for income taxes increased by $6.9 million from a tax benefit of $1.4 million for the quarter ended March
30, 2015 to income tax expense of $5.5 million for the quarter ended March 28, 2016. The increase in income tax expense in 2016 is primarily due to no tax benefit being recognized on U.S. losses with a full valuation allowance. Further, the income
tax expense for the quarter ended March 28, 2016 was higher due to inclusion of Viasystems earnings from foreign subsidiaries.

[0001193125-16-582073:mdna:50]
Our effective tax rate was primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of other credits and deductions
available to us, valuation allowance establishment, and certain non-deductible items. Certain foreign losses generated are not more likely than not to be realizable, and thus no income tax benefit has been recognized on these losses. As of March 28,
2016, we had net deferred income tax liabilities of approximately $11.7 million and as of December 28, 2015, we had net deferred income tax liabilities of approximately $13.1 million.

[0001193125-16-582073:mdna:51]
[same as prior period, unchanged from 0001193125-15-366187:mdna:46]

[0001193125-16-582073:mdna:52]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, and term and revolving debt. Our principal uses of cash have been to finance
acquisitions and capital expenditures, meet debt service requirements, fund working capital requirements, and refinance existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working
capital requirements will continue to be the principal demands on our cash in the future.

[0001193125-16-582073:mdna:53]
Cash flow provided
by operating activities during the quarter ended March 28, 2016 was $17.9 million as compared to $67.4 million in the same period in 2015. The decrease in cash flow was due to seasonal volatility and timing of receivable collections. As of
March 28, 2016, we had net working capital of approximately $309.8 million compared to $277.5 million as of December 28, 2015. Cash cycle days were 54 days for the quarter ended March 28, 2016 as compared to 53 days for the
quarter ended March 30, 2015, essentially unchanged.

[0001193125-16-582073:mdna:54]
Net cash used in investing activities was
approximately $16.6 million for the quarter ended March 28, 2016 primarily reflecting purchases of property, plant and equipment of $20.1 million less release of restricted cash to cash and cash equivalents of $3.5 million. For the quarter
ended March 30, 2015, net cash used in investing activities was approximately $15.6 million reflecting purchases of property, plant and equipment of $22.8 million, net of proceeds from the sale of such property, plant and equipment and other asset
held for sale of $7.2 million.

[0001193125-16-582073:mdna:55]
Net cash used in financing activities was approximately $76.5 million for the
quarter ended March 28, 2016 reflecting the repayment of normally scheduled principal payments as well as an additional prepayment of principal of long-term debt. For the quarter ended March 30, 2015, net cash used in financing activities was
approximately $47.8 million reflecting the repayment of long-term debt of $48.1 million, offset by proceeds from the exercise of stock options of $0.3 million.

[0001193125-16-582073:mdna:56]
As of March 28, 2016, we had cash and cash equivalents of approximately $183.7 million, of which approximately $142.0 million was held by our foreign subsidiaries, primarily Asia. Cash and cash
equivalents held by our foreign locations are expected to be used in local operations.

[0001193125-16-582073:mdna:57]
Our 2016 capital
expenditure plan is expected to be in the range of $110 million to $120 million. The expenditures will fund capital equipment purchases to increase production capacity, especially for advanced technology manufacturing, comply with changing
environmental regulations, replace aging equipment, and expand our technological capabilities.

[0001193125-16-582073:mdna:58]
[same as prior period, unchanged from 0001193125-15-366187:mdna:53]

[0001193125-16-582073:mdna:59]
On May 31, 2015, in conjunction with the acquisition of Viasystems, we entered into a $950.0
million Term Loan Credit Agreement (Term Loan). Additionally, we entered into a $150.0 million U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and a $150.0 million Asia Asset-Based Lending Credit agreement (Asia ABL). We drew $80.0 million of
the U.S. ABL at the closing of the acquisition of Viasystems.

[0001193125-16-582073:mdna:60]
The Term Loan Credit agreement was issued at a discount at 96.5% and bears
interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus an applicable interest margin of 5.0%. At March 28, 2016, the weighted average interest rate on the outstanding borrowings under the Term Loan was 6.0%. There is no provision, other
than an event of default, for the interest margin to increase. The Term Loan will mature on May 31, 2021. The Term Loan is secured by a significant amount of our assets and our domestic subsidiaries and a pledge of 65% of the voting stock of
our first tier foreign subsidiaries and is structurally senior to our convertible senior notes. See Convertible Senior Notes due 2020 below.

[0001193125-16-582073:mdna:61]
The U.S. ABL consists of three tranches comprised of a revolving credit facility of up to $150.0 million, a letter of credit facility of up to $75.0 million, and swingline loans of up to $30.0 million,
provided that at no time may amounts outstanding under the tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement.
Borrowings under the U.S. ABL bear interest at a floating rate of LIBOR plus a margin of 175 basis points. At March 28, 2016, the weighted average interest rate on the outstanding borrowings under the U.S. ABL was 2.19%. Beginning in 2016, the
applicable margin can vary based on the remaining availability of the facility, from 150 to 200 basis points for LIBOR-based loans. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic
cash, receivables and inventories as well as by a second position against a significant amount of our assets and our domestic subsidiaries and a pledge of 65% of the voting stock of our first tier foreign subsidiaries and are structurally senior to
our convertible senior notes. See Convertible Senior Notes due 2020 below. At March 28, 2016, $80.0 million of the U.S. ABL was outstanding and classified as a current liability.

[0001193125-16-582073:mdna:62]
We and our domestic subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Term Loan
and U.S. ABL related obligations.

[0001193125-16-582073:mdna:63]
The Asia ABL consists of two tranches comprised of a revolving credit
facility of up to $150.0 million and a letter of credit facility of up to $100.0 million provided that at no time may amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a
percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 175 basis points. There is no provision, other than an event of default, for
the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of our Asia Pacific cash and receivables and are structurally senior to our domestic obligations, including our
convertible senior notes. See Convertible Senior Notes due 2020 below. Our Asia Pacific subsidiary and certain of its subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Asia ABL related obligations. At March
28, 2016, none of the Asia ABL was outstanding.

[0001193125-16-582073:mdna:64]
We are required to make scheduled payments of the outstanding
Term Loan balance on a quarterly basis which began on October 1, 2015. Based on certain parameters defined in the Term Loan agreement, we may be required to make an additional principal payment on an annual basis. Any additional annual payments
reduce future required quarterly scheduled payments. During the quarter ended March 28, 2016, we made debt principal payments totaling $76.5 million representing normally scheduled principal payments as well as an additional prepayment of principal.
Any other outstanding balances under the Term Loan are due at the maturity date of May 31, 2021. Borrowings under the Term Loan are subject to various financial and operating covenants including maintaining a maximum total leverage ratio. Under
the occurrence of certain events, the U.S. ABL and the Asia ABL are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. At December 28, 2015, we were in compliance with the
covenants under the Term Loan, the U.S. ABL and the Asia ABL.

[0001193125-16-582073:mdna:65]
We are also required to pay a commitment fee of
0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The U.S. ABL commitment fee may vary from 0.25% to 0.375% based on utilization levels. Additionally, we also paid commitment fees of 0.5% per annum on the unused portion
of the $90.0 million senior secured revolving loan associated with the terminated 2012 credit agreement for the quarter ended March 30, 2015. We incurred total commitment fees related to unused borrowing availability of $0.2 million for each of the
quarters ended March 28, 2016 and March 30, 2015, respectively. As of March 28, 2016, the outstanding amount of the Term Loan was $871.1 million, all of which is included as long-term debt. Additionally, $80.0 million of the U.S. ABL and none of the
Asia ABL was outstanding as of March 28, 2016. Available borrowing capacity under the U.S. ABL and Asia ABL was $63.0 million and $141.1 million, which includes $7.0 million and $8.9 million, respectively, of outstanding letters of credit mentioned
below at March 28, 2016.

[0001193125-16-582073:mdna:66]
[same as prior period, unchanged from 0001193125-15-366187:mdna:61]

[0001193125-16-582073:mdna:67]
We have up to $75.0 million and $100.0 million Letters of Credit Facilities available under the U.S. ABL and the Asia ABL, respectively. As of March 28, 2016, letters of credit in the amount of $7.0
million were outstanding under the U.S. ABL and $8.9 million were outstanding under the Asia ABL with various expiration dates through February 2017.

[0001193125-16-582073:mdna:68]
[same as prior period, unchanged from 0001193125-15-366187:mdna:63]

[0001193125-16-582073:mdna:69]
We are party to a revolving loan credit facility with a lender in China. Under this arrangement, the lender has made available to us approximately $35.3 million in unsecured borrowing with all terms of
the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in December 2016. As of March 28, 2016, the Chinese Revolver had
not been drawn upon.

[0001193125-16-582073:mdna:70]
Convertible Senior Notes due 2020

[0001193125-16-582073:mdna:71]
On December 2013, we issued 1.75% convertible senior notes due December 15, 2020, in a public offering for an
aggregate principal amount of $250.0 million. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes
are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of
the convertible senior notes.

[0001193125-16-582073:mdna:72]
In connection with the issuance of the convertible senior notes due 2020, we
entered into a convertible note hedge and warrant transaction (the Call Spread Transaction), with respect to our common stock. The convertible note hedge consists of our option to purchase up to 25.9 million common stock shares at a price of
$9.64 per share. The hedge expires on December 15, 2020 and can only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, we sold warrants to purchase 25.9 million shares of our common
stock at a price of $14.26 per share. The warrants expire ratably from March 2021 through January 2022. The Call Spread Transaction has no effect on the terms of the convertible senior notes due 2020 and reduces potential dilution by effectively
increasing the conversion price of the convertible senior notes due 2020 to $14.26 per share of our common stock.

[0001193125-16-582073:mdna:73]
[same as prior period, unchanged from 0001193125-15-366187:mdna:68]

[0001193125-16-582073:mdna:74]
[same as prior period, unchanged from 0001193125-15-366187:mdna:69]

[0001193125-16-582073:mdna:75]
The following table provides information on our contractual obligations as of March 28, 2016:

[0001193125-16-582073:mdna:76]
|  |  | Total |  |  | Less Than1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 953,181 |  |  | $ | 80,358 |  |  | $ | 40,671 |  |  | $ | 95,902 |  |  | $ | 736,250 |  |
| Convertible debt obligations |  |  | 250,000 |  |  |  | — |  |  |  | — |  |  |  | 250,000 |  |  |  | — |  |
| Interest on debt obligations |  |  | 296,606 |  |  |  | 58,981 |  |  |  | 114,187 |  |  |  | 105,030 |  |  |  | 18,408 |  |
| Equipment payables |  |  | 13,984 |  |  |  | 13,984 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 61,943 |  |  |  | 52,854 |  |  |  | 9,089 |  |  |  | — |  |  |  | — |  |
| Operating lease commitments |  |  | 27,736 |  |  |  | 8,816 |  |  |  | 8,986 |  |  |  | 3,781 |  |  |  | 6,153 |  |
| Total contractual obligations |  | $ | 1,603,450 |  |  | $ | 214,993 |  |  | $ | 172,933 |  |  | $ | 454,713 |  |  | $ | 760,811 |  |

[0001193125-16-582073:mdna:77]
| (1) | Unrecognized uncertain tax benefits of $15.4 million are not included in the table above as the settlement timing is uncertain. |

[0001193125-16-582073:mdna:78]
[same as prior period, unchanged from 0001193125-15-366187:mdna:74]

[0001193125-16-582073:mdna:79]
[same as prior period, unchanged from 0001193125-15-366187:mdna:75]

[0001193125-16-582073:mdna:80]
[same as prior period, unchanged from 0001193125-15-366187:mdna:76]

[0001193125-16-582073:mdna:81]
[same as prior period, unchanged from 0001193125-15-366187:mdna:77]
