# TTMI MD&A — 0001193125-14-404493


## mdna

[0001193125-14-404493:mdna:1]
[same as prior period, unchanged from 0001193125-14-295293:mdna:1]

[0001193125-14-404493:mdna:2]
[same as prior period, unchanged from 0001193125-14-295293:mdna:2]

[0001193125-14-404493:mdna:3]
[same as prior period, unchanged from 0001193125-14-295293:mdna:3]

[0001193125-14-404493:mdna:4]
We are a leading global
provider of time-critical and technologically complex printed circuit board (PCB) products and backplane assemblies (PCBs populated with electronic components), which serve as the foundation of sophisticated electronic products. We provide our
customers time-to-market and advanced technology products and offer a one-stop manufacturing solution to customers from engineering support to prototype development through final volume production. We serve a diversified customer base in various
markets throughout the world, including manufacturers of networking/communications infrastructure products, touch screen tablets, and smartphones. We also serve the aerospace and defense, high-end computing, and industrial/medical industries. Our
customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001193125-14-404493:mdna:5]
On September 21, 2014, we, Viasystems Group, Inc. (Viasystems), and Vector Acquisition Corp. (Merger Sub) entered into an Agreement and Plan of Merger (the Merger Agreement) under which we will
acquire all outstanding shares of Viasystems (the Merger) for a combined consideration of $11.33 in cash and 0.706 shares of TTM common stock per outstanding share of Viasystems common stock, which based on the closing market price on
September 19, 2014 was valued at $16.46 per share of Viasystems common stock, or approximately $368 million. The total enterprise value of the transaction, including the assumption of debt, is approximately $927 million. See Note 2 to the
Consolidated Condensed Financial Statements included herein for additional information. The transaction is expected to close in the first half of 2015.

[0001193125-14-404493:mdna:6]
[same as prior period, unchanged from 0001193125-14-295293:mdna:5]

[0001193125-14-404493:mdna:7]
In the normal course of operations, we are exposed to risks associated with fluctuations in foreign currency exchange
rates. Specifically, we are subject to risks associated with transactions that are denominated in currencies other than our functional currencies. Our primary foreign exchange exposure is to the Chinese Renminbi (RMB). For the three quarters ended
September 29, 2014, our consolidated condensed statement of operations included an unrealized foreign exchange loss of approximately $2.1 million, due primarily to the rapid depreciation of the RMB against the U.S. Dollar during the first
quarter of 2014. Unrealized foreign exchange gains during the third quarter of 2014 were approximately $1.5 million. We do not engage in hedging to manage foreign currency risk related to revenue and expenses denominated in RMB nor do we currently
use derivative instruments to reduce exposure to foreign currency risk for a majority of our loans due from our foreign subsidiaries.

[0001193125-14-404493:mdna:8]
Labor costs represent a significant portion of our total manufacturing costs. Our labor costs in the People’s Republic of China (China) have increased rapidly over the past number of years as a
result of mandated increases in the minimum wage and increased compensation offered to our labor force due to the reduction of overtime hours that we implemented to meet standards required by some of our global customers. These increases in labor
costs have reduced the gross and operating margins of our Asia Pacific operating segment. We believe annual labor rate increases together with increased pricing pressures from our principal customers and the reduction in our first quarter and second
quarter operating leverage due to the seasonal nature of our business will occur each year for the foreseeable future and may further reduce gross and operating margins in our Asia Pacific operating segment.

[0001193125-14-404493:mdna:9]
We sell to OEMs both directly and indirectly through EMS providers. While our customers include both OEMs and EMS
providers, we measure customers based on OEM companies as they are the ultimate end customers. Sales to our 10 largest OEM customers accounted for 58% and 56% of our net sales for the quarters ended September 29, 2014 and September 30,
2013, respectively. Sales to our 10 largest OEM customers accounted for 55% and 52% of our net sales for the three quarters ended September 29, 2014 and September 30, 2013, respectively.

[0001193125-14-404493:mdna:10]
[same as prior period, unchanged from 0001193125-14-295293:mdna:27]

[0001193125-14-404493:mdna:11]
The following table shows the percentage of our net sales attributable to
each of the principal end markets we serve for the periods indicated.

[0001193125-14-404493:mdna:12]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
| End Markets(1) |  | September 29,2014 |  |  | September 30,2013 |  |  | September 29,2014 |  |  | September 30,2013 |  |
| Aerospace/Defense |  |  | 15 | % |  |  | 16 | % |  |  | 17 | % |  |  | 16 | % |
| Cellular Phone(2) |  |  | 25 |  |  |  | 21 |  |  |  | 18 |  |  |  | 18 |  |
| Computing/Storage/Peripherals(2) |  |  | 13 |  |  |  | 19 |  |  |  | 15 |  |  |  | 18 |  |
| Medical/Industrial/Instrumentation |  |  | 9 |  |  |  | 9 |  |  |  | 10 |  |  |  | 8 |  |
| Networking/Communications |  |  | 32 |  |  |  | 30 |  |  |  | 35 |  |  |  | 34 |  |
| Other(2) |  |  | 6 |  |  |  | 5 |  |  |  | 5 |  |  |  | 6 |  |
| Total |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001193125-14-404493:mdna:13]
[same as prior period, unchanged from 0001193125-14-295293:mdna:11]

[0001193125-14-404493:mdna:14]
[same as prior period, unchanged from 0001193125-14-295293:mdna:12]

[0001193125-14-404493:mdna:15]
For PCBs, we measure the
time sensitivity of our products by tracking the quick-turn percentage of our work. We define quick-turn orders as those with delivery times of 10 days or less, which typically captures research and development, prototype, and new product
introduction work, in addition to unexpected short-term production demand from our customers. Generally, we quote prices after we receive the design specifications and the time and volume requirements from our customers. Our quick-turn services
command a premium price as compared to our standard lead-time products.

[0001193125-14-404493:mdna:16]
We also deliver product within
compressed lead times of 11 to 20 days. We typically receive a premium price for this work as well. Purchase orders may be cancelled prior to shipment. We charge customers a fee, based on percentage completed, if an order is cancelled once it
has entered production. We derive revenues primarily from the sale of PCBs and backplane assemblies using customer-supplied engineering and design plans. We recognize revenues when persuasive evidence of a sales arrangement exists, the sales terms
are fixed or determinable, title and risk of loss have transferred, and collectability is reasonably assured — generally when products are shipped to the customer. Net sales consist of gross sales less an allowance for returns, which
typically have been less than 3% of gross sales. We provide our customers a limited right of return for defective PCBs and backplane assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results.

[0001193125-14-404493:mdna:17]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the
manufacture and testing of our products as well as stock-based compensation expense. Many factors affect our gross margin, including capacity utilization, product mix, product quality issues, production volume, and yield. We generally do not
participate in any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for the raw materials we use.

[0001193125-14-404493:mdna:18]
[same as prior period, unchanged from 0001193125-14-295293:mdna:16]

[0001193125-14-404493:mdna:19]
[same as prior period, unchanged from 0001193125-14-295293:mdna:17]

[0001193125-14-404493:mdna:20]
[same as prior period, unchanged from 0001193125-14-295293:mdna:18]

[0001193125-14-404493:mdna:21]
[same as prior period, unchanged from 0001193125-14-295293:mdna:19]

[0001193125-14-404493:mdna:22]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in
our Annual Report on Form 10-K for the fiscal year ended December 30, 2013 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since
December 30, 2013.

[0001193125-14-404493:mdna:23]
Specific to our goodwill valuation policy, we will perform our annual
impairment test during our fourth fiscal quarter. Given the recent volatility of our market capitalization, it is reasonably possible that we could record an impairment charge by fiscal year end when we conduct our annual impairment test.

[0001193125-14-404493:mdna:24]
[same as prior period, unchanged from 0001193125-14-295293:mdna:21]

[0001193125-14-404493:mdna:25]
The following table sets forth the relationship of various items to net sales in our consolidated condensed statements of operations:

[0001193125-14-404493:mdna:26]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29,2014 |  |  | September 30,2013 |  |  | September 29,2014 |  |  | September 30,2013 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 85.8 |  |  |  | 85.7 |  |  |  | 86.5 |  |  |  | 85.3 |  |
| Gross profit |  |  | 14.2 |  |  |  | 14.3 |  |  |  | 13.5 |  |  |  | 14.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.6 |  |  |  | 2.6 |  |  |  | 2.9 |  |  |  | 2.7 |  |
| General and administrative |  |  | 7.5 |  |  |  | 7.2 |  |  |  | 7.6 |  |  |  | 7.7 |  |
| Amortization of definite-lived intangibles |  |  | 0.5 |  |  |  | 0.7 |  |  |  | 0.7 |  |  |  | 0.7 |  |
| Restructuring charges |  |  | — |  |  |  | 1.0 |  |  |  | — |  |  |  | 0.3 |  |
| Impairment of long-lived assets |  |  | — |  |  |  | 3.2 |  |  |  | 0.2 |  |  |  | 1.1 |  |
| Gain on sale of assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1.8 | ) |
| Total operating expenses |  |  | 10.6 |  |  |  | 14.7 |  |  |  | 11.4 |  |  |  | 10.7 |  |
| Operating income (loss) |  |  | 3.6 |  |  |  | (0.4 | ) |  |  | 2.1 |  |  |  | 4.0 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (1.7 | ) |  |  | (1.7 | ) |  |  | (1.9 | ) |  |  | (1.8 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other, net |  |  | 0.4 |  |  |  | 0.8 |  |  |  | (0.2 | ) |  |  | 0.4 |  |
| Total other expense, net |  |  | (1.3 | ) |  |  | (0.9 | ) |  |  | (2.1 | ) |  |  | (1.4 | ) |
| Income (loss) before income taxes |  |  | 2.3 |  |  |  | (1.3 | ) |  |  | — |  |  |  | 2.6 |  |
| Income tax (provision) benefit |  |  | (0.1 | ) |  |  | (1.0 | ) |  |  | 0.1 |  |  |  | (1.3 | ) |
| Net income (loss) |  |  | 2.2 |  |  |  | (2.3 | ) |  |  | 0.1 |  |  |  | 1.3 |  |
| Less: Net income attributable to noncontrolling interest |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.2 | ) |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  |  | 2.2 | % |  |  | (2.3 | )% |  |  | 0.1 | % |  |  | 1.1 | % |

[0001193125-14-404493:mdna:27]
[same as prior period, unchanged from 0001193125-14-295293:mdna:24]

[0001193125-14-404493:mdna:28]
23

[0001193125-14-404493:mdna:29]
The following table compares net sales by reportable segment for the quarter
and three quarters ended September 29, 2014 and September 30, 2013:

[0001193125-14-404493:mdna:30]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29,2014 |  |  | September 30,2013 |  |  | September 29,2014 |  |  | September 30,2013 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 214,727 |  |  | $ | 206,460 |  |  | $ | 547,092 |  |  | $ | 618,674 |  |
| North America |  |  | 131,054 |  |  |  | 132,608 |  |  |  | 389,237 |  |  |  | 385,866 |  |
| Total sales |  |  | 345,781 |  |  |  | 339,068 |  |  |  | 936,329 |  |  |  | 1,004,540 |  |
| Inter-segment sales |  |  | (506 | ) |  |  | (377 | ) |  |  | (1,524 | ) |  |  | (2,436 | ) |
| Total net sales |  | $ | 345,275 |  |  | $ | 338,691 |  |  | $ | 934,805 |  |  | $ | 1,002,104 |  |

[0001193125-14-404493:mdna:31]
[same as prior period, unchanged from 0001193125-14-295293:mdna:28]

[0001193125-14-404493:mdna:32]
Total net sales increased $6.6 million, or 1.9%, from $338.7 million for the third quarter of 2013 to $345.3 million for the third quarter of 2014. Net sales for the Asia Pacific segment, excluding
inter-segment sales, increased $8.1 million, or 3.9%, from $206.1 million in the third quarter of 2013 to $214.2 million in the third quarter of 2014. This increase was primarily due to higher demand in our Cellular Phone and
Networking/Communications end markets, partially offset by lower demand in our Computing/Storage/Peripherals end market. The change in our product mix resulted in a 13% increase in the average PCB selling price, partially offset by an 8% decrease in
PCB shipments from the third quarter of 2013. Net sales for the North America segment decreased $1.5 million, or 1.1%, from $132.6 million in the third quarter of 2013 to $131.1 million in the third quarter of 2014. This decrease was primarily due
to a 7% decrease in demand for PCB products in the Networking/Communications end market, partially offset by increased revenue for PCB products in the Medical/Industrial/Instrumentation end market.

[0001193125-14-404493:mdna:33]
Total net sales decreased $67.3 million, or 6.7%, from $1,002.1 million for the first three quarters of 2013 to $934.8
million for the first three quarters of 2014. Net sales for the Asia Pacific segment, excluding inter-segment sales, decreased $70.6 million, or 11.5%, from $616.2 million in the first three quarters of 2013 to $545.6 million in the first three
quarters of 2014. This decrease was primarily due to the absence of net sales resulting from the sale of a controlling equity interest in a subsidiary in the second quarter of 2013 combined with lower demand in our Computing/Storage/Peripherals and
Cellular Phone end markets, which resulted in a 20% decrease in PCB shipments from the first three quarters of 2013. This decrease in net sales was partially offset by an 11% increase in the average PCB selling price, which was driven by product mix
shift. Net sales for the North America segment increased $3.3 million, or 0.9%, from $385.9 million in the first three quarters of 2013 to $389.2 million in the first three quarters of 2014. This increase was primarily due to an increase in demand
for backplane assemblies and for PCB products in our Medical/Industrial/ Instrumentation end market.

[0001193125-14-404493:mdna:34]
[same as prior period, unchanged from 0001193125-14-295293:mdna:31]

[0001193125-14-404493:mdna:35]
Gross margin decreased from 14.3% for the third quarter of 2013 to 14.2% for the third quarter of 2014. Gross margin for
the Asia Pacific segment increased from 12.6% for the third quarter of 2013 to 13.6% for the third quarter of 2014, primarily due to higher production volumes at certain PCB fabrication plants and lower product warranty claims, partially offset by
higher production costs resulting from new product introductions, product mix changes, and a five day production shut down at one of our advanced technology facilities in China due to an unexpected power outage. Gross margin for the North America
segment decreased from 16.9% for the third quarter of 2013 to 15.2% for the third quarter of 2014, primarily due to a mix shift toward lower margin assembly products and lower cost absorption due to lower production volumes at certain PCB
fabrication plants.

[0001193125-14-404493:mdna:36]
Gross margin decreased from 14.7% for the first three quarters of 2013 to 13.5% for the
first three quarters of 2014. Gross margin for the Asia Pacific segment decreased from 13.5% for the first three quarters of 2013 to 12.5% for the first three quarters of 2014, primarily due to unfavorable product mix, lower utilization and
increased equipment-related expenses at our advanced technology plants in the first two quarters of 2014. Gross margin for the North America segment decreased from 16.6% for the first three quarters of 2013 to 14.9% for the first three quarters of
2014, primarily due to a mix shift toward lower margin assembly products and lower cost absorption due to lower production volumes at certain PCB fabrication plants.

[0001193125-14-404493:mdna:37]
[same as prior period, unchanged from 0001193125-14-295293:mdna:34]

[0001193125-14-404493:mdna:38]
Selling and marketing expenses increased by $0.1 million, or 1.1%, from $8.9 million for the third quarter of 2013 to $9.0
million for the third quarter of 2014. As a percentage of net sales, selling and marketing expenses remained consistent at 2.6% for each of the third quarters of 2013 and 2014. Selling and marketing expenses decreased $0.6 million, or 2.2%, from
$27.6 million for the first three quarters of 2013 to $27.0 million for the first three quarters of 2014. As a percentage of net sales, selling and marketing expenses were 2.7% and 2.9% for the first three quarters of 2013 and 2014, respectively.
The decrease in selling and marketing expenses for the first three quarters of 2014 was primarily due to reduced commissions and lower travel expenses over the comparable periods of the prior year. Additionally, the increase in selling and marketing
expense as a percentage of net sales for the first three quarters of 2014 was primarily due to lower net sales.

[0001193125-14-404493:mdna:39]
General and
Administrative Expense

[0001193125-14-404493:mdna:40]
General and administrative expenses increased $1.5 million from $24.3 million,
or 7.2% of net sales, for the third quarter of 2013 to $25.8 million, or 7.5% of net sales, for the third quarter of 2014. General and administrative expenses decreased $6.0 million from $77.0 million, or 7.7% of net sales, for the first three
quarters of 2013 to $71.0 million, or 7.6% of net sales, for the first three quarters of 2014. The increase in general and administrative expense for the third quarter of 2014 primarily related to costs of $1.6 million related to the proposed
acquisition of Viasystems. The decrease in general and administrative expense for the first three quarters ended 2014 is primarily due to costs savings resulting from the sale of our controlling equity interest in a subsidiary in the Asia Pacific
operating segment and lower incentive compensation expense, offset by the $1.6 million of acquisition-related costs recorded in the third quarter of 2014.

[0001193125-14-404493:mdna:41]
[same as prior period, unchanged from 0001193125-14-295293:mdna:38]

[0001193125-14-404493:mdna:42]
Other expense, net increased
$1.1 million from $3.2 million for the third quarter of 2013 to $4.3 million for the third quarter of 2014. The increase in other expense, net was primarily due to a decrease in currency transaction and derivative gains.

[0001193125-14-404493:mdna:43]
Other expense, net increased $6.5 million from $13.7 million for the first three quarters of 2013 to $20.2 million for
the first three quarters of 2014. The increase in other expense, net was primarily due to unrealized foreign currency transaction losses of $3.6 million due to the rapid depreciation of the Chinese RMB against the U.S. Dollar, and $0.5 million
loss on the extinguishment of debt related to repurchase of a portion of convertible senior notes due 2015, both in the first quarter of 2014.

[0001193125-14-404493:mdna:44]
[same as prior period, unchanged from 0001193125-14-295293:mdna:41]

[0001193125-14-404493:mdna:45]
The provision for income taxes decreased $3.0 million from $3.4 million for the third quarter of 2013 to $0.4 million for the third quarter of 2014. In 2013, income tax expense was higher primarily due to
the increase of valuation allowance of $3.3 million as a result of a new state law that significantly reduced the carryforward period of certain state tax credits. In addition, in the third quarter of 2014, we had a decrease in income tax expense
due to discrete benefits resulting from the research and development deduction at a Chinese subsidiary within our Asia Pacific operating segment.

[0001193125-14-404493:mdna:46]
The provision for income taxes decreased $14.5 million from an income tax expense of $13.5 million for the first three quarters of 2013 to an income tax benefit of $1.0 million for the first three
quarters of 2014. The decrease in our provision for income taxes was primarily due to losses incurred for the first three quarters of 2014 compared to income in the same period of the prior year, combined with (i) a $1.5 million discrete tax
benefit recorded in the first quarter of 2014 resulting from the retroactive approval of the high technology enterprise status for a subsidiary within the Asia Pacific operating segment, (ii) a $0.7 million discrete tax benefit recorded in the
third quarter of 2014 resulting from the research and development deduction at a Chinese subsidiary within the Asia Pacific operating segment, and (iii) a $0.4 million change in estimates resulting from completion of our 2013 federal income tax
return.

[0001193125-14-404493:mdna:47]
Our effective tax rate is primarily impacted by the U.S. federal income tax rate, apportioned state
income tax rates, tax rates in China and Hong Kong, generation of other credits and deductions available to us, and certain non-deductible items. Certain foreign losses generated are not more than likely to be realizable, and thus no income tax
benefit has been recognized on these losses. Additionally, as of September 29, 2014 and December 30, 2013, we had net deferred income tax assets of approximately $6.3 million and $5.4 million, respectively. Based on our forecast for future
taxable earnings, we believe it is more likely than not that we will utilize the deferred income tax assets in future periods.

[0001193125-14-404493:mdna:48]
Liquidity and Capital Resources

[0001193125-14-404493:mdna:49]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, and term and revolving debt. Our principal uses of cash have been to finance capital
expenditures, meet debt service requirements, fund working capital requirements, finance acquisitions, and refinance existing debt. We anticipate that financing acquisitions, servicing debt, financing capital expenditures, and funding working
capital requirements, will continue to be the principal demands on our cash in the future.

[0001193125-14-404493:mdna:50]
As of
September 29, 2014, we had net working capital of approximately $251.3 million compared to $347.0 million as of December 30, 2013.

[0001193125-14-404493:mdna:51]
25

[0001193125-14-404493:mdna:52]
As of September 29, 2014, we had cash and cash equivalents of
approximately $248.7 million, of which approximately $67.6 million was held by our foreign subsidiaries. Of the cash and cash equivalents held by our foreign subsidiaries as of September 29, 2014, $64.4 million was located in Asia and $3.2
million was located in Europe. Cash and cash equivalents located in our Asia Pacific operating segment are expected to be used in local operations. Cash and cash equivalents located in our backplane assembly facility in Shanghai, China, as well as
in Europe, which are managed in conjunction with our U.S. operations, totaled approximately $14.2 million and are available for repatriation and a deferred tax liability for U.S. income taxes on undistributed earnings has been recorded.

[0001193125-14-404493:mdna:53]
Our 2014 capital expenditure plan is expected to total approximately $100.0 million (of which approximately $80.0 million
relates to our Asia Pacific operating segment). The expenditures will fund capital equipment purchases to increase production capacity, especially for advanced technology manufacturing, comply with increased environmental regulations, replace aging
equipment, and expand our technological capabilities.

[0001193125-14-404493:mdna:54]
Based on our current level of operations, we believe
that cash generated from operations, cash on hand and cash available from borrowings under our existing credit arrangements will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next
12 months. However, we may enter into new borrowing arrangements, if needed, to fund acquisitions, fund our business operations, or refinance existing debt.

[0001193125-14-404493:mdna:55]
[same as prior period, unchanged from 0001193125-14-295293:mdna:51]

[0001193125-14-404493:mdna:56]
We are party to a facility agreement
(Credit Agreement) consisting of a $370.0 million senior secured Term Loan, a $90.0 million senior secured Revolving Loan and a secured $80.0 million Letters of Credit Facility. The Term Loan and Letters of Credit Facility will mature on
September 14, 2016, and the Revolving Loan will mature on March 14, 2016. The Credit Agreement is secured by substantially all of the assets of our Asia Pacific operating segment and is senior to all of our other debt, including the
convertible senior notes. We have fully and unconditionally guaranteed the full and timely payment of all Credit Agreement related obligations of the Asia Pacific operating segment.

[0001193125-14-404493:mdna:57]
Borrowings under the Credit Agreement bear interest at a floating rate of LIBOR plus an interest margin of 2.38%. At
September 29, 2014, the weighted average interest rate on the outstanding borrowings under the Credit Agreement was 2.53%.

[0001193125-14-404493:mdna:58]
Borrowings under the Credit Agreement are subject to certain financial and operating covenants that include maintaining maximum total leverage ratios and minimum net worth, current ratio, and interest
coverage ratios for both us and our Asia Pacific operating segment. In addition, our Credit Agreement includes a covenant that the Principal Shareholders (as defined in the Shareholders Agreement dated April 9, 2010 as amended on
September 14, 2012) will not reduce their shareholding below 15 percent of TTM’s issued shares. At September 29, 2014, we were in compliance with the covenants.

[0001193125-14-404493:mdna:59]
We are required to pay a commitment fee of 0.50% per annum on any unused portion of the loans and letters of credit
facility granted under the Credit Agreement. We incurred $0.2 million and $0.4 million for the quarter and three quarters ended September 29, 2014, respectively, in commitment fees. As of September 29, 2014, the outstanding amount of the
Term Loan was $273.8 million, of which $96.2 million is due for repayment through September 2015 and is included as short-term debt, with the remaining $177.6 million included as long-term debt. None of the Revolving Loan associated with the Credit
Agreement was outstanding at September 29, 2014. Available borrowing capacity under the Revolving Loan was $90.0 million as of September 29, 2014.

[0001193125-14-404493:mdna:60]
We have an $80.0 million Letters of Credit Facility under the Credit Agreement. As of September 29, 2014, letters of credit in the amount of $43.2 million were outstanding under our Credit Agreement,
and other standby letters of credit were outstanding in the amount of $3.9 million. The other outstanding standby letters of credit expire between December 31, 2014 and February 28, 2015.

[0001193125-14-404493:mdna:61]
We are party to a revolving loan credit facility with a lender in China. Under this arrangement, the lender has made
available to us approximately $47.3 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the revolver is drawn upon. There are no commitment fees on the unused portion of the revolver and this arrangement
expires in December 2014. As of September 29, 2014, the revolver had not been drawn upon.

[0001193125-14-404493:mdna:62]
Convertible
Senior Notes due 2020

[0001193125-14-404493:mdna:63]
On December 20, 2013, we issued 1.75% convertible senior notes due
December 15, 2020, in a public offering for an aggregate principal amount of $220.0 million. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and
December 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering
expenses are being amortized to interest expense over the term of the convertible senior notes.

[0001193125-14-404493:mdna:64]
In January 2014, we closed the sale of an additional $30.0 million aggregate
principal amount of our 1.75% convertible senior notes due 2020 (Additional Notes). The Additional Notes were sold pursuant to the exercise of an over-allotment option granted by us in the underwriting agreement related to the offer and sale of
$220.0 million aggregate principal amount of our 1.75% convertible senior notes due 2020. In connection with the offering of the Additional Notes, we entered into additional convertible note hedge transactions with respect to shares of our common
stock. The additional purchased call options cover up to approximately 3.1 million shares of common stock, at a strike price of $9.64 and will expire upon the maturity of the notes. Additionally, we also entered into additional warrant
transactions, whereby we sold warrants to acquire up to approximately 3.1 million shares of common stock at a strike price of $14.26, which will expire ratably from March 2021 through January 2022.

[0001193125-14-404493:mdna:65]
Convertible Senior Notes due 2015

[0001193125-14-404493:mdna:66]
In May 2008, we issued $175.0 million of convertible senior notes. The convertible senior notes bear interest at a
rate of 3.25% per annum. Interest is payable semiannually in arrears on May 15 and November 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness
and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the convertible senior notes.

[0001193125-14-404493:mdna:67]
Prior to December 30, 2013, we repurchased $136.1 million principal amount of notes. In January 2014, we repurchased
$6.5 million principal amount of notes at approximately 103.4% of their principal amount. This repurchase was also accounted for as an extinguishment of debt and, accordingly, we recognized a loss of approximately $0.5 million, primarily associated
with the premium paid to repurchase the convertible senior notes and the recognition of certain remaining unamortized debt discount and issuance costs. At September 29, 2014, $32.4 million of principal related to the convertible senior notes
due 2015 remain outstanding.

[0001193125-14-404493:mdna:68]
[same as prior period, unchanged from 0001193125-14-295293:mdna:64]

[0001193125-14-404493:mdna:69]
The following table provides information on our contractual obligations as of September 29, 2014:

[0001193125-14-404493:mdna:70]
|  |  | Total |  |  | Less Than1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After5 Years |  |
|  |  | (In thousands) |  |
| Contractual Obligations(1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term debt obligations |  | $ | 273,805 |  |  | $ | 96,205 |  |  | $ | 177,600 |  |  | $ | — |  |  | $ | — |  |
| Convertible debt obligations |  |  | 282,395 |  |  |  | 32,395 |  |  |  | — |  |  |  | — |  |  |  | 250,000 |  |
| Interest on debt obligations |  |  | 39,565 |  |  |  | 11,725 |  |  |  | 12,527 |  |  |  | 8,750 |  |  |  | 6,563 |  |
| Foreign currency forward contract liabilities |  |  | 2,868 |  |  |  | 2,868 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Equipment payables |  |  | 54,138 |  |  |  | 54,138 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 22,902 |  |  |  | 20,803 |  |  |  | 2,099 |  |  |  | — |  |  |  | — |  |
| Operating lease commitments |  |  | 6,402 |  |  |  | 2,520 |  |  |  | 2,574 |  |  |  | 1,171 |  |  |  | 137 |  |
| Total contractual obligations |  | $ | 682,075 |  |  | $ | 220,654 |  |  | $ | 194,800 |  |  | $ | 9,921 |  |  | $ | 256,700 |  |

[0001193125-14-404493:mdna:71]
| (1) | Unrecognized uncertain tax benefits of $2.5 million are not included in the table above as we have not determined when the amount will be paid. |

[0001193125-14-404493:mdna:72]
[same as prior period, unchanged from 0001193125-14-295293:mdna:68]

[0001193125-14-404493:mdna:73]
[same as prior period, unchanged from 0001193125-14-295293:mdna:69]

[0001193125-14-404493:mdna:74]
[same as prior period, unchanged from 0001193125-14-295293:mdna:70]

[0001193125-14-404493:mdna:75]
[same as prior period, unchanged from 0001193125-14-295293:mdna:71]

[0001193125-14-404493:mdna:76]
Recently Issued Accounting Standards

[0001193125-14-404493:mdna:77]
On May 28, 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. (ASU)
2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The ASU will replace most existing
revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us at the beginning of fiscal year 2017. Early application is not permitted. The standard permits the use of either the retrospective or
cumulative effect transition method. We are evaluating the effect that ASU 2014-09 will have on our consolidated financial statements and related disclosures. We have not yet selected a transition method nor have we determined the effect of the
standard on our ongoing financial reporting.

[0001193125-14-404493:mdna:78]
In July 2013, the FASB issued an update that would require an
unrecognized tax benefit, or a portion of an unrecognized benefit, to be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward. This
update is effective for interim and annual periods beginning after December 15, 2013, with early adoption permitted. We adopted the amendment on January 1, 2014, and our adoption did not have a material impact on our financial statements.
