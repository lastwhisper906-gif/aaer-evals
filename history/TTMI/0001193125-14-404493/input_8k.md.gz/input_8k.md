# TTMI 8-K — 0001171843-14-005051 filed 2014-10-29

## item codes, every 8-K on or before 2014-11-10

- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2014-11-10

- none on or before 2014-11-10

## item 2.02 — earnings release, exhibit 99.1

[0001171843-14-005051:8k_2_02:1]
EX-99
2
newsrelease.htm
PRESS RELEASE

[0001171843-14-005051:8k_2_02:2]
TTM Technologies, Inc. Reports Third Quarter 2014 Results
EXHIBIT 99.1

[0001171843-14-005051:8k_2_02:3]
TTM Technologies, Inc. Reports Third Quarter 2014 Results

[0001171843-14-005051:8k_2_02:4]
COSTA MESA, Calif., Oct. 29, 2014 (GLOBE NEWSWIRE) -- TTM Technologies, Inc. (Nasdaq:TTMI), a major global printed circuit board (PCB) manufacturer, today reported results for the third quarter 2014, which ended September 29, 2014.

[0001171843-14-005051:8k_2_02:5]
Third Quarter 2014 Highlights

[0001171843-14-005051:8k_2_02:6]
- Net sales were $345.3 million

[0001171843-14-005051:8k_2_02:7]
- GAAP net income was $7.7 million, or $0.09 per diluted share

[0001171843-14-005051:8k_2_02:8]
- Non-GAAP net income was $11.0 million, or $0.13 per diluted share

[0001171843-14-005051:8k_2_02:9]
- Announced agreement to acquire Viasystems Group, Inc.

[0001171843-14-005051:8k_2_02:10]
Third Quarter 2014 Financial Results

[0001171843-14-005051:8k_2_02:11]
Net sales for the third quarter of 2014 were $345.3 million compared to $297.6 million in the second quarter of 2014 and $338.7 million in the third quarter of 2013.

[0001171843-14-005051:8k_2_02:12]
GAAP operating income for the third quarter of 2014 was $12.3 million compared to operating income of $3.2 million in the second quarter of 2014 and an operating loss of $1.2 million in the third quarter of 2013.

[0001171843-14-005051:8k_2_02:13]
GAAP net income for the third quarter of 2014 was $7.7 million, or $0.09 per diluted share. This compares to a GAAP net loss of $3.1 million, or $0.04 per share, in the second quarter of 2014 and GAAP net loss of $7.7 million, or $0.09 per share, in the third quarter of 2013.

[0001171843-14-005051:8k_2_02:14]
On a non-GAAP basis, net income for the third quarter of 2014 was $11.0 million, or $0.13 per diluted share. This compares to non-GAAP net income of $3.9 million, or $0.05 per diluted share, for the second quarter of 2014 and $11.6 million, or $0.14 per diluted share, for the third quarter of 2013.

[0001171843-14-005051:8k_2_02:15]
Adjusted EBITDA for the third quarter of 2014 was $43.6 million, or 12.6 percent of net sales, compared to adjusted EBITDA of $32.8 million, or 11.0 percent of net sales, for the second quarter of 2014 and $42.3 million, or 12.5 percent of net sales, for the third quarter of 2013.

[0001171843-14-005051:8k_2_02:16]
"As expected, we grew revenue and operating income on a sequential basis in the third quarter. We experienced solid demand across all of our end markets, led by a strong revenue ramp in cellular phones and better than expected sales in our networking/communications end market," said Tom Edman, CEO of TTM. "Our operating margins, however, fell short of goal due primarily to an unanticipated five day power outage at our advanced technology facility in Asia Pacific which interrupted our ramp for new products and contributed to our yield shortfall early in the quarter. By the end of the quarter, our productivity and yield levels were back on plan. We anticipate continued improvement in yields and operating performance in the fourth quarter."

[0001171843-14-005051:8k_2_02:17]
Mr. Edman continued, "On September 22nd, we announced a definitive agreement to acquire Viasystems. We expect the combination will create an industry leader with a broad global footprint and expanded capabilities to serve more customers and end markets. It also accelerates our strategy to diversify our business and reduce the impact of seasonality inherent in the cellular phone end market. The acquisition is expected to close in the first half of 2015, and I'm pleased with the positive feedback that we have received from both customers and employees."

[0001171843-14-005051:8k_2_02:18]
Business Outlook

[0001171843-14-005051:8k_2_02:19]
For the fourth quarter of 2014, TTM estimates that revenue will be in the range of $370 million to $390 million, and non-GAAP net income in the range of $0.22 to $0.28 per diluted share.

[0001171843-14-005051:8k_2_02:20]
The Acquisition of Viasystems

[0001171843-14-005051:8k_2_02:21]
As previously announced, on September 22, 2014, TTM announced the execution of a definitive agreement under which TTM will acquire all outstanding shares of Viasystems for a combined consideration of $11.33 in cash and 0.706 shares of TTM common stock per Viasystems' share. The parties currently expect to close the transaction in the first half of 2015. The transaction is subject to customary closing conditions, including regulatory approvals and approval by the shareholders of Viasystems.

[0001171843-14-005051:8k_2_02:22]
TTM has received a fully-underwritten financing commitment from J.P. Morgan, Barclays and RBS to finance the transaction. TTM expects to utilize a new $1.1 billion senior secured credit facility to finance the cash portion of the purchase price, refinance certain debt at each company, and pay for costs associated with the transaction.

[0001171843-14-005051:8k_2_02:23]
To Access the Live Webcast/Conference Call

[0001171843-14-005051:8k_2_02:24]
TTM will host a conference call and webcast to discuss third quarter 2014 results and fourth quarter 2014 outlook on Wednesday, October 29, 2014, at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call may include forward-looking statements.

[0001171843-14-005051:8k_2_02:25]
Telephone access is available by dialing domestic 1-888-417-8533 or international 1-719-325-2308 (ID 5369065). The conference call also will be webcast on TTM's website at www.ttmtech.com.

[0001171843-14-005051:8k_2_02:26]
To Access a Replay of the Webcast

[0001171843-14-005051:8k_2_02:27]
The replay of the webcast will remain accessible for one week following the live event on TTM's website at www.ttmtech.com.

[0001171843-14-005051:8k_2_02:28]
About TTM

[0001171843-14-005051:8k_2_02:29]
TTM Technologies, Inc. is a major global PCB manufacturer, focusing on quick-turn and technologically advanced PCBs and the backplane and sub-system assembly business. TTM stands for time-to-market, representing how TTM's time-critical, one-stop manufacturing services enable customers to shorten the time required to develop new products and bring them to market. Additional information can be found at www.ttmtech.com.

[0001171843-14-005051:8k_2_02:30]
Forward-Looking Statements

[0001171843-14-005051:8k_2_02:31]
This release contains forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These statements reflect TTM's current expectations, and TTM does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond TTM's control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, general market and economic conditions, including interest rates, currency exchange rates and consumer spending, the ability of TTM and Viasystems to consummate the proposed merger and realize anticipated synergies, demand for TTM's products, market pressures on prices of TTM's products, warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements, TTM's dependence upon a small number of customers and other "Risk Factors" set forth in TTM's most recent SEC filings.

[0001171843-14-005051:8k_2_02:32]
No Offer or Solicitation

[0001171843-14-005051:8k_2_02:33]
The information in this communication is for informational purposes only and is neither an offer to purchase, nor a solicitation of an offer to sell, subscribe for or buy any securities or the solicitation of any vote in any jurisdiction pursuant to the proposed transactions or otherwise, nor shall there be any sale, issuance or transfer of securities in any jurisdiction in contravention of applicable law. No offer of securities shall be made except by means of a prospectus meeting the requirements of Section 10 of the Securities Act of 1933, as amended.

[0001171843-14-005051:8k_2_02:34]
Additional Information and Where to Find It

[0001171843-14-005051:8k_2_02:35]
This communication may be deemed to be solicitation material in respect of the proposed merger between TTM and Viasystems (the "proposed merger"). TTM has filed with the SEC a registration statement on Form S-4, which includes a prospectus with respect to TTM's shares of common stock to be issued in the proposed merger and a proxy statement of Viasystems in connection with the proposed merger (the "Proxy Statement/Prospectus"). The Proxy Statement/Prospectus will be sent or given to Viasystems' stockholders when the Proxy Statement/Prospectus is declared effective by the SEC, and it will contain important information about the proposed merger and related matters. VIASYSTEMS SECURITY HOLDERS ARE ADVISED TO READ THE PROXY STATEMENT/PROSPECTUS CAREFULLY BECAUSE IT CONTAINS IMPORTANT INFORMATION ABOUT THE PROPOSED MERGER. The Proxy Statement/Prospectus and other relevant materials (when they become available) and any other documents filed by TTM or Viasystems with the SEC may be obtained free of charge at the SEC's website at www.sec.gov. In addition, security holders will be able to obtain free copies of the Proxy Statement/Prospectus from TTM or Viasystems by contacting either (1) Investor Relations by mail at TTM Technologies, Inc., 1665 Scenic Avenue, Suite 250, Costa Mesa, CA 92626, Attn: Investor Relations Department, by telephone at 714-327-3000, or by going to TTM's Investor Relations page on its corporate website at www.ttmtech.com or (2) Investor Relations by mail at Viasystems Group, Inc., 101 South Hanley Road, Suite 1800, St. Louis, MO 63105, Attn: Investor Relations Department, by telephone at 314-727-2087, or by going to Viasystems' Investor Info page on its corporate website at www.viasystems.com.

[0001171843-14-005051:8k_2_02:36]
Participants in the Solicitation

[0001171843-14-005051:8k_2_02:37]
TTM and Viasystems and their respective directors and executive officers may be deemed to be participants in the solicitation of proxies from Viasystems' stockholders in connection with the proposed merger and may have direct or indirect interests in the proposed merger. Information about TTM's directors and executive officers is set forth in TTM's Proxy Statement on Schedule 14A for its 2014 Annual Meeting of Stockholders, which was filed with the SEC on March 14, 2014, and its Annual Report on Form 10-K for the fiscal year ended December 30, 2013, which was filed with the SEC on February 21, 2014. These documents are available free of charge at the SEC's website at www.sec.gov, and from TTM by contacting Investor Relations by mail at TTM Technologies, Inc., 1665 Scenic Avenue, Suite 250, Costa Mesa, CA 92626, Attn: Investor Relations Department, by telephone at 714-327-3000, or by going to TTM's Investor Relations page on its corporate website at www.ttmtech.com. Information about Viasystems' directors and executive officers is set forth in Viasystems' Proxy Statement on Schedule 14A for its 2014 Annual Meeting of Stockholders, which was filed with the SEC on March 14, 2014, and its Annual Report on Form 10-K for the fiscal year ended December 31, 2013, which was filed with the SEC on February 14, 2014. These documents are available free of charge at the SEC's website at www.sec.gov, and from Viasystems by contacting Investor Relations by mail at Viasystems Group, Inc., 101 South Hanley Road, Suite 1800, St. Louis, MO 63105, Attn: Investor Relations Department, by telephone at 314-727-2087, or by going to Viasystems' Investor Info page on its corporate website at www.viasystems.com. Additional information regarding the interests of participants in the solicitation of proxies in connection with the proposed merger is included in the Proxy Statement/Prospectus that TTM filed with the SEC.

[0001171843-14-005051:8k_2_02:38]
About Our Non-GAAP Financial Measures

[0001171843-14-005051:8k_2_02:39]
This release includes information about TTM's adjusted EBITDA, non-GAAP net income attributable to stockholders and non-GAAP earnings per share attributable to stockholders, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable investors to see TTM through the eyes of management and to provide better insight into TTM's ongoing financial performance.

[0001171843-14-005051:8k_2_02:40]
Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, asset impairments, restructuring, costs related to acquisitions, and other charges. Management believes that the non-GAAP financial information – which adds back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt, acquisition-related costs, asset impairments, restructuring and other unusual or infrequent items as well as the associated tax impact of these charges and discrete tax items – provides additional useful information to investors regarding TTM's ongoing financial condition and results of operations.

[0001171843-14-005051:8k_2_02:41]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar non-GAAP financial measures used by other companies. TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliation to the most directly comparable GAAP financial measure. However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001171843-14-005051:8k_2_02:42]
| TTM TECHNOLOGIES, INC. |
| Selected Unaudited Financial Information |
| (In thousands, except per share data) |
|  | Third Quarter | Second Quarter | First Three Quarters |
|  | 2014 | 2013 | 2014 | 2014 | 2013 |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |
| Net sales | $ 345,275 | $ 338,691 | $ 297,635 | $ 934,805 | $ 1,002,104 |
| Cost of goods sold | 296,167 | 290,252 | 259,035 | 808,591 | 854,478 |
| Gross profit | 49,108 | 48,439 | 38,600 | 126,214 | 147,626 |
| Operating expenses: |  |  |  |  |  |
| Selling and marketing | 9,033 | 8,865 | 8,637 | 26,993 | 27,614 |
| General and administrative | 25,733 | 24,293 | 22,647 | 70,898 | 76,992 |
| Amortization of definite-lived intangibles | 1,980 | 2,329 | 2,236 | 6,452 | 6,984 |
| Restructuring charges | 49 | 3,357 | 37 | 62 | 3,357 |
| Impairment of long-lived assets | -- | 10,782 | 1,845 | 1,845 | 10,782 |
| Gain on sale of assets | -- | -- | -- | -- | (17,917) |
| Total operating expenses | 36,795 | 49,626 | 35,402 | 106,250 | 107,812 |
| Operating income (loss) | 12,313 | (1,187) | 3,198 | 19,964 | 39,814 |
| Interest expense | (6,018) | (5,848) | (5,915) | (18,139) | (18,049) |
| Loss on extinguishment of debt | -- | -- | -- | (506) | -- |
| Other, net | 1,742 | 2,692 | 121 | (1,532) | 4,326 |
| Income (loss) before income taxes | 8,037 | (4,343) | (2,596) | (213) | 26,091 |
| Income tax (provision) benefit | (379) | (3,365) | (508) | 968 | (13,494) |
| Net income (loss) | 7,658 | (7,708) | (3,104) | 755 | 12,597 |
| Net income attributable to noncontrolling interest | -- | -- | -- | -- | (2,016) |
| Net income (loss) attributable to stockholders | $ 7,658 | $ (7,708) | $ (3,104) | $ 755 | $ 10,581 |
| Earnings (loss) per share attributable to stockholders: |  |  |  |  |  |
| Basic | $ 0.09 | $ (0.09) | $ (0.04) | $ 0.01 | $ 0.13 |
| Diluted | $ 0.09 | $ (0.09) | $ (0.04) | $ 0.01 | $ 0.13 |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |
| Basic | 83,345 | 82,630 | 83,336 | 83,202 | 82,458 |
| Diluted | 84,039 | 82,630 | 83,336 | 83,853 | 83,025 |
| SELECTED BALANCE SHEET DATA |  |  |  |  |  |
|  | September 29, 2014 | December 30, 2013 |  |  |  |
| Cash and cash equivalents | $ 248,708 | $ 330,554 |  |  |  |
| Accounts and notes receivable, net | 270,295 | 277,070 |  |  |  |
| Inventories | 151,638 | 138,145 |  |  |  |
| Total current assets | 718,081 | 804,991 |  |  |  |
| Property, plant and equipment, net | 793,680 | 810,672 |  |  |  |
| Other non-current assets | 49,642 | 57,912 |  |  |  |
| Total assets | 1,561,403 | 1,673,575 |  |  |  |
| Short-term debt, including current portion long-term debt | $ 127,686 | $ 96,204 |  |  |  |
| Accounts payable | 182,038 | 192,357 |  |  |  |
| Total current liabilities | 466,747 | 458,003 |  |  |  |
| Debt, net of discount | 372,834 | 477,539 |  |  |  |
| Total long-term liabilities | 384,746 | 510,277 |  |  |  |
| Total stockholders' equity | 709,910 | 705,295 |  |  |  |
| Total liabilities and stockholders' equity | 1,561,403 | 1,673,575 |  |  |  |

[0001171843-14-005051:8k_2_02:43]
| SUPPLEMENTAL DATA |  |  |  |  |  |
|  | Third Quarter | Second Quarter | First Three Quarters |
|  | 2014 | 2013 | 2014 | 2014 | 2013 |
| Gross margin | 14.2% | 14.3% | 13.0% | 13.5% | 14.7% |
| Operating margin | 3.6% | (0.4)% | 1.1% | 2.1% | 4.0% |
| End Market Breakdown: |  |  |  |  |  |
|  | Third Quarter | Second Quarter |  |  |
|  | 2014 | 2013 | 2014 |  |  |
| Aerospace/Defense | 15% | 16% | 18% |  |  |
| Cellular Phone | 25% | 21% | 12% |  |  |
| Computing/Storage/Peripherals | 13% | 19% | 14% |  |  |
| Medical/Industrial/Instrumentation | 9% | 9% | 11% |  |  |
| Networking/Communications | 32% | 30% | 40% |  |  |
| Other | 6% | 5% | 5% |  |  |
| Stock-based Compensation: |  |  |  |  |  |
|  | Third Quarter | Second Quarter |  |  |
|  | 2014 | 2013 | 2014 |  |  |
| Amount included in: |  |  |  |  |  |
| Cost of goods sold | $ 207 | $ 252 | $ 199 |  |  |
| Selling and marketing | 257 | 304 | 253 |  |  |
| General and administrative | 1,490 | 1,275 | 1,479 |  |  |
| Total stock-based compensation expense | $ 1,954 | $ 1,831 | $ 1,931 |  |  |
| Operating Segment Data: |  |  |  |  |  |
|  | Third Quarter | Second Quarter |  |  |
| Net sales: | 2014 | 2013 | 2014 |  |  |
| Asia Pacific | $ 214,727 | $ 206,460 | $ 166,699 |  |  |
| North America | 131,054 | 132,608 | 131,594 |  |  |
| Total sales | 345,781 | 339,068 | 298,293 |  |  |
| Inter-segment sales | (506) | (377) | (658) |  |  |
| Total net sales | $ 345,275 | $ 338,691 | $ 297,635 |  |  |
| Operating segment income: |  |  |  |  |  |
| Asia Pacific | $ 10,034 | $ (7,313) | $ (1,925) |  |  |
| North America | 4,259 | 8,455 | 7,359 |  |  |
| Total operating segment income | 14,293 | 1,142 | 5,434 |  |  |
| Amortization of definite-lived intangibles | (1,980) | (2,329) | (2,236) |  |  |
| Total operating income (loss) | 12,313 | (1,187) | 3,198 |  |  |
| Total other expense | (4,276) | (3,156) | (5,794) |  |  |
| Income (loss) before income taxes | $ 8,037 | $ (4,343) | $ (2,596) |  |  |

[0001171843-14-005051:8k_2_02:44]
| RECONCILIATIONS1 |  |  |  |  |  |
|  | Third Quarter | Second Quarter | First Three Quarters |  |  |
|  | 2014 | 2013 | 2014 | 2014 | 2013 |
| Non-GAAP gross profit reconciliation2: |  |  |  |  |  |
| GAAP gross profit | $ 49,108 | $ 48,439 | $ 38,600 | $ 126,214 | $ 147,626 |
| Add back item: |  |  |  |  |  |
| Stock-based compensation | 207 | 252 | 199 | 669 | 809 |
| Non-GAAP gross profit | $ 49,315 | $ 48,691 | $ 38,799 | $ 126,883 | $ 148,435 |
| Non-GAAP gross margin | 14.3% | 14.4% | 13.0% | 13.6% | 14.8% |
| Non-GAAP operating income reconciliation3: |  |  |  |  |  |
| GAAP operating income (loss) | $ 12,313 | $ (1,187) | $ 3,198 | $ 19,964 | $ 39,814 |
| Add back items: |  |  |  |  |  |
| Amortization of definite-lived intangibles | 1,980 | 2,329 | 2,236 | 6,452 | 6,984 |
| Stock-based compensation | 1,954 | 1,831 | 1,931 | 6,053 | 6,744 |
| Gain on sale of assets | -- | -- | -- | -- | (17,917) |
| Acquisition-related costs | 1,632 | -- | -- | 1,632 | -- |
| Impairments and restructuring charges | 49 | 14,139 | 1,882 | 1,907 | 14,139 |
| Non-GAAP operating income | $ 17,928 | $ 17,112 | $ 9,247 | $ 36,008 | $ 49,764 |
| Non-GAAP operating margin | 5.2% | 5.1% | 3.1% | 3.9% | 5.0% |
| Non-GAAP net income and EPS attributable to stockholders reconciliation4: |  |  |  |  |
| GAAP net income (loss) attributable to stockholders | $ 7,658 | $ (7,708) | $ (3,104) | $ 755 | $ 10,581 |
| Add back items: |  |  |  |  |  |
| Amortization of definite-lived intangibles | 1,980 | 2,329 | 2,236 | 6,452 | 6,984 |
| Stock-based compensation | 1,954 | 1,831 | 1,931 | 6,053 | 6,744 |
| Non-cash interest expense | 2,548 | 2,134 | 2,509 | 7,580 | 6,283 |
| Gain on sale of assets | -- | -- | -- | -- | (17,917) |
| Acquisition-related costs | 1,632 | -- | -- | 1,632 | -- |
| Impairments, restructuring and other charges | 49 | 14,139 | 1,882 | 2,413 | 14,139 |
| Income taxes | (4,810) | (1,080) | (1,587) | (8,789) | 2,320 |
| Non-GAAP net income attributable to stockholders | $ 11,011 | $ 11,645 | $ 3,867 | $ 16,096 | $ 29,134 |
| Non-GAAP earnings per diluted share attributable to stockholders | $ 0.13 | $ 0.14 | $ 0.05 | $ 0.19 | $ 0.35 |
| Adjusted EBITDA reconciliation5: |  |  |  |  |  |
| GAAP net income (loss) | $ 7,658 | $ (7,708) | $ (3,104) | $ 755 | $ 12,597 |
| Add back items: |  |  |  |  |  |
| Income tax provision | 379 | 3,365 | 508 | (968) | 13,494 |
| Interest expense | 6,018 | 5,848 | 5,915 | 18,139 | 18,049 |
| Amortization of definite-lived intangibles | 1,980 | 2,329 | 2,236 | 6,452 | 6,984 |
| Depreciation expense | 23,887 | 22,527 | 23,437 | 71,031 | 68,782 |
| Stock-based compensation | 1,954 | 1,831 | 1,931 | 6,053 | 6,744 |
| Gain on sale of assets | -- | -- | -- | -- | (17,917) |
| Acquisition-related costs | 1,632 | -- | -- | 1,632 | -- |
| Impairments, restructuring and other charges | 49 | 14,139 | 1,882 | 2,413 | 14,139 |
| Adjusted EBITDA | $ 43,557 | $ 42,331 | $ 32,805 | $ 105,507 | $ 122,872 |
| Adjusted EBITDA margin | 12.6% | 12.5% | 11.0% | 11.3% | 12.3% |
| 1 This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income attributable to stockholders, non-GAAP EPS attributable to stockholders, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |
| 2 Non-GAAP gross profit and gross margin measures exclude stock-based compensation expense. |
| 3 Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, acquisition-related costs and restructuring and impairment charges. |
| 4 This information provides non-GAAP net income attributable to stockholders and non-GAAP EPS attributable to stockholders, which are non-GAAP financial measures. Management believes that both measures --- which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, acquisition-related costs, asset impairments, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items --- provide additional useful information to investors regarding the Company's ongoing financial condition and results of operations. |
| 5 Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, acquisition-related costs, asset impairments, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |

[0001171843-14-005051:8k_2_02:45]
CONTACT: Todd Schull, CFO
         714-327-3000
