# TTMI notes — 0001193125-14-404493


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-404493:notes:1]
(12) Commitments and
 Contingencies

[0001193125-14-404493:notes:2]
Legal
 Matters

[0001193125-14-404493:notes:3]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible or probable
 loss for known matters would not be material to the Company’s
 financial condition, the outcome of these actions is inherently
 difficult to predict. In the event of an adverse outcome, the
 ultimate potential loss could have a material adverse effect on the
 Company’s financial condition or results of operations in a
 particular period. The Company has accrued amounts for its loss
 contingencies which are probable and estimable at
 September 29, 2014 and December 30, 2013. However, these
 amounts are not material to the consolidated condensed financial
 statements of the Company.

[0001193125-14-404493:notes:4]
Class Action Complaints
 related to Viasystems Acquisition

[0001193125-14-404493:notes:5]
Since
 the public announcement on September 22, 2014 of the execution
 of the Merger Agreement, Viasystems, TTM, Merger Sub, and the
 members of the Viasystems Board have been named as defendants in
 two putative class action complaints challenging the Merger. The
 first lawsuit, filed in the Circuit Court of St. Louis County,
 Missouri on September 30, 2014 (the Missouri Lawsuit), and the
 second lawsuit, filed in the Court of Chancery of the State of
 Delaware on October 13, 2014 (the Delaware Lawsuit and,
 together with the Missouri Lawsuit, the Lawsuits), generally allege
 that the Merger fails to properly value Viasystems, that the
 individual defendants breached their fiduciary duties in approving
 the Merger Agreement, and that those breaches were aided and
 abetted by TTM, Merger Sub, and Viasystems.

[0001193125-14-404493:notes:6]
The
 Delaware Lawsuit specifically alleges, among other allegations,
 that (1) the Viasystems Board breached its fiduciary duties
 by: (a) agreeing to the Merger for grossly inadequate
 consideration, (b) agreeing to lock up the Merger with deal
 protection devices that prevent other bidders from making a
 successful competing offer for Viasystems, and
 (c) participating in a transaction where the loyalties of the
 Viasystems Board and management are divided; (2) the voting
 agreements entered into between the Company and certain of
 Viasystems’ significant stockholders prevent Viasystems
 stockholders from providing a meaningful vote on the proposal to
 adopt the Merger; and (3) that those breaches of fiduciary
 duties were aided and abetted by TTM, Merger Sub, and Viasystems.
 Further, the Missouri Lawsuit specifically alleges, among other
 allegations, that (1) the proposed Merger is unfair and the
 consideration to be paid in connection with the Merger is
 inadequate; (2) the Viasystems Board and Viasystems’
 management have a conflict of interest due to the cash pool bonus
 and change in control payments to be made to certain executive
 officers and key employees if the Merger is consummated; and
 (3) the Merger Agreement contains impermissible deal
 protection devices.

[0001193125-14-404493:notes:7]
The
 Lawsuits seek injunctive relief to enjoin the defendants from
 completing the Merger on the agreed-upon terms, rescinding, to the
 extent already implemented, the Merger Agreement or any of the
 terms therein, costs and disbursements and attorneys’ and
 experts’ fees and costs, as well as other equitable relief as
 the respective court deems proper. The Delaware Lawsuit also seeks:
 (1) in the event the Merger is consummated prior to the entry
 of the court’s final judgment, rescissory damages as an
 alternative to rescission, and (2) an accounting by all
 defendants to the plaintiff and other members of the class for all
 damages caused by the defendants and for all profits and any
 special benefits obtained as a result of their alleged breaches of
 their fiduciary duties. TTM believes the Lawsuits are without
 merit.

[0001193125-14-404493:notes:8]
Environmental
 Matters

[0001193125-14-404493:notes:9]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States comply in all material respects
 with applicable environmental laws and regulations. In China,
 governmental authorities have adopted new rules and regulations
 governing environmental issues. An update to Chinese
 environmental water waste law was issued in late 2012, but allows
 for an interim period in which plants subject to such law may
 install equipment that meets the new regulatory regime and come
 into full compliance with the new laws in 2014 and 2015, depending
 on the province of China in which such plant is located. The
 Company’s plants in China are not yet in full compliance with
 the newly adopted environmental regulations as updated in late
 2012. The Company expects to come into compliance and does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan, which includes capital expenditures
 estimated to be approximately $15, 000 through 2015, to address the
 regulatory changes in order to come into full compliance during the
 interim period.


## us-gaap:EarningsPerShareTextBlock

[0001193125-14-404493:notes:10]
(13) Earnings Per
 Share

[0001193125-14-404493:notes:11]
The following is a reconciliation of the numerator and
 denominator used to calculate basic earnings per share and diluted
 earnings per share for the quarter and three quarters ended
 September 29, 2014 and September 30, 2013:

[0001193125-14-404493:notes:12]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2014 |  |  | September 30, 2013 |  |  | September 29, 2014 |  |  | September 30, 2013 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  | $ | 7,658 |  |  | $ | (7,708 | ) |  | $ | 755 |  |  | $ | 10,581 |  |
| Weighted average shares outstanding |  |  | 83,345 |  |  |  | 82,630 |  |  |  | 83,202 |  |  |  | 82,458 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 694 |  |  |  | — |  |  |  | 651 |  |  |  | 567 |  |
| Diluted shares |  |  | 84,039 |  |  |  | 82,630 |  |  |  | 83,853 |  |  |  | 83,025 |  |
| Earnings (loss) per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.09 |  |  | $ | (0.09 | ) |  | $ | 0.01 |  |  | $ | 0.13 |  |
| Diluted |  | $ | 0.09 |  |  | $ | (0.09 | ) |  | $ | 0.01 |  |  | $ | 0.13 |  |

[0001193125-14-404493:notes:13]
For the quarter and three quarters ended September 29,
 2014 and for the three quarters ended September 30, 2013,
 performance-based restricted stock units, restricted stock units
 and stock options to purchase 1,263, 1,230 and 1,987 shares of
 common stock, respectively, were not considered in calculating
 diluted earnings per share because the options’ exercise
 prices or the total expected proceeds under the treasury stock
 method for performance-based restricted stock units, restricted
 stock units or stock options was greater than the average market
 price of common shares during the period and, therefore, the effect
 would be anti-dilutive.

[0001193125-14-404493:notes:14]
For the quarter ended September 30, 2013, potential shares
 of common stock, consisting of stock options to purchase
 approximately 954 shares of common stock at exercise prices ranging
 from $5.78 to $16.82 per share, 1,551 restricted stock units, and
 118 performance-based restricted stock units were not included in
 the computation of diluted earnings per share because the Company
 incurred a net loss from operations and, as a result, the impact
 would be anti-dilutive.

[0001193125-14-404493:notes:15]
For the quarter and three quarters ended September 29,
 2014, the effect of 27,970 shares of common stock, related to the
 Company’s convertible senior notes and warrants to purchase
 28,020 shares of common stock were not included in the computation
 of dilutive earnings per share because the effect would be
 anti-dilutive under the treasury stock method. For the quarter and
 three quarters ended September 30, 2013, the effect of 10,963
 shares of common stock, related to the Company’s convertible
 senior notes and warrants to purchase 10,963 shares of common stock
 were not included in the computation of dilutive earnings per share
 because the effect would be anti-dilutive under the treasury stock
 method.


## us-gaap:ScheduleOfDerivativeInstrumentsTextBlock

[0001193125-14-404493:notes:16]
The fair values of derivative instruments in the consolidated
 condensed balance sheet are as follows:

[0001193125-14-404493:notes:17]
|  |  |  |  | Asset / (Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | September 29, 2014 |  |  | December 30, 2013 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |
| Foreign exchange contracts |  | Other accrued expenses |  | $ | (62 | ) |  | $ | (751 | ) |
| Foreign exchange contracts |  | Deposits and other non-current assets |  |  | — |  |  |  | 10 |  |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | — |  |  |  | 647 |  |
| Foreign exchange contracts |  | Other accrued expenses |  |  | (2,806 | ) |  |  | (899 | ) |
| Foreign exchange contracts |  | Other long-term liabilities |  |  | — |  |  |  | (1,288 | ) |
|  |  |  |  | $ | (2,868 | ) |  | $ | (2,281 | ) |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-14-404493:notes:18]
At September 29, 2014 and December 30, 2013, the
 following financial assets and liabilities were measured at fair
 value on a recurring basis using the type of inputs
 shown:

[0001193125-14-404493:notes:19]
|  |  | September 29, 2014 |  |  | Fair Value Measurements Using: |  |
|  |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Money market funds |  | $ | 129,012 |  |  | $ | 129,012 |  |  | $ | — |  |  |  | — |  |
| Foreign exchange derivative liabilities |  |  | 2,868 |  |  |  | — |  |  |  | 2,868 |  |  |  | — |  |
|  |  | December 30, 2013 |  |  | Fair Value Measurements Using: |  |
|  |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Money market funds |  | $ | 23,838 |  |  | $ | 23,838 |  |  | $ | — |  |  |  | — |  |
| Available for sale securities |  |  | 148 |  |  |  | 148 |  |  |  | — |  |  |  | — |  |
| Foreign exchange derivative assets |  |  | 657 |  |  |  | — |  |  |  | 657 |  |  |  | — |  |
| Foreign exchange derivative liabilities |  |  | 2,938 |  |  |  | — |  |  |  | 2,938 |  |  |  | — |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001193125-14-404493:notes:20]
For the three quarters ended September 29, 2014 and
 September 30, 2013, the following assumptions were used in
 determining the fair value:

[0001193125-14-404493:notes:21]
|  |  | September 29, 20141 |  |  | September 30, 20132 |  |
| Weighted-average fair value |  | $ | 5.80 |  |  | $ | 6.79 |  |
| Risk-free interest rate |  |  | 0.4 | % |  |  | 0.3 | % |
| Dividend yield |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 41 | % |  |  | 49 | % |
| Expected term in months |  |  | 23 |  |  |  | 25 |  |

[0001193125-14-404493:notes:22]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2012, the second year of the three-year performance period applicable to PRUs granted in 2013 and the first year of the three-year performance period applicable to PRUs granted in 2014. |

[0001193125-14-404493:notes:23]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2011, the second year of the three-year performance period applicable to PRUs granted in 2012 and the first year of the three-year performance period applicable to PRUs granted in 2013. |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-14-404493:notes:24]
(10) Significant
 Customers and Concentration of Credit Risk

[0001193125-14-404493:notes:25]
[same as prior period, unchanged from 0001193125-14-295293:notes:36]

[0001193125-14-404493:notes:26]
The Company’s customers include both OEM and EMS
 companies. The Company’s OEM customers often direct a
 significant portion of their purchases through EMS companies. While
 the Company’s customers include both OEM and EMS providers,
 the Company measures customer concentration based on OEM companies,
 as they are the ultimate end customers.

[0001193125-14-404493:notes:27]
For each of the quarters ended September 29, 2014 and
 September 30, 2013, one customer accounted for approximately
 23% of the Company’s net sales. For the three quarters ended
 September 29, 2014 and September 30, 2013, one customer
 accounted for approximately 16% and 17%, respectively, of the
 Company’s net sales.


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-14-404493:notes:28]
Inventories as of September 29, 2014 and December 30,
 2013 consist of the following:

[0001193125-14-404493:notes:29]
|  |  | As of |  |
|  |  | September 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 45,733 |  |  | $ | 42,533 |  |
| Work-in-process |  |  | 61,320 |  |  |  | 48,338 |  |
| Finished goods |  |  | 44,585 |  |  |  | 47,274 |  |
|  |  | $ | 151,638 |  |  | $ | 138,145 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-404493:notes:30]
(15) Segment
 Information

[0001193125-14-404493:notes:31]
[same as prior period, unchanged from 0001193125-14-295293:notes:99]

[0001193125-14-404493:notes:32]
[same as prior period, unchanged from 0001193125-14-295293:notes:100]

[0001193125-14-404493:notes:33]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2014 |  |  | September 30, 2013 |  |  | September 29, 2014 |  |  | September 30, 2013 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 214,727 |  |  | $ | 206,460 |  |  | $ | 547,092 |  |  | $ | 618,674 |  |
| North America |  |  | 131,054 |  |  |  | 132,608 |  |  |  | 389,237 |  |  |  | 385,866 |  |
| Total sales |  |  | 345,781 |  |  |  | 339,068 |  |  |  | 936,329 |  |  |  | 1,004,540 |  |
| Inter-segment sales |  |  | (506 | ) |  |  | (377 | ) |  |  | (1,524 | ) |  |  | (2,436 | ) |
| Total net sales |  | $ | 345,275 |  |  | $ | 338,691 |  |  | $ | 934,805 |  |  | $ | 1,002,104 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 10,034 |  |  | $ | (7,313 | ) |  | $ | 11,976 |  |  | $ | 27,454 |  |
| North America |  |  | 4,259 |  |  |  | 8,455 |  |  |  | 14,440 |  |  |  | 19,344 |  |
| Total operating segment income |  |  | 14,293 |  |  |  | 1,142 |  |  |  | 26,416 |  |  |  | 46,798 |  |
| Amortization of definite-lived intangibles |  |  | (1,980 | ) |  |  | (2,329 | ) |  |  | (6,452 | ) |  |  | (6,984 | ) |
| Total operating income (loss) |  |  | 12,313 |  |  |  | (1,187 | ) |  |  | 19,964 |  |  |  | 39,814 |  |
| Total other expense |  |  | (4,276 | ) |  |  | (3,156 | ) |  |  | (20,177 | ) |  |  | (13,723 | ) |
| Income (loss) before income taxes |  | $ | 8,037 |  |  | $ | (4,343 | ) |  | $ | (213 | ) |  | $ | 26,091 |  |

[0001193125-14-404493:notes:34]
The Company accounts for inter-segment sales and transfers as
 if the sale or transfer were to third parties: at arms length and
 consistent with the Company’s revenue recognition policy. The
 inter-segment sales for the quarter and the three quarters ended
 September 29, 2014 and September 30, 2013 are sales from
 the Asia Pacific operating segment to the North America operating
 segment.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-14-404493:notes:35]
(3)
 Inventories


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-14-404493:notes:36]
(16) Related Party
 Transactions

[0001193125-14-404493:notes:37]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $11,469 and $13,740 for the quarters ended
 September 29, 2014 and September 30, 2013, respectively,
 and $36,647 and $51,349 for the three quarters ended
 September 29, 2014 and September 30, 2013,
 respectively.

[0001193125-14-404493:notes:38]
Dongguan Shengyi Electronics Ltd., (SYE) is a related party as
 a significant shareholder of the Company holds an equity interest
 in the parent company of SYE. Sales to SYE for the quarters ended
 September 29, 2014 and September 30, 2013 were $2,282 and
 $14,351, respectively, and $21,535 and $18,361 for the three
 quarters ended September 29, 2014 and September 30, 2013,
 respectively. Additionally, purchases from SYE for the quarter and
 three quarters ended September 29, 2014 were approximately $78
 and $550, respectively. There were no purchases from SYE for the
 quarter or three quarters ended September 30, 2013.

[0001193125-14-404493:notes:39]
As of
 September 29, 2014 and December 30, 2013, the
 Company’s consolidated condensed balance sheet included
 $19,884 and $19,547, respectively, in accounts payable due to, and
 $8,924 and $13,312, respectively, in accounts receivable due from
 related parties for the purchase of laminate and prepreg, and sales
 of PCBs to SYE, as mentioned above.


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-14-404493:notes:40]
[same as prior period, unchanged from 0001193125-14-295293:notes:68]

[0001193125-14-404493:notes:41]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2014 |  |  | September 30, 2013 |  |  | September 29, 2014 |  |  | September 30, 2013 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 207 |  |  | $ | 252 |  |  | $ | 669 |  |  | $ | 809 |  |
| Selling and marketing |  |  | 257 |  |  |  | 304 |  |  |  | 845 |  |  |  | 1,001 |  |
| General and administrative |  |  | 1,490 |  |  |  | 1,275 |  |  |  | 4,539 |  |  |  | 4,934 |  |
| Stock-based compensation expense recognized |  |  | 1,954 |  |  |  | 1,831 |  |  |  | 6,053 |  |  |  | 6,744 |  |
| Income tax benefit recognized |  |  | (517 | ) |  |  | (459 | ) |  |  | (1,580 | ) |  |  | (1,640 | ) |
| Total stock-based compensation expense after income taxes |  | $ | 1,437 |  |  | $ | 1,372 |  |  | $ | 4,473 |  |  | $ | 5,104 |  |


## us-gaap:ScheduleOfShareBasedCompensationArrangementByShareBasedPaymentAwardPerformanceBasedUnitsVestedAndExpectedToVestTableTextBlock

[0001193125-14-404493:notes:42]
PRUs activity for the three quarters ended September 29,
 2014 was as follows:

[0001193125-14-404493:notes:43]
|  |  | Shares |  |
|  |  | (In thousands) |  |
| Outstanding target shares at December 30, 2013 |  |  | 353 |  |
| Granted: |  |  |  |  |
| Third tranche of 2012 grant |  |  | 59 |  |
| Second tranche of 2013 grant |  |  | 113 |  |
| First tranche of 2014 grant |  |  | 86 |  |
| Change in units due to annual performance achievement |  |  | (42 | ) |
| Vested |  |  | (90 | ) |
| Forfeitures / cancellations |  |  | (34 | ) |
| Outstanding target shares at September 29, 2014 |  |  | 445 |  |


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-14-404493:notes:44]
[same as prior period, unchanged from 0001193125-14-295293:notes:1]

[0001193125-14-404493:notes:45]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2014 |  |  | September 30, 2013 |  |  | September 29, 2014 |  |  | September 30, 2013 |  |
|  |  | (In thousands) |  |
| Derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (2,213 | ) |  | $ | 353 |  |  | $ | (1,259 | ) |  | $ | (312 | ) |
| Interest rate swap |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 620 |  |
|  |  | $ | (2,213 | ) |  | $ | 353 |  |  | $ | (1,259 | ) |  | $ | 308 |  |


## us-gaap:ScheduleOfUnrecognizedCompensationCostNonvestedAwardsTableTextBlock

[0001193125-14-404493:notes:46]
The following is a summary of total unrecognized compensation
 costs as of September 29, 2014:

[0001193125-14-404493:notes:47]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |
|  |  | (In thousands) |  |  | (years) |
| PRU awards |  | $ | 1,362 |  |  | 1.5 |
| RSU awards |  |  | 8,185 |  |  | 1.3 |
| Stock option awards |  |  | 5 |  |  | 0.1 |
|  |  | $ | 9,552 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-14-404493:notes:48]
(8) Financial
 Instruments

[0001193125-14-404493:notes:49]
[same as prior period, unchanged from 0001193125-14-295293:notes:13]

[0001193125-14-404493:notes:50]
The Company enters into foreign currency forward contracts to
 mitigate the impact of changes in foreign currency exchange rates
 and to reduce the volatility of purchases and other obligations
 generated in currencies other than the functional currencies. The
 Company’s foreign subsidiaries may at times purchase forward
 exchange contracts to manage their foreign currency risks in
 relation to certain purchases of machinery denominated in foreign
 currencies other than the Company’s foreign functional
 currency. The notional amount of the foreign exchange contracts as
 of September 29, 2014 and December 30, 2013 was
 approximately $30,379 and $47,000, respectively. The Company has
 designated certain of these foreign exchange contracts as cash flow
 hedges.

[0001193125-14-404493:notes:51]
[same as prior period, unchanged from 0001193125-14-295293:notes:17]

[0001193125-14-404493:notes:52]
|  |  |  |  |  | For the Quarter Ended |  |
|  |  |  |  |  | September 29, 2014 |  |  | September 30, 2013 |  |
|  |  |  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized into Income |  |
|  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward |  |  | Depreciation expense |  |  | $ | (65 | ) |  | $ | (40 | ) |  | $ | — |  |  | $ | (1,240 | ) |  | $ | (111 | ) |  | $ | — |  |
|  |  |  |  |  |  | $ | (65 | ) |  | $ | (40 | ) |  | $ | — |  |  | $ | (1,240 | ) |  | $ | (111 | ) |  | $ | — |  |
|  |  |  |  |  | For the Three Quarters Ended |  |
|  |  |  |  |  | September 29, 2014 |  |  | September 30, 2013 |  |
|  |  |  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized into Income |  |
|  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward |  |  | Depreciation expense |  |  | $ | 55 |  |  | $ | (105 | ) |  | $ | — |  |  | $ | (1,437 | ) |  | $ | (111 | ) |  | $ | — |  |
|  |  |  |  |  |  | $ | 55 |  |  | $ | (105 | ) |  | $ | — |  |  | $ | (1,437 | ) |  | $ | (111 | ) |  | $ | — |  |

[0001193125-14-404493:notes:53]
The following table provides a summary of the activity
 associated with the designated cash flow hedges reflected in
 accumulated other comprehensive income (loss) for the three
 quarters ended September 29, 2014 and September 30,
 2013:

[0001193125-14-404493:notes:54]
|  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2014 |  |  | September 30, 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance unrealized loss, net of tax |  | $ | (1,613 | ) |  | $ | (15 | ) |
| Changes in fair value, net of tax |  |  | 55 |  |  |  | (1,437 | ) |
| Reclassification to earnings |  |  | 105 |  |  |  | 111 |  |
| Ending balance unrealized loss, net of tax |  | $ | (1,453 | ) |  | $ | (1,341 | ) |

[0001193125-14-404493:notes:55]
The Company expects that approximately $169 of expense will be
 reclassified into the statement of operations, net of tax, in the
 next 12 months.

[0001193125-14-404493:notes:56]
Other Financial
 Instruments

[0001193125-14-404493:notes:57]
The carrying amount and estimated fair value of the
 Company’s financial instruments at September 29, 2014
 and December 30, 2013 were as follows:

[0001193125-14-404493:notes:58]
|  |  | September 29, 2014 |  |  | December 30, 2013 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Available for sale securities |  | $ | — |  |  | $ | — |  |  | $ | 148 |  |  | $ | 148 |  |
| Derivative assets, current |  |  | — |  |  |  | — |  |  |  | 647 |  |  |  | 647 |  |
| Derivative liabilities, current |  |  | 2,868 |  |  |  | 2,868 |  |  |  | 1,650 |  |  |  | 1,650 |  |
| Derivative assets, non-current |  |  | — |  |  |  | — |  |  |  | 10 |  |  |  | 10 |  |
| Derivative liabilities, non-current |  |  | — |  |  |  | — |  |  |  | 1,288 |  |  |  | 1,288 |  |
| Long-term debt |  |  | 273,805 |  |  |  | 273,036 |  |  |  | 370,008 |  |  |  | 369,402 |  |
| Convertible senior notes due 2015 |  |  | 31,481 |  |  |  | 32,800 |  |  |  | 36,568 |  |  |  | 39,960 |  |
| Convertible senior notes due 2020 |  |  | 195,234 |  |  |  | 243,725 |  |  |  | 167,167 |  |  |  | 237,050 |  |

[0001193125-14-404493:notes:59]
[same as prior period, unchanged from 0001193125-14-295293:notes:25]

[0001193125-14-404493:notes:60]
[same as prior period, unchanged from 0001193125-14-295293:notes:26]

[0001193125-14-404493:notes:61]
The fair value of the long-term debt was estimated based on
 discounting the debt over its life using current market rates for
 similar debt as of September 29, 2014 and December 30,
 2013.

[0001193125-14-404493:notes:62]
[same as prior period, unchanged from 0001193125-14-295293:notes:28]

[0001193125-14-404493:notes:63]
As of September 29, 2014 and December 30, 2013, the
 Company’s other financial instruments also included cash and
 cash equivalents, accounts receivable, accounts payable and
 equipment payables. Due to short-term maturities, the carrying
 amount of these instruments approximates fair value.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001193125-14-404493:notes:64]
(18) Noncontrolling
 Interest Holdings

[0001193125-14-404493:notes:65]
On
 June 17, 2013, the Company completed the sale of its 70.2%
 controlling equity interest in Dongguan Shengyi Electronics Ltd.
 (SYE) to its noncontrolling partner, Shengyi Technology Co. Ltd.
 (Sytech), for 702,000,000 Chinese RMB or $114,495. The Company
 recognized a gain on the sale of SYE of $17,917. Consideration net
 of cash sold was $67,147.

[0001193125-14-404493:notes:66]
[same as prior period, unchanged from 0001193125-14-295293:notes:87]


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-14-404493:notes:67]
The following provides a summary of the components of
 accumulated other comprehensive income (loss) as of
 September 29, 2014 and December 30, 2013:

[0001193125-14-404493:notes:68]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Unrealized Gains (Losses) on Available for Sale Securities |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 30, 2013 |  | $ | 47,280 |  |  | $ | (1,613 | ) |  | $ | (63 | ) |  | $ | 45,604 |  |
| Other comprehensive income (loss) before reclassifications |  |  | (4,940 | ) |  |  | 55 |  |  |  | (20 | ) |  |  | (4,905 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | — |  |  |  | 105 |  |  |  | 83 |  |  |  | 188 |  |
| Other comprehensive (loss) income |  |  | (4,940 | ) |  |  | 160 |  |  |  | 63 |  |  |  | (4,717 | ) |
| Ending balance at September 29, 2014 |  | $ | 42,340 |  |  | $ | (1,453 | ) |  | $ | — |  |  | $ | 40,887 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-14-404493:notes:69]
The following table summarizes the long-term debt of the
 Company as of September 29, 2014 and December 30,
 2013:

[0001193125-14-404493:notes:70]
|  |  | Average Effective Interest Rate as of September 29, 2014 |  | September 29, 2014 |  |  | Average Effective Interest Rate as of December 30, 2013 |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.53% |  | $ | 273,800 |  |  | 2.55% |  | $ | 370,000 |  |
| Other |  | 6.00% |  |  | 5 |  |  | 6.00% |  |  | 8 |  |
|  |  |  |  |  | 273,805 |  |  |  |  |  | 370,008 |  |
| Less: current maturities |  |  |  |  | (96,205 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 177,600 |  |  |  |  | $ | 273,804 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-14-404493:notes:71]
(2) Acquisition of
 Viasystems Group, Inc.

[0001193125-14-404493:notes:72]
On September 21, 2014, TTM, Viasystems Group, Inc.
 (Viasystems), and Vector Acquisition Corp. (Merger Sub) entered
 into an Agreement and Plan of Merger (the Merger Agreement) under
 which TTM will acquire all outstanding shares of Viasystems (the
 Merger) for a combined consideration of $11.33 in cash and 0.706
 shares of TTM common stock per outstanding share of Viasystems
 common stock, which based on the closing market price on
 September 19, 2014 was valued at $16.46 per share of
 Viasystems common stock, or approximately $368 million. The total
 enterprise value of the transaction, including the assumption of
 debt, is approximately $927 million which was based on the closing
 market price on September 19, 2014 and is subject to change
 prior to the consummation of the Merger.

[0001193125-14-404493:notes:73]
The Merger Agreement provides that Viasystems is entitled to
 receive a reverse breakup fee of $40 million from TTM in the event
 that the Merger Agreement is terminated following specific
 conditions.

[0001193125-14-404493:notes:74]
On September 30, 2014, in conjunction with TTM’s
 announcement of the execution of a definitive agreement with
 Viasystems, TTM was named in a class action complaint filed in the
 Circuit Court of St. Louis County, Missouri. On October 13,
 2014, TTM was named in a similar class action complaint filed in
 the Court of Chancery of the State of Delaware. Both suits were
 filed on behalf of the public stockholders of Viasystems against
 Viasystems’ board of directors for breaches of fiduciary
 duties arising out of their attempt to sell Viasystems to TTM, and
 against TTM for aiding and abetting such breaches of fiduciary
 duties. TTM cannot assess the potential outcomes of these class
 action complaints at this time. See Note 12 to these
 Consolidated Condensed Financial Statements for additional
 information.

[0001193125-14-404493:notes:75]
Bank fees and legal and accounting costs associated with the
 acquisition of Viasystems of $1,632 for the quarter
 ended September 29, 2014 have been expensed and recorded
 as general and administrative expense in the consolidated condensed
 statement of operations in accordance with ASC Topic 805,
 Business Combinations.

[0001193125-14-404493:notes:76]
The transaction is expected to close in the first half of
 2015.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-404493:notes:77]
(7) Income
 Taxes

[0001193125-14-404493:notes:78]
The Company’s provision for income taxes was $379 and
 $3,365 for the quarters ended September 29, 2014 and
 September 30, 2013, respectively. Additionally, the Company
 had an income tax benefit of $968 for the three quarters ended
 September 29, 2014 and a provision for income taxes of $13,494
 for the three quarters ended September 30, 2013. The
 Company’s provision for income taxes reflects the benefits of
 earnings from the Company’s operations in lower-tax
 jurisdictions in China, the apportioned state income tax rates,
 generation of other credits and deductions, and certain
 non-deductible items.

[0001193125-14-404493:notes:79]
During the quarter ended September 29, 2014, the
 Company’s provision for income taxes was impacted by losses
 incurred in certain foreign jurisdictions for which no tax benefit
 was recorded as a result of full valuation allowances. In addition,
 the Company recorded discrete tax benefits resulting from the
 research and development deduction at a Chinese subsidiary within
 the Company’s Asia Pacific operating segment and changes in
 estimates resulting from the completion of the Company’s 2013
 federal income tax return. During the three quarters ended
 September 29, 2014, the Company’s provision for income
 taxes was further impacted by a discrete tax benefit resulting from
 the retroactive approval of the high technology enterprise status
 for certain Chinese subsidiaries within the Company’s Asia
 Pacific operating segment.

[0001193125-14-404493:notes:80]
The Company’s provision for income taxes for the quarter
 and three quarters ended September 30, 2013 was impacted by
 the impairment of property, plant and equipment related to a plant
 closure in China which resulted in no related tax benefit.
 Additionally, in the third quarter of 2013, a state law was enacted
 that significantly reduced the carryforward period of certain state
 tax credits. As a result, a valuation allowance in the amount of
 approximately $3.3 million generated a discrete tax item for the
 quarter and three quarters ended September 30,
 2013.

[0001193125-14-404493:notes:81]
[same as prior period, unchanged from 0001193125-14-295293:notes:84]


## us-gaap:LongTermDebtTextBlock

[0001193125-14-404493:notes:82]
(5) Long-term Debt and
 Letters of Credit

[0001193125-14-404493:notes:83]
The calendar maturities of long-term debt through 2016 are as
 follows:

[0001193125-14-404493:notes:84]
|  |  | (In thousands) |  |
| 2015 |  | $ | 96,205 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 273,805 |  |

[0001193125-14-404493:notes:85]
Credit
 Agreement

[0001193125-14-404493:notes:86]
In 2012, the Company became a party to a facility agreement
 (Credit Agreement) consisting of a $370,000 senior secured term
 loan (Term Loan), a $90,000 senior secured revolving loan
 (Revolving Loan), and a secured $80,000 letters of credit facility
 (Letters of Credit Facility). The Term Loan and Letters of Credit
 Facility will mature on September 14, 2016. The Revolving Loan
 will mature on March 14, 2016. The Credit Agreement is secured
 by substantially all of the assets of the Company’s Asia
 Pacific operating segment and is senior to all other debt,
 including the convertible senior notes. See Note 6 to these
 Consolidated Condensed Financial Statements for additional
 information. The Company has fully and unconditionally guaranteed
 the full and timely payment of all Credit Agreement related
 obligations of its Asia Pacific operating segment.

[0001193125-14-404493:notes:87]
As of September 29, 2014 and December 30, 2013, the
 remaining unamortized debt issuance costs included in other
 non-current assets was $1,323 and $1,937, respectively, and is
 amortized to interest expense over the term of the Company’s
 Credit Agreement using the effective interest rate method. At
 September 29, 2014, the remaining amortization period for the
 unamortized debt issuance costs was 1.7 years.

[0001193125-14-404493:notes:88]
The Company is also required to pay a commitment fee of
 0.50% per annum on any unused portion of the loan and letters
 of credit facility granted under the Credit Agreement. The Company
 incurred commitment fees related to unused borrowing availability
 of $155 and $129 for the quarters ended September 29, 2014 and
 September 30, 2013, respectively, and $439 and $320 for the
 three quarters ended September 29, 2014 and September 30,
 2013, respectively. As of September 29, 2014, the outstanding
 amount of the Term Loan under the Credit Agreement was $273,800, of
 which $96,200 is due for repayment through September 2015 and is
 included as short-term debt, with the remaining $177,600 included
 as long-term debt. None of the Revolving Loan was outstanding under
 the Credit Agreement as of September 29, 2014. Available
 borrowing capacity under the Revolving Loan was $90,000 at
 September 29, 2014.

[0001193125-14-404493:notes:89]
Other Credit
 Facility

[0001193125-14-404493:notes:90]
Additionally, the Company is party to a revolving loan credit
 facility with a lender in the People’s Republic of China
 (China). Under this arrangement, the lender has made available to
 the Company approximately $47,300 in unsecured borrowing with all
 terms of the borrowing to be negotiated at the time the revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the revolver and this arrangement expires in December 2014. As of
 September 29, 2014, the revolver had not been drawn
 upon.

[0001193125-14-404493:notes:91]
Letters of
 Credit

[0001193125-14-404493:notes:92]
The Company has an $80,000 Letters of Credit Facility under the
 Credit Agreement, as mentioned above. As of September 29,
 2014, letters of credit in the amount of $43,234 were outstanding
 under this Credit Agreement. The Company has other standby letters
 of credit outstanding in the amount of $3,894, which expire between
 December 31, 2014 and February 28, 2015.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-14-404493:notes:93]
[same as prior period, unchanged from 0001193125-14-295293:notes:70]

[0001193125-14-404493:notes:94]
[same as prior period, unchanged from 0001193125-14-295293:notes:71]

[0001193125-14-404493:notes:95]
The accompanying consolidated condensed financial statements
 have been prepared by the Company, without audit, pursuant to the
 rules and regulations of the Securities and Exchange Commission
 (SEC). Certain information and disclosures normally included in
 financial statements prepared in accordance with accounting
 principles generally accepted in the United States of America have
 been condensed or omitted pursuant to such rules and regulations.
 These consolidated condensed financial statements reflect all
 adjustments (consisting only of normal recurring adjustments)
 which, in the opinion of management, are necessary to present
 fairly the financial position, the results of operations and cash
 flows of the Company for the periods presented. It is suggested
 that these consolidated condensed financial statements be read in
 conjunction with the consolidated financial statements and the
 notes thereto included in the Company’s most recent Annual
 Report on Form 10-K. The results of operations for the interim
 periods are not necessarily indicative of the results to be
 expected for the full year. The preparation of financial statements
 in accordance with U.S. generally accepted accounting principles
 requires management to make estimates and assumptions that affect
 the amounts reported in the Company’s consolidated condensed
 financial statements and accompanying notes. Actual results could
 differ materially from those estimates. The Company uses a 13-week
 fiscal quarter accounting period with the fourth quarter ending on
 the Monday nearest December 31.

[0001193125-14-404493:notes:96]
Recently Issued
 Accounting Standards

[0001193125-14-404493:notes:97]
On May 28, 2014, the Financial Accounting Standards Board
 (FASB) issued Accounting Standards Update No. (ASU) 2014-09,
 Revenue from Contracts with Customers, which requires an
 entity to recognize the amount of revenue to which it expects to be
 entitled for the transfer of promised goods or services to
 customers. The ASU will replace most existing revenue recognition
 guidance in U.S. GAAP when it becomes effective. The new standard
 is effective for the Company at the beginning of fiscal year 2017.
 Early application is not permitted. The standard permits the use of
 either the retrospective or cumulative effect transition method.
 The Company is evaluating the effect that ASU 2014-09 will have on
 its consolidated financial statements and related disclosures. The
 Company has not yet selected a transition method nor has it
 determined the effect of the standard on its ongoing financial
 reporting.

[0001193125-14-404493:notes:98]
[same as prior period, unchanged from 0001193125-14-295293:notes:75]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-14-404493:notes:99]
(14) Stock-Based
 Compensation

[0001193125-14-404493:notes:100]
[same as prior period, unchanged from 0001193125-14-295293:notes:89]

[0001193125-14-404493:notes:101]
[same as prior period, unchanged from 0001193125-14-295293:notes:90]

[0001193125-14-404493:notes:102]
The Company records stock-based compensation expense for PRU
 awards granted based on management’s periodic assessment of
 the probability of the PRU awards vesting. PRUs activity for the
 three quarters ended September 29, 2014 was as
 follows:

[0001193125-14-404493:notes:103]
The fair value for PRUs granted is calculated using a Monte
 Carlo simulation model, as the TSR modifier contains a market
 condition. For the three quarters ended September 29, 2014 and
 September 30, 2013, the following assumptions were used in
 determining the fair value:

[0001193125-14-404493:notes:104]
[same as prior period, unchanged from 0001193125-14-295293:notes:93]

[0001193125-14-404493:notes:105]
The Company granted 833 and 894 restricted stock units during
 the three quarters ended September 29, 2014 and
 September 30, 2013, respectively. The units granted have a
 weighted-average fair value per unit of $8.00 and $8.17 for the
 three quarters ended September 29, 2014 and September 30,
 2013, respectively. The fair value for restricted stock units
 granted is based on the closing share price of the Company’s
 common stock on the date of grant. There were no restricted stock
 units granted during the quarters ended September 29, 2014 and
 September 30, 2013.

[0001193125-14-404493:notes:106]
[same as prior period, unchanged from 0001193125-14-295293:notes:95]

[0001193125-14-404493:notes:107]
The Company did not grant any stock option awards during the
 quarter or three quarters ended September 29, 2014 and
 September 30, 2013.

[0001193125-14-404493:notes:108]
Summary of Unrecognized
 Compensation Costs


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-14-404493:notes:109]
(11) Fair Value
 Measures

[0001193125-14-404493:notes:110]
[same as prior period, unchanged from 0001193125-14-295293:notes:33]

[0001193125-14-404493:notes:111]
There were no transfers of financial assets or liabilities
 between Level 1 and Level 2 inputs for the quarter or three
 quarters ended September 29, 2014 and September 30,
 2013.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-14-404493:notes:112]
(9) Accumulated Other
 Comprehensive Income (Loss)

[0001193125-14-404493:notes:113]
Foreign currency translation amounts as of September 29,
 2014 and December 30, 2013 are net of taxes of $3,085 and
 $3,132, respectively.

[0001193125-14-404493:notes:114]
The following provides a summary of reclassifications out of
 accumulated other comprehensive income for the quarter and three
 quarters ended September 29, 2014 and September 30,
 2013:

[0001193125-14-404493:notes:115]
|  |  |  |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |
|  |  |  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Statement of Operations Location |  | September 29, 2014 |  |  | September 30, 2013 |  |  | September 29, 2014 |  |  | September 30, 2013 |  |
| Loss on cash flow hedges |  | Depreciation expense, net of tax |  | $ | 40 |  |  | $ | 111 |  |  | $ | 105 |  |  | $ | 111 |  |
| Loss on available for sale securities |  | Other, net, net of tax |  | $ | — |  |  | $ | 18 |  |  | $ | 83 |  |  | $ | 22 |  |
| Gain on foreign currency translation |  | Gain on sale of assets, net of tax |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (14,266 | ) |


## ttmi:ScheduleOfLiabilityAndEquityComponentsOfConvertibleNotesTableTextBlock

[0001193125-14-404493:notes:116]
As of September 29, 2014 and December 30, 2013, the
 following summarizes the liability and equity components of the
 convertible senior notes:

[0001193125-14-404493:notes:117]
|  |  | As of September 29, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (54,766 | ) |  | $ | 195,234 |  |  | $ | 220,000 |  |  | $ | (52,833 | ) |  | $ | 167,167 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (914 | ) |  |  | 31,481 |  |  |  | 38,909 |  |  |  | (2,341 | ) |  |  | 36,568 |  |
| Total |  | $ | 282,395 |  |  | $ | (55,680 | ) |  | $ | 226,715 |  |  | $ | 258,909 |  |  | $ | (55,174 | ) |  | $ | 203,735 |  |
|  |  | As of September 29, 2014 |  |  | As of December 30, 2013 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 53,000 |  |  | $ | (1,644 | ) |  | $ | 51,356 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |  |  | 39,928 |  |  |  | (1,413 | ) |  |  | 38,515 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |  | $ | 92,928 |  |  | $ | (3,057 | ) |  | $ | 89,871 |  |


## ttmi:DistributionOfProfitsDisclosureTextBlock

[0001193125-14-404493:notes:118]
(17) Distribution of
 Profits

[0001193125-14-404493:notes:119]
As stipulated by the relevant laws and regulations of China
 applicable to the Company’s subsidiaries in China, each of
 such subsidiaries is required to make appropriations from its net
 income as determined in accordance with accounting principles and
 the relevant financial regulations of China (PRC GAAP) to a
 non-distributable reserve, also referred to as statutory surplus
 reserve. The appropriations to the statutory surplus reserve are
 required to be made at not less than 10% of the profit after tax as
 determined under PRC GAAP and required until the balance reaches
 50% of its registered capital. The statutory surplus reserve is
 used to offset future or past losses. These Chinese subsidiaries
 may, upon a resolution passed by their respective shareholders,
 convert the statutory surplus reserve into capital. There were
 appropriations of approximately $207 to the statutory surplus
 reserve of these Chinese subsidiaries for the quarter ended
 September 29, 2014.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock

[0001193125-14-404493:notes:120]
The components of interest expense resulting from the
 convertible senior notes for the quarter and three quarters ended
 September 29, 2014 and September 30, 2013 are as
 follows:

[0001193125-14-404493:notes:121]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 29, 2014 |  |  | September 30, 2013 |  |  | September 29, 2014 |  |  | September 30, 2013 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | — |  |  | $ | 3,273 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 1,422 |  |  |  | 790 |  |  |  | 4,266 |  |
|  |  | $ | 1,357 |  |  | $ | 1,422 |  |  | $ | 4,063 |  |  | $ | 4,266 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,779 |  |  | $ | — |  |  | $ | 5,294 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 352 |  |  |  | 1,751 |  |  |  | 1,036 |  |  |  | 5,147 |  |
|  |  | $ | 2,131 |  |  | $ | 1,751 |  |  | $ | 6,330 |  |  | $ | 5,147 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 178 |  |  | $ | — |  |  | $ | 531 |  |  | $ | — |  |
| Convertible senior notes due 2015 |  |  | 36 |  |  |  | 177 |  |  |  | 104 |  |  |  | 519 |  |
|  |  | $ | 214 |  |  | $ | 177 |  |  | $ | 635 |  |  | $ | 519 |  |


## ttmi:ConvertibleSeniorNotesTextBlock

[0001193125-14-404493:notes:122]
(6) Convertible Senior
 Notes

[0001193125-14-404493:notes:123]
Convertible Senior
 Notes due 2020

[0001193125-14-404493:notes:124]
In December 2013, the Company issued 1.75% convertible
 senior notes due December 15, 2020, in a public offering for
 an aggregate principal amount of $220,000. The convertible senior
 notes bear interest at a rate of 1.75% per annum. Interest is
 payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and senior in
 right of payment to any of the Company’s future subordinated
 indebtedness.

[0001193125-14-404493:notes:125]
In January 2014, the Company closed the sale of an additional
 $30,000 aggregate principal amount of its 1.75% convertible senior
 notes due 2020 (Additional Notes). The Additional Notes were sold
 pursuant to the exercise of an over-allotment option granted by the
 Company in the underwriting agreement related to the offer and sale
 of $220,000 aggregate principal amount of its 1.75% convertible
 senior notes due 2020.

[0001193125-14-404493:notes:126]
In connection with the offering of the Additional Notes, the
 Company entered into additional convertible note hedge and warrant
 transactions (Additional Call Spread Transaction) with respect to
 shares of its common stock. The additional convertible note hedge,
 which cost an aggregate $7,953 and was recorded, net of tax, as a
 reduction of additional paid-in capital, consists of the
 Company’s option to purchase up to 3,100 common stock shares
 at a price of $9.64 per share and will expire upon the maturity of
 the notes. Additionally, the Company sold warrants to purchase
 3,100 shares of its common stock at a price of $14.26 per
 share. The warrants expire ratably from March 2021 through January
 2022. The proceeds from the sale of warrants of $4,053 was recorded
 as an increase to additional paid-in capital. The 2020 Additional
 Call Spread Transaction has no effect on the terms of the
 convertible senior notes due 2020 and reduces potential dilution by
 effectively increasing the conversion price of the convertible
 senior notes due 2020 to $14.26 per share of the Company’s
 common stock.

[0001193125-14-404493:notes:127]
[same as prior period, unchanged from 0001193125-14-295293:notes:116]

[0001193125-14-404493:notes:128]
Convertible Senior
 Notes due 2015

[0001193125-14-404493:notes:129]
In May 2008, the Company issued 3.25% convertible senior
 notes due May 15, 2015, in a public offering for an aggregate
 principal amount of $175,000. The convertible senior notes bear
 interest at a rate of 3.25% per annum. Interest is payable
 semiannually in arrears on May 15 and November 15 of each
 year. The convertible senior notes are senior unsecured obligations
 and rank equally to the Company’s future unsecured senior
 indebtedness and senior in right of payment to any of the
 Company’s future subordinated indebtedness.

[0001193125-14-404493:notes:130]
[same as prior period, unchanged from 0001193125-14-295293:notes:119]

[0001193125-14-404493:notes:131]
[same as prior period, unchanged from 0001193125-14-295293:notes:120]

[0001193125-14-404493:notes:132]
As of September 29, 2014 and December 30, 2013,
 remaining unamortized debt issuance costs included in other
 non-current assets were $5,580 and $5,399, respectively. The debt
 issuance costs and debt discount are being amortized to interest
 expense over the term of the convertible senior notes using the
 effective interest rate method. At September 29, 2014, the
 remaining weighted average amortization period for the unamortized
 senior convertible note discount and debt issuance costs was
 6.1 years.

[0001193125-14-404493:notes:133]
For the quarter and three quarters ended September 29,
 2014, the amortization of debt discount and debt issuance costs for
 the 2020 convertible senior notes and the 2015 convertible senior
 notes is based on an effective interest rate of 6.48% and 8.37%,
 respectively. For the quarter and three quarters ended
 September 30, 2013, the amortization of debt discount and debt
 issuance costs for the 2015 convertible senior notes is based on an
 effective interest rate of 8.37%.


## ttmi:TangibleAssetImpairmentChargesTextBlock

[0001193125-14-404493:notes:134]
(4) Impairment of
 Long-Lived Assets

[0001193125-14-404493:notes:135]
In
 conjunction with the closure of its Suzhou, China manufacturing
 facility in 2013, the Company determined that certain long-lived
 assets, primarily consisting of held for sale machinery and
 equipment, were impaired. As a result, the Company recorded a
 charge for the impairment of long-lived assets in the amount of
 $10,782 for the quarter and three quarters ended September 30,
 2013 and reclassified such assets to assets held for sale, which
 were included in other current assets in the December 30, 2013
 consolidated condensed balance sheet.

[0001193125-14-404493:notes:136]
During
 the three quarters ended September 29, 2014, the Company
 recorded an impairment charge for additional assets, related to the
 closure of the Suzhou, China manufacturing facility, which were
 originally designated to be transferred to other facilities in
 China as well as the disposal of a substantial portion of the
 assets held for sale. As a result, the Company recognized an
 additional impairment charge in the amount of $1,845 during the
 three quarters ended September 29, 2014, as the carrying value
 of the assets was greater than the market value at the date of
 disposal.
