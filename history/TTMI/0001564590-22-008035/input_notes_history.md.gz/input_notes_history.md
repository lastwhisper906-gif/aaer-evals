# TTMI note change history — 0001564590-21-040796 → 0001564590-21-053547


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001564590-21-053547:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 27, 2021 and December 28, 2020. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2021-08-04, similarity 0.9914):
[0001564590-21-040796:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of June 28, 2021 and December 28, 2020. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001564590-21-053547:note_history:2]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due to the coronavirus (COVID-19) global pandemic, the global economy and financial markets have been volatile, have contributed to disruptions in global supply chains and labor shortages, and there is a significant amount of uncertainty about the length and severity of the consequences caused by the on-going pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal 2021 ending on January 3, 2022 will be a 53-week year with the additional week included in the fourth quarter. Fiscal 2020 was a 52-week year.
  (was, 2021-08-04, similarity 0.6187):
[0001564590-21-040796:note_history:2]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due to the coronavirus (COVID-19) global pandemic, the global economy and financial markets have been volatile and there is a significant amount of uncertainty about the length and severity of the consequences caused by the on-going pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 13-week fiscal quarter accounting period with the fourth quarter ending on the Monday nearest December 31.

- added (2021-11-02):
[0001564590-21-053547:note_history:3]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale that was completed on April 17, 2020 of the following now former Company subsidiaries: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. Refer to Note 2, Discontinued Operations, for additional information.

- changed (2021-11-02):
[0001564590-21-053547:note_history:4]
The Company currently has two reportable segments: PCB and RF and Specialty Components (RF&S Components). On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting. As a result of the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.
  (was, 2021-08-04, similarity 0.8416):
[0001564590-21-040796:note_history:4]
The Company currently has two reportable segments: PCB and RF and Specialty Components (RF&S Components). In fiscal 2020, subsequent to the quarter ended June 29, 2020, RF&S Components was added as a reportable segment. As a result, the Company had three reportable segments as of December 28, 2020: PCB, RF&S Components, and E-M Solutions. On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting. As a result of the addition of the RF&S Components reportable segment and the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.

- removed (2021-11-02):
[0001564590-21-040796:note_history:5]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. Refer to Note 2, Discontinued Operations, for additional information.

- removed (2021-11-02):
[0001564590-21-040796:note_history:6]
Immaterial Correction of Error

- removed (2021-11-02):
[0001564590-21-040796:note_history:7]
During the quarter ended September 28, 2020, the Company paid for certain transaction costs related to the sale of the Mobility business unit totaling $11,043. These transaction costs should have been recorded as an expense earlier in the year and recorded in the period ending June 29, 2020, which would have reduced the gain on sale of Mobility business unit, during the quarter ended June 29, 2020. The Company overstated both the income from discontinued operations, net of income taxes and net income by $11,043, both basic earnings per share from discontinued operations and basic earnings per share of $0.10 and $0.11 in the quarter and two quarters ended June 29, 2020, respectively, and both diluted earnings per share from discontinued operations and diluted earnings per share of $0.10 in the quarter and two quarters ended June 29, 2020. Management concluded that this error in the timing of recording the expense was not material to the consolidated condensed financial statements for the quarter and two quarters ended June 29, 2020. Prior period amounts have been revised to correct the error.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001564590-21-053547:note_history:8]
As of September 27, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:
  (was, 2021-08-04, similarity 0.9692):
[0001564590-21-040796:note_history:8]
As of June 28, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:

- added (2021-11-02):
[0001564590-21-053547:note_history:9]
|  |  | As of September 27, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,114 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,183 |  |  |  | 660 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,297 |  |  | $ | 660 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |

- removed (2021-11-02):
[0001564590-21-040796:note_history:10]
|  |  | As of June 28, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,289 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,355 |  |  |  | 712 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,644 |  |  | $ | 712 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001564590-21-053547:note_history:11]
The following table summarizes the long-term debt of the Company as of September 27, 2021 and December 28, 2020:
  (was, 2021-08-04, similarity 0.9447):
[0001564590-21-040796:note_history:11]
The following table summarizes the long-term debt of the Company as of June 28, 2021 and December 28, 2020:

- changed (2021-11-02):
[0001564590-21-053547:note_history:12]
|  |  | Interest Rate as of September 27, 2021 |  |  | Principal Outstanding as of September 27, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.59 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.49 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (660 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,297 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,922 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,922 |  |  |  |  |  |  | $ | 842,853 |  |
  (was, 2021-08-04, similarity 0.9705):
[0001564590-21-040796:note_history:12]
|  |  | Interest Rate as of June 28, 2021 |  |  | Principal Outstanding as of June 28, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.60 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.50 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (712 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,644 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,523 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,523 |  |  |  |  |  |  | $ | 842,853 |  |

- changed (2021-11-02):
[0001564590-21-053547:note_history:13]
Pursuant to the Term Loan Credit Agreement, the Company may reinvest the cash proceeds received from the sale of the Mobility business unit for a period of twelve months commencing September 3, 2020. If the proceeds are not reinvested during that
  (was, 2021-08-04, similarity 0.7928):
[0001564590-21-040796:note_history:13]
Pursuant to the Term Loan Credit Agreement, the Company may reinvest the cash proceeds received from the sale of the Mobility business unit for a period of twelve months commencing September 3, 2020. If the proceeds are not reinvested during that time, the Company is required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to

- changed (2021-11-02):
[0001564590-21-053547:note_history:14]
time, the Company is required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to repay $400,000 of the Term Loan during the year ended December 28, 2020 and used the remaining cash proceeds for reinvestment pursuant to the Term Loan Credit Agreement. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.
  (was, 2021-08-04, similarity 0.8939):
[0001564590-21-040796:note_history:14]
repay $400,000 of the Term Loan during the year ended December 28, 2020 and used the remaining cash proceeds for reinvestment pursuant to the Term Loan Credit Agreement. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

- changed (2021-11-02):
[0001564590-21-053547:note_history:15]
The Company used a portion of the net proceeds from the issuance of the Senior Notes due 2029 during the quarter ended March 29, 2021 to: (i) fund the early retirement of $375,000 Senior Notes due 2025, (ii) fund the repayment of $40,000 outstanding under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) Revolving credit facility (but not terminate the commitments thereunder), and (iii) pay related premiums, fees and expenses. The Company has and intends to use the remaining net proceeds for general corporate purposes.
  (was, 2021-08-04, similarity 0.9921):
[0001564590-21-040796:note_history:15]
The Company used a portion of the net proceeds from the issuance of the Senior Notes due 2029 during the quarter ended March 29, 2021 to: (i) fund the early retirement of $375,000 Senior Notes due 2025, (ii) fund the repayment of $40,000 outstanding under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) Revolving credit facility (but not terminate the commitments thereunder), and (iii) pay related premiums, fees and expenses. The Company intends to use the remaining net proceeds for general corporate purposes.

- changed (2021-11-02):
[0001564590-21-053547:note_history:16]
As of September 27, 2021, letters of credit in the amount of $12,346 were outstanding under the U.S. ABL and $2,606 were outstanding under the Asia Asset-Based Lending Credit Agreement (Asia ABL) with various expiration dates through September 2021. Available borrowing capacity under the U.S. ABL and the Asia ABL was $137,654 and $117,394, respectively, which considers letters of credit outstanding as of September 27, 2021.
  (was, 2021-08-04, similarity 0.9384):
[0001564590-21-040796:note_history:16]
As of June 28, 2021, letters of credit in the amount of $12,201 were outstanding under the U.S. ABL and $3,475 were outstanding under the Asia Asset-Based Lending Credit Agreement (Asia ABL) with various expiration dates through July 2021. Available borrowing capacity under the U.S. ABL and the Asia ABL was $137,799 and $116,525, respectively, which considers letters of credit outstanding as of June 28, 2021.

- changed (2021-11-02):
[0001564590-21-053547:note_history:17]
As of September 27, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:
  (was, 2021-08-04, similarity 0.9692):
[0001564590-21-040796:note_history:17]
As of June 28, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:

- added (2021-11-02):
[0001564590-21-053547:note_history:18]
|  |  | As of September 27, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,114 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,183 |  |  |  | 660 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,297 |  |  | $ | 660 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |

- changed (2021-11-02):
[0001564590-21-053547:note_history:19]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,496 and $1,919 as of September 27, 2021 and December 28, 2020, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2021-08-04, similarity 0.9785):
[0001564590-21-040796:note_history:19]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,637 and $1,919 as of June 28, 2021 and December 28, 2020, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2021-11-02):
[0001564590-21-053547:note_history:20]
As of September 27, 2021, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 5.5 years.
  (was, 2021-08-04, similarity 0.9603):
[0001564590-21-040796:note_history:20]
As of June 28, 2021, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 5.7 years.

- added (2021-11-02):
[0001564590-21-053547:note_history:21]
During the three quarters ended September 27, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.

- removed (2021-11-02):
[0001564590-21-040796:note_history:22]
|  |  | As of June 28, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,289 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,355 |  |  |  | 712 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,644 |  |  | $ | 712 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |

- removed (2021-11-02):
[0001564590-21-040796:note_history:23]
During the two quarters ended June 28, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001564590-21-053547:note_history:24]
The following table summarizes the long-term debt of the Company as of September 27, 2021 and December 28, 2020:
  (was, 2021-08-04, similarity 0.9447):
[0001564590-21-040796:note_history:24]
The following table summarizes the long-term debt of the Company as of June 28, 2021 and December 28, 2020:

- changed (2021-11-02):
[0001564590-21-053547:note_history:25]
|  |  | Interest Rate as of September 27, 2021 |  |  | Principal Outstanding as of September 27, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.59 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.49 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (660 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,297 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,922 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,922 |  |  |  |  |  |  | $ | 842,853 |  |
  (was, 2021-08-04, similarity 0.9705):
[0001564590-21-040796:note_history:25]
|  |  | Interest Rate as of June 28, 2021 |  |  | Principal Outstanding as of June 28, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.60 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.50 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (712 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,644 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,523 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,523 |  |  |  |  |  |  | $ | 842,853 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001564590-21-053547:note_history:26]
|  |  | Quarter Ended September 27, 2021 |  |  | Quarter Ended September 28, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 173,894 |  |  | $ | 12 |  |  | $ | 173,906 |  |  | $ | 182,558 |  |  | $ | 180 |  |  | $ | 18 |  |  | $ | 182,756 |  |  |
| Automotive |  |  | 99,205 |  |  |  | — |  |  |  | 99,205 |  |  |  | 63,114 |  |  |  | — |  |  |  | 10,097 |  |  |  | 73,211 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 38 |  |  |  | — |  |  |  | — |  |  |  | 38 |  |  |
| Data Center Computing (2) |  |  | 81,202 |  |  |  | — |  |  |  | 81,202 |  |  |  | 62,554 |  |  |  | 186 |  |  |  | 34 |  |  |  | 62,774 |  |  |
| Medical/Industrial/Instrumentation |  |  | 108,879 |  |  |  | 1,467 |  |  |  | 110,346 |  |  |  | 91,836 |  |  |  | 742 |  |  |  | 2,939 |  |  |  | 95,517 |  |  |
| Networking/Communications |  |  | 74,316 |  |  |  | 12,848 |  |  |  | 87,164 |  |  |  | 74,366 |  |  |  | 7,203 |  |  |  | 8,919 |  |  |  | 90,488 |  |  |
| Other |  |  | 3,622 |  |  |  | 1,339 |  |  |  | 4,961 |  |  |  | 6,845 |  |  |  | 3,431 |  |  |  | (1,484 | ) |  |  | 8,792 |  |  |
| Total |  | $ | 541,118 |  |  | $ | 15,666 |  |  | $ | 556,784 |  |  | $ | 481,311 |  |  | $ | 11,742 |  |  | $ | 20,523 |  |  | $ | 513,576 |  |  |
  (was, 2021-08-04, similarity 0.9379):
[0001564590-21-040796:note_history:26]
|  |  | Quarter Ended June 28, 2021 |  |  | Quarter Ended June 29, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 185,152 |  |  | $ | 6 |  |  | $ | 185,158 |  |  | $ | 188,910 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 188,939 |  |  |
| Automotive |  |  | 102,893 |  |  |  | — |  |  |  | 102,893 |  |  |  | 57,998 |  |  |  | — |  |  |  | 11,583 |  |  |  | 69,581 |  |  |
| Data Center Computing (2) |  |  | 82,230 |  |  |  | 24 |  |  |  | 82,254 |  |  |  | 71,541 |  |  |  | 273 |  |  |  | 36 |  |  |  | 71,850 |  |  |
| Medical/Industrial/Instrumentation |  |  | 104,012 |  |  |  | 1,067 |  |  |  | 105,079 |  |  |  | 115,813 |  |  |  | 800 |  |  |  | 2,988 |  |  |  | 119,601 |  |  |
| Networking/Communications |  |  | 75,728 |  |  |  | 11,950 |  |  |  | 87,678 |  |  |  | 95,416 |  |  |  | 10,560 |  |  |  | 7,446 |  |  |  | 113,422 |  |  |
| Other |  |  | 3,465 |  |  |  | 856 |  |  |  | 4,321 |  |  |  | 7,165 |  |  |  | 449 |  |  |  | (709 | ) |  |  | 6,905 |  |  |
| Total |  | $ | 553,480 |  |  | $ | 13,903 |  |  | $ | 567,383 |  |  | $ | 536,843 |  |  | $ | 12,091 |  |  | $ | 21,364 |  |  | $ | 570,298 |  |  |

- changed (2021-11-02):
[0001564590-21-053547:note_history:27]
|  |  | Three Quarters Ended September 27, 2021 |  |  | Three Quarters Ended September 28, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 545,585 |  |  | $ | 24 |  |  | $ | — |  |  | $ | 545,609 |  |  | $ | 555,882 |  |  | $ | 189 |  |  | $ | 38 |  |  | $ | 556,109 |  |  |
| Automotive |  |  | 293,890 |  |  |  | — |  |  |  | 3,642 |  |  |  | 297,532 |  |  |  | 182,970 |  |  |  | — |  |  |  | 28,693 |  |  |  | 211,663 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,334 |  |  |  | — |  |  |  | — |  |  |  | 1,334 |  |  |
| Data Center Computing (2) |  |  | 235,191 |  |  |  | 456 |  |  |  | — |  |  |  | 235,647 |  |  |  | 192,209 |  |  |  | 663 |  |  |  | 124 |  |  |  | 192,996 |  |  |
| Medical/Industrial/Instrumentation |  |  | 303,661 |  |  |  | 3,615 |  |  |  | 25 |  |  |  | 307,301 |  |  |  | 298,117 |  |  |  | 2,336 |  |  |  | 9,247 |  |  |  | 309,700 |  |  |
| Networking/Communications |  |  | 216,982 |  |  |  | 35,451 |  |  |  | 1 |  |  |  | 252,434 |  |  |  | 240,215 |  |  |  | 19,173 |  |  |  | 20,560 |  |  |  | 279,948 |  |  |
| Other |  |  | 9,775 |  |  |  | 2,713 |  |  |  | (412 | ) |  |  | 12,076 |  |  |  | 21,429 |  |  |  | 10,913 |  |  |  | (2,572 | ) |  |  | 29,770 |  |  |
| Total |  | $ | 1,605,084 |  |  | $ | 42,259 |  |  | $ | 3,256 |  |  | $ | 1,650,599 |  |  | $ | 1,492,156 |  |  | $ | 33,274 |  |  | $ | 56,090 |  |  | $ | 1,581,520 |  |  |
  (was, 2021-08-04, similarity 0.9714):
[0001564590-21-040796:note_history:27]
|  |  | Two Quarters Ended June 28, 2021 |  |  | Two Quarters Ended June 29, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 371,691 |  |  |  | 12 |  |  | $ | — |  |  | $ | 371,703 |  |  | $ | 373,324 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 373,353 |  |  |
| Automotive |  |  | 194,685 |  |  |  | — |  |  |  | 3,642 |  |  |  | 198,327 |  |  |  | 119,856 |  |  |  | — |  |  |  | 18,596 |  |  |  | 138,452 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,296 |  |  |  | — |  |  |  | — |  |  |  | 1,296 |  |  |
| Data Center Computing (2) |  |  | 153,989 |  |  |  | 456 |  |  |  | — |  |  |  | 154,445 |  |  |  | 129,655 |  |  |  | 476 |  |  |  | 90 |  |  |  | 130,221 |  |  |
| Medical/Industrial/Instrumentation |  |  | 194,782 |  |  |  | 2,148 |  |  |  | 25 |  |  |  | 196,955 |  |  |  | 206,281 |  |  |  | 1,594 |  |  |  | 6,308 |  |  |  | 214,183 |  |  |
| Networking/Communications |  |  | 142,666 |  |  |  | 22,603 |  |  |  | 1 |  |  |  | 165,270 |  |  |  | 165,849 |  |  |  | 18,627 |  |  |  | 11,641 |  |  |  | 196,117 |  |  |
| Other |  |  | 6,153 |  |  |  | 1,374 |  |  |  | (412 | ) |  |  | 7,115 |  |  |  | 14,584 |  |  |  | 826 |  |  |  | (1,088 | ) |  |  | 14,322 |  |  |
| Total |  | $ | 1,063,966 |  |  | $ | 26,593 |  |  | $ | 3,256 |  |  | $ | 1,093,815 |  |  | $ | 1,010,845 |  |  | $ | 21,532 |  |  | $ | 35,567 |  |  | $ | 1,067,944 |  |  |

- changed (2021-11-02):
[0001564590-21-053547:note_history:28]
| (1) | Other represents results from the now closed SH E-MS and SZ facilities. |
  (was, 2021-08-04, similarity 0.7023):
[0001564590-21-040796:note_history:28]
| (1) | Other represents SH E-MS and SZ results. |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001564590-21-053547:note_history:29]
As of September 27, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $11,008. The Company expects to recognize revenue on approximately 84% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.
  (was, 2021-08-04, similarity 0.979):
[0001564590-21-040796:note_history:29]
As of June 28, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $11,905. The Company expects to recognize revenue on approximately 82% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.

- changed (2021-11-02):
[0001564590-21-053547:note_history:30]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and three quarters ended September 27, 2021, and 98% and 2%, respectively, of the Company’s revenue for the quarter and three quarters ended September 28, 2020.
  (was, 2021-08-04, similarity 0.7175):
[0001564590-21-040796:note_history:30]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for both quarter and two quarters ended June 28, 2021 and June 29, 2020.

- changed (2021-11-02):
[0001564590-21-053547:note_history:31]
|  |  | Quarter Ended September 27, 2021 |  |  | Quarter Ended September 28, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 173,894 |  |  | $ | 12 |  |  | $ | 173,906 |  |  | $ | 182,558 |  |  | $ | 180 |  |  | $ | 18 |  |  | $ | 182,756 |  |  |
| Automotive |  |  | 99,205 |  |  |  | — |  |  |  | 99,205 |  |  |  | 63,114 |  |  |  | — |  |  |  | 10,097 |  |  |  | 73,211 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 38 |  |  |  | — |  |  |  | — |  |  |  | 38 |  |  |
| Data Center Computing (2) |  |  | 81,202 |  |  |  | — |  |  |  | 81,202 |  |  |  | 62,554 |  |  |  | 186 |  |  |  | 34 |  |  |  | 62,774 |  |  |
| Medical/Industrial/Instrumentation |  |  | 108,879 |  |  |  | 1,467 |  |  |  | 110,346 |  |  |  | 91,836 |  |  |  | 742 |  |  |  | 2,939 |  |  |  | 95,517 |  |  |
| Networking/Communications |  |  | 74,316 |  |  |  | 12,848 |  |  |  | 87,164 |  |  |  | 74,366 |  |  |  | 7,203 |  |  |  | 8,919 |  |  |  | 90,488 |  |  |
| Other |  |  | 3,622 |  |  |  | 1,339 |  |  |  | 4,961 |  |  |  | 6,845 |  |  |  | 3,431 |  |  |  | (1,484 | ) |  |  | 8,792 |  |  |
| Total |  | $ | 541,118 |  |  | $ | 15,666 |  |  | $ | 556,784 |  |  | $ | 481,311 |  |  | $ | 11,742 |  |  | $ | 20,523 |  |  | $ | 513,576 |  |  |
  (was, 2021-08-04, similarity 0.9379):
[0001564590-21-040796:note_history:31]
|  |  | Quarter Ended June 28, 2021 |  |  | Quarter Ended June 29, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 185,152 |  |  | $ | 6 |  |  | $ | 185,158 |  |  | $ | 188,910 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 188,939 |  |  |
| Automotive |  |  | 102,893 |  |  |  | — |  |  |  | 102,893 |  |  |  | 57,998 |  |  |  | — |  |  |  | 11,583 |  |  |  | 69,581 |  |  |
| Data Center Computing (2) |  |  | 82,230 |  |  |  | 24 |  |  |  | 82,254 |  |  |  | 71,541 |  |  |  | 273 |  |  |  | 36 |  |  |  | 71,850 |  |  |
| Medical/Industrial/Instrumentation |  |  | 104,012 |  |  |  | 1,067 |  |  |  | 105,079 |  |  |  | 115,813 |  |  |  | 800 |  |  |  | 2,988 |  |  |  | 119,601 |  |  |
| Networking/Communications |  |  | 75,728 |  |  |  | 11,950 |  |  |  | 87,678 |  |  |  | 95,416 |  |  |  | 10,560 |  |  |  | 7,446 |  |  |  | 113,422 |  |  |
| Other |  |  | 3,465 |  |  |  | 856 |  |  |  | 4,321 |  |  |  | 7,165 |  |  |  | 449 |  |  |  | (709 | ) |  |  | 6,905 |  |  |
| Total |  | $ | 553,480 |  |  | $ | 13,903 |  |  | $ | 567,383 |  |  | $ | 536,843 |  |  | $ | 12,091 |  |  | $ | 21,364 |  |  | $ | 570,298 |  |  |

- changed (2021-11-02):
[0001564590-21-053547:note_history:32]
|  |  | Three Quarters Ended September 27, 2021 |  |  | Three Quarters Ended September 28, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 545,585 |  |  | $ | 24 |  |  | $ | — |  |  | $ | 545,609 |  |  | $ | 555,882 |  |  | $ | 189 |  |  | $ | 38 |  |  | $ | 556,109 |  |  |
| Automotive |  |  | 293,890 |  |  |  | — |  |  |  | 3,642 |  |  |  | 297,532 |  |  |  | 182,970 |  |  |  | — |  |  |  | 28,693 |  |  |  | 211,663 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,334 |  |  |  | — |  |  |  | — |  |  |  | 1,334 |  |  |
| Data Center Computing (2) |  |  | 235,191 |  |  |  | 456 |  |  |  | — |  |  |  | 235,647 |  |  |  | 192,209 |  |  |  | 663 |  |  |  | 124 |  |  |  | 192,996 |  |  |
| Medical/Industrial/Instrumentation |  |  | 303,661 |  |  |  | 3,615 |  |  |  | 25 |  |  |  | 307,301 |  |  |  | 298,117 |  |  |  | 2,336 |  |  |  | 9,247 |  |  |  | 309,700 |  |  |
| Networking/Communications |  |  | 216,982 |  |  |  | 35,451 |  |  |  | 1 |  |  |  | 252,434 |  |  |  | 240,215 |  |  |  | 19,173 |  |  |  | 20,560 |  |  |  | 279,948 |  |  |
| Other |  |  | 9,775 |  |  |  | 2,713 |  |  |  | (412 | ) |  |  | 12,076 |  |  |  | 21,429 |  |  |  | 10,913 |  |  |  | (2,572 | ) |  |  | 29,770 |  |  |
| Total |  | $ | 1,605,084 |  |  | $ | 42,259 |  |  | $ | 3,256 |  |  | $ | 1,650,599 |  |  | $ | 1,492,156 |  |  | $ | 33,274 |  |  | $ | 56,090 |  |  | $ | 1,581,520 |  |  |
  (was, 2021-08-04, similarity 0.9714):
[0001564590-21-040796:note_history:32]
|  |  | Two Quarters Ended June 28, 2021 |  |  | Two Quarters Ended June 29, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 371,691 |  |  |  | 12 |  |  | $ | — |  |  | $ | 371,703 |  |  | $ | 373,324 |  |  | $ | 9 |  |  | $ | 20 |  |  | $ | 373,353 |  |  |
| Automotive |  |  | 194,685 |  |  |  | — |  |  |  | 3,642 |  |  |  | 198,327 |  |  |  | 119,856 |  |  |  | — |  |  |  | 18,596 |  |  |  | 138,452 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,296 |  |  |  | — |  |  |  | — |  |  |  | 1,296 |  |  |
| Data Center Computing (2) |  |  | 153,989 |  |  |  | 456 |  |  |  | — |  |  |  | 154,445 |  |  |  | 129,655 |  |  |  | 476 |  |  |  | 90 |  |  |  | 130,221 |  |  |
| Medical/Industrial/Instrumentation |  |  | 194,782 |  |  |  | 2,148 |  |  |  | 25 |  |  |  | 196,955 |  |  |  | 206,281 |  |  |  | 1,594 |  |  |  | 6,308 |  |  |  | 214,183 |  |  |
| Networking/Communications |  |  | 142,666 |  |  |  | 22,603 |  |  |  | 1 |  |  |  | 165,270 |  |  |  | 165,849 |  |  |  | 18,627 |  |  |  | 11,641 |  |  |  | 196,117 |  |  |
| Other |  |  | 6,153 |  |  |  | 1,374 |  |  |  | (412 | ) |  |  | 7,115 |  |  |  | 14,584 |  |  |  | 826 |  |  |  | (1,088 | ) |  |  | 14,322 |  |  |
| Total |  | $ | 1,063,966 |  |  | $ | 26,593 |  |  | $ | 3,256 |  |  | $ | 1,093,815 |  |  | $ | 1,010,845 |  |  | $ | 21,532 |  |  | $ | 35,567 |  |  | $ | 1,067,944 |  |  |

- changed (2021-11-02):
[0001564590-21-053547:note_history:33]
| (1) | Other represents results from the now closed SH E-MS and SZ facilities. |
  (was, 2021-08-04, similarity 0.7023):
[0001564590-21-040796:note_history:33]
| (1) | Other represents SH E-MS and SZ results. |
