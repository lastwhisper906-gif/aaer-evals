# TTMI MD&A — 0001564590-22-008035


## mdna

[0001564590-22-008035:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001564590-22-008035:mdna:2]
This financial review presents our operating results for each of our three most recent fiscal years and our financial condition as of January 3, 2022. Except for historical information contained herein, the following discussion contains forward-looking statements which are subject to known and unknown risks, uncertainties and other factors that may cause our actual results to differ materially from those expressed or implied by such forward-looking statements. We discuss such risks, uncertainties and other factors throughout this report and specifically under Item 1A of Part I of this report, Risk Factors. In addition, the following discussion should be read in connection with the information presented in our consolidated financial statements and the related notes to our consolidated financial statements.

[0001564590-22-008035:mdna:3]
COMPANY OVERVIEW

[0001564590-22-008035:mdna:4]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering and manufacturing solution to our customers. This one-stop design, engineering and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,600 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-22-008035:mdna:5]
RECENT DEVELOPMENTS

[0001564590-22-008035:mdna:6]
The coronavirus (COVID-19) pandemic initially caused business disruption to our operations in China in January 2020. By March 2020, the situation escalated as the scope of the COVID-19 pandemic worsened outside of the Asia-Pacific region, with Europe and North America being affected by the pandemic. With the development and deployment of vaccines, certain of the adverse societal and economic effects of the pandemic have declined. However, as new variants of the virus emerge and evolve, we could see a rebound in the severity of the adverse effects of the pandemic. As a result, we expect continued impacts on our production, as well as ongoing significant uncertainty relating to the actual and potential impacts of the COVID-19 pandemic, and we cannot reasonably estimate its duration or severity. The COVID-19 pandemic has created and continues to create various global macroeconomic, customer demand, operational and supply chain risks, any one of which could have a material and adverse impact on our business going forward. See Item 1A, Risk Factors, of Part I above for further information related to the COVID-19 pandemic.

[0001564590-22-008035:mdna:7]
We have taken active measures to seek to protect our employees, suppliers and customers by implementing extensive pandemic related protocols, establishing situational leadership teams in Asia-Pacific and North America along with regularly scheduled executive reviews and planning calls, implementing global travel restrictions, and conforming to the guidance and direction of local governments and global health organizations. We are monitoring the impacts the COVID-19 pandemic has had, and continues to have, on our supply chain and are collaborating with our third-party partners with the goal of mitigating, to the extent reasonably practicable, significant delays in delivery of our products.

[0001564590-22-008035:mdna:8]
During the year ended January 3, 2022, we experienced supply chain constraints and inflationary pressures, and expect those constraints and pressures to continue into 2022. We have been actively taking measures intended to manage both supply chain constraints and higher raw materials costs through such measures as supplier diversification, ongoing operational efficiency efforts and quotation adjustments to mitigate the impact on our business.

[0001564590-22-008035:mdna:9]
We also continue to see more challenges in attracting and retaining labor in North America. We actively seek to demonstrate employees’ value to our business through a combination of financial and non-financial methods.  However, a number of factors may continue to adversely affect the labor force available to us, including high employment levels, government regulations, and wage inflation. An overall labor shortage, lack of skilled labor, increased turnover or labor inflation could have a material adverse impact on our business.

[0001564590-22-008035:mdna:10]
FINANCIAL OVERVIEW

[0001564590-22-008035:mdna:11]
Results related to our Mobility business unit are reported as discontinued operations for all periods presented. See Note 3, Discontinued Operations, of the Notes to Consolidated Financial Statements for further information. Unless otherwise noted, amounts and disclosures throughout our Management’s Discussion and Analysis of Financial Condition and Results of Operations relate to our continuing operations.

[0001564590-22-008035:mdna:12]
We use a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal year 2021 consisted of 53 weeks ended on January 3, 2022, with the additional week included in the fourth quarter. We estimate the additional week contributed approximately $42.2 million of additional revenue and approximately $2.5 million of additional operating income for the year ended January 3, 2022. Fiscal year 2020 and 2019 were 52 weeks ended on December 28, 2020 and December 30, 2019, respectively.

[0001564590-22-008035:mdna:13]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our five largest customers accounted for 30%, 29% and 27% of our net sales in fiscal years 2021, 2020 and 2019, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-22-008035:mdna:14]
The following table shows the percentage of our net sales attributable to each of the principal end markets we serve for the periods indicated:

[0001564590-22-008035:mdna:15]
|  |  | For the Year Ended |  |  |
| End Markets (1) |  | January 3, 2022 |  |  |  | December 28, 2020 |  |  |  | December 30, 2019 |  |  |
| Aerospace and Defense |  |  | 33 |  | % |  |  | 36 |  | % |  |  | 33 |  | % |
| Automotive |  |  | 18 |  |  |  |  | 15 |  |  |  |  | 19 |  |  |
| Data Center Computing (2) |  |  | 14 |  |  |  |  | 12 |  |  |  |  | 11 |  |  |
| Medical/Industrial/Instrumentation |  |  | 19 |  |  |  |  | 18 |  |  |  |  | 17 |  |  |
| Networking/Communications |  |  | 15 |  |  |  |  | 18 |  |  |  |  | 18 |  |  |
| Other (3) |  |  | 1 |  |  |  |  | 1 |  |  |  |  | 2 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-22-008035:mdna:16]
| (1) | Sales to EMS companies are classified by the end markets of their OEM customers. |

[0001564590-22-008035:mdna:17]
| (2) | Beginning in the first quarter of 2021, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |

[0001564590-22-008035:mdna:18]
| (3) | Other end market reflects direct sales to EMS and distributor customers. |

[0001564590-22-008035:mdna:19]
We derive revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of RF and microwave components, assemblies and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and custom electronic assemblies manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0001564590-22-008035:mdna:20]
We also manufacture certain components, assemblies, and subsystems which service our RF and Specialty Components (RF&S Components) customers. We recognize revenue at a point in time upon transfer of control of the products to our customer. Point in time recognition was determined as our customers do not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0001564590-22-008035:mdna:21]
Net sales consist of gross sales less an allowance for returns, which typically have been approximately 2% of gross sales. We provide our customers a limited right of return for defective PCBs including components, subsystems and assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results and anticipated returns.

[0001564590-22-008035:mdna:22]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. While we have entered into supply assurance agreements with some of our key suppliers to maintain the continuity of supply of some of the key materials we use, we generally do not participate in any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for most of the raw materials we use.

[0001564590-22-008035:mdna:23]
Selling and marketing expenses consist primarily of salaries, labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0001564590-22-008035:mdna:24]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001564590-22-008035:mdna:25]
Research and development expenses consist primarily of salaries and labor related benefits paid to our research and development staff, as well as material costs.

[0001564590-22-008035:mdna:26]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0001564590-22-008035:mdna:27]
Our consolidated financial statements included in this report have been prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP). The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001564590-22-008035:mdna:28]
A critical accounting policy is defined as one that is both material to the presentation of our consolidated financial statements and requires us to make judgments that could have a material effect on our financial condition or results of operations. These policies require us to make assumptions about matters that are highly uncertain at the time of the estimate. Critical accounting estimates refers

[0001564590-22-008035:mdna:29]
to those estimates made in accordance with U.S. GAAP that have had or are reasonably likely to have a material impact on the amounts reported in the consolidated financial statements and the related notes due to the significant level of uncertainty involved in developing the estimate. Different estimates we could reasonably have used, or changes in the estimates that are reasonably likely to occur, could have a material effect on our financial condition or results of operations.

[0001564590-22-008035:mdna:30]
We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Management has discussed the development, selection and disclosure of these estimates with the audit committee of our board of directors. Actual results may differ from these estimates under different assumptions or conditions.

[0001564590-22-008035:mdna:31]
We believe the following critical accounting policies and estimates reflect the more significant judgments and estimates used by us in preparing our consolidated financial statements:

[0001564590-22-008035:mdna:32]
Revenue Recognition

[0001564590-22-008035:mdna:33]
Revenue is recognized when control of the promised goods or services is transferred to customers, in an amount that reflects the consideration to which we expect to be entitled in exchange for those goods or services. We apply a five-step approach in determining the amount and timing of revenue to be recognized: (1) identifying the contract with a customer; (2) identifying the performance obligations in the contract; (3) determining the transaction price; (4) allocating the transaction price to the performance obligations in the contract; and (5) recognizing revenue when the corresponding performance obligation is satisfied.

[0001564590-22-008035:mdna:34]
For PCBs and custom electronic assemblies, including pursuant to long-term contracts related to the manufacture of components, assemblies and subsystems, orders for products generally correspond to the production schedules of customers and are supported with firm purchase orders. Customers have continuous control of the work in progress and finished goods throughout the PCB and custom electronic assemblies manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. Revenue recognized is based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0001564590-22-008035:mdna:35]
For revenue recorded on an over time basis, we apply a gross margin estimate to inventory in process of being manufactured for customers to determine how much of a contract asset should be recorded at period end. Contract assets totaled $324.9 million and $273.3 million for the years ended January 3, 2022 and December 28, 2020, respectively. The increase of $51.6 million is primarily due to timing of progress on customer work orders at year-end. We use historical information to estimate the gross margin associated with performance obligations that are satisfied over time. We reevaluate our estimate of gross margins on a quarterly basis. Based on the review of gross margins, we update our estimate to the model as necessary. If our estimates of performance obligations are inaccurate, we may recognize too much or too little revenue in a period. While experience has shown that trends in gross margins are not volatile, changes in pricing or cost efficiencies could create significant fluctuations. A decrease or increase of 200 basis points in gross margin estimates would have increased or decreased our contract assets by $0.6 million.

[0001564590-22-008035:mdna:36]
In addition, the Company manufactures components, assemblies, and subsystems which service its RF&S Components customers. The Company recognizes revenue at a point in time upon transfer of control of the products to the customer. Point in time recognition was determined as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

[0001564590-22-008035:mdna:37]
Goodwill and Intangible Assets

[0001564590-22-008035:mdna:38]
We have significant goodwill and definite-lived intangibles. We review these assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. In addition, we perform an impairment test related to goodwill at least annually. As necessary, we make judgments regarding future cash flow forecasts in the assessment of impairment.

[0001564590-22-008035:mdna:39]
Goodwill is allocated to our reporting units, which are our operating segments or one level below our operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic characteristics. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. We assess qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or perform a quantitative impairment test. When tested quantitatively, we compare the fair value of the applicable reporting unit with its carrying value. We estimate the fair values of our reporting units using a combination of the discounted cash flow (DCF) and market approach. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss.

[0001564590-22-008035:mdna:40]
We have two reportable segments: PCB and RF&S Components. Goodwill is attributable to both of our PCB and RF&S Components reportable segments.

[0001564590-22-008035:mdna:41]
36

[0001564590-22-008035:mdna:42]
In the fourth quarter of 2021, we performed our annual impairment test qualitatively and concluded that it was more likely than not that goodwill was not impaired. Management will continue to monitor the reporting units for changes in the business environment that could impact recoverability. The recoverability of goodwill is dependent upon the continued growth of cash flows from our business activities. If the economy or business environment falter and we are unable to achieve our assumed revenue growth rates or profit margin percentages, our projections used would need to be re-measured, which could impact the carrying value of our goodwill in one or more of our reporting units.

[0001564590-22-008035:mdna:43]
We also assess definite-lived intangibles for potential impairment given similar impairment indicators. When indicators of impairment exist related to our definite-lived intangible assets, we use an estimate of the undiscounted cash flows in measuring whether the carrying amount of the assets is recoverable. If the sum of the undiscounted cash flows is less than the carrying amount of the net assets, impairment is measured based on the difference between the net asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary, which involve judgments related to future cash flows and the application of the appropriate valuation model.

[0001564590-22-008035:mdna:44]
RESULTS OF OPERATIONS

[0001564590-22-008035:mdna:45]
We operate on a 52 or 53 week year ending on the Monday nearest December 31. Fiscal year 2021 consisted of 53 weeks ended on January 3, 2022, with the additional week included in the fourth quarter. We estimate the additional week contributed approximately $42.2 million of additional revenue and approximately $2.5 million of additional operating income for the year ended January 3, 2022. Fiscal year 2020 and 2019 were 52 weeks ended on December 28, 2020 and December 30, 2019, respectively.

[0001564590-22-008035:mdna:46]
The following table sets forth the relationship of various items to net sales in our consolidated statements of operations:

[0001564590-22-008035:mdna:47]
|  |  | For the Year Ended |  |  |
|  |  | January 3, 2022 |  |  |  | December 28, 2020 |  |  |  | December 30, 2019 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 83.5 |  |  |  |  | 83.0 |  |  |  |  | 82.3 |  |  |
| Gross profit |  |  | 16.5 |  |  |  |  | 17.0 |  |  |  |  | 17.7 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.8 |  |  |  |  | 3.0 |  |  |  |  | 3.2 |  |  |
| General and administrative |  |  | 5.5 |  |  |  |  | 5.8 |  |  |  |  | 6.1 |  |  |
| Research and development |  |  | 0.8 |  |  |  |  | 1.0 |  |  |  |  | 0.8 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.6 |  |  |  |  | 1.8 |  |  |  |  | 2.2 |  |  |
| Restructuring charges |  |  | 0.2 |  |  |  |  | 0.8 |  |  |  |  | 0.3 |  |  |
| Impairment of goodwill |  |  | — |  |  |  |  | 3.3 |  |  |  |  | — |  |  |
| Total operating expenses |  |  | 10.9 |  |  |  |  | 15.7 |  |  |  |  | 12.6 |  |  |
| Operating income |  |  | 5.6 |  |  |  |  | 1.3 |  |  |  |  | 5.1 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.0 | ) |  |  |  | (3.5 | ) |  |  |  | (3.8 | ) |  |
| Loss on extinguishment of debt |  |  | (0.7 | ) |  |  |  | — |  |  |  |  | — |  |  |
| Other, net |  |  | 0.2 |  |  |  |  | — |  |  |  |  | 0.3 |  |  |
| Total other expense, net |  |  | (2.5 | ) |  |  |  | (3.5 | ) |  |  |  | (3.5 | ) |  |
| Income (loss) from continuing operations before income taxes |  |  | 3.1 |  |  |  |  | (2.2 | ) |  |  |  | 1.6 |  |  |
| Income tax (provision) benefit |  |  | (0.7 | ) |  |  |  | 1.4 |  |  |  |  | (0.1 | ) |  |
| Net income (loss) from continuing operations |  |  | 2.4 |  | % |  |  | (0.8 | ) | % |  |  | 1.5 |  | % |

[0001564590-22-008035:mdna:48]
During the year ended January 3, 2022, E-M Solutions no longer met the criteria for segment reporting and the SH BPA facility has been integrated into the PCB reportable segment. As a result, we reclassified prior periods to reflect these changes to our segments.

[0001564590-22-008035:mdna:49]
Net Sales

[0001564590-22-008035:mdna:50]
Total net sales increased $143.4 million, or 6.8%, to $2,248.7 million for the year ended January 3, 2022 from $2,105.3 million for the year ended December 28, 2020. This increase primarily resulted from an increase in net sales for the PCB reportable segment of $206.0 million, or 10.4%, to $2,186.9 million for the year ended January 3, 2022 from $1,980.9 million for the year ended December 28, 2020. The increase in PCB net sales was primarily due to increased demand in our Automotive, Data Center Computing, and Medical/Industrial/Instrumentation end markets, partially offset by lower demand in our Aerospace and Defense and Networking/Communications end markets. Also driving the increase in PCB net sales was an increase in the volume of PCB shipments of 24.3% as compared to the year ended December 28, 2020. The benefit of this volume increase, however, was partially offset by a 11.9% decrease in the average price per square foot. Also contributing to the increase in total net sales was an increase in net sales for the RF&S Components reportable segment of $13.9 million, or 31.2%, to $58.6 million for the year ended January 3,

[0001564590-22-008035:mdna:51]
2022 from $44.7 million for the year ended December 28, 2020. The increase in RF&S Components net sales was primarily due to increased demand in our Networking/Communications end market. Partially offsetting the PCB and RF&S Components increases was a $76.5 million reduction in net sales due to the closure of the two plants from our E-M Solutions segment.

[0001564590-22-008035:mdna:52]
Total net sales decreased $27.9 million, or 1.3%, to $2,105.3 million for the year ended December 28, 2020 from $2,133.2 million for the year ended December 30, 2019. This decrease primarily resulted from a decrease in net sales for the Other reportable segment of $81.5 million, or 50.1%, to $79.7 million for the year ended December 28, 2020 from $161.3 million for the year ended December 30, 2019, primarily due to the winding down of the two plants from our E-M Solutions segment and lower demand in our Automotive end market. Also contributing to the decrease in total net sales was a decrease in net sales for the RF&S Components reportable segment of $17.7 million, or 28.3%, to $44.7 million for the year ended December 28, 2020 from $62.3 million for the year ended December 30, 2019. The decrease in RF&S Components net sales was primarily due to U.S.-imposed restrictions on the sale of U.S.-designed products to certain customers in China which, coupled with the impact of COVID-19, resulted in lower demand in our Networking/Communications and Other end markets. The decreases in the Other and RF&S Components reportable segments were partially offset by an increase in net sales for the PCB reportable segment of $71.3 million, or 3.7%, to $1,980.9 million for the year ended December 28, 2020 from $1,909.6 million for the year ended December 30, 2019. The increase in PCB net sales was primarily due to increased demand in our Aerospace and Defense, Medical/Industrial/Instrumentation, and Data Center Computing end markets, partially offset by lower demand in our Automotive end market. Also driving the increase in PCB net sales were changes in product mix, which resulted in a 15.2% increase in the average price per square foot. The benefit of this price increase, however, was partially offset by a 10.1% decrease in the volume of PCB shipments as compared to the year ended December 30, 2019.

[0001564590-22-008035:mdna:53]
For information regarding net sales by country, see Note 17 of the Notes to Consolidated Financial Statements.

[0001564590-22-008035:mdna:54]
Gross Margin

[0001564590-22-008035:mdna:55]
Overall gross margin decreased to 16.5% for the year ended January 3, 2022 from 17.0% for the year ended December 28, 2020. The decrease in overall gross margin was due to the decrease in gross margin for the PCB reportable segment to 16.3% for the year ended January 3, 2022, from 18.1% for the year ended December 28, 2020, primarily due to higher raw material costs resulting primarily from increased commodity prices, principally copper, unfavorable foreign exchange rates which increased our cost of operations, and production and labor inefficiencies. We were able to mitigate most of these cost increases through higher revenue and production and spending efficiencies including savings realized from the closure of two of our E-M Solutions factories at the end of 2020. Gross margin for the RF&S Components reportable segment increased to 52.6% for the year ended January 3, 2022, from 45.9% for the year ended December 28, 2020, primarily due to higher sales.

[0001564590-22-008035:mdna:56]
Overall gross margin decreased to 17.0% for the year ended December 28, 2020 from 17.7% for the year ended December 30, 2019. The decrease in overall gross margin was due to the decrease in gross margin for the RF&S Components reportable segment to 45.9% for the year ended December 28, 2020 from 63.2% for the year ended December 30, 2019, primarily due to lower sales. The lower sales of RF&S Components products was mainly due to restrictions on the sale of U.S.-designed products to certain customers in China. The decrease in overall gross margin was also attributable to lower sales from winding down of the two plants from our E-M Solutions segment. These decreases were partially offset by the gross margin for the PCB reportable segment, which increased to 18.1% for the year ended December 28, 2020 from 17.8% for the year ended December 30, 2019, primarily due to higher volumes at our Aerospace and Defense facilities.

[0001564590-22-008035:mdna:57]
Capacity utilization is a key driver for us, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the year ended January 3, 2022 in our Asia and North America PCB facilities was 86% and 51%, respectively, compared to 62% and 62%, respectively, for the year ended December 28, 2020. The increase in capacity utilization in our Asia facilities was due to an increase in production related to increased sales in our Automotive, Data Center Computing, and Medical/Industrial/Instrumentation end markets. The decrease in our capacity utilization in our North America PCB facilities was primarily due to labor shortages and increased capacity resulting from equipment expansion.

[0001564590-22-008035:mdna:58]
Selling and Marketing Expenses

[0001564590-22-008035:mdna:59]
Selling and marketing expenses decreased $0.9 million to $63.0 million for the year ended January 3, 2022 from $63.9 million for the year ended December 28, 2020. As a percentage of net sales, selling and marketing expenses were 2.8% for the year ended January 3, 2022 as compared to 3.0% for the year ended December 28, 2020. The decrease in selling and marketing expenses in 2021 was primarily due to a decrease in commission expense.

[0001564590-22-008035:mdna:60]
Selling and marketing expenses decreased $5.3 million to $63.9 million for the year ended December 28, 2020 from $69.2 million for the year ended December 30, 2019. As a percentage of net sales, selling and marketing expenses were 3.0% for the year ended December 28, 2020 as compared to 3.2% for the year ended December 30, 2019. The decrease in selling and marketing expenses in 2020 was primarily due to reduced travel expense and other costs as a result of the COVID-19 pandemic, which has decreased travel on a temporary basis and commission expense.

[0001564590-22-008035:mdna:61]
General and Administrative Expenses

[0001564590-22-008035:mdna:62]
General and administrative expenses increased $2.4 million to $124.9 million, or 5.5% of net sales, for the year ended January 3, 2022 from $122.5 million, or 5.8% of net sales, for the year ended December 28, 2020. This increase was primarily due to an increase in labor costs and other general and administrative spending, including increased consulting and legal costs.

[0001564590-22-008035:mdna:63]
General and administrative expenses decreased $6.8 million to $122.5 million, or 5.8% of net sales, for the year ended December 28, 2020 from $129.3 million, or 6.1% of net sales, for the year ended December 30, 2019. This decrease was primarily due to a decrease in acquisition costs and cost reduction efforts as a result of the COVID-19 pandemic.

[0001564590-22-008035:mdna:64]
Restructuring Charges

[0001564590-22-008035:mdna:65]
For the years ended January 3, 2022, December 28, 2020 and December 30, 2019, we incurred restructuring charges of $4.2 million, $16.8 million and $5.4 million, respectively, related to the restructuring of our E-M Solutions business unit and other global realignment restructuring efforts.

[0001564590-22-008035:mdna:66]
For the year ended January 3, 2022, we recognized restructuring charges of $0.6 million and $3.6 million in our PCB reportable segment and Corporate and Other, respectively. For the year ended December 28, 2020, we recognized restructuring charges of $16.8 million in Corporate and Other. For the year ended December 30, 2019, we recognized restructuring charges of $5.2 million and $0.1 million in our PCB and RF&S Components reportable segments, respectively, and $0.1 million in Corporate and Other. These charges primarily represent employee separation and contract termination and other costs associated with the restructuring plans.

[0001564590-22-008035:mdna:67]
Impairment of Goodwill

[0001564590-22-008035:mdna:68]
For the year ended December 28, 2020, we recorded a goodwill impairment charge of $69.2 million. See Note 5 of the Notes to Consolidated Financial Statements for further information.

[0001564590-22-008035:mdna:69]
Other Expense

[0001564590-22-008035:mdna:70]
Other expense, net decreased $18.4 million to $55.9 million for the year ended January 3, 2022 from $74.4 million for the year ended December 28, 2020. The decrease in other expense, net was primarily due to:

[0001564590-22-008035:mdna:71]
|  | • | a decrease in interest expense of $27.7 million due to overall lower levels of debt outstanding, |

[0001564590-22-008035:mdna:72]
|  | • | an increase in other income of $4.2 million for the year ended January 3, 2022 related to the change in fair value of warrant liabilities, |

[0001564590-22-008035:mdna:73]
|  | • | partially offset by $15.2 million of loss on extinguishment of debt. |

[0001564590-22-008035:mdna:74]
Other expense, net decreased $0.9 million to $74.4 million for the year ended December 28, 2020 from $75.3 million for the year ended December 30, 2019. The decrease in other expense, net was primarily due to:

[0001564590-22-008035:mdna:75]
|  | • | a decrease in interest expense of $8.9 million mainly as a result of a $400.0 million debt principal prepayment for the Term Loan made during the year ended December 28, 2020 and lower interest rates, |

[0001564590-22-008035:mdna:76]
|  | • | partially offset by an increase in foreign currency losses due to the strengthening of the Chinese Renminbi (RMB) during the year ended December 28, 2020 compared to the year ended December 30, 2019. We utilize the RMB at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China. |

[0001564590-22-008035:mdna:77]
Income Taxes

[0001564590-22-008035:mdna:78]
The provision for income taxes increased $45.5 million to an income tax expense of $15.6 million for the year ended January 3, 2022 from an income tax benefit of $29.9 million for the year ended December 28, 2020. The change in income tax from a benefit to an expense in 2021 was primarily due to an increase in pre-tax book income, the absence of beneficial tax examination settlement in 2020, and an increase in the valuation allowance set up against certain state tax credits. The increase in tax expense was partially offset by a tax benefit related to the retroactive approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China (including the impact on the respective subsidiaries’ deferred tax amounts).

[0001564590-22-008035:mdna:79]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the US federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us, as well as changes in valuation allowances, certain non-deductible items, global intangible low taxed income, and the establishment of a deferred tax liability related to unremitted foreign earnings.

[0001564590-22-008035:mdna:80]
The provision for income taxes decreased $32.3 million to an income tax benefit of $29.9 million for the year ended December 28, 2020 from an income tax expense of $2.4 million for the year ended December 30, 2019. The change in income tax from an expense to a benefit in 2020 was primarily due to the release of uncertain tax positions in 2020 totaling $34.7 million as a result of statute of limitation expirations and the conclusion of a tax exam. This was partially offset by tax expense related to the retroactive approval of the Company’s renewal application for High and New Tax Enterprise status for one of the Company’s manufacturing

[0001564590-22-008035:mdna:81]
subsidiaries in China (including the impact on the respective Company’s deferred tax assets) and by an increase in the deferred tax liability related to unremitted foreign earnings.

[0001564590-22-008035:mdna:82]
Liquidity and Capital Resources

[0001564590-22-008035:mdna:83]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our Revolving Credit Facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, to repay debt obligations, and to repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and potential share repurchases will be the principal demands on our cash in the future.

[0001564590-22-008035:mdna:84]
Cash flow provided by operating activities from continuing operations during the year ended January 3, 2022 was $176.6 million as compared to $247.7 million in the same period in 2020. The decrease in cash flow was primarily due to increased investment in working capital and the collection of Mobility-related accounts receivable after the sale of the business unit in 2020. See Note 3, Discontinued Operations, of the Notes to Consolidated Financial Statements for further information. This is partially offset by an increase in net income from continuing operations of $70.8 million.

[0001564590-22-008035:mdna:85]
Net cash used in investing activities for continuing operations was approximately $84.1 million for the year ended January 3, 2022, primarily reflecting $82.0 million for purchases of property, plant and equipment and other assets, $3.2 million investment in unconsolidated joint venture, less $1.4 million for proceeds from sale of property, plant and equipment and other assets. Net cash used in investing activities for continuing operations was approximately $93.6 million for the year ended December 28, 2020 comprised primarily of purchases of property, plant and equipment and other assets.

[0001564590-22-008035:mdna:86]
Net cash used in financing activities for continuing operations during the year ended January 3, 2022 was $7.2 million, primarily reflecting repayment of long-term debt of $425.8 million, repurchases of common stock of $64.7 million, capital equipment financing of $7.5 million, payment of debt issuance costs of $6.0 million, and cash used to settle warrants of $3.2 million, less the proceeds from long-term debt borrowing of $500.0 million. Net cash used in financing activities for continuing operations was approximately $642.3 million for the year ended December 28, 2020, primarily reflecting repayment of long-term debt of $650.0 million.

[0001564590-22-008035:mdna:87]
We received pre-tax proceeds from the sale of the Mobility business unit, net of cash disposed, of $507.5 million during the year ended December 28, 2020, which have been presented in the consolidated statements of cash flows within net cash provided by investing activities from discontinued operations.

[0001564590-22-008035:mdna:88]
As of January 3, 2022, we had cash and cash equivalents of approximately $537.7 million, of which approximately $201.8 million was held by our foreign subsidiaries, primarily in China. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for the repatriation of this cash.

[0001564590-22-008035:mdna:89]
Our 2022 capital expenditure plan is expected to be in the range of $90.0 million to $110.0 million.

[0001564590-22-008035:mdna:90]
Share Repurchases

[0001564590-22-008035:mdna:91]
On February 3, 2021, our board of directors authorized a share repurchase program allowing us to repurchase up to $100.0 million of our common stock. During 2021, we repurchased a total of 4.7 million shares of our common stock for $64.7 million (including commissions). Under the authorization, which expires on February 3, 2023, we expect to repurchase additional shares, which may be in open market or in private transactions.

[0001564590-22-008035:mdna:92]
Long-term Debt and Letters of Credit

[0001564590-22-008035:mdna:93]
As of January 3, 2022, we had $927.8 million of outstanding debt, net of discount and debt issuance costs, composed of $494.5 million of Senior Notes due March 2029, $403.3 million of a Term Loan due September 2024, and $30.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL).

[0001564590-22-008035:mdna:94]
Pursuant to the terms of the Term Loan Facility and Senior Notes due 2029, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of January 3, 2022, we were in compliance with the covenants under the Term Loan Facility, Senior Notes due 2029 and ABL Revolving Loans.

[0001564590-22-008035:mdna:95]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next twelve months. Additional information regarding our indebtedness, including information about the credit available under our debt facilities, interest rates and other key terms of our outstanding indebtedness, is included in Note 7 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001564590-22-008035:mdna:96]
Contractual Obligations and Commitments

[0001564590-22-008035:mdna:97]
As part of our ongoing operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, derivative liabilities, purchase obligations, and leases as of January 3, 2022.

[0001564590-22-008035:mdna:98]
A summary of our long-term debt obligations as of January 3, 2022 is included in Note 7 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001564590-22-008035:mdna:99]
Our aggregate interest on debt obligations as of January 3, 2022 amounted to $178.7 million, which are expected to be settled as follows: $31.1 million within 1 year, $59.2 million within 1-3 years, $40.0 million within 4-5 years, and $48.4 million after 5 years. For debt obligations based on variable rates, interest rates used are as of January 3, 2022.

[0001564590-22-008035:mdna:100]
Our derivative liabilities of $4.3 million as of January 3, 2022 are expected to be settled within one year.

[0001564590-22-008035:mdna:101]
We also have outstanding firm purchase orders with certain suppliers for the purchase of inventory. These purchase orders are generally short-term in nature. Orders for standard, or catalog, items can typically be canceled with little or no financial penalty. Our policy regarding non-standard or customized items dictates that such items are only ordered specifically for customers who have contractually assumed liability for the inventory, although exceptions are made to this policy in certain situations. In addition, a substantial portion of catalog items covered by our purchase orders are procured for specific customers based on their purchase orders or a forecast under which the customer has contractually assumed liability for such material. Accordingly, our liability from purchase obligations under these purchase orders is not expected to be significant.

[0001564590-22-008035:mdna:102]
A summary of our lease obligations as of January 3, 2022 is included in Note 2 of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001564590-22-008035:mdna:103]
Off-Balance Sheet Arrangements

[0001564590-22-008035:mdna:104]
We do not have any relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, which would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes. In addition, we do not engage in trading activities involving non-exchange traded contracts. As a result, we are not materially exposed to any financing, liquidity, market, or credit risk that could arise if we had engaged in these relationships.

[0001564590-22-008035:mdna:105]
Seasonality

[0001564590-22-008035:mdna:106]
Historically, we experienced significant seasonality in revenues with a softer first half of the fiscal year and generally ramping volumes in the third quarter which usually peaked in the fourth quarter. After the divestiture of our former Mobility business unit in 2020, this pattern has changed. Barring end market demand changes, we now tend to experience modest seasonal softness in the first and third quarters due to holidays and vacation periods in China and North America, respectively, which limit production leading to stronger revenue levels in the second and fourth quarters.

[0001564590-22-008035:mdna:107]
Recently Issued Accounting Standards

[0001564590-22-008035:mdna:108]
For a description of recently adopted and issued accounting standards, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Note 1 of the Notes to Consolidated Financial Statements.
