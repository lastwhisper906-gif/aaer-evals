# TTMI notes — 0001564590-22-008035


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001564590-22-008035:notes:1]
Portions of the registrant’s definitive Proxy Statement for its 2022 Annual Meeting of Stockholders are incorporated by reference into Part III of this report. Such Proxy Statement will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-22-008035:notes:2]
| (1) | Nature of Operations and Summary of Significant Accounting Policies |

[0001564590-22-008035:notes:3]
Nature of Operations

[0001564590-22-008035:notes:4]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This one-stop design, engineering and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001564590-22-008035:notes:5]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-22-008035:notes:6]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale that was completed on April 17, 2020 of the following now former Company subsidiaries: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). For all periods presented in the consolidated statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. See Note 3, Discontinued Operations, for additional information.

[0001564590-22-008035:notes:7]
The Company operates on a 52 or 53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal year 2021 consisted of 53 weeks ended on January 3, 2022, with the additional week included in the fourth quarter. Fiscal year 2020 and 2019 were 52 weeks ended on December 28, 2020 and December 30, 2019, respectively. All references to years relate to fiscal years unless otherwise noted.

[0001564590-22-008035:notes:8]
Reclassifications

[0001564590-22-008035:notes:9]
The Company currently has two reportable segments: PCB and RF and Specialty Components (RF&S Components). On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting. As a result of the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.

[0001564590-22-008035:notes:10]
Use of Estimates

[0001564590-22-008035:notes:11]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amount of revenues and expenses during the reporting period. These estimates and assumptions are based on management’s best estimates and judgment. Due to the coronavirus (COVID-19) global pandemic, the global economy and financial markets have been volatile, have contributed to disruptions in global supply chains and labor shortages, and there is a significant amount of uncertainty about the length and severity of the consequences caused by the ongoing pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Management evaluates its estimates and assumptions on an ongoing basis using historical experience and other factors, including the economic environment, which management believes to be reasonable under the circumstances. Management adjusts such estimates and assumptions when facts and circumstances dictate. The actual results the Company experienced may differ materially and adversely from its estimates. To the extent there are material differences between the estimates and actual results, the Company’s future result of operations will be affected.

[0001564590-22-008035:notes:12]
Principles of Consolidation

[0001564590-22-008035:notes:13]
The consolidated financial statements include the accounts of TTM and its subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001564590-22-008035:notes:14]
Foreign Currency Translation and Transactions

[0001564590-22-008035:notes:15]
The functional currency of certain of the Company’s subsidiaries is the Chinese Renminbi (RMB). Accordingly, assets and liabilities are translated into U.S. dollars using period-end exchange rates. Sales and expenses are translated at the average exchange rates in effect during the period. The resulting translation gains or losses are recorded as a component of accumulated other comprehensive (loss) income in the consolidated statement of stockholders’ equity and the consolidated statement of comprehensive income. Net losses resulting from foreign currency remeasurements and transactions are included in expenses as a component of other, net in the consolidated statements of operations and totaled $5,033, $10,475 and $467 for the years ended January 3, 2022, December 28, 2020 and December 30, 2019, respectively.

[0001564590-22-008035:notes:16]
Cash Equivalents

[0001564590-22-008035:notes:17]
The Company considers highly liquid investments with insignificant interest rate risk and original maturities to the Company of three months or less to be cash equivalents.

[0001564590-22-008035:notes:18]
Accounts Receivable and Allowance for Doubtful Accounts

[0001564590-22-008035:notes:19]
Accounts receivable are reflected at estimated net realizable value, do not bear interest and do not generally require collateral. The Company performs credit evaluations of its customers and adjusts credit limits based upon payment history and the customer’s current creditworthiness. The Company maintains an allowance for doubtful accounts based upon a variety of factors. The Company considers both current and forecasted future economic conditions in determining the adequacy of its allowance for doubtful accounts.

[0001564590-22-008035:notes:20]
The Company’s allowance for doubtful accounts was $1,558, $2,886, and $1,929 as of January 3, 2022, December 28, 2020 and December 30, 2019, respectively.

[0001564590-22-008035:notes:21]
Inventories

[0001564590-22-008035:notes:22]
Inventories are stated at the lower of cost (determined on a first-in, first-out and weighted average basis) or net realizable value. Assessments to value the inventory at the lower of the actual cost to purchase and/or manufacture the inventory, or net realizable value of the inventory, are based upon assumptions about future demand and market conditions. As a result of the Company’s assessments, when the net realizable value of inventory is less than the carrying value, the inventory cost is written down to the net realizable value and the write down is recorded as a charge to cost of goods sold.

[0001564590-22-008035:notes:23]
Property, Plant and Equipment, Net

[0001564590-22-008035:notes:24]
Property, plant and equipment are recorded at cost. Depreciation expense is computed using the straight-line method over the estimated useful lives of the assets. Assets recorded under leasehold improvements are amortized using the straight-line method over the lesser of their useful lives or the related lease term. The Company uses the following estimated useful lives:

[0001564590-22-008035:notes:25]
| Land use rights |  | 50-99 years |
| Buildings and improvements |  | 7-50 years |
| Machinery and equipment |  | 3-10 years |
| Furniture and fixtures |  | 3-7 years |

[0001564590-22-008035:notes:26]
Upon retirement or other disposition of property, plant and equipment, the cost and related accumulated depreciation are removed from the accounts. The resulting gain or loss is included in the determination of operating income in the period incurred. Depreciation and amortization expense on property, plant and equipment was $85,942, $99,572, and $93,370 for the years ended January 3, 2022, December 28, 2020 and December 30, 2019, respectively.

[0001564590-22-008035:notes:27]
The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is amortized over the average useful lives of such assets, which primarily consist of buildings and machinery and equipment. The Company capitalized interest costs of $936, $1,783 and $1,810 during the years ended January 3, 2022, December 28, 2020 and December 30, 2019, respectively, in connection with various capital projects.

[0001564590-22-008035:notes:28]
Major renewals and betterments are capitalized and depreciated over their estimated useful lives while minor expenditures for maintenance and repairs are included in operating income as incurred.

[0001564590-22-008035:notes:29]
Goodwill

[0001564590-22-008035:notes:30]
Goodwill represents the excess of purchase price of an acquisition over the fair value of net assets acquired. Goodwill is not amortized but instead is assessed for impairment, at a reporting unit level, annually and when events and circumstances warrant an evaluation. Goodwill is allocated to reporting units, which are operating segments or one level below the Company’s operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar

[0001564590-22-008035:notes:31]
economic characteristics. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. The Company assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or performs a quantitative impairment test. When tested quantitatively, the Company compares the fair value of the applicable reporting unit with its carrying value. In making this assessment, management relies on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, business trends and declines in the Company’s market capitalization. The Company estimates the fair values of its reporting units using a combination of the discounted cash flow (DCF) and market approaches. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss. See Note 5 for further details.

[0001564590-22-008035:notes:32]
Intangible Assets

[0001564590-22-008035:notes:33]
Intangible assets include customer relationships and technology, which are being amortized over their estimated useful lives on a straight-line basis. The estimated useful lives of such intangibles range from 5 years to 13 years.

[0001564590-22-008035:notes:34]
Impairment of Long-lived Assets

[0001564590-22-008035:notes:35]
Long-lived tangible assets, including property, plant and equipment, assets held for sale, and definite-lived intangible assets, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of the asset or asset groups may not be recoverable. The Company regularly evaluates whether events or circumstances have occurred that indicate possible impairment and relies on a number of factors, including expected future operating results, business plans, economic projections, and anticipated future cash flows. The Company uses an estimate of the future undiscounted net cash flows of the related asset or asset group over the remaining life in measuring whether the assets are recoverable. If the sum of the undiscounted cash flows is less than the carrying amount of the net assets, impairment is measured based on the difference between the net asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary.

[0001564590-22-008035:notes:36]
The Company classifies assets to be sold as assets held for sale when (i) Company management has approved and commits to a plan to sell the asset; (ii) the asset is available for immediate sale in its present condition and is ready for sale; (iii) an active program to locate a buyer and other actions required to sell the asset have been initiated; (iv) the sale of the asset is probable; (v) the asset is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and (vi) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn. Assets classified as held for sale are recorded at the lower of the carrying amount or fair value less the cost to sell.

[0001564590-22-008035:notes:37]
The Company classifies assets held for use when a decision to dispose of an asset or a business is made and the held for sale criteria are not met. In evaluating the recoverability of property and intangible assets subject to amortization, in a held for use business, the carrying value is first compared to the sum of the undiscounted cash flows expected to result from the use and eventual disposition. If the carrying value exceeds the undiscounted expected cash flows, then a fair value analysis is performed. An impairment charge is recognized if the carrying value exceeds the fair value.

[0001564590-22-008035:notes:38]
Leases

[0001564590-22-008035:notes:39]
The Company determines if an arrangement is a lease at inception. Operating leases are included in operating lease right-of-use (ROU) assets, and lease liabilities are included in other current liabilities and operating lease liabilities on the consolidated balance sheets. Finance lease ROU assets are included in property, plant and equipment, net and lease liabilities are included in other current liabilities and other long-term liabilities on the consolidated balance sheets.

[0001564590-22-008035:notes:40]
ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments arising from the lease. Operating and finance lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date in determining the present value of lease payments. The operating and finance lease ROU assets also include any lease payments made and excludes lease incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Operating lease expense is recognized on a straight-line basis over the lease term. Finance lease expense is recognized based on the effective interest method over the lease term.

[0001564590-22-008035:notes:41]
The Company has lease agreements with lease and non-lease components and accounts for the lease and non-lease components as a single lease component.

[0001564590-22-008035:notes:42]
Revenue Recognition

[0001564590-22-008035:notes:43]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as the design and manufacture of RF and microwave components and assemblies. In the absence

[0001564590-22-008035:notes:44]
of a sales agreement, the Company’s standard terms and conditions apply. Revenue is recognized when control of the promised goods or services is transferred to the Company’s customers, in an amount that reflects the consideration to which it expects to be entitled in exchange for those goods or services. The Company applies a five-step approach in determining the amount and timing of revenue to be recognized: (1) identifying the contract with a customer; (2) identifying the performance obligations in the contract; (3) determining the transaction price; (4) allocating the transaction price to the performance obligations in the contract; and (5) recognizing revenue when the corresponding performance obligation is satisfied.

[0001564590-22-008035:notes:45]
Revenue Streams

[0001564590-22-008035:notes:46]
For PCBs and custom electronic assemblies, including pursuant to the Company’s long-term contracts related to the manufacture of components, assemblies and subsystems, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous control of the work in progress and finished goods throughout the PCB and custom electronic assemblies manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, the Company recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation. Revenue recognized is based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0001564590-22-008035:notes:47]
In addition, the Company manufactures components, assemblies, and subsystems which service its RF&S Components customers. The Company recognizes revenue at a point in time upon transfer of control of the products to the customer. Point in time recognition was determined as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

[0001564590-22-008035:notes:48]
Performance Obligations

[0001564590-22-008035:notes:49]
Each distinct promise to transfer products is considered to be an identified performance obligation for which revenue is recognized upon transfer of control of the products to the customer. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. As of January 3, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations for the Company’s long-term contracts was $8,071. The Company expects to recognize revenue on approximately 80% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.

[0001564590-22-008035:notes:50]
Transaction Price

[0001564590-22-008035:notes:51]
The Company provides customers a limited right of return for defective PCBs including components, subsystems and assemblies. Estimates of returns are treated as variable consideration for purposes of determining the transaction price. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns. To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of other current liabilities on the consolidated balance sheets. Shipping and handling fees and related freight costs and supplies associated with shipping products to customers are included as a component of cost of goods sold. Warranty-related services are not considered a separate performance obligation. Incremental warranty costs that are not related to sales returns are recorded in other current liabilities on the consolidated balance sheets and cost of goods sold on the consolidated statements of operations. The following summarizes the activity in the Company’s sales returns and allowances for the years ended January 3, 2022, December 28, 2020 and December 30, 2019:

[0001564590-22-008035:notes:52]
|  |  | For the Year Ended |  |
|  |  | January 3, |  |  | December 28, |  |  | December 30, |  |
|  |  | 2022 |  |  | 2020 |  |  | 2019 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 13,015 |  |  | $ | 12,717 |  |  | $ | 15,296 |  |
| Addition charged as a reduction of sales |  |  | 5,635 |  |  |  | 7,658 |  |  |  | 15,632 |  |
| Deductions |  |  | (5,767 | ) |  |  | (7,389 | ) |  |  | (18,228 | ) |
| Effect of foreign currency exchange rates |  |  | (30 | ) |  |  | 29 |  |  |  | 17 |  |
| Balance at end of year |  | $ | 12,853 |  |  | $ | 13,015 |  |  | $ | 12,717 |  |

[0001564590-22-008035:notes:53]
Contract Balances

[0001564590-22-008035:notes:54]
Accounts receivable represents the Company’s unconditional right to receive consideration from its customer. Payments are generally due within 90 days or less of invoicing and do not include a significant financing component. To date, there have been no material credit losses on accounts receivable.

[0001564590-22-008035:notes:55]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified as current assets and are transferred to receivables when the entitlement to payment becomes unconditional. The Company’s contract assets are generally converted to trade account receivables within 90 days, at which time the Company is entitled to payment of the fixed price upon delivery of the finished product subject to customer payment terms. Contract assets were $324,862 and $273,256 as of January 3, 2022 and December 28, 2020, respectively, and represent unbilled amounts for work performed to date. In 2021, there were no material impairment losses on contract assets.

[0001564590-22-008035:notes:56]
A contract liability is recognized when the Company has received payment in advance for the future transfer of goods or services. The Company’s contract liabilities are generally converted to revenue within 180 days. Contract liabilities were $14,189 and $4,254 as of January 3, 2022 and December 28, 2020, respectively, and represent customer advances for work yet to be performed.

[0001564590-22-008035:notes:57]
The change in the balances of the Company’s contract assets and liabilities primarily results from timing differences between revenue recognition and customer billings and/or payments.

[0001564590-22-008035:notes:58]
The Company has elected to account for shipping and handling activities as a fulfillment cost as permitted by the standard. All incremental customer contract acquisition costs are expensed as they are incurred as the amortization period of the asset that the Company otherwise would have recognized is one year or less in duration.

[0001564590-22-008035:notes:59]
Disaggregated Revenue

[0001564590-22-008035:notes:60]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue in 2021, and 98% and 2%, respectively, of the Company’s revenue in 2020 and 2019.

[0001564590-22-008035:notes:61]
The following tables represent a disaggregation of revenue by principal end markets with the reportable segments:

[0001564590-22-008035:notes:62]
|  |  | For the Year Ended January 3, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 727,868 |  |  | $ | 137 |  |  | $ | — |  |  | $ | 728,005 |  |  |
| Automotive |  |  | 407,063 |  |  |  | — |  |  |  | 3,642 |  |  |  | 410,705 |  |  |
| Data Center Computing (2) |  |  | 323,528 |  |  |  | 457 |  |  |  | — |  |  |  | 323,985 |  |  |
| Medical/Industrial/Instrumentation |  |  | 416,504 |  |  |  | 4,880 |  |  |  | 25 |  |  |  | 421,409 |  |  |
| Networking/Communications |  |  | 297,569 |  |  |  | 49,059 |  |  |  | 1 |  |  |  | 346,629 |  |  |
| Other |  |  | 14,369 |  |  |  | 4,050 |  |  |  | (412 | ) |  |  | 18,007 |  |  |
| Total |  | $ | 2,186,901 |  |  | $ | 58,583 |  |  | $ | 3,256 |  |  | $ | 2,248,740 |  |  |

[0001564590-22-008035:notes:63]
|  |  | For the Year Ended December 28, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 745,050 |  |  | $ | 189 |  |  | $ | 646 |  |  | $ | 745,885 |  |  |
| Automotive |  |  | 269,755 |  |  |  | — |  |  |  | 49,100 |  |  |  | 318,855 |  |  |
| Cellular Phone |  |  | 1,341 |  |  |  | — |  |  |  | — |  |  |  | 1,341 |  |  |
| Data Center Computing (2) |  |  | 258,078 |  |  |  | 834 |  |  |  | 124 |  |  |  | 259,036 |  |  |
| Medical/Industrial/Instrumentation |  |  | 375,106 |  |  |  | 2,967 |  |  |  | 9,622 |  |  |  | 387,695 |  |  |
| Networking/Communications |  |  | 308,421 |  |  |  | 39,160 |  |  |  | 23,003 |  |  |  | 370,584 |  |  |
| Other |  |  | 23,167 |  |  |  | 1,506 |  |  |  | (2,747 | ) |  |  | 21,926 |  |  |
| Total |  | $ | 1,980,918 |  |  | $ | 44,656 |  |  | $ | 79,748 |  |  | $ | 2,105,322 |  |  |

[0001564590-22-008035:notes:64]
|  |  | For the Year Ended December 30, 2019 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 696,287 |  |  | $ | 777 |  |  | $ | 535 |  |  | $ | 697,599 |  |  |
| Automotive |  |  | 302,194 |  |  |  | — |  |  |  | 101,911 |  |  |  | 404,105 |  |  |
| Cellular Phone |  |  | 1,224 |  |  |  | — |  |  |  | — |  |  |  | 1,224 |  |  |
| Data Center Computing (2) |  |  | 235,697 |  |  |  | 1,588 |  |  |  | 206 |  |  |  | 237,491 |  |  |
| Medical/Industrial/Instrumentation |  |  | 332,545 |  |  |  | 3,752 |  |  |  | 28,688 |  |  |  | 364,985 |  |  |
| Networking/Communications |  |  | 317,536 |  |  |  | 43,333 |  |  |  | 30,205 |  |  |  | 391,074 |  |  |
| Other |  |  | 24,145 |  |  |  | 12,865 |  |  |  | (278 | ) |  |  | 36,732 |  |  |
| Total |  | $ | 1,909,628 |  |  | $ | 62,315 |  |  | $ | 161,267 |  |  | $ | 2,133,210 |  |  |

[0001564590-22-008035:notes:65]
| (1) | Other represents results from the now closed SH E-MS and SZ facilities. |

[0001564590-22-008035:notes:66]
| (2) | Beginning in the first quarter of 2021, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |

[0001564590-22-008035:notes:67]
Value Added and Sales Tax Collected from Customers

[0001564590-22-008035:notes:68]
As a part of the Company’s normal course of business, value added and sales taxes are collected from customers. Such taxes collected are remitted, in a timely manner, to the appropriate governmental tax authority on behalf of the customer. Value added and sales taxes are excluded from reported revenues and costs of goods sold presented in the consolidated statements of operations and comprehensive income.

[0001564590-22-008035:notes:69]
Stock-Based Compensation

[0001564590-22-008035:notes:70]
The Company recognizes stock-based compensation expense in its consolidated financial statements for its incentive compensation plan awards. The incentive compensation plan awards include performance-based restricted stock units, restricted stock units, and stock options. The associated compensation expense for all awards is based on the grant date fair value of the awards. For performance-based restricted stock units, compensation expense also includes management’s periodic assessment of annual financial performance goals to be achieved. Compensation expense for the incentive compensation plan awards is recognized on a straight line basis over the vesting period of the awards. The fair value of performance-based restricted stock units is estimated on the grant date using a Monte Carlo simulation model based on the underlying common stock closing price as of the date of grant, stock price volatility, and risk-free interest rates. The fair value of restricted stock units is measured on the grant date based on the quoted closing market price of the Company’s common stock. The fair value of the stock options is estimated on the grant date using the Black-Scholes option pricing model based on the underlying common stock closing price as of the date of grant, the expected term, stock price volatility, and risk-free interest rates.

[0001564590-22-008035:notes:71]
Income Taxes

[0001564590-22-008035:notes:72]
Income taxes are accounted for under the asset and liability method. Deferred income tax assets or liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of assets and liabilities and their respective tax bases and operating loss and tax credit carryforwards. Deferred income tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be settled or realized. The effect on deferred income tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax assets are reviewed for recoverability, and the Company records a valuation allowance to reduce its deferred income tax assets when it is more likely than not that all or some portion of the deferred income tax assets will not be realized.

[0001564590-22-008035:notes:73]
The Company has various foreign subsidiaries formed or acquired to conduct or support its business outside the United States. The Company expects its earnings attributable to foreign subsidiaries will not be indefinitely reinvested except in certain circumstances where we have established a deferred tax liability for foreign withholding and estimated federal/state tax impact. For those other companies with earnings currently being reinvested outside of the U.S., no deferred tax liabilities on undistributed earnings are recorded.

[0001564590-22-008035:notes:74]
The Company recognizes the effect of income tax positions only if those positions are more likely than not to be sustained. Recognized income tax positions are measured at the largest amount that is greater than 50 percent likely to be realized. Changes in recognition or measurement are reflected in the period in which the change in judgment occurs. Estimated interest and penalties related to underpayment of income taxes are recorded as a component of income tax provision in the consolidated statements of operations.

[0001564590-22-008035:notes:75]
Fair Value Measures

[0001564590-22-008035:notes:76]
The Company measures at fair value certain of its financial and non-financial assets and liabilities by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability. The levels of the fair value hierarchy are:

[0001564590-22-008035:notes:77]
Level 1 — Quoted market prices in active markets for identical assets or liabilities;

[0001564590-22-008035:notes:78]
Level 2 — Significant other observable inputs (e.g., quoted prices for similar items in active markets, quoted prices for identical or similar items in markets that are not active, inputs other than quoted prices that are observable, such as interest rate and yield curves, and market-corroborated inputs); and

[0001564590-22-008035:notes:79]
Level 3 — Unobservable inputs in which there is little or no market data, which require the reporting unit to develop its own assumptions.

[0001564590-22-008035:notes:80]
Earnings Per Share

[0001564590-22-008035:notes:81]
Basic earnings per common share excludes dilution and is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted earnings per common share reflect the potential dilution that could occur if stock options, Convertible Senior Notes or other common stock equivalents were exercised or converted into common stock. The dilutive effect of stock options or other common stock equivalents is calculated using the treasury stock method. During the year ended December 28, 2020, the Company calculated the dilutive effect of Convertible Senior Notes using the treasury stock method because the Company repaid and settled the Convertible Senior Notes in cash. This change in policy from the if-converted method to treasury stock method was applied on a prospective basis.

[0001564590-22-008035:notes:82]
Comprehensive Income

[0001564590-22-008035:notes:83]
Comprehensive income includes changes to equity accounts that were not the result of transactions with stockholders. Comprehensive income is comprised of net income, changes in the cumulative foreign currency translation adjustments, pension obligation adjustments, and realized and unrealized gains or losses on hedged derivative instruments.

[0001564590-22-008035:notes:84]
Loss Contingencies

[0001564590-22-008035:notes:85]
The Company establishes an accrual for an estimated loss contingency when it is both probable that an asset has been impaired or that a liability has been incurred and the amount of the loss can be reasonably estimated. Any legal fees expected to be incurred in connection with a contingency are expensed as incurred.

[0001564590-22-008035:notes:86]
Accounting for Retirement Benefit Plans

[0001564590-22-008035:notes:87]
The Company accounts for its retirement benefit plans and postretirement and postemployment benefit obligations in accordance with ASC Topic 715, Compensation—Retirement Benefits. ASC Topic 715 requires the Company to recognize the overfunded or underfunded status of a defined benefit plan, measured as the difference between the fair value of plan assets and the plan's benefit obligation, as an asset or liability in its consolidated balance sheets and to recognize changes to that funded status in the year in which the changes occur through accumulated other comprehensive loss. ASC Topic 715 also requires measurement of the funded status of a plan as of the Company's consolidated balance sheet dates.

[0001564590-22-008035:notes:88]
Recently Adopted and Issued Accounting Standards

[0001564590-22-008035:notes:89]
Recently Adopted Accounting Standards

[0001564590-22-008035:notes:90]
In December 2019, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company adopted this ASU as of December 29, 2020 and it did not have a material impact on its consolidated financial statements and related disclosures.

[0001564590-22-008035:notes:91]
Recently Issued Accounting Standards Not Yet Adopted

[0001564590-22-008035:notes:92]
In November 2021, the FASB issued ASU 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance, which provides guidance on disclosures for transactions with a government that are accounted for by applying a grant or contribution accounting model by analogy. The guidance is effective for fiscal years, and for interim periods within those fiscal years, beginning after December 15, 2021. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-22-008035:notes:93]
| (2) | Leases |

[0001564590-22-008035:notes:94]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases and finance leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments, and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the ROU asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-22-008035:notes:95]
The components of lease expense were as follows:

[0001564590-22-008035:notes:96]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 7,907 |  |  | $ | 9,304 |  |
| Variable lease cost |  |  | 798 |  |  |  | 529 |  |
| Short-term lease cost |  |  | 338 |  |  |  | 525 |  |
| Finance lease costs: |  |  |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  | 538 |  |  |  | — |  |
| Interest on lease liabilities |  |  | 159 |  |  |  | — |  |

[0001564590-22-008035:notes:97]
Supplemental cash flow information related to leases was as follows:

[0001564590-22-008035:notes:98]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |
| Operating cash flows for operating leases |  | $ | 8,308 |  |  | $ | 8,865 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 8,651 |  |  |  | 10,036 |  |
| Finance leases |  |  | 15,297 |  |  |  | — |  |

[0001564590-22-008035:notes:99]
Supplemental balance sheet information related to leases was as follows:

[0001564590-22-008035:notes:100]
|  |  |  |  | As of |  |
|  |  | Balance Sheet Location |  | January 3, 2022 |  |  | December 28, 2020 |  |
|  |  |  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease right-of-use assets |  | $ | 20,802 |  |  | $ | 24,340 |  |
| Finance leases |  | Property, plant and equipment, net |  |  | 14,759 |  |  |  | — |  |
| Total lease assets |  |  |  | $ | 35,561 |  |  | $ | 24,340 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 6,362 |  |  | $ | 8,144 |  |
| Finance leases |  | Other current liabilities |  |  | 698 |  |  |  | — |  |
| Long-term: |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease liabilities |  |  | 15,252 |  |  |  | 17,211 |  |
| Finance leases |  | Other long-term liabilities |  |  | 14,317 |  |  |  | — |  |
| Total lease liabilities |  |  |  | $ | 36,629 |  |  | $ | 25,355 |  |

[0001564590-22-008035:notes:101]
|  |  | As of |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |
| Weighted average remaining lease term (years): |  |  |  |  |  |  |  |  |
| Operating leases |  | 3.9 |  |  | 4.2 |  |
| Finance leases |  | 14.6 |  |  |  | — |  |
| Weighted average discount rate: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 2.56 | % |  |  | 3.31 | % |
| Finance leases |  |  | 2.68 | % |  |  | — |  |

[0001564590-22-008035:notes:102]
Maturities of lease liabilities were as follows:

[0001564590-22-008035:notes:103]
|  |  | Operating Leases (1) |  |  | Finance Leases |  |
|  |  | (In thousands) |  |
| Less than one year |  | $ | 6,833 |  |  | $ | 1,089 |  |
| 1 - 2 years |  |  | 6,085 |  |  |  | 1,110 |  |
| 2 - 3 years |  |  | 4,910 |  |  |  | 1,135 |  |
| 3 - 4 years |  |  | 2,618 |  |  |  | 1,146 |  |
| 4 - 5 years |  |  | 1,458 |  |  |  | 1,175 |  |
| Thereafter |  |  | 901 |  |  |  | 12,656 |  |
| Total lease payments |  |  | 22,805 |  |  |  | 18,311 |  |
| Less imputed interest |  |  | (1,191 | ) |  |  | (3,296 | ) |
| Total |  | $ | 21,614 |  |  | $ | 15,015 |  |

[0001564590-22-008035:notes:104]
|  | (1) | Excludes $851 of legally binding minimum lease payments for leases signed but not yet commenced. |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-22-008035:notes:105]
| (3) | Discontinued Operations |

[0001564590-22-008035:notes:106]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement for the sale of the Company’s Mobility business unit. The sale was completed on April 17, 2020 for a base purchase price of $550,000, subject to customary purchase price adjustments. The base purchase price did not include certain accounts receivable of the divested business, which were estimated to total approximately $95,000. After the price adjustments, the final purchase price was $569,246, which did not include approximately $83,000 accounts receivable of the divested business.

[0001564590-22-008035:notes:107]
On April 18, 2020, the Company entered into a Transition Services Agreement (TSA) with the Purchaser pursuant to which the Purchaser is receiving certain services (the Services) to enable it to operate the Mobility business unit after the closing of the sale of the Mobility business unit. The Services include finance and accounting, human resources, legal and compliance, sales, information technology, and other corporate support services. Under the TSA, the Services are being provided at cost for a period of up to 24 months. In addition, the Company entered into a Manufacturing Supply Agreement with the Purchaser pursuant to which the Purchaser will supply products to a few customers of the Company. There was no material impact on the Company’s consolidated financial statements.

[0001564590-22-008035:notes:108]
Further, on June 29, 2020, the Company entered into a Sales Force Agreement with the Purchaser pursuant to which the Company’s sales representatives assist the Purchaser in selling PCBs manufactured by the Purchaser to certain customers for a commission for a period up to April 17, 2021. There was no material impact on the Company’s consolidated financial statements.

[0001564590-22-008035:notes:109]
As the sale of the Company’s Mobility business unit represents a strategic shift that had a major effect on the Company’s operations and financial results, in accordance with the provisions of FASB authoritative guidance on the presentation of financial statements, Mobility business unit results are classified as discontinued operations in the consolidated statements of operations for all periods presented.

[0001564590-22-008035:notes:110]
The following table summarizes the results of Mobility operations for each period prior to sale:

[0001564590-22-008035:notes:111]
|  |  | For the Year Ended |  |
|  |  | December 28, |  |  | December 30, |  |
|  |  | 2020 |  |  | 2019 |  |
|  |  | (In thousands, except per share data) |  |
| Net sales |  | $ | 143,951 |  |  | $ | 556,098 |  |
| Cost of goods sold |  |  | 136,800 |  |  |  | 531,592 |  |
| Gross profit |  |  | 7,151 |  |  |  | 24,506 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 1,461 |  |  |  | 4,840 |  |
| General and administrative |  |  | 2,317 |  |  |  | 4,875 |  |
| Research and development |  |  | 147 |  |  |  | — |  |
| Amortization of definite-lived intangibles |  |  | 809 |  |  |  | 2,698 |  |
| Restructuring charges |  |  | — |  |  |  | 1,601 |  |
| Total operating expenses |  |  | 4,734 |  |  |  | 14,014 |  |
| Operating income |  |  | 2,417 |  |  |  | 10,492 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (223 | ) |  |  | (1,147 | ) |
| Gain on sale of the Mobility business unit |  |  | 237,253 |  |  |  | — |  |
| Other, net |  |  | 1,160 |  |  |  | 2,513 |  |
| Total other income, net |  |  | 238,190 |  |  |  | 1,366 |  |
| Income from discontinued operations before income taxes |  |  | 240,607 |  |  |  | 11,858 |  |
| Income tax provision |  |  | (46,686 | ) |  |  | (2,478 | ) |
| Income from discontinued operations, net of income taxes |  | $ | 193,921 |  |  | $ | 9,380 |  |
| Earnings per share from discontinued operations: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 1.82 |  |  | $ | 0.09 |  |
| Diluted earnings per share |  | $ | 1.82 |  |  | $ | 0.09 |  |

[0001564590-22-008035:notes:112]
Depreciation expense related to the discontinued operations for the years ended December 28, 2020 and December 30, 2019, was $21,375 and $73,204, respectively.

[0001564590-22-008035:notes:113]
During the year ended December 28, 2020, the Company’s income tax expense related to the discontinued operations was impacted by a net discrete tax expense of $46,686. The net income tax expense for the year ended December 28, 2020 is related mainly to (i) China withholding tax related to gain on sale, (ii) U.S. income tax related to Global Intangible Low Taxed Income (GILTI) inclusion net of IRC Section 250 deduction and foreign tax credits, offset by (iii) release of U.S. uncertain tax positions as a result of available excess foreign tax credits.

[0001564590-22-008035:notes:114]
Proceeds from the sale of the Company’s Mobility business unit have been presented in the consolidated statements of cash flows within net cash provided by investing activities from discontinued operations. The following is a reconciliation of the final gain recorded for the sale of the Company’s Mobility business unit (in thousands):

[0001564590-22-008035:notes:115]
| Net proceeds from the sale of the Mobility business unit (1) |  | $ | 569,246 |  |
| Mobility business unit assets: |  |  |  |  |
| Cash and cash equivalents |  |  | 12,513 |  |
| Restricted cash |  |  | 35,412 |  |
| Accounts receivable, net |  |  | 12 |  |
| Contract assets |  |  | 40,072 |  |
| Inventories |  |  | 4,988 |  |
| Prepaid expenses and other current assets |  |  | 4,593 |  |
| Property, plant and equipment, net |  |  | 328,648 |  |
| Goodwill |  |  | 68,267 |  |
| Definite-lived intangibles, net |  |  | 5,520 |  |
| Deposits and other non-current assets |  |  | 6,291 |  |
| Total Mobility business unit assets |  |  | 506,316 |  |
| Mobility business unit liabilities: |  |  |  |  |
| Accounts payable |  |  | 142,636 |  |
| Accrued salaries, wages and benefits |  |  | 9,392 |  |
| Other current liabilities |  |  | 8,890 |  |
| Other long-term liabilities |  |  | 303 |  |
| Total Mobility business unit liabilities |  |  | 161,221 |  |
| Derecognition of foreign currency translation adjustments and unrealized losses on cash flow hedges recorded in accumulated other comprehensive loss |  |  | 26,957 |  |
| Other transaction costs incurred as part of the sale of the Mobility business unit (2) |  |  | 13,855 |  |
| Gain on sale of the Mobility business unit before income taxes |  | $ | 237,253 |  |

[0001564590-22-008035:notes:116]
| (1) | Net proceeds from the sale of the Mobility business unit are net of the finalized customary purchase price adjustments. |

[0001564590-22-008035:notes:117]
| (2) | Costs directly incurred as a result of the sale of the Company’s Mobility business unit, including bank fees, legal fees, professional fees, and other costs. |


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001564590-22-008035:notes:118]
The following is a reconciliation of the final gain recorded for the sale of the Company’s Mobility business unit (in thousands):


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-22-008035:notes:119]
| (4) | Composition of Certain Consolidated Financial Statement Captions |

[0001564590-22-008035:notes:120]
|  |  | As of |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 114,653 |  |  | $ | 103,890 |  |
| Work-in-process |  |  | 9,620 |  |  |  | 7,841 |  |
| Finished goods |  |  | 3,339 |  |  |  | 3,920 |  |
|  |  | $ | 127,612 |  |  | $ | 115,651 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 62,015 |  |  | $ | 61,781 |  |
| Buildings and improvements |  |  | 429,344 |  |  |  | 398,540 |  |
| Machinery and equipment |  |  | 891,925 |  |  |  | 832,723 |  |
| Furniture and fixtures and other |  |  | 10,360 |  |  |  | 10,304 |  |
| Construction-in-progress |  |  | 25,554 |  |  |  | 33,191 |  |
|  |  |  | 1,419,198 |  |  |  | 1,336,539 |  |
| Less: Accumulated depreciation |  |  | (753,443 | ) |  |  | (686,104 | ) |
|  |  | $ | 665,755 |  |  | $ | 650,435 |  |
| Other current liabilities: |  |  |  |  |  |  |  |  |
| Sales return and allowances |  | $ | 12,853 |  |  | $ | 13,015 |  |
| Interest |  |  | 8,741 |  |  |  | 7,157 |  |
| Income taxes payable |  |  | 7,162 |  |  |  | 2,428 |  |
| Operating lease |  |  | 6,362 |  |  |  | 8,144 |  |
| Derivative liabilities |  |  | 4,295 |  |  |  | — |  |
| Finance leases |  |  | 698 |  |  |  | — |  |
| Restructuring |  |  | 34 |  |  |  | 7,382 |  |
| Other |  |  | 52,884 |  |  |  | 51,296 |  |
|  |  | $ | 93,029 |  |  | $ | 89,422 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 28,361 |  |  | $ | 23,704 |  |
| Finance leases |  |  | 14,317 |  |  |  | — |  |
| Defined benefit pension plan liability |  |  | 5,276 |  |  |  | 9,986 |  |
| Derivative liabilities |  |  | — |  |  |  | 14,968 |  |
| Other |  |  | 20,958 |  |  |  | 25,167 |  |
|  |  | $ | 68,912 |  |  | $ | 73,825 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-22-008035:notes:121]
| (5) | Goodwill |

[0001564590-22-008035:notes:122]
As of January 3, 2022, December 28, 2020 and December 30, 2019, goodwill by reportable segment was as follows:

[0001564590-22-008035:notes:123]
|  |  | PCB |  | RF&S Components |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 30, 2019 |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 700,724 |  | $ | 177,200 |  | $ | 877,924 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | — |  |  | (171,400 | ) |
|  |  |  | 529,324 |  |  | 177,200 |  |  | 706,524 |  |
| Impairment loss during the year ended December 28, 2020 |  |  | — |  |  | (69,200 | ) |  | (69,200 | ) |
| Balance as of December 28, 2020 and January 3, 2022 |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  |  | 700,724 |  |  | 177,200 |  |  | 877,924 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (69,200 | ) |  | (240,600 | ) |
|  |  | $ | 529,324 |  | $ | 108,000 |  | $ | 637,324 |  |

[0001564590-22-008035:notes:124]
The Company evaluates its goodwill on an annual basis during its fourth fiscal quarter and at other times when events or changes in circumstances — such as significant adverse changes in the business climate or operating results or changes in management strategy, coupled with a decline in the market price of its stock and market capitalization — indicate that there may be a potential impairment.

[0001564590-22-008035:notes:125]
In the fourth quarter of 2021, the Company performed its annual goodwill impairment test qualitatively and concluded that it was more likely than not that there was no impairment to goodwill.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-22-008035:notes:126]
| (6) | Definite-lived Intangibles |

[0001564590-22-008035:notes:127]
As of January 3, 2022 and December 28, 2020, the components of definite-lived intangibles were as follows:

[0001564590-22-008035:notes:128]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| January 3, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 366,071 |  |  | $ | (154,461 | ) |  | $ | 211,610 |  |  |  | 11.3 |  |
| Technology |  |  | 47,650 |  |  |  | (19,342 | ) |  |  | 28,308 |  |  |  | 9.5 |  |
|  |  | $ | 413,721 |  |  | $ | (173,803 | ) |  | $ | 239,918 |  |  |  |  |  |
| December 28, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 397,500 |  |  | $ | (150,142 | ) |  | $ | 247,358 |  |  |  | 10.9 |  |
| Technology |  |  | 47,650 |  |  |  | (13,701 | ) |  |  | 33,949 |  |  |  | 9.5 |  |
|  |  | $ | 445,150 |  |  | $ | (163,843 | ) |  | $ | 281,307 |  |  |  |  |  |

[0001564590-22-008035:notes:129]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $41,389, $44,373 and $50,598 for the years ended January 3, 2022, December 28, 2020 and December 30, 2019, respectively. For the years ended January 3, 2022, December 28, 2020 and December 30, 2019, $5,641, $5,535 and $4,822, respectively, of amortization expense is included in cost of goods sold.

[0001564590-22-008035:notes:130]
Estimated aggregate amortization for definite-lived intangible assets for the next five years and thereafter is as follows:

[0001564590-22-008035:notes:131]
|  |  | (In thousands) |  |
| 2022 |  | $ | 38,631 |  |
| 2023 |  |  | 36,699 |  |
| 2024 |  |  | 29,516 |  |
| 2025 |  |  | 25,397 |  |
| 2026 |  |  | 25,397 |  |
| Thereafter |  |  | 84,278 |  |
|  |  | $ | 239,918 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-22-008035:notes:132]
| (7) | Long-term Debt and Letters of Credit |

[0001564590-22-008035:notes:133]
The following table summarizes the long-term debt of the Company as of January 3, 2022 and December 28, 2020:

[0001564590-22-008035:notes:134]
|  |  | Interest Rate as of January 3, 2022 |  |  | Principal Outstanding as of January 3, 2022 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.60 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.50 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (607 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (7,454 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 927,818 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 927,818 |  |  |  |  |  |  | $ | 842,853 |  |

[0001564590-22-008035:notes:135]
The fiscal calendar maturities of long-term debt through 2026 and thereafter are as follows:

[0001564590-22-008035:notes:136]
|  |  | (In thousands) |  |
| 2022 |  | $ | — |  |
| 2023 |  |  | — |  |
| 2024 |  |  | 435,879 |  |
| 2025 |  |  | — |  |
| 2026 |  |  | — |  |
| Thereafter |  |  | 500,000 |  |
|  |  | $ | 935,879 |  |

[0001564590-22-008035:notes:137]
As of January 3, 2022, the Company was in compliance with the financial covenants under the Term Loan Facility, Senior Notes due 2029 and ABL Revolving Loans.

[0001564590-22-008035:notes:138]
Senior Notes due 2029

[0001564590-22-008035:notes:139]
On March 10, 2021, the Company issued $500,000 of Senior Notes due 2029, which are included in long-term debt and bear interest at a rate of 4.0% per annum. Interest is payable semiannually in arrears on March 1 and September 1 of each year beginning September 1, 2021. The Senior Notes due 2029 will mature on March 1, 2029.

[0001564590-22-008035:notes:140]
The Company used a portion of the net proceeds from the issuance of the Senior Notes due 2029 during the quarter ended March 29, 2021 to: (i) fund the early retirement of $375,000 Senior Notes due 2025, (ii) fund the repayment of $40,000 outstanding under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) Revolving credit facility (but not terminate the commitments thereunder), and (iii) pay related premiums, fees and expenses. The Company has and intends to use the remaining net proceeds for general corporate purposes.

[0001564590-22-008035:notes:141]
Convertible Senior Notes due 2020

[0001564590-22-008035:notes:142]
The Convertible Senior Notes bore interest at a rate of 1.75% per annum. Interest was payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes were unsecured obligations that ranked equally to the Company’s future unsecured senior indebtedness and were senior in right of payment to any of the Company’s future subordinated indebtedness. Offering expenses were amortized to interest expense over the term of the Convertible Senior Notes. The Convertible Senior Notes matured and were repaid in cash in the amount of $249,975 on December 15, 2020.

[0001564590-22-008035:notes:143]
Convertible Note Hedge and Warrant Transaction:    In connection with the issuance of the Convertible Senior Notes due 2020, the Company entered into a convertible note hedge and warrant transaction (Call Spread Transaction), with respect to the Company’s common stock. The convertible note hedge consisted of the Company’s option to purchase up to 25,939 common stock shares at a price of $9.64 per share. The hedge could only be executed upon the conversion of the above mentioned Convertible Senior

[0001564590-22-008035:notes:144]
Notes due 2020 and it expired unexercised on December 15, 2020. Additionally, the Company sold equity-classified warrants to purchase 25,940 shares of its common stock at a price of $14.26 per share. Although the Convertible Senior Notes are no longer outstanding, these warrants remain outstanding and expire ratably from March 2021 through January 2022. The Call Spread Transaction had no effect on the terms of the Convertible Senior Notes due 2020.

[0001564590-22-008035:notes:145]
The components of interest expense resulting from the Convertible Senior Notes for the years ended December 28, 2020 and

[0001564590-22-008035:notes:146]
December 30, 2019 were as follows:

[0001564590-22-008035:notes:147]
|  |  | For the Year Ended |  |
|  |  | December 28, |  |  | December 30, |  |
|  |  | 2020 |  |  | 2019 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 4,180 |  |  | $ | 4,374 |  |
| Amortization of debt discount |  | $ | 9,926 |  |  | $ | 9,751 |  |
| Amortization of debt issuance costs |  | $ | 995 |  |  | $ | 977 |  |

[0001564590-22-008035:notes:148]
Term Loan Facility

[0001564590-22-008035:notes:149]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $405,879 as of January 3, 2022 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR plus an applicable interest margin of 2.5%, or an alternate base rate (as defined in the Term Loan Credit Agreement) plus an applicable margin of 1.5%. As of January 3, 2022, the interest rate on the outstanding borrowings under the Term Loan Facility was 2.60%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes due 2029. See Senior Notes due 2029 above.

[0001564590-22-008035:notes:150]
Pursuant to the Term Loan Credit Agreement, the Company could reinvest the cash proceeds received from the sale of the Mobility business unit for a period of twelve months commencing September 3, 2020. If the proceeds were not reinvested during that time, the Company was required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to repay $400,000 of the Term Loan during the year ended December 28, 2020 and used the remaining cash proceeds for reinvestment pursuant to the Term Loan Credit Agreement. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

[0001564590-22-008035:notes:151]
Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. For 2021, the Company is not required to make an additional principal payment as its First Lien Leverage Ratio was less than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0001564590-22-008035:notes:152]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-22-008035:notes:153]
Asset-Based Lending Agreements

[0001564590-22-008035:notes:154]
In June 2019, the Company amended its U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and its Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans). The U.S. ABL credit facility was amended to extend its maturity to June 2024 and decrease the size of the revolving credit facility to $150,000. The Asia ABL credit facility was amended to extend the maturity to June 2024.

[0001564590-22-008035:notes:155]
The U.S. ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $50,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 125 basis points or an alternate base rate (defined as the greater of the prime rate, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%) subject to a 1.0% floor, plus an applicable margin of 25 basis points, at the Company’s option. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for LIBOR-based loans and from 25 to 50 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to

[0001564590-22-008035:notes:156]
increase. The U.S. ABL will mature on June 3, 2024. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes due 2029. See Senior Notes due 2029 and Convertible Senior Notes above.

[0001564590-22-008035:notes:157]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of January 3, 2022, the interest rate on the outstanding borrowings under the Asia ABL was 1.50%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on June 4, 2024. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes due 2029. See Senior Notes due 2029 above. As of January 3, 2022, $30,000 under the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-22-008035:notes:158]
As of January 3, 2022, letters of credit in the amount of $9,231 were outstanding under the U.S. ABL and $3,197 were outstanding under the Asia ABL with various expiration dates through April 2022. Available borrowing capacity under the U.S. ABL and the Asia ABL was $140,769 and $116,803, respectively, which considers letters of credit outstanding as of January 3, 2022.

[0001564590-22-008035:notes:159]
The Company is required to pay a commitment fee of 0.25% per annum on any unused portion of the U.S. ABL and 0.28% per annum on any unused portion of the Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $663, $541 and $703 for the years ended January 3, 2022, December 28, 2020 and December 30, 2019, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0001564590-22-008035:notes:160]
Debt Issuance and Debt Discount

[0001564590-22-008035:notes:161]
As of January 3, 2022 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:

[0001564590-22-008035:notes:162]
|  |  | As of January 3, 2022 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |

[0001564590-22-008035:notes:163]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-22-008035:notes:164]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,355 and $1,919 as of January 3, 2022 and December 28, 2020, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

[0001564590-22-008035:notes:165]
As of January 3, 2022, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 5.2 years.

[0001564590-22-008035:notes:166]
Loss on Extinguishment of Debt

[0001564590-22-008035:notes:167]
During the year ended January 3, 2022, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-22-008035:notes:168]
| (8) | Income Taxes |

[0001564590-22-008035:notes:169]
The components of income (loss) from continuing operations before income taxes for the years ended January 3, 2022, December 28, 2020 and December 30, 2019 are:

[0001564590-22-008035:notes:170]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| United States |  | $ | (28,057 | ) |  | $ | (84,582 | ) |  | $ | 16,066 |  |
| Foreign |  |  | 98,110 |  |  |  | 38,305 |  |  |  | 18,260 |  |
| Income (loss) from continuing operations before income taxes |  | $ | 70,053 |  |  | $ | (46,277 | ) |  | $ | 34,326 |  |

[0001564590-22-008035:notes:171]
The Company expects its earnings attributable to foreign subsidiaries will not be indefinitely reinvested, except for certain circumstances where we have established a deferred tax liability of approximately $2,816 and $1,666 for the foreign and U.S. federal/state impact, respectively. For those other companies with earnings currently being reinvested outside of the U.S., the undistributed earnings amounted to approximately $60,769 as of January 3, 2022. The determination of the unrecognized deferred tax liability related to these undistributed earnings is approximately $2,642.

[0001564590-22-008035:notes:172]
The components of income tax (provision) benefit for the years ended January 3, 2022, December 28, 2020
and December 30, 2019 are:

[0001564590-22-008035:notes:173]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Current (provision) benefit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (1,125 | ) |  | $ | (44 | ) |  | $ | 294 |  |
| State |  |  | 547 |  |  |  | (4,624 | ) |  |  | (2,922 | ) |
| Foreign |  |  | (9,211 | ) |  |  | 27,902 |  |  |  | (12,748 | ) |
| Total current |  |  | (9,789 | ) |  |  | 23,234 |  |  |  | (15,376 | ) |
| Deferred (provision) benefit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 2,889 |  |  |  | 2,446 |  |  |  | 1,004 |  |
| State |  |  | (1,492 | ) |  |  | 4,498 |  |  |  | (1,076 | ) |
| Foreign |  |  | (7,247 | ) |  |  | (287 | ) |  |  | 13,043 |  |
| Total deferred |  |  | (5,850 | ) |  |  | 6,657 |  |  |  | 12,971 |  |
| Income tax (provision) benefit |  | $ | (15,639 | ) |  | $ | 29,891 |  |  | $ | (2,405 | ) |

[0001564590-22-008035:notes:174]
The following is a reconciliation of the provision for income taxes at the statutory federal income tax rate compared to the Company’s provision for income taxes for the years ended January 3, 2022, December 28, 2020 and December 30, 2019:

[0001564590-22-008035:notes:175]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Statutory federal income tax (provision) benefit |  | $ | (14,711 | ) |  | $ | 9,718 |  |  | $ | (7,209 | ) |
| State income taxes, net of federal benefit and state tax credits |  |  | 1,815 |  |  |  | (2,674 | ) |  |  | (3,163 | ) |
| IRC Section 162(m) limitation |  |  | (725 | ) |  |  | (712 | ) |  |  | (868 | ) |
| Stock options |  |  | 89 |  |  |  | (1,298 | ) |  |  | (252 | ) |
| Global Intangible Low-Taxed Income |  |  | (9,824 | ) |  |  | (1,300 | ) |  |  | — |  |
| Permanently reinvested earnings assertion |  |  | (1,392 | ) |  |  | (1,442 | ) |  |  | (1,765 | ) |
| Foreign tax differential on foreign earnings & other permanent items |  |  | 3,917 |  |  |  | 3,933 |  |  |  | 687 |  |
| Change in valuation allowance |  |  | (1,139 | ) |  |  | (2,668 | ) |  |  | 2,127 |  |
| Uncertain tax positions |  |  | (642 | ) |  |  | 36,936 |  |  |  | 999 |  |
| Foreign tax credits |  |  | 3,028 |  |  |  | 4,250 |  |  |  | 4,582 |  |
| Federal research and development credits |  |  | 3,400 |  |  |  | — |  |  |  | — |  |
| Goodwill impairment |  |  | — |  |  |  | (14,532 | ) |  |  | — |  |
| Other |  |  | 545 |  |  |  | (320 | ) |  |  | 2,457 |  |
| Income tax (provision) benefit |  | $ | (15,639 | ) |  | $ | 29,891 |  |  | $ | (2,405 | ) |

[0001564590-22-008035:notes:176]
Deferred income taxes reflect the net tax effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. The significant components of the net deferred income tax assets (liabilities) as of January 3, 2022 and December 28, 2020 are as follows:

[0001564590-22-008035:notes:177]
|  |  | As of |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Deferred income tax assets: |  |  |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 41,354 |  |  | $ | 43,209 |  |
| Reserves and accruals |  |  | 30,944 |  |  |  | 29,429 |  |
| Interest expense limitation |  |  | 2,826 |  |  |  | — |  |
| Unrealized loss on cash flow hedge |  |  | 1,128 |  |  |  | 4,713 |  |
| Tax credit carryforwards |  |  | 38,890 |  |  |  | 39,757 |  |
| Stock-based compensation |  |  | 4,724 |  |  |  | 4,216 |  |
| Property, plant and equipment |  |  | 7,665 |  |  |  | 9,989 |  |
| Other deferred income tax assets |  |  | 707 |  |  |  | 493 |  |
|  |  |  | 128,238 |  |  |  | 131,806 |  |
| Less: valuation allowance |  |  | (16,541 | ) |  |  | (15,322 | ) |
|  |  |  | 111,697 |  |  |  | 116,484 |  |
| Deferred income tax liabilities: |  |  |  |  |  |  |  |  |
| Repatriation of foreign earnings |  |  | (4,482 | ) |  |  | (4,006 | ) |
| Property, plant and equipment basis differences |  |  | (62,791 | ) |  |  | (50,463 | ) |
| Goodwill and intangible amortization |  |  | (33,318 | ) |  |  | (39,668 | ) |
| Other deferred income tax liabilities |  |  | (4,203 | ) |  |  | (5,700 | ) |
| Net deferred income tax assets (included in Deposits and other non-current assets) |  | $ | 6,903 |  |  | $ | 16,647 |  |

[0001564590-22-008035:notes:178]
As of January 3, 2022, the Company had the following net operating loss (NOL) carryforwards: $107,969 in the U.S. for federal, $28,427 in various U.S. states, $62,909 in China, and $18,034 in Hong Kong. The U.S. federal NOLs expire in 2028 through 2032, the various U.S. states’ NOLs expire in 2022 through 2037, the China NOLs expire in 2025 through 2031, and the Hong Kong NOLs carryforward indefinitely. Further, the Company’s tax credits were approximately $48,150, of which $5,777 carryforward indefinitely.

[0001564590-22-008035:notes:179]
In connection with the Company’s acquisition of Viasystems during 2015, there was more than a 50% change in ownership under Section 382 of the Internal Revenue Code of 1986, as amended, and regulations issued there under. As a consequence, the utilization of the acquired Viasystems U.S. NOLs is limited to approximately $9,826 per year. In addition, the Company recognized certain gains built in at the time of the ownership change, which increase the limitation by approximately $47,463 for each of the first 5 years after the acquisition. Any unused limitation in a year can be carried over to succeeding years. The Company has fully utilized the portion of the NOL carryforward that included the $47,463 per year and so the only remaining NOL available is the $9,826 per year, the total of which is $107,969.

[0001564590-22-008035:notes:180]
A valuation allowance is provided when it is more likely than not that all or some portion of the deferred income tax assets will not be realized. The Company maintains a valuation allowance on certain of its U.S. net deferred tax assets represented by income tax attributes carried forward that are expected to expire unused. Certain subsidiaries within China continue to have NOL carryforwards in various tax jurisdictions that the Company has determined are not more likely than not to be utilized. As a result, a full valuation allowance has been recorded for these subsidiaries as of January 3, 2022. For the remaining net deferred income tax assets, management has determined that it is more likely than not that the results of future operations will generate sufficient taxable income to realize the net deferred tax assets.

[0001564590-22-008035:notes:181]
The following summarizes the activity in the Company’s valuation allowance for the years ended January 3, 2022, December 28, 2020 and December 30, 2019:

[0001564590-22-008035:notes:182]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 15,322 |  |  | $ | 14,292 |  |  | $ | 16,635 |  |
| Additions charged to expense |  |  | 2,330 |  |  |  | 3,904 |  |  |  | 1,526 |  |
| Other reduction charged to expense |  |  | (1,111 | ) |  |  | (2,874 | ) |  |  | (3,869 | ) |
| Balance at end of year |  | $ | 16,541 |  |  | $ | 15,322 |  |  | $ | 14,292 |  |

[0001564590-22-008035:notes:183]
Certain entities within China qualified for the high and new technology enterprise (HNTE) status enabling those entities to enjoy certain benefits, which were effective for the years ended January 3, 2022, December 28, 2020 and December 30, 2019. The HNTE status as well as enhanced research and development (R&D) deductions decreased Chinese taxes. HNTE and R&D benefit and effect on earnings per share are as follows:

[0001564590-22-008035:notes:184]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands, except per share data) |  |
| HNTE and R&D benefits |  | $ | 5,611 |  |  | $ | 4,235 |  |  | $ | 6,060 |  |
| Basic shares |  |  | 106,314 |  |  |  | 106,366 |  |  |  | 105,195 |  |
| Diluted shares |  |  | 108,153 |  |  |  | 106,366 |  |  |  | 106,332 |  |
| Increases earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.05 |  |  | $ | 0.04 |  |  | $ | 0.06 |  |
| Diluted |  | $ | 0.05 |  |  | $ | 0.04 |  |  | $ | 0.06 |  |

[0001564590-22-008035:notes:185]
HNTE status expires at various dates in 2022, but the Company expects to continue to file for renewal of such HNTE status for the foreseeable future.

[0001564590-22-008035:notes:186]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, exclusive of accrued interest and penalties, is as follows:

[0001564590-22-008035:notes:187]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 7,404 |  |  | $ | 37,465 |  |  | $ | 30,284 |  |
| Additions based on tax positions related to the current year |  |  | 2,749 |  |  |  | 839 |  |  |  | 3,553 |  |
| Additions for tax positions of prior years |  |  | 41 |  |  |  | 202 |  |  |  | 4,952 |  |
| Reductions for tax positions of prior years |  |  | (357 | ) |  |  | (27,283 | ) |  |  | (103 | ) |
| Lapse of statute of limitations |  |  | (395 | ) |  |  | (3,819 | ) |  |  | (1,221 | ) |
| Balance at end of year |  | $ | 9,442 |  |  | $ | 7,404 |  |  | $ | 37,465 |  |

[0001564590-22-008035:notes:188]
During the year ended January 3, 2022, the Company increased current years’ uncertain tax positions by $2,038 due to (i) amortization of certain capitalized research expenditures; and (ii) U.S. R&D credit generated in 2021.

[0001564590-22-008035:notes:189]
As of January 3, 2022 and December 28, 2020, the Company recorded unrecognized tax benefits of $804 and $1,046, respectively, as well as interest and penalties of $1,026 and $1,566, respectively, to current and long-term liabilities. The Company has also recorded unrecognized tax benefits of $8,638 and $6,358 against certain deferred tax assets as of January 3, 2022 and December 28, 2020, respectively. The amount of unrecognized tax benefits that would, if recognized, reduce the Company’s effective income tax rate in any future periods is $1,830 including interest and penalties. The Company expects no change to its unrecognized tax benefits over the next twelve months due to expiring statutes.

[0001564590-22-008035:notes:190]
As of January 3, 2022, the Company is open for (i) U.S. federal income tax examination for the period from 2019 to 2021 and NOL and credit carryforwards are subject to adjustment for 3 years post utilization, (ii) state and local income tax examination for tax years 2018 to 2021 and NOL and credit carryforwards are subject to adjustment for 4 years post utilization; and (iii) foreign income tax examinations generally for tax years from 2011 to 2021.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-22-008035:notes:191]
| (9) | Financial Instruments |

[0001564590-22-008035:notes:192]
Derivatives

[0001564590-22-008035:notes:193]
Interest Rate Swaps

[0001564590-22-008035:notes:194]
The Company’s business is exposed to risk resulting from fluctuations in interest rates on certain LIBOR-based variable rate debt. Increases in interest rates would increase interest expenses relating to the outstanding variable rate borrowings and increase the cost of debt. Fluctuations in interest rates can also lead to significant fluctuations in the fair value of the debt obligations.

[0001564590-22-008035:notes:195]
On May 15, 2018, the Company entered into a four-year pay-fixed, receive floating (1-month LIBOR), interest rate swap arrangement with a notional amount of $400,000 for the period beginning June 1, 2018 and ending on June 1, 2022. Under the terms of the interest rate swap, the Company pays a fixed rate of 2.84% against a portion of its LIBOR-based debt and receives floating 1-month LIBOR during the swap period.

[0001564590-22-008035:notes:196]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of January 3, 2022, the fair value of the interest rate swap was recorded as a liability in the amount of $4,295 and included as a component of other current liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax, in the Company’s consolidated balance sheets. No ineffectiveness was recognized for the years ended January 3, 2022 and December 28, 2020. During the year ended January 3, 2022, the interest rate swap increased interest expense by $11,272.

[0001564590-22-008035:notes:197]
Foreign Exchange Contracts

[0001564590-22-008035:notes:198]
The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. There were no forward exchange contracts as of January 3, 2022. As of December 28, 2020, the notional amount of the foreign exchange contracts was approximately $1,181 (JPY 125.0 million). The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-22-008035:notes:199]
Commodity Price Risk Management

[0001564590-22-008035:notes:200]
The Company uses various raw materials in the manufacturing of PCBs. In particular, the Company has been experiencing increasing prices and lead times of copper clad laminates (CCLs), a key raw material for the manufacture of PCBs. CCLs are made from epoxy resin, glass cloth and copper foil, all of which are seeing limited supply and resulting increased prices. The Company only buys a small amount of copper directly. However, copper is a major driver of laminate cost. As such, the Company enters into commodity contracts to hedge copper as a proxy for hedging laminate. As of January 3, 2022, the Company has commodity contracts with a notional quantity of (i) 0.5 metric tonnes each for the period beginning January 4, 2022 and ending on March 31, 2022, (ii) 0.5 metric tonnes for the period beginning April 5, 2022 and ending on June 29, 2022, (iii) 0.6 metric tonnes for the period beginning June 30, 2022 and ending on October 3, 2022, and (iv) 0.7 metric tonnes for the period beginning October 4, 2022 and ending on January 3, 2023. As of January 3, 2022, the fair value of the commodity contracts was recorded as an asset in the amount of $297 and included as a component of prepaid expenses and other current assets. The changes in the fair value of these commodity contracts are recorded in cost of goods sold in the consolidated statements of operations. The commodity contracts decreased cost of goods sold by $297 for the year ended January 3, 2022. These commodity contracts are not designated as accounting hedges.

[0001564590-22-008035:notes:201]
The fair values of derivative instruments in the consolidated balance sheets are as follows:

[0001564590-22-008035:notes:202]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | January 3, 2022 |  |  | December 28, 2020 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other current liabilities |  | $ | (4,295 | ) |  | $ | — |  |
| Interest rate swap |  | Other long-term liabilities |  |  | — |  |  |  | (14,968 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | — |  |  |  | 28 |  |
| Commodity contracts |  | Prepaid expenses and other current assets |  |  | 297 |  |  |  | — |  |

[0001564590-22-008035:notes:203]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the years ended January 3, 2022, December 28, 2020 and December 30, 2019:

[0001564590-22-008035:notes:204]
|  |  |  | For the Year Ended |  |  |
|  |  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (599 | ) |  | $ | (11,272 | ) |  | $ | (11,843 | ) |  | $ | (8,942 | ) |  | $ | (9,647 | ) |  | $ | (2,315 | ) |  |

[0001564590-22-008035:notes:205]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the years ended January 3, 2022, December 28, 2020 and December 30, 2019:

[0001564590-22-008035:notes:206]
|  |  | For the Year Ended |  |
|  |  | January 3, |  |  | December 28, |  |  | December 30, |  |
|  |  | 2022 |  |  | 2020 |  |  | 2019 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | (11,231 | ) |  | $ | (9,617 | ) |  | $ | (4,214 | ) |
| Changes in fair value loss, net of tax |  |  | (515 | ) |  |  | (8,718 | ) |  |  | (7,296 | ) |
| Reclassification to earnings |  |  | 8,523 |  |  |  | 6,720 |  |  |  | 1,893 |  |
| Derecognition of unrealized losses on cash flow hedge due to sale of Mobility business unit |  | — |  |  |  | 384 |  |  | — |  |
| Ending balance, net of tax |  | $ | (3,223 | ) |  | $ | (11,231 | ) |  | $ | (9,617 | ) |

[0001564590-22-008035:notes:207]
Based on the current yield curve, the Company expects that losses of approximately $3,999 of the accumulated other comprehensive loss will be reclassified into the statement of operations, net of tax, in the next twelve months.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-22-008035:notes:208]
| (10) | Accumulated Other Comprehensive Loss |

[0001564590-22-008035:notes:209]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax as of January 3, 2022, December 28, 2020 and December 30, 2019:

[0001564590-22-008035:notes:210]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | (Losses) Gains on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of December 30, 2019 |  | $ | 1,115 |  |  | $ | (1,584 | ) |  | $ | (9,617 | ) |  | $ | (10,086 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,745 |  |  |  | (1,271 | ) |  |  | (8,718 | ) |  |  | (8,244 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 6,720 |  |  |  | 6,720 |  |
| Reclassification adjustment for foreign currency translation |  |  | (346 | ) |  |  | — |  |  |  | — |  |  |  | (346 | ) |
| Derecognition of foreign currency translation adjustments due to sale of Mobility business unit |  |  | (27,341 | ) |  |  | — |  |  |  | — |  |  |  | (27,341 | ) |
| Derecognition of unrealized losses on cash flow hedge due to sale of Mobility business unit |  |  | — |  |  |  | — |  |  |  | 384 |  |  |  | 384 |  |
| Net year to date other comprehensive loss |  |  | (25,942 | ) |  |  | (1,271 | ) |  |  | (1,614 | ) |  |  | (28,827 | ) |
| Ending balance as of December 28, 2020 |  |  | (24,827 | ) |  |  | (2,855 | ) |  |  | (11,231 | ) |  |  | (38,913 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 928 |  |  |  | 2,722 |  |  |  | (515 | ) |  |  | 3,135 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 8,523 |  |  |  | 8,523 |  |
| Net year to date other comprehensive income |  |  | 928 |  |  |  | 2,722 |  |  |  | 8,008 |  |  |  | 11,658 |  |
| Ending balance as of January 3, 2022 |  | $ | (23,899 | ) |  | $ | (133 | ) |  | $ | (3,223 | ) |  | $ | (27,255 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-22-008035:notes:211]
| (11) | Significant Customers and Concentration of Credit Risk |

[0001564590-22-008035:notes:212]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk.

[0001564590-22-008035:notes:213]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.

[0001564590-22-008035:notes:214]
For the years ended January 3, 2022 and December 28, 2020, one customer accounted for approximately 10% and 11% of the Company’s net sales, respectively. There were no customers that accounted for 10% or more of net sales for the year ended December 30, 2019.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-22-008035:notes:215]
| (12) | Fair Value Measures |

[0001564590-22-008035:notes:216]
The Company measures at fair value its financial and non-financial assets by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability.

[0001564590-22-008035:notes:217]
The carrying amount and estimated fair value of the Company’s financial instruments as of January 3, 2022 and December 28, 2020 were as follows:

[0001564590-22-008035:notes:218]
|  |  | As of |  |  | As of |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 297 |  |  | $ | 297 |  |  | $ | 28 |  |  | $ | 28 |  |
| Derivative liabilities, current |  |  | 4,295 |  |  |  | 4,295 |  |  |  | — |  |  |  | — |  |
| Derivative liabilities, non-current |  |  | — |  |  |  | — |  |  |  | 14,968 |  |  |  | 14,968 |  |
| Senior Notes due March 2029 |  |  | 494,556 |  |  |  | 498,200 |  |  |  | — |  |  |  | — |  |
| Term Loan due September 2024 |  |  | 403,262 |  |  |  | 406,135 |  |  |  | 402,370 |  |  |  | 407,909 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 370,483 |  |  |  | 383,974 |  |
| ABL Revolving Loans |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |

[0001564590-22-008035:notes:219]
The fair value of the derivative instruments was determined using pricing models developed based on the LIBOR swap rate, foreign currency exchange rates, and other observable market data, including quoted market prices, as appropriate using Level 2 inputs. The values were adjusted to reflect non-performance risk of both the counterparty and the Company, as necessary.

[0001564590-22-008035:notes:220]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of January 3, 2022 and December 28, 2020, which are considered Level 2 inputs.

[0001564590-22-008035:notes:221]
The fair value of plan assets in the defined benefit plan of $26,278 and $23,484 as of January 3, 2022 and December 28, 2020, respectively, were not included in the table above and was estimated based on quoted market prices of the securities that are actively traded and price quotes that are readily available, which are considered Level 1 inputs. See Note 15 for further details of the plan assets measured at fair value in the defined benefit plan.

[0001564590-22-008035:notes:222]
As of January 3, 2022 and December 28, 2020, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of January 3, 2022 consisted of $335,873 held in the U.S., with the remaining $201,805 held by foreign subsidiaries.

[0001564590-22-008035:notes:223]
The majority of the Company’s non-financial assets and liabilities, which include goodwill, intangible assets, inventories, and property, plant and equipment, are not required to be carried at fair value on a recurring basis. However, if certain triggering events occur (or are tested at least annually in the case of goodwill) such that a non-financial instrument is required to be evaluated for impairment, based upon a comparison of the non-financial instrument’s fair value to its carrying value, an impairment is recorded to reduce the carrying value to the fair value, if the carrying value exceeds the fair value.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-22-008035:notes:224]
| (13) | Commitments and Contingencies |

[0001564590-22-008035:notes:225]
Legal Matters

[0001564590-22-008035:notes:226]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of January 3, 2022 and December 28, 2020. However, these amounts are not material to the consolidated financial statements of the Company.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-22-008035:notes:227]
| (14) | Stock-Based Compensation |

[0001564590-22-008035:notes:228]
Incentive Compensation Plan

[0001564590-22-008035:notes:229]
The Company maintains a 2014 Incentive Compensation Plan (the Plan), which, with subsequent amendments, allows for issuance of up to 15,788 shares through its expiration date of February 2024.

[0001564590-22-008035:notes:230]
The Plan provides for the grant of performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock appreciation rights. The exercise price for awards is determined by the compensation committee of the board of directors. Each award shall vest and expire as determined by the compensation committee of the board of directors, with PRUs and RSUs generally vesting over three years for employees and one year for non-employee directors. PRUs and RSUs do not have voting rights. All grants provide for accelerated vesting if there is a change in control, as defined in the Plan.

[0001564590-22-008035:notes:231]
As of January 3, 2022, 507 PRUs, 3,127 RSUs and 60 stock options were outstanding under the Plan. Included in the 507 PRUs outstanding as of January 3, 2022 are 181 vested but not yet released. Included in the 3,127 RSUs outstanding as of January 3, 2022 are 530 vested but not yet released RSUs associated with non-employee directors. These RSUs vest over one year with release of the underlying shares of common stock deferred until retirement from the board of directors, (or until one year after retirement in the case of certain prior grants).

[0001564590-22-008035:notes:232]
Performance-based Restricted Stock Units

[0001564590-22-008035:notes:233]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period may range from zero to 2.4 times the target number depending on performance during the period. The performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and EBITDA (earnings before interest, tax, depreciation, and amortization expense), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three-year performance period.

[0001564590-22-008035:notes:234]
Under the PRU program, financial goals are set at the beginning of each fiscal year and performance is reviewed at the end of that year. The percentage to be applied to each participant’s target award ranges from zero to 160% based upon the extent to which the annual financial performance goals are achieved. If specific performance threshold levels for the annual financial goals are met, the amount earned for that element will be applied to one-third of the participants’ PRU award to determine the number of units earned.

[0001564590-22-008035:notes:235]
At the end of the three-year performance period, the total units earned, if any, are adjusted by applying a modifier, ranging from zero to 150% based on the Company’s TSR based on stock price changes relative to a group of peer companies selected by the Company’s compensation committee for the same three-year period.

[0001564590-22-008035:notes:236]
The TSR modifier is intended to ensure that there are limited or no payouts under the PRU program if the Company’s stock performance is significantly below the median TSR of a group of peer companies selected by the Company’s compensation committee over the three-year performance period. Where the annual financial goals have been met and where there has been strong relative TSR performance over the three-year performance period, the PRU program may provide substantial rewards to participants with a maximum payout of 2.4 times the initial PRU award. However, even if all of the annual financial metric goals are achieved in each of the three years, there will be no payouts if the Company’s stock performance is below that of the 10th percentile for PRUs granted in 2021, 2020 and 2019 of the group of peer companies selected by the Company’s compensation committee, as appropriate.

[0001564590-22-008035:notes:237]
Recipients of PRU awards generally must remain employed by the Company on a continuous basis through the end of the three-year performance period in order to receive any amount of the PRUs covered by that award. In events such as death, disability or retirement, the recipient may be entitled to pro-rata amounts of PRUs as defined in the Plan. Target shares subject to PRU awards do not have voting rights of common stock until earned and issued following the end of the three-year performance period.

[0001564590-22-008035:notes:238]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. As of January 3, 2022, management determined that vesting of the PRU awards was probable. PRU activity for the year ended January 3, 2022 was as follows:

[0001564590-22-008035:notes:239]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Outstanding shares as of December 28, 2020 |  |  | 289 |  |  | $ | 10.27 |  |
| Granted |  |  | 325 |  |  |  | 14.23 |  |
| Vested |  |  | (181 | ) |  |  | 9.20 |  |
| Forfeited / cancelled |  |  | (10 | ) |  |  | 9.20 |  |
| Change in units due to annual performance achievement |  |  | (97 | ) |  |  | 8.38 |  |
| Outstanding shares as of January 3, 2022 |  |  | 326 |  |  | $ | 15.41 |  |

[0001564590-22-008035:notes:240]
The fair value of PRUs granted is calculated using a Monte Carlo simulation model, as the TSR modifier contains a market condition. For the years ended January 3, 2022, December 28, 2020 and December 30, 2019, the following assumptions were used in determining the fair value:

[0001564590-22-008035:notes:241]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 (1) |  |  | December 28, 2020 (2) |  |  | December 30, 2019 (3) |  |
| Weighted-average fair value |  | $ | 14.23 |  |  | $ | 10.57 |  |  | $ | 10.17 |  |
| Risk-free interest rate |  |  | 0.18 | % |  |  | 0.18 | % |  |  | 2.18 | % |
| Dividend yield |  |  | — |  |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 47 | % |  |  | 49 | % |  |  | 38 | % |

[0001564590-22-008035:notes:242]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2019, the second year of the three-year performance period applicable to PRUs granted in 2020 and the first year of the three-year performance period applicable to PRUs granted in 2021. |

[0001564590-22-008035:notes:243]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2018, the second year of the three-year performance period applicable to PRUs granted in 2019 and the first year of the three-year performance period applicable to PRUs granted in 2020. |

[0001564590-22-008035:notes:244]
| (3) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2017, the second year of the three-year performance period applicable to PRUs granted in 2018 and the first year of the three-year performance period applicable to PRUs granted in 2019. |

[0001564590-22-008035:notes:245]
The risk-free interest rate for the expected term of PRUs is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is calculated using the Company’s historical stock price.

[0001564590-22-008035:notes:246]
Restricted Stock Units

[0001564590-22-008035:notes:247]
RSU activity for the year ended January 3, 2022 was as follows:

[0001564590-22-008035:notes:248]
|  |  | Shares |  |  | Weighted Average Grant-Date Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Non-vested RSUs outstanding as of December 28, 2020 |  |  | 2,566 |  |  | $ | 11.20 |  |
| Granted |  |  | 1,395 |  |  |  | 14.40 |  |
| Vested |  |  | (1,174 | ) |  |  | 14.65 |  |
| Forfeited |  |  | (190 | ) |  |  | 11.63 |  |
| Non-vested RSUs outstanding as of January 3, 2022 |  |  | 2,597 |  |  | $ | 12.70 |  |
| Vested and expected to vest through 2024 as of January 3, 2022 |  |  | 3,127 |  |  | $ | 12.41 |  |

[0001564590-22-008035:notes:249]
The fair value of the Company’s RSUs is determined based upon the closing common stock price on the grant date. The weighted average fair value per unit of RSUs granted was $14.40, $11.20 and $10.09 for the years ended January 3, 2022, December 28, 2020 and December 30, 2019, respectively. The total fair value of RSUs vested for the years ended January 3, 2022, December 28, 2020 and December 30, 2019 was $17,185, $13,093 and $13,954, respectively.

[0001564590-22-008035:notes:250]
Stock Options

[0001564590-22-008035:notes:251]
As of January 3, 2022, stock options outstanding was 60. This is not material to the consolidated financial statements of the Company.

[0001564590-22-008035:notes:252]
Stock-based Compensation Expense and Unrecognized Compensation Costs

[0001564590-22-008035:notes:253]
For the years ended January 3, 2022, December 28, 2020 and December 30, 2019, the amounts recognized in the consolidated statements of operations with respect to the stock-based compensation plan are as follows:

[0001564590-22-008035:notes:254]
|  |  | For the Year Ended |  |
|  |  | January 3, |  |  | December 28, |  |  | December 30, |  |
|  |  | 2022 |  |  | 2020 |  |  | 2019 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 4,714 |  |  | $ | 3,889 |  |  | $ | 3,148 |  |
| Selling and marketing |  |  | 2,540 |  |  |  | 1,919 |  |  |  | 1,887 |  |
| General and administrative |  |  | 9,718 |  |  |  | 10,083 |  |  |  | 11,568 |  |
| Research and development |  |  | 739 |  |  |  | 182 |  |  |  | 213 |  |
| Stock-based compensation expense recognized |  | $ | 17,711 |  |  | $ | 16,073 |  |  | $ | 16,816 |  |

[0001564590-22-008035:notes:255]
The following is a summary of total unrecognized compensation costs as of January 3, 2022:

[0001564590-22-008035:notes:256]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 24,406 |  |  |  | 1.4 |  |
| PRU awards |  |  | 1,457 |  |  |  | 1.0 |  |
| Stock options |  |  | 46 |  |  |  | 0.6 |  |
|  |  | $ | 25,909 |  |  |  |  |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-22-008035:notes:257]
| (15) | Employee Benefit Plans, Deferred Compensation Plan and Retirement Benefit Plan |

[0001564590-22-008035:notes:258]
As of January 3, 2022, the Company has several defined contribution plans. In North America, the Company has savings plans (the Savings Plans) in which eligible full-time employees can participate and contribute a percentage of compensation subject to the maximum allowed by the tax agencies. The Savings Plans provides for a partial match by the Company. In China, the Company contributes to either separate trust-administered funds or various government-sponsored pension plans on a mandatory basis. For all defined contribution plans, the Company has no further payment obligation once the required contributions have been made. The Company recorded contributions to defined contribution plans of $29,464, $23,146 and $31,253 during the years ended January 3, 2022, December 28, 2020 and December 30, 2019, respectively.

[0001564590-22-008035:notes:259]
The Company also maintains a deferred compensation plan (the Compensation Plan). The Compensation Plan is an unfunded, nonqualified deferred compensation plan and is limited to selected employees, including the Company’s named executive officers and directors. The Compensation Plan allows participants to defer up to 100% of their annual bonus and between 5% and 100% of their annual director fees. Amounts deferred under the Compensation Plan will be credited to accounts maintained by the Company for each participant and will be credited or debited with the participant’s proportionate share of any gains or losses attributable to the performance of investment options selected by the participant.

[0001564590-22-008035:notes:260]
Following the acquisition of Anaren on April 18, 2018, the Company has a noncontributory defined benefit pension plan covering eligible employees. Effective August 15, 2000, the plan was closed for new participants. Benefits under this plan generally are based on the employee’s years of service and compensation. Effective December 31, 2019, the plan is frozen as to further participation and to further benefit accruals.

[0001564590-22-008035:notes:261]
As of January 3, 2022 and December 28, 2020, the funded status of the accumulated benefit obligation was 83%. The Company expects to fund a minimum required contribution of approximately $346 during fiscal year 2022.

[0001564590-22-008035:notes:262]
The following tables set forth the changes in benefit obligation and the plan assets in the defined benefit plan described above for the years ended January 3, 2022, December 28, 2020 and December 30, 2019:

[0001564590-22-008035:notes:263]
|  |  | For the Year Ended |  |
| Change in Benefit Obligations |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Benefit obligation at beginning of year |  | $ | (33,470 | ) |  | $ | (30,600 | ) |  | $ | (27,661 | ) |
| Service cost |  |  | — |  |  |  | — |  |  |  | (397 | ) |
| Interest cost |  |  | (722 | ) |  |  | (907 | ) |  |  | (1,109 | ) |
| Amendments/curtailments/special termination |  |  | — |  |  |  | — |  |  |  | 1,636 |  |
| Actuarial gain (loss) |  |  | 1,304 |  |  |  | (3,146 | ) |  |  | (4,174 | ) |
| Benefits paid |  |  | 1,334 |  |  |  | 1,183 |  |  |  | 1,105 |  |
| Benefit obligation at end of year |  | $ | (31,554 | ) |  | $ | (33,470 | ) |  | $ | (30,600 | ) |
| Accumulated benefit obligation at end of year |  | $ | 31,554 |  |  | $ | 33,470 |  |  | $ | 30,600 |  |

[0001564590-22-008035:notes:264]
|  |  | For the Year Ended |  |
| Change in Plan Assets |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Fair value of plan assets at beginning of year |  | $ | 23,484 |  |  | $ | 21,287 |  |  | $ | 18,251 |  |
| Actual return on plan assets |  |  | 3,526 |  |  |  | 2,704 |  |  |  | 3,346 |  |
| Employer contributions |  |  | 602 |  |  |  | 676 |  |  |  | 795 |  |
| Benefits paid |  |  | (1,334 | ) |  |  | (1,183 | ) |  |  | (1,105 | ) |
| Fair value of plan assets at end of year |  | $ | 26,278 |  |  | $ | 23,484 |  |  | $ | 21,287 |  |
| Unfunded status |  | $ | (5,276 | ) |  | $ | (9,986 | ) |  | $ | (9,313 | ) |
| Net amount recognized |  | $ | (5,276 | ) |  | $ | (9,986 | ) |  | $ | (9,313 | ) |

[0001564590-22-008035:notes:265]
Amounts before income tax effect recognized in the consolidated balance sheets consists of the following:

[0001564590-22-008035:notes:266]
|  |  | As of |  |  | As of |  |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  |
|  |  | (In thousands) |  |  |
| Other long-term liabilities |  | $ | (5,276 | ) |  | $ | (9,986 | ) |  |
| Net amount recognized |  | $ | (5,276 | ) |  | $ | (9,986 | ) |  |

[0001564590-22-008035:notes:267]
Amounts before income tax effect included in accumulated other comprehensive loss as of January 3, 2022 and
December 28, 2020 are as follows:

[0001564590-22-008035:notes:268]
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  |
|  |  | (In thousands) |  |  |
| Net actuarial loss |  | $ | (238 | ) |  | $ | (3,811 | ) |  |
| Accumulated other comprehensive loss |  | $ | (238 | ) |  | $ | (3,811 | ) |  |

[0001564590-22-008035:notes:269]
The net actuarial loss during the year ended January 3, 2022 was primarily driven by a decrease in liabilities due to a higher assumed discount rate.

[0001564590-22-008035:notes:270]
The components included in the net periodic benefit cost and the increase in minimum liability included in other comprehensive loss for the years ended January 3, 2022, December 28, 2020 and December 30, 2019 are as follows:

[0001564590-22-008035:notes:271]
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |  |
|  |  | (In thousands) |  |  |
| Service cost |  | $ | — |  |  | $ | — |  |  | $ | 397 |  |  |
| Interest cost |  |  | 722 |  |  |  | 907 |  |  |  | 1,109 |  |  |
| Expected return on plan assets |  |  | (1,279 | ) |  |  | (1,272 | ) |  |  | (1,228 | ) |  |
| Amortization of net actuarial loss |  |  | 23 |  |  |  | — |  |  |  | — |  |  |
| Net periodic benefit cost |  | $ | (534 | ) |  | $ | (365 | ) |  | $ | 278 |  |  |

[0001564590-22-008035:notes:272]
The weighted-average assumptions used to determine benefit obligations for this plan as of January 3, 2022, December 28, 2020 and December 30, 2019 are as follows:

[0001564590-22-008035:notes:273]
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |  |
| Discount rate |  |  | 2.60 |  | % |  | 2.20 |  | % |  | 3.02 |  | % |
| Rate of compensation increase |  |  | — |  |  |  | — |  |  |  | 3.20 |  |  |
| Expected return on plan assets |  |  | 5.50 |  |  |  | 5.50 |  |  |  | 6.00 |  |  |

[0001564590-22-008035:notes:274]
The Company determines the discount rate assumption based on the internal rate of return for a portfolio of high quality bonds, with a minimum rating of Moody's AA Corporate and with maturities that are consistent with the projected future cash flow obligations.

[0001564590-22-008035:notes:275]
The weighted-average assumptions used to determine net periodic benefit cost for the years ended January 3, 2022, December 28, 2020 and December 30, 2019 are as follows:

[0001564590-22-008035:notes:276]
|  |  | For the Year Ended |  |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |  |
| Discount rate |  |  | 2.20 |  | % |  | 3.02 |  | % |  | 4.09 |  | % |
| Rate of compensation increase |  |  | — |  |  |  | — |  |  |  | 3.20 |  |  |
| Expected return on plan assets |  |  | 5.50 |  |  |  | 6.00 |  |  |  | 6.75 |  |  |

[0001564590-22-008035:notes:277]
The Company determines the expected long-term rate of return on plan assets based upon recommendations from its pension plan's investment advisors and using an allocation approach that considers diversification and rebalancing for a portfolio of assets invested over a long-term time horizon. The approach relies on the historical returns of the plan's portfolio and relationships between equities and fixed income investments, consistent with the widely accepted capital market principle that a diversified portfolio with a larger allocation to equity investments can generate a greater return over the long run. Additionally, the Company monitors the mix of investments in its portfolio to ensure alignment with its expected long-term pension obligations. The Company reviews the expected long-term rate of return annually and revises it as appropriate.

[0001564590-22-008035:notes:278]
Investments shall be made pursuant to the following objectives: 1) preserve the purchasing power of the plan’s assets adjusted for inflation; 2) provide long-term growth; and 3) avoid significant volatility. Asset allocation shall be determined based on a long-term target allocation having 29% of assets invested in large-cap stocks, 11% in mid-cap stocks, 11% in small-cap stocks, 11% in international stocks, 34% in the broad bond market, and 3% in the real estate market, with little or none invested in cash. Both the investment allocation and the plan performance are reviewed periodically.

[0001564590-22-008035:notes:279]
The target allocation for 2022 and the plan asset allocation at the end of 2021 and 2020, in percentages, by asset category are as follows:

[0001564590-22-008035:notes:280]
|  |  | Target Allocation 2022 |  |  |  | January 3, 2022 |  |  |  | December 28, 2020 |  |  |
| Equity securities (1) |  |  | 65 |  | % |  |  | 67 |  | % |  |  | 68 |  | % |
| Debt securities (2) |  |  | 34 |  |  |  |  | 32 |  |  |  |  | 30 |  |  |
| Cash and cash equivalents (3) |  |  | 1 |  |  |  |  | 1 |  |  |  |  | 2 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-22-008035:notes:281]
The following table summarizes plan assets measured at fair value as of January 3, 2022 and December 28, 2020:

[0001564590-22-008035:notes:282]
|  |  | As of |  |
|  |  | January 3, 2022 |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
|  |  | (In thousands) |  |
| Equity securities (1) |  | $ | 17,661 |  |  | $ | 17,661 |  |  | $ | — |  |  | $ | — |  |
| Debt securities (2) |  |  | 8,290 |  |  |  | 8,290 |  |  |  | — |  |  |  | — |  |
| Cash and cash equivalents (3) |  |  | 327 |  |  |  | 327 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 26,278 |  |  | $ | 26,278 |  |  | $ | — |  |  | $ | — |  |
|  |  | As of |  |
|  |  | December 28, 2020 |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
|  |  | (In thousands) |  |
| Equity securities (1) |  | $ | 15,922 |  |  | $ | 15,922 |  |  | $ | — |  |  | $ | — |  |
| Debt securities (2) |  |  | 7,015 |  |  |  | 7,015 |  |  |  | — |  |  |  | — |  |
| Cash and cash equivalents (3) |  |  | 547 |  |  |  | 547 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 23,484 |  |  | $ | 23,484 |  |  | $ | — |  |  | $ | — |  |

[0001564590-22-008035:notes:283]
| (1) | Equity securities include U.S. and foreign exchange traded common and preferred stocks and mutual funds. Common and preferred shares issued by U.S. and non-U.S. corporations are traded actively on exchanges and price quotes for these shares are readily available. Holdings of corporate stock are categorized as Level 1 investments. |

[0001564590-22-008035:notes:284]
| (2) | Debt securities include the debt of the U.S. Treasury and U.S. and foreign corporate issuers. U.S. Treasury notes and bonds are actively traded and price quotes for these securities are readily available. Holdings of U.S. Treasury notes and bonds are categorized as Level 1 investments. |

[0001564590-22-008035:notes:285]
| (3) | Cash and cash equivalents include short-term U.S. government investment notes, short-term money market mutual funds, accrued income and cash held on account. Cash held on account and short- term U.S. government investment notes (including accrued income thereon) for which there is an active market and daily pricing for the security are categorized as Level 1 investments. |

[0001564590-22-008035:notes:286]
The Company seeks to maximize medium to long-term returns of the overall pension plan assets with reasonable levels of investment risk. One element of controlling the overall investment risk is through diversification of asset allocation, among domestic and international equity and debt instruments. The plan's equity investments include foreign and domestic exchange traded equities across a range of industries and countries, but primarily in the domestic markets. The plan's debt securities are primarily invested in government and corporate issuers primarily in the domestic market.

[0001564590-22-008035:notes:287]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid:

[0001564590-22-008035:notes:288]
|  |  | (In thousands) |  |
| 2022 |  | $ | 1,369 |  |
| 2023 |  |  | 1,451 |  |
| 2024 |  |  | 1,535 |  |
| 2025 |  |  | 1,600 |  |
| 2026 |  |  | 1,652 |  |
| Years 2027 through 2031 |  |  | 8,709 |  |


## us-gaap:PreferredStockTextBlock

[0001564590-22-008035:notes:289]
| (16) | Preferred Stock |

[0001564590-22-008035:notes:290]
The board of directors has the authority, without action by stockholders, to designate and issue preferred stock in one or more series. The board of directors may also designate the rights, preferences and privileges of each series of preferred stock, any or all of which may be superior to the rights of the common stock. As of January 3, 2022, no shares of preferred stock were outstanding.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-22-008035:notes:291]
| (17) | Segment Information |

[0001564590-22-008035:notes:292]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting. As a result of the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation. See Note 20 for further details. The PCB reportable segment consists of fifteen domestic PCB and sub-system plants; six PCB fabrication plants in China; and one in Canada. The RF&S Components reportable segment consists of one domestic RF component plant and one RF component plant in China.

[0001564590-22-008035:notes:293]
The Company, including the chief operating decision maker, evaluates segment performance based on reportable segment income, which is operating income before amortization of intangibles. Interest expense and interest income are not presented by segment since they are not included in the measure of segment profitability reviewed by the chief operating decision maker. All inter-segment transactions have been eliminated.

[0001564590-22-008035:notes:294]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 2,186,901 |  |  | $ | 1,980,918 |  |  | $ | 1,909,628 |  |
| RF&S Components |  |  | 58,583 |  |  |  | 44,656 |  |  |  | 62,315 |  |
| Other (1) |  |  | 3,256 |  |  |  | 79,748 |  |  |  | 161,267 |  |
| Total net sales |  | $ | 2,248,740 |  |  | $ | 2,105,322 |  |  | $ | 2,133,210 |  |
| Operating Segment Income: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 262,442 |  |  | $ | 266,319 |  |  | $ | 235,455 |  |
| RF&S Components |  |  | 22,035 |  |  |  | (56,671 | ) |  |  | 29,376 |  |
| Corporate and Other (1) |  |  | (117,097 | ) |  |  | (137,183 | ) |  |  | (104,604 | ) |
| Total operating segment income |  |  | 167,380 |  |  |  | 72,465 |  |  |  | 160,227 |  |
| Amortization of definite-lived intangibles (2) |  |  | (41,389 | ) |  |  | (44,373 | ) |  |  | (50,598 | ) |
| Total operating income |  |  | 125,991 |  |  |  | 28,092 |  |  |  | 109,629 |  |
| Total other expense, net |  |  | (55,938 | ) |  |  | (74,369 | ) |  |  | (75,303 | ) |
| Income (loss) before income taxes |  | $ | 70,053 |  |  | $ | (46,277 | ) |  | $ | 34,326 |  |

[0001564590-22-008035:notes:295]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Depreciation Expense: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 76,380 |  |  | $ | 79,737 |  |  | $ | 80,635 |  |
| RF&S Components |  |  | 1,671 |  |  |  | 1,742 |  |  |  | 1,720 |  |
| Corporate and Other (1) |  |  | 7,891 |  |  |  | 18,093 |  |  |  | 11,015 |  |
| Total depreciation expense |  | $ | 85,942 |  |  | $ | 99,572 |  |  | $ | 93,370 |  |
| Capital Expenditures: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 74,028 |  |  | $ | 64,895 |  |  | $ | 103,851 |  |
| RF&S Components |  |  | 1,604 |  |  |  | 1,514 |  |  |  | 3,683 |  |
| Corporate and Other (1) |  |  | 6,735 |  |  |  | 5,916 |  |  |  | 9,872 |  |
| Total capital expenditures |  | $ | 82,367 |  |  | $ | 72,325 |  |  | $ | 117,406 |  |

[0001564590-22-008035:notes:296]
|  |  | As of |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,655,401 |  |  | $ | 1,528,925 |  |
| RF&S Components |  |  | 216,737 |  |  |  | 227,990 |  |
| Corporate and Other (1) |  |  | 1,153,409 |  |  |  | 1,139,029 |  |
| Total assets |  | $ | 3,025,547 |  |  | $ | 2,895,944 |  |

[0001564590-22-008035:notes:297]
| (2) | Amortization of definite-lived intangibles primarily relates to the PCB and RF&S Components reportable segments. For the years ended January 3, 2022, December 28, 2020 and December 30, 2019, $5,641, $5,535 and $4,822, respectively, of amortization expense is included in cost of goods sold. |

[0001564590-22-008035:notes:298]
The Corporate category primarily includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, information technology and human resources personnel, as well as global sales and marketing personnel, research and development costs, and acquisition and integration costs associated with acquisitions and divestitures of $1,002, $273 and $6,902 for the years ended January 3, 2022, December 28, 2020 and December 30, 2019, respectively, are included in Corporate.

[0001564590-22-008035:notes:299]
The Company markets and sells its products in approximately 52 countries. Other than in the United States and China, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales and long-lived assets are as follows:

[0001564590-22-008035:notes:300]
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
|  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |
|  |  | (In thousands) |  |
| United States |  | $ | 1,049,590 |  |  | $ | 1,131,663 |  |  | $ | 1,086,440 |  |  | $ | 1,154,218 |  |  | $ | 1,118,725 |  |  | $ | 1,348,741 |  |
| China |  |  | 327,435 |  |  |  | 382,580 |  |  |  | 334,462 |  |  |  | 387,627 |  |  |  | 341,779 |  |  |  | 335,191 |  |
| Other |  |  | 871,715 |  |  |  | 28,754 |  |  |  | 684,420 |  |  |  | 27,221 |  |  |  | 672,706 |  |  |  | 26,473 |  |
| Total |  | $ | 2,248,740 |  |  | $ | 1,542,997 |  |  | $ | 2,105,322 |  |  | $ | 1,569,066 |  |  | $ | 2,133,210 |  |  | $ | 1,710,405 |  |

[0001564590-22-008035:notes:301]
Net sales are attributed to countries by country invoiced.


## us-gaap:EarningsPerShareTextBlock

[0001564590-22-008035:notes:302]
| (18) | Earnings Per Share |

[0001564590-22-008035:notes:303]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share from continuing operations for the years ended January 3, 2022, December 28, 2020 and December 30, 2019:

[0001564590-22-008035:notes:304]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income (loss) from continuing operations |  | $ | 54,414 |  |  | $ | (16,386 | ) |  | $ | 31,921 |  |
| Basic weighted average shares |  |  | 106,314 |  |  |  | 106,366 |  |  |  | 105,195 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,639 |  |  |  | — |  |  |  | 1,137 |  |
| Dilutive effect of outstanding warrants |  |  | 200 |  |  |  | — |  |  |  | — |  |
| Diluted shares |  |  | 108,153 |  |  |  | 106,366 |  |  |  | 106,332 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.51 |  |  | $ | (0.15 | ) |  | $ | 0.30 |  |
| Diluted |  | $ | 0.50 |  |  | $ | (0.15 | ) |  | $ | 0.30 |  |

[0001564590-22-008035:notes:305]
For the years ended January 3, 2022, December 28, 2020 and December 30, 2019, PRUs, RSUs and stock options to purchase 895, 433 and 730 shares of common stock, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met at January 3, 2022, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common shares during the applicable year and, as a result, the impact would be anti-dilutive.

[0001564590-22-008035:notes:306]
The below is a summary of amounts convertible to common stock related to Convertible Senior Notes and related warrants:

[0001564590-22-008035:notes:307]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Common stock related to Convertible Senior Notes |  |  | — |  |  |  | — |  |  |  | 25,938 |  |
| Warrants to purchase common stock |  |  | 707 |  |  |  | 25,940 |  |  |  | 25,940 |  |

[0001564590-22-008035:notes:308]
During the year ended December 28, 2020, the Company calculated the dilutive effect of Convertible Senior Notes using the treasury stock method because the Company repaid and settled the Convertible Senior Notes in cash. This change in policy from the if-converted method to treasury stock method was applied on a prospective basis. For the year ended December 28, 2020, the effect of shares of common stock related to the Company’s Convertible Senior Notes were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive due to the net loss from continuing operations. For the year ended December 30, 2019, the effect of shares of common stock related to the Company’s Convertible Senior Notes, based on the if-converted method, were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive.

[0001564590-22-008035:notes:309]
Outstanding warrants for the years ended December 28, 2020 and December 30, 2019 to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock were greater than the average market price of common shares during the applicable year, and therefore, the effect would be anti-dilutive.


## us-gaap:TreasuryStockTextBlock

[0001564590-22-008035:notes:310]
| (19) | Share Repurchase Program |

[0001564590-22-008035:notes:311]
On February 3, 2021, the Company announced that its Board of Directors authorized and approved a share repurchase program. Under the program, the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through February 3, 2023. The Company may repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (the Exchange Act) which sets certain restrictions on the method, timing, price and volume of open market stock repurchases. In addition, the Company adopted a trading plan, which may be amended from time to time, in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price and amount of any repurchases is determined at the Company’s discretion, and the share repurchase program may be suspended, terminated or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.

[0001564590-22-008035:notes:312]
During the year ended January 3, 2022, the Company repurchased a total of 4,723 shares of common stock for a total cost of $64,726 (including commissions). As of January 3, 2022, the remaining amount available to be repurchased under the Company’s share repurchase program was $35,369.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-22-008035:notes:313]
| (20) | Restructuring Charges |

[0001564590-22-008035:notes:314]
On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. The E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company ceased operations at the SH E-MS and SZ facilities while integrating the SH BPA facility into its PCB operations. The restructuring is another step in advancing the Company’s stated strategy of increasing its focus on differentiated higher margin products that more fully leverage the Company’s early engagement capabilities and industry leading engineering-based technology solutions. The Company closed the SH E-MS and SZ facilities at the end of 2020. As of January 3, 2022, the Company had incurred approximately $20,028 of restructuring charges and $6,702 of accelerated depreciation expense since the April 29, 2020 announcement.

[0001564590-22-008035:notes:315]
In connection with the restructuring of its E-M Solutions business unit and other global realignment restructuring efforts, the Company recognized employee separation, contract termination and other costs during the years ended January 3, 2022, December 28, 2020 and December 30, 2019. Contract termination and other costs primarily represented plant closure costs.

[0001564590-22-008035:notes:316]
The below table summarizes such restructuring costs by reportable segment for the years ended January 3, 2022, December 28, 2020 and December 30, 2019:

[0001564590-22-008035:notes:317]
|  |  | For the Year Ended |  |
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |  | December 30, 2019 |  |
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 504 |  |  | $ | 122 |  |  | $ | 626 |  |  | $ | — |  |  | $ | 14 |  |  | $ | 14 |  |  | $ | 5,218 |  |  | $ | — |  |  | $ | 5,218 |  |
| RF&S Components |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 52 |  |  |  | — |  |  |  | 52 |  |
| Corporate and Other (1) |  |  | 415 |  |  |  | 3,204 |  |  |  | 3,619 |  |  |  | 15,270 |  |  |  | 1,480 |  |  |  | 16,750 |  |  |  | 80 |  |  |  | 30 |  |  |  | 110 |  |
|  |  | $ | 919 |  |  | $ | 3,326 |  |  | $ | 4,245 |  |  | $ | 15,270 |  |  | $ | 1,494 |  |  | $ | 16,764 |  |  | $ | 5,350 |  |  | $ | 30 |  |  | $ | 5,380 |  |

[0001564590-22-008035:notes:318]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated balance sheets. The below table shows the utilization of the accrued restructuring costs during the years ended January 3, 2022 and December 28, 2020:

[0001564590-22-008035:notes:319]
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of December 30, 2019 |  | $ | 260 |  |  | $ | 242 |  |  | $ | 502 |  |
| Charged to expense |  |  | 15,270 |  |  |  | 1,494 |  |  |  | 16,764 |  |
| Amount paid |  |  | (8,467 | ) |  |  | (1,417 | ) |  |  | (9,884 | ) |
| Accrued as of December 28, 2020 |  | $ | 7,063 |  |  | $ | 319 |  |  | $ | 7,382 |  |
| Charged to expense |  |  | 919 |  |  |  | 3,326 |  |  |  | 4,245 |  |
| Amount paid |  |  | (7,974 | ) |  |  | (3,619 | ) |  |  | (11,593 | ) |
| Accrued as of January 3, 2022 |  | $ | 8 |  |  | $ | 26 |  |  | $ | 34 |  |
