# TTMI 8-K — 0001193125-22-032669 filed 2022-02-09

## item codes, every 8-K on or before 2022-03-01

- 2022-03-01 0001193125-22-059877 — 7.01, 9.01
- 2022-02-09 0001193125-22-032669 — 2.02, 9.01
- 2021-10-27 0001193125-21-309324 — 2.02, 9.01
- 2021-07-28 0001193125-21-227406 — 2.02, 9.01
- 2021-06-14 0001193125-21-189568 — 5.02, 9.01
- 2021-05-13 0001193125-21-159545 — 2.02, 5.02, 5.07, 9.01
- 2021-04-28 0001193125-21-136849 — 2.02, 9.01
- 2021-03-16 0001193125-21-083011 — 1.02, 8.01
- 2021-03-10 0001193125-21-076246 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2021-02-24 0001193125-21-054812 — 7.01, 9.01
- 2021-02-23 0001193125-21-051549 — 7.01, 9.01
- 2021-02-03 0001193125-21-027322 — 2.02, 8.01, 9.01
- 2020-12-15 0001193125-20-318208 — 7.01, 9.01
- 2020-10-28 0001193125-20-279980 — 2.02, 9.01
- 2020-09-04 0001193125-20-239645 — 5.02
- 2020-07-29 0001193125-20-203110 — 2.02, 9.01
- 2020-05-08 0001193125-20-137566 — 5.07
- 2020-05-04 0001193125-20-131366 — 7.01, 9.01
- 2020-04-29 0001193125-20-126358 — 2.05, 7.01, 9.01
- 2020-04-29 0001193125-20-126117 — 2.02, 9.01
- 2020-04-23 0001193125-20-117365 — 2.01, 7.01, 9.01
- 2020-02-05 0001193125-20-025365 — 2.02, 9.01
- 2020-01-31 0001193125-20-021278 — 5.02
- 2020-01-22 0001193125-20-012011 — 1.01, 7.01, 9.01
- 2019-10-30 0001193125-19-278973 — 2.02, 9.01
- 2019-08-19 0001193125-19-224091 — 5.02, 9.01
- 2019-07-31 0001193125-19-208689 — 2.02, 9.01
- 2019-07-24 0001193125-19-201401 — 1.01, 2.03
- 2019-06-13 0001193125-19-171943 — 7.01, 9.01
- 2019-06-06 0001193125-19-167332 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2019-05-09 0001193125-19-143113 — 5.07
- 2019-05-01 0001193125-19-132977 — 2.02, 9.01
- 2019-02-06 0001193125-19-029540 — 2.02, 9.01
- 2019-01-15 0001193125-19-009142 — 2.02, 9.01
- 2018-10-30 0001193125-18-312212 — 2.02, 9.01
- 2018-10-22 0001193125-18-303926 — 5.02
- 2018-09-06 0001193125-18-268231 — 5.02, 9.01
- 2018-08-01 0001193125-18-234997 — 2.02, 9.01
- 2018-06-29 0001193125-18-209635 — 9.01 — amendment of 0001193125-18-120583
- 2018-05-29 0001193125-18-176976 — 7.01, 9.01
- 2018-05-10 0001193125-18-159394 — 5.07
- 2018-05-09 0001193125-18-157596 — 5.02
- 2018-05-02 0001193125-18-148650 — 2.02, 9.01
- 2018-04-18 0001193125-18-120583 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2018-02-21 0001193125-18-052169 — 8.01, 9.01
- 2018-02-20 0001193125-18-050385 — 5.02, 9.01
- 2018-02-09 0001193125-18-036966 — 7.01, 9.01
- 2018-02-07 0001193125-18-034744 — 2.02, 9.01
- 2017-12-14 0001193125-17-369625 — 1.01, 2.03, 9.01
- 2017-12-04 0001193125-17-359439 — 1.01, 7.01, 9.01
- 2017-11-01 0001193125-17-329425 — 2.02, 9.01
- 2017-09-29 0001193125-17-298999 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2017-09-15 0001193125-17-286491 — 7.01, 9.01
- 2017-09-11 0001193125-17-281193 — 7.01, 9.01
- 2017-09-06 0001193125-17-277536 — 7.01, 9.01
- 2017-08-02 0001193125-17-245823 — 2.02, 9.01
- 2017-05-18 0001193125-17-173896 — 5.02, 5.07
- 2017-05-08 0001193125-17-162548 — 2.02, 9.01
- 2017-03-01 0001193125-17-063931 — 1.01, 1.02, 5.02
- 2017-02-08 0001193125-17-034652 — 2.02, 9.01
- 2016-11-18 0001193125-16-772305 — 8.01, 9.01
- 2016-10-26 0001193125-16-747948 — 2.02, 9.01
- 2016-10-20 0001193125-16-742905 — 5.02
- 2016-10-05 0001193125-16-731552 — 5.02, 9.01
- 2016-09-27 0001193125-16-720828 — 1.01, 2.03, 7.01, 9.01
- 2016-07-27 0001193125-16-659983 — 2.02, 9.01
- 2016-05-23 0001193125-16-599342 — 7.01, 9.01
- 2016-05-18 0001193125-16-594656 — 5.02, 5.03, 5.07, 9.01
- 2016-04-27 0001171843-16-009432 — 2.02, 9.01
- 2016-03-08 0001193125-16-495457 — 5.03, 7.01, 9.01
- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2022-03-01

- none on or before 2022-03-01

## item 2.02 — earnings release, exhibit 99.1

[0001193125-22-032669:8k_2_02:1]
EX-99.1
2
d306565dex991.htm
EX-99.1

[0001193125-22-032669:8k_2_02:2]
EX-99.1

[0001193125-22-032669:8k_2_02:3]
Exhibit 99.1

[0001193125-22-032669:8k_2_02:4]
| TTM Technologies, Inc., Q4’21 |  |  |  | Contact: |
|  |  |  |  | Sameer Desai, |
|  |  |  |  | Vice President, Corporate |
|  |  |  |  | Development & Investor Relations |
|  |  |  |  | Sameer.desai@ttmtech.com |
|  |  |  |  | 714-327-3050 |

[0001193125-22-032669:8k_2_02:5]
TTM Technologies, Inc. Reports Fiscal Fourth Quarter and 2021 Results

[0001193125-22-032669:8k_2_02:6]
Santa Ana, CA – February 9, 2022– TTM Technologies, Inc. (NASDAQ:TTMI), a leading global printed circuit board (“PCB”) and radio
frequency (“RF”) components manufacturer, today reported results for the fourth quarter and fiscal 2021, which ended on January 3, 2022.

[0001193125-22-032669:8k_2_02:7]
Fourth Quarter 2021 Highlights

[0001193125-22-032669:8k_2_02:8]
|  | • |  | Net sales were $598.1 million |

[0001193125-22-032669:8k_2_02:9]
|  | • |  | GAAP net income of $8.4 million, or $0.08 per diluted share |

[0001193125-22-032669:8k_2_02:10]
|  | • |  | Non-GAAP net income was $36.2 million, or $0.34 per diluted share |

[0001193125-22-032669:8k_2_02:11]
|  | • |  | Operating cash flow of $62.4 million |

[0001193125-22-032669:8k_2_02:12]
|  | • |  | Repurchased 2.2 million shares of common stock for $29.6 million at an average price of $13.47 per share |

[0001193125-22-032669:8k_2_02:13]
Fourth Quarter 2021 GAAP Financial Results

[0001193125-22-032669:8k_2_02:14]
Net sales for the fourth quarter of 2021 were $598.1 million, compared to $523.8 million in the fourth quarter of 2020.

[0001193125-22-032669:8k_2_02:15]
GAAP operating income for the fourth quarter of 2021 was $33.1 million. This compares to GAAP operating income of $29.2 million in the
fourth quarter of 2020.

[0001193125-22-032669:8k_2_02:16]
GAAP net income for the fourth quarter of 2021 was $8.4 million, or $0.08 per diluted share, compared to net income
of $39.0 million, or $0.34 per diluted share in the fourth quarter of 2020.

[0001193125-22-032669:8k_2_02:17]
Fourth Quarter 2021
Non-GAAP Financial Results

[0001193125-22-032669:8k_2_02:18]
On a non-GAAP basis, net income for the
fourth quarter of 2021 was $36.2 million, or $0.34 per diluted share. This compares to non-GAAP net income of $40.2 million, or $0.37 per diluted share, for the fourth quarter of 2020.

[0001193125-22-032669:8k_2_02:19]
Adjusted EBITDA in the fourth quarter of 2021 was $70.4 million, or 11.8 percent of net sales, compared to adjusted EBITDA of
$68.2 million, or 13.0% percent of net sales, for the fourth quarter of 2020.

[0001193125-22-032669:8k_2_02:20]
“In the fourth quarter, TTM achieved revenues above the
high end of guidance and non-GAAP earnings at the high end of the guided range. This outperformance was driven by strength in all of our commercial end markets, despite labor and production challenges in North
America and tight supply conditions globally for certain raw materials,” said Tom Edman, CEO of TTM.

[0001193125-22-032669:8k_2_02:21]
Full Year 2021 Financial Results1

[0001193125-22-032669:8k_2_02:22]
Net sales for fiscal year 2021 increased to $2.25 billion from $2.11 billion
from continuing operations in fiscal year 2020, a 6.8% increase. Excluding the two E-MS facilities that were closed at the end of 2020, our revenues grew 10.9% for the year.

[0001193125-22-032669:8k_2_02:23]
GAAP operating income for fiscal year 2021 was $126.0 million, an increase from GAAP operating income of $28.1 million from continuing
operations in fiscal year 2020.

[0001193125-22-032669:8k_2_02:24]
| 1 | In 2020, we completed the sale of the Mobility business so we are comparing 2021 results to 2020 continuing operations, which excludes the Mobility business. The E-MS business is still included in 2020 continuing operations. |

[0001193125-22-032669:8k_2_02:25]
| TTM Technologies, Inc., Q4’21 |  |  |  | Contact: |
|  |  |  |  | Sameer Desai, |
|  |  |  |  | Vice President, Corporate |
|  |  |  |  | Development & Investor Relations |
|  |  |  |  | Sameer.desai@ttmtech.com |
|  |  |  |  | 714-327-3050 |

[0001193125-22-032669:8k_2_02:26]
GAAP net income for fiscal year 2021 was $54.4 million, or $0.50 per diluted share, compared to GAAP net loss of $16.4 million
from continuing operations, or ($0.15) per diluted share, for fiscal year 2020.

[0001193125-22-032669:8k_2_02:27]
On a non-GAAP basis, net income
for fiscal year 2021 was $138.0 million, or $1.28 per diluted share. This compares to fiscal year 2020 non-GAAP net income of $116.7 million from continuing operations, or $1.10 per diluted share.

[0001193125-22-032669:8k_2_02:28]
Adjusted EBITDA for fiscal year 2021 was $275.6 million, or 12.3 percent of net sales, compared to $272.3 million from continuing
operations, or 12.9 percent of net sales, for fiscal year 2020. Cash flow from operations for fiscal year 2021 was $176.6 million.

[0001193125-22-032669:8k_2_02:29]
“Despite the headwinds from materials and labor inflation and availability, COVID-19 and the strengthening
Chinese currency, we delivered solid results in 2021 with revenues growing 10.9% year on year excluding divested businesses,” continued Edman. “Also in 2021, we generated $176.6 million in operating cash flow which enabled us to
strengthen our balance sheet and return capital to our shareholders. For the year we repurchased 4.7 million shares for $64.6 million on our $100 million stock buyback program.”

[0001193125-22-032669:8k_2_02:30]
Business Outlook

[0001193125-22-032669:8k_2_02:31]
In the first quarter, we are seeing
continued labor challenges along with normal seasonality associated with Chinese New Year and one less week in the quarter compared to the fourth quarter.

[0001193125-22-032669:8k_2_02:32]
Taking these factors into consideration, TTM estimates that revenue for the first quarter of 2022 will be in the range of $540 million to
$580 million, and non-GAAP net income will be in the range of $0.20 to $0.26 per diluted share.

[0001193125-22-032669:8k_2_02:33]
Live Webcast/Conference Call

[0001193125-22-032669:8k_2_02:34]
TTM will host a conference
call and webcast to discuss fourth quarter 2021 results and the first quarter 2022 outlook on Wednesday, February 9th, 2022 at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call will include forward-looking statements.

[0001193125-22-032669:8k_2_02:35]
Telephone access is available by dialing domestic 888-394-8218 or
international 323-794-2588 (ID 1667874). The conference call also will be webcast on TTM’s website at www.ttm.com.

[0001193125-22-032669:8k_2_02:36]
To Access a Replay of the Webcast

[0001193125-22-032669:8k_2_02:37]
The replay of the
webcast will remain accessible for one week following the live event on TTM’s website at www.ttm.com.

[0001193125-22-032669:8k_2_02:38]
About TTM

[0001193125-22-032669:8k_2_02:39]
TTM Technologies, Inc. is a leading global printed circuit board manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs
and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. TTM stands for
time-to-market, representing how TTM’s time-critical, one-stop manufacturing services enable customers to shorten the time
required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001193125-22-032669:8k_2_02:40]
| TTM Technologies, Inc., Q4’21 |  |  |  | Contact: |
|  |  |  |  | Sameer Desai, |
|  |  |  |  | Vice President, Corporate |
|  |  |  |  | Development & Investor Relations |
|  |  |  |  | Sameer.desai@ttmtech.com |
|  |  |  |  | 714-327-3050 |

[0001193125-22-032669:8k_2_02:41]
Forward-Looking Statements

[0001193125-22-032669:8k_2_02:42]
The preliminary financial results included in this press release represent the most current information available to management. The company’s actual
results when disclosed in its Form 10-K may differ from these preliminary results as a result of the completion of the company’s financial closing procedures; final adjustments; completion of the review
by the company’s independent registered accounting firm; and other developments that may arise between now and the disclosure of the final results. This release contains forward-looking statements that relate to future events or performance.
TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These statements reflect TTM’s current expectations, and TTM does not undertake to update or revise these forward looking
statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond
TTM’s control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, the impact of COVID-19, general
market and economic conditions, including interest rates, currency exchange rates and consumer spending, demand for TTM’s products, market pressures on prices of TTM’s products, warranty claims, changes in product mix, contemplated
significant capital expenditures and related financing requirements, TTM’s dependence upon a small number of customers and other factors set forth in the “Risk Factors” and “Management’s Discussion and Analysis of Financial
Condition and Results of Operations” sections of the Company’s public reports filed with the SEC.

[0001193125-22-032669:8k_2_02:43]
About Our
Non-GAAP Financial Measures

[0001193125-22-032669:8k_2_02:44]
This release includes information about TTM’s adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing financial performance.

[0001193125-22-032669:8k_2_02:45]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no
standardized measurement prescribed by GAAP and may not be comparable to similar non-GAAP financial measures used by other companies. TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliation to the most directly comparable GAAP financial measure. However, the non-GAAP financial measures should not be considered in
isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001193125-22-032669:8k_2_02:46]
With respect to the Company’s outlook for non-GAAP net income per diluted share, we are unable to predict with reasonable certainty or without unreasonable effort certain items that may affect a comparable measure calculated and presented in accordance with
GAAP. Our expected non-GAAP net income per diluted share excludes primarily the future impact of restructuring actions, impairment charges, unusual gains and losses, and tax adjustments. These reconciling
items are highly variable and difficult to predict due to various factors outside of management’s control and could have a material impact on our future period net income per diluted share calculated and presented in accordance with GAAP.
Accordingly, a reconciliation of non-GAAP net income per diluted share to a comparable measure calculated and presented in accordance with GAAP is not available without unreasonable effort and has not been
provided.

[0001193125-22-032669:8k_2_02:47]
- Tables Follow –

[0001193125-22-032669:8k_2_02:48]
| TTM TECHNOLOGIES, INC. |  |
| Selected Unaudited Financial Information |  |
| (In thousands, except per share data) |  |
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 598,141 |  |  | $ | 523,802 |  |  | $ | 2,248,740 |  |  | $ | 2,105,322 |  |
| Cost of goods sold |  |  | 500,819 |  |  |  | 435,829 |  |  |  | 1,876,729 |  |  |  | 1,746,299 |  |
| Gross profit |  |  | 97,322 |  |  |  | 87,973 |  |  |  | 372,011 |  |  |  | 359,023 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 16,271 |  |  |  | 15,849 |  |  |  | 63,016 |  |  |  | 63,882 |  |
| General and administrative |  |  | 33,790 |  |  |  | 26,831 |  |  |  | 124,865 |  |  |  | 122,477 |  |
| Research and development |  |  | 5,071 |  |  |  | 4,604 |  |  |  | 18,146 |  |  |  | 19,770 |  |
| Amortization of definite-lived intangibles |  |  | 8,911 |  |  |  | 9,589 |  |  |  | 35,748 |  |  |  | 38,838 |  |
| Restructuring charges |  |  | 211 |  |  |  | 1,934 |  |  |  | 4,245 |  |  |  | 16,764 |  |
| Impairment of goodwill |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 69,200 |  |
| Total operating expenses |  |  | 64,254 |  |  |  | 58,807 |  |  |  | 246,020 |  |  |  | 330,931 |  |
| Operating income |  |  | 33,068 |  |  |  | 29,166 |  |  |  | 125,991 |  |  |  | 28,092 |  |
| Interest expense |  |  | (11,860 | ) |  |  | (14,599 | ) |  |  | (45,475 | ) |  |  | (73,156 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | (15,217 | ) |  |  | — |  |
| Other, net |  |  | (584 | ) |  |  | (1,854 | ) |  |  | 4,754 |  |  |  | (1,213 | ) |
| Income (loss) from continuing operations before income taxes |  |  | 20,624 |  |  |  | 12,713 |  |  |  | 70,053 |  |  |  | (46,277 | ) |
| Income tax (provision) benefit |  |  | (12,237 | ) |  |  | 26,247 |  |  |  | (15,639 | ) |  |  | 29,891 |  |
| Net income (loss) from continuing operations |  |  | 8,387 |  |  |  | 38,960 |  |  |  | 54,414 |  |  |  | (16,386 | ) |
| Income from discontinued operations, net of income taxes |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 193,921 |  |
| Net income |  | $ | 8,387 |  |  | $ | 38,960 |  |  | $ | 54,414 |  |  | $ | 177,535 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings (loss) per share from continuing operations |  | $ | 0.08 |  |  | $ | 0.36 |  |  | $ | 0.51 |  |  | $ | (0.15 | ) |
| Basic earnings per share from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.82 |  |
| Basic earnings per share |  | $ | 0.08 |  |  | $ | 0.36 |  |  | $ | 0.51 |  |  | $ | 1.67 |  |
| Diluted earnings (loss) per share from continuing operations |  | $ | 0.08 |  |  | $ | 0.34 |  |  | $ | 0.50 |  |  | $ | (0.15 | ) |
| Diluted earnings per share from discontinued operations |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.82 |  |
| Diluted earnings per share |  | $ | 0.08 |  |  | $ | 0.34 |  |  | $ | 0.50 |  |  | $ | 1.67 |  |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 104,186 |  |  |  | 106,755 |  |  |  | 106,314 |  |  |  | 106,366 |  |
| Diluted |  |  | 105,769 |  |  |  | 113,513 |  |  |  | 108,153 |  |  |  | 106,366 |  |
| Reconciliation of the denominator used to calculate basic earnings per share and diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 104,186 |  |  |  | 106,755 |  |  |  | 106,314 |  |  |  |  |  |
| Dilutive effect of convertible debt |  |  | — |  |  |  | 5,193 |  |  |  | — |  |  |  |  |  |
| Dilutive effect of warrants |  |  | — |  |  |  | — |  |  |  | 200 |  |  |  |  |  |
| Dilutive effect of performance-based stock units, restricted stock units & stock options |  |  | 1,583 |  |  |  | 1,565 |  |  |  | 1,639 |  |  |  |  |  |
| Diluted shares |  |  | 105,769 |  |  |  | 113,513 |  |  |  | 108,153 |  |  |  |  |  |
| SELECTED BALANCE SHEET DATA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001193125-22-032669:8k_2_02:49]
|  |  | January 3, 2022 |  |  | December 28, 2020 |  |
| Cash and cash equivalents, including restricted cash |  | $ | 537,678 |  |  | $ | 451,565 |  |
| Accounts and notes receivable, net |  |  | 386,347 |  |  |  | 381,105 |  |
| Contract assets |  |  | 324,862 |  |  |  | 273,256 |  |
| Inventories |  |  | 127,612 |  |  |  | 115,651 |  |
| Total current assets |  |  | 1,407,413 |  |  |  | 1,248,758 |  |
| Property, plant and equipment, net |  |  | 665,755 |  |  |  | 650,435 |  |
| Operating lease right of use asset |  |  | 20,802 |  |  |  | 24,340 |  |
| Other non-current assets |  |  | 931,577 |  |  |  | 972,411 |  |
| Total assets |  |  | 3,025,547 |  |  |  | 2,895,944 |  |
| Accounts payable |  | $ | 361,484 |  |  | $ | 327,102 |  |
| Total current liabilities |  |  | 558,148 |  |  |  | 518,046 |  |
| Debt, net of discount |  |  | 927,818 |  |  |  | 842,853 |  |
| Total long-term liabilities |  |  | 1,011,982 |  |  |  | 933,889 |  |
| Total equity |  |  | 1,455,417 |  |  |  | 1,444,009 |  |
| Total liabilities and equity |  |  | 3,025,547 |  |  |  | 2,895,944 |  |

[0001193125-22-032669:8k_2_02:50]
SUPPLEMENTAL DATA

[0001193125-22-032669:8k_2_02:51]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Gross margin |  |  | 16.3 | % |  |  | 16.8 | % |  |  | 16.5 | % |  |  | 17.1 | % |
| Operating margin |  |  | 5.5 | % |  |  | 5.6 | % |  |  | 5.6 | % |  |  | 1.3 | % |

[0001193125-22-032669:8k_2_02:52]
End Market Breakdown,
excludes Mobility:

[0001193125-22-032669:8k_2_02:53]
|  |  | Fourth Quarter |  |
|  |  | 2021 |  |  | 2020 |  |
| Aerospace/Defense |  |  | 30 | % |  |  | 36 | % |
| Automotive |  |  | 19 | % |  |  | 21 | % |
| Data Center Computing |  |  | 15 | % |  |  | 13 | % |
| Medical/Industrial/Instrumentation |  |  | 19 | % |  |  | 15 | % |
| Networking/Communications |  |  | 16 | % |  |  | 15 | % |
| Other |  |  | 1 | % |  |  | 0 | % |

[0001193125-22-032669:8k_2_02:54]
Stock-based Compensation:

[0001193125-22-032669:8k_2_02:55]
|  |  | Fourth Quarter |  |
|  |  | 2021 |  |  | 2020 |  |
| Amount included in: |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,404 |  |  | $ | 1,246 |  |
| Selling and marketing |  |  | 721 |  |  |  | 620 |  |
| General and administrative |  |  | 2,806 |  |  |  | 2,211 |  |
| Research and development |  |  | 277 |  |  |  | 35 |  |
| Total stock-based compensation expense |  | $ | 5,208 |  |  | $ | 4,112 |  |

[0001193125-22-032669:8k_2_02:56]
Operating Segment Data:

[0001193125-22-032669:8k_2_02:57]
|  |  | Fourth Quarter |  |
| Net sales: |  | 2021 |  |  | 2020 |  |
| PCB |  | $ | 581,817 |  |  | $ | 488,762 |  |
| RF&S Components |  |  | 16,324 |  |  |  | 11,382 |  |
| Other1 |  |  | — |  |  |  | 23,658 |  |
| Total net sales |  | $ | 598,141 |  |  | $ | 523,802 |  |
| Operating segment income: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 70,731 |  |  | $ | 63,188 |  |
| RF&S Components |  |  | 6,906 |  |  |  | 3,209 |  |
| Corporate & Other1 |  |  | (34,168 | ) |  |  | (26,258 | ) |
| Total operating segment income |  |  | 43,469 |  |  |  | 40,139 |  |
| Amortization of definite-lived intangibles |  |  | (10,401 | ) |  |  | (10,973 | ) |
| Total operating income |  |  | 33,068 |  |  |  | 29,166 |  |
| Total other expense |  |  | (12,444 | ) |  |  | (16,453 | ) |
| Income from continuing operations before income taxes |  | $ | 20,624 |  |  | $ | 12,713 |  |

[0001193125-22-032669:8k_2_02:58]
RECONCILIATIONS2

[0001193125-22-032669:8k_2_02:59]
|  |  | Fourth Quarter |  |  | Full Year |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Non-GAAP gross profit reconciliation3: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit from continuing operations |  | $ | 97,322 |  |  | $ | 87,973 |  |  | $ | 372,011 |  |  | $ | 359,023 |  |
| Add back item: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 1,490 |  |  |  | 1,384 |  |  |  | 5,641 |  |  |  | 5,535 |  |
| Accelerated depreciation |  |  | — |  |  |  | 899 |  |  |  | — |  |  |  | 5,835 |  |
| Stock-based compensation |  |  | 1,404 |  |  |  | 1,246 |  |  |  | 4,714 |  |  |  | 3,889 |  |
| Unrealized gain on commodity hedge |  |  | (362 | ) |  |  | — |  |  |  | (297 | ) |  |  | — |  |
| Restructuring and other charges |  |  | 7 |  |  |  | — |  |  |  | 261 |  |  |  | — |  |
| Non-GAAP gross profit |  | $ | 99,861 |  |  | $ | 91,502 |  |  | $ | 382,330 |  |  | $ | 374,282 |  |
| Non-GAAP gross margin |  |  | 16.7 | % |  |  | 17.5 | % |  |  | 17.0 | % |  |  | 17.8 | % |
| Non-GAAP operating income reconciliation4: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP operating income from continuing operations |  | $ | 33,068 |  |  | $ | 29,166 |  |  | $ | 125,991 |  |  | $ | 28,092 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 10,401 |  |  |  | 10,973 |  |  |  | 41,389 |  |  |  | 44,373 |  |
| Accelerated depreciation |  |  | — |  |  |  | 1,057 |  |  |  | — |  |  |  | 6,751 |  |
| Stock-based compensation |  |  | 5,208 |  |  |  | 4,112 |  |  |  | 17,711 |  |  |  | 16,073 |  |
| (Gain) on sale of assets |  |  | — |  |  |  | (97 | ) |  |  | (421 | ) |  |  | (97 | ) |
| Unrealized gain on commodity hedge |  |  | (362 | ) |  |  | — |  |  |  | (297 | ) |  |  | — |  |
| Impairments, restructuring, acquisition-related and other charges |  |  | 800 |  |  |  | 2,098 |  |  |  | 5,350 |  |  |  | 86,237 |  |
| Non-GAAP operating income |  | $ | 49,115 |  |  | $ | 47,309 |  |  | $ | 189,723 |  |  | $ | 181,429 |  |
| Non-GAAP operating margin |  |  | 8.2 | % |  |  | 9.0 | % |  |  | 8.4 | % |  |  | 8.6 | % |
| Non-GAAP net income and EPS reconciliation5: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) from continuing operations |  | $ | 8,387 |  |  | $ | 38,960 |  |  | $ | 54,414 |  |  | $ | (16,386 | ) |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 10,401 |  |  |  | 10,973 |  |  |  | 41,389 |  |  |  | 44,373 |  |
| Accelerated depreciation |  |  | — |  |  |  | 1,057 |  |  |  | — |  |  |  | 6,751 |  |
| Stock-based compensation |  |  | 5,208 |  |  |  | 4,112 |  |  |  | 17,711 |  |  |  | 16,073 |  |
| Non-cash interest expense |  |  | 496 |  |  |  | 2,962 |  |  |  | 2,109 |  |  |  | 17,451 |  |
| (Gain) on sale of assets |  |  | — |  |  |  | (119 | ) |  |  | (991 | ) |  |  | (825 | ) |
| Change in fair value of warrant liabilities |  |  | (373 | ) |  |  | — |  |  |  | (4,241 | ) |  |  | — |  |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | 15,217 |  |  |  | — |  |
| Unrealized gain on commodity hedge |  |  | (362 | ) |  |  | — |  |  |  | (297 | ) |  |  | — |  |
| Impairments, restructuring, acquisition-related and other charges |  |  | 800 |  |  |  | 2,098 |  |  |  | 5,350 |  |  |  | 86,237 |  |
| Income taxes6 |  |  | 11,636 |  |  |  | (19,800 | ) |  |  | 7,373 |  |  |  | (36,988 | ) |
| Non-GAAP net income |  | $ | 36,193 |  |  | $ | 40,243 |  |  | $ | 138,034 |  |  | $ | 116,686 |  |
| Non-GAAP earnings per diluted share |  | $ | 0.34 |  |  | $ | 0.37 |  |  | $ | 1.28 |  |  | $ | 1.10 |  |

[0001193125-22-032669:8k_2_02:60]
| Non-GAAP diluted number of shares: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted number of shares |  |  | 105,769 |  |  |  | 113,513 |  |  |  | 108,153 |  |  |  | 106,366 |  |
| Dilutive effect of convertible debt |  |  | — |  |  |  | (5,193 | ) |  |  | — |  |  |  | — |  |
| Non-GAAP diluted number of shares |  |  | 105,769 |  |  |  | 108,320 |  |  |  | 108,153 |  |  |  | 106,366 |  |
| Adjusted EBITDA reconciliation7: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) from continuing operations |  | $ | 8,387 |  |  | $ | 38,960 |  |  | $ | 54,414 |  |  | $ | (16,386 | ) |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax provision (benefit) |  |  | 12,237 |  |  |  | (26,247 | ) |  |  | 15,639 |  |  |  | (29,891 | ) |
| Interest expense |  |  | 11,860 |  |  |  | 14,599 |  |  |  | 45,475 |  |  |  | 73,156 |  |
| Amortization of definite-lived intangibles |  |  | 10,401 |  |  |  | 10,973 |  |  |  | 41,389 |  |  |  | 44,373 |  |
| Depreciation expense |  |  | 22,231 |  |  |  | 23,775 |  |  |  | 85,942 |  |  |  | 99,572 |  |
| Stock-based compensation |  |  | 5,208 |  |  |  | 4,112 |  |  |  | 17,711 |  |  |  | 16,073 |  |
| (Gain) on sale of assets |  |  | — |  |  |  | (119 | ) |  |  | (991 | ) |  |  | (825 | ) |
| Change in fair value of warrant liabilities |  |  | (373 | ) |  |  | — |  |  |  | (4,241 | ) |  |  | — |  |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | 15,217 |  |  |  | — |  |
| Unrealized gain on commodity hedge |  |  | (362 | ) |  |  | — |  |  |  | (297 | ) |  |  | — |  |
| Impairments, restructuring, acquisition-related and other charges |  |  | 800 |  |  |  | 2,098 |  |  |  | 5,350 |  |  |  | 86,237 |  |
| Adjusted EBITDA |  | $ | 70,389 |  |  | $ | 68,151 |  |  | $ | 275,608 |  |  | $ | 272,309 |  |
| Adjusted EBITDA margin |  |  | 11.8 | % |  |  | 13.0 | % |  |  | 12.3 | % |  |  | 12.9 | % |
| Free cash flow reconciliation8: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flow |  | $ | 62,369 |  |  | $ | 55,491 |  |  | $ | 176,632 |  |  | $ | 247,714 |  |
| Capital expenditures, net |  |  | (19,455 | ) |  |  | (18,663 | ) |  |  | (80,524 | ) |  |  | (93,001 | ) |
| Free cash flow |  | $ | 42,914 |  |  | $ | 36,828 |  |  | $ | 96,108 |  |  | $ | 154,713 |  |

[0001193125-22-032669:8k_2_02:61]
| 1 | Other represents the Shanghai E-MS and Shenzhen plant results. |

[0001193125-22-032669:8k_2_02:62]
| 2 | This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income, non-GAAP EPS, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |

[0001193125-22-032669:8k_2_02:63]
| 3 | Non-GAAP gross profit and gross margin measures exclude amortization of intangibles, accelerated depreciation, stock-based compensation expense, unrealized gain on commodity hedge, restructuring and other charges. |

[0001193125-22-032669:8k_2_02:64]
| 4 | Non-GAAP operating income and operating margin measures exclude amortization of intangibles, accelerated depreciation, stock-based compensation expense, gain on sale of assets, unrealized gain on commodity hedge, impairment of goodwill, restructuring, acquisition-related costs, and other charges. |

[0001193125-22-032669:8k_2_02:65]
| 5 | This information provides non-GAAP net income and non-GAAP EPS, which are non-GAAP financial measures. Management believes that both measures — which add back amortization of intangibles, accelerated depreciation, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, change in fair value of warrant liabilities, loss on extinguishment of debt, unrealized gain on commodity hedge, impairment of goodwill, restructuring, acquisition-related costs, and other charges as well as the associated tax impact of these charges and discrete tax items — provide additional useful information to investors regarding the Company’s ongoing financial condition and results of operations. |

[0001193125-22-032669:8k_2_02:66]
| 6 | Income tax adjustments reflect the difference between income taxes based on a non-GAAP tax rate and a forecasted annual GAAP tax rate. |

[0001193125-22-032669:8k_2_02:67]
| 7 | Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, change in fair value of warrant liabilities, loss on extinguishment of debt, unrealized gain on commodity hedge, impairment of goodwill, restructuring, acquisition-related costs, and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |

[0001193125-22-032669:8k_2_02:68]
| 8 | Free Cash Flow in 2020 has been restated to exclude the Mobility business which was sold in Q2 of 2020. |
