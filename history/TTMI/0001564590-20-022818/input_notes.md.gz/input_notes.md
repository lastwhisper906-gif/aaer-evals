# TTMI notes — 0001564590-20-022818


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-20-022818:notes:1]
[same as prior period, unchanged from 0001564590-19-041722:notes:1]

[0001564590-20-022818:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This one-stop design and manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001564590-20-022818:notes:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-20-022818:notes:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due to the coronavirus (COVID-19) global pandemic, the global economy and financial markets have been disrupted and there is a significant amount of uncertainty about the length and severity of the consequences caused by the pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 13-week fiscal quarter accounting period with the fourth quarter ending on the Monday nearest December 31.

[0001564590-20-022818:notes:5]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). For all periods presented in the consolidated condensed balance sheet, all assets and liabilities attributable to the Mobility business unit have been aggregated under the captions “Current assets held for sale”, “Non-current assets held for sale”, “Current liabilities held for sale” and “Non-current liabilities held for sale”. For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses and income taxes attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. Prior year results have been recast to conform with the current presentation. Refer to Note 2, Discontinued Operations, for additional information.

[0001564590-20-022818:notes:6]
Unless otherwise noted, amounts and disclosures throughout these notes to consolidated condensed financial statements relate to continuing operations. These consolidated condensed financial statements reflect all adjustments (consisting only of normal recurring adjustments) which, in the opinion of management, are necessary to present fairly the financial position, the results of operations and cash flows of the Company for the periods presented. The results of operations for the interim periods are not necessarily indicative of the results to be expected for the full year.

[0001564590-20-022818:notes:7]
[same as prior period, unchanged from 0001564590-19-041722:notes:5]

[0001564590-20-022818:notes:8]
Certain prior year amounts in the condensed consolidated financial statements have been reclassified due to the sale of the Company’s Mobility business unit. Refer to Note 2, Discontinued Operations, for further information regarding this sale and the resulting prior year reclassifications. Further, in 2020, the Company began presenting research and development expenses as a separate line item on the consolidated condensed statements of operations to better align with similar presentation made by peers and to provide additional disclosure that is meaningful for investors. The prior year consolidated condensed statements of operations were adjusted to conform with this new presentation. Research and development expense were previously presented within general and administrative expense on the consolidated condensed statements of operations.

[0001564590-20-022818:notes:9]
[same as prior period, unchanged from 0001564590-19-041722:notes:7]

[0001564590-20-022818:notes:10]
Recently Adopted Accounting Standards

[0001564590-20-022818:notes:11]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which amends the current accounting guidance and requires the measurement of all expected losses based on historical experience, current conditions and reasonable and supportable forecasts. For trade receivables, loans, and other financial instruments, the Company will be required to use a forward-looking expected loss model that reflects losses that are probable rather than the incurred loss model for recognizing credit losses. The standard became effective for interim and annual periods beginning after December 15, 2019. Application of the amendments is through a cumulative-effect adjustment to retained earnings as of the effective date. The Company adopted this ASU as of December 31, 2019 and it did not have a material impact on its financial statements.

[0001564590-20-022818:notes:12]
Recently Issued Accounting Standards Not Yet Adopted

[0001564590-20-022818:notes:13]
In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting, which provides temporary relief to the GAAP guidance on contract modifications and hedge accounting to ease the financial reporting burdens of the expected market transition from LIBOR and other interbank offered rates to alternative rates. This guidance is effective beginning on March 12, 2020 through December 31, 2022. The guidance on contract modifications can be applied prospectively from any date beginning March 12, 2020 and may also be applied to modifications of existing contracts made earlier in the interim period that includes March 12, 2020. The guidance on hedging can be applied to eligible hedging relationships existing at the beginning of the interim period that includes March 12, 2020 and to new eligible hedging relationships entered into after the beginning of that interim period. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures.

[0001564590-20-022818:notes:14]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company has evaluated the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures and the impact is not expected to be material.

[0001564590-20-022818:notes:15]
In August 2018, the FASB issued ASU 2018-14, Compensation—Retirement Benefits—Defined Benefit Plans—General (Subtopic 715-20)—Disclosure Framework—Changes to the Disclosure Requirements for Defined Benefit Plans. The amendments in this update change the disclosure requirements for employers that sponsor defined benefit pension and/or other postretirement benefit plans. It eliminates requirements for certain disclosures that are no longer considered cost beneficial and requires new disclosures that the FASB considers pertinent. The guidance is effective for fiscal years ending after December 15, 2020. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on the consolidated condensed financial statements and related disclosures.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-20-022818:notes:16]
(2) Discontinued Operations

[0001564590-20-022818:notes:17]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement for the sale of the Company’s Mobility business unit. The sale was completed on April 17, 2020 for a base purchase price of $550,000 in cash, subject to customary purchase price adjustments. The base purchase price does not include certain accounts receivable of the divested business, which are estimated to total approximately $95,000.

[0001564590-20-022818:notes:18]
As the sale of the Company’s Mobility business unit represents a strategic shift that will have a major effect on the Company’s operations and financial results, in accordance with the provisions of FASB authoritative guidance on the presentation of financial statements, Mobility business unit results are classified as discontinued operations in the consolidated condensed statements of operations for all periods presented. Prior year results have been recast to conform with the current presentation. The Mobility business unit is part of the Company’s PCB reportable segment.

[0001564590-20-022818:notes:19]
The following table summarizes the results of Mobility operations for each period prior to sale:

[0001564590-20-022818:notes:20]
|  |  | Quarter Ended |  |
|  |  | March 30, |  |  | April 1, |  |
|  |  | 2020 |  |  | 2019 |  |
|  |  | (In thousands, except per share data) |  |
| Net sales |  | $ | 113,174 |  |  | $ | 83,755 |  |
| Cost of goods sold |  |  | 108,425 |  |  |  | 93,896 |  |
| Gross profit |  |  | 4,749 |  |  |  | (10,141 | ) |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 1,176 |  |  |  | 1,341 |  |
| General and administrative |  |  | 1,310 |  |  |  | 470 |  |
| Research and development |  |  | 147 |  |  |  | — |  |
| Amortization of definite-lived intangibles |  |  | 675 |  |  |  | 674 |  |
| Total operating expenses |  |  | 3,308 |  |  |  | 2,485 |  |
| Operating income (loss) |  |  | 1,441 |  |  |  | (12,626 | ) |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (223 | ) |  |  | (553 | ) |
| Other, net |  |  | 1,571 |  |  |  | (173 | ) |
| Total other income (expense), net |  |  | 1,348 |  |  |  | (726 | ) |
| Income (loss) from discontinued operations before income taxes |  |  | 2,789 |  |  |  | (13,352 | ) |
| Income tax (provision) benefit |  |  | (743 | ) |  |  | 3,862 |  |
| Income (loss) from discontinued operations, net of income taxes |  | $ | 2,046 |  |  | $ | (9,490 | ) |
| Earnings (loss) per share from discontinued operations: |  |  |  |  |  |  |  |  |
| Basic earnings (loss) per share |  | $ | 0.02 |  |  | $ | (0.09 | ) |
| Diluted earnings (loss) per share |  | $ | 0.02 |  |  | $ | (0.09 | ) |

[0001564590-20-022818:notes:21]
Depreciation expense related to the discontinued operations for the quarter ended March 30, 2020 and April 1, 2019 was $18,265 and $18,075, respectively.

[0001564590-20-022818:notes:22]
Assets being sold and liabilities being assumed by the Purchaser in the sale of the Company’s Mobility business unit include substantially all assets and liabilities, with the exception of certain accounts receivable. The following table summarizes the major categories of assets and liabilities classified as held for sale in the consolidated condensed balance sheets as of the end of each period:

[0001564590-20-022818:notes:23]
|  |  | As of |  |
|  |  | March 30, |  |  | December 30, |  |
|  |  | 2020 |  |  | 2019 |  |
|  |  | (In thousands) |  |
| Cash and cash equivalents |  | $ | 33,103 |  |  | $ | 20,336 |  |
| Restricted cash |  |  | 35,342 |  |  |  | — |  |
| Accounts receivable, net |  |  | 6 |  |  |  | 66 |  |
| Contract assets |  |  | 30,181 |  |  |  | 33,635 |  |
| Inventories |  |  | 8,643 |  |  |  | 8,266 |  |
| Prepaid expenses and other current assets |  |  | 3,978 |  |  |  | 5,269 |  |
| Property, plant and equipment, net |  |  | 330,312 |  |  |  | 344,728 |  |
| Operating lease right-of-use assets |  |  | 1,593 |  |  |  | 1,983 |  |
| Goodwill |  |  | 68,267 |  |  |  | 68,267 |  |
| Definite-lived intangibles, net |  |  | 5,653 |  |  |  | 6,328 |  |
| Deposits and other non-current assets |  |  | 5,896 |  |  |  | 4,291 |  |
| Total assets classified as held for sale |  | $ | 522,974 |  |  | $ | 493,169 |  |
| Accounts payable |  | $ | 144,715 |  |  |  | 153,700 |  |
| Accrued salaries, wages and benefits |  |  | 12,057 |  |  |  | 13,606 |  |
| Other current liabilities |  |  | 12,720 |  |  |  | 18,085 |  |
| Operating lease liabilities |  |  | 820 |  |  |  | 1,104 |  |
| Other long-term liabilities |  |  | 423 |  |  |  | 426 |  |
| Total liabilities classified as held for sale |  | $ | 170,735 |  |  | $ | 186,921 |  |


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001564590-20-022818:notes:24]
The following table summarizes the major categories of assets and liabilities classified as held for sale in the consolidated condensed balance sheets as of the end of each period:


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-20-022818:notes:25]
[same as prior period, unchanged from 0001564590-19-041722:notes:27]

[0001564590-20-022818:notes:26]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the right-of-use (ROU) asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-20-022818:notes:27]
[same as prior period, unchanged from 0001564590-19-041722:notes:29]

[0001564590-20-022818:notes:28]
|  |  | Quarter Ended |  |
|  |  | March 30, 2020 |  |  | April 1, 2019 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 2,481 |  |  | $ | 2,032 |  |
| Variable lease cost |  |  | 106 |  |  |  | 159 |  |
| Short-term lease cost |  |  | 229 |  |  |  | 41 |  |

[0001564590-20-022818:notes:29]
[same as prior period, unchanged from 0001564590-19-041722:notes:31]

[0001564590-20-022818:notes:30]
|  |  | Quarter Ended |  |
|  |  | March 30, 2020 |  |  | April 1, 2019 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 2,171 |  |  | $ | 2,012 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 1,876 |  |  |  | 6,824 |  |

[0001564590-20-022818:notes:31]
[same as prior period, unchanged from 0001564590-19-041722:notes:33]

[0001564590-20-022818:notes:32]
|  |  | As of |  |
|  |  | March 30, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Operating lease right-of-use assets |  | $ | 21,724 |  |  | $ | 22,173 |  |
| Other current liabilities |  |  | 7,504 |  |  |  | 7,111 |  |
| Operating lease liabilities |  |  | 14,832 |  |  |  | 15,413 |  |
| Total operating lease liabilities |  | $ | 22,336 |  |  | $ | 22,524 |  |

[0001564590-20-022818:notes:33]
|  |  | As of |  |
|  |  | March 30, 2020 |  |  | December 30, 2019 |  |
| Weighted average remaining lease term |  | 4.2 years |  |  | 4.4 years |  |
| Weighted average discount rate |  |  | 3.24 | % |  |  | 3.92 | % |

[0001564590-20-022818:notes:34]
[same as prior period, unchanged from 0001564590-19-041722:notes:36]

[0001564590-20-022818:notes:35]
|  |  | (In thousands) |  |
| Less than one year |  | $ | 7,875 |  |
| 1 - 2 years |  |  | 6,533 |  |
| 2 - 3 years |  |  | 2,820 |  |
| 3 - 4 years |  |  | 2,258 |  |
| 4 - 5 years |  |  | 1,791 |  |
| Thereafter |  |  | 2,681 |  |
| Total lease payments |  |  | 23,958 |  |
| Less imputed interest |  |  | (1,622 | ) |
| Total |  | $ | 22,336 |  |

[0001564590-20-022818:notes:36]
[same as prior period, unchanged from 0001564590-19-041722:notes:38]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-022818:notes:37]
[same as prior period, unchanged from 0001564590-19-041722:notes:42]

[0001564590-20-022818:notes:38]
As of March 30, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $23,014. The Company expects to recognize revenue on approximately 44% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.

[0001564590-20-022818:notes:39]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter ended March 30, 2020, and 97% and 3%, respectively, of the Company’s revenue for the quarter ended April 1, 2019.

[0001564590-20-022818:notes:40]
[same as prior period, unchanged from 0001564590-19-041722:notes:45]

[0001564590-20-022818:notes:41]
|  |  | Quarter Ended March 30, 2020 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 184,451 |  |  | $ | — |  |  | $ | 184,451 |  |  |
| Automotive |  |  | 61,421 |  |  |  | 7,463 |  |  |  | 68,884 |  |  |
| Cellular Phone |  |  | 2,788 |  |  |  | — |  |  |  | 2,788 |  |  |
| Computing/Storage/Peripherals |  |  | 58,282 |  |  |  | 104 |  |  |  | 58,386 |  |  |
| Medical/Industrial/Instrumentation |  |  | 88,224 |  |  |  | 3,758 |  |  |  | 91,982 |  |  |
| Networking/Communications |  |  | 60,898 |  |  |  | 18,977 |  |  |  | 79,875 |  |  |
| Other |  |  | 11,366 |  |  |  | (86 | ) |  |  | 11,280 |  |  |
| Total |  | $ | 467,430 |  |  | $ | 30,216 |  |  | $ | 497,646 |  |  |

[0001564590-20-022818:notes:42]
|  |  | Quarter Ended April 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 164,797 |  |  | $ | 4 |  |  | $ | 164,801 |  |  |
| Automotive |  |  | 81,593 |  |  |  | 19,765 |  |  |  | 101,358 |  |  |
| Cellular Phone |  |  | 1,904 |  |  |  | — |  |  |  | 1,904 |  |  |
| Computing/Storage/Peripherals |  |  | 57,846 |  |  |  | 189 |  |  |  | 58,035 |  |  |
| Medical/Industrial/Instrumentation |  |  | 82,182 |  |  |  | 8,167 |  |  |  | 90,349 |  |  |
| Networking/Communications |  |  | 84,023 |  |  |  | 23,339 |  |  |  | 107,362 |  |  |
| Other |  |  | 12,722 |  |  |  | (86 | ) |  |  | 12,636 |  |  |
| Total |  | $ | 485,067 |  |  | $ | 51,378 |  |  | $ | 536,445 |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-20-022818:notes:43]
[same as prior period, unchanged from 0001564590-19-041722:notes:48]

[0001564590-20-022818:notes:44]
|  |  | As of |  |
|  |  | March 30, 2020 |  |  | December 30, 2019 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 108,770 |  |  | $ | 97,660 |  |
| Work-in-process |  |  | 8,709 |  |  |  | 10,898 |  |
| Finished goods |  |  | 3,470 |  |  |  | 5,195 |  |
|  |  | $ | 120,949 |  |  | $ | 113,753 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 62,009 |  |  | $ | 62,009 |  |
| Buildings and improvements |  |  | 390,544 |  |  |  | 381,980 |  |
| Machinery and equipment |  |  | 808,022 |  |  |  | 777,916 |  |
| Furniture and fixtures and other |  |  | 10,511 |  |  |  | 10,329 |  |
| Construction-in-progress |  |  | 31,168 |  |  |  | 58,195 |  |
|  |  |  | 1,302,254 |  |  |  | 1,290,429 |  |
| Less: Accumulated depreciation |  |  | (635,643 | ) |  |  | (612,228 | ) |
|  |  | $ | 666,611 |  |  | $ | 678,201 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-20-022818:notes:45]
[same as prior period, unchanged from 0001564590-19-041722:notes:50]

[0001564590-20-022818:notes:46]
As of March 30, 2020 and December 30, 2019, goodwill was as follows:

[0001564590-20-022818:notes:47]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 30, 2019 and March 30, 2020 |  |  |  |  |
| Goodwill |  | $ | 946,191 |  |
| Accumulated impairment loss |  |  | (171,400 | ) |
| Goodwill in assets held for sale |  |  | (68,267 | ) |
|  |  | $ | 706,524 |  |

[0001564590-20-022818:notes:48]
[same as prior period, unchanged from 0001564590-19-041722:notes:53]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-20-022818:notes:49]
[same as prior period, unchanged from 0001564590-19-041722:notes:57]

[0001564590-20-022818:notes:50]
As of March 30, 2020 and December 30, 2019, the components of definite-lived intangibles were as follows:

[0001564590-20-022818:notes:51]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| March 30, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 397,500 |  |  | $ | (120,865 | ) |  | $ | 276,635 |  |  |  | 11.0 |  |
| Technology |  |  | 47,650 |  |  |  | (9,550 | ) |  |  | 38,100 |  |  |  | 9.5 |  |
|  |  | $ | 445,150 |  |  | $ | (130,415 | ) |  | $ | 314,735 |  |  |  |  |  |
| December 30, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 396,270 |  |  | $ | (111,272 | ) |  | $ | 284,998 |  |  |  | 11.0 |  |
| Technology |  |  | 39,500 |  |  |  | (8,064 | ) |  |  | 31,436 |  |  |  | 9.4 |  |
| Acquired intangibles from acquisition in 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 1,230 |  |  |  | (31 | ) |  |  | 1,199 |  |  |  | 5.0 |  |
| Technology |  |  | 8,150 |  |  |  | (103 | ) |  |  | 8,047 |  |  |  | 10.0 |  |
|  |  | $ | 445,150 |  |  | $ | (119,470 | ) |  | $ | 325,680 |  |  |  |  |  |

[0001564590-20-022818:notes:52]
Definite-lived intangibles are generally amortized using the straight-line method of amortization over the estimated useful life. Amortization expense was $10,945 and $17,331 for the quarters ended March 30, 2020 and April 1, 2019, respectively. For the quarters ended March 30, 2020 and April 1, 2019, $1,383 and $1,179, respectively, of amortization expense is included in cost of goods sold.

[0001564590-20-022818:notes:53]
[same as prior period, unchanged from 0001564590-19-041722:notes:61]

[0001564590-20-022818:notes:54]
|  |  | (In thousands) |  |
| Remaining 2020 |  | $ | 32,836 |  |
| 2021 |  |  | 41,344 |  |
| 2022 |  |  | 38,793 |  |
| 2023 |  |  | 36,838 |  |
| 2024 |  |  | 29,812 |  |
| Thereafter |  |  | 135,112 |  |
|  |  | $ | 314,735 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-20-022818:notes:55]
(8) Long-term Debt and Letters of Credit

[0001564590-20-022818:notes:56]
The following table summarizes the long-term debt of the Company as of March 30, 2020 and December 30, 2019:

[0001564590-20-022818:notes:57]
|  |  | Interest Rate as of March 30, 2020 |  |  | Principal Outstanding as of March 30, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 3.48 |  | % | $ | 805,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 2.23 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 2.38 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (9,305 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (12,202 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,479,347 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (249,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,229,372 |  |  |  |  |  |  | $ | 1,225,962 |  |

[0001564590-20-022818:notes:58]
The Company has twelve months to reinvest the cash proceeds received from the sale of the Mobility business unit. If the proceeds are not reinvested, the Company is required to use the proceeds to prepay the Term Loan. The Company plans to use the cash proceeds for debt repayment and reinvestment. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

[0001564590-20-022818:notes:59]
Debt Covenants

[0001564590-20-022818:notes:60]
Borrowings under the Term Loan and Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

[0001564590-20-022818:notes:61]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0001564590-20-022818:notes:62]
Debt Issuance and Debt Discount

[0001564590-20-022818:notes:63]
As of March 30, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

[0001564590-20-022818:notes:64]
|  |  | As of March 30, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,340 |  |  | $ | 1,918 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,121 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 741 |  |  |  | 7,387 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 12,202 |  |  | $ | 9,305 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |

[0001564590-20-022818:notes:65]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-20-022818:notes:66]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,369 and $2,511 as of March 30, 2020 and December 30, 2019, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0001564590-20-022818:notes:67]
As of March 30, 2020, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.4 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-022818:notes:68]
[same as prior period, unchanged from 0001564590-19-041722:notes:93]

[0001564590-20-022818:notes:69]
The Company’s effective tax rate is impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items. Additionally, no tax benefit was recorded on the losses incurred in certain foreign jurisdictions as a result of corresponding increases in the valuation allowances in these jurisdictions.

[0001564590-20-022818:notes:70]
During the quarter ended March 30, 2020, the Company’s effective tax rate was impacted by a net discrete expense of $2,053. This is related to retroactive approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China (including the impact on the respective Company’s deferred tax assets) and by the accrued interest expense on existing uncertain tax positions.

[0001564590-20-022818:notes:71]
The Company has various foreign subsidiaries formed or acquired to conduct or support its business outside the United States. The Company expects its earnings attributable to most foreign subsidiaries may be repatriated back to the U.S. and so a deferred tax liability has been recorded for foreign withholding and the estimated federal/state tax impact. For those other companies with earnings currently being reinvested outside of the U.S., no deferred tax liabilities on undistributed earnings are recorded.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-20-022818:notes:72]
[same as prior period, unchanged from 0001564590-19-041722:notes:96]

[0001564590-20-022818:notes:73]
[same as prior period, unchanged from 0001564590-19-041722:notes:97]

[0001564590-20-022818:notes:74]
[same as prior period, unchanged from 0001564590-19-041722:notes:98]

[0001564590-20-022818:notes:75]
[same as prior period, unchanged from 0001564590-19-041722:notes:99]

[0001564590-20-022818:notes:76]
[same as prior period, unchanged from 0001564590-19-041722:notes:100]

[0001564590-20-022818:notes:77]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of March 30, 2020, the fair value of the interest rate swap was recorded as a liability in the amount of $19,341 and included as a component of other long-term liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax. No ineffectiveness was recognized for the quarters ended March 30, 2020 and April 1, 2019. The interest rate swap increased interest expense by $1,175 and $339 for the quarters ended March 30, 2020 and April 1, 2019, respectively.

[0001564590-20-022818:notes:78]
[same as prior period, unchanged from 0001564590-19-041722:notes:102]

[0001564590-20-022818:notes:79]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than its functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts as of March 30, 2020 and December 30, 2019 was approximately $787 and $1,994, respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-20-022818:notes:80]
[same as prior period, unchanged from 0001564590-19-041722:notes:104]

[0001564590-20-022818:notes:81]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | March 30, 2020 |  |  | December 30, 2019 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other long-term liabilities |  | $ | (19,341 | ) |  | $ | (12,067 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | — |  |  |  | 1 |  |
| Foreign exchange contracts |  | Other current liabilities |  |  | (2 | ) |  |  | (3 | ) |

[0001564590-20-022818:notes:82]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the quarters ended March 30, 2020 and April 1, 2019:

[0001564590-20-022818:notes:83]
|  |  |  | Quarter Ended March 30, 2020 |  |  | Quarter Ended April 1, 2019 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (8,449 | ) |  | $ | (1,175 | ) |  | $ | (2,586 | ) |  | $ | (339 | ) |  |

[0001564590-20-022818:notes:84]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the quarters ended March 30, 2020 and April 1, 2019:

[0001564590-20-022818:notes:85]
|  |  | Quarter Ended |
|  |  | March 30, |  |  | April 1, |  |  |
|  |  | 2020 |  |  | 2019 |  |  |
|  |  | (In thousands) |
| Beginning balance, net of tax |  | $ | (9,617 | ) |  | $ | (4,214 | ) |  |
| Changes in fair value loss, net of tax |  |  | (6,018 | ) |  |  | (1,828 | ) |  |
| Reclassification to earnings |  |  | 860 |  |  |  | 278 |  |  |
| Ending balance, net of tax |  | $ | (14,775 | ) |  | $ | (5,764 | ) |  |

[0001564590-20-022818:notes:86]
Based on the current yield curve, the Company expects that losses of approximately $6,564 of the accumulated other comprehensive loss will be reclassified into the statement of operations, net of tax, in the next twelve months.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-20-022818:notes:87]
[same as prior period, unchanged from 0001564590-19-041722:notes:114]

[0001564590-20-022818:notes:88]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of March 30, 2020 and December 30, 2019:

[0001564590-20-022818:notes:89]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | (Losses) Gains on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of December 30, 2019 |  | $ | 1,115 |  |  | $ | (1,584 | ) |  | $ | (9,617 | ) |  | $ | (10,086 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (367 | ) |  |  | 27 |  |  |  | (6,018 | ) |  |  | (6,358 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 860 |  |  |  | 860 |  |
| Other comprehensive (loss) income |  |  | (367 | ) |  |  | 27 |  |  |  | (5,158 | ) |  |  | (5,498 | ) |
| Ending balance as of March 30, 2020 |  | $ | 748 |  |  | $ | (1,557 | ) |  | $ | (14,775 | ) |  | $ | (15,584 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-20-022818:notes:90]
[same as prior period, unchanged from 0001564590-19-041722:notes:117]

[0001564590-20-022818:notes:91]
In the normal course of business, the Company extends credit to its customers. Most customers to which the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk.

[0001564590-20-022818:notes:92]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers. There were no customers that accounted for 10% or more of net sales for the quarters ended March 30, 2020 and April 1, 2019.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-20-022818:notes:93]
[same as prior period, unchanged from 0001564590-19-041722:notes:121]

[0001564590-20-022818:notes:94]
[same as prior period, unchanged from 0001564590-19-041722:notes:122]

[0001564590-20-022818:notes:95]
The carrying amount and estimated fair value of the Company’s financial instruments as of March 30, 2020 and December 30, 2019 were as follows:

[0001564590-20-022818:notes:96]
|  |  | As of |  |  | As of |  |
|  |  | March 30, 2020 |  |  | December 30, 2019 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | — |  |  | $ | — |  |  |  | 1 |  |  |  | 1 |  |
| Derivative liabilities, current |  |  | 2 |  |  |  | 2 |  |  |  | 3 |  |  |  | 3 |  |
| Derivative liabilities, non-current |  |  | 19,341 |  |  |  | 19,341 |  |  |  | 12,067 |  |  |  | 12,067 |  |
| Term Loan due September 2024 |  |  | 797,621 |  |  |  | 706,152 |  |  |  | 797,200 |  |  |  | 808,901 |  |
| Senior Notes due October 2025 |  |  | 369,879 |  |  |  | 312,101 |  |  |  | 369,684 |  |  |  | 390,143 |  |
| Convertible Senior Notes due December 2020 |  |  | 241,847 |  |  |  | 276,095 |  |  |  | 239,053 |  |  |  | 391,686 |  |
| ABL Revolving Loans |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |

[0001564590-20-022818:notes:97]
[same as prior period, unchanged from 0001564590-19-041722:notes:125]

[0001564590-20-022818:notes:98]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of March 30, 2020 and December 30, 2019, which are considered Level 2 inputs.

[0001564590-20-022818:notes:99]
[same as prior period, unchanged from 0001564590-19-041722:notes:127]

[0001564590-20-022818:notes:100]
As of March 30, 2020 and December 30, 2019, the Company’s other financial instruments also included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of March 30, 2020 consisted of $36,525 held in the U.S., with the remaining $325,467 held by foreign subsidiaries.

[0001564590-20-022818:notes:101]
[same as prior period, unchanged from 0001564590-19-041722:notes:129]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-022818:notes:102]
(14) Commitments and Contingencies

[0001564590-20-022818:notes:103]
Legal Matters

[0001564590-20-022818:notes:104]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of March 30, 2020 and December 30, 2019. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-022818:notes:105]
(15) (Loss) Earnings Per Share

[0001564590-20-022818:notes:106]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the quarters ended March 30, 2020 and April 1, 2019:

[0001564590-20-022818:notes:107]
|  |  | Quarter Ended |  |
|  |  | March 30, 2020 |  |  | April 1, 2019 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net (loss) income |  | $ | (3,220 | ) |  | $ | 6,238 |  |
| Basic weighted average shares |  |  | 105,686 |  |  |  | 104,315 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | — |  |  |  | 1,299 |  |
| Diluted shares |  |  | 105,686 |  |  |  | 105,614 |  |
| (Loss) earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.03 | ) |  | $ | 0.06 |  |
| Diluted |  | $ | (0.03 | ) |  | $ | 0.06 |  |

[0001564590-20-022818:notes:108]
For the quarter ended March 30, 2020, potential shares of common stock, consisting of stock options to purchase approximately 100 shares of common stock at exercise prices ranging from $9.54 to $16.60 per share, 2,459 restricted stock units (RSUs), and 216 performance-based restricted stock units (PRUs) were not included in the computation of diluted earnings per share because the Company incurred a net loss and, as a result, the impact would be anti-dilutive.

[0001564590-20-022818:notes:109]
PRUs, RSUs, and stock options to purchase 1,089 shares of common stock for the quarter ended April 1, 2019 was not included in the computation of diluted earnings per share because the options’ exercise prices or the total expected proceeds under the treasury stock method for PRUs, RSUs, or stock options was greater than the average market price of common shares during the applicable quarter and, as a result, the impact would be anti-dilutive.

[0001564590-20-022818:notes:110]
Outstanding warrants for the quarters ended March 30, 2020 and April 1, 2019, to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock were greater than the average market price of common shares during the applicable quarter, and therefore, the effect would be anti-dilutive.

[0001564590-20-022818:notes:111]
For the quarters ended March 30, 2020 and April 1, 2019, the effect of shares of common stock related to the Company’s Convertible Senior Notes, based on the if-converted method, were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-20-022818:notes:112]
[same as prior period, unchanged from 0001564590-19-041722:notes:139]

[0001564590-20-022818:notes:113]
[same as prior period, unchanged from 0001564590-19-041722:notes:140]

[0001564590-20-022818:notes:114]
|  |  | Quarter Ended |
|  |  | March 30, |  |  | April 1, |  |  |
|  |  | 2020 |  |  | 2019 |  |  |
|  |  | (In thousands) |
| Cost of goods sold |  | $ | 854 |  |  | $ | 705 |  |  |
| Selling and marketing |  |  | 469 |  |  |  | 466 |  |  |
| General and administrative |  |  | 3,512 |  |  |  | 2,755 |  |  |
| Stock-based compensation expense recognized |  | $ | 4,835 |  |  | $ | 3,926 |  |  |

[0001564590-20-022818:notes:115]
[same as prior period, unchanged from 0001564590-19-041722:notes:150]

[0001564590-20-022818:notes:116]
The following is a summary of total unrecognized compensation costs as of March 30, 2020:

[0001564590-20-022818:notes:117]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 16,352 |  |  |  | 1.4 |  |
| PRU awards |  |  | 1,090 |  |  |  | 1.2 |  |
| Stock options |  |  | 213 |  |  |  | 1.5 |  |
|  |  | $ | 17,655 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-022818:notes:118]
[same as prior period, unchanged from 0001564590-19-041722:notes:153]

[0001564590-20-022818:notes:119]
[same as prior period, unchanged from 0001564590-19-041722:notes:154]

[0001564590-20-022818:notes:120]
[same as prior period, unchanged from 0001564590-19-041722:notes:155]

[0001564590-20-022818:notes:121]
|  |  |  | Quarter Ended |
|  |  |  | March 30, 2020 |  |  | April 1, 2019 |  |  |
|  |  |  | (In thousands) |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |
| PCB |  |  | $ | 467,430 |  |  | $ | 485,067 |  |  |
| E-M Solutions |  |  |  | 30,216 |  |  |  | 51,378 |  |  |
| Total net sales |  |  | $ | 497,646 |  |  | $ | 536,445 |  |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |
| PCB |  |  | $ | 61,626 |  |  | $ | 70,494 |  |  |
| E-M Solutions |  |  |  | (4,329 | ) |  |  | 1,179 |  |  |
| Corporate |  |  |  | (30,170 | ) |  |  | (24,226 | ) |  |
| Total operating segment income |  |  |  | 27,127 |  |  |  | 47,447 |  |  |
| Amortization of definite-lived intangibles (1) |  |  |  | (10,945 | ) |  |  | (17,331 | ) |  |
| Total operating income |  |  |  | 16,182 |  |  |  | 30,116 |  |  |
| Total other expense |  |  |  | (17,279 | ) |  |  | (21,492 | ) |  |
| (Loss) income before income taxes |  |  | $ | (1,097 | ) |  | $ | 8,624 |  |  |

[0001564590-20-022818:notes:122]
| (1) | Amortization of definite-lived intangibles relates to the PCB reportable segment. For the quarters ended March 30, 2020 and April 1, 2019, $1,383 and $1,179, respectively, of amortization expense is included in cost of goods sold. |

[0001564590-20-022818:notes:123]
The Corporate category primarily includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, information technology, facilities and human resources personnel, as well as global sales and marketing personnel, research and development costs, and acquisition and integration costs associated with acquisitions.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001564590-20-022818:notes:124]
(18) Related Party Transactions

[0001564590-20-022818:notes:125]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $6,272 and $8,312 for the quarters ended March 30, 2020 and April 1, 2019, respectively.

[0001564590-20-022818:notes:126]
As of March 30, 2020 and December 30, 2019, the Company’s consolidated condensed balance sheets included $6,895 and $9,220, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.


## us-gaap:SubsequentEventsTextBlock

[0001564590-20-022818:notes:127]
(19) Subsequent Events

[0001564590-20-022818:notes:128]
On April 17, 2020, the Company completed the sale of its Mobility business unit for a base purchase price of $550,000 in cash, subject to customary purchase price adjustments. The base purchase price does not include certain accounts receivable of the divested business, which is estimated to total approximately $95,000.

[0001564590-20-022818:notes:129]
On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit, which consists of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company will discontinue operations at the SH E-MS and SZ facilities while integrating the SH BPA facility into its PCB operations. No goodwill is allocated to the E-M Solutions reportable segment. The cash outlay for severance and other shutdown costs is estimated to be approximately $17,000 and is expected to be incurred over the next 12 to 15 months. The Company also expects to incur approximately $8,000 related to non-cash asset impairments. At this time, these amounts are estimates and subject to change as the Company carries out the restructuring. This subsequent event has not been recognized in these consolidated condensed financial statements and will be recognized in the Company’s consolidated financial statements in the upcoming quarters.
