# TTMI 8-K — 0001193125-20-126117 filed 2020-04-29

## item codes, every 8-K on or before 2020-05-07

- 2020-05-04 0001193125-20-131366 — 7.01, 9.01
- 2020-04-29 0001193125-20-126358 — 2.05, 7.01, 9.01
- 2020-04-29 0001193125-20-126117 — 2.02, 9.01
- 2020-04-23 0001193125-20-117365 — 2.01, 7.01, 9.01
- 2020-02-05 0001193125-20-025365 — 2.02, 9.01
- 2020-01-31 0001193125-20-021278 — 5.02
- 2020-01-22 0001193125-20-012011 — 1.01, 7.01, 9.01
- 2019-10-30 0001193125-19-278973 — 2.02, 9.01
- 2019-08-19 0001193125-19-224091 — 5.02, 9.01
- 2019-07-31 0001193125-19-208689 — 2.02, 9.01
- 2019-07-24 0001193125-19-201401 — 1.01, 2.03
- 2019-06-13 0001193125-19-171943 — 7.01, 9.01
- 2019-06-06 0001193125-19-167332 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2019-05-09 0001193125-19-143113 — 5.07
- 2019-05-01 0001193125-19-132977 — 2.02, 9.01
- 2019-02-06 0001193125-19-029540 — 2.02, 9.01
- 2019-01-15 0001193125-19-009142 — 2.02, 9.01
- 2018-10-30 0001193125-18-312212 — 2.02, 9.01
- 2018-10-22 0001193125-18-303926 — 5.02
- 2018-09-06 0001193125-18-268231 — 5.02, 9.01
- 2018-08-01 0001193125-18-234997 — 2.02, 9.01
- 2018-06-29 0001193125-18-209635 — 9.01 — amendment of 0001193125-18-120583
- 2018-05-29 0001193125-18-176976 — 7.01, 9.01
- 2018-05-10 0001193125-18-159394 — 5.07
- 2018-05-09 0001193125-18-157596 — 5.02
- 2018-05-02 0001193125-18-148650 — 2.02, 9.01
- 2018-04-18 0001193125-18-120583 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2018-02-21 0001193125-18-052169 — 8.01, 9.01
- 2018-02-20 0001193125-18-050385 — 5.02, 9.01
- 2018-02-09 0001193125-18-036966 — 7.01, 9.01
- 2018-02-07 0001193125-18-034744 — 2.02, 9.01
- 2017-12-14 0001193125-17-369625 — 1.01, 2.03, 9.01
- 2017-12-04 0001193125-17-359439 — 1.01, 7.01, 9.01
- 2017-11-01 0001193125-17-329425 — 2.02, 9.01
- 2017-09-29 0001193125-17-298999 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2017-09-15 0001193125-17-286491 — 7.01, 9.01
- 2017-09-11 0001193125-17-281193 — 7.01, 9.01
- 2017-09-06 0001193125-17-277536 — 7.01, 9.01
- 2017-08-02 0001193125-17-245823 — 2.02, 9.01
- 2017-05-18 0001193125-17-173896 — 5.02, 5.07
- 2017-05-08 0001193125-17-162548 — 2.02, 9.01
- 2017-03-01 0001193125-17-063931 — 1.01, 1.02, 5.02
- 2017-02-08 0001193125-17-034652 — 2.02, 9.01
- 2016-11-18 0001193125-16-772305 — 8.01, 9.01
- 2016-10-26 0001193125-16-747948 — 2.02, 9.01
- 2016-10-20 0001193125-16-742905 — 5.02
- 2016-10-05 0001193125-16-731552 — 5.02, 9.01
- 2016-09-27 0001193125-16-720828 — 1.01, 2.03, 7.01, 9.01
- 2016-07-27 0001193125-16-659983 — 2.02, 9.01
- 2016-05-23 0001193125-16-599342 — 7.01, 9.01
- 2016-05-18 0001193125-16-594656 — 5.02, 5.03, 5.07, 9.01
- 2016-04-27 0001171843-16-009432 — 2.02, 9.01
- 2016-03-08 0001193125-16-495457 — 5.03, 7.01, 9.01
- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2020-05-07

- none on or before 2020-05-07

## item 2.02 — earnings release, exhibit 99.1

[0001193125-20-126117:8k_2_02:1]
EX-99.1
2
d923982dex991.htm
EX-99.1

[0001193125-20-126117:8k_2_02:2]
EX-99.1

[0001193125-20-126117:8k_2_02:3]
Exhibit 99.1

[0001193125-20-126117:8k_2_02:4]
| TTM Technologies, Inc., Q1’20 |  | Contact: Sameer Desai, Senior Director, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-20-126117:8k_2_02:5]
TTM Technologies, Inc. Reports Fiscal First Quarter 2020 Results

[0001193125-20-126117:8k_2_02:6]
Santa Ana, CA – April 29, 2020 – TTM Technologies, Inc. (NASDAQ:TTMI), a leading global printed circuit board (“PCB”) and radio
frequency (“RF”) components manufacturer, today reported results for the first quarter of fiscal 2020, which ended on March 30, 2020. On April 19th, TTM completed the previously announced sale of its Mobility business unit. The
operating results and related assets and liabilities of the Mobility business under US GAAP are presented as discontinued operations for all periods. To facilitate the comparison of TTM’s results to prior periods and to previously issued
guidance, non-GAAP financial information is also provided below which includes the results of the Mobility business unit.

[0001193125-20-126117:8k_2_02:7]
First Quarter 2020 Highlights

[0001193125-20-126117:8k_2_02:8]
|  | – |  | GAAP net sales were $497.6 million |

[0001193125-20-126117:8k_2_02:9]
|  | – |  | Non-GAAP net sales were $610.8 million |

[0001193125-20-126117:8k_2_02:10]
|  | – |  | GAAP net loss of $3.2 million, or ($0.03) per diluted share |

[0001193125-20-126117:8k_2_02:11]
|  | – |  | Non-GAAP net income was $19.6 million, or $0.18 per diluted share, inclusive of $1.9 million in foreign exchange gains |

[0001193125-20-126117:8k_2_02:12]
|  | – |  | Cash flow from operations of $27.9 million |

[0001193125-20-126117:8k_2_02:13]
|  | – |  | Announced restructuring of Electro-Mechanical Solutions (E-MS) Business unit |

[0001193125-20-126117:8k_2_02:14]
First Quarter 2020 GAAP Financial Results

[0001193125-20-126117:8k_2_02:15]
Net sales for the first quarter of 2020 were $497.6 million, compared to $536.4 million in the first quarter of 2019 and $535.7 million in the
fourth quarter of 2019.

[0001193125-20-126117:8k_2_02:16]
GAAP operating income for the first quarter of 2020 was $16.2 million, compared to $30.1 million in the first quarter
of 2019 and $29.4 million in the fourth quarter of 2019.

[0001193125-20-126117:8k_2_02:17]
GAAP net loss for the first quarter of 2020 was $3.2 million, or ($0.03) per diluted
share. This compares to net income of $6.2 million, or $0.06 per diluted share in the first quarter of 2019, and net income of $7.3 million, or $0.07 per diluted share, in the fourth quarter of 2019.

[0001193125-20-126117:8k_2_02:18]
First Quarter 2020 Non-GAAP Financial Results

[0001193125-20-126117:8k_2_02:19]
Net sales for the first quarter of 2020 were $610.8 million, compared to $620.2 million in the first quarter of 2019 and
$719.3 million in the fourth quarter of 2019.

[0001193125-20-126117:8k_2_02:20]
On a non-GAAP basis, net income for the first quarter
of 2020 was $19.6 million, or $0.18 per diluted share. This compares to non-GAAP net income of $16.4 million, or $0.16 per diluted share, for the first quarter of 2019 and $43.9 million, or
$0.41 per diluted share, in the fourth quarter of 2019.

[0001193125-20-126117:8k_2_02:21]
Adjusted EBITDA for the first quarter of 2020 was $82.1 million, or 13.4 percent of net
sales, compared to adjusted EBITDA of $78.5 million, or 12.7 percent of net sales, for the first quarter of 2019 and $111.3 million, or 15.5 percent of net sales, for the fourth quarter of 2019.

[0001193125-20-126117:8k_2_02:22]
“As we start the second quarter, all of our manufacturing facilities remain operational and we are particularly proud of our urgent production of printed
circuit boards used for critical medical needs. I want to recognize all of our employees for their tremendous efforts in support of our customers during these challenging times,” said Tom Edman, CEO of TTM. “TTM’s first priority
remains the health and safety of our employees and we have taken proactive measures against the spread of COVID-19 in all of our facilities. We have implemented enhanced cleaning, social distancing practices,
temperature checks, and masks among other measures.”

[0001193125-20-126117:8k_2_02:23]
| TTM Technologies, Inc., Q1’20 |  | Contact: Sameer Desai, Senior Director, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-20-126117:8k_2_02:24]
“Regarding our financial results for the first quarter, TTM delivered revenue above the midpoint and earnings above the previously guided range despite a
government mandated shutdown of our manufacturing plants in China as a result of COVID-19. The year over year growth we experienced in the aerospace and defense, cellular and computing end markets partially
offset weakness in our automotive and networking and communications end markets.”

[0001193125-20-126117:8k_2_02:25]
Business Outlook

[0001193125-20-126117:8k_2_02:26]
Looking ahead, we believe that COVID-19 may cause end demand weakness, supply chain disruptions, as well as
inefficiencies with our own production. Taking this into consideration, TTM estimates that revenue for the second quarter of 2020 will be in the range of $520 million to $560 million, and non-GAAP
net income will be in the range of $0.11 to $0.17 per diluted share, which includes the financial impact of the Mobility business unit until it was sold on April 17th.

[0001193125-20-126117:8k_2_02:27]
Live Webcast/Conference Call

[0001193125-20-126117:8k_2_02:28]
TTM will host a conference
call and webcast to discuss first quarter 2020 results and the second quarter 2020 outlook on Wednesday, April 29, 2020, at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call will include forward-looking statements.

[0001193125-20-126117:8k_2_02:29]
Telephone access is available by dialing domestic 800-309-1256 or
international 720-543-0314 (ID 557290). The conference call also will be webcast on TTM’s website at www.ttm.com.

[0001193125-20-126117:8k_2_02:30]
To Access a Replay of the Webcast

[0001193125-20-126117:8k_2_02:31]
The replay of the
webcast will remain accessible for one week following the live event on TTM’s website at www.ttm.com.

[0001193125-20-126117:8k_2_02:32]
About TTM

[0001193125-20-126117:8k_2_02:33]
TTM Technologies, Inc. is a leading global printed circuit board manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs,
backplane assemblies and electro-mechanical solutions as well as a global designer and manufacturer of RF and microwave components and assemblies. TTM stands for
time-to-market, representing how TTM’s time-critical, one-stop manufacturing services enable customers to shorten the time
required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001193125-20-126117:8k_2_02:34]
Forward-Looking Statements

[0001193125-20-126117:8k_2_02:35]
This release contains forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply predictions and
actual events or results may differ materially. These statements reflect TTM’s current expectations, and TTM does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any
projected results expressed or implied in this or other TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond TTM’s control, which could cause actual results to differ
materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, the impact of COVID-19, general market and economic conditions, including interest rates, currency
exchange rates and consumer spending, demand for TTM’s products, market pressures on prices of TTM’s products, warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements,
TTM’s dependence upon a small number of customers and other factors set forth in the “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” sections of the
Company’s public reports filed with the SEC.

[0001193125-20-126117:8k_2_02:36]
| TTM Technologies, Inc., Q1’20 |  | Contact: Sameer Desai, Senior Director, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-20-126117:8k_2_02:37]
About Our Non-GAAP Financial Measures

[0001193125-20-126117:8k_2_02:38]
This release includes information about TTM’s adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable
investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing financial performance.

[0001193125-20-126117:8k_2_02:39]
A material limitation
associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar
non-GAAP financial measures used by other companies. TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and
reconciliation to the most directly comparable GAAP financial measure. However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information
prepared in accordance with GAAP.

[0001193125-20-126117:8k_2_02:40]
With respect to the Company’s outlook for non-GAAP net income per diluted
share, we are unable to predict with reasonable certainty or without unreasonable effort certain items that may affect a comparable measure calculated and presented in accordance with GAAP. Our expected
non-GAAP net income per diluted share excludes primarily the future impact of restructuring actions, impairment charges, unusual gains and losses, and tax adjustments. These reconciling items are highly
variable and difficult to predict due to various factors outside of management’s control and could have a material impact on our future period net income per diluted share calculated and presented in accordance with GAAP. Accordingly, a
reconciliation of non-GAAP net income per diluted share to a comparable measure calculated and presented in accordance with GAAP is not available without unreasonable effort and has not been provided.

[0001193125-20-126117:8k_2_02:41]
- Tables Follow -

[0001193125-20-126117:8k_2_02:42]
TTM TECHNOLOGIES, INC.

[0001193125-20-126117:8k_2_02:43]
Selected Unaudited Financial Information

[0001193125-20-126117:8k_2_02:44]
(In thousands, except per share data)

[0001193125-20-126117:8k_2_02:45]
|  |  | First Quarter |  |  | Fourth Quarter |  |
|  |  | 2020 |  |  | 2019* |  |  | 2019* |  |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 497,646 |  |  | $ | 536,445 |  |  | $ | 535,715 |  |
| Cost of goods sold |  |  | 416,304 |  |  |  | 437,619 |  |  |  | 435,470 |  |
| Gross profit |  |  | 81,342 |  |  |  | 98,826 |  |  |  | 100,245 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 16,169 |  |  |  | 17,560 |  |  |  | 17,560 |  |
| General and administrative |  |  | 34,339 |  |  |  | 29,850 |  |  |  | 37,192 |  |
| Research and development |  |  | 4,762 |  |  |  | 4,716 |  |  |  | 4,368 |  |
| Amortization of definite-lived intangibles |  |  | 9,562 |  |  |  | 16,152 |  |  |  | 9,531 |  |
| Restructuring charges |  |  | 328 |  |  |  | 432 |  |  |  | 2,204 |  |
| Total operating expenses |  |  | 65,160 |  |  |  | 68,710 |  |  |  | 70,855 |  |
| Operating income |  |  | 16,182 |  |  |  | 30,116 |  |  |  | 29,390 |  |
| Interest expense |  |  | (19,781 | ) |  |  | (21,135 | ) |  |  | (19,975 | ) |
| Other, net |  |  | 2,502 |  |  |  | (357 | ) |  |  | (1,742 | ) |
| (Loss) income from continuing operations before income taxes |  |  | (1,097 | ) |  |  | 8,624 |  |  |  | 7,673 |  |
| Income tax provision |  |  | (2,123 | ) |  |  | (2,386 | ) |  |  | (394 | ) |
| Net (loss) income from continuing operations |  |  | (3,220 | ) |  |  | 6,238 |  |  |  | 7,279 |  |
| Income (loss) from discontinued operations, net of income taxes |  |  | 2,046 |  |  |  | (9,490 | ) |  |  | 17,980 |  |
| Net (loss) income |  | $ | (1,174 | ) |  | $ | (3,252 | ) |  | $ | 25,259 |  |
| * Reclassified Research and development expenses as a separate line item from General and administrative expenses |  |  |  |  |  |  |  |  |  |  |  |  |
| (Loss) earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic (loss) earnings per share from continuing operations |  | $ | (0.03 | ) |  | $ | 0.06 |  |  | $ | 0.07 |  |
| Basic earnings (loss) per share from discontinued operations |  |  | 0.02 |  |  |  | (0.09 | ) |  |  | 0.17 |  |
| Basic (loss) earnings per share |  | $ | (0.01 | ) |  | $ | (0.03 | ) |  | $ | 0.24 |  |
| Diluted (loss) earnings per share from continuing operations |  | $ | (0.03 | ) |  | $ | 0.06 |  |  | $ | 0.07 |  |
| Diluted earnings (loss) per share from discontinued operations |  |  | 0.02 |  |  |  | (0.09 | ) |  |  | 0.17 |  |
| Diluted (loss) earnings per share |  | $ | (0.01 | ) |  | $ | (0.03 | ) |  | $ | 0.24 |  |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 105,686 |  |  |  | 104,315 |  |  |  | 105,502 |  |
| Diluted |  |  | 105,686 |  |  |  | 105,614 |  |  |  | 107,135 |  |
| Reconciliation of the denominator used to calculate basic earnings per share and diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  |  |  |  |  | 104,315 |  |  |  | 105,502 |  |
| Dilutive effect of convertible debt |  |  |  |  |  |  | — |  |  |  | — |  |
| Dilutive effect of warrants |  |  |  |  |  |  | — |  |  |  | — |  |
| Dilutive effect of performance-based stock units, restricted stock units & stock options |  |  |  |  |  |  | 1,299 |  |  |  | 1,633 |  |
| Diluted shares |  |  |  |  |  |  | 105,614 |  |  |  | 107,135 |  |
| (Loss) earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per share from continuing operations |  |  |  |  |  | $ | 0.06 |  |  | $ | 0.07 |  |
| Basic (loss) earnings per share from discontinued operations |  |  |  |  |  |  | (0.09 | ) |  |  | 0.17 |  |
| Basic (loss) earnings per share |  |  |  |  |  | $ | (0.03 | ) |  | $ | 0.24 |  |
| Diluted earnings per share from continuing operations |  |  |  |  |  | $ | 0.06 |  |  | $ | 0.07 |  |
| Diluted (loss) earnings per share from discontinued operations |  |  |  |  |  |  | (0.09 | ) |  |  | 0.17 |  |
| Diluted (loss) earnings per share |  |  |  |  |  | $ | (0.03 | ) |  | $ | 0.24 |  |
| SELECTED BALANCE SHEET DATA |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | March 30,2020 |  |  | December 30,2019 |  |  |  |  |
| Cash and cash equivalents, including restricted cash |  | $ | 361,992 |  |  | $ | 379,818 |  |  |  |  |  |
| Accounts and notes receivable, net |  |  | 458,639 |  |  |  | 503,598 |  |  |  |  |  |
| Contract assets |  |  | 256,482 |  |  |  | 254,600 |  |  |  |  |  |
| Inventories |  |  | 120,949 |  |  |  | 113,753 |  |  |  |  |  |
| Current assets held for sale |  |  | 522,974 |  |  |  | 67,572 |  |  |  |  |  |
| Total current assets |  |  | 1,751,787 |  |  |  | 1,342,684 |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 666,611 |  |  |  | 678,201 |  |  |  |  |  |
| Operating lease right of use asset |  |  | 21,724 |  |  |  | 22,173 |  |  |  |  |  |
| Non-current assets held for sale |  |  | — |  |  |  | 478,580 |  |  |  |  |  |
| Other non-current assets |  |  | 1,083,996 |  |  |  | 1,039,295 |  |  |  |  |  |
| Total assets |  |  | 3,524,118 |  |  |  | 3,560,933 |  |  |  |  |  |
| Short-term debt, including current portion of long-term debt |  | $ | 249,975 |  |  | $ | 249,975 |  |  |  |  |  |
| Accounts payable |  |  | 309,580 |  |  |  | 329,866 |  |  |  |  |  |
| Current liabilities held for sale |  |  | 170,735 |  |  |  | 185,391 |  |  |  |  |  |
| Total current liabilities |  |  | 904,363 |  |  |  | 946,666 |  |  |  |  |  |
| Debt, net of discount |  |  | 1,229,372 |  |  |  | 1,225,962 |  |  |  |  |  |
| Non-current liabilities held for sale |  |  | — |  |  |  | 1,530 |  |  |  |  |  |
| Total long-term liabilities |  |  | 1,342,555 |  |  |  | 1,335,230 |  |  |  |  |  |
| Total equity |  |  | 1,277,200 |  |  |  | 1,279,037 |  |  |  |  |  |
| Total liabilities and equity |  |  | 3,524,118 |  |  |  | 3,560,933 |  |  |  |  |  |

[0001193125-20-126117:8k_2_02:46]
| SUPPLEMENTAL DATA |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | First Quarter |  |  | Fourth Quarter |  |
|  |  | 2020 |  |  | 2019 |  |  | 2019 |  |
| Gross margin |  |  | 16.3 | % |  |  | 18.4 | % |  |  | 18.7 | % |
| Operating margin |  |  | 3.3 | % |  |  | 5.6 | % |  |  | 5.5 | % |
| End Market Breakdown, including Mobility: |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | First Quarter |  |  | Fourth Quarter |  |
|  |  | 2020 |  |  | 2019 |  |  | 2019 |  |
| Aerospace/Defense |  |  | 30 | % |  |  | 27 | % |  |  | 26 | % |
| Automotive |  |  | 12 | % |  |  | 17 | % |  |  | 14 | % |
| Cellular Phone |  |  | 11 | % |  |  | 7 | % |  |  | 16 | % |
| Computing/Storage/Peripherals |  |  | 14 | % |  |  | 13 | % |  |  | 14 | % |
| Medical/Industrial/Instrumentation |  |  | 16 | % |  |  | 15 | % |  |  | 13 | % |
| Networking/Communications |  |  | 14 | % |  |  | 18 | % |  |  | 15 | % |
| Other |  |  | 3 | % |  |  | 3 | % |  |  | 2 | % |
| Stock-based Compensation, including Mobility: |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | First Quarter |  |  | Fourth Quarter |  |
|  |  | 2020 |  |  | 2019 |  |  | 2019 |  |
| Amount included in: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 854 |  |  | $ | 705 |  |  | $ | 942 |  |
| Selling and marketing |  |  | 469 |  |  |  | 466 |  |  |  | 518 |  |
| General and administrative |  |  | 3,512 |  |  |  | 2,755 |  |  |  | 3,166 |  |
| Total stock-based compensation expense |  | $ | 4,835 |  |  | $ | 3,926 |  |  | $ | 4,626 |  |
| Operating Segment Data: |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | First Quarter |  |  | Fourth Quarter |  |
| Net sales: |  |  | 2020 |  |  |  | 2019 |  |  |  | 2019 |  |
| PCB |  | $ | 467,430 |  |  | $ | 485,067 |  |  | $ | 488,390 |  |
| E-M Solutions |  |  | 30,216 |  |  |  | 51,378 |  |  |  | 47,325 |  |
| Total net sales |  | $ | 497,646 |  |  | $ | 536,445 |  |  | $ | 535,715 |  |
| Operating segment income: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 61,626 |  |  | $ | 70,494 |  |  | $ | 72,736 |  |
| E-M Solutions |  |  | (4,329 | ) |  |  | 1,179 |  |  |  | 1,841 |  |
| Corporate |  |  | (30,170 | ) |  |  | (24,226 | ) |  |  | (34,373 | ) |
| Total operating segment income |  |  | 27,127 |  |  |  | 47,447 |  |  |  | 40,204 |  |
| Amortization of definite-lived intangibles |  |  | (10,945 | ) |  |  | (17,331 | ) |  |  | (10,814 | ) |
| Total operating income |  |  | 16,182 |  |  |  | 30,116 |  |  |  | 29,390 |  |
| Total other expense |  |  | (17,279 | ) |  |  | (21,492 | ) |  |  | (21,717 | ) |
| (Loss) income from continuing operations before income taxes |  | $ | (1,097 | ) |  | $ | 8,624 |  |  | $ | 7,673 |  |

[0001193125-20-126117:8k_2_02:47]
| RECONCILIATIONS1 |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | GAAPMarch 30, 2020 |  |  | Mobility balancesMarch 30, 20202 |  |  | CombinedMarch 30, 2020 |  |
| Cash and cash equivalents, including restricted cash |  | $ | 361,992 |  |  | $ | 68,445 |  |  | $ | 430,437 |  |
| Accounts and notes receivable, net |  |  | 458,639 |  |  |  | 6 |  |  |  | 458,645 |  |
| Contract assets |  |  | 256,482 |  |  |  | 30,181 |  |  |  | 286,663 |  |
| Inventories |  |  | 120,949 |  |  |  | 8,643 |  |  |  | 129,592 |  |
| Current assets held for sale |  |  | 522,974 |  |  |  | (522,974 | ) |  |  | — |  |
| Total current assets |  |  | 1,751,787 |  |  |  | (411,721 | ) |  |  | 1,340,066 |  |
| Property, plant and equipment, net |  |  | 666,611 |  |  |  | 330,312 |  |  |  | 996,923 |  |
| Operating lease right of use asset |  |  | 21,724 |  |  |  | 1,593 |  |  |  | 23,317 |  |
| Non-current assets held for sale |  |  | — |  |  |  | — |  |  |  | — |  |
| Other non-current assets |  |  | 1,083,996 |  |  |  | 79,816 |  |  |  | 1,163,812 |  |
| Total assets |  |  | 3,524,118 |  |  |  | — |  |  |  | 3,524,118 |  |
| Short-term debt, including current portion of long-term debt |  | $ | 249,975 |  |  | $ | — |  |  | $ | 249,975 |  |
| Accounts payable |  |  | 309,580 |  |  |  | 144,715 |  |  |  | 454,295 |  |
| Current liabilities held for sale |  |  | 170,735 |  |  |  | (178,041 | ) |  |  | — |  |
| Total current liabilities |  |  | 904,363 |  |  |  | (8,549 | ) |  |  | 903,120 |  |
| Debt, net of discount |  |  | 1,229,372 |  |  |  | — |  |  |  | 1,229,372 |  |
| Non-current liabilities held for sale |  |  | — |  |  |  | — |  |  |  | — |  |
| Total long-term liabilities |  |  | 1,342,555 |  |  |  | 8,549 |  |  |  | 1,343,798 |  |
| Total equity |  |  | 1,277,200 |  |  |  | — |  |  |  | 1,277,200 |  |
| Total liabilities and equity |  |  | 3,524,118 |  |  |  | — |  |  |  | 3,524,118 |  |
|  |  | GAAPDecember 30, 2019 |  |  | Mobility balancesDecember 30, 20192 |  |  | CombinedDecember 30, 2019 |  |
| Cash and cash equivalents, including restricted cash |  | $ | 379,818 |  |  | $ | 20,336 |  |  | $ | 400,154 |  |
| Accounts and notes receivable, net |  |  | 503,598 |  |  |  | 66 |  |  |  | 503,664 |  |
| Contract assets |  |  | 254,600 |  |  |  | 33,635 |  |  |  | 288,235 |  |
| Inventories |  |  | 113,753 |  |  |  | 8,266 |  |  |  | 122,019 |  |
| Current assets held for sale |  |  | 67,572 |  |  |  | (67,572 | ) |  |  | — |  |
| Total current assets |  |  | 1,342,684 |  |  |  | — |  |  |  | 1,342,684 |  |
| Property, plant and equipment, net |  |  | 678,201 |  |  |  | 344,728 |  |  |  | 1,022,929 |  |
| Operating lease right of use asset |  |  | 22,173 |  |  |  | 1,983 |  |  |  | 24,156 |  |
| Non-current assets held for sale |  |  | 425,597 |  |  |  | (478,580 | ) |  |  | — |  |
| Other non-current assets |  |  | 1,092,278 |  |  |  | 131,869 |  |  |  | 1,171,164 |  |
| Total assets |  |  | 3,560,933 |  |  |  | — |  |  |  | 3,560,933 |  |
| Short-term debt, including current portion of long-term debt |  | $ | 249,975 |  |  | $ | — |  |  | $ | 249,975 |  |
| Accounts payable |  |  | 329,866 |  |  |  | 153,700 |  |  |  | 483,566 |  |
| Current liabilities held for sale |  |  | 185,391 |  |  |  | (185,391 | ) |  |  | — |  |
| Total current liabilities |  |  | 946,666 |  |  |  | — |  |  |  | 946,666 |  |
| Debt, net of discount |  |  | 1,225,962 |  |  |  | — |  |  |  | 1,225,962 |  |
| Non-current liabilities held for sale |  |  | 1,530 |  |  |  | (1,530 | ) |  |  | — |  |
| Total long-term liabilities |  |  | 1,335,230 |  |  |  | — |  |  |  | 1,335,230 |  |
| Total equity |  |  | 1,279,037 |  |  |  | — |  |  |  | 1,279,037 |  |
| Total liabilities and equity |  |  | 3,560,933 |  |  |  | — |  |  |  | 3,560,933 |  |
|  |  | First Quarter |  |  | Fourth Quarter |  |
|  |  | 2020 |  |  | 2019 |  |  | 2019 |  |
| Non-GAAP revenue reconciliation3: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP revenue |  | $ | 497,646 |  |  | $ | 536,445 |  |  | $ | 535,715 |  |
| Revenue from discontinued operations |  |  | 113,174 |  |  |  | 83,755 |  |  |  | 183,538 |  |
| Non-GAAP revenue |  | $ | 610,820 |  |  | $ | 620,200 |  |  | $ | 719,253 |  |
| Non-GAAP gross profit reconciliation4: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 81,342 |  |  | $ | 98,826 |  |  | $ | 100,245 |  |
| Gross profit from discontinued operations |  |  | 4,749 |  |  |  | (10,141 | ) |  |  | 24,304 |  |
| Add back item: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 1,383 |  |  |  | 1,179 |  |  |  | 1,283 |  |
| Stock-based compensation |  |  | 854 |  |  |  | 705 |  |  |  | 942 |  |
| Non-GAAP gross profit |  | $ | 88,328 |  |  | $ | 90,569 |  |  | $ | 126,774 |  |
| Non-GAAP gross margin |  |  | 14.5 | % |  |  | 14.6 | % |  |  | 17.6 | % |
| Non-GAAP operating income reconciliation5: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP operating income |  | $ | 16,182 |  |  | $ | 30,116 |  |  | $ | 29,390 |  |
| Operating income (loss) from discontinued operations |  |  | 1,441 |  |  |  | (12,626 | ) |  |  | 20,036 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 11,620 |  |  |  | 18,005 |  |  |  | 11,489 |  |
| Stock-based compensation |  |  | 4,835 |  |  |  | 3,926 |  |  |  | 4,626 |  |
| (Gain) on sale of assets |  |  | — |  |  |  | — |  |  |  | (66 | ) |
| Restructuring, acquisition-related, and other charges |  |  | 1,596 |  |  |  | 1,103 |  |  |  | 6,856 |  |
| Non-GAAP operating income |  | $ | 35,674 |  |  | $ | 40,524 |  |  | $ | 72,331 |  |
| Non-GAAP operating margin |  |  | 5.8 | % |  |  | 6.5 | % |  |  | 10.1 | % |
| Non-GAAP net income and EPS reconciliation6: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net (loss) income |  | $ | (3,220 | ) |  | $ | 6,238 |  |  | $ | 7,279 |  |
| Net income (loss) from discontinued operations |  |  | 2,046 |  |  |  | (9,490 | ) |  |  | 17,980 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 11,620 |  |  |  | 18,005 |  |  |  | 11,489 |  |
| Stock-based compensation |  |  | 4,835 |  |  |  | 3,926 |  |  |  | 4,626 |  |
| Non-cash interest expense |  |  | 3,553 |  |  |  | 3,868 |  |  |  | 3,501 |  |
| (Gain) on sale of assets |  |  | (233 | ) |  |  | (3,071 | ) |  |  | (186 | ) |
| Restructuring, acquisition-related, and other charges |  |  | 1,596 |  |  |  | 1,103 |  |  |  | 6,856 |  |
| Income taxes7 |  |  | (593 | ) |  |  | (4,150 | ) |  |  | (7,623 | ) |
| Non-GAAP net income |  | $ | 19,604 |  |  | $ | 16,429 |  |  | $ | 43,922 |  |
| Non-GAAP earnings per diluted share |  | $ | 0.18 |  |  | $ | 0.16 |  |  | $ | 0.41 |  |
| Non-GAAP diluted number of shares8: |  |  |  |  |  |  |  |  |  |  |  |  |
| Diluted shares |  |  | 107,378 |  |  |  | 105,614 |  |  |  | 107,135 |  |
| Dilutive effect of convertible debt |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-GAAP diluted number of shares |  |  | 107,378 |  |  |  | 105,614 |  |  |  | 107,135 |  |
| Adjusted EBITDA reconciliation9: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net (loss) income |  | $ | (3,220 | ) |  | $ | 6,238 |  |  | $ | 7,279 |  |
| Net income (loss) from discontinued operations |  |  | 2,046 |  |  |  | (9,490 | ) |  |  | 17,980 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax provision (benefit) |  |  | 2,865 |  |  |  | (1,476 | ) |  |  | 1,140 |  |
| Interest expense |  |  | 20,004 |  |  |  | 21,688 |  |  |  | 20,107 |  |
| Amortization of definite-lived intangibles |  |  | 11,620 |  |  |  | 18,005 |  |  |  | 11,489 |  |
| Depreciation expense |  |  | 42,632 |  |  |  | 41,602 |  |  |  | 42,018 |  |
| Stock-based compensation |  |  | 4,835 |  |  |  | 3,926 |  |  |  | 4,626 |  |
| (Gain) on sale of assets |  |  | (233 | ) |  |  | (3,071 | ) |  |  | (186 | ) |
| Restructuring, acquisition-related, and other charges |  |  | 1,596 |  |  |  | 1,103 |  |  |  | 6,856 |  |
| Adjusted EBITDA |  | $ | 82,145 |  |  | $ | 78,525 |  |  | $ | 111,309 |  |
| Adjusted EBITDA margin |  |  | 13.4 | % |  |  | 12.7 | % |  |  | 15.5 | % |
| Free cash flow reconciliation, including Mobility: |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flow |  |  | 27,913 |  |  |  | 36,924 |  |  |  | 130,148 |  |
| Capital expenditures, net |  |  | (32,451 | ) |  |  | (28,446 | ) |  |  | (46,982 | ) |
| Free cash flow |  | $ | (4,538 | ) |  | $ | 8,478 |  |  | $ | 83,166 |  |

[0001193125-20-126117:8k_2_02:48]
| 1 | This information provides a reconciliation of non-GAAP balance sheet data to the financial information in our consolidated condensed balance sheets and non-GAAP revenue, non-GAAP gross profit, non-GAAP operating income, non-GAAP net income, non-GAAP EPS, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |

[0001193125-20-126117:8k_2_02:49]
| 2 | Excludes the estimated gain on sale of Mobility. |

[0001193125-20-126117:8k_2_02:50]
| 3 | Non-GAAP revenue includes revenue from discontinued operations. |

[0001193125-20-126117:8k_2_02:51]
| 4 | Non-GAAP gross profit and gross margin measures include discontinued operations and exclude amortization of intangibles and stock-based compensation expense. |

[0001193125-20-126117:8k_2_02:52]
| 5 | Non-GAAP operating income and operating margin measures include discontinued operations and exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, acquisition-related costs, restructuring and other charges. |

[0001193125-20-126117:8k_2_02:53]
| 6 | This information provides non-GAAP net income and non-GAAP EPS, which are non-GAAP financial measures. Management believes that both measures — which include discontinued operations and add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, acquisition-related costs, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items — provide additional useful information to investors regarding the Company’s ongoing financial condition and results of operations. |

[0001193125-20-126117:8k_2_02:54]
| 7 | Income tax adjustments reflect the difference between income taxes based on a non-GAAP tax rate and a forecasted annual GAAP tax rate. |

[0001193125-20-126117:8k_2_02:55]
| 8 | Non-GAAP diluted number of shares used in computing non-GAAP earnings per share excludes the dilutive effect of convertible debt. |

[0001193125-20-126117:8k_2_02:56]
| 9 | Adjusted EBITDA is defined as earnings, including discontinued operations, before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, acquisition-related costs, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |
