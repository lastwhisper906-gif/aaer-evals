# TTMI MD&A — 0001564590-20-022818


## mdna

[0001564590-20-022818:mdna:1]
[same as prior period, unchanged from 0001564590-19-041722:mdna:1]

[0001564590-20-022818:mdna:2]
[same as prior period, unchanged from 0001564590-19-041722:mdna:2]

[0001564590-20-022818:mdna:3]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions), as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering and manufacturing solution to our customers. This one-stop design, engineering and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,200 customers in various markets throughout the world, including, and increasingly, aerospace and defense, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-20-022818:mdna:4]
[same as prior period, unchanged from 0001564590-19-041722:mdna:4]

[0001564590-20-022818:mdna:5]
The recent coronavirus (COVID-19) pandemic first caused some business disruption in our operations in China beginning in January 2020. By March 2020, the situation escalated as the scope of the COVID-19 pandemic worsened outside of the Asia-Pacific region, with Europe and North America being affected by the pandemic. There is significant uncertainty relating to the potential impacts of the COVID-19 pandemic, and we cannot reasonably estimate its duration or severity. The COVID-19 pandemic creates various global macroeconomic, operational and supply chain risks any one of which could have a material and adverse impact on our business going forward. See Item 1A, Risk Factors, of Part II below for further information related to the COVID-19 pandemic. We have taken measures to protect our employees, suppliers and customers by implementing our pandemic recovery protocols, establishing situational leadership teams in Asia-Pacific and North America along with routine executive review and planning calls, implementing global travel restrictions, and conforming to the guidance and direction of local governments and global health organizations. We are monitoring the impacts the COVID-19 pandemic has had, and continues to have, on our supply chain and are collaborating with our third-party partners with the goal of mitigating to the extent reasonably practicable significant delays in delivery of our products.

[0001564590-20-022818:mdna:6]
On April 17, 2020, we completed the sale of the following subsidiaries of our Mobility business unit: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) for a base purchase price of $550.0 million in cash, subject to customary purchase price adjustments. The purchase agreement excludes from the sale certain accounts receivable related to the business, which we expect, based on the terms of the purchase agreement will result in an estimated $95.0 million in cash to us and is expected to be collected during the next three to four months.

[0001564590-20-022818:mdna:7]
On April 28, 2020, our board of directors approved a restructuring plan with respect to our E-M Solutions business unit, which consists of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). Pursuant to the plan, we will discontinue operations at the SH E-MS and SZ facilities while integrating the SH BPA facility into our PCB operations.

[0001564590-20-022818:mdna:8]
[same as prior period, unchanged from 0001564590-19-041722:mdna:6]

[0001564590-20-022818:mdna:9]
Results related to our Mobility business unit are reported as discontinued operations for all periods presented. See Part I, Item 1, Note 2, Discontinued Operations, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q for further information. Unless otherwise noted, amounts and disclosures throughout our MD&A relate to our continuing operations.

[0001564590-20-022818:mdna:10]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers accounted for 42% and 41% of our net sales for the quarters ended March 30, 2020 and April 1, 2019, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-20-022818:mdna:11]
[same as prior period, unchanged from 0001564590-19-041722:mdna:8]

[0001564590-20-022818:mdna:12]
|  |  | Quarter Ended |
| End Markets (1) |  | March 30, 2020 |  |  |  | April 1, 2019 |  |  |
| Aerospace and Defense |  |  | 37 |  | % |  |  | 31 |  | % |
| Automotive |  |  | 14 |  |  |  |  | 19 |  |  |
| Cellular Phone |  |  | 1 |  |  |  |  | — |  |  |
| Computing/Storage/Peripherals (2) |  |  | 12 |  |  |  |  | 11 |  |  |
| Medical/Industrial/Instrumentation |  |  | 18 |  |  |  |  | 17 |  |  |
| Networking/Communications |  |  | 16 |  |  |  |  | 20 |  |  |
| Other (2) |  |  | 2 |  |  |  |  | 2 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-20-022818:mdna:13]
[same as prior period, unchanged from 0001564590-19-041722:mdna:10]

[0001564590-20-022818:mdna:14]
| (2) | Tablets are included in the Computing/Storage/Peripherals end market and other consumer devices that include wearables, portable video devices and personal headphones are included in the Other end market. |

[0001564590-20-022818:mdna:15]
We derive revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of RF and microwave components, assemblies and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and custom electronic assemblies manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

[0001564590-20-022818:mdna:16]
[same as prior period, unchanged from 0001564590-19-041722:mdna:15]

[0001564590-20-022818:mdna:17]
[same as prior period, unchanged from 0001564590-19-041722:mdna:16]

[0001564590-20-022818:mdna:18]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. While we have entered into supply assurance agreements with some of our key suppliers to maintain the continuity of supply of some of the key materials we use, we generally do not participate in any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for most of the raw materials we use.

[0001564590-20-022818:mdna:19]
[same as prior period, unchanged from 0001564590-19-041722:mdna:18]

[0001564590-20-022818:mdna:20]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, facilities, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001564590-20-022818:mdna:21]
Research and development expenses consist primarily of salaries and labor related benefits paid to our research and development staff.

[0001564590-20-022818:mdna:22]
[same as prior period, unchanged from 0001564590-19-041722:mdna:20]

[0001564590-20-022818:mdna:23]
[same as prior period, unchanged from 0001564590-19-041722:mdna:21]

[0001564590-20-022818:mdna:24]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended December 30, 2019 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since December 30, 2019.

[0001564590-20-022818:mdna:25]
[same as prior period, unchanged from 0001564590-19-041722:mdna:27]

[0001564590-20-022818:mdna:26]
[same as prior period, unchanged from 0001564590-19-041722:mdna:28]

[0001564590-20-022818:mdna:27]
|  |  | Quarter Ended |
|  |  | March 30, 2020 |  |  |  | April 1, 2019 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 83.7 |  |  |  |  | 81.6 |  |  |
| Gross profit |  |  | 16.3 |  |  |  |  | 18.4 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.2 |  |  |  |  | 3.3 |  |  |
| General and administrative |  |  | 7.0 |  |  |  |  | 5.6 |  |  |
| Research and development |  |  | 0.9 |  |  |  |  | 0.9 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.9 |  |  |  |  | 3.0 |  |  |
| Total operating expenses |  |  | 13.0 |  |  |  |  | 12.8 |  |  |
| Operating income |  |  | 3.3 |  |  |  |  | 5.6 |  |  |
| Other expense: |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (4.0 | ) |  |  |  | (3.9 | ) |  |
| Other, net |  |  | 0.5 |  |  |  |  | (0.1 | ) |  |
| Total other expense, net |  |  | (3.5 | ) |  |  |  | (4.0 | ) |  |
| (Loss) income before income taxes |  |  | (0.2 | ) |  |  |  | 1.6 |  |  |
| Income tax provision |  |  | (0.4 | ) |  |  |  | (0.4 | ) |  |
| Net (loss) income from continuing operations |  |  | (0.6 | ) | % |  |  | 1.2 |  | % |

[0001564590-20-022818:mdna:28]
[same as prior period, unchanged from 0001564590-19-041722:mdna:30]

[0001564590-20-022818:mdna:29]
[same as prior period, unchanged from 0001564590-19-041722:mdna:31]

[0001564590-20-022818:mdna:30]
Total net sales decreased $38.8 million, or 7.2%, to $497.6 million for the first quarter of 2020 from $536.4 million for the first quarter of 2019. This decrease primarily resulted from a reduction in net sales for the E-M Solutions reportable segment of $21.2 million, or 41.2%, to $30.2 million for the first quarter of 2020 from $51.4 million for the first quarter of 2019. The decrease was primarily due to lower demand in our Automotive, Medical/Industrial/Instrumentation, and Networking/Communications end markets. Additionally, net sales for the PCB reportable segment decreased by $17.6 million, or 3.6%, to $467.4 million for the first quarter of 2020 from $485.1 million for the first quarter of 2019. The reduction in net sales for the PCB reportable segment was primarily due to lower demand in our Networking/Communications and Automotive end markets partially offset by increased demand in our Aerospace and Defense end market. These changes resulted in a 23.6% decrease in the volume of PCB shipments partially offset by an average PCB selling price increase of 26.5%, driven mainly by product mix shift, as compared to the first quarter of 2019.

[0001564590-20-022818:mdna:31]
[same as prior period, unchanged from 0001564590-19-041722:mdna:34]

[0001564590-20-022818:mdna:32]
Overall gross margin decreased to 16.3% for the first quarter of 2020 from 18.4% for the first quarter of 2019. Gross margin for the PCB reportable segment decreased to 18.6% for the first quarter of 2020 from 20.3% for the first quarter of 2019, primarily due to lower volumes in our commercially focused facilities. Gross margin for the E-M Solutions reportable segment decreased to (5.7%) for the first quarter of 2020 from 6.3% for the first quarter of 2019, primarily due to lower sales and additional provision for excess and obsolete inventories.

[0001564590-20-022818:mdna:33]
Capacity utilization is a key driver for us, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the first quarter of 2020 in our Asia and North America PCB facilities was 50% and 67%, respectively, compared to 64% and 62%, respectively, for the first quarter of 2019. The decline in capacity utilization in our Asia PCB facilities was due to a decrease in production caused by the extended Chinese New Year holidays due to COVID-19 while the increase in capacity utilization in our North America PCB facilities was due to an increase in production related to increased sales in our Aerospace and Defense end market.

[0001564590-20-022818:mdna:34]
[same as prior period, unchanged from 0001564590-19-041722:mdna:38]

[0001564590-20-022818:mdna:35]
Selling and marketing expenses decreased $1.4 million, to $16.2 million for the first quarter of 2020 from $17.6 million for the first quarter of 2019. As a percentage of net sales, selling and marketing expenses was 3.2% for the first quarter of 2020, as compared to 3.3% for the first quarter of 2019. The decrease in selling and marketing expense for the quarter ended March 30, 2020 was primarily due to reduced commission expense.

[0001564590-20-022818:mdna:36]
[same as prior period, unchanged from 0001564590-19-041722:mdna:41]

[0001564590-20-022818:mdna:37]
General and administrative expenses increased $4.4 million to $34.7 million, or 7.0% of net sales, for the first quarter of 2020 from $30.3 million, or 5.6% of net sales, for the first quarter of 2019. The increase in general and administrative expenses for the quarter ended March 30, 2020 was primarily due to the increase in acquisition/integration, bad debt, and consulting costs.

[0001564590-20-022818:mdna:38]
[same as prior period, unchanged from 0001564590-19-041722:mdna:44]

[0001564590-20-022818:mdna:39]
Other expense, net decreased $4.2 million to $17.3 million for the first quarter of 2020 from $21.5 million for the first quarter of 2019. The decrease in other expense, net for the quarter ended March 30, 2020 was primarily the result of higher foreign currency gains due to the depreciation of the Chinese Renminbi (RMB) in the first quarter of 2020 compared to the first quarter of 2019. We utilize the RMB at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China.

[0001564590-20-022818:mdna:40]
[same as prior period, unchanged from 0001564590-19-041722:mdna:47]

[0001564590-20-022818:mdna:41]
The provision for income taxes decreased by $0.3 million to $2.1 million of tax expense for the first quarter of 2020 from $2.4 million of tax expense for the first quarter of 2019. The decrease in income tax expense for the first quarter of 2020 was primarily due to a decrease in continuing operating income offset by an increase related to the retroactive approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China.

[0001564590-20-022818:mdna:42]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of credits and deductions available to us, as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax asset of approximately $24.5 million and $11.3 million as of March 30, 2020 and April 1, 2019, respectively.

[0001564590-20-022818:mdna:43]
On March 27, 2020, the President of the United States signed the Coronavirus Aid, Relief, and Economic Security Act (CARES Act) providing economic relief to disruptions caused by the Coronavirus pandemic. Accounting Standard Codification (ASC) 740, Accounting for Income Taxes, requires companies to recognize the effect of tax law changes in the period of enactment regardless of the effective date of those tax law changes. We considered the impact to our financial statements of the corporate income tax aspects of the CARES Act and determined the impact is not material to our financial statements. The CARES Act includes a number of provisions, including the increase of IRC Section 163(j) limitation of Adjusted Tax Income (ATI) from 30% to 50%. This is applicable to 2019 and 2020 tax years. The Company properly accounted for such change in the Q1 2020 provision calculation. There are also provisions that allow for a 100% refund of Alternative Minimum Tax Credit carryforwards and which postpone tax compliance deadlines and payments ordinarily due April 15, 2020.

[0001564590-20-022818:mdna:44]
[same as prior period, unchanged from 0001564590-19-041722:mdna:50]

[0001564590-20-022818:mdna:45]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our Revolving Credit Facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, meet debt service requirements, fund working capital requirements, and pay down existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001564590-20-022818:mdna:46]
Cash flow provided by operating activities for continuing operations during the first quarter of 2020 was $6.6 million as compared to cash flow provided by operating activities from continuing operations of $9.1 million in the same period in 2019. The decrease in cash flow was primarily due to the net loss from continuing operations of $3.2 million for the first quarter of 2020 as compared to a net income of $6.2 million in the same period in 2019, partially offset by lower investment in working capital.

[0001564590-20-022818:mdna:47]
Net cash used in investing activities for continuing operations was approximately $23.9 million for the first quarter of 2020, reflecting purchases of property, plant and equipment and other assets. Net cash used in investing activities for continuing operations was approximately $22.2 million for the first quarter of 2019, reflecting $27.2 million for purchases of property, plant and equipment less proceeds from sale of property, plant and equipment and other assets of $5.0 million.

[0001564590-20-022818:mdna:48]
There was no activity related to cash flows from financing activities for the first quarter of 2020. Net cash used in financing activities was approximately $30.0 million for the first quarter of 2019, reflecting repayment of long-term debt of $30.0 million.

[0001564590-20-022818:mdna:49]
As of March 30, 2020, we had cash and cash equivalents of approximately $361.9 million, of which approximately $325.5 million was held by our foreign subsidiaries, primarily in China.

[0001564590-20-022818:mdna:50]
Our 2020 net capital expenditures and asset acquisitions are expected to be in the range of $100.0 million to $120.0 million.

[0001564590-20-022818:mdna:51]
We believe our existing cash resources and sources of liquidity, together with cash generated from operations, will be sufficient to meet our working capital requirements for at least the next twelve months. However, should demand for our products change significantly over the next twelve months or should we experience significant increases in delinquent or uncollectible accounts receivable for any reason, including in particular continued or worsening economic conditions caused by the COVID-19 global pandemic, our cash provided by operations could decrease significantly and we could be required to seek additional sources of liquidity to continue our operations at their current level.

[0001564590-20-022818:mdna:52]
[same as prior period, unchanged from 0001564590-19-041722:mdna:57]

[0001564590-20-022818:mdna:53]
As of March 30, 2020, we had $1,479.3 million of outstanding debt, net of discount and debt issuance costs, composed of $797.6 million of Term Loan due September 2024, $369.9 million of Senior Notes due October 2025, $241.8 million of Convertible Senior Notes due December 2020, $40.0 million under the U.S. ABL, and $30.0 million under the Asia ABL.

[0001564590-20-022818:mdna:54]
Borrowings under the Term Loan Facility and Senior Notes Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. As of March 30, 2020, we were in compliance with the covenants under the Term Loan Facility, Senior Notes Facility and ABL Revolving Loans.

[0001564590-20-022818:mdna:55]
[same as prior period, unchanged from 0001564590-19-041722:mdna:60]

[0001564590-20-022818:mdna:56]
[same as prior period, unchanged from 0001564590-19-041722:mdna:61]

[0001564590-20-022818:mdna:57]
As of the date of this report, there were no material changes to our contractual obligations and commitments outside the ordinary course of business since December 30, 2019 as reported in our Annual Report on Form 10-K for the fiscal year ended December 30, 2019.

[0001564590-20-022818:mdna:58]
[same as prior period, unchanged from 0001564590-19-041722:mdna:63]

[0001564590-20-022818:mdna:59]
[same as prior period, unchanged from 0001564590-19-041722:mdna:64]

[0001564590-20-022818:mdna:60]
[same as prior period, unchanged from 0001564590-19-041722:mdna:65]

[0001564590-20-022818:mdna:61]
Orders for our products generally correspond to the production schedules of our customers. We historically experience seasonal fluctuations in the first quarter due to the Chinese New Year holidays, which typically results in lower net sales for that quarter. We attribute this decline to shutdowns of our customers’ and our own China based manufacturing facilities surrounding the Chinese New Year public holidays, which normally occur in January or February of each year.

[0001564590-20-022818:mdna:62]
Recently Issued Accounting Standards

[0001564590-20-022818:mdna:63]
For a description of recently adopted and issued accounting standards, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Part I, Item 1, Note 1, Nature of Operations and Basis of Presentation, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q.
