# TTMI note change history — 0001564590-19-041722 → 0001564590-20-022818


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-07):
[0001564590-20-022818:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of March 30, 2020 and December 30, 2019. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2019-11-07, similarity 0.9907):
[0001564590-19-041722:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 30, 2019 and December 31, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-07):
[0001564590-20-022818:note_history:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This one-stop design and manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.
  (was, 2019-11-07, similarity 0.9515):
[0001564590-19-041722:note_history:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers from engineering support to prototype development through final mass production. This one-stop design and manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- changed (2020-05-07):
[0001564590-20-022818:note_history:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.
  (was, 2019-11-07, similarity 0.9327):
[0001564590-19-041722:note_history:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

- changed (2020-05-07):
[0001564590-20-022818:note_history:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due to the coronavirus (COVID-19) global pandemic, the global economy and financial markets have been disrupted and there is a significant amount of uncertainty about the length and severity of the consequences caused by the pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 13-week fiscal quarter accounting period with the fourth quarter ending on the Monday nearest December 31.
  (was, 2019-11-07, similarity 0.698):
[0001564590-19-041722:note_history:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements reflect all adjustments (consisting only of normal recurring adjustments) which, in the opinion of management, are necessary to present fairly the financial position, the results of operations and cash flows of the Company for the periods presented. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The results of operations for the interim periods are not necessarily indicative of the results to be expected for the full year. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Actual results could differ materially from those estimates. The Company uses a 13-week fiscal quarter accounting period with the fourth quarter ending on the Monday nearest December 31.

- added (2020-05-07):
[0001564590-20-022818:note_history:5]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). For all periods presented in the consolidated condensed balance sheet, all assets and liabilities attributable to the Mobility business unit have been aggregated under the captions “Current assets held for sale”, “Non-current assets held for sale”, “Current liabilities held for sale” and “Non-current liabilities held for sale”. For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses and income taxes attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. Prior year results have been recast to conform with the current presentation. Refer to Note 2, Discontinued Operations, for additional information.

- added (2020-05-07):
[0001564590-20-022818:note_history:6]
Unless otherwise noted, amounts and disclosures throughout these notes to consolidated condensed financial statements relate to continuing operations. These consolidated condensed financial statements reflect all adjustments (consisting only of normal recurring adjustments) which, in the opinion of management, are necessary to present fairly the financial position, the results of operations and cash flows of the Company for the periods presented. The results of operations for the interim periods are not necessarily indicative of the results to be expected for the full year.

- added (2020-05-07):
[0001564590-20-022818:note_history:7]
Certain prior year amounts in the condensed consolidated financial statements have been reclassified due to the sale of the Company’s Mobility business unit. Refer to Note 2, Discontinued Operations, for further information regarding this sale and the resulting prior year reclassifications. Further, in 2020, the Company began presenting research and development expenses as a separate line item on the consolidated condensed statements of operations to better align with similar presentation made by peers and to provide additional disclosure that is meaningful for investors. The prior year consolidated condensed statements of operations were adjusted to conform with this new presentation. Research and development expense were previously presented within general and administrative expense on the consolidated condensed statements of operations.

- added (2020-05-07):
[0001564590-20-022818:note_history:8]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which amends the current accounting guidance and requires the measurement of all expected losses based on historical experience, current conditions and reasonable and supportable forecasts. For trade receivables, loans, and other financial instruments, the Company will be required to use a forward-looking expected loss model that reflects losses that are probable rather than the incurred loss model for recognizing credit losses. The standard became effective for interim and annual periods beginning after December 15, 2019. Application of the amendments is through a cumulative-effect adjustment to retained earnings as of the effective date. The Company adopted this ASU as of December 31, 2019 and it did not have a material impact on its financial statements.

- added (2020-05-07):
[0001564590-20-022818:note_history:9]
In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting, which provides temporary relief to the GAAP guidance on contract modifications and hedge accounting to ease the financial reporting burdens of the expected market transition from LIBOR and other interbank offered rates to alternative rates. This guidance is effective beginning on March 12, 2020 through December 31, 2022. The guidance on contract modifications can be applied prospectively from any date beginning March 12, 2020 and may also be applied to modifications of existing contracts made earlier in the interim period that includes March 12, 2020. The guidance on hedging can be applied to eligible hedging relationships existing at the beginning of the interim period that includes March 12, 2020 and to new eligible hedging relationships entered into after the beginning of that interim period. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures.

- added (2020-05-07):
[0001564590-20-022818:note_history:10]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company has evaluated the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures and the impact is not expected to be material.

- removed (2020-05-07):
[0001564590-19-041722:note_history:11]
Certain amounts in the prior period consolidated condensed financial statement have been reclassified to conform to the presentation of the current period consolidated condensed financial statement. These reclassifications had no effect on the previously reported net income. An adjustment has been made to combine the statutory surplus reserve with retained earnings on the consolidated condensed balance sheet and the consolidated condensed statement of stockholders’ equity.

- removed (2020-05-07):
[0001564590-19-041722:note_history:12]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU 2016-02, Leases (Topic 842) which supersedes the existing lease recognition requirements in the current accounting standard for leases. The core principal of the new standard is that an entity should recognize right-of-use (ROU) assets and lease liabilities arising from a lease for both financing and operating leases, along with additional qualitative and quantitative disclosures.

- removed (2020-05-07):
[0001564590-19-041722:note_history:13]
In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements. ASU 2018-11 provides additional guidance to Topic 842 including providing preparers an additional optional retrospective adoption method which allows entities to initially apply the new leases standard at the adoption date and recognize a cumulative effect adjustment to the opening balance of retained earnings. ASU 2018-11 also provides lessors a practical expedient to not separate lease from non-lease components, in certain situations.

- removed (2020-05-07):
[0001564590-19-041722:note_history:14]
The Company adopted the new lease standard as of January 1, 2019 and utilized the retrospective cumulative effect adjustment transition method with a cumulative effect adjustment being recorded as of the adoption date. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated condensed balance sheet as of December 31, 2018 and the consolidated condensed statement of operations for the quarter and three quarters ended October 1, 2018. The Company implemented internal controls and key system functionality to enable the preparation of financial information on adoption. The Company elected certain available practical expedients including the package of practical expedients permitted under the transition guidance within the new standard, which among other things, allowed the Company to carry forward the historical lease classification. Additionally, the Company elected an accounting policy to not record ROU assets and lease liabilities for leases with an initial term of twelve months or less on its consolidated condensed balance sheet.

- removed (2020-05-07):
[0001564590-19-041722:note_history:15]
The cumulative effect of the changes made to the Company’s January 1, 2019 consolidated condensed balance sheet for the adoption of the new lease standard was as follows:

- removed (2020-05-07):
[0001564590-19-041722:note_history:16]
|  |  | Balance as of December 31, 2018 |  |  | New Lease Standard Adjustment |  |  | Balance as of January 1, 2019 |  |
|  |  | (In thousands) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets |  | $ | — |  |  | $ | 16,894 |  |  | $ | 16,894 |  |
| Deposits and other non-current assets |  |  | 55,597 |  |  |  | (548 | ) |  |  | 55,049 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  |  | 113,756 |  |  |  | 2,545 |  |  |  | 116,301 |  |
| Operating lease liabilities |  |  | — |  |  |  | 14,356 |  |  |  | 14,356 |  |
| Other long-term liabilities |  |  | 94,777 |  |  |  | (555 | ) |  |  | 94,222 |  |

- removed (2020-05-07):
[0001564590-19-041722:note_history:17]
The adoption of the new accounting guidance did not have a material impact to the consolidated condensed statement of operations for the quarter and three quarters ended September 30, 2019, or the consolidated condensed statement of cash flows for the three quarters ended September 30, 2019. See Note 3 for further details.

- removed (2020-05-07):
[0001564590-19-041722:note_history:18]
In June 2018, the FASB issued ASU 2018-07, Compensation-Stock Compensation (Topic 718): Improvements to Nonemployee Share-based Payments. This ASU expands the scope of Topic 718 to include share-based payment transactions for acquiring goods and services from nonemployees. The effective date for the standard is for interim periods in fiscal years beginning after December 15, 2018, with early adoption permitted, but no earlier than the Company's adoption date of Topic 606. The new guidance is required to be applied retrospectively with the cumulative effect recognized at the date of initial application. The Company adopted ASU 2018-07 on January 1, 2019. The adoption did not have a material impact on the consolidated condensed financial statements or related disclosures.

- removed (2020-05-07):
[0001564590-19-041722:note_history:19]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company adopted ASU 2017-12 on January 1, 2019. The adoption did not have a material impact on the consolidated condensed financial statements or related disclosures.

- removed (2020-05-07):
[0001564590-19-041722:note_history:20]
In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments. Apart from the amendments to ASU 2016-13 as mentioned below, the ASU also included subsequent amendments to ASU 2016-01, which we adopted on January 2, 2018. The guidance in relation to the amendments to ASU 2016-01 is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures.

- removed (2020-05-07):
[0001564590-19-041722:note_history:21]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial

- removed (2020-05-07):
[0001564590-19-041722:note_history:22]
Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments—Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. All of these ASUs are effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2020-05-07):
[0001564590-19-041722:note_history:23]
(2) Summary of Significant Accounting Policies

- removed (2020-05-07):
[0001564590-19-041722:note_history:24]
Leases

- removed (2020-05-07):
[0001564590-19-041722:note_history:25]
The Company determines if an arrangement is a lease at inception. Operating leases are included in operating lease ROU assets, other current liabilities, and operating lease liabilities on the consolidated condensed balance sheets.

- removed (2020-05-07):
[0001564590-19-041722:note_history:26]
ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments arising from the lease. Operating lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of the Company’s leases do not provide an implicit rate, the Company uses incremental borrowing rate based on the information available at commencement date in determining the present value of lease payments. The operating lease ROU asset also includes any lease payments made and excludes lease incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

- removed (2020-05-07):
[0001564590-19-041722:note_history:27]
The Company has lease agreements with lease and non-lease components and accounts for the lease and non-lease components as a single lease component.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2020-05-07):
[0001564590-19-041722:note_history:28]
The components of interest expense resulting from the Convertible Senior Notes for the quarter and three quarters ended September 30, 2019 and October 1, 2018 were as follows:

- removed (2020-05-07):
[0001564590-19-041722:note_history:29]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, |  |  | October 1, |  |  | September 30, |  |  | October 1, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,457 |  |  | $ | 2,303 |  |  | $ | 7,254 |  |  | $ | 6,800 |  |
| Amortization of debt issuance costs |  | $ | 246 |  |  | $ | 231 |  |  | $ | 727 |  |  | $ | 682 |  |


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-07):
[0001564590-20-022818:note_history:30]
As of March 30, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2019-11-07, similarity 0.964):
[0001564590-19-041722:note_history:30]
As of September 30, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes were as follows:

- changed (2020-05-07):
[0001564590-20-022818:note_history:31]
|  |  | As of March 30, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,340 |  |  | $ | 1,918 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,121 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 741 |  |  |  | 7,387 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 12,202 |  |  | $ | 9,305 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |
  (was, 2019-11-07, similarity 0.816):
[0001564590-19-041722:note_history:31]
|  |  | As of September 30, 2019 |  |  |  | As of December 31, 2018 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,986 |  |  | $ | 2,113 |  |  |  | 4.66 |  | % |  | $ | 8,229 |  |  | $ | 2,489 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,509 |  |  | — |  |  |  | 5.92 |  |  |  |  | 6,071 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 1,245 |  |  |  | 12,423 |  |  |  | 6.48 |  |  |  |  | 1,972 |  |  |  | 19,678 |  |  |  | 6.48 |  |  |
|  |  | $ | 13,740 |  |  | $ | 14,536 |  |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2020-05-07):
[0001564590-19-041722:note_history:32]
As of September 30, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:

- removed (2020-05-07):
[0001564590-19-041722:note_history:33]
|  |  | As of September 30, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-07):
[0001564590-20-022818:note_history:34]
The following table summarizes the long-term debt of the Company as of March 30, 2020 and December 30, 2019:
  (was, 2019-11-07, similarity 0.95):
[0001564590-19-041722:note_history:34]
The following table summarizes the long-term debt of the Company as of September 30, 2019 and December 31, 2018:

- added (2020-05-07):
[0001564590-20-022818:note_history:35]
|  |  | Interest Rate as of March 30, 2020 |  |  | Principal Outstanding as of March 30, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 3.48 |  | % | $ | 805,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 2.23 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 2.38 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (9,305 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (12,202 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,479,347 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (249,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,229,372 |  |  |  |  |  |  | $ | 1,225,962 |  |

- added (2020-05-07):
[0001564590-20-022818:note_history:36]
The Company has twelve months to reinvest the cash proceeds received from the sale of the Mobility business unit. If the proceeds are not reinvested, the Company is required to use the proceeds to prepay the Term Loan. The Company plans to use the cash proceeds for debt repayment and reinvestment. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

- added (2020-05-07):
[0001564590-20-022818:note_history:37]
Debt Covenants

- changed (2020-05-07):
[0001564590-20-022818:note_history:38]
Borrowings under the Term Loan and Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.
  (was, 2019-11-07, similarity 0.9549):
[0001564590-19-041722:note_history:38]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

- added (2020-05-07):
[0001564590-20-022818:note_history:39]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

- changed (2020-05-07):
[0001564590-20-022818:note_history:40]
As of March 30, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2019-11-07, similarity 0.964):
[0001564590-19-041722:note_history:40]
As of September 30, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes were as follows:

- changed (2020-05-07):
[0001564590-20-022818:note_history:41]
|  |  | As of March 30, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,340 |  |  | $ | 1,918 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,121 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 741 |  |  |  | 7,387 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 12,202 |  |  | $ | 9,305 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |
  (was, 2019-11-07, similarity 0.816):
[0001564590-19-041722:note_history:41]
|  |  | As of September 30, 2019 |  |  |  | As of December 31, 2018 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,986 |  |  | $ | 2,113 |  |  |  | 4.66 |  | % |  | $ | 8,229 |  |  | $ | 2,489 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,509 |  |  | — |  |  |  | 5.92 |  |  |  |  | 6,071 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 1,245 |  |  |  | 12,423 |  |  |  | 6.48 |  |  |  |  | 1,972 |  |  |  | 19,678 |  |  |  | 6.48 |  |  |
|  |  | $ | 13,740 |  |  | $ | 14,536 |  |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |  |

- changed (2020-05-07):
[0001564590-20-022818:note_history:42]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,369 and $2,511 as of March 30, 2020 and December 30, 2019, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2019-11-07, similarity 0.9769):
[0001564590-19-041722:note_history:42]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,654 and $1,420 as of September 30, 2019 and December 31, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2020-05-07):
[0001564590-20-022818:note_history:43]
As of March 30, 2020, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.4 years.
  (was, 2019-11-07, similarity 0.964):
[0001564590-19-041722:note_history:43]
As of September 30, 2019, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.5 years.

- removed (2020-05-07):
[0001564590-19-041722:note_history:44]
|  | Interest Rate as of September 30, 2019 |  |  | Principal Outstanding as of September 30, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  | (In thousands, except interest rates) |  |
| Term Loan due September 2024 |  | 4.52 |  | % | $ | 805,879 |  |  |  | 5.00 |  | % | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due June 2024 |  | 3.27 |  |  |  | 40,000 |  |  |  | 4.00 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  | 3.42 |  |  |  | 30,000 |  |  |  | 3.90 |  |  |  | 30,000 |  |
|  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  | (14,536 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  | (13,740 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  | 1,472,578 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  | $ | 1,472,578 |  |  |  |  |  |  | $ | 1,462,425 |  |

- removed (2020-05-07):
[0001564590-19-041722:note_history:45]
Term Loan Facility

- removed (2020-05-07):
[0001564590-19-041722:note_history:46]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $805,879 as of September 30, 2019 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR plus an applicable interest margin of 2.5%, or an alternate base rate (as defined in the Term Loan Credit Agreement) plus an applicable margin of 1.5%. As of September 30, 2019, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.52%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

- removed (2020-05-07):
[0001564590-19-041722:note_history:47]
Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. For 2019, the Company is not required to make an additional principal payment as its First Lien Leverage Ratio was less than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

- removed (2020-05-07):
[0001564590-19-041722:note_history:48]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

- removed (2020-05-07):
[0001564590-19-041722:note_history:49]
Senior Notes

- removed (2020-05-07):
[0001564590-19-041722:note_history:50]
The $375,000 of Senior Notes, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

- removed (2020-05-07):
[0001564590-19-041722:note_history:51]
Convertible Senior Notes due 2020

- removed (2020-05-07):
[0001564590-19-041722:note_history:52]
The Company maintains 1.75% Convertible Senior Notes in the amount of $249,975 due December 15, 2020. The Convertible Senior Notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes are senior unsecured obligations and would rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the Convertible Senior Notes.

- removed (2020-05-07):
[0001564590-19-041722:note_history:53]
As of September 30, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:

- removed (2020-05-07):
[0001564590-19-041722:note_history:54]
|  |  | As of September 30, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

- removed (2020-05-07):
[0001564590-19-041722:note_history:55]
The components of interest expense resulting from the Convertible Senior Notes for the quarter and three quarters ended September 30, 2019 and October 1, 2018 were as follows:

- removed (2020-05-07):
[0001564590-19-041722:note_history:56]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, |  |  | October 1, |  |  | September 30, |  |  | October 1, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,457 |  |  | $ | 2,303 |  |  | $ | 7,254 |  |  | $ | 6,800 |  |
| Amortization of debt issuance costs |  | $ | 246 |  |  | $ | 231 |  |  | $ | 727 |  |  | $ | 682 |  |

- removed (2020-05-07):
[0001564590-19-041722:note_history:57]
Asset-Based Lending Agreements

- removed (2020-05-07):
[0001564590-19-041722:note_history:58]
During June 2019, the Company amended its U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and its Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans). The U.S. ABL credit facility was amended to extend its maturity to June 2024, decrease the size of the facility to $150,000 and add a $100,000 incremental facility. The Asia ABL credit facility was amended to extend the maturity to June 2024 and add a $50,000 incremental facility.

- removed (2020-05-07):
[0001564590-19-041722:note_history:59]
The U.S. ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $50,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 125 basis points or an alternate base rate (defined as the greater of the prime rate, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%) subject to a 1.0% floor, plus an applicable margin of 25 basis points, at the Company’s option. As of September 30, 2019, the interest rate on the outstanding borrowings under the U.S. ABL was 3.27%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for LIBOR-based loans and from 25 to 50 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on June 3, 2024. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of September 30, 2019, $40,000 under the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

- removed (2020-05-07):
[0001564590-19-041722:note_history:60]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of September 30, 2019, the interest rate on the outstanding borrowings under the Asia ABL was 3.42%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on June 4, 2024. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of September 30, 2019, $30,000 under the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

- removed (2020-05-07):
[0001564590-19-041722:note_history:61]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of September 30, 2019, letters of credit in the amount of $13,640 were outstanding under the U.S. ABL and $24,522 were outstanding under the Asia ABL with various expiration dates through May 2020. Available borrowing capacity under the U.S. ABL and the Asia ABL was $96,360 and $95,478, respectively, which considers letters of credit outstanding as of September 30, 2019.

- removed (2020-05-07):
[0001564590-19-041722:note_history:62]
The Company is required to pay a commitment fee of 0.25% per annum on any unused portion of the U.S. ABL and 0.28% per annum on any unused portion of the Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $144 and $251 for the quarters ended September 30, 2019 and October 1, 2018, respectively, and $594 and $739 for the three quarters ended September 30, 2019 and October 1, 2018, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

- removed (2020-05-07):
[0001564590-19-041722:note_history:63]
Other Credit Facility

- removed (2020-05-07):
[0001564590-19-041722:note_history:64]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $28,078 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver. In July 2019, the expiration of the Chinese Revolver was extended to July 2020. As of September 30, 2019, the Chinese Revolver had not been drawn upon.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-07):
[0001564590-20-022818:note_history:65]
The following table summarizes the long-term debt of the Company as of March 30, 2020 and December 30, 2019:
  (was, 2019-11-07, similarity 0.95):
[0001564590-19-041722:note_history:65]
The following table summarizes the long-term debt of the Company as of September 30, 2019 and December 31, 2018:

- added (2020-05-07):
[0001564590-20-022818:note_history:66]
|  |  | Interest Rate as of March 30, 2020 |  |  | Principal Outstanding as of March 30, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 3.48 |  | % | $ | 805,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 2.23 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 2.38 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (9,305 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (12,202 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,479,347 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (249,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,229,372 |  |  |  |  |  |  | $ | 1,225,962 |  |

- removed (2020-05-07):
[0001564590-19-041722:note_history:67]
|  | Interest Rate as of September 30, 2019 |  |  | Principal Outstanding as of September 30, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  | (In thousands, except interest rates) |  |
| Term Loan due September 2024 |  | 4.52 |  | % | $ | 805,879 |  |  |  | 5.00 |  | % | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due June 2024 |  | 3.27 |  |  |  | 40,000 |  |  |  | 4.00 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  | 3.42 |  |  |  | 30,000 |  |  |  | 3.90 |  |  |  | 30,000 |  |
|  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  | (14,536 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  | (13,740 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  | 1,472,578 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  | $ | 1,472,578 |  |  |  |  |  |  | $ | 1,462,425 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-05-07):
[0001564590-20-022818:note_history:68]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $6,272 and $8,312 for the quarters ended March 30, 2020 and April 1, 2019, respectively.
  (was, 2019-11-07, similarity 0.8482):
[0001564590-19-041722:note_history:68]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $8,005 and $10,437 for the quarters ended September 30, 2019 and October 1, 2018, respectively, and $25,234 and $35,695 for the three quarters ended September 30, 2019 and October 1, 2018, respectively.

- changed (2020-05-07):
[0001564590-20-022818:note_history:69]
As of March 30, 2020 and December 30, 2019, the Company’s consolidated condensed balance sheets included $6,895 and $9,220, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.
  (was, 2019-11-07, similarity 0.9776):
[0001564590-19-041722:note_history:69]
As of September 30, 2019 and December 31, 2018, the Company’s consolidated condensed balance sheets included $10,290 and $10,630, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-07):
[0001564590-20-022818:note_history:70]
|  |  | Quarter Ended March 30, 2020 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 184,451 |  |  | $ | — |  |  | $ | 184,451 |  |  |
| Automotive |  |  | 61,421 |  |  |  | 7,463 |  |  |  | 68,884 |  |  |
| Cellular Phone |  |  | 2,788 |  |  |  | — |  |  |  | 2,788 |  |  |
| Computing/Storage/Peripherals |  |  | 58,282 |  |  |  | 104 |  |  |  | 58,386 |  |  |
| Medical/Industrial/Instrumentation |  |  | 88,224 |  |  |  | 3,758 |  |  |  | 91,982 |  |  |
| Networking/Communications |  |  | 60,898 |  |  |  | 18,977 |  |  |  | 79,875 |  |  |
| Other |  |  | 11,366 |  |  |  | (86 | ) |  |  | 11,280 |  |  |
| Total |  | $ | 467,430 |  |  | $ | 30,216 |  |  | $ | 497,646 |  |  |
  (was, 2019-11-07, similarity 0.6904):
[0001564590-19-041722:note_history:70]
|  |  | Quarter Ended September 30, 2019 |  |  | Quarter Ended October 1, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 171,903 |  |  | $ | 1 |  |  | $ | 171,904 |  |  | $ | 160,067 |  |  | $ | 122 |  |  | $ | 160,189 |  |
| Automotive |  |  | 78,393 |  |  |  | 39,559 |  |  |  | 117,952 |  |  |  | 96,329 |  |  |  | 19,628 |  |  |  | 115,957 |  |
| Cellular Phone |  |  | 136,184 |  |  |  | — |  |  |  | 136,184 |  |  |  | 125,442 |  |  |  | — |  |  |  | 125,442 |  |
| Computing/Storage/Peripherals |  |  | 84,429 |  |  |  | 72 |  |  |  | 84,501 |  |  |  | 107,796 |  |  |  | 253 |  |  |  | 108,049 |  |
| Medical/Industrial/Instrumentation |  |  | 89,395 |  |  |  | 5,775 |  |  |  | 95,170 |  |  |  | 93,248 |  |  |  | 10,457 |  |  |  | 103,705 |  |
| Networking/Communications |  |  | 72,045 |  |  |  | 22,746 |  |  |  | 94,791 |  |  |  | 97,926 |  |  |  | 28,986 |  |  |  | 126,912 |  |
| Other |  |  | 16,755 |  |  |  | (440 | ) |  |  | 16,315 |  |  |  | 15,548 |  |  |  | 35 |  |  |  | 15,583 |  |
| Total |  | $ | 649,104 |  |  | $ | 67,713 |  |  | $ | 716,817 |  |  | $ | 696,356 |  |  | $ | 59,481 |  |  | $ | 755,837 |  |

- changed (2020-05-07):
[0001564590-20-022818:note_history:71]
|  |  | Quarter Ended April 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 164,797 |  |  | $ | 4 |  |  | $ | 164,801 |  |  |
| Automotive |  |  | 81,593 |  |  |  | 19,765 |  |  |  | 101,358 |  |  |
| Cellular Phone |  |  | 1,904 |  |  |  | — |  |  |  | 1,904 |  |  |
| Computing/Storage/Peripherals |  |  | 57,846 |  |  |  | 189 |  |  |  | 58,035 |  |  |
| Medical/Industrial/Instrumentation |  |  | 82,182 |  |  |  | 8,167 |  |  |  | 90,349 |  |  |
| Networking/Communications |  |  | 84,023 |  |  |  | 23,339 |  |  |  | 107,362 |  |  |
| Other |  |  | 12,722 |  |  |  | (86 | ) |  |  | 12,636 |  |  |
| Total |  | $ | 485,067 |  |  | $ | 51,378 |  |  | $ | 536,445 |  |  |
  (was, 2019-11-07, similarity 0.6947):
[0001564590-19-041722:note_history:71]
|  |  | Three Quarters Ended September 30, 2019 |  |  | Three Quarters Ended October 1, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 512,272 |  |  | $ | 367 |  |  | $ | 512,639 |  |  | $ | 445,694 |  |  | $ | 666 |  |  | $ | 446,360 |  |
| Automotive |  |  | 243,254 |  |  |  | 83,317 |  |  |  | 326,571 |  |  |  | 323,228 |  |  |  | 64,792 |  |  |  | 388,020 |  |
| Cellular Phone |  |  | 219,362 |  |  |  | — |  |  |  | 219,362 |  |  |  | 285,695 |  |  |  | — |  |  |  | 285,695 |  |
| Computing/Storage/Peripherals |  |  | 260,448 |  |  |  | 261 |  |  |  | 260,709 |  |  |  | 305,971 |  |  |  | 1,126 |  |  |  | 307,097 |  |
| Medical/Industrial/Instrumentation |  |  | 264,536 |  |  |  | 23,583 |  |  |  | 288,119 |  |  |  | 283,586 |  |  |  | 27,836 |  |  |  | 311,422 |  |
| Networking/Communications |  |  | 240,045 |  |  |  | 72,011 |  |  |  | 312,056 |  |  |  | 279,216 |  |  |  | 73,061 |  |  |  | 352,277 |  |
| Other |  |  | 51,130 |  |  |  | (531 | ) |  |  | 50,599 |  |  |  | 44,442 |  |  |  | 993 |  |  |  | 45,435 |  |
| Total |  | $ | 1,791,047 |  |  | $ | 179,008 |  |  | $ | 1,970,055 |  |  | $ | 1,967,832 |  |  | $ | 168,474 |  |  | $ | 2,136,306 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-07):
[0001564590-20-022818:note_history:72]
As of March 30, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $23,014. The Company expects to recognize revenue on approximately 44% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.
  (was, 2019-11-07, similarity 0.9323):
[0001564590-19-041722:note_history:72]
As of September 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $9,024. The Company expects to recognize revenue on approximately 100% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.

- changed (2020-05-07):
[0001564590-20-022818:note_history:73]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter ended March 30, 2020, and 97% and 3%, respectively, of the Company’s revenue for the quarter ended April 1, 2019.
  (was, 2019-11-07, similarity 0.8988):
[0001564590-19-041722:note_history:73]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter ended September 30, 2019, and 97% and 3%, respectively, of the Company’s revenue for the three quarters ended September 30, 2019.

- changed (2020-05-07):
[0001564590-20-022818:note_history:74]
|  |  | Quarter Ended March 30, 2020 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 184,451 |  |  | $ | — |  |  | $ | 184,451 |  |  |
| Automotive |  |  | 61,421 |  |  |  | 7,463 |  |  |  | 68,884 |  |  |
| Cellular Phone |  |  | 2,788 |  |  |  | — |  |  |  | 2,788 |  |  |
| Computing/Storage/Peripherals |  |  | 58,282 |  |  |  | 104 |  |  |  | 58,386 |  |  |
| Medical/Industrial/Instrumentation |  |  | 88,224 |  |  |  | 3,758 |  |  |  | 91,982 |  |  |
| Networking/Communications |  |  | 60,898 |  |  |  | 18,977 |  |  |  | 79,875 |  |  |
| Other |  |  | 11,366 |  |  |  | (86 | ) |  |  | 11,280 |  |  |
| Total |  | $ | 467,430 |  |  | $ | 30,216 |  |  | $ | 497,646 |  |  |
  (was, 2019-11-07, similarity 0.6904):
[0001564590-19-041722:note_history:74]
|  |  | Quarter Ended September 30, 2019 |  |  | Quarter Ended October 1, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 171,903 |  |  | $ | 1 |  |  | $ | 171,904 |  |  | $ | 160,067 |  |  | $ | 122 |  |  | $ | 160,189 |  |
| Automotive |  |  | 78,393 |  |  |  | 39,559 |  |  |  | 117,952 |  |  |  | 96,329 |  |  |  | 19,628 |  |  |  | 115,957 |  |
| Cellular Phone |  |  | 136,184 |  |  |  | — |  |  |  | 136,184 |  |  |  | 125,442 |  |  |  | — |  |  |  | 125,442 |  |
| Computing/Storage/Peripherals |  |  | 84,429 |  |  |  | 72 |  |  |  | 84,501 |  |  |  | 107,796 |  |  |  | 253 |  |  |  | 108,049 |  |
| Medical/Industrial/Instrumentation |  |  | 89,395 |  |  |  | 5,775 |  |  |  | 95,170 |  |  |  | 93,248 |  |  |  | 10,457 |  |  |  | 103,705 |  |
| Networking/Communications |  |  | 72,045 |  |  |  | 22,746 |  |  |  | 94,791 |  |  |  | 97,926 |  |  |  | 28,986 |  |  |  | 126,912 |  |
| Other |  |  | 16,755 |  |  |  | (440 | ) |  |  | 16,315 |  |  |  | 15,548 |  |  |  | 35 |  |  |  | 15,583 |  |
| Total |  | $ | 649,104 |  |  | $ | 67,713 |  |  | $ | 716,817 |  |  | $ | 696,356 |  |  | $ | 59,481 |  |  | $ | 755,837 |  |

- changed (2020-05-07):
[0001564590-20-022818:note_history:75]
|  |  | Quarter Ended April 1, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 164,797 |  |  | $ | 4 |  |  | $ | 164,801 |  |  |
| Automotive |  |  | 81,593 |  |  |  | 19,765 |  |  |  | 101,358 |  |  |
| Cellular Phone |  |  | 1,904 |  |  |  | — |  |  |  | 1,904 |  |  |
| Computing/Storage/Peripherals |  |  | 57,846 |  |  |  | 189 |  |  |  | 58,035 |  |  |
| Medical/Industrial/Instrumentation |  |  | 82,182 |  |  |  | 8,167 |  |  |  | 90,349 |  |  |
| Networking/Communications |  |  | 84,023 |  |  |  | 23,339 |  |  |  | 107,362 |  |  |
| Other |  |  | 12,722 |  |  |  | (86 | ) |  |  | 12,636 |  |  |
| Total |  | $ | 485,067 |  |  | $ | 51,378 |  |  | $ | 536,445 |  |  |
  (was, 2019-11-07, similarity 0.6947):
[0001564590-19-041722:note_history:75]
|  |  | Three Quarters Ended September 30, 2019 |  |  | Three Quarters Ended October 1, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 512,272 |  |  | $ | 367 |  |  | $ | 512,639 |  |  | $ | 445,694 |  |  | $ | 666 |  |  | $ | 446,360 |  |
| Automotive |  |  | 243,254 |  |  |  | 83,317 |  |  |  | 326,571 |  |  |  | 323,228 |  |  |  | 64,792 |  |  |  | 388,020 |  |
| Cellular Phone |  |  | 219,362 |  |  |  | — |  |  |  | 219,362 |  |  |  | 285,695 |  |  |  | — |  |  |  | 285,695 |  |
| Computing/Storage/Peripherals |  |  | 260,448 |  |  |  | 261 |  |  |  | 260,709 |  |  |  | 305,971 |  |  |  | 1,126 |  |  |  | 307,097 |  |
| Medical/Industrial/Instrumentation |  |  | 264,536 |  |  |  | 23,583 |  |  |  | 288,119 |  |  |  | 283,586 |  |  |  | 27,836 |  |  |  | 311,422 |  |
| Networking/Communications |  |  | 240,045 |  |  |  | 72,011 |  |  |  | 312,056 |  |  |  | 279,216 |  |  |  | 73,061 |  |  |  | 352,277 |  |
| Other |  |  | 51,130 |  |  |  | (531 | ) |  |  | 50,599 |  |  |  | 44,442 |  |  |  | 993 |  |  |  | 45,435 |  |
| Total |  | $ | 1,791,047 |  |  | $ | 179,008 |  |  | $ | 1,970,055 |  |  | $ | 1,967,832 |  |  | $ | 168,474 |  |  | $ | 2,136,306 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-05-07):
[0001564590-20-022818:note_history:76]
(19) Subsequent Events

- added (2020-05-07):
[0001564590-20-022818:note_history:77]
On April 17, 2020, the Company completed the sale of its Mobility business unit for a base purchase price of $550,000 in cash, subject to customary purchase price adjustments. The base purchase price does not include certain accounts receivable of the divested business, which is estimated to total approximately $95,000.

- added (2020-05-07):
[0001564590-20-022818:note_history:78]
On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit, which consists of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company will discontinue operations at the SH E-MS and SZ facilities while integrating the SH BPA facility into its PCB operations. No goodwill is allocated to the E-M Solutions reportable segment. The cash outlay for severance and other shutdown costs is estimated to be approximately $17,000 and is expected to be incurred over the next 12 to 15 months. The Company also expects to incur approximately $8,000 related to non-cash asset impairments. At this time, these amounts are estimates and subject to change as the Company carries out the restructuring. This subsequent event has not been recognized in these consolidated condensed financial statements and will be recognized in the Company’s consolidated financial statements in the upcoming quarters.
