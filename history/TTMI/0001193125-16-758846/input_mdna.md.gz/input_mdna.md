# TTMI MD&A — 0001193125-16-758846


## mdna

[0001193125-16-758846:mdna:1]
[same as prior period, unchanged from 0001193125-16-671832:mdna:1]

[0001193125-16-758846:mdna:2]
|  | • |  | our ability to minimize design or manufacturing defects in our products; |

[0001193125-16-758846:mdna:3]
|  | • |  | changes in our industry, interest rates, or the general economy; |

[0001193125-16-758846:mdna:4]
|  | • |  | the effects of economic cycles and fluctuations in the worldwide demand for electronic products; |

[0001193125-16-758846:mdna:5]
|  | • |  | our ability to adapt to changing laws and regulations in China; |

[0001193125-16-758846:mdna:6]
|  | • |  | our ability to manage the risks associated with manufacturing facilities inside and outside of the United States; |

[0001193125-16-758846:mdna:7]
|  | • |  | our ability to respond to technological change and process development; |

[0001193125-16-758846:mdna:8]
|  | • |  | our ability to compete successfully against other manufacturers; |

[0001193125-16-758846:mdna:9]
|  | • |  | our reliance on a relatively small number of OEMs for a large portion of our net sales; |

[0001193125-16-758846:mdna:10]
|  | • |  | our reliance on raw materials suppliers to satisfy our product quality standards; |

[0001193125-16-758846:mdna:11]
|  | • |  | our ability to comply with environmental laws; |

[0001193125-16-758846:mdna:12]
|  | • |  | our reliance on the U.S. government for a substantial portion of our business; |

[0001193125-16-758846:mdna:13]
|  | • |  | our ability to retain our employees who have important industry experience, including our key senior executives; |

[0001193125-16-758846:mdna:14]
|  | • |  | our future sources of, and needs for, liquidity and capital resources; |

[0001193125-16-758846:mdna:15]
|  | • |  | our ability to repay our debt obligations as they come due; |

[0001193125-16-758846:mdna:16]
|  | • |  | our ability to successfully integrate acquisitions; |

[0001193125-16-758846:mdna:17]
|  | • |  | our exposure to intellectual property infringement claims and litigation; |

[0001193125-16-758846:mdna:18]
|  | • |  | the effect of climate change initiatives on our business and operations; and |

[0001193125-16-758846:mdna:19]
|  | • |  | our reliance on OEMs to outsource their PCB manufacturing and backplane assemble needs for us. |

[0001193125-16-758846:mdna:20]
This discussion and analysis should be read in conjunction with “Management’s Discussion and Analysis of
Financial Condition and Results of Operations” set forth in our Annual Report on Form 10-K for the fiscal year ended December 28, 2015, filed with the SEC.

[0001193125-16-758846:mdna:21]
[same as prior period, unchanged from 0001193125-16-671832:mdna:3]

[0001193125-16-758846:mdna:22]
We are a leading global printed circuit
board (PCB) manufacturer, focusing on quick-turn and technologically advanced PCBs and electro-mechanical solutions (E-M Solutions). We focus on providing time-to-market and advanced technology products and offer a one-stop manufacturing solution to
our customers from engineering support to prototype development through final volume production. This one-stop manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the
time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,500 customers in various markets throughout the world, including manufacturers of networking/communications
infrastructure products, smartphones, tablets and ultra notebooks, as well as the aerospace and defense, automotive components, high-end computing, and medical, industrial and instrumentation related products. Our customers include both original
equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001193125-16-758846:mdna:23]
On May 31, 2015,
we completed the acquisition of Viasystems Group, Inc. (Viasystems), for total consideration of $248.8 million in cash and 15.1 million shares of TTM common stock with a fair value of $149.0 million, and thereby acquired all of the outstanding
shares of capital stock and other equity rights of Viasystems. Additionally, in connection with the completion of the acquisition, we assumed and refinanced Viasystems’ debt, which was approximately $669.0 million as of May 31, 2015.
Viasystems was a worldwide provider of complex multi-layer rigid, flexible, and rigid-flex PCBs and custom electronic assemblies.

[0001193125-16-758846:mdna:24]
The acquisition of Viasystems has had and will continue to have a significant effect on our operations and financial results. We have greatly increased and diversified our revenue base and added the fast
growing automotive end market to our portfolio of markets we serve. Our financial results for the third quarter and three quarters ended 2016 demonstrate the benefits of this diversification along with our strong operational execution and focus
on realizing synergies from the integration. These results are reflected in improved gross and operating margins the third quarter and three quarters ended 2016 as compared to the same periods in 2015.

[0001193125-16-758846:mdna:25]
On May 31, 2015, in conjunction with the acquisition of Viasystems, we entered into a $950.0 million Term Loan
Credit Agreement (Term Loan). During the three quarters ended September 26, 2016, the Company made debt principal payments totaling $106.5 million, representing normally scheduled principal payments as well as additional prepayments of principal.

[0001193125-16-758846:mdna:26]
Subsequent to September 26, 2016, we issued a new $775.0 million Term Loan (New Term Loan) at an interest
rate of LIBOR plus 4.25%, a reduction of 75 basis points from our previous Term Loan, and repaid in full the $841.1 million of our previous Term Loan outstanding, which resulted in an overall net reduction of $66.1 million in the Term Loan
outstanding. Principal payments under the New Term Loan are due quarterly beginning in April 2020 with the balance due on May 31, 2021, the same maturity as the previous Term Loan. In addition, we amended our U.S. ABL credit facility to
increase the amount available under the U.S. ABL to $200.0 million, reduce the applicable margin by 0.25% for both Eurodollar loans and ABR loans, and reduce the Letters of Credit Facilities to $50.0 million.

[0001193125-16-758846:mdna:27]
While our customers include both OEM and EMS providers, we measure customers based on OEM companies, as they are the
ultimate end customers. Sales to our 10 largest customers accounted for 46% and 45% of our net sales for the quarters ended September 26, 2016 and September 28, 2015, respectively, and 42% and 51% for the three quarters ended September 26, 2016 and
September 28, 2015, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001193125-16-758846:mdna:28]
22

[0001193125-16-758846:mdna:29]
The following table shows the percentage of our net sales attributable to
each of the principal end markets we served for the periods indicated:

[0001193125-16-758846:mdna:30]
|  |  | Quarter Ended |  |  | Three quarters Ended |  |
| End Markets(1)(2)(4) |  | September 26,2016 |  |  | September 28,2015 |  |  | September 26,2016 |  |  | September 28,2015 |  |
| Aerospace/Defense |  |  | 15 | % |  |  | 14 | % |  |  | 15 | % |  |  | 15 | % |
| Automotive(2) |  |  | 19 |  |  |  | 17 |  |  |  | 20 |  |  |  | 12 |  |
| Cellular Phone(3) |  |  | 17 |  |  |  | 16 |  |  |  | 12 |  |  |  | 22 |  |
| Computing/Storage/Peripherals(3) |  |  | 12 |  |  |  | 12 |  |  |  | 13 |  |  |  | 11 |  |
| Medical/Industrial/Instrumentation |  |  | 14 |  |  |  | 14 |  |  |  | 15 |  |  |  | 12 |  |
| Networking/Communications |  |  | 21 |  |  |  | 25 |  |  |  | 23 |  |  |  | 26 |  |
| Other(2)(3) |  |  | 2 |  |  |  | 2 |  |  |  | 2 |  |  |  | 2 |  |
| Total |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001193125-16-758846:mdna:31]
[same as prior period, unchanged from 0001193125-16-671832:mdna:11]

[0001193125-16-758846:mdna:32]
[same as prior period, unchanged from 0001193125-16-671832:mdna:12]

[0001193125-16-758846:mdna:33]
[same as prior period, unchanged from 0001193125-16-671832:mdna:13]

[0001193125-16-758846:mdna:34]
[same as prior period, unchanged from 0001193125-16-671832:mdna:14]

[0001193125-16-758846:mdna:35]
[same as prior period, unchanged from 0001193125-16-671832:mdna:15]

[0001193125-16-758846:mdna:36]
[same as prior period, unchanged from 0001193125-16-671832:mdna:16]

[0001193125-16-758846:mdna:37]
[same as prior period, unchanged from 0001193125-16-671832:mdna:17]

[0001193125-16-758846:mdna:38]
[same as prior period, unchanged from 0001193125-16-671832:mdna:18]

[0001193125-16-758846:mdna:39]
[same as prior period, unchanged from 0001193125-16-671832:mdna:19]

[0001193125-16-758846:mdna:40]
[same as prior period, unchanged from 0001193125-16-671832:mdna:20]

[0001193125-16-758846:mdna:41]
[same as prior period, unchanged from 0001193125-16-671832:mdna:21]

[0001193125-16-758846:mdna:42]
23

[0001193125-16-758846:mdna:43]
[same as prior period, unchanged from 0001193125-16-671832:mdna:22]

[0001193125-16-758846:mdna:44]
[same as prior period, unchanged from 0001193125-16-671832:mdna:23]

[0001193125-16-758846:mdna:45]
[same as prior period, unchanged from 0001193125-16-671832:mdna:24]

[0001193125-16-758846:mdna:46]
|  |  | Quarter Ended |  |  | Three quarters Ended |  |
|  |  | September 26, 2016 |  |  | September 28, 2015 |  |  | September 26, 2016 |  |  | September 28, 2015 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 82.9 |  |  |  | 86.3 |  |  |  | 84.1 |  |  |  | 85.8 |  |
| Gross profit |  |  | 17.1 |  |  |  | 13.7 |  |  |  | 15.9 |  |  |  | 14.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.4 |  |  |  | 2.7 |  |  |  | 2.7 |  |  |  | 2.8 |  |
| General and administrative |  |  | 5.6 |  |  |  | 6.1 |  |  |  | 5.9 |  |  |  | 8.8 |  |
| Amortization of definite-lived intangibles |  |  | 0.9 |  |  |  | 1.0 |  |  |  | 1.0 |  |  |  | 0.9 |  |
| Impairment of long-lived assets |  |  | — |  |  |  | — |  |  |  | 0.2 |  |  |  | — |  |
| Restructuring charges |  |  | 0.4 |  |  |  | 0.3 |  |  |  | 0.4 |  |  |  | 0.1 |  |
| Gain on sale of asset |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Total operating expenses |  |  | 9.3 |  |  |  | 10.1 |  |  |  | 10.2 |  |  |  | 12.5 |  |
| Operating income |  |  | 7.8 |  |  |  | 3.6 |  |  |  | 5.7 |  |  |  | 1.7 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.9 | ) |  |  | (3.2 | ) |  |  | (3.3 | ) |  |  | (2.8 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Other, net |  |  | 0.6 |  |  |  | 0.6 |  |  |  | 0.4 |  |  |  | 0.4 |  |
| Total other expense, net |  |  | (2.3 | ) |  |  | (2.6 | ) |  |  | (2.9 | ) |  |  | (2.5 | ) |
| Income (loss) before income taxes |  |  | 5.5 |  |  |  | 1.0 |  |  |  | 2.8 |  |  |  | (0.8 | ) |
| Income tax provision |  |  | (1.5 | ) |  |  | (1.3 | ) |  |  | (0.8 | ) |  |  | (1.7 | ) |
| Net income (loss) |  |  | 4.0 |  |  |  | (0.3 | ) |  |  | 2.0 |  |  |  | (2.5 | ) |
| Less: Net income attributable to noncontrolling interest |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  |  | 4.0 | % |  |  | (0.3 | )% |  |  | 2.0 | % |  |  | (2.5 | )% |

[0001193125-16-758846:mdna:47]
We have reviewed our reportable operating segments and determined that we continue to
have two reportable operating segments: PCB and E-M Solutions. This determination was made based on the criteria of earning revenues and incurring expenses, our organizational structure which has segment managers who report to the chief operating
decision maker, discrete financial information, and the aggregation of similar operating segments into reportable operating segments.

[0001193125-16-758846:mdna:48]
The following table compares net sales by reportable segment for the quarters and three quarters ended September 26, 2016 and September 28, 2015:

[0001193125-16-758846:mdna:49]
|  |  | Quarter Ended |  |  | Three quarters Ended |  |
|  |  | September 26, 2016 |  |  | September 28, 2015 |  |  | September 26, 2016 |  |  | September 28, 2015 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 598,656 |  |  | $ | 604,771 |  |  | $ | 1,692,175 |  |  | $ | 1,332,996 |  |
| E-M Solutions |  |  | 46,246 |  |  |  | 49,658 |  |  |  | 143,151 |  |  |  | 97,634 |  |
| Total sales |  |  | 644,902 |  |  |  | 654,429 |  |  |  | 1,835,326 |  |  |  | 1,430,630 |  |
| Inter-segment sales |  |  | (3,182 | ) |  |  | (2,424 | ) |  |  | (8,501 | ) |  |  | (4,016 | ) |
| Total net sales |  | $ | 641,720 |  |  | $ | 652,005 |  |  | $ | 1,826,825 |  |  | $ | 1,426,614 |  |

[0001193125-16-758846:mdna:50]
[same as prior period, unchanged from 0001193125-16-671832:mdna:30]

[0001193125-16-758846:mdna:51]
Total net sales decreased $10.3 million, or 1.6%, from $652.0 million for the third quarter of 2015 to $641.7 million for the third quarter of 2016. Net sales for the PCB operating segment, excluding
inter-segment sales, decreased $6.9 million, or 1.1%, from $602.4 million for the third quarter of 2015 to $595.5 million for the third quarter of 2016. This decrease is primarily due to lower demand in our Computing/Storage/Peripherals and
Networking/Communications end markets, partially offset by higher demand in

[0001193125-16-758846:mdna:52]
Aerospace/Defense and Cellular Phone end markets. This resulted in an average PCB selling price decrease of 4.6% which was driven by a product mix shift, partially offset by a 4.8% increase in
PCB shipments as compared to the third quarter of 2015. Net sales for the E-M Solutions operating segment decreased $3.4 million, or 6.9%, from $49.6 million for the third quarter of 2015 to $46.2 million for the third quarter of 2016 due to lower
demand in our Networking/Communications end market, partially offset by higher demand in our Automotive end market.

[0001193125-16-758846:mdna:53]
Total net sales increased $400.2 million, or 28.1%, from $1,426.6 million for the first three quarters of 2015 to $1,826.8 million for the first three quarters of 2016. Net sales for the PCB
operating segment, excluding inter-segment sales, increased $354.4 million, or 26.7%, from $1,329.3 million for the first three quarters of 2015 to $1,683.7 million for the first three quarters of 2016. This increase is primarily due to the
additional sales resulting from the acquisition of Viasystems, which accounted for $410.7 million of the net increase in PCB sales for the first three quarters of 2016, partially offset by lower demand in our Cellular Phone and
Networking/Communications end markets. These changes, including the sales from Viasystems, resulted in a 57.2% increase in PCB shipments as compared to the first three quarters of 2015, partially offset by an average PCB selling price decrease of
18.5%, which was driven by a product mix shift resulting from the acquisition. Net sales for the E-M Solutions operating segment increased $45.8 million from $97.4 million for the first three quarters of 2015 to $143.2 million for the first three
quarters of 2016. This increase is due to the additional sales resulting from the acquisition of Viasystems.

[0001193125-16-758846:mdna:54]
[same as prior period, unchanged from 0001193125-16-671832:mdna:33]

[0001193125-16-758846:mdna:55]
Overall gross margin increased from 13.7% for the third quarter of 2015 to 17.1% for the third quarter
of 2016, and from 14.2% for the first three quarters of 2015 to 15.9% for the first three quarters of 2016.

[0001193125-16-758846:mdna:56]
Gross margin for the PCB operating segment increased from 14.3% for the third quarter of 2015 to 17.7% for the third
quarter of 2016, and from 14.8% for the first three quarters of 2015 to 16.9% for the first three quarters of 2016, primarily due to the improved operating performance at certain acquired manufacturing facilities and the benefits resulting from our
synergy initiatives, partially offset by reduced volumes at our facilities supporting the Networking/Communications end market.

[0001193125-16-758846:mdna:57]
Gross margin for the E-M Solutions operating segment increased from 5.8% for the third quarter of 2015 to 11.0% for the third quarter of 2016, and from 5.7% for the first three quarters of 2015 to 8.6%
for the first three quarters of 2016, primarily due to savings from the closure of our Juarez, Mexico facility and increased production volumes at certain acquired facilities.

[0001193125-16-758846:mdna:58]
[same as prior period, unchanged from 0001193125-16-671832:mdna:37]

[0001193125-16-758846:mdna:59]
Selling and
marketing expenses decreased $2.0 million, from $17.6 million for the third quarter of 2015 to $15.6 million for the third quarter of 2016. As a percentage of net sales, selling and marketing expenses were 2.7% for the third quarter of 2015, as
compared to 2.4% for the third quarter of 2016. The decrease in the third quarter expense and as a percentage of net sales is primarily related to workforce reductions associated with global realignment efforts.

[0001193125-16-758846:mdna:60]
Selling and marketing expenses increased $10.1 million, from $39.4 million for the first three quarters of 2015 to $49.5
million for the first three quarters of 2016. As a percentage of net sales, selling and marketing expenses were 2.8% for the first three quarters of 2015, as compared to 2.7% for the first three quarters of 2016. The increase in the expense for
the first three quarters primarily relates to increased selling and marketing expense incurred with the acquisition of Viasystems, partially offset by workforce reductions associated with global realignment efforts. The decrease as a percentage of
net sales was primarily due to higher net sales and saving from workforce reductions mentioned above.

[0001193125-16-758846:mdna:61]
General and Administrative
Expenses

[0001193125-16-758846:mdna:62]
General and administrative expenses decreased $3.9 million from $39.5 million, or 6.1% of net
sales, for the third quarter of 2015 to $35.6 million, or 5.6% of net sales, for the third quarter of 2016. General and administrative expenses decreased $17.8 million from $126.0 million, or 8.8% of net sales, for the first three quarters of
2015 to $108.2 million, or 5.9% of net sales, for the first three quarters of 2016. The decrease in expense primarily related to a decrease of $1.9 million and $31.4 million for the quarter and three quarters ended September 26, 2016, respectively,
in acquisition related costs, partially offset by increased expenses incurred with the acquisition of Viasystems. The decrease in general and administrative expense as percentage of net sales was primarily due to the decrease in acquisition related
costs and higher net sales.

[0001193125-16-758846:mdna:63]
Impairment of Long-Lived Assets and Restructuring Charges

[0001193125-16-758846:mdna:64]
For the third quarter and the first three quarters of 2016, we incurred restructuring charges of $2.1 million and $8.0
million, respectively, which primarily related to the consolidation plan announced September 29, 2015 that resulted in the closure of our facilities in Cleveland, Ohio, Milpitas, California, and Juarez, Mexico (the Consolidation Plan) and other
global realignment efforts. These charges primarily represented severance and contract termination and other costs. Approximately $0.9 million and $3.3 million of these restructuring charges were recognized in our PCB operating segment for the
third quarter and the first three quarters of 2016, respectively, $1.3 million and $4.0 million were recognized in our E-M Solutions operating segment for the third quarter and the first

[0001193125-16-758846:mdna:65]
[same as prior period, unchanged from 0001193125-16-671832:mdna:43]

[0001193125-16-758846:mdna:66]
three quarters of 2016, respectively, and $0.7 million was recognized in our Corporate operating segment for the first three quarters of 2016. As of September 26, 2016, we have incurred
approximately $15.2 million of such charges since the September 29, 2015 announcement and estimate that we will incur total charges of approximately $20.0 million related to these closures and other global realignment efforts.

[0001193125-16-758846:mdna:67]
Additionally, as a result of the above mentioned plant closures and other plant realignment efforts, we also recognized
impairment charges of $3.3 million for the first three quarters of 2016, of which $1.4 million were recognized in our PCB operating segment and $1.9 million were recognized related in the Corporate operating segment. The impairment charge for
the PCB operating segment related to machinery and equipment while the impairment charge for the Corporate operating segment related to the write-off of capitalized software costs.

[0001193125-16-758846:mdna:68]
If forecasts and assumptions used to support the realizability of our long-lived assets change in the future, significant
impairment or restructuring charges could result that would adversely affect our results of operations and financial condition.

[0001193125-16-758846:mdna:69]
Other
Income (Expense)

[0001193125-16-758846:mdna:70]
Other expense, net decreased $2.1 million from $17.0 million for the third quarter of
2015 to $14.9 million for the third quarter of 2016. The decrease in other expense, net for the third quarter was primarily due to a decrease in interest expense related to the Term Loan, totaling $841.1 million as of September 26, 2016 at a
weighted average interest rate of 6.0%, which was entered into on May 31, 2015 in connection with the acquisition of Viasystems, resulting from normally scheduled principal payments as well as additional Term Loan prepayments of principal of $106.5
million.

[0001193125-16-758846:mdna:71]
Other expense, net increased $16.3 million from $36.1 million for the first three quarters of 2015
to $52.4 million for the first three quarters of 2016. The increase was primarily due to an increase in interest expense related to the Term Loan and U.S. ABL, at a weighted average interest rate of 5.7%, which was entered into on May 31, 2015 in
connection with the acquisition of Viasystems. This increase was partially offset by $2.0 million of higher foreign currency transaction gains for the three quarters ended September 26, 2016, respectively, due primarily to the devaluation of the
RMB, which is utilized at certain of our Asia operations.

[0001193125-16-758846:mdna:72]
[same as prior period, unchanged from 0001193125-16-671832:mdna:49]

[0001193125-16-758846:mdna:73]
The provision for income taxes increased by $0.8 million from $8.7 million of tax expense for the third quarter of 2015 to
$9.5 million of tax expense for the third quarter of 2016. The increase in income tax expense was primarily due to an increase of operating income in higher tax rate jurisdictions in the third quarter of 2016 compared to 2015. In addition, purchase
accounting adjustments further decreased the third quarter of 2015 net book income before taxes in taxable foreign jurisdictions. The provision for income taxes decreased $10.0 million from $24.0 million of tax expense for the first three quarters
of 2015 to $14.0 million of tax expense for the first three quarters of 2016. The decrease in income tax expense in 2016 as compared to 2015 was primarily due to discrete tax benefits recorded in the three quarters of 2016 related to the release of
existing uncertain tax positions due to the expiration of the statute of limitations and research and development tax benefits in certain foreign jurisdictions. Further, a discrete tax expense was recorded during the three quarters of 2015 related
to a valuation allowance that was provided against our existing U.S. net deferred tax assets.

[0001193125-16-758846:mdna:74]
Our effective
tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of credits and deductions available to us, changes in the valuation allowance, and certain
non-deductible items. U.S. and certain foreign losses generated are not more likely than not to be realizable, and thus no income tax benefit has been recognized on these losses. As of September 26, 2016, we had net deferred income tax liabilities
of approximately $10.5 million and as of December 28, 2015, we had net deferred income tax liabilities of approximately $13.1 million.

[0001193125-16-758846:mdna:75]
[same as prior period, unchanged from 0001193125-16-671832:mdna:52]

[0001193125-16-758846:mdna:76]
[same as prior period, unchanged from 0001193125-16-671832:mdna:53]

[0001193125-16-758846:mdna:77]
Cash flow provided by operating activities during the first three quarters of 2016 was $200.7
million as compared to $97.6 million in the same period in 2015. The increase in cash flow was primarily due to higher net income. As of September 26, 2016, we had net working capital of approximately $309.1 million compared to $277.5
million as of December 28, 2015. Cash cycle days were 46 days for the third quarter of 2016 as compared to 52 days for the same quarter of 2015.

[0001193125-16-758846:mdna:78]
Net cash used in investing activities was approximately $57.5 million for the first three quarters of 2016 primarily reflecting purchases of property, plant and equipment, net of proceeds from sales of
property, plant and equipment and assets held for sale of $61.0 million, less release of restricted cash to cash and cash equivalents of $3.5 million. For the first three quarters of 2015, net cash used in investing activities was approximately
$226.6 million primarily reflecting the acquisition of Viasystems, net of cash acquired, in the amount of $169.2 million, and purchases of property, plant and equipment, net of proceeds from sale of property, plant and equipment and asset held for
sale of $55.5 million.

[0001193125-16-758846:mdna:79]
[same as prior period, unchanged from 0001193125-16-671832:mdna:56]

[0001193125-16-758846:mdna:80]
Net cash used in financing activities was approximately $106.4 million for
the first three quarters of 2016 primarily reflecting the repayment of normally scheduled principal payments as well as additional prepayments of principal of long-term debt. For the first three quarters of 2015, net cash used in financing
activities was approximately $3.3 million reflecting proceeds from long-term debt and a revolving loan totaling $1,030.0 million, offset by the repayment of $966.5 million of debt, including the assumed long-term debt in the acquisition of $669.0
million, payoff of the 2012 credit agreement term loan, the payoff of the remaining 2015 convertible senior notes, and payment of debt issuance costs and original issue discount of $67.4 million associated with the new long-term borrowing and
revolver loan totaling $1,030.0 million.

[0001193125-16-758846:mdna:81]
As of September 26, 2016, we had cash and cash equivalents of
approximately $291.8 million, of which approximately $174.2 million was held by our foreign subsidiaries, primarily in Asia. Cash and cash equivalents held by our foreign locations are expected to be used in local operations.

[0001193125-16-758846:mdna:82]
Our 2016 capital expenditures are expected to be in the range of $105 million to $115 million. The expenditures will fund
capital equipment purchases to increase production capacity, especially for advanced technology manufacturing, comply with changing environmental regulations, replace aging equipment, and expand our technological capabilities.

[0001193125-16-758846:mdna:83]
[same as prior period, unchanged from 0001193125-16-671832:mdna:60]

[0001193125-16-758846:mdna:84]
[same as prior period, unchanged from 0001193125-16-671832:mdna:61]

[0001193125-16-758846:mdna:85]
The Term Loan Credit agreement was issued at a discount at 96.5% and bears interest at a floating rate of LIBOR, with a
1.0% LIBOR floor, plus an applicable interest margin of 5.0%. At September 26, 2016, the weighted average interest rate on the outstanding borrowings under the Term Loan was 6.0%. There is no provision, other than an event of default, for the
interest margin to increase. The Term Loan will mature on May 31, 2021. The Term Loan is secured by a significant amount of our assets and our domestic subsidiaries and a pledge of 65% of the voting stock of our first tier foreign subsidiaries
and is structurally senior to our convertible senior notes. See Convertible Senior Notes due 2020 below.

[0001193125-16-758846:mdna:86]
The
U.S. ABL consists of three tranches comprised of a revolving credit facility of up to $150.0 million, a letter of credit facility of up to $75.0 million, and swingline loans of up to $30.0 million, provided that at no time may amounts outstanding
under the tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at a
floating rate of LIBOR plus a margin of 175 basis points. At September 26, 2016, the weighted average interest rate on the outstanding borrowings under the U.S. ABL was 2.27%. The applicable margin can vary based on the remaining availability of the
facility, from 150 to 200 basis points for LIBOR-based loans. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and inventories as well as by a second position
against a significant amount of our assets and our domestic subsidiaries and a pledge of 65% of the voting stock of our first tier foreign subsidiaries and are structurally senior to our convertible senior notes. See Convertible Senior Notes due
2020 below. At September 26, 2016, $80.0 million of the U.S. ABL was outstanding and classified as short term debt.

[0001193125-16-758846:mdna:87]
We and our domestic subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Term Loan and U.S. ABL related obligations.

[0001193125-16-758846:mdna:88]
The Asia ABL consists of two tranches comprised of a revolving credit facility of up to $150.0 million and a letter of
credit facility of up to $100.0 million provided that at no time may amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible
Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 175 basis points. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL
will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of cash and receivables of certain of our subsidiaries in Asia and are structurally senior to our domestic obligations, including our convertible senior notes.
See Convertible Senior Notes due 2020 below. Additionally, certain of our subsidiaries in Asia have fully and unconditionally guaranteed the full and timely payment of all Asia ABL related obligations. At September 26, 2016, none of the Asia ABL was
outstanding.

[0001193125-16-758846:mdna:89]
We are required to make scheduled payments of the outstanding Term Loan balance on a quarterly
basis. Based on certain parameters defined in the Term Loan agreement, we may be required to make an additional principal payment on an annual basis. Any additional annual payments or prepayments reduce future required quarterly scheduled payments.
During the three quarters ended September 26, 2016, we made debt principal payments totaling $106.5 million, representing normally scheduled principal payments as well as additional prepayments of principal. From time to time, we may make additional
principal payments in the normal course of

[0001193125-16-758846:mdna:90]
business as cash flow allows. Any other outstanding balances under the Term Loan are due at the maturity date of May 31, 2021. Borrowings under the Term Loan are subject to various
financial and operating covenants including maintaining a maximum total leverage ratio. Under the occurrence of certain events, the U.S. ABL and the Asia ABL are subject to various financial and operational covenants, including maintaining minimum
fixed charge coverage ratios. At September 26, 2016, we were in compliance with the covenants under the Term Loan, the U.S. ABL and the Asia ABL.

[0001193125-16-758846:mdna:91]
We are also required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL based on utilization levels. Additionally, we also paid commitment fees of
0.5% per annum on the unused portion of the $90.0 million senior secured revolving loan associated with the terminated 2012 credit agreement for the three quarters ended September 28, 2015. We incurred total commitment fees related to
unused borrowing availability of $0.2 million and $0.5 million for the quarter and three quarters ended September 26, 2016, respectively. As of September 26, 2016, the outstanding amount of the Term Loan was $841.1 million, of which $66.1 million is
included in short-term debt and the remaining $775.0 million is included as long-term debt. Additionally, $80.0 million of the U.S. ABL and none of the Asia ABL was outstanding as of September 26, 2016. Available borrowing capacity under the U.S.
ABL and Asia ABL was $63.0 million and $142.9 million, respectively, which includes $7.0 million and $7.1 million of outstanding letters of credit mentioned below, respectively, at September 26, 2016.

[0001193125-16-758846:mdna:92]
Subsequent to September 26, 2016, we issued a New Term Loan for $775.0 million at an interest rate of LIBOR plus 4.25%, a
reduction of 75 basis points from our previous Term Loan, and repaid in full the $841.1 million of our previous Term Loan outstanding, which resulted in an overall net reduction of $66.1 million in the Term Loan outstanding. Principal payments
under the New Term Loan are due quarterly beginning in April 2020 with the balance due on May 31, 2021, the same maturity as the previous Term Loan. In addition, we amended our U.S. ABL credit facility to increase the amount available under the
U.S. ABL to $200.0 million, reduce the applicable margin by 0.25% for both Eurodollar loans and ABR loans, and reduce the Letters of Credit Facilities to $50.0 million.

[0001193125-16-758846:mdna:93]
[same as prior period, unchanged from 0001193125-16-671832:mdna:70]

[0001193125-16-758846:mdna:94]
We have up to $75.0 million and $100.0
million Letters of Credit Facilities available under the U.S. ABL and the Asia ABL, respectively. As of September 26, 2016, letters of credit in the amount of $7.0 million were outstanding under the U.S. ABL and $7.1 million were outstanding
under the Asia ABL with various expiration dates through September 2017.

[0001193125-16-758846:mdna:95]
[same as prior period, unchanged from 0001193125-16-671832:mdna:72]

[0001193125-16-758846:mdna:96]
We are party to a revolving loan credit facility with a lender in China. Under this arrangement, the lender has made
available to us approximately $34.5 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this
arrangement expires in December 2016. As of September 26, 2016, the Chinese Revolver had not been drawn upon.

[0001193125-16-758846:mdna:97]
Convertible Senior Notes due
2020

[0001193125-16-758846:mdna:98]
In December 2013, we issued 1.75% convertible senior notes due December 15, 2020, in a public
offering for an aggregate principal amount of $250.0 million. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The
convertible senior notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest
expense over the term of the convertible senior notes.

[0001193125-16-758846:mdna:99]
In connection with the issuance of the convertible
senior notes due 2020, we entered into a convertible note hedge and warrant transaction (the Call Spread Transaction), with respect to our common stock. The convertible note hedge consists of our option to purchase up to 25.9 million common
stock shares at a price of $9.64 per share. The hedge expires on December 15, 2020 and can only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, we sold warrants to purchase
25.9 million shares of our common stock at a price of $14.26 per share. The warrants expire ratably from March 2021 through January 2022. The Call Spread Transaction has no effect on the terms of the convertible senior notes due 2020 and
reduces potential dilution by effectively increasing the conversion price of the convertible senior notes due 2020 to $14.26 per share of our common stock.

[0001193125-16-758846:mdna:100]
[same as prior period, unchanged from 0001193125-16-671832:mdna:77]

[0001193125-16-758846:mdna:101]
[same as prior period, unchanged from 0001193125-16-671832:mdna:78]

[0001193125-16-758846:mdna:102]
The following table provides information on our contractual obligations as of September 26, 2016:

[0001193125-16-758846:mdna:103]
|  |  | Total |  |  | Less Than1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 923,018 |  |  | $ | 146,473 |  |  | $ | 724 |  |  | $ | 775,821 |  |  | $ | — |  |
| Convertible debt obligations |  |  | 250,000 |  |  |  | — |  |  |  | — |  |  |  | 250,000 |  |  |  | — |  |
| Interest on debt obligations |  |  | 252,710 |  |  |  | 65,975 |  |  |  | 102,959 |  |  |  | 83,776 |  |  |  | — |  |
| Equipment payables |  |  | 13,057 |  |  |  | 13,057 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 72,514 |  |  |  | 66,472 |  |  |  | 6,042 |  |  |  | — |  |  |  | — |  |
| Operating lease commitments |  |  | 27,282 |  |  |  | 8,914 |  |  |  | 8,584 |  |  |  | 4,490 |  |  |  | 5,294 |  |
| Total contractual obligations |  | $ | 1,538,581 |  |  | $ | 300,891 |  |  | $ | 118,309 |  |  | $ | 1,114,087 |  |  | $ | 5,294 |  |

[0001193125-16-758846:mdna:104]
[same as prior period, unchanged from 0001193125-16-671832:mdna:81]

[0001193125-16-758846:mdna:105]
[same as prior period, unchanged from 0001193125-16-671832:mdna:82]

[0001193125-16-758846:mdna:106]
[same as prior period, unchanged from 0001193125-16-671832:mdna:83]

[0001193125-16-758846:mdna:107]
[same as prior period, unchanged from 0001193125-16-671832:mdna:84]

[0001193125-16-758846:mdna:108]
[same as prior period, unchanged from 0001193125-16-671832:mdna:85]
