# TTMI notes — 0001193125-16-758846


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-16-758846:notes:1]
(12) Commitments and
 Contingencies

[0001193125-16-758846:notes:2]
Legal
 Matters

[0001193125-16-758846:notes:3]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of September 26, 2016 and
 December 28, 2015. However, these amounts are not material to
 the consolidated condensed financial statements of the
 Company.

[0001193125-16-758846:notes:4]
Environmental
 Matters

[0001193125-16-758846:notes:5]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling, and disposal of chemicals, solid wastes,
 and other hazardous materials, as well as compliance with air
 quality standards and chemical use reporting. The Company believes
 that its facilities in the United States, Canada and Mexico comply
 in all material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted new
 rules and regulations governing environmental issues. An update to
 the Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the updated environmental regulations. The Company believes it
 has developed plans acceptable to the Chinese government and is in
 the process of implementing these plans. The Company does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan related to the efforts to come into full
 compliance with the new regulations. The 2016 capital expenditure
 costs expected for these plans are included in the Company’s
 capital expenditure projections.


## us-gaap:ConvertibleDebtTableTextBlock

[0001193125-16-758846:notes:6]
As of September 26, 2016 and December 28, 2015, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:

[0001193125-16-758846:notes:7]
|  |  | As of September 26, 2016 and December 28, 2015 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-16-758846:notes:8]
[same as prior period, unchanged from 0001193125-16-671832:notes:8]

[0001193125-16-758846:notes:9]
[same as prior period, unchanged from 0001193125-16-671832:notes:9]

[0001193125-16-758846:notes:10]
|  |  | Quarter Ended |  |  | Three quarters Ended |  |
|  |  | September 26, 2016 |  |  | September 28, 2015 |  |  | September 26, 2016 |  |  | September 28, 2015 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 412 |  |  | $ | 322 |  |  | $ | 1,161 |  |  | $ | 790 |  |
| Selling and marketing |  |  | 268 |  |  |  | 294 |  |  |  | 749 |  |  |  | 834 |  |
| General and administrative |  |  | 2,119 |  |  |  | 2,056 |  |  |  | 5,980 |  |  |  | 5,402 |  |
| Stock-based compensation expense recognized |  | $ | 2,799 |  |  | $ | 2,672 |  |  | $ | 7,890 |  |  | $ | 7,026 |  |

[0001193125-16-758846:notes:11]
[same as prior period, unchanged from 0001193125-16-671832:notes:11]

[0001193125-16-758846:notes:12]
[same as prior period, unchanged from 0001193125-16-671832:notes:12]

[0001193125-16-758846:notes:13]
The Company records stock-based compensation expense for PRU
 awards granted based on management’s periodic assessment of
 the probability of the PRU awards vesting. For the quarters and
 three quarters ended September 26, 2016, management determined that
 vesting of the PRU awards was probable. PRUs activity for the three
 quarters ended September 26, 2016 was as follows:

[0001193125-16-758846:notes:14]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding target shares at December 28, 2015 |  |  | 301 |  |  | $ | 8.58 |  |
| Granted |  |  | 347 |  |  |  | 6.46 |  |
| Change in units due to annual financial target performance achievement |  |  | (20 | ) |  |  | 6.46 |  |
| Outstanding target shares at September 26, 2016 |  |  | 628 |  |  | $ | 7.48 |  |

[0001193125-16-758846:notes:15]
[same as prior period, unchanged from 0001193125-16-671832:notes:15]

[0001193125-16-758846:notes:16]
The Company granted 1,814 and 1,301 restricted stock units
 during the three quarters ended September 26, 2016 and
 September 28, 2015, respectively. The RSUs granted have a
 weighted-average fair value per unit of $6.74 and $9.15 for the
 three quarters ended September 26, 2016 and September 28, 2015,
 respectively. The fair value for RSUs granted is based on the
 closing share price of the Company’s common stock on the date
 of grant. There were no restricted stock units granted during the
 quarters ended September 26, 2016 and September 28,
 2015.

[0001193125-16-758846:notes:17]
[same as prior period, unchanged from 0001193125-16-671832:notes:17]

[0001193125-16-758846:notes:18]
The Company did not grant any stock option awards during the
 quarters and three quarters ended September 26, 2016 and September
 28, 2015.

[0001193125-16-758846:notes:19]
[same as prior period, unchanged from 0001193125-16-671832:notes:19]

[0001193125-16-758846:notes:20]
The following is a summary of total unrecognized compensation
 costs as of September 26, 2016:

[0001193125-16-758846:notes:21]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| RSU awards |  | $ | 14,067 |  |  |  | 1.4 |  |
| PRU awards |  |  | 2,063 |  |  |  | 1.6 |  |
|  |  | $ | 16,130 |  |  |  |  |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001193125-16-758846:notes:22]
(18) Sale of Suzhou,
 China Manufacturing Facility

[0001193125-16-758846:notes:23]
During
 the three quarters ended September 28, 2015, the Company sold its
 Meadville Aspocomp (Suzhou) Electronic Co., Ltd. subsidiary, which
 held its Suzhou, China manufacturing facility, for $21,275 and
 recognized a gain of $2,504. This subsidiary was included in the
 Company’s PCB operating segment.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-16-758846:notes:24]
[same as prior period, unchanged from 0001193125-16-671832:notes:24]

[0001193125-16-758846:notes:25]
Inventories as of September 26, 2016 and December 28, 2015
 consisted of the following:

[0001193125-16-758846:notes:26]
|  |  | As of |  |
|  |  | September 26, 2016 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 69,739 |  |  | $ | 70,577 |  |
| Work-in-process |  |  | 115,880 |  |  |  | 97,193 |  |
| Finished goods |  |  | 95,550 |  |  |  | 101,153 |  |
|  |  | $ | 281,169 |  |  | $ | 268,923 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-16-758846:notes:27]
Recently Adopted and
 Issued Accounting Standards

[0001193125-16-758846:notes:28]
In March 2016, the Financial Accounting Standards Board (FASB)
 issued Accounting Standards Update (ASU) 2016-09, Stock
 Compensation (Topic 718): Improvements to Employee Share-Based
 Payment Accounting. The objective of this update is to simplify
 several aspects of the accounting for employee share-based payment
 transactions, including the income tax consequences, classification
 of awards as either equity or liabilities, and classification on
 the statement of cash flows. This ASU is effective for fiscal years
 beginning after December 15, 2016, including interim periods within
 those fiscal years. Early adoption is permitted. The Company is
 currently evaluating the new guidance to determine the impact it
 may have on its consolidated financial statements and related
 disclosures.

[0001193125-16-758846:notes:29]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic
 842). The objective of this update is to increase transparency
 and comparability among organizations by recognizing lease assets
 and lease liabilities on the balance sheet and disclosing key
 information about leasing arrangements. This ASU is effective for
 fiscal years beginning after December 15, 2018, including interim
 periods within those annual periods and is to be applied utilizing
 a modified retrospective approach. The Company is currently
 evaluating the new guidance to determine the impact it may have on
 its consolidated financial statements and related
 disclosures.

[0001193125-16-758846:notes:30]
In April 2015, the FASB issued ASU 2015-03, Imputation of
 Interest, as amended, which requires an entity to record debt
 issuance costs related to debt reported in the balance sheet as a
 direct deduction from the face amount of that debt. The update is
 effective for annual periods ending after December 15, 2015.
 The standard requires the use of the retrospective transition
 method. The Company adopted the new standard in the first quarter
 of 2016. Accordingly, as of September 26, 2016, approximately
 $26,314 of unamortized debt issuance costs were presented as a
 reduction of long-term debt on the Company’s consolidated
 condensed balance sheets. Furthermore, the Company reclassified
 approximately $31,171 of unamortized debt issuance costs that had
 been presented as other non-current assets as of December 28,
 2015.

[0001193125-16-758846:notes:31]
In May 2014, the FASB issued ASU 2014-09, Revenue from
 Contracts with Customers, as amended, which requires an entity
 to recognize the amount of revenue to which it expects to be
 entitled for the transfer of promised goods or services to
 customers. The ASU will replace most existing revenue recognition
 guidance in U.S. GAAP when it becomes effective. The new standard
 is effective for the Company at the beginning of fiscal year 2018,
 however application of the standard is allowed as early as the
 beginning of fiscal 2017. The standard permits the use of either
 the retrospective or cumulative effect transition method and
 management is currently evaluating which transition approach to
 use. The Company has assessed that the impact of the new guidance
 will result in a change to the timing of revenue recognition for a
 portion of the Company’s revenue stream from
 “point in time” upon physical delivery to an
 “over time” model and believes this transition could
 have a material impact on the Company’s consolidated
 financial statements upon adoption.


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001193125-16-758846:notes:32]
The following provides a summary of reclassifications out of
 accumulated other comprehensive income (loss) for the quarters and
 three quarters ended September 26, 2016 and September 28,
 2015:

[0001193125-16-758846:notes:33]
|  |  |  |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |
|  |  |  |  | For the Quarter Ended |  |  | For the Three quarters Ended |  |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Statement of Operations Location |  | September 26, 2016 |  |  | September 28, 2015 |  |  | September 26, 2016 |  |  | September 28, 2015 |  |
| Loss on cash flow hedges |  | Depreciation expense, net of tax |  | $ | 47 |  |  | $ | 44 |  |  | $ | 128 |  |  | $ | 129 |  |
| Gain on foreign currency translation |  | Gain on sale of assets, net of tax |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (1,786 | ) |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-16-758846:notes:34]
The Company accounts for inter-segment sales and transfers
 consistent with the Company’s revenue recognition policy. The
 inter-segment sales for the quarters and three quarters ended
 September 26, 2016 and September 28, 2015, are sales primarily from
 the PCB to the E-M Solutions operating segment.

[0001193125-16-758846:notes:35]
|  |  | Quarter Ended |  |  | Three quarters Ended |  |
|  |  | September 26, 2016 |  |  | September 28, 2015 |  |  | September 26, 2016 |  |  | September 28, 2015 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 598,656 |  |  | $ | 604,771 |  |  | $ | 1,692,175 |  |  | $ | 1,332,996 |  |
| E-M Solutions |  |  | 46,246 |  |  |  | 49,658 |  |  |  | 143,151 |  |  |  | 97,634 |  |
| Total sales |  |  | 644,902 |  |  |  | 654,429 |  |  |  | 1,835,326 |  |  |  | 1,430,630 |  |
| Inter-segment sales |  |  | (3,182 | ) |  |  | (2,424 | ) |  |  | (8,501 | ) |  |  | (4,016 | ) |
| Total net sales |  | $ | 641,720 |  |  | $ | 652,005 |  |  | $ | 1,826,825 |  |  | $ | 1,426,614 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 75,501 |  |  | $ | 52,191 |  |  | $ | 189,838 |  |  | $ | 105,907 |  |
| E-M Solutions |  |  | 1,421 |  |  |  | (1,729 | ) |  |  | 1,655 |  |  |  | (1,188 | ) |
| Corporate |  |  | (20,747 | ) |  |  | (20,445 | ) |  |  | (69,841 | ) |  |  | (67,713 | ) |
| Total operating segment income (loss) |  |  | 56,175 |  |  |  | 30,017 |  |  |  | 121,652 |  |  |  | 37,006 |  |
| Amortization of definite-lived intangibles |  |  | (5,949 | ) |  |  | (6,421 | ) |  |  | (17,845 | ) |  |  | (12,205 | ) |
| Total operating income (loss) |  |  | 50,226 |  |  |  | 23,596 |  |  |  | 103,807 |  |  |  | 24,801 |  |
| Total other expense |  |  | (14,943 | ) |  |  | (17,004 | ) |  |  | (52,411 | ) |  |  | (36,083 | ) |
| Income (loss) before income taxes |  | $ | 35,283 |  |  | $ | 6,592 |  |  | $ | 51,396 |  |  | $ | (11,282 | ) |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001193125-16-758846:notes:36]
[same as prior period, unchanged from 0001193125-16-671832:notes:36]

[0001193125-16-758846:notes:37]
On September 29, 2015, the Company announced a
 consolidation plan that resulted in the closure of the
 Company’s facilities in Cleveland, Ohio, Milpitas, California
 and Juarez, Mexico (the Consolidation Plan) and the laid off
 approximately 480 employees at these sites. The Consolidation Plan
 was part of the Company’s integration strategy to improve
 total plant utilization, operational performance and customer focus
 following its acquisition of Viasystems. In accordance with the
 Consolidation Plan, the Company has combined its Cleveland and
 Milpitas facilities into its North Jackson, Ohio and Silicon
 Valley, California facilities, respectively, and closed its Juarez
 facility.

[0001193125-16-758846:notes:38]
In connection with the Consolidation Plan and other global
 realignment restructuring efforts, the Company recognized employee
 separation costs and contract termination and other costs during
 the quarter and three quarters ended September 26,
 2016. Contract termination and other costs primarily
 represented plant closure costs for Cleveland, Ohio, Milpitas,
 California and Juarez, Mexico, as well as costs related to building
 operating leases associated with the downsizing of the St. Louis,
 Missouri office.

[0001193125-16-758846:notes:39]
[same as prior period, unchanged from 0001193125-16-671832:notes:39]

[0001193125-16-758846:notes:40]
|  |  | Quarter Ended September 26, 2016 |  |  | Three quarters Ended September 26, 2016 |  |
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Operating Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 157 |  |  | $ | 778 |  |  | $ | 935 |  |  | $ | 1,425 |  |  | $ | 1,878 |  |  | $ | 3,303 |  |
| E-M Solutions |  |  | 222 |  |  |  | 1,072 |  |  |  | 1,294 |  |  |  | 956 |  |  |  | 3,016 |  |  |  | 3,972 |  |
| Corporate |  |  | (121 | ) |  |  | (5 | ) |  |  | (126 | ) |  |  | (112 | ) |  |  | 842 |  |  |  | 730 |  |
|  |  | $ | 258 |  |  | $ | 1,845 |  |  | $ | 2,103 |  |  | $ | 2,269 |  |  | $ | 5,736 |  |  | $ | 8,005 |  |

[0001193125-16-758846:notes:41]
During the quarter and three quarters ended September 28,
 2015, the Company recognized restructuring charges of $1,936 in its
 E-M Solutions segment. These charges primarily represent severance
 expense associated with the closure of the Juarez
 facility.

[0001193125-16-758846:notes:42]
The below table shows the utilization of the accrued
 restructuring costs during the three quarters ended September 26,
 2016:

[0001193125-16-758846:notes:43]
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued at December 28, 2015 |  | $ | 6,044 |  |  | $ | 535 |  |  | $ | 6,579 |  |
| Charged to expense |  |  | 2,390 |  |  |  | 5,790 |  |  |  | 8,180 |  |
| Adjustments to estimate |  |  | (121 | ) |  |  | (54 | ) |  |  | (175 | ) |
| Amount paid |  |  | (7,575 | ) |  |  | (4,725 | ) |  |  | (12,300 | ) |
| Accrued at September 26, 2016 |  | $ | 738 |  |  | $ | 1,546 |  |  | $ | 2,284 |  |

[0001193125-16-758846:notes:44]
As of September 26, 2016, the remaining accrual for employee
 separation/severance, which relates to employees yet to be
 separated, was included as a component of accrued salaries, wages
 and benefits and the remaining unpaid estimated contract
 termination and other costs are included as a component of other
 accrued expenses in the consolidated condensed balance sheet. The
 Company expects the remaining employees to be separated and the
 remaining accrued restructuring costs to be substantially paid out
 by December 2016.

[0001193125-16-758846:notes:45]
As of September 26, 2016, the Company has incurred
 approximately $15,178 of restructuring charges since the September
 29, 2015 announcement and estimates that it will incur total
 charges of approximately $20,000 related to these closures and
 global realignment efforts.

[0001193125-16-758846:notes:46]
The Company also recognized $3,346 in impairment charges during
 the three quarters ended September 26, 2016. As a result of the
 above mentioned plant closures and other plant realignment efforts,
 $1,393 of impairment charges were recognized in the consolidated
 condensed statement of operations related to machinery and
 equipment in the PCB operating segment for the three quarters ended
 September 26, 2016. Additionally, the Company expensed $1,953
 of capitalized software costs in the Corporate operating segment
 during the three quarters ended September 26, 2016.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-16-758846:notes:47]
The following provides a summary of the components of
 accumulated other comprehensive income (loss) as of September 26,
 2016 and December 28, 2015:

[0001193125-16-758846:notes:48]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 28, 2015 |  | $ | 2,895 |  |  | $ | (1,272 | ) |  | $ | 1,623 |  |
| Other comprehensive loss before reclassifications |  |  | (19,061 | ) |  |  | (17 | ) |  |  | (19,078 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 128 |  |  |  | 128 |  |
| Other comprehensive (loss) income |  |  | (19,061 | ) |  |  | 111 |  |  |  | (18,950 | ) |
| Ending balance at September 26, 2016 |  | $ | (16,166 | ) |  | $ | (1,161 | ) |  | $ | (17,327 | ) |


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001193125-16-758846:notes:49]
[same as prior period, unchanged from 0001193125-16-671832:notes:48]

[0001193125-16-758846:notes:50]
[same as prior period, unchanged from 0001193125-16-671832:notes:49]


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-16-758846:notes:51]
The following table summarizes the long-term debt of the
 Company as of September 26, 2016 and December 28,
 2015:

[0001193125-16-758846:notes:52]
|  |  | Average Effective Interest Rate as of September 26, 2016 |  |  | September 26, 2016 |  |  | Average Effective Interest Rate as of December 28, 2015 |  |  | December 28, 2015 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 6.00% |  |  | $ | 841,143 |  |  |  | 6.00% |  |  | $ | 947,625 |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.27% |  |  |  | 80,000 |  |  |  | 2.17% |  |  |  | 80,000 |  |
| Convertible senior notes due December 2020 |  |  | 1.75% |  |  |  | 250,000 |  |  |  | 1.75% |  |  |  | 250,000 |  |
| Capital lease |  |  | 6.43% |  |  |  | 1,875 |  |  |  |  |  |  |  | — |  |
|  |  |  |  |  |  |  | 1,173,018 |  |  |  |  |  |  |  | 1,277,625 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (64,854 | ) |  |  |  |  |  |  | (75,668 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (26,314 | ) |  |  |  |  |  |  | (31,171 | ) |
|  |  |  |  |  |  |  | 1,081,850 |  |  |  |  |  |  |  | 1,170,786 |  |
| Less: current maturities |  |  |  |  |  |  | (146,473 | ) |  |  |  |  |  |  | (157,375 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 935,377 |  |  |  |  |  |  | $ | 1,013,411 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-16-758846:notes:53]
[same as prior period, unchanged from 0001193125-16-671832:notes:52]

[0001193125-16-758846:notes:54]
[same as prior period, unchanged from 0001193125-16-671832:notes:53]

[0001193125-16-758846:notes:55]
During
 the quarter and three quarters ended September 26, 2016, the
 Company’s effective tax rate was impacted by a net discrete
 benefit of $240 and $6,733, respectively, related to (i) tax
 holiday benefits, (ii) release of uncertain tax positions due to
 expiration of the statute of limitations in a foreign jurisdiction,
 and (iii) accrued interest on existing uncertain tax positions.
 Additionally, no tax benefit was recorded on the losses incurred in
 the U.S. and certain foreign jurisdictions as a result of
 corresponding increases in the valuation allowances in these
 jurisdictions. The Company’s foreign earnings attributable to
 certain foreign subsidiaries will be indefinitely reinvested in
 such foreign jurisdictions and, therefore, no deferred tax
 liabilities for U.S. income taxes on undistributed earnings of
 those certain foreign subsidiaries are recorded.

[0001193125-16-758846:notes:56]
Certain entities in China operated under tax incentives
 effective through 2016. For the quarter and three quarters ended
 September 26, 2016, the tax incentives decreased Chinese taxes by
 approximately $1,564 and $6,089, respectively, which increased
 basic earnings per share by $0.02 and $0.06, and increased diluted
 earnings per share by $0.01 and $0.05, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-16-758846:notes:57]
[same as prior period, unchanged from 0001193125-16-671832:notes:56]

[0001193125-16-758846:notes:58]
TTM Technologies, Inc. (the Company or TTM) is a leading global
 printed circuit board (PCB) manufacturer, focusing on quick-turn
 and technologically advanced PCBs and electro-mechanical solutions
 (E-M Solutions). The Company provides time-to-market and advanced
 technology products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final volume production. This one-stop manufacturing solution
 allows the Company to align technology developments with the
 diverse needs of the Company’s customers and to enable them
 to reduce the time required to develop new products and bring them
 to market.

[0001193125-16-758846:notes:59]
The Company serves a diversified customer base in various
 markets throughout the world, including manufacturers of
 networking/communications infrastructure products, tablets and
 smartphones, as well as the aerospace and defense, automotive
 components, high-end computing, and medical, industrial and
 instrumentation related products. The Company’s customers
 include both original equipment manufacturers (OEMs) and electronic
 manufacturing services (EMS) providers.

[0001193125-16-758846:notes:60]
The accompanying consolidated condensed financial statements
 have been prepared by the Company, without audit, pursuant to the
 rules and regulations of the Securities and Exchange Commission
 (SEC). Certain information and disclosures normally included in
 financial statements prepared in accordance with accounting
 principles generally accepted in the United States of America (U.S.
 GAAP) have been condensed or omitted pursuant to such rules and
 regulations. These consolidated condensed financial statements
 reflect all adjustments (consisting only of normal recurring
 adjustments) which, in the opinion of management, are necessary to
 present fairly the financial position, the results of operations
 and cash flows of the Company for the periods presented. It is
 suggested that these consolidated condensed financial statements be
 read in conjunction with the consolidated financial statements and
 the notes thereto included in the Company’s most recent
 Annual Report on Form 10-K. The results of operations for the
 interim periods are not necessarily indicative of the results to be
 expected for the full year. The preparation of financial statements
 in accordance with U.S. GAAP requires management to make estimates
 and assumptions that affect the amounts reported in the
 Company’s consolidated condensed financial statements and
 accompanying notes. Actual results could differ materially from
 those estimates. The Company uses a 52/53 week fiscal calendar with
 the fourth quarter ending on the Monday nearest December 31.
 Fiscal 2015 was a 52 week year. Fiscal 2016 will be a 53 week year
 with the additional week included in the fourth quarter.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-16-758846:notes:61]
The following is a reconciliation of the numerator and
 denominator used to calculate basic earnings (loss) per share and
 diluted earnings (loss) per share for the quarters and three
 quarters ended September 26, 2016 and September 28,
 2015:

[0001193125-16-758846:notes:62]
|  |  | Quarter Ended |  |  | Three quarters Ended |  |
|  |  | September 26, 2016 |  |  | September 28, 2015 |  |  | September 26, 2016 |  |  | September 28, 2015 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings (loss) |  | $ | 25,582 |  |  | $ | (2,237 | ) |  | $ | 36,866 |  |  | $ | (35,403 | ) |
| Diluted earnings (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to TTM Technologies, Inc. stockholders |  | $ | 25,582 |  |  | $ | (2,237 | ) |  | $ | 36,866 |  |  | $ | (35,403 | ) |
| Interest expense from convertible senior notes, net of tax |  |  | 3,321 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Diluted earnings (loss) |  | $ | 28,903 |  |  | $ | (2,237 | ) |  | $ | 36,866 |  |  | $ | (35,403 | ) |
| Basic shares |  |  | 100,245 |  |  |  | 99,128 |  |  |  | 100,004 |  |  |  | 90,522 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 1,460 |  |  |  | — |  |  |  | 1,090 |  |  |  | — |  |
| Dilutive effect of assumed conversion of convertible senior notes outstanding |  |  | 25,940 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Diluted shares |  |  | 127,645 |  |  |  | 99,128 |  |  |  | 101,094 |  |  |  | 90,522 |  |
| Income (loss) per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.26 |  |  | $ | (0.02 | ) |  | $ | 0.37 |  |  | $ | (0.39 | ) |
| Diluted |  | $ | 0.23 |  |  | $ | (0.02 | ) |  | $ | 0.36 |  |  | $ | (0.39 | ) |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-16-758846:notes:63]
[same as prior period, unchanged from 0001193125-16-671832:notes:64]

[0001193125-16-758846:notes:64]
|  |  | (In thousands) |  |
| Remaining 2016 |  | $ | 6,035 |  |
| 2017 |  |  | 23,647 |  |
| 2018 |  |  | 22,889 |  |
| 2019 |  |  | 18,746 |  |
| 2020 |  |  | 18,746 |  |
| Thereafter |  |  | 42,956 |  |
|  |  | $ | 133,019 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-16-758846:notes:65]
As of
 September 26, 2016 and December 28, 2015, goodwill was as
 follows:

[0001193125-16-758846:notes:66]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 28, 2015 |  | $ | 346,990 |  |
| Goodwill recognized during the first two quarters of 2016 |  |  | 25,624 |  |
| Foreign currency translation adjustment |  |  | (7 | ) |
| Balance as of September 26, 2016 |  | $ | 372,607 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-16-758846:notes:67]
[same as prior period, unchanged from 0001193125-16-671832:notes:68]

[0001193125-16-758846:notes:68]
On May 31, 2015, the Company completed the acquisition of
 Viasystems Group, Inc. (Viasystems), for total consideration of
 $248,824 in cash and 15,082 shares of TTM common stock with a fair
 value of $149,006, and thereby acquired all of the outstanding
 shares of capital stock and other equity rights of Viasystems.
 Additionally, in connection with the completion of the acquisition,
 the Company assumed and refinanced Viasystems’ debt, which
 was approximately $669,024 as of May 31, 2015. Viasystems was
 a worldwide provider of complex multi-layer rigid, flexible, and
 rigid-flex PCBs and custom electronic assemblies.

[0001193125-16-758846:notes:69]
Bank fees and legal, accounting, and other professional service
 costs associated with the acquisition of Viasystems of $197
 and $2,065 for the quarters ended September 26, 2016 and
 September 28, 2015, respectively, and $1,493 and $32,927 for the
 three quarters ended September 26, 2016 and September 28, 2015,
 respectively, have been expensed and recorded as general and
 administrative expense in the consolidated condensed
 statements of operations.

[0001193125-16-758846:notes:70]
The following summarizes the components of the purchase
 price:

[0001193125-16-758846:notes:71]
The value of the shares of the Company’s common stock
 used in determining the purchase price was $9.88 per share, the
 closing price of the Company’s common stock on May 29,
 2015, the last business day prior to the effective date of the
 acquisition.

[0001193125-16-758846:notes:72]
The purchase price of the Viasystems acquisition was allocated
 to tangible and intangible assets acquired, liabilities assumed and
 noncontrolling interest based on the fair value at the date of the
 acquisition (May 31, 2015). The excess of the purchase price over
 the fair value of net assets acquired and noncontrolling interest
 was allocated to goodwill. The fair value assigned to intangible
 assets acquired was based on estimates and assumptions made by
 management at the time of acquisition. The Company finalized the
 allocation of the purchase price during the second quarter of
 2016.

[0001193125-16-758846:notes:73]
The fair values assigned are based on reasonable methods
 applicable to the nature of the assets acquired, liabilities
 assumed and noncontrolling interest. The following summarizes the
 final estimated fair values of net assets acquired and
 noncontrolling interest:

[0001193125-16-758846:notes:74]
[same as prior period, unchanged from 0001193125-16-671832:notes:74]

[0001193125-16-758846:notes:75]
Goodwill represents the excess of the Viasystems purchase price
 over the fair value of tangibles and identifiable intangible assets
 acquired, liabilities assumed and noncontrolling interest. During
 the first two quarters of 2016, goodwill was adjusted to
 reflect:

[0001193125-16-758846:notes:76]
[same as prior period, unchanged from 0001193125-16-671832:notes:76]

[0001193125-16-758846:notes:77]
[same as prior period, unchanged from 0001193125-16-671832:notes:77]

[0001193125-16-758846:notes:78]
The goodwill acquired in the acquisition is not deductible for
 income tax purposes.

[0001193125-16-758846:notes:79]
[same as prior period, unchanged from 0001193125-16-671832:notes:79]

[0001193125-16-758846:notes:80]
The unaudited pro forma financial information in the table
 below gives effect to this acquisition as if it had occurred at the
 beginning of fiscal 2015. The pro forma financial information
 presented includes the effects of adjustments related to the fair
 value step up of acquired inventory, amortization of acquired
 intangible assets and depreciation of acquired fixed assets, and
 other non-recurring transactions costs directly associated with the
 acquisitions such as legal, accounting and banking fees.

[0001193125-16-758846:notes:81]
|  |  | Three quarters Ended September 28, 2015 |  |
|  |  | (In thousands, except per share data) |  |
| Net sales |  | $ | 1,933,430 |  |
| Net loss attributable to TTM Technologies, Inc. stockholders |  | $ | (25,033 | ) |
| Basic loss per share |  | $ | (0.28 | ) |
| Dilutive loss per share |  | $ | (0.28 | ) |

[0001193125-16-758846:notes:82]
The pro forma financial information as presented above is for
 informational purposes only and is not necessarily indicative of
 the actual results that would have been achieved had the Viasystems
 acquisition occurred at the beginning of the period presented, or
 the results that may be achieved in future periods.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-16-758846:notes:83]
(9) Accumulated Other
 Comprehensive Income (Loss)


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-16-758846:notes:84]
[same as prior period, unchanged from 0001193125-16-671832:notes:86]

[0001193125-16-758846:notes:85]
As of September 26, 2016 and December 28, 2015, the
 components of definite-lived intangibles were as
 follows:

[0001193125-16-758846:notes:86]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| September 26, 2016: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (72,334 | ) |  | $ | 117 |  |  | $ | 131,346 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (1,327 | ) |  |  | — |  |  |  | 1,673 |  |  |  | 3.0 |  |
|  |  | $ | 206,563 |  |  | $ | (73,661 | ) |  | $ | 117 |  |  | $ | 133,019 |  |  |  |  |  |
| December 28, 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 91,492 |  |  | $ | (80,152 | ) |  | $ | 426 |  |  | $ | 11,766 |  |  |  | 9.2 |  |
| Trade name |  |  | 10,302 |  |  |  | (10,313 | ) |  |  | 11 |  |  |  | — |  |  |  | 6.0 |  |
| Acquired intangibles from Viasystems acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 147,500 |  |  |  | (10,815 | ) |  |  | — |  |  |  | 136,685 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (577 | ) |  |  | — |  |  |  | 2,423 |  |  |  | 3.0 |  |
|  |  | $ | 252,294 |  |  | $ | (101,857 | ) |  | $ | 437 |  |  | $ | 150,874 |  |  |  |  |  |

[0001193125-16-758846:notes:87]
The September 26, 2016 and December 28, 2015
 definite-lived intangible balances include foreign currency
 translation adjustments related to foreign subsidiaries with
 functional currencies other than the U.S. Dollar.

[0001193125-16-758846:notes:88]
Definite-lived intangibles are generally amortized using the
 straight line method of amortization over the useful life, with the
 exception of certain customer relationship intangibles, which are
 amortized using an accelerated method of amortization based on
 estimated cash flows. Amortization expense was $5,949 and $6,421
 for the quarters ended September 26, 2016 and September 28, 2015,
 respectively, and $17,845 and $12,205 for the three quarters ended
 September 26, 2016 and September 28, 2015, respectively.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-16-758846:notes:89]
[same as prior period, unchanged from 0001193125-16-671832:notes:91]

[0001193125-16-758846:notes:90]
[same as prior period, unchanged from 0001193125-16-671832:notes:92]

[0001193125-16-758846:notes:91]
[same as prior period, unchanged from 0001193125-16-671832:notes:93]

[0001193125-16-758846:notes:92]
For
 both of the quarters ended September 26, 2016 and September 28,
 2015, one customer accounted for approximately 17% of the
 Company’s net sales. For the three quarters ended September
 26, 2016 and September 28, 2015, one customer accounted for
 approximately 13% and 21%, respectively, of the Company’s net
 sales. There were no other customers that accounted for 10% or more
 of net sales for the quarters or three quarters ended September 26,
 2016 and September 28, 2015.


## us-gaap:EarningsPerShareTextBlock

[0001193125-16-758846:notes:93]
[same as prior period, unchanged from 0001193125-16-671832:notes:95]

[0001193125-16-758846:notes:94]
For the quarter and three quarters ended September 26, 2016,
 performance-based stock units (PRUs), restricted stock units (RSUs)
 and stock options to purchase 233 and 1,174 shares of common stock,
 respectively, were not considered in calculating diluted earnings
 per share because the options’ exercise prices or the total
 expected proceeds under the treasury stock method for
 performance-based stock units, restricted stock units or stock
 options was greater than the average market price of common shares
 during the applicable quarter and three quarters and, therefore,
 the effect would be anti-dilutive.

[0001193125-16-758846:notes:95]
For the three quarters ended September 26, 2016, the effect of
 shares of common stock related to the Company’s convertible
 senior notes, based on the if-converted method, were not included
 in the computation of dilutive earnings per share as the impact
 would be anti-dilutive.

[0001193125-16-758846:notes:96]
For the quarter and three quarters ended September 28, 2015,
 potential shares of common stock, consisting of stock options to
 purchase approximately 422 shares of common stock at exercise
 prices ranging from $5.78 to $16.82 per share, 2,326 RSUs, and 275
 PRUs were not included in the computation of diluted earnings per
 share because the Company incurred a net loss and, as a result, the
 impact would be anti-dilutive.

[0001193125-16-758846:notes:97]
For the quarters and three quarters ended September 26, 2016
 and September 28, 2015, outstanding warrants to purchase 25,940 and
 27,500 shares of common stock, respectively, were not included in
 the computation of dilutive earnings per share because the strike
 price of the warrants to purchase the Company’s common stock
 were greater than the average market price of common shares during
 the applicable quarters and three quarters, and therefore, the
 effect would be anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-16-758846:notes:98]
[same as prior period, unchanged from 0001193125-16-671832:notes:100]

[0001193125-16-758846:notes:99]
The
 Company measures at fair value its financial and non-financial
 assets by using a fair value hierarchy that prioritizes the inputs
 to valuation techniques used to measure fair value. Fair value is
 the price that would be received to sell an asset or paid to
 transfer a liability in an orderly transaction between market
 participants at the measurement date, essentially an exit price,
 based on the highest and best use of the asset or
 liability.

[0001193125-16-758846:notes:100]
The
 carrying amount and estimated fair value of the Company’s
 financial instruments at September 26, 2016 and December 28,
 2015 were as follows:

[0001193125-16-758846:notes:101]
|  |  | September 26, 2016 |  |  | December 28, 2015 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Term and revolving loans |  | $ | 873,377 |  |  | $ | 921,143 |  |  | $ | 970,764 |  |  | $ | 935,000 |  |
| Convertible senior notes due 2020 |  |  | 206,598 |  |  |  | 325,625 |  |  |  | 200,022 |  |  |  | 230,950 |  |
| Capital lease |  |  | 1,875 |  |  |  | 1,875 |  |  |  | — |  |  |  | — |  |

[0001193125-16-758846:notes:102]
The
 fair value of the long-term debt was estimated based on quoted
 market prices or discounting the debt over its life using current
 market rates for similar debt as of September 26, 2016 and
 December 28, 2015, which are considered Level 1 and Level 2
 inputs.

[0001193125-16-758846:notes:103]
The
 fair value of the convertible senior notes was estimated based on
 quoted market prices of the securities on an active exchange, which
 are considered Level 1 and Level 2 inputs.

[0001193125-16-758846:notes:104]
As of
 September 26, 2016 and December 28, 2015, the Company’s
 other financial instruments also included cash and cash
 equivalents, accounts receivable and accounts payable. Due to
 short-term maturities, the carrying amount of these instruments
 approximates fair value. Our cash and cash equivalents at September
 26, 2016 consisted of $117,566 held in the U.S., with the remaining
 $174,217 held by foreign subsidiaries.

[0001193125-16-758846:notes:105]
The
 majority of the Company’s non-financial assets and
 liabilities, which include goodwill, intangible assets,
 inventories, and property, plant and equipment, are not required to
 be carried at fair value on a recurring basis. However, if certain
 triggering events occur such that a non-financial instrument is
 required to be evaluated for impairment (at least annually for
 goodwill), based upon a comparison of the non-financial
 instrument’s fair value to its carrying value, an impairment
 is recorded to reduce the carrying value to the fair value, if the
 carrying value exceeds the fair value.

[0001193125-16-758846:notes:106]
The
 Company recognized impairment charges related to long-lived assets
 of $3,346 in the three quarters ended September 26, 2016. The fair
 values of the impaired long-lived assets were based on level 2 and
 3 inputs. There was no impairment of long-lived assets recognized
 in the quarter ended September 26, 2016 or for the quarter and
 three quarters ended September 28, 2015.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-16-758846:notes:107]
[same as prior period, unchanged from 0001193125-16-671832:notes:111]

[0001193125-16-758846:notes:108]
All
 goodwill relates to the Company’s PCB reportable operating
 segment.

[0001193125-16-758846:notes:109]
[same as prior period, unchanged from 0001193125-16-671832:notes:114]


## us-gaap:LongTermDebtTextBlock

[0001193125-16-758846:notes:110]
(7) Long-term Debt and
 Letters of Credit

[0001193125-16-758846:notes:111]
Term and Revolving
 Loans

[0001193125-16-758846:notes:112]
On May 31, 2015, in conjunction with the acquisition of
 Viasystems, the Company entered into a $950,000 Term Loan Credit
 Agreement (Term Loan). Additionally, the Company entered into a
 $150,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and a
 $150,000 Asia Asset-Based Lending Credit agreement (Asia ABL)
 (collectively the ABL Revolving Loans). The Company drew $80,000 of
 the U.S. ABL at the closing of the acquisition of
 Viasystems.

[0001193125-16-758846:notes:113]
The Term Loan was issued at a discount at 96.5% and bears
 interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus
 an applicable interest margin of 5.0%, or JP Morgan Chase
 Bank’s prime rate, with a 2% floor, plus a margin of 4%, at
 the Company’s option. At September 26, 2016, the weighted
 average interest rate on the outstanding borrowings under the Term
 Loan was 6.0%. There is no provision, other than an event of
 default, for the interest margin to increase. The Term Loan will
 mature on May 31, 2021. The Term Loan is secured by a
 significant amount of the assets of the Company and its domestic
 subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and is structurally
 senior to the Company’s convertible senior notes. See
 Convertible Senior Notes below.

[0001193125-16-758846:notes:114]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $150,000, a letter of credit
 facility of up to $75,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $150,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 175 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 75 basis points, at the Company’s option. At
 September 26, 2016, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 2.27%. The applicable
 margin can vary based on the remaining availability of the
 facility, from 150 to 200 basis points for LIBOR-based loans or
 from 50 to 100 basis points for JP Morgan Chase Bank’s prime
 rate-based loans. Other than availability and an event of default,
 there are no other provisions for the interest margin to increase.
 The U.S. ABL will mature on May 31, 2020. Loans made under the
 U.S. ABL are secured first by all of the Company’s domestic
 cash, receivables and inventories as well as by a second position
 against a significant amount of the assets of the Company and its
 domestic subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and are
 structurally senior to the Company’s convertible senior
 notes. See Convertible Senior Notes below. At September 26, 2016,
 $80,000 of the U.S. ABL was outstanding and classified as
 short-term debt.

[0001193125-16-758846:notes:115]
The Company and its domestic subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Term
 Loan and U.S. ABL related obligations.

[0001193125-16-758846:notes:116]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of cash and receivables of certain of the
 Companies subsidiaries in Asia and are structurally senior to the
 Company’s domestic obligations, including the convertible
 senior notes. See Convertible Senior Notes below. Additionally,
 certain of the Company’s subsidiaries in Asia have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At September 26, 2016, none of the Asia
 ABL was outstanding.

[0001193125-16-758846:notes:117]
The Company is required to make scheduled payments of the
 outstanding Term Loan balance on a quarterly basis. Based on
 certain parameters defined in the Term Loan agreement, the Company
 may be required to make an additional principal payment on an
 annual basis. Any additional annual payments or prepayments reduce
 future required quarterly scheduled payments. During the three
 quarters ended September 26, 2016, the Company made debt principal
 payments totaling $106,482, representing normally scheduled
 principal payments as well as additional prepayments of principal.
 Any other outstanding balances under the Term Loan are due at the
 maturity date of May 31, 2021. Borrowings under the Term Loan
 are subject to various financial and operating covenants including
 maintaining a maximum total leverage ratio. Under the occurrence of
 certain events, the U.S. ABL and the Asia ABL are subject to
 various financial and operational covenants, including maintaining
 minimum fixed charge coverage ratios. At September 26, 2016, the
 Company was in compliance with the covenants under the Term Loan,
 the U.S. ABL and the Asia ABL.

[0001193125-16-758846:notes:118]
As of September 26, 2016 and December 28, 2015, remaining
 unamortized debt discount of $25,405 and $30,242, respectively, and
 debt issuance costs of $22,361 and $26,619, respectively, related
 to the Term Loan. These debt discount and debt issuance costs are
 recorded as a reduction of the Term Loan and are amortized over the
 duration of the Term Loan into interest expense using an effective
 interest rate of 7.50%.

[0001193125-16-758846:notes:119]
Additionally, remaining unamortized debt issuance costs related
 to the ABL Revolving Loans were $3,573 and $4,303 as of September
 26, 2016 and December 28, 2015, respectively. These debt issuance
 costs are included in other non-current assets and are amortized to
 interest expense over the duration of the ABL Revolving Loans using
 the straight line method of amortization.

[0001193125-16-758846:notes:120]
At September 26, 2016, the remaining amortization period for
 the unamortized debt discount and debt issuance costs for both the
 Term Loan and the ABL Revolving Loans was 4.6 years.

[0001193125-16-758846:notes:121]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL based on utilization levels. Additionally, the Company also
 paid commitment fees of 0.5% per annum on the unused portion
 of the $90,000 senior secured revolving loan associated with the
 terminated 2012 credit agreement for the three quarters ended
 September 28, 2015. The Company incurred total commitment fees
 related to unused borrowing availability of $171 and $200 for the
 quarters ended September 26, 2016 and September 28, 2015,
 respectively, and $516 and $565 for the three quarters ended
 September 26, 2016 and September 28, 2015, respectively. As of
 September 26, 2016, the outstanding amount of the Term Loan was
 $841,143, of which $66,143 is included as short-term debt and the
 remaining $775,000 is included as long-term debt. Additionally,
 $80,000 of the U.S. ABL and none of the Asia ABL was outstanding as
 of September 26, 2016. Available borrowing capacity under the U.S.
 ABL and Asia ABL was $63,003 and $142,904, which includes letters
 of credit outstanding of $6,997 and $7,096 mentioned below,
 respectively, at September 26, 2016.

[0001193125-16-758846:notes:122]
Subsequent to September 26, 2016, the Company issued a new
 $775,000 Term Loan (New Term Loan) at an interest rate of LIBOR
 plus 4.25%, a reduction of 75 basis points from its previous Term
 Loan, and repaid in full the $841,143 of the previously issued Term
 Loan outstanding, which resulted in an overall net reduction of
 $66,143 in the Term Loan outstanding. Principal payments under
 the New Term Loan are due quarterly beginning in April 2020 with
 the balance due on May 31, 2021, the same maturity as the previous
 Term Loan. In addition, the Company amended its U.S. ABL
 credit facility to increase the amount available under the U.S. ABL
 to $200,000, reduce the applicable margin by 0.25% for both
 Eurodollar loans and ABR loans, and reduce the Letters of Credit
 Facilities to $50,000.

[0001193125-16-758846:notes:123]
Letters of
 Credit

[0001193125-16-758846:notes:124]
The Company has up to $75,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of September 26, 2016, letters of credit in the
 amount of $6,997 were outstanding under the U.S. ABL and $7,096
 were outstanding under the Asia ABL with various expiration dates
 through September 2017.

[0001193125-16-758846:notes:125]
At December 28, 2015, certain letters of credit were
 securitized by cash collateral. As such the Company had recorded
 such cash as restricted cash on the consolidated condensed balance
 sheet as of December 28, 2015. As of September 26, 2016, none of
 the letters of credit were securitized by cash
 collateral.

[0001193125-16-758846:notes:126]
Convertible Senior
 Notes due 2020

[0001193125-16-758846:notes:127]
The Company issued 1.75% convertible senior notes due
 December 15, 2020 in a public offering for an aggregate
 principal amount of $250,000 in 2013. The convertible senior notes
 bear interest at a rate of 1.75% per annum. Interest is
 payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 senior unsecured obligations and rank equally to the
 Company’s future unsecured senior indebtedness and are senior
 in right of payment to any of the Company’s future
 subordinated indebtedness.

[0001193125-16-758846:notes:128]
Convertible Senior
 Notes due 2015

[0001193125-16-758846:notes:129]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015 in a public offering for an aggregate principal
 amount of $175,000. In May 2015 the outstanding principal of
 $32,395 plus accrued interest was paid in full.

[0001193125-16-758846:notes:130]
The components of interest expense resulting from the
 convertible senior notes for the quarters and three quarters ended
 September 26, 2016 and September 28, 2015 are as
 follows:

[0001193125-16-758846:notes:131]
|  |  | For the Quarter Ended |  |  | For the Three quarters Ended |  |
|  |  | September 26, 2016 |  |  | September 28, 2015 |  |  | September 26, 2016 |  |  | September 28, 2015 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 395 |  |
|  |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,676 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 2,025 |  |  | $ | 1,898 |  |  | $ | 5,977 |  |  | $ | 5,603 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 554 |  |
|  |  | $ | 2,025 |  |  | $ | 1,898 |  |  | $ | 5,977 |  |  | $ | 6,157 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 203 |  |  | $ | 190 |  |  | $ | 599 |  |  | $ | 561 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 56 |  |
|  |  | $ | 203 |  |  | $ | 190 |  |  | $ | 599 |  |  | $ | 617 |  |

[0001193125-16-758846:notes:132]
As of September 26, 2016 and December 28, 2015, remaining
 unamortized debt discount of $39,449 and $45,426, respectively, and
 debt issuance costs of $3,953 and $4,552, respectively, related to
 the convertible senior notes. These debt discount and debt issuance
 costs are recorded as a reduction of the convertible senior notes
 and are being amortized to interest expense over the term of the
 convertible senior notes using the effective interest rate method.
 At September 26, 2016, the remaining weighted average amortization
 period for the unamortized senior convertible note discount and
 debt issuance costs was 4.2 years.

[0001193125-16-758846:notes:133]
For the quarter and three quarters ended September 26, 2016 and
 September 28, 2015, the amortization of the convertible senior
 notes due 2020 debt discount and debt issuance costs was based on
 an effective interest rate of 6.48%. For the three quarters ended
 September 28, 2015, the amortization of the convertible senior
 notes due 2015 debt discount and debt issuance costs was based on
 an effective interest rate of 8.37%.

[0001193125-16-758846:notes:134]
Other Credit
 Facility

[0001193125-16-758846:notes:135]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $34,500 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2016. As of September 26, 2016, the Chinese Revolver had not been
 drawn upon.

[0001193125-16-758846:notes:136]
Loss on
 Extinguishment of Debt

[0001193125-16-758846:notes:137]
The Company became a party to its current Term Loan and ABL
 Revolving Loans during the second quarter of 2015 in order to
 refinance and pay in full the remaining outstanding amount of
 $225,700 under an existing 2012 credit agreement, as well as to
 finance the acquisition of Viasystems and refinance
 Viasystems’ outstanding debt. As a result, the Company
 recognized losses of approximately $802 for the three quarters
 ended September 28, 2015 resulting from the write off of the
 remaining unamortized debt issuance costs associated with the
 terminated 2012 credit agreement.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-16-758846:notes:138]
(16) Related Party
 Transactions

[0001193125-16-758846:notes:139]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $12,292 and $21,167 for the quarters ended
 September 26, 2016 and September 28, 2015, respectively, and
 $42,549 and $43,335 for the three quarters ended September 26, 2016
 and September 28, 2015, respectively.

[0001193125-16-758846:notes:140]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCBs to SYE and purchases PCBs including various
 services relating to PCB manufacturing from SYE. Sales to SYE for
 the quarters ended September 26, 2016 and September 28, 2015
 were $254 and $1,042, respectively, and $863 and $3,867 for the
 three quarters ended September 26, 2016 and September 28, 2015,
 respectively. Purchases of PCBs, including various services
 relating to PCB manufacturing, for the quarter ended September 28,
 2015 were $344, and $1,840 for the three quarters ended September
 28, 2015. There were no purchases of PCBs including various
 services relating to PCB manufacturing for the quarter or three
 quarters ended September 26, 2016.

[0001193125-16-758846:notes:141]
As of
 September 26, 2016 and December 28, 2015, the Company’s
 consolidated condensed balance sheets included $16,952 and
 $29,306, respectively, in accounts payable due to related parties
 for purchases of laminate and prepreg and various PCB manufacturing
 services and such balances are included as a component of accounts
 payable on the consolidated condensed balance sheets. Additionally,
 the Company’s consolidated condensed balance sheets included
 $598 and $1,999, in accounts receivable due from a related party
 for sales of PCBs to SYE, as of September 26, 2016 and December 28,
 2015, respectively, as mentioned above, and such balances are
 included as a component of accounts receivable, net on the
 consolidated condensed balance sheets.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-16-758846:notes:142]
[same as prior period, unchanged from 0001193125-16-671832:notes:149]

[0001193125-16-758846:notes:143]
The operating segments reported below are the Company’s
 segments for which separate financial information is available and
 upon which operating results are evaluated by the chief operating
 decision maker to assess performance and to allocate resources. The
 Company has reviewed its reportable operating segments and
 determined that it continues to have two reportable operating
 segments: PCB and E-M Solutions. This determination was made based
 on the criteria of earning revenues and incurring expenses, the
 Company’s organizational structure which has segment managers
 who report to the chief operating decision maker, discrete
 financial information, and the aggregation of similar operating
 segments into reportable operating segments. Factors considered to
 determine whether operating segments can be aggregated into
 reportable segments included similarity regarding economic
 characteristics, products, production processes, type or classes of
 customers, distribution methods, and regulatory
 environments.

[0001193125-16-758846:notes:144]
The Company, including the chief operating decision maker,
 evaluates segment performance based on operating segment income,
 which is operating income before amortization of intangibles.
 Interest expense and interest income are not presented by segment
 since they are not included in the measure of segment profitability
 reviewed by the chief operating decision maker. All inter-segment
 transactions have been eliminated.

[0001193125-16-758846:notes:145]
The Corporate category includes operating expenses that are not
 included in the segment operating performance measures. Corporate
 consists primarily of corporate governance functions such as
 finance, accounting, information technology, facilities and human
 resources personnel, as well as global sales and marketing
 personnel and acquisition and integration costs associated with the
 acquisition of Viasystems. Corporate includes bank fees and legal,
 accounting, and other professional service costs associated with
 the acquisition of Viasystems of $197 and $2,065 for the quarters
 ended September 26, 2016 and September 28, 2015, respectively, and
 $1,493 and $32,927 for the three quarters ended September 26, 2016
 and September 28, 2015, respectively.


## ttmi:DistributionOfProfitsDisclosureTextBlock

[0001193125-16-758846:notes:146]
(17) Distribution of
 profits

[0001193125-16-758846:notes:147]
As
 stipulated by the relevant laws and regulations of China applicable
 to the Company’s subsidiaries in China, each of such
 subsidiaries is required to make appropriations from its net income
 as determined in accordance with accounting principles and the
 relevant financial regulations of China (PRC GAAP) to a
 non-distributable reserve, also referred to as statutory surplus
 reserve. The appropriations to the statutory surplus reserve are
 required to be made at not less than 10% of the profit after tax as
 determined under PRC GAAP and required until the balance reaches
 50% of its registered capital. The statutory surplus reserve is
 used to offset future or past losses. These Chinese subsidiaries
 may, upon a resolution passed by their respective shareholders,
 convert the statutory surplus reserve into capital. An increase in
 such appropriations of approximately $597 was made to the statutory
 surplus reserve of these Chinese subsidiaries for the quarter ended
 September 26, 2016.
