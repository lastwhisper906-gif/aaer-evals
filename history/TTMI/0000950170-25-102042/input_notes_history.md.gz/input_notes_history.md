# TTMI note change history — 0000950170-25-063937 → 0000950170-25-102042


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-08-04):
[0000950170-25-102042:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of June 30, 2025 and December 30, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2025-05-06, similarity 0.9944):
[0000950170-25-063937:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of March 31, 2025 and December 30, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

- changed (2025-08-04):
[0000950170-25-102042:note_history:2]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $12,808 and $17,218 as of June 30, 2025 and December 30, 2024, respectively.
  (was, 2025-05-06, similarity 0.9847):
[0000950170-25-063937:note_history:2]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $10,427 and $17,218 as of March 31, 2025 and December 30, 2024, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-08-04):
[0000950170-25-102042:note_history:3]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflicts between Russia and Ukraine, as well as other global regions and the imposition of, or changes to, tariffs by the United States as well as retaliatory tariffs or measures by other countries, the global economy and financial markets have been volatile in recent periods. As such, the Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.
  (was, 2025-05-06, similarity 0.9994):
[0000950170-25-063937:note_history:3]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflict between Russia and Ukraine as well as other global regions and the imposition of, or changes to, tariffs by the United States as well as retaliatory tariffs or measures by other countries, the global economy and financial markets have been volatile in recent periods. As such, the Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

- added (2025-08-04):
[0000950170-25-102042:note_history:4]
In July 2025, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2025-05, Measurement of Credit Losses for Accounts Receivable and Contract Assets, which provides a practical expedient to measure credit losses on accounts receivable and contract assets. The ASU is effective for annual periods beginning after December 15, 2025, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the timing of the adoption and the impact of this ASU on its consolidated financial statements and related disclosures.

- changed (2025-08-04):
[0000950170-25-102042:note_history:5]
In November 2024, the FASB issued ASU 2024-03, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosure in the notes to the financial statements of specified information about certain costs and expenses. In January 2025, the FASB issued ASU 2025-01, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which amends the effective date of ASU 2024-03 to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027. Early adoption of ASU 2024-03 is permitted. ASU 2024-03 should be applied either prospectively to financial statements issued for reporting periods after the effective date or retrospectively to any or all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.
  (was, 2025-05-06, similarity 0.9604):
[0000950170-25-063937:note_history:5]
In November 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2024-03, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosure in the notes to the financial statements of specified information about certain costs and expenses. In January 2025, the FASB issued ASU 2025-01, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which amends the effective date of ASU 2024-03 to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027. Early adoption of ASU 2024-03 is permitted. ASU 2024-03 should be applied either prospectively to financial statements issued for reporting periods after the effective date or retrospectively to any or all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-04):
[0000950170-25-102042:note_history:6]
|  |  | As of |
|  |  | June 30, 2025 |  | December 30, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 2,989 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 3,362 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,303 |  |  |  | 2,614 |  |  |  | 8.01 |  |  |  |  | 3,589 |  |  |  | 2,840 |  |  |  | 8.01 |  |  |
| Total |  | $ | 6,292 |  |  | $ | 2,614 |  |  |  |  |  |  | $ | 6,951 |  |  | $ | 2,840 |  |  |  |  |  |
  (was, 2025-05-06, similarity 0.9911):
[0000950170-25-063937:note_history:6]
|  |  | As of |
|  |  | March 31, 2025 |  | December 30, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,176 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 3,362 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,449 |  |  |  | 2,727 |  |  |  | 8.01 |  |  |  |  | 3,589 |  |  |  | 2,840 |  |  |  | 8.01 |  |  |
| Total |  | $ | 6,625 |  |  | $ | 2,727 |  |  |  |  |  |  | $ | 6,951 |  |  | $ | 2,840 |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-04):
[0000950170-25-102042:note_history:7]
|  |  | As of |  |
|  |  | June 30, 2025 |  |  | December 30, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 6.57 |  |  |  |  | 343,901 |  |  |  | 6.59 |  |  |  |  | 345,634 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 5.62 |  |  |  |  | 80,000 |  |  |  | 5.64 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 2,149 |  |  |  | 5.99 |  |  |  |  | 2,311 |  |
| Total debt |  |  |  |  |  |  | 926,050 |  |  |  |  |  |  |  | 927,945 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (6,292 | ) |  |  |  |  |  |  | (6,951 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,614 | ) |  |  |  |  |  |  | (2,840 | ) |
| Subtotal |  |  |  |  |  |  | 917,144 |  |  |  |  |  |  |  | 918,154 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,805 | ) |  |  |  |  |  |  | (3,795 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,339 |  |  |  |  |  |  | $ | 914,359 |  |
  (was, 2025-05-06, similarity 0.995):
[0000950170-25-063937:note_history:7]
|  |  | As of |  |
|  |  | March 31, 2025 |  |  | December 30, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 6.57 |  |  |  |  | 344,768 |  |  |  | 6.59 |  |  |  |  | 345,634 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 5.62 |  |  |  |  | 80,000 |  |  |  | 5.64 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 2,230 |  |  |  | 5.99 |  |  |  |  | 2,311 |  |
| Total debt |  |  |  |  |  |  | 926,998 |  |  |  |  |  |  |  | 927,945 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (6,625 | ) |  |  |  |  |  |  | (6,951 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,727 | ) |  |  |  |  |  |  | (2,840 | ) |
| Subtotal |  |  |  |  |  |  | 917,646 |  |  |  |  |  |  |  | 918,154 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,800 | ) |  |  |  |  |  |  | (3,795 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,846 |  |  |  |  |  |  | $ | 914,359 |  |

- changed (2025-08-04):
[0000950170-25-102042:note_history:8]
|  |  | As of |
|  |  | June 30, 2025 |  | December 30, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 2,989 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 3,362 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,303 |  |  |  | 2,614 |  |  |  | 8.01 |  |  |  |  | 3,589 |  |  |  | 2,840 |  |  |  | 8.01 |  |  |
| Total |  | $ | 6,292 |  |  | $ | 2,614 |  |  |  |  |  |  | $ | 6,951 |  |  | $ | 2,840 |  |  |  |  |  |
  (was, 2025-05-06, similarity 0.9911):
[0000950170-25-063937:note_history:8]
|  |  | As of |
|  |  | March 31, 2025 |  | December 30, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,176 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 3,362 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,449 |  |  |  | 2,727 |  |  |  | 8.01 |  |  |  |  | 3,589 |  |  |  | 2,840 |  |  |  | 8.01 |  |  |
| Total |  | $ | 6,625 |  |  | $ | 2,727 |  |  |  |  |  |  | $ | 6,951 |  |  | $ | 2,840 |  |  |  |  |  |

- changed (2025-08-04):
[0000950170-25-102042:note_history:9]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,057 and $1,239 as of June 30, 2025 and December 30, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2025-05-06, similarity 0.9856):
[0000950170-25-063937:note_history:9]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,147 and $1,239 as of March 31, 2025 and December 30, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2025-08-04):
[0000950170-25-102042:note_history:10]
As of June 30, 2025, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 4.3 years.
  (was, 2025-05-06, similarity 0.967):
[0000950170-25-063937:note_history:10]
As of March 31, 2025, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 4.6 years.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-04):
[0000950170-25-102042:note_history:11]
|  |  | As of |  |
|  |  | June 30, 2025 |  |  | December 30, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 6.57 |  |  |  |  | 343,901 |  |  |  | 6.59 |  |  |  |  | 345,634 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 5.62 |  |  |  |  | 80,000 |  |  |  | 5.64 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 2,149 |  |  |  | 5.99 |  |  |  |  | 2,311 |  |
| Total debt |  |  |  |  |  |  | 926,050 |  |  |  |  |  |  |  | 927,945 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (6,292 | ) |  |  |  |  |  |  | (6,951 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,614 | ) |  |  |  |  |  |  | (2,840 | ) |
| Subtotal |  |  |  |  |  |  | 917,144 |  |  |  |  |  |  |  | 918,154 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,805 | ) |  |  |  |  |  |  | (3,795 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,339 |  |  |  |  |  |  | $ | 914,359 |  |
  (was, 2025-05-06, similarity 0.995):
[0000950170-25-063937:note_history:11]
|  |  | As of |  |
|  |  | March 31, 2025 |  |  | December 30, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 6.57 |  |  |  |  | 344,768 |  |  |  | 6.59 |  |  |  |  | 345,634 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 5.62 |  |  |  |  | 80,000 |  |  |  | 5.64 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 2,230 |  |  |  | 5.99 |  |  |  |  | 2,311 |  |
| Total debt |  |  |  |  |  |  | 926,998 |  |  |  |  |  |  |  | 927,945 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (6,625 | ) |  |  |  |  |  |  | (6,951 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,727 | ) |  |  |  |  |  |  | (2,840 | ) |
| Subtotal |  |  |  |  |  |  | 917,646 |  |  |  |  |  |  |  | 918,154 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,800 | ) |  |  |  |  |  |  | (3,795 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,846 |  |  |  |  |  |  | $ | 914,359 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-04):
[0000950170-25-102042:note_history:12]
|  |  | For the Quarter Ended |  |
|  |  | June 30, 2025 |  |  | July 1, 2024 |  |
|  |  | Aerospace and Defense (A&D) |  |  | Commercial |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 325,092 |  |  | $ | — |  |  | $ | — |  |  | $ | 325,092 |  |  | $ | 273,038 |  |  | $ | — |  |  | $ | — |  |  | $ | 273,038 |  |
| Automotive |  |  | — |  |  |  | 81,424 |  |  |  | — |  |  |  | 81,424 |  |  |  | — |  |  |  | 82,635 |  |  |  | — |  |  |  | 82,635 |  |
| Data Center Computing |  |  | — |  |  |  | 148,222 |  |  |  | 279 |  |  |  | 148,501 |  |  |  | — |  |  |  | 123,956 |  |  |  | 63 |  |  |  | 124,019 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 110,571 |  |  |  | 1,009 |  |  |  | 111,580 |  |  |  | — |  |  |  | 86,349 |  |  |  | 722 |  |  |  | 87,071 |  |
| Networking |  |  | — |  |  |  | 55,264 |  |  |  | 8,760 |  |  |  | 64,024 |  |  |  | — |  |  |  | 30,129 |  |  |  | 8,245 |  |  |  | 38,374 |  |
| Total |  | $ | 325,092 |  |  | $ | 395,481 |  |  | $ | 10,048 |  |  | $ | 730,621 |  |  | $ | 273,038 |  |  | $ | 323,069 |  |  | $ | 9,030 |  |  | $ | 605,137 |  |
  (was, 2025-05-06, similarity 0.6633):
[0000950170-25-063937:note_history:12]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2025 |  |  | April 1, 2024 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 305,689 |  |  | $ | — |  |  | $ | 305,689 |  |  | $ | 264,776 |  |  | $ | — |  |  | $ | 264,776 |  |
| Automotive |  |  | 71,678 |  |  |  | — |  |  |  | 71,678 |  |  |  | 73,617 |  |  |  | — |  |  |  | 73,617 |  |
| Data Center Computing |  |  | 137,236 |  |  |  | 667 |  |  |  | 137,903 |  |  |  | 119,377 |  |  |  | 59 |  |  |  | 119,436 |  |
| Medical/Industrial/Instrumentation |  |  | 82,293 |  |  |  | 909 |  |  |  | 83,202 |  |  |  | 78,793 |  |  |  | 734 |  |  |  | 79,527 |  |
| Networking |  |  | 42,952 |  |  |  | 7,244 |  |  |  | 50,196 |  |  |  | 25,278 |  |  |  | 7,479 |  |  |  | 32,757 |  |
| Total |  | $ | 639,848 |  |  | $ | 8,820 |  |  | $ | 648,668 |  |  | $ | 561,841 |  |  | $ | 8,272 |  |  | $ | 570,113 |  |

- added (2025-08-04):
[0000950170-25-102042:note_history:13]
|  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2025 |  |  | July 1, 2024 |  |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 632,510 |  |  | $ | — |  |  | $ | — |  |  | $ | 632,510 |  |  | $ | 551,304 |  |  | $ | — |  |  | $ | — |  |  | $ | 551,304 |  |
| Automotive |  |  | — |  |  |  | 152,778 |  |  |  | — |  |  |  | 152,778 |  |  |  | — |  |  |  | 152,908 |  |  |  | — |  |  |  | 152,908 |  |
| Data Center Computing |  |  | — |  |  |  | 284,989 |  |  |  | 946 |  |  |  | 285,935 |  |  |  | — |  |  |  | 237,913 |  |  |  | 122 |  |  |  | 238,035 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 192,108 |  |  |  | 1,918 |  |  |  | 194,026 |  |  |  | — |  |  |  | 161,564 |  |  |  | 1,456 |  |  |  | 163,020 |  |
| Networking |  |  | — |  |  |  | 98,036 |  |  |  | 16,004 |  |  |  | 114,040 |  |  |  | — |  |  |  | 54,259 |  |  |  | 15,724 |  |  |  | 69,983 |  |
| Total |  | $ | 632,510 |  |  | $ | 727,911 |  |  | $ | 18,868 |  |  | $ | 1,379,289 |  |  | $ | 551,304 |  |  | $ | 606,644 |  |  | $ | 17,302 |  |  | $ | 1,175,250 |  |

- added (2025-08-04):
[0000950170-25-102042:note_history:14]
(1)
The end market revenue for the A&D and Commercial reportable segments prior to the quarter ended June 30, 2025 has been recast to reflect certain adjustments to allocations resulting from the segment reorganization. The end market revenue excludes intersegment sales totaling $2,650 and $5,650 for the quarter and two quarters ended June 30, 2025, respectively, and $1,708 and $3,489 for the quarter and two quarters ended July 1, 2024, respectively. See Note 10, Segment Information, for further information.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-04):
[0000950170-25-102042:note_history:15]
As of June 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations for long‑term contracts was $375,733. The Company expects to recognize revenue on approximately 59% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.
  (was, 2025-05-06, similarity 0.9877):
[0000950170-25-063937:note_history:15]
As of March 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations for long‑term contracts was $406,807. The Company expects to recognize revenue on approximately 53% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.

- changed (2025-08-04):
[0000950170-25-102042:note_history:16]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of June 30, 2025 and December 30, 2024 were $32,685 and $36,976, respectively.
  (was, 2025-05-06, similarity 0.9875):
[0000950170-25-063937:note_history:16]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of March 31, 2025 and December 30, 2024 were $37,731 and $36,976, respectively.

- added (2025-08-04):
[0000950170-25-102042:note_history:17]
Revenue recognized for the two quarters ended June 30, 2025 from amounts recorded as contract liabilities as of December 30, 2024 was $54,970. Revenue recognized for the two quarters ended July 1, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $28,205.

- changed (2025-08-04):
[0000950170-25-102042:note_history:18]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and two quarters ended June 30, 2025, and 96% and 4%, respectively, of the Company’s revenue for the quarter and two quarters ended July 1, 2024.
  (was, 2025-05-06, similarity 0.6732):
[0000950170-25-063937:note_history:18]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for both the quarters ended March 31, 2025 and April 1, 2024.

- changed (2025-08-04):
[0000950170-25-102042:note_history:19]
|  |  | For the Quarter Ended |  |
|  |  | June 30, 2025 |  |  | July 1, 2024 |  |
|  |  | Aerospace and Defense (A&D) |  |  | Commercial |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 325,092 |  |  | $ | — |  |  | $ | — |  |  | $ | 325,092 |  |  | $ | 273,038 |  |  | $ | — |  |  | $ | — |  |  | $ | 273,038 |  |
| Automotive |  |  | — |  |  |  | 81,424 |  |  |  | — |  |  |  | 81,424 |  |  |  | — |  |  |  | 82,635 |  |  |  | — |  |  |  | 82,635 |  |
| Data Center Computing |  |  | — |  |  |  | 148,222 |  |  |  | 279 |  |  |  | 148,501 |  |  |  | — |  |  |  | 123,956 |  |  |  | 63 |  |  |  | 124,019 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 110,571 |  |  |  | 1,009 |  |  |  | 111,580 |  |  |  | — |  |  |  | 86,349 |  |  |  | 722 |  |  |  | 87,071 |  |
| Networking |  |  | — |  |  |  | 55,264 |  |  |  | 8,760 |  |  |  | 64,024 |  |  |  | — |  |  |  | 30,129 |  |  |  | 8,245 |  |  |  | 38,374 |  |
| Total |  | $ | 325,092 |  |  | $ | 395,481 |  |  | $ | 10,048 |  |  | $ | 730,621 |  |  | $ | 273,038 |  |  | $ | 323,069 |  |  | $ | 9,030 |  |  | $ | 605,137 |  |
  (was, 2025-05-06, similarity 0.6633):
[0000950170-25-063937:note_history:19]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2025 |  |  | April 1, 2024 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 305,689 |  |  | $ | — |  |  | $ | 305,689 |  |  | $ | 264,776 |  |  | $ | — |  |  | $ | 264,776 |  |
| Automotive |  |  | 71,678 |  |  |  | — |  |  |  | 71,678 |  |  |  | 73,617 |  |  |  | — |  |  |  | 73,617 |  |
| Data Center Computing |  |  | 137,236 |  |  |  | 667 |  |  |  | 137,903 |  |  |  | 119,377 |  |  |  | 59 |  |  |  | 119,436 |  |
| Medical/Industrial/Instrumentation |  |  | 82,293 |  |  |  | 909 |  |  |  | 83,202 |  |  |  | 78,793 |  |  |  | 734 |  |  |  | 79,527 |  |
| Networking |  |  | 42,952 |  |  |  | 7,244 |  |  |  | 50,196 |  |  |  | 25,278 |  |  |  | 7,479 |  |  |  | 32,757 |  |
| Total |  | $ | 639,848 |  |  | $ | 8,820 |  |  | $ | 648,668 |  |  | $ | 561,841 |  |  | $ | 8,272 |  |  | $ | 570,113 |  |

- added (2025-08-04):
[0000950170-25-102042:note_history:20]
|  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2025 |  |  | July 1, 2024 |  |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 632,510 |  |  | $ | — |  |  | $ | — |  |  | $ | 632,510 |  |  | $ | 551,304 |  |  | $ | — |  |  | $ | — |  |  | $ | 551,304 |  |
| Automotive |  |  | — |  |  |  | 152,778 |  |  |  | — |  |  |  | 152,778 |  |  |  | — |  |  |  | 152,908 |  |  |  | — |  |  |  | 152,908 |  |
| Data Center Computing |  |  | — |  |  |  | 284,989 |  |  |  | 946 |  |  |  | 285,935 |  |  |  | — |  |  |  | 237,913 |  |  |  | 122 |  |  |  | 238,035 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 192,108 |  |  |  | 1,918 |  |  |  | 194,026 |  |  |  | — |  |  |  | 161,564 |  |  |  | 1,456 |  |  |  | 163,020 |  |
| Networking |  |  | — |  |  |  | 98,036 |  |  |  | 16,004 |  |  |  | 114,040 |  |  |  | — |  |  |  | 54,259 |  |  |  | 15,724 |  |  |  | 69,983 |  |
| Total |  | $ | 632,510 |  |  | $ | 727,911 |  |  | $ | 18,868 |  |  | $ | 1,379,289 |  |  | $ | 551,304 |  |  | $ | 606,644 |  |  | $ | 17,302 |  |  | $ | 1,175,250 |  |

- added (2025-08-04):
[0000950170-25-102042:note_history:21]
(1)
The end market revenue for the A&D and Commercial reportable segments prior to the quarter ended June 30, 2025 has been recast to reflect certain adjustments to allocations resulting from the segment reorganization. The end market revenue excludes intersegment sales totaling $2,650 and $5,650 for the quarter and two quarters ended June 30, 2025, respectively, and $1,708 and $3,489 for the quarter and two quarters ended July 1, 2024, respectively. See Note 10, Segment Information, for further information.

- removed (2025-08-04):
[0000950170-25-063937:note_history:22]
Revenue recognized for the quarter ended March 31, 2025 from amounts recorded as contract liabilities as of December 30, 2024 was $22,496. Revenue recognized for the quarter ended April 1, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $18,214.
