# TTMI MD&A — 0000950170-25-102042


## mdna

[0000950170-25-102042:mdna:1]
[same as prior period, unchanged from 0000950170-25-063937:mdna:1]

[0000950170-25-102042:mdna:2]
[same as prior period, unchanged from 0000950170-25-063937:mdna:2]

[0000950170-25-102042:mdna:3]
[same as prior period, unchanged from 0000950170-25-063937:mdna:3]

[0000950170-25-102042:mdna:4]
[same as prior period, unchanged from 0000950170-25-063937:mdna:4]

[0000950170-25-102042:mdna:5]
[same as prior period, unchanged from 0000950170-25-063937:mdna:5]

[0000950170-25-102042:mdna:6]
[same as prior period, unchanged from 0000950170-25-063937:mdna:6]

[0000950170-25-102042:mdna:7]
On July 9, 2025, we announced the acquisition of a 750,000-square-foot facility in Eau Claire, Wisconsin, as well as land rights for an additional future manufacturing site in Penang, Malaysia. We believe the Eau Claire, Wisconsin facility comes equipped with the necessary infrastructure to support advanced technology PCB manufacturing and enhances our ability to support future high-volume U.S. production of advanced technology PCBs across key markets, particularly data center computing and networking for generative artificial intelligence (AI) applications. In addition, we acquired land rights for ten acres in Penang to establish a new production site that we anticipate will align with customers’ increasing interests in supply chain diversification beyond China. The future Penang facility will be in close proximity to our existing facility and will enable us to deliver cost-competitive, high-quality advanced technology PCB manufacturing to commercial markets such as data center computing, networking, and medical, industrial, and instrumentation. Together, these new investments support our strategy to offer regionally optimized, globally connected manufacturing solutions for our customers.

[0000950170-25-102042:mdna:8]
We previously announced we are in the process of constructing a new advanced technology PCB manufacturing facility in Syracuse, New York. We expect that our new facility will bring advanced technology capability for our domestic high-volume production of ultra‑high‑density interconnect (HDI) PCBs in support of national security requirements. The external construction of our facility is largely complete and we continue to make progress on the internal fabrication. We have equipment orders in place and, assuming no delays in delivery, expect installation to begin in the third quarter of 2025 with production expected to commence in the second half of 2026.

[0000950170-25-102042:mdna:9]
20

[0000950170-25-102042:mdna:10]
[same as prior period, unchanged from 0000950170-25-063937:mdna:8]

[0000950170-25-102042:mdna:11]
Our customers include both OEMs and EMS providers. We sell to OEMs both directly and indirectly through EMS providers. For such indirect sales, we measure customers based on OEM companies as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 53% and 54% of our net sales for the quarter and two quarters ended June 30, 2025, respectively. Sales to our ten largest customers collectively accounted for 54% of our net sales for both the quarter and two quarters ended July 1, 2024.

[0000950170-25-102042:mdna:12]
[same as prior period, unchanged from 0000950170-25-063937:mdna:10]

[0000950170-25-102042:mdna:13]
|  |  | For the Quarter Ended |  | For the Two Quarters Ended |
|  |  | June 30, 2025 |  | July 1, 2024 (1) |  | June 30, 2025 (1) |  | July 1, 2024 (1) |
| End Markets (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  |  | 45 |  | % |  |  | 45 |  | % |  |  | 47 |  | % |  |  | 47 |  | % |
| Automotive |  |  | 11 |  |  |  |  | 14 |  |  |  |  | 11 |  |  |  |  | 13 |  |  |
| Data Center Computing |  |  | 21 |  |  |  |  | 21 |  |  |  |  | 21 |  |  |  |  | 20 |  |  |
| Medical/Industrial/Instrumentation |  |  | 15 |  |  |  |  | 14 |  |  |  |  | 14 |  |  |  |  | 14 |  |  |
| Networking |  |  | 8 |  |  |  |  | 6 |  |  |  |  | 7 |  |  |  |  | 6 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0000950170-25-102042:mdna:14]
(1)
The end market revenue prior to the quarter ended June 30, 2025 has been recast to reflect certain adjustments to allocations resulting from the segment reorganization.

[0000950170-25-102042:mdna:15]
(2)
Sales to EMS companies are classified by the end markets of their OEM customers.

[0000950170-25-102042:mdna:16]
[same as prior period, unchanged from 0000950170-25-063937:mdna:13]

[0000950170-25-102042:mdna:17]
[same as prior period, unchanged from 0000950170-25-063937:mdna:14]

[0000950170-25-102042:mdna:18]
[same as prior period, unchanged from 0000950170-25-063937:mdna:15]

[0000950170-25-102042:mdna:19]
[same as prior period, unchanged from 0000950170-25-063937:mdna:16]

[0000950170-25-102042:mdna:20]
[same as prior period, unchanged from 0000950170-25-063937:mdna:17]

[0000950170-25-102042:mdna:21]
[same as prior period, unchanged from 0000950170-25-063937:mdna:18]

[0000950170-25-102042:mdna:22]
[same as prior period, unchanged from 0000950170-25-063937:mdna:19]

[0000950170-25-102042:mdna:23]
[same as prior period, unchanged from 0000950170-25-063937:mdna:20]

[0000950170-25-102042:mdna:24]
[same as prior period, unchanged from 0000950170-25-063937:mdna:21]

[0000950170-25-102042:mdna:25]
[same as prior period, unchanged from 0000950170-25-063937:mdna:41]

[0000950170-25-102042:mdna:26]
[same as prior period, unchanged from 0000950170-25-063937:mdna:22]

[0000950170-25-102042:mdna:27]
[same as prior period, unchanged from 0000950170-25-063937:mdna:23]

[0000950170-25-102042:mdna:28]
[same as prior period, unchanged from 0000950170-25-063937:mdna:24]

[0000950170-25-102042:mdna:29]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2025 |  |  | July 1, 2024 |  |  | June 30, 2025 |  |  | July 1, 2024 |  |
|  |  | (In thousands, except margin rates) |  |
| Net sales |  | $ | 730,621 |  |  | $ | 605,137 |  |  | $ | 1,379,289 |  |  | $ | 1,175,250 |  |
| Cost of goods sold |  |  | 582,512 |  |  |  | 487,910 |  |  |  | 1,100,208 |  |  |  | 954,304 |  |
| Gross profit |  |  | 148,109 |  |  |  | 117,227 |  |  |  | 279,081 |  |  |  | 220,946 |  |
| Gross margin |  |  | 20.3 | % |  |  | 19.4 | % |  |  | 20.2 | % |  |  | 18.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 21,316 |  |  |  | 19,798 |  |  |  | 42,587 |  |  |  | 40,092 |  |
| General and administrative |  |  | 49,719 |  |  |  | 38,604 |  |  |  | 93,493 |  |  |  | 82,274 |  |
| Research and development |  |  | 7,009 |  |  |  | 8,547 |  |  |  | 15,073 |  |  |  | 15,868 |  |
| Amortization of definite-lived intangibles |  |  | 6,888 |  |  |  | 10,256 |  |  |  | 13,777 |  |  |  | 21,685 |  |
| Restructuring charges |  |  | 1,408 |  |  |  | 1,036 |  |  |  | 2,122 |  |  |  | 4,974 |  |
| Total operating expenses |  |  | 86,340 |  |  |  | 78,241 |  |  |  | 167,052 |  |  |  | 164,893 |  |
| Operating income |  |  | 61,769 |  |  |  | 38,986 |  |  |  | 112,029 |  |  |  | 56,053 |  |
| Operating margin |  |  | 8.5 | % |  |  | 6.4 | % |  |  | 8.1 | % |  |  | 4.8 | % |
| Total other expense, net |  |  | (16,244 | ) |  |  | (8,454 | ) |  |  | (25,513 | ) |  |  | (11,452 | ) |
| Income tax provision |  |  | (3,995 | ) |  |  | (4,180 | ) |  |  | (12,808 | ) |  |  | (7,783 | ) |
| Net income |  | $ | 41,530 |  |  | $ | 26,352 |  |  | $ | 73,708 |  |  | $ | 36,818 |  |

[0000950170-25-102042:mdna:30]
The following discussion and analysis is for the quarter and two quarters ended June 30, 2025, compared to the quarter and two quarters ended July 1, 2024, unless otherwise stated.

[0000950170-25-102042:mdna:31]
[same as prior period, unchanged from 0000950170-25-063937:mdna:27]

[0000950170-25-102042:mdna:32]
Total net sales increased $125.5 million, or 20.7%, to $730.6 million for the quarter ended June 30, 2025, from $605.1 million for the quarter ended July 1, 2024. The primary driver of this increase was strong demand in our aerospace and defense, data center computing, and networking end markets, the latter two being driven by generative AI. In addition, our medical, industrial, and instrumentation end market was also stronger as inventories and demand have normalized in this end market.

[0000950170-25-102042:mdna:33]
Total net sales increased $204.0 million, or 17.4%, to $1,379.3 million for the two quarters ended June 30, 2025, from $1,175.3 million for the two quarters ended July 1, 2024. The primary drivers of the increase were as discussed in the paragraph above.

[0000950170-25-102042:mdna:34]
[same as prior period, unchanged from 0000950170-25-063937:mdna:29]

[0000950170-25-102042:mdna:35]
Gross profit increased $30.9 million to $148.1 million for the quarter ended June 30, 2025, from $117.2 million for the quarter ended July 1, 2024, primarily due to higher sales. Gross margin rate increased to 20.3% for the quarter ended June 30, 2025, from 19.4% for the quarter ended July 1, 2024. This increase was primarily due to improved operational execution, favorable product mix, and increased volume of PCB shipments as compared to the second quarter of 2024.

[0000950170-25-102042:mdna:36]
Gross profit increased $58.1 million to $279.1 million for the two quarters ended June 30, 2025, from $220.9 million for the two quarters ended July 1, 2024, primarily due to higher sales. Gross margin rate increased to 20.2% for the two quarters ended June 30, 2025, from 18.8% for the two quarters ended July 1, 2024. The increase was primarily due to improved operational execution, favorable product mix, and increased volume of PCB shipments as compared to the same period of 2024.

[0000950170-25-102042:mdna:37]
[same as prior period, unchanged from 0000950170-25-063937:mdna:32]

[0000950170-25-102042:mdna:38]
Operating expenses increased $8.1 million to $86.3 million for the quarter ended June 30, 2025, from $78.2 million for the quarter ended July 1, 2024, primarily due to the absence of gains on the sale of assets primarily related to the sale of two buildings vacated with the closure of our Anaheim and Santa Clara plants of $14.4 million that occurred in the quarter ended July 1, 2024, partially offset by the absence of the write down of our Hong Kong building of $6.1 million that occurred in the quarter ended July 1, 2024. Higher incentive compensation expense also contributed to the increase in operating expenses, partially offset by a decrease in amortization of definite-lived intangibles.

[0000950170-25-102042:mdna:39]
Operating expenses increased $2.2 million to $167.1 million for the two quarters ended June 30, 2025, from $164.9 million for the two quarters ended July 1, 2024, primarily due to the absence of gains on the sale of assets primarily related to the sale of two buildings vacated with the closure of our Anaheim and Santa Clara plants of $14.4 million that occurred in the two quarters ended July 1, 2024, partially offset by the absence of the write down of our Hong Kong building of $6.1 million that occurred in the two quarters ended July 1, 2024. In addition, increased stock-based compensation and incentive compensation expense contributed to the higher operating expenses, partially offset by a decrease in amortization of definite-lived intangibles.

[0000950170-25-102042:mdna:40]
[same as prior period, unchanged from 0000950170-25-063937:mdna:34]

[0000950170-25-102042:mdna:41]
Operating income increased $22.8 million to $61.8 million for the quarter ended June 30, 2025, from $39.0 million for the quarter ended July 1, 2024. Operating margin rate increased to 8.5% for the quarter ended June 30, 2025, from 6.4% for the quarter ended July 1, 2024. The primary drivers of these increases are discussed above in the variance explanations for Gross Profit and Margin Rate and Operating Expenses.

[0000950170-25-102042:mdna:42]
Operating income increased $56.0 million to $112.0 million for the two quarters ended June 30, 2025, from $56.1 million for the two quarters ended July 1, 2024. Operating margin rate increased to 8.1% for the two quarters ended June 30, 2025, from 4.8% for the two quarters ended July 1, 2024. The primary drivers of these increases are discussed above in the variance explanations for Gross Profit and Margin Rate and Operating Expenses.

[0000950170-25-102042:mdna:43]
[same as prior period, unchanged from 0000950170-25-063937:mdna:36]

[0000950170-25-102042:mdna:44]
Total other expense, net increased $7.8 million to $16.2 million for the quarter ended June 30, 2025, from $8.5 million for the quarter ended July 1, 2024, primarily as a result of unrealized foreign exchange losses during the quarter ended June 30, 2025. We utilize the Chinese Renminbi (RMB) and Malaysian Ringgit (MYR) at our China and Malaysia facilities, respectively, for employee‑related and other costs of running our operations in foreign countries. There was an unrealized loss from foreign exchange of $5.7 million during the quarter ended June 30, 2025, compared to $0.1 million during the quarter ended July 1, 2024. This unrealized loss was related to the translation of our China and Malaysia balance sheets from their local currencies into the U.S. dollar functional currency, which experienced devaluation against the RMB and MYR during the quarter ended June 30, 2025 as compared to the quarter ended July 1, 2024.

[0000950170-25-102042:mdna:45]
Total other expense, net increased $14.1 million to $25.5 million for the two quarters ended June 30, 2025, from $11.5 million for the two quarters ended July 1, 2024, primarily as a result of unrealized foreign exchange losses during the two quarters ended June 30, 2025. There was an $8.0 million unrealized loss from foreign exchange during the two quarters ended June 30, 2025, compared to a $4.2 million unrealized gain from foreign exchange during the two quarters ended July 1, 2024. This unrealized loss was related to the translation of our China and Malaysia balance sheets from their local currencies into the U.S. dollar functional currency, which experienced devaluation against the RMB and MYR during the two quarters ended June 30, 2025 as compared to the two quarters ended July 1, 2024.

[0000950170-25-102042:mdna:46]
[same as prior period, unchanged from 0000950170-25-063937:mdna:38]

[0000950170-25-102042:mdna:47]
Income tax expense decreased $0.2 million to $4.0 million for the quarter ended June 30, 2025, from $4.2 million for the quarter ended July 1, 2024, primarily due to an income tax benefit from the deduction of stock-based compensation, partially offset by accruals for potential assessments in various jurisdictions and the finalization of China and Canada corporate income tax returns.

[0000950170-25-102042:mdna:48]
Income tax expense increased $5.0 million to $12.8 million for the two quarters ended June 30, 2025, from $7.8 million for the two quarters ended July 1, 2024, primarily due to an increase in income before income taxes for the two quarters ended June 30, 2025 and accruals for potential assessments in various jurisdictions, partially offset by an income tax benefit from the deduction of stock‑based compensation.

[0000950170-25-102042:mdna:49]
On July 4, 2025, the One Big Beautiful Bill Act (OBBBA) was enacted, introducing amendments to U.S. tax laws with various effective dates from 2025 to 2027. The OBBBA includes provisions such as the permanent extension of certain provisions of the Tax Cuts and Jobs Act that were set to expire at the end of 2025 and modifications to the international tax framework. Income Taxes (Topic 740): Improvements to Income Tax Disclosures requires the effects of changes in tax rates and laws on deferred tax balances to be recognized in the period in which the legislation is enacted. Therefore, our tax provisions for the quarter and two quarters ended June 30, 2025, do not incorporate the effects of these tax law changes. We are in the process of evaluating and estimating the impact of the OBBBA on our consolidated condensed financial statements and will complete our assessment during the third quarter of 2025.

[0000950170-25-102042:mdna:50]
Our effective tax rate is primarily impacted by the mix of foreign and U.S. income, tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax liability of $41.8 million and $42.9 million as of June 30, 2025 and July 1, 2024, respectively.

[0000950170-25-102042:mdna:51]
[same as prior period, unchanged from 0000950170-25-063937:mdna:42]

[0000950170-25-102042:mdna:52]
[same as prior period, unchanged from 0000950170-25-063937:mdna:43]

[0000950170-25-102042:mdna:53]
During the quarter ended June 30, 2025, in connection with our change in organizational structure to enhance clarity in sector performance, accountability, and operating costs, our management finalized its assessment of our operating segments and concluded that we now have three reportable segments: Aerospace and Defense (A&D), Commercial, and RF&S Components. As a result, certain prior period amounts have been reclassified to conform with this new presentation. See Part I, Item 1, Note 10, Segment Information, of the Notes to Consolidated Condensed Financial Statements in this Report for further information.

[0000950170-25-102042:mdna:54]
[same as prior period, unchanged from 0000950170-25-063937:mdna:45]

[0000950170-25-102042:mdna:55]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2025 |  |  | July 1, 2024 |  |  | June 30, 2025 |  |  | July 1, 2024 |  |
|  |  | (In thousands, except margin rates) |  |
| Segment sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| A&D |  | $ | 327,569 |  |  | $ | 274,507 |  |  | $ | 637,712 |  |  | $ | 554,265 |  |
| Commercial |  |  | 395,624 |  |  |  | 323,255 |  |  |  | 728,329 |  |  |  | 607,058 |  |
| RF&S Components |  |  | 10,078 |  |  |  | 9,083 |  |  |  | 18,898 |  |  |  | 17,416 |  |
| Total |  | $ | 733,271 |  |  | $ | 606,845 |  |  | $ | 1,384,939 |  |  | $ | 1,178,739 |  |
| Segment operating income: |  |  |  |  |  |  |  |  |  |  |  |  |
| A&D |  | $ | 45,282 |  |  | $ | 25,500 |  |  | $ | 86,059 |  |  | $ | 59,973 |  |
| Commercial |  |  | 60,069 |  |  |  | 49,670 |  |  |  | 103,718 |  |  |  | 79,753 |  |
| RF&S Components |  |  | 2,863 |  |  |  | 2,052 |  |  |  | 4,455 |  |  |  | 3,713 |  |
| Total |  |  | 108,214 |  |  |  | 77,222 |  |  |  | 194,232 |  |  |  | 143,439 |  |
| Segment operating margin rate: |  |  |  |  |  |  |  |  |  |  |  |  |
| A&D |  |  | 13.8 | % |  |  | 9.3 | % |  |  | 13.5 | % |  |  | 10.8 | % |
| Commercial |  |  | 15.2 | % |  |  | 15.4 | % |  |  | 14.2 | % |  |  | 13.1 | % |
| RF&S Components |  |  | 28.4 | % |  |  | 22.6 | % |  |  | 23.6 | % |  |  | 21.3 | % |
| Total |  |  | 14.8 | % |  |  | 12.7 | % |  |  | 14.0 | % |  |  | 12.2 | % |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  | (1,408 | ) |  |  | (1,036 | ) |  |  | (2,122 | ) |  |  | (4,974 | ) |
| Gain on sale of property, plant, and equipment |  | — |  |  |  | 14,420 |  |  | — |  |  |  | 14,420 |  |
| Acquisition-related and other charges |  | — |  |  |  | (10,184 | ) |  | — |  |  |  | (10,072 | ) |
| Stock-based compensation |  |  | (9,188 | ) |  |  | (6,580 | ) |  |  | (17,975 | ) |  |  | (13,367 | ) |
| Other corporate expenses |  |  | (26,625 | ) |  |  | (22,265 | ) |  |  | (43,658 | ) |  |  | (47,037 | ) |
| Amortization of definite-lived intangibles (1) |  |  | (9,224 | ) |  |  | (12,591 | ) |  |  | (18,448 | ) |  |  | (26,356 | ) |
| Operating income |  | $ | 61,769 |  |  | $ | 38,986 |  |  | $ | 112,029 |  |  | $ | 56,053 |  |

[0000950170-25-102042:mdna:56]
(1)
Amortization of definite-lived intangibles relates to the A&D, Commercial, and RF&S Components reportable segments, but is not reviewed separately by the chief operating decision maker (CODM). For the quarters ended June 30, 2025 and July 1, 2024, amortization expense of $2,336 and $2,335, respectively, is included in cost of goods sold for the A&D reportable segment. For both the two quarters ended June 30, 2025 and July 1, 2024, amortization expense of $4,671 is included in cost of goods sold for the A&D reportable segment.

[0000950170-25-102042:mdna:57]
Segment operating income, as reconciled in Part I, Item 1, Note 10, Segment Information, of the Notes to Consolidated Condensed Financial Statements in this Report, and segment operating margin rate (segment operating income divided by segment sales) are presented in conformity with Accounting Standards Codification (ASC) Topic 280, Segment Reporting. These measures are reported to the CODM, who is the President and Chief Executive Officer, for purposes of making decisions about allocating resources to the segments and assessing their performance. For these reasons, these measures are excluded from the definition of non‑GAAP financial measures under the SEC's Regulation G and Item 10(e) of Regulation S-K.

[0000950170-25-102042:mdna:58]
A&D

[0000950170-25-102042:mdna:59]
Segment Sales

[0000950170-25-102042:mdna:60]
Segment sales for the A&D reportable segment increased $53.1 million, or 19.3%, to $327.6 million for the quarter ended June 30, 2025, from $274.5 million for the quarter ended July 1, 2024. The primary drivers of this increase were improved spending in previous defense budgets, our strong strategic program alignment, and key bookings for ongoing franchise programs, including

[0000950170-25-102042:mdna:61]
restricted programs. These increases were driven by increased sales related to missiles and munitions as well as strong demand in our Mission Systems and Specialty Assembly businesses.

[0000950170-25-102042:mdna:62]
Segment sales for the A&D reportable segment increased $83.4 million, or 15.1%, to $637.7 million for the two quarters ended June 30, 2025, from $554.3 million for the two quarters ended July 1, 2024. The primary drivers of the increase were as discussed in the paragraph above.

[0000950170-25-102042:mdna:63]
[same as prior period, unchanged from 0000950170-25-063937:mdna:50]

[0000950170-25-102042:mdna:64]
Segment operating income for the A&D reportable segment increased $19.8 million to $45.3 million for the quarter ended June 30, 2025, from $25.5 million for the quarter ended July 1, 2024. Segment operating margin rate for the A&D reportable segment increased to 13.8% for the quarter ended June 30, 2025, from 9.3% for the quarter ended July 1, 2024. The primary drivers of these increases were higher sales volume as discussed above, and improved operational execution.

[0000950170-25-102042:mdna:65]
Segment operating income for the A&D reportable segment increased $26.1 million to $86.1 million for the two quarters ended June 30, 2025, from $60.0 million for the two quarters ended July 1, 2024. Segment operating margin rate for the A&D reportable segment increased to 13.5% for the two quarters ended June 30, 2025, from 10.8% for the two quarters ended July 1, 2024. The primary drivers of these increases were higher sales volume as discussed above, and improved operational execution.

[0000950170-25-102042:mdna:66]
Commercial

[0000950170-25-102042:mdna:67]
Segment Sales

[0000950170-25-102042:mdna:68]
Segment sales for the Commercial reportable segment increased $72.4 million, or 22.4%, to $395.6 million for the quarter ended June 30, 2025, from $323.3 million for the quarter ended July 1, 2024. The primary driver of this increase was strong demand in our data center computing and networking end markets driven by generative AI. In addition, our medical, industrial, and instrumentation end market was also stronger as inventories and demand have normalized in this end market with growth in the industrial and instrumentation areas.

[0000950170-25-102042:mdna:69]
Segment sales for the Commercial reportable segment increased $121.3 million, or 20.0%, to $728.3 million for the two quarters ended June 30, 2025, from $607.1 million for the two quarters ended July 1, 2024. The primary driver of this increase was strong demand in our data center computing and networking end markets driven by generative AI, as well as normalized demand in our medical, industrial, and instrumentation end market.

[0000950170-25-102042:mdna:70]
Segment Operating Income and Margin Rate

[0000950170-25-102042:mdna:71]
Segment operating income for the Commercial reportable segment increased $10.4 million to $60.1 million for the quarter ended June 30, 2025, from $49.7 million for the quarter ended July 1, 2024. However, segment operating margin rate for the Commercial reportable segment slightly decreased to 15.2% for the quarter ended June 30, 2025, from 15.4% for the quarter ended July 1, 2024. The primary driver of the increase in segment operating income was higher sales volume as discussed above, while the segment operating margin rate slightly decreased due to ramp-up costs in connection with our fabrication plant in Penang, Malaysia, as well as product mix change.

[0000950170-25-102042:mdna:72]
Segment operating income for the Commercial reportable segment increased $24.0 million to $103.7 million for the two quarters ended June 30, 2025, from $79.8 million for the two quarters ended July 1, 2024. Segment operating margin rate for the Commercial reportable segment increased to 14.2% for the two quarters ended June 30, 2025, from 13.1% for the two quarters ended July 1, 2024. The primary drivers of these increases were higher sales volume as discussed above, and improved operational execution.

[0000950170-25-102042:mdna:73]
RF&S Components

[0000950170-25-102042:mdna:74]
Segment Sales

[0000950170-25-102042:mdna:75]
Segment sales for the RF&S Components reportable segment increased $1.0 million, or 11.0%, to $10.1 million for the quarter ended June 30, 2025, from $9.1 million for the quarter ended July 1, 2024. The primary driver of this increase was strong demand across the networking and medical, industrial, and instrumentation end markets.

[0000950170-25-102042:mdna:76]
Segment sales for the RF&S Components reportable segment increased $1.5 million, or 8.5%, to $18.9 million for the two quarters ended June 30, 2025, from $17.4 million for the two quarters ended July 1, 2024. The primary driver of this increase was strong demand across the networking and medical, industrial, and instrumentation end markets.

[0000950170-25-102042:mdna:77]
Segment Operating Income and Margin Rate

[0000950170-25-102042:mdna:78]
Segment operating income for the RF&S Components reportable segment increased $0.8 million to $2.9 million for the quarter ended June 30, 2025, from $2.1 million for the quarter ended July 1, 2024. Segment operating margin rate for the RF&S Components

[0000950170-25-102042:mdna:79]
reportable segment increased to 28.4% for the quarter ended June 30, 2025, from 22.6% for the quarter ended July 1, 2024. The primary drivers of these increases were higher sales volume as discussed above, and improved operational execution.

[0000950170-25-102042:mdna:80]
Segment operating income for the RF&S Components reportable segment increased $0.7 million to $4.5 million for the two quarters ended June 30, 2025, from $3.7 million for the two quarters ended July 1, 2024. Segment operating margin rate for the RF&S Components reportable segment increased to 23.6% for the two quarters ended June 30, 2025, from 21.3% for the two quarters ended July 1, 2024. The primary drivers of these increases were higher sales volume as discussed above, and improved operational execution.

[0000950170-25-102042:mdna:81]
[same as prior period, unchanged from 0000950170-25-063937:mdna:54]

[0000950170-25-102042:mdna:82]
[same as prior period, unchanged from 0000950170-25-063937:mdna:55]

[0000950170-25-102042:mdna:83]
Cash flow provided by operating activities during the first two quarters of 2025 was $87.1 million as compared to cash flow provided by operating activities of $85.8 million in the same period in 2024. The increase in cash flow was primarily due to an increase in net income of $36.9 million partially offset by increased investment in working capital largely driven by the timing of collections and advance payments and increased inventories related to ramping production levels.

[0000950170-25-102042:mdna:84]
Net cash used in investing activities during the first two quarters of 2025 was $123.5 million, primarily resulting from the use of $123.7 million for net purchases of property, plant, and equipment and other assets. Net cash used in investing activities during the first two quarters of 2024 was approximately $52.5 million, primarily resulting from the use of $88.8 million for purchases of property, plant and equipment and other assets. This was partially offset by the receipt of $29.6 million of proceeds from the sale of property, plant, and equipment and other assets primarily related to the sale of two buildings vacated by the closure of our Anaheim and Santa Clara plants and $6.7 million of proceeds from the sale of property associated with our Shanghai E‑MS subsidiary.

[0000950170-25-102042:mdna:85]
Net cash used in financing activities during the first two quarters of 2025 was $19.8 million, reflecting the use of $17.9 million for repurchases of our common stock and $1.9 million for the repayment of long-term debt borrowings. Net cash used in financing activities during the first two quarters of 2024 was $37.1 million, reflecting the use of $34.5 million for repurchases of common stock and $2.6 million for the repayment of long-term debt borrowings.

[0000950170-25-102042:mdna:86]
As of June 30, 2025, we had cash and cash equivalents of approximately $448.0 million, of which approximately $137.7 million was held by our foreign subsidiaries, primarily in China, and $201.4 million of available borrowing capacity under our revolving credit facilities. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax expenses not previously accrued for the repatriation of this cash.

[0000950170-25-102042:mdna:87]
Our total 2025 capital expenditures are expected to be in the range of $235.0 million to $255.0 million, of which approximately $66.0 million relate to construction of our new plant in Syracuse, New York.

[0000950170-25-102042:mdna:88]
[same as prior period, unchanged from 0000950170-25-063937:mdna:61]

[0000950170-25-102042:mdna:89]
On May 8, 2025, our Board of Directors authorized a new share repurchase program (2025 Repurchase Program), under which we may repurchase up to $100.0 million in value of our common stock from time to time through May 7, 2027. We did not repurchase any shares of our common stock during the quarter ended June 30, 2025. During the two quarters ended June 30, 2025, under our previous two-year repurchase program that expired on May 3, 2025, we repurchased approximately 0.7 million shares of our common stock for a total cost of $17.9 million (including commissions). As of June 30, 2025, the remaining amount in value available to be repurchased under the 2025 Repurchase Program was $100.0 million.

[0000950170-25-102042:mdna:90]
[same as prior period, unchanged from 0000950170-25-063937:mdna:63]

[0000950170-25-102042:mdna:91]
As of June 30, 2025, we had $917.1 million of outstanding debt, net of discount and issuance costs, composed of $497.0 million of Senior Notes due 2029, $338.0 million under the Term Loan Facility due 2030 (Term Loan Facility), $80.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL), and $2.1 million of other loans.

[0000950170-25-102042:mdna:92]
Pursuant to the terms of the Senior Notes due 2029 and Term Loan Facility, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments. Under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of June 30, 2025, we were in compliance with the covenants under the Senior Notes due 2029, Term Loan Facility, and ABL Revolving Loans.

[0000950170-25-102042:mdna:93]
[same as prior period, unchanged from 0000950170-25-063937:mdna:66]

[0000950170-25-102042:mdna:94]
[same as prior period, unchanged from 0000950170-25-063937:mdna:67]

[0000950170-25-102042:mdna:95]
We have agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $12.8 million and $17.2 million as of June 30, 2025 and December 30, 2024, respectively.

[0000950170-25-102042:mdna:96]
[same as prior period, unchanged from 0000950170-25-063937:mdna:69]

[0000950170-25-102042:mdna:97]
As part of our ongoing operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, derivative liabilities, purchase obligations, and leases. As of June 30, 2025, there were no material changes outside the ordinary course of business since December 30, 2024 to our contractual obligations and commitments and the related cash requirements.

[0000950170-25-102042:mdna:98]
[same as prior period, unchanged from 0000950170-25-063937:mdna:71]

[0000950170-25-102042:mdna:99]
[same as prior period, unchanged from 0000950170-25-063937:mdna:72]

[0000950170-25-102042:mdna:100]
Recently Issued Accounting Standards

[0000950170-25-102042:mdna:101]
[same as prior period, unchanged from 0000950170-25-063937:mdna:74]
