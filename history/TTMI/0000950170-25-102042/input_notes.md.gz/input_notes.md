# TTMI notes — 0000950170-25-102042


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000950170-25-102042:notes:1]
[same as prior period, unchanged from 0000950170-25-063937:notes:1]

[0000950170-25-102042:notes:2]
[same as prior period, unchanged from 0000950170-25-063937:notes:2]

[0000950170-25-102042:notes:3]
[same as prior period, unchanged from 0000950170-25-063937:notes:3]

[0000950170-25-102042:notes:4]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflicts between Russia and Ukraine, as well as other global regions and the imposition of, or changes to, tariffs by the United States as well as retaliatory tariffs or measures by other countries, the global economy and financial markets have been volatile in recent periods. As such, the Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

[0000950170-25-102042:notes:5]
Recently Issued Accounting Standards Not Yet Adopted

[0000950170-25-102042:notes:6]
In July 2025, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2025-05, Measurement of Credit Losses for Accounts Receivable and Contract Assets, which provides a practical expedient to measure credit losses on accounts receivable and contract assets. The ASU is effective for annual periods beginning after December 15, 2025, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the timing of the adoption and the impact of this ASU on its consolidated financial statements and related disclosures.

[0000950170-25-102042:notes:7]
In November 2024, the FASB issued ASU 2024-03, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosure in the notes to the financial statements of specified information about certain costs and expenses. In January 2025, the FASB issued ASU 2025-01, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which amends the effective date of ASU 2024-03 to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027. Early adoption of ASU 2024-03 is permitted. ASU 2024-03 should be applied either prospectively to financial statements issued for reporting periods after the effective date or retrospectively to any or all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

[0000950170-25-102042:notes:8]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. The update will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted for annual financial statements not yet issued or made available for issuance. The Company will adopt ASU 2023-09 in its 2025 fiscal year Form 10-K. This ASU will impact only the Company's disclosures with no impacts to the results of operations, cash flows, and financial condition.


## us-gaap:TreasuryStockTextBlock

[0000950170-25-102042:notes:9]
[same as prior period, unchanged from 0000950170-25-063937:notes:8]

[0000950170-25-102042:notes:10]
On May 8, 2025, the Company's Board of Directors authorized a new share repurchase program (2025 Repurchase Program), under which the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through May 7, 2027. The Company’s previous two-year repurchase program expired on May 3, 2025. The Company may repurchase shares through open market purchases, privately‑negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (Exchange Act), which sets certain restrictions on the method, timing, price, and volume of open market stock repurchases. In addition, the Company adopted one trading plan in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price, and amount of any repurchases will be determined at the Company’s discretion, and the share repurchase program may be suspended, terminated, or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.

[0000950170-25-102042:notes:11]
During the quarter ended June 30, 2025, the Company did not repurchase any shares. During the two quarters ended June 30, 2025, the Company repurchased 700 shares of common stock for a total cost of $17,875 (including commissions) under the Company’s previous repurchase program. As of June 30, 2025, the remaining amount in value available to be repurchased under the 2025 Repurchase Program was $100,000.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-25-102042:notes:12]
[same as prior period, unchanged from 0000950170-25-063937:notes:12]

[0000950170-25-102042:notes:13]
[same as prior period, unchanged from 0000950170-25-063937:notes:13]

[0000950170-25-102042:notes:14]
The Company had cash and cash equivalents held by its foreign subsidiaries of $137,730 and $207,909 as of June 30, 2025 and December 30, 2024, respectively. The Company maintains its cash and cash equivalents with major financial institutions and such balances exceed Federal Deposit Insurance Corporation insurance limits. The Company has not experienced any losses in such accounts and believes it is not exposed to any significant risk on cash and cash equivalents.

[0000950170-25-102042:notes:15]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. As of June 30, 2025, one customer accounted for 11% of the Company's accounts receivable. There were no customers that accounted for 10% or more of the Company's accounts receivable as of December 30, 2024.

[0000950170-25-102042:notes:16]
[same as prior period, unchanged from 0000950170-25-063937:notes:16]

[0000950170-25-102042:notes:17]
For the quarter and two quarters ended June 30, 2025, one customer accounted for approximately 12% of the Company's net sales. For the quarter and two quarters ended July 1, 2024, one customer accounted for approximately 11% of the Company's net sales.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-25-102042:notes:18]
[same as prior period, unchanged from 0000950170-25-063937:notes:18]

[0000950170-25-102042:notes:19]
As of June 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations for long‑term contracts was $375,733. The Company expects to recognize revenue on approximately 59% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.

[0000950170-25-102042:notes:20]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of June 30, 2025 and December 30, 2024 were $32,685 and $36,976, respectively.

[0000950170-25-102042:notes:21]
Revenue recognized for the two quarters ended June 30, 2025 from amounts recorded as contract liabilities as of December 30, 2024 was $54,970. Revenue recognized for the two quarters ended July 1, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $28,205.

[0000950170-25-102042:notes:22]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and two quarters ended June 30, 2025, and 96% and 4%, respectively, of the Company’s revenue for the quarter and two quarters ended July 1, 2024.

[0000950170-25-102042:notes:23]
[same as prior period, unchanged from 0000950170-25-063937:notes:23]

[0000950170-25-102042:notes:24]
|  |  | For the Quarter Ended |  |
|  |  | June 30, 2025 |  |  | July 1, 2024 |  |
|  |  | Aerospace and Defense (A&D) |  |  | Commercial |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 325,092 |  |  | $ | — |  |  | $ | — |  |  | $ | 325,092 |  |  | $ | 273,038 |  |  | $ | — |  |  | $ | — |  |  | $ | 273,038 |  |
| Automotive |  |  | — |  |  |  | 81,424 |  |  |  | — |  |  |  | 81,424 |  |  |  | — |  |  |  | 82,635 |  |  |  | — |  |  |  | 82,635 |  |
| Data Center Computing |  |  | — |  |  |  | 148,222 |  |  |  | 279 |  |  |  | 148,501 |  |  |  | — |  |  |  | 123,956 |  |  |  | 63 |  |  |  | 124,019 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 110,571 |  |  |  | 1,009 |  |  |  | 111,580 |  |  |  | — |  |  |  | 86,349 |  |  |  | 722 |  |  |  | 87,071 |  |
| Networking |  |  | — |  |  |  | 55,264 |  |  |  | 8,760 |  |  |  | 64,024 |  |  |  | — |  |  |  | 30,129 |  |  |  | 8,245 |  |  |  | 38,374 |  |
| Total |  | $ | 325,092 |  |  | $ | 395,481 |  |  | $ | 10,048 |  |  | $ | 730,621 |  |  | $ | 273,038 |  |  | $ | 323,069 |  |  | $ | 9,030 |  |  | $ | 605,137 |  |

[0000950170-25-102042:notes:25]
|  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2025 |  |  | July 1, 2024 |  |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 632,510 |  |  | $ | — |  |  | $ | — |  |  | $ | 632,510 |  |  | $ | 551,304 |  |  | $ | — |  |  | $ | — |  |  | $ | 551,304 |  |
| Automotive |  |  | — |  |  |  | 152,778 |  |  |  | — |  |  |  | 152,778 |  |  |  | — |  |  |  | 152,908 |  |  |  | — |  |  |  | 152,908 |  |
| Data Center Computing |  |  | — |  |  |  | 284,989 |  |  |  | 946 |  |  |  | 285,935 |  |  |  | — |  |  |  | 237,913 |  |  |  | 122 |  |  |  | 238,035 |  |
| Medical/Industrial/Instrumentation |  |  | — |  |  |  | 192,108 |  |  |  | 1,918 |  |  |  | 194,026 |  |  |  | — |  |  |  | 161,564 |  |  |  | 1,456 |  |  |  | 163,020 |  |
| Networking |  |  | — |  |  |  | 98,036 |  |  |  | 16,004 |  |  |  | 114,040 |  |  |  | — |  |  |  | 54,259 |  |  |  | 15,724 |  |  |  | 69,983 |  |
| Total |  | $ | 632,510 |  |  | $ | 727,911 |  |  | $ | 18,868 |  |  | $ | 1,379,289 |  |  | $ | 551,304 |  |  | $ | 606,644 |  |  | $ | 17,302 |  |  | $ | 1,175,250 |  |

[0000950170-25-102042:notes:26]
(1)
The end market revenue for the A&D and Commercial reportable segments prior to the quarter ended June 30, 2025 has been recast to reflect certain adjustments to allocations resulting from the segment reorganization. The end market revenue excludes intersegment sales totaling $2,650 and $5,650 for the quarter and two quarters ended June 30, 2025, respectively, and $1,708 and $3,489 for the quarter and two quarters ended July 1, 2024, respectively. See Note 10, Segment Information, for further information.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000950170-25-102042:notes:27]
[same as prior period, unchanged from 0000950170-25-063937:notes:25]

[0000950170-25-102042:notes:28]
|  |  | As of |  |
|  |  | June 30, 2025 |  |  | December 30, 2024 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 193,032 |  |  | $ | 178,066 |  |
| Work-in-process |  |  | 51,611 |  |  |  | 45,580 |  |
| Finished goods |  |  | 5,696 |  |  |  | 1,339 |  |
| Inventories |  | $ | 250,339 |  |  | $ | 224,985 |  |
| Property, plant, and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 68,098 |  |  | $ | 69,788 |  |
| Buildings and improvements |  |  | 526,374 |  |  |  | 515,773 |  |
| Machinery and equipment |  |  | 1,155,847 |  |  |  | 1,116,658 |  |
| Furniture and fixtures and other |  |  | 11,418 |  |  |  | 11,115 |  |
| Construction-in-progress |  |  | 116,126 |  |  |  | 75,502 |  |
| Property, plant, and equipment, gross |  |  | 1,877,863 |  |  |  | 1,788,836 |  |
| Less: Accumulated depreciation |  |  | (958,644 | ) |  |  | (918,879 | ) |
| Property, plant, and equipment, net |  | $ | 919,219 |  |  | $ | 869,957 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | $ | 13,185 |  |  | $ | 15,919 |  |
| Sales return and allowances |  |  | 12,256 |  |  |  | 10,777 |  |
| Warranty |  |  | 11,412 |  |  |  | 7,685 |  |
| Accrued facility operating costs |  |  | 10,857 |  |  |  | 8,925 |  |
| Interest |  |  | 8,569 |  |  |  | 9,054 |  |
| Housing fund |  |  | 8,344 |  |  |  | 7,927 |  |
| Operating leases |  |  | 8,296 |  |  |  | 7,556 |  |
| Accrued professional fees |  |  | 3,624 |  |  |  | 3,606 |  |
| Other |  |  | 35,295 |  |  |  | 48,525 |  |
| Other current liabilities |  | $ | 111,838 |  |  | $ | 119,974 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 42,756 |  |  | $ | 41,362 |  |
| Customer deposits |  |  | 28,390 |  |  |  | 28,390 |  |
| Finance leases |  |  | 16,183 |  |  |  | 11,985 |  |
| Other |  |  | 26,630 |  |  |  | 26,011 |  |
| Other long-term liabilities |  | $ | 113,959 |  |  | $ | 107,748 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-25-102042:notes:29]
[same as prior period, unchanged from 0000950170-25-063937:notes:27]

[0000950170-25-102042:notes:30]
In connection with the Company’s assessment of its operating segments, effective during the quarter ended June 30, 2025, the Company determined that its operating segments were also its reporting units and reallocated its PCB goodwill between A&D and Commercial based on the estimated relative fair values of the reporting units. In addition, management performed a goodwill impairment assessment for each segment and concluded no impairment indicators as of June 30, 2025.

[0000950170-25-102042:notes:31]
[same as prior period, unchanged from 0000950170-25-063937:notes:28]

[0000950170-25-102042:notes:32]
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| As of June 30, 2025 and December 30, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 256,199 |  |  | $ | 382,636 |  |  | $ | 177,200 |  |  | $ | 816,035 |  |
| Accumulated impairment losses |  |  | — |  |  |  | — |  |  |  | (145,900 | ) |  |  | (145,900 | ) |
| Carrying amount |  | $ | 256,199 |  |  | $ | 382,636 |  |  | $ | 31,300 |  |  | $ | 670,135 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-25-102042:notes:33]
[same as prior period, unchanged from 0000950170-25-063937:notes:30]

[0000950170-25-102042:notes:34]
[same as prior period, unchanged from 0000950170-25-063937:notes:31]

[0000950170-25-102042:notes:35]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| As of June 30, 2025 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 323,500 |  |  | $ | (175,487 | ) |  | $ | 148,013 |  |  |  | 11.8 |  |
| Technology |  |  | 66,650 |  |  |  | (41,292 | ) |  |  | 25,358 |  |  |  | 8.2 |  |
| Total |  | $ | 390,150 |  |  | $ | (216,779 | ) |  | $ | 173,371 |  |  |  |  |
| As of December 30, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 323,500 |  |  | $ | (161,710 | ) |  | $ | 161,790 |  |  |  | 11.8 |  |
| Technology |  |  | 66,650 |  |  |  | (36,621 | ) |  |  | 30,029 |  |  |  | 8.2 |  |
| Total |  | $ | 390,150 |  |  | $ | (198,331 | ) |  | $ | 191,819 |  |  |  |  |

[0000950170-25-102042:notes:36]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $9,224 and $18,448 for the quarter and two quarters ended June 30, 2025, respectively, and $12,591 and $26,356 for the quarter and two quarters ended July 1, 2024, respectively. For the quarters ended June 30, 2025 and July 1, 2024, $2,336 and $2,335, respectively, of amortization expense was included in cost of goods sold. For both the two quarters ended June 30, 2025 and July 1, 2024, $4,671 of amortization expense was included in cost of goods sold.

[0000950170-25-102042:notes:37]
[same as prior period, unchanged from 0000950170-25-063937:notes:34]

[0000950170-25-102042:notes:38]
|  |  | (In thousands) |  |
| Remaining 2025 |  | $ | 18,449 |  |
| 2026 |  |  | 36,897 |  |
| 2027 |  |  | 34,543 |  |
| 2028 |  |  | 30,997 |  |
| 2029 |  |  | 22,355 |  |
| Thereafter |  |  | 30,130 |  |
| Total |  | $ | 173,371 |  |


## us-gaap:LongTermDebtTextBlock

[0000950170-25-102042:notes:39]
(8) Long-term Debt and Letters of Credit

[0000950170-25-102042:notes:40]
Long-term debt was as follows:

[0000950170-25-102042:notes:41]
|  |  | As of |  |
|  |  | June 30, 2025 |  |  | December 30, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 6.57 |  |  |  |  | 343,901 |  |  |  | 6.59 |  |  |  |  | 345,634 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 5.62 |  |  |  |  | 80,000 |  |  |  | 5.64 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 2,149 |  |  |  | 5.99 |  |  |  |  | 2,311 |  |
| Total debt |  |  |  |  |  |  | 926,050 |  |  |  |  |  |  |  | 927,945 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (6,292 | ) |  |  |  |  |  |  | (6,951 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,614 | ) |  |  |  |  |  |  | (2,840 | ) |
| Subtotal |  |  |  |  |  |  | 917,144 |  |  |  |  |  |  |  | 918,154 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,805 | ) |  |  |  |  |  |  | (3,795 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,339 |  |  |  |  |  |  | $ | 914,359 |  |

[0000950170-25-102042:notes:42]
Debt Covenants

[0000950170-25-102042:notes:43]
Borrowings under the Senior Notes due 2029 and Term Loan Facility due 2030 (Term Loan Facility) are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

[0000950170-25-102042:notes:44]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans) are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0000950170-25-102042:notes:45]
Debt Issuance Costs and Debt Discount

[0000950170-25-102042:notes:46]
Remaining unamortized debt issuance costs and debt discount were as follows:

[0000950170-25-102042:notes:47]
|  |  | As of |
|  |  | June 30, 2025 |  | December 30, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 2,989 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 3,362 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,303 |  |  |  | 2,614 |  |  |  | 8.01 |  |  |  |  | 3,589 |  |  |  | 2,840 |  |  |  | 8.01 |  |  |
| Total |  | $ | 6,292 |  |  | $ | 2,614 |  |  |  |  |  |  | $ | 6,951 |  |  | $ | 2,840 |  |  |  |  |  |

[0000950170-25-102042:notes:48]
The above debt issuance costs and debt discount are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0000950170-25-102042:notes:49]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,057 and $1,239 as of June 30, 2025 and December 30, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0000950170-25-102042:notes:50]
As of June 30, 2025, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 4.3 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-25-102042:notes:51]
[same as prior period, unchanged from 0000950170-25-063937:notes:48]

[0000950170-25-102042:notes:52]
[same as prior period, unchanged from 0000950170-25-063937:notes:49]

[0000950170-25-102042:notes:53]
During the quarter and two quarters ended June 30, 2025, the Company’s effective tax rate was impacted by a net discrete benefit of $4,166 and $3,284, respectively. This was primarily related to income tax benefits from the deduction of stock‑based compensation and the release of uncertain tax positions due to the expiration of the statute of limitations in certain foreign jurisdiction, partially offset by accruals for potential assessments in various jurisdictions and the finalization of China and Canada corporate income tax returns.

[0000950170-25-102042:notes:54]
[same as prior period, unchanged from 0000950170-25-063937:notes:51]

[0000950170-25-102042:notes:55]
One Big Beautiful Bill Act (OBBBA)

[0000950170-25-102042:notes:56]
On July 4, 2025, the OBBBA was enacted, introducing amendments to U.S. tax laws with various effective dates from 2025 to 2027. The OBBBA includes provisions such as the permanent extension of certain provisions of the Tax Cuts and Jobs Act that were set to expire at the end of 2025 and modifications to the international tax framework. Topic 740 requires the effects of changes in tax rates and laws on deferred tax balances to be recognized in the period in which the legislation is enacted. Therefore, the Company’s tax provisions for the quarter and two quarters ended June 30, 2025, do not incorporate the effects of these tax law changes. The Company is in the process of evaluating and estimating the impact of the OBBBA on its consolidated condensed financial statements and will complete its assessment during the third quarter of 2025.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-25-102042:notes:57]
[same as prior period, unchanged from 0000950170-25-063937:notes:52]

[0000950170-25-102042:notes:58]
During the quarter ended June 30, 2025, in connection with the Company's change in organizational structure to enhance clarity in sector performance, accountability, and operating costs, the Company’s management finalized its assessment of the Company's operating segments and concluded that the Company now has three reportable segments: A&D, Commercial, and RF&S Components. In prior periods, the Company had two reportable segments: PCB and RF&S Components. As a result, certain prior period amounts have been reclassified to conform with this new presentation.

[0000950170-25-102042:notes:59]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker (CODM), who is the President and Chief Executive Officer, to assess performance and to allocate resources. The CODM uses segment operating income to allocate resources such as employees and capital resources for each segment during the Company’s annual budgeting and forecasting process. Total sales and operating profit by segment include intersegment sales which are generally recorded at cost-plus a specified fee or at a negotiated fixed price. Separate segment asset measures are not used as a basis for the CODM to evaluate the performance of or to allocate resources to the segments.

[0000950170-25-102042:notes:60]
The A&D reportable segment consists of PCBs, value-added assemblies, microelectronics, RF/microwave components and assemblies, and integrated mission systems. These highly engineered electronics products include the manufacture and test of customer‑supplied designs as well as long-term contracts to design, develop, manufacture, and test new products. The products in the A&D reportable segment support surveillance, intelligence, communications, and other critical missions for customers in the aerospace and defense industry. The Commercial reportable segment consists of PCBs using customer-supplied engineering and design plans supporting customers in the automotive, medical, industrial, and instrumentation, networking, and data center computing end markets. The RF&S Components reportable segment consists of TTM designed RF components for commercial customers in the telecommunications, industrial and instrumentation markets, as well as commercial off-the-shelf (COTS) components for certain aerospace and defense customers.

[0000950170-25-102042:notes:61]
[same as prior period, unchanged from 0000950170-25-063937:notes:56]

[0000950170-25-102042:notes:62]
|  |  | For the Quarter Ended June 30, 2025 |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Eliminations |  |  | Total |
|  |  | (In thousands, except margin rates) |
| Net sales |  | $ | 325,092 |  |  | $ | 395,481 |  |  | $ | 10,048 |  |  | $ | — |  |  | $ | 730,621 |  |  |
| Intersegment sales |  |  | 2,477 |  |  |  | 143 |  |  |  | 30 |  |  |  | (2,650 | ) |  |  | — |  |  |
| Segment sales |  | $ | 327,569 |  |  | $ | 395,624 |  |  | $ | 10,078 |  |  | $ | (2,650 | ) |  | $ | 730,621 |  |  |
|  |  | Net Sales |  |  | Cost of Goods Sold |  |  | Operating Expenses |  |  | Operating Income |  |  | Operating Margin |
| A&D |  | $ | 327,569 |  |  | $ | (251,046 | ) |  | $ | (31,241 | ) |  | $ | 45,282 |  |  |  | 13.8 |  | % |
| Commercial |  |  | 395,624 |  |  |  | (317,652 | ) |  |  | (17,903 | ) |  |  | 60,069 |  |  |  | 15.2 |  |  |
| RF&S Components |  |  | 10,078 |  |  |  | (4,855 | ) |  |  | (2,360 | ) |  |  | 2,863 |  |  |  | 28.4 |  |  |
| Total segment |  |  | 733,271 |  |  |  | (573,553 | ) |  |  | (51,504 | ) |  |  | 108,214 |  |  |  | 14.8 |  |  |
| Eliminations |  |  | (2,650 | ) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  |  |  |  | (1,408 | ) |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  |  |  |  | (9,188 | ) |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  |  |  |  |  |  | (26,625 | ) |  |  |  |  |
| Amortization of definite-lived intangibles (1) |  |  |  |  |  |  |  |  |  |  |  | (9,224 | ) |  |  |  |  |
| Consolidated |  | $ | 730,621 |  |  |  |  |  |  |  |  |  | 61,769 |  |  |  | 8.5 |  | % |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  | (11,095 | ) |  |  |  |  |
| Other, net |  |  |  |  |  |  |  |  |  |  |  | (5,149 | ) |  |  |  |  |
| Income before income taxes |  |  |  |  |  |  |  |  |  |  | $ | 45,525 |  |  |  |  |  |

[0000950170-25-102042:notes:63]
|  |  | For the Quarter Ended July 1, 2024 |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Eliminations |  |  | Total |
|  |  | (In thousands, except margin rates) |
| Net sales |  | $ | 273,038 |  |  | $ | 323,069 |  |  | $ | 9,030 |  |  | $ | — |  |  | $ | 605,137 |  |  |
| Intersegment sales |  |  | 1,469 |  |  |  | 186 |  |  |  | 53 |  |  |  | (1,708 | ) |  |  | — |  |  |
| Segment sales |  | $ | 274,507 |  |  | $ | 323,255 |  |  | $ | 9,083 |  |  | $ | (1,708 | ) |  | $ | 605,137 |  |  |
|  |  | Net Sales |  |  | Cost of Goods Sold |  |  | Operating Expenses |  |  | Operating Income |  |  | Operating Margin |
| A&D |  | $ | 274,507 |  |  | $ | (220,647 | ) |  | $ | (28,360 | ) |  | $ | 25,500 |  |  |  | 9.3 |  | % |
| Commercial |  |  | 323,255 |  |  |  | (256,244 | ) |  |  | (17,341 | ) |  |  | 49,670 |  |  |  | 15.4 |  |  |
| RF&S Components |  |  | 9,083 |  |  |  | (4,586 | ) |  |  | (2,445 | ) |  |  | 2,052 |  |  |  | 22.6 |  |  |
| Total segment |  |  | 606,845 |  |  |  | (481,477 | ) |  |  | (48,146 | ) |  |  | 77,222 |  |  |  | 12.7 |  |  |
| Eliminations |  |  | (1,708 | ) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  |  |  |  | (1,036 | ) |  |  |  |  |
| Gain on sale of property, plant, and equipment |  |  |  |  |  |  |  |  |  |  |  | 14,420 |  |  |  |  |  |
| Acquisition-related and other charges |  |  |  |  |  |  |  |  |  |  |  | (10,184 | ) |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  |  |  |  | (6,580 | ) |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  |  |  |  |  |  | (22,265 | ) |  |  |  |  |
| Amortization of definite-lived intangibles (1) |  |  |  |  |  |  |  |  |  |  |  | (12,591 | ) |  |  |  |  |
| Consolidated |  | $ | 605,137 |  |  |  |  |  |  |  |  |  | 38,986 |  |  |  | 6.4 |  | % |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  | (12,219 | ) |  |  |  |  |
| Other, net |  |  |  |  |  |  |  |  |  |  |  | 3,765 |  |  |  |  |  |
| Income before income taxes |  |  |  |  |  |  |  |  |  |  | $ | 30,532 |  |  |  |  |  |

[0000950170-25-102042:notes:64]
|  |  | For the Two Quarters Ended June 30, 2025 |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Eliminations |  |  | Total |
|  |  | (In thousands, except margin rates) |
| Net sales |  | $ | 632,510 |  |  | $ | 727,911 |  |  | $ | 18,868 |  |  | $ | — |  |  | $ | 1,379,289 |  |  |
| Intersegment sales |  |  | 5,202 |  |  |  | 418 |  |  |  | 30 |  |  |  | (5,650 | ) |  |  | — |  |  |
| Segment sales |  | $ | 637,712 |  |  | $ | 728,329 |  |  | $ | 18,898 |  |  | $ | (5,650 | ) |  | $ | 1,379,289 |  |  |
|  |  | Net Sales |  |  | Cost of Goods Sold |  |  | Operating Expenses |  |  | Operating Income |  |  | Operating Margin |
| A&D |  | $ | 637,712 |  |  | $ | (489,975 | ) |  | $ | (61,678 | ) |  | $ | 86,059 |  |  |  | 13.5 |  | % |
| Commercial |  |  | 728,329 |  |  |  | (586,737 | ) |  |  | (37,874 | ) |  |  | 103,718 |  |  |  | 14.2 |  |  |
| RF&S Components |  |  | 18,898 |  |  |  | (9,633 | ) |  |  | (4,810 | ) |  |  | 4,455 |  |  |  | 23.6 |  |  |
| Total segment |  |  | 1,384,939 |  |  |  | (1,086,345 | ) |  |  | (104,362 | ) |  |  | 194,232 |  |  |  | 14.0 |  |  |
| Eliminations |  |  | (5,650 | ) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  |  |  |  | (2,122 | ) |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  |  |  |  | (17,975 | ) |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  |  |  |  |  |  | (43,658 | ) |  |  |  |  |
| Amortization of definite-lived intangibles (1) |  |  |  |  |  |  |  |  |  |  |  | (18,448 | ) |  |  |  |  |
| Consolidated |  | $ | 1,379,289 |  |  |  |  |  |  |  |  |  | 112,029 |  |  |  | 8.1 |  | % |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  | (22,559 | ) |  |  |  |  |
| Other, net |  |  |  |  |  |  |  |  |  |  |  | (2,954 | ) |  |  |  |  |
| Income before income taxes |  |  |  |  |  |  |  |  |  |  | $ | 86,516 |  |  |  |  |  |

[0000950170-25-102042:notes:65]
|  |  | For the Two Quarters Ended July 1, 2024 |
|  |  | A&D |  |  | Commercial |  |  | RF&S Components |  |  | Eliminations |  |  | Total |
|  |  | (In thousands, except margin rates) |
| Net sales |  | $ | 551,304 |  |  | $ | 606,644 |  |  | $ | 17,302 |  |  | $ | — |  |  | $ | 1,175,250 |  |  |
| Intersegment sales |  |  | 2,961 |  |  |  | 414 |  |  |  | 114 |  |  |  | (3,489 | ) |  |  | — |  |  |
| Segment sales |  | $ | 554,265 |  |  | $ | 607,058 |  |  | $ | 17,416 |  |  | $ | (3,489 | ) |  | $ | 1,175,250 |  |  |
|  |  | Net Sales |  |  | Cost of Goods Sold |  |  | Operating Expenses |  |  | Operating Income |  |  | Operating Margin |
| A&D |  | $ | 554,265 |  |  | $ | (437,347 | ) |  | $ | (56,945 | ) |  | $ | 59,973 |  |  |  | 10.8 |  | % |
| Commercial |  |  | 607,058 |  |  |  | (493,084 | ) |  |  | (34,221 | ) |  |  | 79,753 |  |  |  | 13.1 |  |  |
| RF&S Components |  |  | 17,416 |  |  |  | (8,990 | ) |  |  | (4,713 | ) |  |  | 3,713 |  |  |  | 21.3 |  |  |
| Total segment |  |  | 1,178,739 |  |  |  | (939,421 | ) |  |  | (95,879 | ) |  |  | 143,439 |  |  |  | 12.2 |  |  |
| Eliminations |  |  | (3,489 | ) |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  |  |  |  | (4,974 | ) |  |  |  |  |
| Gain on sale of property, plant, and equipment |  |  |  |  |  |  |  |  |  |  |  | 14,420 |  |  |  |  |  |
| Acquisition-related and other charges |  |  |  |  |  |  |  |  |  |  |  | (10,072 | ) |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  |  |  |  | (13,367 | ) |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  |  |  |  |  |  | (47,037 | ) |  |  |  |  |
| Amortization of definite-lived intangibles (1) |  |  |  |  |  |  |  |  |  |  |  | (26,356 | ) |  |  |  |  |
| Consolidated |  | $ | 1,175,250 |  |  |  |  |  |  |  |  |  | 56,053 |  |  |  | 4.8 |  | % |
| Interest expense |  |  |  |  |  |  |  |  |  |  |  | (24,543 | ) |  |  |  |  |
| Other, net |  |  |  |  |  |  |  |  |  |  |  | 13,091 |  |  |  |  |  |
| Income before income taxes |  |  |  |  |  |  |  |  |  |  | $ | 44,601 |  |  |  |  |  |

[0000950170-25-102042:notes:66]
(1)
Amortization of definite-lived intangibles relates to the A&D, Commercial, and RF&S Components reportable segments, but is not reviewed separately by the CODM. For the quarters ended June 30, 2025 and July 1, 2024, amortization expense of $2,336 and $2,335, respectively, is included in cost of goods sold for the A&D reportable segment. For both the two quarters ended June 30, 2025 and July 1, 2024, amortization expense of $4,671 is included in cost of goods sold for the A&D reportable segment.

[0000950170-25-102042:notes:67]
[same as prior period, unchanged from 0000950170-25-063937:notes:60]

[0000950170-25-102042:notes:68]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2025 |  |  | July 1, 2024 |  |  | June 30, 2025 |  |  | July 1, 2024 |  |
|  |  | (In thousands) |  |
| A&D |  | $ | 8,942 |  |  | $ | 9,490 |  |  | $ | 17,733 |  |  | $ | 19,014 |  |
| Commercial |  |  | 16,956 |  |  |  | 14,651 |  |  |  | 33,345 |  |  |  | 27,964 |  |
| RF&S Components |  |  | 443 |  |  |  | 419 |  |  |  | 866 |  |  |  | 886 |  |
| Segment total |  |  | 26,341 |  |  |  | 24,560 |  |  |  | 51,944 |  |  |  | 47,864 |  |
| Corporate |  |  | 1,351 |  |  |  | 1,623 |  |  |  | 2,611 |  |  |  | 3,015 |  |
| Total |  | $ | 27,692 |  |  | $ | 26,183 |  |  | $ | 54,555 |  |  | $ | 50,879 |  |

[0000950170-25-102042:notes:69]
The Company markets and sells its products in approximately 50 countries. For the quarter and two quarters ended June 30, 2025, the Company did not conduct business in any country other than the United States in which its net sales in that country exceeded 10% of the Company’s total net sales. For the quarter and two quarters ended July 1, 2024, net sales in Taiwan also exceeded 10% of the Company’s total net sales. Net sales are attributed to countries by the invoiced location and were as follows:

[0000950170-25-102042:notes:70]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2025 |  |  | July 1, 2024 |  |  | June 30, 2025 |  |  | July 1, 2024 |  |
|  |  | (In thousands) |  |
| United States |  | $ | 381,619 |  |  | $ | 308,774 |  |  | $ | 739,427 |  |  | $ | 609,733 |  |
| Taiwan |  |  | 50,856 |  |  |  | 73,931 |  |  |  | 105,012 |  |  |  | 142,855 |  |
| Other |  |  | 298,146 |  |  |  | 222,432 |  |  |  | 534,850 |  |  |  | 422,662 |  |
| Total net sales |  | $ | 730,621 |  |  | $ | 605,137 |  |  | $ | 1,379,289 |  |  | $ | 1,175,250 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950170-25-102042:notes:71]
[same as prior period, unchanged from 0000950170-25-063937:notes:64]

[0000950170-25-102042:notes:72]
[same as prior period, unchanged from 0000950170-25-063937:notes:65]

[0000950170-25-102042:notes:73]
|  |  | ForeignCurrencyTranslation |  |  | PensionObligation |  |  | Cash FlowHedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 30, 2024 |  | $ | (33,757 | ) |  | $ | 3,612 |  |  | $ | 2,263 |  |  | $ | (27,882 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 159 |  |  |  | — |  |  |  | (1,774 | ) |  |  | (1,615 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | 1,174 |  |  |  | (271 | ) |  |  | 903 |  |
| Net year to date other comprehensive income (loss) |  |  | 159 |  |  |  | 1,174 |  |  |  | (2,045 | ) |  |  | (712 | ) |
| Balance as of June 30, 2025 |  | $ | (33,598 | ) |  | $ | 4,786 |  |  | $ | 218 |  |  | $ | (28,594 | ) |


## us-gaap:EarningsPerShareTextBlock

[0000950170-25-102042:notes:74]
(12) Earnings Per Share

[0000950170-25-102042:notes:75]
[same as prior period, unchanged from 0000950170-25-063937:notes:86]

[0000950170-25-102042:notes:76]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 30, 2025 |  |  | July 1, 2024 |  |  | June 30, 2025 |  |  | July 1, 2024 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income |  | $ | 41,530 |  |  | $ | 26,352 |  |  | $ | 73,708 |  |  | $ | 36,818 |  |
| Basic weighted average shares |  |  | 101,857 |  |  |  | 101,234 |  |  |  | 101,861 |  |  |  | 101,593 |  |
| Dilutive effect of performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock options |  |  | 3,016 |  |  |  | 2,655 |  |  |  | 2,840 |  |  |  | 2,400 |  |
| Diluted shares |  |  | 104,873 |  |  |  | 103,889 |  |  |  | 104,701 |  |  |  | 103,993 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 0.41 |  |  | $ | 0.26 |  |  | $ | 0.72 |  |  | $ | 0.36 |  |
| Diluted earnings per share |  |  | 0.40 |  |  |  | 0.25 |  |  |  | 0.70 |  |  |  | 0.35 |  |

[0000950170-25-102042:notes:77]
PRUs, RSUs, and stock options to purchase 369 and 250 shares of common stock for the quarter and two quarters ended June 30, 2025, respectively, and 330 and 177 shares of common stock for the quarter and two quarters ended July 1, 2024, respectively, were not included in the computation of diluted earnings per share because the impact would be anti-dilutive. The PRUs would have had an anti-dilutive impact because the performance conditions had not been met during the applicable quarter and two quarters. The RSUs and stock options would have had an anti-dilutive impact because the total expected proceeds under the treasury stock method or the options’ exercise prices were greater than the average market price of common stock during the applicable quarter and two quarters.


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-25-102042:notes:78]
[same as prior period, unchanged from 0000950170-25-063937:notes:72]

[0000950170-25-102042:notes:79]
The Company measures at fair value its financial and non-financial assets and liabilities by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability.

[0000950170-25-102042:notes:80]
[same as prior period, unchanged from 0000950170-25-063937:notes:74]

[0000950170-25-102042:notes:81]
|  |  | As of |  |
|  |  | June 30, 2025 |  |  | December 30, 2024 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 1,524 |  |  | $ | 1,524 |  |  | $ | 1,765 |  |  | $ | 1,765 |  |
| Derivative assets, non-current |  |  | — |  |  |  | — |  |  |  | 1,326 |  |  |  | 1,326 |  |
| Derivative liabilities, current |  |  | — |  |  |  | — |  |  |  | 667 |  |  |  | 667 |  |
| Derivative liabilities, non-current |  |  | 872 |  |  |  | 872 |  |  |  | — |  |  |  | — |  |
| Senior Notes due March 2029 |  |  | 497,011 |  |  |  | 477,010 |  |  |  | 496,638 |  |  |  | 464,325 |  |
| Term Loan due May 2030 |  |  | 337,984 |  |  |  | 344,761 |  |  |  | 339,205 |  |  |  | 346,930 |  |
| ABL Revolving Loans |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |
| Other loan |  |  | 2,149 |  |  |  | 2,149 |  |  |  | 2,311 |  |  |  | 2,311 |  |

[0000950170-25-102042:notes:82]
[same as prior period, unchanged from 0000950170-25-063937:notes:76]

[0000950170-25-102042:notes:83]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of June 30, 2025 and December 30, 2024, which are considered Level 2 inputs.

[0000950170-25-102042:notes:84]
As of June 30, 2025 and December 30, 2024, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value.

[0000950170-25-102042:notes:85]
[same as prior period, unchanged from 0000950170-25-063937:notes:79]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-25-102042:notes:86]
(14) Commitments and Contingencies

[0000950170-25-102042:notes:87]
Legal Matters

[0000950170-25-102042:notes:88]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of June 30, 2025 and December 30, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0000950170-25-102042:notes:89]
Supplier Finance Program Obligations

[0000950170-25-102042:notes:90]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $12,808 and $17,218 as of June 30, 2025 and December 30, 2024, respectively.
