# TTMI 8-K — 0001193125-24-189522 filed 2024-07-31

## item codes, every 8-K on or before 2024-08-06

- 2024-08-01 0001193125-24-191480 — 1.01, 2.03
- 2024-07-31 0001193125-24-189522 — 2.02, 9.01
- 2024-06-14 0001193125-24-161581 — 1.01, 2.03
- 2024-06-10 0001193125-24-158390 — 5.03, 9.01 — amendment of 0001193125-24-136138
- 2024-05-10 0001193125-24-136138 — 5.02, 5.03, 5.07, 7.01, 9.01
- 2024-05-01 0001193125-24-126373 — 2.02, 9.01
- 2024-02-07 0001193125-24-026126 — 2.02, 9.01
- 2023-11-01 0001193125-23-267755 — 2.02, 9.01
- 2023-08-02 0001193125-23-201189 — 5.02, 7.01, 9.01
- 2023-08-02 0001193125-23-201186 — 2.02, 9.01
- 2023-06-20 0001193125-23-169669 — 1.01, 2.03, 7.01, 9.01
- 2023-05-30 0001193125-23-156582 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2023-05-12 0001193125-23-142632 — 5.07
- 2023-05-03 0001193125-23-134390 — 2.02, 8.01, 9.01
- 2023-03-09 0001193125-23-066103 — 7.01, 9.01
- 2023-02-08 0001193125-23-028382 — 2.02, 2.05, 7.01, 9.01
- 2022-11-03 0001193125-22-276659 — 2.02, 9.01 — amendment of 0001193125-22-275849
- 2022-11-02 0001193125-22-275849 — 2.02, 9.01
- 2022-09-08 0001193125-22-241001 — 9.01 — amendment of 0001193125-22-182826
- 2022-08-03 0001193125-22-211262 — 2.02, 9.01
- 2022-06-27 0001193125-22-182826 — 2.01, 7.01, 9.01
- 2022-05-16 0001193125-22-151684 — 5.07
- 2022-05-04 0001193125-22-140455 — 2.02, 9.01
- 2022-04-18 0001193125-22-108017 — 1.01, 7.01, 9.01
- 2022-03-01 0001193125-22-059877 — 7.01, 9.01
- 2022-02-09 0001193125-22-032669 — 2.02, 9.01
- 2021-10-27 0001193125-21-309324 — 2.02, 9.01
- 2021-07-28 0001193125-21-227406 — 2.02, 9.01
- 2021-06-14 0001193125-21-189568 — 5.02, 9.01
- 2021-05-13 0001193125-21-159545 — 2.02, 5.02, 5.07, 9.01
- 2021-04-28 0001193125-21-136849 — 2.02, 9.01
- 2021-03-16 0001193125-21-083011 — 1.02, 8.01
- 2021-03-10 0001193125-21-076246 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2021-02-24 0001193125-21-054812 — 7.01, 9.01
- 2021-02-23 0001193125-21-051549 — 7.01, 9.01
- 2021-02-03 0001193125-21-027322 — 2.02, 8.01, 9.01
- 2020-12-15 0001193125-20-318208 — 7.01, 9.01
- 2020-10-28 0001193125-20-279980 — 2.02, 9.01
- 2020-09-04 0001193125-20-239645 — 5.02
- 2020-07-29 0001193125-20-203110 — 2.02, 9.01
- 2020-05-08 0001193125-20-137566 — 5.07
- 2020-05-04 0001193125-20-131366 — 7.01, 9.01
- 2020-04-29 0001193125-20-126358 — 2.05, 7.01, 9.01
- 2020-04-29 0001193125-20-126117 — 2.02, 9.01
- 2020-04-23 0001193125-20-117365 — 2.01, 7.01, 9.01
- 2020-02-05 0001193125-20-025365 — 2.02, 9.01
- 2020-01-31 0001193125-20-021278 — 5.02
- 2020-01-22 0001193125-20-012011 — 1.01, 7.01, 9.01
- 2019-10-30 0001193125-19-278973 — 2.02, 9.01
- 2019-08-19 0001193125-19-224091 — 5.02, 9.01
- 2019-07-31 0001193125-19-208689 — 2.02, 9.01
- 2019-07-24 0001193125-19-201401 — 1.01, 2.03
- 2019-06-13 0001193125-19-171943 — 7.01, 9.01
- 2019-06-06 0001193125-19-167332 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2019-05-09 0001193125-19-143113 — 5.07
- 2019-05-01 0001193125-19-132977 — 2.02, 9.01
- 2019-02-06 0001193125-19-029540 — 2.02, 9.01
- 2019-01-15 0001193125-19-009142 — 2.02, 9.01
- 2018-10-30 0001193125-18-312212 — 2.02, 9.01
- 2018-10-22 0001193125-18-303926 — 5.02
- 2018-09-06 0001193125-18-268231 — 5.02, 9.01
- 2018-08-01 0001193125-18-234997 — 2.02, 9.01
- 2018-06-29 0001193125-18-209635 — 9.01 — amendment of 0001193125-18-120583
- 2018-05-29 0001193125-18-176976 — 7.01, 9.01
- 2018-05-10 0001193125-18-159394 — 5.07
- 2018-05-09 0001193125-18-157596 — 5.02
- 2018-05-02 0001193125-18-148650 — 2.02, 9.01
- 2018-04-18 0001193125-18-120583 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2018-02-21 0001193125-18-052169 — 8.01, 9.01
- 2018-02-20 0001193125-18-050385 — 5.02, 9.01
- 2018-02-09 0001193125-18-036966 — 7.01, 9.01
- 2018-02-07 0001193125-18-034744 — 2.02, 9.01
- 2017-12-14 0001193125-17-369625 — 1.01, 2.03, 9.01
- 2017-12-04 0001193125-17-359439 — 1.01, 7.01, 9.01
- 2017-11-01 0001193125-17-329425 — 2.02, 9.01
- 2017-09-29 0001193125-17-298999 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2017-09-15 0001193125-17-286491 — 7.01, 9.01
- 2017-09-11 0001193125-17-281193 — 7.01, 9.01
- 2017-09-06 0001193125-17-277536 — 7.01, 9.01
- 2017-08-02 0001193125-17-245823 — 2.02, 9.01
- 2017-05-18 0001193125-17-173896 — 5.02, 5.07
- 2017-05-08 0001193125-17-162548 — 2.02, 9.01
- 2017-03-01 0001193125-17-063931 — 1.01, 1.02, 5.02
- 2017-02-08 0001193125-17-034652 — 2.02, 9.01
- 2016-11-18 0001193125-16-772305 — 8.01, 9.01
- 2016-10-26 0001193125-16-747948 — 2.02, 9.01
- 2016-10-20 0001193125-16-742905 — 5.02
- 2016-10-05 0001193125-16-731552 — 5.02, 9.01
- 2016-09-27 0001193125-16-720828 — 1.01, 2.03, 7.01, 9.01
- 2016-07-27 0001193125-16-659983 — 2.02, 9.01
- 2016-05-23 0001193125-16-599342 — 7.01, 9.01
- 2016-05-18 0001193125-16-594656 — 5.02, 5.03, 5.07, 9.01
- 2016-04-27 0001171843-16-009432 — 2.02, 9.01
- 2016-03-08 0001193125-16-495457 — 5.03, 7.01, 9.01
- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2024-08-06

- none on or before 2024-08-06

## item 2.02 — earnings release, exhibit 99.1

[0001193125-24-189522:8k_2_02:1]
EX-99.1
2
d810000dex991.htm
EX-99.1

[0001193125-24-189522:8k_2_02:2]
EX-99.1

[0001193125-24-189522:8k_2_02:3]
Exhibit 99.1

[0001193125-24-189522:8k_2_02:4]
|  |  |  |  | Contact: Sameer Desai, |
|  |  |  |  | Vice President, Corporate Development & Investor Relations |
|  |  |  |  | Sameer.desai@ttmtech.com |
|  |  |  |  | 714-327-3050 |

[0001193125-24-189522:8k_2_02:5]
TTM Technologies, Inc. Reports Second Quarter 2024 Results

[0001193125-24-189522:8k_2_02:6]
Santa Ana, CA – July 31, 2024 – TTM Technologies, Inc. (NASDAQ: TTMI), a leading global manufacturer of technology solutions including mission
systems, radio frequency (“RF”) components and RF microwave/microelectronic assemblies, quick-turn and technologically advanced printed circuit boards (“PCB”), today reported results for the second quarter 2024, which ended on
July 1, 2024.

[0001193125-24-189522:8k_2_02:7]
Second Quarter 2024 Highlights

[0001193125-24-189522:8k_2_02:8]
|  | • |  | Net sales were $605.1 million |

[0001193125-24-189522:8k_2_02:9]
|  | • |  | GAAP net income of $26.4 million, or $0.25 per diluted share |

[0001193125-24-189522:8k_2_02:10]
|  | • |  | Non-GAAP net income was $40.1 million, or $0.39 per diluted share |

[0001193125-24-189522:8k_2_02:11]
|  | • |  | Cash flow from operations was $41.9 million |

[0001193125-24-189522:8k_2_02:12]
|  | • |  | Repurchased 1.39 million shares of common stock for $25.1 million at an average price of $18.09 per share |

[0001193125-24-189522:8k_2_02:13]
|  | • |  | Anticipate close of the refinancing of $346.5 million of a senior secured term loan at an interest rate of SOFR + 2.25% |

[0001193125-24-189522:8k_2_02:14]
Second Quarter 2024 GAAP Financial Results

[0001193125-24-189522:8k_2_02:15]
Net sales for the second quarter of 2024 were $605.1 million, compared to $546.5 million in the second quarter of 2023.

[0001193125-24-189522:8k_2_02:16]
GAAP operating income for the second quarter of 2024 was $39.0 million compared to GAAP operating income for the second quarter of 2023 of
$21.4 million.

[0001193125-24-189522:8k_2_02:17]
GAAP net income for the second quarter of 2024 was $26.4 million, or $0.25 per diluted share, compared to GAAP net income of
$6.8 million, or $0.07 per diluted share in the second quarter of 2023.

[0001193125-24-189522:8k_2_02:18]
Second Quarter 2024 Non-GAAP
Financial Results

[0001193125-24-189522:8k_2_02:19]
On a non-GAAP basis, net income for the second quarter of 2024 was $40.1 million, or
$0.39 per diluted share. This compares to non-GAAP net income of $33.0 million, or $0.32 per diluted share, for the second quarter of 2023.

[0001193125-24-189522:8k_2_02:20]
Adjusted EBITDA in the second quarter of 2024 was $84.6 million, or 14.0% of sales compared to adjusted EBITDA of $74.7 million, or 13.7% of sales
for the second quarter of 2023.

[0001193125-24-189522:8k_2_02:21]
“TTM reported Non-GAAP EPS that was above the guided range and demonstrated
solid year on year growth due to higher revenues and improved operational execution. Revenues were above the guided range, representing the second consecutive quarter of year on year growth due to demand strength in our Aerospace and Defense and
Data Center Computing end markets, the latter being driven by generative AI,” said Tom Edman, CEO of TTM. “In addition, cash flow from operations was a healthy $41.9 million enabling us to repurchase stock while maintaining a solid balance
sheet with a net leverage ratio of 1.4x. Finally, we refinanced our Term Loan B, reducing interest expense going forward,” concluded Mr. Edman.

[0001193125-24-189522:8k_2_02:22]
Refinancing of Term Loan B

[0001193125-24-189522:8k_2_02:23]
We anticipate that on
August 1, 2024, we will close the refinancing of $346.5 million of a senior secured term loan (“New Term Loan Facility”) at an interest rate of SOFR + 2.25%, 50 basis points lower than our previous Term B Loans issued in May
2023. Upon closing, the new Term B Loans will be issued at par

[0001193125-24-189522:8k_2_02:24]
|  |  |  |  | Contact: Sameer Desai, |
|  |  |  |  | Vice President, Corporate Development & Investor Relations |
|  |  |  |  | Sameer.desai@ttmtech.com |
|  |  |  |  | 714-327-3050 |

[0001193125-24-189522:8k_2_02:25]
and maintain the same maturity of May 2030. Once issued, this debt will amend and restate TTM’s previous senior secured term loan facility. We anticipate using the proceeds from the New Term
Loan Facility to refinance $346.5 million of such outstanding indebtedness. We have used cash on hand to pay fees and expenses of approximately $1 million related to the refinancing activity. Once finalized, the new financing is expected
to generate annual interest savings of approximately $1.7 million.

[0001193125-24-189522:8k_2_02:26]
Business Outlook

[0001193125-24-189522:8k_2_02:27]
For the third quarter of 2024, TTM estimates that revenues will be in the range of $580 million to $620 million, and non-GAAP net income will be in the range of $0.37 to $0.43 per diluted share.

[0001193125-24-189522:8k_2_02:28]
With respect to the Company’s
outlook for non-GAAP net income per diluted share, we are unable to predict with reasonable certainty or without unreasonable effort certain items that may affect a comparable measure calculated and presented
in accordance with GAAP. Our expected non-GAAP net income per diluted share excludes primarily the future impact of restructuring actions, impairment charges, unusual gains and losses, and tax adjustments.
These reconciling items are highly variable and difficult to predict due to various factors outside of management’s control and could have a material impact on our future period net income per diluted share calculated and presented in
accordance with GAAP. Accordingly, a reconciliation of non-GAAP net income per diluted share to a comparable measure calculated and presented in accordance with GAAP has not been provided because the Company
is unable to provide such reconciliation without unreasonable effort. For the same reasons, TTM is unable to address the probable significance of the information.

[0001193125-24-189522:8k_2_02:29]
Live Webcast/Conference Call

[0001193125-24-189522:8k_2_02:30]
TTM will host a conference
call and webcast to discuss second quarter 2024 results and the third quarter 2024 outlook on Wednesday, July 31, 2024, at 1:00 p.m. Eastern Time (10:00 a.m. Pacific Time). The conference call will include forward-looking statements.

[0001193125-24-189522:8k_2_02:31]
Access to the conference call is available by clicking on the registration link TTM Technologies, Inc. second quarter 2024 conference call. Registering
participants will receive dial in information and a unique PIN to join the call. Participants can register at any time up to the start of the conference call. The conference call will also be simulcast on the company’s website, and can be
accessed by clicking on the link TTM Technologies Inc. second quarter 2024 webcast. The webcast will remain accessible for one week following the live event.

[0001193125-24-189522:8k_2_02:32]
To Access a Replay of the Webcast

[0001193125-24-189522:8k_2_02:33]
The replay of the
webcast will remain accessible for one week following the live event on TTM’s website at TTM Technologies Inc. second quarter 2024 webcast.

[0001193125-24-189522:8k_2_02:34]
About TTM

[0001193125-24-189522:8k_2_02:35]
TTM Technologies, Inc. is a leading global
manufacturer of technology solutions including mission systems, RF components/RF microwave/microelectronic assemblies, quick-turn and technologically advanced PCBs. TTM stands for
time-to-market, representing how TTM’s time-critical, one-stop manufacturing services enable customers to shorten the time
required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001193125-24-189522:8k_2_02:36]
|  |  |  |  | Contact: Sameer Desai, |
|  |  |  |  | Vice President, Corporate Development & Investor Relations |
|  |  |  |  | Sameer.desai@ttmtech.com |
|  |  |  |  | 714-327-3050 |

[0001193125-24-189522:8k_2_02:37]
Forward-Looking Statements

[0001193125-24-189522:8k_2_02:38]
The preliminary financial results included in this press release represent the most current information available to management. The company’s actual
results when disclosed in its Form 10-Q may differ from these preliminary results as a result of the completion of the company’s financial closing procedures, final adjustments, completion of the review
by the company’s independent registered accounting firm, and other developments that may arise between now and the disclosure of the final results. This release contains forward-looking statements that relate to future events or performance.
TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These statements reflect TTM’s current expectations, and TTM does not undertake to update or revise these forward looking
statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond
TTM’s control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, general market and economic conditions, including interest rates, currency
exchange rates, and consumer spending, demand for TTM’s products, market pressures on prices of TTM’s products, warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements,
TTM’s dependence upon a small number of customers, and other factors set forth in the “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” sections of the
Company’s public reports filed with the SEC.

[0001193125-24-189522:8k_2_02:39]
About Our Non-GAAP Financial Measures

[0001193125-24-189522:8k_2_02:40]
To supplement our consolidated condensed financial statements presented on a GAAP basis, this release includes information about TTM’s adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing financial performance.

[0001193125-24-189522:8k_2_02:41]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no
standardized measurement prescribed by GAAP and may not be comparable to similar non-GAAP financial measures used by other companies. TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliations below to the most directly comparable GAAP financial measure. However, the non-GAAP financial measures should not be considered
in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001193125-24-189522:8k_2_02:42]
- Tables Follow -

[0001193125-24-189522:8k_2_02:43]
TTM TECHNOLOGIES, INC.

[0001193125-24-189522:8k_2_02:44]
Selected Unaudited Financial Information

[0001193125-24-189522:8k_2_02:45]
(In thousands, except per share data)

[0001193125-24-189522:8k_2_02:46]
CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS

[0001193125-24-189522:8k_2_02:47]
|  |  | Second Quarter |  |  | First Two Quarters |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net sales |  | $ | 605,137 |  |  | $ | 546,509 |  |  | $ | 1,175,250 |  |  | $ | 1,090,946 |  |
| Cost of goods sold |  |  | 487,910 |  |  |  | 448,002 |  |  |  | 954,304 |  |  |  | 906,316 |  |
| Gross profit |  |  | 117,227 |  |  |  | 98,507 |  |  |  | 220,946 |  |  |  | 184,630 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 19,798 |  |  |  | 18,180 |  |  |  | 40,092 |  |  |  | 39,482 |  |
| General and administrative |  |  | 38,604 |  |  |  | 37,840 |  |  |  | 82,274 |  |  |  | 72,913 |  |
| Research and development |  |  | 8,547 |  |  |  | 6,424 |  |  |  | 15,868 |  |  |  | 13,509 |  |
| Amortization of definite-lived intangibles |  |  | 10,256 |  |  |  | 3,852 |  |  |  | 21,685 |  |  |  | 25,816 |  |
| Restructuring charges |  |  | 1,036 |  |  |  | 10,803 |  |  |  | 4,974 |  |  |  | 14,970 |  |
| Total operating expenses |  |  | 78,241 |  |  |  | 77,099 |  |  |  | 164,893 |  |  |  | 166,690 |  |
| Operating income |  |  | 38,986 |  |  |  | 21,408 |  |  |  | 56,053 |  |  |  | 17,940 |  |
| Interest expense |  |  | (12,219 | ) |  |  | (11,843 | ) |  |  | (24,543 | ) |  |  | (24,650 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | (1,154 | ) |  |  | — |  |  |  | (1,154 | ) |
| (Loss) gain on sale of subsidiary |  |  | — |  |  |  | (69 | ) |  |  | — |  |  |  | 1,270 |  |
| Other, net |  |  | 3,765 |  |  |  | 5,068 |  |  |  | 13,091 |  |  |  | 6,266 |  |
| Income (loss) before income taxes |  |  | 30,532 |  |  |  | 13,410 |  |  |  | 44,601 |  |  |  | (328 | ) |
| Income tax (provision) benefit |  |  | (4,180 | ) |  |  | (6,586 | ) |  |  | (7,783 | ) |  |  | 1,338 |  |
| Net income |  | $ | 26,352 |  |  | $ | 6,824 |  |  | $ | 36,818 |  |  | $ | 1,010 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.26 |  |  | $ | 0.07 |  |  | $ | 0.36 |  |  | $ | 0.01 |  |
| Diluted |  |  | 0.25 |  |  |  | 0.07 |  |  |  | 0.35 |  |  |  | 0.01 |  |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 101,234 |  |  |  | 102,759 |  |  |  | 101,593 |  |  |  | 102,570 |  |
| Diluted |  |  | 103,889 |  |  |  | 104,820 |  |  |  | 103,993 |  |  |  | 104,575 |  |
| Reconciliation of the denominator used to calculate basic earnings per share and diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding |  |  | 101,234 |  |  |  | 102,759 |  |  |  | 101,593 |  |  |  | 102,570 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 2,655 |  |  |  | 2,061 |  |  |  | 2,400 |  |  |  | 2,005 |  |
| Diluted shares |  |  | 103,889 |  |  |  | 104,820 |  |  |  | 103,993 |  |  |  | 104,575 |  |

[0001193125-24-189522:8k_2_02:48]
SELECTED BALANCE SHEET DATA

[0001193125-24-189522:8k_2_02:49]
|  |  | July 1, 2024 |  |  | January 1, 2024 |  |
| Cash and cash equivalents, including restricted cash |  | $ | 446,247 |  |  | $ | 450,208 |  |
| Accounts and notes receivable, net |  |  | 400,714 |  |  |  | 413,557 |  |
| Receivable from sale of SH E-MS property |  |  | — |  |  |  | 6,737 |  |
| Contract assets |  |  | 340,120 |  |  |  | 292,050 |  |
| Inventories |  |  | 216,906 |  |  |  | 213,075 |  |
| Total current assets |  |  | 1,452,631 |  |  |  | 1,429,687 |  |
| Property, plant and equipment, net |  |  | 838,243 |  |  |  | 807,667 |  |
| Operating lease right of use asset |  |  | 81,886 |  |  |  | 86,286 |  |
| Other non-current assets |  |  | 970,604 |  |  |  | 1,000,023 |  |
| Total assets |  |  | 3,343,364 |  |  |  | 3,323,663 |  |
| Short-term debt, including current portion of long-term debt |  | $ | 2,625 |  |  | $ | 3,500 |  |
| Accounts payable |  |  | 371,189 |  |  |  | 334,609 |  |
| Total current liabilities |  |  | 712,100 |  |  |  | 703,984 |  |
| Debt, net of discount |  |  | 913,428 |  |  |  | 914,336 |  |
| Total long-term liabilities |  |  | 1,102,365 |  |  |  | 1,108,640 |  |
| Total equity |  |  | 1,528,899 |  |  |  | 1,511,039 |  |
| Total liabilities and equity |  |  | 3,343,364 |  |  |  | 3,323,663 |  |

[0001193125-24-189522:8k_2_02:50]
SUPPLEMENTAL DATA

[0001193125-24-189522:8k_2_02:51]
|  |  | Second Quarter |  |  | First Two Quarters |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Gross margin |  |  | 19.4 | % |  |  | 18.0 | % |  |  | 18.8 | % |  |  | 16.9 | % |
| Operating margin |  |  | 6.4 | % |  |  | 3.9 | % |  |  | 4.8 | % |  |  | 1.6 | % |
| End Market Breakdown: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Second Quarter |  |  |  |  |  |  |  |
|  |  | 2024 |  |  | 2023 |  |  |  |  |  |  |  |
| Aerospace and Defense |  |  | 45 | % |  |  | 47 | % |  |  |  |  |  |  |  |  |
| Automotive |  |  | 14 | % |  |  | 17 | % |  |  |  |  |  |  |  |  |
| Data Center Computing |  |  | 21 | % |  |  | 12 | % |  |  |  |  |  |  |  |  |
| Medical/Industrial/Instrumentation |  |  | 14 | % |  |  | 16 | % |  |  |  |  |  |  |  |  |
| Networking |  |  | 6 | % |  |  | 8 | % |  |  |  |  |  |  |  |  |
| Stock-based Compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Second Quarter |  |  |  |  |  |  |  |
| Amount included in: |  |  | 2024 |  |  |  | 2023 |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,941 |  |  | $ | 1,497 |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 836 |  |  |  | 698 |  |  |  |  |  |  |  |  |  |
| General and administrative |  |  | 3,468 |  |  |  | 2,677 |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 335 |  |  |  | 249 |  |  |  |  |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 6,580 |  |  | $ | 5,121 |  |  |  |  |  |  |  |  |  |
| Operating Segment Data: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Second Quarter |  |  |  |  |  |  |  |
| Net sales: |  |  | 2024 |  |  |  | 2023 |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 596,107 |  |  | $ | 536,531 |  |  |  |  |  |  |  |  |  |
| RF&S Components |  |  | 9,030 |  |  |  | 9,978 |  |  |  |  |  |  |  |  |  |
| Total net sales |  | $ | 605,137 |  |  | $ | 546,509 |  |  |  |  |  |  |  |  |  |
| Operating segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 90,927 |  |  | $ | 58,479 |  |  |  |  |  |  |  |  |  |
| RF&S Components |  |  | 2,052 |  |  |  | 3,202 |  |  |  |  |  |  |  |  |  |
| Corporate & Other |  |  | (41,402 | ) |  |  | (33,998 | ) |  |  |  |  |  |  |  |  |
| Total operating segment income |  |  | 51,577 |  |  |  | 27,683 |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | (12,591 | ) |  |  | (6,275 | ) |  |  |  |  |  |  |  |  |
| Total operating income |  |  | 38,986 |  |  |  | 21,408 |  |  |  |  |  |  |  |  |  |
| Total other expense |  |  | (8,454 | ) |  |  | (7,998 | ) |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 30,532 |  |  | $ | 13,410 |  |  |  |  |  |  |  |  |  |

[0001193125-24-189522:8k_2_02:52]
RECONCILIATIONS1

[0001193125-24-189522:8k_2_02:53]
|  |  | Second Quarter |  |  | First Two Quarters |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Non-GAAP gross profit reconciliation2: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 117,227 |  |  | $ | 98,507 |  |  | $ | 220,946 |  |  | $ | 184,630 |  |
| Add back item: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 2,335 |  |  |  | 2,423 |  |  |  | 4,671 |  |  |  | 8,231 |  |
| Stock-based compensation |  |  | 1,941 |  |  |  | 1,497 |  |  |  | 3,970 |  |  |  | 3,159 |  |
| Unrealized (gain) loss on commodity hedge |  |  | (434 | ) |  |  | 867 |  |  |  | (1,186 | ) |  |  | (1,261 | ) |
| Purchase accounting related inventory markup |  |  | — |  |  |  | 164 |  |  |  | — |  |  |  | 327 |  |
| Other charges |  |  | — |  |  |  | 1,416 |  |  |  | (162 | ) |  |  | 2,649 |  |
| Non-GAAP gross profit |  | $ | 121,069 |  |  | $ | 104,874 |  |  | $ | 228,239 |  |  | $ | 197,735 |  |
| Non-GAAP gross margin |  |  | 20.0 | % |  |  | 19.2 | % |  |  | 19.4 | % |  |  | 18.1 | % |
| Non-GAAP operating income reconciliation3: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP operating income |  | $ | 38,986 |  |  | $ | 21,408 |  |  | $ | 56,053 |  |  | $ | 17,940 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 12,591 |  |  |  | 6,275 |  |  |  | 26,356 |  |  |  | 34,047 |  |
| Stock-based compensation |  |  | 6,580 |  |  |  | 5,121 |  |  |  | 13,367 |  |  |  | 10,361 |  |
| Gain on sale of property |  |  | (14,420 | ) |  |  | (42 | ) |  |  | (7,973 | ) |  |  | (215 | ) |
| Unrealized (gain) loss on commodity hedge |  |  | (434 | ) |  |  | 867 |  |  |  | (1,186 | ) |  |  | (1,261 | ) |
| Purchase accounting related inventory markup |  |  | — |  |  |  | 164 |  |  |  | — |  |  |  | 327 |  |
| Restructuring, acquisition-related and other charges |  |  | 11,220 |  |  |  | 12,297 |  |  |  | 8,599 |  |  |  | 18,241 |  |
| Non-GAAP operating income |  | $ | 54,523 |  |  | $ | 46,090 |  |  | $ | 95,216 |  |  | $ | 79,440 |  |
| Non-GAAP operating margin |  |  | 9.0 | % |  |  | 8.4 | % |  |  | 8.1 | % |  |  | 7.3 | % |
| Non-GAAP net income and EPS reconciliation4: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 26,352 |  |  | $ | 6,824 |  |  | $ | 36,818 |  |  | $ | 1,010 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 12,591 |  |  |  | 6,275 |  |  |  | 26,356 |  |  |  | 34,047 |  |
| Stock-based compensation |  |  | 6,580 |  |  |  | 5,121 |  |  |  | 13,367 |  |  |  | 10,361 |  |
| Non-cash interest expense |  |  | 506 |  |  |  | 497 |  |  |  | 1,024 |  |  |  | 1,224 |  |
| Gain on sale of property |  |  | (14,420 | ) |  |  | (42 | ) |  |  | (7,973 | ) |  |  | (215 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | 1,154 |  |  |  | — |  |  |  | 1,154 |  |
| Loss (gain) on sale of subsidiary |  |  | — |  |  |  | 69 |  |  |  | — |  |  |  | (1,270 | ) |
| Unrealized (gain) loss on commodity hedge |  |  | (434 | ) |  |  | 867 |  |  |  | (1,186 | ) |  |  | (1,261 | ) |
| Purchase accounting related inventory markup |  |  | — |  |  |  | 164 |  |  |  | — |  |  |  | 327 |  |
| Restructuring, acquisition-related and other charges |  |  | 11,308 |  |  |  | 12,297 |  |  |  | 8,599 |  |  |  | 18,241 |  |
| Income taxes5 |  |  | (2,352 | ) |  |  | (182 | ) |  |  | (4,087 | ) |  |  | (11,926 | ) |
| Non-GAAP net income |  | $ | 40,131 |  |  | $ | 33,044 |  |  | $ | 72,918 |  |  | $ | 51,692 |  |
| Non-GAAP earnings per diluted share |  | $ | 0.39 |  |  | $ | 0.32 |  |  | $ | 0.70 |  |  | $ | 0.49 |  |
| Adjusted EBITDA reconciliation6: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 26,352 |  |  | $ | 6,824 |  |  | $ | 36,818 |  |  | $ | 1,010 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax provision (benefit) |  |  | 4,180 |  |  |  | 6,586 |  |  |  | 7,783 |  |  |  | (1,338 | ) |
| Interest expense |  |  | 12,219 |  |  |  | 11,843 |  |  |  | 24,543 |  |  |  | 24,650 |  |
| Amortization of definite-lived intangibles |  |  | 12,591 |  |  |  | 6,275 |  |  |  | 26,356 |  |  |  | 34,047 |  |
| Depreciation expense |  |  | 26,184 |  |  |  | 24,937 |  |  |  | 50,880 |  |  |  | 50,190 |  |
| Stock-based compensation |  |  | 6,580 |  |  |  | 5,121 |  |  |  | 13,367 |  |  |  | 10,361 |  |
| Gain on sale of property |  |  | (14,420 | ) |  |  | (42 | ) |  |  | (7,973 | ) |  |  | (215 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | 1,154 |  |  |  | — |  |  |  | 1,154 |  |
| Loss (gain) on sale of subsidiary |  |  | — |  |  |  | 69 |  |  |  | — |  |  |  | (1,270 | ) |
| Unrealized (gain) loss on commodity hedge |  |  | (434 | ) |  |  | 867 |  |  |  | (1,186 | ) |  |  | (1,261 | ) |
| Purchase accounting related inventory markup |  |  | — |  |  |  | 164 |  |  |  | — |  |  |  | 327 |  |
| Restructuring, acquisition-related and other charges |  |  | 11,308 |  |  |  | 10,924 |  |  |  | 8,761 |  |  |  | 15,592 |  |
| Adjusted EBITDA |  | $ | 84,560 |  |  | $ | 74,722 |  |  | $ | 159,349 |  |  | $ | 133,247 |  |
| Adjusted EBITDA margin |  |  | 14.0 | % |  |  | 13.7 | % |  |  | 13.6 | % |  |  | 12.2 | % |
| Free cash flow reconciliation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flow |  | $ | 41,855 |  |  | $ | 25,884 |  |  | $ | 85,750 |  |  | $ | 80,962 |  |
| Capital expenditures, net |  |  | (9,955 | ) |  |  | (49,417 | ) |  |  | (59,251 | ) |  |  | (80,124 | ) |
| Free cash flow |  | $ | 31,900 |  |  | $ | (23,533 | ) |  | $ | 26,499 |  |  | $ | 838 |  |

[0001193125-24-189522:8k_2_02:54]
| 1 | This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income, non-GAAP EPS, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |

[0001193125-24-189522:8k_2_02:55]
| 2 | Non-GAAP gross profit and gross margin measures exclude amortization of intangibles, stock-based compensation expense, unrealized (gain) loss on commodity hedge, purchase accounting related inventory markup, and other charges. |

[0001193125-24-189522:8k_2_02:56]
| 3 | Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, unrealized (gain) loss on commodity hedge, purchase accounting related inventory markup, restructuring, acquisition-related costs, and other charges. |

[0001193125-24-189522:8k_2_02:57]
| 4 | This information provides non-GAAP net income and non-GAAP EPS, which are non-GAAP financial measures. Management believes that both measures — which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, loss on extinguishment of debt, loss (gain) on sale of subsidiary, unrealized (gain) loss on commodity hedge, purchase accounting related inventory markup, restructuring, acquisition-related costs, and other charges as well as the associated tax impact of these charges and discrete tax items — provide additional useful information to investors regarding the Company’s ongoing financial condition and results of operations. |

[0001193125-24-189522:8k_2_02:58]
| 5 | Income tax adjustments reflect the difference between income taxes based on a non-GAAP tax rate and a forecasted annual GAAP tax rate. |

[0001193125-24-189522:8k_2_02:59]
| 6 | Adjusted EBITDA is defined as earnings before income taxes, interest expense, amortization of intangibles, depreciation, stock-based compensation expense, gain on sale of assets, loss on extinguishment of debt, loss (gain) on sale of subsidiary, unrealized (gain) loss on commodity hedge, purchase accounting related inventory markup, restructuring, acquisition-related costs, and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |
