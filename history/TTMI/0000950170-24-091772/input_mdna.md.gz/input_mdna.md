# TTMI MD&A — 0000950170-24-091772


## mdna

[0000950170-24-091772:mdna:1]
[same as prior period, unchanged from 0000950170-24-054464:mdna:1]

[0000950170-24-091772:mdna:2]
[same as prior period, unchanged from 0000950170-24-054464:mdna:2]

[0000950170-24-091772:mdna:3]
[same as prior period, unchanged from 0000950170-24-054464:mdna:3]

[0000950170-24-091772:mdna:4]
[same as prior period, unchanged from 0000950170-24-054464:mdna:4]

[0000950170-24-091772:mdna:5]
[same as prior period, unchanged from 0000950170-24-054464:mdna:5]

[0000950170-24-091772:mdna:6]
[same as prior period, unchanged from 0000950170-24-054464:mdna:6]

[0000950170-24-091772:mdna:7]
On August 1, 2024, we entered into a First Amendment to our Amended and Restated Term Loan Credit Agreement, dated as of May 30, 2023, by and among us, as Borrower, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto, pursuant to which we closed a $346.5 million senior secured term loan (New Term Loan Facility) that bears interest at a floating rate of 1-month Chicago Mercantile Exchange (CME) Term Secured Overnight Financing Rate (SOFR) plus an applicable margin of 2.25%, 50 basis points lower than our previous Term Loan issued in May 2023 (Term Loan Facility). The New Term Loan Facility amends and restates our previous Term Loan Facility. The New Term Loan Facility is issued at par, maintains the same maturity of May 30, 2030 as the previous Term Loan Facility, and the majority is a cashless rollover from the previous Term Loan Facility. We estimate we will incur fees and expenses of approximately $1.0 million related to the refinancing activity. The new financing is expected to generate annual interest savings of approximately $1.7 million.

[0000950170-24-091772:mdna:8]
On November 1, 2023, we announced our selection of Syracuse, New York as the location for a new proposed advanced technology PCB manufacturing facility. We expect that the proposed facility will bring advanced technology capability for our domestic high-volume production of ultra-high-density interconnect (HDI) PCBs in support of national security requirements. We believe the planned investment aligns with New York State’s continuing focus on the region as a premier technology hub for U.S. electronics and the recent selection of Buffalo-Rochester-Syracuse (BRS) for the Federal Tech Hub designation. The project reflects our support for cultivating a stronger microelectronics ecosystem in New York and across the U.S. Aerospace and Defense industrial base. We have broken ground on the 24-acre property adjacent to our existing facility in Syracuse for the campus expansion and the site for the new facility, and we expect initial low rate production within 18 to 24 months. Phase one of the proposed project, including capital for campus-wide improvements is estimated to be $100.0 million to $130.0 million, and is anticipated to run through 2026. Our planned capital investment commitments will be determined after finalizing terms with various stakeholders.

[0000950170-24-091772:mdna:9]
[same as prior period, unchanged from 0000950170-24-054464:mdna:23]

[0000950170-24-091772:mdna:10]
[same as prior period, unchanged from 0000950170-24-054464:mdna:8]

[0000950170-24-091772:mdna:11]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 54% of our net sales for both the quarter and two quarters ended July 1, 2024. Sales to our ten largest customers collectively accounted for 50% and 49% of our net sales for the quarter and two quarters ended July 3, 2023, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0000950170-24-091772:mdna:12]
[same as prior period, unchanged from 0000950170-24-054464:mdna:10]

[0000950170-24-091772:mdna:13]
|  |  | Quarter Ended |  | Two Quarters Ended |
|  |  | July 1, 2024 |  | July 3, 2023 |  | July 1, 2024 |  | July 3, 2023 |
| End Markets (1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  |  | 45 |  | % |  |  | 47 |  | % |  |  | 46 |  | % |  |  | 45 |  | % |
| Automotive |  |  | 14 |  |  |  |  | 17 |  |  |  |  | 13 |  |  |  |  | 17 |  |  |
| Data Center Computing |  |  | 21 |  |  |  |  | 12 |  |  |  |  | 21 |  |  |  |  | 11 |  |  |
| Medical/Industrial/Instrumentation |  |  | 14 |  |  |  |  | 16 |  |  |  |  | 14 |  |  |  |  | 17 |  |  |
| Networking |  |  | 6 |  |  |  |  | 8 |  |  |  |  | 6 |  |  |  |  | 10 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0000950170-24-091772:mdna:14]
[same as prior period, unchanged from 0000950170-24-054464:mdna:12]

[0000950170-24-091772:mdna:15]
[same as prior period, unchanged from 0000950170-24-054464:mdna:13]

[0000950170-24-091772:mdna:16]
[same as prior period, unchanged from 0000950170-24-054464:mdna:14]

[0000950170-24-091772:mdna:17]
[same as prior period, unchanged from 0000950170-24-054464:mdna:15]

[0000950170-24-091772:mdna:18]
[same as prior period, unchanged from 0000950170-24-054464:mdna:16]

[0000950170-24-091772:mdna:19]
[same as prior period, unchanged from 0000950170-24-054464:mdna:17]

[0000950170-24-091772:mdna:20]
[same as prior period, unchanged from 0000950170-24-054464:mdna:18]

[0000950170-24-091772:mdna:21]
[same as prior period, unchanged from 0000950170-24-054464:mdna:19]

[0000950170-24-091772:mdna:22]
[same as prior period, unchanged from 0000950170-24-054464:mdna:20]

[0000950170-24-091772:mdna:23]
[same as prior period, unchanged from 0000950170-24-054464:mdna:21]

[0000950170-24-091772:mdna:24]
[same as prior period, unchanged from 0000950170-24-054464:mdna:22]

[0000950170-24-091772:mdna:25]
[same as prior period, unchanged from 0000950170-24-054464:mdna:24]

[0000950170-24-091772:mdna:26]
[same as prior period, unchanged from 0000950170-24-054464:mdna:25]

[0000950170-24-091772:mdna:27]
|  |  | Quarter Ended |  | Two Quarters Ended |
|  |  | July 1, 2024 |  | July 3, 2023 |  | July 1, 2024 |  | July 3, 2023 |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 80.6 |  |  |  |  | 82.0 |  |  |  |  | 81.2 |  |  |  |  | 83.1 |  |  |
| Gross profit |  |  | 19.4 |  |  |  |  | 18.0 |  |  |  |  | 18.8 |  |  |  |  | 16.9 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.3 |  |  |  |  | 3.3 |  |  |  |  | 3.4 |  |  |  |  | 3.6 |  |  |
| General and administrative |  |  | 6.4 |  |  |  |  | 6.9 |  |  |  |  | 7.0 |  |  |  |  | 6.7 |  |  |
| Research and development |  |  | 1.4 |  |  |  |  | 1.2 |  |  |  |  | 1.4 |  |  |  |  | 1.2 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.7 |  |  |  |  | 0.7 |  |  |  |  | 1.8 |  |  |  |  | 2.4 |  |  |
| Restructuring charges |  |  | 0.2 |  |  |  |  | 2.0 |  |  |  |  | 0.4 |  |  |  |  | 1.4 |  |  |
| Total operating expenses |  |  | 13.0 |  |  |  |  | 14.1 |  |  |  |  | 14.0 |  |  |  |  | 15.3 |  |  |
| Operating income |  |  | 6.4 |  |  |  |  | 3.9 |  |  |  |  | 4.8 |  |  |  |  | 1.6 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.0 | ) |  |  |  | (2.2 | ) |  |  |  | (2.1 | ) |  |  |  | (2.2 | ) |  |
| Loss on extinguishment of debt |  |  | — |  |  |  |  | (0.2 | ) |  |  |  | — |  |  |  |  | (0.1 | ) |  |
| Gain on sale of subsidiary |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |  |  | 0.1 |  |  |
| Other, net |  |  | 0.6 |  |  |  |  | 0.9 |  |  |  |  | 1.1 |  |  |  |  | 0.6 |  |  |
| Total other expense, net |  |  | (1.4 | ) |  |  |  | (1.5 | ) |  |  |  | (1.0 | ) |  |  |  | (1.6 | ) |  |
| Income before income taxes |  |  | 5.0 |  |  |  |  | 2.4 |  |  |  |  | 3.8 |  |  |  |  | — |  |  |
| Income tax (provision) benefit |  |  | (0.7 | ) |  |  |  | (1.2 | ) |  |  |  | (0.7 | ) |  |  |  | 0.1 |  |  |
| Net income |  |  | 4.3 |  | % |  |  | 1.2 |  | % |  |  | 3.1 |  | % |  |  | 0.1 |  | % |

[0000950170-24-091772:mdna:28]
The following discussion and analysis is for the quarter and two quarters ended July 1, 2024, compared to the quarter and two quarters ended July 3, 2023, unless otherwise stated.

[0000950170-24-091772:mdna:29]
[same as prior period, unchanged from 0000950170-24-054464:mdna:28]

[0000950170-24-091772:mdna:30]
Total net sales increased $58.6 million, or 10.7%, to $605.1 million for the second quarter of 2024 from $546.5 million for the second quarter of 2023. The increase in total net sales primarily resulted from an increase in net sales for the PCB reportable segment of $59.6 million, or 11.1%, to $596.1 million for the second quarter of 2024 from $536.5 million for the second quarter of 2023. The primary driver of this increase was demand growth in our aerospace and defense and data center computing end markets, partially offset by demand weakness in our automotive, networking, and medical, industrial, and instrumentation end markets. Net sales for the RF&S Components reportable segment decreased $1.0 million, or 9.5%, to $9.0 million for the second quarter of 2024 from $10.0 million for the second quarter of 2023, which was primarily due to lower demand in our networking end market.

[0000950170-24-091772:mdna:31]
Total net sales increased $84.4 million or 7.7%, to $1,175.3 million for the first two quarters of 2024 from $1,090.9 million for the first two quarters of 2023. This increase in total net sales primarily resulted from an increase in net sales for the PCB reportable segment of $87.3 million, or 8.2%, to $1,157.9 million for the first two quarters of 2024 from $1,070.6 million for the first two quarters of 2023. The primary driver of this increase was demand growth in our aerospace and defense and data center computing end markets, partially offset by demand weakness in our networking, automotive, and medical, industrial, and instrumentation end markets, and by the sale of our Shanghai backplane business in the first quarter of 2023, which had the effect of reducing $8.4 million of net sales when comparing the first two quarters of 2024 to the first two quarters of 2023. Net sales for the RF&S Components reportable segment decreased $3.0 million, or 14.8%, to $17.3 million for the first two quarters of 2024 from $20.3 million for the first two quarters of 2023, which was primarily due to lower demand in our networking end market.

[0000950170-24-091772:mdna:32]
[same as prior period, unchanged from 0000950170-24-054464:mdna:30]

[0000950170-24-091772:mdna:33]
Overall gross margin increased to 19.4% for the second quarter of 2024 from 18.0% for the second quarter of 2023. Gross margin for the PCB reportable segment increased to 20.0% for the second quarter of 2024 from 18.6% for the second quarter of 2023. This increase was due to higher sales volume, particularly in the data center computing end market, and improved operational execution. Gross margin for the RF&S Components reportable segment decreased to 49.8% for the second quarter of 2024 from 57.4% for the second quarter of 2023, primarily due to lower sales.

[0000950170-24-091772:mdna:34]
Overall gross margin increased to 18.8% for the first two quarters of 2024 from 16.9% for the first two quarters of 2023. Gross margin for the PCB reportable segment increased to 19.7% for the first two quarters of 2024 from 17.6% for the first two quarters of 2023. This increase was due to higher sales volume, particularly in the data center computing end market, and improved operational execution. Gross margin for the RF&S Components reportable segment decreased to 48.7% for the first two quarters of 2024 from 53.5% for the first two quarters of 2023, primarily due to lower sales.

[0000950170-24-091772:mdna:35]
An important factor affecting gross margins is capacity utilization, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume PCB facilities in Asia, as a significant portion of our operating costs are fixed in nature. North America utilization figures are not as meaningful as Asia because bottlenecks in these high mix low volume facilities tend to occur in areas outside of plating, which is the core process that we use for calculating utilization rates. Capacity utilization for the second quarter of 2024 in our Asia and North America PCB facilities was 64% and 39%, respectively, compared to 46% and 38%, respectively, for the second quarter of 2023. Capacity utilization for the first two quarters of 2024 in our Asia and North America PCB facilities was 58% and 38%, respectively, compared to 49% and 38%, respectively, for the first two quarters of 2023. The increase in capacity utilization in our Asia PCB facilities was due to continued strong data center demand.

[0000950170-24-091772:mdna:36]
[same as prior period, unchanged from 0000950170-24-054464:mdna:33]

[0000950170-24-091772:mdna:37]
Selling and marketing expenses increased $1.6 million to $19.8 million, or 3.3% of net sales, for the second quarter of 2024 from $18.2 million, or 3.3% of net sales, for the second quarter of 2023. The increase in selling and marketing expenses was primarily due to increases in labor costs and commissions. The selling and marketing expenses as a percentage of net sales was flat as a result of higher net sales offset by increased expenses.

[0000950170-24-091772:mdna:38]
Selling and marketing expenses increased $0.6 million to $40.1 million, or 3.4% of net sales, for the first two quarters of 2024 from $39.5 million, or 3.6% of net sales, for the first two quarters of 2023. The increase in selling and marketing expenses was primarily due to increases in certain personnel costs and stock-based compensation, partially offset by a decrease in commissions. The selling and marketing expenses as a percentage of net sales decreased as a result of higher net sales.

[0000950170-24-091772:mdna:39]
[same as prior period, unchanged from 0000950170-24-054464:mdna:35]

[0000950170-24-091772:mdna:40]
General and administrative expenses increased $0.8 million to $38.6 million, or 6.4% of net sales, for the second quarter of 2024 from $37.8 million, or 6.9% of net sales, for the second quarter of 2023. The increase in general and administrative expenses was primarily due to increases in consulting and legal expenses, bad debt, labor costs, and the write down of our Hong Kong building of $6.1 million, partially offset by gains on the sale of assets primarily related to the sale of two buildings vacated by the closure of our Anaheim and Santa Clara plants of $14.4 million. The general and administrative expenses as a percentage of net sales decreased as a result of higher net sales.

[0000950170-24-091772:mdna:41]
General and administrative expenses increased $9.4 million to $82.3 million, or 7.0% of net sales, for the first two quarters of 2024 from $72.9 million, or 6.7% of net sales, for the first two quarters of 2023. The increase in general and administrative expenses was primarily due to increases in labor costs, consulting and legal expenses, incentive compensation, bad debt, stock-based compensation, and the write down of our Hong Kong building of $6.1 million, partially offset by gains on the sale of assets primarily related to the sale of two buildings vacated by the closure of our Anaheim and Santa Clara plants of $14.4 million.

[0000950170-24-091772:mdna:42]
[same as prior period, unchanged from 0000950170-24-054464:mdna:37]

[0000950170-24-091772:mdna:43]
Research and development expenses increased $2.1 million to $8.5 million, or 1.4% of net sales, for the second quarter of 2024 from $6.4 million, or 1.2% of net sales, for the second quarter of 2023. The increase in research and development expenses was primarily due to increases in labor costs and research and development projects.

[0000950170-24-091772:mdna:44]
Research and development expenses increased $2.4 million to $15.9 million, or 1.4% of net sales, for the first two quarters of 2024 from $13.5 million, or 1.2% of net sales, for the first two quarters of 2023. The increase in research and development expenses was primarily due to increases in labor costs and research and development projects.

[0000950170-24-091772:mdna:45]
[same as prior period, unchanged from 0000950170-24-054464:mdna:39]

[0000950170-24-091772:mdna:46]
Total other expense, net increased $0.5 million to $8.5 million for the second quarter of 2024 from $8.0 million for the second quarter of 2023, primarily due to a $2.8 million decrease in foreign currency gain mainly resulting from higher monetary liabilities than assets in Renminbi (RMB) in the second quarter of 2024 as compared to the second quarter of 2023 and an increase in interest expense of $0.4 million, partially offset by an increase in interest income of $1.5 million and the absence of $1.2 million of loss on extinguishment in the second quarter of 2024 as compared to the second quarter of 2023. We utilize the RMB at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China.

[0000950170-24-091772:mdna:47]
Total other expense, net decreased $6.8 million to $11.5 million for the first two quarters of 2024 from $18.3 million for the first two quarters of 2023, primarily due to an increase in interest income of $3.3 million and an increase in foreign currency gains of $2.9 million resulting from the weakening RMB in the first two quarters of 2024 compared to the first two quarters of 2023.

[0000950170-24-091772:mdna:48]
[same as prior period, unchanged from 0000950170-24-054464:mdna:41]

[0000950170-24-091772:mdna:49]
Income tax expense decreased $2.4 million to $4.2 million for the second quarter of 2024 from $6.6 million for the second quarter of 2023. The decrease in income tax expense was primarily due to a windfall tax benefit of the stock-based compensation releases and finalization of China and Canada corporate income tax returns which was partially offset by the absence in the second quarter of 2024 of the release of uncertain tax position benefits that existed in the second quarter of 2023.

[0000950170-24-091772:mdna:50]
Income tax expense increased $9.1 million to $7.8 million for the first two quarters of 2024 from an income tax benefit of $1.3 million for the first two quarters of 2023. The increase in income tax expense for the first two quarters of 2024 was primarily due to an increase in pre-tax income for the first two quarters of 2024, the absence in the first two quarters of 2024 of the release of uncertain tax position benefits that existed in the first two quarters of 2023, and the approval of our renewal application for High and New Technology Enterprise status for two of our manufacturing subsidiaries in China (including the impact on the respective subsidiaries’ deferred tax amounts), but partially offset by a windfall tax benefit of the stock-based compensation releases and finalization of China and Canada corporate income tax returns.

[0000950170-24-091772:mdna:51]
Our effective tax rate is primarily impacted by the mix of foreign and U.S. income, tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax liability of $42.9 million and $54.4 million as of July 1, 2024 and July 3, 2023, respectively.

[0000950170-24-091772:mdna:52]
[same as prior period, unchanged from 0000950170-24-054464:mdna:44]

[0000950170-24-091772:mdna:53]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our revolving credit facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, repay debt obligations, and repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and repurchasing common stock will be the principal demands on our cash in the future.

[0000950170-24-091772:mdna:54]
Cash flow provided by operating activities during the first two quarters of 2024 was $85.8 million as compared to cash flow provided by operating activities of $81.0 million in the same period in 2023. The increase in cash flow was primarily due to an increase in net income of $35.8 million partially offset by an increased investment in working capital.

[0000950170-24-091772:mdna:55]
Net cash used in investing activities during the first two quarters of 2024 was $52.5 million, primarily resulting from the use of $88.8 million for purchases of property, plant and equipment and other assets. This is partially offset by the receipt of $29.6 million of proceeds from the sale of property, plant, and equipment and other assets primarily related to the sale of two buildings vacated by the closure of our Anaheim and Santa Clara plants and $6.7 million of proceeds from the sale of property associated with our Shanghai E‑MS subsidiary. Net cash used in investing activities was approximately $12.3 million for the first two quarters of 2023, primarily reflecting the use of $80.5 million for purchases of property, plant, and equipment and other assets, partially offset by the receipt of $61.8 million of proceeds from the sale of property associated with our Shanghai E‑MS subsidiary and $6.0 million of proceeds from the sale of our Shanghai Backplane Assembly subsidiary, net of cash disposed.

[0000950170-24-091772:mdna:56]
Net cash used in financing activities during the first two quarters of 2024 was $37.1 million reflecting the use of $34.5 million for repurchases of common stock and $2.6 million for the repayment of long-term debt borrowings. Net cash used in financing activities during the first two quarters of 2023 was $72.4 million, primarily reflecting repayment of long-term debt borrowings of $290.7 million, refund of customer deposits of $7.5 million, payment of debt issuance costs of $5.5 million, and payment of original issue discount of $3.5 million, partially offset by the receipt of proceeds from long-term debt borrowing of $234.8 million.

[0000950170-24-091772:mdna:57]
As of July 1, 2024, we had cash and cash equivalents of $446.2 million, of which $174.6 million was held by our foreign subsidiaries, primarily in China. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for the repatriation of this cash.

[0000950170-24-091772:mdna:58]
Our total 2024 capital expenditures are expected to be in the range of $190.0 million to $210.0 million.

[0000950170-24-091772:mdna:59]
[same as prior period, unchanged from 0000950170-24-054464:mdna:51]

[0000950170-24-091772:mdna:60]
On May 3, 2023, our Board of Directors authorized a share repurchase program (2023 Repurchase Program) allowing us to repurchase up to $100.0 million of our common stock from time to time through May 3, 2025. During the quarter ended July 1, 2024, we repurchased 1.4 million shares of our common stock for a total cost of $25.1 million (including commissions) and during the two quarters ended July 1, 2024, we repurchased 2.0 million shares of our common stock for a total cost of $34.5 million (including commissions). As of July 1, 2024, the remaining amount in value available to be repurchased under the 2023 Repurchase Program was approximately $41.1 million.

[0000950170-24-091772:mdna:61]
[same as prior period, unchanged from 0000950170-24-054464:mdna:53]

[0000950170-24-091772:mdna:62]
As of July 1, 2024, we had $916.1 million of outstanding debt, net of discount and debt issuance costs, composed of $496.3 million of Senior Notes due March 2029, $339.8 million under the Term Loan Facility, and $80.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL).

[0000950170-24-091772:mdna:63]
Pursuant to the terms of the Senior Notes due March 2029 and Term Loan Facility, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments. Under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of July 1, 2024, we were in compliance with the covenants under the Senior Notes due March 2029, Term Loan Facility, and ABL Revolving Loans.

[0000950170-24-091772:mdna:64]
Based on our current level of operations, we believe that cash generated from operations, cash on hand, and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next 12 months. Additional information regarding our indebtedness, including information about the credit available under our debt facilities, interest rates, and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 8, Long‑term Debt and Letters of Credit, of the Notes to Consolidated Condensed Financial Statements included in this Report.

[0000950170-24-091772:mdna:65]
[same as prior period, unchanged from 0000950170-24-054464:mdna:57]

[0000950170-24-091772:mdna:66]
We have agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, we confirm the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and we pay the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $5.1 million and $18.8 million as of July 1, 2024 and January 1, 2024, respectively.

[0000950170-24-091772:mdna:67]
[same as prior period, unchanged from 0000950170-24-054464:mdna:59]

[0000950170-24-091772:mdna:68]
As part of our on-going operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, derivative liabilities, purchase obligations, and leases. As of July 1, 2024, there were no material changes outside the ordinary course of business since January 1, 2024 to our contractual obligations and commitments and the related cash requirements.

[0000950170-24-091772:mdna:69]
[same as prior period, unchanged from 0000950170-24-054464:mdna:61]

[0000950170-24-091772:mdna:70]
We have and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for our products and services from customers in foreign countries. As of July 1, 2024, we had outstanding offset agreements of approximately $28.0 million, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event we fail to perform in accordance with contract requirements. To date, we have not been obligated to pay any such penalties. For details about our offset agreements, see Part I, Item 1, Note 14, Commitments and Contingencies, of the Notes to Consolidated Condensed Financial Statements included in this Report.

[0000950170-24-091772:mdna:71]
[same as prior period, unchanged from 0000950170-24-054464:mdna:63]

[0000950170-24-091772:mdna:72]
[same as prior period, unchanged from 0000950170-24-054464:mdna:64]

[0000950170-24-091772:mdna:73]
Recently Issued Accounting Standards

[0000950170-24-091772:mdna:74]
For a description of recently adopted and issued accounting standards, including the respective dates of adoption and the expected effects on our results of operations and financial condition, see Part I, Item 1, Note 1, Nature of Operations and Basis of Presentation, of the Notes to Consolidated Condensed Financial Statements included in this Report.
