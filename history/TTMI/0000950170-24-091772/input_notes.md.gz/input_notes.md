# TTMI notes — 0000950170-24-091772


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000950170-24-091772:notes:1]
[same as prior period, unchanged from 0000950170-24-054464:notes:1]

[0000950170-24-091772:notes:2]
[same as prior period, unchanged from 0000950170-24-054464:notes:2]

[0000950170-24-091772:notes:3]
[same as prior period, unchanged from 0000950170-24-054464:notes:3]

[0000950170-24-091772:notes:4]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflict between Russia and Ukraine, and the conflict in Israel and the Gaza Strip, the global economy and financial markets have been volatile. As such, the Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

[0000950170-24-091772:notes:5]
Recently Issued Accounting Standards Not Yet Adopted

[0000950170-24-091772:notes:6]
In March 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2024-02, Codification Improvements - Amendments to Remove References to the Concepts Statements, to remove various references to concepts statements from the Accounting Standards Codification (ASC). These amendments clarify guidance, simplify wording or structure of guidance, and other minor improvements. The amendments are effective for fiscal years beginning after December 15, 2024, applied prospectively, with early adoption and retrospective application permitted. The impact of the adoption of the amendments in this update is not expected to be material to the Company's consolidated financial statements and related disclosures.

[0000950170-24-091772:notes:7]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. The update will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted for annual financial statements not yet issued or made available for issuance. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

[0000950170-24-091772:notes:8]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The amendments are effective for fiscal years beginning after December 15, 2023, and for interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

[0000950170-24-091772:notes:9]
In October 2023, the FASB issued ASU 2023-06, Disclosure Improvements: Codification Amendments in Response to the Securities and Exchange Commission’s Disclosure Update and Simplification Initiative, which modifies the disclosure or presentation requirements of a variety of topics in the ASC in response to the SEC’s Release No. 33-10532, Disclosure Update and Simplification Initiative, and align the ASC requirements with the SEC’s regulations. For entities subject to the SEC's existing disclosure requirements, the effective date for each amendment will be the date on which the SEC's removal of that related disclosure from Regulation S-X or Regulation S-K becomes effective. However, if by June 30, 2027, the SEC has not removed the related disclosure from its regulations, the amendments will be removed from the Codification and not become effective. Early adoption is prohibited. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.


## us-gaap:TreasuryStockTextBlock

[0000950170-24-091772:notes:10]
[same as prior period, unchanged from 0000950170-24-054464:notes:10]

[0000950170-24-091772:notes:11]
[same as prior period, unchanged from 0000950170-24-054464:notes:11]

[0000950170-24-091772:notes:12]
During the quarter ended July 1, 2024, the Company repurchased 1,390 shares of common stock for a total cost of $25,145 (including commissions) and during the two quarters ended July 1, 2024, the Company repurchased 1,990 shares of common stock for a total cost of $34,479 (including commissions). As of July 1, 2024, the remaining amount in value available to be repurchased under the 2023 Repurchase Program was approximately $41,088.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-24-091772:notes:13]
[same as prior period, unchanged from 0000950170-24-054464:notes:13]

[0000950170-24-091772:notes:14]
[same as prior period, unchanged from 0000950170-24-054464:notes:14]

[0000950170-24-091772:notes:15]
The Company had cash and cash equivalents held by its foreign subsidiaries of $174,623 and $195,928 as of July 1, 2024 and January 1, 2024, respectively. The Company maintains its cash and cash equivalents with major financial institutions and such balances exceed Federal Deposit Insurance Corporation insurance limits. The Company has not experienced any losses in such accounts and believes it is not exposed to any significant risk on cash and cash equivalents.

[0000950170-24-091772:notes:16]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs on-going credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. As of July 1, 2024 and January 1, 2024, there were no customers that accounted for 10% or more of the Company's accounts receivable.

[0000950170-24-091772:notes:17]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.
For the quarter and two quarters ended July 1, 2024, one customer accounted for approximately 11% of the Company's net sales. For the quarter and two quarters ended July 3, 2023, one customer accounted for approximately 13% of the Company's net sales.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-24-091772:notes:18]
[same as prior period, unchanged from 0000950170-24-054464:notes:19]

[0000950170-24-091772:notes:19]
As of July 1, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $413,941. The Company expects to recognize revenue on approximately 49% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.

[0000950170-24-091772:notes:20]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of July 1, 2024 and January 1, 2024 were $35,227 and $25,213, respectively.

[0000950170-24-091772:notes:21]
Revenue recognized for the two quarters ended July 1, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $28,205. Revenue recognized for the two quarters ended July 3, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $27,069.

[0000950170-24-091772:notes:22]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for both the quarter and two quarters ended July 1, 2024 and July 3, 2023.

[0000950170-24-091772:notes:23]
[same as prior period, unchanged from 0000950170-24-054464:notes:24]

[0000950170-24-091772:notes:24]
|  |  | Quarter Ended July 1, 2024 |  |  | Quarter Ended July 3, 2023 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 272,789 |  |  | $ | — |  |  | $ | 272,789 |  |  | $ | 254,284 |  |  | $ | — |  |  | $ | 254,284 |  |
| Automotive |  |  | 82,698 |  |  |  | — |  |  |  | 82,698 |  |  |  | 92,374 |  |  |  | — |  |  |  | 92,374 |  |
| Data Center Computing |  |  | 124,052 |  |  |  | 63 |  |  |  | 124,115 |  |  |  | 64,305 |  |  |  | 51 |  |  |  | 64,356 |  |
| Medical/Industrial/Instrumentation |  |  | 86,416 |  |  |  | 722 |  |  |  | 87,138 |  |  |  | 88,979 |  |  |  | 745 |  |  |  | 89,724 |  |
| Networking |  |  | 30,152 |  |  |  | 8,245 |  |  |  | 38,397 |  |  |  | 36,589 |  |  |  | 9,182 |  |  |  | 45,771 |  |
| Total |  | $ | 596,107 |  |  | $ | 9,030 |  |  | $ | 605,137 |  |  | $ | 536,531 |  |  | $ | 9,978 |  |  | $ | 546,509 |  |

[0000950170-24-091772:notes:25]
|  |  | Two Quarters Ended July 1, 2024 |  |  | Two Quarters Ended July 3, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 537,565 |  |  | $ | — |  |  | $ | 537,565 |  |  | $ | 486,576 |  |  | $ | — |  |  | $ | 486,576 |  |
| Automotive |  |  | 156,315 |  |  |  | — |  |  |  | 156,315 |  |  |  | 185,841 |  |  |  | — |  |  |  | 185,841 |  |
| Data Center Computing |  |  | 243,429 |  |  |  | 122 |  |  |  | 243,551 |  |  |  | 122,175 |  |  |  | 51 |  |  |  | 122,226 |  |
| Medical/Industrial/Instrumentation |  |  | 165,209 |  |  |  | 1,456 |  |  |  | 166,665 |  |  |  | 189,747 |  |  |  | 1,662 |  |  |  | 191,409 |  |
| Networking |  |  | 55,430 |  |  |  | 15,724 |  |  |  | 71,154 |  |  |  | 86,303 |  |  |  | 18,591 |  |  |  | 104,894 |  |
| Total |  | $ | 1,157,948 |  |  | $ | 17,302 |  |  | $ | 1,175,250 |  |  | $ | 1,070,642 |  |  | $ | 20,304 |  |  | $ | 1,090,946 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000950170-24-091772:notes:26]
[same as prior period, unchanged from 0000950170-24-054464:notes:27]

[0000950170-24-091772:notes:27]
|  |  | As of |  |
|  |  | July 1, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 164,961 |  |  | $ | 165,666 |  |
| Work-in-process |  |  | 49,657 |  |  |  | 45,494 |  |
| Finished goods |  |  | 2,288 |  |  |  | 1,915 |  |
| Inventories |  | $ | 216,906 |  |  | $ | 213,075 |  |
| Property, plant, and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 68,705 |  |  | $ | 71,131 |  |
| Buildings and improvements |  |  | 511,699 |  |  |  | 512,148 |  |
| Machinery and equipment |  |  | 1,070,313 |  |  |  | 986,527 |  |
| Furniture and fixtures and other |  |  | 10,513 |  |  |  | 10,157 |  |
| Construction-in-progress |  |  | 61,477 |  |  |  | 90,940 |  |
| Property, plant, and equipment, gross |  |  | 1,722,707 |  |  |  | 1,670,903 |  |
| Less: Accumulated depreciation |  |  | (884,464 | ) |  |  | (863,236 | ) |
| Property, plant, and equipment, net |  | $ | 838,243 |  |  | $ | 807,667 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Accrued capital expenditures |  | $ | 14,681 |  |  | $ | 35,026 |  |
| Sales return and allowances |  |  | 12,910 |  |  |  | 12,301 |  |
| Accrued facility operating costs |  |  | 9,264 |  |  |  | 10,172 |  |
| Operating leases |  |  | 8,160 |  |  |  | 8,433 |  |
| Housing fund |  |  | 7,609 |  |  |  | 7,749 |  |
| Warranty |  |  | 7,055 |  |  |  | 10,557 |  |
| Interest |  |  | 6,873 |  |  |  | 9,399 |  |
| Income taxes payable |  |  | 6,231 |  |  |  | 5,466 |  |
| Accrued professional fees |  |  | 6,145 |  |  |  | 3,276 |  |
| Restructuring |  |  | 594 |  |  |  | 1,179 |  |
| Derivative liabilities |  |  | 65 |  |  |  | 297 |  |
| Other |  |  | 40,371 |  |  |  | 36,951 |  |
| Other current liabilities |  | $ | 119,958 |  |  | $ | 140,806 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 44,664 |  |  | $ | 44,238 |  |
| Customer deposits |  |  | 28,390 |  |  |  | 29,820 |  |
| Finance leases |  |  | 12,405 |  |  |  | 12,799 |  |
| Defined benefit pension plan liability |  |  | 748 |  |  |  | 836 |  |
| Derivative liabilities |  |  | — |  |  |  | 1,476 |  |
| Other |  |  | 26,558 |  |  |  | 24,349 |  |
| Other long-term liabilities |  | $ | 112,765 |  |  | $ | 113,518 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-24-091772:notes:28]
[same as prior period, unchanged from 0000950170-24-054464:notes:29]

[0000950170-24-091772:notes:29]
[same as prior period, unchanged from 0000950170-24-054464:notes:30]

[0000950170-24-091772:notes:30]
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| As of July 1, 2024 and January 1, 2024 |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 810,235 |  |  | $ | 177,200 |  |  | $ | 987,435 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | (113,300 | ) |  |  | (284,700 | ) |
| Carrying amount |  | $ | 638,835 |  |  | $ | 63,900 |  |  | $ | 702,735 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-24-091772:notes:31]
[same as prior period, unchanged from 0000950170-24-054464:notes:32]

[0000950170-24-091772:notes:32]
[same as prior period, unchanged from 0000950170-24-054464:notes:33]

[0000950170-24-091772:notes:33]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| As of July 1, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 324,730 |  |  | $ | (149,076 | ) |  | $ | 175,654 |  |  |  | 11.8 |  |
| Technology |  |  | 66,650 |  |  |  | (31,949 | ) |  |  | 34,701 |  |  |  | 8.2 |  |
| Total |  | $ | 391,380 |  |  | $ | (181,025 | ) |  | $ | 210,355 |  |  |  |  |
| As of January 1, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 416,230 |  |  | $ | (222,766 | ) |  | $ | 193,464 |  |  |  | 11.2 |  |
| Technology |  |  | 66,650 |  |  |  | (27,278 | ) |  |  | 39,372 |  |  |  | 8.2 |  |
| Backlog |  |  | 13,000 |  |  |  | (9,750 | ) |  |  | 3,250 |  |  |  | 2.0 |  |
| Trade names |  |  | 2,500 |  |  |  | (1,875 | ) |  |  | 625 |  |  |  | 2.0 |  |
| Total |  | $ | 498,380 |  |  | $ | (261,669 | ) |  | $ | 236,711 |  |  |  |  |

[0000950170-24-091772:notes:34]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $12,591 and $26,356 for the quarter and two quarters ended July 1, 2024, respectively, and $6,275 and $34,047 for the quarter and two quarters ended July 3, 2023, respectively. For the quarter and two quarters ended July 1, 2024, $2,335 and $4,671, respectively, of amortization expense was included in cost of goods sold. For the quarter and two quarters ended July 3, 2023, $2,423 and $8,231, respectively, of amortization expense was included in cost of goods sold.

[0000950170-24-091772:notes:35]
In connection with the finalization of acquired identifiable intangible asset valuation during the quarter ended July 3, 2023 related to the Company's acquisition in 2022 of Telephonics, the Company recorded a net reduction in amortization expense of $2,862, which included $4,813 of amortization expense and a reduction in amortization expense of $5,117 and $2,558 due to the change in amortization period, which corresponded to the fiscal year ended January 2, 2023 and quarter ended April 3, 2023, respectively. The Company recorded amortization expense of $15,252 related to the acquired identifiable intangible assets during the two quarters ended July 3, 2023 (of which $5,627 corresponded to the fiscal year ended January 2, 2023 due to the change in amortization period). For the quarter and two quarters ended July 3, 2023, $1,475 and $5,900, respectively, of amortization expense related to the acquired identifiable intangible assets was included in cost of goods sold (of which $2,950 corresponded to the fiscal year ended January 2, 2023).

[0000950170-24-091772:notes:36]
[same as prior period, unchanged from 0000950170-24-054464:notes:36]

[0000950170-24-091772:notes:37]
|  |  | (In thousands) |  |
| Remaining 2024 |  | $ | 18,536 |  |
| 2025 |  |  | 36,897 |  |
| 2026 |  |  | 36,897 |  |
| 2027 |  |  | 34,543 |  |
| 2028 |  |  | 30,997 |  |
| Thereafter |  |  | 52,485 |  |
| Total |  | $ | 210,355 |  |


## us-gaap:LongTermDebtTextBlock

[0000950170-24-091772:notes:38]
(8) Long-term Debt and Letters of Credit

[0000950170-24-091772:notes:39]
Long-term debt was as follows:

[0000950170-24-091772:notes:40]
|  |  | As of July 1, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.08 |  |  |  |  | 346,500 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.63 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 926,500 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,398 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (3,049 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,053 |  |  |  |  |  |  |  | 917,836 |  |
| Less: Current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,428 |  |  |  |  |  |  | $ | 914,336 |  |

[0000950170-24-091772:notes:41]
Debt Covenants

[0000950170-24-091772:notes:42]
Borrowings under the Senior Notes due March 2029 and Term Loan due May 2030 (Term Loan Facility) are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

[0000950170-24-091772:notes:43]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans) are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0000950170-24-091772:notes:44]
Debt Issuance Costs and Debt Discount

[0000950170-24-091772:notes:45]
Remaining unamortized debt issuance costs and debt discount were as follows:

[0000950170-24-091772:notes:46]
|  |  | As of July 1, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,727 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,671 |  |  |  | 3,049 |  |  |  | 8.26 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,398 |  |  | $ | 3,049 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |

[0000950170-24-091772:notes:47]
The above debt issuance costs and debt discount are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0000950170-24-091772:notes:48]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,421 and $1,603 as of July 1, 2024 and January 1, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0000950170-24-091772:notes:49]
As of July 1, 2024, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 5.3 years.

[0000950170-24-091772:notes:50]
Refinancing of Term Loan Facility

[0000950170-24-091772:notes:51]
On August 1, 2024, the Company entered into a First Amendment to its Amended and Restated Term Loan Credit Agreement, dated as of May 30, 2023, by and among the Company, as Borrower, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto, pursuant to which the Company closed its $346,500 of a senior secured term loan (New Term Loan Facility) that bears interest at a floating rate of 1-month Chicago Mercantile Exchange (CME) Term Secured Overnight Financing Rate (SOFR) plus an applicable margin of 2.25%, 50 basis points lower than the previous Term Loan Facility issued in May 2023. The New Term Loan Facility is issued at par, maintains the same maturity of May 30, 2030 as the previous Term Loan Facility, and the majority is a cashless rollover from the previous Term Loan Facility.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-091772:notes:52]
[same as prior period, unchanged from 0000950170-24-054464:notes:50]

[0000950170-24-091772:notes:53]
[same as prior period, unchanged from 0000950170-24-054464:notes:51]

[0000950170-24-091772:notes:54]
During the quarter and two quarters ended July 1, 2024, the Company’s effective tax rate was impacted by a net discrete benefit of $3,348 and $2,861, respectively. This is primarily related to a windfall tax benefit of the stock-based compensation releases and finalization of China and Canada corporate income tax returns, which was partially offset by the approval of the Company’s renewal application for High and New Technology Enterprise status for two of the Company’s manufacturing subsidiaries in China (including the impact on the respective subsidiaries’ deferred tax amounts), and accrued interest expense on existing uncertain tax positions.

[0000950170-24-091772:notes:55]
[same as prior period, unchanged from 0000950170-24-054464:notes:53]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-091772:notes:56]
[same as prior period, unchanged from 0000950170-24-054464:notes:54]

[0000950170-24-091772:notes:57]
[same as prior period, unchanged from 0000950170-24-054464:notes:55]

[0000950170-24-091772:notes:58]
The Company, including the chief operating decision maker, evaluates segment performance based on reportable segment income, which is operating income before amortization of intangibles. Interest expense and interest income are not presented by segment since they are not included in the measure of segment profitability reviewed by the chief operating decision maker. All inter‑segment transactions have been eliminated. Net sales by segment, operating segment income, and segment assets were as follows:

[0000950170-24-091772:notes:59]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |  |
|  |  | July 1, 2024 |  |  | July 3, 2023 |  |  | July 1, 2024 |  |  | July 3, 2023 |  |  |
|  |  | (In thousands) |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 596,107 |  |  | $ | 536,531 |  |  | $ | 1,157,948 |  |  | $ | 1,070,642 |  |  |
| RF&S Components |  |  | 9,030 |  |  |  | 9,978 |  |  |  | 17,302 |  |  |  | 20,304 |  |  |
| Total net sales |  | $ | 605,137 |  |  | $ | 546,509 |  |  | $ | 1,175,250 |  |  | $ | 1,090,946 |  |  |
| Operating Segment Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 90,927 |  |  | $ | 58,479 |  |  | $ | 160,579 |  |  | $ | 110,113 |  |  |
| RF&S Components |  |  | 2,052 |  |  |  | 3,202 |  |  |  | 3,714 |  |  |  | 5,370 |  |  |
| Corporate and Other |  |  | (41,402 | ) |  |  | (33,998 | ) |  |  | (81,884 | ) |  |  | (63,496 | ) |  |
| Total operating segment income |  |  | 51,577 |  |  |  | 27,683 |  |  |  | 82,409 |  |  |  | 51,987 |  |  |
| Amortization of definite-lived intangibles (1) |  |  | (12,591 | ) |  |  | (6,275 | ) |  |  | (26,356 | ) |  |  | (34,047 | ) |  |
| Total operating income |  |  | 38,986 |  |  |  | 21,408 |  |  |  | 56,053 |  |  |  | 17,940 |  |  |
| Total other expense |  |  | (8,454 | ) |  |  | (7,998 | ) |  |  | (11,452 | ) |  |  | (18,268 | ) |  |
| Income (loss) before income taxes |  | $ | 30,532 |  |  | $ | 13,410 |  |  | $ | 44,601 |  |  | $ | (328 | ) |  |

[0000950170-24-091772:notes:60]
|  |  | As of |  |
|  |  | July 1, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |
| PCB |  | $ | 2,103,247 |  |  | $ | 2,032,202 |  |
| RF&S Components |  |  | 136,021 |  |  |  | 142,520 |  |
| Corporate and Other |  |  | 1,104,096 |  |  |  | 1,148,941 |  |
| Total assets |  | $ | 3,343,364 |  |  | $ | 3,323,663 |  |

[0000950170-24-091772:notes:61]
(1)
Amortization of definite-lived intangibles relates to the PCB and RF&S Components reportable segments. For the quarter and two quarters ended July 1, 2024, $2,335 and $4,671, respectively, of amortization expense is included in cost of goods sold. For the quarter and two quarters ended July 3, 2023, $2,423 and $8,231, respectively, of amortization expense is included in cost of goods sold.

[0000950170-24-091772:notes:62]
[same as prior period, unchanged from 0000950170-24-054464:notes:60]

[0000950170-24-091772:notes:63]
The Company markets and sells its products in approximately 60 countries. Other than in the United States and Taiwan, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales are attributed to countries by country invoiced and were as follows:

[0000950170-24-091772:notes:64]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 1, 2024 |  |  | July 3, 2023 |  |  | July 1, 2024 |  |  | July 3, 2023 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 308,774 |  |  | $ | 319,122 |  |  | $ | 609,733 |  |  | $ | 630,563 |  |
| Taiwan |  |  | 73,931 |  |  |  | 37,439 |  |  |  | 142,855 |  |  |  | 65,382 |  |
| Other |  |  | 222,432 |  |  |  | 189,948 |  |  |  | 422,662 |  |  |  | 395,001 |  |
| Total net sales |  | $ | 605,137 |  |  | $ | 546,509 |  |  | $ | 1,175,250 |  |  | $ | 1,090,946 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950170-24-091772:notes:65]
[same as prior period, unchanged from 0000950170-24-054464:notes:63]

[0000950170-24-091772:notes:66]
[same as prior period, unchanged from 0000950170-24-054464:notes:64]

[0000950170-24-091772:notes:67]
|  |  | ForeignCurrencyTranslation |  |  | PensionObligation |  |  | Cash FlowHedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of January 1, 2024 |  | $ | (32,860 | ) |  | $ | 2,530 |  |  | $ | 1,263 |  |  | $ | (29,067 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (858 | ) |  |  | — |  |  |  | 4,740 |  |  |  | 3,882 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | (1,728 | ) |  |  | (1,728 | ) |
| Net year to date other comprehensive (loss) income |  |  | (858 | ) |  |  | — |  |  |  | 3,012 |  |  |  | 2,154 |  |
| Ending balance as of July 1, 2024 |  | $ | (33,718 | ) |  | $ | 2,530 |  |  | $ | 4,275 |  |  | $ | (26,913 | ) |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-24-091772:notes:68]
[same as prior period, unchanged from 0000950170-24-054464:notes:66]

[0000950170-24-091772:notes:69]
[same as prior period, unchanged from 0000950170-24-054464:notes:67]

[0000950170-24-091772:notes:70]
[same as prior period, unchanged from 0000950170-24-054464:notes:68]

[0000950170-24-091772:notes:71]
The Company’s business is exposed to risk resulting from fluctuations in interest rates on certain SOFR based variable rate debt. Increases in interest rates increase interest expenses relating to the outstanding variable rate borrowings and increase the cost of debt. Fluctuations in interest rates can also lead to significant fluctuations in the fair value of the debt obligations.

[0000950170-24-091772:notes:72]
On March 23, 2023, the Company entered into a four-year pay-fixed, receive-floating (1-month CME Term SOFR), interest rate swap arrangement with a notional amount of $250,000 for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its Term SOFR-based debt and receives a floating 1-month CME Term SOFR during the swap period.

[0000950170-24-091772:notes:73]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax in the Company's consolidated condensed balance sheets. No ineffectiveness was recognized for the quarter and two quarters ended July 1, 2024.

[0000950170-24-091772:notes:74]
[same as prior period, unchanged from 0000950170-24-054464:notes:74]

[0000950170-24-091772:notes:75]
The Company uses various raw materials in the manufacturing of PCBs. Copper clad laminates (CCLs), a key raw material for the manufacture of PCBs, are made from epoxy resin, glass cloth, and copper foil. The Company only buys a small amount of copper directly. However, copper is a major driver of laminate cost. The Company enters into commodity contracts to hedge copper as a proxy for hedging laminate. As of July 1, 2024, the Company has commodity contracts with a notional quantity of (i) 0.6 metric tonnes for the period beginning July 1, 2024 and ending on September 30, 2024, (ii) 0.5 metric tonnes for the period beginning October 1, 2024 and ending on December 31, 2024, (iii) 0.5 metric tonnes for the period beginning January 1, 2025 and ending on March 31, 2025, and (iv) 0.5 metric tonnes for the period beginning April 1, 2025 and ending on June 30, 2025. The changes in the fair value of these commodity contracts are recorded in cost of goods sold in the consolidated condensed statements of operations. The commodity contracts decreased cost of goods sold by $609 and $1,040 for the quarter and two quarters ended July 1, 2024, respectively. The commodity contracts increased cost of goods sold by $1,423 and $382 for the quarter and two quarters ended July 3, 2023, respectively. These commodity contracts are not designated as accounting hedges.

[0000950170-24-091772:notes:76]
[same as prior period, unchanged from 0000950170-24-054464:notes:76]

[0000950170-24-091772:notes:77]
|  |  | Asset/(Liability) Fair Value |  |
|  |  | July 1, 2024 |  |  | January 1, 2024 |  |
|  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |
| Interest rate swap: |  |  |  |  |  |  |
| Prepaid expenses and other current assets |  | $ | 3,876 |  |  | $ | 3,253 |  |
| Deposits and other non-current assets |  |  | 1,917 |  |  |  | — |  |
| Other long-term liabilities |  |  | — |  |  |  | (1,476 | ) |
| Net asset |  | $ | 5,793 |  |  | $ | 1,777 |  |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |
| Commodity contracts: |  |  |  |  |  |  |
| Prepaid expenses and other current assets |  | $ | 889 |  |  | $ | — |  |
| Other current liabilities |  |  | — |  |  |  | (297 | ) |
| Net asset (liability) |  | $ | 889 |  |  | $ | (297 | ) |

[0000950170-24-091772:notes:78]
[same as prior period, unchanged from 0000950170-24-054464:notes:78]

[0000950170-24-091772:notes:79]
|  |  |  |  | Quarter Ended July 1, 2024 |  |  | Quarter Ended July 3, 2023 |  |
|  |  | FinancialStatement Caption |  | Gain Recognized in Other Comprehensive Income |  |  | AmountsReclassifiedinto Net Income |  |  | Gain Recognized in Other Comprehensive Income |  |  | AmountsReclassifiedinto Net Income |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense |  | $ | 1,232 |  |  | $ | 1,158 |  |  | $ | 7,710 |  |  | $ | (968 | ) |

[0000950170-24-091772:notes:80]
|  |  |  |  | Two Quarters Ended July 1, 2024 |  |  | Two Quarters Ended July 3, 2023 |  |
|  |  | FinancialStatement Caption |  | Gain Recognized in Other Comprehensive Income |  |  | AmountsReclassifiedinto Net Income |  |  | Gain Recognized in Other Comprehensive Loss |  |  | AmountsReclassifiedinto Net Income |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense |  | $ | 6,340 |  |  | $ | (2,323 | ) |  | $ | 6,809 |  |  | $ | (968 | ) |

[0000950170-24-091772:notes:81]
[same as prior period, unchanged from 0000950170-24-054464:notes:80]

[0000950170-24-091772:notes:82]
|  |  | Two Quarters Ended |  |
|  |  | July 1, 2024 |  |  | July 3, 2023 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | 1,263 |  |  | $ | (85 | ) |
| Changes in fair value gain, net of tax |  |  | 4,740 |  |  |  | 5,140 |  |
| Reclassification to earnings |  |  | (1,728 | ) |  |  | (721 | ) |
| Ending balance, net of tax |  | $ | 4,275 |  |  | $ | 4,334 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-24-091772:notes:83]
[same as prior period, unchanged from 0000950170-24-054464:notes:82]

[0000950170-24-091772:notes:84]
[same as prior period, unchanged from 0000950170-24-054464:notes:83]

[0000950170-24-091772:notes:85]
[same as prior period, unchanged from 0000950170-24-054464:notes:84]

[0000950170-24-091772:notes:86]
|  |  | As of July 1, 2024 |  |  | As of January 1, 2024 |  |
|  |  | CarryingAmount |  |  | Fair Value |  |  | CarryingAmount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 4,765 |  |  | $ | 4,765 |  |  | $ | 3,282 |  |  | $ | 3,282 |  |
| Derivative assets, non-current |  |  | 1,917 |  |  |  | 1,917 |  |  |  | — |  |  |  | — |  |
| Derivative liabilities, current |  |  | 65 |  |  |  | 65 |  |  |  | 297 |  |  |  | 297 |  |
| Derivative liabilities, non-current |  |  | — |  |  |  | — |  |  |  | 1,476 |  |  |  | 1,476 |  |
| Senior Notes due March 2029 |  |  | 496,273 |  |  |  | 457,305 |  |  |  | 495,915 |  |  |  | 455,035 |  |
| Term Loan due May 2030 |  |  | 339,780 |  |  |  | 347,585 |  |  |  | 341,921 |  |  |  | 351,743 |  |
| ABL Revolving Loans |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |

[0000950170-24-091772:notes:87]
[same as prior period, unchanged from 0000950170-24-054464:notes:86]

[0000950170-24-091772:notes:88]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of July 1, 2024 and January 1, 2024, which are considered Level 2 inputs.

[0000950170-24-091772:notes:89]
As of July 1, 2024 and January 1, 2024, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value.

[0000950170-24-091772:notes:90]
[same as prior period, unchanged from 0000950170-24-054464:notes:89]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-091772:notes:91]
(14) Commitments and Contingencies

[0000950170-24-091772:notes:92]
Legal Matters

[0000950170-24-091772:notes:93]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 1, 2024 and January 1, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0000950170-24-091772:notes:94]
Offset Agreements

[0000950170-24-091772:notes:95]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of July 1, 2024, the Company had outstanding offset agreements of approximately $27,963, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. To date, the Company has not been obligated to pay any such penalties.

[0000950170-24-091772:notes:96]
Supplier Finance Program Obligations

[0000950170-24-091772:notes:97]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $5,057 and $18,832 as of July 1, 2024 and January 1, 2024, respectively.


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-091772:notes:98]
(15) Earnings Per Share

[0000950170-24-091772:notes:99]
The reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share is as follows:

[0000950170-24-091772:notes:100]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 1, 2024 |  |  | July 3, 2023 |  |  | July 1, 2024 |  |  | July 3, 2023 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income |  | $ | 26,352 |  |  | $ | 6,824 |  |  | $ | 36,818 |  |  | $ | 1,010 |  |
| Basic weighted average shares |  |  | 101,234 |  |  |  | 102,759 |  |  |  | 101,593 |  |  |  | 102,570 |  |
| Dilutive effect of performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock options |  |  | 2,655 |  |  |  | 2,061 |  |  |  | 2,400 |  |  |  | 2,005 |  |
| Diluted shares |  |  | 103,889 |  |  |  | 104,820 |  |  |  | 103,993 |  |  |  | 104,575 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.26 |  |  | $ | 0.07 |  |  | $ | 0.36 |  |  | $ | 0.01 |  |
| Diluted |  | $ | 0.25 |  |  | $ | 0.07 |  |  | $ | 0.35 |  |  | $ | 0.01 |  |

[0000950170-24-091772:notes:101]
PRUs, RSUs, and stock options to purchase 330 and 177 shares of common stock for the quarter and two quarters ended July 1, 2024, respectively, and 524 and 345 shares of common stock for the quarter and two quarters ended July 3, 2023, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met at July 1, 2024 and July 3, 2023, and for the RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common stock during the applicable quarter and two quarters and, as a result, the impact would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-24-091772:notes:102]
[same as prior period, unchanged from 0000950170-24-054464:notes:102]

[0000950170-24-091772:notes:103]
[same as prior period, unchanged from 0000950170-24-054464:notes:103]

[0000950170-24-091772:notes:104]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period depends on performance during the period and may range from zero to 2.4 times the target number for PRUs awarded before 2023 and zero to 2.0 times the target number for PRUs awarded in 2023 and thereafter. For PRUs awarded before 2023, the performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and earnings before interest, tax, depreciation, and amortization expense (EBITDA), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three‑year performance period. For PRUs awarded in 2023 and thereafter, the performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and EBITDA, each equally weighted, and (b) the three-year TSR performance result, which will be an additive component to the Company’s financial results of the aggregated three-year measurement period.

[0000950170-24-091772:notes:105]
Under the PRU program, financial goals with respect to one or more target milestones are set at the beginning of each fiscal year and performance is reviewed at the end of that year. The percentage to be applied to each participant’s target award ranges from zero to 160% for PRUs awarded before 2023 and zero to 200% for PRUs awarded in 2023 and thereafter, based upon the extent to which the target milestones are achieved. If specific performance threshold levels for the target milestones are met, the amount earned for that element over the three-year performance period will be applied equally for PRUs awarded before 2023 and 80% for PRUs awarded in 2023 and thereafter, of the participants’ PRU award to determine the number of units earned.

[0000950170-24-091772:notes:106]
At the end of the three-year performance period, the total units earned, if any, are adjusted by the TSR calculation. The TSR calculation is a percentage ranging from zero to 150% for PRUs awarded before 2023 and zero to 200% for PRUs awarded in 2023 and thereafter, determined on the Company’s TSR based on stock price changes relative to a group of peer companies selected by the Company’s compensation committee for the same three-year period. For outstanding PRU awards granted before 2023, the TSR is used as an overall modifier of the three-year performance period such that the base calculations are multiplied by the TSR modifier, ranging from zero to 200%, based on the relative performance of the Company’s stock price as compared to its TSR peer group. For PRUs awarded in 2023 and thereafter, the TSR calculation will be applied to 20% of the participants’ PRU award to determine the number of additional units earned.

[0000950170-24-091772:notes:107]
[same as prior period, unchanged from 0000950170-24-054464:notes:107]

[0000950170-24-091772:notes:108]
[same as prior period, unchanged from 0000950170-24-054464:notes:108]

[0000950170-24-091772:notes:109]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 1, 2024 |  |  | July 3, 2023 |  |  | July 1, 2024 |  |  | July 3, 2023 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 1,941 |  |  | $ | 1,497 |  |  | $ | 3,970 |  |  | $ | 3,159 |  |
| Selling and marketing |  |  | 836 |  |  |  | 698 |  |  |  | 1,704 |  |  |  | 1,439 |  |
| General and administrative |  |  | 3,468 |  |  |  | 2,677 |  |  |  | 7,063 |  |  |  | 5,239 |  |
| Research and development |  |  | 335 |  |  |  | 249 |  |  |  | 630 |  |  |  | 524 |  |
| Stock-based compensation expense recognized |  | $ | 6,580 |  |  | $ | 5,121 |  |  | $ | 13,367 |  |  | $ | 10,361 |  |

[0000950170-24-091772:notes:110]
A summary of total unrecognized compensation costs as of July 1, 2024 was as follows:

[0000950170-24-091772:notes:111]
|  |  | Unrecognized Compensation Costs |  |  | Remaining Weighted AverageRecognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 56,973 |  |  |  | 1.7 |  |
| PRU awards |  |  | 7,314 |  |  |  | 1.8 |  |
| Total |  | $ | 64,287 |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-091772:notes:112]
[same as prior period, unchanged from 0000950170-24-054464:notes:112]

[0000950170-24-091772:notes:113]
On February 8, 2023, the Company announced a consolidation plan, pursuant to which the Company ceased operations at three of its manufacturing facilities during the fiscal year ended January 1, 2024 and consolidated the operations of those facilities into other Company facilities. The three manufacturing facilities were PCB operations located in Anaheim and Santa Clara, California, and Hong Kong. The Company recorded $25,742 of restructuring charges and $5,161 of accelerated depreciation since the February 8, 2023 announcement.

[0000950170-24-091772:notes:114]
In addition to this consolidation plan, the Company recognized employee separation, contract termination, and other costs during the quarter and two quarters ended July 1, 2024 and July 3, 2023 in connection with other global realignment restructuring efforts. Contract termination and other costs primarily represented plant closure costs.

[0000950170-24-091772:notes:115]
[same as prior period, unchanged from 0000950170-24-054464:notes:115]

[0000950170-24-091772:notes:116]
|  |  | Quarter Ended July 1, 2024 |  |  | Quarter Ended July 3, 2023 |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | — |  |  | $ | 1,053 |  |  | $ | 1,053 |  |  | $ | 7,385 |  |  | $ | 2,999 |  |  | $ | 10,384 |  |
| RF&S Components |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 14 |  |  |  | — |  |  |  | 14 |  |
| Corporate and Other |  |  | — |  |  |  | (17 | ) |  |  | (17 | ) |  |  | 179 |  |  |  | 226 |  |  |  | 405 |  |
| Total |  | $ | — |  |  | $ | 1,036 |  |  | $ | 1,036 |  |  | $ | 7,578 |  |  | $ | 3,225 |  |  | $ | 10,803 |  |

[0000950170-24-091772:notes:117]
|  |  | Two Quarters Ended July 1, 2024 |  |  | Two Quarters Ended July 3, 2023 |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | — |  |  | $ | 4,943 |  |  | $ | 4,943 |  |  | $ | 11,142 |  |  | $ | 3,185 |  |  | $ | 14,327 |  |
| RF&S Components |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 14 |  |  |  | — |  |  |  | 14 |  |
| Corporate and Other |  |  | — |  |  |  | 31 |  |  |  | 31 |  |  |  | 305 |  |  |  | 324 |  |  |  | 629 |  |
| Total |  | $ | — |  |  | $ | 4,974 |  |  | $ | 4,974 |  |  | $ | 11,461 |  |  | $ | 3,509 |  |  | $ | 14,970 |  |

[0000950170-24-091772:notes:118]
[same as prior period, unchanged from 0000950170-24-054464:notes:118]

[0000950170-24-091772:notes:119]
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of January 1, 2024 |  | $ | 994 |  |  | $ | 185 |  |  | $ | 1,179 |  |
| Charged to expense |  |  | — |  |  |  | 4,974 |  |  |  | 4,974 |  |
| Amount paid |  |  | (416 | ) |  |  | (5,143 | ) |  |  | (5,559 | ) |
| Accrued as of July 1, 2024 |  | $ | 578 |  |  | $ | 16 |  |  | $ | 594 |  |
