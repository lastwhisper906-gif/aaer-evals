# TTMI note change history — 0000950170-24-054464 → 0000950170-24-091772


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000950170-24-091772:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 1, 2024 and January 1, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2024-05-07, similarity 0.9771):
[0000950170-24-054464:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 1, 2024 and January 1, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

- changed (2024-08-06):
[0000950170-24-091772:note_history:2]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of July 1, 2024, the Company had outstanding offset agreements of approximately $27,963, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. To date, the Company has not been obligated to pay any such penalties.
  (was, 2024-05-07, similarity 0.9965):
[0000950170-24-054464:note_history:2]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of April 1, 2024, the Company had outstanding offset agreements of approximately $27,963, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. To date, the Company has not been obligated to pay any such penalties.

- changed (2024-08-06):
[0000950170-24-091772:note_history:3]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $5,057 and $18,832 as of July 1, 2024 and January 1, 2024, respectively.
  (was, 2024-05-07, similarity 0.9785):
[0000950170-24-054464:note_history:3]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $17,689 and $18,832 as of April 1, 2024 and January 1, 2024, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000950170-24-091772:note_history:4]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflict between Russia and Ukraine, and the conflict in Israel and the Gaza Strip, the global economy and financial markets have been volatile. As such, the Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.
  (was, 2024-05-07, similarity 0.9889):
[0000950170-24-054464:note_history:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflict between Russia and Ukraine, and the conflict in Israel and the Gaza Strip, the global economy and financial markets have been volatile. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000950170-24-091772:note_history:5]
|  |  | As of July 1, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,727 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,671 |  |  |  | 3,049 |  |  |  | 8.26 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,398 |  |  | $ | 3,049 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |
  (was, 2024-05-07, similarity 0.993):
[0000950170-24-054464:note_history:5]
|  |  | As of April 1, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,907 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,799 |  |  |  | 3,156 |  |  |  | 8.26 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,706 |  |  | $ | 3,156 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000950170-24-091772:note_history:6]
|  |  | As of July 1, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.08 |  |  |  |  | 346,500 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.63 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 926,500 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,398 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (3,049 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,053 |  |  |  |  |  |  |  | 917,836 |  |
| Less: Current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,428 |  |  |  |  |  |  | $ | 914,336 |  |
  (was, 2024-05-07, similarity 0.9946):
[0000950170-24-054464:note_history:6]
|  |  | As of April 1, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.07 |  |  |  |  | 347,375 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.62 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 927,375 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,706 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (3,156 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,513 |  |  |  |  |  |  |  | 917,836 |  |
| Less: current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,888 |  |  |  |  |  |  | $ | 914,336 |  |

- changed (2024-08-06):
[0000950170-24-091772:note_history:7]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans) are subject to various financial covenants, including leverage and fixed charge coverage ratios.
  (was, 2024-05-07, similarity 0.9983):
[0000950170-24-054464:note_history:7]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.

- changed (2024-08-06):
[0000950170-24-091772:note_history:8]
|  |  | As of July 1, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,727 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,671 |  |  |  | 3,049 |  |  |  | 8.26 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,398 |  |  | $ | 3,049 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |
  (was, 2024-05-07, similarity 0.993):
[0000950170-24-054464:note_history:8]
|  |  | As of April 1, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,907 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,799 |  |  |  | 3,156 |  |  |  | 8.26 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,706 |  |  | $ | 3,156 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |

- changed (2024-08-06):
[0000950170-24-091772:note_history:9]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,421 and $1,603 as of July 1, 2024 and January 1, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2024-05-07, similarity 0.9858):
[0000950170-24-054464:note_history:9]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,512 and $1,603 as of April 1, 2024 and January 1, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2024-08-06):
[0000950170-24-091772:note_history:10]
As of July 1, 2024, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 5.3 years.
  (was, 2024-05-07, similarity 0.9744):
[0000950170-24-054464:note_history:10]
As of April 1, 2024, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 5.5 years.

- added (2024-08-06):
[0000950170-24-091772:note_history:11]
Refinancing of Term Loan Facility

- added (2024-08-06):
[0000950170-24-091772:note_history:12]
On August 1, 2024, the Company entered into a First Amendment to its Amended and Restated Term Loan Credit Agreement, dated as of May 30, 2023, by and among the Company, as Borrower, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto, pursuant to which the Company closed its $346,500 of a senior secured term loan (New Term Loan Facility) that bears interest at a floating rate of 1-month Chicago Mercantile Exchange (CME) Term Secured Overnight Financing Rate (SOFR) plus an applicable margin of 2.25%, 50 basis points lower than the previous Term Loan Facility issued in May 2023. The New Term Loan Facility is issued at par, maintains the same maturity of May 30, 2030 as the previous Term Loan Facility, and the majority is a cashless rollover from the previous Term Loan Facility.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000950170-24-091772:note_history:13]
|  |  | As of July 1, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.08 |  |  |  |  | 346,500 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.63 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 926,500 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,398 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (3,049 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,053 |  |  |  |  |  |  |  | 917,836 |  |
| Less: Current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,428 |  |  |  |  |  |  | $ | 914,336 |  |
  (was, 2024-05-07, similarity 0.9946):
[0000950170-24-054464:note_history:13]
|  |  | As of April 1, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 8.07 |  |  |  |  | 347,375 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.62 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 927,375 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,706 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (3,156 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,513 |  |  |  |  |  |  |  | 917,836 |  |
| Less: current maturities |  |  |  |  |  |  | (2,625 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,888 |  |  |  |  |  |  | $ | 914,336 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-08-06):
[0000950170-24-091772:note_history:14]
|  |  | Quarter Ended July 1, 2024 |  |  | Quarter Ended July 3, 2023 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 272,789 |  |  | $ | — |  |  | $ | 272,789 |  |  | $ | 254,284 |  |  | $ | — |  |  | $ | 254,284 |  |
| Automotive |  |  | 82,698 |  |  |  | — |  |  |  | 82,698 |  |  |  | 92,374 |  |  |  | — |  |  |  | 92,374 |  |
| Data Center Computing |  |  | 124,052 |  |  |  | 63 |  |  |  | 124,115 |  |  |  | 64,305 |  |  |  | 51 |  |  |  | 64,356 |  |
| Medical/Industrial/Instrumentation |  |  | 86,416 |  |  |  | 722 |  |  |  | 87,138 |  |  |  | 88,979 |  |  |  | 745 |  |  |  | 89,724 |  |
| Networking |  |  | 30,152 |  |  |  | 8,245 |  |  |  | 38,397 |  |  |  | 36,589 |  |  |  | 9,182 |  |  |  | 45,771 |  |
| Total |  | $ | 596,107 |  |  | $ | 9,030 |  |  | $ | 605,137 |  |  | $ | 536,531 |  |  | $ | 9,978 |  |  | $ | 546,509 |  |

- added (2024-08-06):
[0000950170-24-091772:note_history:15]
|  |  | Two Quarters Ended July 1, 2024 |  |  | Two Quarters Ended July 3, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 537,565 |  |  | $ | — |  |  | $ | 537,565 |  |  | $ | 486,576 |  |  | $ | — |  |  | $ | 486,576 |  |
| Automotive |  |  | 156,315 |  |  |  | — |  |  |  | 156,315 |  |  |  | 185,841 |  |  |  | — |  |  |  | 185,841 |  |
| Data Center Computing |  |  | 243,429 |  |  |  | 122 |  |  |  | 243,551 |  |  |  | 122,175 |  |  |  | 51 |  |  |  | 122,226 |  |
| Medical/Industrial/Instrumentation |  |  | 165,209 |  |  |  | 1,456 |  |  |  | 166,665 |  |  |  | 189,747 |  |  |  | 1,662 |  |  |  | 191,409 |  |
| Networking |  |  | 55,430 |  |  |  | 15,724 |  |  |  | 71,154 |  |  |  | 86,303 |  |  |  | 18,591 |  |  |  | 104,894 |  |
| Total |  | $ | 1,157,948 |  |  | $ | 17,302 |  |  | $ | 1,175,250 |  |  | $ | 1,070,642 |  |  | $ | 20,304 |  |  | $ | 1,090,946 |  |

- removed (2024-08-06):
[0000950170-24-054464:note_history:16]
|  |  | Quarter Ended April 1, 2024 |  |
|  |  | PCB |  |  | RF and Specialty Components(RF&S Components) |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 264,776 |  |  | $ | — |  |  | $ | 264,776 |  |
| Automotive |  |  | 73,617 |  |  |  | — |  |  |  | 73,617 |  |
| Data Center Computing |  |  | 119,377 |  |  |  | 59 |  |  |  | 119,436 |  |
| Medical/Industrial/Instrumentation |  |  | 78,793 |  |  |  | 734 |  |  |  | 79,527 |  |
| Networking |  |  | 25,278 |  |  |  | 7,479 |  |  |  | 32,757 |  |
| Total |  | $ | 561,841 |  |  | $ | 8,272 |  |  | $ | 570,113 |  |

- removed (2024-08-06):
[0000950170-24-054464:note_history:17]
|  |  | Quarter Ended April 3, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 232,292 |  |  | $ | — |  |  | $ | 232,292 |  |
| Automotive |  |  | 93,467 |  |  |  | — |  |  |  | 93,467 |  |
| Data Center Computing |  |  | 57,870 |  |  |  | — |  |  |  | 57,870 |  |
| Medical/Industrial/Instrumentation |  |  | 100,768 |  |  |  | 917 |  |  |  | 101,685 |  |
| Networking |  |  | 49,714 |  |  |  | 9,409 |  |  |  | 59,123 |  |
| Total |  | $ | 534,111 |  |  | $ | 10,326 |  |  | $ | 544,437 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0000950170-24-091772:note_history:18]
As of July 1, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $413,941. The Company expects to recognize revenue on approximately 49% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.
  (was, 2024-05-07, similarity 0.9877):
[0000950170-24-054464:note_history:18]
As of April 1, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $385,265. The Company expects to recognize revenue on approximately 49% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.

- changed (2024-08-06):
[0000950170-24-091772:note_history:19]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of July 1, 2024 and January 1, 2024 were $35,227 and $25,213, respectively.
  (was, 2024-05-07, similarity 0.9874):
[0000950170-24-054464:note_history:19]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of April 1, 2024 and January 1, 2024 were $34,044 and $25,213, respectively.

- added (2024-08-06):
[0000950170-24-091772:note_history:20]
Revenue recognized for the two quarters ended July 1, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $28,205. Revenue recognized for the two quarters ended July 3, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $27,069.

- changed (2024-08-06):
[0000950170-24-091772:note_history:21]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for both the quarter and two quarters ended July 1, 2024 and July 3, 2023.
  (was, 2024-05-07, similarity 0.8188):
[0000950170-24-054464:note_history:21]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for the quarters ended April 1, 2024 and April 3, 2023.

- added (2024-08-06):
[0000950170-24-091772:note_history:22]
|  |  | Quarter Ended July 1, 2024 |  |  | Quarter Ended July 3, 2023 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 272,789 |  |  | $ | — |  |  | $ | 272,789 |  |  | $ | 254,284 |  |  | $ | — |  |  | $ | 254,284 |  |
| Automotive |  |  | 82,698 |  |  |  | — |  |  |  | 82,698 |  |  |  | 92,374 |  |  |  | — |  |  |  | 92,374 |  |
| Data Center Computing |  |  | 124,052 |  |  |  | 63 |  |  |  | 124,115 |  |  |  | 64,305 |  |  |  | 51 |  |  |  | 64,356 |  |
| Medical/Industrial/Instrumentation |  |  | 86,416 |  |  |  | 722 |  |  |  | 87,138 |  |  |  | 88,979 |  |  |  | 745 |  |  |  | 89,724 |  |
| Networking |  |  | 30,152 |  |  |  | 8,245 |  |  |  | 38,397 |  |  |  | 36,589 |  |  |  | 9,182 |  |  |  | 45,771 |  |
| Total |  | $ | 596,107 |  |  | $ | 9,030 |  |  | $ | 605,137 |  |  | $ | 536,531 |  |  | $ | 9,978 |  |  | $ | 546,509 |  |

- added (2024-08-06):
[0000950170-24-091772:note_history:23]
|  |  | Two Quarters Ended July 1, 2024 |  |  | Two Quarters Ended July 3, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 537,565 |  |  | $ | — |  |  | $ | 537,565 |  |  | $ | 486,576 |  |  | $ | — |  |  | $ | 486,576 |  |
| Automotive |  |  | 156,315 |  |  |  | — |  |  |  | 156,315 |  |  |  | 185,841 |  |  |  | — |  |  |  | 185,841 |  |
| Data Center Computing |  |  | 243,429 |  |  |  | 122 |  |  |  | 243,551 |  |  |  | 122,175 |  |  |  | 51 |  |  |  | 122,226 |  |
| Medical/Industrial/Instrumentation |  |  | 165,209 |  |  |  | 1,456 |  |  |  | 166,665 |  |  |  | 189,747 |  |  |  | 1,662 |  |  |  | 191,409 |  |
| Networking |  |  | 55,430 |  |  |  | 15,724 |  |  |  | 71,154 |  |  |  | 86,303 |  |  |  | 18,591 |  |  |  | 104,894 |  |
| Total |  | $ | 1,157,948 |  |  | $ | 17,302 |  |  | $ | 1,175,250 |  |  | $ | 1,070,642 |  |  | $ | 20,304 |  |  | $ | 1,090,946 |  |

- removed (2024-08-06):
[0000950170-24-054464:note_history:24]
Revenue recognized for the quarter ended April 1, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $18,214. Revenue recognized for the quarter ended April 3, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $18,508.

- removed (2024-08-06):
[0000950170-24-054464:note_history:25]
|  |  | Quarter Ended April 1, 2024 |  |
|  |  | PCB |  |  | RF and Specialty Components(RF&S Components) |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 264,776 |  |  | $ | — |  |  | $ | 264,776 |  |
| Automotive |  |  | 73,617 |  |  |  | — |  |  |  | 73,617 |  |
| Data Center Computing |  |  | 119,377 |  |  |  | 59 |  |  |  | 119,436 |  |
| Medical/Industrial/Instrumentation |  |  | 78,793 |  |  |  | 734 |  |  |  | 79,527 |  |
| Networking |  |  | 25,278 |  |  |  | 7,479 |  |  |  | 32,757 |  |
| Total |  | $ | 561,841 |  |  | $ | 8,272 |  |  | $ | 570,113 |  |

- removed (2024-08-06):
[0000950170-24-054464:note_history:26]
|  |  | Quarter Ended April 3, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 232,292 |  |  | $ | — |  |  | $ | 232,292 |  |
| Automotive |  |  | 93,467 |  |  |  | — |  |  |  | 93,467 |  |
| Data Center Computing |  |  | 57,870 |  |  |  | — |  |  |  | 57,870 |  |
| Medical/Industrial/Instrumentation |  |  | 100,768 |  |  |  | 917 |  |  |  | 101,685 |  |
| Networking |  |  | 49,714 |  |  |  | 9,409 |  |  |  | 59,123 |  |
| Total |  | $ | 534,111 |  |  | $ | 10,326 |  |  | $ | 544,437 |  |
