# TTMI notes — 0001564590-21-024040


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-21-024040:notes:1]
[same as prior period, unchanged from 0001564590-20-051296:notes:1]

[0001564590-21-024040:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This one-stop design, engineering and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001564590-21-024040:notes:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-21-024040:notes:4]
[same as prior period, unchanged from 0001564590-20-051296:notes:4]

[0001564590-21-024040:notes:5]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income (loss) from discontinued operations, net of income taxes”. Refer to Note 2, Discontinued Operations, for additional information.

[0001564590-21-024040:notes:6]
[same as prior period, unchanged from 0001564590-20-051296:notes:6]

[0001564590-21-024040:notes:7]
[same as prior period, unchanged from 0001564590-20-051296:notes:7]

[0001564590-21-024040:notes:8]
The Company currently has two reportable segments: PCB and RF and Specialty Components (RF&S Components). In fiscal 2020, subsequent to the quarter ended March 30, 2020, RF&S Components was added as a reportable segment. As a result, the Company had three reportable segments as of December 28, 2020: PCB, RF&S Components, and E-M Solutions. On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer meets the criteria for segment reporting. As a result of the addition of the RF&S Components reportable segment and the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.

[0001564590-21-024040:notes:9]
[same as prior period, unchanged from 0001564590-20-051296:notes:13]

[0001564590-21-024040:notes:10]
Recently Adopted Accounting Standards

[0001564590-21-024040:notes:11]
In December 2019, the Financial Accounting Standards Board (FASB) issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes.

[0001564590-21-024040:notes:12]
ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company adopted this ASU as of December 29, 2020 and it did not have a material impact on its consolidated condensed financial statements and related disclosures.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-21-024040:notes:13]
[same as prior period, unchanged from 0001564590-20-051296:notes:20]

[0001564590-21-024040:notes:14]
[same as prior period, unchanged from 0001564590-20-051296:notes:21]

[0001564590-21-024040:notes:15]
On April 18, 2020, the Company entered into a Transition Services Agreement (TSA) with the Purchaser pursuant to which the Purchaser is receiving certain services (the Services) to enable it to operate the Mobility business unit after the closing of the sale of the Mobility business unit. The Services include finance and accounting, human resources, legal and compliance, sales, information technology, and other corporate support services. Under the TSA, the Services are being provided at cost for a period of up to 24 months. In addition, the Company entered into a Manufacturing Supply Agreement with the Purchaser pursuant to which the Purchaser will supply products to a few customers of the Company. There was no material impact on the Company’s consolidated condensed financial statements.

[0001564590-21-024040:notes:16]
Further, on June 29, 2020, the Company entered into a Sales Force Agreement with the Purchaser pursuant to which the Company’s sales representatives assist the Purchaser in selling PCBs manufactured by the Purchaser to certain customers for a commission for a period up to April 17, 2021. There was no material impact on the Company’s consolidated condensed financial statements.

[0001564590-21-024040:notes:17]
As the sale of the Company’s Mobility business unit represents a strategic shift that will have a major effect on the Company’s operations and financial results, in accordance with the provisions of FASB authoritative guidance on the presentation of financial statements, Mobility business unit results are classified as discontinued operations in the consolidated condensed statements of operations for all periods presented.

[0001564590-21-024040:notes:18]
The following table summarizes the results of Mobility operations for the quarter ended March 30, 2020 prior to sale:

[0001564590-21-024040:notes:19]
|  |  | Quarter Ended |  |
|  |  | March 30, |  |
|  |  | 2020 |  |
|  |  | (In thousands) |  |
| Net sales |  | $ | 113,174 |  |
| Cost of goods sold |  |  | 108,425 |  |
| Gross profit |  |  | 4,749 |  |
| Operating expenses: |  |  |  |  |
| Selling and marketing |  |  | 1,176 |  |
| General and administrative |  |  | 1,310 |  |
| Research and development |  |  | 147 |  |
| Amortization of definite-lived intangibles |  |  | 675 |  |
| Total operating expenses |  |  | 3,308 |  |
| Operating income |  |  | 1,441 |  |
| Other (expense) income: |  |  |  |  |
| Interest expense |  |  | (223 | ) |
| Other, net |  |  | 1,571 |  |
| Total other income, net |  |  | 1,348 |  |
| Income from discontinued operations before income taxes |  |  | 2,789 |  |
| Income tax provision |  |  | (743 | ) |
| Income from discontinued operations, net of income taxes |  | $ | 2,046 |  |
| Earnings per share from discontinued operations: |  |  |  |  |
| Basic earnings per share |  | $ | 0.02 |  |
| Diluted earnings per share |  | $ | 0.02 |  |

[0001564590-21-024040:notes:20]
Depreciation expense related to the discontinued operations for the quarter ended March 30, 2020 was $18,265.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-21-024040:notes:21]
[same as prior period, unchanged from 0001564590-20-051296:notes:34]

[0001564590-21-024040:notes:22]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the right-of-use (ROU) asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-21-024040:notes:23]
[same as prior period, unchanged from 0001564590-20-051296:notes:36]

[0001564590-21-024040:notes:24]
|  |  | Quarter Ended |  |
|  |  | March 29, 2021 |  |  | March 30, 2020 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 2,208 |  |  | $ | 2,481 |  |
| Variable lease cost |  |  | 234 |  |  |  | 106 |  |
| Short-term lease cost |  |  | 54 |  |  |  | 229 |  |

[0001564590-21-024040:notes:25]
[same as prior period, unchanged from 0001564590-20-051296:notes:38]

[0001564590-21-024040:notes:26]
|  |  | Quarter Ended |  |
|  |  | March 29, 2021 |  |  | March 30, 2020 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 2,159 |  |  | $ | 2,171 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 284 |  |  |  | 1,876 |  |

[0001564590-21-024040:notes:27]
[same as prior period, unchanged from 0001564590-20-051296:notes:40]

[0001564590-21-024040:notes:28]
|  |  | As of |  |
|  |  | March 29, 2021 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Operating lease right-of-use assets |  | $ | 21,383 |  |  | $ | 24,340 |  |
| Other current liabilities |  |  | 6,609 |  |  |  | 8,144 |  |
| Operating lease liabilities |  |  | 15,658 |  |  |  | 17,211 |  |
| Total operating lease liabilities |  | $ | 22,267 |  |  | $ | 25,355 |  |

[0001564590-21-024040:notes:29]
|  |  | As of |  |
|  |  | March 29, 2021 |  |  | December 28, 2020 |  |
| Weighted average remaining lease term |  | 4.4 years |  |  | 4.2 years |  |
| Weighted average discount rate |  |  | 3.29 | % |  |  | 3.31 | % |

[0001564590-21-024040:notes:30]
[same as prior period, unchanged from 0001564590-20-051296:notes:43]

[0001564590-21-024040:notes:31]
|  |  | (In thousands) |  |
| Less than one year |  | $ | 7,214 |  |
| 1 - 2 years |  |  | 5,015 |  |
| 2 - 3 years |  |  | 4,309 |  |
| 3 - 4 years |  |  | 3,370 |  |
| 4 - 5 years |  |  | 2,123 |  |
| Thereafter |  |  | 1,902 |  |
| Total lease payments |  |  | 23,933 |  |
| Less imputed interest |  |  | (1,666 | ) |
| Total |  | $ | 22,267 |  |

[0001564590-21-024040:notes:32]
|  | (1) | Excludes $851 of legally binding minimum lease payments for leases signed but not yet commenced. |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-21-024040:notes:33]
[same as prior period, unchanged from 0001564590-20-051296:notes:46]

[0001564590-21-024040:notes:34]
As of March 29, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $12,850. The Company expects to recognize revenue on approximately 100% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.

[0001564590-21-024040:notes:35]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the both the quarters ended March 29, 2021 and March 30, 2020.

[0001564590-21-024040:notes:36]
[same as prior period, unchanged from 0001564590-20-051296:notes:49]

[0001564590-21-024040:notes:37]
|  |  | Quarter Ended March 29, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 186,539 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 186,545 |  |  |
| Automotive |  |  | 91,792 |  |  |  | — |  |  |  | 3,642 |  |  |  | 95,434 |  |  |
| Data Center Computing (2) |  |  | 71,759 |  |  |  | 432 |  |  |  | — |  |  |  | 72,191 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,770 |  |  |  | 1,081 |  |  |  | 25 |  |  |  | 91,876 |  |  |
| Networking/Communications |  |  | 66,938 |  |  |  | 10,653 |  |  |  | 1 |  |  |  | 77,592 |  |  |
| Other |  |  | 2,688 |  |  |  | 518 |  |  |  | (412 | ) |  |  | 2,794 |  |  |
| Total |  | $ | 510,486 |  |  | $ | 12,690 |  |  | $ | 3,256 |  |  | $ | 526,432 |  |  |

[0001564590-21-024040:notes:38]
|  |  | Quarter Ended March 30, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 184,414 |  |  | $ | — |  |  | $ | — |  |  | $ | 184,414 |  |  |
| Automotive |  |  | 61,858 |  |  |  | — |  |  |  | 7,013 |  |  |  | 68,871 |  |  |
| Cellular Phone |  |  | 2,775 |  |  |  | — |  |  |  | — |  |  |  | 2,775 |  |  |
| Data Center Computing (2) |  |  | 58,114 |  |  |  | 203 |  |  |  | 54 |  |  |  | 58,371 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,468 |  |  |  | 794 |  |  |  | 3,320 |  |  |  | 94,582 |  |  |
| Networking/Communications |  |  | 70,433 |  |  |  | 8,067 |  |  |  | 4,195 |  |  |  | 82,695 |  |  |
| Other |  |  | 5,940 |  |  |  | 377 |  |  |  | (379 | ) |  |  | 5,938 |  |  |
| Total |  | $ | 474,002 |  |  | $ | 9,441 |  |  | $ | 14,203 |  |  | $ | 497,646 |  |  |

[0001564590-21-024040:notes:39]
| (1) | Other represents SH E-MS and SZ results. |

[0001564590-21-024040:notes:40]
| (2) | In the current period, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-21-024040:notes:41]
[same as prior period, unchanged from 0001564590-20-051296:notes:52]

[0001564590-21-024040:notes:42]
|  |  | As of |  |
|  |  | March 29, 2021 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 108,271 |  |  | $ | 103,890 |  |
| Work-in-process |  |  | 9,259 |  |  |  | 7,841 |  |
| Finished goods |  |  | 3,594 |  |  |  | 3,920 |  |
|  |  | $ | 121,124 |  |  | $ | 115,651 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 62,061 |  |  | $ | 61,781 |  |
| Buildings and improvements |  |  | 402,361 |  |  |  | 398,540 |  |
| Machinery and equipment |  |  | 840,249 |  |  |  | 832,723 |  |
| Furniture and fixtures and other |  |  | 10,198 |  |  |  | 10,304 |  |
| Construction-in-progress |  |  | 36,911 |  |  |  | 33,191 |  |
|  |  |  | 1,351,780 |  |  |  | 1,336,539 |  |
| Less: Accumulated depreciation |  |  | (700,586 | ) |  |  | (686,104 | ) |
|  |  | $ | 651,194 |  |  | $ | 650,435 |  |
| Other current liabilities: |  |  |  |  |  |  |  |  |
| Sales returns and allowances |  | $ | 12,669 |  |  | $ | 13,015 |  |
| Income taxes payable |  |  | 5,553 |  |  |  | 2,428 |  |
| Warrant liabilities |  |  | 4,070 |  |  |  | — |  |
| Restructuring |  |  | 3,184 |  |  |  | 7,382 |  |
| Interest |  |  | 3,051 |  |  |  | 7,157 |  |
| Other |  |  | 58,201 |  |  |  | 59,440 |  |
|  |  | $ | 86,728 |  |  | $ | 89,422 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 23,782 |  |  | $ | 23,704 |  |
| Derivative liabilities |  |  | 12,579 |  |  |  | 14,968 |  |
| Defined benefit pension plan liability |  |  | 9,605 |  |  |  | 9,986 |  |
| Other |  |  | 26,455 |  |  |  | 25,167 |  |
|  |  | $ | 72,421 |  |  | $ | 73,825 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-21-024040:notes:43]
[same as prior period, unchanged from 0001564590-20-051296:notes:54]

[0001564590-21-024040:notes:44]
As of March 29, 2021 and December 28, 2020, goodwill by reportable segment was as follows:

[0001564590-21-024040:notes:45]
|  |  | PCB |  | RF&S Components |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 28, 2020 and March 29, 2021 |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 700,724 |  | $ | 177,200 |  | $ | 877,924 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (69,200 | ) |  | (240,600 | ) |
|  |  | $ | 529,324 |  | $ | 108,000 |  | $ | 637,324 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-21-024040:notes:46]
[same as prior period, unchanged from 0001564590-20-051296:notes:62]

[0001564590-21-024040:notes:47]
As of March 29, 2021 and December 28, 2020, the components of definite-lived intangibles were as follows:

[0001564590-21-024040:notes:48]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| March 29, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 397,500 |  |  | $ | (159,663 | ) |  | $ | 237,837 |  |  |  | 10.9 |  |
| Technology |  |  | 47,650 |  |  |  | (15,085 | ) |  |  | 32,565 |  |  |  | 9.5 |  |
|  |  | $ | 445,150 |  |  | $ | (174,748 | ) |  | $ | 270,402 |  |  |  |  |  |
| December 28, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 397,500 |  |  | $ | (150,142 | ) |  | $ | 247,358 |  |  |  | 10.9 |  |
| Technology |  |  | 47,650 |  |  |  | (13,701 | ) |  |  | 33,949 |  |  |  | 9.5 |  |
|  |  | $ | 445,150 |  |  | $ | (163,843 | ) |  | $ | 281,307 |  |  |  |  |  |

[0001564590-21-024040:notes:49]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $10,905 and $10,945 for the quarters ended March 29, 2021 and March 30, 2020, respectively. For the quarters ended March 29, 2021 and March 30, 2020, $1,384 and $1,383, respectively, of amortization expense is included in cost of goods sold.

[0001564590-21-024040:notes:50]
[same as prior period, unchanged from 0001564590-20-051296:notes:66]

[0001564590-21-024040:notes:51]
|  |  | (In thousands) |  |
| Remaining 2021 |  | $ | 30,274 |  |
| 2022 |  |  | 38,631 |  |
| 2023 |  |  | 36,713 |  |
| 2024 |  |  | 29,713 |  |
| 2025 |  |  | 25,397 |  |
| Thereafter |  |  | 109,674 |  |
|  |  | $ | 270,402 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-21-024040:notes:52]
(8) Long-term Debt and Letters of Credit

[0001564590-21-024040:notes:53]
The following table summarizes the long-term debt of the Company as of March 29, 2021 and December 28, 2020:

[0001564590-21-024040:notes:54]
|  |  | Interest Rate as of March 29, 2021 |  |  | Principal Outstanding as of March 29, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.61 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.51 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (763 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,988 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,128 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,128 |  |  |  |  |  |  | $ | 842,853 |  |

[0001564590-21-024040:notes:55]
The Company has twelve months from September 3, 2020 to reinvest the cash proceeds received from the sale of the Mobility business unit. If the proceeds are not reinvested, the Company is required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to repay $400,000 of the Term Loan during the year ended December 28, 2020 and plans to use

[0001564590-21-024040:notes:56]
the remaining cash proceeds for reinvestment. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

[0001564590-21-024040:notes:57]
Senior Notes due 2029

[0001564590-21-024040:notes:58]
On March 10, 2021, the Company issued $500,000 of Senior Notes due 2029, which are included in long-term debt and bear interest at a rate of 4.0% per annum. Interest is payable semiannually in arrears on March 1 and September 1 of each year beginning September 1, 2021. The Senior Notes due 2029 will mature on March 1, 2029.

[0001564590-21-024040:notes:59]
The Company used a portion of the net proceeds from the issuance of the Senior Notes due 2029 during the quarter ended March 29, 2021 to: (i) fund the early retirement of $375,000 Senior Notes due 2025, (ii) fund the repayment of $40,000 outstanding under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) Revolving credit facility (but not terminate the commitments thereunder), and (iii) pay related premiums, fees and expenses. The Company intends to use the remaining net proceeds for general corporate purposes.

[0001564590-21-024040:notes:60]
Asset-Based Lending Agreements

[0001564590-21-024040:notes:61]
As of March 29, 2021, letters of credit in the amount of $10,753 were outstanding under the U.S. ABL and $11,721 were outstanding under the Asia ABL with various expiration dates through July 2021. Available borrowing capacity under the U.S. ABL and the Asia ABL was $139,247 and $108,279, respectively, which considers letters of credit outstanding as of March 29, 2021.

[0001564590-21-024040:notes:62]
Debt Covenants

[0001564590-21-024040:notes:63]
Borrowings under the Term Loan and Senior Notes due 2029 are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-21-024040:notes:64]
Under the occurrence of certain events, the U.S. ABL and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0001564590-21-024040:notes:65]
Debt Issuance and Debt Discount

[0001564590-21-024040:notes:66]
As of March 29, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:

[0001564590-21-024040:notes:67]
|  |  | As of March 29, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,462 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,526 |  |  |  | 763 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,988 |  |  | $ | 763 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |

[0001564590-21-024040:notes:68]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-21-024040:notes:69]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,778 and $1,919 as of March 29, 2021 and December 28, 2020, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0001564590-21-024040:notes:70]
As of March 29, 2021, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 5.9 years.

[0001564590-21-024040:notes:71]
Loss on Extinguishment of Debt

[0001564590-21-024040:notes:72]
During the quarter ended March 29, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-024040:notes:73]
[same as prior period, unchanged from 0001564590-20-051296:notes:82]

[0001564590-21-024040:notes:74]
[same as prior period, unchanged from 0001564590-20-051296:notes:83]

[0001564590-21-024040:notes:75]
During the quarter ended March 29, 2021, the Company’s effective tax rate was impacted by a net discrete benefit of $383. This benefit resulted from the approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China, including the impact on the respective Company’s deferred tax amounts, partially offset by tax expense on stock based compensation releases and the accrued interest expense on existing uncertain tax positions.

[0001564590-21-024040:notes:76]
[same as prior period, unchanged from 0001564590-20-051296:notes:85]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-21-024040:notes:77]
[same as prior period, unchanged from 0001564590-20-051296:notes:86]

[0001564590-21-024040:notes:78]
[same as prior period, unchanged from 0001564590-20-051296:notes:87]

[0001564590-21-024040:notes:79]
[same as prior period, unchanged from 0001564590-20-051296:notes:88]

[0001564590-21-024040:notes:80]
[same as prior period, unchanged from 0001564590-20-051296:notes:89]

[0001564590-21-024040:notes:81]
On May 15, 2018, the Company entered into a four-year pay-fixed, receive floating (1-month LIBOR), interest rate swap arrangement with a notional amount of $400,000 for the period beginning June 1, 2018 and ending on June 1, 2022. Under the terms of the interest rate swap, the Company pays a fixed rate of 2.84% against a portion of its LIBOR-based debt and receives floating 1-month LIBOR during the swap period.

[0001564590-21-024040:notes:82]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of March 29, 2021, the fair value of the interest rate swap was recorded as a liability in the amount of $12,579 and included as a component of other long-term liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax. No ineffectiveness was recognized for the quarters ended March 29, 2021 and March 30, 2020. The interest rate swap increased interest expense by $2,740 and $1,175 for the quarters ended March 29, 2021 and March 30, 2020, respectively.

[0001564590-21-024040:notes:83]
[same as prior period, unchanged from 0001564590-20-051296:notes:92]

[0001564590-21-024040:notes:84]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than its functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts as of March 29, 2021 and December 28, 2020 was approximately $1,852 (Japanese Yen (JPY) 196.3 million) and $1,181 (JPY 125.0 million), respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-21-024040:notes:85]
[same as prior period, unchanged from 0001564590-20-051296:notes:94]

[0001564590-21-024040:notes:86]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | March 29, 2021 |  |  | December 28, 2020 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other long-term liabilities |  | $ | (12,579 | ) |  | $ | (14,968 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | — |  |  |  | 28 |  |
| Foreign exchange contracts |  | Other current liabilities |  |  | 56 |  |  |  | — |  |

[0001564590-21-024040:notes:87]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the quarters ended March 29, 2021 and March 30, 2020:

[0001564590-21-024040:notes:88]
|  |  |  | Quarter Ended March 29, 2021 |  |  | Quarter Ended March 30, 2020 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (351 | ) |  | $ | (2,740 | ) |  | $ | (8,449 | ) |  | $ | (1,175 | ) |  |

[0001564590-21-024040:notes:89]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the quarters ended March 29, 2021 and March 30, 2020:

[0001564590-21-024040:notes:90]
|  |  | Quarter Ended |
|  |  | March 29, |  |  | March 30, |  |  |
|  |  | 2021 |  |  | 2020 |  |  |
|  |  | (In thousands) |
| Beginning balance, net of tax |  | $ | (11,231 | ) |  | $ | (9,617 | ) |  |
| Changes in fair value loss, net of tax |  |  | (263 | ) |  |  | (6,018 | ) |  |
| Reclassification to earnings |  |  | 2,052 |  |  |  | 860 |  |  |
| Ending balance, net of tax |  | $ | (9,442 | ) |  | $ | (14,775 | ) |  |

[0001564590-21-024040:notes:91]
Based on the current yield curve, the Company expects that losses of approximately $8,092 of the accumulated other comprehensive loss will be reclassified into the statement of operations, net of tax, in the next twelve months.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-21-024040:notes:92]
[same as prior period, unchanged from 0001564590-20-051296:notes:102]

[0001564590-21-024040:notes:93]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of March 29, 2021 and December 28, 2020:

[0001564590-21-024040:notes:94]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | (Losses) Gains on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of December 28, 2020 |  | $ | (24,827 | ) |  | $ | (2,855 | ) |  | $ | (11,231 | ) |  | $ | (38,913 | ) |
| Other comprehensive loss before reclassifications |  |  | (3 | ) |  |  | — |  |  |  | (263 | ) |  |  | (266 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | 2,052 |  |  |  | 2,052 |  |
| Other comprehensive (loss) income |  |  | (3 | ) |  |  | — |  |  |  | 1,789 |  |  |  | 1,786 |  |
| Ending balance as of March 29, 2021 |  | $ | (24,830 | ) |  | $ | (2,855 | ) |  | $ | (9,442 | ) |  | $ | (37,127 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-21-024040:notes:95]
[same as prior period, unchanged from 0001564590-20-051296:notes:105]

[0001564590-21-024040:notes:96]
[same as prior period, unchanged from 0001564590-20-051296:notes:106]

[0001564590-21-024040:notes:97]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.

[0001564590-21-024040:notes:98]
For the quarter ended March 29, 2021, other than one customer that accounted for approximately 13% of the Company’s net sales, there were no other customers that accounted for 10% or more of net sales. For the quarter ended March 30, 2020, there were no customers that accounted for 10% or more of net sales.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-21-024040:notes:99]
[same as prior period, unchanged from 0001564590-20-051296:notes:108]

[0001564590-21-024040:notes:100]
[same as prior period, unchanged from 0001564590-20-051296:notes:109]

[0001564590-21-024040:notes:101]
The carrying amount and estimated fair value of the Company’s financial instruments as of March 29, 2021 and December 28, 2020 were as follows:

[0001564590-21-024040:notes:102]
|  |  | As of |  |  | As of |  |
|  |  | March 29, 2021 |  |  | December 28, 2020 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | — |  |  | $ | — |  |  | $ | 28 |  |  | $ | 28 |  |
| Derivative liabilities, current |  |  | 56 |  |  |  | 56 |  |  |  | — |  |  |  | — |  |
| Derivative liabilities, non-current |  |  | 12,579 |  |  |  | 12,579 |  |  |  | 14,968 |  |  |  | 14,968 |  |
| Warrant liabilities, current |  |  | 4,070 |  |  |  | 4,070 |  |  |  | — |  |  |  | — |  |
| Senior Notes due March 2029 |  |  | 493,538 |  |  |  | 493,425 |  |  |  | — |  |  |  | — |  |
| Term Loan due September 2024 |  |  | 402,590 |  |  |  | 406,387 |  |  |  | 402,370 |  |  |  | 407,909 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 370,483 |  |  |  | 383,974 |  |
| ABL Revolving Loans |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |

[0001564590-21-024040:notes:103]
[same as prior period, unchanged from 0001564590-20-051296:notes:112]

[0001564590-21-024040:notes:104]
The fair value of the warrant liabilities was valued using the Black-Scholes model with the following weighted-average assumptions: expected term of 0.25 years, expected volatility of 35%, risk-free interest rate of 0.032%, and expected dividend yield of 0%. The inputs used in the warrant valuation are considered Level 3 inputs.

[0001564590-21-024040:notes:105]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of March 29, 2021 and December 28, 2020, which are considered Level 2 inputs.

[0001564590-21-024040:notes:106]
As of March 29, 2021 and December 28, 2020, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of March 29, 2021 consisted of $305,841 held in the U.S., with the remaining $233,807 held by foreign subsidiaries.

[0001564590-21-024040:notes:107]
[same as prior period, unchanged from 0001564590-20-051296:notes:116]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-024040:notes:108]
(14) Commitments and Contingencies

[0001564590-21-024040:notes:109]
Legal Matters

[0001564590-21-024040:notes:110]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of March 29, 2021 and December 28, 2020. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-024040:notes:111]
(15) Loss Per Share

[0001564590-21-024040:notes:112]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share from continuing operations for the quarters ended March 29, 2021 and March 30, 2020:

[0001564590-21-024040:notes:113]
|  |  | Quarter Ended |  |
|  |  | March 29, 2021 |  |  | March 30, 2020 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net loss from continuing operations |  | $ | (3,192 | ) |  | $ | (3,220 | ) |
| Basic weighted average shares |  |  | 106,825 |  |  |  | 105,686 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | — |  |  |  | — |  |
| Diluted shares |  |  | 106,825 |  |  |  | 105,686 |  |
| Loss per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.03 | ) |  | $ | (0.03 | ) |
| Diluted |  | $ | (0.03 | ) |  | $ | (0.03 | ) |

[0001564590-21-024040:notes:114]
For the quarter ended March 29, 2021, potential shares of common stock, consisting of stock options to purchase approximately 60 shares of common stock at exercise prices ranging from $11.83 to $16.60 per share, 2,897 restricted stock units (RSUs), and 289 performance-based restricted stock units (PRUs) were not included in the computation of diluted earnings per share because the Company incurred a net loss and as a result, the impact would be anti-dilutive. For the quarter ended March 30, 2020, potential shares of common stock, consisting of stock options to purchase approximately 100 shares of common stock at exercise prices ranging from $9.54 to $16.60 per share, 2,459 RSUs, and 216 PRUs were not included in the computation of diluted earnings per share because the Company incurred a net loss and, as a result, the impact would be anti-dilutive.

[0001564590-21-024040:notes:115]
Outstanding warrants for the quarters ended March 29, 2021 and March 30, 2020, to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock was greater than the average market price of common shares during the applicable quarter and because the Company incurred a net loss, and therefore, the effect would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-21-024040:notes:116]
[same as prior period, unchanged from 0001564590-20-051296:notes:129]

[0001564590-21-024040:notes:117]
[same as prior period, unchanged from 0001564590-20-051296:notes:130]

[0001564590-21-024040:notes:118]
|  |  | Quarter Ended |
|  |  | March 29, |  |  | March 30, |  |  |
|  |  | 2021 |  |  | 2020 |  |  |
|  |  | (In thousands) |
| Cost of goods sold |  | $ | 1,165 |  |  | $ | 850 |  |  |
| Selling and marketing |  |  | 646 |  |  |  | 451 |  |  |
| General and administrative |  |  | 2,355 |  |  |  | 3,477 |  |  |
| Research and development |  |  | 43 |  |  |  | 57 |  |  |
| Stock-based compensation expense recognized |  | $ | 4,209 |  |  | $ | 4,835 |  |  |

[0001564590-21-024040:notes:119]
[same as prior period, unchanged from 0001564590-20-051296:notes:132]

[0001564590-21-024040:notes:120]
The following is a summary of total unrecognized compensation costs as of March 29, 2021:

[0001564590-21-024040:notes:121]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 17,102 |  |  |  | 1.4 |  |
| PRU awards |  |  | 3,974 |  |  |  | 1.4 |  |
| Stock options |  |  | 110 |  |  |  | 1.1 |  |
|  |  | $ | 21,186 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-024040:notes:122]
[same as prior period, unchanged from 0001564590-20-051296:notes:135]

[0001564590-21-024040:notes:123]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. In fiscal 2020, subsequent to the quarter ended March 30, 2020, RF&S Components was added as a reportable segment. As a result, the Company had three reportable segments as of December 28, 2020: PCB, RF&S Components, and E-M Solutions. On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer meets the criteria for segment reporting. As a result of the addition of the RF&S Components reportable segment and the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.

[0001564590-21-024040:notes:124]
[same as prior period, unchanged from 0001564590-20-051296:notes:137]

[0001564590-21-024040:notes:125]
|  |  | Quarter Ended |  |
|  |  | March 29, 2021 |  |  | March 30, 2020 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 510,486 |  |  | $ | 474,002 |  |
| RF&S Components |  |  | 12,690 |  |  |  | 9,441 |  |
| Other (1) |  |  | 3,256 |  |  |  | 14,203 |  |
| Total net sales |  | $ | 526,432 |  |  | $ | 497,646 |  |
| Operating Segment Loss: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 57,232 |  |  | $ | 60,238 |  |
| RF&S Components |  |  | 3,862 |  |  |  | 1,908 |  |
| Corporate and Other (1) |  |  | (30,389 | ) |  |  | (35,019 | ) |
| Total operating segment income |  |  | 30,705 |  |  |  | 27,127 |  |
| Amortization of definite-lived intangibles (2) |  |  | (10,905 | ) |  |  | (10,945 | ) |
| Total operating income |  |  | 19,800 |  |  |  | 16,182 |  |
| Total other expense |  |  | (24,099 | ) |  |  | (17,279 | ) |
| Loss before income taxes |  | $ | (4,299 | ) |  | $ | (1,097 | ) |

[0001564590-21-024040:notes:126]
|  |  | As of |  |
|  |  | March 29, 2021 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,549,531 |  |  | $ | 1,529,102 |  |
| RF&S Components |  |  | 225,233 |  |  |  | 227,990 |  |
| Corporate and Other (1) |  |  | 1,191,064 |  |  |  | 1,138,852 |  |
| Total assets |  | $ | 2,965,828 |  |  | $ | 2,895,944 |  |

[0001564590-21-024040:notes:127]
| (2) | Amortization of definite-lived intangibles primarily relates to the PCB and RF&S Components reportable segments. For the quarters ended March 29, 2021 and March 30, 2020, $1,384 and $1,383, respectively, of amortization expense is included in cost of goods sold. |

[0001564590-21-024040:notes:128]
The Corporate category primarily includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, information technology, facilities and human resources personnel, as well as global sales and marketing personnel, research and development costs, and acquisition and integration costs associated with acquisitions and divestitures.

[0001564590-21-024040:notes:129]
The Company markets and sells its products in approximately 46 countries. Other than in the United States and China, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales are as follows:

[0001564590-21-024040:notes:130]
|  |  | Quarter Ended |  |
|  |  | March 29, 2021 |  |  | March 30, 2020 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| United States |  | $ | 268,467 |  |  | $ | 262,279 |  |
| China |  |  | 81,709 |  |  |  | 74,929 |  |
| Other |  |  | 176,256 |  |  |  | 160,438 |  |
| Total net sales |  | $ | 526,432 |  |  | $ | 497,646 |  |

[0001564590-21-024040:notes:131]
[same as prior period, unchanged from 0001564590-20-051296:notes:144]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-024040:notes:132]
(18) Restructuring Charges

[0001564590-21-024040:notes:133]
On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. The E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company ceased operations at the SH E-MS and SZ facilities while integrating the SH BPA facility into its PCB operations. The restructuring is another step in advancing the Company’s stated strategy of increasing its focus on differentiated higher margin products that more fully leverage the Company’s early engagement capabilities and industry leading engineering-based technology solutions. The Company closed the SH E-MS and SZ facilities at the end of 2020. As of March 29, 2021, the Company has incurred approximately $19,272 of restructuring charges and $6,702 of accelerated depreciation expense since the April 29, 2020 announcement.

[0001564590-21-024040:notes:134]
In connection with the restructuring of its E-M Solutions business unit and other global realignment restructuring efforts, the Company recognized employee separation, contract termination and other costs during the quarters ended March 29, 2021 and March 30, 2020. Contract termination and other costs primarily represented plant closure costs.

[0001564590-21-024040:notes:135]
The below table summarizes such restructuring costs by reportable segment, which are included as a component of general and administrative expenses in the consolidated condensed statements of operations, for the quarters ended March 29, 2021 and March 30, 2020:

[0001564590-21-024040:notes:136]
|  |  | Quarter Ended March 29, 2021 |  |  |
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  |
|  |  | (In thousands) |  |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 342 |  |  | $ | 12 |  |  | $ | 354 |  |  |
| Corporate and Other (1) |  |  | 359 |  |  |  | 2,519 |  |  |  | 2,878 |  |  |
|  |  | $ | 701 |  |  | $ | 2,531 |  |  | $ | 3,232 |  |  |

[0001564590-21-024040:notes:137]
|  |  | Quarter Ended March 30, 2020 |  |  |
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  |
|  |  | (In thousands) |  |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | — |  |  | $ | 13 |  |  | $ | 13 |  |  |
| Corporate and Other (1) |  |  | 309 |  |  |  | 6 |  |  |  | 315 |  |  |
|  |  | $ | 309 |  |  | $ | 19 |  |  | $ | 328 |  |  |

[0001564590-21-024040:notes:138]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated condensed balance sheet. The below table shows the utilization of the accrued restructuring costs during the quarter ended March 29, 2021:

[0001564590-21-024040:notes:139]
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of December 28, 2020 |  | $ | 7,063 |  |  | $ | 319 |  |  | $ | 7,382 |  |
| Charged to expense |  |  | 701 |  |  |  | 2,531 |  |  |  | 3,232 |  |
| Amount paid |  |  | (4,629 | ) |  |  | (2,801 | ) |  |  | (7,430 | ) |
| Accrued as of March 29, 2021 |  | $ | 3,135 |  |  | $ | 49 |  |  | $ | 3,184 |  |
