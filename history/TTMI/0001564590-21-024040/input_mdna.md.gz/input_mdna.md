# TTMI MD&A — 0001564590-21-024040


## mdna

[0001564590-21-024040:mdna:1]
[same as prior period, unchanged from 0001564590-20-051296:mdna:1]

[0001564590-21-024040:mdna:2]
[same as prior period, unchanged from 0001564590-20-051296:mdna:2]

[0001564590-21-024040:mdna:3]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering and manufacturing solution to our customers. This one-stop design, engineering and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,100 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-21-024040:mdna:4]
[same as prior period, unchanged from 0001564590-20-051296:mdna:4]

[0001564590-21-024040:mdna:5]
The coronavirus (COVID-19) pandemic first caused business disruption in our operations in China in January 2020. By March 2020, the situation escalated as the scope of the COVID-19 pandemic worsened outside of the Asia-Pacific region, with Europe and North America being affected by the pandemic. Also, we experienced an increase in COVID-19 cases in our facilities in North America during the fourth quarter of 2020. As a result, we expect continued impacts on our production, as well as ongoing significant uncertainty relating to the actual and potential impacts of the COVID-19 pandemic, and we cannot reasonably estimate its duration or severity. The COVID-19 pandemic has created and continues to create various global macroeconomic, customer demand, operational and supply chain risks any one of which could have a material and adverse impact on our business going forward. See Item 1A, Risk Factors, of Part II below for further information related to the COVID-19 pandemic. We have taken active measures to protect our employees, suppliers and customers by implementing our pandemic recovery protocols, establishing situational leadership teams in Asia-Pacific and North America along with regularly scheduled executive review and planning calls, implementing global travel restrictions, and conforming to the guidance and direction of local governments and global health organizations. We are monitoring the impacts the COVID-19 pandemic has had, and continues to have, on our supply chain and are collaborating with our third-party partners with the goal of mitigating, to the extent reasonably practicable, significant delays in delivery of our products.

[0001564590-21-024040:mdna:6]
There have been increasing prices and lead times of copper clad laminates (CCLs), a key raw material for the manufacture of PCBs. CCLs are made from epoxy resin, glass cloth and copper foil, all of which are seeing limited supply and resulting in increased prices. We are actively managing higher raw materials costs by seeking to pass on the increase in costs to our customers, implementing ongoing operational efficiencies, and through supplier diversification.

[0001564590-21-024040:mdna:7]
[same as prior period, unchanged from 0001564590-20-051296:mdna:6]

[0001564590-21-024040:mdna:8]
Results related to our Mobility business unit are reported as discontinued operations for all periods presented. See Part I, Item 1, Note 2, Discontinued Operations, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q for further information. Unless otherwise noted, amounts and disclosures throughout our Management’s Discussion and Analysis of Financial Condition and Results of Operations relate to our continuing operations.

[0001564590-21-024040:mdna:9]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 45% and 42% of our net sales for the quarters ended March 29, 2021 and March 30, 2020, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-21-024040:mdna:10]
[same as prior period, unchanged from 0001564590-20-051296:mdna:9]

[0001564590-21-024040:mdna:11]
|  |  | Quarter Ended |  |  |
| End Markets (1) |  | March 29, 2021 |  |  |  | March 30, 2020 |  |  |
| Aerospace and Defense |  |  | 35 |  | % |  |  | 37 |  | % |
| Automotive |  |  | 18 |  |  |  |  | 14 |  |  |
| Data Center Computing (2) |  |  | 14 |  |  |  |  | 12 |  |  |
| Medical/Industrial/Instrumentation |  |  | 17 |  |  |  |  | 19 |  |  |
| Networking/Communications |  |  | 15 |  |  |  |  | 17 |  |  |
| Other (3) |  |  | 1 |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-21-024040:mdna:12]
[same as prior period, unchanged from 0001564590-20-051296:mdna:11]

[0001564590-21-024040:mdna:13]
| (2) | In the current period, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |

[0001564590-21-024040:mdna:14]
| (3) | Other end market reflects direct sales to EMS and distributor customers. |

[0001564590-21-024040:mdna:15]
We derive revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of RF and microwave components, assemblies and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and custom electronic assemblies manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0001564590-21-024040:mdna:16]
[same as prior period, unchanged from 0001564590-20-051296:mdna:14]

[0001564590-21-024040:mdna:17]
[same as prior period, unchanged from 0001564590-20-051296:mdna:15]

[0001564590-21-024040:mdna:18]
[same as prior period, unchanged from 0001564590-20-051296:mdna:16]

[0001564590-21-024040:mdna:19]
[same as prior period, unchanged from 0001564590-20-051296:mdna:17]

[0001564590-21-024040:mdna:20]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, facilities, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001564590-21-024040:mdna:21]
[same as prior period, unchanged from 0001564590-20-051296:mdna:19]

[0001564590-21-024040:mdna:22]
[same as prior period, unchanged from 0001564590-20-051296:mdna:20]

[0001564590-21-024040:mdna:23]
[same as prior period, unchanged from 0001564590-20-051296:mdna:21]

[0001564590-21-024040:mdna:24]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended December 28, 2020 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since December 28, 2020.

[0001564590-21-024040:mdna:25]
[same as prior period, unchanged from 0001564590-20-051296:mdna:24]

[0001564590-21-024040:mdna:26]
[same as prior period, unchanged from 0001564590-20-051296:mdna:25]

[0001564590-21-024040:mdna:27]
|  |  | Quarter Ended |
|  |  | March 29, 2021 |  |  |  | March 30, 2020 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 84.5 |  |  |  |  | 83.7 |  |  |
| Gross profit |  |  | 15.5 |  |  |  |  | 16.3 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.1 |  |  |  |  | 3.2 |  |  |
| General and administrative |  |  | 6.0 |  |  |  |  | 7.0 |  |  |
| Research and development |  |  | 0.8 |  |  |  |  | 0.9 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.8 |  |  |  |  | 1.9 |  |  |
| Total operating expenses |  |  | 11.7 |  |  |  |  | 13.0 |  |  |
| Operating income |  |  | 3.8 |  |  |  |  | 3.3 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.2 | ) |  |  |  | (4.0 | ) |  |
| Loss on extinguishment of debt |  |  | (2.9 | ) |  |  |  | — |  |  |
| Other, net |  |  | 0.5 |  |  |  |  | 0.5 |  |  |
| Total other expense, net |  |  | (4.6 | ) |  |  |  | (3.5 | ) |  |
| Loss from continuing operations before income taxes |  |  | (0.8 | ) |  |  |  | (0.2 | ) |  |
| Income tax benefit (provision) |  |  | 0.2 |  |  |  |  | (0.4 | ) |  |
| Net loss from continuing operations |  |  | (0.6 | ) | % |  |  | (0.6 | ) | % |

[0001564590-21-024040:mdna:28]
As of March 29, 2021, E-M Solutions no longer meets the criteria for segment reporting and the SH BPA facility is integrated into the PCB reportable segment. In fiscal 2020, subsequent to the quarter ended March 30, 2020, RF&S Components was added as a reportable segment. As a result, we reclassified prior periods to reflect the new segment.

[0001564590-21-024040:mdna:29]
[same as prior period, unchanged from 0001564590-20-051296:mdna:28]

[0001564590-21-024040:mdna:30]
Despite the closure of the two plants from our discontinued E-M Solutions segment, which accounted for $10.9 million reduction in net sales, total net sales increased $28.8 million, or 5.8%, to $526.4 million for the first quarter of 2021 from $497.6 million for the first quarter of 2020. This increase in total net sales primarily resulted from an increase in net sales for the PCB reportable segment of $36.5 million, or 7.7%, to $510.5 million for the first quarter of 2021 from $474.0 million for the first quarter of 2020 primarily due to higher demand in our Automotive, Data Center Computing and Aerospace and Defense end markets, partially offset by lower demand in our Networking/Communications and Other end markets. In addition, these changes in the PCB reportable segment resulted in a 28.8% increase in the volume of PCB shipments, partially offset by a decrease in the average price per square foot of 15.8%, driven mainly by product mix shift as compared to the first quarter of 2020. Also contributing to the increase in total net sales was an increase in net sales for the RF&S Components reportable segment of $3.2 million, or 34.4%, to $12.7 million for the first quarter of 2021 from $9.4 million for the first quarter of 2020 primarily due to higher demand in our Networking/Communications end market.

[0001564590-21-024040:mdna:31]
[same as prior period, unchanged from 0001564590-20-051296:mdna:32]

[0001564590-21-024040:mdna:32]
Overall gross margin decreased to 15.5% for the first quarter of 2021 from 16.3% for the first quarter of 2020. This decrease was primarily driven by a decrease in gross margin for the PCB reportable segment to 15.7% for the first quarter of 2021 from 17.6% for the first quarter of 2020. This decline was due to approximately $13.0 million of additional costs related to a stronger Chinese currency, higher raw material costs due to increased commodity prices, primarily copper, and continued costs and production inefficiencies due to COVID-19. We were able to mitigate most of these costs through higher revenue, and production and spending efficiencies. Gross margin for the RF&S Components reportable segment increased to 47.5% for the first quarter of 2021 from 45.8% for the first quarter of 2020, primarily due to higher sales.

[0001564590-21-024040:mdna:33]
Capacity utilization is a key driver for us, which is measured by actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the first quarter of 2021 in our Asia and North America PCB facilities was 80% and 55%, respectively, compared to 52% and 67%, respectively, for the first quarter of 2020. The increase in capacity utilization in our Asia PCB facilities was due to an increase in production resulting from increased sales in our Automotive and Data Center Computing end

[0001564590-21-024040:mdna:34]
markets. The decrease in our capacity utilization in our North America PCB facilities was due to production inefficiencies caused by COVID-19.

[0001564590-21-024040:mdna:35]
[same as prior period, unchanged from 0001564590-20-051296:mdna:36]

[0001564590-21-024040:mdna:36]
Selling and marketing expenses increased $0.1 million, to $16.3 million for the first quarter of 2021 from $16.2 million for the first quarter of 2020. As a percentage of net sales, selling and marketing expenses was 3.1% for the first quarter of 2021, as compared to 3.2% for the first quarter of 2020. The increase in selling and marketing expense for the first quarter of 2021 was primarily due to an increase in commission expense, partially offset by reduced travel expense due to the COVID-19 pandemic, which has decreased travel on a temporary basis.

[0001564590-21-024040:mdna:37]
[same as prior period, unchanged from 0001564590-20-051296:mdna:39]

[0001564590-21-024040:mdna:38]
General and administrative expenses decreased $3.1 million to $31.5 million, or 6.0% of net sales, for the first quarter of 2021 from $34.7 million, or 7.0% of net sales, for the first quarter of 2020. This decrease was primarily due to a decrease in bad debt and acquisition/integration costs.

[0001564590-21-024040:mdna:39]
[same as prior period, unchanged from 0001564590-20-051296:mdna:44]

[0001564590-21-024040:mdna:40]
Other expense, net increased $6.8 million to $24.1 million for the first quarter of 2021 from $17.3 million for the first quarter of 2020. This increase was primarily the result of $15.2 million of loss on extinguishment of debt associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs related to the repayment of the Senior Notes due in 2025. This increase is partially offset by a decrease in interest expense of $8.4 million due to overall lower levels of debt outstanding.

[0001564590-21-024040:mdna:41]
[same as prior period, unchanged from 0001564590-20-051296:mdna:47]

[0001564590-21-024040:mdna:42]
Income tax expense decreased by $3.2 million to $1.1 million of tax benefit for the first quarter of 2021 from $2.1 million of tax expense for the first quarter of 2020. The decrease in income tax expense for the first quarter of 2021 was primarily due to a decrease in pre-tax income from continuing operations and the approval of the Company’s renewal application for High and New Enterprise status for two of the Company’s manufacturing subsidiaries in China.

[0001564590-21-024040:mdna:43]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax asset of approximately $16.0 million and $24.5 million as of March 29, 2021 and March 30, 2020, respectively.

[0001564590-21-024040:mdna:44]
On March 11, 2021, the President of the United States signed the American Rescue Plan (ARP) providing additional economic relief to the disruptions caused by the COVID-19 pandemic. Accounting Standard Codification (ASC) 740, Accounting for Income Taxes, requires companies to recognize the effect of tax law changes in the period of enactment regardless of the effective date of those tax law changes. We considered the impact to our financial statements of the corporate income tax aspects of the ARP and determined the impact is not material to our financial statements.

[0001564590-21-024040:mdna:45]
[same as prior period, unchanged from 0001564590-20-051296:mdna:52]

[0001564590-21-024040:mdna:46]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our Revolving Credit Facilities. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, and to repay existing debt. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and potential share repurchases will be the principal demands on our cash in the future.

[0001564590-21-024040:mdna:47]
Cash flow provided by operating activities for continuing operations during the first quarter of 2021 was $41.1 million as compared to cash flow provided by operating activities for continuing operations of $6.6 million in the same period in 2020. The increase in cash flow was primarily due to less investment in working capital.

[0001564590-21-024040:mdna:48]
Net cash used in investing activities for continuing operations was approximately $21.0 million for the first quarter of 2021, reflecting $21.8 million for purchases of property, plant and equipment and other assets less $0.8 million for proceeds from sale of property, plant and equipment and other assets. Net cash used in investing activities for continuing operations was approximately $23.9 million for the first quarter of 2020, reflecting purchases of property, plant and equipment and other assets.

[0001564590-21-024040:mdna:49]
Net cash provided by financing activities for continuing operations during the first quarter of 2021 was $68.1 million, primarily reflecting proceeds from long-term debt borrowing of $500.0 million, less the repayment of long-term debt borrowings of $425.8 million and payment of debt issuance costs of $4.8 million. There was no activity related to cash flows from financing activities for the first quarter of 2020.

[0001564590-21-024040:mdna:50]
As of March 29, 2021, we had cash and cash equivalents of approximately $539.6 million, of which approximately $233.8 million was held by our foreign subsidiaries, primarily in China. Should we choose to remit cash to the United States from our

[0001564590-21-024040:mdna:51]
foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for on the repatriation of this cash.

[0001564590-21-024040:mdna:52]
Our total 2021 capital expenditures are expected to be in the range of $70.0 million to $90.0 million.

[0001564590-21-024040:mdna:53]
[same as prior period, unchanged from 0001564590-20-051296:mdna:61]

[0001564590-21-024040:mdna:54]
As of March 29, 2021, we had $926.1 million of outstanding debt, net of discount and debt issuance costs, composed of $493.5 million of Senior Notes due March 2029, $402.6 million of Term Loan due September 2024, and $30.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL).

[0001564590-21-024040:mdna:55]
Pursuant to the terms of the Term Loan Facility and Senior Notes due 2029, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, as a result of the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of March 29, 2021, we were in compliance with the covenants under the Term Loan Facility, Senior Notes due 2029 and ABL Revolving Loans.

[0001564590-21-024040:mdna:56]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next twelve months. Additional information regarding our indebtedness, including information about the credit available under our debt facilities, interest rates and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 8, Long-term Debt and Letters of Credit, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q.

[0001564590-21-024040:mdna:57]
[same as prior period, unchanged from 0001564590-20-051296:mdna:65]

[0001564590-21-024040:mdna:58]
The following table provides information on our contractual obligations as of March 29, 2021:

[0001564590-21-024040:mdna:59]
|  |  | Total |  |  | Less Than 1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 935,879 |  |  | $ | — |  |  | $ | — |  |  | $ | 435,879 |  |  | $ | 500,000 |  |
| Interest on debt obligations |  |  | 198,548 |  |  |  | 32,488 |  |  |  | 62,325 |  |  |  | 45,346 |  |  |  | 58,389 |  |
| Derivative liabilities |  |  | 13,716 |  |  |  | 10,975 |  |  |  | 2,741 |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 136,925 |  |  |  | 110,845 |  |  |  | 17,247 |  |  |  | 725 |  |  |  | 8,108 |  |
| Total contractual obligations |  | $ | 1,285,068 |  |  | $ | 154,308 |  |  | $ | 82,313 |  |  | $ | 481,950 |  |  | $ | 566,497 |  |

[0001564590-21-024040:mdna:60]
| (1) | Unrecognized uncertain tax benefits of $2.8 million are not included in the table above as the settlement timing is uncertain. Operating leases are not included in the table above – see Part I, Item 1, Note 3, Leases, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q for further details. |

[0001564590-21-024040:mdna:61]
Off-Balance Sheet Arrangements

[0001564590-21-024040:mdna:62]
[same as prior period, unchanged from 0001564590-20-051296:mdna:68]

[0001564590-21-024040:mdna:63]
[same as prior period, unchanged from 0001564590-20-051296:mdna:69]

[0001564590-21-024040:mdna:64]
[same as prior period, unchanged from 0001564590-20-051296:mdna:70]

[0001564590-21-024040:mdna:65]
Recently Issued Accounting Standards

[0001564590-21-024040:mdna:66]
[same as prior period, unchanged from 0001564590-20-051296:mdna:72]
