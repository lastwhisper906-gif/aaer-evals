# TTMI note change history — 0001564590-20-051296 → 0001564590-21-024040


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0001564590-21-024040:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of March 29, 2021 and December 28, 2020. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2020-11-05, similarity 0.9907):
[0001564590-20-051296:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 28, 2020 and December 30, 2019. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0001564590-21-024040:note_history:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This one-stop design, engineering and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.
  (was, 2020-11-05, similarity 0.7424):
[0001564590-20-051296:note_history:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This one-stop design and manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- changed (2021-05-05):
[0001564590-21-024040:note_history:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.
  (was, 2020-11-05, similarity 0.9854):
[0001564590-20-051296:note_history:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

- changed (2021-05-05):
[0001564590-21-024040:note_history:4]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income (loss) from discontinued operations, net of income taxes”. Refer to Note 2, Discontinued Operations, for additional information.
  (was, 2020-11-05, similarity 0.8038):
[0001564590-20-051296:note_history:4]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale of the Company’s following subsidiaries, which was completed on April 17, 2020: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). Prior to the closing of the sale of the Company’s Mobility business unit, all assets and liabilities attributable to the Mobility business unit have been aggregated under the captions “Current assets held for sale”, “Non-current assets held for sale”, “Current liabilities held for sale” and “Non-current liabilities held for sale”. For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income (loss) from discontinued operations, net of income taxes”. Prior year results have been recast to conform with the current presentation. Refer to Note 2, Discontinued Operations, for additional information.

- added (2021-05-05):
[0001564590-21-024040:note_history:5]
The Company currently has two reportable segments: PCB and RF and Specialty Components (RF&S Components). In fiscal 2020, subsequent to the quarter ended March 30, 2020, RF&S Components was added as a reportable segment. As a result, the Company had three reportable segments as of December 28, 2020: PCB, RF&S Components, and E-M Solutions. On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer meets the criteria for segment reporting. As a result of the addition of the RF&S Components reportable segment and the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.

- added (2021-05-05):
[0001564590-21-024040:note_history:6]
In December 2019, the Financial Accounting Standards Board (FASB) issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes.

- added (2021-05-05):
[0001564590-21-024040:note_history:7]
ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company adopted this ASU as of December 29, 2020 and it did not have a material impact on its consolidated condensed financial statements and related disclosures.

- removed (2021-05-05):
[0001564590-20-051296:note_history:8]
Certain prior year amounts in the consolidated condensed financial statements have been reclassified due to the sale of the Company’s Mobility business unit. Refer to Note 2, Discontinued Operations, for further information regarding this sale and the resulting prior year reclassifications.

- removed (2021-05-05):
[0001564590-20-051296:note_history:9]
During the quarter ended September 28, 2020, the Company’s RF and Specialty Components (RF&S Components) operating segment met the quantitative threshold for separate presentation of a reportable segment. In prior periods, the Company had two reportable segments: PCB and E-M Solutions. The RF&S Components reportable segment was previously aggregated with the PCB reportable segment. As a result, certain prior year amounts and prior quarters within the current year have been reclassified to conform with this new presentation.

- removed (2021-05-05):
[0001564590-20-051296:note_history:10]
Further, in 2020, the Company began presenting research and development expenses as a separate line item on the consolidated condensed statements of operations to better align with similar presentation made by peers and to provide additional disclosure that is meaningful for investors. The prior year consolidated condensed statements of operations were adjusted to conform with this new presentation. Research and development expense were previously presented within general and administrative expense on the consolidated condensed statements of operations.

- removed (2021-05-05):
[0001564590-20-051296:note_history:11]
Immaterial Correction of Error

- removed (2021-05-05):
[0001564590-20-051296:note_history:12]
During the quarter ended September 28, 2020, the Company paid for certain transaction costs related to the sale of the Mobility business unit totaling $11,043. This should have been recorded as an expense, which would have reduced the gain on sale of Mobility business unit, during the quarter ended June 29, 2020. The Company overstated both the income from discontinued operations, net of income taxes and net income by $11,043, both basic earnings per share from discontinued operations and basic earnings per share of $0.10 and $0.11 in the quarter and two quarters ended June 29, 2020, respectively, and both diluted earnings per share from discontinued operations and diluted earnings per share of $0.10 in the quarter and two quarters ended June 29, 2020. Further, total current liabilities were understated by $11,043 and retained earnings were overstated by $11,043 as of June 29, 2020. Management concluded that this error was not material to the consolidated condensed financial statements for the quarter and two quarters ended June 29, 2020. Prior period amounts have been revised to correct the error.

- removed (2021-05-05):
[0001564590-20-051296:note_history:13]
In March 2020, the FASB issued ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting, which provides temporary relief to the GAAP guidance on contract modifications and hedge accounting to ease the financial reporting burdens of the expected market transition from LIBOR and other interbank offered rates to alternative rates. This guidance became effective beginning on March 12, 2020 and will remain in effect through December 31, 2022. The guidance on contract modifications can be applied prospectively from any date beginning March 12, 2020 and may also be applied to modifications of existing contracts made earlier in the interim period that included March 12, 2020. The guidance on hedging can be applied to eligible hedging relationships existing at the beginning of the interim period that included March 12, 2020 and to new eligible hedging relationships entered into after the beginning of that interim period. The Company adopted this ASU and it did not have a material impact on its financial statements.

- removed (2021-05-05):
[0001564590-20-051296:note_history:14]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which amends the current accounting guidance and requires the measurement of all expected losses based on historical experience, current conditions and reasonable and supportable forecasts. For trade receivables, loans, and other financial instruments, the Company will be required to use a forward-looking expected loss model that reflects losses that are probable rather than the incurred loss model for recognizing credit losses. The standard became effective for interim and annual periods beginning after December 15, 2019. Application of the amendments is through a cumulative-effect adjustment to retained earnings as of the effective date. The Company adopted this ASU as of December 31, 2019 and it did not have a material impact on its financial statements.

- removed (2021-05-05):
[0001564590-20-051296:note_history:15]
Recently Issued Accounting Standards Not Yet Adopted

- removed (2021-05-05):
[0001564590-20-051296:note_history:16]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company has evaluated the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures and the impact is not expected to be material.

- removed (2021-05-05):
[0001564590-20-051296:note_history:17]
In August 2018, the FASB issued ASU 2018-14, Compensation—Retirement Benefits—Defined Benefit Plans—General (Subtopic 715-20)—Disclosure Framework—Changes to the Disclosure Requirements for Defined Benefit Plans. The amendments in this update change the disclosure requirements for employers that sponsor defined benefit pension and/or other postretirement benefit plans. It eliminates requirements for certain disclosures that are no longer considered cost beneficial and requires new disclosures that the FASB considers pertinent. The guidance is effective for fiscal years ending after December 15, 2020. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on its consolidated condensed financial statements and related disclosures.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0001564590-21-024040:note_history:18]
As of March 29, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:
  (was, 2020-11-05, similarity 0.8301):
[0001564590-20-051296:note_history:18]
As of September 28, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- added (2021-05-05):
[0001564590-21-024040:note_history:19]
|  |  | As of March 29, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,462 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,526 |  |  |  | 763 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,988 |  |  | $ | 763 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |

- removed (2021-05-05):
[0001564590-20-051296:note_history:20]
|  |  | As of September 28, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 2,862 |  |  | $ | 866 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 4,721 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 219 |  |  |  | 2,188 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 7,802 |  |  | $ | 3,054 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0001564590-21-024040:note_history:21]
The following table summarizes the long-term debt of the Company as of March 29, 2021 and December 28, 2020:
  (was, 2020-11-05, similarity 0.95):
[0001564590-20-051296:note_history:21]
The following table summarizes the long-term debt of the Company as of September 28, 2020 and December 30, 2019:

- added (2021-05-05):
[0001564590-21-024040:note_history:22]
|  |  | Interest Rate as of March 29, 2021 |  |  | Principal Outstanding as of March 29, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.61 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.51 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (763 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,988 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,128 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,128 |  |  |  |  |  |  | $ | 842,853 |  |

- added (2021-05-05):
[0001564590-21-024040:note_history:23]
The Company has twelve months from September 3, 2020 to reinvest the cash proceeds received from the sale of the Mobility business unit. If the proceeds are not reinvested, the Company is required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to repay $400,000 of the Term Loan during the year ended December 28, 2020 and plans to use

- changed (2021-05-05):
[0001564590-21-024040:note_history:24]
the remaining cash proceeds for reinvestment. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.
  (was, 2020-11-05, similarity 0.6936):
[0001564590-20-051296:note_history:24]
The Company has twelve months to reinvest the cash proceeds received from the sale of the Mobility business unit. If the proceeds are not reinvested, the Company is required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to repay $400,000 of the Term Loan during the quarter ended September 28, 2020 and plans to use the remaining cash proceeds for reinvestment. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

- added (2021-05-05):
[0001564590-21-024040:note_history:25]
Senior Notes due 2029

- added (2021-05-05):
[0001564590-21-024040:note_history:26]
On March 10, 2021, the Company issued $500,000 of Senior Notes due 2029, which are included in long-term debt and bear interest at a rate of 4.0% per annum. Interest is payable semiannually in arrears on March 1 and September 1 of each year beginning September 1, 2021. The Senior Notes due 2029 will mature on March 1, 2029.

- added (2021-05-05):
[0001564590-21-024040:note_history:27]
The Company used a portion of the net proceeds from the issuance of the Senior Notes due 2029 during the quarter ended March 29, 2021 to: (i) fund the early retirement of $375,000 Senior Notes due 2025, (ii) fund the repayment of $40,000 outstanding under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) Revolving credit facility (but not terminate the commitments thereunder), and (iii) pay related premiums, fees and expenses. The Company intends to use the remaining net proceeds for general corporate purposes.

- added (2021-05-05):
[0001564590-21-024040:note_history:28]
Asset-Based Lending Agreements

- added (2021-05-05):
[0001564590-21-024040:note_history:29]
As of March 29, 2021, letters of credit in the amount of $10,753 were outstanding under the U.S. ABL and $11,721 were outstanding under the Asia ABL with various expiration dates through July 2021. Available borrowing capacity under the U.S. ABL and the Asia ABL was $139,247 and $108,279, respectively, which considers letters of credit outstanding as of March 29, 2021.

- changed (2021-05-05):
[0001564590-21-024040:note_history:30]
Borrowings under the Term Loan and Senior Notes due 2029 are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.
  (was, 2020-11-05, similarity 0.9751):
[0001564590-20-051296:note_history:30]
Borrowings under the Term Loan and Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

- changed (2021-05-05):
[0001564590-21-024040:note_history:31]
Under the occurrence of certain events, the U.S. ABL and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.
  (was, 2020-11-05, similarity 0.8307):
[0001564590-20-051296:note_history:31]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

- changed (2021-05-05):
[0001564590-21-024040:note_history:32]
As of March 29, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:
  (was, 2020-11-05, similarity 0.8301):
[0001564590-20-051296:note_history:32]
As of September 28, 2020 and December 30, 2019, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- added (2021-05-05):
[0001564590-21-024040:note_history:33]
|  |  | As of March 29, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,462 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,526 |  |  |  | 763 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,988 |  |  | $ | 763 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |

- changed (2021-05-05):
[0001564590-21-024040:note_history:34]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,778 and $1,919 as of March 29, 2021 and December 28, 2020, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2020-11-05, similarity 0.9769):
[0001564590-20-051296:note_history:34]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,084 and $2,511 as of September 28, 2020 and December 30, 2019, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2021-05-05):
[0001564590-21-024040:note_history:35]
As of March 29, 2021, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 5.9 years.
  (was, 2020-11-05, similarity 0.964):
[0001564590-20-051296:note_history:35]
As of September 28, 2020, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.6 years.

- added (2021-05-05):
[0001564590-21-024040:note_history:36]
Loss on Extinguishment of Debt

- added (2021-05-05):
[0001564590-21-024040:note_history:37]
During the quarter ended March 29, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.

- removed (2021-05-05):
[0001564590-20-051296:note_history:38]
|  |  | Interest Rate as of September 28, 2020 |  |  | Principal Outstanding as of September 28, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 2.65 |  | % | $ | 405,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 1.40 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.55 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,100,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (3,054 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (7,802 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,089,998 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (249,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 840,023 |  |  |  |  |  |  | $ | 1,225,962 |  |

- removed (2021-05-05):
[0001564590-20-051296:note_history:39]
As of September 28, 2020, the Company’s restricted cash balance of $249,975 consisted of a specific deposit account to be used for principal payment on the Convertible Senior Notes due December 2020.

- removed (2021-05-05):
[0001564590-20-051296:note_history:40]
|  |  | As of September 28, 2020 |  |  | As of December 30, 2019 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 2,862 |  |  | $ | 866 |  |  |  | 4.66 |  | % | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 4,721 |  |  | — |  |  |  | 5.92 |  |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 219 |  |  |  | 2,188 |  |  |  | 6.48 |  |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |
|  |  | $ | 7,802 |  |  | $ | 3,054 |  |  |  |  |  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0001564590-21-024040:note_history:41]
The following table summarizes the long-term debt of the Company as of March 29, 2021 and December 28, 2020:
  (was, 2020-11-05, similarity 0.95):
[0001564590-20-051296:note_history:41]
The following table summarizes the long-term debt of the Company as of September 28, 2020 and December 30, 2019:

- added (2021-05-05):
[0001564590-21-024040:note_history:42]
|  |  | Interest Rate as of March 29, 2021 |  |  | Principal Outstanding as of March 29, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.61 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.51 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (763 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,988 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,128 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,128 |  |  |  |  |  |  | $ | 842,853 |  |

- removed (2021-05-05):
[0001564590-20-051296:note_history:43]
|  |  | Interest Rate as of September 28, 2020 |  |  | Principal Outstanding as of September 28, 2020 |  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 2.65 |  | % | $ | 405,879 |  |  |  | 4.28 |  | % | $ | 805,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,975 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 1.40 |  |  |  | 40,000 |  |  |  | 3.03 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.55 |  |  |  | 30,000 |  |  |  | 3.18 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,100,854 |  |  |  |  |  |  |  | 1,500,854 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (3,054 | ) |  |  |  |  |  |  | (11,943 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (7,802 | ) |  |  |  |  |  |  | (12,974 | ) |
|  |  |  |  |  |  |  | 1,089,998 |  |  |  |  |  |  |  | 1,475,937 |  |
| Less: current maturities |  |  |  |  |  |  | (249,975 | ) |  |  |  |  |  |  | (249,975 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 840,023 |  |  |  |  |  |  | $ | 1,225,962 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2021-05-05):
[0001564590-20-051296:note_history:44]
(18) Related Party Transactions

- removed (2021-05-05):
[0001564590-20-051296:note_history:45]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a significant shareholder of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $5,760 and $7,151 for the quarters ended September 28, 2020 and September 30, 2019, respectively, and $17,527 and $22,847 for the three quarters ended September 28, 2020 and September 30, 2019, respectively.

- removed (2021-05-05):
[0001564590-20-051296:note_history:46]
As of September 28, 2020 and December 30, 2019, the Company’s consolidated condensed balance sheets included $6,786 and $9,220, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-05-05):
[0001564590-21-024040:note_history:47]
|  |  | Quarter Ended March 29, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 186,539 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 186,545 |  |  |
| Automotive |  |  | 91,792 |  |  |  | — |  |  |  | 3,642 |  |  |  | 95,434 |  |  |
| Data Center Computing (2) |  |  | 71,759 |  |  |  | 432 |  |  |  | — |  |  |  | 72,191 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,770 |  |  |  | 1,081 |  |  |  | 25 |  |  |  | 91,876 |  |  |
| Networking/Communications |  |  | 66,938 |  |  |  | 10,653 |  |  |  | 1 |  |  |  | 77,592 |  |  |
| Other |  |  | 2,688 |  |  |  | 518 |  |  |  | (412 | ) |  |  | 2,794 |  |  |
| Total |  | $ | 510,486 |  |  | $ | 12,690 |  |  | $ | 3,256 |  |  | $ | 526,432 |  |  |

- added (2021-05-05):
[0001564590-21-024040:note_history:48]
|  |  | Quarter Ended March 30, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 184,414 |  |  | $ | — |  |  | $ | — |  |  | $ | 184,414 |  |  |
| Automotive |  |  | 61,858 |  |  |  | — |  |  |  | 7,013 |  |  |  | 68,871 |  |  |
| Cellular Phone |  |  | 2,775 |  |  |  | — |  |  |  | — |  |  |  | 2,775 |  |  |
| Data Center Computing (2) |  |  | 58,114 |  |  |  | 203 |  |  |  | 54 |  |  |  | 58,371 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,468 |  |  |  | 794 |  |  |  | 3,320 |  |  |  | 94,582 |  |  |
| Networking/Communications |  |  | 70,433 |  |  |  | 8,067 |  |  |  | 4,195 |  |  |  | 82,695 |  |  |
| Other |  |  | 5,940 |  |  |  | 377 |  |  |  | (379 | ) |  |  | 5,938 |  |  |
| Total |  | $ | 474,002 |  |  | $ | 9,441 |  |  | $ | 14,203 |  |  | $ | 497,646 |  |  |

- added (2021-05-05):
[0001564590-21-024040:note_history:49]
| (1) | Other represents SH E-MS and SZ results. |

- added (2021-05-05):
[0001564590-21-024040:note_history:50]
| (2) | In the current period, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |

- removed (2021-05-05):
[0001564590-20-051296:note_history:51]
|  | Quarter Ended September 28, 2020 |  |  | Quarter Ended September 30, 2019 |  |  |
|  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  |
| End Markets | (In thousands) |  |  |
| Aerospace and Defense | $ | 182,709 |  |  | $ | 180 |  |  | $ | 16 |  | $ | 182,905 |  |  | $ | 170,651 |  |  | $ | 729 |  |  | $ | 1 |  | $ | 171,381 |  |  |
| Automotive |  | 64,375 |  |  |  | — |  |  |  | 8,891 |  |  | 73,266 |  |  |  | 72,597 |  |  |  | — |  |  |  | 39,559 |  |  | 112,156 |  |  |
| Cellular Phone |  | 39 |  |  |  | — |  |  |  | — |  |  | 39 |  |  |  | 3,512 |  |  |  | — |  |  |  | — |  |  | 3,512 |  |  |
| Computing/Storage/ Peripherals |  | 62,606 |  |  |  | 186 |  |  |  | 30 |  |  | 62,822 |  |  |  | 57,367 |  |  |  | 592 |  |  |  | 72 |  |  | 58,031 |  |  |
| Medical/Industrial/ Instrumentation |  | 92,059 |  |  |  | 742 |  |  |  | 2,769 |  |  | 95,570 |  |  |  | 84,178 |  |  |  | 705 |  |  |  | 5,775 |  |  | 90,658 |  |  |
| Networking/Communications |  | 55,905 |  |  |  | 7,203 |  |  |  | 27,185 |  |  | 90,293 |  |  |  | 58,782 |  |  |  | 7,971 |  |  |  | 22,746 |  |  | 89,499 |  |  |
| Other |  | 5,971 |  |  |  | 3,431 |  |  |  | (721 | ) |  | 8,681 |  |  |  | 5,729 |  |  |  | 3,647 |  |  |  | (440 | ) |  | 8,936 |  |  |
| Total | $ | 463,664 |  |  | $ | 11,742 |  |  | $ | 38,170 |  | $ | 513,576 |  |  | $ | 452,816 |  |  | $ | 13,644 |  |  | $ | 67,713 |  | $ | 534,173 |  |  |

- removed (2021-05-05):
[0001564590-20-051296:note_history:52]
|  | Three Quarters Ended September 28, 2020 |  |  | Three Quarters Ended September 30, 2019 |  |  |
|  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  |
| End Markets | (In thousands) |  |  |
| Aerospace and Defense | $ | 555,771 |  |  | $ | 189 |  |  | $ | 36 |  | $ | 555,996 |  |  | $ | 510,210 |  |  | $ | 777 |  |  | $ | 367 |  | $ | 511,354 |  |  |
| Automotive |  | 183,896 |  |  |  | — |  |  |  | 27,816 |  |  | 211,712 |  |  |  | 227,239 |  |  |  | — |  |  |  | 83,317 |  |  | 310,556 |  |  |
| Cellular Phone |  | 1,203 |  |  |  | — |  |  |  | — |  |  | 1,203 |  |  |  | 5,416 |  |  |  | — |  |  |  | — |  |  | 5,416 |  |  |
| Computing/Storage/ Peripherals |  | 192,275 |  |  |  | 663 |  |  |  | 170 |  |  | 193,108 |  |  |  | 170,914 |  |  |  | 1,373 |  |  |  | 261 |  |  | 172,548 |  |  |
| Medical/Industrial/ Instrumentation |  | 292,794 |  |  |  | 2,336 |  |  |  | 9,714 |  |  | 304,844 |  |  |  | 246,889 |  |  |  | 2,629 |  |  |  | 23,583 |  |  | 273,101 |  |  |
| Networking/ Communications |  | 178,428 |  |  |  | 19,173 |  |  |  | 82,429 |  |  | 280,030 |  |  |  | 188,069 |  |  |  | 37,192 |  |  |  | 72,011 |  |  | 297,272 |  |  |
| Other |  | 25,262 |  |  |  | 10,913 |  |  |  | (1,548 | ) |  | 34,627 |  |  |  | 18,025 |  |  |  | 9,754 |  |  |  | (531 | ) |  | 27,248 |  |  |
| Total | $ | 1,429,629 |  |  | $ | 33,274 |  |  | $ | 118,617 |  | $ | 1,581,520 |  |  | $ | 1,366,762 |  |  | $ | 51,725 |  |  | $ | 179,008 |  | $ | 1,597,495 |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-05):
[0001564590-21-024040:note_history:53]
As of March 29, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $12,850. The Company expects to recognize revenue on approximately 100% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.
  (was, 2020-11-05, similarity 0.7652):
[0001564590-20-051296:note_history:53]
As of September 28, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $19,606. The Company expects to recognize revenue on approximately 86% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.

- added (2021-05-05):
[0001564590-21-024040:note_history:54]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the both the quarters ended March 29, 2021 and March 30, 2020.

- added (2021-05-05):
[0001564590-21-024040:note_history:55]
|  |  | Quarter Ended March 29, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 186,539 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 186,545 |  |  |
| Automotive |  |  | 91,792 |  |  |  | — |  |  |  | 3,642 |  |  |  | 95,434 |  |  |
| Data Center Computing (2) |  |  | 71,759 |  |  |  | 432 |  |  |  | — |  |  |  | 72,191 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,770 |  |  |  | 1,081 |  |  |  | 25 |  |  |  | 91,876 |  |  |
| Networking/Communications |  |  | 66,938 |  |  |  | 10,653 |  |  |  | 1 |  |  |  | 77,592 |  |  |
| Other |  |  | 2,688 |  |  |  | 518 |  |  |  | (412 | ) |  |  | 2,794 |  |  |
| Total |  | $ | 510,486 |  |  | $ | 12,690 |  |  | $ | 3,256 |  |  | $ | 526,432 |  |  |

- added (2021-05-05):
[0001564590-21-024040:note_history:56]
|  |  | Quarter Ended March 30, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 184,414 |  |  | $ | — |  |  | $ | — |  |  | $ | 184,414 |  |  |
| Automotive |  |  | 61,858 |  |  |  | — |  |  |  | 7,013 |  |  |  | 68,871 |  |  |
| Cellular Phone |  |  | 2,775 |  |  |  | — |  |  |  | — |  |  |  | 2,775 |  |  |
| Data Center Computing (2) |  |  | 58,114 |  |  |  | 203 |  |  |  | 54 |  |  |  | 58,371 |  |  |
| Medical/Industrial/Instrumentation |  |  | 90,468 |  |  |  | 794 |  |  |  | 3,320 |  |  |  | 94,582 |  |  |
| Networking/Communications |  |  | 70,433 |  |  |  | 8,067 |  |  |  | 4,195 |  |  |  | 82,695 |  |  |
| Other |  |  | 5,940 |  |  |  | 377 |  |  |  | (379 | ) |  |  | 5,938 |  |  |
| Total |  | $ | 474,002 |  |  | $ | 9,441 |  |  | $ | 14,203 |  |  | $ | 497,646 |  |  |

- added (2021-05-05):
[0001564590-21-024040:note_history:57]
| (1) | Other represents SH E-MS and SZ results. |

- added (2021-05-05):
[0001564590-21-024040:note_history:58]
| (2) | In the current period, the Computing/Storage/Peripherals end market was renamed to Data Center Computing to better reflect the customer mix and growth prospects. There was no change to the customers included in this end market. |

- removed (2021-05-05):
[0001564590-20-051296:note_history:59]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter and three quarters ended September 28, 2020. Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and three quarters ended September 30, 2019.

- removed (2021-05-05):
[0001564590-20-051296:note_history:60]
|  | Quarter Ended September 28, 2020 |  |  | Quarter Ended September 30, 2019 |  |  |
|  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  |
| End Markets | (In thousands) |  |  |
| Aerospace and Defense | $ | 182,709 |  |  | $ | 180 |  |  | $ | 16 |  | $ | 182,905 |  |  | $ | 170,651 |  |  | $ | 729 |  |  | $ | 1 |  | $ | 171,381 |  |  |
| Automotive |  | 64,375 |  |  |  | — |  |  |  | 8,891 |  |  | 73,266 |  |  |  | 72,597 |  |  |  | — |  |  |  | 39,559 |  |  | 112,156 |  |  |
| Cellular Phone |  | 39 |  |  |  | — |  |  |  | — |  |  | 39 |  |  |  | 3,512 |  |  |  | — |  |  |  | — |  |  | 3,512 |  |  |
| Computing/Storage/ Peripherals |  | 62,606 |  |  |  | 186 |  |  |  | 30 |  |  | 62,822 |  |  |  | 57,367 |  |  |  | 592 |  |  |  | 72 |  |  | 58,031 |  |  |
| Medical/Industrial/ Instrumentation |  | 92,059 |  |  |  | 742 |  |  |  | 2,769 |  |  | 95,570 |  |  |  | 84,178 |  |  |  | 705 |  |  |  | 5,775 |  |  | 90,658 |  |  |
| Networking/Communications |  | 55,905 |  |  |  | 7,203 |  |  |  | 27,185 |  |  | 90,293 |  |  |  | 58,782 |  |  |  | 7,971 |  |  |  | 22,746 |  |  | 89,499 |  |  |
| Other |  | 5,971 |  |  |  | 3,431 |  |  |  | (721 | ) |  | 8,681 |  |  |  | 5,729 |  |  |  | 3,647 |  |  |  | (440 | ) |  | 8,936 |  |  |
| Total | $ | 463,664 |  |  | $ | 11,742 |  |  | $ | 38,170 |  | $ | 513,576 |  |  | $ | 452,816 |  |  | $ | 13,644 |  |  | $ | 67,713 |  | $ | 534,173 |  |  |

- removed (2021-05-05):
[0001564590-20-051296:note_history:61]
|  | Three Quarters Ended September 28, 2020 |  |  | Three Quarters Ended September 30, 2019 |  |  |
|  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  | PCB |  |  | RF&S Components |  |  | E-M Solutions |  | Total |  |  |
| End Markets | (In thousands) |  |  |
| Aerospace and Defense | $ | 555,771 |  |  | $ | 189 |  |  | $ | 36 |  | $ | 555,996 |  |  | $ | 510,210 |  |  | $ | 777 |  |  | $ | 367 |  | $ | 511,354 |  |  |
| Automotive |  | 183,896 |  |  |  | — |  |  |  | 27,816 |  |  | 211,712 |  |  |  | 227,239 |  |  |  | — |  |  |  | 83,317 |  |  | 310,556 |  |  |
| Cellular Phone |  | 1,203 |  |  |  | — |  |  |  | — |  |  | 1,203 |  |  |  | 5,416 |  |  |  | — |  |  |  | — |  |  | 5,416 |  |  |
| Computing/Storage/ Peripherals |  | 192,275 |  |  |  | 663 |  |  |  | 170 |  |  | 193,108 |  |  |  | 170,914 |  |  |  | 1,373 |  |  |  | 261 |  |  | 172,548 |  |  |
| Medical/Industrial/ Instrumentation |  | 292,794 |  |  |  | 2,336 |  |  |  | 9,714 |  |  | 304,844 |  |  |  | 246,889 |  |  |  | 2,629 |  |  |  | 23,583 |  |  | 273,101 |  |  |
| Networking/ Communications |  | 178,428 |  |  |  | 19,173 |  |  |  | 82,429 |  |  | 280,030 |  |  |  | 188,069 |  |  |  | 37,192 |  |  |  | 72,011 |  |  | 297,272 |  |  |
| Other |  | 25,262 |  |  |  | 10,913 |  |  |  | (1,548 | ) |  | 34,627 |  |  |  | 18,025 |  |  |  | 9,754 |  |  |  | (531 | ) |  | 27,248 |  |  |
| Total | $ | 1,429,629 |  |  | $ | 33,274 |  |  | $ | 118,617 |  | $ | 1,581,520 |  |  | $ | 1,366,762 |  |  | $ | 51,725 |  |  | $ | 179,008 |  | $ | 1,597,495 |  |  |
