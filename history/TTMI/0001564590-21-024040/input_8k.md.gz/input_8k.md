# TTMI 8-K — 0001193125-21-136849 filed 2021-04-28

## item codes, every 8-K on or before 2021-05-05

- 2021-04-28 0001193125-21-136849 — 2.02, 9.01
- 2021-03-16 0001193125-21-083011 — 1.02, 8.01
- 2021-03-10 0001193125-21-076246 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2021-02-24 0001193125-21-054812 — 7.01, 9.01
- 2021-02-23 0001193125-21-051549 — 7.01, 9.01
- 2021-02-03 0001193125-21-027322 — 2.02, 8.01, 9.01
- 2020-12-15 0001193125-20-318208 — 7.01, 9.01
- 2020-10-28 0001193125-20-279980 — 2.02, 9.01
- 2020-09-04 0001193125-20-239645 — 5.02
- 2020-07-29 0001193125-20-203110 — 2.02, 9.01
- 2020-05-08 0001193125-20-137566 — 5.07
- 2020-05-04 0001193125-20-131366 — 7.01, 9.01
- 2020-04-29 0001193125-20-126358 — 2.05, 7.01, 9.01
- 2020-04-29 0001193125-20-126117 — 2.02, 9.01
- 2020-04-23 0001193125-20-117365 — 2.01, 7.01, 9.01
- 2020-02-05 0001193125-20-025365 — 2.02, 9.01
- 2020-01-31 0001193125-20-021278 — 5.02
- 2020-01-22 0001193125-20-012011 — 1.01, 7.01, 9.01
- 2019-10-30 0001193125-19-278973 — 2.02, 9.01
- 2019-08-19 0001193125-19-224091 — 5.02, 9.01
- 2019-07-31 0001193125-19-208689 — 2.02, 9.01
- 2019-07-24 0001193125-19-201401 — 1.01, 2.03
- 2019-06-13 0001193125-19-171943 — 7.01, 9.01
- 2019-06-06 0001193125-19-167332 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2019-05-09 0001193125-19-143113 — 5.07
- 2019-05-01 0001193125-19-132977 — 2.02, 9.01
- 2019-02-06 0001193125-19-029540 — 2.02, 9.01
- 2019-01-15 0001193125-19-009142 — 2.02, 9.01
- 2018-10-30 0001193125-18-312212 — 2.02, 9.01
- 2018-10-22 0001193125-18-303926 — 5.02
- 2018-09-06 0001193125-18-268231 — 5.02, 9.01
- 2018-08-01 0001193125-18-234997 — 2.02, 9.01
- 2018-06-29 0001193125-18-209635 — 9.01 — amendment of 0001193125-18-120583
- 2018-05-29 0001193125-18-176976 — 7.01, 9.01
- 2018-05-10 0001193125-18-159394 — 5.07
- 2018-05-09 0001193125-18-157596 — 5.02
- 2018-05-02 0001193125-18-148650 — 2.02, 9.01
- 2018-04-18 0001193125-18-120583 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2018-02-21 0001193125-18-052169 — 8.01, 9.01
- 2018-02-20 0001193125-18-050385 — 5.02, 9.01
- 2018-02-09 0001193125-18-036966 — 7.01, 9.01
- 2018-02-07 0001193125-18-034744 — 2.02, 9.01
- 2017-12-14 0001193125-17-369625 — 1.01, 2.03, 9.01
- 2017-12-04 0001193125-17-359439 — 1.01, 7.01, 9.01
- 2017-11-01 0001193125-17-329425 — 2.02, 9.01
- 2017-09-29 0001193125-17-298999 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2017-09-15 0001193125-17-286491 — 7.01, 9.01
- 2017-09-11 0001193125-17-281193 — 7.01, 9.01
- 2017-09-06 0001193125-17-277536 — 7.01, 9.01
- 2017-08-02 0001193125-17-245823 — 2.02, 9.01
- 2017-05-18 0001193125-17-173896 — 5.02, 5.07
- 2017-05-08 0001193125-17-162548 — 2.02, 9.01
- 2017-03-01 0001193125-17-063931 — 1.01, 1.02, 5.02
- 2017-02-08 0001193125-17-034652 — 2.02, 9.01
- 2016-11-18 0001193125-16-772305 — 8.01, 9.01
- 2016-10-26 0001193125-16-747948 — 2.02, 9.01
- 2016-10-20 0001193125-16-742905 — 5.02
- 2016-10-05 0001193125-16-731552 — 5.02, 9.01
- 2016-09-27 0001193125-16-720828 — 1.01, 2.03, 7.01, 9.01
- 2016-07-27 0001193125-16-659983 — 2.02, 9.01
- 2016-05-23 0001193125-16-599342 — 7.01, 9.01
- 2016-05-18 0001193125-16-594656 — 5.02, 5.03, 5.07, 9.01
- 2016-04-27 0001171843-16-009432 — 2.02, 9.01
- 2016-03-08 0001193125-16-495457 — 5.03, 7.01, 9.01
- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2021-05-05

- none on or before 2021-05-05

## item 2.02 — earnings release, exhibit 99.1

[0001193125-21-136849:8k_2_02:1]
EX-99.1
2
d147647dex991.htm
EX-99.1

[0001193125-21-136849:8k_2_02:2]
EX-99.1

[0001193125-21-136849:8k_2_02:3]
Exhibit 99.1

[0001193125-21-136849:8k_2_02:4]
| TTM Technologies, Inc., Q1’21 |  | Contact: |  |  |
|  |  | Sameer Desai, |  |  |
|  |  | Vice President, CorporateDevelopment & Investor Relations |  |  |
|  |  | Sameer.desai@ttmtech.com |  |  |
|  |  | 714-327-3050 |  |  |

[0001193125-21-136849:8k_2_02:5]
TTM Technologies, Inc. Reports Fiscal First Quarter 2021 Results

[0001193125-21-136849:8k_2_02:6]
Santa Ana, CA – April 28, 2021– TTM Technologies, Inc. (NASDAQ:TTMI), a leading global printed circuit board (“PCB”) and radio
frequency (“RF”) components and assemblies manufacturer, today reported results for the first quarter of fiscal 2021, which ended on March 29, 2021.

[0001193125-21-136849:8k_2_02:7]
First Quarter 2021 Highlights

[0001193125-21-136849:8k_2_02:8]
|  | • |  | Net sales were $526.4 million |

[0001193125-21-136849:8k_2_02:9]
|  | • |  | GAAP net loss of $3.2 million, or ($0.03) per diluted share |

[0001193125-21-136849:8k_2_02:10]
|  | • |  | Non-GAAP net income was $25.3 million, or $0.23 per diluted share |

[0001193125-21-136849:8k_2_02:11]
|  | • |  | Cash flow from operations was $41.1 million |

[0001193125-21-136849:8k_2_02:12]
|  | • |  | Successful completion of $500 million Senior Notes offering at 4.0% due 2029, redemption of previously issued $375 million Senior Notes at 5.625% due 2025, and repayment of $40 million US ABL |

[0001193125-21-136849:8k_2_02:13]
First Quarter 2021
Financial Results

[0001193125-21-136849:8k_2_02:14]
Net sales for the first quarter of 2021 were $526.4 million, compared to $497.6 million from continuing operations
in the first quarter of 2020.

[0001193125-21-136849:8k_2_02:15]
GAAP operating income from for the first quarter of 2021 was $19.8 million. This compares to GAAP operating income of
$16.2 million from continuing operations in the first quarter of 2020.

[0001193125-21-136849:8k_2_02:16]
GAAP net loss for the first quarter of 2021 was
$3.2 million, inclusive of a $15.2 million of debt extinguishment related charges, or ($0.03) per diluted share, compared to net loss of $3.2 million, or ($0.03) per diluted share from continuing operations in the
first quarter of 2020.

[0001193125-21-136849:8k_2_02:17]
On a non-GAAP basis, net income for the first quarter of 2021 was $25.3 million, or
$0.23 per diluted share. This compares to non-GAAP net income of $16.7 million, or $0.16 per diluted share from continuing operations in the first quarter of 2020.

[0001193125-21-136849:8k_2_02:18]
Adjusted EBITDA in the first quarter of 2021 was $61.0 million, or 11.6 percent of net sales, compared to adjusted EBITDA of
$60.2 million, or 12.1 percent of net sales, from continuing operations, in the first quarter of 2020.

[0001193125-21-136849:8k_2_02:19]
“In the first
quarter, TTM delivered revenue and non-GAAP earnings above the midpoint of the previously guided range despite significant challenges from COVID-19 and tight supply
conditions for certain raw materials. The solid performance was driven by better than expected sales across all end markets led by strong year on year growth from the automotive and data center computing end markets,” said Tom Edman, CEO of
TTM. “Additionally, strict financial discipline drove solid operating cash flow in the quarter. Our improved financial performance enabled us to issue $500 million of new Senior Notes at a lower interest rate and longer tenor than our
previous Senior Notes which were redeemed. These achievements reflect the strategic changes made to strengthen TTM, particularly the divestiture of the volatile mobility business which normally caused weak seasonal results in the first half of the
year.”

[0001193125-21-136849:8k_2_02:20]
Business Outlook

[0001193125-21-136849:8k_2_02:21]
TTM estimates that
revenue for the second quarter of 2021 will be in the range of $525 million to $565 million, and non-GAAP net income will be in the range of $0.27 to $0.33 per diluted share.

[0001193125-21-136849:8k_2_02:22]
| TTM Technologies, Inc., Q1’21 |  | Contact: |  |  |
|  |  | Sameer Desai, |  |  |
|  |  | Vice President, CorporateDevelopment & InvestorRelations |  |  |
|  |  | Sameer.desai@ttmtech.com |  |  |
|  |  | 714-327-3050 |  |  |

[0001193125-21-136849:8k_2_02:23]
Live Webcast/Conference Call

[0001193125-21-136849:8k_2_02:24]
TTM will host a conference call and webcast to discuss first quarter 2021 results and the second quarter 2021 outlook on Wednesday, April 28th, 2021 at 4:30
p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call will include forward-looking statements.

[0001193125-21-136849:8k_2_02:25]
Telephone access is available by dialing
domestic 800-367-2403 or international 334-777-6978 (ID 7087128). The conference call
also will be webcast on TTM’s website at www.ttm.com.

[0001193125-21-136849:8k_2_02:26]
To Access a Replay of the Webcast

[0001193125-21-136849:8k_2_02:27]
The replay of the webcast will remain accessible for one week following the live event on TTM’s website at www.ttm.com.

[0001193125-21-136849:8k_2_02:28]
About TTM

[0001193125-21-136849:8k_2_02:29]
TTM Technologies, Inc. is a leading global
printed circuit board manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components
and assemblies. TTM stands for time-to-market, representing how TTM’s time-critical, one-stop manufacturing services enable
customers to shorten the time required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001193125-21-136849:8k_2_02:30]
Forward-Looking Statements

[0001193125-21-136849:8k_2_02:31]
The preliminary financial
results included in this press release represent the most current information available to management. The company’s actual results when disclosed in its Form 10-Q may differ from these preliminary
results as a result of the completion of the company’s financial closing procedures; final adjustments; completion of the review by the company’s independent registered accounting firm; and other developments that may arise between now and
the disclosure of the final results. This release contains forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These
statements reflect TTM’s current expectations, and TTM does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other
TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond TTM’s control, which could cause actual results to differ materially from the forward-looking statements. These risks and
uncertainties include, but are not limited to, the impact of COVID-19, general market and economic conditions, including interest rates, currency exchange rates and consumer spending, demand for TTM’s
products, market pressures on prices of TTM’s products and raw materials used in TTM’s products, warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements, TTM’s
dependence upon a small number of customers and other factors set forth in the “Risk Factors” and “Management’s Discussion and Analysis of Financial Condition and Results of Operations” sections of the Company’s public
reports filed with the SEC.

[0001193125-21-136849:8k_2_02:32]
About Our Non-GAAP Financial Measures

[0001193125-21-136849:8k_2_02:33]
This release includes information about TTM’s adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable
investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing financial performance.

[0001193125-21-136849:8k_2_02:34]
A material limitation
associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar
non-GAAP financial measures used by other companies. TTM compensates for these limitations by providing full

[0001193125-21-136849:8k_2_02:35]
| TTM Technologies, Inc., Q1’21 |  | Contact: |  |  |
|  |  | Sameer Desai, |  |  |
|  |  | Vice President, CorporateDevelopment & Investor Relations |  |  |
|  |  | Sameer.desai@ttmtech.com |  |  |
|  |  | 714-327-3050 |  |  |

[0001193125-21-136849:8k_2_02:36]
disclosure of each non-GAAP financial measure and reconciliation to the most directly
comparable GAAP financial measure. However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001193125-21-136849:8k_2_02:37]
With respect to the Company’s outlook for non-GAAP net income per diluted share, we are unable to predict with
reasonable certainty or without unreasonable effort certain items that may affect a comparable measure calculated and presented in accordance with GAAP. Our expected non-GAAP net income per diluted share
excludes primarily the future impact of restructuring actions, impairment charges, unusual gains and losses, and tax adjustments. These reconciling items are highly variable and difficult to predict due to various factors outside of
management’s control and could have a material impact on our future period net income per diluted share calculated and presented in accordance with GAAP. Accordingly, a reconciliation of non-GAAP net
income per diluted share to a comparable measure calculated and presented in accordance with GAAP is not available without unreasonable effort and has not been provided.

[0001193125-21-136849:8k_2_02:38]
- Tables Follow -

[0001193125-21-136849:8k_2_02:39]
TTM TECHNOLOGIES, INC.

[0001193125-21-136849:8k_2_02:40]
Selected Unaudited Financial Information

[0001193125-21-136849:8k_2_02:41]
(In thousands, except per share data)

[0001193125-21-136849:8k_2_02:42]
|  |  | First Quarter |  |
|  |  | 2021 |  |  | 2020 |  |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 526,432 |  |  | $ | 497,646 |  |
| Cost of goods sold |  |  | 444,832 |  |  |  | 416,304 |  |
| Gross profit |  |  | 81,600 |  |  |  | 81,342 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 16,282 |  |  |  | 16,169 |  |
| General and administrative |  |  | 28,295 |  |  |  | 34,339 |  |
| Research and development |  |  | 4,470 |  |  |  | 4,762 |  |
| Amortization of definite-lived intangibles |  |  | 9,521 |  |  |  | 9,562 |  |
| Restructuring charges |  |  | 3,232 |  |  |  | 328 |  |
| Total operating expenses |  |  | 61,800 |  |  |  | 65,160 |  |
| Operating income |  |  | 19,800 |  |  |  | 16,182 |  |
| Interest expense |  |  | (11,389 | ) |  |  | (19,781 | ) |
| Loss on extinguishment of debt |  |  | (15,217 | ) |  |  | — |  |
| Other, net |  |  | 2,507 |  |  |  | 2,502 |  |
| Loss from continuing operations before income taxes |  |  | (4,299 | ) |  |  | (1,097 | ) |
| Income tax benefit (provision) |  |  | 1,107 |  |  |  | (2,123 | ) |
| Net loss from continuing operations |  |  | (3,192 | ) |  |  | (3,220 | ) |
| Income from discontinued operations, net of income taxes |  |  | — |  |  |  | 2,046 |  |
| Net loss |  | $ | (3,192 | ) |  | $ | (1,174 | ) |
| (Loss) earnings per share: |  |  |  |  |  |  |  |  |
| Basic loss per share from continuing operations |  | $ | (0.03 | ) |  | $ | (0.03 | ) |
| Basic earnings per share from discontinued operations |  |  | — |  |  |  | 0.02 |  |
| Basic loss per share |  | $ | (0.03 | ) |  | $ | (0.01 | ) |
| Diluted loss per share from continuing operations |  | $ | (0.03 | ) |  | $ | (0.03 | ) |
| Diluted earnings per share from discontinued operations |  |  | — |  |  |  | 0.02 |  |
| Diluted loss per share |  | $ | (0.03 | ) |  | $ | (0.01 | ) |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |  |
| Basic |  |  | 106,825 |  |  |  | 105,686 |  |
| Diluted |  |  | 106,825 |  |  |  | 105,686 |  |

[0001193125-21-136849:8k_2_02:43]
SELECTED BALANCE SHEET DATA

[0001193125-21-136849:8k_2_02:44]
|  |  | March 29, 2021 |  |  | December 28, 2020 |  |
| Cash and cash equivalents, including restricted cash |  | $ | 539,648 |  |  | $ | 451,565 |  |
| Accounts and notes receivable, net |  |  | 366,768 |  |  |  | 381,105 |  |
| Contract assets |  |  | 271,702 |  |  |  | 273,256 |  |
| Inventories |  |  | 121,124 |  |  |  | 115,651 |  |
| Total current assets |  |  | 1,332,639 |  |  |  | 1,248,758 |  |
| Property, plant and equipment, net |  |  | 651,194 |  |  |  | 650,435 |  |
| Operating lease right of use asset |  |  | 21,383 |  |  |  | 24,340 |  |
| Other non-current assets |  |  | 960,612 |  |  |  | 972,411 |  |
| Total assets |  |  | 2,965,828 |  |  |  | 2,895,944 |  |
| Accounts payable |  | $ | 336,739 |  |  | $ | 327,102 |  |
| Total current liabilities |  |  | 509,154 |  |  |  | 518,046 |  |
| Debt, net of discount |  |  | 926,128 |  |  |  | 842,853 |  |
| Total long-term liabilities |  |  | 1,014,207 |  |  |  | 933,889 |  |
| Total equity |  |  | 1,442,467 |  |  |  | 1,444,009 |  |
| Total liabilities and equity |  |  | 2,965,828 |  |  |  | 2,895,944 |  |

[0001193125-21-136849:8k_2_02:45]
SUPPLEMENTAL DATA

[0001193125-21-136849:8k_2_02:46]
|  |  | First Quarter |  |
|  |  | 2021 |  |  | 2020 |  |
| Gross margin |  |  | 15.5 | % |  |  | 16.3 | % |
| Operating margin |  |  | 3.8 | % |  |  | 3.3 | % |
| End Market Breakdown, excludes Mobility: |  |  |  |  |  |  |  |  |
|  |  | First Quarter |  |
|  |  | 2021 |  |  | 2020 |  |
| Aerospace/Defense |  |  | 35 | % |  |  | 37 | % |
| Automotive |  |  | 18 | % |  |  | 14 | % |
| Data Center Computing |  |  | 14 | % |  |  | 12 | % |
| Medical/Industrial/Instrumentation |  |  | 17 | % |  |  | 19 | % |
| Networking/Communications |  |  | 15 | % |  |  | 17 | % |
| Other |  |  | 1 | % |  |  | 1 | % |
| Stock-based Compensation: |  |  |  |  |  |  |  |  |
|  |  | First Quarter |  |
|  |  | 2021 |  |  | 2020 |  |
| Amount included in: |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,165 |  |  | $ | 850 |  |
| Selling and marketing |  |  | 646 |  |  |  | 451 |  |
| General and administrative |  |  | 2,355 |  |  |  | 3,477 |  |
| Research and development |  |  | 43 |  |  |  | 57 |  |
| Total stock-based compensation expense |  | $ | 4,209 |  |  | $ | 4,835 |  |
| Operating Segment Data: |  |  |  |  |  |  |  |  |
|  |  | First Quarter |  |
|  |  | 2021 |  |  | 2020 |  |
| Net sales: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 510,486 |  |  | $ | 474,002 |  |
| RF&S |  |  | 12,690 |  |  |  | 9,441 |  |
| Other |  |  | 3,256 |  |  |  | 14,203 |  |
| Total net sales |  | $ | 526,432 |  |  | $ | 497,646 |  |
| Operating segment income: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 57,232 |  |  | $ | 60,238 |  |
| RF&S |  |  | 3,862 |  |  |  | 1,908 |  |
| Corporate & Other |  |  | (30,389 | ) |  |  | (35,019 | ) |
| Total operating segment income |  |  | 30,705 |  |  |  | 27,127 |  |
| Amortization of definite-lived intangibles |  |  | (10,905 | ) |  |  | (10,945 | ) |
| Total operating income |  |  | 19,800 |  |  |  | 16,182 |  |
| Total other expense |  |  | (24,099 | ) |  |  | (17,279 | ) |
| Loss from continuing operations before income taxes |  | $ | (4,299 | ) |  | $ | (1,097 | ) |
| RECONCILIATIONS1 |  |  |  |  |  |  |
|  |  | First Quarter |  |
|  |  | 2021 |  |  | 2020 |  |
| Non-GAAP gross profit reconciliation2: |  |  |  |  |  |  |  |  |
| GAAP gross profit from continuing operations |  | $ | 81,600 |  |  | $ | 81,342 |  |
| Add back item: |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 1,384 |  |  |  | 1,383 |  |
| Stock-based compensation |  |  | 1,165 |  |  |  | 850 |  |
| Restructuring and other charges |  |  | 254 |  |  |  | — |  |
| Non-GAAP gross profit |  | $ | 84,403 |  |  | $ | 83,575 |  |
| Non-GAAP gross margin |  |  | 16.0 | % |  |  | 16.8 | % |
| Non-GAAP operating income reconciliation3: |  |  |  |  |  |  |  |  |
| GAAP operating income from continuing operations |  | $ | 19,800 |  |  | $ | 16,182 |  |
| Add back items: |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 10,905 |  |  |  | 10,945 |  |
| Stock-based compensation |  |  | 4,209 |  |  |  | 4,835 |  |
| (Gain) on sale of assets |  |  | (410 | ) |  |  | — |  |
| Restructuring, acquisition-related, and other charges |  |  | 3,285 |  |  |  | 1,596 |  |
| Non-GAAP operating income |  | $ | 37,789 |  |  | $ | 33,558 |  |
| Non-GAAP operating margin |  |  | 7.2 | % |  |  | 6.7 | % |
| Non-GAAP net income and EPS reconciliation4: |  |  |  |  |  |  |  |  |
| GAAP net loss from continuing operations |  | $ | (3,192 | ) |  | $ | (3,220 | ) |

[0001193125-21-136849:8k_2_02:47]
| Add back items: |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 10,905 |  |  |  | 10,945 |  |
| Stock-based compensation |  |  | 4,209 |  |  |  | 4,835 |  |
| Non-cash interest expense |  |  | 537 |  |  |  | 3,553 |  |
| (Gain) on sale of assets |  |  | (980 | ) |  |  | (233 | ) |
| Change in fair value of warrant liabilities |  |  | (172 | ) |  |  | — |  |
| Loss on extinguishment of debt |  |  | 15,217 |  |  |  | — |  |
| Restructuring, acquisition-related, and other charges |  |  | 3,285 |  |  |  | 1,596 |  |
| Income taxes5 |  |  | (4,551 | ) |  |  | (816 | ) |
| Non-GAAP net income |  | $ | 25,258 |  |  | $ | 16,660 |  |
| Non-GAAP earnings per diluted share |  | $ | 0.23 |  |  | $ | 0.16 |  |
| Non-GAAP diluted number of shares: |  |  |  |  |  |  |  |  |
| GAAP Diluted shares |  |  | 106,825 |  |  |  | 105,686 |  |
| Dilutive effect of Restricted Stock Units, Performance-based Restricted Stock Units, Stock Options |  |  | 1,879 |  |  |  | 1,692 |  |
| Non-GAAP diluted number of shares |  |  | 108,704 |  |  |  | 107,378 |  |
| Adjusted EBITDA reconciliation6: |  |  |  |  |  |  |  |  |
| GAAP net loss from continuing operations |  | $ | (3,192 | ) |  | $ | (3,220 | ) |
| Add back items: |  |  |  |  |  |  |  |  |
| Income tax (benefit) provision |  |  | (1,107 | ) |  |  | 2,123 |  |
| Interest expense |  |  | 11,389 |  |  |  | 19,781 |  |
| Amortization of definite-lived intangibles |  |  | 10,905 |  |  |  | 10,945 |  |
| Depreciation expense |  |  | 21,476 |  |  |  | 24,372 |  |
| Stock-based compensation |  |  | 4,209 |  |  |  | 4,835 |  |
| (Gain) on sale of assets |  |  | (980 | ) |  |  | (233 | ) |
| Change in fair value of warrant liabilities |  |  | (172 | ) |  |  | — |  |
| Loss on extinguishment of debt |  |  | 15,217 |  |  |  | — |  |
| Restructuring, acquisition-related, and other charges |  |  | 3,285 |  |  |  | 1,596 |  |
| Adjusted EBITDA |  | $ | 61,030 |  |  | $ | 60,199 |  |
| Adjusted EBITDA margin |  |  | 11.6 | % |  |  | 12.1 | % |
| Free cash flow reconciliation7: |  |  |  |  |  |  |  |  |
| Operating cash flow |  | $ | 41,145 |  |  | $ | 6,627 |  |
| Capital expenditures, net |  |  | (20,966 | ) |  |  | (23,932 | ) |
| Free cash flow |  | $ | 20,179 |  |  | $ | (17,305 | ) |

[0001193125-21-136849:8k_2_02:48]
| 1 | This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income, non-GAAP EPS, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |

[0001193125-21-136849:8k_2_02:49]
| 2 | Non-GAAP gross profit and gross margin measures exclude amortization of intangibles, stock-based compensation expense, and restructuring and other charges. |

[0001193125-21-136849:8k_2_02:50]
| 3 | Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, restructuring, acquisition-related costs, and other charges. |

[0001193125-21-136849:8k_2_02:51]
| 4 | This information provides non-GAAP net income and non-GAAP EPS, which are non-GAAP financial measures. Management believes that both measures – which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, change in fair value of warrant liabilities, loss on extinguishment of debt, restructuring, acquisition-related costs, and other charges as well as the associated tax impact of these charges and discrete tax items – provide additional useful information to investors regarding the Company’s ongoing financial condition and results of operations. |

[0001193125-21-136849:8k_2_02:52]
| 5 | Income tax adjustments reflect the difference between income taxes based on a non-GAAP tax rate and a forecasted annual GAAP tax rate. |

[0001193125-21-136849:8k_2_02:53]
| 6 | Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, change in fair value of warrant liabilities, loss on extinguishment of debt, restructuring, acquisition-related costs, and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |

[0001193125-21-136849:8k_2_02:54]
| 7 | Free Cash Flow in 2020 has been restated to exclude the Mobility business which was sold in Q2 of 2020. |
