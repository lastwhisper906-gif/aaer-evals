# TTMI note change history — 0000950170-23-019634 → 0000950170-23-041297


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-08-10):
[0000950170-23-041297:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 3, 2023 and January 2, 2023 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2023-05-09, similarity 0.8039):
[0000950170-23-019634:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 3, 2023 and January 2, 2023. However, these amounts are not material to the consolidated condensed financial statements of the Company.

- changed (2023-08-10):
[0000950170-23-041297:note_history:2]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of July 3, 2023, the Company had outstanding offset agreements of approximately $20,169, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of July 3, 2023, no such penalties have been paid.
  (was, 2023-05-09, similarity 0.9878):
[0000950170-23-019634:note_history:2]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations, if applicable. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of April 3, 2023, the Company had outstanding offset agreements of approximately $20,169, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of April 3, 2023, no such penalties have been paid.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-08-10):
[0000950170-23-041297:note_history:3]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions including mission systems, radio frequency (RF) components/RF microwave/microelectronic assemblies, quick-turn and technologically advanced printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This one-stop design, engineering, and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.
  (was, 2023-05-09, similarity 0.9204):
[0000950170-23-019634:note_history:3]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions, including engineered systems, radio frequency (RF) components and RF microwave/microelectronic assemblies, and printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This one-stop design, engineering, and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- changed (2023-08-10):
[0000950170-23-041297:note_history:4]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation related products, and networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors and government agencies.
  (was, 2023-05-09, similarity 0.9873):
[0000950170-23-019634:note_history:4]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation related products, as well as networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors and government agencies.

- changed (2023-08-10):
[0000950170-23-041297:note_history:5]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the on-going effects of the coronavirus (COVID-19) and its variants on the Company and the conflict between Russia and Ukraine, the global economy and financial markets have been volatile. In addition, both COVID-19 and the conflict in Ukraine have contributed to on-going disruptions in global supply chains, labor shortages, high inflation, and a potential recession, and there is a significant amount of uncertainty about the length and severity of the direct and indirect effects of COVID-19 variants and the conflict. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.
  (was, 2023-05-09, similarity 0.7471):
[0000950170-23-019634:note_history:5]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the on-going effects of the coronavirus (COVID-19) global pandemic on the Company and the conflict between Russia and Ukraine, the global economy and financial markets have been volatile, and both the pandemic and conflict has contributed to on-going disruptions in global supply chains, labor shortages, high inflation, and a potential recession, and there is a significant amount of uncertainty about the length and severity of the direct and indirect effects of the pandemic and the conflict. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

- changed (2023-08-10):
[0000950170-23-041297:note_history:6]
In September 2022, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. The Company adopted ASU 2022-04 as of April 3, 2023. The Company has agreements with financial institutions to facilitate the payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days, with a weighted average of 260 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $8,206 and $6,653 as of July 3, 2023 and January 2, 2023, respectively.
  (was, 2023-05-09, similarity 0.9918):
[0000950170-23-019634:note_history:6]
In September 2022, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. The Company adopted ASU 2022-04 as of April 3, 2023. The Company has agreements with financial institutions to facilitate the payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 220 days to 360 days, with a weighted average of 290 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $3,565 and $6,653 as of April 3, 2023 and January 2, 2023, respectively.

- changed (2023-08-10):
[0000950170-23-041297:note_history:7]
In December 2022, the FASB issued ASU 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which deferred the sunset date of Topic 848 to December 31, 2024, after which entities will no longer be permitted to apply the optional expedients and exceptions in Topic 848. On March 23, 2023, the Company entered into a four-year pay-fixed, receive floating (1-month CME Term Secured Overnight Financing Rate (SOFR)), interest rate swap arrangement with a notional amount of $250,000 for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its Term SOFR-based debt and receives a floating 1-month CME Term SOFR during the swap period. The Company elected optional expedients provided in Topic 848 which allow the designation of the interest rate swap as a cash flow hedge.
  (was, 2023-05-09, similarity 0.9884):
[0000950170-23-019634:note_history:7]
In December 2022, the FASB issued ASU 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which deferred the sunset date of Topic 848 to December 31, 2024, after which entities will no longer be permitted to apply the optional expedients and exceptions in Topic 848. On March 23, 2023, the Company entered into a four-year pay-fixed, receive floating (1-month CME Term Secured Overnight Financing Rate (SOFR)), interest rate swap arrangement with a notional amount of $250.0 million for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its LIBOR-based debt and receives a floating 1-month CME Term SOFR during the swap period. The Company elected optional expedients provided in Topic 848 which allow the designation of the interest rate swap as a cash flow hedge.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-10):
[0000950170-23-041297:note_history:8]
As of July 3, 2023 and January 2, 2023, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:
  (was, 2023-05-09, similarity 0.9776):
[0000950170-23-019634:note_history:8]
As of April 3, 2023 and January 2, 2023, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

- changed (2023-08-10):
[0000950170-23-041297:note_history:9]
|  |  | As of July 3, 2023 |  |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,435 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 4,181 |  |  |  | 3,471 |  |  |  | 8.25 |  |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 8,616 |  |  | $ | 3,471 |  |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |
  (was, 2023-05-09, similarity 0.6763):
[0000950170-23-019634:note_history:9]
|  |  | As of April 3, 2023 |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,608 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 981 |  |  |  | 297 |  |  |  | 4.66 |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 5,589 |  |  | $ | 297 |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-10):
[0000950170-23-041297:note_history:10]
The following table summarizes the long-term debt of the Company as of July 3, 2023 and January 2, 2023:
  (was, 2023-05-09, similarity 0.9637):
[0000950170-23-019634:note_history:10]
The following table summarizes the long-term debt of the Company as of April 3, 2023 and January 2, 2023:

- changed (2023-08-10):
[0000950170-23-041297:note_history:11]
|  |  | Interest Rate as ofJuly 3, 2023 |  |  |  | PrincipalOutstandingas ofJuly 3, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 7.89 |  |  |  |  | 350,000 |  |  |  | — |  |  |  |  | — |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.44 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
| Term Loan due September 2024 |  |  | — |  |  |  |  | — |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
|  |  |  |  |  |  |  | 880,000 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,616 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (3,471 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 867,913 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 864,413 |  |  |  |  |  |  | $ | 879,407 |  |
  (was, 2023-05-09, similarity 0.792):
[0000950170-23-019634:note_history:11]
|  |  | Interest Rate as ofApril 3, 2023 |  |  |  | PrincipalOutstandingas ofApril 3, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 7.36 |  |  |  |  | 355,879 |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 6.26 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 885,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (5,589 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (297 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 879,993 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 879,993 |  |  |  |  |  |  | $ | 879,407 |  |

- added (2023-08-10):
[0000950170-23-041297:note_history:12]
Term Loan Facility

- added (2023-08-10):
[0000950170-23-041297:note_history:13]
On May 30, 2023, pursuant to an Amended & Restated Term Loan Credit Agreement by and among the Company, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto (Term Loan Credit Agreement), the Company closed its $350,000 senior secured Term Loan due 2030 (Term Loan Facility), of which $3,500 is included in short-term debt and $346,500 is included in long-term debt. The Term Loan Facility was issued with a 1.0% original issue discount and bears interest at a floating rate of 1-month CME Term SOFR plus an applicable margin of 2.75%. There is no provision, other than an event of default, for the interest margin to increase. The Company is required to make quarterly principal repayments in an aggregate annual amount equal to 1% of the initial aggregate principal amount of the Term Loan Facility beginning October 1, 2023. Such principal repayment is payable quarterly on January 1, April 1, July 1, and October 1 and ending with the last such day to occur prior to May 30, 2030. The remaining principal under the Term Loan Facility is scheduled to mature on May 30, 2030. In addition, the Term Loan Credit Agreement will permit the Company to add one or more senior secured incremental term loan facilities to the Term Loan Facility subject to the satisfaction of certain conditions.

- added (2023-08-10):
[0000950170-23-041297:note_history:14]
The Company used $234,818 under the Term Loan Facility and $115,182 of cashless rollover from continuing lenders, together with cash on hand, to refinance the full amount of indebtedness outstanding under the Company’s previous Term Loan Facility that was due to mature in 2024, as well as to pay related fees and expenses.

- added (2023-08-10):
[0000950170-23-041297:note_history:15]
The obligations under the Term Loan Facility are unconditionally guaranteed by each Subsidiary Guarantor of the Company, subject to certain exceptions (Guarantors). The Term Loan Facility is secured by (i) a perfected first priority security interest in substantially all of the assets of the Company and the Guarantors (other than the U.S. ABL Priority Collateral (as defined below)), including all of the total outstanding voting capital stock held by the Company and the Guarantors (subject to a limitation of 65% on pledges of such capital stock of certain foreign subsidiaries and domestic holding companies of foreign subsidiaries) and (ii) a perfected second priority interest in all of the U.S. ABL Priority Collateral. The Term Loan Facility is structurally senior to the Company’s Senior Notes due 2029.

- added (2023-08-10):
[0000950170-23-041297:note_history:16]
Asset-Based Lending Agreements

- added (2023-08-10):
[0000950170-23-041297:note_history:17]
The Company amended and restated its U.S. Asset-Based Lending Credit Agreement (U.S. ABL) on May 30, 2023 and its Asia Asset-Based Lending Credit Agreement (Asia ABL) on June 14, 2023. Both agreements were amended for the benchmark interest rate and margins and maturity was extended to May 2028 and June 2028 for the U.S. ABL and the Asia ABL, respectively.

- added (2023-08-10):
[0000950170-23-041297:note_history:18]
The U.S. ABL is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $50,000, provided that at no time may amounts outstanding under the agreement exceed in the aggregate $150,000 or the applicable borrowing base, which is the sum of (i) a percentage of the principal amount of “Eligible Accounts”, plus (ii) a percentage of the net orderly liquidation value of (x) “Eligible Inventory”, minus (y) “Inventory Reserves” applicable thereto, minus (iii) “Reserves”, each as defined in the U.S. ABL agreement.

- added (2023-08-10):
[0000950170-23-041297:note_history:19]
Borrowings under the U.S. ABL bear interest at a floating rate of Term SOFR plus a margin ranging from 1.25% to 1.50%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for Term SOFR-based loans and from 25 to 50 basis points for JPMorgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The Company is also required to pay certain fees in connection with the U.S. ABL agreement, including unused commitment fees based on the average daily unused portion of the U.S. ABL facility, equal to 0.25% on an annual basis.

- added (2023-08-10):
[0000950170-23-041297:note_history:20]
The U.S. ABL is scheduled to mature on May 30, 2028. The Guarantors have also fully guaranteed the full and timely payment of all obligations in respect of the U.S. ABL. Loans made under the U.S. ABL are secured by a perfected first priority security interest in certain deposit accounts, cash and cash equivalents, accounts receivable and certain U.S. inventory (U.S. ABL Priority Collateral) as well as by a perfected second priority interest in all of the collateral securing the Term Loan Facility.

- added (2023-08-10):
[0000950170-23-041297:note_history:21]
The Asia ABL is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $100,000, provided that at no time may amounts outstanding under the agreement exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement.

- added (2023-08-10):
[0000950170-23-041297:note_history:22]
Borrowings under the Asia ABL bear interest at a floating rate of Term SOFR plus 130 basis points. There is no provision, other than an event of default, for the interest margin to increase. The Company is also required to pay certain fees in connection with the Asia ABL agreement, including unused commitment fees based on the average daily unused portion of the Asia ABL facility, equal to 0.25% on an annual basis.

- added (2023-08-10):
[0000950170-23-041297:note_history:23]
The Asia ABL is scheduled to mature on June 13, 2028. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes due 2029.

- added (2023-08-10):
[0000950170-23-041297:note_history:24]
As of July 3, 2023, letters of credit in the amount of $6,191 were outstanding under the U.S. ABL and $14,039 were outstanding under the Asia ABL with various maturities through September 2024. Available borrowing capacity under the U.S. ABL and the Asia ABL was $143,809 and $105,961, respectively, which considers letters of credit outstanding as of July 3, 2023.

- changed (2023-08-10):
[0000950170-23-041297:note_history:25]
As of July 3, 2023 and January 2, 2023, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:
  (was, 2023-05-09, similarity 0.9776):
[0000950170-23-019634:note_history:25]
As of April 3, 2023 and January 2, 2023, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

- changed (2023-08-10):
[0000950170-23-041297:note_history:26]
|  |  | As of July 3, 2023 |  |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,435 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 4,181 |  |  |  | 3,471 |  |  |  | 8.25 |  |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 8,616 |  |  | $ | 3,471 |  |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |
  (was, 2023-05-09, similarity 0.6763):
[0000950170-23-019634:note_history:26]
|  |  | As of April 3, 2023 |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,608 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 981 |  |  |  | 297 |  |  |  | 4.66 |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 5,589 |  |  | $ | 297 |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |

- changed (2023-08-10):
[0000950170-23-041297:note_history:27]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,786 and $792 as of July 3, 2023 and January 2, 2023, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2023-05-09, similarity 0.9852):
[0000950170-23-019634:note_history:27]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $652 and $792 as of April 3, 2023 and January 2, 2023, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2023-08-10):
[0000950170-23-041297:note_history:28]
As of July 3, 2023, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 6.3 years.
  (was, 2023-05-09, similarity 0.9744):
[0000950170-23-019634:note_history:28]
As of April 3, 2023, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.6 years.

- added (2023-08-10):
[0000950170-23-041297:note_history:29]
Loss on Extinguishment of Debt

- added (2023-08-10):
[0000950170-23-041297:note_history:30]
During the quarter ended July 3, 2023, the Company recognized loss on extinguishment of debt of $1,154, primarily associated with the write-off of the remaining unamortized debt issuance and debt discount as a result of the repayment of the remaining outstanding balance of the Term Loan Facility that was due to mature September 2024.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-10):
[0000950170-23-041297:note_history:31]
The following table summarizes the long-term debt of the Company as of July 3, 2023 and January 2, 2023:
  (was, 2023-05-09, similarity 0.9637):
[0000950170-23-019634:note_history:31]
The following table summarizes the long-term debt of the Company as of April 3, 2023 and January 2, 2023:

- changed (2023-08-10):
[0000950170-23-041297:note_history:32]
|  |  | Interest Rate as ofJuly 3, 2023 |  |  |  | PrincipalOutstandingas ofJuly 3, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 7.89 |  |  |  |  | 350,000 |  |  |  | — |  |  |  |  | — |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.44 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
| Term Loan due September 2024 |  |  | — |  |  |  |  | — |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
|  |  |  |  |  |  |  | 880,000 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,616 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (3,471 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 867,913 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 864,413 |  |  |  |  |  |  | $ | 879,407 |  |
  (was, 2023-05-09, similarity 0.792):
[0000950170-23-019634:note_history:32]
|  |  | Interest Rate as ofApril 3, 2023 |  |  |  | PrincipalOutstandingas ofApril 3, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 7.36 |  |  |  |  | 355,879 |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 6.26 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 885,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (5,589 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (297 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 879,993 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 879,993 |  |  |  |  |  |  | $ | 879,407 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-08-10):
[0000950170-23-041297:note_history:33]
|  |  | Quarter Ended July 3, 2023 |  |  | Quarter Ended July 4, 2022 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
| End Markets |  | (In thousands) |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 254,284 |  |  | $ | — |  |  | $ | 254,284 |  |  | $ | 189,676 |  |  | $ | — |  |  | $ | 189,676 |  |
| Automotive |  |  | 92,374 |  |  |  | — |  |  |  | 92,374 |  |  |  | 111,778 |  |  |  | — |  |  |  | 111,778 |  |
| Data Center Computing |  |  | 64,305 |  |  |  | 51 |  |  |  | 64,356 |  |  |  | 106,188 |  |  |  | 20 |  |  |  | 106,208 |  |
| Medical/Industrial/Instrumentation |  |  | 88,979 |  |  |  | 745 |  |  |  | 89,724 |  |  |  | 131,061 |  |  |  | 2,246 |  |  |  | 133,307 |  |
| Networking |  |  | 36,589 |  |  |  | 9,182 |  |  |  | 45,771 |  |  |  | 69,766 |  |  |  | 15,109 |  |  |  | 84,875 |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 960 |  |  |  | (1,254 | ) |  |  | (294 | ) |
| Total |  | $ | 536,531 |  |  | $ | 9,978 |  |  | $ | 546,509 |  |  | $ | 609,429 |  |  | $ | 16,121 |  |  | $ | 625,550 |  |

- added (2023-08-10):
[0000950170-23-041297:note_history:34]
|  |  | Two Quarters Ended July 3, 2023 |  |  | Two Quarters Ended July 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 486,576 |  |  | $ | — |  |  | $ | 486,576 |  |  | $ | 361,856 |  |  | $ | — |  |  |  | $ | 361,856 |  |  |
| Automotive |  |  | 185,841 |  |  |  | — |  |  |  | 185,841 |  |  |  | 227,014 |  |  |  | — |  |  |  |  | 227,014 |  |  |
| Data Center Computing |  |  | 122,175 |  |  |  | 51 |  |  |  | 122,226 |  |  |  | 197,972 |  |  |  | 20 |  |  |  |  | 197,992 |  |  |
| Medical/Industrial/Instrumentation |  |  | 189,747 |  |  |  | 1,662 |  |  |  | 191,409 |  |  |  | 251,423 |  |  |  | 3,784 |  |  |  |  | 255,207 |  |  |
| Networking |  |  | 86,303 |  |  |  | 18,591 |  |  |  | 104,894 |  |  |  | 133,409 |  |  |  | 28,866 |  |  |  |  | 162,275 |  |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,825 |  |  |  | (1,359 | ) |  |  |  | 2,466 |  |  |
| Total |  | $ | 1,070,642 |  |  | $ | 20,304 |  |  | $ | 1,090,946 |  |  | $ | 1,175,499 |  |  | $ | 31,311 |  |  |  | $ | 1,206,810 |  |  |

- removed (2023-08-10):
[0000950170-23-019634:note_history:35]
|  |  | Quarter Ended April 3, 2023 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 232,292 |  |  | $ | — |  |  | $ | 232,292 |  |  |
| Automotive |  |  | 93,467 |  |  |  | — |  |  |  | 93,467 |  |  |
| Data Center Computing |  |  | 57,870 |  |  |  | — |  |  |  | 57,870 |  |  |
| Medical/Industrial/Instrumentation |  |  | 100,768 |  |  |  | 917 |  |  |  | 101,685 |  |  |
| Networking |  |  | 49,714 |  |  |  | 9,409 |  |  |  | 59,123 |  |  |
| Total |  | $ | 534,111 |  |  | $ | 10,326 |  |  | $ | 544,437 |  |  |

- removed (2023-08-10):
[0000950170-23-019634:note_history:36]
|  |  | Quarter Ended April 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 172,180 |  |  | $ | — |  |  | $ | 172,180 |  |  |
| Automotive |  |  | 115,236 |  |  |  | — |  |  |  | 115,236 |  |  |
| Data Center Computing |  |  | 91,784 |  |  |  | — |  |  |  | 91,784 |  |  |
| Medical/Industrial/Instrumentation |  |  | 120,362 |  |  |  | 1,538 |  |  |  | 121,900 |  |  |
| Networking |  |  | 63,643 |  |  |  | 13,757 |  |  |  | 77,400 |  |  |
| Other |  |  | 2,865 |  |  |  | (105 | ) |  |  | 2,760 |  |  |
| Total |  | $ | 566,070 |  |  | $ | 15,190 |  |  | $ | 581,260 |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-10):
[0000950170-23-041297:note_history:37]
As of July 3, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $376,291. The Company expects to recognize revenue on approximately 50% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount expected to be recognized thereafter.
  (was, 2023-05-09, similarity 0.9879):
[0000950170-23-019634:note_history:37]
As of April 3, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $378,829. The Company expects to recognize revenue on approximately 52% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount expected to be recognized thereafter.

- changed (2023-08-10):
[0000950170-23-041297:note_history:38]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of July 3, 2023 and January 2, 2023 were $19,971 and $21,632, respectively.
  (was, 2023-05-09, similarity 0.9874):
[0000950170-23-019634:note_history:38]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of April 3, 2023 and January 2, 2023 were $20,641 and $21,632, respectively.

- changed (2023-08-10):
[0000950170-23-041297:note_history:39]
Revenue recognized for the two quarters ended July 3, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $27,069.
  (was, 2023-05-09, similarity 0.9512):
[0000950170-23-019634:note_history:39]
Revenue recognized for the quarter ended April 3, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $18,508.

- changed (2023-08-10):
[0000950170-23-041297:note_history:40]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for the quarter and two quarters ended July 3, 2023, and 97% and 3%, respectively, of the Company’s revenue for the quarter and two quarters ended July 4, 2022.
  (was, 2023-05-09, similarity 0.6241):
[0000950170-23-019634:note_history:40]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for the quarter ended April 3, 2023, and 97% and 3%, respectively, of the Company’s revenue for the quarter ended April 4, 2022.

- added (2023-08-10):
[0000950170-23-041297:note_history:41]
|  |  | Quarter Ended July 3, 2023 |  |  | Quarter Ended July 4, 2022 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
| End Markets |  | (In thousands) |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 254,284 |  |  | $ | — |  |  | $ | 254,284 |  |  | $ | 189,676 |  |  | $ | — |  |  | $ | 189,676 |  |
| Automotive |  |  | 92,374 |  |  |  | — |  |  |  | 92,374 |  |  |  | 111,778 |  |  |  | — |  |  |  | 111,778 |  |
| Data Center Computing |  |  | 64,305 |  |  |  | 51 |  |  |  | 64,356 |  |  |  | 106,188 |  |  |  | 20 |  |  |  | 106,208 |  |
| Medical/Industrial/Instrumentation |  |  | 88,979 |  |  |  | 745 |  |  |  | 89,724 |  |  |  | 131,061 |  |  |  | 2,246 |  |  |  | 133,307 |  |
| Networking |  |  | 36,589 |  |  |  | 9,182 |  |  |  | 45,771 |  |  |  | 69,766 |  |  |  | 15,109 |  |  |  | 84,875 |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 960 |  |  |  | (1,254 | ) |  |  | (294 | ) |
| Total |  | $ | 536,531 |  |  | $ | 9,978 |  |  | $ | 546,509 |  |  | $ | 609,429 |  |  | $ | 16,121 |  |  | $ | 625,550 |  |

- added (2023-08-10):
[0000950170-23-041297:note_history:42]
|  |  | Two Quarters Ended July 3, 2023 |  |  | Two Quarters Ended July 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 486,576 |  |  | $ | — |  |  | $ | 486,576 |  |  | $ | 361,856 |  |  | $ | — |  |  |  | $ | 361,856 |  |  |
| Automotive |  |  | 185,841 |  |  |  | — |  |  |  | 185,841 |  |  |  | 227,014 |  |  |  | — |  |  |  |  | 227,014 |  |  |
| Data Center Computing |  |  | 122,175 |  |  |  | 51 |  |  |  | 122,226 |  |  |  | 197,972 |  |  |  | 20 |  |  |  |  | 197,992 |  |  |
| Medical/Industrial/Instrumentation |  |  | 189,747 |  |  |  | 1,662 |  |  |  | 191,409 |  |  |  | 251,423 |  |  |  | 3,784 |  |  |  |  | 255,207 |  |  |
| Networking |  |  | 86,303 |  |  |  | 18,591 |  |  |  | 104,894 |  |  |  | 133,409 |  |  |  | 28,866 |  |  |  |  | 162,275 |  |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,825 |  |  |  | (1,359 | ) |  |  |  | 2,466 |  |  |
| Total |  | $ | 1,070,642 |  |  | $ | 20,304 |  |  | $ | 1,090,946 |  |  | $ | 1,175,499 |  |  | $ | 31,311 |  |  |  | $ | 1,206,810 |  |  |

- removed (2023-08-10):
[0000950170-23-019634:note_history:43]
|  |  | Quarter Ended April 3, 2023 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 232,292 |  |  | $ | — |  |  | $ | 232,292 |  |  |
| Automotive |  |  | 93,467 |  |  |  | — |  |  |  | 93,467 |  |  |
| Data Center Computing |  |  | 57,870 |  |  |  | — |  |  |  | 57,870 |  |  |
| Medical/Industrial/Instrumentation |  |  | 100,768 |  |  |  | 917 |  |  |  | 101,685 |  |  |
| Networking |  |  | 49,714 |  |  |  | 9,409 |  |  |  | 59,123 |  |  |
| Total |  | $ | 534,111 |  |  | $ | 10,326 |  |  | $ | 544,437 |  |  |

- removed (2023-08-10):
[0000950170-23-019634:note_history:44]
|  |  | Quarter Ended April 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |
| Aerospace and Defense |  | $ | 172,180 |  |  | $ | — |  |  | $ | 172,180 |  |  |
| Automotive |  |  | 115,236 |  |  |  | — |  |  |  | 115,236 |  |  |
| Data Center Computing |  |  | 91,784 |  |  |  | — |  |  |  | 91,784 |  |  |
| Medical/Industrial/Instrumentation |  |  | 120,362 |  |  |  | 1,538 |  |  |  | 121,900 |  |  |
| Networking |  |  | 63,643 |  |  |  | 13,757 |  |  |  | 77,400 |  |  |
| Other |  |  | 2,865 |  |  |  | (105 | ) |  |  | 2,760 |  |  |
| Total |  | $ | 566,070 |  |  | $ | 15,190 |  |  | $ | 581,260 |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2023-08-10):
[0000950170-23-019634:note_history:45]
(18) Subsequent Events

- removed (2023-08-10):
[0000950170-23-019634:note_history:46]
On May 3, 2023, the Company announced that its Board of Directors authorized and approved a share repurchase program. Under the program, the Company may repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through May 3, 2025. The Company may repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (Exchange Act) which sets certain restrictions on the method, timing, price and volume of open market stock repurchases. In addition, the Company expects to adopt one or more trading plans in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price and amount of any repurchases will be determined at the Company’s discretion, and the share repurchase program may be suspended, terminated or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.
