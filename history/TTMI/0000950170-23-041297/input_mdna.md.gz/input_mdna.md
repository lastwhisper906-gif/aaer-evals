# TTMI MD&A — 0000950170-23-041297


## mdna

[0000950170-23-041297:mdna:1]
[same as prior period, unchanged from 0000950170-23-019634:mdna:1]

[0000950170-23-041297:mdna:2]
Cautionary Statement Regarding Forward-Looking Statements

[0000950170-23-041297:mdna:3]
This Quarterly Report on Form 10-Q contains forward-looking statements regarding future events or our future financial and operational performance. Forward-looking statements include statements regarding markets for our products; trends in net sales, gross profits and estimated expense levels; liquidity and anticipated cash needs and availability; and any statement that contains the words “anticipate,” “believe,” “plan,” “forecast,” “foresee,” “estimate,” “project,” “expect,” “seek,” “target,” “intend,” “goal” and other similar expressions. The forward-looking statements included in this report reflect our current expectations and beliefs, and we do not undertake publicly to update or revise these statements, even if experience or future changes make it clear that any projected results expressed in this report or future quarterly reports to stockholders, press releases or company statements will not be realized. In addition, the inclusion of any statement in this report does not constitute an admission by us that the events or circumstances described in such statement are material. Furthermore, we wish to caution and advise readers that these statements are based on assumptions that may not materialize and may involve risks and uncertainties, many of which are beyond our control, that could cause actual events or performance to differ materially from those contained or implied in these forward-looking statements. These risks and uncertainties include the business and economic risks described in Item 1A “Risk Factors” of Part II below and elsewhere in this Quarterly Report on Form 10-Q. The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated condensed financial statements and the related notes and the other financial information included in this Quarterly Report on Form 10-Q, as well as the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” set forth in our Annual Report on Form 10-K for the fiscal year ended January 2, 2023, filed with the SEC.

[0000950170-23-041297:mdna:4]
[same as prior period, unchanged from 0000950170-23-019634:mdna:2]

[0000950170-23-041297:mdna:5]
We are a leading global manufacturer of technology solutions including mission systems, radio frequency (RF) components/RF microwave/microelectronic assemblies, quick-turn and technologically advanced printed circuit boards (PCB). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering, and manufacturing solution to our customers. This one-stop design, engineering, and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,500 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation, and networking. Our customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors and government agencies.

[0000950170-23-041297:mdna:6]
[same as prior period, unchanged from 0000950170-23-019634:mdna:4]

[0000950170-23-041297:mdna:7]
While demand in the Aerospace and Defense end market remains strong, bookings in our commercial end markets have stabilized at a low level given continued customer inventory reductions and weaker end market demand. This resulted in a decline to revenues during the quarter ended July 3, 2023 when compared to the same quarter last year.

[0000950170-23-041297:mdna:8]
On May 30, 2023, we closed our $350.0 million senior secured Term Loan due 2030 (Term Loan Facility). The Term Loan Facility was issued with a 1.0% original issue discount and bears interest at a floating rate of 1-month CME Term Secured Overnight Financing Rate (SOFR) plus an applicable margin of 2.75%. We also amended and restated our U.S. Asset-Based Lending Credit Agreement (U.S. ABL) on May 30, 2023 and our Asia Asset-Based Lending Credit Agreement (Asia ABL) on June 14, 2023. Both agreements were amended for the benchmark interest rate and margins and maturity was extended to May 2028 and June 2028 for the U.S. ABL and the Asia ABL, respectively. Refer to Part I, Item 1, Note 8, Long-term Debt and Letters of Credit, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q for further information.

[0000950170-23-041297:mdna:9]
On March 30, 2023, we completed the sale of our Shanghai Backplane Assembly entity for approximately $11.2 million to DBG Holdings Limited (DBG), which is wholly owned by DBG Technology Co. Ltd., a public company traded on the Shenzhen Stock Exchange. We recorded a gain on the sale of $1.3 million.

[0000950170-23-041297:mdna:10]
On February 8, 2023, we announced our plan to close PCB manufacturing operations in Anaheim and Santa Clara, California, and Hong Kong and to consolidate the business from these sites into our remaining facilities. The plant closures are expected to improve both facility and talent utilization across our footprint resulting in improved profitability. We expect to record between $22.0 million and $28.0 million in separation, accelerated depreciation and disposal costs related to this restructuring, primarily between now and the end of 2023. Approximately 80% of these costs are expected to be in the form of cash expenditures and the rest in the form of non-cash charges. As of July 3, 2023, we have substantially closed the Hong Kong manufacturing facility. We expect the Anaheim and Santa Clara facilities to be substantially closed by the end of 2023.

[0000950170-23-041297:mdna:11]
On December 22, 2022, our land, building, and relevant ancillary assets related to our former Shanghai E-MS (SH E-MS) manufacturing facility was expropriated by the Chinese government for a compensation fee of Renminbi (RMB) 477.6 million resulting in a gain on the sale of $51.8 million. We received 90% of the proceeds as of July 3, 2023 and expect to receive the remaining 10% of

[0000950170-23-041297:mdna:12]
the proceeds before December 30, 2023. As of July 3, 2023 and January 2, 2023, the receivable from sale of SH E-MS property was $6.6 million and $69.2 million, respectively.

[0000950170-23-041297:mdna:13]
[same as prior period, unchanged from 0000950170-23-019634:mdna:9]

[0000950170-23-041297:mdna:14]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 50% and 49% of our net sales for the quarter and two quarters ended July 3, 2023, respectively. Sales to our ten largest customers collectively accounted for 41% and 43% of our net sales for the quarter and two quarters ended July 4, 2022, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0000950170-23-041297:mdna:15]
[same as prior period, unchanged from 0000950170-23-019634:mdna:11]

[0000950170-23-041297:mdna:16]
|  |  | Quarter Ended |  |  |  | Two Quarters Ended |  |  |
| End Markets (1) |  | July 3, 2023 |  |  |  | July 4, 2022 |  |  |  | July 3, 2023 |  |  |  | July 4, 2022 |  |  |
| Aerospace and Defense |  |  | 47 |  | % |  |  | 30 |  | % |  |  | 45 |  | % |  |  | 30 |  | % |
| Automotive |  |  | 17 |  |  |  |  | 18 |  |  |  |  | 17 |  |  |  |  | 19 |  |  |
| Data Center Computing |  |  | 12 |  |  |  |  | 17 |  |  |  |  | 11 |  |  |  |  | 16 |  |  |
| Medical/Industrial/Instrumentation |  |  | 16 |  |  |  |  | 21 |  |  |  |  | 17 |  |  |  |  | 21 |  |  |
| Networking |  |  | 8 |  |  |  |  | 14 |  |  |  |  | 10 |  |  |  |  | 14 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0000950170-23-041297:mdna:17]
[same as prior period, unchanged from 0000950170-23-019634:mdna:13]

[0000950170-23-041297:mdna:18]
[same as prior period, unchanged from 0000950170-23-019634:mdna:15]

[0000950170-23-041297:mdna:19]
[same as prior period, unchanged from 0000950170-23-019634:mdna:16]

[0000950170-23-041297:mdna:20]
[same as prior period, unchanged from 0000950170-23-019634:mdna:17]

[0000950170-23-041297:mdna:21]
[same as prior period, unchanged from 0000950170-23-019634:mdna:18]

[0000950170-23-041297:mdna:22]
[same as prior period, unchanged from 0000950170-23-019634:mdna:19]

[0000950170-23-041297:mdna:23]
[same as prior period, unchanged from 0000950170-23-019634:mdna:20]

[0000950170-23-041297:mdna:24]
[same as prior period, unchanged from 0000950170-23-019634:mdna:21]

[0000950170-23-041297:mdna:25]
[same as prior period, unchanged from 0000950170-23-019634:mdna:22]

[0000950170-23-041297:mdna:26]
Our consolidated condensed financial statements included in this report have been prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP). The preparation of these financial statements requires

[0000950170-23-041297:mdna:27]
management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0000950170-23-041297:mdna:28]
[same as prior period, unchanged from 0000950170-23-019634:mdna:24]

[0000950170-23-041297:mdna:29]
[same as prior period, unchanged from 0000950170-23-019634:mdna:25]

[0000950170-23-041297:mdna:30]
The following table sets forth the relationship of various items to net sales in our consolidated condensed statements of operations, for the periods indicated:

[0000950170-23-041297:mdna:31]
|  |  | Quarter Ended |  | Two Quarters Ended |
|  |  | July 3, 2023 |  |  |  | July 4, 2022 |  |  |  | July 3, 2023 |  |  |  | July 4, 2022 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 82.0 |  |  |  |  | 81.3 |  |  |  |  | 83.1 |  |  |  |  | 82.8 |  |  |
| Gross profit |  |  | 18.0 |  |  |  |  | 18.7 |  |  |  |  | 16.9 |  |  |  |  | 17.2 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.3 |  |  |  |  | 2.8 |  |  |  |  | 3.6 |  |  |  |  | 2.9 |  |  |
| General and administrative |  |  | 6.9 |  |  |  |  | 7.7 |  |  |  |  | 6.7 |  |  |  |  | 6.7 |  |  |
| Research and development |  |  | 1.2 |  |  |  |  | 0.9 |  |  |  |  | 1.2 |  |  |  |  | 0.9 |  |  |
| Amortization of definite-lived intangibles |  |  | 0.7 |  |  |  |  | 1.3 |  |  |  |  | 2.4 |  |  |  |  | 1.4 |  |  |
| Restructuring charges |  |  | 2.0 |  |  |  |  | 0.1 |  |  |  |  | 1.4 |  |  |  |  | 0.1 |  |  |
| Total operating expenses |  |  | 14.1 |  |  |  |  | 12.8 |  |  |  |  | 15.3 |  |  |  |  | 12.0 |  |  |
| Operating income |  |  | 3.9 |  |  |  |  | 5.9 |  |  |  |  | 1.6 |  |  |  |  | 5.2 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.2 | ) |  |  |  | (1.7 | ) |  |  |  | (2.2 | ) |  |  |  | (1.8 | ) |  |
| Loss on extinguishment of debt |  |  | (0.2 | ) |  |  |  | — |  |  |  |  | (0.1 | ) |  |  |  | — |  |  |
| (Loss) gain on sale of subsidiary |  |  | — |  |  |  |  | — |  |  |  |  | 0.1 |  |  |  |  | — |  |  |
| Other, net |  |  | 0.9 |  |  |  |  | 1.3 |  |  |  |  | 0.6 |  |  |  |  | 0.8 |  |  |
| Total other expense, net |  |  | (1.5 | ) |  |  |  | (0.4 | ) |  |  |  | (1.6 | ) |  |  |  | (1.0 | ) |  |
| Income before income taxes |  |  | 2.4 |  |  |  |  | 5.5 |  |  |  |  | — |  |  |  |  | 4.2 |  |  |
| Income tax (provision) benefit |  |  | (1.2 | ) |  |  |  | (1.1 | ) |  |  |  | 0.1 |  |  |  |  | (0.5 | ) |  |
| Net income |  |  | 1.2 |  | % |  |  | 4.4 |  | % |  |  | 0.1 |  | % |  |  | 3.7 |  | % |

[0000950170-23-041297:mdna:32]
The following discussion and analysis is for the quarter and the two quarters ended July 3, 2023, compared to the same periods ended July 4, 2022, unless otherwise stated.

[0000950170-23-041297:mdna:33]
[same as prior period, unchanged from 0000950170-23-019634:mdna:28]

[0000950170-23-041297:mdna:34]
Total net sales decreased $79.0 million, or 12.6%, to $546.5 million for the second quarter of 2023 from $625.6 million for the second quarter of 2022. The decrease in total net sales primarily resulted from a decrease in net sales for the PCB reportable segment of $72.9 million, or 12.0%, to $536.5 million for the second quarter of 2023 from $609.4 million for the second quarter of 2022. The primary driver of this decrease was demand weakness in our commercial end markets, partially offset by the inclusion of Telephonics as well as organic growth in our Aerospace and Defense end market. Net sales for the RF&S Components reportable segment decreased $6.1 million, or 38.1%, to $10.0 million for the second quarter of 2023 from $16.1 million for the second quarter of 2022, which was primarily due to lower demand in our Networking end market.

[0000950170-23-041297:mdna:35]
Total net sales decreased $115.9 million, or 9.6%, to $1,090.9 million for the first two quarters of 2023 from $1,206.8 million for the first two quarters of 2022. This decrease in total net sales primarily resulted from a decrease in net sales for the PCB reportable segment of $104.9 million, or 8.9%, to $1,070.6 million for the first two quarters of 2023 from $1,175.5 million for the first two quarters of 2022. The primary driver of this decrease was demand weakness in our commercial end markets, partially offset by the inclusion of Telephonics as well as organic growth in our Aerospace and Defense end market. Additionally, there was a decrease in net sales for the RF&S Components reportable segment of $11.0 million, or 35.2%, to $20.3 million for the first two quarters of 2023 from $31.3 million for the first two quarters of 2022 primarily due to lower demand in our Networking end market.

[0000950170-23-041297:mdna:36]
[same as prior period, unchanged from 0000950170-23-019634:mdna:30]

[0000950170-23-041297:mdna:37]
Overall gross margin decreased to 18.0% for the second quarter of 2023 from 18.7% for the second quarter of 2022. Gross margin for the PCB reportable segment decreased to 18.6% for the second quarter of 2023 from 19.6% for the second quarter of 2022. This decrease was primarily due to the revenue decline in the commercial sector, including lower premium revenue and prices, and production inefficiencies including supply chain challenges in the integrated electronics portion of our Aerospace and Defense end market partially offset by better product mix, the inclusion of Telephonics and favorable exchange rates. Gross margin for the RF&S

[0000950170-23-041297:mdna:38]
Components reportable segment decreased to 57.4% for the second quarter of 2023 from 60.2% for the second quarter of 2022, primarily due to lower sales.

[0000950170-23-041297:mdna:39]
Overall gross margin decreased to 16.9% for the first two quarters of 2023 from 17.2% for the first two quarters of 2022. Gross margin for the PCB reportable segment increased to 17.6% for the first two quarters of 2023 from 17.2% for the first two quarters of 2022. This increase was primarily due to the inclusion of Telephonics, better product mix and favorable exchange rates partially offset by lower revenue, lower premium revenue and pricing, and production inefficiencies. Gross margin for the RF&S Components reportable segment decreased to 53.5% for the first two quarters of 2023 from 60.3% for the first two quarters of 2022, primarily due to lower sales.

[0000950170-23-041297:mdna:40]
Capacity utilization is a key driver for us, which is measured by the actual production as a percentage of capacity. This measure is particularly important in our high-volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the second quarter of 2023 in our Asia and North America PCB facilities was 46% and 38%, respectively, compared to 81% and 44%, respectively, for the second quarter of 2022. Capacity utilization for the first two quarters of 2023 in our Asia and North America PCB facilities was 49% and 38%, respectively, compared to 79% and 47%, respectively, for the first two quarters of 2022. The decrease in capacity utilization in our Asia PCB facilities was caused by a decline in production volumes due to demand weakness in our commercial end markets while the decrease in our North America PCB facilities was due to the additional plating capacity added as well as a greater mix of higher technology product that requires less plating.

[0000950170-23-041297:mdna:41]
[same as prior period, unchanged from 0000950170-23-019634:mdna:33]

[0000950170-23-041297:mdna:42]
Selling and marketing expenses increased $0.6 million, to $18.2 million for the second quarter of 2023 from $17.6 million for the second quarter of 2022. As a percentage of net sales, selling and marketing expenses were 3.3% for the second quarter of 2023, as compared to 2.8% for the second quarter of 2022. The increase in selling and marketing expenses was primarily due to $2.1 million of selling and marketing expenses incurred by Telephonics post acquisition, partially offset by a $1.7 million decrease in commission expense.

[0000950170-23-041297:mdna:43]
Selling and marketing expenses increased $3.7 million, to $39.5 million for the first two quarters of 2023 from $35.8 million for the first two quarters of 2022. As a percentage of net sales, selling and marketing expenses were 3.6% for the first two quarters of 2023, as compared to 2.9% for the first two quarters of 2022. The increase in selling and marketing expenses for the first two quarters of 2023 was primarily due to $4.2 million of selling and marketing expenses incurred by Telephonics post acquisition and an increase in labor and travel costs, partially offset by a $2.0 million decrease in commission expense.

[0000950170-23-041297:mdna:44]
[same as prior period, unchanged from 0000950170-23-019634:mdna:35]

[0000950170-23-041297:mdna:45]
General and administrative expenses decreased $10.5 million to $37.8 million, or 6.9% of net sales, for the second quarter of 2023 from $48.4 million, or 7.7% of net sales, for the second quarter of 2022. The decrease in general and administrative expenses was primarily due to $10.4 million of reduced acquisition and integration costs mainly related to the acquisition of Telephonics on June 27, 2022. In addition, there was a decrease of $1.9 million in incentive compensation. These decreases were partially offset by $2.4 million of general and administrative expenses incurred by Telephonics post acquisition.

[0000950170-23-041297:mdna:46]
General and administrative expenses decreased $8.2 million to $72.9 million, or 6.7% of net sales, for the first two quarters of 2023 from $81.1 million, or 6.7% of net sales, for the first two quarters of 2022. The decrease in general and administrative expenses primarily resulted from $10.9 million of reduced acquisition and integration costs mainly related to the acquisition of Telephonics on June 27, 2022, partially offset by $3.6 million of general and administrative expenses incurred by Telephonics post acquisition.

[0000950170-23-041297:mdna:47]
[same as prior period, unchanged from 0000950170-23-019634:mdna:37]

[0000950170-23-041297:mdna:48]
Research and development expenses increased $1.2 million to $6.4 million, or 1.2% of net sales, for the second quarter of 2023 from $5.2 million, or 0.9% of net sales, for the second quarter of 2022. The increase in expense was primarily due to $1.9 million of research and development expense incurred by Telephonics post acquisition.

[0000950170-23-041297:mdna:49]
Research and development expenses increased $2.7 million to $13.5 million, or 1.2% of net sales, for the first two quarters of 2023 from $10.8 million, or 0.9% of net sales, for the first two quarters of 2022. The increase in expense was primarily due to $3.2 million of research and development expense incurred by Telephonics post acquisition.

[0000950170-23-041297:mdna:50]
Total Other Expense, Net

[0000950170-23-041297:mdna:51]
Total other expense, net increased $4.9 million to $8.0 million for the second quarter of 2023 from $3.1 million for the second quarter of 2022. This increase was primarily the result of a decrease in other income of $2.6 million mainly due to foreign currency losses resulting from the strengthening RMB in the second quarter of 2023 compared to the second quarter of 2022, a loss on extinguishment of debt of $1.2 million, and an increase in interest expense of $1.1 million due to higher interest rates. We utilize the RMB at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China.

[0000950170-23-041297:mdna:52]
Total other expense, net increased $5.8 million to $18.3 million for the first two quarters of 2023 from $12.5 million for the first two quarters of 2022. This increase was primarily the result of a decrease in other income of $3.3 million mainly due to foreign currency losses resulting from the strengthening RMB in the first two quarters of 2023 compared to the first two quarters of 2022, and an increase in interest expense of $2.6 million due to higher interest rates.

[0000950170-23-041297:mdna:53]
[same as prior period, unchanged from 0000950170-23-019634:mdna:41]

[0000950170-23-041297:mdna:54]
Income tax expense increased by $0.3 million to $6.6 million for the second quarter of 2023 from $6.3 million for the second quarter of 2022. The increase in income tax expense was primarily due to a change in the mix of U.S. and foreign pre-tax income partially offset by the release of uncertain tax positions due to the expiration of the statute of limitation in foreign jurisdictions.

[0000950170-23-041297:mdna:55]
Income tax expense decreased by $6.9 million to a $1.3 million tax benefit for the first two quarters of 2023 from $5.6 million of tax expense for the first two quarters of 2022. The decrease in income tax expense for the first two quarters of 2023 was primarily due to a decrease in pre-tax income for the first two quarters of 2023, the release of uncertain tax positions due to the expiration of the statute of limitation in foreign jurisdictions, and the absence in the first quarter of 2023 of the High and New Tax Enterprise status renewal benefits that existed in the first quarter of 2022.

[0000950170-23-041297:mdna:56]
Our effective tax rate is primarily impacted by the mix of foreign and U.S. income, tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax liability of approximately $54.4 million and $20.7 million as of July 3, 2023 and July 4, 2022, respectively. The increase in the deferred income tax liability was primarily due to the recording of a full valuation allowance for the U.S. in the last quarter of 2022.

[0000950170-23-041297:mdna:57]
[same as prior period, unchanged from 0000950170-23-019634:mdna:44]

[0000950170-23-041297:mdna:58]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our revolving credit facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, to repay debt obligations, and to repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and repurchasing common stock will be the principal demands on our cash in the future.

[0000950170-23-041297:mdna:59]
Cash flow provided by operating activities during the first two quarters of 2023 was $81.0 million as compared to cash flow provided by operating activities of $115.3 million in the same period in 2022. The decrease in cash flow was primarily due to the $44.0 million decrease in net income.

[0000950170-23-041297:mdna:60]
Net cash used in investing activities was approximately $12.3 million for the first two quarters of 2023, primarily reflecting the use of $80.5 million for purchases of property, plant and equipment and other assets, partially offset by the receipt of $61.8 million of proceeds from the sale of property associated with our Shanghai E-MS subsidiary and $6.0 million of proceeds from the sale of our Shanghai Backplane Assembly subsidiary, net of cash disposed. Net cash used in investing activities was approximately $349.0 million for the first two quarters of 2022, primarily reflecting the $299.2 million acquisition of Telephonics and $49.9 million for purchases of property, plant and equipment and other assets.

[0000950170-23-041297:mdna:61]
Net cash used in financing activities during the first two quarters of 2023 was $72.4 million, primarily reflecting repayment of long-term debt borrowings of $290.7 million, refund of customer deposits of $7.5 million, payment of debt issuance costs of $5.5 million and payment of original issue discount of $3.5 million, partially offset by the receipt of proceeds from long-term debt borrowing of $234.8 million. Net cash used in financing activities during the first two quarters of 2022 was $36.3 million, primarily reflecting repurchases of common stock of $35.4 million and cash used to settle warrants of $0.9 million.

[0000950170-23-041297:mdna:62]
As of July 3, 2023, we had cash and cash equivalents of approximately $398.7 million, of which approximately $232.5 million was held by our foreign subsidiaries, primarily in Hong Kong. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for the repatriation of this cash.

[0000950170-23-041297:mdna:63]
Our 2023 capital expenditures are expected to be in the range of $130.0 million to $150.0 million.

[0000950170-23-041297:mdna:64]
[same as prior period, unchanged from 0000950170-23-019634:mdna:51]

[0000950170-23-041297:mdna:65]
As of July 3, 2023, we had $867.9 million of outstanding debt, net of discount and debt issuance costs, composed of $495.6 million of Senior Notes due March 2029, $342.3 million of a Term Loan due May 2030, and $30.0 million under the Asia ABL.

[0000950170-23-041297:mdna:66]
Pursuant to the terms of the Term Loan Facility and Senior Notes due 2029, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments. Under the U.S. ABL and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of July 3, 2023, we were in compliance with the covenants under the Term Loan Facility, Senior Notes due 2029 and ABL Revolving Loans.

[0000950170-23-041297:mdna:67]
[same as prior period, unchanged from 0000950170-23-019634:mdna:54]

[0000950170-23-041297:mdna:68]
[same as prior period, unchanged from 0000950170-23-019634:mdna:55]

[0000950170-23-041297:mdna:69]
As part of our on-going operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, purchase obligations, and leases as of July 3, 2023. As of the date of this report, there were no material changes outside the ordinary course of business since January 2, 2023 to our contractual obligations and commitments and the related cash requirements, except for our interest on debt obligations. Our aggregate interest on debt obligations as of July 3, 2023 amounted to $312.9 million, which are expected to be settled as follows: $49.5 million within 1 year, $98.1 million within 1-3 years, $97.0 million within 4-5 years, and $68.3 million after 5 years. For debt obligations based on variable rates, interest rates used are as of July 3, 2023.

[0000950170-23-041297:mdna:70]
[same as prior period, unchanged from 0000950170-23-019634:mdna:57]

[0000950170-23-041297:mdna:71]
Following the acquisition of Telephonics on June 27, 2022, we have and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for our products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and our obligations under these agreements may be satisfied through activities that do not require us to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for such activities as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of July 3, 2023, we had outstanding offset agreements of approximately $20.2 million, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event we fail to perform in accordance with contract requirements. Historically, we have not paid any such penalties, and as of July 3, 2023, no such penalties have been paid.

[0000950170-23-041297:mdna:72]
[same as prior period, unchanged from 0000950170-23-019634:mdna:59]

[0000950170-23-041297:mdna:73]
[same as prior period, unchanged from 0000950170-23-019634:mdna:60]

[0000950170-23-041297:mdna:74]
Recently Issued Accounting Standards

[0000950170-23-041297:mdna:75]
[same as prior period, unchanged from 0000950170-23-019634:mdna:62]
