# TTMI notes — 0000950170-23-041297


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000950170-23-041297:notes:1]
[same as prior period, unchanged from 0000950170-23-019634:notes:1]

[0000950170-23-041297:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global manufacturer of technology solutions including mission systems, radio frequency (RF) components/RF microwave/microelectronic assemblies, quick-turn and technologically advanced printed circuit boards (PCB). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering, and manufacturing solution to customers. This one-stop design, engineering, and manufacturing solution allows the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0000950170-23-041297:notes:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation related products, and networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors and government agencies.

[0000950170-23-041297:notes:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the on-going effects of the coronavirus (COVID-19) and its variants on the Company and the conflict between Russia and Ukraine, the global economy and financial markets have been volatile. In addition, both COVID-19 and the conflict in Ukraine have contributed to on-going disruptions in global supply chains, labor shortages, high inflation, and a potential recession, and there is a significant amount of uncertainty about the length and severity of the direct and indirect effects of COVID-19 variants and the conflict. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

[0000950170-23-041297:notes:5]
[same as prior period, unchanged from 0000950170-23-019634:notes:5]

[0000950170-23-041297:notes:6]
Recently Adopted Accounting Standards

[0000950170-23-041297:notes:7]
In September 2022, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. The Company adopted ASU 2022-04 as of April 3, 2023. The Company has agreements with financial institutions to facilitate the payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days, with a weighted average of 260 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $8,206 and $6,653 as of July 3, 2023 and January 2, 2023, respectively.

[0000950170-23-041297:notes:8]
In December 2022, the FASB issued ASU 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which deferred the sunset date of Topic 848 to December 31, 2024, after which entities will no longer be permitted to apply the optional expedients and exceptions in Topic 848. On March 23, 2023, the Company entered into a four-year pay-fixed, receive floating (1-month CME Term Secured Overnight Financing Rate (SOFR)), interest rate swap arrangement with a notional amount of $250,000 for the period beginning April 1, 2023 and ending on April 1, 2027. Under the terms of the interest rate swap, the Company pays a fixed rate of 3.49% against a portion of its Term SOFR-based debt and receives a floating 1-month CME Term SOFR during the swap period. The Company elected optional expedients provided in Topic 848 which allow the designation of the interest rate swap as a cash flow hedge.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-041297:notes:9]
[same as prior period, unchanged from 0000950170-23-019634:notes:9]

[0000950170-23-041297:notes:10]
On June 27, 2022, the Company completed its acquisition of all of the issued and outstanding capital stock of Gritel Holding Co., Inc. (Gritel) and ISC Farmingdale Corp. for a total consideration of $298,339 in cash. At the time of acquisition, Telephonics Corporation was wholly-owned by Gritel, and as a result of the acquisition, became an indirect, wholly-owned subsidiary of the Company (collectively with ISC Farmingdale Corp., Telephonics).

[0000950170-23-041297:notes:11]
For the quarter and two quarters ended July 3, 2023, legal, accounting, and other professional service costs associated with the acquisition of $97 and $508, respectively, have been expensed and recorded as general and administrative expense in the consolidated condensed statements of operations. For the quarter and two quarters ended July 4, 2022, bank fees and legal, accounting, and other professional service costs associated with the acquisition of $9,854 and $10,708, respectively, were expensed and recorded as general and administrative expense in the consolidated condensed statements of operations.

[0000950170-23-041297:notes:12]
Purchase Price Allocation

[0000950170-23-041297:notes:13]
The purchase price was allocated to tangible and intangible assets acquired, and liabilities assumed based on the fair value at the date of the acquisition, June 27, 2022. The excess of the purchase price over the fair value of net assets acquired was allocated to goodwill. The fair values were based on management’s analysis, including work performed by third-party valuation specialists. As of July 3, 2023, the Company has finalized the allocation of the purchase price.

[0000950170-23-041297:notes:14]
The fair values assigned are based on reasonable methods applicable to the nature of the assets acquired and liabilities assumed. The following summarizes the final estimated fair values of net assets acquired:

[0000950170-23-041297:notes:15]
|  |  | (In thousands) |  |  |
| Accounts receivable |  | $ | 51,140 |  |  |
| Contract assets |  |  | 26,460 |  |  |
| Inventories |  |  | 38,616 |  |  |
| Prepaid expenses and other current assets |  |  | 5,605 |  |  |
| Property, plant and equipment |  |  | 69,253 |  |  |
| Operating lease right-of-use assets |  |  | 497 |  |  |
| Goodwill |  |  | 112,326 |  |  |
| Identifiable intangible assets |  |  | 101,000 |  |  |
| Non-current deferred tax assets |  |  | 913 |  |  |
| Deposits and other non-current assets |  |  | 3,129 |  |  |
| Accounts payable |  |  | (16,026 | ) |  |
| Contract liabilities |  |  | (65,262 | ) |  |
| Accrued salaries, wages and benefits |  |  | (10,616 | ) |  |
| Other current liabilities |  |  | (12,751 | ) |  |
| Operating lease liabilities |  |  | (336 | ) |  |
| Other long-term liabilities |  |  | (5,609 | ) |  |
| Total |  | $ | 298,339 |  |  |

[0000950170-23-041297:notes:16]
Identifiable Intangible Assets

[0000950170-23-041297:notes:17]
Acquired identifiable intangible assets include customer relationships, technology, backlog, and trade names. The fair value of the identifiable intangible assets was determined using various valuation methods including relief from royalty and excess earnings to determine the present value of expected future cash flows for each identifiable intangible asset based on discount rates. The expected cash flows were estimated using available historical data adjusted based on a market participant perspective. The Company used risk adjusted discount rates between 7.0% and 8.0% to discount the expected future cash flows. The fair value assigned to each class of intangible assets and the related weighted average amortization periods are as follows:

[0000950170-23-041297:notes:18]
|  |  | Estimated Fair Value |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) | (In years) |  |
| Customer relationships |  | $ | 56,000 |  |  |  | 10.0 |  |
| Technology |  |  | 29,500 |  |  |  | 5.0 |  |
| Backlog |  |  | 13,000 |  |  |  | 2.0 |  |
| Trade names |  |  | 2,500 |  |  |  | 2.0 |  |
|  |  | $ | 101,000 |  |  |  |  |

[0000950170-23-041297:notes:19]
In connection with the finalization of the acquired identifiable intangible asset valuation, the Company adjusted the amortization period of the intangible assets. As a result, the Company recorded a net reduction in amortization expense of $2,862 during the quarter ended July 3, 2023, which includes $4,813 of amortization expense and a reduction in amortization expense of $5,117 and $2,558 due to the change in amortization period, which corresponded to the year ended January 2, 2023 and quarter ended April 3, 2023, respectively. The Company recorded amortization expense of $15,252 related to the acquired identifiable intangible assets during the two quarters ended July 3, 2023 (of which $5,627 corresponded to the year ended January 2, 2023 due to the change in amortization period). For the quarter and two quarters ended July 3, 2023, $1,475 and $5,900 of amortization expense is included in cost of goods sold, respectively (of which $2,950 corresponded to the year ended January 2, 2023).

[0000950170-23-041297:notes:20]
[same as prior period, unchanged from 0000950170-23-019634:notes:17]

[0000950170-23-041297:notes:21]
Goodwill represents the excess of the purchase price over the fair value of assets acquired and liabilities assumed. During the quarter ended July 3, 2023, the Company increased goodwill by $563 due to an adjustment to the estimate of fair value for deferred taxes. The Company believes that the acquisition of Telephonics will strengthen the Company’s differentiated position in the Aerospace and Defense market. The Company believes that these factors support the amount of goodwill recognized as a result of the purchase price paid for Telephonics, in relation to other acquired tangible and intangible assets. The goodwill acquired in the acquisition is not deductible for income tax purposes.

[0000950170-23-041297:notes:22]
[same as prior period, unchanged from 0000950170-23-019634:notes:19]

[0000950170-23-041297:notes:23]
Included in the consolidated condensed statements of operations are net sales of $53,327 and $101,966, excluding intercompany sales, for the quarter and two quarters ended July 3, 2023, respectively. Included in the consolidated condensed statements of operations are pre-tax income of $4,414 and $11,199, excluding amortization of intangibles, for the quarter and two quarters ended July 3, 2023, respectively. The results of operations of Telephonics for the quarter and two quarters ended July 4, 2022 are not material to the Company’s consolidated condensed statements of operations.

[0000950170-23-041297:notes:24]
Pro forma Financial Information

[0000950170-23-041297:notes:25]
The unaudited pro forma financial information below gives effect to this acquisition as if it had occurred at the beginning of fiscal 2022, or January 4, 2022. The pro forma financial information presented includes the effects of adjustments related to the amortization of acquired identifiable intangible assets, decrease in inventory markup, depreciation of acquired fixed assets, and other non-recurring transactions costs directly associated with the acquisition such as legal, accounting and banking fees.

[0000950170-23-041297:notes:26]
The pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the actual results that would have been achieved had the acquisition occurred at the beginning of the earliest period presented, or the results that may be achieved in future periods.

[0000950170-23-041297:notes:27]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 3, 2023 |  |  | July 4, 2022 |  |  | July 3, 2023 |  |  | July 4, 2022 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net sales |  | $ | 546,509 |  |  | $ | 676,344 |  |  | $ | 1,090,946 |  |  | $ | 1,313,878 |  |
| Net income |  |  | 1,597 |  |  |  | 33,744 |  |  |  | 1,849 |  |  |  | 47,318 |  |
| Basic earnings per share |  | $ | 0.02 |  |  | $ | 0.33 |  |  | $ | 0.02 |  |  | $ | 0.46 |  |
| Diluted earnings per share |  | $ | 0.02 |  |  | $ | 0.33 |  |  | $ | 0.02 |  |  | $ | 0.46 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000950170-23-041297:notes:28]
[same as prior period, unchanged from 0000950170-23-019634:notes:25]

[0000950170-23-041297:notes:29]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases and finance leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the right-of-use (ROU) asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-23-041297:notes:30]
[same as prior period, unchanged from 0000950170-23-019634:notes:27]

[0000950170-23-041297:notes:31]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 3, 2023 |  |  | July 4, 2022 |  |  | July 3, 2023 |  |  | July 4, 2022 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 1,762 |  |  | $ | 1,792 |  |  | $ | 3,808 |  |  | $ | 3,676 |  |
| Variable lease cost |  |  | 217 |  |  |  | 208 |  |  |  | 495 |  |  |  | 454 |  |
| Short-term lease cost |  |  | 158 |  |  |  | 174 |  |  |  | 275 |  |  |  | 314 |  |
| Finance lease costs: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  | 343 |  |  |  | 344 |  |  |  | 687 |  |  |  | 687 |  |
| Interest on lease liabilities |  |  | 93 |  |  |  | 99 |  |  |  | 187 |  |  |  | 197 |  |

[0000950170-23-041297:notes:32]
[same as prior period, unchanged from 0000950170-23-019634:notes:29]

[0000950170-23-041297:notes:33]
|  |  | Two Quarters Ended |  |
|  |  | July 3, 2023 |  |  | July 4, 2022 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |
| Operating cash flows for operating leases |  | $ | 3,827 |  |  | $ | 3,654 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |
| Operating leases |  |  | 728 |  |  |  | 5,368 |  |

[0000950170-23-041297:notes:34]
[same as prior period, unchanged from 0000950170-23-019634:notes:31]

[0000950170-23-041297:notes:35]
|  |  |  |  | As of |  |
|  |  | Balance Sheet Location |  | July 3, 2023 |  |  | January 2, 2023 |  |
|  |  |  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease right-of-use assets |  | $ | 14,041 |  |  | $ | 18,862 |  |
| Finance leases |  | Property, plant and equipment, net |  |  | 12,697 |  |  |  | 13,384 |  |
| Total lease assets |  |  |  | $ | 26,738 |  |  | $ | 32,246 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 5,942 |  |  | $ | 7,368 |  |
| Finance leases |  | Other current liabilities |  |  | 769 |  |  |  | 736 |  |
| Long-term: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease liabilities |  |  | 8,804 |  |  |  | 12,249 |  |
| Finance leases |  | Other long-term liabilities |  |  | 13,189 |  |  |  | 13,579 |  |
| Total lease liabilities |  |  |  | $ | 28,704 |  |  | $ | 33,932 |  |

[0000950170-23-041297:notes:36]
|  |  | As of |  |
|  |  | July 3, 2023 |  |  | January 2, 2023 |  |
| Weighted average remaining lease term (years): |  |  |  |  |  |  |
| Operating leases |  | 3.1 |  |  | 3.3 |  |
| Finance leases |  | 13.1 |  |  | 13.6 |  |
| Weighted average discount rate: |  |  |  |  |  |  |
| Operating leases |  |  | 3.34 | % |  |  | 3.09 | % |
| Finance leases |  |  | 2.69 | % |  |  | 2.69 | % |

[0000950170-23-041297:notes:37]
[same as prior period, unchanged from 0000950170-23-019634:notes:34]

[0000950170-23-041297:notes:38]
|  |  | OperatingLeases (1) |  |  | FinanceLeases |  |
|  |  | (In thousands) |  |
| Less than one year |  | $ | 6,303 |  |  | $ | 1,133 |  |
| 1 - 2 years |  |  | 5,148 |  |  |  | 1,127 |  |
| 2 - 3 years |  |  | 2,290 |  |  |  | 1,171 |  |
| 3 - 4 years |  |  | 870 |  |  |  | 1,175 |  |
| 4 - 5 years |  |  | 399 |  |  |  | 1,223 |  |
| Thereafter |  |  | 588 |  |  |  | 10,846 |  |
| Total lease payments |  |  | 15,598 |  |  |  | 16,675 |  |
| Less imputed interest |  |  | (852 | ) |  |  | (2,717 | ) |
| Total |  | $ | 14,746 |  |  | $ | 13,958 |  |

[0000950170-23-041297:notes:39]
(1)
Excludes $2,074 of legally binding minimum lease payments for leases signed but not yet commenced.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-23-041297:notes:40]
[same as prior period, unchanged from 0000950170-23-019634:notes:37]

[0000950170-23-041297:notes:41]
As of July 3, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $376,291. The Company expects to recognize revenue on approximately 50% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount expected to be recognized thereafter.

[0000950170-23-041297:notes:42]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of July 3, 2023 and January 2, 2023 were $19,971 and $21,632, respectively.

[0000950170-23-041297:notes:43]
Revenue recognized for the two quarters ended July 3, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $27,069.

[0000950170-23-041297:notes:44]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for the quarter and two quarters ended July 3, 2023, and 97% and 3%, respectively, of the Company’s revenue for the quarter and two quarters ended July 4, 2022.

[0000950170-23-041297:notes:45]
[same as prior period, unchanged from 0000950170-23-019634:notes:42]

[0000950170-23-041297:notes:46]
|  |  | Quarter Ended July 3, 2023 |  |  | Quarter Ended July 4, 2022 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
| End Markets |  | (In thousands) |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 254,284 |  |  | $ | — |  |  | $ | 254,284 |  |  | $ | 189,676 |  |  | $ | — |  |  | $ | 189,676 |  |
| Automotive |  |  | 92,374 |  |  |  | — |  |  |  | 92,374 |  |  |  | 111,778 |  |  |  | — |  |  |  | 111,778 |  |
| Data Center Computing |  |  | 64,305 |  |  |  | 51 |  |  |  | 64,356 |  |  |  | 106,188 |  |  |  | 20 |  |  |  | 106,208 |  |
| Medical/Industrial/Instrumentation |  |  | 88,979 |  |  |  | 745 |  |  |  | 89,724 |  |  |  | 131,061 |  |  |  | 2,246 |  |  |  | 133,307 |  |
| Networking |  |  | 36,589 |  |  |  | 9,182 |  |  |  | 45,771 |  |  |  | 69,766 |  |  |  | 15,109 |  |  |  | 84,875 |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 960 |  |  |  | (1,254 | ) |  |  | (294 | ) |
| Total |  | $ | 536,531 |  |  | $ | 9,978 |  |  | $ | 546,509 |  |  | $ | 609,429 |  |  | $ | 16,121 |  |  | $ | 625,550 |  |

[0000950170-23-041297:notes:47]
|  |  | Two Quarters Ended July 3, 2023 |  |  | Two Quarters Ended July 4, 2022 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 486,576 |  |  | $ | — |  |  | $ | 486,576 |  |  | $ | 361,856 |  |  | $ | — |  |  |  | $ | 361,856 |  |  |
| Automotive |  |  | 185,841 |  |  |  | — |  |  |  | 185,841 |  |  |  | 227,014 |  |  |  | — |  |  |  |  | 227,014 |  |  |
| Data Center Computing |  |  | 122,175 |  |  |  | 51 |  |  |  | 122,226 |  |  |  | 197,972 |  |  |  | 20 |  |  |  |  | 197,992 |  |  |
| Medical/Industrial/Instrumentation |  |  | 189,747 |  |  |  | 1,662 |  |  |  | 191,409 |  |  |  | 251,423 |  |  |  | 3,784 |  |  |  |  | 255,207 |  |  |
| Networking |  |  | 86,303 |  |  |  | 18,591 |  |  |  | 104,894 |  |  |  | 133,409 |  |  |  | 28,866 |  |  |  |  | 162,275 |  |  |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,825 |  |  |  | (1,359 | ) |  |  |  | 2,466 |  |  |
| Total |  | $ | 1,070,642 |  |  | $ | 20,304 |  |  | $ | 1,090,946 |  |  | $ | 1,175,499 |  |  | $ | 31,311 |  |  |  | $ | 1,206,810 |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000950170-23-041297:notes:48]
[same as prior period, unchanged from 0000950170-23-019634:notes:45]

[0000950170-23-041297:notes:49]
|  |  | As of |  |
|  |  | July 3, 2023 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 148,707 |  |  | $ | 145,561 |  |
| Work-in-process |  |  | 33,506 |  |  |  | 20,114 |  |
| Finished goods |  |  | 4,552 |  |  |  | 4,964 |  |
|  |  | $ | 186,765 |  |  | $ | 170,639 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 76,811 |  |  | $ | 76,811 |  |
| Buildings and improvements |  |  | 445,969 |  |  |  | 443,353 |  |
| Machinery and equipment |  |  | 996,939 |  |  |  | 989,935 |  |
| Furniture and fixtures and other |  |  | 11,089 |  |  |  | 11,327 |  |
| Construction-in-progress |  |  | 32,891 |  |  |  | 27,774 |  |
|  |  |  | 1,563,699 |  |  |  | 1,549,200 |  |
| Less: Accumulated depreciation |  |  | (854,122 | ) |  |  | (824,996 | ) |
|  |  | $ | 709,577 |  |  | $ | 724,204 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Restructuring |  | $ | 13,249 |  |  | $ | 2,513 |  |
| Sales return and allowances |  |  | 10,659 |  |  |  | 12,319 |  |
| Accrued facility operating costs |  |  | 9,371 |  |  |  | 9,081 |  |
| Housing fund |  |  | 7,309 |  |  |  | 7,440 |  |
| Interest |  |  | 6,846 |  |  |  | 9,336 |  |
| Warranty |  |  | 5,960 |  |  |  | 8,045 |  |
| Operating leases |  |  | 5,942 |  |  |  | 7,368 |  |
| Income taxes payable |  |  | 4,302 |  |  |  | 28,057 |  |
| Accrued professional fees |  |  | 3,232 |  |  |  | 5,123 |  |
| Derivative liabilities |  |  | 783 |  |  |  | 1,622 |  |
| Other |  |  | 35,590 |  |  |  | 39,128 |  |
|  |  | $ | 103,243 |  |  | $ | 130,032 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 54,470 |  |  | $ | 54,268 |  |
| Customer deposits |  |  | 31,250 |  |  |  | 38,750 |  |
| Finance leases |  |  | 13,189 |  |  |  | 13,579 |  |
| Defined benefit pension plan liability |  |  | 2,474 |  |  |  | 2,471 |  |
| Other |  |  | 27,198 |  |  |  | 25,976 |  |
|  |  | $ | 128,581 |  |  | $ | 135,044 |  |

[0000950170-23-041297:notes:50]
On December 22, 2022, land, building, and relevant ancillary assets related to the Company’s former Shanghai E-MS (SH E-MS) manufacturing facility were expropriated by the Chinese government for a compensation fee of Renminbi (RMB) 477.6 million generating a gain on the sale of $51,804. The Company received 90% of the proceeds as of July 3, 2023 and expects to receive the remaining 10% of the proceeds before December 30, 2023. As of July 3, 2023 and January 2, 2023, the receivable from sale of SH E-MS property was $6,595 and $69,240, respectively.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-23-041297:notes:51]
[same as prior period, unchanged from 0000950170-23-019634:notes:48]

[0000950170-23-041297:notes:52]
As of July 3, 2023 and January 2, 2023, goodwill by reportable segment was as follows:

[0000950170-23-041297:notes:53]
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 2, 2023 |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 823,837 |  |  | $ | 177,200 |  |  | $ | 1,001,037 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | (69,200 | ) |  |  | (240,600 | ) |
|  |  |  | 652,437 |  |  |  | 108,000 |  |  |  | 760,437 |  |
| Goodwill adjustment during the two quarters ended July 3, 2023 |  |  | (10,787 | ) |  |  | — |  |  |  | (10,787 | ) |
| Derecognition of goodwill due to sale of subsidiary |  |  | (2,815 | ) |  |  | — |  |  |  | (2,815 | ) |
| Balance as of July 3, 2023 |  |  |  |  |  |  |  |  |  |
| Goodwill |  |  | 810,235 |  |  |  | 177,200 |  |  |  | 987,435 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | (69,200 | ) |  |  | (240,600 | ) |
|  |  | $ | 638,835 |  |  | $ | 108,000 |  |  | $ | 746,835 |  |

[0000950170-23-041297:notes:54]
During the two quarters ended July 3, 2023, the Company decreased goodwill by $10,787 due to an adjustment to the estimate of fair value for identifiable intangible assets and deferred taxes. Goodwill recognized as a result of the acquisition of Telephonics is finalized as of July 3, 2023. See Note 2, Acquisition of Gritel and ISC Farmingdale Corp., for further information.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-23-041297:notes:55]
[same as prior period, unchanged from 0000950170-23-019634:notes:52]

[0000950170-23-041297:notes:56]
As of July 3, 2023 and January 2, 2023, the components of definite-lived intangibles were as follows:

[0000950170-23-041297:notes:57]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| July 3, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 416,230 |  |  | $ | (203,782 | ) |  | $ | 212,448 |  |  |  | 11.2 |  |
| Technology |  |  | 66,650 |  |  |  | (22,608 | ) |  |  | 44,042 |  |  |  | 8.2 |  |
| Backlog |  |  | 13,000 |  |  |  | (6,500 | ) |  |  | 6,500 |  |  |  | 2.0 |  |
| Trade names |  |  | 2,500 |  |  |  | (1,250 | ) |  |  | 1,250 |  |  |  | 2.0 |  |
|  |  | $ | 498,380 |  |  | $ | (234,140 | ) |  | $ | 264,240 |  |  |  |  |
| January 2, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 366,071 |  |  | $ | (187,560 | ) |  | $ | 178,511 |  |  |  | 11.3 |  |
| Technology |  |  | 47,650 |  |  |  | (24,876 | ) |  |  | 22,774 |  |  |  | 9.5 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 82,500 |  |  |  | (3,173 | ) |  |  | 79,327 |  |  |  | 13.0 |  |
| Trade names |  |  | 8,250 |  |  |  | (825 | ) |  |  | 7,425 |  |  |  | 5.0 |  |
|  |  | $ | 504,471 |  |  | $ | (216,434 | ) |  | $ | 288,037 |  |  |  |  |

[0000950170-23-041297:notes:58]
[same as prior period, unchanged from 0000950170-23-019634:notes:55]

[0000950170-23-041297:notes:59]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $6,275 and $9,658 for the quarters ended July 3, 2023 and July 4, 2022, respectively, and $34,047 and $19,316 for the two quarters ended July 3, 2023 and July 4, 2022, respectively. For the quarter and two quarters ended July 3, 2023, $2,423 and $8,231, respectively, of amortization expense is included in cost of goods sold. For the quarter and two quarters ended July 4, 2022, $1,383 and $2,767, respectively, of amortization expense is included in cost of goods sold.

[0000950170-23-041297:notes:60]
[same as prior period, unchanged from 0000950170-23-019634:notes:57]

[0000950170-23-041297:notes:61]
|  |  | (In thousands) |  |
| Remaining 2023 |  | $ | 27,530 |  |
| 2024 |  |  | 44,892 |  |
| 2025 |  |  | 36,897 |  |
| 2026 |  |  | 36,897 |  |
| 2027 |  |  | 34,543 |  |
| Thereafter |  |  | 83,481 |  |
|  |  | $ | 264,240 |  |


## us-gaap:LongTermDebtTextBlock

[0000950170-23-041297:notes:62]
(8) Long-term Debt and Letters of Credit

[0000950170-23-041297:notes:63]
The following table summarizes the long-term debt of the Company as of July 3, 2023 and January 2, 2023:

[0000950170-23-041297:notes:64]
|  |  | Interest Rate as ofJuly 3, 2023 |  |  |  | PrincipalOutstandingas ofJuly 3, 2023 |  |  | Interest Rate as ofJanuary 2, 2023 |  |  |  | PrincipalOutstandingas ofJanuary 2, 2023 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 7.89 |  |  |  |  | 350,000 |  |  |  | — |  |  |  |  | — |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.44 |  |  |  |  | 30,000 |  |  |  | 5.79 |  |  |  |  | 30,000 |  |
| Term Loan due September 2024 |  |  | — |  |  |  |  | — |  |  |  | 6.89 |  |  |  |  | 405,879 |  |
|  |  |  |  |  |  |  | 880,000 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,616 | ) |  |  |  |  |  |  | (6,080 | ) |
| Long-term debt unamortized discount |  |  |  |  |  |  | (3,471 | ) |  |  |  |  |  |  | (392 | ) |
|  |  |  |  |  |  |  | 867,913 |  |  |  |  |  |  |  | 929,407 |  |
| Less: current maturities |  |  |  |  |  |  | (3,500 | ) |  |  |  |  |  |  | (50,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 864,413 |  |  |  |  |  |  | $ | 879,407 |  |

[0000950170-23-041297:notes:65]
Term Loan Facility

[0000950170-23-041297:notes:66]
On May 30, 2023, pursuant to an Amended & Restated Term Loan Credit Agreement by and among the Company, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto (Term Loan Credit Agreement), the Company closed its $350,000 senior secured Term Loan due 2030 (Term Loan Facility), of which $3,500 is included in short-term debt and $346,500 is included in long-term debt. The Term Loan Facility was issued with a 1.0% original issue discount and bears interest at a floating rate of 1-month CME Term SOFR plus an applicable margin of 2.75%. There is no provision, other than an event of default, for the interest margin to increase. The Company is required to make quarterly principal repayments in an aggregate annual amount equal to 1% of the initial aggregate principal amount of the Term Loan Facility beginning October 1, 2023. Such principal repayment is payable quarterly on January 1, April 1, July 1, and October 1 and ending with the last such day to occur prior to May 30, 2030. The remaining principal under the Term Loan Facility is scheduled to mature on May 30, 2030. In addition, the Term Loan Credit Agreement will permit the Company to add one or more senior secured incremental term loan facilities to the Term Loan Facility subject to the satisfaction of certain conditions.

[0000950170-23-041297:notes:67]
The Company used $234,818 under the Term Loan Facility and $115,182 of cashless rollover from continuing lenders, together with cash on hand, to refinance the full amount of indebtedness outstanding under the Company’s previous Term Loan Facility that was due to mature in 2024, as well as to pay related fees and expenses.

[0000950170-23-041297:notes:68]
The obligations under the Term Loan Facility are unconditionally guaranteed by each Subsidiary Guarantor of the Company, subject to certain exceptions (Guarantors). The Term Loan Facility is secured by (i) a perfected first priority security interest in substantially all of the assets of the Company and the Guarantors (other than the U.S. ABL Priority Collateral (as defined below)), including all of the total outstanding voting capital stock held by the Company and the Guarantors (subject to a limitation of 65% on pledges of such capital stock of certain foreign subsidiaries and domestic holding companies of foreign subsidiaries) and (ii) a perfected second priority interest in all of the U.S. ABL Priority Collateral. The Term Loan Facility is structurally senior to the Company’s Senior Notes due 2029.

[0000950170-23-041297:notes:69]
Asset-Based Lending Agreements

[0000950170-23-041297:notes:70]
The Company amended and restated its U.S. Asset-Based Lending Credit Agreement (U.S. ABL) on May 30, 2023 and its Asia Asset-Based Lending Credit Agreement (Asia ABL) on June 14, 2023. Both agreements were amended for the benchmark interest rate and margins and maturity was extended to May 2028 and June 2028 for the U.S. ABL and the Asia ABL, respectively.

[0000950170-23-041297:notes:71]
The U.S. ABL is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $50,000, provided that at no time may amounts outstanding under the agreement exceed in the aggregate $150,000 or the applicable borrowing base, which is the sum of (i) a percentage of the principal amount of “Eligible Accounts”, plus (ii) a percentage of the net orderly liquidation value of (x) “Eligible Inventory”, minus (y) “Inventory Reserves” applicable thereto, minus (iii) “Reserves”, each as defined in the U.S. ABL agreement.

[0000950170-23-041297:notes:72]
Borrowings under the U.S. ABL bear interest at a floating rate of Term SOFR plus a margin ranging from 1.25% to 1.50%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for Term SOFR-based loans and from 25 to 50 basis points for JPMorgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The Company is also required to pay certain fees in connection with the U.S. ABL agreement, including unused commitment fees based on the average daily unused portion of the U.S. ABL facility, equal to 0.25% on an annual basis.

[0000950170-23-041297:notes:73]
The U.S. ABL is scheduled to mature on May 30, 2028. The Guarantors have also fully guaranteed the full and timely payment of all obligations in respect of the U.S. ABL. Loans made under the U.S. ABL are secured by a perfected first priority security interest in certain deposit accounts, cash and cash equivalents, accounts receivable and certain U.S. inventory (U.S. ABL Priority Collateral) as well as by a perfected second priority interest in all of the collateral securing the Term Loan Facility.

[0000950170-23-041297:notes:74]
The Asia ABL is comprised of a revolving credit facility for up to $150,000 and a sublimit for letter of credit for up to $100,000, provided that at no time may amounts outstanding under the agreement exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement.

[0000950170-23-041297:notes:75]
Borrowings under the Asia ABL bear interest at a floating rate of Term SOFR plus 130 basis points. There is no provision, other than an event of default, for the interest margin to increase. The Company is also required to pay certain fees in connection with the Asia ABL agreement, including unused commitment fees based on the average daily unused portion of the Asia ABL facility, equal to 0.25% on an annual basis.

[0000950170-23-041297:notes:76]
The Asia ABL is scheduled to mature on June 13, 2028. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes due 2029.

[0000950170-23-041297:notes:77]
As of July 3, 2023, letters of credit in the amount of $6,191 were outstanding under the U.S. ABL and $14,039 were outstanding under the Asia ABL with various maturities through September 2024. Available borrowing capacity under the U.S. ABL and the Asia ABL was $143,809 and $105,961, respectively, which considers letters of credit outstanding as of July 3, 2023.

[0000950170-23-041297:notes:78]
Debt Covenants

[0000950170-23-041297:notes:79]
Borrowings under the Senior Notes due 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

[0000950170-23-041297:notes:80]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0000950170-23-041297:notes:81]
Debt Issuance and Debt Discount

[0000950170-23-041297:notes:82]
As of July 3, 2023 and January 2, 2023, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

[0000950170-23-041297:notes:83]
|  |  | As of July 3, 2023 |  |  |  | As of January 2, 2023 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,435 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,779 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 4,181 |  |  |  | 3,471 |  |  |  | 8.25 |  |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | 1,301 |  |  |  | 392 |  |  |  | 4.66 |  |  |
|  |  | $ | 8,616 |  |  | $ | 3,471 |  |  |  |  |  |  | $ | 6,080 |  |  | $ | 392 |  |  |  |  |  |

[0000950170-23-041297:notes:84]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0000950170-23-041297:notes:85]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,786 and $792 as of July 3, 2023 and January 2, 2023, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0000950170-23-041297:notes:86]
As of July 3, 2023, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 6.3 years.

[0000950170-23-041297:notes:87]
Loss on Extinguishment of Debt

[0000950170-23-041297:notes:88]
During the quarter ended July 3, 2023, the Company recognized loss on extinguishment of debt of $1,154, primarily associated with the write-off of the remaining unamortized debt issuance and debt discount as a result of the repayment of the remaining outstanding balance of the Term Loan Facility that was due to mature September 2024.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-041297:notes:89]
[same as prior period, unchanged from 0000950170-23-019634:notes:71]

[0000950170-23-041297:notes:90]
[same as prior period, unchanged from 0000950170-23-019634:notes:72]

[0000950170-23-041297:notes:91]
During the quarter and two quarters ended July 3, 2023, the Company’s effective tax rate was impacted by a net discrete benefit of $1,079. This is primarily related to the release of uncertain tax positions due to the expiration of the statute of limitations in certain foreign jurisdictions.

[0000950170-23-041297:notes:92]
The Company has various foreign subsidiaries formed or acquired to conduct or support its business outside the U.S. The Company expects its earnings attributable to most foreign subsidiaries may be repatriated back to the U.S. and so a deferred tax liability has been recorded for foreign withholding taxes and the estimated federal/state tax impact on any repatriation. For those other companies with earnings currently being reinvested outside of the U.S., no deferred tax liability on undistributed earnings has been recorded.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-041297:notes:93]
[same as prior period, unchanged from 0000950170-23-019634:notes:76]

[0000950170-23-041297:notes:94]
[same as prior period, unchanged from 0000950170-23-019634:notes:77]

[0000950170-23-041297:notes:95]
[same as prior period, unchanged from 0000950170-23-019634:notes:78]

[0000950170-23-041297:notes:96]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |  |
|  |  | July 3, 2023 |  |  | July 4, 2022 |  |  | July 3, 2023 |  |  | July 4, 2022 |  |  |
|  |  | (In thousands) |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 536,531 |  |  | $ | 609,429 |  |  | $ | 1,070,642 |  |  | $ | 1,175,499 |  |  |
| RF&S Components |  |  | 9,978 |  |  |  | 16,121 |  |  |  | 20,304 |  |  |  | 31,311 |  |  |
| Total net sales |  | $ | 546,509 |  |  | $ | 625,550 |  |  | $ | 1,090,946 |  |  | $ | 1,206,810 |  |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 58,479 |  |  | $ | 91,908 |  |  | $ | 110,113 |  |  | $ | 148,448 |  |  |
| RF&S Components |  |  | 3,202 |  |  |  | 6,678 |  |  |  | 5,370 |  |  |  | 12,428 |  |  |
| Corporate and Other |  |  | (33,998 | ) |  |  | (51,726 | ) |  |  | (63,496 | ) |  |  | (78,490 | ) |  |
| Total operating segment income |  |  | 27,683 |  |  |  | 46,860 |  |  |  | 51,987 |  |  |  | 82,386 |  |  |
| Amortization of definite-lived intangibles (1) |  |  | (6,275 | ) |  |  | (9,658 | ) |  |  | (34,047 | ) |  |  | (19,316 | ) |  |
| Total operating income |  |  | 21,408 |  |  |  | 37,202 |  |  |  | 17,940 |  |  |  | 63,070 |  |  |
| Total other expense, net |  |  | (7,998 | ) |  |  | (3,073 | ) |  |  | (18,268 | ) |  |  | (12,464 | ) |  |
| Income (loss) before income taxes |  | $ | 13,410 |  |  | $ | 34,129 |  |  | $ | (328 | ) |  | $ | 50,606 |  |  |

[0000950170-23-041297:notes:97]
|  |  | As of |  |
|  |  | July 3, 2023 |  |  | January 2, 2023 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |
| PCB |  | $ | 1,838,717 |  |  | $ | 1,890,723 |  |
| RF&S Components |  |  | 193,169 |  |  |  | 202,619 |  |
| Corporate and Other |  |  | 1,116,605 |  |  |  | 1,230,262 |  |
| Total assets |  | $ | 3,148,491 |  |  | $ | 3,323,604 |  |

[0000950170-23-041297:notes:98]
(1)
Amortization of definite-lived intangibles relates to the PCB and RF&S Components reportable segments. For the quarter and two quarters ended July 3, 2023, $2,423 and $8,231, respectively, of amortization expense is included in cost of goods sold. For the quarter and two quarters ended July 4, 2022, $1,383 and $2,767, respectively, of amortization expense is included in cost of goods sold.

[0000950170-23-041297:notes:99]
The Corporate and Other category primarily includes operating expenses that are not included in the segment operating performance measures. Corporate and Other consists primarily of corporate governance functions such as finance, accounting,

[0000950170-23-041297:notes:100]
information technology and human resources personnel, as well as global sales and marketing personnel, research and development costs, and acquisition and integration costs associated with acquisitions and divestitures.

[0000950170-23-041297:notes:101]
The Company markets and sells its products in approximately 60 countries. Other than in the United States, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales are as follows:

[0000950170-23-041297:notes:102]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |  |
|  |  | July 3, 2023 |  |  | July 4, 2022 |  |  | July 3, 2023 |  |  | July 4, 2022 |  |  |
|  |  | (In thousands) |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 319,122 |  |  | $ | 274,480 |  |  | $ | 630,563 |  |  | $ | 538,881 |  |  |
| China |  |  | 31,775 |  |  |  | 75,771 |  |  |  | 75,812 |  |  |  | 152,976 |  |  |
| Other |  |  | 195,612 |  |  |  | 275,299 |  |  |  | 384,571 |  |  |  | 514,953 |  |  |
| Total net sales |  | $ | 546,509 |  |  | $ | 625,550 |  |  | $ | 1,090,946 |  |  | $ | 1,206,810 |  |  |

[0000950170-23-041297:notes:103]
[same as prior period, unchanged from 0000950170-23-019634:notes:85]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950170-23-041297:notes:104]
[same as prior period, unchanged from 0000950170-23-019634:notes:86]

[0000950170-23-041297:notes:105]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of July 3, 2023 and January 2, 2023:

[0000950170-23-041297:notes:106]
|  |  | ForeignCurrencyTranslation |  |  | PensionObligation |  |  | (Losses) Gainson Cash FlowHedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of January 2, 2023 |  | $ | (25,984 | ) |  | $ | 1,279 |  |  | $ | (85 | ) |  | $ | (24,790 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (7,060 | ) |  |  | — |  |  |  | 5,140 |  |  |  | (1,920 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | (721 | ) |  |  | (721 | ) |
| Other comprehensive (loss) income |  |  | (7,060 | ) |  |  | — |  |  |  | 4,419 |  |  |  | (2,641 | ) |
| Ending balance as of July 3, 2023 |  | $ | (33,044 | ) |  | $ | 1,279 |  |  | $ | 4,334 |  |  | $ | (27,431 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-23-041297:notes:107]
[same as prior period, unchanged from 0000950170-23-019634:notes:89]

[0000950170-23-041297:notes:108]
Financial instruments that are potentially subject to concentrations of credit risk are primarily cash and cash equivalents and accounts receivable.

[0000950170-23-041297:notes:109]
The Company had cash and cash equivalents held by its foreign subsidiaries of $232,479 and $161,708 as of July 3, 2023 and January 2, 2023, respectively. The Company maintains its cash and cash equivalents with major financial institutions and such balances exceed Federal Deposit Insurance Corporation insurance limits. The Company has not experienced any losses in such accounts and believes it is not exposed to any significant risk on cash and cash equivalents.

[0000950170-23-041297:notes:110]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs on-going credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. There were no customers that accounted for 10% or more of accounts receivable as of July 3, 2023. As of January 2, 2023, there was one customer that accounted for 11% of the Company’s accounts receivable.

[0000950170-23-041297:notes:111]
[same as prior period, unchanged from 0000950170-23-019634:notes:91]

[0000950170-23-041297:notes:112]
For the quarter and two quarters ended July 3, 2023, one customer accounted for approximately 13% of the Company’s net sales. For the quarter and two quarters ended July 4, 2022, one customer accounted for approximately 11% and 10% of the Company’s net sales, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-23-041297:notes:113]
[same as prior period, unchanged from 0000950170-23-019634:notes:93]

[0000950170-23-041297:notes:114]
[same as prior period, unchanged from 0000950170-23-019634:notes:94]

[0000950170-23-041297:notes:115]
The carrying amount and estimated fair value of the Company’s financial instruments as of July 3, 2023 and January 2, 2023 were as follows:

[0000950170-23-041297:notes:116]
|  |  | As of |  |  | As of |  |
|  |  | July 3, 2023 |  |  | January 2, 2023 |  |
|  |  | CarryingAmount |  |  | Fair Value |  |  | CarryingAmount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 4,342 |  |  | $ | 4,342 |  |  | $ | — |  |  | $ | — |  |
| Derivative assets, non-current |  |  | 1,514 |  |  |  | 1,514 |  |  |  | — |  |  |  | — |  |
| Derivative liabilities, current |  |  | 783 |  |  |  | 783 |  |  |  | 1,622 |  |  |  | 1,622 |  |
| Senior Notes due March 2029 |  |  | 495,565 |  |  |  | 424,515 |  |  |  | 495,221 |  |  |  | 430,165 |  |
| Term Loan due May 2030 |  |  | 342,348 |  |  |  | 347,813 |  |  |  | — |  |  |  | — |  |
| Term Loan due September 2024 |  |  | — |  |  |  | — |  |  |  | 404,186 |  |  |  | 405,628 |  |
| ABL Revolving Loans |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |

[0000950170-23-041297:notes:117]
[same as prior period, unchanged from 0000950170-23-019634:notes:97]

[0000950170-23-041297:notes:118]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of July 3, 2023 and January 2, 2023, which are considered Level 2 inputs.

[0000950170-23-041297:notes:119]
As of July 3, 2023 and January 2, 2023, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value.

[0000950170-23-041297:notes:120]
[same as prior period, unchanged from 0000950170-23-019634:notes:100]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-041297:notes:121]
(14) Commitments and Contingencies

[0000950170-23-041297:notes:122]
Legal Matters

[0000950170-23-041297:notes:123]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 3, 2023 and January 2, 2023 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0000950170-23-041297:notes:124]
Offset Agreements

[0000950170-23-041297:notes:125]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of July 3, 2023, the Company had outstanding offset agreements of approximately $20,169, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of July 3, 2023, no such penalties have been paid.


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-041297:notes:126]
[same as prior period, unchanged from 0000950170-23-019634:notes:106]

[0000950170-23-041297:notes:127]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the quarter and two quarters ended July 3, 2023 and July 4, 2022:

[0000950170-23-041297:notes:128]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 3, |  |  | July 4, |  |  | July 3, |  |  | July 4, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2022 |  |  | 2022 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income |  | $ | 6,824 |  |  | $ | 27,792 |  |  | $ | 1,010 |  |  | $ | 45,038 |  |
| Basic weighted average shares |  |  | 102,759 |  |  |  | 101,270 |  |  |  | 102,570 |  |  |  | 101,941 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 2,061 |  |  |  | 1,951 |  |  |  | 2,005 |  |  |  | 1,818 |  |
| Dilutive effect of outstanding warrants |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3 |  |
| Diluted shares |  |  | 104,820 |  |  |  | 103,221 |  |  |  | 104,575 |  |  |  | 103,762 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.07 |  |  | $ | 0.27 |  |  | $ | 0.01 |  |  | $ | 0.44 |  |
| Diluted |  | $ | 0.07 |  |  | $ | 0.27 |  |  | $ | 0.01 |  |  | $ | 0.43 |  |

[0000950170-23-041297:notes:129]
Performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock options to purchase 524 and 345 shares of common stock for the quarter and two quarters ended July 3, 2023, respectively, and 1,054 and 1,014 shares of common stock for the quarter and two quarters ended July 4, 2022, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met at July 3, 2023 and July 4, 2022, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common stock during the applicable quarter and two quarters and, as a result, the impact would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-23-041297:notes:130]
[same as prior period, unchanged from 0000950170-23-019634:notes:111]

[0000950170-23-041297:notes:131]
[same as prior period, unchanged from 0000950170-23-019634:notes:112]

[0000950170-23-041297:notes:132]
|  |  | Quarter Ended |  | Two Quarters Ended |
|  |  | July 3, |  |  | July 4, |  |  |  | July 3, |  |  | July 4, |  |  |
|  |  | 2023 |  |  | 2022 |  |  |  | 2023 |  |  | 2022 |  |  |
|  |  | (In thousands) |
| Cost of goods sold |  | $ | 1,497 |  |  | $ | 1,172 |  |  |  | $ | 3,159 |  |  | $ | 2,448 |  |  |
| Selling and marketing |  |  | 698 |  |  |  | 620 |  |  |  |  | 1,439 |  |  |  | 1,270 |  |  |
| General and administrative |  |  | 2,677 |  |  |  | 2,396 |  |  |  |  | 5,239 |  |  |  | 4,449 |  |  |
| Research and development |  |  | 249 |  |  |  | 239 |  |  |  |  | 524 |  |  |  | 494 |  |  |
| Stock-based compensation expense recognized |  | $ | 5,121 |  |  | $ | 4,427 |  |  |  | $ | 10,361 |  |  | $ | 8,661 |  |  |

[0000950170-23-041297:notes:133]
[same as prior period, unchanged from 0000950170-23-019634:notes:114]

[0000950170-23-041297:notes:134]
The following is a summary of total unrecognized compensation costs as of July 3, 2023:

[0000950170-23-041297:notes:135]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted AverageRecognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 46,819 |  |  |  | 1.7 |  |
| PRU awards |  |  | 2,303 |  |  |  | 1.2 |  |
|  |  | $ | 49,122 |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-041297:notes:136]
[same as prior period, unchanged from 0000950170-23-019634:notes:117]

[0000950170-23-041297:notes:137]
On February 8, 2023, the Company announced a consolidation plan, which would include closing three of its manufacturing facilities and consolidating the operations of those facilities into other Company facilities. The three manufacturing facilities are PCB operations located in Anaheim and Santa Clara, California, and Hong Kong. As of July 3, 2023, the Company has ceased operations at the Hong Kong manufacturing facility. The Company expects the Anaheim and Santa Clara facilities to cease operations by the end of 2023. The Company expects to record between $22,000 and $28,000 in separation, accelerated depreciation and disposal costs related to this restructuring, primarily by the end of 2023. Approximately 80% of these costs are expected to be in the form of cash expenditures

[0000950170-23-041297:notes:138]
and the rest in the form of non-cash charges. As of July 3, 2023, the Company has incurred approximately $11,456 of restructuring charges and $2,649 of accelerated depreciation expense since the February 8, 2023 announcement.

[0000950170-23-041297:notes:139]
In addition to this consolidation plan, the Company recognized employee separation, contract termination and other costs during the quarter and two quarters ended July 3, 2023 and July 4, 2022 in connection with other global realignment restructuring efforts. Contract termination and other costs primarily represented plant closure costs.

[0000950170-23-041297:notes:140]
The below table summarizes such restructuring costs by reportable segment for the quarter and two quarters ended July 3, 2023 and July 4, 2022:

[0000950170-23-041297:notes:141]
|  |  | Quarter Ended July 3, 2023 |  |  | Two Quarters Ended July 3, 2023 |  |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |  |
|  |  | (In thousands) |  |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 7,385 |  |  | $ | 2,999 |  |  | $ | 10,384 |  |  | $ | 11,142 |  |  | $ | 3,185 |  |  | $ | 14,327 |  |  |
| RF&S Components |  |  | 14 |  |  |  | — |  |  |  | 14 |  |  |  | 14 |  |  |  | — |  |  |  | 14 |  |  |
| Corporate and Other |  |  | 179 |  |  |  | 226 |  |  |  | 405 |  |  |  | 305 |  |  |  | 324 |  |  |  | 629 |  |  |
|  |  | $ | 7,578 |  |  | $ | 3,225 |  |  | $ | 10,803 |  |  | $ | 11,461 |  |  | $ | 3,509 |  |  | $ | 14,970 |  |  |

[0000950170-23-041297:notes:142]
|  |  | Quarter Ended July 4, 2022 |  |  | Two Quarters Ended July 4, 2022 |  |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |  |
|  |  | (In thousands) |  |  |
| Reportable Segment: (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | — |  |  | $ | 343 |  |  | $ | 343 |  |  | $ | — |  |  | $ | 343 |  |  | $ | 343 |  |  |
| Corporate and Other |  |  | — |  |  |  | 113 |  |  |  | 113 |  |  |  | 31 |  |  |  | 266 |  |  |  | 297 |  |  |
|  |  | $ | — |  |  | $ | 456 |  |  | $ | 456 |  |  | $ | 31 |  |  | $ | 609 |  |  | $ | 640 |  |  |

[0000950170-23-041297:notes:143]
(1)
There were no restructuring costs incurred for RF&S Components reportable segment during the quarter and two quarters ended July 4, 2022.

[0000950170-23-041297:notes:144]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated condensed balance sheet. The below table shows the utilization of the accrued restructuring costs during the two quarters ended July 3, 2023:

[0000950170-23-041297:notes:145]
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand OtherCosts |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of January 2, 2023 |  | $ | 2,510 |  |  | $ | 3 |  |  | $ | 2,513 |  |
| Charged to expense |  |  | 11,461 |  |  |  | 3,509 |  |  |  | 14,970 |  |
| Amount paid, net of government contributions eligible for offsetting |  |  | (1,316 | ) |  |  | (2,918 | ) |  |  | (4,234 | ) |
| Accrued as of July 3, 2023 |  | $ | 12,655 |  |  | $ | 594 |  |  | $ | 13,249 |  |
