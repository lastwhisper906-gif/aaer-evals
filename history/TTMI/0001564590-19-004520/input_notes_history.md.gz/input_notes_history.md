# TTMI note change history — 0001564590-18-020718 → 0001564590-18-028539


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-08):
[0001564590-18-028539:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of October 1, 2018 and January 1, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2018-08-09, similarity 0.9927):
[0001564590-18-020718:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 2, 2018 and January 1, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-11-08):
[0001564590-18-028539:note_history:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of RF and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop manufacturing solution to customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- changed (2018-11-08):
[0001564590-18-028539:note_history:3]
The Company assessed the new guidance and adopted the new revenue standard on January 2, 2018, which resulted in a change to the timing of revenue recognition for certain of the Company’s revenue streams from “point in time” upon physical delivery to an “over time” model. Additionally, the Company elected the cumulative effect transition method with adjustment to the opening balance of retained earnings at January 2, 2018 for all open contracts as of January 1, 2018. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet at January 1, 2018 and the consolidated condensed statement of operations for the quarter and three quarters ended October 2, 2017.
  (was, 2018-08-09, similarity 0.9829):
[0001564590-18-020718:note_history:3]
The Company assessed the new guidance and adopted the new revenue standard on January 2, 2018, which resulted in a change to the timing of revenue recognition for certain of the Company’s revenue streams from “point in time” upon physical delivery to an “over time” model. Additionally, the Company elected the cumulative effect transition method with adjustment to the opening balance of retained earnings at January 2, 2018 for all open contracts as of January 1, 2018. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet at January 1, 2018 and the consolidated condensed statement of operations for the quarter and two quarters ended July 3, 2017.

- added (2018-11-08):
[0001564590-18-028539:note_history:4]
Additionally, the disclosure below summarizes the impact of the adoption of the new revenue standard on the Company’s consolidated condensed balance sheet as of October 1, 2018, statement of operations for the quarter and three quarters ended October 1, 2018 and statement of cash flows for the three quarters ended October 1, 2018 for which the As Reported reflects the new revenue standard and Balances without New Revenue Standard Adjustment reflects the Company’s replaced revenue recognition policy of “point in time” and upon physical delivery, for certain revenue streams, as appropriate.

- changed (2018-11-08):
[0001564590-18-028539:note_history:5]
|  |  | October 1, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 569,215 |  |  | $ | 8,171 |  |  | $ | 561,044 |  |
| Contract assets |  |  | 296,836 |  |  |  | 288,723 |  |  |  | 8,113 |  |
| Inventories |  |  | 122,232 |  |  |  | (241,839 | ) |  |  | 364,071 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 112,005 |  |  |  | 13,945 |  |  |  | 98,060 |  |
| Other long-term liabilities |  |  | 100,724 |  |  |  | 3,163 |  |  |  | 97,561 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 343,177 |  |  |  | 37,947 |  |  |  | 305,230 |  |
  (was, 2018-08-09, similarity 0.9916):
[0001564590-18-020718:note_history:5]
|  |  | July 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 541,587 |  |  | $ | 8,171 |  |  | $ | 533,416 |  |
| Contract assets |  |  | 300,717 |  |  |  | 293,114 |  |  |  | 7,603 |  |
| Inventories |  |  | 121,285 |  |  |  | (245,895 | ) |  |  | 367,180 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 104,139 |  |  |  | 14,033 |  |  |  | 90,106 |  |
| Other long-term liabilities |  |  | 92,938 |  |  |  | 3,163 |  |  |  | 89,775 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 315,975 |  |  |  | 38,194 |  |  |  | 277,781 |  |

- added (2018-11-08):
[0001564590-18-028539:note_history:6]
|  |  | Quarter ended October 1, 2018 |  |  | Three quarters ended October 1, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |  | As reported |  |  | Effect of Change Increase |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Net sales |  | $ | 755,837 |  |  | $ | (4,303 | ) |  | $ | 760,140 |  |  | $ | 2,136,306 |  |  | $ | 27,508 |  |  | $ | 2,108,798 |  |
| Cost of goods sold |  |  | 626,253 |  |  |  | (4,056 | ) |  |  | 630,309 |  |  |  | 1,801,904 |  |  |  | 18,263 |  |  |  | 1,783,641 |  |
| Gross profit |  |  | 129,584 |  |  |  | (247 | ) |  |  | 129,831 |  |  |  | 334,402 |  |  |  | 9,245 |  |  |  | 325,157 |  |
| Net income |  |  | 27,001 |  |  |  | (247 | ) |  |  | 27,248 |  |  |  | 121,102 |  |  |  | 9,373 |  |  |  | 111,729 |  |

- changed (2018-11-08):
[0001564590-18-028539:note_history:7]
Included in the Effect of Change Increase (Decrease) columns for the three quarters ended October 1, 2018 are $14,408, $11,375 and $3,033 of net sales, cost of goods sold and gross profit, respectively, related to the opening balance sheet of Anaren Inc. which was acquired on April 18, 2018 (See Note 3), and not to the activity during the three quarters of 2018.
  (was, 2018-08-09, similarity 0.9072):
[0001564590-18-020718:note_history:7]
Included in the Effect of Change Increase (Decrease) columns for the quarter and two quarters ended July 2, 2018 are $14,408, $11,375 and $3,033 of net sales, cost of goods sold and gross profit, respectively, related to the opening balance sheet of Anaren Inc. which was acquired on April 18, 2018 (See Note 3), and not to the activity during the quarter.

- changed (2018-11-08):
[0001564590-18-028539:note_history:8]
|  |  | Three Quarters ended October 1, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 121,102 |  |  | $ | 9,373 |  |  | $ | 111,729 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred income taxes |  |  | (64,516 | ) |  |  | (128 | ) |  |  | (64,388 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (44,685 | ) |  |  | — |  |  |  | (44,685 | ) |
| Contract assets |  |  | (12,597 | ) |  |  | (28,069 | ) |  |  | 15,472 |  |
| Inventories |  |  | 5,399 |  |  |  | 18,263 |  |  |  | (12,864 | ) |
| Accrued salaries, wages and benefits and other accrued expenses |  |  | (43,758 | ) |  |  | 561 |  |  |  | (44,319 | ) |
  (was, 2018-08-09, similarity 0.9896):
[0001564590-18-020718:note_history:8]
|  |  | Two Quarters ended July 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 94,101 |  |  | $ | 9,620 |  |  | $ | 84,481 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred income taxes |  |  | (64,769 | ) |  |  | (128 | ) |  |  | (64,641 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (17,056 | ) |  |  | — |  |  |  | (17,056 | ) |
| Contract assets |  |  | (16,478 | ) |  |  | (32,460 | ) |  |  | 15,982 |  |
| Inventories |  |  | 5,685 |  |  |  | 22,319 |  |  |  | (16,634 | ) |
| Accrued salaries, wages and benefits and other accrued expenses |  |  | (47,911 | ) |  |  | 649 |  |  |  | (48,560 | ) |

- added (2018-11-08):
[0001564590-18-028539:note_history:9]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those annual periods. The FASB also provided a practical expedient transition method to adopt the new lease requirements by allowing entities to initially apply requirements by recognizing a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption that would enable the Company to not provide comparative period financial statements. Instead, the Company would apply the transition provisions of the lease standard at its effective date. The Company is planning  on electing the practical expedient transition method as well as the package of practical expedients to not reassess prior conclusions related to contracts containing leases, lease classification and initial direct costs, and is evaluating other practical expedients available under the guidance. The Company expects the impact of adopting this new accounting standard to be material to its consolidated balance sheet, but is still evaluating the impact to its consolidated statement of income.

- removed (2018-11-08):
[0001564590-18-020718:note_history:10]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop manufacturing solution to customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

- removed (2018-11-08):
[0001564590-18-020718:note_history:11]
Additionally, the disclosure below summarizes the impact of the adoption of the new revenue standard on the Company’s consolidated condensed balance sheet as of July 2, 2018, statement of operations for the quarter and two quarters ended July 2, 2018 and statement of cash flows for the two quarters ended July 2, 2018 for which the As Reported reflects the new revenue standard and Balances without New Revenue Standard Adjustment reflects the Company’s replaced revenue recognition policy of “point in time” and upon physical delivery, for certain revenue streams, as appropriate.

- removed (2018-11-08):
[0001564590-18-020718:note_history:12]
|  |  | Quarter ended July 2, 2018 |  |  | Two Quarters ended July 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |  | As reported |  |  | Effect of Change Increase |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Net sales |  | $ | 716,887 |  |  | $ | 17,730 |  |  | $ | 699,157 |  |  | $ | 1,380,469 |  |  | $ | 31,811 |  |  | $ | 1,348,658 |  |
| Cost of goods sold |  |  | 600,747 |  |  |  | (10,338 | ) |  |  | 611,085 |  |  |  | 1,175,651 |  |  |  | 22,319 |  |  |  | 1,153,332 |  |
| Gross profit |  |  | 116,140 |  |  |  | 7,392 |  |  |  | 108,748 |  |  |  | 204,818 |  |  |  | 9,492 |  |  |  | 195,326 |  |
| Net income |  |  | 84,004 |  |  |  | 7,392 |  |  |  | 76,612 |  |  |  | 94,101 |  |  |  | 9,620 |  |  |  | 84,481 |  |

- removed (2018-11-08):
[0001564590-18-020718:note_history:13]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those annual periods and is to be applied utilizing a modified retrospective approach. The Company is currently planning on electing the package of practical expedients to not reassess prior conclusions related to contracts containing leases, lease classification and initial direct costs, and is evaluating other practical expedients available under the guidance. Additionally, the Company continues to evaluate the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, the primary effect of adopting this update will be to record assets and liabilities for existing operating leases.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-11-08):
[0001564590-18-028539:note_history:14]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as the design and manufacture of RF and microwave components and assemblies.

- changed (2018-11-08):
[0001564590-18-028539:note_history:15]
For the PCBs and custom electronic assemblies, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, the Company records revenue in accordance with the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation ─ Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.
  (was, 2018-08-09, similarity 0.9941):
[0001564590-18-020718:note_history:15]
For the PCBs and custom electronic assemblies, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous transfer of control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, the Company records revenue in accordance with the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation ─ Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.

- changed (2018-11-08):
[0001564590-18-028539:note_history:16]
The Company provides customers a limited right of return for defective PCBs including components and subsystems, and assemblies. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.
  (was, 2018-08-09, similarity 0.9713):
[0001564590-18-020718:note_history:16]
The Company provides customers a limited right of return for defective PCBs, assemblies, components and subsystems. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.

- removed (2018-11-08):
[0001564590-18-020718:note_history:17]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans.  With the acquisition of Anaren Inc. (See Note 3), the Company now also derives revenue from the design, development, and manufacture of components, assemblies, and subsystems which receive, process, and transmit microwave and RF signals which service the aerospace and defense electronics, and wireless communications markets.

- removed (2018-11-08):
[0001564590-18-020718:note_history:18]
The Company has three revenue streams which generally coincide with the Company’s reportable segments. These reportable segments are: PCB, E-M Solutions and Anaren.  See Note 17 Segment Information.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-08):
[0001564590-18-028539:note_history:19]
The components of interest expense resulting from the convertible senior notes for the quarters and three quarters ended October 1, 2018 and October 2, 2017 are as follows:
  (was, 2018-08-09, similarity 0.9091):
[0001564590-18-020718:note_history:19]
The components of interest expense resulting from the convertible senior notes for the quarter and two quarters ended July 2, 2018 and July 3, 2017 are as follows:

- added (2018-11-08):
[0001564590-18-028539:note_history:20]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 1, |  |  | October 2, |  |  | October 1, |  |  | October 2, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,303 |  |  | $ | 2,159 |  |  | $ | 6,800 |  |  | $ | 6,376 |  |
| Amortization of debt issuance costs |  | $ | 231 |  |  | $ | 216 |  |  | $ | 682 |  |  | $ | 639 |  |

- removed (2018-11-08):
[0001564590-18-020718:note_history:21]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 2, |  |  | July 3, |  |  | July 2, |  |  | July 3, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,267 |  |  | $ | 2,125 |  |  | $ | 4,497 |  |  | $ | 4,216 |  |
| Amortization of debt issuance costs |  | $ | 227 |  |  | $ | 214 |  |  | $ | 451 |  |  | $ | 423 |  |


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-08):
[0001564590-18-028539:note_history:22]
As of October 1, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2018-08-09, similarity 0.969):
[0001564590-18-020718:note_history:22]
As of July 2, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- changed (2018-11-08):
[0001564590-18-028539:note_history:23]
|  |  | As of October 1, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 9,266 |  |  | $ | 2,804 |  |  | 4.66% |  |  | $ | 2,788 |  |  | $ | 1,691 |  |  | 3.96% |  |
| Senior Notes due October 2025 |  |  | 6,253 |  |  | — |  |  | 5.92% |  |  |  | 6,782 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 2,207 |  |  |  | 22,019 |  |  | 6.48% |  |  |  | 2,889 |  |  |  | 28,822 |  |  | 6.48% |  |
|  |  | $ | 17,726 |  |  | $ | 24,823 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |
  (was, 2018-08-09, similarity 0.9903):
[0001564590-18-020718:note_history:23]
|  |  | As of July 2, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 10,037 |  |  | $ | 3,037 |  |  | 4.66% |  |  | $ | 2,788 |  |  | $ | 1,691 |  |  | 3.96% |  |
| Senior Notes due October 2025 |  |  | 6,432 |  |  | — |  |  | 5.92% |  |  |  | 6,782 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 2,438 |  |  |  | 24,322 |  |  | 6.48% |  |  |  | 2,889 |  |  |  | 28,822 |  |  | 6.48% |  |
|  |  | $ | 18,907 |  |  | $ | 27,359 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-08):
[0001564590-18-028539:note_history:24]
As of October 1, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:
  (was, 2018-08-09, similarity 0.9635):
[0001564590-18-020718:note_history:24]
As of July 2, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:

- changed (2018-11-08):
[0001564590-18-028539:note_history:25]
|  |  | As of October 1, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |
  (was, 2018-08-09, similarity 0.9331):
[0001564590-18-020718:note_history:25]
|  |  | As of July 2, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-08):
[0001564590-18-028539:note_history:26]
The following table summarizes the long-term debt of the Company as of October 1, 2018 and January 1, 2018:
  (was, 2018-08-09, similarity 0.9436):
[0001564590-18-020718:note_history:26]
The following table summarizes the long-term debt of the Company as of July 2, 2018 and January 1, 2018:

- added (2018-11-08):
[0001564590-18-028539:note_history:27]
|  |  | Interest Rate as of October 1, 2018 |  |  | Principal Outstanding as of October 1, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.77% |  |  | $ | 905,879 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.77% |  |  |  | 40,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.67% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  |  | — |  |  |  | — |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,600,864 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (24,823 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (17,726 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 1,558,315 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (40,000 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,518,315 |  |  |  |  |  |  | $ | 975,479 |  |

- changed (2018-11-08):
[0001564590-18-028539:note_history:28]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $905,879 as of October 1, 2018, of which $40,000 is included in short-term debt and $865,879 is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR, plus an applicable interest margin of 2.50%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At October 1, 2018 the interest rate on the outstanding borrowings under the Term Loan Facility was 4.77%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.
  (was, 2018-08-09, similarity 0.9858):
[0001564590-18-020718:note_history:28]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. These incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. This Term Loan Facility had an outstanding balance of $945,879 as of July 2, 2018, of which $40,000 is included in short-term debt and $905,879 is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR, plus an applicable interest margin of 2.50%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At July 2, 2018 the interest rate on the outstanding borrowings under the Term Loan Facility was 4.60%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

- changed (2018-11-08):
[0001564590-18-028539:note_history:29]
Subsequent to October 1, 2018, the Company made an optional debt principal prepayment of $40,000. As a result of the principal prepayments, the Company is no longer required to make any quarterly scheduled payments. However, based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.
  (was, 2018-08-09, similarity 0.8277):
[0001564590-18-020718:note_history:29]
The Company is required to make scheduled payments of the outstanding Term Loan Facility on a quarterly basis beginning January 1, 2018. Subsequent to July 2, 2018, the Company made an optional debt principal prepayment of $40,000. As a result of the prepayment, the Company is no longer required to make any quarterly scheduled payments until October 2022. However, based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

- changed (2018-11-08):
[0001564590-18-028539:note_history:30]
As of October 1, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:
  (was, 2018-08-09, similarity 0.9635):
[0001564590-18-020718:note_history:30]
As of July 2, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:

- changed (2018-11-08):
[0001564590-18-028539:note_history:31]
|  |  | As of October 1, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |
  (was, 2018-08-09, similarity 0.9331):
[0001564590-18-020718:note_history:31]
|  |  | As of July 2, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

- changed (2018-11-08):
[0001564590-18-028539:note_history:32]
The components of interest expense resulting from the convertible senior notes for the quarters and three quarters ended October 1, 2018 and October 2, 2017 are as follows:
  (was, 2018-08-09, similarity 0.9091):
[0001564590-18-020718:note_history:32]
The components of interest expense resulting from the convertible senior notes for the quarter and two quarters ended July 2, 2018 and July 3, 2017 are as follows:

- added (2018-11-08):
[0001564590-18-028539:note_history:33]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 1, |  |  | October 2, |  |  | October 1, |  |  | October 2, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,303 |  |  | $ | 2,159 |  |  | $ | 6,800 |  |  | $ | 6,376 |  |
| Amortization of debt issuance costs |  | $ | 231 |  |  | $ | 216 |  |  | $ | 682 |  |  | $ | 639 |  |

- changed (2018-11-08):
[0001564590-18-028539:note_history:34]
The U.S. ABL consists of three tranches comprised of a revolving credit facility for up to $200,000, a letter of credit facility for up to $50,000, and swingline loans for up to $30,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at the Company’s option. At October 1, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 3.77%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At October 1, 2018, $40,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.
  (was, 2018-08-09, similarity 0.9933):
[0001564590-18-020718:note_history:34]
The U.S. ABL consists of three tranches comprised of a revolving credit facility for up to $200,000, a letter of credit facility for up to $50,000, and swingline loans for up to $30,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at the Company’s option. At July 2, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 3.60%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At July 2, 2018, $40,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

- changed (2018-11-08):
[0001564590-18-028539:note_history:35]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At October 1, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.67%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At October 1, 2018, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.
  (was, 2018-08-09, similarity 0.9899):
[0001564590-18-020718:note_history:35]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At July 2, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.50%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At July 2, 2018, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

- changed (2018-11-08):
[0001564590-18-028539:note_history:36]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of October 1, 2018, letters of credit in the amount of $6,701 were outstanding under the U.S. ABL and $9,287 were outstanding under the Asia ABL with various expiration dates through December 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $153,299 and $110,713, respectively, which considers letters of credit outstanding at October 1, 2018.
  (was, 2018-08-09, similarity 0.9527):
[0001564590-18-020718:note_history:36]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of July 2, 2018, letters of credit in the amount of $6,137 were outstanding under the U.S. ABL and $13,469 were outstanding under the Asia ABL with various expiration dates through June 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $153,863 and $106,531, respectively, which considers letters of credit outstanding at July 2, 2018.

- changed (2018-11-08):
[0001564590-18-028539:note_history:37]
The Company is required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $251 and $179 for the quarters ended October 1, 2018 and October 2, 2017, respectively, and $739 and $546 for the three quarters ended October 1, 2018 and October 2, 2017, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.
  (was, 2018-08-09, similarity 0.921):
[0001564590-18-020718:note_history:37]
The Company is required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $247 and $180 for the quarters ended July 2, 2018 and July 3, 2017, respectively, and $488 and $367 for the two quarters ended July 2, 2018 and July 3, 2017, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

- changed (2018-11-08):
[0001564590-18-028539:note_history:38]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $30,600 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2019. As of October 1, 2018, the Chinese Revolver had not been drawn upon.
  (was, 2018-08-09, similarity 0.9209):
[0001564590-18-020718:note_history:38]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $31,700 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2019. As of July 2, 2018, the Chinese Revolver had not been drawn upon.

- changed (2018-11-08):
[0001564590-18-028539:note_history:39]
As of October 1, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2018-08-09, similarity 0.969):
[0001564590-18-020718:note_history:39]
As of July 2, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

- changed (2018-11-08):
[0001564590-18-028539:note_history:40]
|  |  | As of October 1, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 9,266 |  |  | $ | 2,804 |  |  | 4.66% |  |  | $ | 2,788 |  |  | $ | 1,691 |  |  | 3.96% |  |
| Senior Notes due October 2025 |  |  | 6,253 |  |  | — |  |  | 5.92% |  |  |  | 6,782 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 2,207 |  |  |  | 22,019 |  |  | 6.48% |  |  |  | 2,889 |  |  |  | 28,822 |  |  | 6.48% |  |
|  |  | $ | 17,726 |  |  | $ | 24,823 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |
  (was, 2018-08-09, similarity 0.9903):
[0001564590-18-020718:note_history:40]
|  |  | As of July 2, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 10,037 |  |  | $ | 3,037 |  |  | 4.66% |  |  | $ | 2,788 |  |  | $ | 1,691 |  |  | 3.96% |  |
| Senior Notes due October 2025 |  |  | 6,432 |  |  | — |  |  | 5.92% |  |  |  | 6,782 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 2,438 |  |  |  | 24,322 |  |  | 6.48% |  |  |  | 2,889 |  |  |  | 28,822 |  |  | 6.48% |  |
|  |  | $ | 18,907 |  |  | $ | 27,359 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |

- changed (2018-11-08):
[0001564590-18-028539:note_history:41]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,670 and $2,421 as of October 1, 2018 and January 1, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.
  (was, 2018-08-09, similarity 0.9817):
[0001564590-18-020718:note_history:41]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,921 and $2,421 as of July 2, 2018 and January 1, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

- changed (2018-11-08):
[0001564590-18-028539:note_history:42]
At October 1, 2018, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.9 years.
  (was, 2018-08-09, similarity 0.9591):
[0001564590-18-020718:note_history:42]
At July 2, 2018, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.1 years.

- added (2018-11-08):
[0001564590-18-028539:note_history:43]
Loss on Extinguishment of Debt

- added (2018-11-08):
[0001564590-18-028539:note_history:44]
During the quarter ended October 2, 2017, the Company recognized loss on extinguishment of debt of $768, primarily associated with the write off of the remaining unamortized debt issuance and debt discount for the 2016 Term Loan.

- removed (2018-11-08):
[0001564590-18-020718:note_history:45]
|  |  | Interest Rate as of July 2, 2018 |  |  | Principal Outstanding as of July 2, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.60% |  |  | $ | 945,879 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.60% |  |  |  | 40,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.50% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  | 6.43% |  |  |  | 1,556 |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,642,420 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (27,359 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (18,907 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 1,596,154 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (40,729 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,555,425 |  |  |  |  |  |  | $ | 975,479 |  |

- removed (2018-11-08):
[0001564590-18-020718:note_history:46]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 2, |  |  | July 3, |  |  | July 2, |  |  | July 3, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,267 |  |  | $ | 2,125 |  |  | $ | 4,497 |  |  | $ | 4,216 |  |
| Amortization of debt issuance costs |  | $ | 227 |  |  | $ | 214 |  |  | $ | 451 |  |  | $ | 423 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-08):
[0001564590-18-028539:note_history:47]
The following table summarizes the long-term debt of the Company as of October 1, 2018 and January 1, 2018:
  (was, 2018-08-09, similarity 0.9436):
[0001564590-18-020718:note_history:47]
The following table summarizes the long-term debt of the Company as of July 2, 2018 and January 1, 2018:

- added (2018-11-08):
[0001564590-18-028539:note_history:48]
|  |  | Interest Rate as of October 1, 2018 |  |  | Principal Outstanding as of October 1, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.77% |  |  | $ | 905,879 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.77% |  |  |  | 40,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.67% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  |  | — |  |  |  | — |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,600,864 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (24,823 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (17,726 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 1,558,315 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (40,000 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,518,315 |  |  |  |  |  |  | $ | 975,479 |  |

- removed (2018-11-08):
[0001564590-18-020718:note_history:49]
|  |  | Interest Rate as of July 2, 2018 |  |  | Principal Outstanding as of July 2, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.60% |  |  | $ | 945,879 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.60% |  |  |  | 40,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.50% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  | 6.43% |  |  |  | 1,556 |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,642,420 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (27,359 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (18,907 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 1,596,154 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (40,729 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,555,425 |  |  |  |  |  |  | $ | 975,479 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2018-11-08):
[0001564590-18-028539:note_history:50]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $10,437 and $13,225 for the quarters ended October 1, 2018 and October 2, 2017, respectively, and $35,695 and $38,886 for the three quarters ended October 1, 2018 and October 2, 2017, respectively.
  (was, 2018-08-09, similarity 0.9079):
[0001564590-18-020718:note_history:50]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $12,550 and $12,121 for the quarters ended July 2, 2018 and July 3, 2017, respectively, and $38,257 and $25,611 for the two quarters ended July 2, 2018 and July 3, 2017, respectively.

- changed (2018-11-08):
[0001564590-18-028539:note_history:51]
As of October 1, 2018 and January 1, 2018, the Company’s consolidated condensed balance sheets included $10,745 and $14,452, respectively, in accounts payable due to related parties primarily for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.
  (was, 2018-08-09, similarity 0.9546):
[0001564590-18-020718:note_history:51]
As of July 2, 2018 and January 1, 2018, the Company’s consolidated condensed balance sheets included $15,256 and $14,452, respectively, in accounts payable due to related parties primarily for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-11-08):
[0001564590-18-028539:note_history:52]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as the design and manufacture of RF and microwave components and assemblies.

- changed (2018-11-08):
[0001564590-18-028539:note_history:53]
For the PCBs and custom electronic assemblies, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, the Company records revenue in accordance with the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation ─ Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.
  (was, 2018-08-09, similarity 0.9941):
[0001564590-18-020718:note_history:53]
For the PCBs and custom electronic assemblies, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous transfer of control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, the Company records revenue in accordance with the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation ─ Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.

- changed (2018-11-08):
[0001564590-18-028539:note_history:54]
The Company provides customers a limited right of return for defective PCBs including components and subsystems, and assemblies. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.
  (was, 2018-08-09, similarity 0.9713):
[0001564590-18-020718:note_history:54]
The Company provides customers a limited right of return for defective PCBs, assemblies, components and subsystems. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.

- removed (2018-11-08):
[0001564590-18-020718:note_history:55]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans.  With the acquisition of Anaren Inc. (See Note 3), the Company now also derives revenue from the design, development, and manufacture of components, assemblies, and subsystems which receive, process, and transmit microwave and RF signals which service the aerospace and defense electronics, and wireless communications markets.

- removed (2018-11-08):
[0001564590-18-020718:note_history:56]
The Company has three revenue streams which generally coincide with the Company’s reportable segments. These reportable segments are: PCB, E-M Solutions and Anaren.  See Note 17 Segment Information.
