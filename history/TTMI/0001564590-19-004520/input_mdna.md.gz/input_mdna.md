# TTMI MD&A — 0001564590-19-004520


## mdna

[0001564590-19-004520:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001564590-19-004520:mdna:2]
This financial review presents our operating results for each of our three most recent fiscal years and our financial condition at December 31, 2018. Except for historical information contained herein, the following discussion contains forward-looking statements which are subject to known and unknown risks, uncertainties and other factors that may cause our actual results to differ materially from those expressed or implied by such forward-looking statements. We discuss such risks, uncertainties and other factors throughout this report and specifically under Item 1A of Part I of this report, Risk Factors. In addition, the following discussion should be read in connection with the information presented in our consolidated financial statements and the related notes to our consolidated financial statements.

[0001564590-19-004520:mdna:3]
COMPANY OVERVIEW

[0001564590-19-004520:mdna:4]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering and manufacturing solution to our customers from engineering support to prototype development through final mass production. This one-stop design and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 2,200 customers in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-19-004520:mdna:5]
RECENT DEVELOPMENTS

[0001564590-19-004520:mdna:6]
On April 18, 2018, we acquired all of the equity interests of Anaren, Inc. (Anaren) for total consideration of $787.9 million. Anaren is a leading provider of mission-critical RF solutions, microelectronics, and microwave components and assemblies for the wireless infrastructure and aerospace and defense electronics markets.

[0001564590-19-004520:mdna:7]
Additionally, on April 18, 2018 we closed our $600.0 million commitment for incremental loans concurrent with the completion of our acquisition of Anaren. We used the proceeds of the incremental loans, along with cash on hand to fund the purchase price of the acquisition and to pay related fees and expenses.

[0001564590-19-004520:mdna:8]
FINANCIAL OVERVIEW

[0001564590-19-004520:mdna:9]
For the fiscal year 2018, we experienced higher demand in our Aerospace and Defense, Computing/Storage/Peripherals and Medical/Industrial/Instrumentation end markets and additional sales from Anaren, partially offset by lower demand in our Cellular Phone and Networking/Communications end markets.

[0001564590-19-004520:mdna:10]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies as they are the ultimate end customers. Sales to our five largest customers accounted for 32%, 37% and 33% of our net sales in fiscal years 2018, 2017 and 2016, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-19-004520:mdna:11]
The following table shows the percentage of our net sales attributable to each of the principal end markets we served for the periods indicated:

[0001564590-19-004520:mdna:12]
|  |  | For the Year Ended |  |
| End Markets (1) |  | December 31, 2018 (3) |  |  | January 1, 2018 |  |  | January 2, 2017 |  |
| Aerospace and Defense |  | 22 | % |  | 16 | % |  | 15 | % |
| Automotive |  | 18 |  |  | 19 |  |  | 20 |  |
| Cellular Phone (2) |  | 13 |  |  | 18 |  |  | 14 |  |
| Computing/Storage/Peripherals (2) |  | 14 |  |  | 13 |  |  | 12 |  |
| Medical/Industrial/Instrumentation |  | 14 |  |  | 14 |  |  | 14 |  |
| Networking/Communications |  | 17 |  |  | 18 |  |  | 23 |  |
| Other (2) |  | 2 |  |  | 2 |  |  | 2 |  |
| Total |  | 100 | % |  | 100 | % |  | 100 | % |

[0001564590-19-004520:mdna:13]
| (1) | Sales to EMS companies are classified by the end markets of their OEM customers. |

[0001564590-19-004520:mdna:14]
| (2) | Smartphones are included in the Cellular Phone end market, tablets are included in the Computing/Storage/Peripherals end market and other consumer devices that include wearables, portable video devices and personal headphones are included in the Other end market. |

[0001564590-19-004520:mdna:15]
| (3) | Amounts include activity of Anaren since acquisition which occurred on April 18, 2018. |

[0001564590-19-004520:mdna:16]
We derive revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as the design and manufacture of RF and microwave components and assemblies. Most orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Most of our customers have continuous control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, and in light of our adoption of the new over time revenue standard beginning in the first quarter of 2018, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation rather than upon shipment as we had in the past. We recognize revenue under these contracts based on the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

[0001564590-19-004520:mdna:17]
Additionally, we have certain long-term contracts related to the manufacture of components, assemblies, and subsystems which service the aerospace and defense electronics market. These long-term contracts, many of which provide for periodic payments, are recognized over time under the percentage-of completion method. Estimated manufacturing cost-at-completion for these contracts are reviewed on a periodic basis, and adjustments are made as needed to the estimated cost-at-completion, based on actual costs incurred, progress made, and estimates of costs required to complete the contractual requirements. When the estimated manufacturing cost-at-completion exceeds the contract value, the contract is written down to its net realizable value and the loss resulting from the cost overruns are immediately recognized.

[0001564590-19-004520:mdna:18]
We also manufacture certain components, assemblies, and subsystems which service our wireless communications customers. We recognize revenue at a point in time upon transfer of control of the products to our customer. Point in time recognition was determined as our customers do not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0001564590-19-004520:mdna:19]
Net sales consist of gross sales less an allowance for returns, which typically have been less than 2% of gross sales. We provide our customers a limited right of return for defective PCBs including components, subsystems and assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results and anticipated returns.

[0001564590-19-004520:mdna:20]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. While we have entered into supply assurance agreements with some of our key suppliers to maintain the continuity of supply of some of the key materials we use, we generally do not participate in any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for the raw materials we use.

[0001564590-19-004520:mdna:21]
Selling and marketing expenses consist primarily of salaries, labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0001564590-19-004520:mdna:22]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, facilities, research and development, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001564590-19-004520:mdna:23]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0001564590-19-004520:mdna:24]
Our consolidated financial statements included in this report have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001564590-19-004520:mdna:25]
A critical accounting policy is defined as one that is both material to the presentation of our consolidated financial statements and requires us to make judgments that could have a material effect on our financial condition or results of operations. These policies require us to make assumptions about matters that are highly uncertain at the time of the estimate. Different estimates we could reasonably have used, or changes in the estimates that are reasonably likely to occur, could have a material effect on our financial condition or results of operations.

[0001564590-19-004520:mdna:26]
We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Management has discussed the development, selection and disclosure of these estimates with the audit committee of our board of directors. Actual results may differ from these estimates under different assumptions or conditions.

[0001564590-19-004520:mdna:27]
Our critical accounting policies include impairment of goodwill and intangible assets; realizability of deferred tax assets; and valuation of assets acquired and liabilities assumed from business combinations.

[0001564590-19-004520:mdna:28]
Goodwill and Intangible Assets

[0001564590-19-004520:mdna:29]
We have significant goodwill and definite-lived intangibles. We review these assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. In addition, we perform an impairment test related to goodwill at least annually. As necessary, we make judgments regarding future cash flow forecasts in the assessment of impairment.

[0001564590-19-004520:mdna:30]
We have two reportable segments consisting of PCB and E-M Solutions. There is only goodwill in our PCB reportable segment. Goodwill is allocated to our reporting units, which are our operating segments or one level below our operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic characteristics. Our PCB reportable segment is made up of five reporting units. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. We assess qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or perform its annual impairment test. When tested quantitatively, we compare the fair value of the applicable reporting unit with its carrying value. We estimate the fair values of our reporting units using a combination of the income and market approach. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss. In the fourth quarter of 2018, we performed our annual impairment test quantitatively and concluded that goodwill was not impaired.

[0001564590-19-004520:mdna:31]
In performing the impairment test, we determined the fair value of our reporting units by using discounted cash flow (DCF) and market analyses. For the portions of our business related to our acquisition of Anaren, it was determined that fair value was equivalent to carrying value due to the recent valuation in the second quarter of 2018 and results and forecasts in line with our forecasted cash flow at the time of acquisition. Determining fair value requires us to make judgments about appropriate discount rates, terminal value growth rates and the amount and timing of expected future cash flows. The cash flows employed in the DCF analysis for each reporting unit are based on the reporting unit's budget, long-term business plan, and recent operating performance. Discount rate assumptions are based on an assessment of the risk inherent in the future cash flows of the respective reporting unit and market conditions. Under the market approach, we use revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting units. For the fourth quarter 2018 test, excluding the impact of the acquisition of Anaren, the fair value of the reporting units tested exceeded the respective carrying values by 10% to 34%. Significant assumptions used in the DCF included terminal value growth rates and discount rates that ranged from 15% to 25%. An increase in the discount rate and decrease in the long-term growth rates of 0.5% would result in the fair value of the reporting units exceeding their respective carrying values by 9% to 25%. Given the inherent uncertainty in determining the assumptions underlying a DCF and market analysis, actual results may differ from those used in our valuations. In assessing the reasonableness of the determined fair values, we also reconciled the aggregate determined fair value of the Company to the Company's market capitalization, which, at the date of our fourth quarter 2018 impairment test, included a 28% control premium on a normalized basis.

[0001564590-19-004520:mdna:32]
Management will continue to monitor the reporting units for changes in the business environment that could impact recoverability. The recoverability of goodwill is dependent upon the continued growth of cash flows from our business activities. If the economy or business environment falter and we are unable to achieve our assumed revenue growth rates or profit margin percentages, our projections used would need to be re-measured, which could impact the carrying value of our goodwill in one or more of our reporting units.

[0001564590-19-004520:mdna:33]
We also assess definite-lived intangibles for potential impairment given similar impairment indicators. When indicators of impairment exist related to our definite-lived intangible assets, we use an estimate of the undiscounted cash flows in measuring whether the carrying amount of the assets is recoverable. Measurement of the amount of impairment, if any, is based upon the difference between the asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary, which involve judgments related to future cash flows and the application of the appropriate valuation model.

[0001564590-19-004520:mdna:34]
Income Taxes

[0001564590-19-004520:mdna:35]
Deferred income tax assets are reviewed for recoverability, and valuation allowances are provided, when necessary, to reduce deferred income tax assets to the amounts that are more likely than not to be realized based on our estimate of future taxable income. At December 31, 2018, we had a net noncurrent deferred income tax asset of $13.7 million, which is comprised of a net deferred tax asset of $174.8 million and a net deferred tax liability of $161.1 million. At December 31, 2018, our deferred income tax asset of $174.8 million was net of a valuation allowance of approximately $27.4 million. Should our expectations of taxable income change in future periods, it may be necessary to adjust our valuation allowance, which could affect our results of operations in the period such a determination is made.

[0001564590-19-004520:mdna:36]
Effects of the Tax Cuts and Jobs Act

[0001564590-19-004520:mdna:37]
On December 22, 2017, U.S. Tax Act was enacted. Accounting Standards Codification (ASC) Topic 740, Accounting for Income Taxes, requires companies to recognize the effect of tax law changes in the period of enactment regardless of the effective date of those tax law changes. Certain provisions of U.S. Tax Act are effective September 27, 2017, December 31, 2017 and January 1, 2018.

[0001564590-19-004520:mdna:38]
U.S. Tax Act included provisions requiring a “deemed” one-time mandatory repatriation transition tax on the net accumulated earnings and profits of a U.S. taxpayer’s foreign subsidiaries earned post 1986. We have performed an earnings and profits analysis with consideration given to foreign loss carryforwards acquired as a result of our acquisitions and determined that there was no income tax effect in the current or any prior or future period.

[0001564590-19-004520:mdna:39]
Other significant provisions that are effective and for which we have considered their impact on income taxes include: limitations on certain entertainment expenses, the inclusion of commissions and performance based compensation in determining the excessive compensation limitation, limitation on the current deductibility of net interest expense in excess of 30 percent of adjusted taxable income, an incremental tax (base erosion anti-abuse tax or BEAT) on excessive amounts paid to foreign related parties, a minimum tax on certain foreign earnings in excess of 10 percent of the foreign subsidiaries tangible assets (i.e., global intangible low-taxed income or GILTI), the benefit related to foreign derived intangible income (FDII), the required capitalization of research and development expenditures and the impact of requiring tax conformity with Accounting Standard Update (ASU) 2014-09, Revenue from Contracts with Customers. We have made a policy election to treat the GILTI tax as a period expense.

[0001564590-19-004520:mdna:40]
In addition, we are subject to income taxes in the United States and foreign jurisdictions. Significant judgment is required in determining our worldwide provision for income taxes. In the ordinary course of our business, there are many transactions for which the ultimate tax determination is uncertain. Additionally, our calculations of income taxes are based on our interpretations of applicable tax laws in the jurisdictions in which we file.

[0001564590-19-004520:mdna:41]
Business Combinations

[0001564590-19-004520:mdna:42]
The application of acquisition accounting to a business acquisition requires that we identify the individual assets acquired and liabilities assumed and estimate the fair value of each. The fair value of assets acquired and liabilities assumed in a business acquisition are recognized at the acquisition date, with the purchase price exceeding the fair values being recognized as goodwill. Determining fair value of identifiable assets, particularly intangibles, liabilities acquired and contingent obligations assumed requires management to make estimates. In certain circumstances, the allocations of the purchase price are based upon preliminary estimates and assumptions and subject to revision when we receive final information, including appraisals and other analysis. Accordingly, the measurement period for such purchase price allocations will end when the information, or the facts and circumstances, becomes available, but will not exceed twelve months. We will recognize measurement-period adjustments during the period of resolution, including the effect on earnings of any amounts that would have been recorded in previous periods if the accounting had been completed at the acquisition date.

[0001564590-19-004520:mdna:43]
Goodwill and intangible assets often represent a significant portion of the assets acquired in a business combination. We recognize the fair value of an acquired intangible apart from goodwill whenever the intangible arises from contractual or other legal rights, or when it can be separated or divided from the acquired entity and sold, transferred, licensed, rented or exchanged, either individually or in combination with a related contract, asset or liability. Intangible assets consist primarily of customer relationships, developed technology, and backlog acquired in business combinations. We generally assess the estimated fair values of acquired intangibles using a combination of valuation techniques. To estimate fair value, we are required to make certain estimates and assumptions, including future economic and market conditions

[0001564590-19-004520:mdna:44]
RESULTS OF OPERATIONS

[0001564590-19-004520:mdna:45]
We operate on a 52 or 53 week year ending on the Monday nearest December 31. Fiscal year 2018 and 2017 were 52 weeks ended December 31, 2018 and January 1, 2018, respectively. Fiscal year 2016 consisted of 53 weeks ended on January 2, 2017 with the additional week included in the fourth quarter. We estimated the additional week contributed approximately $29.2 million of additional revenue and approximately $1.1 million of additional operating income for the year ended January 2, 2017.

[0001564590-19-004520:mdna:46]
The following table sets forth the relationship of various items to net sales in our consolidated statements of operations:

[0001564590-19-004520:mdna:47]
|  |  | For the Year Ended |  |  |
|  |  | December 31, 2018 |  |  |  | January 1, 2018 |  |  |  | January 2, 2017 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 83.9 |  |  |  |  | 83.8 |  |  |  |  | 83.3 |  |  |
| Gross profit |  |  | 16.1 |  |  |  |  | 16.2 |  |  |  |  | 16.7 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.6 |  |  |  |  | 2.5 |  |  |  |  | 2.6 |  |  |
| General and administrative |  |  | 5.6 |  |  |  |  | 4.7 |  |  |  |  | 5.8 |  |  |
| Amortization of definite-lived intangibles |  |  | 2.1 |  |  |  |  | 1.0 |  |  |  |  | 1.0 |  |  |
| Restructuring charges |  |  | 0.2 |  |  |  |  | — |  |  |  |  | 0.4 |  |  |
| Impairment of long-lived assets |  |  | — |  |  |  |  | — |  |  |  |  | 0.1 |  |  |
| Total operating expenses |  |  | 10.5 |  |  |  |  | 8.2 |  |  |  |  | 9.9 |  |  |
| Operating income |  |  | 5.6 |  |  |  |  | 8.0 |  |  |  |  | 6.8 |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.7 | ) |  |  |  | (2.0 | ) |  |  |  | (3.0 | ) |  |
| Loss on extinguishment of debt |  |  | — |  |  |  |  | — |  |  |  |  | (1.9 | ) |  |
| Other, net |  |  | 0.3 |  |  |  |  | (0.7 | ) |  |  |  | 0.7 |  |  |
| Total other expense, net |  |  | (2.4 | ) |  |  |  | (2.7 | ) |  |  |  | (4.2 | ) |  |
| Income before income taxes |  |  | 3.2 |  |  |  |  | 5.3 |  |  |  |  | 2.6 |  |  |
| Income tax benefit (provision) |  |  | 2.9 |  |  |  |  | (0.6 | ) |  |  |  | (1.2 | ) |  |
| Net income |  |  | 6.1 |  |  |  |  | 4.7 |  |  |  |  | 1.4 |  |  |
| Less: Net income attributable to the noncontrolling interest |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  |  | 6.1 |  | % |  |  | 4.7 |  | % |  |  | 1.4 |  | % |

[0001564590-19-004520:mdna:48]
The Anaren acquisition occurred on April 18, 2018. Accordingly, our fiscal year 2018 only includes Anaren’s 2018 results of operations since the acquisition date.

[0001564590-19-004520:mdna:49]
We have two reportable segments: PCB and E-M Solutions. The PCB reportable segment is comprised of multiple operating segments. Factors considered in determining whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production process, type or class of customers, distribution methods and regulatory environments.

[0001564590-19-004520:mdna:50]
Net Sales

[0001564590-19-004520:mdna:51]
Total net sales increased $188.7 million, or 7.1%, from $2,658.6 million for the year ended January 1, 2018 to $2,847.3 million for the year ended December 31, 2018. Net sales for the PCB reportable segment increased $172.8 million, or 7.1%, from $2,448.5 million for the year ended January 1, 2018 to $2,621.3 million for the year ended December 31, 2018. This increase was primarily due to the acquisition of Anaren, which accounted for $191.0 million in net sales in 2018, as well as higher demand in the Aerospace and Defense, Computing/Storage/Peripherals and Medical/Industrial/Instrumentation end markets compared to the year ended January 1, 2018, partially offset by a decline in demand in our Cellular Phone, Networking/Communications and Automotive end markets. These changes resulted in an average PCB selling price increase of 8.1%, driven mainly by product mix shift, however the resulting increase in net sales was partially offset by a 6.9% decrease in the volume of PCB shipments as compared to the year ended January 1, 2018. Net sales for the E-M Solutions reportable segment increased $15.8 million, or 7.5%, from $210.1 million for the year ended January 1, 2018 to $225.9 million for the year ended December 31, 2018. The increase was primarily due to higher demand in our Automotive and Networking/Communications end markets.

[0001564590-19-004520:mdna:52]
Total net sales increased $125.2 million, or 4.9%, from $2,533.4 million for the year ended January 2, 2017 to $2,658.6 million for the year ended January 1, 2018. Net sales for the PCB reportable segment increased $113.6 million, or 4.9%, from $2,334.9 million for the year ended January 2, 2017 to $2,448.5 million for the year ended January 1, 2018. This increase was primarily due to higher demand in our Cellular Phone, Computing/Storage/Peripherals and Aerospace and Defense end markets compared to the year ended January 2, 2017, partially offset by lower demand in our Networking/Communications end market. While these changes resulted in essentially no change in PCB shipments as compared to the year ended January 2, 2017, average PCB selling price increased by 4.9% as a result of higher average PCB selling price in our Cellular Phone end market, which is primarily due to a more complex technology at a higher cost. Net sales for the E-M Solutions reportable segment increased $11.6 million, or 5.8%, from $198.5 million for the year ended January 2, 2017 to $210.1 million for the year ended January 1, 2018. This increase was primarily due to higher demand in our Automotive end market.

[0001564590-19-004520:mdna:53]
For information regarding net sales by country, see Note 18 of the Notes to Consolidated Financial Statements.

[0001564590-19-004520:mdna:54]
Gross Margin

[0001564590-19-004520:mdna:55]
Overall gross margin decreased from 16.2% for the year ended January 1, 2018 to 16.1% for the year ended December 31, 2018. Gross margin for the PCB reportable segment was 17.2% for both the years ended January 1, 2018 and December 31, 2018, primarily due to the acquisition of Anaren and higher capacity utilization at our Aerospace & Defense focused facilities, offset by decreased volumes at our Cellular Phone focused facilities. Gross margin for the PCB reportable segment included a charge of $4.9 million to cost of goods sold associated with inventory resulting from purchase accounting. Gross margin for the E-M Solutions reportable segment decreased from 8.1% for the year ended January 1, 2018 to 8.0% for the year ended December 31, 2018.

[0001564590-19-004520:mdna:56]
Overall gross margin decreased from 16.7% for the year ended January 2, 2017 to 16.2% for the year ended January 1, 2018. Gross margin for the PCB reportable segment decreased from 17.7% for the year ended January 2, 2017 to 17.2% for the year ended January 1, 2018, primarily due to the change in classification of certain facilities and labor support related costs from general and administrative expenses to cost of goods sold as a result of changes in our business structure, partially offset by higher margins in our Cellular Phone focused facilities. Gross margin for the E-M Solutions reportable segment decreased from 9.1% for the year ended January 2, 2017 to 8.1% for the year ended January 1, 2018 primarily due to mix shift toward higher direct material content work.

[0001564590-19-004520:mdna:57]
Capacity utilization is a key driver for us, particularly in our high volume Asia facilities, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the year ended January 1, 2018 in our Asia and North America PCB facilities was 86% and 54%, respectively, compared to 75% and 60%, respectively, for the year ended December 31, 2018.

[0001564590-19-004520:mdna:58]
Selling and Marketing Expenses

[0001564590-19-004520:mdna:59]
Selling and marketing expenses increased $7.4 million from $65.9 million for the year ended January 1, 2018 to $73.3 million for the year ended December 31, 2018. As a percentage of net sales, selling and marketing expenses were 2.5% for the year ended January 1, 2018 as compared to 2.6% for the year ended December 31, 2018. The increase in selling and marketing expenses in 2018 was primarily related to the acquisition of Anaren on April 18, 2018.

[0001564590-19-004520:mdna:60]
Selling and marketing expenses decreased $0.5 million from $66.4 million for the year ended January 2, 2017 to $65.9 million for the year ended January 1, 2018. As a percentage of net sales, selling and marketing expenses were 2.6% for the year ended January 2, 2017 as compared to 2.5% for the year ended January 1, 2018. The decrease in selling and marketing expense as a percentage of net sales for the periods noted was primarily due to higher net sales and lower travel expenses.

[0001564590-19-004520:mdna:61]
General and Administrative Expenses

[0001564590-19-004520:mdna:62]
General and administrative expenses increased $33.3 million from $126.1 million, or 4.7% of net sales, for the year ended January 1, 2018 to $159.4 million, or 5.6% of net sales, for the year ended December 31, 2018. The increase in expense was primarily related to general and administrative expenses incurred by Anaren post acquisition and $13.3 million of acquisition-related costs during the year ended December 31, 2018 primarily associated with the acquisition of Anaren on April 18, 2018.

[0001564590-19-004520:mdna:63]
General and administrative expenses decreased $21.1 million from $147.2 million, or 5.8% of net sales, for the year ended January 2, 2017 to $126.1 million, or 4.7% of net sales, for the year ended January 1, 2018. The decrease in expense is primarily related to the change in classification of certain facilities and labor support related costs to cost of goods sold due to changes in our business structure.

[0001564590-19-004520:mdna:64]
Restructuring and Impairment Charges

[0001564590-19-004520:mdna:65]
For the years ended December 31, 2018, January 1, 2018, and January 2, 2017, we incurred restructuring charges of $5.5 million, $1.2 million, and $8.9 million, respectively, related to integration and other efficiency and cost saving measures following the acquisition of Anaren on April 18, 2018 and closure of our facilities in Cleveland, Ohio, Milpitas, California, and Juarez, Mexico and other global realignment efforts following the acquisition of Viasystems on May 31, 2015.

[0001564590-19-004520:mdna:66]
During the year ended December 31, 2018, we recognized restructuring charges of $2.0 million and $3.5 million in our PCB reportable segment and Corporate, respectively. For the year ended January 1, 2018, we recognized restructuring charges of $0.3 million and $0.5 million in our PCB and E-M Solutions reportable segments, respectively, and $0.4 million in Corporate. For the year ended January 2, 2017, we recognized restructuring charges of $3.7 million and $4.5 million in our PCB and E-M Solutions reportable segments, respectively, and $0.7 million in Corporate. These charges primarily represent employee separation and contract termination and other costs associated with the restructuring plans. As of December 31, 2018, we had incurred approximately $23.0 million of restructuring charges since the inception of the restructuring plans.

[0001564590-19-004520:mdna:67]
Additionally, as a result of the above mentioned plant closures and other plant realignment efforts, we also recognized impairment charges of $3.3 million for the year ended January 2, 2017, of which $1.4 million were recognized in our PCB reportable segment and $1.9 million were recognized in the Corporate. The impairment charge for the PCB reportable segment related to machinery and equipment while the impairment charge for Corporate related to the write-off of capitalized software costs.

[0001564590-19-004520:mdna:68]
If forecasts and assumptions used to support the realizability of our long-lived assets change in the future, significant restructuring or impairment charges could result that would adversely affect our results of operations and financial condition.

[0001564590-19-004520:mdna:69]
Other Income (Expense)

[0001564590-19-004520:mdna:70]
Other expense, net decreased $3.5 million from $72.8 million for the year ended January 1, 2018 to $69.3 million for the year ended December 31, 2018. The decrease in other expense, net was primarily due to:

[0001564590-19-004520:mdna:71]
|  | • | a decrease in expense of $26.3 million due to $3.5 million of foreign exchange gains for the year ended December 31, 2018 compared to $22.8 million foreign exchange losses for the year ended January 1, 2018, primarily resulting from a weakening Chinese Renminbi relative to the U.S. dollar, |

[0001564590-19-004520:mdna:72]
|  | • | partially offset by an increase in interest expense of $25.1 million, primarily related to the $600.0 million incremental borrowing in conjunction with the Anaren acquisition, $23.0 million draw on our U.S. Asset-Based Lending Credit (U.S. ABL), higher amortization of debt issuance costs and debt discount and additional interest expense from our interest rate swap. |

[0001564590-19-004520:mdna:73]
Other expense, net decreased $33.7 million from $106.5 million for the year ended January 2, 2017 to $72.8 million for the year ended January 1, 2018. The decrease in other expense, net was primarily due to:

[0001564590-19-004520:mdna:74]
|  | • | the absence of the 2016 loss on extinguishment of debt of $47.8 million related to the full repayment of the 2015 Term Loan Credit Agreement, |

[0001564590-19-004520:mdna:75]
|  | • | a decrease in interest expense of $22.1 million, due to overall lower amount of principal outstanding, a lower Term Loan Facility interest rate margin by 175 basis points, and three quarters of comparatively lower amortization of debt issuance costs and debt discount after the full repayment of our 2016 Term Loan in the fourth quarter of 2016, and |

[0001564590-19-004520:mdna:76]
|  | • | partially offset by an increase from a change in foreign exchange expense of $36.3 million resulting from a $22.8 million foreign exchange losses for the year ended January 1, 2018 compared to a $13.5 million of foreign exchange gains for the year ended January 2, 2017 primarily resulting from a weakening U.S. dollar relative to the Chinese Renminbi. |

[0001564590-19-004520:mdna:77]
Income Taxes

[0001564590-19-004520:mdna:78]
The provision for income taxes decreased $99.1 million from an income tax expense of $15.2 million for the year ended January 1, 2018 to an income tax benefit of $83.9 million for the year ended December 31, 2018. The decrease in income tax expense in 2018 was primarily due to a release of the valuation allowance in the U.S. and certain foreign entities and an increase in tax incentives in China, partially offset by an increase to tax expense for the establishment of a deferred tax liability related to unremitted foreign earnings.

[0001564590-19-004520:mdna:79]
Our tax expense is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of other credits and deductions available to us, changes in our valuation allowance, and certain non-deductible items. Certain losses generated are not more likely than not to be realizable, and thus no income tax benefit has been recognized on these losses. We had a net deferred income tax asset of approximately $13.7 million and $4.9 million deferred tax liability as of December 31, 2018 and January 1, 2018, respectively. Based on our forecast for future taxable earnings in the U.S. and certain foreign jurisdictions, we believe it is more likely than not that we will utilize the deferred income tax assets in future periods.

[0001564590-19-004520:mdna:80]
The provision for income taxes decreased $16.2 million from an income tax expense of $31.4 million for the year ended January 2, 2017 to $15.2 million for the year ended January 1, 2018. The decrease in income tax expense in 2017 was primarily due to a release of the valuation allowance in certain foreign entities and an increase in tax incentives in China.

[0001564590-19-004520:mdna:81]
Liquidity and Capital Resources

[0001564590-19-004520:mdna:82]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, term debt, senior notes and revolving debt. Our principal uses of cash have been to finance capital expenditures, finance acquisitions (including the acquisition of Anaren in fiscal 2018), meet debt service requirements, fund working capital requirements, and refinance existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001564590-19-004520:mdna:83]
Cash flow provided by operating activities during the year ended December 31, 2018 was $273.1 million as compared to $332.8 million in the same period in 2017. The decrease in cash flow was primarily due to increased working capital. As of December 31, 2018, we had net working capital of approximately $533.7 million compared to $501.0 million as of January 1, 2018.

[0001564590-19-004520:mdna:84]
Net cash used in investing activities was approximately $746.2 million for the year ended December 31, 2018 primarily reflecting $596.4 million for the acquisition of Anaren, net of debt assumed, and $150.1 million for purchases of property, plant and equipment.

[0001564590-19-004520:mdna:85]
Net cash provided by financing activities was approximately $321.1 million for the year ended December 31, 2018, primarily reflecting proceeds of $623.0 million from the incremental term and revolving loan borrowings, offset by the repayment of assumed long-term debt related to the acquisition of Anaren of $178.6 million, repayment of long-term debt of $114.4 million, and payment of debt issuance costs and original issue discount of $9.2 million associated with the Term Loan Facility and Senior Notes.

[0001564590-19-004520:mdna:86]
As of December 31, 2018, we had cash and cash equivalents of approximately $256.4 million, of which approximately $213.9 million was held by our foreign subsidiaries, primarily in Asia.

[0001564590-19-004520:mdna:87]
Our 2019 capital expenditure plan is expected to be in the range of $130.0 million to $150.0 million.

[0001564590-19-004520:mdna:88]
Long-term Debt and Letters of Credit

[0001564590-19-004520:mdna:89]
Term Loan Facility

[0001564590-19-004520:mdna:90]
On April 18, 2018, we closed our $600.0 million commitment of incremental loans concurrent with the completion of our acquisition of Anaren. At issuance, these incremental loans increased the existing balance of our Term Loan Facility due 2024 from $348.3 million to $948.3 million. As of December 31, 2018, the Term Loan Facility had an outstanding balance of $835.9 million, of which $30.0 million is included in short-term debt and $805.9 million is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at our option, at a floating rate of LIBOR, plus an applicable interest margin of 2.50%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At December 31, 2018 the interest rate on the outstanding borrowings under the Term Loan Facility was 5.00%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of our domestic assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and is structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-19-004520:mdna:91]
During 2018, after the closing of our April 18, 2018 incremental loans facility, we made a $2.4 million quarterly scheduled principal payment and $110.0 million optional debt principal prepayments. Subsequent to December 31, 2018, we made an optional debt principal prepayment of $30.0 million. As a result of the principal prepayments, we are no longer required to make any quarterly scheduled payments. However, based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, we may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018. For 2019, we are not required to make an additional principal payment as our First Lien Leverage Ratio was less than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0001564590-19-004520:mdna:92]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments. At December 31, 2018, we were in compliance with the covenants under the Term Loan Facility.

[0001564590-19-004520:mdna:93]
Senior Notes

[0001564590-19-004520:mdna:94]
The $375.0 million of Senior Notes issued, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

[0001564590-19-004520:mdna:95]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments. At December 31, 2018, we were in compliance with the covenants under the Senior Notes.

[0001564590-19-004520:mdna:96]
Convertible Senior Notes due 2020

[0001564590-19-004520:mdna:97]
We maintain 1.75% convertible senior notes in the amount of $250.0 million due December 15, 2020. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the convertible senior notes.

[0001564590-19-004520:mdna:98]
Conversion:     At any time prior to March 15, 2020, holders may convert their convertible senior notes into cash and, if applicable, into shares of our common stock based on a conversion rate of 103.7613 shares of our common stock per $1,000 principal amount of convertible senior notes, subject to adjustment, under the following circumstances: (1) during any calendar quarter beginning after March 31, 2015 (and only during such calendar quarter), if the last reported sale price of our common stock for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day of such preceding calendar quarter; (2) during the five business day period after any 10 consecutive trading day period in which the trading price per note for each day of that 10 consecutive trading day period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on such day; or (3) upon the occurrence of specified corporate transactions described in the indenture governing the notes. In 2018, the conversion criteria had been met allowing holders to give notice of conversion during the year. However, as of December 31, 2018, the conversion criteria that would allow holders to give notice of conversion in the first quarter of 2019 had not been met.

[0001564590-19-004520:mdna:99]
On or after March 15, 2020 until the close of business on the third scheduled trading day preceding the maturity date, holders may convert their notes at any time, regardless of the foregoing circumstances. Upon conversion, for each $1,000 principal amount of notes, we will pay shares of our common stock, cash or a combination of cash and shares of our common stock at our election, if applicable, based on a daily conversion value calculated on a proportionate basis for each day of the 80 trading day observation period. All conversions occurring on the same date or on or after March 15, 2020 shall be settled using the same settlement method. Additionally, in the event of a fundamental change as defined in the indenture governing the notes, or other conversion rate adjustments such as share splits or combinations, other distributions of shares, cash or other assets to stockholders, including self-tender transactions (Other Conversion Rate Adjustments), the conversion rate may be modified to adjust the number of shares per $1,000 principal amount of the notes. As of December 31, 2018, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0001564590-19-004520:mdna:100]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to Other Conversion Rate Adjustments, would be 32.4 million.

[0001564590-19-004520:mdna:101]
Note Repurchase:    We are not permitted to redeem the convertible senior notes at any time prior to maturity. In the event of a fundamental change or certain default events, as defined in the indenture governing the notes, holders may require us to repurchase for cash all or a portion of their convertible senior notes at a price equal to 100% of the principal amount, plus any accrued and unpaid interest.

[0001564590-19-004520:mdna:102]
Convertible Note Hedge and Warrant Transaction:  In connection with the issuance of the convertible senior notes due 2020, we entered into a convertible note hedge and warrant transaction (Call Spread Transaction), with respect to our common stock. The convertible note hedge consists of our option to purchase up to 25.9 million common stock shares at a price of $9.64 per share. The hedge expires on December 15, 2020 and can only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, we sold warrants to purchase 25.9 million shares of our common stock at a price of $14.26 per share. The warrants expire ratably from March 2021 through January 2022. The Call Spread Transaction has no effect on the terms of the convertible senior notes due 2020 and reduces potential dilution by effectively increasing the conversion price of the convertible senior notes due 2020 to $14.26 per share of our common stock.

[0001564590-19-004520:mdna:103]
Asset-Based Lending Agreements

[0001564590-19-004520:mdna:104]
We maintain a $200.0 million U.S. ABL, and a $150.0 million Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans).

[0001564590-19-004520:mdna:105]
The U.S. ABL consists of three tranches comprised of a revolving credit facility of up to $200.0 million, a letter of credit facility for up to $50.0 million, and swingline loans for up to $30.0 million, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at our option. At December 31, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 4.00%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and certain inventories as well as by a second position against a significant amount of our domestic assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and are structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At December 31, 2018, $40.0 million of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-004520:mdna:106]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150.0 million and a letter of credit facility for up to $100.0 million, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At December 31, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.90%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of our Asia Pacific cash and receivables and are structurally senior to our domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At December 31, 2018, $30.0 million of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-004520:mdna:107]
We have up to $50.0 million and $100.0 million Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of December 31, 2018, letters of credit in the amount of $10.1 million were outstanding under the U.S. ABL and $12.1million were outstanding under the Asia ABL with various expiration dates through May 2020. Available borrowing capacity under the U.S. ABL and the Asia ABL was $149.9 million and $107.9 million, respectively, which considers letters of credit outstanding at December 31, 2018.

[0001564590-19-004520:mdna:108]
We are required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the ABL Revolving Loans. We paid commitment fees of $1.0 million, $0.8 million and $0.7 million for the years ended December 31, 2018, January 1, 2018, and January 2, 2017, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. At December 31, 2018, we were in compliance with the covenants under the ABL Revolving Loans.

[0001564590-19-004520:mdna:109]
Other Credit Facility

[0001564590-19-004520:mdna:110]
Additionally, we are party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to us approximately $30.5 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in June 2019. As of December 31, 2018, the Chinese Revolver had not been drawn upon.

[0001564590-19-004520:mdna:111]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next 12 months.

[0001564590-19-004520:mdna:112]
Contractual Obligations and Commitments

[0001564590-19-004520:mdna:113]
The following table provides information on our contractual obligations as of December 31, 2018:

[0001564590-19-004520:mdna:114]
|  |  | Total |  |  | Less Than 1 year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 1,280,879 |  |  | $ | 30,000 |  |  | $ | 70,000 |  |  | $ | — |  |  | $ | 1,180,879 |  |
| Convertible debt obligations |  |  | 249,985 |  |  |  | — |  |  |  | 249,985 |  |  |  | — |  |  |  | — |  |
| Interest on debt obligations |  |  | 398,927 |  |  |  | 72,774 |  |  |  | 130,014 |  |  |  | 123,715 |  |  |  | 72,424 |  |
| Derivative liabilities |  |  | 5,595 |  |  |  | 1,222 |  |  |  | 3,720 |  |  |  | 653 |  |  |  | — |  |
| Purchase obligations |  |  | 112,553 |  |  |  | 102,228 |  |  |  | 1,213 |  |  |  | 686 |  |  |  | 8,426 |  |
| Operating lease commitments |  |  | 24,141 |  |  |  | 7,282 |  |  |  | 8,107 |  |  |  | 4,580 |  |  |  | 4,172 |  |
| Total contractual obligations |  | $ | 2,072,080 |  |  | $ | 213,506 |  |  | $ | 463,039 |  |  | $ | 129,634 |  |  | $ | 1,265,901 |  |

[0001564590-19-004520:mdna:115]
| (1) | Unrecognized uncertain tax benefits of $37.9 million are not included in the table above as the settlement timing is uncertain. |

[0001564590-19-004520:mdna:116]
Off-Balance Sheet Arrangements

[0001564590-19-004520:mdna:117]
We do not have any relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, which would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes. In addition, we do not engage in trading activities involving non-exchange traded contracts. As a result, we are not materially exposed to any financing, liquidity, market, or credit risk that could arise if we had engaged in these relationships.

[0001564590-19-004520:mdna:118]
Seasonality

[0001564590-19-004520:mdna:119]
Orders for our products generally correspond to the production schedules of our customers. We historically experience higher net sales in the third and fourth quarters due to end customer demand in the fourth quarter for consumer electronics products. Seasonal fluctuations also include the Chinese New Year holidays in the first quarter, which typically results in lower net sales. We attribute this decline to shutdowns of our customers’ and our own China based manufacturing facilities surrounding the Chinese New Year public holidays, which normally occur in January or February of each year.

[0001564590-19-004520:mdna:120]
Recently Issued Accounting Standards

[0001564590-19-004520:mdna:121]
For a description of recently adopted and issued accounting standards, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Note 1 of the Notes to Consolidated Financial Statements.
