# TTMI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001564590-19-004520:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES |

[0001564590-19-004520:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001564590-19-004520:item_9a:3]
Our management, under the supervision and with the participation of our Chief Executive Officer (CEO) and Chief Financial Officer (CFO), has evaluated the effectiveness of the design and operation of our disclosure controls and procedures (as defined in Exchange Act Rules 13a-15(e) and 15d-15(e)) as of the end of the period covered by this Report. Based on this evaluation, our CEO and CFO have concluded that, as of December 31, 2018, such disclosure controls and procedures were effective to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is (i) recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and (ii) accumulated and communicated to our management, including our CEO and CFO, as appropriate to allow timely decisions regarding required disclosures.

[0001564590-19-004520:item_9a:4]
49

[0001564590-19-004520:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0001564590-19-004520:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, (as defined in Exchange Act Rules 13a-15(f) and 15d-15(f)) to provide reasonable assurance regarding the reliability of our financial reporting and the preparation of financial statements for external purposes in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP). Under the supervision of and with the participation of our CEO and CFO, management conducted an assessment of the effectiveness of our internal control over financial reporting as of December 31, 2018 based on the criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Based on this assessment, management concluded that our internal control over financial reporting was effective as of December 31, 2018.

[0001564590-19-004520:item_9a:7]
We acquired Anaren, Inc. on April 18, 2018. Management excluded from its evaluation of the effectiveness of our internal control over financial reporting as of December 31, 2018 the acquired entity’s internal control over financial reporting associated with 2.4% of total assets and 6.7% of total net sales included in our consolidated financial statements as of and for the year ended December 31, 2018.

[0001564590-19-004520:item_9a:8]
The effectiveness of our internal control over financial reporting as of December 31, 2018 has been audited by KPMG LLP, an independent registered public accounting firm, as stated in their report, which appears under the heading “Report of Independent Registered Public Accounting Firm” on page 57 of this Report.

[0001564590-19-004520:item_9a:9]
Inherent Limitations on Effectiveness of Controls

[0001564590-19-004520:item_9a:10]
A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system’s objectives will be met. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Further, because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that misstatements due to error or fraud will not occur or that all control issues and instances of fraud, if any, have been detected. In addition, the design of any system of controls is based in part on certain assumptions about the likelihood of future events.

[0001564590-19-004520:item_9a:11]
Changes in Internal Control over Financial Reporting

[0001564590-19-004520:item_9a:12]
There were no changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended December 31, 2018 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
