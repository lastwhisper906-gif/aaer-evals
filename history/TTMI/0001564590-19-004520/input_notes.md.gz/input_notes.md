# TTMI notes — 0001564590-19-004520


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-19-004520:notes:1]
| (1) | Nature of Operations and Summary of Significant Accounting Policies |

[0001564590-19-004520:notes:2]
Nature of Operations

[0001564590-19-004520:notes:3]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers from engineering support to prototype development through final mass production. This one-stop design and manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001564590-19-004520:notes:4]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-19-004520:notes:5]
The Company operates on a 52 or 53 week year ending on the Monday nearest December 31. Fiscal 2018 and 2017 were 52 weeks ended on December 31, 2018 and January 1, 2018, respectively. Fiscal 2016 consisted of 53 weeks ended on January 2, 2017 with the additional week included in the fourth quarter. All references to years relate to fiscal years unless otherwise noted.

[0001564590-19-004520:notes:6]
Reclassifications

[0001564590-19-004520:notes:7]
Certain amounts in the prior period financial statements have been reclassified to conform to the presentation of the current period financial statements. These reclassifications had no effect on the previously reported net income. An adjustment has been made to combine the statutory surplus reserve with retained earnings on the consolidated balance sheets and the consolidated statements of stockholders’ equity.

[0001564590-19-004520:notes:8]
Use of Estimates

[0001564590-19-004520:notes:9]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amount of revenues and expenses during the reporting period. Such estimates include the sales return reserve; accounts receivable; inventories; goodwill; intangible assets and other long-lived assets; product warranty liabilities; legal contingencies; income taxes; pension obligations; and fair values of financial instruments. These estimates and assumptions are based on management’s best estimates and judgment. Management evaluates its estimates and assumptions on an ongoing basis using historical experience and other factors, including the economic environment, which management believes to be reasonable under the circumstances. Management adjusts such estimates and assumptions when facts and circumstances dictate. The actual results we experienced may differ materially and adversely from our estimates. To the extent there are material differences between the estimates and actual results, our future result of operations will be affected.

[0001564590-19-004520:notes:10]
Principles of Consolidation

[0001564590-19-004520:notes:11]
The consolidated financial statements include the accounts of TTM and its subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001564590-19-004520:notes:12]
Foreign Currency Translation and Transactions

[0001564590-19-004520:notes:13]
The functional currency of certain of the Company’s subsidiaries is the Chinese Renminbi (RMB). Accordingly, assets and liabilities are translated into U.S. dollars using period-end exchange rates. Sales and expenses are translated at the average exchange rates in effect during the period. The resulting translation gains or losses are recorded as a component of accumulated other comprehensive (loss) income in the consolidated statement of stockholders’ equity and the consolidated statement of comprehensive income (loss). Net gains and losses resulting from foreign currency remeasurements and transactions are included in income as a component of other, net in the consolidated statements of operations and totaled $3,529 gain, $22,802 loss and $13,538 gain for the years ended December 31, 2018, January 1, 2018 and January 2, 2017, respectively.

[0001564590-19-004520:notes:14]
Cash Equivalents

[0001564590-19-004520:notes:15]
The Company considers highly liquid investments with insignificant interest rate risk and original maturities to the Company of three months or less to be cash equivalents. Cash equivalents consist primarily of interest-bearing bank accounts.

[0001564590-19-004520:notes:16]
The Company considers highly liquid investments with an effective maturity to the Company of more than three months and less than one year to be short-term investments

[0001564590-19-004520:notes:17]
Accounts Receivable and Allowance for Doubtful Accounts

[0001564590-19-004520:notes:18]
Accounts receivable are reflected at estimated net realizable value, do not bear interest and do not generally require collateral. The Company performs credit evaluations of its customers and adjusts credit limits based upon payment history and the customer’s current creditworthiness. The Company maintains an allowance for doubtful accounts based upon a variety of factors. The Company reviews all open accounts and provides specific reserves for customer collection issues when it believes the loss is probable, considering such factors as the length of time receivables are past due, the financial condition of the customer, and historical experience. The Company also records a reserve for all customers, excluding those that have been specifically reserved for, based upon evaluation of historical losses.

[0001564590-19-004520:notes:19]
The following summarizes the activity in the Company’s allowance for doubtful accounts for the years ended December 31, 2018, January 1, 2018 and January 2, 2017:

[0001564590-19-004520:notes:20]
|  |  | For the Year Ended |  |
|  |  | December 31, |  |  | January 1, |  |  | January 2, |  |
|  |  | 2018 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 2,468 |  |  | $ | 2,851 |  |  | $ | 1,525 |  |
| Addition charged to expense |  |  | 429 |  |  |  | 346 |  |  |  | 1,560 |  |
| Deductions |  |  | (141 | ) |  |  | (719 | ) |  |  | (223 | ) |
| Effect of foreign currency exchange rates |  |  | (6 | ) |  |  | (10 | ) |  |  | (11 | ) |
| Balance at end of year |  | $ | 2,750 |  |  | $ | 2,468 |  |  | $ | 2,851 |  |

[0001564590-19-004520:notes:21]
Inventories

[0001564590-19-004520:notes:22]
Inventories are stated at the lower of cost (determined on a first-in, first-out and weighted average basis) or net realizable value. Assessments to value the inventory at the lower of the actual cost to purchase and / or manufacture the inventory, or net realizable value of the inventory, are based upon assumptions about future demand and market conditions. As a result of the Company’s assessments, when the net realizable value of inventory is less than the carrying value, the inventory cost is written down to the net realizable value and the write down is recorded as a charge to cost of goods sold.

[0001564590-19-004520:notes:23]
Property, Plant and Equipment, Net

[0001564590-19-004520:notes:24]
Property, plant and equipment are recorded at cost. Depreciation expense is computed using the straight-line method over the estimated useful lives of the assets. Assets recorded under leasehold improvements are amortized using the straight-line method over the lesser of their useful lives or the related lease term. The Company uses the following estimated useful lives:

[0001564590-19-004520:notes:25]
| Land use rights |  | 50-99 years |
| Buildings and improvements |  | 7-50 years |
| Machinery and equipment |  | 3-12 years |
| Furniture and fixtures |  | 3-7 years |

[0001564590-19-004520:notes:26]
Upon retirement or other disposition of property, plant and equipment, the cost and related accumulated depreciation are removed from the accounts. The resulting gain or loss is included in the determination of operating income in the period incurred. Depreciation and amortization expense on property, plant and equipment was $162,708, $150,809, and $156,229 for the years ended December 31, 2018, January 1, 2018 and January 2, 2017, respectively.

[0001564590-19-004520:notes:27]
The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is amortized over the average useful lives of such assets, which primarily consist of buildings and machinery and equipment. The Company capitalized interest costs of $1,438, $1,494 and $1,876 during the years ended December 31, 2018, January 1, 2018 and January 2, 2017, respectively, in connection with various capital projects.

[0001564590-19-004520:notes:28]
Major renewals and betterments are capitalized and depreciated over their estimated useful lives while minor expenditures for maintenance and repairs are included in operating income as incurred.

[0001564590-19-004520:notes:29]
Goodwill

[0001564590-19-004520:notes:30]
Goodwill represents the excess of purchase price of an acquisition over the fair value of net assets acquired. Goodwill is not amortized but instead is assessed for impairment, at a reporting unit level, annually and when events and circumstances warrant an evaluation. In making this assessment, management relies on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, business trends and declines in the Company’s market capitalization.

[0001564590-19-004520:notes:31]
The Company has two reportable segments consisting of PCB and E-M Solutions. There is goodwill only in the Company’s PCB reportable segment. Goodwill is allocated to reporting units, which are operating segments or one level below the Company’s operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic characteristics. The Company’s PCB reportable segment is made up of two operating segments that consist of five reporting units. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. The Company assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or performs its annual impairment test. When tested quantitatively, the Company compares the fair value of the applicable reporting unit with its carrying value. The Company estimates the fair values of its reporting units using a combination of the income and market approaches. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss. In the fourth quarter of 2018, the Company performed its annual impairment test quantitatively and concluded that goodwill was not impaired. See Note 6 for further details.

[0001564590-19-004520:notes:32]
Intangible Assets

[0001564590-19-004520:notes:33]
Intangible assets include customer relationships, technology, and backlog, which are being amortized over their estimated useful lives using straight-line and accelerated methods. The estimated useful lives of such intangibles range from 1 year to 13 years.

[0001564590-19-004520:notes:34]
Impairment of Long-lived Assets

[0001564590-19-004520:notes:35]
Long-lived tangible assets, including property, plant and equipment, assets held for sale, and definite-lived intangible assets, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of the asset or asset groups may not be recoverable. The Company regularly evaluates whether events or circumstances have occurred that indicate possible impairment and relies on a number of factors, including expected future operating results, business plans, economic projections, and anticipated future cash flows. The Company uses an estimate of the future undiscounted net cash flows of the related asset or asset group over the remaining life in measuring whether the assets are recoverable. Measurement of the amount of impairment, if any, is based upon the difference between the asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary. See Note 4 for information regarding the impairment of long-lived assets during 2016.

[0001564590-19-004520:notes:36]
The Company classifies assets to be sold as assets held for sale when (i) Company management has approved and commits to a plan to sell the asset; (ii) the asset is available for immediate sale in its present condition and is ready for sale; (iii) an active program to locate a buyer and other actions required to sell the asset have been initiated; (iv) the sale of the asset is probable; (v) the asset is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and (vi) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn. Assets classified as held for sale are recorded at the lower of the carrying amount or fair value less the cost to sell and are included as a component of prepaid expenses and other current assets in the consolidated balance sheet.

[0001564590-19-004520:notes:37]
The Company classifies assets held for use when a decision to dispose of an asset or a business is made and the held for sale criteria are not met. Assets of the business are evaluated for recoverability in the following order: (i) assets other than goodwill, property and intangibles; (ii) property and intangibles subject to amortization; and (iii) goodwill. In evaluating the recoverability of property and intangible assets subject to amortization, in a held for use business, the carrying value is first compared to the sum of the undiscounted cash flows expected to result from the use and eventual disposition. If the carrying value exceeds the undiscounted expected cash flows, then a fair value analysis is performed. An impairment charge is recognized if the carrying value exceeds the fair value.

[0001564590-19-004520:notes:38]
Revenue Recognition

[0001564590-19-004520:notes:39]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as the design and manufacture of RF and microwave components and assemblies. In the absence of a sales agreement, the Company’s standard terms and conditions apply. Revenue is recognized when control of the promised goods or services is transferred to the Company’s customers, in an amount that reflects the consideration to which it expects to be entitled in exchange for those goods or services. The Company applies a five-step approach as defined in the new standard in determining the amount and timing of revenue to be recognized: (1) identifying the contract with a customer; (2) identifying the performance obligations in the contract; (3) determining the transaction price; (4) allocating the transaction price to the performance obligations in the contract; and (5) recognizing revenue when the corresponding performance obligation is satisfied.

[0001564590-19-004520:notes:40]
Revenue Streams

[0001564590-19-004520:notes:41]
For the PCBs and custom electronic assemblies, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous control of the work in progress and finished goods throughout the PCB manufacturing process, as PCBs are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, beginning in the first quarter of 2018, the Company now recognizes revenue over time based on the extent of progress towards completion of the performance obligation. Revenue recognized under these contracts is based on the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

[0001564590-19-004520:notes:42]
Additionally, the Company has certain long-term contracts related to its manufacture of components, assemblies, and subsystems which service the aerospace and defense electronics market. These long-term contracts, many of which provide for periodic payments, are recognized over time under the percentage-of completion method. Estimated manufacturing cost-at-completion for these contracts are reviewed on a periodic basis, and adjustments are made as needed to the estimated cost-at-completion, based on actual costs incurred, progress made, and estimates of costs required to complete the contractual requirements. When the estimated manufacturing cost-at-completion exceeds the contract value, the contract is written down to its net realizable value and the loss resulting from the cost overruns are immediately recognized.

[0001564590-19-004520:notes:43]
Finally, the Company manufactures components, assemblies, and subsystems which service its wireless communications customers. The Company recognizes revenue at a point in time upon transfer of control of the products to the customer. Point in time recognition was determined as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

[0001564590-19-004520:notes:44]
Performance Obligations

[0001564590-19-004520:notes:45]
Each distinct promise to transfer products is considered to be an identified performance obligation for which revenue is recognized upon transfer of control of the products to the customer. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. As of December 31, 2018, the aggregate amount of the transaction price allocated to remaining performance obligations for our long-term contracts was $19,671. The Company expects to recognize revenue on approximately 64% of the remaining performance obligations for the Company’s long-term contracts over the next year with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year or less.

[0001564590-19-004520:notes:46]
Transaction Price

[0001564590-19-004520:notes:47]
The Company provides customers a limited right of return for defective PCBs including components, subsystems and assemblies. Estimates of returns are treated as variable consideration for purposes of determining the transaction price. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns. To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued expenses on the consolidated balance sheet. Shipping and handling fees and related freight costs and supplies associated with shipping products to customers are included as a component of cost of goods sold. Warranty-related services are not considered a separate performance obligation. Incremental warranty costs that are not related to sales returns are recorded in accrued expenses and cost of goods sold. The following summarizes the activity in the Company’s sales returns and allowances for the years ended December 31, 2018, January 1, 2018 and January 2, 2017:

[0001564590-19-004520:notes:48]
|  |  | For the Year Ended |  |
|  |  | December 31, |  |  | January 1, |  |  | January 2, |  |
|  |  | 2018 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 8,171 |  |  | $ | 8,119 |  |  | $ | 7,789 |  |
| Addition charged as a reduction of sales (1) |  |  | 23,525 |  |  |  | 14,574 |  |  |  | 22,060 |  |
| Deductions |  |  | (15,602 | ) |  |  | (14,524 | ) |  |  | (21,728 | ) |
| Effect of foreign currency exchange rates |  |  | (23 | ) |  |  | 2 |  |  |  | (2 | ) |
| Balance at end of year |  | $ | 16,071 |  |  | $ | 8,171 |  |  | $ | 8,119 |  |

[0001564590-19-004520:notes:49]
(1)As discussed in Note 2 to the consolidated financial statements, on the date of adopting the new revenue standard, the Company recorded an estimated sales returns and allowance in the amount of $5,213 as of January 2, 2018.

[0001564590-19-004520:notes:50]
Contract Balances

[0001564590-19-004520:notes:51]
Accounts receivable represents the Company’s unconditional right to receive consideration from its customer. Payments are generally due within 90 days or less of invoicing and do not include a significant financing component. To date, there have been no material impairment losses on accounts receivable.

[0001564590-19-004520:notes:52]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified as current assets and transferred to receivables when the entitlement to payment becomes unconditional. The Company’s contract assets are generally converted to trade account receivables within 90 days, at which time the Company is entitled to payment of the fixed price upon delivery of the finished product subject to customer payment terms. Contract assets were $287,741 as of December 31, 2018 and represent unbilled amounts for work performed to date. In 2018, there were no material impairment losses on contract assets. The contract assets increased by $23,585 due to the acquisition of Anaren, Inc. (Anaren) on April 18, 2018. There were no contract assets as of January 1, 2018.

[0001564590-19-004520:notes:53]
A contract liability is recognized when the Company has received payment in advance for the future transfer of goods or services. The Company’s contract liabilities are generally converted to revenue within 90 days. Contract liabilities were $3,220 as of December 31, 2018 and represent customer advances for work yet to be performed. There were no contract liabilities as of January 1, 2018.

[0001564590-19-004520:notes:54]
The Company has elected to account for shipping and handling activities as a fulfillment cost as permitted by the standard. All incremental customer contract acquisition costs are expensed as they are incurred as the amortization period of the asset that the Company otherwise would have recognized is one year or less in duration.

[0001564590-19-004520:notes:55]
Disaggregated Revenue

[0001564590-19-004520:notes:56]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively of the Company’s revenue in 2018. In 2017 and 2016, revenue from products and services transferred to customers was recognized at a point in time.

[0001564590-19-004520:notes:57]
The following tables represent a disaggregation of revenue by principal end markets with the reportable segments:

[0001564590-19-004520:notes:58]
|  |  | For the Year Ended December 31, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 625,494 |  |  | $ | 858 |  |  | $ | 626,352 |  |
| Automotive |  |  | 414,787 |  |  |  | 86,828 |  |  |  | 501,615 |  |
| Cellular Phone |  |  | 384,843 |  |  |  | — |  |  |  | 384,843 |  |
| Computing/Storage/Peripherals |  |  | 392,091 |  |  |  | 1,694 |  |  |  | 393,785 |  |
| Medical/Industrial/Instrumentation |  |  | 362,724 |  |  |  | 39,852 |  |  |  | 402,576 |  |
| Networking/Communications |  |  | 389,720 |  |  |  | 96,894 |  |  |  | 486,614 |  |
| Other |  |  | 51,655 |  |  |  | (179 | ) |  |  | 51,476 |  |
| Total |  | $ | 2,621,314 |  |  | $ | 225,947 |  |  | $ | 2,847,261 |  |

[0001564590-19-004520:notes:59]
|  |  | For the Year Ended January 1, 2018 (1) |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 418,238 |  |  | $ | 1,544 |  |  | $ | 419,782 |  |
| Automotive |  |  | 434,775 |  |  |  | 76,401 |  |  |  | 511,176 |  |
| Cellular Phone |  |  | 483,805 |  |  |  | — |  |  |  | 483,805 |  |
| Computing/Storage/Peripherals |  |  | 352,862 |  |  |  | 4,247 |  |  |  | 357,109 |  |
| Medical/Industrial/Instrumentation |  |  | 330,093 |  |  |  | 38,257 |  |  |  | 368,350 |  |
| Networking/Communications |  |  | 390,335 |  |  |  | 88,506 |  |  |  | 478,841 |  |
| Other |  |  | 38,398 |  |  |  | 1,131 |  |  |  | 39,529 |  |
| Total |  | $ | 2,448,506 |  |  | $ | 210,086 |  |  | $ | 2,658,592 |  |

[0001564590-19-004520:notes:60]
(1)As discussed in Note 2 to the consolidated financial statements, the Company adopted ASC Topic 606, Revenue from Contracts with Customers, under the modified retrospective method on January 2, 2018. Accordingly, the consolidated financial statements for the years ended January 1, 2018 and January 2, 2017 have not been adjusted.

[0001564590-19-004520:notes:61]
|  |  | For the Year Ended January 2, 2017 (1) |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 380,816 |  |  | $ | 450 |  |  | $ | 381,266 |  |
| Automotive |  |  | 449,813 |  |  |  | 44,221 |  |  |  | 494,034 |  |
| Cellular Phone |  |  | 360,816 |  |  |  | — |  |  |  | 360,816 |  |
| Computing/Storage/Peripherals |  |  | 303,807 |  |  |  | 11,145 |  |  |  | 314,952 |  |
| Medical/Industrial/Instrumentation |  |  | 327,701 |  |  |  | 38,928 |  |  |  | 366,629 |  |
| Networking/Communications |  |  | 474,300 |  |  |  | 97,812 |  |  |  | 572,112 |  |
| Other |  |  | 37,623 |  |  |  | 5,927 |  |  |  | 43,550 |  |
| Total |  | $ | 2,334,876 |  |  | $ | 198,483 |  |  | $ | 2,533,359 |  |

[0001564590-19-004520:notes:62]
Stock-Based Compensation

[0001564590-19-004520:notes:63]
The Company recognizes stock-based compensation expense in its consolidated financial statements for its incentive compensation plan awards. The incentive compensation plan awards include performance-based restricted stock units, restricted stock units, and stock options. The associated compensation expense for all awards is based on the grant date fair value of the awards, and for year 2016 include estimated forfeitures. For performance-based restricted stock units, compensation expense also includes management’s periodic assessment of annual financial performance goals to be achieved. Compensation expense for the incentive compensation plan awards is recognized on a straight line basis over the vesting period of the awards. The fair value of performance-based restricted stock units is estimated on the grant date using a Monte Carlo simulation model based on the underlying common stock closing price as of the date of grant, the expected term, stock price volatility, and risk-free interest rates. The fair value of restricted stock units is measured on the grant date based on the quoted closing market price of the Company’s common stock. The fair value of the stock options is estimated on the grant date using the Black-Scholes option pricing model based on the underlying common stock closing price as of the date of grant, the expected term, stock price volatility, and risk-free interest rates.

[0001564590-19-004520:notes:64]
Income Taxes

[0001564590-19-004520:notes:65]
Income taxes are accounted for under the asset and liability method. Deferred income tax assets or liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of assets and liabilities and their respective tax bases and operating loss and tax credit carryforwards. Deferred income tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be settled or realized. The effect on deferred income tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax assets are reviewed for recoverability, and the Company records a valuation allowance to reduce its deferred income tax assets when it is more likely than not that all or some portion of the deferred income tax assets will not be realized.

[0001564590-19-004520:notes:66]
The Company has various foreign subsidiaries formed or acquired to conduct or support its business outside the United States. The Company expects its earnings attributable to foreign subsidiaries will be indefinitely reinvested except for our material Chinese plants and the respective holding companies where a deferred tax liability has been recorded for foreign withholding and estimated federal/state tax impact. For those other companies with earnings currently being reinvested outside of the U.S., no deferred tax liabilities on undistributed earnings are recorded.

[0001564590-19-004520:notes:67]
The Company recognizes the effect of income tax positions only if those positions are more likely than not to be sustained. Recognized income tax positions are measured at the largest amount that is greater than 50 percent likely to be realized. Changes in recognition or measurement are reflected in the period in which the change in judgment occurs. Estimated interest and penalties related to underpayment of income taxes are recorded as a component of income tax provision in the consolidated statement of operations.

[0001564590-19-004520:notes:68]
Effects of the Tax Cuts and Jobs Act

[0001564590-19-004520:notes:69]
On December 22, 2017, the Tax Cuts and Jobs Act (Tax Act) was enacted. Accounting Standard Codification (ASC) Topic 740, Accounting for Income Taxes, requires companies to recognize the effect of tax law changes in the period of enactment regardless of the effective date of those tax law changes. Certain provisions of the Tax Act were effective September 27, 2017, December 31, 2017 and January 1, 2018.

[0001564590-19-004520:notes:70]
For the year ended January 1, 2018, the Company revalued its ending gross deferred tax items, previously recorded at 35 percent, using the enacted 21 percent corporate tax rate. This change caused a reduction to the Company’s U.S. federal deferred tax assets fully offset by a reduction of its valuation allowance.

[0001564590-19-004520:notes:71]
For the year ended January 1, 2018, the Company had performed a preliminary earnings and profits analysis with consideration given to foreign loss carryforwards acquired as a result of the Company’s acquisitions and determined on a provisional basis that there should be no income tax effect in the current or any future period. For the year ended December 31, 2018, the Company completed its analysis and maintains that there should be no income tax effect.

[0001564590-19-004520:notes:72]
The Company determined that the following provisions that are effective January 1, 2018 and relevant to the Company will impact the year ended December 31, 2018 tax expense: limitations on certain entertainment expenses, the inclusion of commissions and performance based compensation in determining the excessive compensation limitation, limitation on the current deductibility of net interest expense in excess of 30 percent of adjusted taxable income, and a minimum tax on certain foreign earnings in excess of 10 percent of the foreign subsidiaries tangible assets (i.e., global intangible low-taxed income or GILTI). The Company has decided to make a policy election to treat the GILTI tax as a period expense and as such, no U.S. deferred taxes will be calculated on foreign earnings that are expected to generate GILTI income when they reverse in future years.

[0001564590-19-004520:notes:73]
Convertible Debt

[0001564590-19-004520:notes:74]
The accounting standards for convertible debt instruments that may be fully or partially settled in cash upon conversion require the debt and equity components to be separately accounted for in a manner that reflects the Company’s nonconvertible borrowing rate when interest expense is recognized in subsequent periods. The amount recorded as debt is based on the fair value of the debt component as a standalone instrument, determined using an average interest rate for similar nonconvertible debt issued by entities with credit ratings comparable to the Company’s at the time of issuance. The difference between the debt recorded at inception and its principal amount is accreted to principal through interest expense during the estimated life of the note.

[0001564590-19-004520:notes:75]
Value Added and Sales Tax Collected from Customers

[0001564590-19-004520:notes:76]
As a part of the Company’s normal course of business, value added and sales taxes are collected from customers. Such taxes collected are remitted, in a timely manner, to the appropriate governmental tax authority on behalf of the customer. Value added and sales taxes are excluded from reported revenues and costs presented in the consolidated statements of operations and comprehensive income (loss).

[0001564590-19-004520:notes:77]
Fair Value Measures

[0001564590-19-004520:notes:78]
The Company measures at fair value certain of its financial and non-financial assets and liabilities by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability. The levels of the fair value hierarchy are:

[0001564590-19-004520:notes:79]
Level 1 — Quoted market prices in active markets for identical assets or liabilities;

[0001564590-19-004520:notes:80]
Level 2 — Significant other observable inputs (e.g., quoted prices for similar items in active markets, quoted prices for identical or similar items in markets that are not active, inputs other than quoted prices that are observable, such as interest rate and yield curves, and market-corroborated inputs); and

[0001564590-19-004520:notes:81]
Level 3 — Unobservable inputs in which there is little or no market data, which require the reporting unit to develop its own assumptions.

[0001564590-19-004520:notes:82]
Earnings Per Share

[0001564590-19-004520:notes:83]
Basic earnings per common share excludes dilution and is computed by dividing net income attributable to TTM Technologies, Inc. stockholders by the weighted average number of common shares outstanding during the period. Diluted earnings per common share reflect the potential dilution that could occur if stock options, convertible senior notes or other common stock equivalents were exercised or converted into common stock. The dilutive effect of stock options or other common stock equivalents is calculated using the treasury stock method, while the dilutive effect of convertible senior notes is calculated using the if-converted method.

[0001564590-19-004520:notes:84]
Comprehensive Income

[0001564590-19-004520:notes:85]
Comprehensive income includes changes to equity accounts that were not the result of transactions with stockholders. Comprehensive income is comprised of net income (loss), changes in the cumulative foreign currency translation adjustments, pension obligation adjustments, and realized and unrealized gains or losses on hedged derivative instruments.

[0001564590-19-004520:notes:86]
Noncontrolling Interest Holdings

[0001564590-19-004520:notes:87]
Noncontrolling interest consisted of a 5% equity interest in a manufacturing facility in Huiyang, China which was acquired along with other assets and liabilities of Viasystems Group Inc. (Viasystems). In 2017, the Company purchased the 5% equity interest from the noncontrolling interest holder. See Note 21.

[0001564590-19-004520:notes:88]
Loss Contingencies

[0001564590-19-004520:notes:89]
The Company establishes an accrual for an estimated loss contingency when it is both probable that an asset has been impaired or that a liability has been incurred and the amount of the loss can be reasonably estimated. Any legal fees expected to be incurred in connection with a contingency are expensed as incurred.

[0001564590-19-004520:notes:90]
Accounting for Retirement Benefit Plans

[0001564590-19-004520:notes:91]
The Company accounts for its retirement benefit plans and postretirement and postemployment benefit obligations in accordance with ASC Topic 715, Compensation—Retirement Benefits. ASC Topic 715 requires the Company to recognize the overfunded or underfunded status of a defined benefit plan, measured as the difference between the fair value of plan assets and the plan's benefit obligation, as an asset or liability in its consolidated balance sheet and to recognize changes to that funded status in the year in which the changes occur through accumulated other comprehensive loss. ASC Topic 715 also requires measurement of the funded status of a plan as of the Company's consolidated balance sheet dates.

[0001564590-19-004520:notes:92]
Recently Adopted and Issued Accounting Standards

[0001564590-19-004520:notes:93]
Recently Adopted Accounting Standards

[0001564590-19-004520:notes:94]
In August 2018, the Financial Accounting Standards Board (FASB) issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework. The updated guidance changes the disclosure requirements on fair value measurements. The updated guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted for any removed or modified disclosures. The Company early adopted the removed or modified disclosures in the fourth quarter of fiscal 2018 and is currently assessing the timing and impact of adopting the updated provisions.

[0001564590-19-004520:notes:95]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (Topic 718): Scope of Modification Accounting. This ASU provides guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting per Topic 718. The Company adopted ASU 2017-09 on January 2, 2018. The adoption did not have a material impact on the consolidated financial statements or related disclosures.

[0001564590-19-004520:notes:96]
In March 2017, the FASB issued ASU 2017-07, Compensation—Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost. ASU 2017-07 requires that an employer report the service cost component in the same line item or items as other compensation costs arising from services rendered by the pertinent employees during the period. The other components of net benefit cost are required to be presented in the income statement separately from the service cost component and outside a subtotal of income from operations, if one is presented. If a separate line item or items are not used, the line item or items used in the income statement to present the other components of net benefit cost must be disclosed. The Company adopted ASU 2017-07 on January 2, 2018. The adoption did not have a material impact on the consolidated financial statements or related disclosures.

[0001564590-19-004520:notes:97]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business. This ASU clarifies the definition of a business to exclude gross assets acquired (or disposed of) that have substantially all of their fair value concentrated in a single identifiable asset or group of similar identifiable assets. The ASU also updates the definition of the term “output” to be consistent with ASC Topic 606. The Company adopted ASU 2017-01 on January 2, 2018. The adoption did not have a material impact on the consolidated financial statements or related disclosures.

[0001564590-19-004520:notes:98]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory. The objective of this update is to improve the accounting for the income tax consequences of intra-entity transfers of assets other than inventory by recognizing the income tax consequences when the transfer occurs. The Company adopted ASU 2016-16 on January 2, 2018. The adoption did not have a material impact on the consolidated financial statements or related disclosures.

[0001564590-19-004520:notes:99]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments—Overall (Topic 825): Recognition and Measurement of Financial Assets and Financial Liabilities. This ASU amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments, and supersedes the guidance to classify equity securities with readily determinable fair values into different categories (that is, trading or available-for-sale) and requires equity securities to be measured at fair value with changes in the fair value recognized through net income. The Company adopted ASU 2016-01 on January 2, 2018. The adoption did not have a material impact on the consolidated financial statements or related disclosures.

[0001564590-19-004520:notes:100]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). Topic 606 supersedes the revenue recognition requirements in Revenue Recognition (Topic 605), and requires entities to recognize revenues when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the entity expects to be entitled to in exchange for those goods or services. The Company adopted Topic 606 as of January 2, 2018 using the modified retrospective transition method. See Note 2 for further details of the change in accounting principle.

[0001564590-19-004520:notes:101]
Recently Issued Accounting Standards Not Yet Adopted

[0001564590-19-004520:notes:102]
In June 2018, the FASB issued ASU 2018-07, Compensation-Stock Compensation (Topic 718): Improvements to Nonemployee Share-based Payments. This ASU expands the scope of Topic 718 to include share-based payment transactions for acquiring goods and services from nonemployees. The effective date for the standard is for interim periods in fiscal years beginning after December 15, 2018, with early adoption permitted, but no earlier than the Company's adoption date of Topic 606. The new guidance is required to be applied retrospectively with the cumulative effect recognized at the date of initial application. The Company does not anticipate the adoption will have a material impact on the consolidated financial statements and related disclosures.

[0001564590-19-004520:notes:103]
In February 2018, the FASB issued ASU 2018-02, Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. ASU 2018-02 allows a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the 2017 Act. Consequently, the amendments eliminate the stranded tax effects resulting from the 2017 Act and will improve the usefulness of information reported to financial statement users. However, because the amendments only relate to the reclassification of the income tax effects of the 2017 Act, the underlying guidance that requires that the effect of a change in tax laws or rates be included in income from continuing operations is not affected. The amendments in this update also require certain disclosures about stranded tax effects. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on the consolidated financial statements and related disclosures.

[0001564590-19-004520:notes:104]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.

[0001564590-19-004520:notes:105]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) which supersedes the existing lease recognition requirements in the current accounting standard for leases. The core principal of the new standard is that an entity should recognize right-of-use (ROU) assets and lease liabilities arising from a lease for both financing and operating leases, along with additional qualitative and quantitative disclosures. The new standard is to be applied using a modified retrospective transition method with the option to elect a number of practical expedients. The new standard will be effective for fiscal years beginning after December 15, 2018, including interim periods within such fiscal years.

[0001564590-19-004520:notes:106]
In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements. ASU 2018-11 provides additional guidance to Topic 842 including providing preparers an additional optional retrospective adoption method which allows entities to initially apply the new leases standard at the adoption date and recognize a cumulative effect adjustment to the opening balance of retained earnings. ASU 2018-11 also provides lessors a practical expedient to not separate lease from non-lease components, in certain situations.

[0001564590-19-004520:notes:107]
The Company will adopt the new lease standard as of January 1, 2019 and plan to utilize the retrospective cumulative effect adjustment transition method with a cumulative effect adjustment being recorded as of the adoption date. The Company expects to elect certain available practical expedients including the package of practical expedients permitted under the transition guidance within the new standard, which among other things, will allow the Company to carry forward the historical lease classification. Additionally, the Company will make an accounting policy election to not record ROU assets and lease liabilities for leases with an initial term of twelve months or less on its consolidated balance sheet.

[0001564590-19-004520:notes:108]
The Company have established a cross-functional implementation team and are in the process of finalizing the scope of arrangements that will be subject to this standard as well as assessing the impact to the Company’s systems, processes, and internal controls over financial reporting. While the Company is still evaluating the impact of adopting ASU 2016-02, the Company anticipate this standard will have a material impact on the consolidated balance sheet. The primary impact will be to record ROU assets and lease liabilities for existing operating leases on the consolidated balance sheets. Currently, the Company estimates the adoption of the standard will result in the recognition of additional ROU assets and lease liabilities that are not anticipated to be greater than the Company’s future minimum lease payments (see Note 14), as of January 1, 2019.

[0001564590-19-004520:notes:109]
The Company do not expect the adoption to have a material impact on its consolidated statements of operations or its consolidated statements of cash flows. The Company do not believe the standard will have a notable impact on its liquidity. The standard will have no impact on the Company’s debt covenant compliance under its current agreements. The Company’s analysis and evaluation of the new standard will continue through its effective date in the first quarter of 2019, including continuing to monitor any potential changes in the standard proposed by the FASB.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-004520:notes:110]
| (2) | Revenues |

[0001564590-19-004520:notes:111]
The Company assessed the new guidance provided by ASU 2014-09 and adopted the new revenue standard on January 2, 2018, which resulted in a change to the timing of revenue recognition for certain of the Company’s revenue streams from point in time upon physical delivery to an over time model. Additionally, the Company elected the cumulative effect transition method with adjustment to the opening balance of retained earnings at January 2, 2018 for all open contracts as of January 1, 2018. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet at January 1, 2018 and the consolidated statement of operations for the years ended January 1, 2018 and January 2, 2017.

[0001564590-19-004520:notes:112]
The cumulative effect of the changes made to the Company’s January 2, 2018 consolidated balance sheet for the adoption of the new revenue standard was as follows:

[0001564590-19-004520:notes:113]
|  |  | Balance at January 1, 2018 |  |  | New Revenue Standard Adjustment |  |  | Balance at January 2, 2018 |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 483,903 |  |  | $ | 8,171 |  |  | $ | 492,074 |  |
| Contract assets |  |  | — |  |  |  | 260,654 |  |  |  | 260,654 |  |
| Inventories |  |  | 294,588 |  |  |  | (223,576 | ) |  |  | 71,012 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 114,685 |  |  |  | 13,384 |  |  |  | 128,069 |  |
| Other long-term liabilities |  |  | 74,667 |  |  |  | 3,291 |  |  |  | 77,958 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 230,850 |  |  |  | 28,574 |  |  |  | 259,424 |  |

[0001564590-19-004520:notes:114]
The adoption of ASC Topic 606 resulted in the establishment of a contract asset balance sheet account and in the reclassification from inventories to contract assets related to certain customer contracts requiring an over time method of revenue recognition. On the date of adopting the new revenue standard, the Company recorded an estimated sales returns and allowance as well as a noncurrent deferred tax liability in the amount of $5,213 and $3,291, respectively, as of January 2, 2018. Additionally, the Company reclassified its sales returns and allowance balance of $8,171 as of January 1, 2018, from trade accounts receivable to other accrued expenses. Sales returns and allowances are recorded as a reduction of revenue and a component of accrued expenses on the consolidated balance sheet.

[0001564590-19-004520:notes:115]
The disclosure below summarizes the impact of the adoption of the new revenue standard on the Company’s consolidated balance sheet as of December 31, 2018 and statement of operations for the year ended December 31, 2018 for which the As Reported reflects the new revenue standard and Balances without New Revenue Standard Adjustment reflects the Company’s replaced revenue recognition policy of point in time and upon physical delivery, for certain revenue streams, as appropriate.

[0001564590-19-004520:notes:116]
|  |  | As of December 31, 2018 |  |
|  |  | As Reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 523,165 |  |  | $ | 10,492 |  |  | $ | 512,673 |  |
| Contract assets |  |  | 287,741 |  |  |  | 278,935 |  |  |  | 8,806 |  |
| Inventories |  |  | 109,377 |  |  |  | (232,473 | ) |  |  | 341,850 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 113,756 |  |  |  | 18,893 |  |  |  | 94,863 |  |
| Other long-term liabilities |  |  | 94,777 |  |  |  | 1,619 |  |  |  | 93,158 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 433,008 |  |  |  | 36,442 |  |  |  | 396,566 |  |

[0001564590-19-004520:notes:117]
|  |  | For the Year Ended December 31, 2018 |  |
|  |  | As Reported |  |  | Effect of Change Increase |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Net sales |  | $ | 2,847,261 |  |  | $ | 17,915 |  |  | $ | 2,829,346 |  |
| Cost of goods sold |  |  | 2,390,227 |  |  |  | 8,897 |  |  |  | 2,381,330 |  |
| Gross profit |  |  | 457,034 |  |  |  | 9,018 |  |  |  | 448,016 |  |
| Net income |  |  | 173,584 |  |  |  | 7,868 |  |  |  | 165,716 |  |

[0001564590-19-004520:notes:118]
Included in the Effect of Change Increase column for the year ended December 31, 2018 are $14,408, $11,375 and $3,033 of net sales, cost of goods sold and gross profit, respectively, related to the opening balance sheet of Anaren which was acquired on April 18, 2018 (See Note 3), and not to the activity during the year ended December 31, 2018.

[0001564590-19-004520:notes:119]
The adoption of the new accounting guidance had no impact to net cash provided by (used in) operating, financing or investing activities on the consolidated statement of cash flows for the year ended December 31, 2018.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-19-004520:notes:120]
| (3) | Acquisition of Anaren, Inc. |

[0001564590-19-004520:notes:121]
On April 18, 2018, the Company acquired all of the equity interests of Anaren for a total consideration of $787,911. Anaren was a leading provider of mission-critical RF solutions, microelectronics, and microwave components and assemblies for the wireless infrastructure and aerospace and defense electronics markets.

[0001564590-19-004520:notes:122]
As of December 31, 2018, bank fees and legal, accounting, and other professional service costs associated with the acquisition of Anaren totaling $14,008 have been expensed and recorded as general and administrative expense in the consolidated statements of operations.

[0001564590-19-004520:notes:123]
The following summarizes the components of the purchase price:

[0001564590-19-004520:notes:124]
|  |  | (In thousands) |  |
| Cash consideration |  | $ | 596,396 |  |
| Cash purchased |  |  | 12,911 |  |
|  |  |  | 609,307 |  |
| Debt assumed |  |  | 178,604 |  |
| Total consideration |  | $ | 787,911 |  |

[0001564590-19-004520:notes:125]
Purchase Price Allocation

[0001564590-19-004520:notes:126]
The purchase price of the Anaren acquisition was allocated to tangible and intangible assets acquired, and liabilities assumed based on the fair value at the date of the acquisition, April 18, 2018. The excess of the purchase price over the fair value of net assets acquired was allocated to goodwill. The fair value assigned to identifiable intangible assets acquired was based on estimates and assumptions made by management at the time of the acquisition. As of December 31, 2018, the Company has finalized the allocation of the purchase price.

[0001564590-19-004520:notes:127]
The fair values assigned are based on reasonable methods applicable to the nature of the assets acquired and liabilities assumed. The following summarizes the final estimated fair values of net assets acquired:

[0001564590-19-004520:notes:128]
|  |  | (In thousands) |  |
| Cash |  | $ | 12,911 |  |
| Trade and notes receivables |  |  | 32,457 |  |
| Contract assets |  |  | 23,585 |  |
| Inventories |  |  | 56,619 |  |
| Other current assets |  |  | 1,373 |  |
| Property, plant and equipment |  |  | 45,115 |  |
| Identifiable intangible assets |  |  | 336,000 |  |
| Other assets |  |  | 300 |  |
| Goodwill |  |  | 394,474 |  |
| Trade accounts payable |  |  | (14,623 | ) |
| Contract liabilities |  |  | (7,778 | ) |
| Other current liabilities |  |  | (7,616 | ) |
| Long-term debt |  |  | (178,604 | ) |
| Non-current deferred tax liabilities |  |  | (76,470 | ) |
| Other liabilities |  |  | (8,436 | ) |
| Total |  | $ | 609,307 |  |

[0001564590-19-004520:notes:129]
The Company acquired $56,619 of inventories as a result of the acquisition. Finished goods were valued at estimated selling prices less costs of disposal and a reasonable profit for the selling effort. Work-in-process inventory was valued at estimated selling prices less costs to complete, costs of disposal and a reasonable profit allowance for the completion and selling effort. Raw materials were valued at estimated replacement cost.

[0001564590-19-004520:notes:130]
Property, Plant and Equipment

[0001564590-19-004520:notes:131]
The fair value of property, plant and equipment was determined by utilizing three approaches: the cost, sales comparison, and income capitalization approaches, each including management assumptions. Each approach assumes valuation of the property at the property’s highest and best use.

[0001564590-19-004520:notes:132]
Identifiable Intangible Assets

[0001564590-19-004520:notes:133]
Acquired identifiable intangible assets include customer relationships, developed technology and backlog. The fair value of the identifiable intangible assets was determined using various valuation methods including relief from royalty and excess earnings to determine the present value of expected future cash flows for each identifiable intangible asset based on discount rates which incorporate a risk premium to take into account the risks inherent in those expected cash flows. The expected cash flows were estimated using available historical data adjusted based on a market participant perspective. The Company used risk adjusted discount rates between 4.5% and 17.0% to discount the expected future cash flows. The fair value assigned to each class of intangible assets and the related weighted average amortization periods are as follows:

[0001564590-19-004520:notes:134]
|  |  | Estimated Fair Value |  |  | Weighted Average Amortization Period |
|  |  | (In thousands) |  |  | (years) |
| Customer relationships |  | $ | 267,500 |  |  | 12.2 years |
| Developed technology |  |  | 39,500 |  |  | 9.4 years |
| Backlog |  |  | 29,000 |  |  | 0.9 years |
|  |  | $ | 336,000 |  |  |  |

[0001564590-19-004520:notes:135]
Goodwill represents the excess of the purchase price over the fair value of assets acquired and liabilities assumed.

[0001564590-19-004520:notes:136]
The Company has two reportable segments: PCB and E-M Solutions and has integrated Anaren into the PCB reportable segment. The excess purchase price over the fair value of assets acquired and liabilities assumed has been completely allocated to the PCB reportable segment.

[0001564590-19-004520:notes:137]
The Company believes that the acquisition of Anaren will produce the following significant benefits:

[0001564590-19-004520:notes:138]
|  | • | Provide the Company with differentiated RF expertise in aerospace and defense and embedded technology that the Company believes is critical to wireless infrastructure markets. |

[0001564590-19-004520:notes:139]
|  | • | Augment the Company’s strong aerospace and defense position and provide new opportunities for growth in the automotive and optical networking market. |

[0001564590-19-004520:notes:140]
|  | • | Deepen the Company’s engagement and interaction with leading customers in the aerospace and defense and wireless communication infrastructure markets. |

[0001564590-19-004520:notes:141]
|  | • | Strengthen the Company’s management and engineering teams with the addition of talented members having extensive experience in RF design; |

[0001564590-19-004520:notes:142]
The Company believes that these primary factors support the amount of goodwill recognized as a result of the purchase price paid for Anaren, in relation to other acquired tangible and intangible assets. The goodwill acquired in the acquisition is not deductible for income tax purposes.

[0001564590-19-004520:notes:143]
Results of Operations

[0001564590-19-004520:notes:144]
The results of operations of Anaren have been included in the Company’s consolidated statement of operations since April 18, 2018 which for 2018 resulted in additional net sales of $191,009. Pre-tax net income included in the consolidated statement of operations from the Anaren operations for the year ended December 31, 2018 have not been reported as it is impracticable to do so given the integration and other efficiency and cost saving measures that occurred during the year ended December 31, 2018.

[0001564590-19-004520:notes:145]
Pro forma Financial Information (unaudited)

[0001564590-19-004520:notes:146]
The unaudited pro forma financial information below gives effect to this acquisition as if it had occurred at the beginning of fiscal 2017, or January 3, 2017. The pro forma financial information presented includes the effects of adjustments related to the amortization of acquired identifiable intangible assets and acquired inventory, depreciation of acquired fixed assets, and other non-recurring transactions costs directly associated with the acquisition such as legal, accounting and banking fees.

[0001564590-19-004520:notes:147]
The pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the actual results that would have been achieved had the acquisition occurred at the beginning of the earliest period presented, or the results that may be achieved in future periods.

[0001564590-19-004520:notes:148]
|  |  | For the Year Ended |  |
|  |  | December 31, |  |  | January 1, |  |
|  |  | 2018 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Net sales |  | $ | 2,915,935 |  |  | $ | 2,892,192 |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  |  | 190,198 |  |  |  | 106,881 |  |
| Basic earnings per share |  | $ | 1.84 |  |  | $ | 1.05 |  |
| Dilutive earnings per share |  | $ | 1.51 |  |  | $ | 0.91 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001564590-19-004520:notes:149]
| (4) | Restructuring and Impairment Charges |

[0001564590-19-004520:notes:150]
Following the acquisition of Anaren on April 18, 2018 and following the acquisition of Viasystems on May 31, 2015, the Company incurred employee separation costs and contract termination and other costs related to the integration and other efficiency and cost saving measures. Contract termination and other costs primarily represented plant closure costs as well as costs related to building operating leases. Following the acquisition of Viasystems on May 31, 2015, the Company closed certain facilities which resulted in the layoff of related employees at these facilities. The acquisitions of Anaren and Viasystems were part of the Company’s integration strategy to improve total plant utilization, operational performance and customer focus.

[0001564590-19-004520:notes:151]
The below table summarizes such restructuring costs by reportable segment for the years ended December 31, 2018, January 1, 2018 and January 2, 2017:

[0001564590-19-004520:notes:152]
|  |  | For the Year Ended |  |
|  |  | December 31, 2018 |  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 2,008 |  |  | $ | — |  |  | $ | 2,008 |  |  | $ | 178 |  |  | $ | 99 |  |  | $ | 277 |  |  | $ | 1,548 |  |  | $ | 2,141 |  |  | $ | 3,689 |  |
| E-M Solutions |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 520 |  |  |  | 520 |  |  |  | 903 |  |  |  | 3,644 |  |  |  | 4,547 |  |
| Corporate |  |  | 3,389 |  |  |  | 121 |  |  |  | 3,510 |  |  |  | 33 |  |  |  | 360 |  |  |  | 393 |  |  |  | (231 | ) |  |  | 946 |  |  |  | 715 |  |
|  |  | $ | 5,397 |  |  | $ | 121 |  |  | $ | 5,518 |  |  | $ | 211 |  |  | $ | 979 |  |  | $ | 1,190 |  |  | $ | 2,220 |  |  | $ | 6,731 |  |  | $ | 8,951 |  |

[0001564590-19-004520:notes:153]
The below table shows the utilization of the accrued restructuring costs during the years ended December 31, 2018 and January 1, 2018:

[0001564590-19-004520:notes:154]
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued at January 2, 2017 |  | $ | 124 |  |  | $ | 1,042 |  |  | $ | 1,166 |  |
| Charged to expense |  |  | 211 |  |  |  | 979 |  |  |  | 1,190 |  |
| Amount paid |  |  | (335 | ) |  |  | (1,522 | ) |  |  | (1,857 | ) |
| Accrued at January 1, 2018 |  | $ | — |  |  | $ | 499 |  |  | $ | 499 |  |
| Charged to expense |  |  | 5,397 |  |  |  | 121 |  |  |  | 5,518 |  |
| Amount paid |  |  | (2,239 | ) |  |  | (227 | ) |  |  | (2,466 | ) |
| Accrued at December 31, 2018 |  | $ | 3,158 |  |  | $ | 393 |  |  | $ | 3,551 |  |

[0001564590-19-004520:notes:155]
As of December 31, 2018, the Company incurred approximately $23,040 of restructuring charges since the inception of the restructuring plans.

[0001564590-19-004520:notes:156]
Additionally, the Company recognized $3,346 in impairment charges during the year ended January 2, 2017. As a result of the above mentioned plant closures and other plant realignment efforts, $1,393 of impairment charges were recognized in the consolidated statement of operations related to machinery and equipment in the PCB reportable segment. In addition, $1,953 of impairment charges were recognized in the consolidated statement of operations related to capitalized software costs in Corporate.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-19-004520:notes:157]
| (5) | Composition of Certain Consolidated Financial Statement Captions |

[0001564590-19-004520:notes:158]
|  |  | As of |  |
|  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 97,600 |  |  | $ | 75,835 |  |
| Work-in-process |  |  | 10,299 |  |  |  | 120,031 |  |
| Finished goods |  |  | 1,478 |  |  |  | 98,722 |  |
|  |  | $ | 109,377 |  |  | $ | 294,588 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 75,431 |  |  | $ | 70,681 |  |
| Buildings and improvements |  |  | 534,122 |  |  |  | 506,394 |  |
| Machinery and equipment |  |  | 1,357,035 |  |  |  | 1,243,456 |  |
| Construction-in-progress, furniture and fixtures and other |  |  | 42,713 |  |  |  | 51,865 |  |
|  |  |  | 2,009,301 |  |  |  | 1,872,396 |  |
| Less: Accumulated depreciation |  |  | (957,277 | ) |  |  | (815,551 | ) |
|  |  | $ | 1,052,024 |  |  | $ | 1,056,845 |  |
| Other accrued expenses: |  |  |  |  |  |  |  |  |
| Interest |  | $ | 9,260 |  |  | $ | 6,297 |  |
| Restructuring |  |  | 3,551 |  |  |  | 499 |  |
| Income taxes payable |  |  | 11,345 |  |  |  | 21,993 |  |
| Other |  |  | 89,600 |  |  |  | 85,896 |  |
|  |  | $ | 113,756 |  |  | $ | 114,685 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-19-004520:notes:159]
| (6) | Goodwill |

[0001564590-19-004520:notes:160]
As of December 31, 2018 and January 1, 2018, goodwill was as follows:

[0001564590-19-004520:notes:161]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 2, 2017 |  |  |  |  |
| Goodwill |  | $ | 544,009 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  |  | 372,609 |  |
| Foreign currency translation adjustment |  |  | (38 | ) |
| Balance as of January 1, 2018 |  |  |  |  |
| Goodwill |  |  | 543,971 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  |  | 372,571 |  |
| Goodwill recognized during the year |  |  | 394,474 |  |
| Balance as of December 31, 2018 |  |  |  |  |
| Goodwill |  |  | 938,445 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  | $ | 767,045 |  |

[0001564590-19-004520:notes:162]
Goodwill balances include foreign currency translation adjustments related to foreign subsidiaries with functional currencies other than the U.S. Dollar. All of the Company’s goodwill is included as a component of the PCB reportable segment.

[0001564590-19-004520:notes:163]
During the fourth quarter of 2018, the Company performed its annual goodwill impairment test quantitatively, which was based on a combination of the income approach utilizing discounted cash flow analysis and the market approach, and concluded that the goodwill was not impaired for the Company’s reporting units. The Company will continue to evaluate its goodwill on an annual basis during its fourth fiscal quarter and whenever events or changes in circumstances — such as significant adverse changes in business climate or operating results, changes in management strategy, coupled with a decline in the market price of our stock and market capitalization — indicate that there may be a potential impairment.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-19-004520:notes:164]
| (7) | Definite-lived Intangibles |

[0001564590-19-004520:notes:165]
As of December 31, 2018 and January 1, 2018, the components of definite-lived intangibles were as follows:

[0001564590-19-004520:notes:166]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,634 |  |  | $ | (123,522 | ) |  | $ | — |  |  | $ | 80,112 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (3,000 | ) |  |  | — |  |  |  | — |  |  |  | 3.0 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 267,500 |  |  |  | (15,561 | ) |  |  | — |  |  |  | 251,939 |  |  |  | 12.2 |  |
| Developed technology |  |  | 39,500 |  |  |  | (3,345 | ) |  |  | — |  |  |  | 36,155 |  |  |  | 9.4 |  |
| Backlog |  |  | 29,000 |  |  |  | (21,283 | ) |  |  | — |  |  |  | 7,717 |  |  |  | 0.9 |  |
|  |  | $ | 542,634 |  |  | $ | (166,711 | ) |  | $ | — |  |  | $ | 375,923 |  |  |  |  |  |
| January 1, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (101,089 | ) |  | $ | 72 |  |  | $ | 102,546 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (2,596 | ) |  |  | — |  |  |  | 404 |  |  |  | 3.0 |  |
|  |  | $ | 206,563 |  |  | $ | (103,685 | ) |  | $ | 72 |  |  | $ | 102,950 |  |  |  |  |  |

[0001564590-19-004520:notes:167]
The January 1, 2018 definite-lived intangible balances include foreign currency translation adjustments related to foreign subsidiaries with functional currencies other than the U.S. Dollar.

[0001564590-19-004520:notes:168]
Definite-lived intangibles are generally amortized using the straight-line method of amortization over the useful life, with the exception of certain customer relationship intangibles, which are amortized using an accelerated method of amortization based on estimated cash flows. Amortization expense was $63,026, $23,634, and $24,252 for the years ended December 31, 2018, January 1, 2018 and January 2, 2017, respectively. For the year ended December 31, 2018, $3,345 of amortization expense is included in cost of goods sold.

[0001564590-19-004520:notes:169]
Estimated aggregate amortization for definite-lived intangible assets for the next five years and thereafter is as follows:

[0001564590-19-004520:notes:170]
|  |  | (In thousands) |  |
| 2019 |  | $ | 53,161 |  |
| 2020 |  |  | 45,419 |  |
| 2021 |  |  | 42,108 |  |
| 2022 |  |  | 39,002 |  |
| 2023 |  |  | 36,290 |  |
| Thereafter |  |  | 159,943 |  |
|  |  | $ | 375,923 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-19-004520:notes:171]
| (8) | Long-term Debt and Letters of Credit |

[0001564590-19-004520:notes:172]
The following table summarizes the long-term debt of the Company as of December 31, 2018 and January 1, 2018:

[0001564590-19-004520:notes:173]
|  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 5.00% |  |  | $ | 835,879 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 4.00% |  |  |  | 40,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.90% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  |  | — |  |  |  | — |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,530,864 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (22,167 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (16,272 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 1,492,425 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (30,000 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,462,425 |  |  |  |  |  |  | $ | 975,479 |  |

[0001564590-19-004520:notes:174]
The fiscal calendar maturities of long-term debt through 2023 and thereafter are as follows:

[0001564590-19-004520:notes:175]
|  |  | (In thousands) |  |
| 2019 |  | $ | 30,000 |  |
| 2020 |  |  | 319,985 |  |
| 2021 |  |  | — |  |
| 2022 |  |  | — |  |
| 2023 |  |  | — |  |
| Thereafter |  |  | 1,180,879 |  |
|  |  | $ | 1,530,864 |  |

[0001564590-19-004520:notes:176]
Term Loan Facility

[0001564590-19-004520:notes:177]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. As of December 31, 2018, the Term Loan Facility had an outstanding balance of $835,879, of which $30,000 is included in short-term debt and $805,879 is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR, plus an applicable interest margin of 2.50%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At December 31, 2018 the interest rate on the outstanding borrowings under the Term Loan Facility was 5.00%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-19-004520:notes:178]
During 2018, after the closing of its April 18, 2018 incremental loans facility, the Company made a $2,371 quarterly scheduled principal payment and $110,000 optional debt principal prepayments. Subsequent to December 31, 2018, the Company made an optional debt principal prepayment of $30,000. As a result of the principal prepayments, the Company is no longer required to make any quarterly scheduled payments. However, based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018. For 2019, the Company is not required to make an additional principal payment as its First Lien Leverage Ratio was less than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0001564590-19-004520:notes:179]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

[0001564590-19-004520:notes:180]
Senior Notes

[0001564590-19-004520:notes:181]
The $375,000 of Senior Notes issued, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

[0001564590-19-004520:notes:182]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

[0001564590-19-004520:notes:183]
Convertible Senior Notes due 2020

[0001564590-19-004520:notes:184]
The Company maintains 1.75% convertible senior notes in the amount of $249,985 due December 15, 2020. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are unsecured obligations and would rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness.

[0001564590-19-004520:notes:185]
Conversion:  At any time prior to March 15, 2020, holders may convert their convertible senior notes into cash and, if applicable, into shares of the Company’s common stock based on a conversion rate of 103.7613 shares of the Company’s common stock per $1 principal amount of convertible senior notes, subject to adjustment, under the following circumstances: (1) during any calendar quarter beginning after March 31, 2015 (and only during such calendar quarter), if the last reported sale price of our common stock for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day of such preceding calendar quarter; (2) during the five business day period after any 10 consecutive trading day period in which the trading price per note for each day of that 10 consecutive trading day period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate on such day; or (3) upon the occurrence of specified corporate transactions described in the indenture governing the notes. In 2018, the conversion criteria had been met allowing holders to give notice of conversion during the year. However, as of December 31, 2018, the conversion criteria that would allow holders to give notice of conversion in the first quarter of 2019 had not been met.

[0001564590-19-004520:notes:186]
On or after March 15, 2020 until the close of business on the third scheduled trading day preceding the maturity date, holders may convert their notes at any time, regardless of the foregoing circumstances. Upon conversion, for each $1 principal amount of notes, the Company will pay shares of our common stock, cash or a combination of cash and shares of our common stock at its election, if applicable, based on a daily conversion value calculated on a proportionate basis for each day of the 80 trading day observation period. All conversions occurring on the same date or on or after March 15, 2020 shall be settled using the same settlement method. Additionally, in the event of a fundamental change as defined in the indenture governing the notes, or other conversion rate adjustments such as share splits or combinations, other distributions of shares, cash or other assets to stockholders, including self-tender transactions (Other Conversion Rate Adjustments), the conversion rate may be modified to adjust the number of shares per $1 principal amount of the notes. As of December 31, 2018, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0001564590-19-004520:notes:187]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to Other Conversion Rate Adjustments, would be 32,423.

[0001564590-19-004520:notes:188]
Note Repurchase:    The Company is not permitted to redeem the convertible senior notes at any time prior to maturity. In the event of a fundamental change or certain default events, as defined in the indenture governing the notes, holders may require the Company to repurchase for cash all or a portion of their convertible senior notes at a price equal to 100% of the principal amount, plus any accrued and unpaid interest.

[0001564590-19-004520:notes:189]
Convertible Note Hedge and Warrant Transaction:    In connection with the issuance of the convertible senior notes due 2020, the Company entered into a convertible note hedge and warrant transaction (Call Spread Transaction), with respect to the Company’s common stock. The convertible note hedge consists of the Company’s option to purchase up to 25,939 common stock shares at a price of $9.64 per share. The hedge expires on December 15, 2020 and can only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, the Company sold warrants to purchase 25,940 shares of its common stock at a price of $14.26 per share. The warrants expire ratably from March 2021 through January 2022. The Call Spread Transaction has no effect on the terms of the convertible senior notes due 2020 and reduces potential dilution by effectively increasing the conversion price of the convertible senior notes due 2020 to $14.26 per share of the Company’s common stock.

[0001564590-19-004520:notes:190]
As of December 31, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:

[0001564590-19-004520:notes:191]
|  |  | As of December 31, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

[0001564590-19-004520:notes:192]
The components of interest expense resulting from the convertible senior notes for the years ended December 31, 2018, January 1, 2018 and January 2, 2017 were as follows:

[0001564590-19-004520:notes:193]
|  |  | For the Year Ended |  |
|  |  | December 31, |  |  | January 1, |  |  | January 2, |  |
|  |  | 2018 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 4,375 |  |  | $ | 4,375 |  |  | $ | 4,375 |  |
| Amortization of debt discount |  | $ | 9,142 |  |  | $ | 8,570 |  |  | $ | 8,034 |  |
| Amortization of debt issuance costs |  | $ | 916 |  |  | $ | 858 |  |  | $ | 805 |  |

[0001564590-19-004520:notes:194]
Asset-Based Lending Agreements

[0001564590-19-004520:notes:195]
The Company maintains a $200,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and a $150,000 Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans).

[0001564590-19-004520:notes:196]
The U.S. ABL consists of three tranches comprised of a revolving credit facility for up to $200,000, a letter of credit facility for up to $50,000, and swingline loans for up to $30,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 150 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 50 basis points, at the Company’s option. At December 31, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 4.00%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At December 31, 2018, $40,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-004520:notes:197]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At December 31, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.90%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At December 31, 2018, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-004520:notes:198]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of December 31, 2018, letters of credit in the amount of $10,128 were outstanding under the U.S. ABL and $12,128 were outstanding under the Asia ABL with various expiration dates through May 2020. Available borrowing capacity under the U.S. ABL and the Asia ABL was $149,872 and $107,872, respectively, which considers letters of credit outstanding at December 31, 2018.

[0001564590-19-004520:notes:199]
The Company is required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL and the Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $992, $783, and $709 for the years ended December 31, 2018, January 1, 2018, and January 2, 2017, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0001564590-19-004520:notes:200]
Other Credit Facility

[0001564590-19-004520:notes:201]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $30,532 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in June 2019. As of December 31, 2018, the Chinese Revolver had not been drawn upon.

[0001564590-19-004520:notes:202]
Debt Issuance and Debt Discount

[0001564590-19-004520:notes:203]
As of December 31, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes, and Convertible Senior Notes are as follows:

[0001564590-19-004520:notes:204]
|  |  | As of December 31, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | $ | 8,229 |  |  | $ | 2,489 |  |  | 4.66% |  |  | $ | 2,788 |  |  | $ | 1,691 |  |  | 3.96% |  |
| Senior Notes due October 2025 |  |  | 6,071 |  |  | — |  |  | 5.92% |  |  |  | 6,782 |  |  | — |  |  | 5.92% |  |
| Convertible Senior Notes |  |  | 1,972 |  |  |  | 19,678 |  |  | 6.48% |  |  |  | 2,889 |  |  |  | 28,822 |  |  | 6.48% |  |
|  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |

[0001564590-19-004520:notes:205]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-19-004520:notes:206]
Debt issuance costs for the ABL Revolving Loans of $1,420 and $2,421 as of December 31, 2018 and January 1, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

[0001564590-19-004520:notes:207]
At December 31, 2018, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.7 years.

[0001564590-19-004520:notes:208]
Loss on Extinguishment of Debt

[0001564590-19-004520:notes:209]
During the years ended January 1, 2018 and January 2, 2017, the Company recognized loss on extinguishment of debt of $768 and $47,767, respectively, primarily associated with the write off of the remaining unamortized debt issuance and debt discount for the 2016 Term Loan and the 2015 Term Loan Credit Agreement, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-004520:notes:210]
| (9) | Income Taxes |

[0001564590-19-004520:notes:211]
The components of income (loss) before income taxes for the years ended December 31, 2018, January 1, 2018 and January 2, 2017 are:

[0001564590-19-004520:notes:212]
|  |  | For the Year Ended |  |
|  |  | December 31, 2018 |  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| United States |  | $ | 18,991 |  |  | $ | (4,178 | ) |  | $ | (85,323 | ) |
| Foreign |  |  | 70,777 |  |  |  | 144,136 |  |  |  | 152,325 |  |
| Income before income taxes |  | $ | 89,768 |  |  | $ | 139,958 |  |  | $ | 67,002 |  |

[0001564590-19-004520:notes:213]
The Company expects its earnings attributable to foreign subsidiaries will be indefinitely reinvested, except for our material Chinese plants and the respective holding companies where a deferred tax liability of approximately $19,439 and $1,066 has been recorded for the foreign and U.S. federal/state impact, respectively. For those other companies with earnings currently being reinvested outside of the U.S., the undistributed earnings amounted to approximately $209,356 as of December 31, 2018. The determination of the unrecognized deferred tax liability related to these undistributed earnings is approximately $4,700.

[0001564590-19-004520:notes:214]
The components of income tax benefit (provision) for the years ended December 31, 2018, January 1, 2018 and January 2, 2017 are:

[0001564590-19-004520:notes:215]
|  |  | For the Year Ended |  |
|  |  | December 31, 2018 |  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Current benefit (provision): |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 381 |  |  | $ | 82 |  |  | $ | (342 | ) |
| State |  |  | (1,294 | ) |  |  | (462 | ) |  |  | (512 | ) |
| Foreign |  |  | (12,045 | ) |  |  | (24,006 | ) |  |  | (29,672 | ) |
| Total current |  |  | (12,958 | ) |  |  | (24,386 | ) |  |  | (30,526 | ) |
| Deferred benefit (provision): |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 97,723 |  |  |  | 11 |  |  |  | — |  |
| State |  |  | 14,351 |  |  |  | (31 | ) |  |  | — |  |
| Foreign |  |  | (15,300 | ) |  |  | 9,175 |  |  |  | (901 | ) |
| Total deferred |  |  | 96,774 |  |  |  | 9,155 |  |  |  | (901 | ) |
| Total benefit (provision) |  | $ | 83,816 |  |  | $ | (15,231 | ) |  | $ | (31,427 | ) |

[0001564590-19-004520:notes:216]
The following is a reconciliation of the provision for income taxes at the statutory federal income tax rate compared to the Company’s provision for income taxes for the years ended December 31, 2018, January 1, 2018 and January 2, 2017:

[0001564590-19-004520:notes:217]
|  |  | For the Year Ended |  |
|  |  | December 31, 2018 |  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Statutory federal income tax |  | $ | (18,851 | ) |  | $ | (48,985 | ) |  | $ | (22,780 | ) |
| State income taxes, net of federal benefit and state tax credits |  |  | (1,953 | ) |  |  | (462 | ) |  |  | 906 |  |
| Foreign deemed dividends |  |  | — |  |  |  | (457 | ) |  |  | (4,585 | ) |
| Transfer pricing |  |  | 1,483 |  |  |  | — |  |  |  | — |  |
| Acquisition related expenses |  |  | (1,737 | ) |  |  | — |  |  |  | (591 | ) |
| IRC Section 162(m) limitation |  |  | (3,702 | ) |  |  | — |  |  |  | — |  |
| Stock options |  |  | 1,072 |  |  |  | — |  |  |  | — |  |
| Intercompany profit in inventory elimination |  |  | — |  |  |  | (743 | ) |  |  | (335 | ) |
| Permanently reinvested earnings assertion |  |  | (15,492 | ) |  |  | — |  |  |  | — |  |
| Tax Act deferred tax revaluation |  |  | — |  |  |  | (59,228 | ) |  |  | — |  |
| Foreign tax differential on foreign earnings & other permanent items |  |  | 2,045 |  |  |  | 30,412 |  |  |  | 17,530 |  |
| Change in valuation allowance |  |  | 118,451 |  |  |  | 66,716 |  |  |  | (19,119 | ) |
| Uncertain tax positions |  |  | (954 | ) |  |  | (3,992 | ) |  |  | (3,464 | ) |
| Federal research and development credits |  |  | 2,996 |  |  |  | 1,270 |  |  |  | 1,270 |  |
| Other |  |  | 458 |  |  |  | 238 |  |  |  | (259 | ) |
| Total benefit (provision) for income taxes |  | $ | 83,816 |  |  | $ | (15,231 | ) |  | $ | (31,427 | ) |

[0001564590-19-004520:notes:218]
Deferred income taxes reflect the net tax effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. The significant components of the net deferred income tax assets (liabilities) as of December 31, 2018 and January 1, 2018 are as follows:

[0001564590-19-004520:notes:219]
|  |  | As of |  |
|  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  | (In thousands) |  |
| Deferred income tax assets: |  |  |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 104,801 |  |  | $ | 143,095 |  |
| Reserves and accruals |  |  | 29,358 |  |  |  | 23,655 |  |
| Interest expense limitation |  |  | 1,276 |  |  |  | — |  |
| Unrealized loss on cash flow hedge |  |  | 1,128 |  |  |  | — |  |
| Tax credit carryforwards |  |  | 30,962 |  |  |  | 27,012 |  |
| Stock-based compensation |  |  | 4,528 |  |  |  | 5,099 |  |
| Original issue discount on convertible senior notes |  |  | 5,130 |  |  |  | 7,345 |  |
| Property, plant and equipment |  |  | 24,826 |  |  |  | 24,170 |  |
| Other deferred income tax assets |  |  | 228 |  |  |  | 1,282 |  |
|  |  |  | 202,237 |  |  |  | 231,658 |  |
| Less: valuation allowance |  |  | (27,426 | ) |  |  | (167,238 | ) |
|  |  |  | 174,811 |  |  |  | 64,420 |  |
| Deferred income tax liabilities: |  |  |  |  |  |  |  |  |
| Discount on convertible senior notes |  |  | (4,683 | ) |  |  | (6,413 | ) |
| Repatriation of foreign earnings |  |  | (20,282 | ) |  |  | (8,977 | ) |
| Property, plant and equipment basis differences |  |  | (50,622 | ) |  |  | (33,661 | ) |
| Goodwill and intangible amortization |  |  | (85,300 | ) |  |  | (19,400 | ) |
| Other deferred income tax liabilities |  |  | (252 | ) |  |  | (828 | ) |
| Net deferred income tax assets (liabilities) |  | $ | 13,672 |  |  | $ | (4,859 | ) |
| Deferred income tax assets (liabilities), net: |  |  |  |  |  |  |  |  |
| Current deferred income taxes |  | $ | — |  |  | $ | — |  |
| Noncurrent deferred income taxes |  |  | 13,672 |  |  |  | (4,859 | ) |

[0001564590-19-004520:notes:220]
As of December 31, 2018, the Company had the following net operating loss (NOL) carryforwards: $431,214 in the U.S. for federal, $148,774 in various U.S. states, $54,000 in China, and $13,300 in Hong Kong. The U.S. federal NOLs expire in 2023 through 2036, the various U.S. states’ NOLs expire in 2019 through 2036, the China NOLs expire in 2019 through 2023, and the Hong Kong NOLs carryforward indefinitely. Further, the Company’s tax credits were approximately $38,065 of which $6,496 carryforward indefinitely.

[0001564590-19-004520:notes:221]
In connection with the Company’s acquisition of Viasystems, there was more than a 50% change in ownership under Section 382 of the Internal Revenue Code of 1986, as amended, and regulations issued there under. As a consequence, the utilization of the acquired Viasystems U.S. NOLs is limited to approximately $9,826 per year. In addition, the Company recognized certain gains built in at the time of the ownership change, which increase the limitation by approximately $47,463 for each of the first 5 years after the acquisition. Any unused limitation in a year can be carried over to succeeding years.

[0001564590-19-004520:notes:222]
A valuation allowance is provided when it is more likely than not that all or some portion of the deferred income tax assets will not be realized. During the year ended December 31, 2018 the Company released a majority of its valuation allowance recorded on its U.S. net deferred tax assets due to a combination of the Company’s expectations for future U.S. taxable income improvement and to offset the net deferred tax liability acquired as a result of the Anaren acquisition. It continues to maintain a valuation allowance on certain of its U.S. net deferred tax assets represented by income tax attributes carried forward that are expected to expire unused. Certain subsidiaries within China continue to have NOL carryforwards in various tax jurisdictions that the Company has determined are not more likely than not to be utilized. As a result, a full valuation allowance has been recorded for these subsidiaries at December 31, 2018. For the remaining net deferred income tax asset, management has determined that it is more likely than not that the results of future operations will generate sufficient taxable income to realize the net deferred tax asset.

[0001564590-19-004520:notes:223]
The following summarizes the activity in the Company’s valuation allowance for the years ended December 31, 2018, January 1, 2018 and January 2, 2017:

[0001564590-19-004520:notes:224]
|  |  | For the Year Ended |  |
|  |  | December 31, 2018 |  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 167,238 |  |  | $ | 221,951 |  |  | $ | 234,192 |  |
| Reduction related to acquisition |  |  | (76,040 | ) |  |  | — |  |  |  | (18,234 | ) |
| Additions charged to expense |  |  | — |  |  |  | 4,515 |  |  |  | 5,993 |  |
| Reduction charged to expense — Tax Act |  |  | — |  |  |  | (59,228 | ) |  |  | — |  |
| Other reduction charged to expense |  |  | (63,772 | ) |  |  | — |  |  |  | — |  |
| Balance at end of year |  | $ | 27,426 |  |  | $ | 167,238 |  |  | $ | 221,951 |  |

[0001564590-19-004520:notes:225]
Certain entities within China qualified for the high and new technology enterprise (HNTE) status enabling those entities to enjoy certain benefits, which were effective for the years ended December 31, 2018, January 1, 2018 and January 2, 2017. The HNTE status as well as enhanced research and development (R&D) deductions decreased Chinese taxes. HNTE and R&D benefit and effect on earnings per share are as follows:

[0001564590-19-004520:notes:226]
|  |  | For the Year Ended |  |
|  |  | December 31, 2018 |  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  | (In thousands, except per share data) |  |
| HNTE and R&D benefits |  | $ | 11,970 |  |  | $ | 11,935 |  |  | $ | 7,666 |  |
| Basic shares |  |  | 103,355 |  |  |  | 101,580 |  |  |  | 100,099 |  |
| Diluted shares |  |  | 134,036 |  |  |  | 132,476 |  |  |  | 101,482 |  |
| Increases earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.12 |  |  | $ | 0.12 |  |  | $ | 0.08 |  |
| Diluted |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.08 |  |

[0001564590-19-004520:notes:227]
HNTE status expires at various dates 2018 through 2019, but the Company expects to continue to file for renewal of such HNTE status for the foreseeable future.

[0001564590-19-004520:notes:228]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, exclusive of accrued interest and penalties, is as follows:

[0001564590-19-004520:notes:229]
|  |  | For the Year Ended |  |
|  |  | December 31, 2018 |  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 38,841 |  |  | $ | 39,727 |  |  | $ | 15,404 |  |
| Additions related to acquisition |  |  | 903 |  |  |  | — |  |  |  | 22,182 |  |
| Additions based on tax positions related to the current year |  |  | 856 |  |  |  | 1,965 |  |  |  | 5,389 |  |
| Additions for tax positions of prior years |  |  | 117 |  |  |  | 1,661 |  |  |  | 1,545 |  |
| Reductions for tax positions of prior years |  |  | (2,140 | ) |  |  | (3,846 | ) |  |  | (2,286 | ) |
| Lapse of statute of limitations |  |  | (728 | ) |  |  | (666 | ) |  |  | (2,507 | ) |
| Balance at end of year |  | $ | 37,849 |  |  | $ | 38,841 |  |  | $ | 39,727 |  |

[0001564590-19-004520:notes:230]
As of December 31, 2018 and January 1, 2018, the Company recorded unrecognized tax benefits of $26,274 and $29,033, respectively, as well as interest and penalties of $13,280 and $12,679, respectively, to other long-term liabilities. The Company has also recorded unrecognized tax benefits of $11,576 and $9,808 against certain deferred tax assets as of December 31, 2018 and January 1, 2018, respectively. The amount of unrecognized tax benefits that would, if recognized, reduce the Company’s effective income tax rate in any future periods is $39,553 including interest and penalties. The Company expects its unrecognized tax benefits to decrease by $1,083 along with related interest of $2,040 over the next 12 months due to expiring statutes.

[0001564590-19-004520:notes:231]
As of December 31, 2018, the Company is subject to (i) U.S. federal income tax examination and / or NOL adjustment for tax years from 2000 to 2018, (ii) state and local income tax examination for tax years 2000 to 2018, and (iii) foreign income tax examinations generally for tax years from 2008 to 2018.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-19-004520:notes:232]
| (10) | Financial Instruments |

[0001564590-19-004520:notes:233]
Derivatives

[0001564590-19-004520:notes:234]
Interest Rate Swaps

[0001564590-19-004520:notes:235]
The Company’s business is exposed to interest rate risk resulting from fluctuations in interest rates on certain LIBOR-based variable rate debt. Increases in interest rates would increase interest expenses relating to the outstanding variable rate borrowings and increase the cost of debt. Fluctuations in interest rates can also lead to significant fluctuations in the fair value of the debt obligations.

[0001564590-19-004520:notes:236]
On May 15, 2018, the Company entered into a four-year pay-fixed, receive floating (1-month LIBOR), interest rate swap arrangement with a notional amount of $400,000 for the period beginning June 1, 2018 and ending on June 1, 2022. Under the terms of the interest rate swap, the Company pays a fixed rate of 2.84% against the first interest payments of a portion of its LIBOR-based debt and receives floating 1-month LIBOR during the swap period.

[0001564590-19-004520:notes:237]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of December 31, 2018, the fair value of the interest rate swap was recorded as a liability in the amount of $4,735 and included as a component of other long-term liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive (loss) income, net of tax, in the Company’s consolidated balance sheet. No ineffectiveness was recognized for the year ended December 31, 2018. During the year ended December 31, 2018, the interest rate swap increased interest expense by $1,598.

[0001564590-19-004520:notes:238]
Foreign Exchange Contracts

[0001564590-19-004520:notes:239]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than its functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts at December 31, 2018 and January 1, 2018 was approximately $4,313 and $10,927, respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-19-004520:notes:240]
The fair values of derivative instruments in the consolidated balance sheets are as follows:

[0001564590-19-004520:notes:241]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other long-term liabilities |  | $ | (4,735 | ) |  | $ | — |  |
| Foreign exchange contracts |  | Other accrued expenses |  |  | — |  |  |  | (6 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | — |  |  |  | 107 |  |
| Foreign exchange contracts |  | Other accrued expenses |  |  | (139 | ) |  |  | (132 | ) |
| Foreign exchange contracts |  | Other long-term liabilities |  |  | — |  |  |  | (13 | ) |

[0001564590-19-004520:notes:242]
The following table provides information about the amounts recorded in accumulated other comprehensive (loss) income related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated statements of operations when derivative amounts are reclassified out of accumulated other comprehensive income for the years ended December 31, 2018, January 1, 2018 and January 2, 2017:

[0001564590-19-004520:notes:243]
|  |  |  | Year ended December 31, 2018 |  |  | Year ended January 1, 2018 |  |  | Year ended January 2, 2017 |  |
|  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption | Gain/(Loss) Recognized in Other Comprehensive Income (Loss) |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income (Loss) |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income (Loss) |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |
|  |  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (6,333 | ) |  | $ | (1,598 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency forward |  | Depreciation expense |  | (21 | ) |  |  | (157 | ) |  |  | — |  |  |  | 276 |  |  |  | (162 | ) |  |  | — |  |  |  | (83 | ) |  |  | (175 | ) |  |  | — |  |

[0001564590-19-004520:notes:244]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive (loss) income for the years ended December 31, 2018, January 1, 2018 and January 2, 2017:

[0001564590-19-004520:notes:245]
|  |  | For the Year Ended |  |
|  |  | December 31, |  |  | January 1, |  |  | January 2, |  |
|  |  | 2018 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | (742 | ) |  | $ | (1,180 | ) |  | $ | (1,272 | ) |
| Changes in fair value (loss) gain, net of tax |  |  | (4,846 | ) |  |  | 276 |  |  |  | (83 | ) |
| Reclassification to earnings |  |  | 1,374 |  |  |  | 162 |  |  |  | 175 |  |
| Ending balance, net of tax |  | $ | (4,214 | ) |  | $ | (742 | ) |  | $ | (1,180 | ) |

[0001564590-19-004520:notes:246]
The Company expects that losses of approximately $837 of the accumulated other comprehensive income (loss) will be reclassified into the statement of operations, net of tax, in the next 12 months.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-19-004520:notes:247]
| (11) | Accumulated Other Comprehensive Income (Loss) |

[0001564590-19-004520:notes:248]
The following provides a summary of the components of accumulated other comprehensive income (loss), net of tax as of December 31, 2018, January 1, 2018 and January 2, 2017:

[0001564590-19-004520:notes:249]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at January 2, 2017 |  | $ | (43,149 | ) |  | $ | — |  |  | $ | (1,180 | ) |  | $ | (44,329 | ) |
| Other comprehensive income before reclassifications |  |  | 47,294 |  |  |  | — |  |  |  | 276 |  |  |  | 47,570 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 162 |  |  |  | 162 |  |
| Net year to date period other comprehensive income |  |  | 47,294 |  |  |  | — |  |  |  | 438 |  |  |  | 47,732 |  |
| Ending balance at January 1, 2018 |  |  | 4,145 |  |  |  | — |  |  |  | (742 | ) |  |  | 3,403 |  |
| Other comprehensive loss before reclassifications |  |  | (2,567 | ) |  |  | (1,284 | ) |  |  | (4,846 | ) |  |  | (8,697 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 1,374 |  |  |  | 1,374 |  |
| Net year to date period other comprehensive loss |  |  | (2,567 | ) |  |  | (1,284 | ) |  |  | (3,472 | ) |  |  | (7,323 | ) |
| Ending balance at December 31, 2018 |  | $ | 1,578 |  |  | $ | (1,284 | ) |  | $ | (4,214 | ) |  | $ | (3,920 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-19-004520:notes:250]
| (12) | Significant Customers and Concentration of Credit Risk |

[0001564590-19-004520:notes:251]
In the normal course of business, the Company extends credit to its customers. Most customers to which the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk.

[0001564590-19-004520:notes:252]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.

[0001564590-19-004520:notes:253]
For the years ended December 31, 2018, January 1, 2018 and January 2, 2017, one customer accounted for approximately 15%, 20% and 15%, respectively, of the Company’s net sales. There were no other customers that accounted for 10% or more of net sales for the years ended December 31, 2018, January 1, 2018 or January 2, 2017.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-19-004520:notes:254]
| (13) | Fair Value Measures |

[0001564590-19-004520:notes:255]
The Company measures at fair value its financial and non-financial assets by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability.

[0001564590-19-004520:notes:256]
The carrying amount and estimated fair value of the Company’s financial instruments as of December 31, 2018 and January 1, 2018 were as follows:

[0001564590-19-004520:notes:257]
|  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | — |  |  | $ | — |  |  | $ | 107 |  |  | $ | 107 |  |
| Derivative liabilities, current |  |  | 139 |  |  |  | 139 |  |  |  | 258 |  |  |  | 258 |  |
| Derivative liabilities, non-current |  |  | 4,735 |  |  |  | 4,735 |  |  |  | — |  |  |  | — |  |
| Term Loan due September 2024 |  |  | 825,161 |  |  |  | 782,592 |  |  |  | 344,646 |  |  |  | 346,943 |  |
| Senior Notes due October 2025 |  |  | 368,929 |  |  |  | 350,880 |  |  |  | 368,218 |  |  |  | 384,769 |  |
| Convertible Senior Notes |  |  | 228,335 |  |  |  | 290,858 |  |  |  | 218,274 |  |  |  | 429,199 |  |
| ABL Revolving Loans |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 47,000 |  |  |  | 47,000 |  |
| Capital lease |  |  | — |  |  |  | — |  |  |  | 1,919 |  |  |  | 1,919 |  |

[0001564590-19-004520:notes:258]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of December 31, 2018 and January 1, 2018, which are considered Level 2 inputs.

[0001564590-19-004520:notes:259]
The fair value of the convertible senior notes was estimated based on quoted market prices of the securities on an active exchange, which are considered Level 2 inputs.

[0001564590-19-004520:notes:260]
The fair value of plan assets in the defined benefit plan of $18,251 as of December 31, 2018 was not included in the table above and was estimated based on quoted market prices of the securities that are actively traded and price quotes that are readily available, which are considered Level 1 inputs. See Note 16 for further details of the plan assets measured at fair value in the defined benefit plan.

[0001564590-19-004520:notes:261]
As of December 31, 2018 and January 1, 2018, the Company’s other financial instruments also included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. Our cash and cash equivalents at December 31, 2018 consisted of $42,502 held in the U.S., with the remaining $213,858 held by foreign subsidiaries.

[0001564590-19-004520:notes:262]
The majority of the Company’s non-financial assets and liabilities, which include goodwill, intangible assets, inventories, and property, plant and equipment, are not required to be carried at fair value on a recurring basis. However, if certain triggering events occur (or are tested at least annually in the case of goodwill) such that a non-financial instrument is required to be evaluated for impairment, based upon a comparison of the non-financial instrument’s fair value to its carrying value, an impairment is recorded to reduce the carrying value to the fair value, if the carrying value exceeds the fair value.

[0001564590-19-004520:notes:263]
For the year ended January 2, 2017, the following assets were measured at fair value on a nonrecurring basis using the type of inputs shown:

[0001564590-19-004520:notes:264]
|  |  |  |  |  |  | Fair Value Measurements Using: |  |
|  |  | January 2, 2017 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |  | Total Losses for the Year Ended January 2, 2017 |  |
|  |  | (In thousands) |  |
| Long-lived assets held and use |  | $ | 2,254 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,254 |  |  | $ | 1,953 |  |
| Assets held for sale |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,393 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3,346 |  |

[0001564590-19-004520:notes:265]
There was no impairment of long-lived assets recognized in the year ended December 31, 2018 or January 1, 2018.

[0001564590-19-004520:notes:266]
The Company has capitalized software costs in accordance with U.S. GAAP. During the year ended January 2, 2017, the Company determined that certain capitalized costs no longer had benefit primarily as a result of the Viasystems acquisition. Because the primary determination of fair value was based on management’s assumptions and estimates of capitalized costs to dispose, the resulting fair value is considered a Level 3 input.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-004520:notes:267]
| (14) | Commitments and Contingencies |

[0001564590-19-004520:notes:268]
Operating Leases

[0001564590-19-004520:notes:269]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under noncancellable operating leases that expire at various dates through 2049. Certain real property leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term.

[0001564590-19-004520:notes:270]
The following is a schedule of future minimum lease payments as of December 31, 2018:

[0001564590-19-004520:notes:271]
|  |  | Operating Leases |  |
|  |  | (In thousands) |  |
| 2019 |  | $ | 7,282 |  |
| 2020 |  |  | 4,701 |  |
| 2021 |  |  | 3,406 |  |
| 2022 |  |  | 2,408 |  |
| 2023 |  |  | 2,172 |  |
| Thereafter |  |  | 4,172 |  |
| Total minimum lease payments |  | $ | 24,141 |  |

[0001564590-19-004520:notes:272]
Total rent expense for the years ended December 31, 2018, January 1, 2018 and January 2, 2017, was approximately $20,345, $16,665 and $10,329, respectively.

[0001564590-19-004520:notes:273]
Legal Matters

[0001564590-19-004520:notes:274]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of December 31, 2018 and January 1, 2018. However, these amounts are not material to the consolidated financial statements of the Company.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-19-004520:notes:275]
| (15) | Stock-Based Compensation |

[0001564590-19-004520:notes:276]
Incentive Compensation Plan

[0001564590-19-004520:notes:277]
The Company maintains a 2014 Incentive Compensation Plan (the Plan), which allowed for the issuance of up to 5,288 shares. In May 2016, the Plan was amended to increase the amount allowed for issuance by 5,000 shares, revising the maximum allowed for issuance to 10,288 through its expiration date of February 2024.

[0001564590-19-004520:notes:278]
The Plan provides for the grant of incentive stock options and nonqualified stock options to the Company’s key employees, non-employee directors and consultants. Other types of awards such as performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock appreciation rights are also permitted. The exercise price for options and awards is determined by the compensation committee of the board of directors and, for options intended to qualify as incentive stock options, may not be less than the fair market value as determined by the closing stock price at the date of the grant. Each option and award shall vest and expire as determined by the compensation committee of the board of directors, with options, PRUs and RSUs generally vesting over three years for employees and one year for non-employee directors. Options, PRUs and RSUs do not have voting rights. Options expire no later than ten years from the grant date. All grants provide for accelerated vesting if there is a change in control, as defined in the Plan. Upon the exercise of outstanding stock options or vesting of RSUs and PRUs, the Company’s practice is to issue new registered shares that are reserved for issuance under the Plan.

[0001564590-19-004520:notes:279]
As of December 31, 2018, 949 PRUs, 2,546 RSUs and 100 stock options were outstanding under the Plan. Included in the 949 PRUs outstanding as of December 31, 2018 are 694 vested but not yet released. Included in the 2,546 RSUs outstanding as of December 31, 2018 are 422 vested but not yet released RSUs associated with non-employee directors. These RSUs vest over one year with release of the underlying shares of common stock deferred until retirement from the board of directors, (or until one year after retirement in the case of certain prior grants).

[0001564590-19-004520:notes:280]
Performance-based Restricted Stock Units

[0001564590-19-004520:notes:281]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period may range from zero to 2.4 times the target number depending on performance during the period. The performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and EBITDA (earnings before interest, tax, depreciation, and amortization expense), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three-year performance period.

[0001564590-19-004520:notes:282]
Under the PRU program, financial goals are set at the beginning of each fiscal year and performance is reviewed at the end of that year. The percentage to be applied to each participant’s target award ranges from zero to 160% based upon the extent to which the annual financial performance goals are achieved. If specific performance threshold levels for the annual financial goals are met, the amount earned for that element will be applied to one-third of the participants’ PRU award to determine the number of units earned.

[0001564590-19-004520:notes:283]
At the end of the three-year performance period, the total units earned, if any, are adjusted by applying a modifier, ranging from zero to 150% based on the Company’s TSR based on stock price changes relative to a group of peer companies selected by the Company’s compensation committee for the same three-year period.

[0001564590-19-004520:notes:284]
The TSR modifier is intended to ensure that there are limited or no payouts under the PRU program if the Company’s stock performance is significantly below the median TSR of a group of peer companies selected by the Company’s compensation committee over the three-year performance period. Where the annual financial goals have been met and where there has been strong relative TSR performance over the three-year performance period, the PRU program may provide substantial rewards to participants with a maximum payout of 2.4 times the initial PRU award. However, even if all of the annual financial metric goals are achieved in each of the three years, there will be no payouts if the Company’s stock performance is below that of the 10th percentile for PRUs granted in 2018, 2017 and 2016 of the group of peer companies selected by the Company’s compensation committee, as appropriate.

[0001564590-19-004520:notes:285]
Recipients of PRU awards generally must remain employed by the Company on a continuous basis through the end of the three-year performance period in order to receive any amount of the PRUs covered by that award. In events such as death, disability or retirement, the recipient may be entitled to pro-rata amounts of PRUs as defined in the Plan. Target shares subject to PRU awards do not have voting rights of common stock until earned and issued following the end of the three-year performance period.

[0001564590-19-004520:notes:286]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. As of December 31, 2018, management determined that vesting of the PRU awards was probable. PRU activity for the year ended December 31, 2018 was as follows:

[0001564590-19-004520:notes:287]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Outstanding shares at January 1, 2018 |  |  | 409 |  |  | $ | 16.39 |  |
| Granted |  |  | 335 |  |  |  | 19.59 |  |
| Vested |  |  | (694 | ) |  |  | 17.22 |  |
| Change in units due to annual performance achievement |  |  | 205 |  |  |  | 16.92 |  |
| Outstanding shares at December 31, 2018 |  |  | 255 |  |  | $ | 18.75 |  |

[0001564590-19-004520:notes:288]
The fair value of PRUs granted is calculated using a Monte Carlo simulation model, as the TSR modifier contains a market condition. For the years ended December 31, 2018, January 1, 2018 and January 2, 2017, the following assumptions were used in determining the fair value:

[0001564590-19-004520:notes:289]
|  |  | For the Year Ended |  |
|  |  | December 31, 2018 (1) |  |  | January 1, 2018 (2) |  |  | January 2, 2017 (3) |  |
| Weighted-average fair value |  | $ | 19.59 |  |  | $ | 22.90 |  |  | $ | 6.46 |  |
| Risk-free interest rate |  |  | 2.14 | % |  |  | 1.20 | % |  |  | 0.84 | % |
| Dividend yield |  |  | — |  |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 40 | % |  |  | 43 | % |  |  | 40 | % |
| Expected term in years |  |  | 1.5 |  |  |  | 1.8 |  |  |  | 2.1 |  |

[0001564590-19-004520:notes:290]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2016, the second year of the three-year performance period applicable to PRUs granted in 2017 and the first year of the three-year performance period applicable to PRUs granted in 2018. |

[0001564590-19-004520:notes:291]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2015, the second year of the three-year performance period applicable to PRUs granted in 2016 and the first year of the three-year performance period applicable to PRUs granted in 2017. |

[0001564590-19-004520:notes:292]
| (3) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2014, the second year of the three-year performance period applicable to PRUs granted in 2015 and the first year of the three-year performance period applicable to PRUs granted in 2016. |

[0001564590-19-004520:notes:293]
The expected term of the PRUs reflects the performance period for the PRUs granted. Expected volatility is calculated using the Company’s historical stock price. The risk-free interest rate for the expected term of PRUs is based on the U.S. Treasury yield curve in effect at the time of grant.

[0001564590-19-004520:notes:294]
Restricted Stock Units

[0001564590-19-004520:notes:295]
RSU activity for the year ended December 31, 2018 was as follows:

[0001564590-19-004520:notes:296]
|  |  | Shares |  |  | Weighted Average Grant-Date Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Non-vested RSUs outstanding at January 1, 2018 |  |  | 2,413 |  |  | $ | 10.88 |  |
| Granted |  |  | 1,057 |  |  |  | 15.35 |  |
| Vested |  |  | (1,243 | ) |  |  | 10.14 |  |
| Forfeited |  |  | (102 | ) |  |  | 12.17 |  |
| Non-vested RSUs outstanding at December 31, 2018 |  |  | 2,125 |  |  | $ | 13.47 |  |
| Vested and expected to vest at December 31, 2018 |  |  | 2,546 |  |  | $ | 12.90 |  |

[0001564590-19-004520:notes:297]
The fair value of the Company’s RSUs is determined based upon the closing common stock price on the grant date. The weighted average fair value per unit of RSUs granted was $15.35, $15.85 and $6.78 for the years ended December 31, 2018, January 1, 2018 and January 2, 2017, respectively. The total fair value of RSUs vested for the years ended December 31, 2018, January 1, 2018 and January 2, 2017 was $12,599, $9,446 and $7,834, respectively.

[0001564590-19-004520:notes:298]
Stock Options

[0001564590-19-004520:notes:299]
During the years ended December 31, 2018 and January 2, 2017, the Company granted 40 and 20 stock options, respectively, to newly appointed members of the board which were estimated to have a weighted fair value per share of $8.37 and $6.78, respectively. The fair value calculation is based on stock options granted during the period using the Black-Scholes option-pricing model on the date of grant. For the year ended December 31, 2018, the weighted fair value was determined using 3.1% as the risk-free interest rate, 43% as the expected volatility, 8.5 years as the expected term and no dividend yield. For the year ended January 2, 2017 the fair value was determined using 1.7% as the risk-free interest rate, 51% as the expected volatility, 8.5 years as the expected term and no dividend yield. No stock options were granted by the Company for the year ended January 1, 2018.

[0001564590-19-004520:notes:300]
The Company determines the expected term of its stock option awards by periodic review of its historical stock option exercise experience. This calculation uses assumed future exercise patterns to account for option holders’ expected exercise and post-vesting termination behavior for outstanding stock options over their remaining contractual terms. Expected volatility is calculated by weighting the Company’s historical stock price to calculate expected volatility over the expected term of each grant. The risk-free interest rate for the expected term of each option granted is based on the U.S. Treasury yield curve in effect at the time of grant with a period that approximates the expected term of the options.

[0001564590-19-004520:notes:301]
Option activity under the Plan for the year ended December 31, 2018 was as follows:

[0001564590-19-004520:notes:302]
|  |  | Options |  |  | Weighted Average Exercise Price |  |  | Weighted Average Remaining Contractual Term |  |  | Aggregate Intrinsic Value |  |
|  |  | (In thousands) |  |  |  |  |  |  | (In years) |  |  | (In thousands) |  |
| Outstanding at January 1, 2018 |  |  | 80 |  |  | $ | 10.98 |  |  |  | 4.2 |  |  | $ | 375 |  |
| Granted |  |  | 40 |  |  |  | 15.57 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (20 | ) |  |  | 9.54 |  |  |  |  |  |  |  |  |  |
| Outstanding at December 31, 2018 |  |  | 100 |  |  | $ | 13.10 |  |  |  | 6.1 |  |  | $ | 4 |  |
| Vested and expected to vest at December 31, 2018 |  |  | 100 |  |  | $ | 13.10 |  |  |  | 6.1 |  |  | $ | 4 |  |
| Exercisable at December 31, 2018 |  |  | 50 |  |  | $ | 11.39 |  |  |  | 2.9 |  |  | $ | 4 |  |

[0001564590-19-004520:notes:303]
The aggregate intrinsic values in the table above represent the total pretax intrinsic value (the difference between Company’s closing stock price on the last trading day of the 2018 fiscal year and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 31, 2018. This amount changes based on the fair market value of the Company’s stock. The total intrinsic value of options exercised for the years ended December 31, 2018, January 1, 2018 and January 2, 2017 was $128, $27 and $127, respectively. The total fair value of the options vested for both years ended December 31, 2018 and January 1, 2018 was $34. There were no options vested for the year ended January 2, 2017.

[0001564590-19-004520:notes:304]
Stock-based Compensation Expense and Unrecognized Compensation Costs

[0001564590-19-004520:notes:305]
For the years ended December 31, 2018, January 1, 2018 and January 2, 2017, the amounts recognized in the consolidated financial statements with respect to the stock-based compensation plan are as follows:

[0001564590-19-004520:notes:306]
|  |  | For the Year Ended |  |
|  |  | December 31, |  |  | January 1, |  |  | January 2, |  |
|  |  | 2018 |  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 2,898 |  |  | $ | 2,252 |  |  | $ | 1,630 |  |
| Selling and marketing |  |  | 1,964 |  |  |  | 1,458 |  |  |  | 1,054 |  |
| General and administrative |  |  | 15,819 |  |  |  | 14,580 |  |  |  | 8,406 |  |
| Stock-based compensation expense recognized |  | $ | 20,681 |  |  | $ | 18,290 |  |  | $ | 11,090 |  |

[0001564590-19-004520:notes:307]
The Company may become entitled to a deduction in its tax returns upon the future exercise of incentive stock options under certain circumstances. For the year ended December 31, 2018, the Company has recorded an income tax benefit. For the years ended January 1, 2018 and January 2, 2017, the Company did not record an income tax benefit as a result of a full valuation allowance on its deferred tax assets.

[0001564590-19-004520:notes:308]
The following is a summary of total unrecognized compensation costs as of December 31, 2018:

[0001564590-19-004520:notes:309]
|  |  | Unrecognized Stock- Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 17,715 |  |  |  | 1.3 |  |
| PRU awards |  |  | 2,508 |  |  |  | 1.4 |  |
| Stock options |  |  | 359 |  |  |  | 2.1 |  |
|  |  | $ | 20,582 |  |  |  |  |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-19-004520:notes:310]
| (16) | Employee Benefit Plans, Deferred Compensation Plan and Retirement Benefit Plan |

[0001564590-19-004520:notes:311]
As of December 31, 2018, the Company has several defined contribution plans. In North America, the Company has savings plans (the Savings Plans) in which eligible full-time employees can participate and contribute a percentage of compensation subject to the maximum allowed by the tax agencies. The Savings Plans provides for a partial match by the Company. In China, the Company contributes to either separate trust-administered funds or various government-sponsored pension plans on a mandatory basis. For all defined contribution plans, the Company has no further payment obligation once the required contributions have been made. The Company recorded contributions to defined contribution plans of $58,445, $42,461 and $36,172 during the years ended December 31, 2018, January 1, 2018 and January 2, 2017, respectively.

[0001564590-19-004520:notes:312]
The Company also maintains a deferred compensation plan (the Compensation Plan). The Compensation Plan is an unfunded, nonqualified deferred compensation plan and is limited to selected employees, including our named executive officers and our directors. The Compensation Plan allows participants to defer up to 100% of their annual bonus and between 5% and 100% of their annual director fees. Amounts deferred under the Compensation Plan will be credited to accounts maintained by the Company for each participant and will be credited or debited with the participant’s proportionate share of any gains or losses attributable to the performance of investment options selected by the participant.

[0001564590-19-004520:notes:313]
During the year ended December 31, 2018 and following the acquisition of Anaren on April 18, 2018, the Company has a noncontributory defined benefit pension plan covering eligible employees. Effective August 15, 2000, the plan was closed for new participants. Benefits under this plan generally are based on the employee’s years of service and compensation. While the Company intends to continue this plan, it reserves the right to terminate or amend the plan at any time.

[0001564590-19-004520:notes:314]
As of December 31, 2018, the funded status of the accumulated benefit obligation was 70%. The Company expects to fund a minimum required contribution of approximately $772 during fiscal year 2019.

[0001564590-19-004520:notes:315]
The following tables set forth the changes in benefit obligation and the plan assets in the defined benefit plan described above for the year ended December 31, 2018:

[0001564590-19-004520:notes:316]
| Change in Benefit Obligations |  | For the Year Ended December 31, 2018 |  |
|  |  | (In thousands) |  |
| Benefit obligation at beginning of year |  | $ | (27,525 | ) |
| Service cost |  |  | (292 | ) |
| Interest cost |  |  | (758 | ) |
| Actuarial gain |  |  | 264 |  |
| Benefits paid |  |  | 650 |  |
| Benefit obligation at end of year |  | $ | (27,661 | ) |
| Accumulated benefit obligation at end of year |  | $ | 26,191 |  |

[0001564590-19-004520:notes:317]
| Change in in Plan Assets |  | For the Year Ended December 31, 2018 |  |
|  |  | (In thousands) |  |
| Fair value of plan assets at beginning of year |  | $ | 19,643 |  |
| Actual return on plan assets |  |  | (1,021 | ) |
| Employer contributions |  |  | 280 |  |
| Benefits paid |  |  | (651 | ) |
| Fair value of plan assets at end of year |  | $ | 18,251 |  |
| Unfunded status |  | $ | (9,410 | ) |
| Net amount recognized |  | $ | (9,410 | ) |

[0001564590-19-004520:notes:318]
Amounts before income tax effect recognized in the consolidated balance sheets consist of the following:

[0001564590-19-004520:notes:319]
|  |  | December 31, 2018 |  |  |
|  |  | (In thousands) |  |  |
| Other long-term liabilities |  | $ | (9,410 | ) |  |
| Net amount recognized |  | $ | (9,410 | ) |  |

[0001564590-19-004520:notes:320]
Amounts before income tax effect recognized in accumulated other comprehensive loss consist of the following:

[0001564590-19-004520:notes:321]
|  |  | December 31, 2018 |  |  |
|  |  | (In thousands) |  |  |
| Net actuarial loss |  | $ | (1,677 | ) |  |
| Accumulated other comprehensive loss |  | $ | (1,677 | ) |  |

[0001564590-19-004520:notes:322]
During 2019, no accumulated other comprehensive loss is expected to be recognized as a component of net periodic benefit cost.

[0001564590-19-004520:notes:323]
The components included in the net periodic benefit cost and the increase in minimum liability included in other comprehensive loss for the year ended December 31, 2018 are as follows:

[0001564590-19-004520:notes:324]
|  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Service cost |  | $ | 292 |  |
| Interest cost |  |  | 758 |  |
| Expected return on plan assets |  |  | (920 | ) |
| Net periodic benefit cost |  | $ | 130 |  |

[0001564590-19-004520:notes:325]
The weighted-average assumptions used to determine benefit obligations for this plan at fiscal year-end were as follows:

[0001564590-19-004520:notes:326]
|  |  | December 31, 2018 |  |  |
| Discount rate |  |  | 4.09 |  | % |
| Rate of compensation increase |  |  | 3.20 |  |  |
| Expected return on plan assets |  |  | 6.75 |  |  |

[0001564590-19-004520:notes:327]
The Company determines the discount rate assumption based on the internal rate of return for a portfolio of high quality bonds, with a minimum rating of Moody's AA Corporate and with maturities that are consistent with the projected future cash flow obligations.

[0001564590-19-004520:notes:328]
The weighted-average assumptions used to determine net periodic benefit cost for the fiscal year were as follows:

[0001564590-19-004520:notes:329]
|  |  | Fiscal Year 2018 |  |  |
| Discount rate |  |  | 3.96 |  | % |
| Rate of compensation increase |  |  | 3.20 |  |  |
| Expected return on plan assets |  |  | 6.75 |  |  |

[0001564590-19-004520:notes:330]
The Company determines the expected long-term rate of return on plan assets based upon recommendations from its pension plan's investment advisors and using an allocation approach that considers diversification and rebalancing for a portfolio of assets invested over a long-term time horizon. The approach relies on the historical returns of the plan's portfolio and relationships between equities and fixed income investments, consistent with the widely accepted capital market principle that a diversified portfolio with a larger allocation to equity investments can generate a greater return over the long run. Additionally, the Company monitors the mix of investments in its portfolio to ensure alignment with its expected long-term pension obligations. The Company reviews the expected long-term rate of return annually and revises it as appropriate.

[0001564590-19-004520:notes:331]
Investments shall be made pursuant to the following objectives: 1) preserve purchasing power of plan’s assets based adjusted for inflation; 2) provide long term growth; 3) avoid significant volatility. Asset allocation shall be determined based on a long-term target allocation having 29% of assets invested in large-cap stocks, 11% in mid-cap stocks, 11% in small-cap stocks, 11% in international stocks, 34% in the broad bond market, and 3% in the real estate market, with little or none invested in cash. Both investment allocation and performance are reviewed periodically.

[0001564590-19-004520:notes:332]
The target allocation in 2019 and plan asset allocation at the end of 2018, in percentages, by asset category are as follows:

[0001564590-19-004520:notes:333]
|  |  | Target Allocation 2019 |  |  |  | December 31, 2018 |  |  |
| Equity securities (1) |  |  | 65 |  | % |  |  | 61 |  | % |
| Debt securities (2) |  |  | 35 |  |  |  |  | 38 |  |  |
| Cash and cash equivalents (3) |  |  | — |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-19-004520:notes:334]
The following table summarizes plan assets measured at fair value on December 31, 2018:

[0001564590-19-004520:notes:335]
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
|  |  | (In thousands) |  |
| Equity securities (1) |  | $ | 11,184 |  |  | $ | 11,184 |  |  | $ | — |  |  | $ | — |  |
| Debt securities (2) |  |  | 6,929 |  |  |  | 6,929 |  |  |  | — |  |  |  | — |  |
| Cash and cash equivalents (3) |  |  | 138 |  |  |  | 138 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 18,251 |  |  | $ | 18,251 |  |  | $ | — |  |  | $ | — |  |

[0001564590-19-004520:notes:336]
| (1) | Equity securities include U.S. and foreign exchange traded common and preferred stocks and mutual funds. Common and preferred shares issued by U.S. and non-U.S. corporations are traded actively on exchanges and price quotes for these shares are readily available. Holdings of corporate stock are categorized as Level 1 investments. |

[0001564590-19-004520:notes:337]
| (2) | Debt securities include the debt of the U.S. Treasury and U.S. and foreign corporate issuers. U.S. Treasury notes and bonds are actively traded and price quotes for these securities are readily available. Holdings of U.S. Treasury notes and bonds are categorized as Level 1 investments. |

[0001564590-19-004520:notes:338]
| (3) | Cash and cash equivalents include short-term U.S. government investment notes, short-term money market mutual funds, accrued income and cash held on account. Cash held on account and short- term U.S. government investment notes (including accrued income thereon) for which there is an active market and daily pricing for the security are categorized as Level 1 investments. |

[0001564590-19-004520:notes:339]
The Company seeks to maximize medium- to long-term returns of overall pension plan assets with reasonable levels of investment risk. One element of controlling overall investment risk is through diversification of asset allocation, among domestic and international equity and debt instruments. The plan's equity investments include foreign and domestic exchange traded equities across a range of industries and countries, but primarily in the domestic markets. The plan's debt securities are primarily invested in government and corporate issuers primarily in the domestic market.

[0001564590-19-004520:notes:340]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid:

[0001564590-19-004520:notes:341]
|  |  | (In thousands) |  |
| 2019 |  | $ | 1,116 |  |
| 2020 |  |  | 1,180 |  |
| 2021 |  |  | 1,262 |  |
| 2022 |  |  | 1,328 |  |
| 2023 |  |  | 1,423 |  |
| Years 2024 through 2028 |  |  | 8,483 |  |


## us-gaap:PreferredStockTextBlock

[0001564590-19-004520:notes:342]
| (17) | Preferred Stock |

[0001564590-19-004520:notes:343]
The board of directors has the authority, without action by stockholders, to designate and issue preferred stock in one or more series. The board of directors may also designate the rights, preferences and privileges of each series of preferred stock, any or all of which may be superior to the rights of the common stock. As of December 31, 2018, no shares of preferred stock were outstanding.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-004520:notes:344]
| (18) | Segment Information |

[0001564590-19-004520:notes:345]
The reportable segments reported below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. The Company has two reportable segments: PCB and E-M Solutions. The PCB reportable segment is comprised of multiple operating segments. Factors considered to determine whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production processes, type or classes of customers, distribution methods, and regulatory environments.

[0001564590-19-004520:notes:346]
The Company, including the chief operating decision maker, evaluates segment performance based on reportable segment income, which is operating income before amortization of intangibles. Interest expense and interest income are not presented by segment since they are not included in the measure of segment profitability reviewed by the chief operating decision maker. All inter-segment transactions have been eliminated.

[0001564590-19-004520:notes:347]
|  |  |  | For the Year Ended |  |
|  |  |  | December 31, 2018 |  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  |  | $ | 2,621,314 |  |  | $ | 2,448,506 |  |  | $ | 2,334,876 |  |
| E-M Solutions |  |  |  | 225,947 |  |  |  | 210,086 |  |  |  | 198,483 |  |
| Total net sales |  |  | $ | 2,847,261 |  |  | $ | 2,658,592 |  |  | $ | 2,533,359 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  |  | $ | 329,668 |  |  | $ | 322,486 |  |  | $ | 285,046 |  |
| E-M Solutions |  |  |  | 8,105 |  |  |  | 6,716 |  |  |  | 4,684 |  |
| Corporate |  |  |  | (115,662 | ) |  |  | (92,808 | ) |  |  | (92,025 | ) |
| Total operating segment income |  |  |  | 222,111 |  |  |  | 236,394 |  |  |  | 197,705 |  |
| Amortization of definite-lived intangibles (2) |  |  |  | (63,026 | ) |  |  | (23,634 | ) |  |  | (24,252 | ) |
| Total operating income |  |  |  | 159,085 |  |  |  | 212,760 |  |  |  | 173,453 |  |
| Total other expense |  |  |  | (69,317 | ) |  |  | (72,802 | ) |  |  | (106,451 | ) |
| Income before income taxes |  |  | $ | 89,768 |  |  | $ | 139,958 |  |  | $ | 67,002 |  |

[0001564590-19-004520:notes:348]
|  |  |  | For the Year Ended |  |
|  |  |  | December 31, 2018 |  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  |  | (In thousands) |  |
| Depreciation Expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  |  | $ | 153,637 |  |  | $ | 144,256 |  |  | $ | 149,466 |  |
| E-M Solutions |  |  |  | 2,850 |  |  |  | 2,471 |  |  |  | 2,540 |  |
| Corporate |  |  |  | 6,221 |  |  |  | 4,082 |  |  |  | 4,223 |  |
| Total depreciation expense |  |  | $ | 162,708 |  |  | $ | 150,809 |  |  | $ | 156,229 |  |
| Capital Expenditures: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  |  | $ | 103,318 |  |  | $ | 161,152 |  |  | $ | 74,318 |  |
| E-M Solutions |  |  |  | 3,918 |  |  |  | 5,438 |  |  |  | 3,206 |  |
| Corporate |  |  |  | 7,758 |  |  |  | 44,001 |  |  |  | 5,873 |  |
| Total capital expenditures |  |  | $ | 114,994 |  |  | $ | 210,591 |  |  | $ | 83,397 |  |

[0001564590-19-004520:notes:349]
|  |  |  | As of |  |
|  |  |  | December 31, 2018 |  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  |  | $ | 2,039,088 |  |  | $ | 1,991,049 |  |  | $ | 1,791,829 |  |
| E-M Solutions |  |  |  | 146,693 |  |  |  | 143,344 |  |  |  | 127,826 |  |
| Corporate |  |  |  | 1,271,722 |  |  |  | 647,489 |  |  |  | 580,421 |  |
| Total assets |  |  | $ | 3,457,503 |  |  | $ | 2,781,882 |  |  | $ | 2,500,076 |  |

[0001564590-19-004520:notes:350]
| (1) | Figures for the years ended January 1, 2018 and January 2, 2017 do not include Anaren, as the acquisition occurred on April 18, 2018. |

[0001564590-19-004520:notes:351]
| (2) | Amortization of definite-lived intangibles primarily relates to the PCB reportable segment. For the year ended December 31, 2018, $3,345 of amortization expense is included in cost of goods sold. |

[0001564590-19-004520:notes:352]
The Corporate category includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, information technology, facilities and human resources personnel, as well as global sales and marketing personnel and acquisition and integration costs associated with the acquisitions. Bank fees and legal, accounting, and other professional service costs associated with acquisitions of $13,279, $2,266 and $1,688 for the years ended December 31, 2018, January 1, 2018 and January 2, 2017, respectively, are included in Corporate.

[0001564590-19-004520:notes:353]
During the year ended January 2, 2017, the Company recorded impairment charges of $1,393 and $1,953 for the impairment of long-lived assets related to its PCB reportable segment and Corporate, respectively. There were no impairment charges for the years ended December 31, 2018 and January 1, 2018.

[0001564590-19-004520:notes:354]
The Company markets and sells its products in approximately 65 countries. Other than in the United States and China, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales and long-lived assets are as follows:

[0001564590-19-004520:notes:355]
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
|  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |
|  |  | (In thousands) |  |
| United States |  | $ | 1,260,739 |  |  | $ | 1,315,174 |  |  | $ | 850,511 |  |  | $ | 642,256 |  |  | $ | 1,119,086 |  |  | $ | 661,058 |  |
| China |  |  | 548,853 |  |  |  | 851,789 |  |  |  | 957,296 |  |  |  | 866,126 |  |  |  | 646,844 |  |  |  | 781,678 |  |
| Other |  |  | 1,037,669 |  |  |  | 28,029 |  |  |  | 850,785 |  |  |  | 23,984 |  |  |  | 767,429 |  |  |  | 23,124 |  |
| Total |  | $ | 2,847,261 |  |  | $ | 2,194,992 |  |  | $ | 2,658,592 |  |  | $ | 1,532,366 |  |  | $ | 2,533,359 |  |  | $ | 1,465,860 |  |

[0001564590-19-004520:notes:356]
Net sales are attributed to countries by country invoiced.


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-004520:notes:357]
| (19) | Earnings Per Share |

[0001564590-19-004520:notes:358]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the years ended December 31, 2018, January 1, 2018 and January 2, 2017:

[0001564590-19-004520:notes:359]
|  |  | For the Year Ended |  |
|  |  | December 31, 2018 |  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  | (In thousands, except per share data) |  |
| Basic earnings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings |  | $ | 173,584 |  |  | $ | 124,214 |  |  | $ | 34,861 |  |
| Diluted earnings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  | $ | 173,584 |  |  | $ | 124,214 |  |  | $ | 34,861 |  |
| Interest expense from convertible senior notes, net of tax |  |  | 11,906 |  |  |  | 13,803 |  |  |  | — |  |
| Diluted earnings |  | $ | 185,490 |  |  | $ | 138,017 |  |  | $ | 34,861 |  |
| Basic weighted average shares |  |  | 103,355 |  |  |  | 101,580 |  |  |  | 100,099 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,677 |  |  |  | 2,157 |  |  |  | 1,383 |  |
| Dilutive effect of outstanding warrants |  |  | 3,065 |  |  |  | 2,799 |  |  |  | — |  |
| Dilutive effect of assumed conversion of convertible senior notes outstanding |  |  | 25,939 |  |  |  | 25,940 |  |  |  | — |  |
| Diluted shares |  |  | 134,036 |  |  |  | 132,476 |  |  |  | 101,482 |  |
| Earnings per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.68 |  |  | $ | 1.22 |  |  | $ | 0.35 |  |
| Diluted |  | $ | 1.38 |  |  | $ | 1.04 |  |  | $ | 0.34 |  |

[0001564590-19-004520:notes:360]
For the years ended December 31, 2018, January 1, 2018 and January 2, 2017, PRUs, RSUs and stock options to purchase 528, 255 and 892 shares of common stock, respectively, were not considered in calculating diluted earnings per share because the options’ exercise prices or the total expected proceeds under the treasury stock method for performance-based stock units, restricted stock units or stock options was greater than the average market price of common shares during the applicable year and, therefore, the effect would be anti-dilutive.

[0001564590-19-004520:notes:361]
The below is a summary of amounts convertible to common stock related to convertible senior notes and related warrants:

[0001564590-19-004520:notes:362]
|  |  | For the Year Ended |  |
|  |  | December 31, 2018 |  |  | January 1, 2018 |  |  | January 2, 2017 |  |
|  |  | (In thousands) |  |
| Common stock related to convertible senior notes |  |  | 25,939 |  |  |  | 25,939 |  |  |  | 25,940 |  |
| Warrants to purchase common stock |  |  | 25,940 |  |  |  | 25,940 |  |  |  | 25,940 |  |

[0001564590-19-004520:notes:363]
For the year ended January 2, 2017, the effect of shares of common stock related to the Company’s convertible senior notes were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive.

[0001564590-19-004520:notes:364]
Outstanding warrants for the year ended January 2, 2017, to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock were greater than the average market price of common shares during the applicable year, and therefore, the effect would be anti-dilutive.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001564590-19-004520:notes:365]
| (20) | Related Party Transactions |

[0001564590-19-004520:notes:366]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $44,992, $51,985 and $55,649 for the years ended December 31, 2018, January 1, 2018 and January 2, 2017, respectively.

[0001564590-19-004520:notes:367]
The Company also sells PCBs to a related party which is a wholly owned subsidiary of an entity in which a member of the Board of Directors of the Company holds an equity interest. Sales to this related party for the years ended December 31, 2018, January 1, 2018 and January 2, 2017 were $8, $78 and $991, respectively.

[0001564590-19-004520:notes:368]
As of December 31, 2018 and January 1, 2018, the Company’s consolidated balance sheets included $10,630 and $14,452, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated balance sheets. Additionally, the Company’s consolidated balance sheets as of December 31, 2018 and January 1, 2018, included $13 and $33, respectively, in accounts receivable due from a related party for sales of PCBs, as mentioned above, and such balances are included as a component of accounts receivable, net on the consolidated balance sheets.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001564590-19-004520:notes:369]
| (21) | Noncontrolling Interest Holdings |

[0001564590-19-004520:notes:370]
During the fourth quarter of 2017, the Company acquired Desay Industrial’s 5% noncontrolling equity interest in the manufacturing facility in Huiyang, China otherwise owned by the Company for 56,400 Chinese RMB or $8,568. The Company recorded an increase to additional paid-in capital for the difference between the purchase price and the carrying value of the noncontrolling interest of $223.
