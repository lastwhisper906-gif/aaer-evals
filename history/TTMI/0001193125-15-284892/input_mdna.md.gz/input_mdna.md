# TTMI MD&A — 0001193125-15-284892


## mdna

[0001193125-15-284892:mdna:1]
[same as prior period, unchanged from 0001193125-15-170026:mdna:1]

[0001193125-15-284892:mdna:2]
[same as prior period, unchanged from 0001193125-15-170026:mdna:2]

[0001193125-15-284892:mdna:3]
[same as prior period, unchanged from 0001193125-15-170026:mdna:3]

[0001193125-15-284892:mdna:4]
We are a leading global
provider of time-critical and technologically complex printed circuit board products and backplane assemblies (i.e., PCBs populated with electronic components and other complex electronic assemblies). We focus on providing time-to-market and
advanced technology products and offer a one-stop manufacturing solution to our customers from engineering support to prototype development through final volume production. This one-stop manufacturing solution allows us to align technology
development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,000 customers in various markets
throughout the world, including manufacturers of networking/communications infrastructure products, smartphones and touchscreen tablets, as well as the aerospace and defense, automotive, high-end computing, and industrial/medical industries. Our
customers include both original equipment manufacturers and electronic manufacturing services providers.

[0001193125-15-284892:mdna:5]
On
May 31, 2015, we completed the acquisition of Viasystems Group, Inc. (Viasystems), for total consideration of $248.8 million in cash and 15.1 million shares of TTM common stock. Additionally, in connection with the completion of the
acquisition, we assumed and refinanced Viasystems’ debt, which was approximately $669.0 million. Viasystems is a worldwide provider of complex multi-layer rigid, flexible, and rigid-flex PCBs and electro-mechanical solutions (E-M Solutions).
Viasystems’ products are found in a wide variety of commercial products, including automotive engine controls, hybrid converters, automotive electronics for navigation, safety, and entertainment, telecommunications switching equipment, data
networking equipment, computer storage equipment, semiconductor test equipment, wind and solar energy applications, off-shore drilling equipment, communications applications, flight control systems, and complex industrial, medical, and other
technical instruments. Viasystems’ E-M Solutions services can be bundled with its PCBs to provide an integrated solution to customers. Viasystems operates 15 manufacturing facilities worldwide: eight in the United States, five in the
People’s Republic of China (China), one each in Canada and Mexico. Viasystems serves a diversified customer base of over 1,000 customers in various markets throughout the world.

[0001193125-15-284892:mdna:6]
For the first two quarters of 2015, we experienced higher demand in our Cellular Phone end market compared to that of the
same period in 2014. This increase in demand resulted in higher capacity utilization at our advanced technology plants resulting in higher net sales and gross margins. Additionally, we had improved operating efficiencies at certain of our plants in
our North America operating segment.

[0001193125-15-284892:mdna:7]
While our customers include both OEMs and EMS providers, we measure
customers based on OEM companies, as they are the ultimate end customers. Sales to our 10 largest customers accounted for 53% and 52% of our net sales for the quarters ended June 29, 2015 and June 30, 2014, respectively, and 55% and 53%
for the two quarters ended June 29, 2015 and June 30, 2014, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001193125-15-284892:mdna:8]
The following table shows the percentage of our net sales attributable to each of the principal end markets we serve for the periods indicated.

[0001193125-15-284892:mdna:9]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
| End Markets(1) |  | June 29,2015 |  |  | June 30,2014 |  |  | June 29,2015 |  |  | June 30,2014 |  |
| Aerospace/Defense |  |  | 15 | % |  |  | 18 | % |  |  | 15 | % |  |  | 17 | % |
| Automotive(3) |  |  | 7 |  |  |  | 2 |  |  |  | 5 |  |  |  | 2 |  |
| Cellular Phone(2) |  |  | 24 |  |  |  | 12 |  |  |  | 27 |  |  |  | 13 |  |
| Computing/Storage/Peripherals(2) |  |  | 11 |  |  |  | 14 |  |  |  | 11 |  |  |  | 16 |  |
| Medical/Industrial/Instrumentation |  |  | 12 |  |  |  | 11 |  |  |  | 11 |  |  |  | 11 |  |
| Networking/Communications |  |  | 26 |  |  |  | 40 |  |  |  | 27 |  |  |  | 37 |  |
| Other(2)(3) |  |  | 5 |  |  |  | 3 |  |  |  | 4 |  |  |  | 4 |  |
| Total |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001193125-15-284892:mdna:10]
[same as prior period, unchanged from 0001193125-15-170026:mdna:11]

[0001193125-15-284892:mdna:11]
| (2) | Smartphones are included in the Cellular Phone end market, tablet PCs are included in the Computing/Storage/Peripherals end market and other mobile devices such as e-readers are included in the Other end market. |

[0001193125-15-284892:mdna:12]
| (3) | Automotive has been reclassified from Other end market for the quarter and two quarters ended June 30, 2014. |

[0001193125-15-284892:mdna:13]
Purchase orders may be cancelled prior to shipment. We charge customers a
fee, based on the percentage completed, if an order is cancelled once it has entered production. We derive revenues primarily from the sale of PCBs and backplane assemblies using customer-supplied engineering and design plans. We recognize revenues
when persuasive evidence of a sales arrangement exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is reasonably assured — generally when products are shipped to the customer. Net
sales consist of gross sales less an allowance for returns, which typically have been less than 3% of gross sales. We provide our customers a limited right of return for defective PCBs and backplane assemblies. We record an estimate for sales
returns and allowances at the time of sale based on historical results.

[0001193125-15-284892:mdna:14]
[same as prior period, unchanged from 0001193125-15-170026:mdna:14]

[0001193125-15-284892:mdna:15]
[same as prior period, unchanged from 0001193125-15-170026:mdna:15]

[0001193125-15-284892:mdna:16]
General and administrative costs primarily
include the salaries for executive, finance, accounting, information technology, facilities and human resources personnel, as well as insurance expenses, expenses for accounting and legal assistance, incentive compensation expense, and gains or
losses on the sale or disposal of property, plant and equipment.

[0001193125-15-284892:mdna:17]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0001193125-15-284892:mdna:18]
Our consolidated condensed financial statements included in this report have been prepared in accordance with U.S. GAAP.
The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001193125-15-284892:mdna:19]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of
Operation, in our Annual Report on Form 10-K for the fiscal year ended December 29, 2014 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates
since December 29, 2014.

[0001193125-15-284892:mdna:20]
26

[0001193125-15-284892:mdna:21]
[same as prior period, unchanged from 0001193125-15-170026:mdna:20]

[0001193125-15-284892:mdna:22]
The quarter and two quarters ended June 30, 2014 do not include the results of operations from our acquisition of
Viasystems, as the acquisition occurred on May 31, 2015. The acquisition has had and will continue to have a significant effect on our operations as discussed in the various comparisons noted below:

[0001193125-15-284892:mdna:23]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 29, 2015 |  |  | June 30, 2014 |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 86.3 |  |  |  | 87.0 |  |  |  | 85.4 |  |  |  | 86.9 |  |
| Gross profit |  |  | 13.7 |  |  |  | 13.0 |  |  |  | 14.6 |  |  |  | 13.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.8 |  |  |  | 2.9 |  |  |  | 2.8 |  |  |  | 3.0 |  |
| General and administrative |  |  | 11.7 |  |  |  | 7.6 |  |  |  | 11.2 |  |  |  | 7.7 |  |
| Amortization of definite-lived intangibles |  |  | 0.8 |  |  |  | 0.8 |  |  |  | 0.7 |  |  |  | 0.8 |  |
| Impairment of long-lived assets |  |  | — |  |  |  | 0.6 |  |  |  | — |  |  |  | 0.3 |  |
| Gain on sale of asset |  |  | — |  |  |  | — |  |  |  | (0.3 | ) |  |  | — |  |
| Total operating expenses |  |  | 15.3 |  |  |  | 11.9 |  |  |  | 14.4 |  |  |  | 11.8 |  |
| Operating (loss) income |  |  | (1.6 | ) |  |  | 1.1 |  |  |  | 0.2 |  |  |  | 1.3 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.9 | ) |  |  | (2.0 | ) |  |  | (2.4 | ) |  |  | (2.1 | ) |
| Loss on extinguishment of debt |  |  | (0.2 | ) |  |  | — |  |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Other, net |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | (0.5 | ) |
| Total other expense, net |  |  | (2.9 | ) |  |  | (2.0 | ) |  |  | (2.5 | ) |  |  | (2.7 | ) |
| Loss before income taxes |  |  | (4.5 | ) |  |  | (0.9 | ) |  |  | (2.3 | ) |  |  | (1.4 | ) |
| Income tax (provision) benefit |  |  | (3.7 | ) |  |  | (0.1 | ) |  |  | (2.0 | ) |  |  | 0.2 |  |
| Net loss |  |  | (8.2 | ) |  |  | (1.0 | ) |  |  | (4.3 | ) |  |  | (1.2 | ) |
| Less: Net income attributable to noncontrolling interest |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net loss attributable to TTM Technologies, Inc. stockholders |  |  | (8.2 | )% |  |  | (1.0 | )% |  |  | (4.3 | )% |  |  | (1.2 | )% |

[0001193125-15-284892:mdna:24]
We currently manage our worldwide operations based on three segments: 1) Asia Pacific,
which consists of five PCB fabrication plants, 2) North America, which consists of seven domestic PCB fabrication plants, including a facility that provides follow-on value-added services primarily for one of the PCB fabrication plants, and one
backplane assembly plant in Shanghai, China, which is managed in conjunction with the Company’s U.S. operations, and 3) Viasystems, which consist of 15 manufacturing facilities worldwide: eight in the United States, five in China, one each in
Canada and Mexico.

[0001193125-15-284892:mdna:25]
The following table compares net sales by reportable segment for the quarter and two
quarters ended June 29, 2015 and June 30, 2014:

[0001193125-15-284892:mdna:26]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 29, 2015 |  |  | June 30, 2014 |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 218,650 |  |  | $ | 166,699 |  |  | $ | 424,015 |  |  | $ | 332,365 |  |
| North America |  |  | 133,794 |  |  |  | 131,594 |  |  |  | 258,115 |  |  |  | 258,183 |  |
| Viasystems |  |  | 93,194 |  |  |  | — |  |  |  | 93,194 |  |  |  | — |  |
| Total sales |  |  | 445,638 |  |  |  | 298,293 |  |  |  | 775,324 |  |  |  | 590,548 |  |
| Inter-segment sales |  |  | (193 | ) |  |  | (658 | ) |  |  | (715 | ) |  |  | (1,018 | ) |
| Total net sales |  | $ | 445,445 |  |  | $ | 297,635 |  |  | $ | 774,609 |  |  | $ | 589,530 |  |

[0001193125-15-284892:mdna:27]
27

[0001193125-15-284892:mdna:28]
[same as prior period, unchanged from 0001193125-15-170026:mdna:27]

[0001193125-15-284892:mdna:29]
Net sales increased $147.8 million, or 49.7%, from $297.6 million for the second quarter of 2014 to $445.4 million for the
second quarter of 2015 due to a significant extent from the acquisition of Viasystems, which accounted for $93.2 million in sales in the second quarter of 2015. Additionally, net sales for the Asia Pacific operating segment, excluding inter-segment
sales, increased $52.5 million, or 31.6%, from $166.0 million in the second quarter of 2014 to $218.5 million in the second quarter of 2015. This increase is primarily due to higher demand in our Cellular Phone end market, partially offset
with lower demand in our Networking/Communications end markets, which resulted in a 12% increase in PCB shipments from the second quarter of 2014. Additionally, the average PCB selling price increased 17%, which was driven by a product mix shift.
Net sales for the North America operating segment also increased $2.2 million, or 1.7%, from $131.6 million in the second quarter of 2014 to $133.8 million in the second quarter of 2015. This increase was primarily due to higher demand in our
Medical/Industrial/Instrumentation end market. This increase in net sales was primarily the result of a 1% increase in production and a 5% increase in the average PCB selling price from the second quarter of 2014.

[0001193125-15-284892:mdna:30]
Net sales increased $185.1 million, or 31.4%, from $589.5 million for the first two quarters of 2014 to $774.6 million
for the first two quarters of 2015 due to a significant extent from the acquisition of Viasystems, which accounted for $93.2 million in sales in the second quarter 2015. Additionally, net sales for the Asia Pacific operating segment, excluding
inter-segment sales, increased $92.0 million, or 27.8%, from $331.3 million in the first two quarters of 2014 to $423.3 million in the first two quarters of 2015. This increase is primarily due to higher demand in our Cellular Phone end
market, partially offset with lower demand in our Networking/Communications end markets, which resulted in a 12% increase in PCB shipments from the first two quarters of 2014. Additionally, the average PCB selling price increased 14%, which was
driven by a product mix shift. Net sales for the North America operating segment decreased $0.1 million, from $258.2 million in the first two quarters of 2014 to $258.1 million in the first two quarters of 2015. This decrease was primarily due to
lower demand in our Computing/Storage/Peripherals end market, offset with higher demand in our Medical/Industrial/Instrumentation end market. This decrease in net sales was primarily the result of a 1% decrease in production, partially offset by a
3% increase in the average PCB selling price from the first two quarters of 2014.

[0001193125-15-284892:mdna:31]
[same as prior period, unchanged from 0001193125-15-170026:mdna:31]

[0001193125-15-284892:mdna:32]
Gross margin increased from 13.0% for the second quarter of 2014 to 13.7% for the second quarter of 2015. Gross margin for
the Asia Pacific segment increased from 10.7% for the second quarter of 2014 to 14.9% for the second quarter of 2015, and from 11.8% for the first two quarters of 2014 to 15.4% for the first two quarters of 2015, both primarily due to higher
utilization at our advanced technology plants in both the second quarter and the first two quarters of 2015. Gross margin for the North America segment increased from 15.9% for the second quarter of 2014 to 18.0% for the second quarter of 2015 and
from 14.7% for the first two quarters of 2014 to 16.7% for the first two quarters of 2015, primarily due to improved operating efficiencies at certain plants in both the second quarter and first two quarters of 2015.

[0001193125-15-284892:mdna:33]
[same as prior period, unchanged from 0001193125-15-170026:mdna:35]

[0001193125-15-284892:mdna:34]
Selling and marketing expenses increased $3.7 million, from $8.6 million for the second quarter of 2014 to $12.3 million for the second quarter of 2015. Selling and marketing expenses increased $3.8
million, from $18.0 million for the first two quarters of 2014 to $21.8 million for the first two quarters of 2015. The increase in expense for the quarter and two quarters of 2015 primarily relates to the acquisition of Viasystems on May 31,
2015. As a percentage of net sales, selling and marketing expenses were 2.9% for the second quarter of 2014, as compared to 2.8% for the second quarter of 2015 and 3.0% for the first two quarters of 2014, as compared to 2.8% for the first two
quarters of 2015. The decrease in selling and marketing expense as a percentage of net sales for the quarter and first two quarters of 2015 is primarily due to higher net sales.

[0001193125-15-284892:mdna:35]
[same as prior period, unchanged from 0001193125-15-170026:mdna:37]

[0001193125-15-284892:mdna:36]
General and
administrative expenses increased $29.3 million from $22.7 million, or 7.6% of net sales, for the second quarter of 2014 to $52.0 million, or 11.7% of net sales, for the second quarter of 2015. General and administrative expenses increased
$41.3 million from $45.2 million, or 7.7% of net sales, for the first two quarters of 2014 to $86.5 million, or 11.2% of net sales, for the first two quarters of 2015. The increase in expense primarily relates to $22.6 million and $30.9
million of acquisition-related costs for the second quarter and first two quarters of 2015, respectively, related to the acquisition of Viasystems on May 31, 2015, and one month of general and administrative expense incurred by Viasystems post
acquisition through June 29, 2015.

[0001193125-15-284892:mdna:37]
[same as prior period, unchanged from 0001193125-15-170026:mdna:39]

[0001193125-15-284892:mdna:38]
Other expense, net increased $7.1 million from $5.8 million for the second quarter of 2014 to $12.9 million for the second
quarter of 2015. The increase in other expense, net was primarily due to an increase in interest expense related to a new long-term borrowing and a revolver loan aggregating $1,030.0 million at a weighted average interest rate of 5.7% related to the
acquisition of Viasystems on May 31, 2015 combined with a $0.8 million extinguishment of debt charge associated with repayment of existing long-term debt on May 31, 2015.

[0001193125-15-284892:mdna:39]
Other expense, net increased $3.2 million from $15.9 million for the first two quarters of 2014 to $19.1 million for the
first two quarters of 2015. The increase in other expense, net was primarily due to an increase in interest expense related to a new long-term borrowing and a revolver loan aggregating $1,030.0 million at a weighted average interest rate of 5.7%
related to the acquisition of Viasystems on May 31, 2015 combined with a $0.8 million extinguishment of debt charge associated with repayment of existing long-term debt on May 31, 2015. The increase in other expense, net was partially
offset by significantly lower foreign currency transaction losses, which for the first quarter of 2014 amounted to $3.6 million due to the rapid depreciation of the Chinese RMB against the U.S. Dollar.

[0001193125-15-284892:mdna:40]
[same as prior period, unchanged from 0001193125-15-170026:mdna:41]

[0001193125-15-284892:mdna:41]
The provision for income taxes increased by $16.1 million from $0.5 million tax expense for the second quarter of 2014 to $16.6 million for the second quarter of 2015. The provision for income taxes
increased $16.6 million from $1.3 million of tax benefit for the first two quarters of 2014 to $15.3 million of tax expense for the first two quarters of 2015. The increase in income tax expense for the second quarter and first two quarters of 2015
is primarily due to providing for a full valuation allowance on existing U.S. deferred tax assets, which was offset by the reversal of deferred tax liabilities related to the Company’s decision to indefinitely reinvest its foreign earnings
attributable to the backplane assembly facility in Shanghai, China. Further, the income tax expense in 2015 is higher due to inclusion of Viasystems earnings from foreign subsidiaries in the second quarter of 2015.

[0001193125-15-284892:mdna:42]
Our effective tax rate is primarily impacted by the favorable tax rates in China and Hong Kong, generation of other
credits and deductions, and certain non-deductible items. U.S. and certain foreign losses generated are not realizable, and thus no income tax benefit has been recognized on these losses. As a result of our cumulative tax losses in the U.S. and
certain foreign jurisdictions, and the full utilization of our loss carryback opportunities, we have concluded that a full valuation allowance should be recorded in such jurisdictions. In certain other foreign jurisdictions where we do not have
cumulative losses, we had net deferred income tax liabilities of approximately $1.2 million as of June 29, 2015 and net deferred tax assets of $2.9 million as of December 29, 2014, respectively.

[0001193125-15-284892:mdna:43]
[same as prior period, unchanged from 0001193125-15-170026:mdna:43]

[0001193125-15-284892:mdna:44]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, and term and revolving debt. Our principal uses of cash have been to finance capital
expenditures, acquire Viasystems, meet debt service requirements, fund working capital requirements, and refinance existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital
requirements will continue to be the principal demands on our cash in the future.

[0001193125-15-284892:mdna:45]
As of June 29, 2015,
we had net working capital of approximately $311.0 million compared to $302.1 million as of December 29, 2014. The increase in working capital is primarily attributable to an increase in accounts and notes receivable, partially reduced by lower
cash, somewhat offset by increases in accounts payable, accrued salaries and other accrued expenses, partially reduced by lower short-term debt. Cash flow provided by operating activities during the first two quarters of 2015 was $82.9 million
as compared to $33.6 million in the same period in 2014. The improved cash flow was the result of stronger operational performance as well as working capital changes mentioned above.

[0001193125-15-284892:mdna:46]
As of June 29, 2015, we had cash and cash equivalents of approximately $148.9 million, of which approximately
$100.6 million was held by our foreign subsidiaries. Of the cash and cash equivalents held by our foreign subsidiaries as of June 29, 2015, $98.2 million was located in Asia and $2.4 million was located in Europe and other locations.
Cash and cash equivalents held by our foreign locations are expected to be used in local operations. As of June 29, 2015, the Company also had $18.5 million of restricted cash located in Asia of which $15.3 million is expected to become
unrestricted by end of the third quarter of 2015.

[0001193125-15-284892:mdna:47]
Our 2015 capital expenditure plan is expected to total
approximately $145 million (of which approximately $80 million relates to our Asia Pacific operating segment). The expenditures will fund capital equipment purchases to increase production capacity, especially for advanced technology manufacturing,
comply with changing environmental regulations, replace aging equipment, and expand our technological capabilities. While our cash capital expenditures are expected to be approximately $145 million in 2015, we expect new capital expenditure
purchases in 2015 to approximate $85 million.

[0001193125-15-284892:mdna:48]
Term and Revolving Loans

[0001193125-15-284892:mdna:49]
On May 31, 2015, in conjunction with the acquisition of Viasystems, we entered into a $950.0 million Term Loan Credit
Agreement (Term Loan). Additionally, we entered into a $150.0 million U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and a $150.0 million Asia Asset-Based Lending Credit agreement (Asia ABL). We drew $80.0 million of the U.S. ABL at the
closing of the acquisition of Viasystems.

[0001193125-15-284892:mdna:50]
The Term Loan Credit agreement was issued at a discount at 96.5%
and bears interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus an applicable interest margin of 5.0%. At June 29, 2015, the weighted average interest rate on the outstanding borrowings under the Term Loan was 6.0%. There is no
provision, other than an event of default, for the interest margin to increase. The Term Loan will mature on May 31, 2021. The Term Loan is secured by a significant amount of the assets of the Company and its domestic subsidiaries and a pledge
of 65% of the voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to our convertible senior notes. See Convertible Senior Notes due 2020 below.

[0001193125-15-284892:mdna:51]
The U.S. ABL consists of three tranches comprised of a revolving credit facility of up to $150.0 million, a letter of
credit facility of up to $75.0 million, and swingline loans of up to $30.0 million, provided that at no time may amounts outstanding under the tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the
principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 175 basis points. At June 29, 2015, the weighted average interest rate
on the outstanding borrowings under the U.S. ABL was 1.9%. Beginning in 2016, the applicable margin can vary based on the remaining availability of the facility, from 150 to 200 basis points for LIBOR-based loans. The U.S. ABL will mature on
May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and inventories as well as by a significant amount of the assets of the Company and its domestic subsidiaries and a pledge of 65% of the
voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to our convertible senior notes. See Convertible Senior Notes due 2020 below. At June 29, 2015, $80.0 million of the U.S. ABL was outstanding and
classified as a current liability.

[0001193125-15-284892:mdna:52]
The Company and its domestic subsidiaries have fully and unconditionally
guaranteed the full and timely payment of all Term Loan and U.S. ABL related obligations.

[0001193125-15-284892:mdna:53]
The Asia ABL
consists of two tranches comprised of a revolving credit facility of up to $150.0 million and a letter of credit facility of up to $100.0 million provided that at no time may amounts outstanding under both tranches exceed in aggregate $150.0 million
or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 175 basis points. There is no
provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion by our Asia Pacific cash and receivables and are structurally
senior to our domestic obligations, including our convertible senior notes. See Convertible Senior Notes due 2020 below. Our Asia Pacific subsidiary and certain of its subsidiaries have fully and unconditionally guaranteed the full and timely
payment of all Asia ABL related obligations. At June 29, 2015, none of the Asia ABL was outstanding.

[0001193125-15-284892:mdna:54]
We
are required to make scheduled payments of the outstanding Term Loan balance on a quarterly basis beginning October 1, 2015. Any other outstanding balances under the Term Loan are due at the maturity date of May 31, 2021. Borrowings under
the Term Loan are subject to various financial and operating covenants including maintaining a maximum total leverage ratio. Under the occurrence of certain events, the U.S. ABL and the Asia ABL are subject to various financial and operational
covenants, including maintaining minimum fixed charges coverage ratios. At June 29, 2015, we were in compliance with the covenants under the Term Loan, the U.S. ABL and the Asia ABL.

[0001193125-15-284892:mdna:55]
We are also required to pay a commitment fee of 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL.
The U.S. ABL commitment fee may vary from 0.25% to 0.375% based on utilization levels. The Company incurred total commitment fees related to unused borrowing availability of $0.2 million and $0.4 million for the quarter and two quarters ended
June 29, 2015, respectively. As of June 29, 2015, the outstanding amount of the Term Loan was $950.0 million, of which $7.1 million is due for repayment within one year and is included as short-term debt, with the remaining $942.9 million
included as long-term debt. Additionally, $80.0 million of the U.S. ABL and none of the Asia ABL was outstanding as of June 29, 2015. Available borrowing capacity under the U.S. ABL and Asia ABL was $65.4 million, which includes $4.6 million of
outstanding letters of credit mentioned below, and $150.0 million, respectively, at June 29, 2015.

[0001193125-15-284892:mdna:56]
Letters of Credit

[0001193125-15-284892:mdna:57]
We have up to $75.0 million and $100.0 million Letters of Credit Facilities available under the U.S. ABL and the Asia ABL,
respectively. As of June 29, 2015, letters of credit in the amount of $4.6 million were outstanding under the U.S. ABL. We have other standby letters of credit outstanding in the amount of $20.5 million which expire between July 2, 2015
and May 16, 2016. These other standby letters of credit are securitized by cash collateral. As such, we have recorded such cash as restricted on the consolidated condensed balance sheet as of June 29, 2015.

[0001193125-15-284892:mdna:58]
Chinese Revolver

[0001193125-15-284892:mdna:59]
We are party to a revolving loan credit facility with a lender in China. Under this arrangement, the lender has made available to us approximately $37.1 million in unsecured borrowing with all terms of
the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in December 2015. As of June 29, 2015, the Chinese Revolver
had not been drawn upon.

[0001193125-15-284892:mdna:60]
Convertible Senior Notes due 2020

[0001193125-15-284892:mdna:61]
We issued 1.75% convertible senior notes due December 15, 2020, in a public offering for an aggregate principal
amount of $250.0 million. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured
obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the convertible senior
notes.

[0001193125-15-284892:mdna:62]
In connection with the issuance of the convertible senior notes due 2020, we entered into a
convertible note hedge and warrant transaction (the Call Spread Transaction), with respect to our common stock. The convertible note hedge consists of our option to purchase up to 28.0 million common stock shares at a price of $9.64 per share.
The hedge expires on December 15, 2020 and can only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, we sold warrants to purchase 28.0 million shares of our common stock at a price of
$14.26 per share. The warrants expire ratably from March 2021 through January 2022. The Call Spread Transaction has no effect on the terms of the convertible senior notes due 2020 and reduces potential dilution by effectively increasing the
conversion price of the convertible senior notes due 2020 to $14.26 per share of our common stock.

[0001193125-15-284892:mdna:63]
Based on
our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of convertible senior notes, and term and revolving debt will be adequate to meet our currently anticipated capital expenditure,
debt service, and working capital needs for the next 12 months. We expect that servicing debt, funding working capital requirements, financing capital expenditures, and financing acquisitions will continue to be the principal demands on our cash.

[0001193125-15-284892:mdna:64]
[same as prior period, unchanged from 0001193125-15-170026:mdna:64]

[0001193125-15-284892:mdna:65]
The following table provides information on our contractual obligations as of June 29, 2015:

[0001193125-15-284892:mdna:66]
|  |  | Total |  |  | Less Than1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After5 Years |  |
|  |  | (In thousands) |  |
| Contractual Obligations(1) |  |  |  |
| Long-term debt obligations |  | $ | 1,030,001 |  |  | $ | 87,126 |  |  | $ | 76,000 |  |  | $ | 95,000 |  |  | $ | 771,875 |  |
| Convertible debt obligations |  |  | 250,000 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 250,000 |  |
| Interest on debt obligations |  |  | 338,937 |  |  |  | 54,133 |  |  |  | 120,077 |  |  |  | 109,300 |  |  |  | 55,427 |  |
| Foreign currency forward contract liabilities |  |  | 2,828 |  |  |  | 2,828 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Equipment payables |  |  | 27,395 |  |  |  | 27,395 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 68,918 |  |  |  | 63,955 |  |  |  | 4,963 |  |  |  | — |  |  |  | — |  |
| Operating lease commitments |  |  | 30,663 |  |  |  | 8,846 |  |  |  | 11,158 |  |  |  | 5,429 |  |  |  | 5,230 |  |
| Total contractual obligations |  | $ | 1,748,742 |  |  | $ | 244,283 |  |  | $ | 212,198 |  |  | $ | 209,729 |  |  | $ | 1,082,532 |  |

[0001193125-15-284892:mdna:67]
| (1) | Unrecognized uncertain tax benefits of $31.7 million are not included in the table above as we have not determined when the amount will be paid. |

[0001193125-15-284892:mdna:68]
[same as prior period, unchanged from 0001193125-15-170026:mdna:68]

[0001193125-15-284892:mdna:69]
[same as prior period, unchanged from 0001193125-15-170026:mdna:69]

[0001193125-15-284892:mdna:70]
[same as prior period, unchanged from 0001193125-15-170026:mdna:70]

[0001193125-15-284892:mdna:71]
As manufacturers of electronic components, orders for our products generally correspond to the production schedules of our customers. We historically experience higher net sales in the third and fourth
quarters due to end customer demand in the fourth quarter for consumer electronics products. Seasonal fluctuations also include the Chinese New Year holidays in the first quarter, which typically results in lower net sales. We attribute this decline
to shutdowns of our customers’ manufacturing facilities surrounding the Chinese New Year public holidays, which normally occur in January or February of each year.
