# TTMI notes — 0001193125-15-284892


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-15-284892:notes:1]
The Company evaluates segment performance based on operating
 segment income, which is operating income before amortization of
 intangibles. Interest expense and interest income are not presented
 by segment since they are not included in the measure of segment
 profitability reviewed by the chief operating decision maker. All
 inter-segment transactions have been eliminated.

[0001193125-15-284892:notes:2]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 29, 2015 |  |  | June 30, 2014 |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 218,650 |  |  | $ | 166,699 |  |  | $ | 424,015 |  |  | $ | 332,365 |  |
| North America |  |  | 133,794 |  |  |  | 131,594 |  |  |  | 258,115 |  |  |  | 258,183 |  |
| Viasystems (1) |  |  | 93,194 |  |  |  | — |  |  |  | 93,194 |  |  |  | — |  |
| Total sales |  |  | 445,638 |  |  |  | 298,293 |  |  |  | 775,324 |  |  |  | 590,548 |  |
| Inter-segment sales |  |  | (193 | ) |  |  | (658 | ) |  |  | (715 | ) |  |  | (1,018 | ) |
| Total net sales |  | $ | 445,445 |  |  | $ | 297,635 |  |  | $ | 774,609 |  |  | $ | 589,530 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asia Pacific |  | $ | 13,654 |  |  | $ | (1,925 | ) |  | $ | 28,095 |  |  | $ | 1,942 |  |
| North America |  |  | (13,514 | ) |  |  | 7,359 |  |  |  | (17,816 | ) |  |  | 10,181 |  |
| Viasystems (1) |  |  | (3,290 | ) |  |  | — |  |  |  | (3,290 | ) |  |  | — |  |
| Total operating segment (loss) income |  |  | (3,150 | ) |  |  | 5,434 |  |  |  | 6,989 |  |  |  | 12,123 |  |
| Amortization of definite-lived intangibles |  |  | (3,910 | ) |  |  | (2,236 | ) |  |  | (5,784 | ) |  |  | (4,472 | ) |
| Total operating (loss) income |  |  | (7,060 | ) |  |  | 3,198 |  |  |  | 1,205 |  |  |  | 7,651 |  |
| Total other expense |  |  | (12,899 | ) |  |  | (5,794 | ) |  |  | (19,079 | ) |  |  | (15,901 | ) |
| Loss before income taxes |  | $ | (19,959 | ) |  | $ | (2,596 | ) |  | $ | (17,874 | ) |  | $ | (8,250 | ) |

[0001193125-15-284892:notes:3]
| (1) | The quarter and two quarters ended June 30, 2014 do not include Viasystems, as the acquisition occurred on May 31, 2015. |

[0001193125-15-284892:notes:4]
The Company will continue to evaluate segment performance based
 on operating segment income, which is operating income before
 amortization of intangibles for the new PCB and E-M Solutions
 reportable operating segments. Interest expense and interest income
 are not presented by segment since they are not included in the
 measure of segment profitability reviewed by the chief operating
 decision maker. The below is presented as if the Company had two
 operating segments under the new structure.

[0001193125-15-284892:notes:5]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 29, 2015 |  |  | June 30, 2014 |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 417,021 |  |  | $ | 277,296 |  |  | $ | 726,813 |  |  | $ | 549,606 |  |
| E-M Solutions |  |  | 28,424 |  |  |  | 20,339 |  |  |  | 47,796 |  |  |  | 39,924 |  |
| Total sales |  |  | 445,445 |  |  |  | 297,635 |  |  |  | 774,609 |  |  |  | 589,530 |  |
| Inter-segment sales |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total net sales |  | $ | 445,445 |  |  | $ | 297,635 |  |  | $ | 774,609 |  |  | $ | 589,530 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 30,456 |  |  | $ | 8,869 |  |  | $ | 53,716 |  |  | $ | 19,399 |  |
| E-M Solutions |  |  | (110 | ) |  |  | 1,477 |  |  |  | 541 |  |  |  | 2,469 |  |
| Corporate |  |  | (33,496 | ) |  |  | (4,912 | ) |  |  | (47,268 | ) |  |  | (9,745 | ) |
| Total operating segment (loss) income |  |  | (3,150 | ) |  |  | 5,434 |  |  |  | 6,989 |  |  |  | 12,123 |  |
| Amortization of definite-lived intangibles |  |  | (3,910 | ) |  |  | (2,236 | ) |  |  | (5,784 | ) |  |  | (4,472 | ) |
| Total operating (loss) income |  |  | (7,060 | ) |  |  | 3,198 |  |  |  | 1,205 |  |  |  | 7,651 |  |
| Total other expense |  |  | (12,899 | ) |  |  | (5,794 | ) |  |  | (19,079 | ) |  |  | (15,901 | ) |
| Loss before income taxes |  | $ | (19,959 | ) |  | $ | (2,596 | ) |  | $ | (17,874 | ) |  | $ | (8,250 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-15-284892:notes:6]
(11) Significant
 Customers and Concentration of Credit Risk

[0001193125-15-284892:notes:7]
In the
 normal course of business, the Company extends credit to its
 customers, which are in diverse end markets. Many customers to
 which the Company extends credit are located outside the United
 States, with the exception of certain customers in the aerospace
 and defense industries. The Company performs ongoing credit
 evaluations of customers, does not require collateral, and
 considers the credit risk profile of the entity from which the
 receivable is due in further evaluating collection risk.

[0001193125-15-284892:notes:8]
[same as prior period, unchanged from 0001193125-15-170026:notes:27]

[0001193125-15-284892:notes:9]
For
 the quarter ended June 29, 2015, one customer accounted for
 approximately 22% of the Company’s net sales. For the quarter
 ended June 30, 2014, no one customer accounted for 10% or more
 of the Company’s net sales. For the two quarters ended
 June 29, 2015 and June 30, 2014, one customer accounted
 for approximately 24% and 12%, respectively, of the Company’s
 net sales. There were no other customers that accounted for 10% or
 more of net sales for the quarters or two quarters ended
 June 29, 2015 and June 30, 2014.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-15-284892:notes:10]
The
 following is a reconciliation of the numerator and denominator used
 to calculate basic loss per share and diluted loss per share for
 the quarter and two quarters ended June 29, 2015 and
 June 30, 2014:

[0001193125-15-284892:notes:11]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 29, 2015 |  |  | June 30, 2014 |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net loss attributable to TTM Technologies, Inc. stockholders |  | $ | (36,612 | ) |  | $ | (3,104 | ) |  | $ | (33,166 | ) |  | $ | (6,903 | ) |
| Weighted average shares outstanding |  |  | 88,834 |  |  |  | 83,336 |  |  |  | 86,218 |  |  |  | 83,130 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Diluted shares |  |  | 88,834 |  |  |  | 83,336 |  |  |  | 86,218 |  |  |  | 83,130 |  |
| Loss per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.41 | ) |  | $ | (0.04 | ) |  | $ | (0.38 | ) |  | $ | (0.08 | ) |
| Diluted |  | $ | (0.41 | ) |  | $ | (0.04 | ) |  | $ | (0.38 | ) |  | $ | (0.08 | ) |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-15-284892:notes:12]
[same as prior period, unchanged from 0001193125-15-170026:notes:36]

[0001193125-15-284892:notes:13]
Inventories as of June 29, 2015 and December 29, 2014
 consisted of the following:

[0001193125-15-284892:notes:14]
|  |  | As of |  |
|  |  | June 29, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 78,316 |  |  | $ | 44,477 |  |
| Work-in-process |  |  | 112,107 |  |  |  | 57,544 |  |
| Finished goods |  |  | 104,917 |  |  |  | 43,166 |  |
|  |  | $ | 295,340 |  |  | $ | 145,187 |  |


## us-gaap:ScheduleOfShareBasedCompensationArrangementByShareBasedPaymentAwardPerformanceBasedUnitsVestedAndExpectedToVestTableTextBlock

[0001193125-15-284892:notes:15]
PRUs activity for the two quarters ended June 29, 2015 was
 as follows:

[0001193125-15-284892:notes:16]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding target shares at December 29, 2014 |  |  | 275 |  |  | $ | 8.03 |  |
| Granted |  |  | 295 |  |  |  | 7.22 |  |
| Change in units due to annual financial target performance achievement |  |  | 22 |  |  |  | 7.22 |  |
| Outstanding target shares at June 29, 2015 |  |  | 592 |  |  | $ | 7.60 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-15-284892:notes:17]
(15) Stock-Based
 Compensation

[0001193125-15-284892:notes:18]
Stock-based compensation expense is recognized in the
 accompanying consolidated condensed statements of operations as
 follows:

[0001193125-15-284892:notes:19]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 29, 2015 |  |  | June 30, 2014 |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 243 |  |  | $ | 199 |  |  | $ | 468 |  |  | $ | 462 |  |
| Selling and marketing |  |  | 269 |  |  |  | 253 |  |  |  | 540 |  |  |  | 588 |  |
| General and administrative |  |  | 1,802 |  |  |  | 1,479 |  |  |  | 3,346 |  |  |  | 3,049 |  |
| Stock-based compensation expense recognized |  |  | 2,314 |  |  |  | 1,931 |  |  |  | 4,354 |  |  |  | 4,099 |  |
| Income tax benefit recognized |  |  | (606 | ) |  |  | (494 | ) |  |  | (1,128 | ) |  |  | (1,063 | ) |
| Total stock-based compensation expense after income taxes |  | $ | 1,708 |  |  | $ | 1,437 |  |  | $ | 3,226 |  |  | $ | 3,036 |  |

[0001193125-15-284892:notes:20]
[same as prior period, unchanged from 0001193125-15-170026:notes:90]

[0001193125-15-284892:notes:21]
[same as prior period, unchanged from 0001193125-15-170026:notes:91]

[0001193125-15-284892:notes:22]
The Company records stock-based compensation expense for PRU
 awards granted based on management’s periodic assessment of
 the probability of the PRU awards vesting. For the quarter and two
 quarters ended June 29, 2015, management determined that
 vesting of the PRU awards was probable. PRUs activity for the two
 quarters ended June 29, 2015 was as follows:

[0001193125-15-284892:notes:23]
[same as prior period, unchanged from 0001193125-15-170026:notes:94]

[0001193125-15-284892:notes:24]
The Company granted 331 and 73 RSUs during the quarters ended
 June 29, 2015 and June 30, 2014, respectively and 1,301
 and 833 restricted stock units during the two quarters ended
 June 29, 2015 and June 30, 2014, respectively. The RSUs
 granted have a weighted-average fair value per unit of $10.19 and
 $7.96 for the quarters ended June 29, 2015 and June 30,
 2014, respectively and $9.15 and $8.00 for the two quarters ended
 June 29, 2015 and June 30, 2014, respectively. The fair
 value for RSUs granted is based on the closing share price of the
 Company’s common stock on the date of grant.

[0001193125-15-284892:notes:25]
[same as prior period, unchanged from 0001193125-15-170026:notes:96]

[0001193125-15-284892:notes:26]
The Company did not grant any stock option awards during the
 quarter or two quarters ended June 29, 2015 and June 30,
 2014.

[0001193125-15-284892:notes:27]
[same as prior period, unchanged from 0001193125-15-170026:notes:98]

[0001193125-15-284892:notes:28]
The following is a summary of total unrecognized compensation
 costs as of June 29, 2015:

[0001193125-15-284892:notes:29]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |
|  |  | (In thousands) |  |  | (years) |
| RSU awards |  | $ | 14,085 |  |  | 1.6 |
| PRU awards |  |  | 2,267 |  |  | 1.7 |
|  |  | $ | 16,352 |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-284892:notes:30]
(16) Segment
 Information

[0001193125-15-284892:notes:31]
The operating segments reported below are the Company’s
 segments for which separate financial information is available and
 upon which operating results are evaluated by the chief operating
 decision maker to assess performance and to allocate resources. The
 Company manages its worldwide operations based on three segments:
 1) Asia Pacific, which consists of five PCB fabrication plants, 2)
 North America, which consists of seven domestic PCB fabrication
 plants, including a facility that provides follow-on value-added
 services primarily for one of the PCB fabrication plants, and one
 backplane assembly plant in Shanghai, China, which is managed in
 conjunction with the Company’s U.S. operations, and 3)
 Viasystems, which consists of 15 manufacturing facilities
 worldwide: eight in the United States, five in China, one each in
 Canada and Mexico.

[0001193125-15-284892:notes:32]
Each segment operates predominantly in the same industry with
 production facilities that produce customized products for its
 customers and use similar means of product distribution.

[0001193125-15-284892:notes:33]
The Company accounts for inter-segment sales and transfers as
 if the sale or transfer were to third parties: at arms length and
 consistent with the Company’s revenue recognition policy. The
 inter-segment sales for the quarter and the two quarters ended
 June 29, 2015 are sales primarily from the Asia Pacific
 operating segment to the North America operating
 segment.

[0001193125-15-284892:notes:34]
As a result of the May 31, 2015 acquisition of Viasystems
 and the ongoing integration activities, the Company has reassessed
 its reportable operating segments and determined that going forward
 it plans to have two reportable operating segments: PCB and E-M
 Solutions. The determination was made based on the criteria of
 earning revenues and incurring expenses, the Company’s
 organizational structure which has segment managers who report to
 the chief operating decision maker and discrete financial
 information, and the aggregation of similar operating segments into
 reportable operating segments.

[0001193125-15-284892:notes:35]
All inter-segment transactions have been eliminated.

[0001193125-15-284892:notes:36]
For the quarter and two quarters ended June 29, 2015,
 Corporate includes bank fees and legal, accounting, and other
 professional service costs associated with the acquisition of
 Viasystems of $22,627 and $30,862, respectively. There were no bank
 fees or legal, accounting, or other professional service costs
 associated with the Viasystems acquisition for the quarter or two
 quarters ended June 30, 2014.


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-15-284892:notes:37]
Estimated aggregate amortization for definite-lived intangible
 assets for the next five years is as follows:

[0001193125-15-284892:notes:38]
|  |  | (In thousands) |  |
| Remaining 2015 |  | $ | 13,256 |  |
| 2016 |  |  | 23,065 |  |
| 2017 |  |  | 22,842 |  |
| 2018 |  |  | 22,075 |  |
| 2019 |  |  | 17,941 |  |
|  |  | $ | 99,179 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-15-284892:notes:39]
As of June 29, 2015 and December 29, 2014 goodwill
 was as follows:

[0001193125-15-284892:notes:40]
|  |  | Asia Pacific |  |  | Viasystems |  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 29, 2014 |  | $ | 12,111 |  |  | $ | — |  |  | $ | 12,111 |  |
| Goodwill recognized during the two quarters ended June 29, 2015 |  |  | — |  |  |  | 297,932 |  |  |  | 297,932 |  |
| Foreign currency translation adjustment during the two quarters ended June 29, 2015 |  |  | 10 |  |  |  | — |  |  |  | 10 |  |
| Balance as of June 29, 2015 |  | $ | 12,121 |  |  | $ | 297,932 |  |  | $ | 310,053 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-15-284892:notes:41]
(12) Fair Value
 Measures

[0001193125-15-284892:notes:42]
The
 Company measures at fair value its financial and non-financial
 assets by using a fair value hierarchy that prioritizes the inputs
 to valuation techniques used to measure fair value. Fair value is
 the price that would be received to sell an asset or paid to
 transfer a liability in an orderly transaction between market
 participants at the measurement date, essentially an exit price,
 based on the highest and best use of the asset or
 liability.

[0001193125-15-284892:notes:43]
The
 carrying amount and estimated fair value of the Company’s
 financial instruments at June 29, 2015 and December 29,
 2014 were as follows:

[0001193125-15-284892:notes:44]
|  |  | June 29, 2015 |  |  | December 29, 2014 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative liabilities, current |  | $ | 2,828 |  |  | $ | 2,828 |  |  | $ | 5,062 |  |  | $ | 5,062 |  |
| Long-term debt |  |  | 997,173 |  |  |  | 1,030,001 |  |  |  | 273,804 |  |  |  | 273,820 |  |
| Convertible senior notes due 2020 |  |  | 200,748 |  |  |  | 292,575 |  |  |  | 197,042 |  |  |  | 241,875 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | 31,841 |  |  |  | 32,631 |  |

[0001193125-15-284892:notes:45]
The
 fair value of the derivative instruments was determined using
 pricing models developed based on the LIBOR swap rate, foreign
 currency exchange rates, and other observable market data,
 including quoted market prices, as appropriate. The values were
 adjusted to reflect nonperformance risk of the counterparty and the
 Company, as necessary.

[0001193125-15-284892:notes:46]
The
 fair value of the long-term debt was estimated based on discounting
 the debt over its life using current market rates for similar debt
 as of June 29, 2015 and December 29, 2014, which are
 considered Level 1 and Level 2 inputs.

[0001193125-15-284892:notes:47]
The
 fair value of the convertible senior notes was estimated based on
 quoted market prices of the securities on an active exchange, which
 are considered Level 1 and Level 2 inputs.

[0001193125-15-284892:notes:48]
As of
 June 29, 2015 and December 29, 2014, the Company’s
 other financial instruments also included cash and cash
 equivalents, accounts receivable, accounts payable and equipment
 payables. Due to short-term maturities, the carrying amount of
 these instruments approximates fair value.

[0001193125-15-284892:notes:49]
At
 June 29, 2015 and December 29, 2014, the following
 financial assets and liabilities were measured at fair value on a
 recurring basis using the type of inputs shown:

[0001193125-15-284892:notes:50]
|  |  | June 29, 2015 |  |  | Fair Value Measurements Using: |  |
|  |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Foreign exchange derivative liabilities |  | $ | 2,828 |  |  | $ | — |  |  | $ | 2,828 |  |  | $ | — |  |
|  |  | December 29, 2014 |  |  | Fair Value Measurements Using: |  |
|  |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Money market funds |  | $ | 129,012 |  |  | $ | 129,012 |  |  | $ | — |  |  |  | — |  |
| Foreign exchange derivative liabilities |  |  | 5,062 |  |  |  | — |  |  |  | 5,062 |  |  |  | — |  |

[0001193125-15-284892:notes:51]
There
 were no transfers of financial assets or liabilities between Level
 1 and Level 2 inputs for the quarters or two quarters ended
 June 29, 2015 and June 30, 2014.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-15-284892:notes:52]
The
 calendar maturities of long-term debt through 2019 and thereafter
 are as follows:

[0001193125-15-284892:notes:53]
|  |  | (In thousands) |  |
| Remaining 2015 |  | $ | 82,376 |  |
| 2016 |  |  | 16,625 |  |
| 2017 |  |  | 40,375 |  |
| 2018 |  |  | 47,500 |  |
| 2019 |  |  | 47,500 |  |
| Thereafter |  |  | 795,625 |  |
|  |  | $ | 1,030,001 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-15-284892:notes:54]
Recently Issued
 Accounting Standards

[0001193125-15-284892:notes:55]
In
 April 2015, the Financial Accounting Standards Board (FASB) issued
 Accounting Standard Update (ASU) 2015-03, Interest-Imputation of
 Interest, which requires an entity to record debt issuance
 costs related to a note reported in the balance sheet as a direct
 deduction from the face amount of that note. The update is
 effective for annual periods ending after December 15, 2015.
 Early application is permitted. The standard requires the use of
 the retrospective transition method. The impact on the
 Company’s consolidated financial statements is not expected
 to be material.

[0001193125-15-284892:notes:56]
In
 August 2014, the FASB issued ASU 2014-15, Disclosure of
 Uncertainties About an Entity’s Ability to Continue as a
 Going Concern, which provides guidance on determining when and
 how to disclose going concern uncertainties in the financial
 statements. The new standard requires management to perform interim
 and annual assessments of an entity’s ability to continue as
 a going concern. The update is effective for annual periods ending
 after December 15, 2016, and interim periods thereafter. Early
 adoption is permitted. The Company adopted ASU 2014-15 at the
 beginning of 2015, and the Company’s adoption did not have an
 impact on its ongoing reporting.

[0001193125-15-284892:notes:57]
In
 May 2014, the FASB issued ASU 2014-09, Revenue from
 Contracts with Customers, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. ASU 2014-09
 will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2018, however
 application of the standard is allowed as early as the beginning of
 fiscal 2017. The standard permits the use of either the
 retrospective or cumulative effect transition method. We are
 evaluating the effect that ASU 2014-09 will have on the
 Company’s consolidated financial statements and related
 disclosures. The Company has not yet selected a transition method,
 nor has the Company determined the effect of the standard on its
 ongoing financial reporting.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-15-284892:notes:58]
(2)
 Acquisition of Viasystems Group, Inc.

[0001193125-15-284892:notes:59]
On May 31, 2015, the Company completed the acquisition of
 Viasystems Group, Inc. (Viasystems), for total consideration of
 $248,824 in cash and 15,082 shares of TTM common stock with a fair
 value of $149,006. Additionally, in connection with the completion
 of the acquisition, the Company assumed and refinanced
 Viasystems’ debt, which was approximately $669,024 as of
 May 31, 2015. Viasystems is a worldwide provider of complex
 multi-layer rigid, flexible, and rigid-flex PCBs and
 electro-mechanical solutions (E-M Solutions). Viasystems’
 products are found in a wide variety of commercial products,
 including automotive engine controls, hybrid converters, automotive
 electronics for navigation, safety, and entertainment,
 telecommunications switching equipment, data networking equipment,
 computer storage equipment, semiconductor test equipment, wind and
 solar energy applications, off-shore drilling equipment,
 communications applications, flight control systems, and complex
 industrial, medical, and other technical instruments.
 Viasystems’ E-M Solutions services can be bundled with its
 PCBs to provide an integrated solution to customers. Viasystems
 operates 15 manufacturing facilities worldwide: eight in the United
 States, five in the People’s Republic of China (China), and
 one each in Canada and Mexico. Viasystems serves a diversified
 customer base of over 1,000 customers in various markets throughout
 the world.

[0001193125-15-284892:notes:60]
Bank fees and legal, accounting, and other professional service
 costs associated with the acquisition of Viasystems of $22,627 and
 $30,862 for the quarter and two quarters ended June 29, 2015,
 respectively, have been expensed and recorded as general and
 administrative expense in the consolidated condensed statements of
 operations. There were no bank fees or legal, accounting, or other
 professional service costs associated with the Viasystems
 acquisition for the quarter or two quarters ended June 30,
 2014.

[0001193125-15-284892:notes:61]
The following summarizes the components of the purchase
 price:

[0001193125-15-284892:notes:62]
|  |  | (In thousands) |  |
| Value of TTM common stock issued |  | $ | 149,006 |  |
| Cash consideration |  |  | 248,824 |  |
|  |  |  | 397,830 |  |
| Debt assumed |  |  | 669,024 |  |
| Enterprise value |  | $ | 1,066,854 |  |

[0001193125-15-284892:notes:63]
The value of the shares of the Company’s common stock
 used in determining the purchase price was $9.88 per share, the
 closing price of the Company’s common stock on May 29,
 2015, the last business day prior to the effective date of the
 acquisition.

[0001193125-15-284892:notes:64]
Preliminary Purchase Price Allocation

[0001193125-15-284892:notes:65]
The purchase price of the Viasystems acquisition was allocated
 to tangible and intangible assets acquired, liabilities assumed and
 noncontrolling interest based on preliminary estimates of fair
 value at the date of the acquisition (May 31, 2015). The excess of
 the purchase price over the fair value of net assets acquired and
 noncontrolling interest was allocated to goodwill. The fair value
 assigned to intangible assets acquired was based on estimates and
 assumptions made by management at the time of
 acquisition.

[0001193125-15-284892:notes:66]
The fair values assigned are based on reasonable methods
 applicable to the nature of the assets acquired, liabilities
 assumed and noncontrolling interest. The following summarizes the
 preliminary estimated fair values of net assets acquired and
 noncontrolling interest:

[0001193125-15-284892:notes:67]
|  |  | (In thousands) |  |
| Cash |  | $ | 82,223 |  |
| Restricted cash |  |  | 3,542 |  |
| Trade and notes receivables ($216,703 contractual gross receivables) |  |  | 208,133 |  |
| Inventories |  |  | 138,277 |  |
| Other current assets |  |  | 31,023 |  |
| Property, plant and equipment |  |  | 452,836 |  |
| Identifiable intangible assets |  |  | 146,500 |  |
| Goodwill |  |  | 297,932 |  |
| Other assets |  |  | 672 |  |
| Current liabilities |  |  | (247,840 | ) |
| Long-term debt |  |  | (669,024 | ) |
| Other liabilities |  |  | (42,421 | ) |
| Noncontrolling interest |  |  | (4,023 | ) |
| Total |  | $ | 397,830 |  |

[0001193125-15-284892:notes:68]
Due to the fact that the Viasystems acquisition has just
 recently occurred in the current interim period, the magnitude of
 the transaction, and the significant information to be obtained and
 analyzed resides in a foreign jurisdiction, the Company’s
 fair value estimates for the purchase price allocation are
 preliminary and may change during the allowable measurement period,
 which is up to the point the Company obtains and analyzes the
 information that existed as of the date of the acquisition
 necessary to determine the fair values of the assets acquired,
 liabilities assumed and noncontrolling interest, but in no case to
 exceed more than one year from the date of acquisition. As of
 June 29, 2015, the Company had not finalized the determination
 of fair values allocated to various assets and liabilities,
 including, but not limited to, property, plant and equipment,
 identifiable intangible assets, other assets, deferred taxes,
 goodwill, tax uncertainties, income taxes payable, other
 liabilities, and noncontrolling interest. Any changes in the fair
 values of the assets acquired and liabilities assumed during the
 measurement period may result in material adjustments to
 goodwill.

[0001193125-15-284892:notes:69]
Inventories

[0001193125-15-284892:notes:70]
The Company acquired $138,277 of inventories as a result of the
 acquisition. Finished goods were valued at estimated selling prices
 less costs of disposal and a reasonable profit allowance for the
 selling effort. Work-in-process inventory was valued at estimated
 selling prices less costs to complete, costs of disposal and a
 reasonable profit allowance for the completion and selling effort.
 Raw materials were valued at estimated replacement cost.

[0001193125-15-284892:notes:71]
Property,
 Plant and Equipment

[0001193125-15-284892:notes:72]
The fair value of property, plant and equipment was determined
 by utilizing three approaches: the cost, sales comparison, and
 income capitalization approaches, each including management
 assumptions. Each approach assumes valuation of the property at the
 property’s highest and best use.

[0001193125-15-284892:notes:73]
Noncontrolling Interest

[0001193125-15-284892:notes:74]
Noncontrolling interest consists of a 5% equity interest in a
 manufacturing facility in Huiyang, China.

[0001193125-15-284892:notes:75]
Identifiable Intangible Assets

[0001193125-15-284892:notes:76]
Acquired identifiable intangible assets include customer
 relationships and technology. The fair value of the identifiable
 intangible assets was determined using various income approach
 methods including excess earnings to determine the present value of
 expected future cash flows for each identifiable intangible asset
 based on discount rates which incorporate a risk premium to take
 into account the risks inherent in those expected cash flows. The
 expected cash flows were estimated using available historical data
 adjusted based on the Company’s historical experience and the
 expectations of market participants. The preliminary estimated fair
 value assigned to each class of intangible assets and the related
 weighted average amortization periods are as follows:

[0001193125-15-284892:notes:77]
|  |  | Estimated fair value |  |  | Weighted-average amortization period |
|  |  | (In thousands) |  |  |  |
| Customer relationships |  | $ | 143,500 |  |  | 8.2 years |
| Technology |  |  | 3,000 |  |  | 3.0 years |
|  |  | $ | 146,500 |  |  |  |

[0001193125-15-284892:notes:78]
Goodwill

[0001193125-15-284892:notes:79]
Goodwill represents the excess of the Viasystems purchase price
 over the fair value of assets acquired, liabilities assumed and
 noncontrolling interest. Prior to the Company’s acquisition
 of Viasystems, the Company had two reporting segments based on
 geographical location of operations, North America and Asia
 Pacific, consistent with the nature of its operations. Due to the
 acquisition, the Company has reassessed its reporting segments and
 determined that it has three reporting segments, two based on
 geographical location of operations, North America and Asia
 Pacific, and Viasystems. The excess purchase price over the fair
 value of assets acquired, liabilities assumed and noncontrolling
 interest has been appropriately allocated to the Viasystems
 reporting segment.

[0001193125-15-284892:notes:80]
The Company believes that the acquisition of Viasystems will
 produce the following significant benefits:

[0001193125-15-284892:notes:81]
|  | • |  | Strengthens the Company’s Position as a Global Market Leader. The combination of the Company and Viasystems will create one of the largest and most diversified PCB manufacturers in the world. The addition of Viasystems extends the Company’s product technologies, production and development solutions, and customer base. |

[0001193125-15-284892:notes:82]
|  | • |  | Enhances End Market and Customer Diversification and Provides Entry to Attractive Automotive Markets. The Company believes that the combination will expand and diversify the Company’s customer base, end markets served, and product suite. The combination will significantly increase the Company’s presence in the automotive end market and provide, among other cross-selling opportunities, the opportunity to market the Company’s advanced technology PCBs to automotive customers. In addition, the combination will expand the Company’s presence in the Medical, Industrial and Instrumentation, Networking / Communications, and Aerospace/ Defense end markets. |

[0001193125-15-284892:notes:83]
The Company believes that these primary factors support the
 amount of goodwill recognized as a result of the purchase price
 paid for Viasystems, in relation to other acquired tangible and
 intangible assets. The goodwill acquired in the acquisition is not
 deductible for income tax purposes subject to certain tax elections
 that are currently being considered.

[0001193125-15-284892:notes:84]
Results of
 Operations

[0001193125-15-284892:notes:85]
Included in the consolidated condensed statements of operations
 are net sales of $93,194, excluding intercompany sales, and a net
 loss of $6,096 from the Viasystems operations for the quarter and
 two quarters ended June 29, 2015.

[0001193125-15-284892:notes:86]
Pro forma
 Financial Information

[0001193125-15-284892:notes:87]
The unaudited pro forma financial information in the table
 below gives effect to this acquisition as if it had occurred at the
 beginning of fiscal 2014. The pro forma financial information
 presented includes the effects of adjustments related to the
 amortization of acquired intangible assets and acquired inventory,
 depreciation of acquired fixed assets, and other non-recurring
 transactions costs directly associated with the acquisitions such
 as legal, accounting and banking fees.

[0001193125-15-284892:notes:88]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | June 29, 2015 |  |  | June 30, 2014 |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  | (In thousands, except per share data) |  |
| Net sales |  | $ | 647,632 |  |  | $ | 598,564 |  |  | $ | 1,281,425 |  |  | $ | 1,186,371 |  |
| Net loss attributable to TTM Technologies, Inc. stockholders |  |  | (23,775 | ) |  |  | (5,399 | ) |  |  | (21,363 | ) |  |  | (36,445 | ) |
| Basic loss per share |  | $ | (0.23 | ) |  | $ | (0.05 | ) |  | $ | (0.21 | ) |  | $ | (0.37 | ) |
| Dilutive loss per share |  | $ | (0.23 | ) |  | $ | (0.05 | ) |  | $ | (0.21 | ) |  | $ | (0.37 | ) |

[0001193125-15-284892:notes:89]
The pro forma financial information as presented above is for
 informational purposes only and is not necessarily indicative of
 the actual results that would have been achieved had the Viasystems
 acquisition occurred at the beginning of the earliest period
 presented, or the results that may be achieved in future
 periods.

[0001193125-15-284892:notes:90]
Viasystems
 Acquisition Litigation

[0001193125-15-284892:notes:91]
Since the public announcement on September 22, 2014 of the
 execution of the Agreement and Plan of Merger, TTM, Viasystems, and
 the members of the Viasystems board of directors (the Viasystems
 Board) have been named as defendants in two putative class action
 complaints challenging the acquisition of Viasystems. See Note 13
 to these Consolidated Condensed Financial Statements for additional
 information.


## us-gaap:EarningsPerShareTextBlock

[0001193125-15-284892:notes:92]
(14) Earnings Per
 Share

[0001193125-15-284892:notes:93]
For
 the quarter and two quarters ended June 29, 2015, potential
 shares of common stock, consisting of stock options to purchase
 approximately 433 shares of common stock at exercise prices ranging
 from $5.78 to $16.82 per share, 2,335 restricted stock units, and
 275 performance-based restricted stock units were not included in
 the computation of diluted earnings per share because the Company
 incurred a net loss and, as a result, the impact would be
 anti-dilutive.

[0001193125-15-284892:notes:94]
For
 the quarter and two quarters ended June 30, 2014, potential
 shares of common stock, consisting of stock options to purchase
 approximately 563 shares of common stock at exercise prices ranging
 from $5.78 to $16.82 per share, 1,729 restricted stock units, and
 229 performance-based restricted stock units were not included in
 the computation of diluted earnings per share because the Company
 incurred a net loss and, as a result, the impact would be
 anti-dilutive.

[0001193125-15-284892:notes:95]
Additionally, for the quarter and two quarters ended
 June 29, 2015 and June 30, 2014, the effect of 25,940
 shares of common stock, related to the Company’s convertible
 senior notes, and warrants to purchase 28,020 shares of common
 stock, were not included in the computation of dilutive earnings
 per share because the effect would be anti-dilutive.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-15-284892:notes:96]
The
 following table summarizes the long-term debt of the Company as of
 June 29, 2015 and December 29, 2014:

[0001193125-15-284892:notes:97]
|  |  | Average Effective Interest Rate as of June 29, 2015 |  | June 29, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  | 6.0% |  | $ | 950,000 |  |  | — |  |  | — |  |
| U.S. ABL revolving loan due May 2020 |  | 1.9% |  |  | 80,000 |  |  | — |  |  | — |  |
| Term loan due September 2016 |  | — |  |  | — |  |  | 2.55% |  | $ | 273,800 |  |
| Other |  | 6.0% |  |  | 1 |  |  | 6.00% |  |  | 4 |  |
|  |  |  |  |  | 1,030,001 |  |  |  |  |  | 273,804 |  |
| Less: Unamortized discount |  |  |  |  | (32,828 | ) |  |  |  |  | — |  |
|  |  |  |  |  | 997,173 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (87,126 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 910,047 |  |  |  |  | $ | 177,600 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsGainLossInStatementOfFinancialPerformanceTextBlock

[0001193125-15-284892:notes:98]
The
 following table provides information about the amounts recorded in
 accumulated other comprehensive income related to derivatives
 designated as cash flow hedges, as well as the amounts recorded in
 each caption in the consolidated condensed statements of operations
 when derivative amounts are reclassified out of accumulated other
 comprehensive income:

[0001193125-15-284892:notes:99]
|  |  |  |  |  | For the Quarter Ended |  |
|  |  |  |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  |  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized into Income |  |
|  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward |  |  | Depreciation expense |  |  | $ | — |  |  | $ | (43 | ) |  | $ | — |  |  | $ | — |  |  | $ | (40 | ) |  | $ | — |  |
|  |  |  |  |  |  | $ | — |  |  | $ | (43 | ) |  | $ | — |  |  | $ | — |  |  | $ | (40 | ) |  | $ | — |  |

[0001193125-15-284892:notes:100]
|  |  |  |  |  | For the Two Quarters Ended |  |
|  |  |  |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  |  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized into Income |  |
|  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward |  |  | Depreciation expense |  |  | $ | (53 | ) |  | $ | (85 | ) |  | $ | — |  |  | $ | 120 |  |  | $ | (65 | ) |  | $ | — |  |
|  |  |  |  |  |  | $ | (53 | ) |  | $ | (85 | ) |  | $ | — |  |  | $ | 120 |  |  | $ | (65 | ) |  | $ | — |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-15-284892:notes:101]
(10) Accumulated Other
 Comprehensive Income (Loss)

[0001193125-15-284892:notes:102]
The
 following provides a summary of the components of accumulated other
 comprehensive income (loss) as of June 29, 2015 and
 December 29, 2014:

[0001193125-15-284892:notes:103]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 29, 2014 |  | $ | 32,439 |  |  | $ | (1,424 | ) |  | $ | 31,015 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 2,175 |  |  |  | (53 | ) |  |  | 2,122 |  |
| Less: Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (1,786 | ) |  |  | 85 |  |  |  | (1,701 | ) |
| Other comprehensive loss |  |  | 389 |  |  |  | 32 |  |  |  | 421 |  |
| Ending balance at June 29, 2015 |  | $ | 32,828 |  |  | $ | (1,392 | ) |  | $ | 31,436 |  |

[0001193125-15-284892:notes:104]
The
 following provides a summary of reclassifications out of
 accumulated other comprehensive income for the quarter and two
 quarters ended June 29, 2015 and June 30,
 2014:

[0001193125-15-284892:notes:105]
|  |  |  |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |
|  |  |  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Statement of Operations Location |  | June 29, 2015 |  |  | June 30, 2014 |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
| Gain on foreign currency translation |  | Gain on sale of assets, net of tax |  | $ | — |  |  | $ | — |  |  | $ | (1,786 | ) |  | $ | — |  |
| Loss on cash flow hedges |  | Depreciation expense, net of tax |  | $ | 43 |  |  | $ | 40 |  |  | $ | 85 |  |  | $ | 65 |  |
| Loss on available for sale securities |  | Other, net, net of tax |  | $ | — |  |  | $ | 46 |  |  | $ | — |  |  | $ | 83 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsTextBlock

[0001193125-15-284892:notes:106]
The
 fair values of derivative instruments in the consolidated condensed
 balance sheets are as follows:

[0001193125-15-284892:notes:107]
|  |  |  |  | Asset / (Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | June 29, 2015 |  |  | December 29, 2014 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |
| Foreign exchange contracts |  | Other accrued expenses |  | $ | — |  |  | $ | (12 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |
| Foreign exchange contracts |  | Other accrued expenses |  |  | (2,828 | ) |  |  | (5,050 | ) |
|  |  |  |  | $ | (2,828 | ) |  | $ | (5,062 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-15-284892:notes:108]
(5)
 Goodwill and Definite-lived Intangibles

[0001193125-15-284892:notes:109]
The assignment of goodwill related to the acquisition of
 Viasystems is preliminary and will be completed in conjunction with
 the final purchase price allocation.

[0001193125-15-284892:notes:110]
Goodwill balances include foreign currency translation
 adjustments related to foreign subsidiaries which operate in
 currencies other than the U.S. Dollar.

[0001193125-15-284892:notes:111]
Definite-lived Intangibles

[0001193125-15-284892:notes:112]
As of June 29, 2015 and December 29, 2014, the
 components of definite-lived intangibles were as
 follows:

[0001193125-15-284892:notes:113]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Accumulated Impairment |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| June 29, 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 91,492 |  |  |  | (77,306 | ) |  | $ | — |  |  | $ | 429 |  |  | $ | 14,615 |  |  |  | 9.2 |  |
| Trade name |  |  | 10,302 |  |  |  | (9,413 | ) |  |  | — |  |  |  | 11 |  |  |  | 900 |  |  |  | 6.0 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 143,500 |  |  |  | (1,952 | ) |  |  | — |  |  |  | — |  |  |  | 141,548 |  |  |  | 8.2 |  |
| Technology |  |  | 3,000 |  |  |  | (83 | ) |  |  | — |  |  |  | — |  |  |  | 2,917 |  |  |  | 3.0 |  |
|  |  | $ | 248,294 |  |  | $ | (88,754 | ) |  | $ | — |  |  | $ | 440 |  |  | $ | 159,980 |  |  |  |  |  |
| December 29, 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 120,427 |  |  | $ | (74,486 | ) |  | $ | (28,935 | ) |  | $ | 445 |  |  | $ | 17,451 |  |  |  | 9.2 |  |
| Trade name |  |  | 10,302 |  |  |  | (8,520 | ) |  |  | — |  |  |  | 17 |  |  |  | 1,799 |  |  |  | 6.0 |  |
|  |  | $ | 130,729 |  |  | $ | (83,006 | ) |  | $ | (28,935 | ) |  | $ | 462 |  |  | $ | 19,250 |  |  |  |  |  |

[0001193125-15-284892:notes:114]
The June 29, 2015 and December 29, 2014
 definite-lived intangible balances include foreign currency
 translation adjustments related to foreign subsidiaries which
 operate in currencies other than the U.S. Dollar.

[0001193125-15-284892:notes:115]
All of the definite-lived intangibles are amortized using the
 straight line method of amortization over the useful life, with the
 exception of certain customer relationship intangibles which are
 amortized using an accelerated method of amortization based on cash
 flows. Amortization expense was $3,910 and $2,236 for the quarters
 ended June 29, 2015 and June 30, 2014, respectively, and
 $5,784 and $4,472 for the two quarters ended June 29, 2015 and
 June 30, 2014, respectively.


## us-gaap:ScheduleOfCashFlowHedgesIncludedInAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-15-284892:notes:116]
The
 following table provides a summary of the activity associated with
 the designated cash flow hedges reflected in accumulated other
 comprehensive income (loss) for the two quarters ended
 June 29, 2015 and June 30, 2014:

[0001193125-15-284892:notes:117]
|  |  | For the Two Quarters Ended |  |
|  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  | (In thousands) |  |
| Beginning balance unrealized loss, net of tax |  | $ | (1,424 | ) |  | $ | (1,613 | ) |
| Changes in fair value (loss) gain, net of tax |  |  | (53 | ) |  |  | 120 |  |
| Reclassification to earnings |  |  | 85 |  |  |  | 65 |  |
| Ending balance unrealized loss, net of tax |  | $ | (1,392 | ) |  | $ | (1,428 | ) |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-15-284892:notes:118]
[same as prior period, unchanged from 0001193125-15-170026:notes:81]

[0001193125-15-284892:notes:119]
TTM
 Technologies, Inc. (the Company or TTM) is a leading global
 provider of time-critical and technologically complex printed
 circuit board (PCB) products and backplane assemblies (i.e., PCBs
 populated with electronic components and other complex electronic
 assemblies). The Company provides time-to-market and advanced
 technology products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final volume production. This one-stop manufacturing solution
 allows the Company to align technology developments with the
 diverse needs of the Company’s customers and to enable them
 to reduce the time required to develop new products and bring them
 to market.

[0001193125-15-284892:notes:120]
Additionally, the Company serves a diversified customer base in
 various markets throughout the world, including manufacturers of
 networking/communications infrastructure products, touchscreen
 tablets and smartphones, as well as the aerospace and defense,
 automotive, high-end computing, and industrial/medical industries.
 The Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

[0001193125-15-284892:notes:121]
The
 accompanying consolidated condensed financial statements have been
 prepared by the Company, without audit, pursuant to the rules and
 regulations of the Securities and Exchange Commission (SEC).
 Certain information and disclosures normally included in financial
 statements prepared in accordance with accounting principles
 generally accepted in the United States of America (U.S. GAAP) have
 been condensed or omitted pursuant to such rules and regulations.
 These consolidated condensed financial statements reflect all
 adjustments (consisting only of normal recurring adjustments)
 which, in the opinion of management, are necessary to present
 fairly the financial position, the results of operations and cash
 flows of the Company for the periods presented. It is suggested
 that these consolidated condensed financial statements be read in
 conjunction with the consolidated financial statements and the
 notes thereto included in the Company’s most recent Annual
 Report on Form 10-K. The results of operations for the interim
 periods are not necessarily indicative of the results to be
 expected for the full year. The preparation of financial statements
 in accordance with U.S. GAAP requires management to make estimates
 and assumptions that affect the amounts reported in the
 Company’s consolidated condensed financial statements and
 accompanying notes. Actual results could differ materially from
 those estimates. The Company uses a 13-week fiscal quarter
 accounting period with the fourth quarter ending on the Monday
 nearest December 31.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-284892:notes:122]
(8) Income
 Taxes

[0001193125-15-284892:notes:123]
The
 Company’s effective tax rate will generally differ from the
 U.S. federal statutory rate of 35% due to favorable tax rates
 associated with earnings from the Company’s operations in
 lower-tax jurisdictions such as China, the apportioned state income
 tax rates, generation of other credits and deductions available to
 the Company, changes in valuation allowances, and certain
 non-deductible items.

[0001193125-15-284892:notes:124]
During
 the quarter ended June 29, 2015, the Company’s effective
 tax rate was impacted by discrete tax expense of $11,490 mainly
 comprised of (i) providing for a full valuation allowance of
 $19,588 against the Company’s existing U.S. net deferred tax
 assets as it is not more likely than not that the U.S. deferred tax
 assets will not be realized after the acquisition of Viasystems due
 to cumulative historical and projected U.S. losses as a combined
 company; and (ii) the reversal of deferred tax liabilities of
 $8,316 related to the Company’s decision to indefinitely
 reinvest the foreign earnings attributable to the backplane
 assembly facility in Shanghai, China. Further, no tax benefit was
 recorded on the losses incurred in the U.S. and certain foreign
 jurisdictions as a result of corresponding increases in the
 valuation allowances in these jurisdictions.

[0001193125-15-284892:notes:125]
For
 the two quarters ended June 29, 2015, and June 30, 2014,
 the Company’s effective tax rate was further impacted by a
 discrete tax benefit resulting from the retroactive approval of the
 high technology enterprise status for certain subsidiaries in China
 within the Company’s Asia Pacific operating
 segment.

[0001193125-15-284892:notes:126]
Certain foreign losses generated are not more than likely to be
 realizable, and thus, no income tax benefit has been recognized on
 these losses. The Company’s foreign earnings attributable to
 the Asia Pacific operating segment will be indefinitely reinvested
 in such foreign jurisdictions and, therefore, no deferred tax
 liabilities for U.S. income taxes on undistributed earnings are
 recorded.

[0001193125-15-284892:notes:127]
Certain entities in China operated under tax incentives
 effective through 2016. The tax incentives decreased Chinese taxes
 by $971 and $3,702, which increased both basic and diluted earnings
 per share by $0.01 and $0.04 for the quarter and two quarters ended
 June 29, 2015, respectively.

[0001193125-15-284892:notes:128]
As a
 result of the acquisition of Viasystems, the Company’s
 unrecognized tax benefit including interest and penalty increased
 by $29,372 during the quarter ended June 29, 2015.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-284892:notes:129]
(13) Commitments and
 Contingencies

[0001193125-15-284892:notes:130]
Legal
 Matters

[0001193125-15-284892:notes:131]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of June 29, 2015 and
 December 29, 2014. However, these amounts are not material to
 the consolidated financial statements of the Company.

[0001193125-15-284892:notes:132]
Class Action Complaints
 related to Viasystems Acquisition

[0001193125-15-284892:notes:133]
Since
 the public announcement on September 22, 2014 of the execution
 of the Merger Agreement, Viasystems, TTM, and the members of the
 Viasystems Board have been named as defendants in two putative
 class action complaints challenging the acquisition of Viasystems.
 The first lawsuit, filed in the Circuit Court of St. Louis County,
 Missouri on September 30, 2014 (the Missouri Lawsuit), and the
 second lawsuit, filed in the Court of Chancery of the State of
 Delaware on October 13, 2014 (the Delaware Lawsuit and,
 together with the Missouri Lawsuit, the Lawsuits), generally allege
 that the Merger fails to properly value Viasystems, that the
 individual defendants breached their fiduciary duties in approving
 the Merger Agreement, and that those breaches were aided and
 abetted by TTM and Viasystems.

[0001193125-15-284892:notes:134]
The
 Delaware Lawsuit specifically alleges, among other allegations,
 that (1) the Viasystems Board breached its fiduciary duties
 by: (a) agreeing to the Merger for grossly inadequate
 consideration, (b) agreeing to lock up the Merger with deal
 protection devices that prevent other bidders from making a
 successful competing offer for Viasystems, and
 (c) participating in a transaction where the loyalties of the
 Viasystems Board and management are divided; (2) the voting
 agreements entered into between the Company and certain of
 Viasystems’ significant stockholders prevent Viasystems
 stockholders from providing a meaningful vote on the proposal to
 adopt the Merger; and (3) that those breaches of fiduciary
 duties were aided and abetted by TTM, Merger Sub, and Viasystems.
 Further, the Missouri Lawsuit specifically alleges, among other
 allegations, that (1) the proposed Merger is unfair and the
 consideration to be paid in connection with the Merger is
 inadequate; (2) the Viasystems Board and Viasystems’
 management have a conflict of interest due to the cash pool bonus
 and change in control payments to be made to certain executive
 officers and key employees if the Merger is consummated; and
 (3) the Merger Agreement contains impermissible deal
 protection devices.

[0001193125-15-284892:notes:135]
The
 Lawsuits seek injunctive relief to enjoin the defendants from
 completing the Merger on the agreed-upon terms, rescinding, to the
 extent already implemented, the Merger Agreement or any of the
 terms therein, costs and disbursements and attorneys’ and
 experts’ fees and costs, as well as other equitable relief as
 the respective court deems proper. The Delaware Lawsuit also seeks:
 (1) in the event the Merger is consummated prior to the entry
 of the court’s final judgment, rescissory damages as an
 alternative to rescission, and (2) an accounting by all
 defendants to the plaintiff and other members of the class for all
 damages caused by the defendants and for all profits and any
 special benefits obtained as a result of their alleged breaches of
 their fiduciary duties.

[0001193125-15-284892:notes:136]
On
 January 6, 2015, the parties to the Missouri Lawsuit entered
 into a Memorandum of Understanding (MOU) with respect to a proposed
 settlement that will terminate both Lawsuits upon entry of the
 final judgment. Pursuant to the terms of the MOU, the parties
 entered into a stipulation of settlement on May 22, 2015, that
 remains subject to customary conditions, including court approval.
 The settlement agreement does not require the defendants to pay any
 monetary consideration to the proposed settlement class. The
 settlement agreement provides for payment of attorneys’ fees
 of the plaintiffs and reimbursement of expenses, in the amount to
 be determined by the court, but not to exceed $550,000. If the
 stipulation of settlement is approved by the court, it will fully
 and finally resolve all of the claims asserted, or that could have
 been asserted, in the Lawsuit against the defendants, and provide a
 release by the proposed settlement class of all claims against the
 defendants and their respective affiliates and agents in connection
 with the Merger.

[0001193125-15-284892:notes:137]
The
 proposed settlement is subject to the preliminary approval of the
 court as well as the court’s final approval after notice of
 the terms of the settlement has been provided to the proposed
 settlement class. Timing of the approval process is dependent on
 the court’s calendar. Members of the proposed settlement
 class will have the right to object to the settlement in writing to
 the court once the court has set a hearing for final
 approval.

[0001193125-15-284892:notes:138]
Environmental
 Matters

[0001193125-15-284892:notes:139]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States and Canada comply in all material
 respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted
 new rules and regulations governing environmental issues. An
 update to the Chinese environmental waste water law was issued in
 late 2012, but allows for an interim period in which plants subject
 to such law may install equipment that meets the new regulatory
 regime. Some of the Company’s plants in China are not yet in
 full compliance with the updated environmental
 regulations. The Company believes it has developed plans
 acceptable to the Chinese government and is in the process of
 implementing these plans. The Company does not anticipate any
 immediate risk of government fines or temporary closure of its
 Chinese plants. The Company has established and enacted an
 investment plan related to the efforts to come into full compliance
 with the new regulations. The 2015 capital expenditure costs
 expected for these plans are included in the Company’s
 capital expenditure projections.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-15-284892:notes:140]
(17) Related Party
 Transactions

[0001193125-15-284892:notes:141]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $12,914 and $13,390 for the quarters ended
 June 29, 2015 and June 30, 2014, respectively, and
 $22,859 and $25,180 for the two quarters ended June 29, 2015
 and June 30, 2014, respectively.

[0001193125-15-284892:notes:142]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCB’s to SYE and purchases various services
 in relation to PCB manufacturing from SYE. Sales to SYE for the
 quarters ended June 29, 2015 and June 30, 2014 were $1,343 and
 $9,100, respectively, and $2,825 and $19,253 for the two quarters
 ended June 29, 2015 and June 30, 2014, respectively. Purchases
 of various services in relation to PCB manufacturing for the
 quarters ended June 29, 2015 and June 30, 2014 were $366 and $201,
 respectively, and $805 and $472 for the two quarters ended June 29,
 2015 and June 30, 2014, respectively.

[0001193125-15-284892:notes:143]
As of
 June 29, 2015 and December 29, 2014, the Company’s
 consolidated balance sheets included $15,739 and $17,950,
 respectively, in accounts payable due to, and $2,852 and $4,934,
 respectively, in accounts receivable due from a related party for
 the purchase of laminate and prepreg and various PCB manufacturing
 services, and sales of PCBs to SYE, as mentioned above.


## us-gaap:LongTermDebtTextBlock

[0001193125-15-284892:notes:144]
(6)
 Long-term Debt and Letters of Credit

[0001193125-15-284892:notes:145]
The following table summarizes the long-term debt of the
 Company as of June 29, 2015 and December 29,
 2014:

[0001193125-15-284892:notes:146]
The calendar maturities of long-term debt through 2019 and
 thereafter are as follows:

[0001193125-15-284892:notes:147]
New
 borrowings

[0001193125-15-284892:notes:148]
On May 31, 2015, in conjunction with the acquisition of
 Viasystems, the Company entered into a $950,000 Term Loan Credit
 Agreement (Term Loan). Additionally, the Company entered into a
 $150,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and a
 $150,000 Asia Asset-Based Lending Credit agreement (Asia ABL)
 (collectively the ABL Revolving Loans). The Company drew $80,000 of
 the U.S. ABL at the closing of the acquisition of
 Viasystems.

[0001193125-15-284892:notes:149]
The Term Loan was issued at a discount at 96.5% and bears
 interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus
 an applicable interest margin of 5.0%, or JP Morgan Chase
 Bank’s prime rate, with a 2% floor, plus a margin of 4%, at
 the Company’s option. At June 29, 2015, the weighted
 average interest rate on the outstanding borrowings under the Term
 Loan was 6.0%. There is no provision, other than an event of
 default, for the interest margin to increase. The Term Loan will
 mature on May 31, 2021. The Term Loan is secured by a
 significant amount of the assets of the Company and its domestic
 subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and is structurally
 senior to the Company’s convertible senior notes. See Note 7
 Convertible Senior Notes.

[0001193125-15-284892:notes:150]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $150,000, a letter of credit
 facility of up to $75,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $150,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL. Borrowings under the U.S. ABL bear
 interest at either a floating rate of LIBOR plus a margin of 175
 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 75 basis points, at the Company’s option. At
 June 29, 2015, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 1.9%. Beginning in
 2016, the applicable margin can vary based on the remaining
 availability of the facility, from 150 to 200 basis points for
 LIBOR-based loans and from 50 to 100 basis points for JP Morgan
 Chase Bank’s prime rate-based loans. Other than availability
 and an event of default, there are no other provisions for the
 interest margin to increase. The U.S. ABL will mature on
 May 31, 2020. Loans made under the U.S. ABL are secured first
 by all of the Company’s domestic cash, receivables and
 inventories as well as by a significant amount of the assets of the
 Company and its domestic subsidiaries and a pledge of 65% of voting
 stock of the Company’s first tier foreign subsidiaries and
 are structurally senior to the Company’s convertible senior
 notes. See Note 7 Convertible Senior Notes. At June 29, 2015,
 $80,000 of the U.S. ABL was outstanding and classified as
 short-term debt.

[0001193125-15-284892:notes:151]
The Company and its domestic subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Term
 Loan and U.S. ABL related obligations.

[0001193125-15-284892:notes:152]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of the Company’s Asia Pacific cash and
 receivables and are structurally senior to the Company’s
 domestic obligations, including the convertible senior notes. See
 Note 7 Convertible Senior Notes. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At June 29, 2015, none of the Asia
 ABL was outstanding.

[0001193125-15-284892:notes:153]
The Company is required to make scheduled payments of the
 outstanding Term Loan balance on a quarterly basis beginning
 October 1, 2015. Any other outstanding balances under the Term
 Loan are due at the maturity date of May 31, 2021. Borrowings
 under the Term Loan are subject to various financial and operating
 covenants including maintaining a maximum total leverage ratio.
 Under the occurrence of certain events, the U.S. ABL and the Asia
 ABL are subject to various financial and operational covenants,
 including maintaining minimum fixed charges coverage ratios. At
 June 29, 2015, the Company was in compliance with the
 covenants under the Term Loan, the U.S. ABL and the Asia
 ABL.

[0001193125-15-284892:notes:154]
As of June 29, 2015, remaining unamortized debt discount
 and debt issuance costs were $32,828 and $33,585, respectively. The
 debt discount is recorded as a reduction of the Term Loan and is
 amortized over the duration of the Term Loan. The debt issuance
 costs are included in other non-current assets and are amortized to
 interest expense over the duration of the Term Loan and ABL
 Revolving Loans. The debt discount and the debt issuance costs
 related to the Term Loan are amortized into interest expense using
 an effective interest rate of 7.49%. The debt issuance costs
 related to the ABL Revolving Loans are amortized into interest
 expense using the straight line method of amortization over the
 duration of the ABL Revolving Loans. At June 29, 2015, the
 remaining amortization period for the unamortized debt discount and
 debt issuance costs was 5.9 years.

[0001193125-15-284892:notes:155]
The Company is required to pay a commitment fee of
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The U.S. ABL commitment fee may vary from 0.25% to 0.375%
 based on utilization levels. Additionally, the Company also paid
 commitment fees of 0.5% per annum on the unused portion of the
 $90,000 senior secured revolving loan associated with the
 terminated 2012 credit agreement during the quarter and two
 quarters ended June 29, 2015. The Company incurred total
 commitment fees related to unused borrowing availability of $193
 and $151 for the quarters ended June 29, 2015 and
 June 30, 2014, respectively, and $366 and $284 for the two
 quarters ended June 29, 2015 and June 30, 2014,
 respectively. As of June 29, 2015, the outstanding amount of
 the Term Loan was $950,000, of which $7,125 is due for repayment
 within one year and is included as short-term debt, with the
 remaining $942,875 included as long-term debt. Additionally,
 $80,000 of the U.S. ABL and none of the Asia ABL was outstanding as
 of June 29, 2015. Available borrowing capacity under the U.S.
 ABL and Asia ABL was $65,444, which considers the letter of credit
 outstanding of $4,556 mentioned below, and $150,000, respectively,
 at June 29, 2015.

[0001193125-15-284892:notes:156]
Letters
 of Credit

[0001193125-15-284892:notes:157]
The Company has up to $75,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of June 29, 2015, letters of credit in the
 amount of $4,556 were outstanding under the U.S. ABL. The Company
 has other standby letters of credit outstanding in the amount of
 $20,516, which expire between July 2, 2015 and May 16,
 2016. These other standby letters of credit are securitized by cash
 collateral. As such, the Company has recorded such cash as
 restricted on the consolidated condensed balance sheet as of
 June 29, 2015. There were no such arrangements at
 December 29, 2014.

[0001193125-15-284892:notes:158]
Other
 Credit Facility

[0001193125-15-284892:notes:159]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $37,100 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2015. As of June 29, 2015, the Chinese Revolver had not been
 drawn upon.

[0001193125-15-284892:notes:160]
Loss on
 Extinguishment of Debt

[0001193125-15-284892:notes:161]
The Company became a party to its current Term Loan and ABL
 Revolving Loans during the second quarter ended June 29, 2015
 in order to refinance and pay in full the remaining outstanding
 amount of $225,700 under an existing 2012 credit agreement, as well
 as to finance the acquisition of Viasystems and refinance
 Viasystems’ outstanding debt. As a result, the Company
 recognized losses of approximately $802 for the quarter and two
 quarters ended June 29, 2015 resulting from the write off of
 the remaining unamortized debt issuance costs associated with the
 terminated 2012 credit agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-15-284892:notes:162]
(9) Financial
 Instruments

[0001193125-15-284892:notes:163]
[same as prior period, unchanged from 0001193125-15-170026:notes:48]

[0001193125-15-284892:notes:164]
The
 Company enters into foreign currency forward contracts to mitigate
 the impact of changes in foreign currency exchange rates and to
 reduce the volatility of purchases and other obligations generated
 in currencies other than the functional currencies. The
 Company’s foreign subsidiaries may at times purchase forward
 exchange contracts to manage their foreign currency risks in
 relation to certain purchases of machinery denominated in foreign
 currencies other than the Company’s foreign functional
 currency. The notional amount of the foreign exchange contracts as
 of June 29, 2015 and December 29, 2014 was approximately
 $13,353 and $29,142, respectively. The Company has designated
 certain of these foreign exchange contracts as cash flow
 hedges.

[0001193125-15-284892:notes:165]
The
 Company expects that approximately $175 of expense will be
 reclassified into the statement of operations, net of tax, in the
 next 12 months.

[0001193125-15-284892:notes:166]
The
 net (loss) gain recognized in other, net in the consolidated
 condensed statements of operations related to foreign exchange
 contracts not designated as hedges was $(341) and $432 for the
 quarters ended June 29, 2015 and June 30, 2014,
 respectively and $(258) and $954 for the two quarters ended
 June 29, 2015 and June 30, 2014, respectively.


## ttmi:ConvertibleSeniorNotesTextBlock

[0001193125-15-284892:notes:167]
(7) Convertible Senior
 Notes

[0001193125-15-284892:notes:168]
Convertible Senior
 Notes due 2020

[0001193125-15-284892:notes:169]
The Company issued 1.75% convertible senior notes due
 December 15, 2020, in a public offering for an aggregate
 principal amount of $250,000. The convertible senior notes bear
 interest at a rate of 1.75% per annum. Interest is payable
 semiannually in arrears on June 15 and December 15 of
 each year. The convertible senior notes are senior unsecured
 obligations and rank equally to the Company’s future
 unsecured senior indebtedness and are senior in right of payment to
 any of the Company’s future subordinated
 indebtedness.

[0001193125-15-284892:notes:170]
Convertible Senior
 Notes due 2015

[0001193125-15-284892:notes:171]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015, in a public offering for an aggregate principal
 amount of $175,000. During the quarter ended June 29, 2015,
 the outstanding principal of $32,395 plus accrued interest was paid
 in full.

[0001193125-15-284892:notes:172]
As of June 29, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:

[0001193125-15-284892:notes:173]
|  |  | As of June 29, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (49,252 | ) |  | $ | 200,748 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 250,000 |  |  | $ | (49,252 | ) |  | $ | 200,748 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |

[0001193125-15-284892:notes:174]
|  |  | As of June 29, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
| Total |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |

[0001193125-15-284892:notes:175]
The components of interest expense resulting from the
 convertible senior notes for the quarter and two quarters ended
 June 29, 2015 and June 30, 2014 were as
 follows:

[0001193125-15-284892:notes:176]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 29, 2015 |  |  | June 30, 2014 |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 2,187 |  |  | $ | 2,179 |  |
| Convertible senior notes due 2015 |  |  | 131 |  |  |  | 263 |  |  |  | 395 |  |  |  | 526 |  |
|  |  | $ | 1,225 |  |  | $ | 1,357 |  |  | $ | 2,582 |  |  | $ | 2,705 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,867 |  |  | $ | 1,751 |  |  | $ | 3,705 |  |  | $ | 3,515 |  |
| Convertible senior notes due 2015 |  |  | 187 |  |  |  | 345 |  |  |  | 554 |  |  |  | 683 |  |
|  |  | $ | 2,054 |  |  | $ | 2,096 |  |  | $ | 4,259 |  |  | $ | 4,198 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 187 |  |  | $ | 175 |  |  | $ | 371 |  |  | $ | 353 |  |
| Convertible senior notes due 2015 |  |  | 19 |  |  |  | 35 |  |  |  | 56 |  |  |  | 69 |  |
|  |  | $ | 206 |  |  | $ | 210 |  |  | $ | 427 |  |  | $ | 422 |  |

[0001193125-15-284892:notes:177]
As of June 29, 2015 and December 29, 2014, remaining
 unamortized debt issuance costs included in other non-current
 assets were $4,936 and $5,363, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At June 29, 2015, the remaining weighted
 average amortization period for the unamortized senior convertible
 note discount and debt issuance costs was
 5.5 years.

[0001193125-15-284892:notes:178]
For the quarter and two quarters ended June 29, 2015 and
 June 30, 2014, the amortization of debt discount and debt
 issuance costs for the 2020 convertible senior notes and the 2015
 convertible senior notes was based on an effective interest rate of
 6.48% and 8.37%, respectively.


## ttmi:AssetsHeldForSaleDisclosureTextBlock

[0001193125-15-284892:notes:179]
(4) Impairment and Sale
 of Suzhou, China Manufacturing Facility

[0001193125-15-284892:notes:180]
The
 Company ceased manufacturing at its Meadville Aspocomp (Suzhou)
 Electronic Co., Ltd. subsidiary, which held its Suzhou, China
 manufacturing facility, and shut down its operations in
 2013. This subsidiary was included in the Company’s Asia
 Pacific operating segment.

[0001193125-15-284892:notes:181]
In the
 quarter ended June 30, 2014, the Company recorded an
 impairment charge for additional assets, related to this
 manufacturing facility. These assets were originally designated to
 be transferred to other facilities in China as well as the disposal
 of a substantial portion of the assets held for sale. As a result,
 the Company recognized an impairment charge in the amount of $1,845
 as the carrying value of the assets was greater than the market
 value at the date of disposal.

[0001193125-15-284892:notes:182]
In the
 fourth quarter of 2014, the Company commenced the process of
 selling this subsidiary and classified its net assets as assets
 held for sale at December 29, 2014. Assets held for sale are
 included in other current assets in the December 29, 2014
 consolidated condensed balance sheet.

[0001193125-15-284892:notes:183]
During
 the two quarters ended June 29, 2015, the Company sold its
 Meadville Aspocomp (Suzhou) Electronic Co., Ltd. subsidiary for
 $21,275 and recognized a gain of $2,504.
