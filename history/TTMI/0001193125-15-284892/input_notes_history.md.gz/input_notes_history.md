# TTMI note change history — 0001193125-15-170026 → 0001193125-15-284892


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-08-10):
[0001193125-15-284892:note_history:1]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of June 29, 2015 and
 December 29, 2014. However, these amounts are not material to
 the consolidated financial statements of the Company.
  (was, 2015-05-05, similarity 0.9859):
[0001193125-15-170026:note_history:1]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible or
 probable loss for known matters would not be material to the
 Company’s financial condition, the outcome of these actions
 is inherently difficult to predict. In the event of an adverse
 outcome, the ultimate potential loss could have a material adverse
 effect on the Company’s financial condition or results of
 operations in a particular period. The Company has accrued amounts
 for its loss contingencies which are probable and estimable as of
 March 30, 2015 and December 29, 2014. However, these
 amounts are not material to the consolidated financial statements
 of the Company.

- changed (2015-08-10):
[0001193125-15-284892:note_history:2]
Since
 the public announcement on September 22, 2014 of the execution
 of the Merger Agreement, Viasystems, TTM, and the members of the
 Viasystems Board have been named as defendants in two putative
 class action complaints challenging the acquisition of Viasystems.
 The first lawsuit, filed in the Circuit Court of St. Louis County,
 Missouri on September 30, 2014 (the Missouri Lawsuit), and the
 second lawsuit, filed in the Court of Chancery of the State of
 Delaware on October 13, 2014 (the Delaware Lawsuit and,
 together with the Missouri Lawsuit, the Lawsuits), generally allege
 that the Merger fails to properly value Viasystems, that the
 individual defendants breached their fiduciary duties in approving
 the Merger Agreement, and that those breaches were aided and
 abetted by TTM and Viasystems.
  (was, 2015-05-05, similarity 0.8046):
[0001193125-15-170026:note_history:2]
Since the public announcement on September 22, 2014 of the
 execution of the Merger Agreement, Viasystems, TTM, Merger Sub, and
 the members of the Viasystems Board have been named as defendants
 in two putative class action complaints challenging the Merger. The
 first lawsuit, filed in the Circuit Court of St. Louis County,
 Missouri on September 30, 2014 (the Missouri Lawsuit), and the
 second lawsuit, filed in the Court of Chancery of the State of
 Delaware on October 13, 2014 (the Delaware Lawsuit and,
 together with the Missouri Lawsuit, the Lawsuits), generally allege
 that the Merger fails to properly value Viasystems, that the
 individual defendants breached their fiduciary duties in approving
 the Merger Agreement, and that those breaches were aided and
 abetted by TTM, Merger Sub, and Viasystems.

- added (2015-08-10):
[0001193125-15-284892:note_history:3]
On
 January 6, 2015, the parties to the Missouri Lawsuit entered
 into a Memorandum of Understanding (MOU) with respect to a proposed
 settlement that will terminate both Lawsuits upon entry of the
 final judgment. Pursuant to the terms of the MOU, the parties
 entered into a stipulation of settlement on May 22, 2015, that
 remains subject to customary conditions, including court approval.
 The settlement agreement does not require the defendants to pay any
 monetary consideration to the proposed settlement class. The
 settlement agreement provides for payment of attorneys’ fees
 of the plaintiffs and reimbursement of expenses, in the amount to
 be determined by the court, but not to exceed $550,000. If the
 stipulation of settlement is approved by the court, it will fully
 and finally resolve all of the claims asserted, or that could have
 been asserted, in the Lawsuit against the defendants, and provide a
 release by the proposed settlement class of all claims against the
 defendants and their respective affiliates and agents in connection
 with the Merger.

- added (2015-08-10):
[0001193125-15-284892:note_history:4]
The
 proposed settlement is subject to the preliminary approval of the
 court as well as the court’s final approval after notice of
 the terms of the settlement has been provided to the proposed
 settlement class. Timing of the approval process is dependent on
 the court’s calendar. Members of the proposed settlement
 class will have the right to object to the settlement in writing to
 the court once the court has set a hearing for final
 approval.

- changed (2015-08-10):
[0001193125-15-284892:note_history:5]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States and Canada comply in all material
 respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted
 new rules and regulations governing environmental issues. An
 update to the Chinese environmental waste water law was issued in
 late 2012, but allows for an interim period in which plants subject
 to such law may install equipment that meets the new regulatory
 regime. Some of the Company’s plants in China are not yet in
 full compliance with the updated environmental
 regulations. The Company believes it has developed plans
 acceptable to the Chinese government and is in the process of
 implementing these plans. The Company does not anticipate any
 immediate risk of government fines or temporary closure of its
 Chinese plants. The Company has established and enacted an
 investment plan related to the efforts to come into full compliance
 with the new regulations. The 2015 capital expenditure costs
 expected for these plans are included in the Company’s
 capital expenditure projections.
  (was, 2015-05-05, similarity 0.996):
[0001193125-15-170026:note_history:5]
The process to manufacture PCBs requires adherence to city,
 county, state, federal, and foreign environmental regulations
 regarding the storage, use, handling and disposal of chemicals,
 solid wastes and other hazardous materials, as well as compliance
 with air quality standards and chemical use reporting. The Company
 believes that its facilities in the United States comply in all
 material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted
 new rules and regulations governing environmental issues. An
 update to the Chinese environmental waste water law was issued in
 late 2012, but allows for an interim period in which plants subject
 to such law may install equipment that meets the new regulatory
 regime. Some of the Company’s plants in China are not yet in
 full compliance with the updated environmental
 regulations. The Company believes it has developed plans
 acceptable to the Chinese government and is in the process of
 implementing these plans. The Company does not anticipate any
 immediate risk of government fines or temporary closure of its
 Chinese plants. The Company has established and enacted an
 investment plan related to the efforts to come into full compliance
 with the new regulations. The 2015 capital expenditure costs
 expected for these plans are included in the Company’s
 capital expenditure projections.

- removed (2015-08-10):
[0001193125-15-170026:note_history:6]
On January 6, 2015, the parties to the Missouri Lawsuit
 entered into a Memorandum of Understanding (MOU) with respect to a
 proposed settlement that will terminate both Lawsuits upon entry of
 the final judgment. The parties are in the process of
 negotiating this settlement agreement. Pursuant to the MOU,
 the settlement agreement will provide for payment of
 attorneys’ fees and reimbursement of expenses, and releases
 of all claims and relief sought in both Lawsuits.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-08-10):
[0001193125-15-284892:note_history:7]
TTM
 Technologies, Inc. (the Company or TTM) is a leading global
 provider of time-critical and technologically complex printed
 circuit board (PCB) products and backplane assemblies (i.e., PCBs
 populated with electronic components and other complex electronic
 assemblies). The Company provides time-to-market and advanced
 technology products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final volume production. This one-stop manufacturing solution
 allows the Company to align technology developments with the
 diverse needs of the Company’s customers and to enable them
 to reduce the time required to develop new products and bring them
 to market.
  (was, 2015-05-05, similarity 0.926):
[0001193125-15-170026:note_history:7]
TTM Technologies, Inc. (the Company or TTM) is a leading global
 provider of time-critical and technologically complex printed
 circuit board (PCB) products and backplane assemblies (i.e., PCBs
 populated with electronic components), which serve as the
 foundation of sophisticated electronic products. The Company
 provides time-to-market and advanced technology products and offers
 a one-stop manufacturing solution to customers from engineering
 support to prototype development through final volume production.
 This one-stop manufacturing solution allows the Company to align
 technology developments with the diverse needs of the
 Company’s customers and to enable them to reduce the time
 required to develop new products and bring them to
 market.

- changed (2015-08-10):
[0001193125-15-284892:note_history:8]
Additionally, the Company serves a diversified customer base in
 various markets throughout the world, including manufacturers of
 networking/communications infrastructure products, touchscreen
 tablets and smartphones, as well as the aerospace and defense,
 automotive, high-end computing, and industrial/medical industries.
 The Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.
  (was, 2015-05-05, similarity 0.9866):
[0001193125-15-170026:note_history:8]
Additionally, the Company serves a diversified customer base in
 various markets throughout the world, including manufacturers of
 networking/communications infrastructure products, touchscreen
 tablets and smartphones, as well as the aerospace and defense,
 high-end computing, and industrial/medical industries. The
 Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

- changed (2015-08-10):
[0001193125-15-284892:note_history:9]
In
 April 2015, the Financial Accounting Standards Board (FASB) issued
 Accounting Standard Update (ASU) 2015-03, Interest-Imputation of
 Interest, which requires an entity to record debt issuance
 costs related to a note reported in the balance sheet as a direct
 deduction from the face amount of that note. The update is
 effective for annual periods ending after December 15, 2015.
 Early application is permitted. The standard requires the use of
 the retrospective transition method. The impact on the
 Company’s consolidated financial statements is not expected
 to be material.
  (was, 2015-05-05, similarity 0.9883):
[0001193125-15-170026:note_history:9]
In April 2015, the Financial Accounting Standards Board (FASB)
 issued Accounting Standard Update (ASU) 2015-03,
 Interest-Imputation of Interest, which requires an entity to
 record debt issuance costs related to a note reported in the
 balance sheet as a direct deduction from the face amount of that
 note. The update is effective for annual periods ending after
 December 15, 2015. Early application is permitted. The
 standard requires the use of the retrospective transition method.
 The impact on the Company’s financial statements is not
 expected to be material.

- changed (2015-08-10):
[0001193125-15-284892:note_history:10]
In
 August 2014, the FASB issued ASU 2014-15, Disclosure of
 Uncertainties About an Entity’s Ability to Continue as a
 Going Concern, which provides guidance on determining when and
 how to disclose going concern uncertainties in the financial
 statements. The new standard requires management to perform interim
 and annual assessments of an entity’s ability to continue as
 a going concern. The update is effective for annual periods ending
 after December 15, 2016, and interim periods thereafter. Early
 adoption is permitted. The Company adopted ASU 2014-15 at the
 beginning of 2015, and the Company’s adoption did not have an
 impact on its ongoing reporting.
  (was, 2015-05-05, similarity 0.8571):
[0001193125-15-170026:note_history:10]
In August 2014, the FASB issued ASU 2014-15 Disclosure of
 Uncertainties About an Entity’s Ability to Continue as a
 Going Concern, which provides guidance on determining when and
 how to disclose going concern uncertainties in the financial
 statements. The new standard requires management to perform interim
 and annual assessments of an entity’s ability to continue as
 a going concern. The update is effective for annual periods ending
 after December 15, 2016, and interim periods thereafter. Early
 adoption is permitted. The impact on the Company’s financial
 statements of adopting ASU 2014-15 is not expected to be
 material.

- changed (2015-08-10):
[0001193125-15-284892:note_history:11]
In
 May 2014, the FASB issued ASU 2014-09, Revenue from
 Contracts with Customers, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. ASU 2014-09
 will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2018, however
 application of the standard is allowed as early as the beginning of
 fiscal 2017. The standard permits the use of either the
 retrospective or cumulative effect transition method. We are
 evaluating the effect that ASU 2014-09 will have on the
 Company’s consolidated financial statements and related
 disclosures. The Company has not yet selected a transition method,
 nor has the Company determined the effect of the standard on its
 ongoing financial reporting.
  (was, 2015-05-05, similarity 0.9378):
[0001193125-15-170026:note_history:11]
In May 2014, the FASB issued ASU 2014-09, Revenue from
 Contracts with Customers, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. ASU 2014-09
 will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2017. Early application
 is not permitted. The standard permits the use of either the
 retrospective or cumulative effect transition method. We are
 evaluating the effect that ASU 2014-09 will have on the
 Company’s consolidated financial statements and related
 disclosures. The Company has not yet selected a transition method,
 nor has the Company determined the effect of the standard on its
 ongoing financial reporting.


## ttmi:ConvertibleSeniorNotesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-08-10):
[0001193125-15-284892:note_history:12]
The Company issued 1.75% convertible senior notes due
 December 15, 2020, in a public offering for an aggregate
 principal amount of $250,000. The convertible senior notes bear
 interest at a rate of 1.75% per annum. Interest is payable
 semiannually in arrears on June 15 and December 15 of
 each year. The convertible senior notes are senior unsecured
 obligations and rank equally to the Company’s future
 unsecured senior indebtedness and are senior in right of payment to
 any of the Company’s future subordinated
 indebtedness.
  (was, 2015-05-05, similarity 0.996):
[0001193125-15-170026:note_history:12]
The Company issued 1.75% convertible senior notes due
 December 15, 2020, in a public offering for an aggregate
 principal amount of $250,000. The convertible senior notes bear
 interest at a rate of 1.75% per annum. Interest is payable
 semiannually in arrears on June 15 and December 15 of
 each year. The convertible senior notes are senior unsecured
 obligations and rank equally to the Company’s future
 unsecured senior indebtedness and senior in right of payment to any
 of the Company’s future subordinated indebtedness.

- added (2015-08-10):
[0001193125-15-284892:note_history:13]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015, in a public offering for an aggregate principal
 amount of $175,000. During the quarter ended June 29, 2015,
 the outstanding principal of $32,395 plus accrued interest was paid
 in full.

- changed (2015-08-10):
[0001193125-15-284892:note_history:14]
As of June 29, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:
  (was, 2015-05-05, similarity 0.9641):
[0001193125-15-170026:note_history:14]
As of March 30, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:

- changed (2015-08-10):
[0001193125-15-284892:note_history:15]
|  |  | As of June 29, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (49,252 | ) |  | $ | 200,748 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 250,000 |  |  | $ | (49,252 | ) |  | $ | 200,748 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |
  (was, 2015-05-05, similarity 0.7241):
[0001193125-15-170026:note_history:15]
|  |  | As of March 30, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (51,120 | ) |  | $ | 198,880 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (187 | ) |  |  | 32,208 |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 282,395 |  |  | $ | (51,307 | ) |  | $ | 231,088 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |

- changed (2015-08-10):
[0001193125-15-284892:note_history:16]
|  |  | As of June 29, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
| Total |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |
  (was, 2015-05-05, similarity 0.616):
[0001193125-15-170026:note_history:16]
|  |  | As of March 30, 2015 and December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |

- changed (2015-08-10):
[0001193125-15-284892:note_history:17]
The components of interest expense resulting from the
 convertible senior notes for the quarter and two quarters ended
 June 29, 2015 and June 30, 2014 were as
 follows:
  (was, 2015-05-05, similarity 0.8754):
[0001193125-15-170026:note_history:17]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended March 30, 2015
 and March 31, 2014 are as follows:

- added (2015-08-10):
[0001193125-15-284892:note_history:18]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 29, 2015 |  |  | June 30, 2014 |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 2,187 |  |  | $ | 2,179 |  |
| Convertible senior notes due 2015 |  |  | 131 |  |  |  | 263 |  |  |  | 395 |  |  |  | 526 |  |
|  |  | $ | 1,225 |  |  | $ | 1,357 |  |  | $ | 2,582 |  |  | $ | 2,705 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,867 |  |  | $ | 1,751 |  |  | $ | 3,705 |  |  | $ | 3,515 |  |
| Convertible senior notes due 2015 |  |  | 187 |  |  |  | 345 |  |  |  | 554 |  |  |  | 683 |  |
|  |  | $ | 2,054 |  |  | $ | 2,096 |  |  | $ | 4,259 |  |  | $ | 4,198 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 187 |  |  | $ | 175 |  |  | $ | 371 |  |  | $ | 353 |  |
| Convertible senior notes due 2015 |  |  | 19 |  |  |  | 35 |  |  |  | 56 |  |  |  | 69 |  |
|  |  | $ | 206 |  |  | $ | 210 |  |  | $ | 427 |  |  | $ | 422 |  |

- changed (2015-08-10):
[0001193125-15-284892:note_history:19]
As of June 29, 2015 and December 29, 2014, remaining
 unamortized debt issuance costs included in other non-current
 assets were $4,936 and $5,363, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At June 29, 2015, the remaining weighted
 average amortization period for the unamortized senior convertible
 note discount and debt issuance costs was
 5.5 years.
  (was, 2015-05-05, similarity 0.9806):
[0001193125-15-170026:note_history:19]
As of March 30, 2015 and December 29, 2014, remaining
 unamortized debt issuance costs included in other non-current
 assets were $5,142 and $5,363, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At March 30, 2015, the remaining
 weighted average amortization period for the unamortized senior
 convertible note discount and debt issuance costs was
 5.7 years.

- changed (2015-08-10):
[0001193125-15-284892:note_history:20]
For the quarter and two quarters ended June 29, 2015 and
 June 30, 2014, the amortization of debt discount and debt
 issuance costs for the 2020 convertible senior notes and the 2015
 convertible senior notes was based on an effective interest rate of
 6.48% and 8.37%, respectively.
  (was, 2015-05-05, similarity 0.6559):
[0001193125-15-170026:note_history:20]
For the quarters ended March 30, 2015 and March 31,
 2014, the amortization of debt discount and debt issuance costs for
 the 2020 convertible senior notes and the 2015 convertible senior
 notes is based on an effective interest rate of 6.48% and 8.37%,
 respectively.

- removed (2015-08-10):
[0001193125-15-170026:note_history:21]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to certain
 conversion adjustments, would be 32,425.

- removed (2015-08-10):
[0001193125-15-170026:note_history:22]
Convertible Note Hedge and Warrant
 Transaction: In connection with the issuance of the
 convertible senior notes due 2020, the Company entered into a
 convertible note hedge and warrant transaction (Call Spread
 Transaction), with respect to the Company’s common stock. The
 convertible note hedge consists of the Company’s option to
 purchase up to 25,940 common stock shares at a price of $9.64 per
 share. The hedge expires on December 15, 2020 and can only be
 executed upon the conversion of the above mentioned convertible
 senior notes due 2020. Additionally, the Company sold warrants to
 purchase 25,940 shares of its common stock at a price of
 $14.26 per share. The warrants expire ratably from March 2021
 through January 2022. The 2020 Call Spread Transaction has no
 effect on the terms of the convertible senior notes due 2020 and
 reduces potential dilution by effectively increasing the conversion
 price of the convertible senior notes due 2020 to $14.26 per share
 of the Company’s common stock.

- removed (2015-08-10):
[0001193125-15-170026:note_history:23]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015, in a public offering for an aggregate principal
 amount of $175,000. On May 15, 2015, the outstanding principal
 of $32,395 plus accrued interest is due and payable. The
 convertible senior notes are senior unsecured obligations and rank
 equally to the Company’s future unsecured senior indebtedness
 and senior in right of payment to any of the Company’s future
 subordinated indebtedness.

- removed (2015-08-10):
[0001193125-15-170026:note_history:24]
The maximum number of shares issuable upon conversion,
 including the effect of a fundamental change and subject to certain
 conversion adjustments, would be 2,587.

- removed (2015-08-10):
[0001193125-15-170026:note_history:25]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2015 |  |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,085 |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 263 |  |
|  |  | $ | 1,357 |  |  | $ | 1,348 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,838 |  |  | $ | 1,764 |  |
| Convertible senior notes due 2015 |  |  | 367 |  |  |  | 338 |  |
|  |  | $ | 2,205 |  |  | $ | 2,102 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 184 |  |  | $ | 177 |  |
| Convertible senior notes due 2015 |  |  | 37 |  |  |  | 34 |  |
|  |  | $ | 221 |  |  | $ | 211 |  |


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-08-10):
[0001193125-15-284892:note_history:26]
The components of interest expense resulting from the
 convertible senior notes for the quarter and two quarters ended
 June 29, 2015 and June 30, 2014 were as
 follows:
  (was, 2015-05-05, similarity 0.8754):
[0001193125-15-170026:note_history:26]
The components of interest expense resulting from the
 convertible senior notes for the quarters ended March 30, 2015
 and March 31, 2014 are as follows:

- added (2015-08-10):
[0001193125-15-284892:note_history:27]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 29, 2015 |  |  | June 30, 2014 |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 2,187 |  |  | $ | 2,179 |  |
| Convertible senior notes due 2015 |  |  | 131 |  |  |  | 263 |  |  |  | 395 |  |  |  | 526 |  |
|  |  | $ | 1,225 |  |  | $ | 1,357 |  |  | $ | 2,582 |  |  | $ | 2,705 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,867 |  |  | $ | 1,751 |  |  | $ | 3,705 |  |  | $ | 3,515 |  |
| Convertible senior notes due 2015 |  |  | 187 |  |  |  | 345 |  |  |  | 554 |  |  |  | 683 |  |
|  |  | $ | 2,054 |  |  | $ | 2,096 |  |  | $ | 4,259 |  |  | $ | 4,198 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 187 |  |  | $ | 175 |  |  | $ | 371 |  |  | $ | 353 |  |
| Convertible senior notes due 2015 |  |  | 19 |  |  |  | 35 |  |  |  | 56 |  |  |  | 69 |  |
|  |  | $ | 206 |  |  | $ | 210 |  |  | $ | 427 |  |  | $ | 422 |  |

- removed (2015-08-10):
[0001193125-15-170026:note_history:28]
|  |  | For the Quarter Ended |  |
|  |  | March 30, 2015 |  |  | March 31, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,085 |  |
| Convertible senior notes due 2015 |  |  | 263 |  |  |  | 263 |  |
|  |  | $ | 1,357 |  |  | $ | 1,348 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,838 |  |  | $ | 1,764 |  |
| Convertible senior notes due 2015 |  |  | 367 |  |  |  | 338 |  |
|  |  | $ | 2,205 |  |  | $ | 2,102 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 184 |  |  | $ | 177 |  |
| Convertible senior notes due 2015 |  |  | 37 |  |  |  | 34 |  |
|  |  | $ | 221 |  |  | $ | 211 |  |


## ttmi:ScheduleOfLiabilityAndEquityComponentsOfConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-08-10):
[0001193125-15-284892:note_history:29]
As of June 29, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:
  (was, 2015-05-05, similarity 0.9641):
[0001193125-15-170026:note_history:29]
As of March 30, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:

- changed (2015-08-10):
[0001193125-15-284892:note_history:30]
|  |  | As of June 29, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (49,252 | ) |  | $ | 200,748 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 250,000 |  |  | $ | (49,252 | ) |  | $ | 200,748 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |
  (was, 2015-05-05, similarity 0.7241):
[0001193125-15-170026:note_history:30]
|  |  | As of March 30, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (51,120 | ) |  | $ | 198,880 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | 32,395 |  |  |  | (187 | ) |  |  | 32,208 |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 282,395 |  |  | $ | (51,307 | ) |  | $ | 231,088 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |

- changed (2015-08-10):
[0001193125-15-284892:note_history:31]
|  |  | As of June 29, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
| Total |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |
  (was, 2015-05-05, similarity 0.616):
[0001193125-15-170026:note_history:31]
|  |  | As of March 30, 2015 and December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
|  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-08-10):
[0001193125-15-284892:note_history:32]
The following table summarizes the long-term debt of the
 Company as of June 29, 2015 and December 29,
 2014:
  (was, 2015-05-05, similarity 0.9538):
[0001193125-15-170026:note_history:32]
The following table summarizes the long-term debt of the
 Company as of March 30, 2015 and December 29,
 2014:

- changed (2015-08-10):
[0001193125-15-284892:note_history:33]
|  |  | Average Effective Interest Rate as of June 29, 2015 |  | June 29, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  | 6.0% |  | $ | 950,000 |  |  | — |  |  | — |  |
| U.S. ABL revolving loan due May 2020 |  | 1.9% |  |  | 80,000 |  |  | — |  |  | — |  |
| Term loan due September 2016 |  | — |  |  | — |  |  | 2.55% |  | $ | 273,800 |  |
| Other |  | 6.0% |  |  | 1 |  |  | 6.00% |  |  | 4 |  |
|  |  |  |  |  | 1,030,001 |  |  |  |  |  | 273,804 |  |
| Less: Unamortized discount |  |  |  |  | (32,828 | ) |  |  |  |  | — |  |
|  |  |  |  |  | 997,173 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (87,126 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 910,047 |  |  |  |  | $ | 177,600 |  |
  (was, 2015-05-05, similarity 0.7164):
[0001193125-15-170026:note_history:33]
|  |  | Average Effective Interest Rate as of March 30, 2015 |  | March 30, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.56% |  | $ | 225,700 |  |  | 2.55% |  | $ | 273,800 |  |
| Other |  | 6.00% |  |  | 2 |  |  | 6.00% |  |  | 4 |  |
|  |  |  |  |  | 225,702 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (96,202 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 129,500 |  |  |  |  | $ | 177,600 |  |

- changed (2015-08-10):
[0001193125-15-284892:note_history:34]
The calendar maturities of long-term debt through 2019 and
 thereafter are as follows:
  (was, 2015-05-05, similarity 0.8993):
[0001193125-15-170026:note_history:34]
The calendar maturities of long-term debt through 2016 are as
 follows:

- changed (2015-08-10):
[0001193125-15-284892:note_history:35]
|  |  | (In thousands) |  |
| Remaining 2015 |  | $ | 82,376 |  |
| 2016 |  |  | 16,625 |  |
| 2017 |  |  | 40,375 |  |
| 2018 |  |  | 47,500 |  |
| 2019 |  |  | 47,500 |  |
| Thereafter |  |  | 795,625 |  |
|  |  | $ | 1,030,001 |  |
  (was, 2015-05-05, similarity 0.6971):
[0001193125-15-170026:note_history:35]
|  |  | (In thousands) |  |
| Remaining 2015 |  | $ | 48,102 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 225,702 |  |

- added (2015-08-10):
[0001193125-15-284892:note_history:36]
New
 borrowings

- added (2015-08-10):
[0001193125-15-284892:note_history:37]
On May 31, 2015, in conjunction with the acquisition of
 Viasystems, the Company entered into a $950,000 Term Loan Credit
 Agreement (Term Loan). Additionally, the Company entered into a
 $150,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and a
 $150,000 Asia Asset-Based Lending Credit agreement (Asia ABL)
 (collectively the ABL Revolving Loans). The Company drew $80,000 of
 the U.S. ABL at the closing of the acquisition of
 Viasystems.

- added (2015-08-10):
[0001193125-15-284892:note_history:38]
The Term Loan was issued at a discount at 96.5% and bears
 interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus
 an applicable interest margin of 5.0%, or JP Morgan Chase
 Bank’s prime rate, with a 2% floor, plus a margin of 4%, at
 the Company’s option. At June 29, 2015, the weighted
 average interest rate on the outstanding borrowings under the Term
 Loan was 6.0%. There is no provision, other than an event of
 default, for the interest margin to increase. The Term Loan will
 mature on May 31, 2021. The Term Loan is secured by a
 significant amount of the assets of the Company and its domestic
 subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and is structurally
 senior to the Company’s convertible senior notes. See Note 7
 Convertible Senior Notes.

- added (2015-08-10):
[0001193125-15-284892:note_history:39]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $150,000, a letter of credit
 facility of up to $75,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $150,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL. Borrowings under the U.S. ABL bear
 interest at either a floating rate of LIBOR plus a margin of 175
 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 75 basis points, at the Company’s option. At
 June 29, 2015, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 1.9%. Beginning in
 2016, the applicable margin can vary based on the remaining
 availability of the facility, from 150 to 200 basis points for
 LIBOR-based loans and from 50 to 100 basis points for JP Morgan
 Chase Bank’s prime rate-based loans. Other than availability
 and an event of default, there are no other provisions for the
 interest margin to increase. The U.S. ABL will mature on
 May 31, 2020. Loans made under the U.S. ABL are secured first
 by all of the Company’s domestic cash, receivables and
 inventories as well as by a significant amount of the assets of the
 Company and its domestic subsidiaries and a pledge of 65% of voting
 stock of the Company’s first tier foreign subsidiaries and
 are structurally senior to the Company’s convertible senior
 notes. See Note 7 Convertible Senior Notes. At June 29, 2015,
 $80,000 of the U.S. ABL was outstanding and classified as
 short-term debt.

- added (2015-08-10):
[0001193125-15-284892:note_history:40]
The Company and its domestic subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Term
 Loan and U.S. ABL related obligations.

- added (2015-08-10):
[0001193125-15-284892:note_history:41]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of the Company’s Asia Pacific cash and
 receivables and are structurally senior to the Company’s
 domestic obligations, including the convertible senior notes. See
 Note 7 Convertible Senior Notes. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At June 29, 2015, none of the Asia
 ABL was outstanding.

- added (2015-08-10):
[0001193125-15-284892:note_history:42]
The Company is required to make scheduled payments of the
 outstanding Term Loan balance on a quarterly basis beginning
 October 1, 2015. Any other outstanding balances under the Term
 Loan are due at the maturity date of May 31, 2021. Borrowings
 under the Term Loan are subject to various financial and operating
 covenants including maintaining a maximum total leverage ratio.
 Under the occurrence of certain events, the U.S. ABL and the Asia
 ABL are subject to various financial and operational covenants,
 including maintaining minimum fixed charges coverage ratios. At
 June 29, 2015, the Company was in compliance with the
 covenants under the Term Loan, the U.S. ABL and the Asia
 ABL.

- added (2015-08-10):
[0001193125-15-284892:note_history:43]
As of June 29, 2015, remaining unamortized debt discount
 and debt issuance costs were $32,828 and $33,585, respectively. The
 debt discount is recorded as a reduction of the Term Loan and is
 amortized over the duration of the Term Loan. The debt issuance
 costs are included in other non-current assets and are amortized to
 interest expense over the duration of the Term Loan and ABL
 Revolving Loans. The debt discount and the debt issuance costs
 related to the Term Loan are amortized into interest expense using
 an effective interest rate of 7.49%. The debt issuance costs
 related to the ABL Revolving Loans are amortized into interest
 expense using the straight line method of amortization over the
 duration of the ABL Revolving Loans. At June 29, 2015, the
 remaining amortization period for the unamortized debt discount and
 debt issuance costs was 5.9 years.

- added (2015-08-10):
[0001193125-15-284892:note_history:44]
The Company is required to pay a commitment fee of
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The U.S. ABL commitment fee may vary from 0.25% to 0.375%
 based on utilization levels. Additionally, the Company also paid
 commitment fees of 0.5% per annum on the unused portion of the
 $90,000 senior secured revolving loan associated with the
 terminated 2012 credit agreement during the quarter and two
 quarters ended June 29, 2015. The Company incurred total
 commitment fees related to unused borrowing availability of $193
 and $151 for the quarters ended June 29, 2015 and
 June 30, 2014, respectively, and $366 and $284 for the two
 quarters ended June 29, 2015 and June 30, 2014,
 respectively. As of June 29, 2015, the outstanding amount of
 the Term Loan was $950,000, of which $7,125 is due for repayment
 within one year and is included as short-term debt, with the
 remaining $942,875 included as long-term debt. Additionally,
 $80,000 of the U.S. ABL and none of the Asia ABL was outstanding as
 of June 29, 2015. Available borrowing capacity under the U.S.
 ABL and Asia ABL was $65,444, which considers the letter of credit
 outstanding of $4,556 mentioned below, and $150,000, respectively,
 at June 29, 2015.

- added (2015-08-10):
[0001193125-15-284892:note_history:45]
The Company has up to $75,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of June 29, 2015, letters of credit in the
 amount of $4,556 were outstanding under the U.S. ABL. The Company
 has other standby letters of credit outstanding in the amount of
 $20,516, which expire between July 2, 2015 and May 16,
 2016. These other standby letters of credit are securitized by cash
 collateral. As such, the Company has recorded such cash as
 restricted on the consolidated condensed balance sheet as of
 June 29, 2015. There were no such arrangements at
 December 29, 2014.

- changed (2015-08-10):
[0001193125-15-284892:note_history:46]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $37,100 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2015. As of June 29, 2015, the Chinese Revolver had not been
 drawn upon.
  (was, 2015-05-05, similarity 0.991):
[0001193125-15-170026:note_history:46]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $37,000 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2015. As of March 30, 2015, the Chinese Revolver had not been
 drawn upon.

- added (2015-08-10):
[0001193125-15-284892:note_history:47]
Loss on
 Extinguishment of Debt

- added (2015-08-10):
[0001193125-15-284892:note_history:48]
The Company became a party to its current Term Loan and ABL
 Revolving Loans during the second quarter ended June 29, 2015
 in order to refinance and pay in full the remaining outstanding
 amount of $225,700 under an existing 2012 credit agreement, as well
 as to finance the acquisition of Viasystems and refinance
 Viasystems’ outstanding debt. As a result, the Company
 recognized losses of approximately $802 for the quarter and two
 quarters ended June 29, 2015 resulting from the write off of
 the remaining unamortized debt issuance costs associated with the
 terminated 2012 credit agreement.

- removed (2015-08-10):
[0001193125-15-170026:note_history:49]
Credit
 Agreement

- removed (2015-08-10):
[0001193125-15-170026:note_history:50]
In 2012, the Company became a party to a facility agreement
 (Credit Agreement) consisting of a $370,000 senior secured term
 loan (Term Loan), a $90,000 senior secured revolving loan
 (Revolving Loan), and a secured $80,000 letters of credit facility
 (Letters of Credit Facility). The Term Loan and Letters of Credit
 Facility will mature on September 14, 2016. The Revolving Loan
 will mature on March 14, 2016. The Credit Agreement is secured
 by substantially all of the assets of the Company’s Asia
 Pacific operating segment and is senior to all other debt,
 including the convertible senior notes. See Note 6 to these
 Consolidated Condensed Financial Statements. The Company has fully
 and unconditionally guaranteed the full and timely payment of all
 Credit Agreement related obligations of its Asia Pacific operating
 segment.

- removed (2015-08-10):
[0001193125-15-170026:note_history:51]
As of March 30, 2015 and December 29, 2014, the
 remaining unamortized debt issuance costs included in other
 non-current assets was $924 and $1,123, respectively, and is
 amortized to interest expense over the term of the Company’s
 Credit Agreement using the effective interest rate method. At
 March 30, 2015, the remaining amortization period for the
 unamortized debt issuance costs was 1.3 years.

- removed (2015-08-10):
[0001193125-15-170026:note_history:52]
The Company is also required to pay a commitment fee of
 0.50% per annum on any unused portion of the Revolving Loan
 and Letters of Credit Facility granted under the Credit Agreement.
 The Company incurred commitment fees related to unused borrowing
 availability of $173 and $133 for the quarters ended March 30,
 2015 and March 31, 2014, respectively. As of March 30,
 2015, the outstanding amount of the Term Loan under the Credit
 Agreement is $225,700, of which $96,200 is due for repayment in
 September 2015 and March 2016 and is included as short-term debt,
 with the remaining $129,500 included as long-term debt. None of the
 Revolving Loan was outstanding under the Credit Agreement as of
 March 30, 2015. Available borrowing capacity under the
 Revolving Loan was $90,000 at March 30, 2015.

- removed (2015-08-10):
[0001193125-15-170026:note_history:53]
The Company has an $80,000 Letters of Credit Facility under the
 Credit Agreement, as mentioned above. As of March 30, 2015,
 letters of credit in the amount of $30,893 were outstanding under
 this Credit Agreement. The Company has other standby letters of
 credit outstanding in the amount of $4,257, which expire between
 December 31, 2015 and February 28, 2016.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-08-10):
[0001193125-15-284892:note_history:54]
The
 following table summarizes the long-term debt of the Company as of
 June 29, 2015 and December 29, 2014:
  (was, 2015-05-05, similarity 0.9538):
[0001193125-15-170026:note_history:54]
The following table summarizes the long-term debt of the
 Company as of March 30, 2015 and December 29,
 2014:

- changed (2015-08-10):
[0001193125-15-284892:note_history:55]
|  |  | Average Effective Interest Rate as of June 29, 2015 |  | June 29, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  | 6.0% |  | $ | 950,000 |  |  | — |  |  | — |  |
| U.S. ABL revolving loan due May 2020 |  | 1.9% |  |  | 80,000 |  |  | — |  |  | — |  |
| Term loan due September 2016 |  | — |  |  | — |  |  | 2.55% |  | $ | 273,800 |  |
| Other |  | 6.0% |  |  | 1 |  |  | 6.00% |  |  | 4 |  |
|  |  |  |  |  | 1,030,001 |  |  |  |  |  | 273,804 |  |
| Less: Unamortized discount |  |  |  |  | (32,828 | ) |  |  |  |  | — |  |
|  |  |  |  |  | 997,173 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (87,126 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 910,047 |  |  |  |  | $ | 177,600 |  |
  (was, 2015-05-05, similarity 0.7164):
[0001193125-15-170026:note_history:55]
|  |  | Average Effective Interest Rate as of March 30, 2015 |  | March 30, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due September 2016 |  | 2.56% |  | $ | 225,700 |  |  | 2.55% |  | $ | 273,800 |  |
| Other |  | 6.00% |  |  | 2 |  |  | 6.00% |  |  | 4 |  |
|  |  |  |  |  | 225,702 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (96,202 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 129,500 |  |  |  |  | $ | 177,600 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-08-10):
[0001193125-15-284892:note_history:56]
The
 calendar maturities of long-term debt through 2019 and thereafter
 are as follows:
  (was, 2015-05-05, similarity 0.8993):
[0001193125-15-170026:note_history:56]
The calendar maturities of long-term debt through 2016 are as
 follows:

- changed (2015-08-10):
[0001193125-15-284892:note_history:57]
|  |  | (In thousands) |  |
| Remaining 2015 |  | $ | 82,376 |  |
| 2016 |  |  | 16,625 |  |
| 2017 |  |  | 40,375 |  |
| 2018 |  |  | 47,500 |  |
| 2019 |  |  | 47,500 |  |
| Thereafter |  |  | 795,625 |  |
|  |  | $ | 1,030,001 |  |
  (was, 2015-05-05, similarity 0.6971):
[0001193125-15-170026:note_history:57]
|  |  | (In thousands) |  |
| Remaining 2015 |  | $ | 48,102 |  |
| 2016 |  |  | 177,600 |  |
|  |  | $ | 225,702 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2015-08-10):
[0001193125-15-284892:note_history:58]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $12,914 and $13,390 for the quarters ended
 June 29, 2015 and June 30, 2014, respectively, and
 $22,859 and $25,180 for the two quarters ended June 29, 2015
 and June 30, 2014, respectively.

- added (2015-08-10):
[0001193125-15-284892:note_history:59]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCB’s to SYE and purchases various services
 in relation to PCB manufacturing from SYE. Sales to SYE for the
 quarters ended June 29, 2015 and June 30, 2014 were $1,343 and
 $9,100, respectively, and $2,825 and $19,253 for the two quarters
 ended June 29, 2015 and June 30, 2014, respectively. Purchases
 of various services in relation to PCB manufacturing for the
 quarters ended June 29, 2015 and June 30, 2014 were $366 and $201,
 respectively, and $805 and $472 for the two quarters ended June 29,
 2015 and June 30, 2014, respectively.

- changed (2015-08-10):
[0001193125-15-284892:note_history:60]
As of
 June 29, 2015 and December 29, 2014, the Company’s
 consolidated balance sheets included $15,739 and $17,950,
 respectively, in accounts payable due to, and $2,852 and $4,934,
 respectively, in accounts receivable due from a related party for
 the purchase of laminate and prepreg and various PCB manufacturing
 services, and sales of PCBs to SYE, as mentioned above.
  (was, 2015-05-05, similarity 0.9245):
[0001193125-15-170026:note_history:60]
As of
 March 30, 2015 and December 29, 2014, the Company’s
 consolidated balance sheets included $16,852 and $17,950,
 respectively, in accounts payable due to, and $4,022 and $4,934,
 respectively, in accounts receivable due from a related party for
 the purchase of laminate and prepreg, and sales of PCBs to SYE, as
 mentioned above.

- removed (2015-08-10):
[0001193125-15-170026:note_history:61]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 For the quarters ended March 30, 2015 and March 31, 2014,
 the Company’s foreign subsidiaries purchased $9,945 and
 $11,790, respectively, of laminate and prepreg from these related
 parties.

- removed (2015-08-10):
[0001193125-15-170026:note_history:62]
Dongguan Shengyi Electronics Ltd. (SYE) is a related party, as
 a significant shareholder of the Company holds an equity interest
 in the parent company of SYE. Sales to SYE for the quarters ended
 March 30, 2015 and March 31, 2014 were $1,481 and
 $10,147, respectively. Additionally, purchases from SYE for the
 quarters ended March 30, 2015 and March 31, 2014 were
 approximately $439 and $271, respectively.
