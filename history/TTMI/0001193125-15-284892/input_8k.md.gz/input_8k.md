# TTMI 8-K — 0001171843-15-004361 filed 2015-08-05

## item codes, every 8-K on or before 2015-08-10

- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2015-08-10

- none on or before 2015-08-10

## item 2.02 — earnings release, exhibit 99.1

[0001171843-15-004361:8k_2_02:1]
EX-99
2
newsrelease.htm
PRESS RELEASE

[0001171843-15-004361:8k_2_02:2]
TTM Technologies, Inc. Reports Second Quarter 2015 Results
EXHIBIT 99.1

[0001171843-15-004361:8k_2_02:3]
TTM Technologies, Inc. Reports Second Quarter 2015 Results

[0001171843-15-004361:8k_2_02:4]
COSTA MESA, Calif., Aug. 5, 2015 (GLOBE NEWSWIRE) -- TTM Technologies, Inc. (Nasdaq:TTMI), a major global printed circuit board ("PCB") manufacturer, today reported results for the second quarter 2015, which ended June 29, 2015. Results for the period reflect approximately one month of consolidated results from the acquisition of Viasystems Group, Inc. ("Viasystems"), completed on June 1, 2015.

[0001171843-15-004361:8k_2_02:5]
Second Quarter 2015 Highlights

[0001171843-15-004361:8k_2_02:6]
-  Completed the acquisition of Viasystems on June 1, 2015

[0001171843-15-004361:8k_2_02:7]
-  Net sales were $445.4 million

[0001171843-15-004361:8k_2_02:8]
-  GAAP net loss was $36.6 million, or $0.41 per share

[0001171843-15-004361:8k_2_02:9]
-  Non-GAAP net income was $14.9 million, or $0.17 per diluted share

[0001171843-15-004361:8k_2_02:10]
Second Quarter 2015 Financial Results

[0001171843-15-004361:8k_2_02:11]
Net sales for the second quarter of 2015 were $445.4 million compared to $329.2 million in the first quarter of 2015 and $297.6 million in the second quarter of 2014.

[0001171843-15-004361:8k_2_02:12]
GAAP operating income for the second quarter of 2015 was a loss of $7.1 million compared to GAAP operating income of $8.3 million in the first quarter of 2015 and $3.2 million in the second quarter of 2014.

[0001171843-15-004361:8k_2_02:13]
GAAP net loss for the second quarter of 2015 was $36.6 million, or $0.41 per share. This compares to GAAP net income of $3.4 million, or $0.04 per diluted share, in the first quarter of 2015 and a GAAP net loss of $3.1 million, or $0.04 per share, in the second quarter of 2014. The GAAP results were significantly impacted by approximately $46 million of expenses related to the acquisition of Viasystems.

[0001171843-15-004361:8k_2_02:14]
On a non-GAAP basis, net income for the second quarter of 2015 was $14.9 million, or $0.17 per diluted share. This compares to non-GAAP net income of $10.8 million, or $0.13 per diluted share, for the first quarter of 2015 and $3.9 million, or $0.05 per diluted share, for the second quarter of 2014.

[0001171843-15-004361:8k_2_02:15]
Adjusted EBITDA for the second quarter of 2015 was $59.7 million, or 13.4 percent of net sales, compared to adjusted EBITDA of $42.5 million, or 12.9 percent of net sales, for the first quarter of 2015 and $32.8 million, or 11 percent of net sales, for the second quarter of 2014.

[0001171843-15-004361:8k_2_02:16]
"The second quarter results reflect the dramatic repositioning of the company as we successfully completed the Viasystems acquisition, which added $93 million of revenue in the quarter," said Tom Edman, CEO of TTM. "In addition, we delivered strong year-over-year organic revenue growth of 18% driven by continued robust demand in the cellular phone and networking end markets. Integration of Viasystems is progressing on plan as our combined TTM focuses on operational execution for our global customer base."

[0001171843-15-004361:8k_2_02:17]
Mr. Edman continued, "We enter the third quarter excited about our significantly expanded position in the automotive market and continued strength in the aerospace and defense, medical, industrial and instrumentation, cellular phone and networking/telecom end markets. As one of the world's leading PCB manufacturers, we now have greater scale and diversity in our end markets and customer base."

[0001171843-15-004361:8k_2_02:18]
Business Outlook

[0001171843-15-004361:8k_2_02:19]
For the third quarter of 2015, TTM estimates that revenue will be in the range of $640 million to $680 million, and non-GAAP net income will be in the range of $0.14 to $0.20 per diluted share.

[0001171843-15-004361:8k_2_02:20]
To Access the Live Webcast/Conference Call

[0001171843-15-004361:8k_2_02:21]
TTM will host a conference call and webcast to discuss second quarter 2015 results and third quarter 2015 outlook on Wednesday, August 5, 2015, at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call may include forward-looking statements.

[0001171843-15-004361:8k_2_02:22]
Telephone access is available by dialing domestic 1-888-503-8175 or international 1-719-325-2458 (ID 5927975). The conference call also will be webcast on TTM's website at www.ttm.com.

[0001171843-15-004361:8k_2_02:23]
To Access a Replay of the Webcast

[0001171843-15-004361:8k_2_02:24]
The replay of the webcast will remain accessible for one week following the live event on TTM's website at www.ttm.com.

[0001171843-15-004361:8k_2_02:25]
About TTM

[0001171843-15-004361:8k_2_02:26]
TTM Technologies, Inc. is a major global printed circuit board manufacturer, focusing on quick-turn and technologically advanced PCBs, backplane assemblies and electro-mechanical solutions. TTM stands for time-to-market, representing how TTM's time-critical, one-stop manufacturing services enable customers to shorten the time required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001171843-15-004361:8k_2_02:27]
Forward-Looking Statements

[0001171843-15-004361:8k_2_02:28]
This release contains forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These statements reflect TTM's current expectations, and TTM does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond TTM's control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, the successful integration of Viasystems, general market and economic conditions, including interest rates, currency exchange rates and consumer spending, demand for TTM's products, market pressures on prices of TTM's products, warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements, TTM's dependence upon a small number of customers and other "Risk Factors" and "Management's discussion and analysis of financial condition and Results of Operations" sections of the Company's public reports filed with the SEC.

[0001171843-15-004361:8k_2_02:29]
About Our Non-GAAP Financial Measures

[0001171843-15-004361:8k_2_02:30]
This release includes information about TTM's adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable investors to see TTM through the eyes of management and to provide better insight into TTM's ongoing financial performance.

[0001171843-15-004361:8k_2_02:31]
Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, asset impairments, restructuring, costs related to acquisitions, and other charges. Management believes that the non-GAAP financial information – which adds back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt, acquisition-related costs, asset impairments, restructuring and other unusual or infrequent items as well as the associated tax impact of these charges and discrete tax items – provides additional useful information to investors regarding TTM's ongoing financial condition and results of operations.

[0001171843-15-004361:8k_2_02:32]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar non-GAAP financial measures used by other companies. TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliation to the most directly comparable GAAP financial measure.  However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001171843-15-004361:8k_2_02:33]
- Tables Follow -

[0001171843-15-004361:8k_2_02:34]
| TTM TECHNOLOGIES, INC. |
| Selected Unaudited Financial Information |
| (In thousands, except per share data) |
|  | Second Quarter | First Quarter | First Two Quarters |
|  | 2015 | 2014 | 2015 | 2015 | 2014 |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |
| Net sales | $ 445,445 | $ 297,635 | $ 329,164 | $ 774,609 | $ 589,530 |
| Cost of goods sold | 384,255 | 259,035 | 277,605 | 661,860 | 512,424 |
| Gross profit | 61,190 | 38,600 | 51,559 | 112,749 | 77,106 |
| Operating expenses: |  |  |  |  |  |
| Selling and marketing | 12,301 | 8,637 | 9,455 | 21,756 | 17,960 |
| General and administrative | 52,009 | 22,647 | 33,990 | 85,999 | 45,165 |
| Amortization of definite-lived intangibles | 3,910 | 2,236 | 1,874 | 5,784 | 4,472 |
| Restructuring charges | 30 | 37 | 479 | 509 | 13 |
| Impairment of long-lived assets | -- | 1,845 | -- | -- | 1,845 |
| Gain on sale of asset | -- | -- | (2,504) | (2,504) | -- |
| Total operating expenses | 68,250 | 35,402 | 43,294 | 111,544 | 69,455 |
| Operating income (loss) | (7,060) | 3,198 | 8,265 | 1,205 | 7,651 |
| Interest expense | (12,778) | (5,915) | (5,765) | (18,543) | (12,121) |
| Loss on extinguishment of debt | (802) | -- | -- | (802) | (506) |
| Other, net | 681 | 121 | (415) | 266 | (3,274) |
| Income (loss) before income taxes | (19,959) | (2,596) | 2,085 | (17,874) | (8,250) |
| Income tax (provision) benefit | (16,624) | (508) | 1,361 | (15,263) | 1,347 |
| Net income (loss) | $ (36,583) | $ (3,104) | $ 3,446 | $ (33,137) | $ (6,903) |
| Net income attributable to noncontrolling interest | (29) | -- | -- | (29) | -- |
| Net income (loss) attributable to stockholders | $ (36,612) | $ (3,104) | $ 3,446 | $ (33,166) | $ (6,903) |
| Earnings (loss) per share attributable to stockholders: |  |  |  |  |  |
| Basic | $ (0.41) | $ (0.04) | $ 0.04 | $ (0.38) | $ (0.08) |
| Diluted | $ (0.41) | $ (0.04) | $ 0.04 | $ (0.38) | $ (0.08) |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |
| Basic | 88,834 | 83,336 | 83,603 | 86,218 | 83,130 |
| Diluted | 88,834 | 83,336 | 84,465 | 86,218 | 83,130 |
| SELECTED BALANCE SHEET DATA |  |  |  |  |  |
|  | June 29, 2015 | December 29, 2014 |  |  |  |
| Cash and cash equivalents, including restricted cash | $ 170,969 | $ 279,042 |  |  |  |
| Accounts and notes receivable, net | 461,483 | 307,933 |  |  |  |
| Inventories | 295,340 | 145,187 |  |  |  |
| Total current assets | 982,609 | 798,123 |  |  |  |
| Property, plant and equipment, net | 1,181,434 | 754,718 |  |  |  |
| Other non-current assets | 515,793 | 48,448 |  |  |  |
| Total assets | 2,679,836 | 1,601,289 |  |  |  |
| Short-term debt, including current portion of long-term debt | $ 87,126 | $ 128,045 |  |  |  |
| Accounts payable | 378,490 | 217,326 |  |  |  |
| Total current liabilities | 671,565 | 496,012 |  |  |  |
| Debt, net of discount | 1,110,795 | 374,642 |  |  |  |
| Total long-term liabilities | 1,168,007 | 389,813 |  |  |  |
| Total stockholders' equity | 840,264 | 715,464 |  |  |  |
| Total liabilities and stockholders' equity | 2,679,836 | 1,601,289 |  |  |  |

[0001171843-15-004361:8k_2_02:35]
| SUPPLEMENTAL DATA |
|  | Second Quarter | First Quarter | First Two Quarters |
|  | 2015 | 2014 | 2015 | 2015 | 2014 |
| Gross margin | 13.7% | 13.0% | 15.7% | 14.6% | 13.1% |
| Operating margin | (1.6)% | 1.1% | 2.5% | 0.2% | 1.3% |
| End Market Breakdown: |  |  |  |  |  |
|  | Second Quarter | First Quarter |  |  |
|  | 2015 | 2014 | 2015 |  |  |
| Aerospace/Defense | 15% | 18% | 15% |  |  |
| Automotive | 7% | 2% | 2% |  |  |
| Cellular Phone | 24% | 12% | 30% |  |  |
| Computing/Storage/Peripherals | 11% | 14% | 11% |  |  |
| Medical/Industrial/Instrumentation | 12% | 11% | 9% |  |  |
| Networking/Communications | 26% | 40% | 29% |  |  |
| Other | 5% | 3% | 4% |  |  |
| Stock-based Compensation: |  |  |  |  |  |
|  | Second Quarter | First Quarter |  |  |
|  | 2015 | 2014 | 2015 |  |  |
| Amount included in: |  |  |  |  |  |
| Cost of goods sold | $ 243 | $ 199 | $ 225 |  |  |
| Selling and marketing | 269 | 253 | 271 |  |  |
| General and administrative | 1,802 | 1,479 | 1,544 |  |  |
| Total stock-based compensation expense | $ 2,314 | $ 1,931 | $ 2,040 |  |  |
| Operating Segment Data: |  |  |  |  |  |
|  | Second Quarter | First Quarter |  |  |
| Net sales: | 2015 | 2014 | 2015 |  |  |
| Asia Pacific | $ 218,650 | $ 166,699 | $ 205,365 |  |  |
| North America | 133,794 | 131,594 | 124,321 |  |  |
| Viasystems | 93,194 | -- | -- |  |  |
| Total sales | 445,638 | 298,293 | 329,686 |  |  |
| Inter-segment sales | (193) | (658) | (522) |  |  |
| Total net sales | $ 445,445 | $ 297,635 | $ 329,164 |  |  |
| Operating segment income: |  |  |  |  |  |
| Asia Pacific | $ 13,654 | $ (1,925) | $ 14,441 |  |  |
| North America | (13,514) | 7,359 | (4,302) |  |  |
| Viasystems | (3,290) | -- | -- |  |  |
| Total operating segment income (loss) | (3,150) | 5,434 | 10,139 |  |  |
| Amortization of definite-lived intangibles | (3,910) | (2,236) | (1,874) |  |  |
| Total operating income (loss) | (7,060) | 3,198 | 8,265 |  |  |
| Total other expense | (12,899) | (5,794) | (6,180) |  |  |
| Income (loss) before income taxes | $ (19,959) | $ (2,596) | $ 2,085 |  |  |

[0001171843-15-004361:8k_2_02:36]
| RECONCILIATIONS1 |
|  | Second Quarter | First Quarter | First Two Quarters |
|  | 2015 | 2014 | 2015 | 2015 | 2014 |
| Non-GAAP gross profit reconciliation2: |  |  |  |  |  |
| GAAP gross profit | $ 61,190 | $ 38,600 | $ 51,559 | $ 112,749 | $ 77,106 |
| Add back item: |  |  |  |  |  |
| Inventory markup and PP&E step up | 7,408 | -- | -- | 7,408 | -- |
| Stock-based compensation | 243 | 199 | 225 | 468 | 462 |
| Non-GAAP gross profit | $ 68,841 | $ 38,799 | $ 51,784 | $ 120,625 | $ 77,568 |
| Non-GAAP gross margin | 15.5% | 13.0% | 15.7% | 15.6% | 13.2% |
| Non-GAAP operating income reconciliation3: |  |  |  |  |  |
| GAAP operating income (loss) | $ (7,060) | $ 3,198 | $ 8,265 | $ 1,205 | $ 7,651 |
| Add back items: |  |  |  |  |  |
| Amortization of definite-lived intangibles | 3,910 | 2,236 | 1,874 | 5,784 | 4,472 |
| Stock-based compensation | 2,314 | 1,931 | 2,040 | 4,354 | 4,099 |
| Gain on sale of asset | -- | -- | (2,504) | (2,504) | -- |
| Acquisition-related costs | 22,627 | -- | 8,235 | 30,862 | -- |
| Inventory markup and PP&E step up | 7,408 | -- | -- | 7,408 | -- |
| Impairments and restructuring charges | 30 | 1,882 | 479 | 509 | 1,858 |
| Non-GAAP operating income | $ 29,229 | $ 9,247 | $ 18,389 | $ 47,618 | $ 18,080 |
| Non-GAAP operating margin | 6.6% | 3.1% | 5.6% | 6.1% | 3.1% |
| Non-GAAP net income and EPS attributable to stockholders reconciliation4: |  |  |  |  |  |
| GAAP net income (loss) attributable to stockholders | $ (36,612) | $ (3,104) | $ 3,446 | $ (33,166) | $ (6,903) |
| Add back items: |  |  |  |  |  |
| Amortization of definite-lived intangibles | 3,910 | 2,236 | 1,874 | 5,784 | 4,472 |
| Stock-based compensation | 2,314 | 1,931 | 2,040 | 4,354 | 4,099 |
| Non-cash interest expense | 3,289 | 2,509 | 2,625 | 5,914 | 5,032 |
| Gain on sale of asset | -- | -- | (2,504) | (2,504) | -- |
| Acquisition-related costs | 22,627 | -- | 8,235 | 30,862 | -- |
| Inventory markup and PP&E step up | 7,408 | -- | -- | 7,408 | -- |
| Impairments, restructuring and other charges | 832 | 1,882 | 479 | 1,311 | 2,364 |
| Income taxes | 11,110 | (1,587) | (5,366) | 5,744 | (3,980) |
| Non-GAAP net income attributable to stockholders | $ 14,878 | $ 3,867 | $ 10,829 | $ 25,707 | $ 5,084 |
| Non-GAAP earnings per diluted share attributable to stockholders | $ 0.17 | $ 0.05 | $ 0.13 | $ 0.29 | $ 0.06 |
| Adjusted EBITDA reconciliation5: |  |  |  |  |  |
| GAAP net income (loss) | $ (36,583) | $ (3,104) | $ 3,446 | $ (33,137) | $ (6,903) |
| Add back items: |  |  |  |  |  |
| Income tax provision (benefit) | 16,624 | 508 | (1,361) | 15,263 | (1,347) |
| Interest expense | 12,778 | 5,915 | 5,765 | 18,543 | 12,121 |
| Amortization of definite-lived intangibles | 3,910 | 2,236 | 1,874 | 5,784 | 4,472 |
| Depreciation expense | 29,776 | 23,437 | 24,536 | 54,312 | 47,144 |
| Stock-based compensation | 2,314 | 1,931 | 2,040 | 4,354 | 4,099 |
| Gain on sale of asset | -- | -- | (2,504) | (2,504) | -- |
| Acquisition-related costs | 22,627 | -- | 8,235 | 30,862 | -- |
| Inventory markup and PP&E step up | 7,408 | -- | -- | 7,408 | -- |
| Impairments, restructuring and other charges | 832 | 1,882 | 479 | 1,311 | 2,364 |
| Adjusted EBITDA | $ 59,686 | $ 32,805 | $ 42,510 | $ 102,196 | $ 61,950 |
| Adjusted EBITDA margin | 13.4% | 11.0% | 12.9% | 13.2% | 10.5% |
| 1 This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income attributable to stockholders, non-GAAP EPS attributable to stockholders, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |
| 2 Non-GAAP gross profit and gross margin measures exclude stock-based compensation expense, inventory markup and PP&E step up. |
| 3 Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges. |
| 4 This information provides non-GAAP net income attributable to stockholders and non-GAAP EPS attributable to stockholders, which are non-GAAP financial measures. Management believes that both measures -- which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items -- provide additional useful information to investors regarding the Company's ongoing financial condition and results of operations. |
| 5 Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |

[0001171843-15-004361:8k_2_02:37]
CONTACT: Todd Schull, CFO
         714-327-3000
