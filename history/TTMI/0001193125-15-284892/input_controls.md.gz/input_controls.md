# TTMI 10-Q controls and the auditor's report


## item_4_controls

[0001193125-15-284892:item_4_controls:1]
Item 4. Controls and Procedures

[0001193125-15-284892:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001193125-15-284892:item_4_controls:3]
Our management, under the supervision and with the participation of our Chief Executive Officer (CEO) and Chief Financial Officer (CFO), has evaluated the effectiveness of the design and operation of our
disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act of 1934, as amended (the Exchange Act)) as of the end of the period covered by this report. Based on this evaluation, our CEO and CFO have
concluded that, as of June 29, 2015, such disclosure controls and procedures were effective to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is
(i) recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and (ii) accumulated and communicated to our management, including our CEO and CFO, as appropriate to allow timely
decisions regarding required disclosures.

[0001193125-15-284892:item_4_controls:4]
Changes in Internal Control Over Financial Reporting

[0001193125-15-284892:item_4_controls:5]
As a result of the acquisition of Viasystems on May 31, 2015, we have implemented internal controls over financial
reporting to include consolidation of the acquired Viasystems, as well as acquisition-related accounting and disclosures. The acquisition of the Viasystems represents a material change in internal control over financial reporting since
management’s last assessment of the Company’s internal control over financial reporting, which was completed as of December 29, 2014.

[0001193125-15-284892:item_4_controls:6]
The acquired Viasystems business utilizes separate information and accounting systems and processes. Our management is in the process of reviewing and evaluating the design and operating effectiveness of
its internal control over financial reporting relating to Viasystems.

[0001193125-15-284892:item_4_controls:7]
There have been no other material
changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended June 29, 2015 that have materially affected, or are reasonably likely to materially affect,
our internal control over financial reporting.

[0001193125-15-284892:item_4_controls:8]
Inherent Limitations on Effectiveness of Controls

[0001193125-15-284892:item_4_controls:9]
A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the
control system’s objectives will be met. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Further, because of the inherent
limitations, internal control over financial reporting may not prevent or detect misstatements due to error or fraud. These inherent limitations include the realities that judgments in decision-making can be faulty and that breakdowns can occur
because of simple error or mistake. Controls also can be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on
certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Projections of any evaluation of controls effectiveness to
future periods are subject to risks that controls may become inadequate because of changes in conditions, or that the degree of compliance with policies or procedures may deteriorate.

[0001193125-15-284892:item_4_controls:10]
33
