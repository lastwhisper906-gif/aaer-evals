# TTMI note change history — 0000950170-24-121449 → 0000950170-25-063937


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0000950170-25-063937:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of March 31, 2025 and December 30, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2024-11-05, similarity 0.9821):
[0000950170-24-121449:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 30, 2024 and January 1, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

- added (2025-05-06):
[0000950170-25-063937:note_history:2]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $10,427 and $17,218 as of March 31, 2025 and December 30, 2024, respectively.

- removed (2025-05-06):
[0000950170-24-121449:note_history:3]
Offset Agreements

- removed (2025-05-06):
[0000950170-24-121449:note_history:4]
The Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of September 30, 2024, the Company had outstanding offset agreements of approximately $27,268, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. To date, the Company has not been obligated to pay any such penalties.

- removed (2025-05-06):
[0000950170-24-121449:note_history:5]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Under the terms of the agreements, the Company confirms the validity of each supplier invoice to the respective financial institution upon receipt. The supplier receives payment from the financial institution, and the Company pays the financial institution based on the terms negotiated, which generally range from 160 days to 360 days. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $18,278 and $18,832 as of September 30, 2024 and January 1, 2024, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0000950170-25-063937:note_history:6]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial, and instrumentation, and networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors, and government agencies (both domestic and allied foreign governments).
  (was, 2024-11-05, similarity 0.9382):
[0000950170-24-121449:note_history:6]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial and instrumentation related products, and networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors, and government agencies (both domestic and allied foreign governments).

- changed (2025-05-06):
[0000950170-25-063937:note_history:7]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflict between Russia and Ukraine as well as other global regions and the imposition of, or changes to, tariffs by the United States as well as retaliatory tariffs or measures by other countries, the global economy and financial markets have been volatile in recent periods. As such, the Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.
  (was, 2024-11-05, similarity 0.9038):
[0000950170-24-121449:note_history:7]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflict between Russia and Ukraine, and the conflict in the Middle East, the global economy and financial markets have been volatile. As such, the Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

- added (2025-05-06):
[0000950170-25-063937:note_history:8]
In November 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2024-03, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosure in the notes to the financial statements of specified information about certain costs and expenses. In January 2025, the FASB issued ASU 2025-01, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which amends the effective date of ASU 2024-03 to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027. Early adoption of ASU 2024-03 is permitted. ASU 2024-03 should be applied either prospectively to financial statements issued for reporting periods after the effective date or retrospectively to any or all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

- changed (2025-05-06):
[0000950170-25-063937:note_history:9]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. The update will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted for annual financial statements not yet issued or made available for issuance. The Company will adopt ASU 2023-09 in its 2025 fiscal year Form 10-K. This ASU will impact only the Company's disclosures with no impacts to the results of operations, cash flows, and financial condition.
  (was, 2024-11-05, similarity 0.7323):
[0000950170-24-121449:note_history:9]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. The update will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted for annual financial statements not yet issued or made available for issuance. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

- removed (2025-05-06):
[0000950170-24-121449:note_history:10]
In November 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosure in the notes to the financial statements of specified information about certain costs and expenses. The amendments are effective for fiscal years beginning after December 15, 2026, and for interim periods within fiscal years beginning after December 15, 2027. Early adoption is permitted. The amendments should be applied either prospectively to financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

- removed (2025-05-06):
[0000950170-24-121449:note_history:11]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements - Amendments to Remove References to the Concepts Statements, to remove various references to concepts statements from the Accounting Standards Codification (ASC). These amendments clarify guidance, simplify wording or structure of guidance, and include other minor improvements. The amendments are effective for fiscal years beginning after December 15, 2024, applied prospectively, with early adoption and retrospective application permitted. The impact of the adoption of the amendments in this update is not expected to be material to the Company's consolidated financial statements and related disclosures.

- removed (2025-05-06):
[0000950170-24-121449:note_history:12]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. The amendments are effective for fiscal years beginning after December 15, 2023, and for interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company will adopt ASU 2023-07 in its 2024 fiscal year Form 10-K using a retrospective transition method. This ASU will impact only the Company's disclosures with no impacts to the results of operations, cash flows, and financial condition.

- removed (2025-05-06):
[0000950170-24-121449:note_history:13]
In October 2023, the FASB issued ASU 2023-06, Disclosure Improvements: Codification Amendments in Response to the Securities and Exchange Commission’s Disclosure Update and Simplification Initiative, which modifies the disclosure or presentation requirements of a variety of topics in the ASC in response to the SEC’s Release No. 33-10532, Disclosure Update and Simplification Initiative, and align the ASC requirements with the SEC’s regulations. For entities subject to the SEC's existing disclosure requirements, the effective date for each amendment will be the date on which the SEC's removal of that related disclosure from Regulation S-X or Regulation S-K becomes effective. However, if by June 30, 2027, the SEC has not removed the related disclosure from its regulations, the amendments will be removed from the Codification and not become effective. Early adoption is prohibited. The Company is currently evaluating the new guidance to determine the impact it may have on the presentation of its consolidated financial statements and related disclosures.


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0000950170-25-063937:note_history:14]
|  |  | As of |
|  |  | March 31, 2025 |  | December 30, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,176 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 3,362 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,449 |  |  |  | 2,727 |  |  |  | 8.01 |  |  |  |  | 3,589 |  |  |  | 2,840 |  |  |  | 8.01 |  |  |
| Total |  | $ | 6,625 |  |  | $ | 2,727 |  |  |  |  |  |  | $ | 6,951 |  |  | $ | 2,840 |  |  |  |  |  |
  (was, 2024-11-05, similarity 0.9498):
[0000950170-24-121449:note_history:14]
|  |  | As of September 30, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,546 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,729 |  |  |  | 2,951 |  |  |  | 8.01 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,275 |  |  | $ | 2,951 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-05-06):
[0000950170-25-063937:note_history:15]
|  |  | As of |  |
|  |  | March 31, 2025 |  |  | December 30, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 6.57 |  |  |  |  | 344,768 |  |  |  | 6.59 |  |  |  |  | 345,634 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 5.62 |  |  |  |  | 80,000 |  |  |  | 5.64 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 2,230 |  |  |  | 5.99 |  |  |  |  | 2,311 |  |
| Total debt |  |  |  |  |  |  | 926,998 |  |  |  |  |  |  |  | 927,945 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (6,625 | ) |  |  |  |  |  |  | (6,951 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,727 | ) |  |  |  |  |  |  | (2,840 | ) |
| Subtotal |  |  |  |  |  |  | 917,646 |  |  |  |  |  |  |  | 918,154 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,800 | ) |  |  |  |  |  |  | (3,795 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,846 |  |  |  |  |  |  | $ | 914,359 |  |

- changed (2025-05-06):
[0000950170-25-063937:note_history:16]
Borrowings under the Senior Notes due 2029 and Term Loan Facility due 2030 (Term Loan Facility) are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.
  (was, 2024-11-05, similarity 0.9347):
[0000950170-24-121449:note_history:16]
Borrowings under the Senior Notes due March 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

- changed (2025-05-06):
[0000950170-25-063937:note_history:17]
|  |  | As of |
|  |  | March 31, 2025 |  | December 30, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,176 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 3,362 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,449 |  |  |  | 2,727 |  |  |  | 8.01 |  |  |  |  | 3,589 |  |  |  | 2,840 |  |  |  | 8.01 |  |  |
| Total |  | $ | 6,625 |  |  | $ | 2,727 |  |  |  |  |  |  | $ | 6,951 |  |  | $ | 2,840 |  |  |  |  |  |
  (was, 2024-11-05, similarity 0.9498):
[0000950170-24-121449:note_history:17]
|  |  | As of September 30, 2024 |  | As of January 1, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,546 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 4,085 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,729 |  |  |  | 2,951 |  |  |  | 8.01 |  |  |  |  | 3,936 |  |  |  | 3,268 |  |  |  | 8.26 |  |  |
| Total |  | $ | 7,275 |  |  | $ | 2,951 |  |  |  |  |  |  | $ | 8,021 |  |  | $ | 3,268 |  |  |  |  |  |

- changed (2025-05-06):
[0000950170-25-063937:note_history:18]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,147 and $1,239 as of March 31, 2025 and December 30, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2024-11-05, similarity 0.9354):
[0000950170-24-121449:note_history:18]
The remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,329 and $1,603 as of September 30, 2024 and January 1, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2025-05-06):
[0000950170-25-063937:note_history:19]
As of March 31, 2025, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 4.6 years.
  (was, 2024-11-05, similarity 0.964):
[0000950170-24-121449:note_history:19]
As of September 30, 2024, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 5.1 years.

- removed (2025-05-06):
[0000950170-24-121449:note_history:20]
|  |  | As of September 30, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 7.10 |  |  |  |  | 346,500 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.15 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 926,500 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,275 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,951 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,274 |  |  |  |  |  |  |  | 917,836 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,465 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 912,809 |  |  |  |  |  |  | $ | 914,336 |  |

- removed (2025-05-06):
[0000950170-24-121449:note_history:21]
Refinancing of Term Loan Facility

- removed (2025-05-06):
[0000950170-24-121449:note_history:22]
On August 1, 2024, the Company entered into a First Amendment to its Amended and Restated Term Loan Credit Agreement, dated as of May 30, 2023, by and among the Company, as Borrower, JPMorgan Chase Bank, N.A., as Administrative Agent, and the several lenders from time to time parties thereto, pursuant to which the Company closed its $346,500 new senior secured term loan (Term Loan Facility) that bears interest at a floating rate of 1-month Chicago Mercantile Exchange (CME) Term Secured Overnight Financing Rate (SOFR) plus an applicable margin of 2.25%, 50 basis points lower than the previous term loan facility issued in May 2023. The Term Loan Facility is issued at par, maintains the same maturity of May 30, 2030 as the previous term loan facility, and the majority is a cashless rollover from the previous term loan facility.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-05-06):
[0000950170-25-063937:note_history:23]
|  |  | As of |  |
|  |  | March 31, 2025 |  |  | December 30, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 6.57 |  |  |  |  | 344,768 |  |  |  | 6.59 |  |  |  |  | 345,634 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 5.62 |  |  |  |  | 80,000 |  |  |  | 5.64 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 2,230 |  |  |  | 5.99 |  |  |  |  | 2,311 |  |
| Total debt |  |  |  |  |  |  | 926,998 |  |  |  |  |  |  |  | 927,945 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (6,625 | ) |  |  |  |  |  |  | (6,951 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,727 | ) |  |  |  |  |  |  | (2,840 | ) |
| Subtotal |  |  |  |  |  |  | 917,646 |  |  |  |  |  |  |  | 918,154 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,800 | ) |  |  |  |  |  |  | (3,795 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,846 |  |  |  |  |  |  | $ | 914,359 |  |

- removed (2025-05-06):
[0000950170-24-121449:note_history:24]
|  |  | As of September 30, 2024 |  |  | As of January 1, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 7.10 |  |  |  |  | 346,500 |  |  |  | 8.10 |  |  |  |  | 349,125 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 6.15 |  |  |  |  | 80,000 |  |  |  | 6.65 |  |  |  |  | 80,000 |  |
| Total debt |  |  |  |  |  |  | 926,500 |  |  |  |  |  |  |  | 929,125 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (7,275 | ) |  |  |  |  |  |  | (8,021 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,951 | ) |  |  |  |  |  |  | (3,268 | ) |
| Subtotal |  |  |  |  |  |  | 916,274 |  |  |  |  |  |  |  | 917,836 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,465 | ) |  |  |  |  |  |  | (3,500 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 912,809 |  |  |  |  |  |  | $ | 914,336 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0000950170-25-063937:note_history:25]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2025 |  |  | April 1, 2024 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 305,689 |  |  | $ | — |  |  | $ | 305,689 |  |  | $ | 264,776 |  |  | $ | — |  |  | $ | 264,776 |  |
| Automotive |  |  | 71,678 |  |  |  | — |  |  |  | 71,678 |  |  |  | 73,617 |  |  |  | — |  |  |  | 73,617 |  |
| Data Center Computing |  |  | 137,236 |  |  |  | 667 |  |  |  | 137,903 |  |  |  | 119,377 |  |  |  | 59 |  |  |  | 119,436 |  |
| Medical/Industrial/Instrumentation |  |  | 82,293 |  |  |  | 909 |  |  |  | 83,202 |  |  |  | 78,793 |  |  |  | 734 |  |  |  | 79,527 |  |
| Networking |  |  | 42,952 |  |  |  | 7,244 |  |  |  | 50,196 |  |  |  | 25,278 |  |  |  | 7,479 |  |  |  | 32,757 |  |
| Total |  | $ | 639,848 |  |  | $ | 8,820 |  |  | $ | 648,668 |  |  | $ | 561,841 |  |  | $ | 8,272 |  |  | $ | 570,113 |  |
  (was, 2024-11-05, similarity 0.9476):
[0000950170-24-121449:note_history:25]
|  |  | Quarter Ended September 30, 2024 |  |  | Quarter Ended October 2, 2023 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 284,275 |  |  | $ | — |  |  | $ | 284,275 |  |  | $ | 255,618 |  |  | $ | — |  |  | $ | 255,618 |  |
| Automotive |  |  | 85,015 |  |  |  | — |  |  |  | 85,015 |  |  |  | 86,803 |  |  |  | — |  |  |  | 86,803 |  |
| Data Center Computing |  |  | 119,299 |  |  |  | 201 |  |  |  | 119,500 |  |  |  | 99,584 |  |  |  | — |  |  |  | 99,584 |  |
| Medical/Industrial/Instrumentation |  |  | 86,185 |  |  |  | 579 |  |  |  | 86,764 |  |  |  | 89,818 |  |  |  | 895 |  |  |  | 90,713 |  |
| Networking |  |  | 32,019 |  |  |  | 8,965 |  |  |  | 40,984 |  |  |  | 31,853 |  |  |  | 8,011 |  |  |  | 39,864 |  |
| Total |  | $ | 606,793 |  |  | $ | 9,745 |  |  | $ | 616,538 |  |  | $ | 563,676 |  |  | $ | 8,906 |  |  | $ | 572,582 |  |

- removed (2025-05-06):
[0000950170-24-121449:note_history:26]
|  |  | Three Quarters Ended September 30, 2024 |  |  | Three Quarters Ended October 2, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 821,840 |  |  | $ | — |  |  | $ | 821,840 |  |  | $ | 742,194 |  |  | $ | — |  |  | $ | 742,194 |  |
| Automotive |  |  | 241,330 |  |  |  | — |  |  |  | 241,330 |  |  |  | 272,644 |  |  |  | — |  |  |  | 272,644 |  |
| Data Center Computing |  |  | 362,728 |  |  |  | 323 |  |  |  | 363,051 |  |  |  | 221,759 |  |  |  | 51 |  |  |  | 221,810 |  |
| Medical/Industrial/Instrumentation |  |  | 251,394 |  |  |  | 2,035 |  |  |  | 253,429 |  |  |  | 279,565 |  |  |  | 2,557 |  |  |  | 282,122 |  |
| Networking |  |  | 87,449 |  |  |  | 24,689 |  |  |  | 112,138 |  |  |  | 118,156 |  |  |  | 26,602 |  |  |  | 144,758 |  |
| Total |  | $ | 1,764,741 |  |  | $ | 27,047 |  |  | $ | 1,791,788 |  |  | $ | 1,634,318 |  |  | $ | 29,210 |  |  | $ | 1,663,528 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0000950170-25-063937:note_history:27]
As of March 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations for long‑term contracts was $406,807. The Company expects to recognize revenue on approximately 53% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.
  (was, 2024-11-05, similarity 0.9783):
[0000950170-24-121449:note_history:27]
As of September 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $481,400. The Company expects to recognize revenue on approximately 46% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.

- changed (2025-05-06):
[0000950170-25-063937:note_history:28]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of March 31, 2025 and December 30, 2024 were $37,731 and $36,976, respectively.
  (was, 2024-11-05, similarity 0.9488):
[0000950170-24-121449:note_history:28]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of September 30, 2024 and January 1, 2024 were $34,703 and $25,213, respectively.

- changed (2025-05-06):
[0000950170-25-063937:note_history:29]
Revenue recognized for the quarter ended March 31, 2025 from amounts recorded as contract liabilities as of December 30, 2024 was $22,496. Revenue recognized for the quarter ended April 1, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $18,214.
  (was, 2024-11-05, similarity 0.6114):
[0000950170-24-121449:note_history:29]
Revenue recognized for the three quarters ended September 30, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $33,331. Revenue recognized for the three quarters ended October 2, 2023 from amounts recorded as contract liabilities as of January 2, 2023 was $33,939.

- changed (2025-05-06):
[0000950170-25-063937:note_history:30]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for both the quarters ended March 31, 2025 and April 1, 2024.
  (was, 2024-11-05, similarity 0.8045):
[0000950170-24-121449:note_history:30]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for both the quarter and three quarters ended September 30, 2024 and October 2, 2023.

- changed (2025-05-06):
[0000950170-25-063937:note_history:31]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2025 |  |  | April 1, 2024 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 305,689 |  |  | $ | — |  |  | $ | 305,689 |  |  | $ | 264,776 |  |  | $ | — |  |  | $ | 264,776 |  |
| Automotive |  |  | 71,678 |  |  |  | — |  |  |  | 71,678 |  |  |  | 73,617 |  |  |  | — |  |  |  | 73,617 |  |
| Data Center Computing |  |  | 137,236 |  |  |  | 667 |  |  |  | 137,903 |  |  |  | 119,377 |  |  |  | 59 |  |  |  | 119,436 |  |
| Medical/Industrial/Instrumentation |  |  | 82,293 |  |  |  | 909 |  |  |  | 83,202 |  |  |  | 78,793 |  |  |  | 734 |  |  |  | 79,527 |  |
| Networking |  |  | 42,952 |  |  |  | 7,244 |  |  |  | 50,196 |  |  |  | 25,278 |  |  |  | 7,479 |  |  |  | 32,757 |  |
| Total |  | $ | 639,848 |  |  | $ | 8,820 |  |  | $ | 648,668 |  |  | $ | 561,841 |  |  | $ | 8,272 |  |  | $ | 570,113 |  |
  (was, 2024-11-05, similarity 0.9476):
[0000950170-24-121449:note_history:31]
|  |  | Quarter Ended September 30, 2024 |  |  | Quarter Ended October 2, 2023 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 284,275 |  |  | $ | — |  |  | $ | 284,275 |  |  | $ | 255,618 |  |  | $ | — |  |  | $ | 255,618 |  |
| Automotive |  |  | 85,015 |  |  |  | — |  |  |  | 85,015 |  |  |  | 86,803 |  |  |  | — |  |  |  | 86,803 |  |
| Data Center Computing |  |  | 119,299 |  |  |  | 201 |  |  |  | 119,500 |  |  |  | 99,584 |  |  |  | — |  |  |  | 99,584 |  |
| Medical/Industrial/Instrumentation |  |  | 86,185 |  |  |  | 579 |  |  |  | 86,764 |  |  |  | 89,818 |  |  |  | 895 |  |  |  | 90,713 |  |
| Networking |  |  | 32,019 |  |  |  | 8,965 |  |  |  | 40,984 |  |  |  | 31,853 |  |  |  | 8,011 |  |  |  | 39,864 |  |
| Total |  | $ | 606,793 |  |  | $ | 9,745 |  |  | $ | 616,538 |  |  | $ | 563,676 |  |  | $ | 8,906 |  |  | $ | 572,582 |  |

- removed (2025-05-06):
[0000950170-24-121449:note_history:32]
|  |  | Three Quarters Ended September 30, 2024 |  |  | Three Quarters Ended October 2, 2023 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 821,840 |  |  | $ | — |  |  | $ | 821,840 |  |  | $ | 742,194 |  |  | $ | — |  |  | $ | 742,194 |  |
| Automotive |  |  | 241,330 |  |  |  | — |  |  |  | 241,330 |  |  |  | 272,644 |  |  |  | — |  |  |  | 272,644 |  |
| Data Center Computing |  |  | 362,728 |  |  |  | 323 |  |  |  | 363,051 |  |  |  | 221,759 |  |  |  | 51 |  |  |  | 221,810 |  |
| Medical/Industrial/Instrumentation |  |  | 251,394 |  |  |  | 2,035 |  |  |  | 253,429 |  |  |  | 279,565 |  |  |  | 2,557 |  |  |  | 282,122 |  |
| Networking |  |  | 87,449 |  |  |  | 24,689 |  |  |  | 112,138 |  |  |  | 118,156 |  |  |  | 26,602 |  |  |  | 144,758 |  |
| Total |  | $ | 1,764,741 |  |  | $ | 27,047 |  |  | $ | 1,791,788 |  |  | $ | 1,634,318 |  |  | $ | 29,210 |  |  | $ | 1,663,528 |  |
