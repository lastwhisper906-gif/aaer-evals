# TTMI notes — 0000950170-25-063937


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000950170-25-063937:notes:1]
[same as prior period, unchanged from 0000950170-24-121449:notes:1]

[0000950170-25-063937:notes:2]
[same as prior period, unchanged from 0000950170-24-121449:notes:2]

[0000950170-25-063937:notes:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial, and instrumentation, and networking. The Company’s customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors, and government agencies (both domestic and allied foreign governments).

[0000950170-25-063937:notes:4]
The accompanying unaudited consolidated condensed financial statements have been prepared by the Company pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements should be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the conflict between Russia and Ukraine as well as other global regions and the imposition of, or changes to, tariffs by the United States as well as retaliatory tariffs or measures by other countries, the global economy and financial markets have been volatile in recent periods. As such, the Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. The actual results the Company experienced may differ materially and adversely from its estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

[0000950170-25-063937:notes:5]
Recently Issued Accounting Standards Not Yet Adopted

[0000950170-25-063937:notes:6]
In November 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2024-03, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires disclosure in the notes to the financial statements of specified information about certain costs and expenses. In January 2025, the FASB issued ASU 2025-01, Income Statement-Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which amends the effective date of ASU 2024-03 to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027. Early adoption of ASU 2024-03 is permitted. ASU 2024-03 should be applied either prospectively to financial statements issued for reporting periods after the effective date or retrospectively to any or all prior periods presented in the financial statements. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, but expects additional disclosures upon adoption.

[0000950170-25-063937:notes:7]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. The update will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted for annual financial statements not yet issued or made available for issuance. The Company will adopt ASU 2023-09 in its 2025 fiscal year Form 10-K. This ASU will impact only the Company's disclosures with no impacts to the results of operations, cash flows, and financial condition.


## us-gaap:TreasuryStockTextBlock

[0000950170-25-063937:notes:8]
[same as prior period, unchanged from 0000950170-24-121449:notes:11]

[0000950170-25-063937:notes:9]
On May 3, 2023, the Company's Board of Directors authorized and approved a share repurchase program (2023 Repurchase Program), under which the Company was permitted to repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through May 3, 2025. The Company may repurchase shares through open market purchases, privately‑negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (Exchange Act), which sets certain restrictions on the method, timing, price, and volume of open market stock repurchases. In addition, the Company adopted one trading plan in accordance with Rule 10b5-1 of the Exchange

[0000950170-25-063937:notes:10]
Act to facilitate certain purchases that may be effected under the share repurchase program. The timing, manner, price, and amount of any repurchases will be determined at the Company’s discretion, and the share repurchase program may be suspended, terminated, or modified at any time for any reason. The repurchase program does not obligate the Company to acquire any specific number of shares.

[0000950170-25-063937:notes:11]
During the quarter ended March 31, 2025, the Company repurchased 700 shares of common stock for a total cost of $17,875 (including commissions). As of March 31, 2025, the remaining amount in value available to be repurchased under the 2023 Repurchase Program was approximately $23,213.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-25-063937:notes:12]
[same as prior period, unchanged from 0000950170-24-121449:notes:14]

[0000950170-25-063937:notes:13]
[same as prior period, unchanged from 0000950170-24-121449:notes:15]

[0000950170-25-063937:notes:14]
The Company had cash and cash equivalents held by its foreign subsidiaries of $151,458 and $207,909 as of March 31, 2025 and December 30, 2024, respectively. The Company maintains its cash and cash equivalents with major financial institutions and such balances exceed Federal Deposit Insurance Corporation insurance limits. The Company has not experienced any losses in such accounts and believes it is not exposed to any significant risk on cash and cash equivalents.

[0000950170-25-063937:notes:15]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk. As of March 31, 2025, one customer accounted for 10% of the Company's accounts receivable. There were no customers that accounted for 10% or more of the Company's accounts receivable as of December 30, 2024.

[0000950170-25-063937:notes:16]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.

[0000950170-25-063937:notes:17]
For the quarter ended March 31, 2025, one customer accounted for approximately 12% of the Company's net sales. For the quarter ended April 1, 2024, two customers collectively accounted for approximately 22% of the Company's net sales.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-25-063937:notes:18]
[same as prior period, unchanged from 0000950170-24-121449:notes:19]

[0000950170-25-063937:notes:19]
As of March 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations for long‑term contracts was $406,807. The Company expects to recognize revenue on approximately 53% of the remaining performance obligations for the Company’s long-term contracts over the next 12 months with the remaining amount expected to be recognized thereafter.

[0000950170-25-063937:notes:20]
For contracts in which anticipated total costs exceed the total expected revenue, an estimated loss is recognized in the period when identifiable. A provision for the entire amount of the estimated loss is recorded on a cumulative basis. The estimated remaining costs to complete for loss contracts as of March 31, 2025 and December 30, 2024 were $37,731 and $36,976, respectively.

[0000950170-25-063937:notes:21]
Revenue recognized for the quarter ended March 31, 2025 from amounts recorded as contract liabilities as of December 30, 2024 was $22,496. Revenue recognized for the quarter ended April 1, 2024 from amounts recorded as contract liabilities as of January 1, 2024 was $18,214.

[0000950170-25-063937:notes:22]
Revenue from products and services transferred to customers over time and at a point in time accounted for 96% and 4%, respectively, of the Company’s revenue for both the quarters ended March 31, 2025 and April 1, 2024.

[0000950170-25-063937:notes:23]
[same as prior period, unchanged from 0000950170-24-121449:notes:24]

[0000950170-25-063937:notes:24]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2025 |  |  | April 1, 2024 |  |
|  |  | PCB |  |  | RF and Specialty Components (RF&S Components) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| End Markets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  | $ | 305,689 |  |  | $ | — |  |  | $ | 305,689 |  |  | $ | 264,776 |  |  | $ | — |  |  | $ | 264,776 |  |
| Automotive |  |  | 71,678 |  |  |  | — |  |  |  | 71,678 |  |  |  | 73,617 |  |  |  | — |  |  |  | 73,617 |  |
| Data Center Computing |  |  | 137,236 |  |  |  | 667 |  |  |  | 137,903 |  |  |  | 119,377 |  |  |  | 59 |  |  |  | 119,436 |  |
| Medical/Industrial/Instrumentation |  |  | 82,293 |  |  |  | 909 |  |  |  | 83,202 |  |  |  | 78,793 |  |  |  | 734 |  |  |  | 79,527 |  |
| Networking |  |  | 42,952 |  |  |  | 7,244 |  |  |  | 50,196 |  |  |  | 25,278 |  |  |  | 7,479 |  |  |  | 32,757 |  |
| Total |  | $ | 639,848 |  |  | $ | 8,820 |  |  | $ | 648,668 |  |  | $ | 561,841 |  |  | $ | 8,272 |  |  | $ | 570,113 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000950170-25-063937:notes:25]
[same as prior period, unchanged from 0000950170-24-121449:notes:27]

[0000950170-25-063937:notes:26]
|  |  | As of |  |
|  |  | March 31, 2025 |  |  | December 30, 2024 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 192,988 |  |  | $ | 178,066 |  |
| Work-in-process |  |  | 50,519 |  |  |  | 45,580 |  |
| Finished goods |  |  | 3,330 |  |  |  | 1,339 |  |
| Inventories |  | $ | 246,837 |  |  | $ | 224,985 |  |
| Property, plant, and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 69,598 |  |  | $ | 69,788 |  |
| Buildings and improvements |  |  | 523,768 |  |  |  | 515,773 |  |
| Machinery and equipment |  |  | 1,141,751 |  |  |  | 1,116,658 |  |
| Furniture and fixtures and other |  |  | 11,242 |  |  |  | 11,115 |  |
| Construction-in-progress |  |  | 81,493 |  |  |  | 75,502 |  |
| Property, plant, and equipment, gross |  |  | 1,827,852 |  |  |  | 1,788,836 |  |
| Less: Accumulated depreciation |  |  | (939,766 | ) |  |  | (918,879 | ) |
| Property, plant, and equipment, net |  | $ | 888,086 |  |  | $ | 869,957 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | $ | 11,737 |  |  | $ | 15,919 |  |
| Sales return and allowances |  |  | 10,687 |  |  |  | 10,777 |  |
| Accrued facility operating costs |  |  | 9,788 |  |  |  | 8,925 |  |
| Warranty |  |  | 8,099 |  |  |  | 7,685 |  |
| Housing fund |  |  | 8,070 |  |  |  | 7,927 |  |
| Operating leases |  |  | 7,916 |  |  |  | 7,556 |  |
| Accrued professional fees |  |  | 3,683 |  |  |  | 3,606 |  |
| Interest |  |  | 3,593 |  |  |  | 9,054 |  |
| Restructuring |  |  | 1,499 |  |  |  | 3,486 |  |
| Other |  |  | 33,543 |  |  |  | 45,039 |  |
| Other current liabilities |  | $ | 98,615 |  |  | $ | 119,974 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 41,520 |  |  | $ | 41,362 |  |
| Customer deposits |  |  | 28,390 |  |  |  | 28,390 |  |
| Finance leases |  |  | 16,245 |  |  |  | 11,985 |  |
| Other |  |  | 25,210 |  |  |  | 26,011 |  |
| Other long-term liabilities |  | $ | 111,365 |  |  | $ | 107,748 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-25-063937:notes:27]
[same as prior period, unchanged from 0000950170-24-121449:notes:29]

[0000950170-25-063937:notes:28]
[same as prior period, unchanged from 0000950170-24-121449:notes:30]

[0000950170-25-063937:notes:29]
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| As of March 31, 2025 and December 30, 2024 |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 810,235 |  |  | $ | 177,200 |  |  | $ | 987,435 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  |  | (145,900 | ) |  |  | (317,300 | ) |
| Carrying amount |  | $ | 638,835 |  |  | $ | 31,300 |  |  | $ | 670,135 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-25-063937:notes:30]
[same as prior period, unchanged from 0000950170-24-121449:notes:32]

[0000950170-25-063937:notes:31]
[same as prior period, unchanged from 0000950170-24-121449:notes:33]

[0000950170-25-063937:notes:32]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| As of March 31, 2025 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 323,500 |  |  | $ | (168,599 | ) |  | $ | 154,901 |  |  |  | 11.8 |  |
| Technology |  |  | 66,650 |  |  |  | (38,956 | ) |  |  | 27,694 |  |  |  | 8.2 |  |
| Total |  | $ | 390,150 |  |  | $ | (207,555 | ) |  | $ | 182,595 |  |  |  |  |
| As of December 30, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 323,500 |  |  | $ | (161,710 | ) |  | $ | 161,790 |  |  |  | 11.8 |  |
| Technology |  |  | 66,650 |  |  |  | (36,621 | ) |  |  | 30,029 |  |  |  | 8.2 |  |
| Total |  | $ | 390,150 |  |  | $ | (198,331 | ) |  | $ | 191,819 |  |  |  |  |

[0000950170-25-063937:notes:33]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $9,224 and $13,765 for the quarters ended March 31, 2025 and April 1, 2024, respectively. For the quarters ended March 31, 2025 and April 1, 2024, $2,335 and $2,336 of amortization expense was included in cost of goods sold, respectively.

[0000950170-25-063937:notes:34]
[same as prior period, unchanged from 0000950170-24-121449:notes:37]

[0000950170-25-063937:notes:35]
|  |  | (In thousands) |  |
| Remaining 2025 |  | $ | 27,673 |  |
| 2026 |  |  | 36,897 |  |
| 2027 |  |  | 34,543 |  |
| 2028 |  |  | 30,997 |  |
| 2029 |  |  | 22,355 |  |
| Thereafter |  |  | 30,130 |  |
| Total |  | $ | 182,595 |  |


## us-gaap:LongTermDebtTextBlock

[0000950170-25-063937:notes:36]
(8) Long-term Debt and Letters of Credit

[0000950170-25-063937:notes:37]
Long-term debt was as follows:

[0000950170-25-063937:notes:38]
|  |  | As of |  |
|  |  | March 31, 2025 |  |  | December 30, 2024 |  |
|  |  | Interest Rate |  | PrincipalOutstanding |  |  | Interest Rate |  | PrincipalOutstanding |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due May 2030 |  |  | 6.57 |  |  |  |  | 344,768 |  |  |  | 6.59 |  |  |  |  | 345,634 |  |
| Asia ABL Revolving Loan due June 2028 |  |  | 5.62 |  |  |  |  | 80,000 |  |  |  | 5.64 |  |  |  |  | 80,000 |  |
| Other |  |  | 5.99 |  |  |  |  | 2,230 |  |  |  | 5.99 |  |  |  |  | 2,311 |  |
| Total debt |  |  |  |  |  |  | 926,998 |  |  |  |  |  |  |  | 927,945 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (6,625 | ) |  |  |  |  |  |  | (6,951 | ) |
| Less: Unamortized debt discount |  |  |  |  |  |  | (2,727 | ) |  |  |  |  |  |  | (2,840 | ) |
| Subtotal |  |  |  |  |  |  | 917,646 |  |  |  |  |  |  |  | 918,154 |  |
| Less: Current maturities |  |  |  |  |  |  | (3,800 | ) |  |  |  |  |  |  | (3,795 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 913,846 |  |  |  |  |  |  | $ | 914,359 |  |

[0000950170-25-063937:notes:39]
Debt Covenants

[0000950170-25-063937:notes:40]
Borrowings under the Senior Notes due 2029 and Term Loan Facility due 2030 (Term Loan Facility) are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments.

[0000950170-25-063937:notes:41]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans) are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0000950170-25-063937:notes:42]
Debt Issuance Costs and Debt Discount

[0000950170-25-063937:notes:43]
Remaining unamortized debt issuance costs and debt discount were as follows:

[0000950170-25-063937:notes:44]
|  |  | As of |
|  |  | March 31, 2025 |  | December 30, 2024 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 3,176 |  |  | $ | — |  |  |  | 4.18 |  | % |  | $ | 3,362 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due May 2030 |  |  | 3,449 |  |  |  | 2,727 |  |  |  | 8.01 |  |  |  |  | 3,589 |  |  |  | 2,840 |  |  |  | 8.01 |  |  |
| Total |  | $ | 6,625 |  |  | $ | 2,727 |  |  |  |  |  |  | $ | 6,951 |  |  | $ | 2,840 |  |  |  |  |  |

[0000950170-25-063937:notes:45]
The above debt issuance costs and debt discount are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0000950170-25-063937:notes:46]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,147 and $1,239 as of March 31, 2025 and December 30, 2024, respectively, are included in deposits and other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0000950170-25-063937:notes:47]
As of March 31, 2025, the remaining weighted average amortization period for all unamortized debt issuance costs and debt discount was 4.6 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-25-063937:notes:48]
[same as prior period, unchanged from 0000950170-24-121449:notes:53]

[0000950170-25-063937:notes:49]
[same as prior period, unchanged from 0000950170-24-121449:notes:54]

[0000950170-25-063937:notes:50]
During the quarter ended March 31, 2025, the Company’s effective tax rate was impacted by a net discrete expense of $882. This was primarily due to deferred tax expense recorded against other comprehensive income, which was offset by a windfall tax benefit of the stock-based compensation released in the quarter ended March 31, 2025.

[0000950170-25-063937:notes:51]
[same as prior period, unchanged from 0000950170-24-121449:notes:56]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-25-063937:notes:52]
[same as prior period, unchanged from 0000950170-24-121449:notes:57]

[0000950170-25-063937:notes:53]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker (CODM), who is the President and Chief Executive Officer, to assess performance and to allocate resources. The CODM uses segment operating income to allocate resources such as employees and capital resources for each segment during the Company’s annual budgeting and forecasting process. Separate segment asset measures are not used as a basis for the CODM to evaluate the performance of or to allocate resources to the segments.

[0000950170-25-063937:notes:54]
The PCB reportable segment consists of PCBs, engineered systems using customer-supplied engineering and design plans, as well as long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance, and communications solutions, components, assemblies, and subsystems. The RF&S Components reportable segment consists of components, assemblies, subsystems, and completed systems which service its RF&S Components and certain aerospace and defense customers.

[0000950170-25-063937:notes:55]
Effective January 1, 2025, the Company changed its organization structure to enhance clarity in sector performance, accountability, and operating costs by clearly allocating resources to either Aerospace and Defense, Commercial, or RF&S Components. To align the new operating model and business structure, the Company is making management organizational changes and implementing new reporting and processes to provide discrete information to manage the business. Management expects to finalize its assessment of its operating segments when the implementations and transitions are completed, which is expected by the end of 2025.

[0000950170-25-063937:notes:56]
Reconciliations of net sales and segment operating income were as follows:

[0000950170-25-063937:notes:57]
|  |  | For the Quarter Ended March 31, 2025 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| Reconciliation of net sales |  |  |  |  |  |  |  |  |  |
| Gross sales |  | $ | 642,639 |  |  | $ | 8,820 |  |  | $ | 651,459 |  |
| Less: Inter-segment sales |  |  | (2,791 | ) |  |  | — |  |  |  | (2,791 | ) |
| Net sales |  |  | 639,848 |  |  |  | 8,820 |  |  |  | 648,668 |  |
| Less: |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  |  | (504,933 | ) |  |  | (4,779 | ) |  |  | (509,712 | ) |
| Operating expenses |  |  | (35,435 | ) |  |  | (2,449 | ) |  |  | (37,884 | ) |
| Segment operating income |  | $ | 99,480 |  |  | $ | 1,592 |  |  |  | 101,072 |  |
| Reconciliation of segment operating income |  |  |  |  |  |  |  |  |  |
| Other (loss) or profit: |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  | (714 | ) |
| Other |  |  |  |  |  |  |  |  | 776 |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  | (8,787 | ) |
| Other corporate expenses |  |  |  |  |  |  |  |  | (32,863 | ) |
| Amortization of definite-lived intangibles (1) |  |  |  |  |  |  |  |  | (9,224 | ) |
| Interest expense |  |  |  |  |  |  |  |  | (11,464 | ) |
| Other, net |  |  |  |  |  |  |  |  | 2,195 |  |
| Income before income taxes |  |  |  |  |  |  |  | $ | 40,991 |  |

[0000950170-25-063937:notes:58]
|  |  | For the Quarter Ended April 1, 2024 |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |
|  |  | (In thousands) |  |
| Reconciliation of net sales |  |  |  |  |  |  |  |  |  |
| Gross sales |  | $ | 563,343 |  |  | $ | 8,333 |  |  | $ | 571,676 |  |
| Less: Inter-segment sales |  |  | (1,502 | ) |  |  | (61 | ) |  |  | (1,563 | ) |
| Net sales |  |  | 561,841 |  |  |  | 8,272 |  |  |  | 570,113 |  |
| Less: |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  |  | (453,180 | ) |  |  | (4,343 | ) |  |  | (457,523 | ) |
| Operating expenses |  |  | (35,281 | ) |  |  | (2,268 | ) |  |  | (37,549 | ) |
| Segment operating income |  | $ | 73,380 |  |  | $ | 1,661 |  |  |  | 75,041 |  |
| Reconciliation of segment operating income |  |  |  |  |  |  |  |  |  |
| Other (loss) or profit: |  |  |  |  |  |  |  |  |  |
| Restructuring |  |  |  |  |  |  |  |  | (3,938 | ) |
| Other |  |  |  |  |  |  |  |  | 864 |  |
| Unallocated amounts: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  |  |  |  |  |  |  | (6,787 | ) |
| Other corporate expenses |  |  |  |  |  |  |  |  | (34,348 | ) |
| Amortization of definite-lived intangibles (1) |  |  |  |  |  |  |  |  | (13,765 | ) |
| Interest expense |  |  |  |  |  |  |  |  | (12,324 | ) |
| Other, net |  |  |  |  |  |  |  |  | 9,326 |  |
| Income before income taxes |  |  |  |  |  |  |  | $ | 14,069 |  |

[0000950170-25-063937:notes:59]
(1)
Amortization of definite-lived intangibles relates to the PCB and RF&S Components reportable segments, but is not reviewed separately by the CODM. For the quarters ended March 31, 2025 and April 1, 2024, amortization expense of $2,335 and $2,336 is included in cost of goods sold for the PCB reportable segment, respectively.

[0000950170-25-063937:notes:60]
Depreciation expense by reportable segment was as follows:

[0000950170-25-063937:notes:61]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2025 |  |  | April 1, 2024 |  |
|  |  | (In thousands) |  |
| PCB |  | $ | 24,691 |  |  | $ | 22,940 |  |
| RF&S Components |  |  | 423 |  |  |  | 466 |  |
| Segment total |  |  | 25,114 |  |  |  | 23,406 |  |
| Corporate |  |  | 1,749 |  |  |  | 1,290 |  |
| Total |  | $ | 26,863 |  |  | $ | 24,696 |  |

[0000950170-25-063937:notes:62]
The Company markets and sells its products in approximately 50 countries. Other than the United States, the Company did not conduct business in any country in which its net sales in that country exceeded 10% of the Company’s total net sales for the quarter ended March 31, 2025. For the quarter ended April 1, 2024, net sales in Taiwan also exceeded 10% of the Company’s total net sales. Net sales are attributed to countries by the invoiced location and were as follows:

[0000950170-25-063937:notes:63]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2025 |  |  | April 1, 2024 |  |
|  |  | (In thousands) |  |
| United States |  | $ | 357,808 |  |  | $ | 300,959 |  |
| Taiwan |  |  | 54,156 |  |  |  | 68,924 |  |
| Other |  |  | 236,704 |  |  |  | 200,230 |  |
| Total net sales |  | $ | 648,668 |  |  | $ | 570,113 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950170-25-063937:notes:64]
[same as prior period, unchanged from 0000950170-24-121449:notes:67]

[0000950170-25-063937:notes:65]
[same as prior period, unchanged from 0000950170-24-121449:notes:68]

[0000950170-25-063937:notes:66]
|  |  | ForeignCurrencyTranslation |  |  | PensionObligation |  |  | Cash FlowHedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 30, 2024 |  | $ | (33,757 | ) |  | $ | 3,612 |  |  | $ | 2,263 |  |  | $ | (27,882 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 44 |  |  |  | — |  |  |  | (1,383 | ) |  |  | (1,339 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | 1,174 |  |  |  | 252 |  |  |  | 1,426 |  |
| Net year to date other comprehensive income (loss) |  |  | 44 |  |  |  | 1,174 |  |  |  | (1,131 | ) |  |  | 87 |  |
| Balance as of March 31, 2025 |  | $ | (33,713 | ) |  | $ | 4,786 |  |  | $ | 1,132 |  |  | $ | (27,795 | ) |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-25-063937:notes:67]
[same as prior period, unchanged from 0000950170-24-121449:notes:70]

[0000950170-25-063937:notes:68]
[same as prior period, unchanged from 0000950170-24-121449:notes:76]

[0000950170-25-063937:notes:69]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2025 |  |  | April 1, 2024 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 2,673 |  |  | $ | 2,029 |  |
| Selling and marketing |  |  | 932 |  |  |  | 868 |  |
| General and administrative |  |  | 4,872 |  |  |  | 3,595 |  |
| Research and development |  |  | 310 |  |  |  | 295 |  |
| Total |  | $ | 8,787 |  |  | $ | 6,787 |  |

[0000950170-25-063937:notes:70]
A summary of total unrecognized compensation costs as of March 31, 2025 was as follows:

[0000950170-25-063937:notes:71]
|  |  | UnrecognizedCompensation Costs |  |  | Remaining Weighted AverageRecognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| Restricted stock units (RSUs) |  | $ | 36,030 |  |  |  | 1.4 |  |
| Performance-based restricted stock units (PRUs) |  |  | 10,505 |  |  |  | 1.4 |  |
| Total |  | $ | 46,535 |  |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-25-063937:notes:72]
[same as prior period, unchanged from 0000950170-24-121449:notes:80]

[0000950170-25-063937:notes:73]
[same as prior period, unchanged from 0000950170-24-121449:notes:81]

[0000950170-25-063937:notes:74]
[same as prior period, unchanged from 0000950170-24-121449:notes:82]

[0000950170-25-063937:notes:75]
|  |  | As of |  |
|  |  | March 31, 2025 |  |  | December 30, 2024 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 1,423 |  |  | $ | 1,423 |  |  | $ | 1,765 |  |  | $ | 1,765 |  |
| Derivative assets, non-current |  |  | — |  |  |  | — |  |  |  | 1,326 |  |  |  | 1,326 |  |
| Derivative liabilities, current |  |  | — |  |  |  | — |  |  |  | 667 |  |  |  | 667 |  |
| Derivative liabilities, non-current |  |  | 136 |  |  |  | 136 |  |  |  | — |  |  |  | — |  |
| Senior Notes due March 2029 |  |  | 496,824 |  |  |  | 461,635 |  |  |  | 496,638 |  |  |  | 464,325 |  |
| Term Loan due May 2030 |  |  | 338,592 |  |  |  | 346,278 |  |  |  | 339,205 |  |  |  | 346,930 |  |
| ABL Revolving Loans |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |  |  | 80,000 |  |
| Other loan |  |  | 2,230 |  |  |  | 2,230 |  |  |  | 2,311 |  |  |  | 2,311 |  |

[0000950170-25-063937:notes:76]
The fair value of the derivative instruments was determined using pricing models developed based on the 1-month Chicago Mercantile Exchange (CME) Term Secured Overnight Financing Rate (SOFR) swap rate and other observable market data, including quoted market prices, as appropriate using Level 2 inputs. The values were adjusted to reflect non-performance risk of both the counterparty and the Company, as necessary.

[0000950170-25-063937:notes:77]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of March 31, 2025 and December 30, 2024, which are considered Level 2 inputs.

[0000950170-25-063937:notes:78]
As of March 31, 2025 and December 30, 2024, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value.

[0000950170-25-063937:notes:79]
The majority of the Company’s non-financial assets and liabilities, which include goodwill, intangible assets, inventories, and property, plant, and equipment, are not required to be carried at fair value on a recurring basis. However, if certain triggering events occur (or as indicated by the annual test in the case of goodwill) such that a non-financial instrument is required to be evaluated for impairment, based upon a comparison of the non-financial instrument’s fair value to its carrying value, an impairment is recorded to reduce the carrying value to the fair value, if the carrying value exceeds the fair value.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-25-063937:notes:80]
(14) Commitments and Contingencies

[0000950170-25-063937:notes:81]
Legal Matters

[0000950170-25-063937:notes:82]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of March 31, 2025 and December 30, 2024 and included as a component of other current liabilities. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0000950170-25-063937:notes:83]
Supplier Finance Program Obligations

[0000950170-25-063937:notes:84]
The Company has agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $10,427 and $17,218 as of March 31, 2025 and December 30, 2024, respectively.


## us-gaap:EarningsPerShareTextBlock

[0000950170-25-063937:notes:85]
(15) Earnings Per Share

[0000950170-25-063937:notes:86]
[same as prior period, unchanged from 0000950170-24-121449:notes:96]

[0000950170-25-063937:notes:87]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2025 |  |  | April 1, 2024 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income |  | $ | 32,178 |  |  | $ | 10,466 |  |
| Basic weighted average shares |  |  | 101,866 |  |  |  | 101,952 |  |
| Dilutive effect of PRUs, RSUs, and stock options |  |  | 2,664 |  |  |  | 2,146 |  |
| Diluted shares |  |  | 104,530 |  |  |  | 104,098 |  |
| Earnings per share: |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 0.32 |  |  | $ | 0.10 |  |
| Diluted earnings per share |  |  | 0.31 |  |  |  | 0.10 |  |

[0000950170-25-063937:notes:88]
For the quarters ended March 31, 2025 and April 1, 2024, PRUs, RSUs, and stock options to purchase 130 and 24 shares of common stock, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met, and for the RSUs and stock options, the total expected proceeds under the treasury stock method or the options’ exercise prices were greater than the average market price of common stock during the applicable quarters and, as a result, the impact would be anti-dilutive.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-25-063937:notes:89]
[same as prior period, unchanged from 0000950170-24-121449:notes:100]

[0000950170-25-063937:notes:90]
On February 8, 2023, the Company announced a consolidation plan, pursuant to which the Company ceased operations at three of its manufacturing facilities during the fiscal year ended January 1, 2024 and consolidated the operations of those facilities into other Company facilities. The three manufacturing facilities were PCB operations located in Anaheim and Santa Clara, California, and Hong Kong. The Company recorded $27,850 of restructuring charges and $6,032 of accelerated depreciation since the February 8, 2023 announcement.

[0000950170-25-063937:notes:91]
In addition to this consolidation plan, the Company recognized employee separation, contract termination, and other costs during the quarters ended March 31, 2025 and April 1, 2024 in connection with other global realignment restructuring efforts. Contract termination and other costs primarily represented plant closure costs.

[0000950170-25-063937:notes:92]
[same as prior period, unchanged from 0000950170-24-121449:notes:103]

[0000950170-25-063937:notes:93]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2025 |  |  | April 1, 2024 |  |
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand Other Costs |  |  | Total |  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| PCB |  | $ | (365 | ) |  | $ | 1,235 |  |  | $ | 870 |  |  | $ | — |  |  | $ | 3,890 |  |  | $ | 3,890 |  |
| Corporate and Other |  |  | (156 | ) |  |  | — |  |  |  | (156 | ) |  |  | — |  |  |  | 48 |  |  |  | 48 |  |
| Total |  | $ | (521 | ) |  | $ | 1,235 |  |  | $ | 714 |  |  | $ | — |  |  | $ | 3,938 |  |  | $ | 3,938 |  |

[0000950170-25-063937:notes:94]
[same as prior period, unchanged from 0000950170-24-121449:notes:106]

[0000950170-25-063937:notes:95]
|  |  | EmployeeSeparation/Severance |  |  | ContractTerminationand Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of December 30, 2024 |  | $ | 3,077 |  |  | $ | 409 |  |  | $ | 3,486 |  |
| (Credited) charged to expense |  |  | (521 | ) |  |  | 1,235 |  |  |  | 714 |  |
| Amount paid |  |  | (1,258 | ) |  |  | (1,443 | ) |  |  | (2,701 | ) |
| Accrued as of March 31, 2025 |  | $ | 1,298 |  |  | $ | 201 |  |  | $ | 1,499 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-25-063937:notes:96]
[same as prior period, unchanged from 0000950170-24-121449:notes:108]

[0000950170-25-063937:notes:97]
On February 26, 2025, Steven Spoto, President of our Integrated Electronics Business Unit, adopted a Rule 10b5-1 trading arrangement that is intended to provide for “eligible sell-to-cover transactions” (as described in Rule 10b5-1(c)(1)(ii)(D)(3) under the Securities Exchange Act of 1934, as amended (Exchange Act)) to satisfy tax withholding obligations arising exclusively from vesting of restricted stock units (RSUs). The number of shares subject to covered RSUs that will be sold to satisfy applicable tax withholding obligations upon vesting is not currently determinable as the number will vary based on the market price of our common stock and the extent to which vesting conditions are satisfied. This sell-to-cover arrangement provides solely for the automatic sale of shares that would otherwise be issuable in respect of a covered RSU in an amount sufficient to satisfy the applicable withholding obligation, with the proceeds of the sale delivered to us in satisfaction of the applicable withholding obligation. The plan for Mr. Spoto is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) and will expire on August 15, 2025 or any earlier date on which all of the contemplated sales have been completed.

[0000950170-25-063937:notes:98]
During the quarter ended March 31, 2025, none of our other directors and/or officers (as defined in Rule 16a-1(f) under the Exchange Act) adopted or terminated a Rule 10b5-1 trading arrangement or a non-Rule 10b5-1 trading arrangement for the purchase or sale of our securities.
