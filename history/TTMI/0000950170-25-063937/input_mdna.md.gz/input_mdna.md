# TTMI MD&A — 0000950170-25-063937


## mdna

[0000950170-25-063937:mdna:1]
[same as prior period, unchanged from 0000950170-24-121449:mdna:1]

[0000950170-25-063937:mdna:2]
[same as prior period, unchanged from 0000950170-24-121449:mdna:2]

[0000950170-25-063937:mdna:3]
This Quarterly Report on Form 10-Q (Report) contains forward-looking statements regarding future events or our future financial and operational performance. Forward-looking statements include statements regarding markets for our products; trends in net sales, gross profits, and estimated expense levels; liquidity and anticipated cash needs and availability; and any statement that contains the words “anticipate,” “believe,” “plan,” “forecast,” “foresee,” “estimate,” “project,” “expect,” “seek,” “target,” “intend,” “goal,” and other similar expressions. The forward-looking statements included in this Report reflect our current expectations and beliefs, and we do not undertake publicly to update or revise these statements, even if experience or future changes make it clear that any projected results expressed in this Report or future quarterly reports to stockholders, press releases, or company statements will not be realized. In addition, the inclusion of any statement in this Report does not constitute an admission by us that the events or circumstances described in such statement are material. Furthermore, we wish to caution and advise readers that these statements are based on assumptions that may not materialize and may involve risks and uncertainties, many of which are beyond our control, that could cause actual events or performance to differ materially from those contained or implied in these forward-looking statements. These risks and uncertainties include the risks identified under the heading "Risk Factors" in our Annual Report on Form 10-K for the fiscal year ended December 30, 2024, as updated by our other filings with the Securities and Exchange Commission (SEC), and described elsewhere in this Report. The following discussion and analysis of our financial condition and results of operations should be read in conjunction with our consolidated condensed financial statements and the related notes and the other financial information included in this Report, as well as the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” set forth in our Annual Report on Form 10-K for the fiscal year ended December 30, 2024, filed with the SEC.

[0000950170-25-063937:mdna:4]
[same as prior period, unchanged from 0000950170-24-121449:mdna:4]

[0000950170-25-063937:mdna:5]
We are a leading global manufacturer of technology solutions including mission systems, radio frequency (RF) components, RF microwave/microelectronic assemblies, and quick-turn and technologically advanced printed circuit boards (PCB). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering, and manufacturing solution to our customers. This solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,400 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive, medical, industrial, and instrumentation, and networking. Our customers include original equipment manufacturers (OEMs), electronic manufacturing services (EMS) providers, original design manufacturers (ODMs), distributors, and government agencies (both domestic and allied foreign governments).

[0000950170-25-063937:mdna:6]
[same as prior period, unchanged from 0000950170-24-121449:mdna:6]

[0000950170-25-063937:mdna:7]
We previously announced the construction of our new advanced technology PCB manufacturing facility in Syracuse, New York. We expect that our new facility will bring advanced technology capability for our domestic high-volume production of ultra‑high‑density interconnect (HDI) PCBs in support of national security requirements. The external construction of our facility is largely complete and we continue to make progress on building the interior. We have equipment orders in place and expect installation to begin in the summer of 2025 with production expected to commence midway through 2026.

[0000950170-25-063937:mdna:8]
[same as prior period, unchanged from 0000950170-24-121449:mdna:11]

[0000950170-25-063937:mdna:9]
Our customers include both OEMs and EMS providers. We sell to OEMs both directly and indirectly through EMS providers. For such indirect sales, we measure customers based on OEM companies as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 56% and 53% of our net sales for the quarters ended March 31, 2025 and April 1, 2024, respectively.

[0000950170-25-063937:mdna:10]
[same as prior period, unchanged from 0000950170-24-121449:mdna:13]

[0000950170-25-063937:mdna:11]
|  |  | For the Quarter Ended |
|  |  | March 31, 2025 |  | April 1, 2024 |
| End Markets (1): |  |  |  |  |  |  |  |  |
| Aerospace and Defense |  |  | 47 |  | % |  |  | 46 |  | % |
| Automotive |  |  | 11 |  |  |  |  | 13 |  |  |
| Data Center Computing |  |  | 21 |  |  |  |  | 21 |  |  |
| Medical/Industrial/Instrumentation |  |  | 13 |  |  |  |  | 14 |  |  |
| Networking |  |  | 8 |  |  |  |  | 6 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |

[0000950170-25-063937:mdna:12]
[same as prior period, unchanged from 0000950170-24-121449:mdna:15]

[0000950170-25-063937:mdna:13]
We derive revenues primarily from the sale of PCBs, engineered systems using customer-supplied engineering and design plans, as well as our long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance, and communications solutions, and RF microwave/microelectronics components, assemblies, and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and engineered systems manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0000950170-25-063937:mdna:14]
[same as prior period, unchanged from 0000950170-24-121449:mdna:17]

[0000950170-25-063937:mdna:15]
Net sales consist of gross sales less an allowance for returns, which typically have been approximately 2% of gross sales. We provide our customers a limited right of return for defective PCBs including components, assemblies, and subsystems. We record an estimate for sales returns and allowances at the time of sale based on historical results and anticipated returns.

[0000950170-25-063937:mdna:16]
[same as prior period, unchanged from 0000950170-24-121449:mdna:19]

[0000950170-25-063937:mdna:17]
Selling and marketing expenses consist primarily of salaries, labor-related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0000950170-25-063937:mdna:18]
[same as prior period, unchanged from 0000950170-24-121449:mdna:21]

[0000950170-25-063937:mdna:19]
Research and development expenses consist primarily of salaries and labor-related benefits paid to our research and development staff, as well as material costs.

[0000950170-25-063937:mdna:20]
[same as prior period, unchanged from 0000950170-24-121449:mdna:23]

[0000950170-25-063937:mdna:21]
[same as prior period, unchanged from 0000950170-24-121449:mdna:24]

[0000950170-25-063937:mdna:22]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended December 30, 2024 for further discussion of critical accounting policies and estimates. There have been no material changes to our critical accounting policies and estimates since December 30, 2024.

[0000950170-25-063937:mdna:23]
CONSOLIDATED OPERATING RESULTS

[0000950170-25-063937:mdna:24]
Selected financial highlights are presented in the table below:

[0000950170-25-063937:mdna:25]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2025 |  |  | April 1, 2024 |  |
|  |  | (In thousands, except margin rates) |  |
| Net sales |  | $ | 648,668 |  |  | $ | 570,113 |  |
| Cost of goods sold |  |  | 517,696 |  |  |  | 466,394 |  |
| Gross profit |  |  | 130,972 |  |  |  | 103,719 |  |
| Gross margin |  |  | 20.2 | % |  |  | 18.2 | % |
| Operating expenses: |  |  |  |  |  |  |
| Selling and marketing |  |  | 21,271 |  |  |  | 20,294 |  |
| General and administrative |  |  | 43,774 |  |  |  | 43,670 |  |
| Research and development |  |  | 8,064 |  |  |  | 7,321 |  |
| Amortization of definite-lived intangibles |  |  | 6,889 |  |  |  | 11,429 |  |
| Restructuring charges |  |  | 714 |  |  |  | 3,938 |  |
| Total operating expenses |  |  | 80,712 |  |  |  | 86,652 |  |
| Operating income |  |  | 50,260 |  |  |  | 17,067 |  |
| Operating margin |  |  | 7.7 | % |  |  | 3.0 | % |
| Total other expense, net |  |  | (9,269 | ) |  |  | (2,998 | ) |
| Income tax provision |  |  | (8,813 | ) |  |  | (3,603 | ) |
| Net income |  | $ | 32,178 |  |  | $ | 10,466 |  |

[0000950170-25-063937:mdna:26]
The following discussion and analysis is for the quarter ended March 31, 2025, compared to the quarter ended April 1, 2024, unless otherwise stated.

[0000950170-25-063937:mdna:27]
[same as prior period, unchanged from 0000950170-24-121449:mdna:31]

[0000950170-25-063937:mdna:28]
Total net sales increased $78.6 million, or 13.8%, to $648.7 million for the quarter ended March 31, 2025, from $570.1 million for the quarter ended April 1, 2024. The primary driver of this increase was strong demand in our aerospace and defense, data center computing, and networking end markets, the latter two being driven by generative artificial intelligence (AI).

[0000950170-25-063937:mdna:29]
Gross Profit and Margin Rate

[0000950170-25-063937:mdna:30]
Gross profit increased $27.3 million to $131.0 million for the quarter ended March 31, 2025, from $103.7 million for the quarter ended April 1, 2024, primarily due to higher sales. Gross margin rate increased to 20.2% for the quarter ended March 31, 2025, from 18.2% for the quarter ended April 1, 2024. This increase was primarily due to higher sales volume for the quarter ended March 31, 2025, particularly in the aerospace and defense, data center computing, and networking end markets, and improved operational execution.

[0000950170-25-063937:mdna:31]
An important factor affecting gross margins is capacity utilization, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume PCB facilities in Asia, as a significant portion of our operating costs are fixed in nature. We believe that our North America utilization figures are not as meaningful as Asia because bottlenecks in these high-mix low-volume facilities tend to occur in areas outside of plating, which is the core process that we use for calculating utilization rates. Capacity utilization for the quarter ended March 31, 2025 in our Asia and North America PCB facilities was 58% and 35%, respectively, compared to 52% and 38%, respectively, for the quarter ended April 1, 2024. The capacity utilization in our Asia PCB facilities improved due to stronger demand in data center computing and networking end markets.

[0000950170-25-063937:mdna:32]
Operating Expenses

[0000950170-25-063937:mdna:33]
Operating expenses decreased $5.9 million to $80.7 million for the quarter ended March 31, 2025, from $86.7 million for the quarter ended April 1, 2024, primarily due to decreases in amortization of definite-lived intangibles of $4.5 million and restructuring charges of $3.2 million related to our global realignment restructuring efforts. See Part I, Item 1, Note 7, Definite-lived Intangibles, and Note 16, Restructuring Charges, respectively, of the Notes to Consolidated Condensed Financial Statements included in this Report for further information. These decreases were partially offset by increases in selling and marketing expenses of $1.0 million, primarily due to higher labor costs and commissions, and research and development expenses of $0.7 million.

[0000950170-25-063937:mdna:34]
Operating Income and Margin Rate

[0000950170-25-063937:mdna:35]
Operating income increased $33.2 million to $50.3 million for the quarter ended March 31, 2025, from $17.1 million for the quarter ended April 1, 2024. Operating margin rate increased to 7.7% for the quarter ended March 31, 2025, from 3.0% for the quarter ended April 1, 2024. The primary drivers of these increases are discussed above in the variance explanations for Gross Profit and Margin Rate and Operating Expenses.

[0000950170-25-063937:mdna:36]
[same as prior period, unchanged from 0000950170-24-121449:mdna:47]

[0000950170-25-063937:mdna:37]
Total other expense, net increased $6.3 million to $9.3 million for the quarter ended March 31, 2025, from $3.0 million for the quarter ended April 1, 2024, primarily as a result of unrealized foreign exchange losses during the quarter ended March 31, 2025. We utilize the Chinese Renminbi (RMB) and Malaysian Ringgit (MYR) at our China and Malaysia facilities, respectively, for employee‑related and other costs of running our operations in foreign countries. There was a $2.2 million unrealized loss from foreign exchange during the quarter ended March 31, 2025, compared to a $4.3 million unrealized gain from foreign exchange during the quarter ended April 1, 2024. This unrealized loss was related to the translation of our China and Malaysia balance sheets from their local currencies into the U.S. dollar functional currency, which experienced devaluation against the RMB and MYR during the quarter ended March 31, 2025 as compared to the quarter ended April 1, 2024.

[0000950170-25-063937:mdna:38]
[same as prior period, unchanged from 0000950170-24-121449:mdna:50]

[0000950170-25-063937:mdna:39]
Income tax expense increased $5.2 million to $8.8 million for the quarter ended March 31, 2025, from $3.6 million for the quarter ended April 1, 2024, primarily due to an increase in income before income taxes.

[0000950170-25-063937:mdna:40]
Our effective tax rate is primarily impacted by the mix of foreign and U.S. income, tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to us as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax liability of $40.6 million and $44.2 million as of March 31, 2025 and April 1, 2024, respectively.

[0000950170-25-063937:mdna:41]
21

[0000950170-25-063937:mdna:42]
SEGMENT OPERATING RESULTS

[0000950170-25-063937:mdna:43]
Basis of Presentation

[0000950170-25-063937:mdna:44]
We have two reportable segments: PCB and RF&S Components. See Part I, Item 1, Note 10, Segment Information, of the Notes to Consolidated Condensed Financial Statements in this Report for further information.

[0000950170-25-063937:mdna:45]
Selected segment financial highlights, with reconciliations to operating income, are presented in the table below:

[0000950170-25-063937:mdna:46]
|  |  | For the Quarter Ended |  |
|  |  | March 31, 2025 |  |  | April 1, 2024 |  |
|  |  | (In thousands, except margin rates) |  |
| Net sales: |  |  |  |  |  |  |
| PCB |  | $ | 639,848 |  |  | $ | 561,841 |  |
| RF&S Components |  |  | 8,820 |  |  |  | 8,272 |  |
| Total |  |  | 648,668 |  |  |  | 570,113 |  |
| Segment operating income: |  |  |  |  |  |  |
| PCB |  |  | 99,480 |  |  |  | 73,380 |  |
| RF&S Components |  |  | 1,592 |  |  |  | 1,661 |  |
| Total |  |  | 101,072 |  |  |  | 75,041 |  |
| Segment operating margin rate: |  |  |  |  |  |  |
| PCB |  |  | 15.5 | % |  |  | 13.1 | % |
| RF&S Components |  |  | 18.0 | % |  |  | 20.1 | % |
| Total |  |  | 15.6 | % |  |  | 13.2 | % |
| Other (loss) or profit: |  |  |  |  |  |  |
| Restructuring |  |  | (714 | ) |  |  | (3,938 | ) |
| Other |  |  | 776 |  |  |  | 864 |  |
| Unallocated amounts: |  |  |  |  |  |  |
| Stock-based compensation |  |  | (8,787 | ) |  |  | (6,787 | ) |
| Other corporate expenses |  |  | (32,863 | ) |  |  | (34,348 | ) |
| Amortization of definite-lived intangibles (1) |  |  | (9,224 | ) |  |  | (13,765 | ) |
| Operating income |  | $ | 50,260 |  |  | $ | 17,067 |  |

[0000950170-25-063937:mdna:47]
(1)
Amortization of definite-lived intangibles relates to the PCB and RF&S Components reportable segments, but is not reviewed separately by the chief operating decision maker (CODM). For the quarters ended March 31, 2025 and April 1, 2024, amortization expense of $2,335 and $2,336, respectively, is included in cost of goods sold for the PCB reportable segment.

[0000950170-25-063937:mdna:48]
Net Sales

[0000950170-25-063937:mdna:49]
Net sales for the PCB reportable segment increased $78.0 million, or 13.9%, to $639.8 million for the quarter ended March 31, 2025, from $561.8 million for the quarter ended April 1, 2024. The primary driver of this increase was strong demand in our aerospace and defense, data center computing, networking, and medical, industrial and instrumentation end markets. The strong demand in our aerospace and defense end market was a result of a positive tailwind in previous defense budgets, our strong strategic program alignment, and key bookings for ongoing franchise programs. The strong demand in our data center computing and networking end markets were driven by generative AI. This increase was partially offset by continued customers’ inventory adjustments and soft demand in our automotive end market. Net sales for the RF&S Components reportable segment increased $0.5 million, or 6.6%, to $8.8 million for the quarter ended March 31, 2025, from $8.3 million for the quarter ended April 1, 2024. The increase in RF&S Components net sales was primarily due to higher demand in our data center computing end market.

[0000950170-25-063937:mdna:50]
Segment Operating Income and Margin Rate

[0000950170-25-063937:mdna:51]
Segment operating income, as reconciled in Part I, Item 1, Note 10, Segment Information, of the Notes to Consolidated Condensed Financial Statements in this Report, and segment operating margin rate (segment operating income divided by segment net sales) are presented in conformity with Accounting Standards Codification (ASC) Topic 280, Segment Reporting. These measures are reported to the CODM, who is the President and Chief Executive Officer, for purposes of making decisions about allocating resources to the segments and assessing their performance. For these reasons, these measures are excluded from the definition of non-GAAP financial measures under the SEC's Regulation G and Item 10(e) of Regulation S-K.

[0000950170-25-063937:mdna:52]
Total segment operating income increased $26.0 million to $101.1 million for the quarter ended March 31, 2025, from $75.0 million for the quarter ended April 1, 2024. Total segment operating margin rate increased to 15.6% for the quarter ended March 31, 2025, from 13.2% for the quarter ended April 1, 2024. Operating income for the PCB reportable segment increased $26.1 million to $99.5 million for the quarter ended March 31, 2025, from $73.4 million for the quarter ended April 1, 2024. Operating margin rate for the PCB reportable segment increased to 15.5% for the quarter ended March 31, 2025, from 13.1% for the quarter ended April 1, 2024.

[0000950170-25-063937:mdna:53]
The primary driver of these increases was higher sales volume, which is discussed above, and improved operational execution. Operating income for the RF&S Components reportable segment remained consistent at $1.6 million for the quarter ended March 31, 2025, compared to $1.7 million for the quarter ended April 1, 2024. Operating margin rate for the RF&S Components reportable segment decreased to 18.0% for the quarter ended March 31, 2025, from 20.1% for the quarter ended April 1, 2024.

[0000950170-25-063937:mdna:54]
[same as prior period, unchanged from 0000950170-24-121449:mdna:54]

[0000950170-25-063937:mdna:55]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our revolving credit facilities. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, repay debt obligations, and repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and repurchasing common stock will be the principal demands on our cash in the future.

[0000950170-25-063937:mdna:56]
Cash flow used in operating activities during the first quarter of 2025 was $10.7 million as compared to cash flow provided by operating activities of $43.9 million in the same period in 2024. The decrease in cash flow from operations was primarily due to the timing of cash collections from customers which drove an increase in working capital.

[0000950170-25-063937:mdna:57]
Net cash used in investing activities during the first quarter of 2025 was $63.2 million, primarily resulting from the use of $63.3 million for purchases of property, plant, and equipment and other assets. Net cash used in investing activities during the first quarter of 2024 was approximately $42.6 million, primarily reflecting the use of $49.3 million for purchases of property, plant, and equipment and other assets, partially offset by $6.7 million of proceeds from the sale of property associated with our Shanghai E-MS subsidiary.

[0000950170-25-063937:mdna:58]
Net cash used in financing activities during the first quarter of 2025 was $18.8 million, reflecting the use of $17.9 million for repurchases of our common stock and $0.9 million for the repayment of long-term debt borrowings. Net cash used in financing activities during the first quarter of 2024 was $11.1 million, reflecting the use of $9.3 million for repurchases of common stock and $1.8 million for the repayment of long-term debt borrowings.

[0000950170-25-063937:mdna:59]
As of March 31, 2025, we had cash and cash equivalents of approximately $411.3 million, of which approximately $151.5 million was held by our foreign subsidiaries, primarily in China, and $195.6 million of available borrowing capacity under our revolving credit facilities. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax expenses not previously accrued for the repatriation of this cash.

[0000950170-25-063937:mdna:60]
Our total 2025 capital expenditures are expected to be in the range of $230.0 million to $250.0 million, of which approximately $66.0 million relate to our construction of our new plant in Syracuse, New York.

[0000950170-25-063937:mdna:61]
[same as prior period, unchanged from 0000950170-24-121449:mdna:61]

[0000950170-25-063937:mdna:62]
On May 3, 2023, our Board of Directors authorized a share repurchase program (2023 Repurchase Program) allowing us to repurchase up to $100.0 million of our common stock from time to time through May 3, 2025. During the quarter ended March 31, 2025, we repurchased approximately 0.7 million shares of our common stock for a total cost of $17.9 million (including commissions). As of March 31, 2025, the remaining amount in value available to be repurchased under the 2023 Repurchase Program was approximately $23.2 million.

[0000950170-25-063937:mdna:63]
[same as prior period, unchanged from 0000950170-24-121449:mdna:63]

[0000950170-25-063937:mdna:64]
As of March 31, 2025, we had $917.6 million of outstanding debt, net of discount and issuance costs, composed of $496.8 million of Senior Notes due 2029, $338.6 million under the Term Loan Facility due 2030 (Term Loan Facility), $80.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL), and $2.2 million of other loans.

[0000950170-25-063937:mdna:65]
Pursuant to the terms of the Senior Notes due 2029 and Term Loan Facility, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and restricted payments. Under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of March 31, 2025, we were in compliance with the covenants under the Senior Notes due 2029, Term Loan Facility, and ABL Revolving Loans.

[0000950170-25-063937:mdna:66]
[same as prior period, unchanged from 0000950170-24-121449:mdna:66]

[0000950170-25-063937:mdna:67]
[same as prior period, unchanged from 0000950170-24-121449:mdna:67]

[0000950170-25-063937:mdna:68]
We have agreements with financial institutions to facilitate payments to certain suppliers. Liabilities associated with these agreements are recorded in accounts payable on the consolidated condensed balance sheets and amounted to $10.4 million and $17.2 million as of March 31, 2025 and December 30, 2024, respectively.

[0000950170-25-063937:mdna:69]
[same as prior period, unchanged from 0000950170-24-121449:mdna:69]

[0000950170-25-063937:mdna:70]
As part of our ongoing operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, derivative liabilities, purchase obligations, and leases. As of March 31, 2025, there were no material changes outside the ordinary course of business since December 30, 2024 to our contractual obligations and commitments and the related cash requirements.

[0000950170-25-063937:mdna:71]
[same as prior period, unchanged from 0000950170-24-121449:mdna:73]

[0000950170-25-063937:mdna:72]
[same as prior period, unchanged from 0000950170-24-121449:mdna:74]

[0000950170-25-063937:mdna:73]
Recently Issued Accounting Standards

[0000950170-25-063937:mdna:74]
[same as prior period, unchanged from 0000950170-24-121449:mdna:76]
