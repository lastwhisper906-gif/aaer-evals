# TTMI MD&A — 0001193125-15-366187


## mdna

[0001193125-15-366187:mdna:1]
Item 2. Management’s Discussion and Analysis of
Financial Condition and Results of Operations

[0001193125-15-366187:mdna:2]
This discussion and analysis should be read in conjunction with
“Management’s Discussion and Analysis of Financial Condition and Results of Operations” set forth in our Annual Report on Form 10-K for the fiscal year ended December 29, 2014, filed with the SEC.

[0001193125-15-366187:mdna:3]
COMPANY OVERVIEW

[0001193125-15-366187:mdna:4]
We are a major global printed circuit board (PCB) manufacturer, focusing on quick-turn and technologically advanced PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions). We focus on
providing time-to-market and advanced technology products and offer a one-stop manufacturing solution to our customers from engineering support to prototype development through final volume production. This one-stop manufacturing solution allows us
to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,500 customers
in various markets throughout the world, including manufacturers of networking/communications infrastructure products, smartphones and touchscreen tablets, as well as the aerospace and defense, automotive, high-end computing, and industrial/medical
industries. Our customers include both original equipment manufacturers and electronic manufacturing services providers.

[0001193125-15-366187:mdna:5]
RECENT
DEVELOPMENTS

[0001193125-15-366187:mdna:6]
On May 31, 2015, we completed the acquisition of Viasystems Group, Inc. (Viasystems),
for total consideration of $248.8 million in cash and 15.1 million shares of TTM common stock. Additionally, in connection with the completion of the acquisition, we assumed and refinanced Viasystems’ debt, which was approximately $669.0
million. Viasystems was a worldwide provider of complex multi-layer rigid, flexible, and rigid-flex PCBs and E-M Solutions. Viasystems’ products were found in a wide variety of commercial products, including automotive engine controls, hybrid
converters, automotive electronics for navigation, safety, and entertainment, telecommunications switching equipment, data networking equipment, computer storage equipment, semiconductor test equipment, wind and solar energy applications, off-shore
drilling equipment, communications applications, flight control systems, and complex industrial, medical, and other technical instruments. Viasystems’ E-M Solutions services can be bundled with its PCBs to provide an integrated solution to
customers. Viasystems operated 15 manufacturing facilities worldwide: eight in the United States, five in the People’s Republic of China (China), one each in Canada and Mexico. Viasystems served a diversified customer base of over 1,000
customers in various markets throughout the world.

[0001193125-15-366187:mdna:7]
On September 29, 2015, we announced a consolidation plan
that will result in the closure of our facilities in Cleveland, Ohio, Milpitas, California and Juarez, Mexico (the Plan). The Plan is part of our integration strategy to improve total plant utilization, operational performance and customer focus
following its recent acquisition of Viasystems, Inc. In accordance with the Plan, we will combine our Cleveland and Milpitas facilities into our North Jackson, Ohio and Silicon Valley, California facilities, respectively, and close our Juarez
facility. As a result, during the quarter and three quarters ended September 28, 2015, we recognized restructuring charges of $1.9 million in our E-M Solutions segment, which is included in other accrued expenses in the September 28, 2015
consolidated condensed balance sheet. These charges primarily represent severance expense associated with the closure of the Juarez facility and are expected to be paid out by June 2016. Severance charges related to the Cleveland, Ohio and Milpitas,
California facility closures are expected to be recorded during the fourth quarter of 2015, once the plans for certain employee transfers to other facilities is finalized. We estimate that we will incur total charges of approximately $15.0 million
to $20.0 million related to these closures. Additionally, our fourth quarter 2015 financial results will be negatively impacted as a result of the planned closure of these facilities.

[0001193125-15-366187:mdna:8]
[same as prior period, unchanged from 0001193125-15-284892:mdna:20]

[0001193125-15-366187:mdna:9]
FINANCIAL OVERVIEW

[0001193125-15-366187:mdna:10]
For the first three quarters of 2015, we experienced higher demand in our Cellular Phone end market compared to that of
the same period in 2014. This increase in demand resulted in higher capacity utilization at our advanced technology plants resulting in higher net sales and gross margins. Additionally, we had improved operating efficiencies at certain of our North
American plants.

[0001193125-15-366187:mdna:11]
While our customers include both OEM and EMS providers, we measure customers based on OEM
companies, as they are the ultimate end customers. Sales to our 10 largest customers accounted for 45% and 58% of our net sales for the quarters ended September 28, 2015 and September 29, 2014, respectively, and 51% and 55% for the three
quarters ended September 28, 2015 and September 29, 2014, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001193125-15-366187:mdna:12]
[same as prior period, unchanged from 0001193125-15-284892:mdna:8]

[0001193125-15-366187:mdna:13]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
| End Markets(1) |  | September 28,2015 |  |  | September 29,2014 |  |  | September 28,2015 |  |  | September 29,2014 |  |
| Aerospace/Defense |  |  | 14 | % |  |  | 15 | % |  |  | 15 | % |  |  | 17 | % |
| Automotive(3) |  |  | 17 |  |  |  | 3 |  |  |  | 12 |  |  |  | 2 |  |
| Cellular Phone(2) |  |  | 16 |  |  |  | 25 |  |  |  | 22 |  |  |  | 18 |  |
| Computing/Storage/Peripherals(2) |  |  | 12 |  |  |  | 13 |  |  |  | 11 |  |  |  | 15 |  |
| Medical/Industrial/Instrumentation |  |  | 14 |  |  |  | 9 |  |  |  | 12 |  |  |  | 10 |  |
| Networking/Communications |  |  | 25 |  |  |  | 32 |  |  |  | 26 |  |  |  | 35 |  |
| Other(2)(3) |  |  | 2 |  |  |  | 3 |  |  |  | 2 |  |  |  | 3 |  |
| Total |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001193125-15-366187:mdna:14]
[same as prior period, unchanged from 0001193125-15-284892:mdna:10]

[0001193125-15-366187:mdna:15]
[same as prior period, unchanged from 0001193125-15-284892:mdna:11]

[0001193125-15-366187:mdna:16]
| (3) | Automotive has been reclassified from Other end market for the quarter and three quarters ended September 29, 2014. |

[0001193125-15-366187:mdna:17]
We derive revenues primarily from the sale of PCBs and backplane assemblies using
customer-supplied engineering and design plans. We recognize revenues when persuasive evidence of a sales arrangement exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is reasonably
assured — generally when products are shipped to the customer. Net sales consist of gross sales less an allowance for returns, which typically have been less than 3% of gross sales. We provide our customers a limited right of return for
defective PCBs and backplane assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results. Purchase orders may be cancelled prior to shipment. We generally charge customers a fee, based on the
percentage completed, if an order is cancelled once it has entered production.

[0001193125-15-366187:mdna:18]
Cost of goods sold consists of
materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component
of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. We generally do not participate in any significant long-term contracts with suppliers, and we believe there are a
number of potential suppliers for the raw materials we use.

[0001193125-15-366187:mdna:19]
Selling and marketing expenses consist primarily
of salaries, labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0001193125-15-366187:mdna:20]
General and administrative costs primarily include the salaries for executive, finance, accounting, information
technology, facilities and human resources personnel, as well as insurance expenses, expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001193125-15-366187:mdna:21]
[same as prior period, unchanged from 0001193125-15-284892:mdna:17]

[0001193125-15-366187:mdna:22]
Our consolidated condensed financial statements included in this report have been prepared in accordance with U.S. GAAP. The preparation of these financial statements requires management to make estimates
and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001193125-15-366187:mdna:23]
See Item 7, Management’s Discussion and Analysis of Financial
Condition and Results of Operation, in our Annual Report on Form 10-K for the fiscal year ended December 29, 2014 for further discussion of critical accounting policies and estimates. There were no material changes to our critical
accounting policies and estimates since December 29, 2014.

[0001193125-15-366187:mdna:24]
[same as prior period, unchanged from 0001193125-15-284892:mdna:21]

[0001193125-15-366187:mdna:25]
The quarter and three quarters ended September 29, 2014 do not include the results of operations from our acquisition
of Viasystems, as the acquisition occurred on May 31, 2015. The acquisition has had and will continue to have a significant effect on our operations as discussed in the various comparisons noted below:

[0001193125-15-366187:mdna:26]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 28, 2015 |  |  | September 29, 2014 |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 86.3 |  |  |  | 85.8 |  |  |  | 85.8 |  |  |  | 86.5 |  |
| Gross profit |  |  | 13.7 |  |  |  | 14.2 |  |  |  | 14.2 |  |  |  | 13.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.7 |  |  |  | 2.6 |  |  |  | 2.8 |  |  |  | 2.9 |  |
| General and administrative |  |  | 6.1 |  |  |  | 7.5 |  |  |  | 8.8 |  |  |  | 7.6 |  |
| Amortization of definite-lived intangibles |  |  | 1.0 |  |  |  | 0.5 |  |  |  | 0.9 |  |  |  | 0.7 |  |
| Restructuring charge |  |  | 0.3 |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |
| Impairment of long-lived assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.2 |  |
| Gain on sale of asset |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |
| Total operating expenses |  |  | 10.1 |  |  |  | 10.6 |  |  |  | 12.5 |  |  |  | 11.4 |  |
| Operating income |  |  | 3.6 |  |  |  | 3.6 |  |  |  | 1.7 |  |  |  | 2.1 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (3.2 | ) |  |  | (1.7 | ) |  |  | (2.8 | ) |  |  | (1.9 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |
| Other, net |  |  | 0.6 |  |  |  | 0.4 |  |  |  | 0.4 |  |  |  | (0.2 | ) |
| Total other expense, net |  |  | (2.6 | ) |  |  | (1.3 | ) |  |  | (2.5 | ) |  |  | (2.1 | ) |
| Income (loss) before income taxes |  |  | 1.0 |  |  |  | 2.3 |  |  |  | (0.8 | ) |  |  | — |  |
| Income tax (provision) benefit |  |  | (1.3 | ) |  |  | (0.1 | ) |  |  | (1.7 | ) |  |  | 0.1 |  |
| Net (loss) income |  |  | (0.3 | ) |  |  | 2.2 |  |  |  | (2.5 | ) |  |  | 0.1 |  |
| Less: Net income attributable to noncontrolling interest |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net (loss) income attributable to TTM Technologies, Inc. stockholders |  |  | (0.3 | )% |  |  | 2.2 | % |  |  | (2.5 | )% |  |  | 0.1 | % |

[0001193125-15-366187:mdna:27]
As a result of the May 31, 2015 acquisition of Viasystems and the ongoing
integration activities, we have reassessed our reportable operating segments and determined that we have two reportable operating segments: PCB and E-M Solutions. This determination was made based on the criteria of earning revenues and incurring
expenses, our organizational structure which has segment managers who report to the chief operating decision maker and discrete financial information, and the aggregation of similar operating segments into reportable operating segments.

[0001193125-15-366187:mdna:28]
The following table compares net sales by reportable segment for the quarter and three quarters ended September 28,
2015 and September 29, 2014:

[0001193125-15-366187:mdna:29]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 28, 2015 |  |  | September 29, 2014 |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 604,771 |  |  | $ | 328,542 |  |  | $ | 1,332,996 |  |  | $ | 879,200 |  |
| E-M Solutions |  |  | 49,658 |  |  |  | 17,368 |  |  |  | 97,634 |  |  |  | 57,472 |  |
| Total sales |  |  | 654,429 |  |  |  | 345,910 |  |  |  | 1,430,630 |  |  |  | 936,672 |  |
| Inter-segment sales |  |  | (2,424 | ) |  |  | (635 | ) |  |  | (4,016 | ) |  |  | (1,867 | ) |
| Total net sales |  | $ | 652,005 |  |  | $ | 345,275 |  |  | $ | 1,426,614 |  |  | $ | 934,805 |  |

[0001193125-15-366187:mdna:30]
28

[0001193125-15-366187:mdna:31]
[same as prior period, unchanged from 0001193125-15-284892:mdna:28]

[0001193125-15-366187:mdna:32]
Net sales increased $306.7 million, or 88.8%, from $345.3 million for the third quarter of 2014 to $652.0 million for the
third quarter of 2015. Net sales for the PCB operating segment, excluding inter-segment sales, increased $274.4 million, or 83.7%, from $328.0 million in the third quarter of 2014 to $602.4 million in the third quarter of 2015. This
increase is primarily due to the acquisition of Viasystems, which accounted for $251.7 million in PCB sales in the third quarter of 2015. Additionally, the increase in PCB sales is due to higher demand in our Cellular Phone and Computing / Storage /
Peripherals end markets, partially offset with lower demand in our Networking/Communications end market. These changes, including the sales from Viasystems, resulted in a 177.6% increase in PCB shipments from the third quarter of 2014 and the
average PCB selling price decreased 40.7%, which was driven by a product mix shift resulting from the acquisition. Net sales for the E-M Solutions operating segment, excluding inter-segment sales, increased $32.3 million, from $17.3 million in the
third quarter of 2014 to $49.6 million in the third quarter of 2015. This increase is due to the acquisition of Viasystems, which accounted for $31.5 million in E-M Solutions sales in the third quarter of 2015.

[0001193125-15-366187:mdna:33]
Net sales increased $491.8 million, or 52.6%, from $934.8 million for the first three quarters of 2014 to $1,426.6
million for the first three quarters of 2015. Net sales for the PCB operating segment, excluding inter-segment sales, increased $451.7 million, or 51.5%, from $877.6 million for the first three quarters of 2014 to $1,329.3 million for the
first three quarters of 2015. This increase is primarily due to the acquisition of Viasystems, which accounted for $334.9 million in PCB sales in the first three quarters of 2015. Additionally, PCB sales increased due to higher demand in our
Cellular Phone end market, partially offset with lower demand in our Networking/Communications end markets. These changes resulted in a 93.4% increase in PCB shipments from the first three quarters of 2014 and a decline in the average PCB selling
price of 27.5%, which was driven by a product mix shift resulting from the acquisition. Net sales for the E-M Solutions operating segment, excluding inter-segment sales, increased $40.2 million, from $57.2 million for the first three quarters of
2014 to $97.4 million for the first three quarters of 2015. This increase is due to the acquisition of Viasystems, which accounted for $41.5 million in E-M Solutions sales in the first three quarters of 2015.

[0001193125-15-366187:mdna:34]
[same as prior period, unchanged from 0001193125-15-284892:mdna:31]

[0001193125-15-366187:mdna:35]
Gross margin decreased from 14.2% for the third quarter of 2014 to 13.7% for the third quarter of 2015 and increased from 13.5% for the first three quarters of 2014 to 14.2% for first three quarters of
2015. Gross margin for the PCB operating segment decreased from 14.5% for the third quarter of 2014 to 14.3% for the third quarter of 2015 primarily due to the $6.5 million inventory markup associated with the acquisition of Viasystems.
Additionally, gross margin for the PCB operating segment increased from 13.7% in the first three quarters of 2014 to 14.8% for the first three quarters of 2015 primarily due to higher utilization at our advanced technology plants partially offset by
the $13.3 million inventory markup associated with the acquisition of Viasystems in the first three quarters of 2015. Gross margin for the E-M Solutions segment decreased from 8.4% for the third quarter of 2014 to 5.8% for the third quarter of 2015
and from 9.8% for the first three quarters of 2014 to 5.7% for the first three quarters of 2015, primarily due to the acquisition of Viasystems in both the third quarter and first three quarters of 2015.

[0001193125-15-366187:mdna:36]
[same as prior period, unchanged from 0001193125-15-284892:mdna:33]

[0001193125-15-366187:mdna:37]
Selling and marketing expenses increased $8.6 million, from $9.0 million for the third quarter of 2014 to $17.6 million for the third quarter of 2015. Selling and marketing expenses increased $12.4
million, from $27.0 million for the first three quarters of 2014 to $39.4 million for the first three quarters of 2015. The increase in expense for the quarter and three quarters of 2015 primarily relates to the acquisition of Viasystems on
May 31, 2015. As a percentage of net sales, selling and marketing expenses were 2.6% for the third quarter of 2014, as compared to 2.7% for the third quarter of 2015 and 2.9% for the first three quarters of 2014, as compared to 2.8% for the
first three quarters of 2015. The decrease in selling and marketing expense as a percentage of net sales for the periods noted is primarily due to higher net sales.

[0001193125-15-366187:mdna:38]
[same as prior period, unchanged from 0001193125-15-284892:mdna:35]

[0001193125-15-366187:mdna:39]
General and
administrative expenses increased $13.7 million from $25.8 million, or 7.5% of net sales, for the third quarter of 2014 to $39.5 million, or 6.1% of net sales, for the third quarter of 2015. General and administrative expenses increased
$55.0 million from $71.0 million, or 7.6% of net sales, for the first three quarters of 2014 to $126.0 million, or 8.8% of net sales, for the first three quarters of 2015. The increase in expense primarily relates to the $2.1 million and $32.9
million of acquisition-related costs for the third quarter and first three quarters of 2015, respectively, related to the acquisition of Viasystems on May 31, 2015, and four months of general and administrative expense incurred by Viasystems
post acquisition through September 28, 2015.

[0001193125-15-366187:mdna:40]
[same as prior period, unchanged from 0001193125-15-284892:mdna:37]

[0001193125-15-366187:mdna:41]
Other expense, net increased $12.7 million from $4.3 million for the third quarter of 2014 to $17.0 million for the third
quarter of 2015. The increase in other expense, net was primarily due to an increase in interest expense of $15.0 million related to a new long-term borrowing and a revolver loan totaling $1,030.0 million at a weighted average interest rate of 5.7%
related to the acquisition of Viasystems on May 31, 2015, offset by higher foreign currency transaction gains in the third quarter of 2015.

[0001193125-15-366187:mdna:42]
Other expense, net increased $15.9 million from $20.2 million for the first three quarters of 2014 to $36.1 million for first three quarters of 2015. The increase in other expense, net was primarily due
to an increase in interest expense related to a new long-term borrowing and a revolver loan totaling $1,030.0 million at a weighted average interest rate of 5.7% related to the acquisition of Viasystems on May 31, 2015 combined with a $0.8
million extinguishment of debt charge associated with repayment of existing long-term debt on May 31, 2015. The increase in other expense, net was partially offset by $3.2 million foreign currency transaction gains for the first three quarters
of 2015 compared to $2.1 million foreign currency transaction losses for the first three quarters of 2014 resulting primarily from the rapid depreciation of the Chinese RMB against the U.S. Dollar in 2014.

[0001193125-15-366187:mdna:43]
[same as prior period, unchanged from 0001193125-15-284892:mdna:40]

[0001193125-15-366187:mdna:44]
The provision for income taxes increased by $8.3 million from $0.4 million tax expense for the third quarter of 2014 to $8.7 million for the third quarter of 2015. The provision for income taxes
increased $25.0 million from $1.0 million of tax benefit for the first three quarters of 2014 to $24.0 million of tax expense for the first three quarters of 2015. The increase in income tax expense for the first three quarters of 2015 is primarily
due to the provision of a full valuation allowance on existing U.S. deferred tax assets, partially offset by the reversal of deferred tax liabilities related to the our decision to indefinitely reinvest the foreign earnings attributable to our
backplane assembly facility in Shanghai, China. Further, the income tax expense in 2015 is higher due to inclusion of Viasystems earnings from foreign subsidiaries in the second and third quarter of 2015.

[0001193125-15-366187:mdna:45]
Our effective tax rate is primarily impacted by the favorable tax rates in China and Hong Kong, generation of other
credits and deductions, and certain non-deductible items. U.S. and certain foreign losses generated are not realizable, and thus no income tax benefit has been recognized on these losses.

[0001193125-15-366187:mdna:46]
[same as prior period, unchanged from 0001193125-15-284892:mdna:43]

[0001193125-15-366187:mdna:47]
Our principal
sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, and term and revolving debt. Our principal uses of cash have been to acquire Viasystems, finance capital expenditures, meet debt service
requirements, fund working capital requirements, and refinance existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal
demands on our cash in the future.

[0001193125-15-366187:mdna:48]
Cash flow provided by operating activities during the first three quarters
of 2015 was $97.6 million as compared to $77.4 million in the same period in 2014. The improved cash flow was the result of stronger operational performance. As of September 28, 2015, we had net working capital of approximately $320.7 million
compared to $302.1 million as of December 29, 2014. For the third quarter of 2015, cash cycle days were 52 days and improved over the previous quarter by 1 day.

[0001193125-15-366187:mdna:49]
Net cash used in investing activities was approximately $226.6 million for the first three quarters of 2015 primarily
reflecting the acquisition of Viasystems, net of cash acquired, in the amount of $169.2 million, and purchases of property, plant and equipment, net of proceeds from sale of property, plant and equipment and asset held for sale of $55.5 million.

[0001193125-15-366187:mdna:50]
Net cash used in financing activities was approximately $3.3 million for the first three quarters of 2015
reflecting proceeds from long-term debt and a revolving loan totaling $1,030.0 million, offset by the repayment of $966.5 million of debt, including the assumed long-term debt in the acquisition of $669.0 million, payoff of the 2012 credit agreement
term loan, the payoff of the remaining 2015 convertible senior notes, and payment of debt issuance costs and original issue discount of $67.4 million associated with the new long-term borrowing and revolver loan totaling $1,030.0 million.

[0001193125-15-366187:mdna:51]
As of September 28, 2015, we had unrestricted cash and cash equivalents of approximately $144.7 million,
of which approximately $110.1 million was held by our foreign subsidiaries. Of the cash and cash equivalents held by our foreign subsidiaries as of September 28, 2015, $109.0 million was located in Asia and $1.1 million was located in
Europe and other locations. Cash and cash equivalents held by our foreign locations are expected to be used in local operations.

[0001193125-15-366187:mdna:52]
Our 2015 capital expenditure plan is expected to total approximately $120
million. The expenditures will fund capital equipment purchases to increase production capacity, especially for advanced technology manufacturing, comply with changing environmental regulations, replace aging equipment, and expand our technological
capabilities. While our cash capital expenditures are expected to be approximately $120 million in 2015, we expect new capital expenditure purchases in 2015 to approximate $80 million.

[0001193125-15-366187:mdna:53]
[same as prior period, unchanged from 0001193125-15-284892:mdna:48]

[0001193125-15-366187:mdna:54]
On May 31, 2015, in
conjunction with the acquisition of Viasystems, we entered into a $950.0 million Term Loan Credit Agreement (Term Loan). Additionally, we entered into a $150.0 million U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and a $150.0 million Asia
Asset-Based Lending Credit agreement (Asia ABL). We drew $80.0 million of the U.S. ABL at the closing of the acquisition of Viasystems.

[0001193125-15-366187:mdna:55]
The Term Loan Credit agreement was issued at a discount at 96.5% and bears interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus an applicable interest margin of 5.0%. At September 28,
2015, the weighted average interest rate on the outstanding borrowings under the Term Loan was 6.0%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan will mature on May 31, 2021. The Term
Loan is secured by a significant amount of the assets of the Company and its domestic subsidiaries and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to our convertible senior
notes. See Convertible Senior Notes due 2020 below.

[0001193125-15-366187:mdna:56]
The U.S. ABL consists of three tranches comprised of a
revolving credit facility of up to $150.0 million, a letter of credit facility of up to $75.0 million, and swingline loans of up to $30.0 million, provided that at no time may amounts outstanding under the tranches exceed in aggregate $150.0 million
or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at a floating rate of LIBOR plus a margin of 175 basis points. At
September 28, 2015, the weighted average interest rate on the outstanding borrowings under the U.S. ABL was 1.9%. Beginning in 2016, the applicable margin can vary based on the remaining availability of the facility, from 150 to 200 basis
points for LIBOR-based loans. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and inventories as well as by a second position against a significant amount of the
assets of the Company and its domestic subsidiaries and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to our convertible senior notes. See Convertible Senior Notes due 2020
below. At September 28, 2015, $80.0 million of the U.S. ABL was outstanding and classified as a current liability.

[0001193125-15-366187:mdna:57]
The Company and its domestic subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Term Loan and U.S. ABL related obligations.

[0001193125-15-366187:mdna:58]
The Asia ABL consists of two tranches comprised of a revolving credit facility of up to $150.0 million and a letter of
credit facility of up to $100.0 million provided that at no time may amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as
defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 175 basis points. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on
May 22, 2020. Loans made under the Asia ABL are secured by a portion of our Asia Pacific cash and receivables and are structurally senior to our domestic obligations, including our convertible senior notes. See Convertible Senior Notes due 2020
below. Our Asia Pacific subsidiary and certain of its subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Asia ABL related obligations. At September 28, 2015, none of the Asia ABL was outstanding.

[0001193125-15-366187:mdna:59]
We are required to make scheduled payments of the outstanding Term Loan balance on a quarterly basis
beginning October 1, 2015. On October 1, 2015, the first scheduled principal payment of $2.4 million was made. Based on certain parameters defined in the Term Loan agreement, the Company may be required to make an additional principal
payment on an annual basis. Any other outstanding balances under the Term Loan are due at the maturity date of May 31, 2021. Borrowings under the Term Loan are subject to various financial and operating covenants including maintaining a maximum
total leverage ratio. Under the occurrence of certain events, the U.S. ABL and the Asia ABL are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. At September 28, 2015, we were
in compliance with the covenants under the Term Loan, the U.S. ABL and the Asia ABL.

[0001193125-15-366187:mdna:60]
We are also required to
pay a commitment fee of 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The U.S. ABL commitment fee may vary from 0.25% to 0.375% based on utilization levels. The Company incurred total commitment fees related to unused
borrowing availability of $0.2 million and $0.6 million for the quarter and three quarters ended September 28, 2015, respectively. As of September 28, 2015, the outstanding amount of the Term Loan was $950.0 million, of which $9.5 million
is due for repayment within one year and is included as short-term debt, with the remaining $940.5 million included as long-term debt. Additionally, $80.0 million of the U.S. ABL and none of the Asia ABL was outstanding as of September 28,
2015. Available borrowing capacity under the U.S. ABL and Asia ABL was $65.4 million and $142.2 million, which includes $4.6 million and $7.8 million, respectively, of outstanding letters of credit mentioned below at September 28, 2015.

[0001193125-15-366187:mdna:61]
[same as prior period, unchanged from 0001193125-15-284892:mdna:56]

[0001193125-15-366187:mdna:62]
We have up to $75.0 million and $100.0 million Letters of Credit Facilities available under the U.S. ABL and the Asia ABL,
respectively. As of September 28, 2015, letters of credit in the amount of $4.6 million were outstanding under the U.S. ABL and $7.8 million were outstanding under the Asia ABL. We have other standby letters of credit outstanding in the amount
of $4.8 million which expire between October 4, 2015 and May 16, 2016. These other standby letters of credit are securitized by cash collateral. As such, we have recorded such cash as restricted on the consolidated condensed balance sheet
as of September 28, 2015.

[0001193125-15-366187:mdna:63]
[same as prior period, unchanged from 0001193125-15-284892:mdna:58]

[0001193125-15-366187:mdna:64]
We are party to a revolving loan credit facility with a lender in China. Under this arrangement, the lender has made
available to us approximately $36.1 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this
arrangement expires in December 2015. As of September 28, 2015, the Chinese Revolver had not been drawn upon.

[0001193125-15-366187:mdna:65]
Convertible Senior
Notes due 2020

[0001193125-15-366187:mdna:66]
We issued 1.75% convertible senior notes due December 15, 2020, in a public
offering for an aggregate principal amount of $250.0 million. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The
convertible senior notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest
expense over the term of the convertible senior notes.

[0001193125-15-366187:mdna:67]
In connection with the issuance of the convertible
senior notes due 2020, we entered into a convertible note hedge and warrant transaction (the Call Spread Transaction), with respect to our common stock. The convertible note hedge consists of our option to purchase up to 28.0 million common
stock shares at a price of $9.64 per share. The hedge expires on December 15, 2020 and can only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, we sold warrants to purchase
28.0 million shares of our common stock at a price of $14.26 per share. The warrants expire ratably from March 2021 through January 2022. The Call Spread Transaction has no effect on the terms of the convertible senior notes due 2020 and
reduces potential dilution by effectively increasing the conversion price of the convertible senior notes due 2020 to $14.26 per share of our common stock.

[0001193125-15-366187:mdna:68]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently
anticipated capital expenditure, debt service, and working capital needs for the next 12 months.

[0001193125-15-366187:mdna:69]
[same as prior period, unchanged from 0001193125-15-284892:mdna:64]

[0001193125-15-366187:mdna:70]
The following table provides information on our contractual obligations as of September 28, 2015:

[0001193125-15-366187:mdna:71]
|  |  | Total |  |  | Less Than1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After5 Years |  |
|  |  | (In thousands) |  |
| Contractual Obligations(1) |  |  |  |
| Long-term debt obligations |  | $ | 1,030,000 |  |  | $ | 89,500 |  |  | $ | 85,500 |  |  | $ | 95,000 |  |  | $ | 760,000 |  |
| Convertible debt obligations |  |  | 250,000 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 250,000 |  |
| Interest on debt obligations |  |  | 324,377 |  |  |  | 53,874 |  |  |  | 118,924 |  |  |  | 107,859 |  |  |  | 43,720 |  |
| Foreign currency forward contract liabilities |  |  | 42 |  |  |  | 42 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Equipment payables |  |  | 18,259 |  |  |  | 18,259 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 67,901 |  |  |  | 67,851 |  |  |  | 50 |  |  |  | — |  |  |  | — |  |
| Operating lease commitments |  |  | 30,225 |  |  |  | 9,323 |  |  |  | 10,214 |  |  |  | 5,288 |  |  |  | 5,400 |  |
| Total contractual obligations |  | $ | 1,720,804 |  |  | $ | 238,849 |  |  | $ | 214,688 |  |  | $ | 208,147 |  |  | $ | 1,059,120 |  |

[0001193125-15-366187:mdna:72]
| (1) | Unrecognized uncertain tax benefits of $34.0 million are not included in the table above as we have not determined when the amount will be paid. |

[0001193125-15-366187:mdna:73]
32

[0001193125-15-366187:mdna:74]
[same as prior period, unchanged from 0001193125-15-284892:mdna:68]

[0001193125-15-366187:mdna:75]
[same as prior period, unchanged from 0001193125-15-284892:mdna:69]

[0001193125-15-366187:mdna:76]
[same as prior period, unchanged from 0001193125-15-284892:mdna:70]

[0001193125-15-366187:mdna:77]
[same as prior period, unchanged from 0001193125-15-284892:mdna:71]
