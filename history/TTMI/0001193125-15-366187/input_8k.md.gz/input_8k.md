# TTMI 8-K — 0001171843-15-005766 filed 2015-10-28

## item codes, every 8-K on or before 2015-11-04

- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2015-11-04

- none on or before 2015-11-04

## item 2.02 — earnings release, exhibit 99.1

[0001171843-15-005766:8k_2_02:1]
EX-99
2
newsrelease.htm
PRESS RELEASE

[0001171843-15-005766:8k_2_02:2]
TTM Technologies, Inc. Reports Third Quarter 2015 Results
EXHIBIT 99.1

[0001171843-15-005766:8k_2_02:3]
TTM Technologies, Inc. Reports Third Quarter 2015 Results

[0001171843-15-005766:8k_2_02:4]
COSTA MESA, Calif., Oct. 28, 2015 (GLOBE NEWSWIRE) -- TTM Technologies, Inc. (Nasdaq:TTMI), a major global printed circuit board ("PCB") manufacturer, today reported results for the third quarter 2015, which ended September 28, 2015. Results for the period reflect the first full quarter of consolidated results from the acquisition of Viasystems Group, Inc. ("Viasystems"), completed on May 31, 2015.

[0001171843-15-005766:8k_2_02:5]
Third Quarter 2015 Highlights

[0001171843-15-005766:8k_2_02:6]
Net sales were $652.0 million

[0001171843-15-005766:8k_2_02:7]
GAAP net loss attributable to stockholders was $2.2 million, or $0.02 per share

[0001171843-15-005766:8k_2_02:8]
Non-GAAP net income attributable to stockholders was $23.8 million, or $0.24 per diluted share

[0001171843-15-005766:8k_2_02:9]
Third Quarter 2015 Financial Results

[0001171843-15-005766:8k_2_02:10]
Net sales for the third quarter of 2015 were $652.0 million compared to $445.4 million in the second quarter of 2015 and $345.3 million in the third quarter of 2014.

[0001171843-15-005766:8k_2_02:11]
GAAP operating income for the third quarter of 2015 was $23.6 million compared to an operating loss of $7.1 million in the second quarter of 2015 and operating income of $12.3 million in the third quarter of 2014.

[0001171843-15-005766:8k_2_02:12]
GAAP net loss attributable to stockholders for the third quarter of 2015 was $2.2 million, or $0.02 per share. This compares to GAAP net loss of $36.6 million, or $0.41 per share, in the second quarter of 2015 and GAAP net income of $7.7 million, or $0.09 per diluted share, in the third quarter of 2014. The GAAP results were negatively impacted by approximately $12.3 million of expenses related to the acquisition and integration of Viasystems.

[0001171843-15-005766:8k_2_02:13]
On a non-GAAP basis, net income attributable to stockholders for the third quarter of 2015 was $23.8 million, or $0.24 per diluted share. This compares to non-GAAP net income of $14.9 million, or $0.17 per diluted share, for the second quarter of 2015 and $11.0 million, or $0.13 per diluted share, for the third quarter of 2014.

[0001171843-15-005766:8k_2_02:14]
Adjusted EBITDA for the third quarter of 2015 was $87.6 million, or 13.4 percent of net sales, compared to adjusted EBITDA of $59.7 million, or 13.4 percent of net sales, for the second quarter of 2015 and $43.6 million, or 12.6 percent of net sales, for the third quarter of 2014.

[0001171843-15-005766:8k_2_02:15]
"Our strong third quarter operating performance included the first full quarter of contribution from the Viasystems acquisition," said Tom Edman, CEO of TTM. "Revenue was within our guidance range and non-GAAP earnings exceeded expectations. Demand in the aerospace and defense and mobility end markets, in particular, remained strong throughout the quarter."

[0001171843-15-005766:8k_2_02:16]
Mr. Edman continued, "We are pleased with both our organic growth and our continued progress with the integration of Viasystems during the quarter. Shortly after the quarter ended, we announced plans to close three facilities as a part of our global integration plan. We expect the consolidation to improve plant utilization, operational performance and customer focus, and project that these actions will drive us closer to realizing our annualized synergies goal of $55.0 million. We remain focused on ongoing operational excellence and execution across our newly expanded diverse set of end markets and customers."

[0001171843-15-005766:8k_2_02:17]
Business Outlook

[0001171843-15-005766:8k_2_02:18]
For the fourth quarter of 2015, TTM estimates that revenue will be in the range of $640 million to $680 million, and non-GAAP net income will be in the range of $0.21 to $0.27 per diluted share.

[0001171843-15-005766:8k_2_02:19]
To Access the Live Webcast/Conference Call

[0001171843-15-005766:8k_2_02:20]
TTM will host a conference call and webcast to discuss third quarter 2015 results and fourth quarter 2015 outlook on Wednesday, October 28, 2015, at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call may include forward-looking statements.

[0001171843-15-005766:8k_2_02:21]
Telephone access is available by dialing domestic 1-877-876-9176 or international 1-785-424-1667 (ID 319737). The conference call also will be webcast on TTM's website at www.ttm.com.

[0001171843-15-005766:8k_2_02:22]
To Access a Replay of the Webcast

[0001171843-15-005766:8k_2_02:23]
The replay of the webcast will remain accessible for one week following the live event on TTM's website at www.ttm.com.

[0001171843-15-005766:8k_2_02:24]
About TTM

[0001171843-15-005766:8k_2_02:25]
TTM Technologies, Inc. is a major global printed circuit board manufacturer, focusing on quick-turn and technologically advanced PCBs, backplane assemblies and electro-mechanical solutions. TTM stands for time-to-market, representing how TTM's time-critical, one-stop manufacturing services enable customers to shorten the time required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001171843-15-005766:8k_2_02:26]
Forward-Looking Statements

[0001171843-15-005766:8k_2_02:27]
This release contains forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These statements reflect TTM's current expectations, and TTM does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond TTM's control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, the successful integration of Viasystems, including, the planned plant combinations and closure, general market and economic conditions, including interest rates, currency exchange rates and consumer spending, demand for TTM's products, market pressures on prices of TTM's products, warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements, TTM's dependence upon a small number of customers and other factors set forth in the "Risk Factors" and "Management's Discussion and Analysis of Financial Condition and Results of Operations" sections of the Company's public reports filed with the SEC.

[0001171843-15-005766:8k_2_02:28]
About Our Non-GAAP Financial Measures

[0001171843-15-005766:8k_2_02:29]
This release includes information about TTM's adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable investors to see TTM through the eyes of management and to provide better insight into TTM's ongoing financial performance.

[0001171843-15-005766:8k_2_02:30]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar non-GAAP financial measures used by other companies. TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliation to the most directly comparable GAAP financial measure. However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001171843-15-005766:8k_2_02:31]
| TTM TECHNOLOGIES, INC. |
| Selected Unaudited Financial Information |
| (In thousands, except per share data) |
|  | Third Quarter | Second Quarter | First Three Quarters |
|  | 2015 | 2014 | 2015 | 2015 | 2014 |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |
| Net sales | $ 652,005 | $ 345,275 | $ 445,445 | $ 1,426,614 | $ 934,805 |
| Cost of goods sold | 562,887 | 296,167 | 384,255 | 1,224,747 | 808,591 |
| Gross profit | 89,118 | 49,108 | 61,190 | 201,867 | 126,214 |
| Operating expenses: |  |  |  |  |  |
| Selling and marketing | 17,642 | 9,033 | 12,301 | 39,398 | 26,993 |
| General and administrative | 39,456 | 25,733 | 52,009 | 125,455 | 70,898 |
| Amortization of definite-lived intangibles | 6,421 | 1,980 | 3,910 | 12,205 | 6,452 |
| Restructuring charges | 2,003 | 49 | 30 | 2,512 | 62 |
| Impairment of long-lived assets | -- | -- | -- | -- | 1,845 |
| Gain on sale of asset | -- | -- | -- | (2,504) | -- |
| Total operating expenses | 65,522 | 36,795 | 68,250 | 177,066 | 106,250 |
| Operating income (loss) | 23,596 | 12,313 | (7,060) | 24,801 | 19,964 |
| Interest expense | (21,002) | (6,018) | (12,778) | (39,545) | (18,139) |
| Loss on extinguishment of debt | -- | -- | (802) | (802) | (506) |
| Other, net | 3,998 | 1,742 | 681 | 4,264 | (1,532) |
| Income (loss) before income taxes | 6,592 | 8,037 | (19,959) | (11,282) | (213) |
| Income tax (provision) benefit | (8,730) | (379) | (16,624) | (23,993) | 968 |
| Net income (loss) | $ (2,138) | $ 7,658 | $ (36,583) | $ (35,275) | $ 755 |
| Net income attributable to noncontrolling interest | (99) | -- | (29) | (128) | -- |
| Net income (loss) attributable to stockholders | $ (2,237) | $ 7,658 | $ (36,612) | $ (35,403) | $ 755 |
| Earnings (loss) per share attributable to stockholders: |  |  |  |  |
| Basic | $ (0.02) | $ 0.09 | $ (0.41) | $ (0.39) | $ 0.01 |
| Diluted | $ (0.02) | $ 0.09 | $ (0.41) | $ (0.39) | $ 0.01 |
| Weighted-average shares used in computing per share amounts: |  |  |  |
| Basic | 99,128 | 83,345 | 88,834 | 90,522 | 83,202 |
| Diluted | 99,128 | 84,039 | 88,834 | 90,522 | 83,853 |
| SELECTED BALANCE SHEET DATA |  |  |  |  |
|  | September 28, 2015 | December 29, 2014 |  |  |  |
| Cash and cash equivalents, including restricted cash | $ 150,118 | $ 279,042 |  |  |  |
| Accounts and notes receivable, net | 485,996 | 307,933 |  |  |  |
| Inventories | 292,831 | 145,187 |  |  |  |
| Total current assets | 980,733 | 798,123 |  |  |  |
| Property, plant and equipment, net | 1,127,774 | 754,718 |  |  |  |
| Other non-current assets | 562,460 | 48,448 |  |  |  |
| Total assets | 2,670,967 | 1,601,289 |  |  |  |
| Short-term debt, including current portion of long-term debt | $ 89,500 | $ 128,045 |  |  |  |
| Accounts payable | 342,233 | 217,326 |  |  |  |
| Total current liabilities | 660,018 | 496,012 |  |  |  |
| Debt, net of discount | 1,111,600 | 374,642 |  |  |  |
| Total long-term liabilities | 1,184,920 | 389,813 |  |  |  |
| Total equity | 826,029 | 715,464 |  |  |  |
| Total liabilities and equity | 2,670,967 | 1,601,289 |  |  |  |
| SUPPLEMENTAL DATA |  |  |  |  |  |
|  | Third Quarter | Second Quarter | First Three Quarters |
|  | 2015 | 2014 | 2015 | 2015 | 2014 |
| Gross margin | 13.7% | 14.2% | 13.7% | 14.2% | 13.5% |
| Operating margin | 3.6% | 3.6% | (1.6)% | 1.7% | 2.1% |
| End Market Breakdown: |  |  |  |  |  |
|  | Third Quarter | Second Quarter |  |  |
|  | 2015 | 2014 | 2015 |  |  |
| Aerospace/Defense | 14% | 15% | 15% |  |  |
| Automotive | 18% | 3% | 7% |  |  |
| Cellular Phone | 16% | 25% | 24% |  |  |
| Computing/Storage/Peripherals | 14% | 13% | 11% |  |  |
| Medical/Industrial/Instrumentation | 14% | 9% | 12% |  |  |
| Networking/Communications | 22% | 32% | 26% |  |  |
| Other | 2% | 3% | 5% |  |  |
| Stock-based Compensation: |  |  |  |  |  |
|  | Third Quarter | Second Quarter |  |  |
|  | 2015 | 2014 | 2015 |  |  |
| Amount included in: |  |  |  |  |  |
| Cost of goods sold | $ 322 | $ 207 | $ 243 |  |  |
| Selling and marketing | 294 | 257 | 269 |  |  |
| General and administrative | 2,056 | 1,490 | 1,802 |  |  |
| Total stock-based compensation expense | $ 2,672 | $ 1,954 | $ 2,314 |  |  |
| Operating Segment Data: |  |  |  |  |  |
|  | Third Quarter | Second Quarter |  |  |
| Net sales: | 2015 | 2014 | 2015 |  |  |
| PCB | $ 604,771 | $ 328,542 | $ 417,901 |  |  |
| E-M Solutions | 49,658 | 17,368 | 28,514 |  |  |
| Corporate | -- | -- | -- |  |  |
| Total sales | 654,429 | 345,910 | 446,415 |  |  |
| Inter-segment sales | (2,424) | (635) | (970) |  |  |
| Total net sales | $ 652,005 | $ 345,275 | $ 445,445 |  |  |
| Operating segment income: |  |  |  |  |  |
| PCB | $ 52,191 | $ 20,457 | $ 30,456 |  |  |
| E-M Solutions | (1,729) | 642 | (110) |  |  |
| Corporate | (20,445) | (6,806) | (33,496) |  |  |
| Total operating segment income (loss) | 30,017 | 14,293 | (3,150) |  |  |
| Amortization of definite-lived intangibles | (6,421) | (1,980) | (3,910) |  |  |
| Total operating income (loss) | 23,596 | 12,313 | (7,060) |  |  |
| Total other expense | (17,004) | (4,276) | (12,899) |  |  |
| Income (loss) before income taxes | $ 6,592 | $ 8,037 | $ (19,959) |  |  |
| RECONCILIATIONS1 |  |  |  |  |  |
|  | Third Quarter | Second Quarter | First Three Quarters |
|  | 2015 | 2014 | 2015 | 2015 | 2014 |
| Non-GAAP gross profit reconciliation2: |  |  |  |  |
| GAAP gross profit | $ 89,118 | $ 49,108 | $ 61,190 | $ 201,867 | $ 126,214 |
| Add back item: |  |  |  |  |  |
| Inventory markup and PP&E step up | 8,214 | -- | 7,408 | 15,622 | -- |
| Stock-based compensation | 322 | 207 | 243 | 790 | 669 |
| Non-GAAP gross profit | $ 97,654 | $ 49,315 | $ 68,841 | $ 218,279 | $ 126,883 |
| Non-GAAP gross margin | 15.0% | 14.3% | 15.5% | 15.3% | 13.6% |
| Non-GAAP operating income reconciliation3: |  |  |  |  |
| GAAP operating income (loss) | $ 23,596 | $ 12,313 | $ (7,060) | $ 24,801 | $ 19,964 |
| Add back items: |  |  |  |  |  |
| Amortization of definite-lived intangibles | 6,421 | 1,980 | 3,910 | 12,205 | 6,452 |
| Stock-based compensation | 2,672 | 1,954 | 2,314 | 7,026 | 6,053 |
| Gain on sale of asset | -- | -- | -- | (2,504) | -- |
| Acquisition-related costs | 2,065 | 1,632 | 22,627 | 32,927 | 1,632 |
| Inventory markup and PP&E step up | 8,214 | -- | 7,408 | 15,622 | -- |
| Impairments and restructuring charges | 2,003 | 49 | 30 | 2,512 | 1,907 |
| Non-GAAP operating income | $ 44,971 | $ 17,928 | $ 29,229 | $ 92,589 | $ 36,008 |
| Non-GAAP operating margin | 6.9% | 5.2% | 6.6% | 6.5% | 3.9% |
| Non-GAAP net income and EPS attributable to stockholders reconciliation4: |  |  |  |  |  |
| GAAP net income (loss) attributable to stockholders | $ (2,237) | $ 7,658 | $ (36,612) | $ (35,403) | $ 755 |
| Add back items: |  |  |  |  |  |
| Amortization of definite-lived intangibles | 6,421 | 1,980 | 3,910 | 12,205 | 6,452 |
| Stock-based compensation | 2,672 | 1,954 | 2,314 | 7,026 | 6,053 |
| Non-cash interest expense | 4,819 | 2,548 | 3,289 | 10,733 | 7,580 |
| Gain on sale of asset | -- | -- | -- | (2,504) | -- |
| Acquisition-related costs | 2,065 | 1,632 | 22,627 | 32,927 | 1,632 |
| Inventory markup and PP&E step up | 8,214 | -- | 7,408 | 15,622 | -- |
| Impairments, restructuring and other charges | 2,003 | 49 | 832 | 3,314 | 2,413 |
| Income taxes | (122) | (4,810) | 11,110 | 5,622 | (8,789) |
| Non-GAAP net income attributable to stockholders | $ 23,835 | $ 11,011 | $ 14,878 | $ 49,542 | $ 16,096 |
| Non-GAAP earnings per diluted share attributable to stockholders | $ 0.24 | $ 0.13 | $ 0.17 | $ 0.54 | $ 0.19 |
| Adjusted EBITDA reconciliation5: |  |  |  |  |  |
| GAAP net income (loss) | $ (2,138) | $ 7,658 | $ (36,583) | $ (35,275) | $ 755 |
| Add back items: |  |  |  |  |  |
| Income tax provision (benefit) | 8,730 | 379 | 16,624 | 23,993 | (968) |
| Interest expense | 21,002 | 6,018 | 12,778 | 39,545 | 18,139 |
| Amortization of definite-lived intangibles | 6,421 | 1,980 | 3,910 | 12,205 | 6,452 |
| Depreciation expense | 40,091 | 23,887 | 29,776 | 94,403 | 71,031 |
| Stock-based compensation | 2,672 | 1,954 | 2,314 | 7,026 | 6,053 |
| Gain on sale of asset | -- | -- | -- | (2,504) | -- |
| Acquisition-related costs | 2,065 | 1,632 | 22,627 | 32,927 | 1,632 |
| Inventory markup | 6,792 | -- | 7,408 | 14,200 | -- |
| Impairments, restructuring and other charges | 2,003 | 49 | 832 | 3,314 | 2,413 |
| Adjusted EBITDA | $ 87,638 | $ 43,557 | $ 59,686 | $ 189,834 | $ 105,507 |
| Adjusted EBITDA margin | 13.4% | 12.6% | 13.4% | 13.3% | 11.3% |
| 1 This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income attributable to stockholders, non-GAAP EPS attributable to stockholders, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |
| 2 Non-GAAP gross profit and gross margin measures exclude stock-based compensation expense, inventory markup and PP&E step up. |
| 3 Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges. |
| 4 This information provides non-GAAP net income attributable to stockholders and non-GAAP EPS attributable to stockholders, which are non-GAAP financial measures. Management believes that both measures --- which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items --- provide additional useful information to investors regarding the Company's ongoing financial condition and results of operations. |
| 5 Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |

[0001171843-15-005766:8k_2_02:32]
CONTACT: Todd Schull, CFO
         714-327-3000
