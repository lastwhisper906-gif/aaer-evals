# TTMI note change history — 0001193125-15-284892 → 0001193125-15-366187


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0001193125-15-366187:note_history:1]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of September 28, 2015 and
 December 29, 2014. However, these amounts are not material to
 the consolidated condensed financial statements of the
 Company.
  (was, 2015-08-10, similarity 0.9846):
[0001193125-15-284892:note_history:1]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of June 29, 2015 and
 December 29, 2014. However, these amounts are not material to
 the consolidated financial statements of the Company.

- changed (2015-11-04):
[0001193125-15-366187:note_history:2]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States, Canada and Mexico comply in all
 material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted
 new rules and regulations governing environmental issues. An
 update to the Chinese environmental waste water law was issued in
 late 2012, but allows for an interim period in which plants subject
 to such law may install equipment that meets the new regulatory
 regime. Some of the Company’s plants in China are not yet in
 full compliance with the updated environmental
 regulations. The Company believes it has developed plans
 acceptable to the Chinese government and is in the process of
 implementing these plans. The Company does not anticipate any
 immediate risk of government fines or temporary closure of its
 Chinese plants. The Company has established and enacted an
 investment plan related to the efforts to come into full compliance
 with the new regulations. The 2015 capital expenditure costs
 expected for these plans are included in the Company’s
 capital expenditure projections.
  (was, 2015-08-10, similarity 0.9892):
[0001193125-15-284892:note_history:2]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States and Canada comply in all material
 respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted
 new rules and regulations governing environmental issues. An
 update to the Chinese environmental waste water law was issued in
 late 2012, but allows for an interim period in which plants subject
 to such law may install equipment that meets the new regulatory
 regime. Some of the Company’s plants in China are not yet in
 full compliance with the updated environmental
 regulations. The Company believes it has developed plans
 acceptable to the Chinese government and is in the process of
 implementing these plans. The Company does not anticipate any
 immediate risk of government fines or temporary closure of its
 Chinese plants. The Company has established and enacted an
 investment plan related to the efforts to come into full compliance
 with the new regulations. The 2015 capital expenditure costs
 expected for these plans are included in the Company’s
 capital expenditure projections.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0001193125-15-366187:note_history:3]
TTM
 Technologies, Inc. (the Company or TTM) is a major global printed
 circuit board (PCB) manufacturer, focusing on quick-turn and
 technologically advanced PCBs, backplane assemblies and
 electro-mechanical solutions (E-M Solutions). The Company provides
 time-to-market and advanced technology products and offers a
 one-stop manufacturing solution to customers from engineering
 support to prototype development through final volume production.
 This one-stop manufacturing solution allows the Company to align
 technology developments with the diverse needs of the
 Company’s customers and to enable them to reduce the time
 required to develop new products and bring them to
 market.
  (was, 2015-08-10, similarity 0.759):
[0001193125-15-284892:note_history:3]
TTM
 Technologies, Inc. (the Company or TTM) is a leading global
 provider of time-critical and technologically complex printed
 circuit board (PCB) products and backplane assemblies (i.e., PCBs
 populated with electronic components and other complex electronic
 assemblies). The Company provides time-to-market and advanced
 technology products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final volume production. This one-stop manufacturing solution
 allows the Company to align technology developments with the
 diverse needs of the Company’s customers and to enable them
 to reduce the time required to develop new products and bring them
 to market.

- changed (2015-11-04):
[0001193125-15-366187:note_history:4]
The
 Company serves a diversified customer base in various markets
 throughout the world, including manufacturers of
 networking/communications infrastructure products, touchscreen
 tablets and smartphones, as well as the aerospace and defense,
 automotive, high-end computing, and industrial/medical industries.
 The Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.
  (was, 2015-08-10, similarity 0.9843):
[0001193125-15-284892:note_history:4]
Additionally, the Company serves a diversified customer base in
 various markets throughout the world, including manufacturers of
 networking/communications infrastructure products, touchscreen
 tablets and smartphones, as well as the aerospace and defense,
 automotive, high-end computing, and industrial/medical industries.
 The Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

- added (2015-11-04):
[0001193125-15-366187:note_history:5]
In
 September 2015, the Financial Accounting Standards Board (FASB)
 issued Accounting Standard Update (ASU) 2015-16, Simplifying the
 Accounting for Measurement-Period Adjustments, which requires
 that an acquirer recognize adjustments to provisional values of
 assets acquired and liabilities assumed in a business combination
 in the reporting period in which the adjustment amounts are
 determined. This update requires that the acquirer record, in the
 same period’s financial statements, the effect on earnings of
 changes in depreciation, amortization, or other income effects, if
 any, as a result of the change to the provisional amounts,
 calculated as if the accounting had been completed at the
 acquisition date. This update also requires an entity to present
 separately on the face of the income statement or disclose in the
 notes the portion of the amount recorded in current-period earnings
 by line item that would have been recorded in previous reporting
 periods if the adjustment to the provisional amounts had been
 recognized as of the acquisition date. The Company adopted ASU
 2015-16 in the third quarter of 2015, and the Company’s
 adoption did not have an impact on its ongoing
 reporting.

- changed (2015-11-04):
[0001193125-15-366187:note_history:6]
In
 April 2015, the FASB issued ASU 2015-03, Interest-Imputation of
 Interest, which requires an entity to record debt issuance
 costs related to a note reported in the balance sheet as a direct
 deduction from the face amount of that note. The update is
 effective for annual periods ending after December 15, 2015.
 Early application is permitted. The standard requires the use of
 the retrospective transition method. The impact on the
 Company’s consolidated financial statements is not expected
 to be material.
  (was, 2015-08-10, similarity 0.9106):
[0001193125-15-284892:note_history:6]
In
 April 2015, the Financial Accounting Standards Board (FASB) issued
 Accounting Standard Update (ASU) 2015-03, Interest-Imputation of
 Interest, which requires an entity to record debt issuance
 costs related to a note reported in the balance sheet as a direct
 deduction from the face amount of that note. The update is
 effective for annual periods ending after December 15, 2015.
 Early application is permitted. The standard requires the use of
 the retrospective transition method. The impact on the
 Company’s consolidated financial statements is not expected
 to be material.

- changed (2015-11-04):
[0001193125-15-366187:note_history:7]
In
 May 2014, the FASB issued ASU 2014-09, Revenue from
 Contracts with Customers, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. ASU 2014-09
 will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2018, however
 application of the standard is allowed as early as the beginning of
 fiscal 2017. The standard permits the use of either the
 retrospective or cumulative effect transition method. The Company
 is evaluating the effect that ASU 2014-09 will have on its
 consolidated financial statements and related disclosures. The
 Company has not yet selected a transition method, nor has the
 Company determined the effect of the standard on its ongoing
 financial reporting.
  (was, 2015-08-10, similarity 0.9804):
[0001193125-15-284892:note_history:7]
In
 May 2014, the FASB issued ASU 2014-09, Revenue from
 Contracts with Customers, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. ASU 2014-09
 will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2018, however
 application of the standard is allowed as early as the beginning of
 fiscal 2017. The standard permits the use of either the
 retrospective or cumulative effect transition method. We are
 evaluating the effect that ASU 2014-09 will have on the
 Company’s consolidated financial statements and related
 disclosures. The Company has not yet selected a transition method,
 nor has the Company determined the effect of the standard on its
 ongoing financial reporting.


## ttmi:ConvertibleSeniorNotesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0001193125-15-366187:note_history:8]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015, in a public offering for an aggregate principal
 amount of $175,000. During the three quarters ended
 September 28, 2015, the outstanding principal of $32,395 plus
 accrued interest was paid in full.
  (was, 2015-08-10, similarity 0.8761):
[0001193125-15-284892:note_history:8]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015, in a public offering for an aggregate principal
 amount of $175,000. During the quarter ended June 29, 2015,
 the outstanding principal of $32,395 plus accrued interest was paid
 in full.

- changed (2015-11-04):
[0001193125-15-366187:note_history:9]
As of September 28, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:
  (was, 2015-08-10, similarity 0.9569):
[0001193125-15-284892:note_history:9]
As of June 29, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:

- added (2015-11-04):
[0001193125-15-366187:note_history:10]
|  |  | As of September 28, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (47,355 | ) |  | $ | 202,645 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 250,000 |  |  | $ | (47,355 | ) |  | $ | 202,645 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |
|  |  | As of September 28, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
| Total |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |

- changed (2015-11-04):
[0001193125-15-366187:note_history:11]
The components of interest expense resulting from the
 convertible senior notes for the quarter and three quarters ended
 September 28, 2015 and September 29, 2014 were as
 follows:
  (was, 2015-08-10, similarity 0.9136):
[0001193125-15-284892:note_history:11]
The components of interest expense resulting from the
 convertible senior notes for the quarter and two quarters ended
 June 29, 2015 and June 30, 2014 were as
 follows:

- changed (2015-11-04):
[0001193125-15-366187:note_history:12]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 28, 2015 |  |  | September 29, 2014 |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,273 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 263 |  |  |  | 395 |  |  |  | 790 |  |
|  |  | $ | 1,094 |  |  | $ | 1,357 |  |  | $ | 3,676 |  |  | $ | 4,063 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,898 |  |  | $ | 1,779 |  |  | $ | 5,603 |  |  | $ | 5,294 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 352 |  |  |  | 554 |  |  |  | 1,036 |  |
|  |  | $ | 1,898 |  |  | $ | 2,131 |  |  | $ | 6,157 |  |  | $ | 6,330 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 190 |  |  | $ | 178 |  |  | $ | 561 |  |  | $ | 531 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 36 |  |  |  | 56 |  |  |  | 104 |  |
|  |  | $ | 190 |  |  | $ | 214 |  |  | $ | 617 |  |  | $ | 635 |  |
  (was, 2015-08-10, similarity 0.8484):
[0001193125-15-284892:note_history:12]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 29, 2015 |  |  | June 30, 2014 |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 2,187 |  |  | $ | 2,179 |  |
| Convertible senior notes due 2015 |  |  | 131 |  |  |  | 263 |  |  |  | 395 |  |  |  | 526 |  |
|  |  | $ | 1,225 |  |  | $ | 1,357 |  |  | $ | 2,582 |  |  | $ | 2,705 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,867 |  |  | $ | 1,751 |  |  | $ | 3,705 |  |  | $ | 3,515 |  |
| Convertible senior notes due 2015 |  |  | 187 |  |  |  | 345 |  |  |  | 554 |  |  |  | 683 |  |
|  |  | $ | 2,054 |  |  | $ | 2,096 |  |  | $ | 4,259 |  |  | $ | 4,198 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 187 |  |  | $ | 175 |  |  | $ | 371 |  |  | $ | 353 |  |
| Convertible senior notes due 2015 |  |  | 19 |  |  |  | 35 |  |  |  | 56 |  |  |  | 69 |  |
|  |  | $ | 206 |  |  | $ | 210 |  |  | $ | 427 |  |  | $ | 422 |  |

- changed (2015-11-04):
[0001193125-15-366187:note_history:13]
As of September 28, 2015 and December 29, 2014,
 remaining unamortized debt issuance costs included in other
 non-current assets were $4,746 and $5,363, respectively. The debt
 issuance costs and debt discount are being amortized to interest
 expense over the term of the convertible senior notes using the
 effective interest rate method. At September 28, 2015, the
 remaining weighted average amortization period for the unamortized
 senior convertible note discount and debt issuance costs was
 5.2 years.
  (was, 2015-08-10, similarity 0.6916):
[0001193125-15-284892:note_history:13]
As of June 29, 2015 and December 29, 2014, remaining
 unamortized debt issuance costs included in other non-current
 assets were $4,936 and $5,363, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At June 29, 2015, the remaining weighted
 average amortization period for the unamortized senior convertible
 note discount and debt issuance costs was
 5.5 years.

- changed (2015-11-04):
[0001193125-15-366187:note_history:14]
For the quarter and three quarters ended September 28,
 2015 and September 29, 2014, the amortization of debt discount
 and debt issuance costs for the 2020 convertible senior notes and
 the 2015 convertible senior notes was based on an effective
 interest rate of 6.48% and 8.37%, respectively.
  (was, 2015-08-10, similarity 0.9046):
[0001193125-15-284892:note_history:14]
For the quarter and two quarters ended June 29, 2015 and
 June 30, 2014, the amortization of debt discount and debt
 issuance costs for the 2020 convertible senior notes and the 2015
 convertible senior notes was based on an effective interest rate of
 6.48% and 8.37%, respectively.

- removed (2015-11-04):
[0001193125-15-284892:note_history:15]
|  |  | As of June 29, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (49,252 | ) |  | $ | 200,748 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 250,000 |  |  | $ | (49,252 | ) |  | $ | 200,748 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |

- removed (2015-11-04):
[0001193125-15-284892:note_history:16]
|  |  | As of June 29, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
| Total |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0001193125-15-366187:note_history:17]
The
 components of interest expense resulting from the convertible
 senior notes for the quarter and three quarters ended
 September 28, 2015 and September 29, 2014 were as
 follows:
  (was, 2015-08-10, similarity 0.9136):
[0001193125-15-284892:note_history:17]
The components of interest expense resulting from the
 convertible senior notes for the quarter and two quarters ended
 June 29, 2015 and June 30, 2014 were as
 follows:

- changed (2015-11-04):
[0001193125-15-366187:note_history:18]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 28, 2015 |  |  | September 29, 2014 |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,273 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 263 |  |  |  | 395 |  |  |  | 790 |  |
|  |  | $ | 1,094 |  |  | $ | 1,357 |  |  | $ | 3,676 |  |  | $ | 4,063 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,898 |  |  | $ | 1,779 |  |  | $ | 5,603 |  |  | $ | 5,294 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 352 |  |  |  | 554 |  |  |  | 1,036 |  |
|  |  | $ | 1,898 |  |  | $ | 2,131 |  |  | $ | 6,157 |  |  | $ | 6,330 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 190 |  |  | $ | 178 |  |  | $ | 561 |  |  | $ | 531 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 36 |  |  |  | 56 |  |  |  | 104 |  |
|  |  | $ | 190 |  |  | $ | 214 |  |  | $ | 617 |  |  | $ | 635 |  |
  (was, 2015-08-10, similarity 0.8484):
[0001193125-15-284892:note_history:18]
|  |  | For the Quarter Ended |  |  | For the Two Quarters Ended |  |
|  |  | June 29, 2015 |  |  | June 30, 2014 |  |  | June 29, 2015 |  |  | June 30, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 2,187 |  |  | $ | 2,179 |  |
| Convertible senior notes due 2015 |  |  | 131 |  |  |  | 263 |  |  |  | 395 |  |  |  | 526 |  |
|  |  | $ | 1,225 |  |  | $ | 1,357 |  |  | $ | 2,582 |  |  | $ | 2,705 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,867 |  |  | $ | 1,751 |  |  | $ | 3,705 |  |  | $ | 3,515 |  |
| Convertible senior notes due 2015 |  |  | 187 |  |  |  | 345 |  |  |  | 554 |  |  |  | 683 |  |
|  |  | $ | 2,054 |  |  | $ | 2,096 |  |  | $ | 4,259 |  |  | $ | 4,198 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 187 |  |  | $ | 175 |  |  | $ | 371 |  |  | $ | 353 |  |
| Convertible senior notes due 2015 |  |  | 19 |  |  |  | 35 |  |  |  | 56 |  |  |  | 69 |  |
|  |  | $ | 206 |  |  | $ | 210 |  |  | $ | 427 |  |  | $ | 422 |  |


## ttmi:ScheduleOfLiabilityAndEquityComponentsOfConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0001193125-15-366187:note_history:19]
As of September 28, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:
  (was, 2015-08-10, similarity 0.9569):
[0001193125-15-284892:note_history:19]
As of June 29, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:

- added (2015-11-04):
[0001193125-15-366187:note_history:20]
|  |  | As of September 28, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (47,355 | ) |  | $ | 202,645 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 250,000 |  |  | $ | (47,355 | ) |  | $ | 202,645 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |
|  |  | As of September 28, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
| Total |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |

- removed (2015-11-04):
[0001193125-15-284892:note_history:21]
|  |  | As of June 29, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (49,252 | ) |  | $ | 200,748 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 250,000 |  |  | $ | (49,252 | ) |  | $ | 200,748 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |

- removed (2015-11-04):
[0001193125-15-284892:note_history:22]
|  |  | As of June 29, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
| Total |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0001193125-15-366187:note_history:23]
The following table summarizes the long-term debt of the
 Company as of September 28, 2015 and December 29,
 2014:
  (was, 2015-08-10, similarity 0.9447):
[0001193125-15-284892:note_history:23]
The following table summarizes the long-term debt of the
 Company as of June 29, 2015 and December 29,
 2014:

- changed (2015-11-04):
[0001193125-15-366187:note_history:24]
|  |  | Average Effective Interest Rate as of September 28, 2015 |  | September 28, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  | 6.0% |  | $ | 950,000 |  |  | — |  |  | — |  |
| U.S. ABL revolving loan due May 2020 |  | 1.9% |  |  | 80,000 |  |  | — |  |  | — |  |
| Term loan due September 2016 |  | — |  |  | — |  |  | 2.5% |  | $ | 273,800 |  |
| Other |  | — |  |  | — |  |  | 6.0% |  |  | 4 |  |
|  |  |  |  |  | 1,030,000 |  |  |  |  |  | 273,804 |  |
| Less: Unamortized discount |  |  |  |  | (31,545 | ) |  |  |  |  | — |  |
|  |  |  |  |  | 998,455 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (89,500 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 908,955 |  |  |  |  | $ | 177,600 |  |
  (was, 2015-08-10, similarity 0.9534):
[0001193125-15-284892:note_history:24]
|  |  | Average Effective Interest Rate as of June 29, 2015 |  | June 29, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  | 6.0% |  | $ | 950,000 |  |  | — |  |  | — |  |
| U.S. ABL revolving loan due May 2020 |  | 1.9% |  |  | 80,000 |  |  | — |  |  | — |  |
| Term loan due September 2016 |  | — |  |  | — |  |  | 2.55% |  | $ | 273,800 |  |
| Other |  | 6.0% |  |  | 1 |  |  | 6.00% |  |  | 4 |  |
|  |  |  |  |  | 1,030,001 |  |  |  |  |  | 273,804 |  |
| Less: Unamortized discount |  |  |  |  | (32,828 | ) |  |  |  |  | — |  |
|  |  |  |  |  | 997,173 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (87,126 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 910,047 |  |  |  |  | $ | 177,600 |  |

- changed (2015-11-04):
[0001193125-15-366187:note_history:25]
The fiscal calendar maturities of long-term debt through 2019
 and thereafter are as follows:
  (was, 2015-08-10, similarity 0.9591):
[0001193125-15-284892:note_history:25]
The calendar maturities of long-term debt through 2019 and
 thereafter are as follows:

- changed (2015-11-04):
[0001193125-15-366187:note_history:26]
The Term Loan was issued at a discount at 96.5% and bears
 interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus
 an applicable interest margin of 5.0%, or JP Morgan Chase
 Bank’s prime rate, with a 2% floor, plus a margin of 4%, at
 the Company’s option. At September 28, 2015, the
 weighted average interest rate on the outstanding borrowings under
 the Term Loan was 6.0%. There is no provision, other than an event
 of default, for the interest margin to increase. The Term Loan will
 mature on May 31, 2021. The Term Loan is secured by a
 significant amount of the assets of the Company and its domestic
 subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and is structurally
 senior to the Company’s convertible senior notes. See Note 7
 Convertible Senior Notes.
  (was, 2015-08-10, similarity 0.9918):
[0001193125-15-284892:note_history:26]
The Term Loan was issued at a discount at 96.5% and bears
 interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus
 an applicable interest margin of 5.0%, or JP Morgan Chase
 Bank’s prime rate, with a 2% floor, plus a margin of 4%, at
 the Company’s option. At June 29, 2015, the weighted
 average interest rate on the outstanding borrowings under the Term
 Loan was 6.0%. There is no provision, other than an event of
 default, for the interest margin to increase. The Term Loan will
 mature on May 31, 2021. The Term Loan is secured by a
 significant amount of the assets of the Company and its domestic
 subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and is structurally
 senior to the Company’s convertible senior notes. See Note 7
 Convertible Senior Notes.

- changed (2015-11-04):
[0001193125-15-366187:note_history:27]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $150,000, a letter of credit
 facility of up to $75,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $150,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 175 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 75 basis points, at the Company’s option. At
 September 28, 2015, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 1.9%. Beginning in
 2016, the applicable margin can vary based on the remaining
 availability of the facility, from 150 to 200 basis points for
 LIBOR-based loans and from 50 to 100 basis points for JP Morgan
 Chase Bank’s prime rate-based loans. Other than availability
 and an event of default, there are no other provisions for the
 interest margin to increase. The U.S. ABL will mature on
 May 31, 2020. Loans made under the U.S. ABL are secured first
 by all of the Company’s domestic cash, receivables and
 inventories as well as by a second position against a significant
 amount of the assets of the Company and its domestic subsidiaries
 and a pledge of 65% of voting stock of the Company’s first
 tier foreign subsidiaries and are structurally senior to the
 Company’s convertible senior notes. See Note 7 Convertible
 Senior Notes. At September 28, 2015, $80,000 of the U.S. ABL
 was outstanding and classified as short-term debt.
  (was, 2015-08-10, similarity 0.9804):
[0001193125-15-284892:note_history:27]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $150,000, a letter of credit
 facility of up to $75,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $150,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL. Borrowings under the U.S. ABL bear
 interest at either a floating rate of LIBOR plus a margin of 175
 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 75 basis points, at the Company’s option. At
 June 29, 2015, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 1.9%. Beginning in
 2016, the applicable margin can vary based on the remaining
 availability of the facility, from 150 to 200 basis points for
 LIBOR-based loans and from 50 to 100 basis points for JP Morgan
 Chase Bank’s prime rate-based loans. Other than availability
 and an event of default, there are no other provisions for the
 interest margin to increase. The U.S. ABL will mature on
 May 31, 2020. Loans made under the U.S. ABL are secured first
 by all of the Company’s domestic cash, receivables and
 inventories as well as by a significant amount of the assets of the
 Company and its domestic subsidiaries and a pledge of 65% of voting
 stock of the Company’s first tier foreign subsidiaries and
 are structurally senior to the Company’s convertible senior
 notes. See Note 7 Convertible Senior Notes. At June 29, 2015,
 $80,000 of the U.S. ABL was outstanding and classified as
 short-term debt.

- changed (2015-11-04):
[0001193125-15-366187:note_history:28]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of the Company’s Asia Pacific cash and
 receivables and are structurally senior to the Company’s
 domestic obligations, including the convertible senior notes. See
 Note 7 Convertible Senior Notes. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At September 28, 2015, none of the
 Asia ABL was outstanding.
  (was, 2015-08-10, similarity 0.9939):
[0001193125-15-284892:note_history:28]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of the Company’s Asia Pacific cash and
 receivables and are structurally senior to the Company’s
 domestic obligations, including the convertible senior notes. See
 Note 7 Convertible Senior Notes. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At June 29, 2015, none of the Asia
 ABL was outstanding.

- added (2015-11-04):
[0001193125-15-366187:note_history:29]
The Company is required to make scheduled payments of the
 outstanding Term Loan balance on a quarterly basis beginning
 October 1, 2015. On October 1, 2015, the first scheduled
 principal payment of $2,375 was made. Based on certain parameters
 defined in the Term Loan agreement, the Company may be required to
 make an additional principal payment on an annual basis. Any other
 outstanding balances under the Term Loan are due at the maturity
 date of May 31, 2021. Borrowings under the Term Loan are
 subject to various financial and operating covenants including
 maintaining a maximum total leverage ratio. Under the occurrence of
 certain events, the U.S. ABL and the Asia ABL are subject to
 various financial and operational covenants, including maintaining
 minimum fixed charge coverage ratios. At September 28, 2015,
 the Company was in compliance with the covenants under the Term
 Loan, the U.S. ABL and the Asia ABL.

- changed (2015-11-04):
[0001193125-15-366187:note_history:30]
As of September 28, 2015, remaining unamortized debt
 discount and debt issuance costs were $31,545 and $32,168,
 respectively. The debt discount is recorded as a reduction of the
 Term Loan and is amortized over the duration of the Term Loan. The
 debt issuance costs are included in other non-current assets and
 are amortized to interest expense over the duration of the Term
 Loan and ABL Revolving Loans. The debt discount and the debt
 issuance costs related to the Term Loan are amortized into interest
 expense using an effective interest rate of 7.49%. The debt
 issuance costs related to the ABL Revolving Loans are amortized
 into interest expense using the straight line method of
 amortization over the duration of the ABL Revolving Loans. At
 September 28, 2015, the remaining amortization period for the
 unamortized debt discount and debt issuance costs was 5.6
 years.
  (was, 2015-08-10, similarity 0.8663):
[0001193125-15-284892:note_history:30]
As of June 29, 2015, remaining unamortized debt discount
 and debt issuance costs were $32,828 and $33,585, respectively. The
 debt discount is recorded as a reduction of the Term Loan and is
 amortized over the duration of the Term Loan. The debt issuance
 costs are included in other non-current assets and are amortized to
 interest expense over the duration of the Term Loan and ABL
 Revolving Loans. The debt discount and the debt issuance costs
 related to the Term Loan are amortized into interest expense using
 an effective interest rate of 7.49%. The debt issuance costs
 related to the ABL Revolving Loans are amortized into interest
 expense using the straight line method of amortization over the
 duration of the ABL Revolving Loans. At June 29, 2015, the
 remaining amortization period for the unamortized debt discount and
 debt issuance costs was 5.9 years.

- changed (2015-11-04):
[0001193125-15-366187:note_history:31]
The Company is required to pay a commitment fee of
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The U.S. ABL commitment fee may vary from 0.25% to 0.375%
 based on utilization levels. Additionally, the Company also paid
 commitment fees of 0.5% per annum on the unused portion of the
 $90,000 senior secured revolving loan associated with the
 terminated 2012 credit agreement during the quarter and two
 quarters ended June 29, 2015. The Company incurred total
 commitment fees related to unused borrowing availability of $200
 and $155 for the quarters ended September 28, 2015 and
 September 29, 2014, respectively, and $565 and $439 for the
 three quarters ended September 28, 2015 and September 29,
 2014, respectively. As of September 28, 2015, the outstanding
 amount of the Term Loan was $950,000, of which $9,500 is due for
 repayment within one year and is included as short-term debt, with
 the remaining $940,500 included as long-term debt. Additionally,
 $80,000 of the U.S. ABL and none of the Asia ABL was outstanding as
 of September 28, 2015. Available borrowing capacity under the
 U.S. ABL and Asia ABL was $65,444 and $142,224, which considers the
 letter of credit outstanding of $4,556 and $7,776 mentioned below,
 respectively, at September 28, 2015.
  (was, 2015-08-10, similarity 0.8595):
[0001193125-15-284892:note_history:31]
The Company is required to pay a commitment fee of
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The U.S. ABL commitment fee may vary from 0.25% to 0.375%
 based on utilization levels. Additionally, the Company also paid
 commitment fees of 0.5% per annum on the unused portion of the
 $90,000 senior secured revolving loan associated with the
 terminated 2012 credit agreement during the quarter and two
 quarters ended June 29, 2015. The Company incurred total
 commitment fees related to unused borrowing availability of $193
 and $151 for the quarters ended June 29, 2015 and
 June 30, 2014, respectively, and $366 and $284 for the two
 quarters ended June 29, 2015 and June 30, 2014,
 respectively. As of June 29, 2015, the outstanding amount of
 the Term Loan was $950,000, of which $7,125 is due for repayment
 within one year and is included as short-term debt, with the
 remaining $942,875 included as long-term debt. Additionally,
 $80,000 of the U.S. ABL and none of the Asia ABL was outstanding as
 of June 29, 2015. Available borrowing capacity under the U.S.
 ABL and Asia ABL was $65,444, which considers the letter of credit
 outstanding of $4,556 mentioned below, and $150,000, respectively,
 at June 29, 2015.

- changed (2015-11-04):
[0001193125-15-366187:note_history:32]
The Company has up to $75,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of September 28, 2015, letters of credit
 in the amount of $4,556 were outstanding under the U.S. ABL and
 $7,776 were outstanding under the Asia ABL. The Company has other
 standby letters of credit outstanding in the amount of $4,832,
 which expire between October 4, 2015 and May 16, 2016.
 These other standby letters of credit are securitized by cash
 collateral. As such, the Company has recorded such cash as
 restricted on the consolidated condensed balance sheet as of
 September 28, 2015. There were no such arrangements at
 December 29, 2014.
  (was, 2015-08-10, similarity 0.9344):
[0001193125-15-284892:note_history:32]
The Company has up to $75,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of June 29, 2015, letters of credit in the
 amount of $4,556 were outstanding under the U.S. ABL. The Company
 has other standby letters of credit outstanding in the amount of
 $20,516, which expire between July 2, 2015 and May 16,
 2016. These other standby letters of credit are securitized by cash
 collateral. As such, the Company has recorded such cash as
 restricted on the consolidated condensed balance sheet as of
 June 29, 2015. There were no such arrangements at
 December 29, 2014.

- changed (2015-11-04):
[0001193125-15-366187:note_history:33]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $36,100 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2015. As of September 28, 2015, the Chinese Revolver had not
 been drawn upon.
  (was, 2015-08-10, similarity 0.987):
[0001193125-15-284892:note_history:33]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $37,100 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2015. As of June 29, 2015, the Chinese Revolver had not been
 drawn upon.

- changed (2015-11-04):
[0001193125-15-366187:note_history:34]
The Company became a party to its current Term Loan and ABL
 Revolving Loans during the second quarter ended June 29, 2015
 in order to refinance and pay in full the remaining outstanding
 amount of $225,700 under an existing 2012 credit agreement, as well
 as to finance the acquisition of Viasystems and refinance
 Viasystems’ outstanding debt. As a result, the Company
 recognized losses of approximately $802 during the three quarters
 ended September 28, 2015 resulting from the write off of the
 remaining unamortized debt issuance costs associated with the
 terminated 2012 credit agreement.
  (was, 2015-08-10, similarity 0.7792):
[0001193125-15-284892:note_history:34]
The Company became a party to its current Term Loan and ABL
 Revolving Loans during the second quarter ended June 29, 2015
 in order to refinance and pay in full the remaining outstanding
 amount of $225,700 under an existing 2012 credit agreement, as well
 as to finance the acquisition of Viasystems and refinance
 Viasystems’ outstanding debt. As a result, the Company
 recognized losses of approximately $802 for the quarter and two
 quarters ended June 29, 2015 resulting from the write off of
 the remaining unamortized debt issuance costs associated with the
 terminated 2012 credit agreement.

- removed (2015-11-04):
[0001193125-15-284892:note_history:35]
The Company is required to make scheduled payments of the
 outstanding Term Loan balance on a quarterly basis beginning
 October 1, 2015. Any other outstanding balances under the Term
 Loan are due at the maturity date of May 31, 2021. Borrowings
 under the Term Loan are subject to various financial and operating
 covenants including maintaining a maximum total leverage ratio.
 Under the occurrence of certain events, the U.S. ABL and the Asia
 ABL are subject to various financial and operational covenants,
 including maintaining minimum fixed charges coverage ratios. At
 June 29, 2015, the Company was in compliance with the
 covenants under the Term Loan, the U.S. ABL and the Asia
 ABL.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0001193125-15-366187:note_history:36]
The
 following table summarizes the long-term debt of the Company as of
 September 28, 2015 and December 29, 2014:
  (was, 2015-08-10, similarity 0.9447):
[0001193125-15-284892:note_history:36]
The
 following table summarizes the long-term debt of the Company as of
 June 29, 2015 and December 29, 2014:

- changed (2015-11-04):
[0001193125-15-366187:note_history:37]
|  |  | Average Effective Interest Rate as of September 28, 2015 |  | September 28, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  | 6.0% |  | $ | 950,000 |  |  | — |  |  | — |  |
| U.S. ABL revolving loan due May 2020 |  | 1.9% |  |  | 80,000 |  |  | — |  |  | — |  |
| Term loan due September 2016 |  | — |  |  | — |  |  | 2.5% |  | $ | 273,800 |  |
| Other |  | — |  |  | — |  |  | 6.0% |  |  | 4 |  |
|  |  |  |  |  | 1,030,000 |  |  |  |  |  | 273,804 |  |
| Less: Unamortized discount |  |  |  |  | (31,545 | ) |  |  |  |  | — |  |
|  |  |  |  |  | 998,455 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (89,500 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 908,955 |  |  |  |  | $ | 177,600 |  |
  (was, 2015-08-10, similarity 0.9534):
[0001193125-15-284892:note_history:37]
|  |  | Average Effective Interest Rate as of June 29, 2015 |  | June 29, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  | 6.0% |  | $ | 950,000 |  |  | — |  |  | — |  |
| U.S. ABL revolving loan due May 2020 |  | 1.9% |  |  | 80,000 |  |  | — |  |  | — |  |
| Term loan due September 2016 |  | — |  |  | — |  |  | 2.55% |  | $ | 273,800 |  |
| Other |  | 6.0% |  |  | 1 |  |  | 6.00% |  |  | 4 |  |
|  |  |  |  |  | 1,030,001 |  |  |  |  |  | 273,804 |  |
| Less: Unamortized discount |  |  |  |  | (32,828 | ) |  |  |  |  | — |  |
|  |  |  |  |  | 997,173 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (87,126 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 910,047 |  |  |  |  | $ | 177,600 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0001193125-15-366187:note_history:38]
The
 fiscal calendar maturities of long-term debt through 2019 and
 thereafter are as follows:
  (was, 2015-08-10, similarity 0.9591):
[0001193125-15-284892:note_history:38]
The
 calendar maturities of long-term debt through 2019 and thereafter
 are as follows:


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0001193125-15-366187:note_history:39]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $21,167 and $11,469 for the quarters ended
 September 28, 2015 and September 29, 2014, respectively,
 and $43,335 and $36,647 for the three quarters ended
 September 28, 2015 and September 29, 2014,
 respectively.
  (was, 2015-08-10, similarity 0.8929):
[0001193125-15-284892:note_history:39]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $12,914 and $13,390 for the quarters ended
 June 29, 2015 and June 30, 2014, respectively, and
 $22,859 and $25,180 for the two quarters ended June 29, 2015
 and June 30, 2014, respectively.

- added (2015-11-04):
[0001193125-15-366187:note_history:40]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCB’s to SYE and purchases PCB’s
 including various services in relation to PCB manufacturing from
 SYE. Sales to SYE for the quarters ended September 28, 2015
 and September 29, 2014 were $1,042 and $2,282, respectively,
 and $3,867 and $21,535 for the three quarters ended
 September 28, 2015 and September 29, 2014, respectively.
 Purchases of PCB including various services in relation to PCB
 manufacturing for the quarters ended September 28, 2015 and
 September 29, 2014 were $344 and $78, respectively, and $1,840
 and $550 for the three quarters ended September 28, 2015 and
 September 29, 2014, respectively.

- changed (2015-11-04):
[0001193125-15-366187:note_history:41]
As of
 September 28, 2015 and December 29, 2014, the
 Company’s consolidated balance sheets included $31,425 and
 $17,950, respectively, in accounts payable due to, and $2,025 and
 $4,934, respectively, in accounts receivable due from a related
 party for the purchase of laminate and prepreg and various PCB
 manufacturing services, and sales of PCBs to SYE, as mentioned
 above.
  (was, 2015-08-10, similarity 0.9809):
[0001193125-15-284892:note_history:41]
As of
 June 29, 2015 and December 29, 2014, the Company’s
 consolidated balance sheets included $15,739 and $17,950,
 respectively, in accounts payable due to, and $2,852 and $4,934,
 respectively, in accounts receivable due from a related party for
 the purchase of laminate and prepreg and various PCB manufacturing
 services, and sales of PCBs to SYE, as mentioned above.

- removed (2015-11-04):
[0001193125-15-284892:note_history:42]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCB’s to SYE and purchases various services
 in relation to PCB manufacturing from SYE. Sales to SYE for the
 quarters ended June 29, 2015 and June 30, 2014 were $1,343 and
 $9,100, respectively, and $2,825 and $19,253 for the two quarters
 ended June 29, 2015 and June 30, 2014, respectively. Purchases
 of various services in relation to PCB manufacturing for the
 quarters ended June 29, 2015 and June 30, 2014 were $366 and $201,
 respectively, and $805 and $472 for the two quarters ended June 29,
 2015 and June 30, 2014, respectively.
