# TTMI notes — 0001193125-15-366187


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-15-366187:notes:1]
The Company accounts for inter-segment sales and transfers as
 if the sale or transfer were to third parties: at arms length and
 consistent with the Company’s revenue recognition policy. The
 inter-segment sales for the quarter and the three quarters ended
 September 28, 2015 are sales primarily from the PCB to the E-M
 Solutions operating segment.

[0001193125-15-366187:notes:2]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 28, 2015 |  |  | September 29, 2014 |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 604,771 |  |  | $ | 328,542 |  |  | $ | 1,332,996 |  |  | $ | 879,200 |  |
| E-M Solutions |  |  | 49,658 |  |  |  | 17,368 |  |  |  | 97,634 |  |  |  | 57,472 |  |
| Total sales |  |  | 654,429 |  |  |  | 345,910 |  |  |  | 1,430,630 |  |  |  | 936,672 |  |
| Inter-segment sales |  |  | (2,424 | ) |  |  | (635 | ) |  |  | (4,016 | ) |  |  | (1,867 | ) |
| Total net sales |  | $ | 652,005 |  |  | $ | 345,275 |  |  | $ | 1,426,614 |  |  | $ | 934,805 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 52,191 |  |  | $ | 20,457 |  |  | $ | 105,907 |  |  | $ | 39,856 |  |
| E-M Solutions |  |  | (1,729 | ) |  |  | 642 |  |  |  | (1,188 | ) |  |  | 3,111 |  |
| Corporate |  |  | (20,445 | ) |  |  | (6,806 | ) |  |  | (67,713 | ) |  |  | (16,551 | ) |
| Total operating segment income |  |  | 30,017 |  |  |  | 14,293 |  |  |  | 37,006 |  |  |  | 26,416 |  |
| Amortization of definite-lived intangibles |  |  | (6,421 | ) |  |  | (1,980 | ) |  |  | (12,205 | ) |  |  | (6,452 | ) |
| Total operating income |  |  | 23,596 |  |  |  | 12,313 |  |  |  | 24,801 |  |  |  | 19,964 |  |
| Total other expense |  |  | (17,004 | ) |  |  | (4,276 | ) |  |  | (36,083 | ) |  |  | (20,177 | ) |
| Income (loss) before income taxes |  | $ | 6,592 |  |  | $ | 8,037 |  |  | $ | (11,282 | ) |  | $ | (213 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-15-366187:notes:3]
[same as prior period, unchanged from 0001193125-15-284892:notes:6]

[0001193125-15-366187:notes:4]
In the
 normal course of business, the Company extends credit to its
 customers, which are in diverse end markets. Many customers to
 which the Company extends credit are located outside the United
 States. The Company performs ongoing credit evaluations of
 customers, does not require collateral, and considers the credit
 risk profile of the entity from which the receivable is due in
 further evaluating collection risk.

[0001193125-15-366187:notes:5]
[same as prior period, unchanged from 0001193125-15-284892:notes:8]

[0001193125-15-366187:notes:6]
For
 the quarter ended September 28, 2015 and September 29,
 2014, one customer accounted for approximately 17% and 23%,
 respectively, of the Company’s net sales. For the three
 quarters ended September 28, 2015 and September 29, 2014,
 one customer accounted for approximately 21% and 16%, respectively,
 of the Company’s net sales.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-15-366187:notes:7]
The following is a reconciliation of the numerator and
 denominator used to calculate basic earnings per share and diluted
 earnings per share for the quarter and three quarters ended
 September 28, 2015 and September 29, 2014:

[0001193125-15-366187:notes:8]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 28, 2015 |  |  | September 29, 2014 |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net (loss) earnings attributable to TTM Technologies, Inc. stockholders |  | $ | (2,237 | ) |  | $ | 7,658 |  |  | $ | (35,403 | ) |  | $ | 755 |  |
| Weighted average shares outstanding |  |  | 99,128 |  |  |  | 83,345 |  |  |  | 90,522 |  |  |  | 83,202 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | — |  |  |  | 694 |  |  |  | — |  |  |  | 651 |  |
| Diluted shares |  |  | 99,128 |  |  |  | 84,039 |  |  |  | 90,522 |  |  |  | 83,853 |  |
| (Loss) earnings per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.02 | ) |  | $ | 0.09 |  |  | $ | (0.39 | ) |  | $ | 0.01 |  |
| Diluted |  | $ | (0.02 | ) |  | $ | 0.09 |  |  | $ | (0.39 | ) |  | $ | 0.01 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-15-366187:notes:9]
(4)
 Inventories

[0001193125-15-366187:notes:10]
Inventories as of September 28, 2015 and December 29,
 2014 consisted of the following:

[0001193125-15-366187:notes:11]
|  |  | As of |  |
|  |  | September 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 73,679 |  |  | $ | 44,477 |  |
| Work-in-process |  |  | 104,737 |  |  |  | 57,544 |  |
| Finished goods |  |  | 114,415 |  |  |  | 43,166 |  |
|  |  | $ | 292,831 |  |  | $ | 145,187 |  |


## us-gaap:ScheduleOfShareBasedCompensationArrangementByShareBasedPaymentAwardPerformanceBasedUnitsVestedAndExpectedToVestTableTextBlock

[0001193125-15-366187:notes:12]
PRUs activity for the three quarters ended September 28,
 2015 was as follows:

[0001193125-15-366187:notes:13]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding target shares at December 29, 2014 |  |  | 275 |  |  | $ | 8.03 |  |
| Granted |  |  | 295 |  |  | $ | 7.22 |  |
| Change in units due to annual financial target performance achievement |  |  | 55 |  |  | $ | 7.22 |  |
| Outstanding target shares at September 28, 2015 |  |  | 625 |  |  | $ | 7.58 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-15-366187:notes:14]
(15)
 Stock-Based Compensation

[0001193125-15-366187:notes:15]
[same as prior period, unchanged from 0001193125-15-284892:notes:18]

[0001193125-15-366187:notes:16]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 28, 2015 |  |  | September 29, 2014 |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 322 |  |  | $ | 207 |  |  | $ | 790 |  |  | $ | 669 |  |
| Selling and marketing |  |  | 294 |  |  |  | 257 |  |  |  | 834 |  |  |  | 845 |  |
| General and administrative |  |  | 2,056 |  |  |  | 1,490 |  |  |  | 5,402 |  |  |  | 4,539 |  |
| Stock-based compensation expense recognized |  | $ | 2,672 |  |  | $ | 1,954 |  |  | $ | 7,026 |  |  | $ | 6,053 |  |

[0001193125-15-366187:notes:17]
Performance-based Restricted Stock Units
 (PRU)

[0001193125-15-366187:notes:18]
[same as prior period, unchanged from 0001193125-15-284892:notes:21]

[0001193125-15-366187:notes:19]
The Company records stock-based compensation expense for PRU
 awards granted based on management’s periodic assessment of
 the probability of the PRU awards vesting. For the quarter and
 three quarters ended September 28, 2015, management determined
 that vesting of the PRU awards was probable. PRUs activity for the
 three quarters ended September 28, 2015 was as
 follows:

[0001193125-15-366187:notes:20]
Restricted
 Stock Units

[0001193125-15-366187:notes:21]
The Company granted 1,301 and 833 restricted stock units during
 the three quarters ended September 28, 2015 and
 September 29, 2014, respectively. The RSUs granted have a
 weighted-average fair value per unit of $9.15 and $8.00 for the
 three quarters ended September 28, 2015 and September 29,
 2014, respectively. The fair value for RSUs granted is based on the
 closing share price of the Company’s common stock on the date
 of grant. There were no restricted stock units granted during the
 quarters ended September 28, 2015 and September 29,
 2014.

[0001193125-15-366187:notes:22]
[same as prior period, unchanged from 0001193125-15-284892:notes:25]

[0001193125-15-366187:notes:23]
The Company did not grant any stock option awards during the
 quarter or three quarters ended September 28, 2015 and
 September 29, 2014.

[0001193125-15-366187:notes:24]
Summary of
 Unrecognized Compensation Costs

[0001193125-15-366187:notes:25]
The following is a summary of total unrecognized compensation
 costs as of September 28, 2015:

[0001193125-15-366187:notes:26]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |
|  |  | (In thousands) |  |  | (years) |
| RSU awards |  | $ | 12,185 |  |  | 1.5 |
| PRU awards |  |  | 1,899 |  |  | 1.6 |
|  |  | $ | 14,084 |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-366187:notes:27]
[same as prior period, unchanged from 0001193125-15-284892:notes:30]

[0001193125-15-366187:notes:28]
The operating segments reported below are the Company’s
 segments for which separate financial information is available and
 upon which operating results are evaluated by the chief operating
 decision maker to assess performance and to allocate resources. As
 a result of the May 31, 2015 acquisition of Viasystems and the
 ongoing integration activities, the Company has reassessed its
 reportable operating segments and determined that it has two
 reportable operating segments: PCB and E-M Solutions. This
 determination was made based on the criteria of earning revenues
 and incurring expenses, the Company’s organizational
 structure which has segment managers who report to the chief
 operating decision maker and discrete financial information, and
 the aggregation of similar operating segments into reportable
 operating segments. All prior-period amounts have been adjusted
 retrospectively to reflect our reportable segment
 changes.

[0001193125-15-366187:notes:29]
The Company evaluates segment performance based on operating
 segment income, which is operating income before amortization of
 intangibles. Interest expense and interest income are not presented
 by segment since they are not included in the measure of segment
 profitability reviewed by the chief operating decision maker. All
 inter-segment transactions have been eliminated.

[0001193125-15-366187:notes:30]
The Corporate category includes operating expenses that are not
 included in the segment operating performance measures. Corporate
 consists primarily of corporate governance functions such as
 finance, accounting, information technology, facilities and human
 resources personnel, as well as global sales and marketing
 personnel and acquisition and integration costs associated with the
 acquisition of Viasystems. Bank fees and legal, accounting, and
 other professional service costs associated with the acquisition of
 Viasystems of $2,065 and $1,632 for the quarters ended
 September 28, 2015 and September 29, 2014, respectively,
 and $32,927 and $1,632 for the three quarters ended
 September 28, 2015 and September 29, 2014, respectively,
 are included in Corporate.


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-15-366187:notes:31]
Estimated aggregate amortization for definite-lived intangible
 assets for the next five years and thereafter is as
 follows:

[0001193125-15-366187:notes:32]
|  |  | (In thousands) |  |
| Remaining 2015 |  | $ | 6,801 |  |
| 2016 |  |  | 23,871 |  |
| 2017 |  |  | 23,647 |  |
| 2018 |  |  | 22,883 |  |
| 2019 |  |  | 18,746 |  |
| Thereafter |  |  | 61,609 |  |
|  |  | $ | 157,557 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-15-366187:notes:33]
As of September 28, 2015 and December 29, 2014
 goodwill was as follows:

[0001193125-15-366187:notes:34]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 29, 2014 |  | $ | 12,111 |  |
| Goodwill acquired during the three quarters ended September 28, 2015 |  |  | 351,135 |  |
| Foreign currency translation adjustment during the three quarters ended September 28, 2015 |  |  | 9 |  |
| Balance as of September 28, 2015 |  | $ | 363,255 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-15-366187:notes:35]
[same as prior period, unchanged from 0001193125-15-284892:notes:41]

[0001193125-15-366187:notes:36]
[same as prior period, unchanged from 0001193125-15-284892:notes:42]

[0001193125-15-366187:notes:37]
The
 carrying amount and estimated fair value of the Company’s
 financial instruments at September 28, 2015 and
 December 29, 2014 were as follows:

[0001193125-15-366187:notes:38]
|  |  | September 28, 2015 |  |  | December 29, 2014 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 20 |  |  | $ | 20 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities, current |  |  | 42 |  |  |  | 42 |  |  |  | 5,062 |  |  |  | 5,062 |  |
| Long-term debt |  |  | 998,455 |  |  |  | 961,125 |  |  |  | 273,804 |  |  |  | 273,820 |  |
| Convertible senior notes due 2020 |  |  | 202,645 |  |  |  | 220,825 |  |  |  | 197,042 |  |  |  | 241,875 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | 31,841 |  |  |  | 32,631 |  |

[0001193125-15-366187:notes:39]
[same as prior period, unchanged from 0001193125-15-284892:notes:45]

[0001193125-15-366187:notes:40]
The
 fair value of the long-term debt was estimated based on quoted
 market prices or discounting the debt over its life using current
 market rates for similar debt as of September 28, 2015 and
 December 29, 2014, which are considered Level 1 and Level 2
 inputs.

[0001193125-15-366187:notes:41]
[same as prior period, unchanged from 0001193125-15-284892:notes:47]

[0001193125-15-366187:notes:42]
As of
 September 28, 2015 and December 29, 2014, the
 Company’s other financial instruments also included cash and
 cash equivalents, accounts receivable, accounts payable and
 equipment payables. Due to short-term maturities, the carrying
 amount of these instruments approximates fair value.

[0001193125-15-366187:notes:43]
At
 September 28, 2015 and December 29, 2014, the following
 financial assets and liabilities were measured at fair value on a
 recurring basis using the type of inputs shown:

[0001193125-15-366187:notes:44]
|  |  | September 28, 2015 |  |  | Fair Value Measurements Using: |  |
|  |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Foreign exchange derivative assets |  | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |
| Foreign exchange derivative liabilities |  |  | 42 |  |  |  | — |  |  |  | 42 |  |  |  | — |  |
|  |  | December 29, 2014 |  |  | Fair Value Measurements Using: |  |
|  |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Money market funds |  | $ | 129,012 |  |  | $ | 129,012 |  |  | $ | — |  |  |  | — |  |
| Foreign exchange derivative liabilities |  |  | 5,062 |  |  |  | — |  |  |  | 5,062 |  |  |  | — |  |

[0001193125-15-366187:notes:45]
There
 were no transfers of financial assets or liabilities between Level
 1 and Level 2 inputs for the quarters or three quarters ended
 September 28, 2015 and September 29, 2014.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-15-366187:notes:46]
The
 fiscal calendar maturities of long-term debt through 2019 and
 thereafter are as follows:

[0001193125-15-366187:notes:47]
|  |  | (In thousands) |  |
| Remaining 2015 |  | $ | 82,375 |  |
| 2016 |  |  | 16,625 |  |
| 2017 |  |  | 40,375 |  |
| 2018 |  |  | 47,500 |  |
| 2019 |  |  | 47,500 |  |
| Thereafter |  |  | 795,625 |  |
|  |  | $ | 1,030,000 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-15-366187:notes:48]
Recently Issued
 Accounting Standards

[0001193125-15-366187:notes:49]
In
 September 2015, the Financial Accounting Standards Board (FASB)
 issued Accounting Standard Update (ASU) 2015-16, Simplifying the
 Accounting for Measurement-Period Adjustments, which requires
 that an acquirer recognize adjustments to provisional values of
 assets acquired and liabilities assumed in a business combination
 in the reporting period in which the adjustment amounts are
 determined. This update requires that the acquirer record, in the
 same period’s financial statements, the effect on earnings of
 changes in depreciation, amortization, or other income effects, if
 any, as a result of the change to the provisional amounts,
 calculated as if the accounting had been completed at the
 acquisition date. This update also requires an entity to present
 separately on the face of the income statement or disclose in the
 notes the portion of the amount recorded in current-period earnings
 by line item that would have been recorded in previous reporting
 periods if the adjustment to the provisional amounts had been
 recognized as of the acquisition date. The Company adopted ASU
 2015-16 in the third quarter of 2015, and the Company’s
 adoption did not have an impact on its ongoing
 reporting.

[0001193125-15-366187:notes:50]
In
 April 2015, the FASB issued ASU 2015-03, Interest-Imputation of
 Interest, which requires an entity to record debt issuance
 costs related to a note reported in the balance sheet as a direct
 deduction from the face amount of that note. The update is
 effective for annual periods ending after December 15, 2015.
 Early application is permitted. The standard requires the use of
 the retrospective transition method. The impact on the
 Company’s consolidated financial statements is not expected
 to be material.

[0001193125-15-366187:notes:51]
In
 August 2014, the FASB issued ASU 2014-15, Disclosure of
 Uncertainties About an Entity’s Ability to Continue as a
 Going Concern, which provides guidance on determining when and
 how to disclose going concern uncertainties in the financial
 statements. The new standard requires management to perform interim
 and annual assessments of an entity’s ability to continue as
 a going concern. The update is effective for annual periods ending
 after December 15, 2016, and interim periods thereafter. Early
 adoption is permitted. The Company adopted ASU 2014-15 at the
 beginning of 2015, and the Company’s adoption did not have an
 impact on its ongoing reporting.

[0001193125-15-366187:notes:52]
In
 May 2014, the FASB issued ASU 2014-09, Revenue from
 Contracts with Customers, which requires an entity to recognize
 the amount of revenue to which it expects to be entitled for the
 transfer of promised goods or services to customers. ASU 2014-09
 will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2018, however
 application of the standard is allowed as early as the beginning of
 fiscal 2017. The standard permits the use of either the
 retrospective or cumulative effect transition method. The Company
 is evaluating the effect that ASU 2014-09 will have on its
 consolidated financial statements and related disclosures. The
 Company has not yet selected a transition method, nor has the
 Company determined the effect of the standard on its ongoing
 financial reporting.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-15-366187:notes:53]
(2) Acquisition of
 Viasystems Group, Inc.

[0001193125-15-366187:notes:54]
On May 31, 2015, the Company completed the acquisition of
 Viasystems Group, Inc. (Viasystems), for total consideration of
 $248,824 in cash and 15,082 shares of TTM common stock with a fair
 value of $149,006, to acquire all of the outstanding shares of
 capital stock and other equity rights of Viasystems. Additionally,
 in connection with the completion of the acquisition, the Company
 assumed and refinanced Viasystems’ debt, which was
 approximately $669,024 as of May 31, 2015. Viasystems was a
 worldwide provider of complex multi-layer rigid, flexible, and
 rigid-flex PCBs and E-M Solutions. Viasystems’ products were
 found in a wide variety of commercial products, including
 automotive engine controls, hybrid converters, automotive
 electronics for navigation, safety, and entertainment,
 telecommunications switching equipment, data networking equipment,
 computer storage equipment, semiconductor test equipment, wind and
 solar energy applications, off-shore drilling equipment,
 communications applications, flight control systems, and complex
 industrial, medical, and other technical instruments.
 Viasystems’ E-M Solutions services can be bundled with its
 PCBs to provide an integrated solution to customers. Viasystems
 operated 15 manufacturing facilities worldwide: eight in the United
 States, five in the People’s Republic of China (China), and
 one each in Canada and Mexico. Viasystems served a diversified
 customer base of over 1,000 customers in various markets throughout
 the world.

[0001193125-15-366187:notes:55]
Bank fees and legal, accounting, and other professional service
 costs associated with the acquisition of Viasystems of $2,065 and
 $1,632 for the quarters ended September 28, 2015 and
 September 29, 2014, respectively, and $32,927 and $1,632 for
 the three quarters ended September 28, 2015 and
 September 29, 2014, respectively, have been expensed and
 recorded as general and administrative expense in the consolidated
 condensed statements of operations.

[0001193125-15-366187:notes:56]
[same as prior period, unchanged from 0001193125-15-284892:notes:61]

[0001193125-15-366187:notes:57]
[same as prior period, unchanged from 0001193125-15-284892:notes:62]

[0001193125-15-366187:notes:58]
[same as prior period, unchanged from 0001193125-15-284892:notes:63]

[0001193125-15-366187:notes:59]
Preliminary Purchase
 Price Allocation

[0001193125-15-366187:notes:60]
[same as prior period, unchanged from 0001193125-15-284892:notes:65]

[0001193125-15-366187:notes:61]
[same as prior period, unchanged from 0001193125-15-284892:notes:66]

[0001193125-15-366187:notes:62]
|  |  | (In thousands) |  |
| Cash |  | $ | 79,662 |  |
| Restricted cash |  |  | 3,510 |  |
| Accounts and notes receivables ($216,703 contractual gross receivables) |  |  | 208,523 |  |
| Inventories |  |  | 132,878 |  |
| Prepaid expenses and other current assets |  |  | 29,659 |  |
| Property, plant and equipment |  |  | 427,269 |  |
| Identifiable intangible assets |  |  | 150,500 |  |
| Goodwill |  |  | 351,135 |  |
| Deposits and other noncurrent assets |  |  | 1,157 |  |
| Current liabilities |  |  | (252,159 | ) |
| Long-term debt |  |  | (669,024 | ) |
| Other liabilities |  |  | (57,980 | ) |
| Noncontrolling interest |  |  | (7,300 | ) |
| Total |  | $ | 397,830 |  |

[0001193125-15-366187:notes:63]
Due to the fact that the Viasystems acquisition has just
 recently occurred, the magnitude of the transaction, and the
 significant information to be obtained and analyzed resides in a
 foreign jurisdiction, the Company’s fair value estimates for
 the purchase price allocation are preliminary and may change during
 the allowable measurement period, which is up to the point the
 Company obtains and analyzes the information that existed as of the
 date of the acquisition necessary to determine the fair values of
 the assets acquired, liabilities assumed and noncontrolling
 interest, but in no case to exceed more than one year from the date
 of acquisition. As of September 28, 2015, the Company had not
 finalized the determination of fair values allocated to various
 assets and liabilities, including, but not limited to, property,
 plant and equipment, identifiable intangible assets, other assets,
 deferred taxes, goodwill, tax uncertainties, income taxes payable,
 other liabilities, and noncontrolling interest. Any changes in the
 fair values of the assets acquired and liabilities assumed during
 the measurement period may result in material adjustments to
 goodwill.

[0001193125-15-366187:notes:64]
[same as prior period, unchanged from 0001193125-15-284892:notes:69]

[0001193125-15-366187:notes:65]
The Company acquired $132,878 of inventories as a result of the
 acquisition. Finished goods were valued at estimated selling prices
 less costs of disposal and a reasonable profit allowance for the
 selling effort. Work-in-process inventory was valued at estimated
 selling prices less costs to complete, costs of disposal and a
 reasonable profit allowance for the completion and selling effort.
 Raw materials were valued at estimated replacement cost.

[0001193125-15-366187:notes:66]
Property, Plant and
 Equipment

[0001193125-15-366187:notes:67]
[same as prior period, unchanged from 0001193125-15-284892:notes:72]

[0001193125-15-366187:notes:68]
Noncontrolling
 Interest

[0001193125-15-366187:notes:69]
Noncontrolling interest consists of a 5% equity interest in a
 manufacturing facility in Huiyang, China. The fair value was
 determined by utilizing a combination of income and market
 comparable approaches. The income approach was used to estimate the
 total enterprise value of the noncontrolling interest by estimating
 discounted future cash flows. The market comparable approach
 indicates the fair value of the noncontrolling interest based on a
 comparison to comparable enterprises in similar lines of business
 that are publicly traded.

[0001193125-15-366187:notes:70]
Identifiable Intangible
 Assets

[0001193125-15-366187:notes:71]
Acquired identifiable intangible assets include customer
 relationships and technology. The fair value of the identifiable
 intangible assets was determined using various income approach
 methods including excess earnings to determine the present value of
 expected future cash flows for each identifiable intangible asset
 based on discount rates which incorporate a risk premium to take
 into account the risks inherent in those expected cash flows. The
 expected cash flows were estimated based on forecasted revenues and
 costs adjusted based on the expectations of market participants.
 The Company used risk adjusted discount rates between 13% and 14%
 to discount the expected future cash flows under the income
 approach. The preliminary estimated fair value assigned to each
 class of intangible assets and the related weighted average
 amortization periods are as follows:

[0001193125-15-366187:notes:72]
|  |  | Estimated fair value |  |  | Weighted-average amortization period |
|  |  | (In thousands) |  |  |  |
| Customer relationships |  | $ | 147,500 |  |  | 8.1 years |
| Technology |  |  | 3,000 |  |  | 3.0 years |
|  |  | $ | 150,500 |  |  |  |

[0001193125-15-366187:notes:73]
[same as prior period, unchanged from 0001193125-15-284892:notes:78]

[0001193125-15-366187:notes:74]
Goodwill represents the excess of the Viasystems purchase price
 over the fair value of assets acquired, liabilities assumed and
 noncontrolling interest. During the quarter ended
 September 28, 2015, goodwill was adjusted to
 reflect:

[0001193125-15-366187:notes:75]
|  | • |  | a decrease in cash by $2,561 and restricted cash by $32 as a result of additional information received regarding the collateralization of specific letters of credit; |

[0001193125-15-366187:notes:76]
|  | • |  | an increase in trade and notes receivable by $390 as a result of additional information received regarding the collectability of such trade and notes receivable; |

[0001193125-15-366187:notes:77]
|  | • |  | a decrease in fair value of inventory by $5,399 resulting from additional information received regarding the valuation of inventory; |

[0001193125-15-366187:notes:78]
|  | • |  | a decrease in current assets of $1,364 resulting primarily from deferred taxes; |

[0001193125-15-366187:notes:79]
|  | • |  | a decrease in property, plant and equipment by $25,567 due to additional information received regarding the valuation of certain property acquired; |

[0001193125-15-366187:notes:80]
|  | • |  | an increase in intangibles by $4,000 resulting from additional information received regarding the valuation of identifiable intangible assets; |

[0001193125-15-366187:notes:81]
|  | • |  | an increase in other noncurrent assets by $485 primarily related to a long-term below market lease asset; |

[0001193125-15-366187:notes:82]
|  | • |  | an increase in current liabilities by $4,319 due to a reassessment of product claims and other amounts due to vendors, and an increase in other noncurrent liabilities by $15,559 primarily related to noncurrent deferred taxes; and |

[0001193125-15-366187:notes:83]
|  | • |  | an increase in noncontrolling interest by $3,277 resulting from additional information received regarding the valuation. |

[0001193125-15-366187:notes:84]
Prior to the Company’s acquisition of Viasystems, the
 Company had two reporting segments based on geographical location
 of operations, North America and Asia Pacific, consistent with the
 nature of its operations. Due to the acquisition, the Company has
 reassessed its reporting segments and determined that it has two
 reporting segments, PCB and E-M Solutions. The excess purchase
 price over the fair value of assets acquired, liabilities assumed
 and noncontrolling interest has been allocated to the PCB reporting
 segment given that Viasystems was primarily a worldwide provider of
 complex multi-layer rigid, flexible, and rigid-flex
 PCBs.

[0001193125-15-366187:notes:85]
[same as prior period, unchanged from 0001193125-15-284892:notes:80]

[0001193125-15-366187:notes:86]
|  | • |  | Strengthens the Company’s Position as a Global Market Leader. The combination of the Company and Viasystems is expected to create one of the largest and most diversified PCB manufacturers in the world. The addition of Viasystems extends the Company’s product technologies, production and development solutions, and customer base. |

[0001193125-15-366187:notes:87]
|  | • |  | Enhances End Market and Customer Diversification and Provides Entry to Attractive Automotive Markets. The Company believes that the combination will expand and diversify the Company’s customer base, end markets served, and product suite. The combination should significantly increase the Company’s presence in the automotive end market and provide, among other cross-selling opportunities, the opportunity to market the Company’s advanced technology PCBs to automotive customers. In addition, the combination is expected to expand the Company’s presence in the Medical, Industrial and Instrumentation, Networking / Communications, and Aerospace / Defense end markets. |

[0001193125-15-366187:notes:88]
The Company believes that these primary factors support the
 amount of goodwill recognized as a result of the purchase price
 paid for Viasystems, in relation to other acquired tangible and
 intangible assets. The goodwill acquired in the acquisition is not
 expected to be deductible for income tax purposes subject to
 certain tax elections that are currently being
 considered.

[0001193125-15-366187:notes:89]
[same as prior period, unchanged from 0001193125-15-284892:notes:84]

[0001193125-15-366187:notes:90]
Included in the consolidated condensed statements of operations
 are net sales from the Viasystems operations of $283,224 and
 $376,418, excluding intercompany sales, for the quarter and three
 quarters ended September 28, 2015, respectively. Net losses
 included in the consolidated condensed statements of operations
 from the Viasystems operations for the quarter and three quarters
 ended September 28, 2015 have not been reported as it is
 impracticable to do so given the integration and other efficiency
 and cost saving measures in process during the third quarter ended
 2015.

[0001193125-15-366187:notes:91]
Pro forma Financial
 Information

[0001193125-15-366187:notes:92]
[same as prior period, unchanged from 0001193125-15-284892:notes:87]

[0001193125-15-366187:notes:93]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 28, 2015 |  |  | September 29, 2014 |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
|  |  | (In thousands, except per share data) |  |
| Net sales |  | $ | 652,005 |  |  | $ | 644,527 |  |  | $ | 1,933,430 |  |  | $ | 1,830,898 |  |
| Net loss attributable to TTM Technologies, Inc. stockholders |  |  | (2,237 | ) |  |  | (14,787 | ) |  |  | (25,033 | ) |  |  | (41,388 | ) |
| Basic loss per share |  | $ | (0.02 | ) |  | $ | (0.15 | ) |  | $ | (0.28 | ) |  | $ | (0.42 | ) |
| Dilutive loss per share |  | $ | (0.02 | ) |  | $ | (0.15 | ) |  | $ | (0.28 | ) |  | $ | (0.42 | ) |

[0001193125-15-366187:notes:94]
[same as prior period, unchanged from 0001193125-15-284892:notes:89]

[0001193125-15-366187:notes:95]
Viasystems Acquisition
 Litigation

[0001193125-15-366187:notes:96]
[same as prior period, unchanged from 0001193125-15-284892:notes:91]


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001193125-15-366187:notes:97]
(3) Restructuring and
 Impairment Charges

[0001193125-15-366187:notes:98]
North America
 Restructuring Activities

[0001193125-15-366187:notes:99]
On
 September 29, 2015, the Company announced a consolidation plan
 that will result in the closure of the Company’s facilities
 in Cleveland, Ohio, Milpitas, California and Juarez, Mexico (the
 Plan). The Plan is part of the Company’s integration strategy
 to improve total plant utilization, operational performance and
 customer focus following its recent acquisition of Viasystems, Inc.
 In accordance with the Plan, the Company will combine its Cleveland
 and Milpitas facilities into its North Jackson, Ohio and Silicon
 Valley, California facilities, respectively, and close its Juarez
 facility.

[0001193125-15-366187:notes:100]
In
 connection with the Plan, during the quarter and three quarters
 ended September 28, 2015, the Company recognized restructuring
 charges of $1,936 in its E-M Solutions segment, which is included
 in other accrued expenses in the September 28, 2015
 consolidated condensed balance sheet. These charges primarily
 represent severance expense associated with the closure of the
 Juarez facility and are expected to be paid out by June 2016.
 Severance charges related to the Cleveland, Ohio and Milpitas,
 California facility closures are expected to be recorded during the
 fourth quarter of 2015, once the plans for certain employee
 transfers to other facilities is finalized.

[0001193125-15-366187:notes:101]
The
 Company estimates that it will incur total charges related to the
 Plan of approximately $15,000 to $20,000.

[0001193125-15-366187:notes:102]
Impairment and Sale of
 Suzhou, China Manufacturing Facility

[0001193125-15-366187:notes:103]
The
 Company ceased manufacturing at its Meadville Aspocomp (Suzhou)
 Electronic Co., Ltd. subsidiary, which held its Suzhou, China
 manufacturing facility, and shut down its operations in
 2013. This subsidiary was included in the Company’s PCB
 operating segment.

[0001193125-15-366187:notes:104]
During
 the three quarters ended September 29, 2014, the Company
 recorded an impairment charge for additional assets, related to
 this manufacturing facility. These assets were originally
 designated to be transferred to other facilities in China as well
 as the disposal of a substantial portion of the assets held for
 sale. As a result, the Company recognized an impairment charge in
 the amount of $1,845 as the carrying value of the assets was
 greater than the market value at the date of disposal.

[0001193125-15-366187:notes:105]
In the
 fourth quarter of 2014, the Company commenced the process of
 selling this subsidiary and classified its net assets as assets
 held for sale at December 29, 2014. Assets held for sale are
 included in other current assets in the December 29, 2014
 consolidated condensed balance sheet.

[0001193125-15-366187:notes:106]
During
 the three quarters ended September 28, 2015, the Company sold
 its Meadville Aspocomp (Suzhou) Electronic Co., Ltd. subsidiary for
 $21,275 and recognized a gain of $2,504.


## us-gaap:EarningsPerShareTextBlock

[0001193125-15-366187:notes:107]
[same as prior period, unchanged from 0001193125-15-284892:notes:92]

[0001193125-15-366187:notes:108]
For the quarter and three quarters ended September 28,
 2015, potential shares of common stock, consisting of stock options
 to purchase approximately 422 shares of common stock at exercise
 prices ranging from $5.78 to $16.82 per share, 2,326 restricted
 stock units, and 275 performance-based restricted stock units were
 not included in the computation of diluted earnings per share
 because the Company incurred a net loss and, as a result, the
 impact would be anti-dilutive.

[0001193125-15-366187:notes:109]
For the quarter and three quarters ended September 29,
 2014, performance-based restricted stock units, restricted stock
 units and stock options to purchase 1,263 and 1,230 shares of
 common stock, respectively, were not considered in calculating
 diluted earnings per share because the options’ exercise
 prices or the total expected proceeds under the treasury stock
 method for performance-based restricted stock units, restricted
 stock units or stock options was greater than the average market
 price of common shares during the period and, therefore, the effect
 would be anti-dilutive.

[0001193125-15-366187:notes:110]
Additionally, for the quarter and three quarters ended
 September 28, 2015 and September 29, 2014, the effect of
 25,940 and 27,970 shares of common stock, respectively, related to
 the Company’s convertible senior notes, and warrants to
 purchase 27,500 shares of common stock, were not included in the
 computation of dilutive earnings per share because the effect would
 be anti-dilutive.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-15-366187:notes:111]
The
 following table summarizes the long-term debt of the Company as of
 September 28, 2015 and December 29, 2014:

[0001193125-15-366187:notes:112]
|  |  | Average Effective Interest Rate as of September 28, 2015 |  | September 28, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  | 6.0% |  | $ | 950,000 |  |  | — |  |  | — |  |
| U.S. ABL revolving loan due May 2020 |  | 1.9% |  |  | 80,000 |  |  | — |  |  | — |  |
| Term loan due September 2016 |  | — |  |  | — |  |  | 2.5% |  | $ | 273,800 |  |
| Other |  | — |  |  | — |  |  | 6.0% |  |  | 4 |  |
|  |  |  |  |  | 1,030,000 |  |  |  |  |  | 273,804 |  |
| Less: Unamortized discount |  |  |  |  | (31,545 | ) |  |  |  |  | — |  |
|  |  |  |  |  | 998,455 |  |  |  |  |  | 273,804 |  |
| Less: current maturities |  |  |  |  | (89,500 | ) |  |  |  |  | (96,204 | ) |
| Long-term debt, less current maturities |  |  |  | $ | 908,955 |  |  |  |  | $ | 177,600 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsGainLossInStatementOfFinancialPerformanceTextBlock

[0001193125-15-366187:notes:113]
[same as prior period, unchanged from 0001193125-15-284892:notes:98]

[0001193125-15-366187:notes:114]
|  |  |  |  |  | For the Quarter Ended |  |
|  |  |  |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
|  |  |  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized into Income |  |
|  |  |  |  |  |  |  |  | (In thousands) |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forwards |  |  | Depreciation expense |  |  | $ | 33 |  |  | $ | (44 | ) |  | $ | — |  |  | $ | (65 | ) |  | $ | (40 | ) |  | $ | — |  |
|  |  |  |  |  |  | $ | 33 |  |  | $ | (44 | ) |  | $ | — |  |  | $ | (65 | ) |  | $ | (40 | ) |  | $ | — |  |

[0001193125-15-366187:notes:115]
|  |  |  |  |  | For the Three Quarters Ended |  |
|  |  |  |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
|  |  |  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/(Loss) Recognized into Income |  |
|  |  |  |  |  |  |  |  | (In thousands) |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forwards |  |  | Depreciation expense |  |  | $ | (20 | ) |  | $ | (129 | ) |  | $ | — |  |  | $ | 55 |  |  | $ | (105 | ) |  | $ | — |  |
|  |  |  |  |  |  | $ | (20 | ) |  | $ | (129 | ) |  | $ | — |  |  | $ | 55 |  |  | $ | (105 | ) |  | $ | — |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-15-366187:notes:116]
[same as prior period, unchanged from 0001193125-15-284892:notes:101]

[0001193125-15-366187:notes:117]
The
 following provides a summary of the components of accumulated other
 comprehensive income (loss) as of September 28, 2015 and
 December 29, 2014:

[0001193125-15-366187:notes:118]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 29, 2014 |  | $ | 32,439 |  |  | $ | (1,424 | ) |  | $ | 31,015 |  |
| Other comprehensive loss before reclassifications |  |  | (16,017 | ) |  |  | (20 | ) |  |  | (16,037 | ) |
| Less: Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (1,786 | ) |  |  | 129 |  |  |  | (1,657 | ) |
| Other comprehensive (loss) income |  |  | (17,803 | ) |  |  | 109 |  |  |  | (17,694 | ) |
| Ending balance at September 28, 2015 |  | $ | 14,636 |  |  | $ | (1,315 | ) |  | $ | 13,321 |  |

[0001193125-15-366187:notes:119]
The
 following provides a summary of reclassifications out of
 accumulated other comprehensive income for the quarter and three
 quarters ended September 28, 2015 and September 29,
 2014:

[0001193125-15-366187:notes:120]
|  |  |  |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |
|  |  |  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Statement of Operations Location |  | September 28, 2015 |  |  | September 29, 2014 |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
| Gain on foreign currency translation |  | Gain on sale of assets, net of tax |  | $ | — |  |  | $ | — |  |  | $ | (1,786 | ) |  | $ | — |  |
| Loss on cash flow hedges |  | Depreciation expense, net of tax |  | $ | 44 |  |  | $ | 40 |  |  | $ | 129 |  |  | $ | 105 |  |
| Loss on available for sale securities |  | Other, net, net of tax |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 83 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsTextBlock

[0001193125-15-366187:notes:121]
[same as prior period, unchanged from 0001193125-15-284892:notes:106]

[0001193125-15-366187:notes:122]
|  |  |  |  |  | Asset / (Liability) Fair Value |  |
|  |  | Balance Sheet Location |  |  | September 28, 2015 |  |  | December 29, 2014 |  |
|  |  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  |  | Other current assets |  |  | $ | 3 |  |  | $ | — |  |
| Foreign exchange contracts |  |  | Other accrued expenses |  |  |  | — |  |  |  | (12 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  |  | Other current assets |  |  |  | 17 |  |  |  | — |  |
| Foreign exchange contracts |  |  | Other accrued expenses |  |  |  | (42 | ) |  |  | (5,050 | ) |
|  |  |  |  |  |  | $ | (22 | ) |  | $ | (5,062 | ) |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-15-366187:notes:123]
(5) Goodwill and
 Definite-lived Intangibles

[0001193125-15-366187:notes:124]
All goodwill relates to the Company’s PCB reportable
 segment. The assignment of goodwill related to the acquisition of
 Viasystems is preliminary and will be completed in conjunction with
 the final purchase price allocation.

[0001193125-15-366187:notes:125]
[same as prior period, unchanged from 0001193125-15-284892:notes:110]

[0001193125-15-366187:notes:126]
Definite-lived
 Intangibles

[0001193125-15-366187:notes:127]
As of September 28, 2015 and December 29, 2014, the
 components of definite-lived intangibles were as
 follows:

[0001193125-15-366187:notes:128]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| September 28, 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 91,492 |  |  | $ | (78,730 | ) |  | $ | 427 |  |  | $ | 13,189 |  |  |  | 9.2 |  |
| Trade name |  |  | 10,302 |  |  |  | (9,863 | ) |  |  | 11 |  |  |  | 450 |  |  |  | 6.0 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 147,500 |  |  |  | (6,249 | ) |  |  | — |  |  |  | 141,251 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (333 | ) |  |  | — |  |  |  | 2,667 |  |  |  | 3.0 |  |
|  |  | $ | 252,294 |  |  | $ | (95,175 | ) |  | $ | 438 |  |  | $ | 157,557 |  |  |  |  |  |
| December 29, 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 91,492 |  |  | $ | (74,486 | ) |  | $ | 445 |  |  | $ | 17,451 |  |  |  | 9.2 |  |
| Trade name |  |  | 10,302 |  |  |  | (8,520 | ) |  |  | 17 |  |  |  | 1,799 |  |  |  | 6.0 |  |
|  |  | $ | 101,794 |  |  | $ | (83,006 | ) |  | $ | 462 |  |  | $ | 19,250 |  |  |  |  |  |

[0001193125-15-366187:notes:129]
The September 28, 2015 and December 29, 2014
 definite-lived intangible balances include foreign currency
 translation adjustments related to foreign subsidiaries which
 operate in currencies other than the U.S. Dollar.

[0001193125-15-366187:notes:130]
All of the definite-lived intangibles are amortized using the
 straight line method of amortization over the useful life, with the
 exception of certain customer relationship intangibles which are
 amortized using an accelerated method of amortization based on cash
 flows. Amortization expense was $6,421 and $1,980 for the quarters
 ended September 28, 2015 and September 29, 2014,
 respectively, and $12,205 and $6,452 for the three quarters ended
 September 28, 2015 and September 29, 2014,
 respectively.


## us-gaap:ScheduleOfCashFlowHedgesIncludedInAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-15-366187:notes:131]
The
 following table provides a summary of the activity associated with
 the designated cash flow hedges reflected in accumulated other
 comprehensive income (loss) for the three quarters ended
 September 28, 2015 and September 29, 2014:

[0001193125-15-366187:notes:132]
|  |  | For the Three Quarters Ended |  |
|  |  | September 28, 2015 |  |  | September 29, 2014 |  |
|  |  | (In thousands) |  |
| Beginning balance unrealized loss, net of tax |  | $ | (1,424 | ) |  | $ | (1,613 | ) |
| Changes in fair value (loss) gain, net of tax |  |  | (20 | ) |  |  | 55 |  |
| Reclassification to earnings |  |  | 129 |  |  |  | 105 |  |
| Ending balance unrealized loss, net of tax |  | $ | (1,315 | ) |  | $ | (1,453 | ) |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-15-366187:notes:133]
[same as prior period, unchanged from 0001193125-15-284892:notes:118]

[0001193125-15-366187:notes:134]
TTM
 Technologies, Inc. (the Company or TTM) is a major global printed
 circuit board (PCB) manufacturer, focusing on quick-turn and
 technologically advanced PCBs, backplane assemblies and
 electro-mechanical solutions (E-M Solutions). The Company provides
 time-to-market and advanced technology products and offers a
 one-stop manufacturing solution to customers from engineering
 support to prototype development through final volume production.
 This one-stop manufacturing solution allows the Company to align
 technology developments with the diverse needs of the
 Company’s customers and to enable them to reduce the time
 required to develop new products and bring them to
 market.

[0001193125-15-366187:notes:135]
The
 Company serves a diversified customer base in various markets
 throughout the world, including manufacturers of
 networking/communications infrastructure products, touchscreen
 tablets and smartphones, as well as the aerospace and defense,
 automotive, high-end computing, and industrial/medical industries.
 The Company’s customers include both original equipment
 manufacturers (OEMs) and electronic manufacturing services (EMS)
 providers.

[0001193125-15-366187:notes:136]
[same as prior period, unchanged from 0001193125-15-284892:notes:121]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-366187:notes:137]
[same as prior period, unchanged from 0001193125-15-284892:notes:122]

[0001193125-15-366187:notes:138]
[same as prior period, unchanged from 0001193125-15-284892:notes:123]

[0001193125-15-366187:notes:139]
During
 the quarter ended September 28, 2015, the Company’s
 effective tax rate was impacted by discrete tax expense of $530
 mainly due to the change in estimates resulting from the completion
 of the Company’s 2014 income tax returns and interest related
 to uncertain tax positions. No tax benefit was recorded on the
 losses incurred in the U.S. and certain foreign jurisdictions as a
 result of corresponding increases in the valuation allowances in
 these jurisdictions.

[0001193125-15-366187:notes:140]
For
 the three quarters ended September 28, 2015, the
 Company’s effective tax rate was further impacted by
 (i) a discrete tax benefit resulting from the retroactive
 approval of the high technology enterprise status for certain
 subsidiaries in China; (ii) a full valuation allowance against
 the Company’s existing U.S. net deferred tax assets; and
 (iii) reversal of deferred tax liabilities related to the
 Company’s decision to indefinitely reinvest the foreign
 earnings attributable to the backplane assembly facility in
 Shanghai, China.

[0001193125-15-366187:notes:141]
Certain foreign losses generated are not more than likely to be
 realizable, and thus, no income tax benefit has been recognized on
 these losses. The Company’s foreign earnings attributable to
 certain subsidiaries in China will be indefinitely reinvested in
 such foreign jurisdictions and, therefore, no deferred tax
 liabilities for U.S. income taxes on undistributed earnings are
 recorded.

[0001193125-15-366187:notes:142]
Certain entities in China operated under tax incentives
 effective through 2016. The tax incentives decreased Chinese taxes
 by $1,053 and $4,755, which increased both basic and diluted
 earnings per share by $0.01 and $0.05 for the quarter and three
 quarters ended September 28, 2015, respectively.

[0001193125-15-366187:notes:143]
As a
 result of the acquisition of Viasystems, the Company’s
 unrecognized tax benefit including interest and penalties increased
 by $29,444. As of September 28, 2015, the Company had not
 finalized the determination of fair values allocated to various
 assets and liabilities, including, deferred taxes, tax
 uncertainties, and income taxes payable. Any changes in the fair
 values of these liabilities assumed during the measurement period
 may result in material adjustments to goodwill.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-366187:notes:144]
(13) Commitments and
 Contingencies

[0001193125-15-366187:notes:145]
Legal
 Matters

[0001193125-15-366187:notes:146]
The
 Company is subject to various legal matters, which it considers
 normal for its business activities. While the Company currently
 believes that the amount of any reasonably possible loss for known
 matters would not be material to the Company’s financial
 condition, the outcome of these actions is inherently difficult to
 predict. In the event of an adverse outcome, the ultimate potential
 loss could have a material adverse effect on the Company’s
 financial condition or results of operations in a particular
 period. The Company has accrued amounts for its loss contingencies
 which are probable and estimable as of September 28, 2015 and
 December 29, 2014. However, these amounts are not material to
 the consolidated condensed financial statements of the
 Company.

[0001193125-15-366187:notes:147]
Class Action Complaints
 related to Viasystems Acquisition

[0001193125-15-366187:notes:148]
Since
 the public announcement on September 22, 2014 of the execution
 of the Merger Agreement, Viasystems, TTM, and the members of the
 Viasystems Board have been named as defendants in two putative
 class action complaints challenging the acquisition of Viasystems.
 The first lawsuit, filed in the Circuit Court of St. Louis County,
 Missouri on September 30, 2014 (the Missouri Lawsuit), and the
 second lawsuit, filed in the Court of Chancery of the State of
 Delaware on October 13, 2014 (the Delaware Lawsuit and,
 together with the Missouri Lawsuit, the Lawsuits), generally allege
 that the Merger fails to properly value Viasystems, that the
 individual defendants breached their fiduciary duties in approving
 the Merger Agreement, and that those breaches were aided and
 abetted by TTM and Viasystems.

[0001193125-15-366187:notes:149]
The
 Delaware Lawsuit specifically alleges, among other allegations,
 that (1) the Viasystems Board breached its fiduciary duties
 by: (a) agreeing to the Merger for grossly inadequate
 consideration, (b) agreeing to lock up the Merger with deal
 protection devices that prevent other bidders from making a
 successful competing offer for Viasystems, and
 (c) participating in a transaction where the loyalties of the
 Viasystems Board and management are divided; (2) the voting
 agreements entered into between the Company and certain of
 Viasystems’ significant stockholders prevent Viasystems
 stockholders from providing a meaningful vote on the proposal to
 adopt the Merger; and (3) that those breaches of fiduciary
 duties were aided and abetted by TTM, Merger Sub, and Viasystems.
 Further, the Missouri Lawsuit specifically alleges, among other
 allegations, that (1) the proposed Merger is unfair and the
 consideration to be paid in connection with the Merger is
 inadequate; (2) the Viasystems Board and Viasystems’
 management have a conflict of interest due to the cash pool bonus
 and change in control payments to be made to certain executive
 officers and key employees if the Merger is consummated; and
 (3) the Merger Agreement contains impermissible deal
 protection devices.

[0001193125-15-366187:notes:150]
The
 Lawsuits seek injunctive relief to enjoin the defendants from
 completing the Merger on the agreed-upon terms, rescinding, to the
 extent already implemented, the Merger Agreement or any of the
 terms therein, costs and disbursements and attorneys’ and
 experts’ fees and costs, as well as other equitable relief as
 the respective court deems proper. The Delaware Lawsuit also seeks:
 (1) in the event the Merger is consummated prior to the entry
 of the court’s final judgment, rescissory damages as an
 alternative to rescission, and (2) an accounting by all
 defendants to the plaintiff and other members of the class for all
 damages caused by the defendants and for all profits and any
 special benefits obtained as a result of their alleged breaches of
 their fiduciary duties.

[0001193125-15-366187:notes:151]
On
 January 6, 2015, the parties to the Missouri Lawsuit entered
 into a Memorandum of Understanding (MOU) with respect to a proposed
 settlement that will terminate both Lawsuits upon entry of the
 final judgment. Pursuant to the terms of the MOU, the parties
 entered into a stipulation of settlement on May 22, 2015, that
 remains subject to customary conditions, including court approval.
 The settlement agreement does not require the defendants to pay any
 monetary consideration to the proposed settlement class. The
 settlement agreement provides for payment of attorneys’ fees
 of the plaintiffs and reimbursement of expenses, in the amount to
 be determined by the court, but not to exceed $550. If the
 stipulation of settlement is approved by the court, it will fully
 and finally resolve all of the claims asserted, or that could have
 been asserted, in the Lawsuit against the defendants, and provide a
 release by the proposed settlement class of all claims against the
 defendants and their respective affiliates and agents in connection
 with the Merger.

[0001193125-15-366187:notes:152]
The
 proposed settlement is subject to the preliminary approval of the
 court as well as the court’s final approval after notice of
 the terms of the settlement has been provided to the proposed
 settlement class. Timing of the approval process is dependent on
 the court’s calendar. Members of the proposed settlement
 class will have the right to object to the settlement in writing to
 the court once the court has set a hearing for final
 approval.

[0001193125-15-366187:notes:153]
Environmental
 Matters

[0001193125-15-366187:notes:154]
The
 process to manufacture PCBs requires adherence to city, county,
 state, federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States, Canada and Mexico comply in all
 material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted
 new rules and regulations governing environmental issues. An
 update to the Chinese environmental waste water law was issued in
 late 2012, but allows for an interim period in which plants subject
 to such law may install equipment that meets the new regulatory
 regime. Some of the Company’s plants in China are not yet in
 full compliance with the updated environmental
 regulations. The Company believes it has developed plans
 acceptable to the Chinese government and is in the process of
 implementing these plans. The Company does not anticipate any
 immediate risk of government fines or temporary closure of its
 Chinese plants. The Company has established and enacted an
 investment plan related to the efforts to come into full compliance
 with the new regulations. The 2015 capital expenditure costs
 expected for these plans are included in the Company’s
 capital expenditure projections.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-15-366187:notes:155]
(17) Related Party
 Transactions

[0001193125-15-366187:notes:156]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $21,167 and $11,469 for the quarters ended
 September 28, 2015 and September 29, 2014, respectively,
 and $43,335 and $36,647 for the three quarters ended
 September 28, 2015 and September 29, 2014,
 respectively.

[0001193125-15-366187:notes:157]
Dongguan Shengyi Electronics Ltd. (SYE) is also a related party
 as it is a wholly owned subsidiary of an entity in which a
 significant shareholder of the Company holds an equity interest.
 The Company sells PCB’s to SYE and purchases PCB’s
 including various services in relation to PCB manufacturing from
 SYE. Sales to SYE for the quarters ended September 28, 2015
 and September 29, 2014 were $1,042 and $2,282, respectively,
 and $3,867 and $21,535 for the three quarters ended
 September 28, 2015 and September 29, 2014, respectively.
 Purchases of PCB including various services in relation to PCB
 manufacturing for the quarters ended September 28, 2015 and
 September 29, 2014 were $344 and $78, respectively, and $1,840
 and $550 for the three quarters ended September 28, 2015 and
 September 29, 2014, respectively.

[0001193125-15-366187:notes:158]
As of
 September 28, 2015 and December 29, 2014, the
 Company’s consolidated balance sheets included $31,425 and
 $17,950, respectively, in accounts payable due to, and $2,025 and
 $4,934, respectively, in accounts receivable due from a related
 party for the purchase of laminate and prepreg and various PCB
 manufacturing services, and sales of PCBs to SYE, as mentioned
 above.


## us-gaap:LongTermDebtTextBlock

[0001193125-15-366187:notes:159]
(6)
 Long-term Debt and Letters of Credit

[0001193125-15-366187:notes:160]
The following table summarizes the long-term debt of the
 Company as of September 28, 2015 and December 29,
 2014:

[0001193125-15-366187:notes:161]
The fiscal calendar maturities of long-term debt through 2019
 and thereafter are as follows:

[0001193125-15-366187:notes:162]
New
 borrowings

[0001193125-15-366187:notes:163]
On May 31, 2015, in conjunction with the acquisition of
 Viasystems, the Company entered into a $950,000 Term Loan Credit
 Agreement (Term Loan). Additionally, the Company entered into a
 $150,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and a
 $150,000 Asia Asset-Based Lending Credit agreement (Asia ABL)
 (collectively the ABL Revolving Loans). The Company drew $80,000 of
 the U.S. ABL at the closing of the acquisition of
 Viasystems.

[0001193125-15-366187:notes:164]
The Term Loan was issued at a discount at 96.5% and bears
 interest at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus
 an applicable interest margin of 5.0%, or JP Morgan Chase
 Bank’s prime rate, with a 2% floor, plus a margin of 4%, at
 the Company’s option. At September 28, 2015, the
 weighted average interest rate on the outstanding borrowings under
 the Term Loan was 6.0%. There is no provision, other than an event
 of default, for the interest margin to increase. The Term Loan will
 mature on May 31, 2021. The Term Loan is secured by a
 significant amount of the assets of the Company and its domestic
 subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and is structurally
 senior to the Company’s convertible senior notes. See Note 7
 Convertible Senior Notes.

[0001193125-15-366187:notes:165]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $150,000, a letter of credit
 facility of up to $75,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $150,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 175 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 75 basis points, at the Company’s option. At
 September 28, 2015, the weighted average interest rate on the
 outstanding borrowings under the U.S. ABL was 1.9%. Beginning in
 2016, the applicable margin can vary based on the remaining
 availability of the facility, from 150 to 200 basis points for
 LIBOR-based loans and from 50 to 100 basis points for JP Morgan
 Chase Bank’s prime rate-based loans. Other than availability
 and an event of default, there are no other provisions for the
 interest margin to increase. The U.S. ABL will mature on
 May 31, 2020. Loans made under the U.S. ABL are secured first
 by all of the Company’s domestic cash, receivables and
 inventories as well as by a second position against a significant
 amount of the assets of the Company and its domestic subsidiaries
 and a pledge of 65% of voting stock of the Company’s first
 tier foreign subsidiaries and are structurally senior to the
 Company’s convertible senior notes. See Note 7 Convertible
 Senior Notes. At September 28, 2015, $80,000 of the U.S. ABL
 was outstanding and classified as short-term debt.

[0001193125-15-366187:notes:166]
The Company and its domestic subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Term
 Loan and U.S. ABL related obligations.

[0001193125-15-366187:notes:167]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of the Company’s Asia Pacific cash and
 receivables and are structurally senior to the Company’s
 domestic obligations, including the convertible senior notes. See
 Note 7 Convertible Senior Notes. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At September 28, 2015, none of the
 Asia ABL was outstanding.

[0001193125-15-366187:notes:168]
The Company is required to make scheduled payments of the
 outstanding Term Loan balance on a quarterly basis beginning
 October 1, 2015. On October 1, 2015, the first scheduled
 principal payment of $2,375 was made. Based on certain parameters
 defined in the Term Loan agreement, the Company may be required to
 make an additional principal payment on an annual basis. Any other
 outstanding balances under the Term Loan are due at the maturity
 date of May 31, 2021. Borrowings under the Term Loan are
 subject to various financial and operating covenants including
 maintaining a maximum total leverage ratio. Under the occurrence of
 certain events, the U.S. ABL and the Asia ABL are subject to
 various financial and operational covenants, including maintaining
 minimum fixed charge coverage ratios. At September 28, 2015,
 the Company was in compliance with the covenants under the Term
 Loan, the U.S. ABL and the Asia ABL.

[0001193125-15-366187:notes:169]
As of September 28, 2015, remaining unamortized debt
 discount and debt issuance costs were $31,545 and $32,168,
 respectively. The debt discount is recorded as a reduction of the
 Term Loan and is amortized over the duration of the Term Loan. The
 debt issuance costs are included in other non-current assets and
 are amortized to interest expense over the duration of the Term
 Loan and ABL Revolving Loans. The debt discount and the debt
 issuance costs related to the Term Loan are amortized into interest
 expense using an effective interest rate of 7.49%. The debt
 issuance costs related to the ABL Revolving Loans are amortized
 into interest expense using the straight line method of
 amortization over the duration of the ABL Revolving Loans. At
 September 28, 2015, the remaining amortization period for the
 unamortized debt discount and debt issuance costs was 5.6
 years.

[0001193125-15-366187:notes:170]
The Company is required to pay a commitment fee of
 0.375% per annum on any unused portion of the U.S. ABL or Asia
 ABL. The U.S. ABL commitment fee may vary from 0.25% to 0.375%
 based on utilization levels. Additionally, the Company also paid
 commitment fees of 0.5% per annum on the unused portion of the
 $90,000 senior secured revolving loan associated with the
 terminated 2012 credit agreement during the quarter and two
 quarters ended June 29, 2015. The Company incurred total
 commitment fees related to unused borrowing availability of $200
 and $155 for the quarters ended September 28, 2015 and
 September 29, 2014, respectively, and $565 and $439 for the
 three quarters ended September 28, 2015 and September 29,
 2014, respectively. As of September 28, 2015, the outstanding
 amount of the Term Loan was $950,000, of which $9,500 is due for
 repayment within one year and is included as short-term debt, with
 the remaining $940,500 included as long-term debt. Additionally,
 $80,000 of the U.S. ABL and none of the Asia ABL was outstanding as
 of September 28, 2015. Available borrowing capacity under the
 U.S. ABL and Asia ABL was $65,444 and $142,224, which considers the
 letter of credit outstanding of $4,556 and $7,776 mentioned below,
 respectively, at September 28, 2015.

[0001193125-15-366187:notes:171]
Letters
 of Credit

[0001193125-15-366187:notes:172]
The Company has up to $75,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively, as
 mentioned above. As of September 28, 2015, letters of credit
 in the amount of $4,556 were outstanding under the U.S. ABL and
 $7,776 were outstanding under the Asia ABL. The Company has other
 standby letters of credit outstanding in the amount of $4,832,
 which expire between October 4, 2015 and May 16, 2016.
 These other standby letters of credit are securitized by cash
 collateral. As such, the Company has recorded such cash as
 restricted on the consolidated condensed balance sheet as of
 September 28, 2015. There were no such arrangements at
 December 29, 2014.

[0001193125-15-366187:notes:173]
Other
 Credit Facility

[0001193125-15-366187:notes:174]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $36,100 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in December
 2015. As of September 28, 2015, the Chinese Revolver had not
 been drawn upon.

[0001193125-15-366187:notes:175]
Loss on
 Extinguishment of Debt

[0001193125-15-366187:notes:176]
The Company became a party to its current Term Loan and ABL
 Revolving Loans during the second quarter ended June 29, 2015
 in order to refinance and pay in full the remaining outstanding
 amount of $225,700 under an existing 2012 credit agreement, as well
 as to finance the acquisition of Viasystems and refinance
 Viasystems’ outstanding debt. As a result, the Company
 recognized losses of approximately $802 during the three quarters
 ended September 28, 2015 resulting from the write off of the
 remaining unamortized debt issuance costs associated with the
 terminated 2012 credit agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-15-366187:notes:177]
[same as prior period, unchanged from 0001193125-15-284892:notes:162]

[0001193125-15-366187:notes:178]
[same as prior period, unchanged from 0001193125-15-284892:notes:163]

[0001193125-15-366187:notes:179]
The
 Company enters into foreign currency forward contracts to mitigate
 the impact of changes in foreign currency exchange rates and to
 reduce the volatility of purchases and other obligations generated
 in currencies other than the functional currencies. The
 Company’s foreign subsidiaries may at times purchase forward
 exchange contracts to manage their foreign currency risks in
 relation to certain purchases of machinery denominated in foreign
 currencies other than the Company’s foreign functional
 currency. The notional amount of the foreign exchange contracts as
 of September 28, 2015 and December 29, 2014 was
 approximately $1,614 and $29,142, respectively. The Company has
 designated certain of these foreign exchange contracts as cash flow
 hedges.

[0001193125-15-366187:notes:180]
The
 Company expects that approximately $172 of expense will be
 reclassified into the statement of operations, net of tax, in the
 next 12 months.

[0001193125-15-366187:notes:181]
The
 net loss recognized in other, net in the consolidated condensed
 statements of operations related to foreign exchange contracts not
 designated as hedges was $102 and $2,213 for the quarters ended
 September 28, 2015 and September 29, 2014, respectively,
 and $360 and $1,259 for the three quarters ended September 28,
 2015 and September 29, 2014, respectively.


## ttmi:ConvertibleSeniorNotesTextBlock

[0001193125-15-366187:notes:182]
[same as prior period, unchanged from 0001193125-15-284892:notes:167]

[0001193125-15-366187:notes:183]
Convertible Senior
 Notes due 2020

[0001193125-15-366187:notes:184]
The Company issued 1.75% convertible senior notes due
 December 15, 2020, in a public offering for an aggregate
 principal amount of $250,000. The convertible senior notes bear
 interest at a rate of 1.75% per annum. Interest is payable
 semiannually in arrears on June 15 and December 15 of
 each year. The convertible senior notes are senior unsecured
 obligations and rank equally to the Company’s future
 unsecured senior indebtedness and are senior in right of payment to
 any of the Company’s future subordinated
 indebtedness.

[0001193125-15-366187:notes:185]
Convertible Senior
 Notes due 2015

[0001193125-15-366187:notes:186]
The Company issued 3.25% convertible senior notes due on
 May 15, 2015, in a public offering for an aggregate principal
 amount of $175,000. During the three quarters ended
 September 28, 2015, the outstanding principal of $32,395 plus
 accrued interest was paid in full.

[0001193125-15-366187:notes:187]
As of September 28, 2015 and December 29, 2014, the
 following summarizes the liability and equity components of the
 convertible senior notes:

[0001193125-15-366187:notes:188]
|  |  | As of September 28, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |  | Principal |  |  | Unamortized Discount |  |  | Net Carrying Amount |  |
|  |  | (in thousands) |  |
| Liability components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 250,000 |  |  | $ | (47,355 | ) |  | $ | 202,645 |  |  | $ | 250,000 |  |  | $ | (52,958 | ) |  | $ | 197,042 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 32,395 |  |  |  | (554 | ) |  |  | 31,841 |  |
| Total |  | $ | 250,000 |  |  | $ | (47,355 | ) |  | $ | 202,645 |  |  | $ | 282,395 |  |  | $ | (53,512 | ) |  | $ | 228,883 |  |
|  |  | As of September 28, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
| Total |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |

[0001193125-15-366187:notes:189]
The components of interest expense resulting from the
 convertible senior notes for the quarter and three quarters ended
 September 28, 2015 and September 29, 2014 were as
 follows:

[0001193125-15-366187:notes:190]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | September 28, 2015 |  |  | September 29, 2014 |  |  | September 28, 2015 |  |  | September 29, 2014 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,273 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 263 |  |  |  | 395 |  |  |  | 790 |  |
|  |  | $ | 1,094 |  |  | $ | 1,357 |  |  | $ | 3,676 |  |  | $ | 4,063 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 1,898 |  |  | $ | 1,779 |  |  | $ | 5,603 |  |  | $ | 5,294 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 352 |  |  |  | 554 |  |  |  | 1,036 |  |
|  |  | $ | 1,898 |  |  | $ | 2,131 |  |  | $ | 6,157 |  |  | $ | 6,330 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 190 |  |  | $ | 178 |  |  | $ | 561 |  |  | $ | 531 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | 36 |  |  |  | 56 |  |  |  | 104 |  |
|  |  | $ | 190 |  |  | $ | 214 |  |  | $ | 617 |  |  | $ | 635 |  |

[0001193125-15-366187:notes:191]
As of September 28, 2015 and December 29, 2014,
 remaining unamortized debt issuance costs included in other
 non-current assets were $4,746 and $5,363, respectively. The debt
 issuance costs and debt discount are being amortized to interest
 expense over the term of the convertible senior notes using the
 effective interest rate method. At September 28, 2015, the
 remaining weighted average amortization period for the unamortized
 senior convertible note discount and debt issuance costs was
 5.2 years.

[0001193125-15-366187:notes:192]
For the quarter and three quarters ended September 28,
 2015 and September 29, 2014, the amortization of debt discount
 and debt issuance costs for the 2020 convertible senior notes and
 the 2015 convertible senior notes was based on an effective
 interest rate of 6.48% and 8.37%, respectively.


## ttmi:DistributionOfProfitsDisclosureTextBlock

[0001193125-15-366187:notes:193]
(18) Distribution of
 Profits

[0001193125-15-366187:notes:194]
As
 stipulated by the relevant laws and regulations of China applicable
 to the Company’s subsidiaries in China, each of such
 subsidiaries is required to make appropriations from its net income
 as determined in accordance with accounting principles and the
 relevant financial regulations of China (PRC GAAP) to a
 non-distributable reserve, also referred to as statutory surplus
 reserve. The appropriations to the statutory surplus reserve are
 required to be made at not less than 10% of the profit after tax as
 determined under PRC GAAP and required until the balance reaches
 50% of its registered capital. The statutory surplus reserve is
 used to offset future or past losses. These Chinese subsidiaries
 may, upon a resolution passed by their respective shareholders,
 convert the statutory surplus reserve into capital. A decrease in
 such appropriations of approximately $320 was made to the statutory
 surplus reserve of these Chinese subsidiaries for the quarter ended
 September 28, 2015.
