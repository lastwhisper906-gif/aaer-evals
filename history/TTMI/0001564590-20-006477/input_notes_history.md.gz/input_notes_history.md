# TTMI note change history — 0001564590-19-030026 → 0001564590-19-041722


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-11-07):
[0001564590-19-041722:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 30, 2019 and December 31, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2019-08-07, similarity 0.9914):
[0001564590-19-030026:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of July 1, 2019 and December 31, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-11-07):
[0001564590-19-041722:note_history:2]
The Company adopted the new lease standard as of January 1, 2019 and utilized the retrospective cumulative effect adjustment transition method with a cumulative effect adjustment being recorded as of the adoption date. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated condensed balance sheet as of December 31, 2018 and the consolidated condensed statement of operations for the quarter and three quarters ended October 1, 2018. The Company implemented internal controls and key system functionality to enable the preparation of financial information on adoption. The Company elected certain available practical expedients including the package of practical expedients permitted under the transition guidance within the new standard, which among other things, allowed the Company to carry forward the historical lease classification. Additionally, the Company elected an accounting policy to not record ROU assets and lease liabilities for leases with an initial term of twelve months or less on its consolidated condensed balance sheet.

- changed (2019-11-07):
[0001564590-19-041722:note_history:3]
The adoption of the new accounting guidance did not have a material impact to the consolidated condensed statement of operations for the quarter and three quarters ended September 30, 2019, or the consolidated condensed statement of cash flows for the three quarters ended September 30, 2019. See Note 3 for further details.
  (was, 2019-08-07, similarity 0.7148):
[0001564590-19-030026:note_history:3]
The adoption of the new accounting guidance did not have a material impact to the consolidated condensed statement of operations for the quarter and two quarters ended July 1, 2019, or the consolidated condensed statement of cash flows for the two quarters ended July 1, 2019. See Note 3 for further details.

- added (2019-11-07):
[0001564590-19-041722:note_history:4]
In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments. Apart from the amendments to ASU 2016-13 as mentioned below, the ASU also included subsequent amendments to ASU 2016-01, which we adopted on January 2, 2018. The guidance in relation to the amendments to ASU 2016-01 is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures.

- changed (2019-11-07):
[0001564590-19-041722:note_history:5]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial
  (was, 2019-08-07, similarity 0.7507):
[0001564590-19-030026:note_history:5]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. This ASU is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures.

- added (2019-11-07):
[0001564590-19-041722:note_history:6]
Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments—Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. All of these ASUs are effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures.

- removed (2019-11-07):
[0001564590-19-030026:note_history:7]
The Company adopted the new lease standard as of January 1, 2019 and utilized the retrospective cumulative effect adjustment transition method with a cumulative effect adjustment being recorded as of the adoption date. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated condensed balance sheet as of December 31, 2018 and the consolidated condensed statement of operations for the quarter and two quarters ended July 2, 2018. The Company implemented internal controls and key system functionality to enable the preparation of financial information on adoption. The Company elected certain available practical expedients including the package of practical expedients permitted under the transition guidance within the new standard, which among other things, allowed the Company to carry forward the historical lease classification. Additionally, the Company elected an accounting policy to not record ROU assets and lease liabilities for leases with an initial term of twelve months or less on its consolidated condensed balance sheet.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-07):
[0001564590-19-041722:note_history:8]
The components of interest expense resulting from the Convertible Senior Notes for the quarter and three quarters ended September 30, 2019 and October 1, 2018 were as follows:
  (was, 2019-08-07, similarity 0.9068):
[0001564590-19-030026:note_history:8]
The components of interest expense resulting from the Convertible Senior Notes for the quarter and two quarters ended July 1, 2019 and July 2, 2018 were as follows:

- added (2019-11-07):
[0001564590-19-041722:note_history:9]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, |  |  | October 1, |  |  | September 30, |  |  | October 1, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,457 |  |  | $ | 2,303 |  |  | $ | 7,254 |  |  | $ | 6,800 |  |
| Amortization of debt issuance costs |  | $ | 246 |  |  | $ | 231 |  |  | $ | 727 |  |  | $ | 682 |  |

- removed (2019-11-07):
[0001564590-19-030026:note_history:10]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 1, |  |  | July 2, |  |  | July 1, |  |  | July 2, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,418 |  |  | $ | 2,267 |  |  | $ | 4,797 |  |  | $ | 4,497 |  |
| Amortization of debt issuance costs |  | $ | 243 |  |  | $ | 227 |  |  | $ | 481 |  |  | $ | 451 |  |


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-07):
[0001564590-19-041722:note_history:11]
As of September 30, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes were as follows:
  (was, 2019-08-07, similarity 0.964):
[0001564590-19-030026:note_history:11]
As of July 1, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes were as follows:

- changed (2019-11-07):
[0001564590-19-041722:note_history:12]
|  |  | As of September 30, 2019 |  |  |  | As of December 31, 2018 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,986 |  |  | $ | 2,113 |  |  |  | 4.66 |  | % |  | $ | 8,229 |  |  | $ | 2,489 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,509 |  |  | — |  |  |  | 5.92 |  |  |  |  | 6,071 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 1,245 |  |  |  | 12,423 |  |  |  | 6.48 |  |  |  |  | 1,972 |  |  |  | 19,678 |  |  |  | 6.48 |  |  |
|  |  | $ | 13,740 |  |  | $ | 14,536 |  |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |  |
  (was, 2019-08-07, similarity 0.9895):
[0001564590-19-030026:note_history:12]
|  |  | As of July 1, 2019 |  |  |  | As of December 31, 2018 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 7,303 |  |  | $ | 2,210 |  |  |  | 4.66 |  | % |  | $ | 8,229 |  |  | $ | 2,489 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,700 |  |  | — |  |  |  | 5.92 |  |  |  |  | 6,071 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 1,491 |  |  |  | 14,880 |  |  |  | 6.48 |  |  |  |  | 1,972 |  |  |  | 19,678 |  |  |  | 6.48 |  |  |
|  |  | $ | 14,494 |  |  | $ | 17,090 |  |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-07):
[0001564590-19-041722:note_history:13]
As of September 30, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:
  (was, 2019-08-07, similarity 0.9574):
[0001564590-19-030026:note_history:13]
As of July 1, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:

- added (2019-11-07):
[0001564590-19-041722:note_history:14]
|  |  | As of September 30, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

- removed (2019-11-07):
[0001564590-19-030026:note_history:15]
|  |  | As of July 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-07):
[0001564590-19-041722:note_history:16]
The following table summarizes the long-term debt of the Company as of September 30, 2019 and December 31, 2018:
  (was, 2019-08-07, similarity 0.9347):
[0001564590-19-030026:note_history:16]
The following table summarizes the long-term debt of the Company as of July 1, 2019 and December 31, 2018:

- changed (2019-11-07):
[0001564590-19-041722:note_history:17]
|  | Interest Rate as of September 30, 2019 |  |  | Principal Outstanding as of September 30, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  | (In thousands, except interest rates) |  |
| Term Loan due September 2024 |  | 4.52 |  | % | $ | 805,879 |  |  |  | 5.00 |  | % | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due June 2024 |  | 3.27 |  |  |  | 40,000 |  |  |  | 4.00 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  | 3.42 |  |  |  | 30,000 |  |  |  | 3.90 |  |  |  | 30,000 |  |
|  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  | (14,536 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  | (13,740 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  | 1,472,578 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  | $ | 1,472,578 |  |  |  |  |  |  | $ | 1,462,425 |  |
  (was, 2019-08-07, similarity 0.9709):
[0001564590-19-030026:note_history:17]
|  | Interest Rate as of July 1, 2019 |  |  | Principal Outstanding as of July 1, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  | (In thousands, except interest rates) |  |
| Term Loan due September 2024 |  | 4.89 |  | % | $ | 805,879 |  |  |  | 5.00 |  | % | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due June 2024 |  | 3.76 |  |  |  | 40,000 |  |  |  | 4.00 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  | 3.79 |  |  |  | 30,000 |  |  |  | 3.90 |  |  |  | 30,000 |  |
|  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  | (17,090 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  | (14,494 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  | 1,469,270 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  | $ | 1,469,270 |  |  |  |  |  |  | $ | 1,462,425 |  |

- changed (2019-11-07):
[0001564590-19-041722:note_history:18]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $805,879 as of September 30, 2019 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR plus an applicable interest margin of 2.5%, or an alternate base rate (as defined in the Term Loan Credit Agreement) plus an applicable margin of 1.5%. As of September 30, 2019, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.52%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.
  (was, 2019-08-07, similarity 0.9894):
[0001564590-19-030026:note_history:18]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $805,879 as of July 1, 2019 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR plus an applicable interest margin of 2.5%, or an alternate base rate (as defined in the Term Loan Credit Agreement) plus an applicable margin of 1.5%. As of July 1, 2019, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.89%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

- changed (2019-11-07):
[0001564590-19-041722:note_history:19]
The Company maintains 1.75% Convertible Senior Notes in the amount of $249,975 due December 15, 2020. The Convertible Senior Notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes are senior unsecured obligations and would rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the Convertible Senior Notes.
  (was, 2019-08-07, similarity 0.8997):
[0001564590-19-030026:note_history:19]
The Company maintains 1.75% Convertible Senior Notes in the amount of $249,975 due December 15, 2020. The Convertible Senior Notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes are senior unsecured obligations and would rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness.

- changed (2019-11-07):
[0001564590-19-041722:note_history:20]
As of September 30, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:
  (was, 2019-08-07, similarity 0.9574):
[0001564590-19-030026:note_history:20]
As of July 1, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:

- added (2019-11-07):
[0001564590-19-041722:note_history:21]
|  |  | As of September 30, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

- changed (2019-11-07):
[0001564590-19-041722:note_history:22]
The components of interest expense resulting from the Convertible Senior Notes for the quarter and three quarters ended September 30, 2019 and October 1, 2018 were as follows:
  (was, 2019-08-07, similarity 0.9068):
[0001564590-19-030026:note_history:22]
The components of interest expense resulting from the Convertible Senior Notes for the quarter and two quarters ended July 1, 2019 and July 2, 2018 were as follows:

- added (2019-11-07):
[0001564590-19-041722:note_history:23]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, |  |  | October 1, |  |  | September 30, |  |  | October 1, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,457 |  |  | $ | 2,303 |  |  | $ | 7,254 |  |  | $ | 6,800 |  |
| Amortization of debt issuance costs |  | $ | 246 |  |  | $ | 231 |  |  | $ | 727 |  |  | $ | 682 |  |

- changed (2019-11-07):
[0001564590-19-041722:note_history:24]
The U.S. ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $50,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 125 basis points or an alternate base rate (defined as the greater of the prime rate, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%) subject to a 1.0% floor, plus an applicable margin of 25 basis points, at the Company’s option. As of September 30, 2019, the interest rate on the outstanding borrowings under the U.S. ABL was 3.27%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for LIBOR-based loans and from 25 to 50 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on June 3, 2024. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of September 30, 2019, $40,000 under the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.
  (was, 2019-08-07, similarity 0.9905):
[0001564590-19-030026:note_history:24]
The U.S. ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $50,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 138 basis points or an alternate base rate (defined as the greater of the prime rate, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%) subject to a 1.0% floor, plus an applicable margin of 38 basis points, at the Company’s option. As of July 1, 2019, the interest rate on the outstanding borrowings under the U.S. ABL was 3.76%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for LIBOR-based loans and from 25 to 50 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on June 3, 2024. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of July 1, 2019, $40,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

- changed (2019-11-07):
[0001564590-19-041722:note_history:25]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of September 30, 2019, the interest rate on the outstanding borrowings under the Asia ABL was 3.42%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on June 4, 2024. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of September 30, 2019, $30,000 under the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.
  (was, 2019-08-07, similarity 0.985):
[0001564590-19-030026:note_history:25]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of July 1, 2019, the interest rate on the outstanding borrowings under the Asia ABL was 3.79%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on June 4, 2024. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of July 1, 2019, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

- added (2019-11-07):
[0001564590-19-041722:note_history:26]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of September 30, 2019, letters of credit in the amount of $13,640 were outstanding under the U.S. ABL and $24,522 were outstanding under the Asia ABL with various expiration dates through May 2020. Available borrowing capacity under the U.S. ABL and the Asia ABL was $96,360 and $95,478, respectively, which considers letters of credit outstanding as of September 30, 2019.

- changed (2019-11-07):
[0001564590-19-041722:note_history:27]
The Company is required to pay a commitment fee of 0.25% per annum on any unused portion of the U.S. ABL and 0.28% per annum on any unused portion of the Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $144 and $251 for the quarters ended September 30, 2019 and October 1, 2018, respectively, and $594 and $739 for the three quarters ended September 30, 2019 and October 1, 2018, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.
  (was, 2019-08-07, similarity 0.9228):
[0001564590-19-030026:note_history:27]
The Company is required to pay a commitment fee of 0.25% per annum on any unused portion of the U.S. ABL and 0.28% per annum on any unused portion of the Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $210 and $247 for the quarters ended July 1, 2019 and July 2, 2018, respectively, and $450 and $488 for the two quarters ended July 1, 2019 and July 2, 2018, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

- changed (2019-11-07):
[0001564590-19-041722:note_history:28]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $28,078 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver. In July 2019, the expiration of the Chinese Revolver was extended to July 2020. As of September 30, 2019, the Chinese Revolver had not been drawn upon.
  (was, 2019-08-07, similarity 0.9237):
[0001564590-19-030026:note_history:28]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $29,070 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver. In July 2019, the expiration of the Chinese Revolver was extended to July 2020. As of July 1, 2019, the Chinese Revolver had not been drawn upon.

- changed (2019-11-07):
[0001564590-19-041722:note_history:29]
As of September 30, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes were as follows:
  (was, 2019-08-07, similarity 0.964):
[0001564590-19-030026:note_history:29]
As of July 1, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes were as follows:

- changed (2019-11-07):
[0001564590-19-041722:note_history:30]
|  |  | As of September 30, 2019 |  |  |  | As of December 31, 2018 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,986 |  |  | $ | 2,113 |  |  |  | 4.66 |  | % |  | $ | 8,229 |  |  | $ | 2,489 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,509 |  |  | — |  |  |  | 5.92 |  |  |  |  | 6,071 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 1,245 |  |  |  | 12,423 |  |  |  | 6.48 |  |  |  |  | 1,972 |  |  |  | 19,678 |  |  |  | 6.48 |  |  |
|  |  | $ | 13,740 |  |  | $ | 14,536 |  |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |  |
  (was, 2019-08-07, similarity 0.9895):
[0001564590-19-030026:note_history:30]
|  |  | As of July 1, 2019 |  |  |  | As of December 31, 2018 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 7,303 |  |  | $ | 2,210 |  |  |  | 4.66 |  | % |  | $ | 8,229 |  |  | $ | 2,489 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,700 |  |  | — |  |  |  | 5.92 |  |  |  |  | 6,071 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 1,491 |  |  |  | 14,880 |  |  |  | 6.48 |  |  |  |  | 1,972 |  |  |  | 19,678 |  |  |  | 6.48 |  |  |
|  |  | $ | 14,494 |  |  | $ | 17,090 |  |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |  |

- changed (2019-11-07):
[0001564590-19-041722:note_history:31]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,654 and $1,420 as of September 30, 2019 and December 31, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.
  (was, 2019-08-07, similarity 0.9785):
[0001564590-19-030026:note_history:31]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,741 and $1,420 as of July 1, 2019 and December 31, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

- changed (2019-11-07):
[0001564590-19-041722:note_history:32]
As of September 30, 2019, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.5 years.
  (was, 2019-08-07, similarity 0.9531):
[0001564590-19-030026:note_history:32]
As of July 1, 2019, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.6 years.

- removed (2019-11-07):
[0001564590-19-030026:note_history:33]
|  |  | As of July 1, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

- removed (2019-11-07):
[0001564590-19-030026:note_history:34]
|  |  | Quarter Ended |  |  | Two Quarters Ended |  |
|  |  | July 1, |  |  | July 2, |  |  | July 1, |  |  | July 2, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,093 |  |  | $ | 1,093 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Amortization of debt discount |  | $ | 2,418 |  |  | $ | 2,267 |  |  | $ | 4,797 |  |  | $ | 4,497 |  |
| Amortization of debt issuance costs |  | $ | 243 |  |  | $ | 227 |  |  | $ | 481 |  |  | $ | 451 |  |

- removed (2019-11-07):
[0001564590-19-030026:note_history:35]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of July 1, 2019, letters of credit in the amount of $15,287 were outstanding under the U.S. ABL and $22,718 were outstanding under the Asia ABL with various expiration dates through May 2020. Available borrowing capacity under the U.S. ABL and the Asia ABL was $94,713 and $97,282, respectively, which considers letters of credit outstanding as of July 1, 2019.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-07):
[0001564590-19-041722:note_history:36]
The following table summarizes the long-term debt of the Company as of September 30, 2019 and December 31, 2018:
  (was, 2019-08-07, similarity 0.9347):
[0001564590-19-030026:note_history:36]
The following table summarizes the long-term debt of the Company as of July 1, 2019 and December 31, 2018:

- changed (2019-11-07):
[0001564590-19-041722:note_history:37]
|  | Interest Rate as of September 30, 2019 |  |  | Principal Outstanding as of September 30, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  | (In thousands, except interest rates) |  |
| Term Loan due September 2024 |  | 4.52 |  | % | $ | 805,879 |  |  |  | 5.00 |  | % | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due June 2024 |  | 3.27 |  |  |  | 40,000 |  |  |  | 4.00 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  | 3.42 |  |  |  | 30,000 |  |  |  | 3.90 |  |  |  | 30,000 |  |
|  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  | (14,536 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  | (13,740 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  | 1,472,578 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  | $ | 1,472,578 |  |  |  |  |  |  | $ | 1,462,425 |  |
  (was, 2019-08-07, similarity 0.9709):
[0001564590-19-030026:note_history:37]
|  | Interest Rate as of July 1, 2019 |  |  | Principal Outstanding as of July 1, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  | (In thousands, except interest rates) |  |
| Term Loan due September 2024 |  | 4.89 |  | % | $ | 805,879 |  |  |  | 5.00 |  | % | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due June 2024 |  | 3.76 |  |  |  | 40,000 |  |  |  | 4.00 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  | 3.79 |  |  |  | 30,000 |  |  |  | 3.90 |  |  |  | 30,000 |  |
|  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  | (17,090 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  | (14,494 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  | 1,469,270 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  | $ | 1,469,270 |  |  |  |  |  |  | $ | 1,462,425 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-11-07):
[0001564590-19-041722:note_history:38]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $8,005 and $10,437 for the quarters ended September 30, 2019 and October 1, 2018, respectively, and $25,234 and $35,695 for the three quarters ended September 30, 2019 and October 1, 2018, respectively.
  (was, 2019-08-07, similarity 0.9041):
[0001564590-19-030026:note_history:38]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $8,917 and $12,550 for the quarters ended July 1, 2019 and July 2, 2018, respectively, and $17,229 and $25,258 for the two quarters ended July 1, 2019 and July 2, 2018, respectively.

- added (2019-11-07):
[0001564590-19-041722:note_history:39]
As of September 30, 2019 and December 31, 2018, the Company’s consolidated condensed balance sheets included $10,290 and $10,630, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.

- removed (2019-11-07):
[0001564590-19-030026:note_history:40]
As of July 1, 2019 and December 31, 2018, the Company’s consolidated condensed balance sheets included $10,537 and $10,630, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-11-07):
[0001564590-19-041722:note_history:41]
|  |  | Quarter Ended September 30, 2019 |  |  | Quarter Ended October 1, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 171,903 |  |  | $ | 1 |  |  | $ | 171,904 |  |  | $ | 160,067 |  |  | $ | 122 |  |  | $ | 160,189 |  |
| Automotive |  |  | 78,393 |  |  |  | 39,559 |  |  |  | 117,952 |  |  |  | 96,329 |  |  |  | 19,628 |  |  |  | 115,957 |  |
| Cellular Phone |  |  | 136,184 |  |  |  | — |  |  |  | 136,184 |  |  |  | 125,442 |  |  |  | — |  |  |  | 125,442 |  |
| Computing/Storage/Peripherals |  |  | 84,429 |  |  |  | 72 |  |  |  | 84,501 |  |  |  | 107,796 |  |  |  | 253 |  |  |  | 108,049 |  |
| Medical/Industrial/Instrumentation |  |  | 89,395 |  |  |  | 5,775 |  |  |  | 95,170 |  |  |  | 93,248 |  |  |  | 10,457 |  |  |  | 103,705 |  |
| Networking/Communications |  |  | 72,045 |  |  |  | 22,746 |  |  |  | 94,791 |  |  |  | 97,926 |  |  |  | 28,986 |  |  |  | 126,912 |  |
| Other |  |  | 16,755 |  |  |  | (440 | ) |  |  | 16,315 |  |  |  | 15,548 |  |  |  | 35 |  |  |  | 15,583 |  |
| Total |  | $ | 649,104 |  |  | $ | 67,713 |  |  | $ | 716,817 |  |  | $ | 696,356 |  |  | $ | 59,481 |  |  | $ | 755,837 |  |
  (was, 2019-08-07, similarity 0.9852):
[0001564590-19-030026:note_history:41]
|  |  | Quarter Ended July 1, 2019 |  |  | Quarter Ended July 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 175,301 |  |  | $ | 362 |  |  | $ | 175,663 |  |  | $ | 162,951 |  |  | $ | 455 |  |  | $ | 163,406 |  |
| Automotive |  |  | 79,048 |  |  |  | 23,993 |  |  |  | 103,041 |  |  |  | 110,607 |  |  |  | 25,854 |  |  |  | 136,461 |  |
| Cellular Phone |  |  | 40,094 |  |  |  | — |  |  |  | 40,094 |  |  |  | 55,393 |  |  |  | — |  |  |  | 55,393 |  |
| Computing/Storage/Peripherals |  |  | 95,127 |  |  |  | — |  |  |  | 95,127 |  |  |  | 109,633 |  |  |  | 568 |  |  |  | 110,201 |  |
| Medical/Industrial/Instrumentation |  |  | 87,471 |  |  |  | 9,641 |  |  |  | 97,112 |  |  |  | 96,704 |  |  |  | 9,856 |  |  |  | 106,560 |  |
| Networking/Communications |  |  | 79,937 |  |  |  | 25,926 |  |  |  | 105,863 |  |  |  | 99,353 |  |  |  | 24,602 |  |  |  | 123,955 |  |
| Other |  |  | 16,143 |  |  |  | (5 | ) |  |  | 16,138 |  |  |  | 20,404 |  |  |  | 507 |  |  |  | 20,911 |  |
| Total |  | $ | 573,121 |  |  | $ | 59,917 |  |  | $ | 633,038 |  |  | $ | 655,045 |  |  | $ | 61,842 |  |  | $ | 716,887 |  |

- changed (2019-11-07):
[0001564590-19-041722:note_history:42]
|  |  | Three Quarters Ended September 30, 2019 |  |  | Three Quarters Ended October 1, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 512,272 |  |  | $ | 367 |  |  | $ | 512,639 |  |  | $ | 445,694 |  |  | $ | 666 |  |  | $ | 446,360 |  |
| Automotive |  |  | 243,254 |  |  |  | 83,317 |  |  |  | 326,571 |  |  |  | 323,228 |  |  |  | 64,792 |  |  |  | 388,020 |  |
| Cellular Phone |  |  | 219,362 |  |  |  | — |  |  |  | 219,362 |  |  |  | 285,695 |  |  |  | — |  |  |  | 285,695 |  |
| Computing/Storage/Peripherals |  |  | 260,448 |  |  |  | 261 |  |  |  | 260,709 |  |  |  | 305,971 |  |  |  | 1,126 |  |  |  | 307,097 |  |
| Medical/Industrial/Instrumentation |  |  | 264,536 |  |  |  | 23,583 |  |  |  | 288,119 |  |  |  | 283,586 |  |  |  | 27,836 |  |  |  | 311,422 |  |
| Networking/Communications |  |  | 240,045 |  |  |  | 72,011 |  |  |  | 312,056 |  |  |  | 279,216 |  |  |  | 73,061 |  |  |  | 352,277 |  |
| Other |  |  | 51,130 |  |  |  | (531 | ) |  |  | 50,599 |  |  |  | 44,442 |  |  |  | 993 |  |  |  | 45,435 |  |
| Total |  | $ | 1,791,047 |  |  | $ | 179,008 |  |  | $ | 1,970,055 |  |  | $ | 1,967,832 |  |  | $ | 168,474 |  |  | $ | 2,136,306 |  |
  (was, 2019-08-07, similarity 0.9664):
[0001564590-19-030026:note_history:42]
|  |  | Two Quarters Ended July 1, 2019 |  |  | Two Quarters Ended July 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 340,369 |  |  | $ | 366 |  |  | $ | 340,735 |  |  | $ | 285,627 |  |  | $ | 544 |  |  | $ | 286,171 |  |
| Automotive |  |  | 164,861 |  |  |  | 43,758 |  |  |  | 208,619 |  |  |  | 226,899 |  |  |  | 45,164 |  |  |  | 272,063 |  |
| Cellular Phone |  |  | 83,178 |  |  |  | — |  |  |  | 83,178 |  |  |  | 160,253 |  |  |  | — |  |  |  | 160,253 |  |
| Computing/Storage/Peripherals |  |  | 176,019 |  |  |  | 189 |  |  |  | 176,208 |  |  |  | 198,175 |  |  |  | 873 |  |  |  | 199,048 |  |
| Medical/Industrial/Instrumentation |  |  | 175,141 |  |  |  | 17,808 |  |  |  | 192,949 |  |  |  | 190,338 |  |  |  | 17,379 |  |  |  | 207,717 |  |
| Networking/Communications |  |  | 168,000 |  |  |  | 49,265 |  |  |  | 217,265 |  |  |  | 181,290 |  |  |  | 44,075 |  |  |  | 225,365 |  |
| Other |  |  | 34,375 |  |  |  | (91 | ) |  |  | 34,284 |  |  |  | 28,894 |  |  |  | 958 |  |  |  | 29,852 |  |
| Total |  | $ | 1,141,943 |  |  | $ | 111,295 |  |  | $ | 1,253,238 |  |  | $ | 1,271,476 |  |  | $ | 108,993 |  |  | $ | 1,380,469 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-11-07):
[0001564590-19-041722:note_history:43]
As of September 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $9,024. The Company expects to recognize revenue on approximately 100% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.
  (was, 2019-08-07, similarity 0.9252):
[0001564590-19-030026:note_history:43]
As of July 1, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $20,097. The Company expects to recognize revenue on approximately 94% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months with the remaining amount recognized thereafter. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year or less.

- changed (2019-11-07):
[0001564590-19-041722:note_history:44]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter ended September 30, 2019, and 97% and 3%, respectively, of the Company’s revenue for the three quarters ended September 30, 2019.
  (was, 2019-08-07, similarity 0.7099):
[0001564590-19-030026:note_history:44]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and two quarters ended July 1, 2019.

- changed (2019-11-07):
[0001564590-19-041722:note_history:45]
|  |  | Quarter Ended September 30, 2019 |  |  | Quarter Ended October 1, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 171,903 |  |  | $ | 1 |  |  | $ | 171,904 |  |  | $ | 160,067 |  |  | $ | 122 |  |  | $ | 160,189 |  |
| Automotive |  |  | 78,393 |  |  |  | 39,559 |  |  |  | 117,952 |  |  |  | 96,329 |  |  |  | 19,628 |  |  |  | 115,957 |  |
| Cellular Phone |  |  | 136,184 |  |  |  | — |  |  |  | 136,184 |  |  |  | 125,442 |  |  |  | — |  |  |  | 125,442 |  |
| Computing/Storage/Peripherals |  |  | 84,429 |  |  |  | 72 |  |  |  | 84,501 |  |  |  | 107,796 |  |  |  | 253 |  |  |  | 108,049 |  |
| Medical/Industrial/Instrumentation |  |  | 89,395 |  |  |  | 5,775 |  |  |  | 95,170 |  |  |  | 93,248 |  |  |  | 10,457 |  |  |  | 103,705 |  |
| Networking/Communications |  |  | 72,045 |  |  |  | 22,746 |  |  |  | 94,791 |  |  |  | 97,926 |  |  |  | 28,986 |  |  |  | 126,912 |  |
| Other |  |  | 16,755 |  |  |  | (440 | ) |  |  | 16,315 |  |  |  | 15,548 |  |  |  | 35 |  |  |  | 15,583 |  |
| Total |  | $ | 649,104 |  |  | $ | 67,713 |  |  | $ | 716,817 |  |  | $ | 696,356 |  |  | $ | 59,481 |  |  | $ | 755,837 |  |
  (was, 2019-08-07, similarity 0.9852):
[0001564590-19-030026:note_history:45]
|  |  | Quarter Ended July 1, 2019 |  |  | Quarter Ended July 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 175,301 |  |  | $ | 362 |  |  | $ | 175,663 |  |  | $ | 162,951 |  |  | $ | 455 |  |  | $ | 163,406 |  |
| Automotive |  |  | 79,048 |  |  |  | 23,993 |  |  |  | 103,041 |  |  |  | 110,607 |  |  |  | 25,854 |  |  |  | 136,461 |  |
| Cellular Phone |  |  | 40,094 |  |  |  | — |  |  |  | 40,094 |  |  |  | 55,393 |  |  |  | — |  |  |  | 55,393 |  |
| Computing/Storage/Peripherals |  |  | 95,127 |  |  |  | — |  |  |  | 95,127 |  |  |  | 109,633 |  |  |  | 568 |  |  |  | 110,201 |  |
| Medical/Industrial/Instrumentation |  |  | 87,471 |  |  |  | 9,641 |  |  |  | 97,112 |  |  |  | 96,704 |  |  |  | 9,856 |  |  |  | 106,560 |  |
| Networking/Communications |  |  | 79,937 |  |  |  | 25,926 |  |  |  | 105,863 |  |  |  | 99,353 |  |  |  | 24,602 |  |  |  | 123,955 |  |
| Other |  |  | 16,143 |  |  |  | (5 | ) |  |  | 16,138 |  |  |  | 20,404 |  |  |  | 507 |  |  |  | 20,911 |  |
| Total |  | $ | 573,121 |  |  | $ | 59,917 |  |  | $ | 633,038 |  |  | $ | 655,045 |  |  | $ | 61,842 |  |  | $ | 716,887 |  |

- changed (2019-11-07):
[0001564590-19-041722:note_history:46]
|  |  | Three Quarters Ended September 30, 2019 |  |  | Three Quarters Ended October 1, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 512,272 |  |  | $ | 367 |  |  | $ | 512,639 |  |  | $ | 445,694 |  |  | $ | 666 |  |  | $ | 446,360 |  |
| Automotive |  |  | 243,254 |  |  |  | 83,317 |  |  |  | 326,571 |  |  |  | 323,228 |  |  |  | 64,792 |  |  |  | 388,020 |  |
| Cellular Phone |  |  | 219,362 |  |  |  | — |  |  |  | 219,362 |  |  |  | 285,695 |  |  |  | — |  |  |  | 285,695 |  |
| Computing/Storage/Peripherals |  |  | 260,448 |  |  |  | 261 |  |  |  | 260,709 |  |  |  | 305,971 |  |  |  | 1,126 |  |  |  | 307,097 |  |
| Medical/Industrial/Instrumentation |  |  | 264,536 |  |  |  | 23,583 |  |  |  | 288,119 |  |  |  | 283,586 |  |  |  | 27,836 |  |  |  | 311,422 |  |
| Networking/Communications |  |  | 240,045 |  |  |  | 72,011 |  |  |  | 312,056 |  |  |  | 279,216 |  |  |  | 73,061 |  |  |  | 352,277 |  |
| Other |  |  | 51,130 |  |  |  | (531 | ) |  |  | 50,599 |  |  |  | 44,442 |  |  |  | 993 |  |  |  | 45,435 |  |
| Total |  | $ | 1,791,047 |  |  | $ | 179,008 |  |  | $ | 1,970,055 |  |  | $ | 1,967,832 |  |  | $ | 168,474 |  |  | $ | 2,136,306 |  |
  (was, 2019-08-07, similarity 0.9664):
[0001564590-19-030026:note_history:46]
|  |  | Two Quarters Ended July 1, 2019 |  |  | Two Quarters Ended July 2, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 340,369 |  |  | $ | 366 |  |  | $ | 340,735 |  |  | $ | 285,627 |  |  | $ | 544 |  |  | $ | 286,171 |  |
| Automotive |  |  | 164,861 |  |  |  | 43,758 |  |  |  | 208,619 |  |  |  | 226,899 |  |  |  | 45,164 |  |  |  | 272,063 |  |
| Cellular Phone |  |  | 83,178 |  |  |  | — |  |  |  | 83,178 |  |  |  | 160,253 |  |  |  | — |  |  |  | 160,253 |  |
| Computing/Storage/Peripherals |  |  | 176,019 |  |  |  | 189 |  |  |  | 176,208 |  |  |  | 198,175 |  |  |  | 873 |  |  |  | 199,048 |  |
| Medical/Industrial/Instrumentation |  |  | 175,141 |  |  |  | 17,808 |  |  |  | 192,949 |  |  |  | 190,338 |  |  |  | 17,379 |  |  |  | 207,717 |  |
| Networking/Communications |  |  | 168,000 |  |  |  | 49,265 |  |  |  | 217,265 |  |  |  | 181,290 |  |  |  | 44,075 |  |  |  | 225,365 |  |
| Other |  |  | 34,375 |  |  |  | (91 | ) |  |  | 34,284 |  |  |  | 28,894 |  |  |  | 958 |  |  |  | 29,852 |  |
| Total |  | $ | 1,141,943 |  |  | $ | 111,295 |  |  | $ | 1,253,238 |  |  | $ | 1,271,476 |  |  | $ | 108,993 |  |  | $ | 1,380,469 |  |
