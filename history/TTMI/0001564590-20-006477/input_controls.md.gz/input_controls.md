# TTMI 10-K controls and the auditor's report


## auditors_report

[0001564590-20-006477:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001564590-20-006477:auditors_report:2]
To the Stockholders and Board of Directors

[0001564590-20-006477:auditors_report:3]
TTM Technologies, Inc.:

[0001564590-20-006477:auditors_report:4]
Opinions on the Consolidated Financial Statements and Internal Control Over Financial Reporting

[0001564590-20-006477:auditors_report:5]
We have audited the accompanying consolidated balance sheets of TTM Technologies, Inc. and subsidiaries (the Company) as of December 30, 2019 and December 31, 2018, the related consolidated statements of operations, comprehensive income, stockholders’ equity, and cash flows for each of the years in the three-year period ended December 30, 2019, and the related notes (collectively, the consolidated financial statements). We also have audited the Company’s internal control over financial reporting as of December 30, 2019, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001564590-20-006477:auditors_report:6]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 30, 2019 and December 31, 2018, and the results of its operations and its cash flows for each of the years in the three-year period ended December 30, 2019, in conformity with U.S. generally accepted accounting principles. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 30, 2019, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001564590-20-006477:auditors_report:7]
Change in Accounting Principle

[0001564590-20-006477:auditors_report:8]
As discussed in Note 1 to the consolidated financial statements, the Company changed its method of accounting for leases in fiscal 2019 due to the adoption of the Financial Accounting Standards Board’s (FASB) Accounting Standards Codification (ASC) Topic 842, Leases.

[0001564590-20-006477:auditors_report:9]
As discussed in Note 1 to the consolidated financial statements, the Company changed its method of accounting for revenue in fiscal 2018 due to the adoption of the FASB’s ASC Topic 606, Revenue from Contracts with Customers.

[0001564590-20-006477:auditors_report:10]
Basis for Opinions

[0001564590-20-006477:auditors_report:11]
The Company’s management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting appearing under Item 9A. Our responsibility is to express an opinion on the Company’s consolidated financial statements and an opinion on the Company’s internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001564590-20-006477:auditors_report:12]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001564590-20-006477:auditors_report:13]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001564590-20-006477:auditors_report:14]
Definition and Limitations of Internal Control Over Financial Reporting

[0001564590-20-006477:auditors_report:15]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001564590-20-006477:auditors_report:16]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001564590-20-006477:auditors_report:17]
Critical Audit Matters

[0001564590-20-006477:auditors_report:18]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the consolidated financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001564590-20-006477:auditors_report:19]
Assessment of the goodwill impairment test for the AMI&I and C&C reporting units

[0001564590-20-006477:auditors_report:20]
As discussed in Note 5 to the consolidated financial statements, the goodwill balance as of December 30, 2019 was $775 million. Of that amount, $186 million related to the Automotive, Medical, Industrial and Instrumentation (AMI&I) reporting unit and $39 million related to the Communications and Computing (C&C) reporting unit. The Company performs goodwill impairment testing on an annual basis and whenever events or changes in circumstances indicate that the carrying value of a reporting unit might exceed its fair value.

[0001564590-20-006477:auditors_report:21]
We identified the assessment of the goodwill impairment test for the AMI&I and C&C reporting units as a critical audit matter. The estimated fair values of the AMI&I and C&C reporting units were 8% and 19%, respectively, above their carrying values, indicating a higher risk that goodwill may be impaired. This resulted in the application of greater auditor judgment. The revenue growth rate and the discount rate assumptions used to estimate the fair values of the reporting units were challenging to test. This is because minor changes to those assumptions could have a significant effect on the Company’s assessment of the carrying value of the goodwill.

[0001564590-20-006477:auditors_report:22]
The primary procedures we performed to address this critical audit matter included the following. We tested certain internal controls over the Company’s goodwill impairment assessment process, including controls related to the determination of the fair values of the reporting units. We also tested controls related to revenue growth rates and the assumptions used to develop the discount rates. We performed sensitivity analyses over the revenue growth rate and discount rate assumptions. This was done to assess their impact on the Company’s determination that the fair values of the AM&I and C&C reporting units exceeded their carrying values. We evaluated the Company’s forecasted revenue growth rates for the AMI&I and C&C reporting units, by comparing the growth rate assumptions to forecasted growth rates in analyst reports. We compared the Company’s historical revenue forecasts to actual results to assess the Company’s ability to accurately forecast. In addition, we involved a valuation professional with specialized skill and knowledge, who assisted in:

[0001564590-20-006477:auditors_report:23]
|  | • | comparing the Company’s discount rates against discount rate ranges that were independently developed using publicly available market data for comparable entities; |

[0001564590-20-006477:auditors_report:24]
|  | • | developing estimates of the AMI&I and C&C reporting units’ fair values using the Company’s cash flow forecasts for those reporting units and independently developed discount rates; and |

[0001564590-20-006477:auditors_report:25]
|  | • | comparing the results of our estimates of fair value to the Company’s fair value estimates. |

[0001564590-20-006477:auditors_report:26]
Evaluation of the sufficiency of audit evidence over net sales

[0001564590-20-006477:auditors_report:27]
As discussed in Note 1 to the consolidated financial statements, the Company recorded approximately $2.7 billion of net sales in 2019. Net sales are recognized primarily from the manufacture and distribution of printed circuit boards, backplane assemblies, electro-mechanical solutions, radio-frequency and microwave components and assemblies from numerous locations around the world.

[0001564590-20-006477:auditors_report:28]
We identified the evaluation of the sufficiency of audit evidence over net sales as a critical audit matter. Evaluating the sufficiency of audit evidence obtained required especially subjective auditor judgment because of the geographical dispersion and decentralized nature of the Company’s net sales generating activities and related control environment. This included determining the Company locations at which procedures were performed and the supervision and review of the procedures performed at those locations. It also included the involvement of IT professionals with specialized skills and knowledge, who assisted in the performance of certain procedures.

[0001564590-20-006477:auditors_report:29]
The primary procedures we performed to address this critical audit matter included the following. We applied auditor judgment to determine the nature and extent of procedures to be performed over net sales, including determining the locations at which those procedures were to be performed. At each location where procedures were performed, we (1) tested certain internal controls over the Company’s net sales processes, including the Company’s controls over the accurate recording of sales amounts; (2) involved IT professionals, who assisted in testing certain IT applications used by the Company in its revenue recognition processes; and (3) tested the recorded net sales by selecting a sample of transactions and comparing the amounts recognized to underlying documentation, including contracts with customers and shipping documentation. In addition, we evaluated the overall sufficiency of audit evidence obtained over net sales.

[0001564590-20-006477:auditors_report:30]
/s/ KPMG LLP

[0001564590-20-006477:auditors_report:31]
We have served as the Company’s auditor since 2014.

[0001564590-20-006477:auditors_report:32]
Irvine, California

[0001564590-20-006477:auditors_report:33]
February 25, 2020

[0001564590-20-006477:auditors_report:34]
TTM TECHNOLOGIES, INC.


## item_9a

[0001564590-20-006477:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES |

[0001564590-20-006477:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001564590-20-006477:item_9a:3]
Our management, under the supervision and with the participation of our Chief Executive Officer (CEO) and Chief Financial Officer (CFO), has evaluated the effectiveness of the design and operation of our disclosure controls and procedures (as defined in Exchange Act Rules 13a-15(e) and 15d-15(e)) as of the end of the period covered by this Report. Based on this evaluation, our CEO and CFO have concluded that, as of December 30, 2019, such disclosure controls and procedures were effective to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is (i) recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and (ii) accumulated and communicated to our management, including our CEO and CFO, as appropriate to allow timely decisions regarding required disclosures.

[0001564590-20-006477:item_9a:4]
Management’s Report on Internal Control over Financial Reporting

[0001564590-20-006477:item_9a:5]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, (as defined in Exchange Act Rules 13a-15(f) and 15d-15(f)) to provide reasonable assurance regarding the reliability of our financial reporting and the preparation of financial statements for external purposes in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP). Under the supervision of and with the participation of our CEO and CFO, management conducted an assessment of the effectiveness of our internal control over financial reporting as of December 30, 2019 based on the criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Based on this assessment, management concluded that our internal control over financial reporting was effective as of December 30, 2019.

[0001564590-20-006477:item_9a:6]
The effectiveness of our internal control over financial reporting as of December 30, 2019 has been audited by KPMG LLP, an independent registered public accounting firm, as stated in their report, which appears under the heading “Report of Independent Registered Public Accounting Firm” on page 55 of this Report.

[0001564590-20-006477:item_9a:7]
Inherent Limitations on Effectiveness of Controls

[0001564590-20-006477:item_9a:8]
A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system’s objectives will be met. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Further, because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that misstatements due to error or fraud will not occur or that all control issues and instances of fraud, if any, have been detected. In addition, the design of any system of controls is based in part on certain assumptions about the likelihood of future events.

[0001564590-20-006477:item_9a:9]
Changes in Internal Control over Financial Reporting

[0001564590-20-006477:item_9a:10]
There were no changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended December 30, 2019 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
