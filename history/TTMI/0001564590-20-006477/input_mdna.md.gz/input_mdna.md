# TTMI MD&A — 0001564590-20-006477


## mdna

[0001564590-20-006477:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001564590-20-006477:mdna:2]
This financial review presents our operating results for each of our three most recent fiscal years and our financial condition as of December 30, 2019. Except for historical information contained herein, the following discussion contains forward-looking statements which are subject to known and unknown risks, uncertainties and other factors that may cause our actual results to differ materially from those expressed or implied by such forward-looking statements. We discuss such risks, uncertainties and other factors throughout this report and specifically under Item 1A of Part I of this report, Risk Factors. In addition, the following discussion should be read in connection with the information presented in our consolidated financial statements and the related notes to our consolidated financial statements.

[0001564590-20-006477:mdna:3]
COMPANY OVERVIEW

[0001564590-20-006477:mdna:4]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions), as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering and manufacturing solution to our customers. This one-stop design, engineering and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,900 customers in various markets throughout the world, including aerospace and defense, automotive components, smartphones and other mobile devices, high-end computing, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-20-006477:mdna:5]
RECENT DEVELOPMENTS

[0001564590-20-006477:mdna:6]
In December 2019, a strain of coronavirus surfaced in China. As a result, there have been numerous factory closures. While many factories were closed for a few days because of the Chinese New Year holiday, the Chinese government ordered that businesses in various areas extend the Chinese New Year holiday due to the coronavirus outbreak. Moreover, because of the current restrictions on travel in China, our employees have been affected and we experienced labor shortages and may continue to experience those shortages for some time. Also, it is possible that the Chinese government will announce new closures in the future. Some of our suppliers and customers in China have similarly been affected and experienced closures and risks of labor shortages. If our suppliers experience additional closures in the future, we may have difficulty sourcing materials necessary to fulfill production requirements and meet scheduled shipments, which will negatively affect our revenues. Even if we are able to find alternate sources for such materials, they may cost more, which will affect our profitability. If our customers in China experience additional closures in the future and are not able to accept orders or if they delay or cancel such orders, our revenues will be negatively affected. At this point in time, there is significant uncertainty relating to the potential effect of the coronavirus on our business. Infections may become more widespread and there might be additional factory closures in the future, all of which will have a negative impact on our business, financial condition and operating results. As a result of this disruption, our financial results for the first quarter of 2020 will be negatively affected.

[0001564590-20-006477:mdna:7]
On January 19, 2020, we entered into a definitive equity interests purchase agreement for the sale of the following subsidiaries of our Mobility business unit: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) for a base purchase price of $550.0 million in cash, subject to customary purchase price adjustments. The purchase agreement excludes from the sale certain accounts receivable related to the business, which we expect, based on the terms of the purchase agreement will result in an estimated $110.0 million in cash to us.

[0001564590-20-006477:mdna:8]
FINANCIAL OVERVIEW

[0001564590-20-006477:mdna:9]
For the fiscal year 2019, we experienced lower demand in our commercial (non-Aerospace and Defense related) end markets, partially offset by higher demand in our Aerospace and Defense end market.

[0001564590-20-006477:mdna:10]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies as they are the ultimate end customers. Sales to our five largest customers accounted for 33%, 32% and 37% of our net sales in fiscal years 2019, 2018 and 2017, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-20-006477:mdna:11]
The following table shows the percentage of our net sales attributable to each of the principal end markets we served for the periods indicated:

[0001564590-20-006477:mdna:12]
|  |  | For the Year Ended |  |  |
| End Markets (1) |  | December 30, 2019 |  |  |  | December 31, 2018 (3) |  |  |  | January 1, 2018 |  |  |
| Aerospace and Defense |  |  | 26 |  | % |  |  | 21 |  | % |  |  | 16 |  | % |
| Automotive |  |  | 16 |  |  |  |  | 18 |  |  |  |  | 19 |  |  |
| Cellular Phone (2) |  |  | 13 |  |  |  |  | 14 |  |  |  |  | 18 |  |  |
| Computing/Storage/Peripherals (2) |  |  | 13 |  |  |  |  | 14 |  |  |  |  | 13 |  |  |
| Medical/Industrial/Instrumentation |  |  | 14 |  |  |  |  | 14 |  |  |  |  | 14 |  |  |
| Networking/Communications |  |  | 15 |  |  |  |  | 17 |  |  |  |  | 18 |  |  |
| Other (2) |  |  | 3 |  |  |  |  | 2 |  |  |  |  | 2 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-20-006477:mdna:13]
| (1) | Sales to EMS companies are classified by the end markets of their OEM customers. |

[0001564590-20-006477:mdna:14]
| (2) | Smartphones are included in the Cellular Phone end market, tablets are included in the Computing/Storage/Peripherals end market and other consumer devices that include wearables, portable video devices and personal headphones are included in the Other end market. |

[0001564590-20-006477:mdna:15]
| (3) | Amended for Anaren integration and amounts include activity of Anaren since the acquisition which occurred on April 18, 2018. |

[0001564590-20-006477:mdna:16]
We derive revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of RF and microwave components, assemblies and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and custom electronic assemblies manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, beginning in the first quarter of 2018, we began recognizing revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

[0001564590-20-006477:mdna:17]
We also manufacture certain components, assemblies, and subsystems which service our wireless communications customers. We recognize revenue at a point in time upon transfer of control of the products to our customer. Point in time recognition was determined as our customers do not simultaneously receive or consume the benefits provided by our performance and the asset being manufactured has alternative uses to us.

[0001564590-20-006477:mdna:18]
Net sales consist of gross sales less an allowance for returns, which typically have been approximately 2% of gross sales. We provide our customers a limited right of return for defective PCBs including components, subsystems and assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results and anticipated returns.

[0001564590-20-006477:mdna:19]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. While we have entered into supply assurance agreements with some of our key suppliers to maintain the continuity of supply of some of the key materials we use, we generally do not participate in any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for most of the raw materials we use.

[0001564590-20-006477:mdna:20]
Selling and marketing expenses consist primarily of salaries, labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0001564590-20-006477:mdna:21]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, facilities, research and development, and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001564590-20-006477:mdna:22]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0001564590-20-006477:mdna:23]
Our consolidated financial statements included in this report have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001564590-20-006477:mdna:24]
A critical accounting policy is defined as one that is both material to the presentation of our consolidated financial statements and requires us to make judgments that could have a material effect on our financial condition or results of operations. These policies require us to make assumptions about matters that are highly uncertain at the time of the estimate. Different estimates we could reasonably have used, or changes in the estimates that are reasonably likely to occur, could have a material effect on our financial condition or results of operations.

[0001564590-20-006477:mdna:25]
We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Management has discussed the development, selection and disclosure of these estimates with the audit committee of our board of directors. Actual results may differ from these estimates under different assumptions or conditions.

[0001564590-20-006477:mdna:26]
Our critical accounting policies include impairment of goodwill and intangible assets and realizability of deferred tax assets.

[0001564590-20-006477:mdna:27]
Goodwill and Intangible Assets

[0001564590-20-006477:mdna:28]
We have significant goodwill and definite-lived intangibles. We review these assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. In addition, we perform an impairment test related to goodwill at least annually. As necessary, we make judgments regarding future cash flow forecasts in the assessment of impairment.

[0001564590-20-006477:mdna:29]
We have two reportable segments consisting of PCB and E-M Solutions. Goodwill is only attributable to our PCB reportable segment. Goodwill is allocated to our reporting units, which are our operating segments or one level below our operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it

[0001564590-20-006477:mdna:30]
is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic characteristics. Our PCB reportable segment is made up of five reporting units. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. We assess qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or perform its annual impairment test. When tested quantitatively, we compare the fair value of the applicable reporting unit with its carrying value. We estimate the fair values of our reporting units using a combination of the income and market approach. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss.

[0001564590-20-006477:mdna:31]
During the third fiscal quarter, our Communications and Computing and Automotive and Medical/Industrial/Instrumentation reporting units had lower than anticipated results and continued declines in sales. We considered these factors to be indicators of potential impairment requiring us to test the related goodwill of $39.3 million for Communications and Computing reporting unit and $185.5 million for Automotive and Medical/Industrial/Instrumentation reporting unit for impairment. As of September 30, 2019, we completed a quantitative goodwill impairment analysis related to these reporting units by comparing the fair value of the reporting unit with its carrying amount. We determined the fair value of the reporting units by using discounted cash flow (DCF) and market analyses. Under the market approach, we used revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting units.

[0001564590-20-006477:mdna:32]
A DCF analysis requires us to estimate the future cash flows as well as to select a risk-adjusted discount rate to measure the present value of the anticipated cash flows. When determining future cash flow estimates, we consider historical results adjusted to reflect current and anticipated future operating conditions. We estimate cash flows for a reporting unit over a discrete period and a terminal period (considering expected long-term growth rates and trends).

[0001564590-20-006477:mdna:33]
Based on our analysis, we estimated that the fair value of the Communications and Computing and Automotive and Medical/Industrial/Instrumentation reporting units exceeded their respective carrying value by 19% and 8%, respectively. If our future cash flow projections and other fair value assumptions for our reporting unit change, we may be subject to potential impairment in subsequent quarters. Estimating the fair value of the reporting unit requires us to make assumptions and estimates in such areas as future economic conditions, industry-specific conditions, product pricing, and necessary capital expenditures. The use of different assumptions or estimates for future cash flows, discount rates, or terminal growth rates could produce substantially different estimates of the fair value of the reporting unit.

[0001564590-20-006477:mdna:34]
In the fourth quarter of 2019, we performed our annual impairment test qualitatively and concluded that it was more likely than not that goodwill was not impaired. Management will continue to monitor the reporting units for changes in the business environment that could impact recoverability. The recoverability of goodwill is dependent upon the continued growth of cash flows from our business activities. If the economy or business environment falter and we are unable to achieve our assumed revenue growth rates or profit margin percentages, our projections used would need to be re-measured, which could impact the carrying value of our goodwill in one or more of our reporting units.

[0001564590-20-006477:mdna:35]
We also assess definite-lived intangibles for potential impairment given similar impairment indicators. When indicators of impairment exist related to our definite-lived intangible assets, we use an estimate of the undiscounted cash flows in measuring whether the carrying amount of the assets is recoverable. Measurement of the amount of impairment, if any, is based upon the difference between the asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary, which involve judgments related to future cash flows and the application of the appropriate valuation model.

[0001564590-20-006477:mdna:36]
Income Taxes

[0001564590-20-006477:mdna:37]
Deferred income tax assets are reviewed for recoverability, and valuation allowances are provided, when necessary, to reduce deferred income tax assets to the amounts that are more likely than not to be realized based on our estimate of future taxable income. As of December 30, 2019, we had a net non-current deferred income tax asset of $26.1 million, which is comprised of a net deferred tax asset of $164.9 million and a net deferred tax liability of $138.8 million. As of December 30, 2019, our deferred income tax asset of $164.9 million was net of a valuation allowance of approximately $25.9 million. Should our expectations of taxable income change in future periods, it may be necessary to adjust our valuation allowance, which could affect our results of operations in the period such a determination is made.

[0001564590-20-006477:mdna:38]
We are subject to income taxes in the United States and foreign jurisdictions. Significant judgment is required in determining our worldwide provision for income taxes. In the ordinary course of our business, there are many transactions for which the ultimate tax determination is uncertain. Additionally, our calculations of income taxes are based on our interpretations of applicable tax laws in the jurisdictions in which we file.

[0001564590-20-006477:mdna:39]
RESULTS OF OPERATIONS

[0001564590-20-006477:mdna:40]
We operate on a 52 or 53 week year ending on the Monday nearest December 31. Fiscal year 2019, 2018, and 2017 were 52 weeks ended December 30, 2019, December 31, 2018 and January 1, 2018, respectively.

[0001564590-20-006477:mdna:41]
The following table sets forth the relationship of various items to net sales in our consolidated statements of operations:

[0001564590-20-006477:mdna:42]
|  |  | For the Year Ended |  |  |
|  |  | December 30, 2019 |  |  |  | December 31, 2018 |  |  |  | January 1, 2018 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 85.1 |  |  |  |  | 83.9 |  |  |  |  | 83.8 |  |  |
| Gross profit |  |  | 14.9 |  |  |  |  | 16.1 |  |  |  |  | 16.2 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.8 |  |  |  |  | 2.6 |  |  |  |  | 2.5 |  |  |
| General and administrative |  |  | 5.7 |  |  |  |  | 5.6 |  |  |  |  | 4.7 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.8 |  |  |  |  | 2.1 |  |  |  |  | 1.0 |  |  |
| Restructuring charges |  |  | 0.3 |  |  |  |  | 0.2 |  |  |  |  | — |  |  |
| Total operating expenses |  |  | 10.6 |  |  |  |  | 10.5 |  |  |  |  | 8.2 |  |  |
| Operating income |  |  | 4.3 |  |  |  |  | 5.6 |  |  |  |  | 8.0 |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (3.1 | ) |  |  |  | (2.7 | ) |  |  |  | (2.0 | ) |  |
| Other, net |  |  | 0.3 |  |  |  |  | 0.3 |  |  |  |  | (0.7 | ) |  |
| Total other expense, net |  |  | (2.8 | ) |  |  |  | (2.4 | ) |  |  |  | (2.7 | ) |  |
| Income before income taxes |  |  | 1.5 |  |  |  |  | 3.2 |  |  |  |  | 5.3 |  |  |
| Income tax (provision) benefit |  |  | (0.2 | ) |  |  |  | 2.9 |  |  |  |  | (0.6 | ) |  |
| Net income |  |  | 1.3 |  | % |  |  | 6.1 |  | % |  |  | 4.7 |  | % |

[0001564590-20-006477:mdna:43]
The Anaren acquisition occurred on April 18, 2018. Accordingly, our fiscal year 2018 only includes Anaren’s 2018 results of operations since the acquisition date.

[0001564590-20-006477:mdna:44]
We have two reportable segments: PCB and E-M Solutions. The PCB reportable segment is comprised of multiple operating segments. Factors considered in determining whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production process, type or class of customers, distribution methods and regulatory environments.

[0001564590-20-006477:mdna:45]
Net Sales

[0001564590-20-006477:mdna:46]
Total net sales decreased $158.0 million, or 5.5%, to $2,689.3 million for the year ended December 30, 2019 from $2,847.3 million for the year ended December 31, 2018. Net sales for the PCB reportable segment decreased $158.3 million, or 6.0%, to $2,463.0 million for the year ended December 30, 2019 from $2,621.3 million for the year ended December 31, 2018. The reduction in PCB net sales was primarily due to lower demand in our commercial (non-Aerospace and Defense related) end markets, partially offset by increased demand in our Aerospace and Defense end market, which was primarily the result of the impact in the fiscal year 2019 of our acquisition of Anaren (which occurred on April 18, 2018) and higher demand at our other Aerospace and Defense focused facilities. These changes resulted in a 16.7% decrease in the volume of PCB shipments partially offset by an average PCB selling price increase of 10.0%, driven mainly by product mix shift, as compared to the year ended December 31, 2018. Net sales for the E-M Solutions reportable segment increased $0.4 million, or 0.2%, to $226.3 million for the year ended December 30, 2019 from $225.9 million for the year ended December 31, 2018. The increase was primarily due to higher demand in our Automotive end market, partially offset by a lower demand in Medical/Industrial/Instrumentation and Networking/Communications end markets.

[0001564590-20-006477:mdna:47]
Total net sales increased $188.7 million, or 7.1%, to $2,847.3 million for the year ended December 31, 2018 from $2,658.6 million for the year ended January 1, 2018. Net sales for the PCB reportable segment increased $172.8 million, or 7.1%, to $2,621.3 million for the year ended December 31, 2018 from $2,448.5 million for the year ended January 1, 2018. This increase was primarily due to the acquisition of Anaren, which accounted for $191.0 million in net sales in 2018, as well as higher demand in the Aerospace and Defense, Computing/Storage/Peripherals and Medical/Industrial/Instrumentation end markets compared to the year ended January 1, 2018, partially offset by a decline in demand in our Cellular Phone, Networking/Communications and Automotive end markets. These changes resulted in an average PCB selling price increase of 8.1%, driven mainly by product mix shift, however the resulting increase in net sales was partially offset by a 6.9% decrease in the volume of PCB shipments as compared to the year ended January 1, 2018. Net sales for the E-M Solutions reportable segment increased $15.8 million, or 7.5%, to $225.9 million for the year ended December 31, 2018 from $210.1 million for the year ended January 1, 2018. The increase was primarily due to higher demand in our Automotive and Networking/Communications end markets.

[0001564590-20-006477:mdna:48]
For information regarding net sales by country, see Note 17 of the Notes to Consolidated Financial Statements.

[0001564590-20-006477:mdna:49]
Gross Margin

[0001564590-20-006477:mdna:50]
Overall gross margin decreased to 14.9% for the year ended December 30, 2019 from 16.1% for the year ended December 31, 2018. Gross margin for the PCB reportable segment decreased to 16.3% for the year ended December 30, 2019 from 17.2% for the year ended December 31, 2018, primarily due to lower volumes in our commercially focused facilities. Gross margin for the E-M Solutions reportable segment decreased to 7.2% for the year ended December 30, 2019 from 8.0% for the year ended December 31, 2018, primarily due to mix shift toward higher direct material content work.

[0001564590-20-006477:mdna:51]
Overall gross margin decreased to 16.1% for the year ended December 31, 2018 from 16.2% for the year ended January 1, 2018. Gross margin for the PCB reportable segment was 17.2% for both the years ended January 1, 2018 and December 31, 2018, primarily due to the acquisition of Anaren and higher capacity utilization at our Aerospace & Defense focused facilities, offset by decreased volumes at our Cellular Phone focused facilities. Gross margin for the PCB reportable segment included a charge of $4.9 million to cost of goods sold associated with inventory resulting from purchase accounting. Gross margin for the E-M Solutions reportable segment decreased to 8.0% for the year ended December 31, 2018 from 8.1% for the year ended January 1, 2018.

[0001564590-20-006477:mdna:52]
Capacity utilization is a key driver for us, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the year ended December 30, 2019 in our Asia and North America PCB facilities was 64% and 58%, respectively, compared to 75% and 60%, respectively, for the year ended December 31, 2018. The decline in capacity utilization in our Asia and North America PCB facilities was due to a decrease in sales in our commercial end markets.

[0001564590-20-006477:mdna:53]
Selling and Marketing Expenses

[0001564590-20-006477:mdna:54]
Selling and marketing expenses increased $0.7 million to $74.0 million for the year ended December 30, 2019 from $73.3 million for the year ended December 31, 2018. As a percentage of net sales, selling and marketing expenses were 2.8% for the year ended December 30, 2019 as compared to 2.6% for the year ended December 31, 2018. The increase in selling and marketing expenses in 2019 primarily relates to expenses associated with operations acquired in the Anaren acquisition.

[0001564590-20-006477:mdna:55]
Selling and marketing expenses increased $7.4 million to $73.3 million for the year ended December 31, 2018 from $65.9 million for the year ended January 1, 2018. As a percentage of net sales, selling and marketing expenses were 2.6% for the year ended December 31, 2018 as compared to 2.5% for the year ended January 1, 2018. The increase in selling and marketing expenses in 2018 was primarily related to the acquisition of Anaren on April 18, 2018.

[0001564590-20-006477:mdna:56]
General and Administrative Expenses

[0001564590-20-006477:mdna:57]
General and administrative expenses decreased $7.3 million to $152.1 million, or 5.7% of net sales, for the year ended December 30, 2019 from $159.4 million, or 5.6% of net sales, for the year ended December 31, 2018. The decrease in expense was primarily due to the decrease in acquisition-related costs of $6.4 million primarily associated with the acquisition of Anaren on April 18, 2018 and a decrease in stock-based compensation and incentive compensation expense of $4.1 million and $2.3 million, respectively, partially offset by $6.4 million for the additional three and a half months of general and administrative expense associated with operations acquired in the Anaren acquisition in 2019 (which occurred on April 18, 2018).

[0001564590-20-006477:mdna:58]
General and administrative expenses increased $33.3 million to $159.4 million, or 5.6% of net sales, for the year ended December 31, 2018 from $126.1 million, or 4.7% of net sales, for the year ended January 1, 2018. The increase in expense was primarily related to general and administrative expenses incurred by Anaren post acquisition and $13.3 million of acquisition-related costs during the year ended December 31, 2018 primarily associated with the acquisition of Anaren on April 18, 2018.

[0001564590-20-006477:mdna:59]
Restructuring Charges

[0001564590-20-006477:mdna:60]
For the years ended December 30, 2019, December 31, 2018 and January 1, 2018, we incurred restructuring charges of $7.0 million, $5.5 million, and $1.2 million, respectively, related to realignment of operations with anticipated market demand, integration and other efficiency and cost saving measures following the acquisition of Anaren on April 18, 2018 and closure of our facilities in Cleveland, Ohio, Milpitas, California, and Juarez, Mexico and other global realignment efforts following the acquisition of Viasystems on May 31, 2015.

[0001564590-20-006477:mdna:61]
For the year ended December 30, 2019, we recognized restructuring charges of $6.9 million and $0.1 million in our PCB reportable segment and Corporate, respectively. For the year ended December 31, 2018, we recognized restructuring charges of $2.0 million and $3.5 million in our PCB reportable segment and Corporate, respectively. For the year ended January 1, 2018, we recognized restructuring charges of $0.3 million and $0.5 million in our PCB and E-M Solutions reportable segments, respectively, and $0.4 million in Corporate. These charges primarily represent employee separation and contract termination and other costs associated with the restructuring plans.

[0001564590-20-006477:mdna:62]
Other Income (Expense)

[0001564590-20-006477:mdna:63]
Other expense, net increased $4.6 million to $73.9 million for the year ended December 30, 2019 from $69.3 million for the year ended December 31, 2018. The increase in other expense, net was primarily due to:

[0001564590-20-006477:mdna:64]
|  | • | an increase in expense of $4.9 million due to $1.4 million of foreign exchange losses for the year ended December 30, 2019 compared to $3.5 million foreign exchange gains for the year ended December 31, 2018, primarily resulting from a strengthening Chinese Renminbi relative to the U.S. dollar, |

[0001564590-20-006477:mdna:65]
|  | • | an increase in interest expense of $4.3 million, primarily related to the $600.0 million incremental debt incurred in conjunction with the Anaren acquisition, |

[0001564590-20-006477:mdna:66]
|  | • | partially offset by an increase in other income related to the sale of other assets of $3.7 million and an increase in government subsidies of $0.9 million. |

[0001564590-20-006477:mdna:67]
Other expense, net decreased $3.5 million to $69.3 million for the year ended December 31, 2018 from $72.8 million for the year ended January 1, 2018. The decrease in other expense, net was primarily due to:

[0001564590-20-006477:mdna:68]
|  | • | a decrease in expense of $26.3 million due to $3.5 million of foreign exchange gains for the year ended December 31, 2018 compared to $22.8 million foreign exchange losses for the year ended January 1, 2018, primarily resulting from a weakening Chinese Renminbi relative to the U.S. dollar, |

[0001564590-20-006477:mdna:69]
|  | • | partially offset by an increase in interest expense of $25.1 million, primarily related to the $600.0 million incremental borrowing in conjunction with the Anaren acquisition, $23.0 million draw on our U.S. Asset-Based Lending Credit (U.S. ABL), higher amortization of debt issuance costs and debt discount and additional interest expense from our interest rate swap. |

[0001564590-20-006477:mdna:70]
Income Taxes

[0001564590-20-006477:mdna:71]
The provision for income taxes increased $88.7 million to an income tax expense of $4.9 million for the year ended December 30, 2019 from an income tax benefit of $83.8 million for the year ended December 31, 2018. The increase in income tax expense in 2019 was primarily due to the absence of a $121.4 million release of the Company’s valuation allowance against its net deferred tax assets in 2018, partially offset by a reduction in the deferred tax liability related to unremitted foreign earnings and tax benefits resulting from the decreased income before income taxes.

[0001564590-20-006477:mdna:72]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the US federal income tax rate, apportioned state income tax rates, generation of other credits and deductions available to us, as well as changes in valuation allowances, certain non-deductible items, global intangible low taxed income, and an establishment of a deferred tax liability related to unremitted foreign earnings.

[0001564590-20-006477:mdna:73]
The provision for income taxes decreased $99.1 million to an income tax benefit of $83.9 million for the year ended December 31, 2018 from an income tax expense of $15.2 million for the year ended January 1, 2018. The decrease in income tax expense in 2018 was primarily due to a release of the valuation allowance in the U.S. and certain foreign entities and an increase in tax incentives in China, partially offset by an increase to tax expense for the establishment of a deferred tax liability related to unremitted foreign earnings.

[0001564590-20-006477:mdna:74]
Liquidity and Capital Resources

[0001564590-20-006477:mdna:75]
Our principal sources of liquidity have been cash provided by operations, the issuance of Convertible Senior Notes, Term Loan, Senior Notes, and borrowings under our Revolving Credit Facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, meet debt service requirements, fund working capital requirements, and pay down existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001564590-20-006477:mdna:76]
Cash flow provided by operating activities during the year ended December 30, 2019 was $311.9 million as compared to $273.1 million in the same period in 2018. The increase in cash flow was primarily due to less investment in working capital, partially offset by decrease in net income of $132.3 million.

[0001564590-20-006477:mdna:77]
Net cash used in investing activities was approximately $136.0 million for the year ended December 30, 2019 primarily reflecting purchases of property, plant and equipment. Net cash used in investing activities was approximately $746.2 million for the year ended December 31, 2018 primarily reflecting $596.4 million for the acquisition of Anaren, net of debt assumed, and $150.1 million for purchases of property, plant and equipment.

[0001564590-20-006477:mdna:78]
Net cash used in financing activities was approximately $31.8 million for the year ended December 30, 2019, primarily reflecting repayment of long-term debt of $30.0 million and payment of debt issuance costs of $1.8 million. Net cash provided by financing activities was approximately $321.1 million for the year ended December 31, 2018, primarily reflecting proceeds of $623.0 million from the incremental term and revolving loan borrowings, offset by the repayment of assumed long-term debt related to the

[0001564590-20-006477:mdna:79]
acquisition of Anaren of $178.6 million, repayment of long-term debt of $114.4 million, and payment of debt issuance costs and original issue discount of $9.2 million associated with the Term Loan Facility and Senior Notes.

[0001564590-20-006477:mdna:80]
As of December 30, 2019, we had cash and cash equivalents of approximately $400.2 million, of which approximately $349.0 million was held by our foreign subsidiaries, primarily in China.

[0001564590-20-006477:mdna:81]
Our 2020 capital expenditure plan is expected to be in the range of $130.0 million to $140.0 million.

[0001564590-20-006477:mdna:82]
Long-term Debt and Letters of Credit

[0001564590-20-006477:mdna:83]
As of December 30, 2019, we had $1,475.9 million of outstanding debt, net of discount and debt issuance costs, composed of $797.2 million of Term Loan due September 2024, $369.7 million of Senior Notes due October 2025, $239.0 million of Convertible Senior Notes due December 2020, $40.0 million under the U.S. ABL, and $30.0 million under the Asia ABL.

[0001564590-20-006477:mdna:84]
Borrowings under the Term Loan Facility and Senior Notes Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. As of December 30, 2019, we were in compliance with the covenants under the Term Loan Facility, Senior Notes Facility and ABL Revolving Loans.

[0001564590-20-006477:mdna:85]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next twelve months. Additional information regarding our indebtedness, including information about availability under our credit facilities, interest rates and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 7, Long-term Debt and Letters of Credit, of the Notes to Consolidated Financial Statements included in this Annual Report on Form 10-K.

[0001564590-20-006477:mdna:86]
Contractual Obligations and Commitments

[0001564590-20-006477:mdna:87]
The following table provides information on our contractual obligations as of December 30, 2019:

[0001564590-20-006477:mdna:88]
|  |  | Total |  |  | Less Than 1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 1,250,879 |  |  | $ | — |  |  | $ | — |  |  | $ | 875,879 |  |  | $ | 375,000 |  |
| Convertible debt obligations |  |  | 249,975 |  |  |  | 249,975 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Interest on debt obligations |  |  | 306,709 |  |  |  | 62,541 |  |  |  | 117,004 |  |  |  | 106,070 |  |  |  | 21,094 |  |
| Derivative liabilities |  |  | 13,203 |  |  |  | 4,925 |  |  |  | 8,278 |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 1,469,067 |  |  |  | 1,318,437 |  |  |  | 141,967 |  |  |  | 675 |  |  |  | 7,988 |  |
| Total contractual obligations |  | $ | 3,289,833 |  |  | $ | 1,635,878 |  |  | $ | 267,249 |  |  | $ | 982,624 |  |  | $ | 404,082 |  |

[0001564590-20-006477:mdna:89]
| (1) | Unrecognized uncertain tax benefits of $39.3 million are not included in the table above as the settlement timing is uncertain. Operating leases are not included in the table above – see Note 2 of the Notes to Consolidated Financial Statements for further details. |

[0001564590-20-006477:mdna:90]
Off-Balance Sheet Arrangements

[0001564590-20-006477:mdna:91]
We do not have any relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, which would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes. In addition, we do not engage in trading activities involving non-exchange traded contracts. As a result, we are not materially exposed to any financing, liquidity, market, or credit risk that could arise if we had engaged in these relationships.

[0001564590-20-006477:mdna:92]
Seasonality

[0001564590-20-006477:mdna:93]
Orders for our products generally correspond to the production schedules of our customers. We historically experience higher net sales in the third and fourth quarters due to end customer demand in the fourth quarter for consumer electronics products. Seasonal fluctuations also include the Chinese New Year holidays in the first quarter, which typically results in lower net sales. We attribute this decline to shutdowns of our customers’ and our own China based manufacturing facilities surrounding the Chinese New Year public holidays, which normally occur in January or February of each year.

[0001564590-20-006477:mdna:94]
Recently Issued Accounting Standards

[0001564590-20-006477:mdna:95]
For a description of recently adopted and issued accounting standards, including the respective dates of adoption and expected effects on our results of operations and financial condition, see Note 1 of the Notes to Consolidated Financial Statements.
