# TTMI notes — 0001564590-20-006477


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001564590-20-006477:notes:1]
Portions of the registrant’s definitive Proxy Statement for its 2020 Annual Meeting of Stockholders are incorporated by reference into Part III of this report. Such Proxy Statement will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-20-006477:notes:2]
| (1) | Nature of Operations and Summary of Significant Accounting Policies |

[0001564590-20-006477:notes:3]
Nature of Operations

[0001564590-20-006477:notes:4]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions) as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. The Company provides time-to-market and volume production of advanced technology products and offers a one-stop design, engineering and manufacturing solution to customers. This one-stop design and manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001564590-20-006477:notes:5]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, automotive components, smartphones and other mobile devices, high-end computing, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-20-006477:notes:6]
The Company operates on a 52 or 53 week year ending on the Monday nearest December 31. Fiscal 2019, 2018, and 2017 were 52 weeks ended on December 30, 2019, December 31, 2018 and January 1, 2018, respectively. All references to years relate to fiscal years unless otherwise noted.

[0001564590-20-006477:notes:7]
Reclassifications

[0001564590-20-006477:notes:8]
Certain amounts in the prior period financial statements have been reclassified to conform to the presentation of the current period financial statements. These reclassifications had no effect on the previously reported net income. An adjustment has been made to combine the statutory surplus reserve with retained earnings on the consolidated statements of stockholders’ equity.

[0001564590-20-006477:notes:9]
Use of Estimates

[0001564590-20-006477:notes:10]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amount of revenues and expenses during the reporting period. Such estimates include the sales return reserve; accounts receivable; inventories; goodwill; intangible assets and other long-lived assets; product warranty liabilities; legal contingencies; income taxes; pension obligations; and fair values of financial instruments. These estimates and assumptions are based on management’s best estimates and judgment. Management evaluates its estimates and assumptions on an ongoing basis using historical experience and other factors, including the economic environment, which management believes to be reasonable under the circumstances. Management adjusts such estimates and assumptions when facts and circumstances dictate. The actual results we experienced may differ materially and adversely from our estimates. To the extent there are material differences between the estimates and actual results, our future result of operations will be affected.

[0001564590-20-006477:notes:11]
Principles of Consolidation

[0001564590-20-006477:notes:12]
The consolidated financial statements include the accounts of TTM and its subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001564590-20-006477:notes:13]
Foreign Currency Translation and Transactions

[0001564590-20-006477:notes:14]
The functional currency of certain of the Company’s subsidiaries is the Chinese Renminbi (RMB). Accordingly, assets and liabilities are translated into U.S. dollars using period-end exchange rates. Sales and expenses are translated at the average exchange rates in effect during the period. The resulting translation gains or losses are recorded as a component of accumulated other comprehensive (loss) income in the consolidated statement of stockholders’ equity and the consolidated statement of comprehensive income. Net gains and losses resulting from foreign currency remeasurements and transactions are included in income as a component of other, net in the consolidated statements of operations and totaled $1,430 loss, $3,529 gain and $22,802 loss for the years ended December 30, 2019, December 31, 2018 and January 1, 2018, respectively.

[0001564590-20-006477:notes:15]
Cash Equivalents

[0001564590-20-006477:notes:16]
The Company considers highly liquid investments with insignificant interest rate risk and original maturities to the Company of three months or less to be cash equivalents. Cash equivalents consist primarily of interest-bearing bank accounts.

[0001564590-20-006477:notes:17]
The Company considers highly liquid investments with an effective maturity to the Company of more than three months and less than one year to be short-term investments.

[0001564590-20-006477:notes:18]
Accounts Receivable and Allowance for Doubtful Accounts

[0001564590-20-006477:notes:19]
Accounts receivable are reflected at estimated net realizable value, do not bear interest and do not generally require collateral. The Company performs credit evaluations of its customers and adjusts credit limits based upon payment history and the customer’s current creditworthiness. The Company maintains an allowance for doubtful accounts based upon a variety of factors. The Company reviews all open accounts and provides specific reserves for customer collection issues when it believes the loss is probable, considering such factors as the length of time receivables are past due, the financial condition of the customer, and historical experience. The Company also records a reserve for all customers, excluding those that have been specifically reserved for, based upon evaluation of historical losses.

[0001564590-20-006477:notes:20]
The Company’s allowance for doubtful accounts was $1,929, $2,750, and $2,468 as of December 30, 2019, December 31, 2018 and January 1, 2018, respectively.

[0001564590-20-006477:notes:21]
Inventories

[0001564590-20-006477:notes:22]
Inventories are stated at the lower of cost (determined on a first-in, first-out and weighted average basis) or net realizable value. Assessments to value the inventory at the lower of the actual cost to purchase and / or manufacture the inventory, or net realizable value of the inventory, are based upon assumptions about future demand and market conditions. As a result of the Company’s assessments, when the net realizable value of inventory is less than the carrying value, the inventory cost is written down to the net realizable value and the write down is recorded as a charge to cost of goods sold.

[0001564590-20-006477:notes:23]
Property, Plant and Equipment, Net

[0001564590-20-006477:notes:24]
Property, plant and equipment are recorded at cost. Depreciation expense is computed using the straight-line method over the estimated useful lives of the assets. Assets recorded under leasehold improvements are amortized using the straight-line method over the lesser of their useful lives or the related lease term. The Company uses the following estimated useful lives:

[0001564590-20-006477:notes:25]
| Land use rights |  | 50-99 years |
| Buildings and improvements |  | 7-50 years |
| Machinery and equipment |  | 3-12 years |
| Furniture and fixtures |  | 3-7 years |

[0001564590-20-006477:notes:26]
Upon retirement or other disposition of property, plant and equipment, the cost and related accumulated depreciation are removed from the accounts. The resulting gain or loss is included in the determination of operating income in the period incurred. Depreciation and amortization expense on property, plant and equipment was $166,574, $162,708, and $150,809 for the years ended December 30, 2019, December 31, 2018 and January 1, 2018, respectively.

[0001564590-20-006477:notes:27]
The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is amortized over the average useful lives of such assets, which primarily consist of buildings and machinery and equipment. The Company capitalized interest costs of $1,810, $1,438 and $1,494 during the years ended December 30, 2019, December 31, 2018 and January 1, 2018, respectively, in connection with various capital projects.

[0001564590-20-006477:notes:28]
Major renewals and betterments are capitalized and depreciated over their estimated useful lives while minor expenditures for maintenance and repairs are included in operating income as incurred.

[0001564590-20-006477:notes:29]
Goodwill

[0001564590-20-006477:notes:30]
Goodwill represents the excess of purchase price of an acquisition over the fair value of net assets acquired. Goodwill is not amortized but instead is assessed for impairment, at a reporting unit level, annually and when events and circumstances warrant an evaluation. In making this assessment, management relies on a number of factors, including expected future operating results, business plans, economic projections, anticipated future cash flows, business trends and declines in the Company’s market capitalization.

[0001564590-20-006477:notes:31]
The Company has two reportable segments consisting of PCB and E-M Solutions. Goodwill is only attributable to the Company’s PCB reportable segment. Goodwill is allocated to reporting units, which are operating segments or one level below the Company’s operating segments (the component level). Reporting units are determined by the discrete financial information available for the component and whether it is regularly reviewed by segment management. Components are aggregated into a single reporting unit if they share similar economic characteristics. The Company’s PCB reportable segment is made up of two operating segments that consist of five reporting units. The Company evaluates its goodwill on an annual basis in the fourth quarter or more frequently if it believes indicators of impairment exist. The Company assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount or performs its annual impairment test. When tested quantitatively, the Company compares the fair value of the applicable reporting unit with its carrying value. The Company estimates the fair values of its reporting units using a combination of the income and market approaches. If the carrying amount of a reporting unit exceeds the reporting unit’s fair value, the amount by which the carrying value exceeds the fair value is recognized as an impairment loss. In the

[0001564590-20-006477:notes:32]
fourth quarter of 2019, the Company performed its annual impairment test qualitatively and concluded that goodwill was not impaired. See Note 5 for further details.

[0001564590-20-006477:notes:33]
Intangible Assets

[0001564590-20-006477:notes:34]
Intangible assets include customer relationships and technology, which are being amortized over their estimated useful lives on a straight-line basis. The estimated useful lives of such intangibles range from 5 years to 13 years.

[0001564590-20-006477:notes:35]
Impairment of Long-lived Assets

[0001564590-20-006477:notes:36]
Long-lived tangible assets, including property, plant and equipment, assets held for sale, and definite-lived intangible assets, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of the asset or asset groups may not be recoverable. The Company regularly evaluates whether events or circumstances have occurred that indicate possible impairment and relies on a number of factors, including expected future operating results, business plans, economic projections, and anticipated future cash flows. The Company uses an estimate of the future undiscounted net cash flows of the related asset or asset group over the remaining life in measuring whether the assets are recoverable. Measurement of the amount of impairment, if any, is based upon the difference between the asset’s carrying value and estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary.

[0001564590-20-006477:notes:37]
The Company classifies assets to be sold as assets held for sale when (i) Company management has approved and commits to a plan to sell the asset; (ii) the asset is available for immediate sale in its present condition and is ready for sale; (iii) an active program to locate a buyer and other actions required to sell the asset have been initiated; (iv) the sale of the asset is probable; (v) the asset is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and (vi) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn. Assets classified as held for sale are recorded at the lower of the carrying amount or fair value less the cost to sell and are included as a component of prepaid expenses and other current assets in the consolidated balance sheets.

[0001564590-20-006477:notes:38]
The Company classifies assets held for use when a decision to dispose of an asset or a business is made and the held for sale criteria are not met. Assets of the business are evaluated for recoverability in the following order: (i) assets other than goodwill, property and intangibles; (ii) property and intangibles subject to amortization; and (iii) goodwill. In evaluating the recoverability of property and intangible assets subject to amortization, in a held for use business, the carrying value is first compared to the sum of the undiscounted cash flows expected to result from the use and eventual disposition. If the carrying value exceeds the undiscounted expected cash flows, then a fair value analysis is performed. An impairment charge is recognized if the carrying value exceeds the fair value.

[0001564590-20-006477:notes:39]
Leases

[0001564590-20-006477:notes:40]
The Company adopted the new lease standard as of January 1, 2019 under the retrospective cumulative effect adjustment transition method. Therefore, the consolidated financial statements for the years ended December 31, 2018 and January 1, 2018 have not been adjusted and continued to be reported under previous U.S. GAAP guidance. As a result, beginning in the first quarter of 2019, the Company determines if an arrangement is a lease at inception. Operating leases are included in operating lease right-of-use (ROU) assets, and lease liabilities are included in other current liabilities and operating lease liabilities on the consolidated balance sheets.

[0001564590-20-006477:notes:41]
ROU assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent the Company’s obligation to make lease payments arising from the lease. Operating lease ROU assets and liabilities are recognized at commencement date based on the present value of lease payments over the lease term. As most of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date in determining the present value of lease payments. The operating lease ROU asset also includes any lease payments made and excludes lease incentives. Lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

[0001564590-20-006477:notes:42]
The Company has lease agreements with lease and non-lease components and accounts for the lease and non-lease components as a single lease component.

[0001564590-20-006477:notes:43]
Revenue Recognition

[0001564590-20-006477:notes:44]
The Company adopted the new revenue standard on January 2, 2018, using the cumulative effect transition method with adjustment to the opening balance of retained earnings at January 2, 2018 for all open contracts as of January 1, 2018. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated statement of operations for the year ended January 1, 2018. The impact of the adoption of the new revenue standard on the Company’s statement of operations for the years ended December 30, 2019 and December 31, 2018 were an additional revenue of $5,058 and $3,507, respectively and additional cost of goods sold of $4,231 and $2,422, respectively.

[0001564590-20-006477:notes:45]
The Company derives revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as the design and manufacture of RF and microwave components and assemblies. In the absence of a sales agreement, the Company’s standard terms and conditions apply. Revenue is recognized when control of the promised goods or services is transferred to the Company’s customers, in an amount that reflects the consideration to which it expects to be entitled in exchange for those goods or services. The Company applies a five-step approach as defined in the new standard in determining the amount and timing of revenue to be recognized: (1) identifying the contract with a customer; (2) identifying the performance obligations in the contract; (3) determining the transaction price; (4) allocating the transaction price to the performance obligations in the contract; and (5) recognizing revenue when the corresponding performance obligation is satisfied.

[0001564590-20-006477:notes:46]
Revenue Streams

[0001564590-20-006477:notes:47]
For PCBs and custom electronic assemblies, including pursuant to the Company’s long-term contracts related to the manufacture of components, assemblies and subsystems, orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous control of the work in progress and finished goods throughout the PCB and custom electronic assemblies manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right to payment for work performed to date. As a result, beginning in the first quarter of 2018, the Company began recognizing revenue over time based on the extent of progress towards completion of the performance obligation. Revenue recognized is based on the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

[0001564590-20-006477:notes:48]
In addition, the Company manufactures components, assemblies, and subsystems which service its wireless communications customers. The Company recognizes revenue at a point in time upon transfer of control of the products to the customer. Point in time recognition was determined as the customer does not simultaneously receive or consume the benefits provided by the Company’s performance and the asset being manufactured has alternative uses to the Company.

[0001564590-20-006477:notes:49]
Performance Obligations

[0001564590-20-006477:notes:50]
Each distinct promise to transfer products is considered to be an identified performance obligation for which revenue is recognized upon transfer of control of the products to the customer. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. The majority of the Company's contracts have a single performance obligation as the promise to transfer the individual good or service is not separately identifiable from other promises in the contract and is, therefore, not distinct. As of December 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations for the Company’s long-term contracts was $9,314. The Company expects to recognize revenue on approximately 100% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year or less.

[0001564590-20-006477:notes:51]
Transaction Price

[0001564590-20-006477:notes:52]
The Company provides customers a limited right of return for defective PCBs including components, subsystems and assemblies. Estimates of returns are treated as variable consideration for purposes of determining the transaction price. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns. To the extent actual experience varies from its historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued expenses on the consolidated balance sheets. Shipping and handling fees and related freight costs and supplies associated with shipping products to customers are included as a component of cost of goods sold. Warranty-related services are not considered a separate performance obligation. Incremental warranty costs that are not related to sales returns are recorded in accrued expenses on the consolidated balance sheets and cost of goods sold on the consolidated statements of operations. The following summarizes the activity in the Company’s sales returns and allowances for the years ended December 30, 2019, December 31, 2018 and January 1, 2018:

[0001564590-20-006477:notes:53]
|  |  | For the Year Ended |  |
|  |  | December 30, |  |  | December 31, |  |  | January 1, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 16,071 |  |  | $ | 8,171 |  |  | $ | 8,119 |  |
| Addition charged as a reduction of sales (1) |  |  | 15,632 |  |  |  | 23,525 |  |  |  | 14,574 |  |
| Deductions |  |  | (18,176 | ) |  |  | (15,602 | ) |  |  | (14,524 | ) |
| Effect of foreign currency exchange rates |  |  | 17 |  |  |  | (23 | ) |  |  | 2 |  |
| Balance at end of year |  | $ | 13,544 |  |  | $ | 16,071 |  |  | $ | 8,171 |  |

[0001564590-20-006477:notes:54]
|  | (1) | On the date of adopting the new revenue standard, the Company recorded an estimated sales returns and allowance in the amount of $5,213 as of January 2, 2018. |

[0001564590-20-006477:notes:55]
Contract Balances

[0001564590-20-006477:notes:56]
Accounts receivable represents the Company’s unconditional right to receive consideration from its customer. Payments are generally due within 90 days or less of invoicing and do not include a significant financing component. To date, there have been no material impairment losses on accounts receivable.

[0001564590-20-006477:notes:57]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment. Contract assets are classified as current assets and are transferred to receivables when the entitlement to payment becomes unconditional. The Company’s contract assets are generally converted to trade account receivables within 90 days, at which time the Company is entitled to payment of the fixed price upon delivery of the finished product subject to customer payment terms. Contract assets were $288,235 and $287,741 as of December 30, 2019 and December 31, 2018, respectively, and represent unbilled amounts for work performed to date. In 2019, there were no material impairment losses on contract assets.

[0001564590-20-006477:notes:58]
A contract liability is recognized when the Company has received payment in advance for the future transfer of goods or services. The Company’s contract liabilities are generally converted to revenue within 90 days. Contract liabilities were $3,838 and $3,220 as of December 30, 2019 and December 31, 2018, respectively, and represent customer advances for work yet to be performed.

[0001564590-20-006477:notes:59]
The Company has elected to account for shipping and handling activities as a fulfillment cost as permitted by the standard. All incremental customer contract acquisition costs are expensed as they are incurred as the amortization period of the asset that the Company otherwise would have recognized is one year or less in duration.

[0001564590-20-006477:notes:60]
Disaggregated Revenue

[0001564590-20-006477:notes:61]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue in 2019 and 2018. In 2017, all revenue from products and services transferred to customers was recognized at a point in time.

[0001564590-20-006477:notes:62]
The following tables represent a disaggregation of revenue by principal end markets with the reportable segments:

[0001564590-20-006477:notes:63]
|  |  | For the Year Ended December 30, 2019 |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 698,742 |  |  | $ | 543 |  |  | $ | 699,285 |  |  |
| Automotive |  |  | 322,382 |  |  |  | 102,004 |  |  |  | 424,386 |  |  |
| Cellular Phone |  |  | 336,725 |  |  |  | — |  |  |  | 336,725 |  |  |
| Computing/Storage/Peripherals |  |  | 360,262 |  |  |  | 288 |  |  |  | 360,550 |  |  |
| Medical/Industrial/Instrumentation |  |  | 355,072 |  |  |  | 29,682 |  |  |  | 384,754 |  |  |
| Networking/Communications |  |  | 321,952 |  |  |  | 94,435 |  |  |  | 416,387 |  |  |
| Other |  |  | 67,840 |  |  |  | (619 | ) |  |  | 67,221 |  |  |
| Total |  | $ | 2,462,975 |  |  | $ | 226,333 |  |  | $ | 2,689,308 |  |  |

[0001564590-20-006477:notes:64]
|  |  | For the Year Ended December 31, 2018 (1) |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 607,862 |  |  | $ | 858 |  |  | $ | 608,720 |  |  |
| Automotive |  |  | 415,772 |  |  |  | 86,828 |  |  |  | 502,600 |  |  |
| Cellular Phone |  |  | 385,757 |  |  |  | — |  |  |  | 385,757 |  |  |
| Computing/Storage/Peripherals |  |  | 399,692 |  |  |  | 1,694 |  |  |  | 401,386 |  |  |
| Medical/Industrial/Instrumentation |  |  | 370,171 |  |  |  | 39,852 |  |  |  | 410,023 |  |  |
| Networking/Communications |  |  | 381,038 |  |  |  | 96,894 |  |  |  | 477,932 |  |  |
| Other |  |  | 61,022 |  |  |  | (179 | ) |  |  | 60,843 |  |  |
| Total |  | $ | 2,621,314 |  |  | $ | 225,947 |  |  | $ | 2,847,261 |  |  |

[0001564590-20-006477:notes:65]
|  |  | For the Year Ended January 1, 2018 (2) |  |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 418,238 |  |  | $ | 1,544 |  |  | $ | 419,782 |  |  |
| Automotive |  |  | 434,775 |  |  |  | 76,401 |  |  |  | 511,176 |  |  |
| Cellular Phone |  |  | 483,805 |  |  |  | — |  |  |  | 483,805 |  |  |
| Computing/Storage/Peripherals |  |  | 352,862 |  |  |  | 4,247 |  |  |  | 357,109 |  |  |
| Medical/Industrial/Instrumentation |  |  | 330,093 |  |  |  | 38,257 |  |  |  | 368,350 |  |  |
| Networking/Communications |  |  | 390,335 |  |  |  | 88,506 |  |  |  | 478,841 |  |  |
| Other |  |  | 38,398 |  |  |  | 1,131 |  |  |  | 39,529 |  |  |
| Total |  | $ | 2,448,506 |  |  | $ | 210,086 |  |  | $ | 2,658,592 |  |  |

[0001564590-20-006477:notes:66]
| (1) | Amended for Anaren integration. |

[0001564590-20-006477:notes:67]
| (2) | The Company adopted ASC Topic 606, Revenue from Contracts with Customers, under the modified retrospective method on January 2, 2018. Accordingly, the consolidated financial statements for the year ended January 1, 2018 have not been adjusted. |

[0001564590-20-006477:notes:68]
Stock-Based Compensation

[0001564590-20-006477:notes:69]
The Company recognizes stock-based compensation expense in its consolidated financial statements for its incentive compensation plan awards. The incentive compensation plan awards include performance-based restricted stock units, restricted stock units, and stock options. The associated compensation expense for all awards is based on the grant date fair value of the awards. For performance-based restricted stock units, compensation expense also includes management’s periodic assessment of annual financial performance goals to be achieved. Compensation expense for the incentive compensation plan awards is recognized on a straight line basis over the vesting period of the awards. The fair value of performance-based restricted stock units is estimated on the grant date using a Monte Carlo simulation model based on the underlying common stock closing price as of the date of grant, the expected term, stock price volatility, and risk-free interest rates. The fair value of restricted stock units is measured on the grant date based on the quoted closing market price of the Company’s common stock. The fair value of the stock options is estimated on the grant date using the Black-Scholes option pricing model based on the underlying common stock closing price as of the date of grant, the expected term, stock price volatility, and risk-free interest rates.

[0001564590-20-006477:notes:70]
Income Taxes

[0001564590-20-006477:notes:71]
Income taxes are accounted for under the asset and liability method. Deferred income tax assets or liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of assets and liabilities and their respective tax bases and operating loss and tax credit carryforwards. Deferred income tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be settled or realized. The effect on deferred income tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. Deferred income tax assets are reviewed for recoverability, and the Company records a valuation allowance to reduce its deferred income tax assets when it is more likely than not that all or some portion of the deferred income tax assets will not be realized.

[0001564590-20-006477:notes:72]
The Company has various foreign subsidiaries formed or acquired to conduct or support its business outside the United States. The Company expects its earnings attributable to foreign subsidiaries will be indefinitely reinvested except for our material Chinese and Canadian plants and the respective holding companies where a deferred tax liability has been recorded for foreign withholding and estimated federal/state tax impact. For those other companies with earnings currently being reinvested outside of the U.S., no deferred tax liabilities on undistributed earnings are recorded.

[0001564590-20-006477:notes:73]
The Company recognizes the effect of income tax positions only if those positions are more likely than not to be sustained. Recognized income tax positions are measured at the largest amount that is greater than 50 percent likely to be realized. Changes in recognition or measurement are reflected in the period in which the change in judgment occurs. Estimated interest and penalties related to underpayment of income taxes are recorded as a component of income tax provision in the consolidated statements of operations.

[0001564590-20-006477:notes:74]
Convertible Debt

[0001564590-20-006477:notes:75]
The accounting standards for convertible debt instruments that may be fully or partially settled in cash upon conversion require the debt and equity components to be separately accounted for in a manner that reflects the Company’s nonconvertible borrowing rate when interest expense is recognized in subsequent periods. The amount recorded as debt is based on the fair value of the debt component as a standalone instrument, determined using an average interest rate for similar nonconvertible debt issued by entities with credit ratings comparable to the Company’s at the time of issuance. The difference between the debt recorded at inception and its principal amount is accreted to principal through interest expense during the estimated life of the note.

[0001564590-20-006477:notes:76]
Value Added and Sales Tax Collected from Customers

[0001564590-20-006477:notes:77]
As a part of the Company’s normal course of business, value added and sales taxes are collected from customers. Such taxes collected are remitted, in a timely manner, to the appropriate governmental tax authority on behalf of the customer. Value added and sales taxes are excluded from reported revenues and costs of goods sold presented in the consolidated statements of operations and comprehensive income.

[0001564590-20-006477:notes:78]
Fair Value Measures

[0001564590-20-006477:notes:79]
The Company measures at fair value certain of its financial and non-financial assets and liabilities by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability. The levels of the fair value hierarchy are:

[0001564590-20-006477:notes:80]
Level 1 — Quoted market prices in active markets for identical assets or liabilities;

[0001564590-20-006477:notes:81]
Level 2 — Significant other observable inputs (e.g., quoted prices for similar items in active markets, quoted prices for identical or similar items in markets that are not active, inputs other than quoted prices that are observable, such as interest rate and yield curves, and market-corroborated inputs); and

[0001564590-20-006477:notes:82]
Level 3 — Unobservable inputs in which there is little or no market data, which require the reporting unit to develop its own assumptions.

[0001564590-20-006477:notes:83]
Earnings Per Share

[0001564590-20-006477:notes:84]
Basic earnings per common share excludes dilution and is computed by dividing net income attributable to TTM Technologies, Inc. stockholders by the weighted average number of common shares outstanding during the period. Diluted earnings per common share reflect the potential dilution that could occur if stock options, Convertible Senior Notes or other common stock equivalents were exercised or converted into common stock. The dilutive effect of stock options or other common stock equivalents is calculated using the treasury stock method, while the dilutive effect of Convertible Senior Notes is calculated using the if-converted method.

[0001564590-20-006477:notes:85]
Comprehensive Income

[0001564590-20-006477:notes:86]
Comprehensive income includes changes to equity accounts that were not the result of transactions with stockholders. Comprehensive income is comprised of net income, changes in the cumulative foreign currency translation adjustments, pension obligation adjustments, and realized and unrealized gains or losses on hedged derivative instruments.

[0001564590-20-006477:notes:87]
Non-controlling Interest Holdings

[0001564590-20-006477:notes:88]
Non-controlling interest consisted of a 5% equity interest in a manufacturing facility in Huiyang, China which was acquired along with other assets and liabilities of Viasystems Group Inc. (Viasystems). In 2017, the Company purchased the 5% equity interest from the non-controlling interest holder. See Note 20.

[0001564590-20-006477:notes:89]
Loss Contingencies

[0001564590-20-006477:notes:90]
The Company establishes an accrual for an estimated loss contingency when it is both probable that an asset has been impaired or that a liability has been incurred and the amount of the loss can be reasonably estimated. Any legal fees expected to be incurred in connection with a contingency are expensed as incurred.

[0001564590-20-006477:notes:91]
Accounting for Retirement Benefit Plans

[0001564590-20-006477:notes:92]
The Company accounts for its retirement benefit plans and postretirement and postemployment benefit obligations in accordance with ASC Topic 715, Compensation—Retirement Benefits. ASC Topic 715 requires the Company to recognize the overfunded or underfunded status of a defined benefit plan, measured as the difference between the fair value of plan assets and the plan's benefit obligation, as an asset or liability in its consolidated balance sheets and to recognize changes to that funded status in the year in which the changes occur through accumulated other comprehensive loss. ASC Topic 715 also requires measurement of the funded status of a plan as of the Company's consolidated balance sheet dates.

[0001564590-20-006477:notes:93]
Recently Adopted and Issued Accounting Standards

[0001564590-20-006477:notes:94]
Recently Adopted Accounting Standards

[0001564590-20-006477:notes:95]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU 2016-02, Leases (Topic 842) which supersedes the existing lease recognition requirements in the current accounting standard for leases. The core principal of the new standard is that an entity should recognize ROU assets and lease liabilities arising from a lease for both financing and operating leases, along with additional qualitative and quantitative disclosures.

[0001564590-20-006477:notes:96]
In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements. ASU 2018-11 provides additional guidance to Topic 842 including providing preparers an additional optional retrospective adoption method which allows entities to initially apply the new leases standard at the adoption date and recognize a cumulative effect adjustment to the opening balance of retained earnings. ASU 2018-11 also provides lessors a practical expedient to not separate lease from non-lease components, in certain situations.

[0001564590-20-006477:notes:97]
The Company adopted the new lease standard as of January 1, 2019 and utilized the retrospective cumulative effect adjustment transition method with a cumulative effect adjustment being recorded as of the adoption date. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet as of December 31, 2018 and the consolidated statements of operations for the years ended December 31, 2018 and January 1, 2018. The Company implemented internal controls and key system functionality to enable the preparation of financial information on adoption. The Company elected certain available practical expedients including the package of practical expedients permitted under the transition guidance within the new standard, which among other things, allowed the Company to carry forward the historical lease classification. Additionally, the Company elected an accounting policy to not record ROU assets and lease liabilities for leases with an initial term of twelve months or less on its consolidated balance sheet.

[0001564590-20-006477:notes:98]
The cumulative effect of the changes made to the Company’s January 1, 2019 consolidated balance sheet for the adoption of the new lease standard was as follows:

[0001564590-20-006477:notes:99]
|  |  | Balance as of December 31, 2018 |  |  | New Lease Standard Adjustment |  |  | Balance as of January 1, 2019 |  |
|  |  | (In thousands) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease right-of-use assets |  | $ | — |  |  | $ | 16,894 |  |  | $ | 16,894 |  |
| Deposits and other non-current assets |  |  | 55,597 |  |  |  | (548 | ) |  |  | 55,049 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  |  | 113,756 |  |  |  | 2,545 |  |  |  | 116,301 |  |
| Operating lease liabilities |  |  | — |  |  |  | 14,356 |  |  |  | 14,356 |  |
| Other long-term liabilities |  |  | 94,777 |  |  |  | (555 | ) |  |  | 94,222 |  |

[0001564590-20-006477:notes:100]
The adoption of the new accounting guidance did not have a material impact to the consolidated statement of operations or the consolidated statement of cash flows for the year ended December 30, 2019. See Note 2 for further details.

[0001564590-20-006477:notes:101]
In June 2018, the FASB issued ASU 2018-07, Compensation-Stock Compensation (Topic 718): Improvements to Nonemployee Share-based Payments. This ASU expands the scope of Topic 718 to include share-based payment transactions for acquiring goods and services from nonemployees. The effective date for the standard is for interim periods in fiscal years beginning after December 15, 2018, with early adoption permitted, but no earlier than the Company's adoption date of Topic 606. The new guidance is required to be applied retrospectively with the cumulative effect recognized at the date of initial application. The Company adopted ASU 2018-07 on January 1, 2019. The adoption did not have a material impact on the consolidated financial statements or related disclosures.

[0001564590-20-006477:notes:102]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. The Company adopted ASU 2017-12 on January 1, 2019. The adoption did not have a material impact on the consolidated financial statements or related disclosures.

[0001564590-20-006477:notes:103]
Recently Issued Accounting Standards Not Yet Adopted

[0001564590-20-006477:notes:104]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years ending after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company has evaluated the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures and the impact is not expected to be material.

[0001564590-20-006477:notes:105]
In August 2018, the FASB issued ASU 2018-14, Compensation—Retirement Benefits—Defined Benefit Plans—General (Subtopic 715-20)—Disclosure Framework—Changes to the Disclosure Requirements for Defined Benefit Plans. The amendments in this update change the disclosure requirements for employers that sponsor defined benefit pension and/or other postretirement benefit plans. It eliminates requirements for certain disclosures that are no longer considered cost beneficial and requires new disclosures that the FASB considers pertinent. The guidance is effective for fiscal years ending after December 15, 2020. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on the consolidated financial statements and related disclosures.

[0001564590-20-006477:notes:106]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancellable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments—Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU

[0001564590-20-006477:notes:107]
2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. In November 2019, the FASB issued ASU 2019-11, Codification Improvements to Topic 326, Financial Instruments—Credit Losses, which clarifies the treatment of expected recoveries for amounts previously written off on purchased receivables, provides transition relief for troubled debt restructurings, and allows for certain disclosure simplifications of accrued interest. All of these ASUs are effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company has evaluated the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures and the impact is not expected to be material.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-20-006477:notes:108]
| (2) | Leases |

[0001564590-20-006477:notes:109]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the ROU asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-20-006477:notes:110]
The components of lease expense were as follows:

[0001564590-20-006477:notes:111]
|  | For the Year Ended December 30, 2019 |  |
|  | (In thousands) |  |
| Operating lease cost | $ | 9,262 |  |
| Variable lease cost |  | 11,283 |  |
| Short-term lease cost |  | 1,273 |  |

[0001564590-20-006477:notes:112]
Supplemental cash flow information related to leases was as follows:

[0001564590-20-006477:notes:113]
|  | For the Year Ended December 30, 2019 |  |
|  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 8,658 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |
| Operating leases |  | 15,697 |  |

[0001564590-20-006477:notes:114]
Supplemental balance sheet information related to leases was as follows:

[0001564590-20-006477:notes:115]
|  | As of December 30, 2019 |  |
|  | (In thousands) |  |
| Operating lease right-of-use assets | $ | 24,156 |  |
| Other current liabilities |  | 8,178 |  |
| Operating lease liabilities |  | 16,517 |  |
| Total operating lease liabilities | $ | 24,695 |  |

[0001564590-20-006477:notes:116]
| Weighted average remaining lease term | 4.2 years |  |
| Weighted average discount rate |  | 3.81 | % |

[0001564590-20-006477:notes:117]
Maturities of operating lease liabilities were as follows (1):

[0001564590-20-006477:notes:118]
|  |  | (In thousands) |  |
| Less than one year |  | $ | 8,795 |  |
| 1 - 2 years |  |  | 7,504 |  |
| 2 - 3 years |  |  | 3,497 |  |
| 3 - 4 years |  |  | 2,219 |  |
| 4 - 5 years |  |  | 1,865 |  |
| Thereafter |  |  | 2,951 |  |
| Total lease payments |  |  | 26,831 |  |
| Less imputed interest |  |  | (2,136 | ) |
| Total |  | $ | 24,695 |  |

[0001564590-20-006477:notes:119]
|  | (1) | Excludes $1,169 of legally binding minimum lease payments for leases signed but not yet commenced. |

[0001564590-20-006477:notes:120]
Operating Leases Pre-Topic 842 Adoption

[0001564590-20-006477:notes:121]
The following is a schedule of future minimum lease payments as of December 31, 2018:

[0001564590-20-006477:notes:122]
|  |  | Operating Leases |  |
|  |  | (In thousands) |  |
| 2019 |  | $ | 7,282 |  |
| 2020 |  |  | 4,701 |  |
| 2021 |  |  | 3,406 |  |
| 2022 |  |  | 2,408 |  |
| 2023 |  |  | 2,172 |  |
| Thereafter |  |  | 4,172 |  |
| Total minimum lease payments |  | $ | 24,141 |  |

[0001564590-20-006477:notes:123]
Total rent expense for the years ended December 31, 2018 and January 1, 2018 was approximately $20,345 and $16,665, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-006477:notes:124]
| (3) | Restructuring Charges |

[0001564590-20-006477:notes:125]
The Company periodically incurs restructuring charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand. Following the acquisition of Anaren on April 18, 2018 and following the acquisition of Viasystems on May 31, 2015, the Company incurred employee separation costs and contract termination and other costs related to the integration and other efficiency and cost saving measures. Contract termination and other costs primarily represented plant closure costs as well as costs related to building operating leases. Following the acquisition of Viasystems on May 31, 2015, the Company closed certain facilities which resulted in the layoff of related employees at these facilities. The actions taken were part of the Company’s integration strategy to improve total plant utilization, operational performance and customer focus.

[0001564590-20-006477:notes:126]
The below table summarizes such restructuring costs by reportable segment for the years ended December 30, 2019, December 31, 2018 and January 1, 2018:

[0001564590-20-006477:notes:127]
|  |  | For the Year Ended |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 6,856 |  |  | $ | 15 |  |  | $ | 6,871 |  |  | $ | 2,008 |  |  | $ | — |  |  | $ | 2,008 |  |  | $ | 178 |  |  | $ | 99 |  |  | $ | 277 |  |
| E-M Solutions |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 520 |  |  |  | 520 |  |
| Corporate |  |  | 80 |  |  |  | 30 |  |  |  | 110 |  |  |  | 3,389 |  |  |  | 121 |  |  |  | 3,510 |  |  |  | 33 |  |  |  | 360 |  |  |  | 393 |  |
|  |  | $ | 6,936 |  |  | $ | 45 |  |  | $ | 6,981 |  |  | $ | 5,397 |  |  | $ | 121 |  |  | $ | 5,518 |  |  | $ | 211 |  |  | $ | 979 |  |  | $ | 1,190 |  |

[0001564590-20-006477:notes:128]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated balance sheets. The below table shows the utilization of the accrued restructuring costs during the years ended December 30, 2019 and December 31, 2018:

[0001564590-20-006477:notes:129]
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of January 1, 2018 |  | $ | — |  |  | $ | 499 |  |  | $ | 499 |  |
| Charged to expense |  |  | 5,397 |  |  |  | 121 |  |  |  | 5,518 |  |
| Amount paid |  |  | (2,239 | ) |  |  | (227 | ) |  |  | (2,466 | ) |
| Accrued as of December 31, 2018 |  | $ | 3,158 |  |  | $ | 393 |  |  | $ | 3,551 |  |
| Charged to expense |  |  | 6,936 |  |  |  | 45 |  |  |  | 6,981 |  |
| Amount paid |  |  | (9,834 | ) |  |  | (196 | ) |  |  | (10,030 | ) |
| Accrued as of December 30, 2019 |  | $ | 260 |  |  | $ | 242 |  |  | $ | 502 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-20-006477:notes:130]
| (4) | Composition of Certain Consolidated Financial Statement Captions |

[0001564590-20-006477:notes:131]
|  |  | As of |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 108,236 |  |  | $ | 97,600 |  |
| Work-in-process |  |  | 8,588 |  |  |  | 10,299 |  |
| Finished goods |  |  | 5,195 |  |  |  | 1,478 |  |
|  |  | $ | 122,019 |  |  | $ | 109,377 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 74,850 |  |  | $ | 75,431 |  |
| Buildings and improvements |  |  | 543,546 |  |  |  | 534,122 |  |
| Machinery and equipment |  |  | 1,436,795 |  |  |  | 1,357,035 |  |
| Construction-in-progress, furniture and fixtures and other |  |  | 71,416 |  |  |  | 42,713 |  |
|  |  |  | 2,126,607 |  |  |  | 2,009,301 |  |
| Less: Accumulated depreciation |  |  | (1,103,678 | ) |  |  | (957,277 | ) |
|  |  | $ | 1,022,929 |  |  | $ | 1,052,024 |  |
| Other current liabilities: |  |  |  |  |  |  |  |  |
| Sales returns and allowances |  | $ | 13,544 |  |  | $ | 16,071 |  |
| Income taxes payable |  |  | 12,899 |  |  |  | 11,345 |  |
| Interest |  |  | 8,893 |  |  |  | 9,260 |  |
| Restructuring |  |  | 502 |  |  |  | 3,551 |  |
| Other |  |  | 74,729 |  |  |  | 73,529 |  |
|  |  | $ | 110,567 |  |  | $ | 113,756 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-20-006477:notes:132]
| (5) | Goodwill |

[0001564590-20-006477:notes:133]
As of December 30, 2019 and December 31, 2018, goodwill was as follows:

[0001564590-20-006477:notes:134]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 1, 2018 |  |  |  |  |
| Goodwill |  |  | 543,971 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  |  | 372,571 |  |
| Goodwill recognized during the year |  |  | 394,474 |  |
| Balance as of December 31, 2018 |  |  |  |  |
| Goodwill |  |  | 938,445 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  |  | 767,045 |  |
| Goodwill recognized during the year |  |  | 7,746 |  |
| Balance as of December 30, 2019 |  |  |  |  |
| Goodwill |  |  | 946,191 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  | $ | 774,791 |  |

[0001564590-20-006477:notes:135]
Goodwill balances include foreign currency translation adjustments related to foreign subsidiaries with functional currencies other than the U.S. Dollar. All of the Company’s goodwill is included as a component of the PCB reportable segment.

[0001564590-20-006477:notes:136]
On November 14, 2019, the Company acquired substantially all the assets of i3 Electronics, Inc. in order to strengthen its advanced technology PCB capabilities and IP portfolio for emerging applications in the aerospace and defense end market and for high end commercial customers. The net assets acquired consists of property, plant, and equipment, customer relationships, and technology. Goodwill is primarily attributable to the benefits the Company expects to derive from enhancing the Company’s capabilities and credentials as a global technology leader for PCB product solutions and RF components as well as the acquired workforce. Goodwill is expected to be deductible for tax purposes because the acquisition was legally structured as an asset acquisition but accounted for as business combinations under FASB ASC Topic 805, Business Combinations. During the year ended December 30, 2019, the expenses incurred by the Company related to this acquisition were immaterial and are included within general and administrative expenses in the consolidated statements of operations. Revenues and earnings related to this acquisition were not material.

[0001564590-20-006477:notes:137]
The Company evaluates its goodwill on an annual basis during its fourth fiscal quarter and at other times when events or changes in circumstances — such as significant adverse changes in the business climate or operating results or changes in management strategy, coupled with a decline in the market price of its stock and market capitalization — indicate that there may be a potential impairment. During the third fiscal quarter, the Company’s Communications and Computing and Automotive and Medical/Industrial/Instrumentation reporting units had lower than anticipated results and continued declines in sales. The Company considered these factors to be indicators of potential impairment requiring the Company to test the related goodwill of $39,300 for the Communications and Computing reporting unit and $185,500 for the Automotive and Medical/Industrial/Instrumentation reporting unit for impairment as of September 30, 2019. The Company completed a quantitative goodwill impairment analysis related to its Communications and Computing and Automotive and Medical/Industrial/Instrumentation reporting units by comparing the fair value of the reporting unit with its carrying amount. The Company determined the fair value of the reporting units by using discounted cash flow (DCF) and market analyses. Under the market approach, the Company used revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting units.

[0001564590-20-006477:notes:138]
Fair value is typically estimated using a DCF analysis which requires the Company to estimate the future cash flows as well as to select a risk-adjusted discount rate to measure the present value of the anticipated cash flows. When determining future cash flow estimates, the Company considers historical results adjusted to reflect current and anticipated future operating conditions. The Company estimates cash flows for a reporting unit over a discrete period and a terminal period (considering expected long-term growth rates and trends).

[0001564590-20-006477:notes:139]
Based on its analysis, the Company estimates that the fair value of the Communications and Computing and Automotive and Medical/Industrial/Instrumentation reporting units exceeded its respective carrying value by 19% and 8%, respectively. If the Company’s future cash flow projections and other fair value assumptions for its reporting unit change, the Company may be subject to potential impairment in subsequent quarters. Estimating the fair value of the reporting unit requires the Company to make assumptions and estimates in such areas as future economic conditions, industry-specific conditions, product pricing, and necessary capital expenditures. The Company used risk adjusted discount rates between 14% and 17% to discount the expected future cash flows. The use of different assumptions or estimates for future cash flows, discount rates, or terminal growth rates could produce substantially different estimates of the fair value of the reporting unit.

[0001564590-20-006477:notes:140]
In the fourth quarter of 2019, the Company performed its annual goodwill impairment test qualitatively and concluded that it was more likely than not that there was no impairment to goodwill.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-20-006477:notes:141]
| (6) | Definite-lived Intangibles |

[0001564590-20-006477:notes:142]
As of December 30, 2019 and December 31, 2018, the components of definite-lived intangibles were as follows:

[0001564590-20-006477:notes:143]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| December 30, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 415,000 |  |  | $ | (123,674 | ) |  | $ | 291,326 |  |  |  | 10.8 |  |
| Technology |  |  | 39,500 |  |  |  | (8,064 | ) |  |  | 31,436 |  |  |  | 9.4 |  |
| Acquired intangibles from current year acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 1,230 |  |  |  | (31 | ) |  |  | 1,199 |  |  |  | 5.0 |  |
| Technology |  |  | 8,150 |  |  |  | (103 | ) |  |  | 8,047 |  |  |  | 10.0 |  |
|  |  | $ | 463,880 |  |  | $ | (131,872 | ) |  | $ | 332,008 |  |  |  |  |  |
| December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,634 |  |  | $ | (123,522 | ) |  | $ | 80,112 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (3,000 | ) |  |  | — |  |  |  | 3.0 |  |
| Acquired intangibles from current year acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 267,500 |  |  |  | (15,561 | ) |  |  | 251,939 |  |  |  | 12.2 |  |
| Developed technology |  |  | 39,500 |  |  |  | (3,345 | ) |  |  | 36,155 |  |  |  | 9.4 |  |
| Backlog |  |  | 29,000 |  |  |  | (21,283 | ) |  |  | 7,717 |  |  |  | 0.9 |  |
|  |  | $ | 542,634 |  |  | $ | (166,711 | ) |  | $ | 375,923 |  |  |  |  |  |

[0001564590-20-006477:notes:144]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $53,296, $63,026, and $23,634 for the years ended December 30, 2019, December 31, 2018 and January 1, 2018, respectively. For the years ended December 30, 2019 and December 31, 2018, $4,822 and $3,345, respectively, of amortization expense is included in cost of goods sold.

[0001564590-20-006477:notes:145]
Estimated aggregate amortization for definite-lived intangible assets for the next five years and thereafter is as follows:

[0001564590-20-006477:notes:146]
|  |  | (In thousands) |  |
| 2020 |  | $ | 46,480 |  |
| 2021 |  |  | 43,190 |  |
| 2022 |  |  | 40,063 |  |
| 2023 |  |  | 37,351 |  |
| 2024 |  |  | 29,812 |  |
| Thereafter |  |  | 135,112 |  |
|  |  | $ | 332,008 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-20-006477:notes:147]
| (7) | Long-term Debt and Letters of Credit |

[0001564590-20-006477:notes:148]
The following table summarizes the long-term debt of the Company as of December 30, 2019 and December 31, 2018:

[0001564590-20-006477:notes:149]
|  |  | Interest Rate as of December 30, 2019 |  |  | Principal Outstanding as of December 30, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 4.28 |  | % | $ | 805,879 |  |  |  | 5.00 |  | % | $ | 835,879 |  |
| Senior Notes due October 2025 |  |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | 3.03 |  |  |  | 40,000 |  |  |  | 4.00 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 3.18 |  |  |  | 30,000 |  |  |  | 3.90 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (11,943 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (12,974 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  |  | 1,475,937 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  |  | (249,975 | ) |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,225,962 |  |  |  |  |  |  | $ | 1,462,425 |  |

[0001564590-20-006477:notes:150]
The fiscal calendar maturities of long-term debt through 2024 and thereafter are as follows:

[0001564590-20-006477:notes:151]
|  |  | (In thousands) |  |
| 2020 |  | $ | 249,975 |  |
| 2021 |  |  | — |  |
| 2022 |  |  | — |  |
| 2023 |  |  | — |  |
| 2024 |  |  | 875,879 |  |
| Thereafter |  |  | 375,000 |  |
|  |  | $ | 1,500,854 |  |

[0001564590-20-006477:notes:152]
Term Loan Facility

[0001564590-20-006477:notes:153]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $805,879 as of December 30, 2019 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR plus an applicable interest margin of 2.5%, or an alternate base rate (as defined in the Term Loan Credit Agreement) plus an applicable margin of 1.5%. As of December 30, 2019, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.28%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-20-006477:notes:154]
Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0001564590-20-006477:notes:155]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

[0001564590-20-006477:notes:156]
Senior Notes

[0001564590-20-006477:notes:157]
The $375,000 of Senior Notes issued, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

[0001564590-20-006477:notes:158]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

[0001564590-20-006477:notes:159]
Convertible Senior Notes due 2020

[0001564590-20-006477:notes:160]
The Company maintains 1.75% Convertible Senior Notes in the amount of $249,975 due December 15, 2020. The Convertible Senior Notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes are unsecured obligations and would rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the Convertible Senior Notes.

[0001564590-20-006477:notes:161]
Conversion:  At any time prior to March 15, 2020, holders may convert their Convertible Senior Notes into cash and, if applicable, into shares of the Company’s common stock based on a conversion rate of 103.7613 shares of the Company’s common stock per $1 principal amount of Convertible Senior Notes, subject to adjustment, under the following circumstances: (1) during any calendar quarter beginning after March 31, 2015 (and only during such calendar quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days during the 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day of such preceding calendar quarter; (2) during the five business day period after any 10 consecutive trading day period in which the trading price per note for each day of that 10 consecutive trading day period was less than 98% of the product of the last reported sale price of the Company’s common stock and the conversion rate on such day; or (3) upon the occurrence of specified corporate transactions described in the indenture governing the notes. In 2019, the conversion criteria had been met during certain periods allowing holders to give notice of conversion during the year.

[0001564590-20-006477:notes:162]
On or after March 15, 2020 until the close of business on the third scheduled trading day preceding the maturity date, holders may convert their notes at any time, regardless of the foregoing circumstances. Upon conversion, for each $1 principal amount of notes, the Company will pay shares of its common stock, cash or a combination of cash and shares of its common stock at its election, if applicable, based on a daily conversion value calculated on a proportionate basis for each day of the 80 trading day observation period. All conversions occurring on the same date or on or after March 15, 2020 shall be settled using the same settlement method. Additionally, in the event of a fundamental change as defined in the indenture governing the notes, or other conversion rate adjustments such as share splits or combinations, other distributions of shares, cash or other assets to stockholders, including self-tender transactions (Other Conversion Rate Adjustments), the conversion rate may be modified to adjust the number of shares per $1 principal amount of the notes. As of December 30, 2019, none of the criteria for a fundamental change or a conversion rate adjustment had been met.

[0001564590-20-006477:notes:163]
The maximum number of shares issuable upon conversion, including the effect of a fundamental change and subject to Other Conversion Rate Adjustments, would be 32,422.

[0001564590-20-006477:notes:164]
Note Repurchase:    The Company is not permitted to redeem the Convertible Senior Notes at any time prior to maturity. In the event of a fundamental change or certain default events, as defined in the indenture governing the notes, holders may require the Company to repurchase for cash all or a portion of their Convertible Senior Notes at a price equal to 100% of the principal amount, plus any accrued and unpaid interest.

[0001564590-20-006477:notes:165]
Convertible Note Hedge and Warrant Transaction:    In connection with the issuance of the Convertible Senior Notes due 2020, the Company entered into a convertible note hedge and warrant transaction (Call Spread Transaction), with respect to the Company’s common stock. The convertible note hedge consists of the Company’s option to purchase up to 25,939 common stock shares at a price of $9.64 per share. The hedge expires on December 15, 2020 and can only be executed upon the conversion of the above mentioned Convertible Senior Notes due 2020. Additionally, the Company sold warrants to purchase 25,940 shares of its common stock at a price of $14.26 per share. The warrants expire ratably from March 2021 through January 2022. The Call Spread Transaction has no effect on the terms of the Convertible Senior Notes due 2020 and reduces potential dilution by effectively increasing the conversion price of the Convertible Senior Notes due 2020 to $14.26 per share of the Company’s common stock.

[0001564590-20-006477:notes:166]
As of December 30, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:

[0001564590-20-006477:notes:167]
|  |  | As of December 30, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

[0001564590-20-006477:notes:168]
The components of interest expense resulting from the Convertible Senior Notes for the years ended December 30, 2019, December 31, 2018 and January 1, 2018 were as follows:

[0001564590-20-006477:notes:169]
|  |  | For the Year Ended |  |
|  |  | December 30, |  |  | December 31, |  |  | January 1, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 4,374 |  |  | $ | 4,375 |  |  | $ | 4,375 |  |
| Amortization of debt discount |  | $ | 9,751 |  |  | $ | 9,142 |  |  | $ | 8,570 |  |
| Amortization of debt issuance costs |  | $ | 977 |  |  | $ | 916 |  |  | $ | 858 |  |

[0001564590-20-006477:notes:170]
Asset-Based Lending Agreements

[0001564590-20-006477:notes:171]
During June 2019, the Company amended its U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and its Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans). The U.S. ABL credit facility was amended to extend its maturity to June 2024, decrease the size of the facility to $150,000 and add a $100,000 incremental facility. The Asia ABL credit facility was amended to extend the maturity to June 2024 and add a $50,000 incremental facility.

[0001564590-20-006477:notes:172]
The U.S. ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $50,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 125 basis points or an alternate base rate (defined as the greater of the prime rate, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%) subject to a 1.0% floor, plus an applicable margin of 25 basis points, at the Company’s option. As of December 30, 2019, the interest rate on the outstanding borrowings under the U.S. ABL was 3.03%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for LIBOR-based loans and from 25 to 50 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on June 3, 2024. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of December 30, 2019, $40,000 under the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-20-006477:notes:173]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of December 30, 2019, the interest rate on the outstanding borrowings under the Asia ABL was 3.18%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on June 4, 2024. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of December 30, 2019, $30,000 under the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-20-006477:notes:174]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of December 30, 2019, letters of credit in the amount of $14,488 were outstanding under the U.S. ABL and $21,709 were outstanding under the Asia ABL with various expiration dates through March 2020. Available borrowing capacity under the U.S. ABL and the Asia ABL was $95,512 and $98,291, respectively, which considers letters of credit outstanding as of December 30, 2019.

[0001564590-20-006477:notes:175]
The Company is required to pay a commitment fee of 0.25% per annum on any unused portion of the U.S. ABL and 0.28% per annum on any unused portion of the Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $703, $992 and $783 for the years ended December 30, 2019, December 31, 2018 and January 1, 2018, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0001564590-20-006477:notes:176]
Other Credit Facility

[0001564590-20-006477:notes:177]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $28,588 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver. In July 2019, the expiration of the Chinese Revolver was extended to July 2020. As of December 30, 2019, the Chinese Revolver had not been drawn upon.

[0001564590-20-006477:notes:178]
Debt Issuance and Debt Discount

[0001564590-20-006477:notes:179]
As of December 30, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes, and Convertible Senior Notes are as follows:

[0001564590-20-006477:notes:180]
|  |  | As of December 30, 2019 |  |  | As of December 31, 2018 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,663 |  |  | $ | 2,016 |  |  |  | 4.66 |  | % | $ | 8,229 |  |  | $ | 2,489 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,316 |  |  | — |  |  |  | 5.92 |  |  |  | 6,071 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 995 |  |  |  | 9,927 |  |  |  | 6.48 |  |  |  | 1,972 |  |  |  | 19,678 |  |  |  | 6.48 |  |  |
|  |  | $ | 12,974 |  |  | $ | 11,943 |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |  |

[0001564590-20-006477:notes:181]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-20-006477:notes:182]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,511 and $1,420 as of December 30, 2019 and December 31, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

[0001564590-20-006477:notes:183]
As of December 30, 2019, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.4 years.

[0001564590-20-006477:notes:184]
Loss on Extinguishment of Debt

[0001564590-20-006477:notes:185]
During the year ended January 1, 2018, the Company recognized loss on extinguishment of debt of $768, primarily associated with the write off of the remaining unamortized debt issuance and debt discount for the 2016 Term Loan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-006477:notes:186]
| (8) | Income Taxes |

[0001564590-20-006477:notes:187]
The components of income (loss) before income taxes for the years ended December 30, 2019, December 31, 2018 and January 1, 2018 are:

[0001564590-20-006477:notes:188]
|  |  | For the Year Ended |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  | (In thousands) |  |
| United States |  | $ | 16,066 |  |  | $ | 18,991 |  |  | $ | (4,178 | ) |
| Foreign |  |  | 30,118 |  |  |  | 70,777 |  |  |  | 144,136 |  |
| Income before income taxes |  | $ | 46,184 |  |  | $ | 89,768 |  |  | $ | 139,958 |  |

[0001564590-20-006477:notes:189]
The Company expects its earnings attributable to foreign subsidiaries will be indefinitely reinvested, except for its material Chinese and Canadian plants and the respective holding companies where a deferred tax liability of approximately $10,243 and $905 has been recorded for the foreign and U.S. federal/state impact, respectively. For those other companies with earnings currently being reinvested outside of the U.S., the undistributed earnings amounted to approximately $60,769 as of December 30, 2019. The determination of the unrecognized deferred tax liability related to these undistributed earnings is approximately $3,589.

[0001564590-20-006477:notes:190]
The components of income tax benefit (provision) for the years ended December 30, 2019, December 31, 2018 and January 1, 2018 are:

[0001564590-20-006477:notes:191]
|  |  | For the Year Ended |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  | (In thousands) |  |
| Current benefit (provision): |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 294 |  |  | $ | 381 |  |  | $ | 82 |  |
| State |  |  | (2,922 | ) |  |  | (1,294 | ) |  |  | (462 | ) |
| Foreign |  |  | (13,042 | ) |  |  | (12,045 | ) |  |  | (24,006 | ) |
| Total current |  |  | (15,670 | ) |  |  | (12,958 | ) |  |  | (24,386 | ) |
| Deferred benefit (provision): |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 1,004 |  |  |  | 97,723 |  |  |  | 11 |  |
| State |  |  | (1,076 | ) |  |  | 14,351 |  |  |  | (31 | ) |
| Foreign |  |  | 10,859 |  |  |  | (15,300 | ) |  |  | 9,175 |  |
| Total deferred |  |  | 10,787 |  |  |  | 96,774 |  |  |  | 9,155 |  |
| Total (provision) benefit |  | $ | (4,883 | ) |  | $ | 83,816 |  |  | $ | (15,231 | ) |

[0001564590-20-006477:notes:192]
The following is a reconciliation of the provision for income taxes at the statutory federal income tax rate compared to the Company’s provision for income taxes for the years ended December 30, 2019, December 31, 2018 and January 1, 2018:

[0001564590-20-006477:notes:193]
|  |  | For the Year Ended |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  | (In thousands) |  |
| Statutory federal income tax |  | $ | (9,699 | ) |  | $ | (18,851 | ) |  | $ | (48,985 | ) |
| State income taxes, net of federal benefit and state tax credits |  |  | (3,163 | ) |  |  | (1,953 | ) |  |  | (462 | ) |
| Foreign deemed dividends |  |  | — |  |  |  | — |  |  |  | (457 | ) |
| Transfer pricing |  |  | — |  |  |  | 1,483 |  |  |  | — |  |
| Acquisition related expenses |  |  | — |  |  |  | (1,737 | ) |  |  | — |  |
| IRC Section 162(m) limitation |  |  | (868 | ) |  |  | (3,702 | ) |  |  | — |  |
| Stock options |  |  | (252 | ) |  |  | 1,072 |  |  |  | — |  |
| Global Intangible Low-Taxed Income |  |  | (457 | ) |  |  | — |  |  |  | — |  |
| Intercompany profit in inventory elimination |  |  | — |  |  |  | — |  |  |  | (743 | ) |
| Permanently reinvested earnings assertion |  |  | (2,903 | ) |  |  | (15,492 | ) |  |  | — |  |
| Tax Act deferred tax revaluation |  |  | — |  |  |  | — |  |  |  | (59,228 | ) |
| Foreign tax differential on foreign earnings & other permanent items |  |  | 2,294 |  |  |  | 2,045 |  |  |  | 30,412 |  |
| Change in valuation allowance |  |  | 2,127 |  |  |  | 118,451 |  |  |  | 66,716 |  |
| Uncertain tax positions |  |  | 999 |  |  |  | (954 | ) |  |  | (3,992 | ) |
| Federal research and development credits |  |  | 4,582 |  |  |  | 2,996 |  |  |  | 1,270 |  |
| Other |  |  | 2,457 |  |  |  | 458 |  |  |  | 238 |  |
| Total (provision) benefit for income taxes |  | $ | (4,883 | ) |  | $ | 83,816 |  |  | $ | (15,231 | ) |

[0001564590-20-006477:notes:194]
Deferred income taxes reflect the net tax effects of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. The significant components of the net deferred income tax assets (liabilities) as of December 30, 2019 and December 31, 2018 are as follows:

[0001564590-20-006477:notes:195]
|  |  | As of |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Deferred income tax assets: |  |  |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 88,798 |  |  | $ | 104,801 |  |
| Reserves and accruals |  |  | 28,240 |  |  |  | 29,358 |  |
| Interest expense limitation |  |  | 13,102 |  |  |  | 1,276 |  |
| Unrealized loss on cash flow hedge |  |  | 2,960 |  |  |  | 1,128 |  |
| Tax credit carryforwards |  |  | 37,889 |  |  |  | 30,962 |  |
| Stock-based compensation |  |  | 4,440 |  |  |  | 4,528 |  |
| Original issue discount on Convertible Senior Notes |  |  | 870 |  |  |  | 5,130 |  |
| Property, plant and equipment |  |  | 13,722 |  |  |  | 24,826 |  |
| Other deferred income tax assets |  |  | 756 |  |  |  | 228 |  |
|  |  |  | 190,777 |  |  |  | 202,237 |  |
| Less: valuation allowance |  |  | (25,874 | ) |  |  | (27,426 | ) |
|  |  |  | 164,903 |  |  |  | 174,811 |  |
| Deferred income tax liabilities: |  |  |  |  |  |  |  |  |
| Discount on Convertible Senior Notes |  |  | — |  |  |  | (4,683 | ) |
| Repatriation of foreign earnings |  |  | (11,148 | ) |  |  | (20,282 | ) |
| Property, plant and equipment basis differences |  |  | (54,310 | ) |  |  | (50,622 | ) |
| Goodwill and intangible amortization |  |  | (73,219 | ) |  |  | (85,300 | ) |
| Other deferred income tax liabilities |  |  | (100 | ) |  |  | (252 | ) |
| Net deferred income tax assets |  | $ | 26,126 |  |  | $ | 13,672 |  |
| Deferred income tax assets, net: |  |  |  |  |  |  |  |  |
| Non-current deferred income taxes |  |  | 26,126 |  |  |  | 13,672 |  |

[0001564590-20-006477:notes:196]
As of December 30, 2019, the Company had the following net operating loss (NOL) carryforwards: $360,640 in the U.S. for federal, $48,025 in various U.S. states, $64,676 in China, and $60,087 in Hong Kong. The U.S. federal NOLs expire in 2023 through 2036, the various U.S. states’ NOLs expire in 2020 through 2036, the China NOLs expire in 2020 through 2029, and the Hong Kong NOLs carryforward indefinitely. Further, the Company’s tax credits were approximately $46,393, of which $6,693 carryforward indefinitely.

[0001564590-20-006477:notes:197]
In connection with the Company’s acquisition of Viasystems, there was more than a 50% change in ownership under Section 382 of the Internal Revenue Code of 1986, as amended, and regulations issued there under. As a consequence, the utilization of the acquired Viasystems U.S. NOLs is limited to approximately $9,826 per year. In addition, the Company recognized certain gains built in at the time of the ownership change, which increase the limitation by approximately $47,463 for each of the first 5 years after the acquisition. Any unused limitation in a year can be carried over to succeeding years.

[0001564590-20-006477:notes:198]
A valuation allowance is provided when it is more likely than not that all or some portion of the deferred income tax assets will not be realized. During the year ended December 31, 2018, the Company released a majority of its valuation allowance recorded on its U.S. net deferred tax assets due to a combination of the Company’s expectations for future U.S. taxable income improvement and to offset the net deferred tax liability acquired as a result of the Anaren acquisition. It continues to maintain a valuation allowance on certain of its U.S. net deferred tax assets represented by income tax attributes carried forward that are expected to expire unused. Certain subsidiaries within China continue to have NOL carryforwards in various tax jurisdictions that the Company has determined are not more likely than not to be utilized. As a result, a full valuation allowance has been recorded for these subsidiaries as of December 30, 2019. For the remaining net deferred income tax asset, management has determined that it is more likely than not that the results of future operations will generate sufficient taxable income to realize the net deferred tax asset.

[0001564590-20-006477:notes:199]
The following summarizes the activity in the Company’s valuation allowance for the years ended December 30, 2019, December 31, 2018 and January 1, 2018:

[0001564590-20-006477:notes:200]
|  |  | For the Year Ended |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 27,426 |  |  | $ | 167,238 |  |  | $ | 221,951 |  |
| Reduction related to acquisition |  |  | — |  |  |  | (76,040 | ) |  |  | — |  |
| Additions charged to expense |  |  | 6,483 |  |  |  | — |  |  |  | 4,515 |  |
| Reduction charged to expense — Tax Act |  |  | — |  |  |  | — |  |  |  | (59,228 | ) |
| Other reduction charged to expense |  |  | (8,035 | ) |  |  | (63,772 | ) |  |  | — |  |
| Balance at end of year |  | $ | 25,874 |  |  | $ | 27,426 |  |  | $ | 167,238 |  |

[0001564590-20-006477:notes:201]
Certain entities within China qualified for the high and new technology enterprise (HNTE) status enabling those entities to enjoy certain benefits, which were effective for the years ended December 30, 2019, December 31, 2018 and January 1, 2018. The HNTE status as well as enhanced research and development (R&D) deductions decreased Chinese taxes. HNTE and R&D benefit and effect on earnings per share are as follows:

[0001564590-20-006477:notes:202]
|  |  | For the Year Ended |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  | (In thousands, except per share data) |  |
| HNTE and R&D benefits |  | $ | 10,060 |  |  | $ | 11,970 |  |  | $ | 11,935 |  |
| Basic shares |  |  | 105,195 |  |  |  | 103,355 |  |  |  | 101,580 |  |
| Diluted shares |  |  | 106,332 |  |  |  | 134,036 |  |  |  | 132,476 |  |
| Increases earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.10 |  |  | $ | 0.12 |  |  | $ | 0.12 |  |
| Diluted |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0001564590-20-006477:notes:203]
HNTE status expires at various dates in 2019 through 2020, but the Company expects to continue to file for renewal of such HNTE status for the foreseeable future.

[0001564590-20-006477:notes:204]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, exclusive of accrued interest and penalties, is as follows:

[0001564590-20-006477:notes:205]
|  |  | For the Year Ended |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 37,849 |  |  | $ | 38,841 |  |  | $ | 39,727 |  |
| Additions related to acquisition |  |  | — |  |  |  | 903 |  |  |  | — |  |
| Additions based on tax positions related to the current year |  |  | 3,553 |  |  |  | 856 |  |  |  | 1,965 |  |
| Additions for tax positions of prior years |  |  | 4,952 |  |  |  | 117 |  |  |  | 1,661 |  |
| Reductions for tax positions of prior years |  |  | (103 | ) |  |  | (2,140 | ) |  |  | (3,846 | ) |
| Lapse of statute of limitations |  |  | (1,221 | ) |  |  | (728 | ) |  |  | (666 | ) |
| Balance at end of year |  | $ | 45,030 |  |  | $ | 37,849 |  |  | $ | 38,841 |  |

[0001564590-20-006477:notes:206]
As of December 30, 2019 and December 31, 2018, the Company recorded unrecognized tax benefits of $25,805 and $26,274, respectively, as well as interest and penalties of $13,531 and $13,280, respectively, to current and long-term liabilities. The Company has also recorded unrecognized tax benefits of $19,225 and $11,576 against certain deferred tax assets as of December 30, 2019 and December 31, 2018, respectively. The amount of unrecognized tax benefits that would, if recognized, reduce the Company’s effective income tax rate in any future periods is $39,336 including interest and penalties. The Company expects its unrecognized tax benefits to decrease by $3,864 along with related interest of $6,555 over the next twelve months due to expiring statutes.

[0001564590-20-006477:notes:207]
As of December 30, 2019, the Company is subject to (i) U.S. federal income tax examination and / or NOL adjustment for tax years from 2000 to 2019, (ii) state and local income tax examination for tax years 2000 to 2019, and (iii) foreign income tax examinations generally for tax years from 2009 to 2019.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-20-006477:notes:208]
| (9) | Financial Instruments |

[0001564590-20-006477:notes:209]
Derivatives

[0001564590-20-006477:notes:210]
Interest Rate Swaps

[0001564590-20-006477:notes:211]
The Company’s business is exposed to interest rate risk resulting from fluctuations in interest rates on certain LIBOR-based variable rate debt. Increases in interest rates would increase interest expenses relating to the outstanding variable rate borrowings and increase the cost of debt. Fluctuations in interest rates can also lead to significant fluctuations in the fair value of the debt obligations.

[0001564590-20-006477:notes:212]
On May 15, 2018, the Company entered into a four-year pay-fixed, receive floating (1-month LIBOR), interest rate swap arrangement with a notional amount of $400,000 for the period beginning June 1, 2018 and ending on June 1, 2022. Under the terms of the interest rate swap, the Company pays a fixed rate of 2.84% against a portion of its LIBOR-based debt and receives floating 1-month LIBOR during the swap period.

[0001564590-20-006477:notes:213]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of December 30, 2019, the fair value of the interest rate swap was recorded as a liability in the amount of $12,067 and included as a component of other long-term liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive (loss) income, net of tax, in the Company’s consolidated balance sheets. No ineffectiveness was recognized for the years ended December 30, 2019 and December 31, 2018. During the year ended December 30, 2019, the interest rate swap increased interest expense by $2,315.

[0001564590-20-006477:notes:214]
Foreign Exchange Contracts

[0001564590-20-006477:notes:215]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than its functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts as of December 30, 2019 and December 31, 2018 was approximately $3,304 and $4,313, respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-20-006477:notes:216]
The fair values of derivative instruments in the consolidated balance sheets are as follows:

[0001564590-20-006477:notes:217]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other long-term liabilities |  | $ | (12,067 | ) |  | $ | (4,735 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | 1 |  |  |  | — |  |
| Foreign exchange contracts |  | Other current liabilities |  |  | (29 | ) |  |  | (139 | ) |

[0001564590-20-006477:notes:218]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the years ended December 30, 2019, December 31, 2018 and January 1, 2018:

[0001564590-20-006477:notes:219]
|  |  |  | For the Year Ended |  |  |
|  |  |  | December 30, 2019 |  |  | December 31, 2018 |  |  | January 1, 2018 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Gain Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (9,647 | ) |  | $ | (2,315 | ) |  | $ | (6,333 | ) |  | $ | (1,598 | ) |  | $ | — |  |  | $ | — |  |  |
| Foreign currency forward |  | Depreciation expense |  | (4 | ) |  |  | (155 | ) |  |  | (21 | ) |  |  | (157 | ) |  |  | 276 |  |  |  | (162 | ) |  |

[0001564590-20-006477:notes:220]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the years ended December 30, 2019, December 31, 2018 and January 1, 2018:

[0001564590-20-006477:notes:221]
|  |  | For the Year Ended |  |
|  |  | December 30, |  |  | December 31, |  |  | January 1, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | (4,214 | ) |  | $ | (742 | ) |  | $ | (1,180 | ) |
| Changes in fair value (loss) gain, net of tax |  |  | (7,296 | ) |  |  | (4,846 | ) |  |  | 276 |  |
| Reclassification to earnings |  |  | 1,893 |  |  |  | 1,374 |  |  |  | 162 |  |
| Ending balance, net of tax |  | $ | (9,617 | ) |  | $ | (4,214 | ) |  | $ | (742 | ) |

[0001564590-20-006477:notes:222]
Based on the current yield curve, the Company expects that losses of approximately $3,561 of accumulated other comprehensive loss will be reclassified into the statement of operations, net of tax, in the next twelve months.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-20-006477:notes:223]
| (10) | Accumulated Other Comprehensive Income (Loss) |

[0001564590-20-006477:notes:224]
The following provides a summary of the components of accumulated other comprehensive income (loss), net of tax as of December 30, 2019, December 31, 2018 and January 1, 2018:

[0001564590-20-006477:notes:225]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of January 1, 2018 |  | $ | 4,145 |  |  | $ | — |  |  | $ | (742 | ) |  | $ | 3,403 |  |
| Other comprehensive loss before reclassifications |  |  | (2,567 | ) |  |  | (1,284 | ) |  |  | (4,846 | ) |  |  | (8,697 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 1,374 |  |  |  | 1,374 |  |
| Net year to date other comprehensive loss |  |  | (2,567 | ) |  |  | (1,284 | ) |  |  | (3,472 | ) |  |  | (7,323 | ) |
| Ending balance as of December 31, 2018 |  |  | 1,578 |  |  |  | (1,284 | ) |  |  | (4,214 | ) |  |  | (3,920 | ) |
| Other comprehensive loss before reclassifications |  |  | (463 | ) |  |  | (300 | ) |  |  | (7,296 | ) |  |  | (8,059 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 1,893 |  |  |  | 1,893 |  |
| Net year to date other comprehensive loss |  |  | (463 | ) |  |  | (300 | ) |  |  | (5,403 | ) |  |  | (6,166 | ) |
| Ending balance as of December 30, 2019 |  | $ | 1,115 |  |  | $ | (1,584 | ) |  | $ | (9,617 | ) |  | $ | (10,086 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-20-006477:notes:226]
| (11) | Significant Customers and Concentration of Credit Risk |

[0001564590-20-006477:notes:227]
In the normal course of business, the Company extends credit to its customers. Most customers to which the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk.

[0001564590-20-006477:notes:228]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.

[0001564590-20-006477:notes:229]
For the years ended December 30, 2019 and December 31, 2018, one customer accounted for approximately 15% of the Company’s net sales. For the year ended January 1, 2018, one customer accounted for approximately 20% of the Company’s net sales. There were no other customers that accounted for 10% or more of net sales for the years ended December 30, 2019, December 31, 2018 or January 1, 2018.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-20-006477:notes:230]
| (12) | Fair Value Measures |

[0001564590-20-006477:notes:231]
The Company measures at fair value its financial and non-financial assets by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability.

[0001564590-20-006477:notes:232]
The carrying amount and estimated fair value of the Company’s financial instruments as of December 30, 2019 and December 31, 2018 were as follows:

[0001564590-20-006477:notes:233]
|  |  | As of |  |  | As of |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |
| Derivative liabilities, current |  |  | 29 |  |  |  | 29 |  |  |  | 139 |  |  |  | 139 |  |
| Derivative liabilities, non-current |  |  | 12,067 |  |  |  | 12,067 |  |  |  | 4,735 |  |  |  | 4,735 |  |
| Term Loan due September 2024 |  |  | 797,200 |  |  |  | 808,901 |  |  |  | 825,161 |  |  |  | 782,592 |  |
| Senior Notes due October 2025 |  |  | 369,684 |  |  |  | 390,143 |  |  |  | 368,929 |  |  |  | 350,880 |  |
| Convertible Senior Notes due December 2020 |  |  | 239,053 |  |  |  | 391,686 |  |  |  | 228,335 |  |  |  | 290,858 |  |
| ABL Revolving Loans |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |

[0001564590-20-006477:notes:234]
The fair value of the derivative instruments was determined using pricing models developed based on the LIBOR swap rate, foreign currency exchange rates, and other observable market data, including quoted market prices, as appropriate using Level 2 inputs. The values were adjusted to reflect non-performance risk of both the counterparty and the Company, as necessary.

[0001564590-20-006477:notes:235]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of December 30, 2019 and December 31, 2018, which are considered Level 2 inputs.

[0001564590-20-006477:notes:236]
The fair value of the Convertible Senior Notes was estimated based on quoted market prices of the securities on an active exchange, which are considered Level 2 inputs.

[0001564590-20-006477:notes:237]
The fair value of plan assets in the defined benefit plan of $21,287 and $18,251 as of December 30, 2019 and December 31, 2018, respectively, were not included in the table above and was estimated based on quoted market prices of the securities that are actively traded and price quotes that are readily available, which are considered Level 1 inputs. See Note 15 for further details of the plan assets measured at fair value in the defined benefit plan.

[0001564590-20-006477:notes:238]
As of December 30, 2019 and December 31, 2018, the Company’s other financial instruments also included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of December 30, 2019 consisted of $51,165 held in the U.S., with the remaining $348,989 held by foreign subsidiaries.

[0001564590-20-006477:notes:239]
The majority of the Company’s non-financial assets and liabilities, which include goodwill, intangible assets, inventories, and property, plant and equipment, are not required to be carried at fair value on a recurring basis. However, if certain triggering events occur (or are tested at least annually in the case of goodwill) such that a non-financial instrument is required to be evaluated for impairment, based upon a comparison of the non-financial instrument’s fair value to its carrying value, an impairment is recorded to reduce the carrying value to the fair value, if the carrying value exceeds the fair value. There was no impairment of long-lived assets recognized for the years ended December 30, 2019, December 31, 2018, or January 1, 2018.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-006477:notes:240]
| (13) | Commitments and Contingencies |

[0001564590-20-006477:notes:241]
Legal Matters

[0001564590-20-006477:notes:242]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of December 30, 2019 and December 31, 2018. However, these amounts are not material to the consolidated financial statements of the Company.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-20-006477:notes:243]
| (14) | Stock-Based Compensation |

[0001564590-20-006477:notes:244]
Incentive Compensation Plan

[0001564590-20-006477:notes:245]
The Company maintains a 2014 Incentive Compensation Plan (the Plan), which allowed for the issuance of up to 5,288 shares. In May 2016, the Plan was amended to increase the amount allowed for issuance by 5,000 shares, revising the maximum allowed for issuance to 10,288 through its expiration date of February 2024.

[0001564590-20-006477:notes:246]
The Plan provides for the grant of incentive stock options and nonqualified stock options to the Company’s key employees, non-employee directors and consultants. Other types of awards such as performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock appreciation rights are also permitted. The exercise price for options and awards is determined by the compensation committee of the board of directors and, for options intended to qualify as incentive stock options, may not be less than the fair market value as determined by the closing stock price at the date of the grant. Each option and award shall vest and expire as determined by the compensation committee of the board of directors, with options, PRUs and RSUs generally vesting over three years for employees and one year for non-employee directors. Options, PRUs and RSUs do not have voting rights. Options expire no later than ten years from the grant date. All grants provide for accelerated vesting if there is a change in control, as defined in the Plan. Upon the exercise of outstanding stock options or vesting of RSUs and PRUs, the Company’s practice is to issue new registered shares that are reserved for issuance under the Plan.

[0001564590-20-006477:notes:247]
As of December 30, 2019, 400 PRUs, 2,997 RSUs and 100 stock options were outstanding under the Plan. Included in the 2,997 RSUs outstanding as of December 30, 2019 are 470 vested but not yet released RSUs associated with non-employee directors. These RSUs vest over one year with release of the underlying shares of common stock deferred until retirement from the board of directors, (or until one year after retirement in the case of certain prior grants).

[0001564590-20-006477:notes:248]
Performance-based Restricted Stock Units

[0001564590-20-006477:notes:249]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period may range from zero to 2.4 times the target number depending on performance during the period. The performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and EBITDA (earnings before interest, tax, depreciation, and amortization expense), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three-year performance period.

[0001564590-20-006477:notes:250]
Under the PRU program, financial goals are set at the beginning of each fiscal year and performance is reviewed at the end of that year. The percentage to be applied to each participant’s target award ranges from zero to 160% based upon the extent to which the annual financial performance goals are achieved. If specific performance threshold levels for the annual financial goals are met, the amount earned for that element will be applied to one-third of the participants’ PRU award to determine the number of units earned.

[0001564590-20-006477:notes:251]
At the end of the three-year performance period, the total units earned, if any, are adjusted by applying a modifier, ranging from zero to 150% based on the Company’s TSR based on stock price changes relative to a group of peer companies selected by the Company’s compensation committee for the same three-year period.

[0001564590-20-006477:notes:252]
The TSR modifier is intended to ensure that there are limited or no payouts under the PRU program if the Company’s stock performance is significantly below the median TSR of a group of peer companies selected by the Company’s compensation committee over the three-year performance period. Where the annual financial goals have been met and where there has been strong relative TSR performance over the three-year performance period, the PRU program may provide substantial rewards to participants with a maximum payout of 2.4 times the initial PRU award. However, even if all of the annual financial metric goals are achieved in each of the three years, there will be no payouts if the Company’s stock performance is below that of the 10th percentile for PRUs granted in 2019, 2018 and 2017 of the group of peer companies selected by the Company’s compensation committee, as appropriate.

[0001564590-20-006477:notes:253]
Recipients of PRU awards generally must remain employed by the Company on a continuous basis through the end of the three-year performance period in order to receive any amount of the PRUs covered by that award. In events such as death, disability or retirement, the recipient may be entitled to pro-rata amounts of PRUs as defined in the Plan. Target shares subject to PRU awards do not have voting rights of common stock until earned and issued following the end of the three-year performance period.

[0001564590-20-006477:notes:254]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. As of December 30, 2019, management determined that vesting of the PRU awards was probable. PRU activity for the year ended December 30, 2019 was as follows:

[0001564590-20-006477:notes:255]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Outstanding shares as of December 31, 2018 |  |  | 255 |  |  | $ | 18.75 |  |
| Granted |  |  | 293 |  |  |  | 10.17 |  |
| Vested |  |  | (186 | ) |  |  | 16.98 |  |
| Forfeited / cancelled |  |  | (7 | ) |  |  | 15.18 |  |
| Change in units due to annual performance achievement |  |  | (141 | ) |  |  | 13.47 |  |
| Outstanding shares as of December 30, 2019 |  |  | 214 |  |  | $ | 12.16 |  |

[0001564590-20-006477:notes:256]
The fair value of PRUs granted is calculated using a Monte Carlo simulation model, as the TSR modifier contains a market condition. For the years ended December 30, 2019, December 31, 2018 and January 1, 2018, the following assumptions were used in determining the fair value:

[0001564590-20-006477:notes:257]
|  |  | For the Year Ended |  |
|  |  | December 30, 2019 (1) |  |  | December 31, 2018 (2) |  |  | January 1, 2018 (3) |  |
| Weighted-average fair value |  | $ | 10.17 |  |  | $ | 19.59 |  |  | $ | 22.90 |  |
| Risk-free interest rate |  |  | 2.18 | % |  |  | 2.14 | % |  |  | 1.20 | % |
| Dividend yield |  |  | — |  |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 38 | % |  |  | 40 | % |  |  | 43 | % |
| Expected term in years |  |  | 1.8 |  |  |  | 1.5 |  |  |  | 1.8 |  |

[0001564590-20-006477:notes:258]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2017, the second year of the three-year performance period applicable to PRUs granted in 2018 and the first year of the three-year performance period applicable to PRUs granted in 2019. |

[0001564590-20-006477:notes:259]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2016, the second year of the three-year performance period applicable to PRUs granted in 2017 and the first year of the three-year performance period applicable to PRUs granted in 2018. |

[0001564590-20-006477:notes:260]
| (3) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2015, the second year of the three-year performance period applicable to PRUs granted in 2016 and the first year of the three-year performance period applicable to PRUs granted in 2017. |

[0001564590-20-006477:notes:261]
The risk-free interest rate for the expected term of PRUs is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is calculated using the Company’s historical stock price. The expected term of the PRUs reflects the performance period for the PRUs granted.

[0001564590-20-006477:notes:262]
Restricted Stock Units

[0001564590-20-006477:notes:263]
RSU activity for the year ended December 30, 2019 was as follows:

[0001564590-20-006477:notes:264]
|  |  | Shares |  |  | Weighted Average Grant-Date Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Non-vested RSUs outstanding as of December 31, 2018 |  |  | 2,125 |  |  | $ | 13.47 |  |
| Granted |  |  | 1,708 |  |  |  | 10.09 |  |
| Vested |  |  | (1,179 | ) |  |  | 11.84 |  |
| Forfeited |  |  | (127 | ) |  |  | 12.38 |  |
| Non-vested RSUs outstanding as of December 30, 2019 |  |  | 2,527 |  |  | $ | 11.91 |  |
| Vested and expected to vest as of December 30, 2019 |  |  | 2,997 |  |  | $ | 11.75 |  |

[0001564590-20-006477:notes:265]
The fair value of the Company’s RSUs is determined based upon the closing common stock price on the grant date. The weighted average fair value per unit of RSUs granted was $10.09, $15.35 and $15.85 for the years ended December 30, 2019, December 31, 2018 and January 1, 2018, respectively. The total fair value of RSUs vested for the years ended December 30, 2019, December 31, 2018 and January 1, 2018 was $13,954, $12,599 and $9,446, respectively.

[0001564590-20-006477:notes:266]
Stock Options

[0001564590-20-006477:notes:267]
The Company did not grant stock option awards during the years ended December 30, 2019 and January 1, 2018. During the year ended December 31, 2018, the Company granted 40 stock options to newly appointed members of the board which were estimated to have a weighted fair value per share of $8.37. The fair value calculation is based on stock options granted during the period using the Black-Scholes option-pricing model on the date of grant. For the year ended December 31, 2018, the weighted fair value was determined using 3.1% as the risk-free interest rate, 43% as the expected volatility, 8.5 years as the expected term and no dividend yield.

[0001564590-20-006477:notes:268]
The Company determines the expected term of its stock option awards by periodic review of its historical stock option exercise experience. This calculation uses assumed future exercise patterns to account for option holders’ expected exercise and post-vesting termination behavior for outstanding stock options over their remaining contractual terms. Expected volatility is calculated by weighting the Company’s historical stock price to calculate expected volatility over the expected term of each grant. The risk-free interest rate for the expected term of each option granted is based on the U.S. Treasury yield curve in effect at the time of grant with a period that approximates the expected term of the options.

[0001564590-20-006477:notes:269]
Option activity under the Plan for the year ended December 30, 2019 was as follows:

[0001564590-20-006477:notes:270]
|  |  | Options |  |  | Weighted Average Exercise Price |  |  | Weighted Average Remaining Contractual Term |  |  | Aggregate Intrinsic Value |  |
|  |  | (In thousands) |  |  |  |  |  |  | (In years) |  |  | (In thousands) |  |
| Outstanding as of December 31, 2018 |  |  | 100 |  |  | $ | 13.10 |  |  |  | 6.1 |  |  | $ | 4 |  |
| Outstanding as of December 30, 2019 |  |  | 100 |  |  | $ | 13.10 |  |  |  | 5.1 |  |  | $ | 212 |  |
| Vested and expected to vest as of December 30, 2019 |  |  | 100 |  |  | $ | 13.10 |  |  |  | 5.1 |  |  | $ | 212 |  |
| Exercisable as of December 30, 2019 |  |  | 65 |  |  | $ | 12.06 |  |  |  | 3.3 |  |  | $ | 212 |  |

[0001564590-20-006477:notes:271]
The aggregate intrinsic values in the table above represent the total pretax intrinsic value (the difference between Company’s closing stock price on the last trading day of the 2019 fiscal year and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 30, 2019. This amount changes based on the fair market value of the Company’s stock. There were no options exercised or vested for the year ended December 30, 2019. The total intrinsic value of options exercised for the years ended December 31, 2018 and January 1, 2018 was $128 and $27, respectively. The total fair value of the options vested for both years ended December 31, 2018 and January 1, 2018 was $34.

[0001564590-20-006477:notes:272]
Stock-based Compensation Expense and Unrecognized Compensation Costs

[0001564590-20-006477:notes:273]
For the years ended December 30, 2019, December 31, 2018 and January 1, 2018, the amounts recognized in the consolidated statements of operations with respect to the stock-based compensation plan are as follows:

[0001564590-20-006477:notes:274]
|  |  | For the Year Ended |  |
|  |  | December 30, |  |  | December 31, |  |  | January 1, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 3,158 |  |  | $ | 2,898 |  |  | $ | 2,252 |  |
| Selling and marketing |  |  | 1,973 |  |  |  | 1,964 |  |  |  | 1,458 |  |
| General and administrative |  |  | 11,685 |  |  |  | 15,819 |  |  |  | 14,580 |  |
| Stock-based compensation expense recognized |  | $ | 16,816 |  |  | $ | 20,681 |  |  | $ | 18,290 |  |

[0001564590-20-006477:notes:275]
The following is a summary of total unrecognized compensation costs as of December 30, 2019:

[0001564590-20-006477:notes:276]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 19,452 |  |  |  | 1.5 |  |
| PRU awards |  |  | 1,352 |  |  |  | 1.4 |  |
| Stock options |  |  | 242 |  |  |  | 1.7 |  |
|  |  | $ | 21,046 |  |  |  |  |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-20-006477:notes:277]
| (15) | Employee Benefit Plans, Deferred Compensation Plan and Retirement Benefit Plan |

[0001564590-20-006477:notes:278]
As of December 30, 2019, the Company has several defined contribution plans. In North America, the Company has savings plans (the Savings Plans) in which eligible full-time employees can participate and contribute a percentage of compensation subject to the maximum allowed by the tax agencies. The Savings Plans provides for a partial match by the Company. In China, the Company contributes to either separate trust-administered funds or various government-sponsored pension plans on a mandatory basis. For all defined contribution plans, the Company has no further payment obligation once the required contributions have been made. The Company recorded contributions to defined contribution plans of $54,395, $58,445 and $42,461 during the years ended December 30, 2019, December 31, 2018 and January 1, 2018, respectively.

[0001564590-20-006477:notes:279]
The Company also maintains a deferred compensation plan (the Compensation Plan). The Compensation Plan is an unfunded, nonqualified deferred compensation plan and is limited to selected employees, including the Company’s named executive officers and directors. The Compensation Plan allows participants to defer up to 100% of their annual bonus and between 5% and 100% of their annual director fees. Amounts deferred under the Compensation Plan will be credited to accounts maintained by the Company for each participant and will be credited or debited with the participant’s proportionate share of any gains or losses attributable to the performance of investment options selected by the participant.

[0001564590-20-006477:notes:280]
During the years ended December 30, 2019 and December 31, 2018, and following the acquisition of Anaren on April 18, 2018, the Company has a noncontributory defined benefit pension plan covering eligible employees. Effective August 15, 2000, the plan was closed for new participants. Benefits under this plan generally are based on the employee’s years of service and compensation. Effective December 31, 2019, the plan is frozen as to further participation and to further benefit accruals.

[0001564590-20-006477:notes:281]
As of December 30, 2019 and December 31, 2018, the funded status of the accumulated benefit obligation was 70%. The Company expects to fund a minimum required contribution of approximately $838 during fiscal year 2020.

[0001564590-20-006477:notes:282]
The following tables set forth the changes in benefit obligation and the plan assets in the defined benefit plan described above for the years ended December 30, 2019 and December 31, 2018:

[0001564590-20-006477:notes:283]
|  |  | For the Year Ended |  |
| Change in Benefit Obligations |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Benefit obligation at beginning of year |  | $ | (27,661 | ) |  | $ | (27,525 | ) |
| Service cost |  |  | (397 | ) |  |  | (292 | ) |
| Interest cost |  |  | (1,109 | ) |  |  | (758 | ) |
| Amendments/curtailments/special termination |  |  | 1,636 |  |  |  | — |  |
| Actuarial (loss) gain |  |  | (4,174 | ) |  |  | 264 |  |
| Benefits paid |  |  | 1,105 |  |  |  | 650 |  |
| Benefit obligation at end of year |  | $ | (30,600 | ) |  | $ | (27,661 | ) |
| Accumulated benefit obligation at end of year |  | $ | 30,600 |  |  | $ | 26,191 |  |

[0001564590-20-006477:notes:284]
|  |  | For the Year Ended |  |
| Change in in Plan Assets |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Fair value of plan assets at beginning of year |  | $ | 18,251 |  |  | $ | 19,643 |  |
| Actual return on plan assets |  |  | 3,346 |  |  |  | (1,021 | ) |
| Employer contributions |  |  | 795 |  |  |  | 280 |  |
| Benefits paid |  |  | (1,105 | ) |  |  | (651 | ) |
| Fair value of plan assets at end of year |  | $ | 21,287 |  |  | $ | 18,251 |  |
| Unfunded status |  | $ | (9,313 | ) |  | $ | (9,410 | ) |
| Net amount recognized |  | $ | (9,313 | ) |  | $ | (9,410 | ) |

[0001564590-20-006477:notes:285]
Amounts before income tax effect recognized in the consolidated balance sheets consists of the following:

[0001564590-20-006477:notes:286]
|  |  | As of |  |  | As of |  |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |  |
|  |  | (In thousands) |  |  |
| Other long-term liabilities |  | $ | (9,313 | ) |  | $ | (9,410 | ) |  |
| Net amount recognized |  | $ | (9,313 | ) |  | $ | (9,410 | ) |  |

[0001564590-20-006477:notes:287]
Amounts before income tax effect included in accumulated other comprehensive loss as of December 30, 2019 and
December 31, 2018 are as follows:

[0001564590-20-006477:notes:288]
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |  |
|  |  | (In thousands) |  |  |
| Net actuarial loss |  | $ | (2,097 | ) |  | $ | (1,677 | ) |  |
| Accumulated other comprehensive loss |  | $ | (2,097 | ) |  | $ | (1,677 | ) |  |

[0001564590-20-006477:notes:289]
During 2020, no accumulated other comprehensive loss is expected to be recognized as a component of net periodic benefit cost.

[0001564590-20-006477:notes:290]
The components included in the net periodic benefit cost and the increase in minimum liability included in other comprehensive loss for the years ended December 30, 2019 and December 31, 2018 are as follows:

[0001564590-20-006477:notes:291]
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Service cost |  | $ | 397 |  |  | $ | 292 |  |
| Interest cost |  |  | 1,109 |  |  |  | 758 |  |
| Expected return on plan assets |  |  | (1,228 | ) |  |  | (920 | ) |
| Net periodic benefit cost |  | $ | 278 |  |  | $ | 130 |  |

[0001564590-20-006477:notes:292]
The weighted-average assumptions used to determine benefit obligations for this plan as of December 30, 2019 and
December 31, 2018 are as follows:

[0001564590-20-006477:notes:293]
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |  |
| Discount rate |  |  | 3.02 |  | % |  | 4.09 |  | % |
| Rate of compensation increase |  |  | 3.20 |  |  |  | 3.20 |  |  |
| Expected return on plan assets |  |  | 6.00 |  |  |  | 6.75 |  |  |

[0001564590-20-006477:notes:294]
The Company determines the discount rate assumption based on the internal rate of return for a portfolio of high quality bonds, with a minimum rating of Moody's AA Corporate and with maturities that are consistent with the projected future cash flow obligations.

[0001564590-20-006477:notes:295]
The weighted-average assumptions used to determine net periodic benefit cost for the year ended December 30, 2019 and December 31, 2018 are as follows:

[0001564590-20-006477:notes:296]
|  |  | For the Year Ended |  |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |  |
| Discount rate |  |  | 4.09 |  | % |  | 3.96 |  | % |
| Rate of compensation increase |  |  | 3.20 |  |  |  | 3.20 |  |  |
| Expected return on plan assets |  |  | 6.75 |  |  |  | 6.75 |  |  |

[0001564590-20-006477:notes:297]
The Company determines the expected long-term rate of return on plan assets based upon recommendations from its pension plan's investment advisors and using an allocation approach that considers diversification and rebalancing for a portfolio of assets invested over a long-term time horizon. The approach relies on the historical returns of the plan's portfolio and relationships between equities and fixed income investments, consistent with the widely accepted capital market principle that a diversified portfolio with a larger allocation to equity investments can generate a greater return over the long run. Additionally, the Company monitors the mix of investments in its portfolio to ensure alignment with its expected long-term pension obligations. The Company reviews the expected long-term rate of return annually and revises it as appropriate.

[0001564590-20-006477:notes:298]
Investments shall be made pursuant to the following objectives: 1) preserve the purchasing power of the plan’s assets adjusted for inflation; 2) provide long term growth; 3) avoid significant volatility. Asset allocation shall be determined based on a long-term target allocation having 29% of assets invested in large-cap stocks, 11% in mid-cap stocks, 11% in small-cap stocks, 11% in international stocks, 34% in the broad bond market, and 3% in the real estate market, with little or none invested in cash. Both the investment allocation and the plan performance are reviewed periodically.

[0001564590-20-006477:notes:299]
The target allocation for 2020 and the plan asset allocation at the end of 2019 and 2018, in percentages, by asset category are as follows:

[0001564590-20-006477:notes:300]
|  |  | Target Allocation 2020 |  |  |  | December 30, 2019 |  |  |  | December 31, 2018 |  |  |
| Equity securities (1) |  |  | 66 |  | % |  |  | 66 |  | % |  |  | 61 |  | % |
| Debt securities (2) |  |  | 31 |  |  |  |  | 31 |  |  |  |  | 38 |  |  |
| Cash and cash equivalents (3) |  |  | 3 |  |  |  |  | 3 |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-20-006477:notes:301]
The following table summarizes plan assets measured at fair value as of December 30, 2019 and December 31, 2018:

[0001564590-20-006477:notes:302]
|  |  | As of |  |
|  |  | December 30, 2019 |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
|  |  | (In thousands) |  |
| Equity securities (1) |  | $ | 14,131 |  |  | $ | 14,131 |  |  | $ | — |  |  | $ | — |  |
| Debt securities (2) |  |  | 6,488 |  |  |  | 6,488 |  |  |  | — |  |  |  | — |  |
| Cash and cash equivalents (3) |  |  | 668 |  |  |  | 668 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 21,287 |  |  | $ | 21,287 |  |  | $ | — |  |  | $ | — |  |
|  |  | As of |  |
|  |  | December 31, 2018 |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
|  |  | (In thousands) |  |
| Equity securities (1) |  | $ | 11,184 |  |  | $ | 11,184 |  |  | $ | — |  |  | $ | — |  |
| Debt securities (2) |  |  | 6,929 |  |  |  | 6,929 |  |  |  | — |  |  |  | — |  |
| Cash and cash equivalents (3) |  |  | 138 |  |  |  | 138 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 18,251 |  |  | $ | 18,251 |  |  | $ | — |  |  | $ | — |  |

[0001564590-20-006477:notes:303]
| (1) | Equity securities include U.S. and foreign exchange traded common and preferred stocks and mutual funds. Common and preferred shares issued by U.S. and non-U.S. corporations are traded actively on exchanges and price quotes for these shares are readily available. Holdings of corporate stock are categorized as Level 1 investments. |

[0001564590-20-006477:notes:304]
| (2) | Debt securities include the debt of the U.S. Treasury and U.S. and foreign corporate issuers. U.S. Treasury notes and bonds are actively traded and price quotes for these securities are readily available. Holdings of U.S. Treasury notes and bonds are categorized as Level 1 investments. |

[0001564590-20-006477:notes:305]
| (3) | Cash and cash equivalents include short-term U.S. government investment notes, short-term money market mutual funds, accrued income and cash held on account. Cash held on account and short- term U.S. government investment notes (including accrued income thereon) for which there is an active market and daily pricing for the security are categorized as Level 1 investments. |

[0001564590-20-006477:notes:306]
The Company seeks to maximize medium to long-term returns of the overall pension plan assets with reasonable levels of investment risk. One element of controlling the overall investment risk is through diversification of asset allocation, among domestic and international equity and debt instruments. The plan's equity investments include foreign and domestic exchange traded equities across a range of industries and countries, but primarily in the domestic markets. The plan's debt securities are primarily invested in government and corporate issuers primarily in the domestic market.

[0001564590-20-006477:notes:307]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid:

[0001564590-20-006477:notes:308]
|  |  | (In thousands) |  |
| 2020 |  | $ | 1,185 |  |
| 2021 |  |  | 1,251 |  |
| 2022 |  |  | 1,309 |  |
| 2023 |  |  | 1,408 |  |
| 2024 |  |  | 1,506 |  |
| Years 2025 through 2029 |  |  | 8,344 |  |


## us-gaap:PreferredStockTextBlock

[0001564590-20-006477:notes:309]
| (16) | Preferred Stock |

[0001564590-20-006477:notes:310]
The board of directors has the authority, without action by stockholders, to designate and issue preferred stock in one or more series. The board of directors may also designate the rights, preferences and privileges of each series of preferred stock, any or all of which may be superior to the rights of the common stock. As of December 30, 2019, no shares of preferred stock were outstanding.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-006477:notes:311]
| (17) | Segment Information |

[0001564590-20-006477:notes:312]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. The Company has two reportable segments: PCB and E-M Solutions. The PCB reportable segment is comprised of multiple operating segments and consists of sixteen domestic PCB, RF sub-system, and RF component fabrication plants, including two facilities that

[0001564590-20-006477:notes:313]
provide follow-on value-added services; nine PCB fabrication and RF component plants in China; and one in Canada. The E-M Solutions reportable segment consists of three custom electronic assembly plants in China. Factors considered to determine whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production processes, type or classes of customers, distribution methods, and regulatory environments.

[0001564590-20-006477:notes:314]
The Company, including the chief operating decision maker, evaluates segment performance based on reportable segment income, which is operating income before amortization of intangibles. Interest expense and interest income are not presented by segment since they are not included in the measure of segment profitability reviewed by the chief operating decision maker. All inter-segment transactions have been eliminated.

[0001564590-20-006477:notes:315]
|  |  |  | For the Year Ended |  |
|  |  |  | December 30, 2019 |  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  |  | $ | 2,462,975 |  |  | $ | 2,621,314 |  |  | $ | 2,448,506 |  |
| E-M Solutions |  |  |  | 226,333 |  |  |  | 225,947 |  |  |  | 210,086 |  |
| Total net sales |  |  | $ | 2,689,308 |  |  | $ | 2,847,261 |  |  | $ | 2,658,592 |  |
| Operating Segment Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  |  | $ | 276,208 |  |  | $ | 329,668 |  |  | $ | 322,486 |  |
| E-M Solutions |  |  |  | 7,119 |  |  |  | 8,105 |  |  |  | 6,716 |  |
| Corporate |  |  |  | (109,910 | ) |  |  | (115,662 | ) |  |  | (92,808 | ) |
| Total operating segment income |  |  |  | 173,417 |  |  |  | 222,111 |  |  |  | 236,394 |  |
| Amortization of definite-lived intangibles (2) |  |  |  | (53,296 | ) |  |  | (63,026 | ) |  |  | (23,634 | ) |
| Total operating income |  |  |  | 120,121 |  |  |  | 159,085 |  |  |  | 212,760 |  |
| Total other expense |  |  |  | (73,937 | ) |  |  | (69,317 | ) |  |  | (72,802 | ) |
| Income before income taxes |  |  | $ | 46,184 |  |  | $ | 89,768 |  |  | $ | 139,958 |  |

[0001564590-20-006477:notes:316]
|  |  |  | For the Year Ended |  |
|  |  |  | December 30, 2019 |  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  |  | (In thousands) |  |
| Depreciation Expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  |  | $ | 155,163 |  |  | $ | 153,637 |  |  | $ | 144,256 |  |
| E-M Solutions |  |  |  | 3,476 |  |  |  | 2,850 |  |  |  | 2,471 |  |
| Corporate |  |  |  | 7,935 |  |  |  | 6,221 |  |  |  | 4,082 |  |
| Total depreciation expense |  |  | $ | 166,574 |  |  | $ | 162,708 |  |  | $ | 150,809 |  |
| Capital Expenditures: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  |  | $ | 130,799 |  |  | $ | 103,318 |  |  | $ | 161,152 |  |
| E-M Solutions |  |  |  | 2,302 |  |  |  | 3,918 |  |  |  | 5,438 |  |
| Corporate |  |  |  | 8,437 |  |  |  | 7,758 |  |  |  | 44,001 |  |
| Total capital expenditures |  |  | $ | 141,538 |  |  | $ | 114,994 |  |  | $ | 210,591 |  |

[0001564590-20-006477:notes:317]
|  |  |  | As of |  |
|  |  |  | December 30, 2019 |  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB (1) |  |  | $ | 2,126,765 |  |  | $ | 2,039,088 |  |  | $ | 1,991,049 |  |
| E-M Solutions |  |  |  | 156,580 |  |  |  | 146,693 |  |  |  | 143,344 |  |
| Corporate |  |  |  | 1,277,588 |  |  |  | 1,271,722 |  |  |  | 647,489 |  |
| Total assets |  |  | $ | 3,560,933 |  |  | $ | 3,457,503 |  |  | $ | 2,781,882 |  |

[0001564590-20-006477:notes:318]
| (1) | Figures for the year ended January 1, 2018 do not include Anaren, as the acquisition occurred on April 18, 2018. |

[0001564590-20-006477:notes:319]
| (2) | Amortization of definite-lived intangibles relates to the PCB reportable segment. For the years ended December 30, 2019 and December 31, 2018, $4,822 and $3,345, respectively, of amortization expense is included in cost of goods sold. |

[0001564590-20-006477:notes:320]
The Corporate category includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, information technology, facilities and human resources personnel, as well as global sales and marketing personnel and acquisition and integration costs associated with the acquisitions. Bank fees and legal, accounting, and other professional service costs associated with acquisitions of $6,902, $13,279 and $2,266 for the years ended December 30, 2019, December 31, 2018 and January 1, 2018, respectively, are included in Corporate.

[0001564590-20-006477:notes:321]
The Company markets and sells its products in approximately 60 countries. Other than in the United States and China, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales and long-lived assets are as follows:

[0001564590-20-006477:notes:322]
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
|  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |
|  |  | (In thousands) |  |
| United States |  | $ | 1,394,464 |  |  | $ | 1,348,741 |  |  | $ | 1,260,739 |  |  | $ | 1,315,174 |  |  | $ | 850,511 |  |  | $ | 642,256 |  |
| China |  |  | 551,861 |  |  |  | 754,514 |  |  |  | 548,853 |  |  |  | 851,789 |  |  |  | 957,296 |  |  |  | 866,126 |  |
| Other |  |  | 742,983 |  |  |  | 26,473 |  |  |  | 1,037,669 |  |  |  | 28,029 |  |  |  | 850,785 |  |  |  | 23,984 |  |
| Total |  | $ | 2,689,308 |  |  | $ | 2,129,728 |  |  | $ | 2,847,261 |  |  | $ | 2,194,992 |  |  | $ | 2,658,592 |  |  | $ | 1,532,366 |  |

[0001564590-20-006477:notes:323]
Net sales are attributed to countries by country invoiced.


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-006477:notes:324]
| (18) | Earnings Per Share |

[0001564590-20-006477:notes:325]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the years ended December 30, 2019, December 31, 2018 and January 1, 2018:

[0001564590-20-006477:notes:326]
|  |  | For the Year Ended |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings |  | $ | 41,301 |  |  | $ | 173,584 |  |  | $ | 124,214 |  |
| Diluted earnings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  | $ | 41,301 |  |  | $ | 173,584 |  |  | $ | 124,214 |  |
| Interest expense from Convertible Senior Notes, net of tax |  |  | 11,090 |  |  |  | 11,906 |  |  |  | 13,803 |  |
| Diluted earnings |  | $ | 52,391 |  |  | $ | 185,490 |  |  | $ | 138,017 |  |
| Basic weighted average shares |  |  | 105,195 |  |  |  | 103,355 |  |  |  | 101,580 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,137 |  |  |  | 1,677 |  |  |  | 2,157 |  |
| Dilutive effect of outstanding warrants |  |  | — |  |  |  | 3,065 |  |  |  | 2,799 |  |
| Dilutive effect of assumed conversion of Convertible Senior Notes outstanding |  |  | — |  |  |  | 25,939 |  |  |  | 25,940 |  |
| Diluted shares |  |  | 106,332 |  |  |  | 134,036 |  |  |  | 132,476 |  |
| Earnings per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.39 |  |  | $ | 1.68 |  |  | $ | 1.22 |  |
| Diluted |  | $ | 0.39 |  |  | $ | 1.38 |  |  | $ | 1.04 |  |

[0001564590-20-006477:notes:327]
For the years ended December 30, 2019, December 31, 2018 and January 1, 2018, PRUs, RSUs and stock options to purchase 730, 528 and 255 shares of common stock, respectively, were not considered in calculating diluted earnings per share because the options’ exercise prices or the total expected proceeds under the treasury stock method for performance-based stock units, restricted stock units or stock options was greater than the average market price of common shares during the applicable year and, therefore, the effect would be anti-dilutive.

[0001564590-20-006477:notes:328]
The below is a summary of amounts convertible to common stock related to Convertible Senior Notes and related warrants:

[0001564590-20-006477:notes:329]
|  |  | For the Year Ended |  |
|  |  | December 30, 2019 |  |  | December 31, 2018 |  |  | January 1, 2018 |  |
|  |  | (In thousands) |  |
| Common stock related to Convertible Senior Notes |  |  | 25,938 |  |  |  | 25,939 |  |  |  | 25,939 |  |
| Warrants to purchase common stock |  |  | 25,940 |  |  |  | 25,940 |  |  |  | 25,940 |  |

[0001564590-20-006477:notes:330]
For the year ended December 30, 2019, the effect of shares of common stock related to the Company’s Convertible Senior Notes, based on the if-converted method, were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive.

[0001564590-20-006477:notes:331]
Outstanding warrants for the year ended December 30, 2019, to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock were greater than the average market price of common shares during the applicable year, and therefore, the effect would be anti-dilutive.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001564590-20-006477:notes:332]
| (19) | Related Party Transactions |

[0001564590-20-006477:notes:333]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $33,695, $44,992 and $51,985 for the years ended December 30, 2019, December 31, 2018 and January 1, 2018, respectively.

[0001564590-20-006477:notes:334]
The Company also sells PCBs to a related party which is a wholly owned subsidiary of an entity in which a member of the Board of Directors of the Company holds an equity interest. Sales to this related party for the years ended December 30, 2019, December 31, 2018 and January 1, 2018 were $250, $8 and $78, respectively.

[0001564590-20-006477:notes:335]
As of December 30, 2019 and December 31, 2018, the Company’s consolidated balance sheets included $10,179 and $10,630, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated balance sheets. Additionally, the Company’s consolidated balance sheets as of December 30, 2019 and December 31, 2018, included $7 and $13, respectively, in accounts receivable due from a related party for sales of PCBs, as mentioned above, and such balances are included as a component of accounts receivable, net on the consolidated balance sheets.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001564590-20-006477:notes:336]
| (20) | Non-controlling Interest Holdings |

[0001564590-20-006477:notes:337]
During the fourth quarter of 2017, the Company acquired Desay Industrial’s 5% non-controlling equity interest in the manufacturing facility in Huiyang, China otherwise owned by the Company for 56,400 Chinese RMB or $8,568. The Company recorded an increase to additional paid-in capital for the difference between the purchase price and the carrying value of the non-controlling interest of $223.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-20-006477:notes:338]
| (21) | Acquisition of Anaren, Inc. |

[0001564590-20-006477:notes:339]
On April 18, 2018, the Company acquired all of the equity interests of Anaren for a total consideration of $787,911. Anaren was a leading provider of mission-critical RF solutions, microelectronics, and microwave components and assemblies for the wireless infrastructure and aerospace and defense electronics markets.

[0001564590-20-006477:notes:340]
Pro forma Financial Information (unaudited)

[0001564590-20-006477:notes:341]
The unaudited pro forma financial information below gives effect to this acquisition as if it had occurred at the beginning of fiscal 2017, or January 3, 2017. The pro forma financial information presented includes the effects of adjustments related to the amortization of acquired identifiable intangible assets and acquired inventory, depreciation of acquired fixed assets, and other non-recurring transactions costs directly associated with the acquisition such as legal, accounting and banking fees.

[0001564590-20-006477:notes:342]
The pro forma financial information as presented below is for informational purposes only and is not necessarily indicative of the actual results that would have been achieved had the acquisition occurred at the beginning of the earliest period presented, or the results that may be achieved in future periods.

[0001564590-20-006477:notes:343]
|  |  | For the Year Ended |  |
|  |  | December 31, |  |  | January 1, |  |
|  |  | 2018 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Net sales |  | $ | 2,915,935 |  |  | $ | 2,892,192 |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  |  | 190,198 |  |  |  | 106,881 |  |
| Basic earnings per share |  | $ | 1.84 |  |  | $ | 1.05 |  |
| Dilutive earnings per share |  | $ | 1.51 |  |  | $ | 0.91 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-20-006477:notes:344]
| (22) | Subsequent Events |

[0001564590-20-006477:notes:345]
In December 2019, a strain of coronavirus surfaced in China. As a result, there have been numerous factory closures. While many factories were closed for a few days because of the Chinese New Year holiday, the Chinese government ordered that businesses in various areas extend the Chinese New Year holiday due to the coronavirus outbreak. Moreover, because of the current restrictions on travel in China, the Company’s employees are affected and the Company experienced labor shortages. Also, it is possible that the Chinese government will announce new closures in the future. Some of the Company’s suppliers and customers in China have similarly been affected and experienced closures and risks of labor shortages. If these suppliers experience additional closures in the future, the Company may have difficulty sourcing materials necessary to fulfill production requirements and meet scheduled shipments, which will negatively affect revenues. Even if the Company is able to find alternate sources for such materials, they may cost more, which will affect profitability. If the Company’s customers in China experience additional closures in the future and are not able to accept orders or if they delay or cancel such orders, revenues will be negatively affected. At this point in time, there is significant uncertainty relating to the potential effect of the coronavirus on the Company’s business. Infections may become more widespread and there might be additional factory closures in the future, all of which will have a negative impact on the Company’s business, financial condition and operating results. As a result of this disruption, the Company’s financial results for the first quarter of 2020 will be negatively affected.

[0001564590-20-006477:notes:346]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement for the sale of the Company’s following subsidiaries: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit) for a base purchase price of $550,000 in cash, subject to customary purchase price adjustments. The purchase agreement excludes from the sale certain accounts receivable related to the business, which the Company expects, based on the terms of the purchase agreement will result in an estimated $110,000 in additional cash to the Company. The accounting recognition and financial reporting for the sale of these subsidiaries will be reflected in the Company’s financial statements in the period corresponding with its closing.
