# TTMI MD&A — 0000950170-22-023197


## mdna

[0000950170-22-023197:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000950170-22-023197:mdna:2]
[same as prior period, unchanged from 0001564590-22-028936:mdna:2]

[0000950170-22-023197:mdna:3]
We are a leading global manufacturer of technology solutions including engineered systems, radio frequency (RF) components and RF microwave/microelectronic assemblies, and printed circuit boards (PCB). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering, and manufacturing solution to our customers. This one-stop design, engineering, and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,400 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0000950170-22-023197:mdna:4]
[same as prior period, unchanged from 0001564590-22-028936:mdna:4]

[0000950170-22-023197:mdna:5]
On June 27, 2022, we completed our acquisition of all of the issued and outstanding common stock of Gritel Holding Co., Inc. (Gritel) and ISC Farmingdale Corp. for a total consideration of $298.3 million in cash. Telephonics Corporation is wholly-owned by Gritel, and as a result of the acquisition, became an indirect, wholly-owned subsidiary of the Company (collectively with ISC Farmingdale Corp., Telephonics). Telephonics is recognized globally as a leading provider of highly sophisticated military intelligence, surveillance and communications solutions that are deployed across a wide range of land, sea, and air applications.

[0000950170-22-023197:mdna:6]
On March 1, 2022, we announced that we will open a new highly automated PCB manufacturing facility in Penang, Malaysia. During the quarter ended October 3, 2022, we completed the pilings required for the building, laid the majority of the foundation, and began raising the steel framework. We have also received multiple deposits from customers with whom we have signed long term agreements which we expect can eventually provide a business base for over 60% of the planned capacity in the new building. We expect the facility to be operational in late 2023 and our total capital expenditures for the facility are expected to be approximately $130.0 million through 2025.

[0000950170-22-023197:mdna:7]
The coronavirus (COVID-19) pandemic initially caused business disruption to our operations in China in January 2020. By March 2020, the situation escalated as the scope of the COVID-19 pandemic worsened outside of the Asia-Pacific region, with Europe and North America being affected by the pandemic. We expect continued impacts on our production, as well as on-going significant uncertainty relating to the actual and potential impacts of the COVID-19 pandemic, and we cannot reasonably estimate its duration or severity. For example, during the first quarter of the 2022 fiscal year, an outbreak in Mainland China forced temporary lockdown orders in several cities in which we operate, and, at other times throughout 2022 the Chinese government has imposed lockdowns and other restrictions as part of its “zero-COVID” policy. Further, in North America, there was a surge in cases resulting from the Omicron variant from December 2021 through January 2022 which resulted in production inefficiencies caused by a combination of quarantine impacts and direct labor shortages on our overall production. The COVID-19 pandemic along with the conflict between Russia and Ukraine has created and continues to create various global macroeconomic, customer demand, operational and supply chain risks and has contributed to high inflation, labor shortages in North America, and a potential recession, each of which could have a material and adverse impact on our business going forward. See Item 1A, Risk Factors, of Part II below for further information related to the COVID-19 pandemic, conflict between Russia and Ukraine, and macro-economic risks resulting, in part, from the pandemic.

[0000950170-22-023197:mdna:8]
We are monitoring the impacts the COVID-19 pandemic has had, and continues to have, on our supply chain, and our operations in China, and are collaborating with our third-party partners with the goal of mitigating, to the extent reasonably practicable, significant delays in delivery of our products. We continue to experience supply chain constraints and inflationary pressures. We have been actively taking measures intended to manage both supply chain constraints and higher raw materials costs, including, without limitation, through such measures as supplier diversification, on-going operational efficiency efforts and quotation adjustments to mitigate the impact on our business.

[0000950170-22-023197:mdna:9]
[same as prior period, unchanged from 0001564590-22-028936:mdna:10]

[0000950170-22-023197:mdna:10]
[same as prior period, unchanged from 0001564590-22-028936:mdna:11]

[0000950170-22-023197:mdna:11]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 45% and 43% of our net sales for the quarter and three quarters ended October 3, 2022, respectively. Sales to our ten largest customers collectively accounted for 41% of our net sales for both the quarter and three quarters ended September 27, 2021. We sell to OEMs both directly and indirectly through EMS providers.

[0000950170-22-023197:mdna:12]
[same as prior period, unchanged from 0001564590-22-028936:mdna:13]

[0000950170-22-023197:mdna:13]
|  |  | Quarter Ended |  |  |  | Three Quarters Ended |  |  |
| End Markets (1) |  | October 3, 2022 |  |  |  | September 27, 2021 |  |  |  | October 3, 2022 |  |  |  | September 27, 2021 |  |  |
| Aerospace and Defense |  |  | 38 |  | % |  |  | 31 |  | % |  |  | 33 |  | % |  |  | 33 |  | % |
| Automotive |  |  | 15 |  |  |  |  | 18 |  |  |  |  | 17 |  |  |  |  | 18 |  |  |
| Data Center Computing |  |  | 14 |  |  |  |  | 14 |  |  |  |  | 16 |  |  |  |  | 14 |  |  |
| Medical/Industrial/Instrumentation |  |  | 19 |  |  |  |  | 20 |  |  |  |  | 21 |  |  |  |  | 19 |  |  |
| Networking/Communications |  |  | 14 |  |  |  |  | 16 |  |  |  |  | 13 |  |  |  |  | 15 |  |  |
| Other (2) |  |  | — |  |  |  |  | 1 |  |  |  |  | — |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0000950170-22-023197:mdna:14]
(1)
Sales to EMS companies are classified by the end markets of their OEM customers.

[0000950170-22-023197:mdna:15]
(2)
Other end market reflects direct sales to EMS and distributor customers.

[0000950170-22-023197:mdna:16]
We derive revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of highly sophisticated intelligence, surveillance and communications solutions, RF and microwave/microelectronics components, assemblies, and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and custom electronic assemblies manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, we recognize revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on a cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Revenues are recorded proportionally as costs are incurred.

[0000950170-22-023197:mdna:17]
[same as prior period, unchanged from 0001564590-22-028936:mdna:18]

[0000950170-22-023197:mdna:18]
[same as prior period, unchanged from 0001564590-22-028936:mdna:19]

[0000950170-22-023197:mdna:19]
[same as prior period, unchanged from 0001564590-22-028936:mdna:20]

[0000950170-22-023197:mdna:20]
[same as prior period, unchanged from 0001564590-22-028936:mdna:21]

[0000950170-22-023197:mdna:21]
[same as prior period, unchanged from 0001564590-22-028936:mdna:22]

[0000950170-22-023197:mdna:22]
[same as prior period, unchanged from 0001564590-22-028936:mdna:23]

[0000950170-22-023197:mdna:23]
[same as prior period, unchanged from 0001564590-22-028936:mdna:24]

[0000950170-22-023197:mdna:24]
[same as prior period, unchanged from 0001564590-22-028936:mdna:25]

[0000950170-22-023197:mdna:25]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended January 3, 2022 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since January 3, 2022.

[0000950170-22-023197:mdna:26]
[same as prior period, unchanged from 0001564590-22-028936:mdna:27]

[0000950170-22-023197:mdna:27]
[same as prior period, unchanged from 0001564590-22-028936:mdna:28]

[0000950170-22-023197:mdna:28]
|  |  | Quarter Ended |  | Three Quarters Ended |
|  |  | October 3, 2022 |  |  |  | September 27, 2021 |  |  |  | October 3, 2022 |  |  |  | September 27, 2021 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 80.8 |  |  |  |  | 83.3 |  |  |  |  | 82.1 |  |  |  |  | 83.4 |  |  |
| Gross profit |  |  | 19.2 |  |  |  |  | 16.7 |  |  |  |  | 17.9 |  |  |  |  | 16.6 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 3.0 |  |  |  |  | 2.8 |  |  |  |  | 2.9 |  |  |  |  | 2.8 |  |  |
| General and administrative |  |  | 6.2 |  |  |  |  | 5.8 |  |  |  |  | 6.6 |  |  |  |  | 5.8 |  |  |
| Research and development |  |  | 1.1 |  |  |  |  | 0.8 |  |  |  |  | 1.0 |  |  |  |  | 0.8 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.5 |  |  |  |  | 1.5 |  |  |  |  | 1.4 |  |  |  |  | 1.6 |  |  |
| Total operating expenses |  |  | 11.8 |  |  |  |  | 10.9 |  |  |  |  | 11.9 |  |  |  |  | 11.0 |  |  |
| Operating income |  |  | 7.4 |  |  |  |  | 5.8 |  |  |  |  | 6.0 |  |  |  |  | 5.6 |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (1.6 | ) |  |  |  | (2.0 | ) |  |  |  | (1.8 | ) |  |  |  | (2.0 | ) |  |
| Loss on extinguishment of debt |  |  | — |  |  |  |  | — |  |  |  |  | — |  |  |  |  | (0.9 | ) |  |
| Other, net |  |  | 1.5 |  |  |  |  | 0.5 |  |  |  |  | 1.1 |  |  |  |  | 0.3 |  |  |
| Total other expense, net |  |  | (0.1 | ) |  |  |  | (1.5 | ) |  |  |  | (0.7 | ) |  |  |  | (2.6 | ) |  |
| Income before income taxes |  |  | 7.3 |  |  |  |  | 4.3 |  |  |  |  | 5.3 |  |  |  |  | 3.0 |  |  |
| Income tax provision |  |  | (0.8 | ) |  |  |  | (0.5 | ) |  |  |  | (0.6 | ) |  |  |  | (0.2 | ) |  |
| Net income |  |  | 6.5 |  | % |  |  | 3.8 |  | % |  |  | 4.7 |  | % |  |  | 2.8 |  | % |

[0000950170-22-023197:mdna:29]
We have two reportable segments: PCB and RF&S Components. We have not yet determined how to treat Telephonics for segment reporting purposes, as we are still in the process of determining how to allocate resources and assess performance in relation to the acquisition of Telephonics. As a result, our discussion and analysis below separates the results of Telephonics from our two reportable segments.

[0000950170-22-023197:mdna:30]
[same as prior period, unchanged from 0001564590-22-028936:mdna:30]

[0000950170-22-023197:mdna:31]
Total net sales increased $114.3 million, or 20.5%, to $671.1 million for the third quarter of 2022 from $556.8 million for the third quarter of 2021. This increase was primarily due to the acquisition of Telephonics during 2022, which accounted for $68.3 million in net sales for the third quarter of 2022. Additionally, there was an increase in net sales for the PCB reportable segment of $47.8 million, or 8.8%, to $588.9 million for the third quarter of 2022 from $541.1 million for the third quarter of 2021, which was primarily due to strong growth across all of our end markets. The increase in PCB net sales also benefitted from a 20.0% increase in the average price per square foot driven mainly by better product mix, higher pricing and premium revenue, partially offset by a 4.3% decrease in the volume of PCB shipments as compared to the third quarter of 2021. Net sales for the RF&S Components reportable segment decreased $1.8 million, or 11.2%, to $13.9 million for the third quarter of 2022 from $15.7 million for the third quarter of 2021, which was primarily due to lower demand.

[0000950170-22-023197:mdna:32]
Total net sales increased $227.3 million, or 13.8%, to $1,877.9 million for the first three quarters of 2022 from $1,650.6 million for the first three quarters of 2021. This increase primarily resulted from an increase in net sales for the PCB reportable segment of $159.3 million, or 9.9%, to $1,764.4 million for the first three quarters of 2022 from $1,605.1 million for the first three quarters of 2021 primarily due to strong growth across all of our end markets except in our Networking/Communications and Other end markets. The increase in PCB net sales also benefitted from a 13.8% increase in the average price per square foot driven mainly by better product mix, higher pricing and premium revenue. Volume was essentially unchanged. The increase in net sales was also due to the acquisition of Telephonics during 2022, which accounted for $68.3 million in net sales for the first three quarters of 2022. Net sales for the RF&S Components reportable segment increased $3.0 million, or 7.0%, to $45.2 million for the first three quarters of 2022 from $42.2 million for the first three quarters of 2021, which was primarily due to higher demand in our Networking/Communications end market.

[0000950170-22-023197:mdna:33]
[same as prior period, unchanged from 0001564590-22-028936:mdna:33]

[0000950170-22-023197:mdna:34]
Overall gross margin increased to 19.2% for the third quarter of 2022 from 16.7% for the third quarter of 2021. Gross margin for the PCB reportable segment increased to 18.8% for the third quarter of 2022 from 15.8% for the third quarter of 2021. This increase was primarily due to better product mix, higher pricing and premium revenue, partially offset by higher labor costs, particularly in North America as we raised wages this year to be more competitive. Gross margin for the RF&S Components reportable segment increased to 63.5% for the third quarter of 2022 from 57.9% for the third quarter of 2021, primarily due to favorable product mix. The acquisition of Telephonics during 2022 also contributed a 0.3% increase in gross margin.

[0000950170-22-023197:mdna:35]
Overall gross margin increased to 17.9% for the first three quarters of 2022 from 16.6% for the first three quarters of 2021. Gross margin for the PCB reportable segment increased to 17.8% for the first three quarters of 2022 from 16.3% for the first three quarters of 2021. This increase was primarily due to better product mix, higher pricing and premium revenue, partially offset by higher labor costs, particularly in North America as we raised wages this year to be more competitive. Gross margin for the RF&S Components reportable segment increased to 61.3% for the first three quarters of 2022 from 54.2% for the first three quarters of 2021, primarily due to higher sales.

[0000950170-22-023197:mdna:36]
Capacity utilization is a key driver for us, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the third quarter of 2022 in our Asia and North America PCB facilities was 78% and 45%, respectively, compared to 91% and 50%, respectively, for the third quarter of 2021. Capacity utilization for the first three quarters of 2022 in our Asia and North America PCB facilities was 84% and 44%, respectively, compared to 86% and 52%, respectively, for the first three quarters of 2021. The decrease in capacity utilization for both the third quarter of 2022 and the first three quarters of 2022 in our Asia PCB facilities was caused by a decline in production volumes while the decrease in our North America PCB facilities during the same periods was due to the additional plating capacity added earlier in the year and direct labor shortages in certain regions.

[0000950170-22-023197:mdna:37]
[same as prior period, unchanged from 0001564590-22-028936:mdna:37]

[0000950170-22-023197:mdna:38]
Selling and marketing expense increased $4.0 million, to $19.8 million for the third quarter of 2022 from $15.8 million for the third quarter of 2021. As a percentage of net sales, selling and marketing expense was 3.0% for the third quarter of 2022, as compared to 2.8% for the third quarter of 2021. The increase in selling and marketing expense was primarily due to $2.3 million of selling and marketing expenses incurred by Telephonics post acquisition and an increase in labor costs.

[0000950170-22-023197:mdna:39]
Selling and marketing expenses increased $8.9 million, to $55.6 million for the first three quarters of 2022 from $46.7 million for the first three quarters of 2021. As a percentage of net sales, selling and marketing expenses was 2.9% for the first three quarters of 2022, as compared to 2.8% for the first three quarters of 2021. The increase in selling and marketing expense for the first three quarters of 2022 was primarily due to $2.3 million of selling and marketing expenses incurred by Telephonics post acquisition and increases in commission expense and labor costs.

[0000950170-22-023197:mdna:40]
[same as prior period, unchanged from 0001564590-22-028936:mdna:40]

[0000950170-22-023197:mdna:41]
General and administrative expense increased $9.0 million to $41.4 million, or 6.2% of net sales, for the third quarter of 2022 from $32.4 million, or 5.8% of net sales, for the third quarter of 2021. The increase in expense was primarily due to $3.2 million of general and administrative expense incurred by Telephonics post acquisition and an increase in incentive compensation and labor costs.

[0000950170-22-023197:mdna:42]
General and administrative expense increased $28.0 million to $123.1 million, or 6.6% of net sales, for the first three quarters of 2022 from $95.1 million, or 5.8% of net sales, for the first three quarters of 2021. The increase in expense was primarily due to $11.0 million of costs incurred in connection with the acquisition of Telephonics on June 27, 2022 and $3.2 million of general and administrative expense incurred by Telephonics post acquisition. In addition, there were increases in labor costs, incentive compensation and bad debt. These increases were partially offset by the decrease in restructuring charges of $3.4 million associated with the restructuring of our E-M Solutions business unit during the first three quarters of 2021.

[0000950170-22-023197:mdna:43]
[same as prior period, unchanged from 0001564590-22-028936:mdna:43]

[0000950170-22-023197:mdna:44]
Other expense, net decreased $8.0 million to $0.6 million for the third quarter of 2022 from $8.6 million for the third quarter of 2021. This decrease was primarily the result of foreign currency gains due to the weakening of the Chinese Renminbi (RMB) in the third quarter of 2022 compared to the third quarter of 2021. We utilize the RMB at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China.

[0000950170-22-023197:mdna:45]
Other expense, net decreased $30.4 million to $13.1 million for the first three quarters of 2022 from $43.5 million for the first three quarters of 2021. This decrease was primarily the result of the absence of $15.2 million of loss on extinguishment of debt. In addition, there were foreign currency gains due to the weakening of the RMB in the first three quarters of 2022 compared to the first three quarters of 2021, partially offset by lower government subsidies.

[0000950170-22-023197:mdna:46]
[same as prior period, unchanged from 0001564590-22-028936:mdna:46]

[0000950170-22-023197:mdna:47]
Income tax expense increased by $2.9 million to $5.6 million of tax expense for the third quarter of 2022 from $2.7 million of tax expense for the third quarter of 2021. The increase in income tax expense for the third quarter of 2022 was primarily due to an increase in pre-tax income offset by the absence in the third quarter of 2022 of new uncertain tax positions that existed in the third quarter of 2021.

[0000950170-22-023197:mdna:48]
Income tax expense increased by $7.8 million to $11.2 million of tax expense for the first three quarters of 2022 from $3.4 million of tax expense for the first three quarters of 2021. The increase in income tax expense for the first three quarters of 2022 was primarily due to an increase in pre-tax income and a lower uncertain tax position release benefit (which resulted from the expiration of the statute of limitation in foreign jurisdictions). The increase was partially offset by the approval of two of the Company’s renewal applications for High and New Enterprise status in China in the current year and the absence in the third quarter of 2022 of new uncertain tax positions that existed in the third quarter of 2021.

[0000950170-22-023197:mdna:49]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax liability of approximately $8.9 million and a net deferred income tax asset of approximately $12.9 million as of October 3, 2022 and September 27, 2021, respectively. The decrease in the deferred income tax asset was primarily due to the recording of a net deferred income tax liability of $22.9 million related to the Telephonics’ acquisition.

[0000950170-22-023197:mdna:50]
On August 9, 2022 and August 16, 2022, the President of the United States signed the CHIPS and Science Act of 2022 (CHIPS Act) and the Inflation Reduction Act of 2022 (IRA), respectively. Accounting Standards Codification (ASC) 740, Accounting for Income Taxes, requires companies to recognize the effect of tax law changes in the period of enactment regardless of the effective date of those tax law changes. We considered the impact to our financial statements of the corporate income tax aspects of the CHIPS Act and IRA, and determined the impact is not material to our financial statements.

[0000950170-22-023197:mdna:51]
[same as prior period, unchanged from 0001564590-22-028936:mdna:51]

[0000950170-22-023197:mdna:52]
Our principal sources of liquidity have been cash provided by operations, the issuance of debt, and borrowings under our revolving credit facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, fund working capital requirements, to repay debt obligations, and to repurchase common stock. We anticipate that financing capital expenditures, financing acquisitions, funding working capital requirements, servicing debt, and repurchasing common stock will be the principal demands on our cash in the future.

[0000950170-22-023197:mdna:53]
Cash flow provided by operating activities during the first three quarters of 2022 was $195.3 million as compared to cash flow provided by operating activities of $114.3 million in the same period in 2021. The increase in cash flow was primarily due to an increase in net income of $42.5 million compared to the comparable prior year period and an overall decreased investment in working capital.

[0000950170-22-023197:mdna:54]
Net cash used in investing activities was approximately $374.7 million for the first three quarters of 2022, primarily reflecting $298.3 million for the acquisition of Telephonics and $76.2 million for purchases of property, plant and equipment and other assets. Net cash used in investing activities was approximately $61.1 million for the first three quarters of 2021, reflecting $62.1 million for purchases of property, plant and equipment and other assets less $1.0 million for proceeds from the sale of property, plant and equipment and other assets.

[0000950170-22-023197:mdna:55]
Net cash used in financing activities during the first three quarters of 2022 was $21.3 million, primarily reflecting repurchases of common stock of $35.4 million, cash used to settle warrants of $0.9 million, less customer deposits of $15.0 million. Net cash provided by financing activities during the first three quarters of 2021 was $24.8 million, primarily reflecting proceeds from long-term debt borrowing of $500.0 million, less the repayment of long-term debt borrowings of $425.8 million, repurchases of common stock of $33.2 million, capital equipment financing of $7.1 million, payment of debt issuance costs of $5.9 million, and cash used to settle warrants of $3.2 million.

[0000950170-22-023197:mdna:56]
As of October 3, 2022, we had cash and cash equivalents of approximately $335.6 million, of which approximately $196.3 million was held by our foreign subsidiaries, primarily in Hong Kong. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for the repatriation of this cash.

[0000950170-22-023197:mdna:57]
Our total 2022 capital expenditures are expected to be in the range of $100.0 million to $120.0 million.

[0000950170-22-023197:mdna:58]
[same as prior period, unchanged from 0001564590-22-028936:mdna:58]

[0000950170-22-023197:mdna:59]
On February 3, 2021, our board of directors authorized a share repurchase program allowing us to repurchase up to $100.0 million of our common stock. During the three quarters ended October 3, 2022, we repurchased a total of 2.7 million shares of our common stock for a total cost of $35.4 million (including commissions). As of October 3, 2022, there are no amounts authorized for repurchase. We repurchased a total of 7.5 million shares of our common stock for $100.0 million under the share repurchase program.

[0000950170-22-023197:mdna:60]
[same as prior period, unchanged from 0001564590-22-028936:mdna:60]

[0000950170-22-023197:mdna:61]
As of October 3, 2022, we had $929.0 million of outstanding debt, net of discount and debt issuance costs, composed of $495.0 million of Senior Notes due March 2029, $404.0 million of a Term Loan due September 2024, and $30.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL).

[0000950170-22-023197:mdna:62]
Pursuant to the terms of the Term Loan Facility and Senior Notes due 2029, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of October 3, 2022, we were in compliance with the covenants under the Term Loan Facility, Senior Notes due 2029 and ABL Revolving Loans.

[0000950170-22-023197:mdna:63]
[same as prior period, unchanged from 0001564590-22-028936:mdna:63]

[0000950170-22-023197:mdna:64]
[same as prior period, unchanged from 0001564590-22-028936:mdna:64]

[0000950170-22-023197:mdna:65]
As part of our on-going operations, we enter into contractual arrangements that obligate us to make future cash payments. These obligations impact our liquidity and capital resource needs. Our estimated future obligations consist of long-term debt obligations, interest on debt obligations, purchase obligations, and leases as of October 3, 2022. As of the date of this report, our contractual obligations have not changed materially since January 3, 2022, except for additional purchase obligations resulting from the Telephonics acquisition. As of October 3, 2022, additional purchase obligations resulting from the Telephonics acquisition amounted to $104.9 million, which are expected to be settled as follows: $96.3 million within 1 year and $8.6 million within 1-3 years.

[0000950170-22-023197:mdna:66]
Offset Agreements

[0000950170-22-023197:mdna:67]
Following the acquisition of Telephonics on June 27, 2022, we have and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for our products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and our obligations under these agreements may be satisfied through activities that do not require us to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for such activities as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations, if applicable. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of October 3, 2022, we had outstanding offset agreements of approximately $32.0 million, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event we fail to perform in accordance with contract requirements. Historically, we have not paid any such penalties, and as of October 3, 2022, no such penalties are estimable or probable.

[0000950170-22-023197:mdna:68]
[same as prior period, unchanged from 0001564590-22-028936:mdna:66]

[0000950170-22-023197:mdna:69]
We tend to experience modest seasonal softness in the first and third quarters due to holidays and vacation periods in China and North America, respectively, which limit production leading to stronger revenue levels in the second and fourth quarters.

[0000950170-22-023197:mdna:70]
Recently Issued Accounting Standards

[0000950170-22-023197:mdna:71]
[same as prior period, unchanged from 0001564590-22-028936:mdna:69]
