# TTMI notes — 0000950170-22-023197


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0000950170-22-023197:notes:1]
[same as prior period, unchanged from 0001564590-22-028936:notes:1]

[0000950170-22-023197:notes:2]
[same as prior period, unchanged from 0001564590-22-028936:notes:2]

[0000950170-22-023197:notes:3]
[same as prior period, unchanged from 0001564590-22-028936:notes:3]

[0000950170-22-023197:notes:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due, in part, to the coronavirus (COVID-19) global pandemic and the conflict between Russia and Ukraine, the global economy and financial markets have been volatile, and both the pandemic and conflict has contributed to on-going disruptions in global supply chains, labor shortages, high inflation, and a potential recession, and there is a significant amount of uncertainty about the length and severity of the direct and indirect effects of the pandemic and the conflict. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31.

[0000950170-22-023197:notes:5]
[same as prior period, unchanged from 0001564590-22-028936:notes:5]

[0000950170-22-023197:notes:6]
Recently Adopted Accounting Standards

[0000950170-22-023197:notes:7]
In October 2021, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires that an acquirer recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification (ASC) 606, Revenue from Contracts with Customers, as if it had originated the contracts. Prior to this ASU, an acquirer generally recognizes contract assets acquired and contract liabilities assumed that arose from contracts with customers at fair value on the acquisition date. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The ASU is to be applied prospectively to business combinations occurring on or after the effective date of the amendment (or if adopted early as of an interim period, as of the beginning of the fiscal year that includes the interim period of early application). The Company early adopted ASU 2021-08 on April 4, 2022 and did not have an impact on its consolidated condensed financial statements and related disclosures. The new guidance was applied to the acquisition of Gritel Holding Co., Inc. (Gritel), ISC Farmingdale Corp., and Gritel's wholly owned subsidiary, Telephonics Corporation.

[0000950170-22-023197:notes:8]
Recently Issued Accounting Standards Not Yet Adopted

[0000950170-22-023197:notes:9]
In September 2022, the FASB issued ASU 2022-04, Liabilities - Supplier Finance Programs (Topic 450-50): Disclosure of Supplier Finance Program Obligations, that requires entities that use supplier finance programs in connection with the purchase of goods and services to disclose the key terms of the programs and information about obligations outstanding at the end of the reporting period, including a rollforward of those obligations. The guidance does not affect the recognition, measurement or financial statement presentation of supplier finance program obligations. The amendments are effective for all entities for fiscal years beginning after December 15, 2022 on a retrospective basis, including interim periods within those fiscal years, except for the requirement to disclose rollforward information, which is effective prospectively for fiscal years beginning after December 15, 2023. Early adoption is permitted upon issuance of the update. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.

[0000950170-22-023197:notes:10]
In November 2021, the FASB issued ASU 2021-10, Government Assistance (Topic 832): Disclosures by Business Entities about Government Assistance, which provides guidance on disclosures for transactions with a government that are accounted for by applying a grant or contribution accounting model by analogy. The guidance is effective for annual periods beginning after December 15, 2021. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on the consolidated financial statements and related disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-22-023197:notes:11]
[same as prior period, unchanged from 0001564590-22-028936:notes:10]

[0000950170-22-023197:notes:12]
On June 27, 2022, the Company completed its acquisition of all of the issued and outstanding capital stock of Gritel and ISC Farmingdale Corp. for a total consideration of $298,339 in cash. Telephonics Corporation is wholly-owned by Gritel, and as a result of the acquisition, became an indirect, wholly-owned subsidiary of the Company (collectively with ISC Farmingdale Corp., Telephonics).

[0000950170-22-023197:notes:13]
For the quarter and three quarters ended October 3, 2022, bank fees and legal, accounting, and other professional service costs associated with the acquisition of $270 and $10,978, respectively, have been expensed and recorded as general and administrative expense in the consolidated condensed statements of operations. There were no bank fees or legal, accounting, or other professional service costs associated with the acquisition for the quarter and three quarters ended September 27, 2021.

[0000950170-22-023197:notes:14]
[same as prior period, unchanged from 0001564590-22-028936:notes:13]

[0000950170-22-023197:notes:15]
[same as prior period, unchanged from 0001564590-22-028936:notes:14]

[0000950170-22-023197:notes:16]
[same as prior period, unchanged from 0001564590-22-028936:notes:15]

[0000950170-22-023197:notes:17]
|  |  | (In thousands) |  |  |
| Accounts receivable |  | $ | 53,886 |  |  |
| Contract assets |  |  | 30,100 |  |  |
| Inventories |  |  | 60,855 |  |  |
| Prepaid expenses and other current assets |  |  | 5,708 |  |  |
| Property, plant and equipment |  |  | 72,230 |  |  |
| Operating lease right-of-use assets |  |  | 2,887 |  |  |
| Goodwill |  |  | 93,070 |  |  |
| Identifiable intangible assets |  |  | 90,750 |  |  |
| Deposits and other non-current assets |  |  | 3,263 |  |  |
| Accounts payable |  |  | (16,026 | ) |  |
| Contract liabilities |  |  | (51,810 | ) |  |
| Accrued salaries, wages and benefits |  |  | (10,575 | ) |  |
| Other current liabilities |  |  | (11,143 | ) |  |
| Operating lease liabilities |  |  | (1,874 | ) |  |
| Non-current deferred tax liabilities |  |  | (22,941 | ) |  |
| Other long-term liabilities |  |  | (41 | ) |  |
| Total |  | $ | 298,339 |  |  |

[0000950170-22-023197:notes:18]
The Company’s fair value estimates for all of the acquired assets and liabilities are preliminary and may change during the allowable measurement period, which is up to the point the Company obtains and analyzes the information that existed as of the date of the acquisition necessary to determine the fair values of the assets acquired and liabilities assumed, but in no case to exceed more than one year from the date of acquisition. Any subsequent changes to the purchase price allocation during the measurement period will be recorded in the reporting period in which the adjustment amounts are determined. Any changes in the fair values of the assets acquired and liabilities assumed during the measurement period may result in material adjustments to goodwill.

[0000950170-22-023197:notes:19]
Goodwill represents the excess of the purchase price over the fair value of assets acquired and liabilities assumed. During the quarter ended October 3, 2022, the Company increased goodwill by $14,803 due to an adjustment to the assessment of fair value for certain acquired inventories, property, plant and equipment, various other assets and liabilities. The adjustments did not have a material impact to the consolidated condensed statements of operations of the Company. The Company believes that the acquisition of Telephonics will strengthen the Company’s differentiated position in the Aerospace and Defense market and complement existing RF and microwave businesses. The Company believes that these factors support the amount of goodwill recognized as a result of the purchase price paid for Telephonics, in relation to other acquired tangible and intangible assets. The goodwill acquired in the acquisition is not deductible for income tax purposes.

[0000950170-22-023197:notes:20]
Results of Operations

[0000950170-22-023197:notes:21]
Included in the consolidated condensed statements of operations are $68,255 and $6,997, excluding intercompany sales, of net sales and pre-tax income for both the quarter and three quarters ended October 3, 2022, respectively.

[0000950170-22-023197:notes:22]
[same as prior period, unchanged from 0001564590-22-028936:notes:20]

[0000950170-22-023197:notes:23]
The unaudited preliminary pro forma financial information below gives effect to this acquisition as if it had occurred at the beginning of fiscal 2021, or December 29, 2020. The preliminary pro forma financial information presented includes the effects of adjustments related to the amortization of acquired identifiable intangible assets and decrease in inventory markup, depreciation of acquired fixed assets, and other non-recurring transactions costs directly associated with the acquisition such as legal, accounting and banking fees.

[0000950170-22-023197:notes:24]
[same as prior period, unchanged from 0001564590-22-028936:notes:22]

[0000950170-22-023197:notes:25]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 3, 2022 |  |  | September 27, 2021 |  |  | October 3, 2022 |  |  | September 27, 2021 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net sales |  | $ | 671,080 |  |  | $ | 637,352 |  |  | $ | 1,984,958 |  |  | $ | 1,853,892 |  |
| Net income |  |  | 43,528 |  |  |  | 24,718 |  |  |  | 95,947 |  |  |  | 50,583 |  |
| Basic earnings per share |  | $ | 0.43 |  |  | $ | 0.23 |  |  | $ | 0.94 |  |  | $ | 0.47 |  |
| Diluted earnings per share |  | $ | 0.42 |  |  | $ | 0.23 |  |  | $ | 0.92 |  |  | $ | 0.46 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000950170-22-023197:notes:26]
[same as prior period, unchanged from 0001564590-22-028936:notes:24]

[0000950170-22-023197:notes:27]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases and finance leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments, and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the right-of-use (ROU) asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-22-023197:notes:28]
[same as prior period, unchanged from 0001564590-22-028936:notes:26]

[0000950170-22-023197:notes:29]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 3, 2022 |  |  | September 27, 2021 |  |  | October 3, 2022 |  |  | September 27, 2021 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 2,080 |  |  | $ | 2,015 |  |  | $ | 5,756 |  |  | $ | 6,147 |  |
| Variable lease cost |  |  | 383 |  |  |  | 193 |  |  |  | 837 |  |  |  | 567 |  |
| Short-term lease cost |  |  | 199 |  |  |  | 89 |  |  |  | 513 |  |  |  | 198 |  |
| Finance lease costs: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of right-of-use assets |  |  | 344 |  |  |  | — |  |  |  | 1,031 |  |  |  | — |  |
| Interest on lease liabilities |  |  | 98 |  |  |  | — |  |  |  | 295 |  |  |  | — |  |

[0000950170-22-023197:notes:30]
[same as prior period, unchanged from 0001564590-22-028936:notes:28]

[0000950170-22-023197:notes:31]
|  |  | Three Quarters Ended |  |
|  |  | October 3, 2022 |  |  | September 27, 2021 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |
| Operating cash flows for operating leases |  | $ | 5,796 |  |  | $ | 6,321 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |
| Operating leases |  |  | 5,196 |  |  |  | 1,954 |  |
| Finance leases |  |  | — |  |  |  | 15,256 |  |

[0000950170-22-023197:notes:32]
[same as prior period, unchanged from 0001564590-22-028936:notes:30]

[0000950170-22-023197:notes:33]
|  |  |  |  | As of |  |
|  |  | Balance Sheet Location |  | October 3, 2022 |  |  | January 3, 2022 |  |
|  |  |  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease right-of-use assets |  | $ | 20,464 |  |  | $ | 20,802 |  |
| Finance leases |  | Property, plant and equipment, net |  |  | 13,728 |  |  |  | 14,759 |  |
| Total lease assets |  |  |  | $ | 34,192 |  |  | $ | 35,561 |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 7,434 |  |  | $ | 6,362 |  |
| Finance leases |  | Other current liabilities |  |  | 718 |  |  |  | 698 |  |
| Long-term: |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease liabilities |  |  | 13,687 |  |  |  | 15,252 |  |
| Finance leases |  | Other long-term liabilities |  |  | 13,771 |  |  |  | 14,317 |  |
| Total lease liabilities |  |  |  | $ | 35,610 |  |  | $ | 36,629 |  |

[0000950170-22-023197:notes:34]
|  |  | As of |  |
|  |  | October 3, 2022 |  |  | January 3, 2022 |  |
| Weighted average remaining lease term (years): |  |  |  |  |  |  |
| Operating leases |  | 3.3 |  |  | 3.9 |  |
| Finance leases |  | 13.9 |  |  | 14.6 |  |
| Weighted average discount rate: |  |  |  |  |  |  |
| Operating leases |  |  | 3.01 | % |  |  | 2.56 | % |
| Finance leases |  |  | 2.69 | % |  |  | 2.68 | % |

[0000950170-22-023197:notes:35]
[same as prior period, unchanged from 0001564590-22-028936:notes:33]

[0000950170-22-023197:notes:36]
|  |  | OperatingLeases (1) |  |  | FinanceLeases |  |
|  |  | (In thousands) |  |
| Less than one year |  | $ | 7,940 |  |  | $ | 1,096 |  |
| 1 - 2 years |  |  | 6,720 |  |  |  | 1,137 |  |
| 2 - 3 years |  |  | 4,482 |  |  |  | 1,133 |  |
| 3 - 4 years |  |  | 1,932 |  |  |  | 1,175 |  |
| 4 - 5 years |  |  | 598 |  |  |  | 1,184 |  |
| Thereafter |  |  | 582 |  |  |  | 11,765 |  |
| Total lease payments |  |  | 22,254 |  |  |  | 17,490 |  |
| Less imputed interest |  |  | (1,133 | ) |  |  | (3,001 | ) |
| Total |  | $ | 21,121 |  |  | $ | 14,489 |  |

[0000950170-22-023197:notes:37]
(1)
Excludes $851 of legally binding minimum lease payments for leases signed but not yet commenced.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-22-023197:notes:38]
[same as prior period, unchanged from 0001564590-22-028936:notes:36]

[0000950170-22-023197:notes:39]
As of October 3, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $303,046. The Company expects to recognize revenue on approximately 64% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.

[0000950170-22-023197:notes:40]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter and three quarters ended October 3, 2022, and 97% and 3%, respectively, of the Company’s revenue for the quarter and three quarters ended September 27, 2021.

[0000950170-22-023197:notes:41]
[same as prior period, unchanged from 0001564590-22-028936:notes:39]

[0000950170-22-023197:notes:42]
|  |  | Quarter Ended October 3, 2022 |  |  | Quarter Ended September 27, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 186,030 |  |  | $ | — |  |  | $ | 68,255 |  |  | $ | 254,285 |  |  | $ | 173,894 |  |  | $ | 12 |  |  | $ | 173,906 |  |  |
| Automotive |  |  | 100,811 |  |  |  | — |  |  |  | — |  |  |  | 100,811 |  |  |  | 99,205 |  |  |  | — |  |  |  | 99,205 |  |  |
| Data Center Computing |  |  | 95,830 |  |  |  | 13 |  |  |  | — |  |  |  | 95,843 |  |  |  | 81,202 |  |  |  | — |  |  |  | 81,202 |  |  |
| Medical/Industrial/Instrumentation |  |  | 128,444 |  |  |  | 1,239 |  |  |  | — |  |  |  | 129,683 |  |  |  | 108,879 |  |  |  | 1,467 |  |  |  | 110,346 |  |  |
| Networking/Communications |  |  | 78,181 |  |  |  | 12,494 |  |  |  | — |  |  |  | 90,675 |  |  |  | 74,316 |  |  |  | 12,848 |  |  |  | 87,164 |  |  |
| Other |  |  | (376 | ) |  |  | 159 |  |  |  | — |  |  |  | (217 | ) |  |  | 3,622 |  |  |  | 1,339 |  |  |  | 4,961 |  |  |
| Total |  | $ | 588,920 |  |  | $ | 13,905 |  |  | $ | 68,255 |  |  | $ | 671,080 |  |  | $ | 541,118 |  |  | $ | 15,666 |  |  | $ | 556,784 |  |  |

[0000950170-22-023197:notes:43]
|  |  | Three Quarters Ended October 3, 2022 |  |  | Three Quarters Ended September 27, 2021 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 547,886 |  |  | $ | — |  |  |  | $ | 68,255 |  |  | $ | 616,141 |  |  | $ | 545,585 |  |  | $ | 24 |  |  | $ | — |  |  | $ | 545,609 |  |  |
| Automotive |  |  | 327,825 |  |  |  | — |  |  |  |  | — |  |  |  | 327,825 |  |  |  | 293,890 |  |  |  | — |  |  |  | 3,642 |  |  |  | 297,532 |  |  |
| Data Center Computing |  |  | 293,802 |  |  |  | 33 |  |  |  |  | — |  |  |  | 293,835 |  |  |  | 235,191 |  |  |  | 456 |  |  |  | — |  |  |  | 235,647 |  |  |
| Medical/Industrial/Instrumentation |  |  | 379,867 |  |  |  | 5,023 |  |  |  |  | — |  |  |  | 384,890 |  |  |  | 303,661 |  |  |  | 3,615 |  |  |  | 25 |  |  |  | 307,301 |  |  |
| Networking/Communications |  |  | 211,590 |  |  |  | 41,360 |  |  |  |  | — |  |  |  | 252,950 |  |  |  | 216,982 |  |  |  | 35,451 |  |  |  | 1 |  |  |  | 252,434 |  |  |
| Other |  |  | 3,449 |  |  |  | (1,200 | ) |  |  |  | — |  |  |  | 2,249 |  |  |  | 9,775 |  |  |  | 2,713 |  |  |  | (412 | ) |  |  | 12,076 |  |  |
| Total |  | $ | 1,764,419 |  |  | $ | 45,216 |  |  |  | $ | 68,255 |  |  | $ | 1,877,890 |  |  | $ | 1,605,084 |  |  | $ | 42,259 |  |  | $ | 3,256 |  |  | $ | 1,650,599 |  |  |

[0000950170-22-023197:notes:44]
(1)
Other represents results from Telephonics for the quarter and three quarters ended October 3, 2022 and from the now closed Shanghai (SH E-MS) and Shenzhen (SZ) facilities previously utilized by the Company's former E-M Solutions business unit for the three quarters ended September 27, 2021.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000950170-22-023197:notes:45]
[same as prior period, unchanged from 0001564590-22-028936:notes:43]

[0000950170-22-023197:notes:46]
|  |  | As of |  |
|  |  | October 3, 2022 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 165,205 |  |  | $ | 114,653 |  |
| Work-in-process |  |  | 36,329 |  |  |  | 9,620 |  |
| Finished goods |  |  | 3,836 |  |  |  | 3,339 |  |
|  |  | $ | 205,370 |  |  | $ | 127,612 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Land and land use rights |  | $ | 62,896 |  |  | $ | 62,015 |  |
| Buildings and improvements |  |  | 482,873 |  |  |  | 429,344 |  |
| Machinery and equipment |  |  | 1,046,439 |  |  |  | 891,925 |  |
| Furniture and fixtures and other |  |  | 12,268 |  |  |  | 10,360 |  |
| Construction-in-progress |  |  | 33,120 |  |  |  | 25,554 |  |
|  |  |  | 1,637,596 |  |  |  | 1,419,198 |  |
| Less: Accumulated depreciation |  |  | (891,604 | ) |  |  | (753,443 | ) |
|  |  | $ | 745,992 |  |  | $ | 665,755 |  |
| Other current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | $ | 27,832 |  |  | $ | 7,162 |  |
| Sales return and allowances |  |  | 12,746 |  |  |  | 12,853 |  |
| Operating leases |  |  | 7,434 |  |  |  | 6,362 |  |
| Derivative liabilities |  |  | 4,951 |  |  |  | 4,295 |  |
| Interest |  |  | 1,792 |  |  |  | 8,741 |  |
| Finance leases |  |  | 718 |  |  |  | 698 |  |
| Other |  |  | 64,001 |  |  |  | 52,918 |  |
|  |  | $ | 119,474 |  |  | $ | 93,029 |  |
| Other long-term liabilities: |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 25,987 |  |  | $ | 28,361 |  |
| Customer deposits |  |  | 21,250 |  |  |  | — |  |
| Finance leases |  |  | 13,771 |  |  |  | 14,317 |  |
| Defined benefit pension plan liability |  |  | 4,481 |  |  |  | 5,276 |  |
| Other |  |  | 19,351 |  |  |  | 20,958 |  |
|  |  | $ | 84,840 |  |  | $ | 68,912 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-22-023197:notes:47]
[same as prior period, unchanged from 0001564590-22-028936:notes:45]

[0000950170-22-023197:notes:48]
As of October 3, 2022 and January 3, 2022, goodwill by reportable segment was as follows:

[0000950170-22-023197:notes:49]
|  |  | PCB |  | RF&S Components |  | Unallocated Telephonics Goodwill |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 3, 2022 |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 700,724 |  | $ | 177,200 |  | $ | — |  | $ | 877,924 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (69,200 | ) |  | — |  |  | (240,600 | ) |
|  |  |  | 529,324 |  |  | 108,000 |  |  | — |  |  | 637,324 |  |
| Goodwill recognized during the three quarters ended October 3, 2022 |  |  | — |  |  | — |  |  | 93,070 |  |  | 93,070 |  |
| Balance as of October 3, 2022 |  |  |  |  |  |  |  |  |  |
| Goodwill |  |  | 700,724 |  |  | 177,200 |  |  | 93,070 |  |  | 970,994 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (69,200 | ) |  | — |  |  | (240,600 | ) |
|  |  | $ | 529,324 |  | $ | 108,000 |  | $ | 93,070 |  | $ | 730,394 |  |

[0000950170-22-023197:notes:50]
[same as prior period, unchanged from 0001564590-22-028936:notes:48]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-22-023197:notes:51]
[same as prior period, unchanged from 0001564590-22-028936:notes:49]

[0000950170-22-023197:notes:52]
As of October 3, 2022 and January 3, 2022, the components of definite-lived intangibles were as follows:

[0000950170-22-023197:notes:53]
|  |  | GrossAmount |  |  | AccumulatedAmortization |  |  | NetCarryingAmount |  |  | WeightedAverageAmortizationPeriod |  |
|  |  | (In thousands) |  |  | (In years) |  |
| October 3, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 366,071 |  |  | $ | (179,285 | ) |  | $ | 186,786 |  |  |  | 11.3 |  |
| Technology |  |  | 47,650 |  |  |  | (23,492 | ) |  |  | 24,158 |  |  |  | 9.5 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 82,500 |  |  |  | (1,587 | ) |  |  | 80,913 |  |  |  | 13.0 |  |
| Trade names |  |  | 8,250 |  |  |  | (412 | ) |  |  | 7,838 |  |  |  | 5.0 |  |
|  |  | $ | 504,471 |  |  | $ | (204,776 | ) |  | $ | 299,695 |  |  |  |  |
| January 3, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 366,071 |  |  | $ | (154,461 | ) |  | $ | 211,610 |  |  |  | 11.3 |  |
| Technology |  |  | 47,650 |  |  |  | (19,342 | ) |  |  | 28,308 |  |  |  | 9.5 |  |
|  |  | $ | 413,721 |  |  | $ | (173,803 | ) |  | $ | 239,918 |  |  |  |  |

[0000950170-22-023197:notes:54]
The Company has acquired customer relationships and trade names as a result of the Telephonics acquisition. See Note 2, Acquisition of Gritel and ISC Farmingdale Corp., for further information.

[0000950170-22-023197:notes:55]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $11,657 and $9,658 for the quarters ended October 3, 2022 and September 27, 2021, respectively, and $30,973 and $30,988 for the three quarters ended October 3, 2022 and September 27, 2021, respectively. For the quarter and three quarters ended October 3, 2022, $1,384 and $4,151, respectively, of amortization expense is included in cost of goods sold. For the quarter and three quarters ended September 27, 2021, $1,384 and $4,151, respectively, of amortization expense is included in cost of goods sold.

[0000950170-22-023197:notes:56]
[same as prior period, unchanged from 0001564590-22-028936:notes:54]

[0000950170-22-023197:notes:57]
|  |  | (In thousands) |  |
| Remaining 2022 |  | $ | 11,657 |  |
| 2023 |  |  | 44,695 |  |
| 2024 |  |  | 37,513 |  |
| 2025 |  |  | 33,393 |  |
| 2026 |  |  | 33,393 |  |
| Thereafter |  |  | 139,044 |  |
|  |  | $ | 299,695 |  |


## us-gaap:LongTermDebtTextBlock

[0000950170-22-023197:notes:58]
(8) Long-term Debt and Letters of Credit

[0000950170-22-023197:notes:59]
The following table summarizes the long-term debt of the Company as of October 3, 2022 and January 3, 2022:

[0000950170-22-023197:notes:60]
|  |  | Interest Rate as ofOctober 3, 2022 |  |  |  | PrincipalOutstandingas ofOctober 3, 2022 |  |  | Interest Rate as ofJanuary 3, 2022 |  |  |  | PrincipalOutstandingas ofJanuary 3, 2022 |  |
|  |  | (In thousands, except interest rates) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % |  | $ | 500,000 |  |  |  | 4.00 |  | % |  | $ | 500,000 |  |
| Term Loan due September 2024 |  |  | 5.67 |  |  |  |  | 405,879 |  |  |  | 2.60 |  |  |  |  | 405,879 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 4.57 |  |  |  |  | 30,000 |  |  |  | 1.50 |  |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 935,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (448 | ) |  |  |  |  |  |  | (607 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (6,427 | ) |  |  |  |  |  |  | (7,454 | ) |
|  |  |  |  |  |  |  | 929,004 |  |  |  |  |  |  |  | 927,818 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 929,004 |  |  |  |  |  |  | $ | 927,818 |  |

[0000950170-22-023197:notes:61]
Debt Covenants

[0000950170-22-023197:notes:62]
Borrowings under the Senior Notes due 2029 and Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0000950170-22-023197:notes:63]
Under the occurrence of certain events, the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0000950170-22-023197:notes:64]
Debt Issuance and Debt Discount

[0000950170-22-023197:notes:65]
As of October 3, 2022 and January 3, 2022, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029 and Term Loan Facility are as follows:

[0000950170-22-023197:notes:66]
|  |  | As of October 3, 2022 |  |  | As of January 3, 2022 |
|  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  | DebtIssuance Costs |  |  | DebtDiscount |  |  | EffectiveInterest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 4,947 |  |  | $ | — |  |  |  | 4.18 |  | % | $ | 5,444 |  |  | $ | — |  |  |  | 4.18 |  | % |
| Term Loan due September 2024 |  |  | 1,480 |  |  |  | 448 |  |  |  | 4.66 |  |  |  | 2,010 |  |  |  | 607 |  |  |  | 4.66 |  |  |
|  |  | $ | 6,427 |  |  | $ | 448 |  |  |  |  |  | $ | 7,454 |  |  | $ | 607 |  |  |  |  |  |

[0000950170-22-023197:notes:67]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0000950170-22-023197:notes:68]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $933 and $1,355 as of October 3, 2022 and January 3, 2022, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0000950170-22-023197:notes:69]
As of October 3, 2022, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 4.8 years.

[0000950170-22-023197:notes:70]
Loss on Extinguishment of Debt

[0000950170-22-023197:notes:71]
During the three quarters ended September 27, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-22-023197:notes:72]
[same as prior period, unchanged from 0001564590-22-028936:notes:70]

[0000950170-22-023197:notes:73]
[same as prior period, unchanged from 0001564590-22-028936:notes:71]

[0000950170-22-023197:notes:74]
During the quarter and three quarters ended October 3, 2022, the Company’s effective tax rate was impacted by a net discrete benefit of $1,432 and $2,257, respectively. This is primarily related to the approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China and a windfall tax benefit of the stock-based compensation releases, which were partially offset by accrued interest expense on existing uncertain tax positions.

[0000950170-22-023197:notes:75]
[same as prior period, unchanged from 0001564590-22-028936:notes:73]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-22-023197:notes:76]
[same as prior period, unchanged from 0001564590-22-028936:notes:74]

[0000950170-22-023197:notes:77]
[same as prior period, unchanged from 0001564590-22-028936:notes:75]

[0000950170-22-023197:notes:78]
[same as prior period, unchanged from 0001564590-22-028936:notes:76]

[0000950170-22-023197:notes:79]
[same as prior period, unchanged from 0001564590-22-028936:notes:77]

[0000950170-22-023197:notes:80]
On May 15, 2018, the Company entered into a four-year pay-fixed, receive floating (1-month LIBOR), interest rate swap arrangement with a notional amount of $400,000 for the period beginning June 1, 2018 and ended on June 1, 2022 (the expiration date of the swap). During the term of the interest rate swap, the Company paid a fixed rate of 2.84% against a portion of its LIBOR-based debt and received floating 1-month LIBOR during the swap period.

[0000950170-22-023197:notes:81]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax, in the Company’s consolidated condensed balance sheets. No ineffectiveness was recognized for the quarter and three quarters ended October 3, 2022 and September 27, 2021. The interest rate swap increased interest expense by $0 and $4,105 for the quarter and three quarters ended October 3, 2022, respectively, and $2,775 and $8,278 for the quarter and three quarters ended September 27, 2021, respectively.

[0000950170-22-023197:notes:82]
[same as prior period, unchanged from 0001564590-22-028936:notes:80]

[0000950170-22-023197:notes:83]
The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts as of October 3, 2022 was approximately $1,625 (Euro (EUR) 1.4 million). There were no foreign exchange contracts as of January 3, 2022.

[0000950170-22-023197:notes:84]
[same as prior period, unchanged from 0001564590-22-028936:notes:82]

[0000950170-22-023197:notes:85]
The Company uses various raw materials in the manufacturing of PCBs. In particular, the Company has been experiencing volatility in prices and increasing lead times of copper clad laminates (CCLs), a key raw material for the manufacture of PCBs. CCLs are made from epoxy resin, glass cloth and copper foil, all of which are seeing limited supply and volatility in prices. The Company only buys a small amount of copper directly. However, copper is a major driver of laminate cost. As such, the Company enters into commodity contracts to hedge copper as a proxy for hedging laminate. As of October 3, 2022, the Company has commodity contracts with a notional quantity of 0.7 metric tonnes each for the periods: (i) beginning October 4, 2022 and ending on January 3, 2023, (ii) beginning January 1, 2023 and ending on March 31, 2023, (iii) beginning April 1, 2023 and ending on June 30, 2023, and (iv) beginning July 1, 2023 and ending on September 30, 2023. As of October 3, 2022, the fair value of the commodity contracts was recorded as a liability in the amount of $4,715 and included as a component of other current liabilities. The changes in the fair value of these commodity contracts are recorded in cost of goods sold in the consolidated condensed statements of operations. The commodity contracts increased cost of goods sold by $1,204 and $5,011 for the quarter and three quarters ended October 3, 2022, respectively. The commodity contracts increased cost of goods sold by $164 and $65 for the quarter and three quarters ended September 27, 2021, respectively. These commodity contracts are not designated as accounting hedges.

[0000950170-22-023197:notes:86]
[same as prior period, unchanged from 0001564590-22-028936:notes:85]

[0000950170-22-023197:notes:87]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | October 3, 2022 |  |  | January 3, 2022 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other current liabilities |  | $ | (236 | ) |  | $ | — |  |
| Interest rate swap |  | Other current liabilities |  |  | — |  |  |  | (4,295 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |
| Commodity contracts |  | Prepaid expenses and other current assets |  |  | — |  |  |  | 297 |  |
| Commodity contracts |  | Other current liabilities |  |  | (4,715 | ) |  |  | — |  |

[0000950170-22-023197:notes:88]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the quarter and three quarters ended October 3, 2022 and September 27, 2021:

[0000950170-22-023197:notes:89]
|  |  |  | Quarter Ended October 3, 2022 |  |  | Quarter Ended September 27, 2021 |  |  |
|  |  | FinancialStatement Caption | Loss Recognized in Other Comprehensive Loss |  |  | LossReclassifiedinto Income |  |  | Loss Recognizedin OtherComprehensive Loss |  |  | LossReclassifiedinto Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | — |  |  | $ | — |  |  | $ | (147 | ) |  | $ | (2,775 | ) |  |

[0000950170-22-023197:notes:90]
|  |  |  | Three Quarters Ended October 3, 2022 |  |  | Three Quarters Ended September 27, 2021 |  |  |
|  |  | FinancialStatement Caption | Gain Recognizedin OtherComprehensive Income |  |  | LossReclassifiedinto Income |  |  | Loss Recognizedin OtherComprehensive Loss |  |  | LossReclassifiedinto Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | 190 |  |  | $ | (4,105 | ) |  | $ | (682 | ) |  | $ | (8,278 | ) |  |

[0000950170-22-023197:notes:91]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the three quarters ended October 3, 2022 and September 27, 2021:

[0000950170-22-023197:notes:92]
|  |  | Three Quarters Ended |
|  |  | October 3, |  |  | September 27, |  |  |
|  |  | 2022 |  |  | 2021 |  |  |
|  |  | (In thousands) |
| Beginning balance, net of tax |  | $ | (3,223 | ) |  | $ | (11,231 | ) |  |
| Changes in fair value gain (loss), net of tax |  |  | 24 |  |  |  | (87 | ) |  |
| Reclassification to earnings |  |  | 3,092 |  |  |  | 5,875 |  |  |
| Ending balance, net of tax |  | $ | (107 | ) |  | $ | (5,443 | ) |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000950170-22-023197:notes:93]
[same as prior period, unchanged from 0001564590-22-028936:notes:92]

[0000950170-22-023197:notes:94]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of October 3, 2022 and January 3, 2022:

[0000950170-22-023197:notes:95]
|  |  | ForeignCurrencyTranslation |  |  | PensionObligation |  |  | (Losses) Gainson Cash FlowHedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of January 3, 2022 |  | $ | (23,899 | ) |  | $ | (133 | ) |  | $ | (3,223 | ) |  | $ | (27,255 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (2,350 | ) |  |  | — |  |  |  | 24 |  |  |  | (2,326 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | 3,092 |  |  |  | 3,092 |  |
| Other comprehensive (loss) income |  |  | (2,350 | ) |  |  | — |  |  |  | 3,116 |  |  |  | 766 |  |
| Ending balance as of October 3, 2022 |  | $ | (26,249 | ) |  | $ | (133 | ) |  | $ | (107 | ) |  | $ | (26,489 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-22-023197:notes:96]
[same as prior period, unchanged from 0001564590-22-028936:notes:95]

[0000950170-22-023197:notes:97]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs on-going credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk.

[0000950170-22-023197:notes:98]
[same as prior period, unchanged from 0001564590-22-028936:notes:97]

[0000950170-22-023197:notes:99]
There were no customers that accounted for 10% or more of net sales for either the quarter ended October 3, 2022 or September 27, 2021. For each of the three quarters ended October 3, 2022 and September 27, 2021, one customer accounted for approximately 10% of the Company’s net sales.


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-22-023197:notes:100]
[same as prior period, unchanged from 0001564590-22-028936:notes:99]

[0000950170-22-023197:notes:101]
[same as prior period, unchanged from 0001564590-22-028936:notes:100]

[0000950170-22-023197:notes:102]
The carrying amount and estimated fair value of the Company’s financial instruments as of October 3, 2022 and January 3, 2022 were as follows:

[0000950170-22-023197:notes:103]
|  |  | As of |  |  | As of |  |
|  |  | October 3, 2022 |  |  | January 3, 2022 |  |
|  |  | CarryingAmount |  |  | Fair Value |  |  | CarryingAmount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | — |  |  | $ | — |  |  | $ | 297 |  |  | $ | 297 |  |
| Derivative liabilities, current |  |  | 4,951 |  |  |  | 4,951 |  |  |  | 4,295 |  |  |  | 4,295 |  |
| Senior Notes due March 2029 |  |  | 495,053 |  |  |  | 400,120 |  |  |  | 494,556 |  |  |  | 498,200 |  |
| Term Loan due September 2024 |  |  | 403,951 |  |  |  | 403,091 |  |  |  | 403,262 |  |  |  | 406,135 |  |
| ABL Revolving Loans |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 30,000 |  |

[0000950170-22-023197:notes:104]
[same as prior period, unchanged from 0001564590-22-028936:notes:103]

[0000950170-22-023197:notes:105]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of October 3, 2022 and January 3, 2022, which are considered Level 2 inputs.

[0000950170-22-023197:notes:106]
As of October 3, 2022 and January 3, 2022, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, contract assets, accounts payable, and contract liabilities. The carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of October 3, 2022 consisted of $139,358 held in the U.S., with the remaining $196,267 held by foreign subsidiaries.

[0000950170-22-023197:notes:107]
[same as prior period, unchanged from 0001564590-22-028936:notes:106]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-22-023197:notes:108]
(14) Commitments and Contingencies

[0000950170-22-023197:notes:109]
Legal Matters

[0000950170-22-023197:notes:110]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of October 3, 2022 and January 3, 2022. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0000950170-22-023197:notes:111]
Offset Agreements

[0000950170-22-023197:notes:112]
Following the acquisition of Telephonics on June 27, 2022, the Company has and may continue to enter into industrial cooperation agreements, sometimes referred to as offset agreements, as a condition to obtaining orders for products and services from customers in foreign countries. These agreements are intended to promote investment in the applicable country, and the Company’s obligations under these agreements may be satisfied through activities that do not require the Company to use cash, including transferring technology or providing manufacturing and other consulting support. The obligations under these agreements may also be satisfied through the use of cash for activities such as purchasing supplies from in-country vendors, setting up support centers, research and development investments, acquisitions, and building or leasing facilities for in-country operations, if applicable. The amount of the offset requirement is determined by contract value awarded and negotiated percentages with customers. As of October 3, 2022, the Company had outstanding offset agreements of approximately $32,000, some of which extend through 2028. Offset programs usually extend over several years and in some cases provide for penalties in the event the Company fails to perform in accordance with contract requirements. Historically, the Company has not paid any such penalties, and as of October 3, 2022, no such penalties are estimable or probable.


## us-gaap:EarningsPerShareTextBlock

[0000950170-22-023197:notes:113]
[same as prior period, unchanged from 0001564590-22-028936:notes:110]

[0000950170-22-023197:notes:114]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the quarter and three quarters ended October 3, 2022 and September 27, 2021:

[0000950170-22-023197:notes:115]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | October 3, |  |  | September 27, |  |  | October 3, |  |  | September 27, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income |  | $ | 43,528 |  |  | $ | 20,958 |  |  | $ | 88,566 |  |  | $ | 46,027 |  |
| Basic weighted average shares |  |  | 102,196 |  |  |  | 107,098 |  |  |  | 102,016 |  |  |  | 106,917 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,524 |  |  |  | 1,247 |  |  |  | 1,720 |  |  |  | 1,655 |  |
| Dilutive effect of outstanding warrants |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 267 |  |
| Diluted shares |  |  | 103,720 |  |  |  | 108,345 |  |  |  | 103,738 |  |  |  | 108,839 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.43 |  |  | $ | 0.20 |  |  | $ | 0.87 |  |  | $ | 0.43 |  |
| Diluted |  | $ | 0.42 |  |  | $ | 0.19 |  |  | $ | 0.85 |  |  | $ | 0.42 |  |

[0000950170-22-023197:notes:116]
Performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock options to purchase 41 and 690 shares of common stock for the quarter and three quarters ended October 3, 2022, respectively, and 997 and 866 shares of common stock for the quarter and three quarters ended September 27, 2021, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met on October 3, 2022 and September 27, 2021, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common stock during the applicable quarter and three quarters and, as a result, the impact would be anti-dilutive.

[0000950170-22-023197:notes:117]
Outstanding warrants for the quarter ended September 27, 2021 to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock was greater than the average market price of common stock during the applicable quarter, and therefore, the effect would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-22-023197:notes:118]
[same as prior period, unchanged from 0001564590-22-028936:notes:114]

[0000950170-22-023197:notes:119]
[same as prior period, unchanged from 0001564590-22-028936:notes:115]

[0000950170-22-023197:notes:120]
|  |  | Quarter Ended |  | Three Quarters Ended |
|  |  | October 3, |  |  | September 27, |  |  |  | October 3, |  |  | September 27, |  |  |
|  |  | 2022 |  |  | 2021 |  |  |  | 2022 |  |  | 2021 |  |  |
|  |  | (In thousands) |
| Cost of goods sold |  | $ | 1,699 |  |  | $ | 1,284 |  |  |  | $ | 4,147 |  |  | $ | 3,310 |  |  |
| Selling and marketing |  |  | 762 |  |  |  | 731 |  |  |  |  | 2,032 |  |  |  | 1,819 |  |  |
| General and administrative |  |  | 2,685 |  |  |  | 2,542 |  |  |  |  | 7,134 |  |  |  | 6,912 |  |  |
| Research and development |  |  | 324 |  |  |  | 387 |  |  |  |  | 818 |  |  |  | 462 |  |  |
| Stock-based compensation expense recognized |  | $ | 5,470 |  |  | $ | 4,944 |  |  |  | $ | 14,131 |  |  | $ | 12,503 |  |  |

[0000950170-22-023197:notes:121]
[same as prior period, unchanged from 0001564590-22-028936:notes:117]

[0000950170-22-023197:notes:122]
The following is a summary of total unrecognized compensation costs as of October 3, 2022:

[0000950170-22-023197:notes:123]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted AverageRecognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 33,723 |  |  |  | 1.5 |  |
| PRU awards |  |  | 3,030 |  |  |  | 1.7 |  |
| Stock options |  |  | 2 |  |  |  | 0.0 |  |
|  |  | $ | 36,755 |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-22-023197:notes:124]
[same as prior period, unchanged from 0001564590-22-028936:notes:120]

[0000950170-22-023197:notes:125]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. On June 27, 2022, the Company completed its acquisition of Telephonics. As of October 3, 2022, the chief operating decision maker is still in the process of determining how to allocate resources and assess performance in relation to the acquisition of Telephonics.

[0000950170-22-023197:notes:126]
[same as prior period, unchanged from 0001564590-22-028936:notes:122]

[0000950170-22-023197:notes:127]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |  |
|  |  | October 3, 2022 |  |  | September 27, 2021 |  |  | October 3, 2022 |  |  | September 27, 2021 |  |  |
|  |  | (In thousands) |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 588,920 |  |  | $ | 541,118 |  |  | $ | 1,764,419 |  |  | $ | 1,605,084 |  |  |
| RF&S Components |  |  | 13,905 |  |  |  | 15,666 |  |  |  | 45,216 |  |  |  | 42,259 |  |  |
| Other (1) |  |  | 68,255 |  |  |  | — |  |  |  | 68,255 |  |  |  | 3,256 |  |  |
| Total net sales |  | $ | 671,080 |  |  | $ | 556,784 |  |  | $ | 1,877,890 |  |  | $ | 1,650,599 |  |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 82,770 |  |  | $ | 61,424 |  |  | $ | 231,218 |  |  | $ | 191,711 |  |  |
| RF&S Components |  |  | 5,984 |  |  |  | 6,537 |  |  |  | 18,412 |  |  |  | 15,129 |  |  |
| Corporate and Other (1) |  |  | (27,319 | ) |  |  | (26,068 | ) |  |  | (105,809 | ) |  |  | (82,929 | ) |  |
| Total operating segment income |  |  | 61,435 |  |  |  | 41,893 |  |  |  | 143,821 |  |  |  | 123,911 |  |  |
| Amortization of definite-lived intangibles (2) |  |  | (11,657 | ) |  |  | (9,658 | ) |  |  | (30,973 | ) |  |  | (30,988 | ) |  |
| Total operating income |  |  | 49,778 |  |  |  | 32,235 |  |  |  | 112,848 |  |  |  | 92,923 |  |  |
| Total other expense |  |  | (615 | ) |  |  | (8,622 | ) |  |  | (13,079 | ) |  |  | (43,494 | ) |  |
| Income before income taxes |  | $ | 49,163 |  |  | $ | 23,613 |  |  | $ | 99,769 |  |  | $ | 49,429 |  |  |

[0000950170-22-023197:notes:128]
|  |  | As of |  |
|  |  | October 3, 2022 |  |  | January 3, 2022 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |
| PCB |  | $ | 1,765,873 |  |  | $ | 1,655,401 |  |
| RF&S Components |  |  | 204,620 |  |  |  | 216,737 |  |
| Corporate and Other (1) |  |  | 1,322,397 |  |  |  | 1,153,409 |  |
| Total assets |  | $ | 3,292,890 |  |  | $ | 3,025,547 |  |

[0000950170-22-023197:notes:129]
(1)
Other represents results from Telephonics and the now closed SH E-MS and SZ facilities.

[0000950170-22-023197:notes:130]
(2)
Amortization of definite-lived intangibles primarily relates to the PCB and RF&S Components reportable segments. For the quarter and three quarters ended October 3, 2022, $1,384 and $4,151, respectively, of amortization expense is included in cost of goods sold. For the quarter and three quarters ended September 27, 2021, $1,384 and $4,151, respectively, of amortization expense is included in cost of goods sold.

[0000950170-22-023197:notes:131]
[same as prior period, unchanged from 0001564590-22-028936:notes:127]

[0000950170-22-023197:notes:132]
The Company markets and sells its products in approximately 60 countries. Other than in the United States and China, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales are as follows:

[0000950170-22-023197:notes:133]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |  |
|  |  | October 3, 2022 |  |  | September 27, 2021 |  |  | October 3, 2022 |  |  | September 27, 2021 |  |  |
|  |  | (In thousands) |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 343,696 |  |  | $ | 245,940 |  |  | $ | 882,577 |  |  | $ | 775,351 |  |  |
| China |  |  | 73,800 |  |  |  | 77,022 |  |  |  | 226,776 |  |  |  | 238,891 |  |  |
| Other |  |  | 253,584 |  |  |  | 233,822 |  |  |  | 768,537 |  |  |  | 636,357 |  |  |
| Total net sales |  | $ | 671,080 |  |  | $ | 556,784 |  |  | $ | 1,877,890 |  |  | $ | 1,650,599 |  |  |

[0000950170-22-023197:notes:134]
[same as prior period, unchanged from 0001564590-22-028936:notes:130]


## us-gaap:TreasuryStockTextBlock

[0000950170-22-023197:notes:135]
[same as prior period, unchanged from 0001564590-22-028936:notes:131]

[0000950170-22-023197:notes:136]
On February 3, 2021, the Company’s Board of Directors authorized and approved a share repurchase program. Under the program, the Company was authorized to repurchase up to $100,000 in value of the Company’s outstanding shares of common stock from time to time through February 3, 2023. The program permitted the Company to repurchase shares through open market purchases, privately-negotiated transactions, or otherwise in accordance with applicable federal securities laws, including Rule 10b-18 of the Securities Exchange Act of 1934, as amended (the Exchange Act) which sets certain restrictions on the method, timing, price, and volume of open market stock repurchases. In addition, the Company adopted a trading plan in accordance with Rule 10b5-1 of the Exchange Act to facilitate certain purchases effected under the share repurchase program. The timing, manner, price, and amount of any repurchases were determined at the Company’s discretion. The repurchase program did not obligate the Company to acquire any specific number of shares.

[0000950170-22-023197:notes:137]
During the quarter ended October 3, 2022, the Company did not make any share repurchases. During the three quarters ended October 3, 2022, the Company has repurchased a total of 2,747 shares of common stock for a total cost of $35,424 (including commissions). As of October 3, 2022, there are no amounts authorized for repurchase.
