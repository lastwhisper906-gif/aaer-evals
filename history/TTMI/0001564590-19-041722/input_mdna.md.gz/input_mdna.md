# TTMI MD&A — 0001564590-19-041722


## mdna

[0001564590-19-041722:mdna:1]
[same as prior period, unchanged from 0001564590-19-030026:mdna:1]

[0001564590-19-041722:mdna:2]
[same as prior period, unchanged from 0001564590-19-030026:mdna:2]

[0001564590-19-041722:mdna:3]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs, backplane assemblies and electro-mechanical solutions (E-M Solutions), as well as a global designer and manufacturer of radio-frequency (RF) and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering and manufacturing solution to our customers from engineering support to prototype development through final mass production. This one-stop design, engineering and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,700 customers in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-19-041722:mdna:4]
[same as prior period, unchanged from 0001564590-19-030026:mdna:4]

[0001564590-19-041722:mdna:5]
On July 18, 2019, we extended the maturity of our revolving loan credit facility (Chinese Revolver) with a lender in China to July 2020. Pursuant to the Chinese Revolver, the lender has made available to us approximately $28 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn down.

[0001564590-19-041722:mdna:6]
[same as prior period, unchanged from 0001564590-19-030026:mdna:7]

[0001564590-19-041722:mdna:7]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers accounted for 52% and 48% of our net sales for the quarter and three quarters ended September 30, 2019, respectively. Sales to our ten largest customers accounted for 49% and 45% of our net sales for the quarter and three quarters ended October 1, 2018, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-19-041722:mdna:8]
[same as prior period, unchanged from 0001564590-19-030026:mdna:9]

[0001564590-19-041722:mdna:9]
|  |  | Quarter Ended |  |  |  | Three Quarters Ended |  |  |
| End Markets (1) |  | September 30, 2019 |  |  |  | October 1, 2018 (3) |  |  |  | September 30, 2019 |  |  |  | October 1, 2018 (3) |  |  |
| Aerospace and Defense |  |  | 24 |  | % |  |  | 21 |  | % |  |  | 26 |  | % |  |  | 21 |  | % |
| Automotive |  |  | 17 |  |  |  |  | 15 |  |  |  |  | 17 |  |  |  |  | 18 |  |  |
| Cellular Phone (2) |  |  | 19 |  |  |  |  | 17 |  |  |  |  | 11 |  |  |  |  | 13 |  |  |
| Computing/Storage/Peripherals (2) |  |  | 12 |  |  |  |  | 14 |  |  |  |  | 13 |  |  |  |  | 14 |  |  |
| Medical/Industrial/Instrumentation |  |  | 13 |  |  |  |  | 14 |  |  |  |  | 15 |  |  |  |  | 15 |  |  |
| Networking/Communications |  |  | 13 |  |  |  |  | 17 |  |  |  |  | 16 |  |  |  |  | 17 |  |  |
| Other (2) |  |  | 2 |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  | 2 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-19-041722:mdna:10]
[same as prior period, unchanged from 0001564590-19-030026:mdna:11]

[0001564590-19-041722:mdna:11]
[same as prior period, unchanged from 0001564590-19-030026:mdna:12]

[0001564590-19-041722:mdna:12]
| (3) | The quarter and three quarters ended October 1, 2018 were amended for the Anaren integration, as the acquisition occurred on April 18, 2018. |

[0001564590-19-041722:mdna:13]
26

[0001564590-19-041722:mdna:14]
We derive revenues primarily from the sale of PCBs, custom electronic assemblies using customer-supplied engineering and design plans as well as our long-term contracts related to the design and manufacture of RF and microwave components, assemblies and subsystems. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous control of the work in progress and finished goods throughout the PCB and custom electronic assemblies manufacturing process, as these are built to customer specifications with no alternative use, and there is an enforceable right of payment for work performed to date. As a result, beginning in the first quarter of 2018, we began recognizing revenue progressively over time based on the extent of progress towards completion of the performance obligation. We recognize revenue based on the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

[0001564590-19-041722:mdna:15]
[same as prior period, unchanged from 0001564590-19-030026:mdna:16]

[0001564590-19-041722:mdna:16]
[same as prior period, unchanged from 0001564590-19-030026:mdna:17]

[0001564590-19-041722:mdna:17]
[same as prior period, unchanged from 0001564590-19-030026:mdna:18]

[0001564590-19-041722:mdna:18]
[same as prior period, unchanged from 0001564590-19-030026:mdna:19]

[0001564590-19-041722:mdna:19]
[same as prior period, unchanged from 0001564590-19-030026:mdna:20]

[0001564590-19-041722:mdna:20]
[same as prior period, unchanged from 0001564590-19-030026:mdna:21]

[0001564590-19-041722:mdna:21]
[same as prior period, unchanged from 0001564590-19-030026:mdna:22]

[0001564590-19-041722:mdna:22]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended December 31, 2018 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since December 31, 2018, except for the estimates used in the quantitative goodwill impairment analysis performed as of September 30, 2019.

[0001564590-19-041722:mdna:23]
During the third fiscal quarter, our Communications and Computing and Automotive and Medical/Industrial/Instrumentation reporting units had lower than anticipated results and continued declines in sales. We considered these factors to be indicators of potential impairment requiring us to test the related goodwill for impairment of $39.3 million for Communications and Computing reporting unit and $185.5 million for Automotive and Medical/Industrial/Instrumentation reporting unit. As of September 30, 2019, we completed a quantitative goodwill impairment analysis related to our Communications and Computing and Automotive and Medical/Industrial/Instrumentation reporting units by comparing the fair value of the reporting unit with its carrying amount. We determined the fair value of the reporting units by using discounted cash flow (DCF) and market analyses. Under the market approach, we used revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting units.

[0001564590-19-041722:mdna:24]
Fair value is typically estimated using a DCF analysis which requires us to estimate the future cash flows as well as to select a risk-adjusted discount rate to measure the present value of the anticipated cash flows. When determining future cash flow estimates, we consider historical results adjusted to reflect current and anticipated future operating conditions. We estimate cash flows for a reporting unit over a discrete period and a terminal period (considering expected long-term growth rates and trends).

[0001564590-19-041722:mdna:25]
Based on our analysis, we estimate that the fair value of the Communications and Computing and Automotive and Medical/Industrial/Instrumentation reporting units exceeded its respective carrying value by 19% and 8%, respectively. If our future

[0001564590-19-041722:mdna:26]
cash flow projections and other fair value assumptions for our reporting unit change, we may be subject to potential impairment in subsequent quarters. Estimating the fair value of the reporting unit requires us to make assumptions and estimates in such areas as future economic conditions, industry-specific conditions, product pricing, and necessary capital expenditures. The use of different assumptions or estimates for future cash flows, discount rates, or terminal growth rates could produce substantially different estimates of the fair value of the reporting unit.

[0001564590-19-041722:mdna:27]
[same as prior period, unchanged from 0001564590-19-030026:mdna:24]

[0001564590-19-041722:mdna:28]
[same as prior period, unchanged from 0001564590-19-030026:mdna:25]

[0001564590-19-041722:mdna:29]
|  |  | Quarter Ended |  |  |  | Three Quarters Ended |  |  |
|  |  | September 30, 2019 |  |  |  | October 1, 2018 |  |  |  | September 30, 2019 |  |  |  | October 1, 2018 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 85.5 |  |  |  |  | 82.9 |  |  |  |  | 85.9 |  |  |  |  | 84.3 |  |  |
| Gross profit |  |  | 14.5 |  |  |  |  | 17.1 |  |  |  |  | 14.1 |  |  |  |  | 15.7 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.6 |  |  |  |  | 2.5 |  |  |  |  | 2.8 |  |  |  |  | 2.6 |  |  |
| General and administrative |  |  | 5.4 |  |  |  |  | 5.3 |  |  |  |  | 5.7 |  |  |  |  | 5.7 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.4 |  |  |  |  | 2.2 |  |  |  |  | 2.0 |  |  |  |  | 2.0 |  |  |
| Total operating expenses |  |  | 9.4 |  |  |  |  | 10.0 |  |  |  |  | 10.5 |  |  |  |  | 10.3 |  |  |
| Operating income |  |  | 5.1 |  |  |  |  | 7.1 |  |  |  |  | 3.6 |  |  |  |  | 5.4 |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.9 | ) |  |  |  | (2.9 | ) |  |  |  | (3.2 | ) |  |  |  | (2.6 | ) |  |
| Other, net |  |  | 1.1 |  |  |  |  | 0.3 |  |  |  |  | 0.6 |  |  |  |  | 0.3 |  |  |
| Total other expense, net |  |  | (1.8 | ) |  |  |  | (2.6 | ) |  |  |  | (2.6 | ) |  |  |  | (2.3 | ) |  |
| Income before income taxes |  |  | 3.3 |  |  |  |  | 4.5 |  |  |  |  | 1.0 |  |  |  |  | 3.1 |  |  |
| Income tax (provision) benefit |  |  | (1.1 | ) |  |  |  | (0.9 | ) |  |  |  | (0.2 | ) |  |  |  | 2.6 |  |  |
| Net income |  |  | 2.2 |  | % |  |  | 3.6 |  | % |  |  | 0.8 |  | % |  |  | 5.7 |  | % |

[0001564590-19-041722:mdna:30]
[same as prior period, unchanged from 0001564590-19-030026:mdna:27]

[0001564590-19-041722:mdna:31]
[same as prior period, unchanged from 0001564590-19-030026:mdna:28]

[0001564590-19-041722:mdna:32]
Total net sales decreased $39.0 million, or 5.2%, to $716.8 million for the third quarter of 2019 from $755.8 million for the third quarter of 2018. This decrease primarily resulted from a reduction in net sales for the PCB reportable segment of $47.3 million, or 6.8%, to $649.1 million for the third quarter of 2019 from $696.4 million for the third quarter of 2018. The reduction in PCB net sales was primarily due to lower demand in our Networking/Communications, Computing/Storage/Peripherals, and Automotive end markets. These changes resulted in an average PCB selling price increase of 5.6%, driven mainly by product mix shift and a 13.6% decrease in the volume of PCB shipments as compared to the third quarter of 2018. The reduction in net sales for the PCB reportable segment was partially offset by an increase in net sales for the E-M Solutions reportable segment of $8.2 million, or 13.8%, to $67.7 million for the third quarter of 2019 from $59.5 million for the third quarter of 2018. The increase was primarily due to higher demand in our Automotive end market partially offset by lower demand in our Networking/Communications end market.

[0001564590-19-041722:mdna:33]
Total net sales decreased $166.2 million, or 7.8%, to $1,970.1 million for the first three quarters of 2019 from $2,136.3 million for the first three quarters of 2018. This decrease resulted from a reduction in net sales for the PCB reportable segment of $176.8 million, or 9.0% to $1,791.0 million for the first three quarters of 2019 from $1,967.8 million for the first three quarters of 2018. The reduction in PCB net sales was primarily due to lower demand in our commercial (non-Aerospace and Defense related) end markets, partially offset by an increase in demand in our Aerospace and Defense end market, which was primarily the result of the impact in the first three quarters of 2019 of our acquisition of Anaren (which occurred on April 18, 2018) and higher demand at our other Aerospace and Defense focused facilities. These changes resulted in an average PCB selling price increase of 10.4%, driven mainly by product mix shift and a 19.2% decrease in the volume of PCB shipments as compared to the first three quarters of 2018. The reduction in net sales for the PCB reportable segment was partially offset by an increase in net sales for the E-M Solutions reportable segment of $10.5 million, or 6.2%, to $179.0 million for the first three quarters of 2019 from $168.5 million for the first three quarters of 2018. The increase was primarily due to higher demand in our Automotive end market.

[0001564590-19-041722:mdna:34]
[same as prior period, unchanged from 0001564590-19-030026:mdna:31]

[0001564590-19-041722:mdna:35]
Overall gross margin decreased to 14.5% for the third quarter of 2019 from 17.1% for the third quarter of 2018. Gross margin for the PCB reportable segment decreased to 15.8% for the third quarter of 2019 from 18.6% for the third quarter of 2018, primarily due to lower volumes in our commercially focused facilities. Gross margin for the E-M Solutions reportable segment decreased to 7.9% for the third quarter of 2019 from 8.0% for the third quarter of 2018.

[0001564590-19-041722:mdna:36]
Overall gross margin decreased to 14.1% for the first three quarters of 2019 from 15.7% for the first three quarters of 2018. Gross margin for the PCB reportable segment decreased to 15.3% for the first three quarters of 2019 from 16.8% for the first three quarters of 2018, primarily due to lower volumes in our commercially focused facilities partially offset by the impact in the first three quarters of 2019 of our acquisition of Anaren and higher production levels at our Aerospace and Defense focused facilities. Gross margin for the E-M Solutions reportable segment decreased to 7.2% for the first three quarters of 2019 from 7.3% for the first three quarters of 2018.

[0001564590-19-041722:mdna:37]
Capacity utilization is a key driver for us, which is measured by the actual production as a percentage of maximum capacity. This measure is particularly important in our high volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the third quarter of 2019 in our Asia and North America PCB facilities was 71% and 57%, respectively, compared to 80% and 60%, respectively, for the third quarter of 2018. Capacity utilization for the first three quarters of 2019 in our Asia and North America PCB facilities was 61% and 59%, respectively, compared to 76% and 61%, respectively, in the first three quarters of 2018. The decline in capacity utilization in our Asia and North America PCB facilities was due to a decrease in sales in our commercial end markets.

[0001564590-19-041722:mdna:38]
[same as prior period, unchanged from 0001564590-19-030026:mdna:35]

[0001564590-19-041722:mdna:39]
Selling and marketing expenses decreased $0.1 million, to $18.4 million for the third quarter of 2019 from $18.5 million for the third quarter of 2018. As a percentage of net sales, selling and marketing expenses was 2.6% for the third quarter of 2019, as compared to 2.5% for the third quarter of 2018. The decrease in selling and marketing expense for the quarter ended September 30, 2019 primarily relates to reduced commission expense.

[0001564590-19-041722:mdna:40]
Selling and marketing expenses increased $0.4 million, to $55.2 million for the first three quarters of 2019 from $54.8 million for the first three quarters of 2018. As a percentage of net sales, selling and marketing expenses was 2.8% for the first three quarters of 2019, as compared to 2.6% for the first three quarters of 2018. The increase in selling and marketing expense for the three quarters ended September 30, 2019 primarily relates to expenses incurred by Anaren post acquisition partially offset by reduced commission expense.

[0001564590-19-041722:mdna:41]
[same as prior period, unchanged from 0001564590-19-030026:mdna:38]

[0001564590-19-041722:mdna:42]
General and administrative expenses decreased $1.0 million to $38.9 million, or 5.4% of net sales, for the third quarter of 2019 from $39.9 million, or 5.3% of net sales, for the third quarter of 2018. The decrease in general and administrative expenses for the quarter ended September 30, 2019 was primarily due to the decrease in incentive compensation and stock-based compensation expense partially offset by higher acquisition/integration costs.

[0001564590-19-041722:mdna:43]
General and administrative expenses decreased $8.4 million to $113.0 million, or 5.7% of net sales, for the first three quarters of 2019 from $121.4 million, or 5.7% of net sales, for the first three quarters of 2018. The decrease in general and administrative expenses for the three quarters ended September 30, 2019 was primarily due to the decrease in acquisition-related costs of $8.6 million associated with the acquisition of Anaren on April 18, 2018 and a decrease in incentive compensation expense of $4.0 million partially offset by $6.4 million for the additional three and a half months of general and administrative expense incurred by Anaren in 2019 (which occurred on April 18, 2018) and higher restructuring charges.

[0001564590-19-041722:mdna:44]
[same as prior period, unchanged from 0001564590-19-030026:mdna:41]

[0001564590-19-041722:mdna:45]
Other expense, net decreased $7.6 million to $12.4 million for the third quarter of 2019 from $20.0 million for the third quarter of 2018. The decrease in other expense, net for the quarter ended September 30, 2019 was primarily the result of higher foreign currency gains due to the depreciation of the Chinese Renminbi (RMB) in the third quarter of 2019 compared to the third quarter of 2018. We utilize the RMB at our China facilities for employee-related expenses, RMB denominated purchases, and other costs of running our operations in China.

[0001564590-19-041722:mdna:46]
Other expense, net increased $1.8 million to $50.9 million for the first three quarters of 2019 from $49.1 million for the first three quarters of 2018. The increase in other expense, net for the three quarters ended September 30, 2019 was primarily due to the increase in interest expense of $6.7 million mainly related to the $600.0 million incremental debt incurred in conjunction with the Anaren acquisition partially offset by an increase in other income related to the sale of other assets of $3.6 million and an increase in government subsidies of $1.6 million.

[0001564590-19-041722:mdna:47]
[same as prior period, unchanged from 0001564590-19-030026:mdna:44]

[0001564590-19-041722:mdna:48]
The provision for income taxes increased by $0.5 million to $8.0 million of tax expense for the third quarter of 2019 from $7.5 million of tax provision for the third quarter of 2018. The provision for income taxes increased by $57.7 million to $3.7 million of tax expense for the first three quarters of 2019 from $54.0 million of tax benefit for the first three quarters of 2018. The increase in income tax expense for the first three quarters of 2019 was primarily due to the absence of a $74.6 million release of a portion of the Company’s valuation allowance against its U.S. federal and state net deferred tax assets which occurred in the second quarter of 2018, partially offset by tax benefits resulting from the decreased income before income taxes for the three quarters ended September 30, 2019 and a reduction of discrete tax expense recorded for the first three quarters of 2019 compared to the amount recorded in the first three quarters of 2018.

[0001564590-19-041722:mdna:49]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of credits and deductions available to us, as well as changes in valuation allowances and certain non-deductible items.

[0001564590-19-041722:mdna:50]
[same as prior period, unchanged from 0001564590-19-030026:mdna:48]

[0001564590-19-041722:mdna:51]
Our principal sources of liquidity have been cash provided by operations, the issuance of Convertible Senior Notes, Term Loan, Senior Notes, and borrowings under our Revolving Credit Facility. Our principal uses of cash have been to finance capital expenditures, finance acquisitions, meet debt service requirements, fund working capital requirements, and pay down existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001564590-19-041722:mdna:52]
Cash flow provided by operating activities during the first three quarters of 2019 was $181.8 million as compared to $121.4 million in the same period in 2018. The increase in cash flow was primarily due to lower investment in working capital during the first three quarters of 2019.

[0001564590-19-041722:mdna:53]
Net cash used in investing activities was approximately $89.0 million for the first three quarters of 2019, reflecting $95.4 million used for purchases of property, plant and equipment and other assets, less proceeds from the sale of property, plant and equipment and other assets of $6.4 million. Net cash used in investing activities was approximately $712.5 million for the first three quarters of 2018, reflecting $596.4 million for the acquisition of Anaren, net of debt assumed, and $116.1 million for net purchases of property, plant and equipment.

[0001564590-19-041722:mdna:54]
Net cash used in financing activities was approximately $31.6 million for the first three quarters of 2019, reflecting repayment of long-term debt of $30.0 million and payment of debt issuance costs of $1.6 million. Net cash provided by financing activities was approximately $391.1 million for the first three quarters of 2018, primarily reflecting proceeds of $623.0 million from the incremental term and revolving loan borrowings incurred in conjunction with our acquisition of Anaren, offset by the repayment of assumed long-term debt related to the acquisition of Anaren of $178.6 million, repayment of long-term debt of $44.4 million, and payment of debt issuance costs and original issue discount of $9.2 million associated with the incremental term loans.

[0001564590-19-041722:mdna:55]
As of September 30, 2019, we had cash and cash equivalents of approximately $316.6 million, of which approximately $250.7 million was held by our foreign subsidiaries, primarily in China.

[0001564590-19-041722:mdna:56]
Our 2019 net capital expenditures and asset acquisitions are expected to be in the range of $140.0 million to $150.0 million.

[0001564590-19-041722:mdna:57]
[same as prior period, unchanged from 0001564590-19-030026:mdna:55]

[0001564590-19-041722:mdna:58]
As of September 30, 2019, we had $1,472.6 million of outstanding debt, net of discount and debt issuance costs, composed of $796.8 million of Term Loan due September 2024, $369.5 million of Senior Notes due October 2025, $236.3 million of Convertible Senior Notes due December 2020, $40.0 million under the U.S. ABL, and $30.0 million under the Asia ABL.

[0001564590-19-041722:mdna:59]
Borrowings under the Term Loan Facility and Senior Notes Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. As of September 30, 2019, we were in compliance with the covenants under the Term Loan Facility, Senior Notes Facility and ABL Revolving Loans.

[0001564590-19-041722:mdna:60]
Additional information regarding our indebtedness, including information about availability under our credit facilities, interest rates and other key terms of our outstanding indebtedness, is included in Part I, Item 1, Note 8, Long-term Debt and Letters of Credit, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q.

[0001564590-19-041722:mdna:61]
[same as prior period, unchanged from 0001564590-19-030026:mdna:75]

[0001564590-19-041722:mdna:62]
[same as prior period, unchanged from 0001564590-19-030026:mdna:76]

[0001564590-19-041722:mdna:63]
[same as prior period, unchanged from 0001564590-19-030026:mdna:77]

[0001564590-19-041722:mdna:64]
[same as prior period, unchanged from 0001564590-19-030026:mdna:78]

[0001564590-19-041722:mdna:65]
[same as prior period, unchanged from 0001564590-19-030026:mdna:79]

[0001564590-19-041722:mdna:66]
[same as prior period, unchanged from 0001564590-19-030026:mdna:80]
