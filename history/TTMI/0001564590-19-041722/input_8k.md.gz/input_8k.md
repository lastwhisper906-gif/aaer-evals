# TTMI 8-K — 0001193125-19-278973 filed 2019-10-30

## item codes, every 8-K on or before 2019-11-07

- 2019-10-30 0001193125-19-278973 — 2.02, 9.01
- 2019-08-19 0001193125-19-224091 — 5.02, 9.01
- 2019-07-31 0001193125-19-208689 — 2.02, 9.01
- 2019-07-24 0001193125-19-201401 — 1.01, 2.03
- 2019-06-13 0001193125-19-171943 — 7.01, 9.01
- 2019-06-06 0001193125-19-167332 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2019-05-09 0001193125-19-143113 — 5.07
- 2019-05-01 0001193125-19-132977 — 2.02, 9.01
- 2019-02-06 0001193125-19-029540 — 2.02, 9.01
- 2019-01-15 0001193125-19-009142 — 2.02, 9.01
- 2018-10-30 0001193125-18-312212 — 2.02, 9.01
- 2018-10-22 0001193125-18-303926 — 5.02
- 2018-09-06 0001193125-18-268231 — 5.02, 9.01
- 2018-08-01 0001193125-18-234997 — 2.02, 9.01
- 2018-06-29 0001193125-18-209635 — 9.01 — amendment of 0001193125-18-120583
- 2018-05-29 0001193125-18-176976 — 7.01, 9.01
- 2018-05-10 0001193125-18-159394 — 5.07
- 2018-05-09 0001193125-18-157596 — 5.02
- 2018-05-02 0001193125-18-148650 — 2.02, 9.01
- 2018-04-18 0001193125-18-120583 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2018-02-21 0001193125-18-052169 — 8.01, 9.01
- 2018-02-20 0001193125-18-050385 — 5.02, 9.01
- 2018-02-09 0001193125-18-036966 — 7.01, 9.01
- 2018-02-07 0001193125-18-034744 — 2.02, 9.01
- 2017-12-14 0001193125-17-369625 — 1.01, 2.03, 9.01
- 2017-12-04 0001193125-17-359439 — 1.01, 7.01, 9.01
- 2017-11-01 0001193125-17-329425 — 2.02, 9.01
- 2017-09-29 0001193125-17-298999 — 1.01, 2.03, 3.03, 7.01, 9.01
- 2017-09-15 0001193125-17-286491 — 7.01, 9.01
- 2017-09-11 0001193125-17-281193 — 7.01, 9.01
- 2017-09-06 0001193125-17-277536 — 7.01, 9.01
- 2017-08-02 0001193125-17-245823 — 2.02, 9.01
- 2017-05-18 0001193125-17-173896 — 5.02, 5.07
- 2017-05-08 0001193125-17-162548 — 2.02, 9.01
- 2017-03-01 0001193125-17-063931 — 1.01, 1.02, 5.02
- 2017-02-08 0001193125-17-034652 — 2.02, 9.01
- 2016-11-18 0001193125-16-772305 — 8.01, 9.01
- 2016-10-26 0001193125-16-747948 — 2.02, 9.01
- 2016-10-20 0001193125-16-742905 — 5.02
- 2016-10-05 0001193125-16-731552 — 5.02, 9.01
- 2016-09-27 0001193125-16-720828 — 1.01, 2.03, 7.01, 9.01
- 2016-07-27 0001193125-16-659983 — 2.02, 9.01
- 2016-05-23 0001193125-16-599342 — 7.01, 9.01
- 2016-05-18 0001193125-16-594656 — 5.02, 5.03, 5.07, 9.01
- 2016-04-27 0001171843-16-009432 — 2.02, 9.01
- 2016-03-08 0001193125-16-495457 — 5.03, 7.01, 9.01
- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2019-11-07

- none on or before 2019-11-07

## item 2.02 — earnings release, exhibit 99.1

[0001193125-19-278973:8k_2_02:1]
EX-99.1
2
d785362dex991.htm
EX-99.1

[0001193125-19-278973:8k_2_02:2]
EX-99.1

[0001193125-19-278973:8k_2_02:3]
Exhibit 99.1

[0001193125-19-278973:8k_2_02:4]
| TTM Technologies, Inc., Q3’19 |  |  |  | Contact: Sameer Desai, Senior Director, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-19-278973:8k_2_02:5]
TTM Technologies, Inc. Reports Fiscal Third Quarter 2019 Results

[0001193125-19-278973:8k_2_02:6]
Santa Ana, CA – October 30, 2019 – TTM Technologies, Inc. (NASDAQ:TTMI), a leading global printed circuit board (“PCB”) and radio
frequency (“RF”) components manufacturer, today reported results for the third quarter of fiscal 2019, which ended on September 30, 2019.

[0001193125-19-278973:8k_2_02:7]
Third Quarter 2019 Highlights

[0001193125-19-278973:8k_2_02:8]
|  | • |  | Net sales were $716.8 million |

[0001193125-19-278973:8k_2_02:9]
|  | • |  | GAAP net income was $15.9 million, or $0.14 per diluted share |

[0001193125-19-278973:8k_2_02:10]
|  | • |  | Non-GAAP net income was $38.9 million, or $0.37 per diluted share |

[0001193125-19-278973:8k_2_02:11]
|  | • |  | Cash flow from operations of $58.7 million |

[0001193125-19-278973:8k_2_02:12]
Third Quarter 2019 Financial Results

[0001193125-19-278973:8k_2_02:13]
Net sales for the
third quarter of 2019 were $716.8 million, compared to $755.8 million in the third quarter of 2018 and $633.0 million in the second quarter of 2019.

[0001193125-19-278973:8k_2_02:14]
GAAP operating income for the third quarter of 2019 was $36.4 million, compared to $54.6 million in the third quarter of 2018 and
$16.8 million in the second quarter of 2019.

[0001193125-19-278973:8k_2_02:15]
GAAP net income for the third quarter of 2019 was $15.9 million, or $0.14 per
diluted share. This compares to income of $27.0 million, or $0.22 per diluted share in the third quarter of 2018, and $3.4 million, or $0.03 per diluted share, in the second quarter of 2019.

[0001193125-19-278973:8k_2_02:16]
On a non-GAAP basis, net income for the third quarter of 2019 was $38.9 million, or $0.37 per diluted share, inclusive of $0.05 of foreign
exchange gains. This compares to non-GAAP net income of $55.1 million, or $0.50 per diluted share, for the third quarter of 2018 and $21.3 million, or $0.20 per diluted share, in the second quarter of 2019.

[0001193125-19-278973:8k_2_02:17]
Adjusted EBITDA for the third quarter of 2019 was $103.5 million, or 14.4 percent of net sales, compared to adjusted EBITDA of
$122.3 million, or 16.2 percent of net sales, for the third quarter of 2018 and $82.9 million, or 13.1 percent of net sales, for the second quarter of 2019.

[0001193125-19-278973:8k_2_02:18]
“For the third quarter, TTM continued to generate solid cash flow and delivered revenue and earnings within the previously guided range,” said Tom
Edman, CEO of TTM. “The year over year growth we experienced in the aerospace and defense and cellular end markets partially offset weakness in our other commercial end markets.”

[0001193125-19-278973:8k_2_02:19]
Business Outlook

[0001193125-19-278973:8k_2_02:20]
For the fourth quarter of 2019 TTM
estimates that revenue will be in the range of $640 million to $680 million, and non-GAAP net income will be in the range of $0.25 to $0.31 per diluted share.

[0001193125-19-278973:8k_2_02:21]
“Significant year on year declines from the automotive and networking and communications end markets are a major contributor to lower revenues in the
fourth quarter. Consequently, we are exercising discipline in managing our costs and focusing on continued cash flow generation. Longer term, we are confident in our diversification and differentiation strategy and will benefit from secular growth
drivers such as 5G wireless technology, increasing automotive electronic content, and ongoing demand strength in aerospace and defense electronics,” concluded Mr. Edman.

[0001193125-19-278973:8k_2_02:22]
| TTM Technologies, Inc., Q3’19 |  |  |  | Contact: Sameer Desai, Senior Director, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-19-278973:8k_2_02:23]
To Access the Live Webcast/Conference Call

[0001193125-19-278973:8k_2_02:24]
TTM will host a conference call and webcast to discuss third quarter 2019 results and the fourth quarter 2019 outlook on Wednesday, October 30,
2019, at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time). The conference call will include forward-looking statements.

[0001193125-19-278973:8k_2_02:25]
Telephone access is available by
dialing domestic 800-367-2403 or international 334-777-6978 (ID 1206370). The conference call also will be webcast on TTM’s website at www.ttm.com.

[0001193125-19-278973:8k_2_02:26]
To Access a Replay of the Webcast

[0001193125-19-278973:8k_2_02:27]
The replay of the
webcast will remain accessible for one week following the live event on TTM’s website at www.ttm.com.

[0001193125-19-278973:8k_2_02:28]
About TTM

[0001193125-19-278973:8k_2_02:29]
TTM Technologies, Inc. is a leading global printed circuit board manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs,
backplane assemblies and electro-mechanical solutions as well as a global designer and manufacturer of RF and microwave components and assemblies. TTM stands for time-to-market, representing how TTM’s time-critical, one-stop manufacturing
services enable customers to shorten the time required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001193125-19-278973:8k_2_02:30]
Forward-Looking Statements

[0001193125-19-278973:8k_2_02:31]
This release contains
forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These statements reflect TTM’s current expectations, and
TTM does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other TTM statements will not be realized. Further, these
statements involve risks and uncertainties, many of which are beyond TTM’s control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to,
general market and economic conditions, including interest rates, currency exchange rates and consumer spending, demand for TTM’s products, market pressures on prices of TTM’s products, warranty claims, changes in product mix, contemplated
significant capital expenditures and related financing requirements, TTM’s dependence upon a small number of customers and other factors set forth in the “Risk Factors” and “Management’s Discussion and Analysis of Financial
Condition and Results of Operations” sections of the Company’s public reports filed with the SEC.

[0001193125-19-278973:8k_2_02:32]
About Our
Non-GAAP Financial Measures

[0001193125-19-278973:8k_2_02:33]
This release includes information about TTM’s adjusted EBITDA, non-GAAP net
income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing
financial performance.

[0001193125-19-278973:8k_2_02:34]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no standardized
measurement prescribed by GAAP and may not be comparable to similar non-GAAP financial measures used by other companies. TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliation to the
most directly comparable GAAP financial measure. However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001193125-19-278973:8k_2_02:35]
With respect to the Company’s outlook for non-GAAP net income per diluted share, we are unable to predict with reasonable certainty or without
unreasonable effort certain items that may affect a

[0001193125-19-278973:8k_2_02:36]
| TTM Technologies, Inc., Q3’19 |  |  |  | Contact: Sameer Desai, Senior Director, Corporate Development & Investor Relations Sameer.desai@ttmtech.com 714-327-3050 |

[0001193125-19-278973:8k_2_02:37]
comparable measure calculated and presented in accordance with GAAP. Our expected non-GAAP net income per diluted share excludes primarily the future impact of restructuring actions, impairment
charges, unusual gains and losses, and tax adjustments. These reconciling items are highly variable and difficult to predict due to various factors outside of management’s control and could have a material impact on our future period net income
per diluted share calculated and presented in accordance with GAAP. Accordingly, a reconciliation of non-GAAP net income per diluted share to a comparable measure calculated and presented in accordance with GAAP is not available without unreasonable
effort and has not been provided.

[0001193125-19-278973:8k_2_02:38]
- Tables Follow -

[0001193125-19-278973:8k_2_02:39]
TTM TECHNOLOGIES, INC.

[0001193125-19-278973:8k_2_02:40]
Selected Unaudited Financial Information

[0001193125-19-278973:8k_2_02:41]
(In thousands, except per share data)

[0001193125-19-278973:8k_2_02:42]
|  |  | Third Quarter |  |  | Second Quarter |  |  | First Three Quarters |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2019 |  |  | 2018 |  |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 716,817 |  |  | $ | 755,837 |  |  | $ | 633,038 |  |  | $ | 1,970,055 |  |  | $ | 2,136,306 |  |
| Cost of goods sold |  |  | 612,983 |  |  |  | 626,253 |  |  |  | 548,423 |  |  |  | 1,692,921 |  |  |  | 1,801,904 |  |
| Gross profit |  |  | 103,834 |  |  |  | 129,584 |  |  |  | 84,615 |  |  |  | 277,134 |  |  |  | 334,402 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 18,400 |  |  |  | 18,533 |  |  |  | 17,867 |  |  |  | 55,168 |  |  |  | 54,780 |  |
| General and administrative |  |  | 38,845 |  |  |  | 39,974 |  |  |  | 34,693 |  |  |  | 108,561 |  |  |  | 119,822 |  |
| Amortization of definite-lived intangibles |  |  | 10,175 |  |  |  | 16,609 |  |  |  | 11,267 |  |  |  | 38,268 |  |  |  | 41,959 |  |
| Restructuring charges |  |  | 53 |  |  |  | (82 | ) |  |  | 3,944 |  |  |  | 4,442 |  |  |  | 1,556 |  |
| Total operating expenses |  |  | 67,473 |  |  |  | 75,034 |  |  |  | 67,771 |  |  |  | 206,439 |  |  |  | 218,117 |  |
| Operating income |  |  | 36,361 |  |  |  | 54,550 |  |  |  | 16,844 |  |  |  | 70,695 |  |  |  | 116,285 |  |
| Interest expense |  |  | (20,568 | ) |  |  | (22,225 | ) |  |  | (20,871 | ) |  |  | (63,127 | ) |  |  | (56,425 | ) |
| Other, net |  |  | 8,126 |  |  |  | 2,213 |  |  |  | 4,621 |  |  |  | 12,217 |  |  |  | 7,284 |  |
| Income before income taxes |  |  | 23,919 |  |  |  | 34,538 |  |  |  | 594 |  |  |  | 19,785 |  |  |  | 67,144 |  |
| Income tax (provision) / benefit |  |  | (8,049 | ) |  |  | (7,537 | ) |  |  | 2,830 |  |  |  | (3,743 | ) |  |  | 53,958 |  |
| Net income |  | $ | 15,870 |  |  | $ | 27,001 |  |  | $ | 3,424 |  |  | $ | 16,042 |  |  | $ | 121,102 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.15 |  |  | $ | 0.26 |  |  | $ | 0.03 |  |  | $ | 0.15 |  |  | $ | 1.17 |  |
| Diluted |  | $ | 0.14 |  |  | $ | 0.22 |  |  | $ | 0.03 |  |  | $ | 0.15 |  |  | $ | 0.98 |  |
| Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 105,492 |  |  |  | 103,676 |  |  |  | 105,470 |  |  |  | 105,092 |  |  |  | 103,246 |  |
| Diluted |  |  | 132,412 |  |  |  | 136,435 |  |  |  | 106,107 |  |  |  | 106,065 |  |  |  | 134,871 |  |
| Reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 15,870 |  |  | $ | 27,001 |  |  |  |  |  |  |  |  |  |  | $ | 121,102 |  |
| Add back items: interest expense, net of tax |  |  | 2,836 |  |  |  | 3,628 |  |  |  |  |  |  |  |  |  |  |  | 10,763 |  |
| Adjusted net income |  | $ | 18,706 |  |  | $ | 30,629 |  |  |  |  |  |  |  |  |  |  | $ | 131,865 |  |
| Weighted-average shares outstanding |  |  | 105,492 |  |  |  | 103,676 |  |  |  |  |  |  |  |  |  |  |  | 103,246 |  |
| Dilutive effect of convertible debt |  |  | 25,938 |  |  |  | 25,938 |  |  |  |  |  |  |  |  |  |  |  | 25,939 |  |
| Dilutive effect of warrants |  |  | — |  |  |  | 5,226 |  |  |  |  |  |  |  |  |  |  |  | 4,086 |  |
| Dilutive effect of performance-based stock units, restricted stock units & stock options |  |  | 982 |  |  |  | 1,595 |  |  |  |  |  |  |  |  |  |  |  | 1,600 |  |
| Diluted shares |  |  | 132,412 |  |  |  | 136,435 |  |  |  |  |  |  |  |  |  |  |  | 134,871 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.15 |  |  | $ | 0.26 |  |  |  |  |  |  |  |  |  |  | $ | 1.17 |  |
| Diluted |  | $ | 0.14 |  |  | $ | 0.22 |  |  |  |  |  |  |  |  |  |  | $ | 0.98 |  |
| SELECTED BALANCE SHEET DATA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | September 30, 2019 |  |  | December 31, 2018 |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents, including restricted cash |  | $ | 316,589 |  |  | $ | 256,360 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts and notes receivable, net |  |  | 529,942 |  |  |  | 523,165 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  |  | 268,542 |  |  |  | 287,741 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Inventories |  |  | 126,324 |  |  |  | 109,377 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total current assets |  |  | 1,277,835 |  |  |  | 1,206,914 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 1,027,868 |  |  |  | 1,052,024 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease right of use asset |  |  | 23,670 |  |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other non-current assets |  |  | 1,168,985 |  |  |  | 1,198,565 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total assets |  |  | 3,498,358 |  |  |  | 3,457,503 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt, including current portion of long-term debt |  | $ | — |  |  | $ | 30,000 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 470,233 |  |  |  | 431,288 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total current liabilities |  |  | 666,673 |  |  |  | 673,214 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt, net of discount |  |  | 1,472,578 |  |  |  | 1,462,425 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total long-term liabilities |  |  | 1,584,332 |  |  |  | 1,557,202 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total equity |  |  | 1,247,353 |  |  |  | 1,227,087 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total liabilities and equity |  |  | 3,498,358 |  |  |  | 3,457,503 |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001193125-19-278973:8k_2_02:43]
SUPPLEMENTAL DATA

[0001193125-19-278973:8k_2_02:44]
|  |  | Third Quarter |  |  | Second Quarter |  |  | First Three Quarters |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2019 |  |  | 2018 |  |
| Gross margin |  |  | 14.5 | % |  |  | 17.1 | % |  |  | 13.4 | % |  |  | 14.1 | % |  |  | 15.7 | % |
| Operating margin |  |  | 5.1 | % |  |  | 7.2 | % |  |  | 2.7 | % |  |  | 3.6 | % |  |  | 5.4 | % |
| End Market Breakdown: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Third Quarter |  |  | Second Quarter |  |  |  |  |  |  |  |
|  |  | 2019 |  |  | 2018* |  |  | 2019 |  |  |  |  |  |  |  |
| Aerospace/Defense |  |  | 24 | % |  |  | 21 | % |  |  | 28 | % |  |  |  |  |  |  |  |  |
| Automotive |  |  | 17 | % |  |  | 15 | % |  |  | 16 | % |  |  |  |  |  |  |  |  |
| Cellular Phone |  |  | 19 | % |  |  | 17 | % |  |  | 6 | % |  |  |  |  |  |  |  |  |
| Computing/Storage/Peripherals |  |  | 12 | % |  |  | 14 | % |  |  | 15 | % |  |  |  |  |  |  |  |  |
| Medical/Industrial/Instrumentation |  |  | 13 | % |  |  | 14 | % |  |  | 15 | % |  |  |  |  |  |  |  |  |
| Networking/Communications |  |  | 13 | % |  |  | 17 | % |  |  | 17 | % |  |  |  |  |  |  |  |  |
| Other |  |  | 2 | % |  |  | 2 | % |  |  | 3 | % |  |  |  |  |  |  |  |  |
| * Amended for Anaren integration |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based Compensation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Third Quarter |  |  | Second Quarter |  |  |  |  |  |  |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  |  |  |  |  |  |
| Amount included in: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 941 |  |  | $ | 774 |  |  | $ | 570 |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 593 |  |  |  | 520 |  |  |  | 396 |  |  |  |  |  |  |  |  |  |
| General and administrative |  |  | 3,128 |  |  |  | 4,165 |  |  |  | 2,636 |  |  |  |  |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 4,662 |  |  | $ | 5,459 |  |  | $ | 3,602 |  |  |  |  |  |  |  |  |  |
| Operating Segment Data: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Third Quarter |  |  | Second Quarter |  |  |  |  |  |  |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  |  |  |  |  |  |
| Net sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 649,104 |  |  | $ | 696,356 |  |  | $ | 573,121 |  |  |  |  |  |  |  |  |  |
| E-M Solutions |  |  | 67,713 |  |  |  | 59,481 |  |  |  | 59,917 |  |  |  |  |  |  |  |  |  |
| Total net sales |  | $ | 716,817 |  |  | $ | 755,837 |  |  | $ | 633,038 |  |  |  |  |  |  |  |  |  |
| Operating segment income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 73,230 |  |  | $ | 98,039 |  |  | $ | 50,989 |  |  |  |  |  |  |  |  |  |
| E-M Solutions |  |  | 3,236 |  |  |  | 2,205 |  |  |  | 863 |  |  |  |  |  |  |  |  |  |
| Corporate |  |  | (28,750 | ) |  |  | (26,920 | ) |  |  | (22,561 | ) |  |  |  |  |  |  |  |  |
| Total operating segment income |  |  | 47,716 |  |  |  | 73,324 |  |  |  | 29,291 |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | (11,355 | ) |  |  | (18,774 | ) |  |  | (12,447 | ) |  |  |  |  |  |  |  |  |
| Total operating income |  |  | 36,361 |  |  |  | 54,550 |  |  |  | 16,844 |  |  |  |  |  |  |  |  |  |
| Total other expense |  |  | (12,442 | ) |  |  | (20,012 | ) |  |  | (16,250 | ) |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 23,919 |  |  | $ | 34,538 |  |  | $ | 594 |  |  |  |  |  |  |  |  |  |

[0001193125-19-278973:8k_2_02:45]
RECONCILIATIONS1

[0001193125-19-278973:8k_2_02:46]
|  |  | Third Quarter |  |  | Second Quarter |  |  | First Three Quarters |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2019 |  |  | 2018 |  |
| Non-GAAP gross profit reconciliation2: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 103,834 |  |  | $ | 129,584 |  |  | $ | 84,615 |  |  | $ | 277,134 |  |  | $ | 334,402 |  |
| Add back item: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Inventory markup |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 4,900 |  |
| Amortization of definite-lived intangibles |  |  | 1,180 |  |  |  | 2,165 |  |  |  | 1,180 |  |  |  | 3,539 |  |  |  | 2,165 |  |
| Stock-based compensation |  |  | 941 |  |  |  | 774 |  |  |  | 570 |  |  |  | 2,216 |  |  |  | 2,132 |  |
| Non-GAAP gross profit |  | $ | 105,955 |  |  | $ | 132,523 |  |  | $ | 86,365 |  |  | $ | 282,889 |  |  | $ | 343,599 |  |
| Non-GAAP gross margin |  |  | 14.8 | % |  |  | 17.5 | % |  |  | 13.6 | % |  |  | 14.4 | % |  |  | 16.1 | % |
| Non-GAAP operating income reconciliation3: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP operating income |  | $ | 36,361 |  |  | $ | 54,550 |  |  | $ | 16,844 |  |  | $ | 70,695 |  |  | $ | 116,285 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 11,355 |  |  |  | 18,774 |  |  |  | 12,447 |  |  |  | 41,807 |  |  |  | 44,124 |  |
| Stock-based compensation |  |  | 4,662 |  |  |  | 5,459 |  |  |  | 3,602 |  |  |  | 12,190 |  |  |  | 14,948 |  |
| Inventory markup |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 4,900 |  |
| Restructuring, acquisition-related, and other charges |  |  | 1,573 |  |  |  | 230 |  |  |  | 4,351 |  |  |  | 7,027 |  |  |  | 12,693 |  |
| Non-GAAP operating income |  | $ | 53,951 |  |  | $ | 79,013 |  |  | $ | 37,244 |  |  | $ | 131,719 |  |  | $ | 192,950 |  |
| Non-GAAP operating margin |  |  | 7.5 | % |  |  | 10.5 | % |  |  | 5.9 | % |  |  | 6.7 | % |  |  | 9.0 | % |
| Non-GAAP net income and EPS reconciliation4: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 15,870 |  |  | $ | 27,001 |  |  | $ | 3,424 |  |  | $ | 16,042 |  |  | $ | 121,102 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of definite-lived intangibles |  |  | 11,355 |  |  |  | 18,774 |  |  |  | 12,447 |  |  |  | 41,807 |  |  |  | 44,124 |  |
| Stock-based compensation |  |  | 4,662 |  |  |  | 5,459 |  |  |  | 3,602 |  |  |  | 12,190 |  |  |  | 14,948 |  |
| Non-cash interest expense |  |  | 3,452 |  |  |  | 3,992 |  |  |  | 3,467 |  |  |  | 10,787 |  |  |  | 10,399 |  |
| (Gain) on sale of Viasource |  |  | (251 | ) |  |  | — |  |  |  | (235 | ) |  |  | (3,557 | ) |  |  | — |  |
| Inventory markup |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 4,900 |  |
| Restructuring, acquisition-related, and other charges |  |  | 1,573 |  |  |  | 230 |  |  |  | 4,351 |  |  |  | 7,027 |  |  |  | 13,235 |  |
| Income taxes5 |  |  | 2,237 |  |  |  | (337 | ) |  |  | (5,789 | ) |  |  | (7,702 | ) |  |  | (73,302 | ) |
| Non-GAAP net income |  | $ | 38,898 |  |  | $ | 55,119 |  |  | $ | 21,267 |  |  | $ | 76,594 |  |  | $ | 135,406 |  |
| Non-GAAP earnings per diluted share |  | $ | 0.37 |  |  | $ | 0.50 |  |  | $ | 0.20 |  |  | $ | 0.72 |  |  | $ | 1.24 |  |
| Non-GAAP diluted number of shares6: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Diluted shares |  |  | 132,412 |  |  |  | 136,435 |  |  |  | 106,107 |  |  |  | 106,065 |  |  |  | 134,871 |  |
| Dilutive effect of convertible debt |  |  | (25,938 | ) |  |  | (25,938 | ) |  |  | — |  |  |  | — |  |  |  | (25,939 | ) |
| Non-GAAP diluted number of shares |  |  | 106,474 |  |  |  | 110,497 |  |  |  | 106,107 |  |  |  | 106,065 |  |  |  | 108,932 |  |
| Adjusted EBITDA reconciliation7: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 15,870 |  |  | $ | 27,001 |  |  | $ | 3,424 |  |  | $ | 16,042 |  |  | $ | 121,102 |  |
| Add back items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax provision (benefit) |  |  | 8,049 |  |  |  | 7,537 |  |  |  | (2,830 | ) |  |  | 3,743 |  |  |  | (53,958 | ) |
| Interest expense |  |  | 20,568 |  |  |  | 22,225 |  |  |  | 20,871 |  |  |  | 63,127 |  |  |  | 56,425 |  |
| Amortization of definite-lived intangibles |  |  | 11,355 |  |  |  | 18,774 |  |  |  | 12,447 |  |  |  | 41,807 |  |  |  | 44,124 |  |
| Depreciation expense |  |  | 41,719 |  |  |  | 41,092 |  |  |  | 41,235 |  |  |  | 124,556 |  |  |  | 121,165 |  |
| Stock-based compensation |  |  | 4,662 |  |  |  | 5,459 |  |  |  | 3,602 |  |  |  | 12,190 |  |  |  | 14,948 |  |
| (Gain) on sale of Viasource |  |  | (251 | ) |  |  | — |  |  |  | (235 | ) |  |  | (3,557 | ) |  |  | — |  |
| Inventory markup |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 4,900 |  |
| Restructuring, acquisition-related, and other charges |  |  | 1,573 |  |  |  | 230 |  |  |  | 4,351 |  |  |  | 7,027 |  |  |  | 12,693 |  |
| Adjusted EBITDA |  | $ | 103,545 |  |  | $ | 122,318 |  |  | $ | 82,865 |  |  | $ | 264,935 |  |  | $ | 321,399 |  |
| Adjusted EBITDA margin |  |  | 14.4 | % |  |  | 16.2 | % |  |  | 13.1 | % |  |  | 13.4 | % |  |  | 15.0 | % |
| Free cash flow reconciliation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flow |  |  | 58,742 |  |  |  | 79,992 |  |  |  | 86,123 |  |  |  | 181,789 |  |  |  | 121,370 |  |
| Capital expenditures, net |  |  | (25,803 | ) |  |  | (35,038 | ) |  |  | (34,741 | ) |  |  | (88,990 | ) |  |  | (116,125 | ) |
| Free cash flow |  | $ | 32,939 |  |  | $ | 44,954 |  |  | $ | 51,382 |  |  | $ | 92,799 |  |  | $ | 5,245 |  |

[0001193125-19-278973:8k_2_02:47]
| 1 | This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income, non-GAAP EPS, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |

[0001193125-19-278973:8k_2_02:48]
| 2 | Non-GAAP gross profit and gross margin measures exclude amortization of intangibles, stock-based compensation expense and inventory markup. |

[0001193125-19-278973:8k_2_02:49]
| 3 | Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, inventory markup, acquisition-related costs, restructuring and other charges. |

[0001193125-19-278973:8k_2_02:50]
| 4 | This information provides non-GAAP net income and non-GAAP EPS, which are non-GAAP financial measures. Management believes that both measures — which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, inventory markup, acquisition-related costs, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items — provide additional useful information to investors regarding the Company’s ongoing financial condition and results of operations. |

[0001193125-19-278973:8k_2_02:51]
| 5 | Income tax adjustments reflect the difference between income taxes based on a non-GAAP tax rate and a forecasted annual GAAP tax rate. |

[0001193125-19-278973:8k_2_02:52]
| 6 | Non-GAAP diluted number of shares used in computing non-GAAP earnings per share excludes the dilutive effect of convertible debt. |

[0001193125-19-278973:8k_2_02:53]
| 7 | Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, inventory markup, acquisition-related costs, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |
