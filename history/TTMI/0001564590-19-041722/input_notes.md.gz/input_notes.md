# TTMI notes — 0001564590-19-041722


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-19-041722:notes:1]
[same as prior period, unchanged from 0001564590-19-030026:notes:1]

[0001564590-19-041722:notes:2]
[same as prior period, unchanged from 0001564590-19-030026:notes:2]

[0001564590-19-041722:notes:3]
[same as prior period, unchanged from 0001564590-19-030026:notes:3]

[0001564590-19-041722:notes:4]
[same as prior period, unchanged from 0001564590-19-030026:notes:4]

[0001564590-19-041722:notes:5]
[same as prior period, unchanged from 0001564590-19-030026:notes:5]

[0001564590-19-041722:notes:6]
[same as prior period, unchanged from 0001564590-19-030026:notes:6]

[0001564590-19-041722:notes:7]
[same as prior period, unchanged from 0001564590-19-030026:notes:7]

[0001564590-19-041722:notes:8]
Recently Adopted Accounting Standards

[0001564590-19-041722:notes:9]
In February 2016, the Financial Accounting Standards Board (FASB) issued ASU 2016-02, Leases (Topic 842) which supersedes the existing lease recognition requirements in the current accounting standard for leases. The core principal of the new standard is that an entity should recognize right-of-use (ROU) assets and lease liabilities arising from a lease for both financing and operating leases, along with additional qualitative and quantitative disclosures.

[0001564590-19-041722:notes:10]
In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements. ASU 2018-11 provides additional guidance to Topic 842 including providing preparers an additional optional retrospective adoption method which allows entities to initially apply the new leases standard at the adoption date and recognize a cumulative effect adjustment to the opening balance of retained earnings. ASU 2018-11 also provides lessors a practical expedient to not separate lease from non-lease components, in certain situations.

[0001564590-19-041722:notes:11]
The Company adopted the new lease standard as of January 1, 2019 and utilized the retrospective cumulative effect adjustment transition method with a cumulative effect adjustment being recorded as of the adoption date. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated condensed balance sheet as of December 31, 2018 and the consolidated condensed statement of operations for the quarter and three quarters ended October 1, 2018. The Company implemented internal controls and key system functionality to enable the preparation of financial information on adoption. The Company elected certain available practical expedients including the package of practical expedients permitted under the transition guidance within the new standard, which among other things, allowed the Company to carry forward the historical lease classification. Additionally, the Company elected an accounting policy to not record ROU assets and lease liabilities for leases with an initial term of twelve months or less on its consolidated condensed balance sheet.

[0001564590-19-041722:notes:12]
[same as prior period, unchanged from 0001564590-19-030026:notes:12]

[0001564590-19-041722:notes:13]
[same as prior period, unchanged from 0001564590-19-030026:notes:13]

[0001564590-19-041722:notes:14]
The adoption of the new accounting guidance did not have a material impact to the consolidated condensed statement of operations for the quarter and three quarters ended September 30, 2019, or the consolidated condensed statement of cash flows for the three quarters ended September 30, 2019. See Note 3 for further details.

[0001564590-19-041722:notes:15]
In June 2018, the FASB issued ASU 2018-07, Compensation-Stock Compensation (Topic 718): Improvements to Nonemployee Share-based Payments. This ASU expands the scope of Topic 718 to include share-based payment transactions for acquiring goods and services from nonemployees. The effective date for the standard is for interim periods in fiscal years beginning after December 15, 2018, with early adoption permitted, but no earlier than the Company's adoption date of Topic 606. The new guidance is required to be applied retrospectively with the cumulative effect recognized at the date of initial application. The Company adopted ASU 2018-07 on January 1, 2019. The adoption did not have a material impact on the consolidated condensed financial statements or related disclosures.

[0001564590-19-041722:notes:16]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company adopted ASU 2017-12 on January 1, 2019. The adoption did not have a material impact on the consolidated condensed financial statements or related disclosures.

[0001564590-19-041722:notes:17]
Recently Issued Accounting Standards Not Yet Adopted

[0001564590-19-041722:notes:18]
In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments. Apart from the amendments to ASU 2016-13 as mentioned below, the ASU also included subsequent amendments to ASU 2016-01, which we adopted on January 2, 2018. The guidance in relation to the amendments to ASU 2016-01 is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures.

[0001564590-19-041722:notes:19]
In August 2018, the FASB issued ASU 2018-14, Compensation—Retirement Benefits—Defined Benefit Plans—General (Subtopic 715-20)—Disclosure Framework—Changes to the Disclosure Requirements for Defined Benefit Plans. The amendments in this update change the disclosure requirements for employers that sponsor defined benefit pension and/or other postretirement benefit plans. It eliminates requirements for certain disclosures that are no longer considered cost beneficial and requires new disclosures that the FASB considers pertinent. The guidance is effective for fiscal years ending after December 15, 2020. Early adoption is permitted. The Company does not anticipate the adoption will have a material impact on the consolidated condensed financial statements and related disclosures.

[0001564590-19-041722:notes:20]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 seeks to provide financial statement users with more decision-useful information about the expected credit losses on financial instruments, including trade receivables, and other commitments to extend credit held by a reporting entity at each reporting date. The amendments require an entity to replace the incurred loss impairment methodology in current U.S. GAAP with a methodology that reflects current expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial

[0001564590-19-041722:notes:21]
Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments—Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. All of these ASUs are effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated condensed financial statements and related disclosures.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-19-041722:notes:22]
[same as prior period, unchanged from 0001564590-19-030026:notes:20]

[0001564590-19-041722:notes:23]
[same as prior period, unchanged from 0001564590-19-030026:notes:21]

[0001564590-19-041722:notes:24]
[same as prior period, unchanged from 0001564590-19-030026:notes:22]

[0001564590-19-041722:notes:25]
[same as prior period, unchanged from 0001564590-19-030026:notes:23]

[0001564590-19-041722:notes:26]
[same as prior period, unchanged from 0001564590-19-030026:notes:24]


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-19-041722:notes:27]
[same as prior period, unchanged from 0001564590-19-030026:notes:25]

[0001564590-19-041722:notes:28]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases that expire at various dates through 2049. The majority of the Company’s lease arrangements are comprised of fixed payments and a limited number of leases consist of variable payments based on equipment usage. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-19-041722:notes:29]
[same as prior period, unchanged from 0001564590-19-030026:notes:27]

[0001564590-19-041722:notes:30]
|  | Quarter Ended September 30, 2019 |  |  | Three Quarters Ended September 30, 2019 |  |
|  | (In thousands) |  |
| Operating lease cost | $ | 2,362 |  |  | $ | 6,886 |  |
| Variable lease cost |  | 4,675 |  |  |  | 6,677 |  |
| Short-term lease cost |  | 369 |  |  |  | 750 |  |

[0001564590-19-041722:notes:31]
[same as prior period, unchanged from 0001564590-19-030026:notes:29]

[0001564590-19-041722:notes:32]
|  | Three Quarters Ended September 30, 2019 |  |
|  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |
| Operating cash flows from operating leases | $ | 6,495 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |
| Operating leases |  | 13,023 |  |

[0001564590-19-041722:notes:33]
[same as prior period, unchanged from 0001564590-19-030026:notes:31]

[0001564590-19-041722:notes:34]
|  | As of September 30, 2019 |  |
|  | (In thousands) |  |
| Operating lease right-of-use assets | $ | 23,670 |  |
| Other current liabilities |  | 7,164 |  |
| Operating lease liabilities |  | 16,727 |  |
| Total operating lease liabilities | $ | 23,891 |  |

[0001564590-19-041722:notes:35]
| Weighted average remaining lease term | 4.5 years |  |
| Weighted average discount rate |  | 3.96 | % |

[0001564590-19-041722:notes:36]
[same as prior period, unchanged from 0001564590-19-030026:notes:34]

[0001564590-19-041722:notes:37]
|  |  | (In thousands) |  |
| Less than one year |  | $ | 7,913 |  |
| 1 - 2 years |  |  | 6,640 |  |
| 2 - 3 years |  |  | 3,987 |  |
| 3 - 4 years |  |  | 2,361 |  |
| 4 - 5 years |  |  | 1,855 |  |
| Thereafter |  |  | 3,417 |  |
| Total lease payments |  |  | 26,173 |  |
| Less imputed interest |  |  | (2,282 | ) |
| Total |  | $ | 23,891 |  |

[0001564590-19-041722:notes:38]
[same as prior period, unchanged from 0001564590-19-030026:notes:36]

[0001564590-19-041722:notes:39]
[same as prior period, unchanged from 0001564590-19-030026:notes:37]

[0001564590-19-041722:notes:40]
[same as prior period, unchanged from 0001564590-19-030026:notes:38]

[0001564590-19-041722:notes:41]
[same as prior period, unchanged from 0001564590-19-030026:notes:39]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-041722:notes:42]
[same as prior period, unchanged from 0001564590-19-030026:notes:40]

[0001564590-19-041722:notes:43]
As of September 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $9,024. The Company expects to recognize revenue on approximately 100% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months. The remaining performance obligations for the Company’s short-term contracts are expected to be recognized within one year.

[0001564590-19-041722:notes:44]
Revenue from products and services transferred to customers over time and at a point in time accounted for 98% and 2%, respectively, of the Company’s revenue for the quarter ended September 30, 2019, and 97% and 3%, respectively, of the Company’s revenue for the three quarters ended September 30, 2019.

[0001564590-19-041722:notes:45]
[same as prior period, unchanged from 0001564590-19-030026:notes:43]

[0001564590-19-041722:notes:46]
|  |  | Quarter Ended September 30, 2019 |  |  | Quarter Ended October 1, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 171,903 |  |  | $ | 1 |  |  | $ | 171,904 |  |  | $ | 160,067 |  |  | $ | 122 |  |  | $ | 160,189 |  |
| Automotive |  |  | 78,393 |  |  |  | 39,559 |  |  |  | 117,952 |  |  |  | 96,329 |  |  |  | 19,628 |  |  |  | 115,957 |  |
| Cellular Phone |  |  | 136,184 |  |  |  | — |  |  |  | 136,184 |  |  |  | 125,442 |  |  |  | — |  |  |  | 125,442 |  |
| Computing/Storage/Peripherals |  |  | 84,429 |  |  |  | 72 |  |  |  | 84,501 |  |  |  | 107,796 |  |  |  | 253 |  |  |  | 108,049 |  |
| Medical/Industrial/Instrumentation |  |  | 89,395 |  |  |  | 5,775 |  |  |  | 95,170 |  |  |  | 93,248 |  |  |  | 10,457 |  |  |  | 103,705 |  |
| Networking/Communications |  |  | 72,045 |  |  |  | 22,746 |  |  |  | 94,791 |  |  |  | 97,926 |  |  |  | 28,986 |  |  |  | 126,912 |  |
| Other |  |  | 16,755 |  |  |  | (440 | ) |  |  | 16,315 |  |  |  | 15,548 |  |  |  | 35 |  |  |  | 15,583 |  |
| Total |  | $ | 649,104 |  |  | $ | 67,713 |  |  | $ | 716,817 |  |  | $ | 696,356 |  |  | $ | 59,481 |  |  | $ | 755,837 |  |

[0001564590-19-041722:notes:47]
|  |  | Three Quarters Ended September 30, 2019 |  |  | Three Quarters Ended October 1, 2018 |  |
|  |  | PCB |  |  | E-M Solutions |  |  | Total |  |  | PCB |  |  | E-M Solutions |  |  | Total |  |
| End Markets |  | (In thousands) |  |
| Aerospace and Defense |  | $ | 512,272 |  |  | $ | 367 |  |  | $ | 512,639 |  |  | $ | 445,694 |  |  | $ | 666 |  |  | $ | 446,360 |  |
| Automotive |  |  | 243,254 |  |  |  | 83,317 |  |  |  | 326,571 |  |  |  | 323,228 |  |  |  | 64,792 |  |  |  | 388,020 |  |
| Cellular Phone |  |  | 219,362 |  |  |  | — |  |  |  | 219,362 |  |  |  | 285,695 |  |  |  | — |  |  |  | 285,695 |  |
| Computing/Storage/Peripherals |  |  | 260,448 |  |  |  | 261 |  |  |  | 260,709 |  |  |  | 305,971 |  |  |  | 1,126 |  |  |  | 307,097 |  |
| Medical/Industrial/Instrumentation |  |  | 264,536 |  |  |  | 23,583 |  |  |  | 288,119 |  |  |  | 283,586 |  |  |  | 27,836 |  |  |  | 311,422 |  |
| Networking/Communications |  |  | 240,045 |  |  |  | 72,011 |  |  |  | 312,056 |  |  |  | 279,216 |  |  |  | 73,061 |  |  |  | 352,277 |  |
| Other |  |  | 51,130 |  |  |  | (531 | ) |  |  | 50,599 |  |  |  | 44,442 |  |  |  | 993 |  |  |  | 45,435 |  |
| Total |  | $ | 1,791,047 |  |  | $ | 179,008 |  |  | $ | 1,970,055 |  |  | $ | 1,967,832 |  |  | $ | 168,474 |  |  | $ | 2,136,306 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-19-041722:notes:48]
[same as prior period, unchanged from 0001564590-19-030026:notes:46]

[0001564590-19-041722:notes:49]
|  |  | As of |  |  | As of |  |
|  |  | September 30, 2019 |  |  | December 31, 2018 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 108,308 |  |  | $ | 97,600 |  |
| Work-in-process |  |  | 11,260 |  |  |  | 10,299 |  |
| Finished goods |  |  | 6,756 |  |  |  | 1,478 |  |
|  |  | $ | 126,324 |  |  | $ | 109,377 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 74,850 |  |  | $ | 75,431 |  |
| Buildings and improvements |  |  | 538,977 |  |  |  | 534,122 |  |
| Machinery and equipment |  |  | 1,418,271 |  |  |  | 1,357,035 |  |
| Construction-in-progress, furniture and fixtures and other |  |  | 64,481 |  |  |  | 42,713 |  |
|  |  |  | 2,096,579 |  |  |  | 2,009,301 |  |
| Less: Accumulated depreciation |  |  | (1,068,711 | ) |  |  | (957,277 | ) |
|  |  | $ | 1,027,868 |  |  | $ | 1,052,024 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-19-041722:notes:50]
[same as prior period, unchanged from 0001564590-19-030026:notes:48]

[0001564590-19-041722:notes:51]
As of September 30, 2019 and December 31, 2018, goodwill was as follows:

[0001564590-19-041722:notes:52]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of September 30, 2019 and December 31, 2018 |  |  |  |  |
| Goodwill |  | $ | 938,445 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  | $ | 767,045 |  |

[0001564590-19-041722:notes:53]
[same as prior period, unchanged from 0001564590-19-030026:notes:51]

[0001564590-19-041722:notes:54]
The Company evaluates its goodwill on an annual basis during its fourth fiscal quarter and at other times when events or changes in circumstances — such as significant adverse changes in the business climate or operating results or changes in management strategy, coupled with a decline in the market price of its stock and market capitalization — indicate that there may be a potential impairment. During the third fiscal quarter, the Company’s Communications and Computing and Automotive and Medical/Industrial/Instrumentation reporting units had lower than anticipated results and continued declines in sales. The Company considered these factors to be indicators of potential impairment requiring the Company to test the related goodwill for impairment of $39,300 for Communications and Computing reporting unit and $185,500 for Automotive and Medical/Industrial/Instrumentation reporting unit. As of September 30, 2019, the Company completed a quantitative goodwill impairment analysis related to its Communications and Computing and Automotive and Medical/Industrial/Instrumentation reporting units by comparing the fair value of the reporting unit with its carrying amount. The Company determined the fair value of the reporting units by using discounted cash flow (DCF) and market analyses. Under the market approach, the Company used revenue and earnings multiples based on comparable industry multiples to estimate the fair value of the reporting units.

[0001564590-19-041722:notes:55]
Fair value is typically estimated using a DCF analysis which requires the Company to estimate the future cash flows as well as to select a risk-adjusted discount rate to measure the present value of the anticipated cash flows. When determining future cash flow estimates, the Company considers historical results adjusted to reflect current and anticipated future operating conditions. The Company estimates cash flows for a reporting unit over a discrete period and a terminal period (considering expected long-term growth rates and trends).

[0001564590-19-041722:notes:56]
Based on its analysis, the Company estimates that the fair value of the Communications and Computing and Automotive and Medical/Industrial/Instrumentation reporting units exceeded its respective carrying value by 19% and 8%, respectively. If the Company’s future cash flow projections and other fair value assumptions for its reporting unit change, the Company may be subject to potential impairment in subsequent quarters. Estimating the fair value of the reporting unit requires the Company to make assumptions and estimates in such areas as future economic conditions, industry-specific conditions, product pricing, and necessary capital expenditures. The use of different assumptions or estimates for future cash flows, discount rates, or terminal growth rates could produce substantially different estimates of the fair value of the reporting unit.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-19-041722:notes:57]
[same as prior period, unchanged from 0001564590-19-030026:notes:53]

[0001564590-19-041722:notes:58]
As of September 30, 2019 and December 31, 2018, the components of definite-lived intangibles were as follows:

[0001564590-19-041722:notes:59]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  | (In years) |  |
| September 30, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 415,000 |  |  | $ | (113,499 | ) |  | $ | 301,501 |  |  | 10.7 |  |
| Technology |  |  | 39,500 |  |  |  | (6,885 | ) |  |  | 32,615 |  |  | 9.4 |  |
|  |  | $ | 454,500 |  |  | $ | (120,384 | ) |  | $ | 334,116 |  |  |  |  |
| December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,634 |  |  | $ | (123,522 | ) |  | $ | 80,112 |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (3,000 | ) |  |  | — |  |  | 3.0 |  |
| Acquired intangibles from acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 267,500 |  |  |  | (15,561 | ) |  |  | 251,939 |  |  | 12.2 |  |
| Developed technology |  |  | 39,500 |  |  |  | (3,345 | ) |  |  | 36,155 |  |  | 9.4 |  |
| Backlog |  |  | 29,000 |  |  |  | (21,283 | ) |  |  | 7,717 |  |  | 0.9 |  |
|  |  | $ | 542,634 |  |  | $ | (166,711 | ) |  | $ | 375,923 |  |  |  |  |

[0001564590-19-041722:notes:60]
Definite-lived intangibles are generally amortized using the straight-line method of amortization over the estimated useful life, with the exception of certain customer relationship intangibles, which are amortized using an accelerated method of amortization based on estimated cash flows. Amortization expense was $11,355 and $18,774 for the quarters ended September 30, 2019 and October 1, 2018, respectively, and $41,807 and $44,124 for the three quarters ended September 30, 2019 and October 1, 2018, respectively. For the quarter and three quarters ended September 30, 2019, $1,180 and $3,539, respectively, of amortization expense is included in cost of goods sold. For both the quarter and three quarters ended October 1, 2018, $2,165 of amortization expense is included in cost of goods sold.

[0001564590-19-041722:notes:61]
[same as prior period, unchanged from 0001564590-19-030026:notes:57]

[0001564590-19-041722:notes:62]
|  |  | (In thousands) |  |
| Remaining 2019 |  | $ | 11,354 |  |
| 2020 |  |  | 45,419 |  |
| 2021 |  |  | 42,108 |  |
| 2022 |  |  | 39,002 |  |
| 2023 |  |  | 36,290 |  |
| Thereafter |  |  | 159,943 |  |
|  |  | $ | 334,116 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-19-041722:notes:63]
(8) Long-term Debt and Letters of Credit

[0001564590-19-041722:notes:64]
The following table summarizes the long-term debt of the Company as of September 30, 2019 and December 31, 2018:

[0001564590-19-041722:notes:65]
|  | Interest Rate as of September 30, 2019 |  |  | Principal Outstanding as of September 30, 2019 |  |  | Interest Rate as of December 31, 2018 |  |  | Principal Outstanding as of December 31, 2018 |  |
|  | (In thousands, except interest rates) |  |
| Term Loan due September 2024 |  | 4.52 |  | % | $ | 805,879 |  |  |  | 5.00 |  | % | $ | 835,879 |  |
| Senior Notes due October 2025 |  | 5.63 |  |  |  | 375,000 |  |  |  | 5.63 |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75 |  |  |  | 249,975 |  |  |  | 1.75 |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due June 2024 |  | 3.27 |  |  |  | 40,000 |  |  |  | 4.00 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  | 3.42 |  |  |  | 30,000 |  |  |  | 3.90 |  |  |  | 30,000 |  |
|  |  |  |  |  |  | 1,500,854 |  |  |  |  |  |  |  | 1,530,864 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  | (14,536 | ) |  |  |  |  |  |  | (22,167 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  | (13,740 | ) |  |  |  |  |  |  | (16,272 | ) |
|  |  |  |  |  |  | 1,472,578 |  |  |  |  |  |  |  | 1,492,425 |  |
| Less: current maturities |  |  |  |  |  | — |  |  |  |  |  |  |  | (30,000 | ) |
| Long-term debt, less current maturities |  |  |  |  | $ | 1,472,578 |  |  |  |  |  |  | $ | 1,462,425 |  |

[0001564590-19-041722:notes:66]
Term Loan Facility

[0001564590-19-041722:notes:67]
On April 18, 2018, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. At issuance, these incremental loans increased the Company’s existing balance of its Term Loan Facility due 2024 from $348,250 to $948,250. The Term Loan Facility had an outstanding balance of $805,879 as of September 30, 2019 and is included in long-term debt. The Term Loan Facility was issued at a weighted average discount of 99.7% and bears interest, at the Company’s option, at a floating rate of LIBOR plus an applicable interest margin of 2.5%, or an alternate base rate (as defined in the Term Loan Credit Agreement) plus an applicable margin of 1.5%. As of September 30, 2019, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.52%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-19-041722:notes:68]
Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. For 2019, the Company is not required to make an additional principal payment as its First Lien Leverage Ratio was less than 2.0. Any remaining outstanding balance under the Term Loan Facility is due at the maturity date of September 28, 2024.

[0001564590-19-041722:notes:69]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

[0001564590-19-041722:notes:70]
Senior Notes

[0001564590-19-041722:notes:71]
The $375,000 of Senior Notes, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

[0001564590-19-041722:notes:72]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-19-041722:notes:73]
Convertible Senior Notes due 2020

[0001564590-19-041722:notes:74]
The Company maintains 1.75% Convertible Senior Notes in the amount of $249,975 due December 15, 2020. The Convertible Senior Notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The Convertible Senior Notes are senior unsecured obligations and would rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the Convertible Senior Notes.

[0001564590-19-041722:notes:75]
As of September 30, 2019 and December 31, 2018, the following summarizes the equity components of the Convertible Senior Notes included in additional paid-in capital:

[0001564590-19-041722:notes:76]
|  |  | As of September 30, 2019 |  |  | As of December 31, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Convertible Senior Notes due 2020 |  | $ | 60,213 |  |  | $ | (1,916 | ) |  | $ | 58,297 |  |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

[0001564590-19-041722:notes:77]
The components of interest expense resulting from the Convertible Senior Notes for the quarter and three quarters ended September 30, 2019 and October 1, 2018 were as follows:

[0001564590-19-041722:notes:78]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, |  |  | October 1, |  |  | September 30, |  |  | October 1, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,457 |  |  | $ | 2,303 |  |  | $ | 7,254 |  |  | $ | 6,800 |  |
| Amortization of debt issuance costs |  | $ | 246 |  |  | $ | 231 |  |  | $ | 727 |  |  | $ | 682 |  |

[0001564590-19-041722:notes:79]
Asset-Based Lending Agreements

[0001564590-19-041722:notes:80]
During June 2019, the Company amended its U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and its Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans). The U.S. ABL credit facility was amended to extend its maturity to June 2024, decrease the size of the facility to $150,000 and add a $100,000 incremental facility. The Asia ABL credit facility was amended to extend the maturity to June 2024 and add a $50,000 incremental facility.

[0001564590-19-041722:notes:81]
The U.S. ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $50,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 125 basis points or an alternate base rate (defined as the greater of the prime rate, the New York Fed bank rate plus 0.5% or LIBOR plus 1.0%) subject to a 1.0% floor, plus an applicable margin of 25 basis points, at the Company’s option. As of September 30, 2019, the interest rate on the outstanding borrowings under the U.S. ABL was 3.27%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 150 basis points for LIBOR-based loans and from 25 to 50 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on June 3, 2024. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of September 30, 2019, $40,000 under the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-041722:notes:82]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. As of September 30, 2019, the interest rate on the outstanding borrowings under the Asia ABL was 3.42%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on June 4, 2024. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. As of September 30, 2019, $30,000 under the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-19-041722:notes:83]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of September 30, 2019, letters of credit in the amount of $13,640 were outstanding under the U.S. ABL and $24,522 were outstanding under the Asia ABL with various expiration dates through May 2020. Available borrowing capacity under the U.S. ABL and the Asia ABL was $96,360 and $95,478, respectively, which considers letters of credit outstanding as of September 30, 2019.

[0001564590-19-041722:notes:84]
The Company is required to pay a commitment fee of 0.25% per annum on any unused portion of the U.S. ABL and 0.28% per annum on any unused portion of the Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $144 and $251 for the quarters ended September 30, 2019 and October 1, 2018, respectively, and $594 and $739 for the three quarters ended September 30, 2019 and October 1, 2018, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0001564590-19-041722:notes:85]
Other Credit Facility

[0001564590-19-041722:notes:86]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $28,078 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver. In July 2019, the expiration of the Chinese Revolver was extended to July 2020. As of September 30, 2019, the Chinese Revolver had not been drawn upon.

[0001564590-19-041722:notes:87]
Debt Issuance and Debt Discount

[0001564590-19-041722:notes:88]
As of September 30, 2019 and December 31, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes were as follows:

[0001564590-19-041722:notes:89]
|  |  | As of September 30, 2019 |  |  |  | As of December 31, 2018 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Term Loan due September 2024 |  | $ | 6,986 |  |  | $ | 2,113 |  |  |  | 4.66 |  | % |  | $ | 8,229 |  |  | $ | 2,489 |  |  |  | 4.66 |  | % |
| Senior Notes due October 2025 |  |  | 5,509 |  |  | — |  |  |  | 5.92 |  |  |  |  | 6,071 |  |  | — |  |  |  | 5.92 |  |  |
| Convertible Senior Notes |  |  | 1,245 |  |  |  | 12,423 |  |  |  | 6.48 |  |  |  |  | 1,972 |  |  |  | 19,678 |  |  |  | 6.48 |  |  |
|  |  | $ | 13,740 |  |  | $ | 14,536 |  |  |  |  |  |  |  | $ | 16,272 |  |  | $ | 22,167 |  |  |  |  |  |  |

[0001564590-19-041722:notes:90]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-19-041722:notes:91]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,654 and $1,420 as of September 30, 2019 and December 31, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0001564590-19-041722:notes:92]
As of September 30, 2019, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.5 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-041722:notes:93]
[same as prior period, unchanged from 0001564590-19-030026:notes:89]

[0001564590-19-041722:notes:94]
The Company’s effective tax rate is impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items.

[0001564590-19-041722:notes:95]
During the quarter and three quarters ended September 30, 2019, the Company’s effective tax rate was impacted by a net discrete expense of $1,222 and a net discrete benefit of $2,067, respectively. This is related to accrued interest expense on existing uncertain tax positions and return to provision expense incurred in the current quarter which is offset by the release of uncertain tax positions due to the expiration of the statute of limitations in foreign jurisdictions as reported in the prior quarter. Additionally, no tax benefit was recorded on the losses incurred in certain foreign jurisdictions as a result of corresponding increases in the valuation allowances in these jurisdictions.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-19-041722:notes:96]
[same as prior period, unchanged from 0001564590-19-030026:notes:93]

[0001564590-19-041722:notes:97]
[same as prior period, unchanged from 0001564590-19-030026:notes:94]

[0001564590-19-041722:notes:98]
[same as prior period, unchanged from 0001564590-19-030026:notes:95]

[0001564590-19-041722:notes:99]
[same as prior period, unchanged from 0001564590-19-030026:notes:96]

[0001564590-19-041722:notes:100]
[same as prior period, unchanged from 0001564590-19-030026:notes:97]

[0001564590-19-041722:notes:101]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of September 30, 2019, the fair value of the interest rate swap was recorded as a liability in the amount of $14,013 and included as a component of other long-term liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax. No ineffectiveness was recognized for the quarter and three quarters ended September 30, 2019 and October 1, 2018. The interest rate swap increased interest expense by $602 and $752 for the quarters ended September 30, 2019 and October 1, 2018, respectively, and $1,308 and $1,055 for the three quarters ended September 30, 2019 and October 1, 2018, respectively.

[0001564590-19-041722:notes:102]
[same as prior period, unchanged from 0001564590-19-030026:notes:99]

[0001564590-19-041722:notes:103]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than its functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts as of September 30, 2019 and December 31, 2018 was approximately $2,518 and $4,313, respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-19-041722:notes:104]
[same as prior period, unchanged from 0001564590-19-030026:notes:101]

[0001564590-19-041722:notes:105]
|  |  |  |  | Asset / (Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | September 30, 2019 |  |  | December 31, 2018 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other long-term liabilities |  | $ | (14,013 | ) |  | $ | (4,735 | ) |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | 28 |  |  |  | — |  |
| Foreign exchange contracts |  | Other current liabilities |  |  | (3 | ) |  |  | (139 | ) |

[0001564590-19-041722:notes:106]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the quarter and three quarters ended September 30, 2019 and October 1, 2018:

[0001564590-19-041722:notes:107]
|  |  |  | Quarter Ended September 30, 2019 |  |  | Quarter Ended October 1, 2018 |  |
|  | Financial Statement Caption |  | Gain (Loss) Recognized in Other Comprehensive Income |  |  | Loss Reclassified into Income |  |  | Gain Recognized in Other Comprehensive Income |  |  | Loss Reclassified into Income |  |
|  |  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap | Interest expense |  | $ | (1,923 | ) |  | $ | (602 | ) |  | $ | 1,641 |  |  | $ | (752 | ) |
| Foreign currency forward | Depreciation expense |  |  | 1 |  |  |  | (39 | ) |  | — |  |  |  | (12 | ) |

[0001564590-19-041722:notes:108]
|  |  |  | Three Quarters September 30, 2019 |  |  | Three Quarters October 1, 2018 |  |
|  | Financial Statement Caption |  | Loss Recognized in Other Comprehensive Income |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Income |  |  | Loss Reclassified into Income |  |
|  |  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap | Interest expense |  | $ | (10,586 | ) |  | $ | (1,308 | ) |  | $ | (78 | ) |  | $ | (1,055 | ) |
| Foreign currency forward | Depreciation expense |  |  | (4 | ) |  |  | (117 | ) |  |  | (26 | ) |  |  | (92 | ) |

[0001564590-19-041722:notes:109]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the three quarters ended September 30, 2019 and October 1, 2018:

[0001564590-19-041722:notes:110]
|  |  | Three Quarters Ended |  |
|  |  | September 30, |  |  | October 1, |  |
|  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | (4,214 | ) |  | $ | (742 | ) |
| Changes in fair value loss, net of tax |  |  | (8,164 | ) |  |  | (104 | ) |
| Reclassification to earnings |  |  | 1,128 |  |  |  | 1,147 |  |
| Ending balance, net of tax |  | $ | (11,250 | ) |  | $ | 301 |  |

[0001564590-19-041722:notes:111]
Based on the current yield curve, the Company expects that losses of approximately $3,702 of the accumulated other comprehensive loss will be reclassified into the statement of operations, net of tax, during the next twelve months.

[0001564590-19-041722:notes:112]
[same as prior period, unchanged from 0001564590-19-030026:notes:108]

[0001564590-19-041722:notes:113]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, |  |  | October 1, |  |  | September 30, |  |  | October 1, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (16 | ) |  | $ | (197 | ) |  | $ | 33 |  |  | $ | (94 | ) |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-19-041722:notes:114]
[same as prior period, unchanged from 0001564590-19-030026:notes:110]

[0001564590-19-041722:notes:115]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of September 30, 2019 and December 31, 2018:

[0001564590-19-041722:notes:116]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | Gains / (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of December 31, 2018 |  | $ | 1,578 |  |  | $ | (1,284 | ) |  | $ | (4,214 | ) |  | $ | (3,920 | ) |
| Other comprehensive loss before reclassifications |  |  | (925 | ) |  |  | (4 | ) |  |  | (8,164 | ) |  |  | (9,093 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | — |  |  |  | 1,128 |  |  |  | 1,128 |  |
| Other comprehensive loss |  |  | (925 | ) |  |  | (4 | ) |  |  | (7,036 | ) |  |  | (7,965 | ) |
| Ending balance as of September 30, 2019 |  | $ | 653 |  |  | $ | (1,288 | ) |  | $ | (11,250 | ) |  | $ | (11,885 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-19-041722:notes:117]
[same as prior period, unchanged from 0001564590-19-030026:notes:113]

[0001564590-19-041722:notes:118]
[same as prior period, unchanged from 0001564590-19-030026:notes:114]

[0001564590-19-041722:notes:119]
[same as prior period, unchanged from 0001564590-19-030026:notes:115]

[0001564590-19-041722:notes:120]
For the quarters ended September 30, 2019 and October 1, 2018, one customer accounted for approximately 20% of the Company’s net sales. For the three quarters ended September 30, 2019 and October 1, 2018, one customer accounted for approximately 13% and 15%, respectively, of the Company’s net sales. There were no other customers that accounted for 10% or more of net sales for the quarter and three quarters ended September 30, 2019 and October 1, 2018.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-19-041722:notes:121]
[same as prior period, unchanged from 0001564590-19-030026:notes:117]

[0001564590-19-041722:notes:122]
[same as prior period, unchanged from 0001564590-19-030026:notes:118]

[0001564590-19-041722:notes:123]
The carrying amount and estimated fair value of the Company’s financial instruments as of September 30, 2019 and December 31, 2018 were as follows:

[0001564590-19-041722:notes:124]
|  |  | As of |  |  | As of |  |
|  |  | September 30, 2019 |  |  | December 31, 2018 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative liabilities, current |  | $ | — |  |  | $ | — |  |  | $ | 139 |  |  | $ | 139 |  |
| Derivative liabilities, non-current |  |  | 14,013 |  |  |  | 14,013 |  |  |  | 4,735 |  |  |  | 4,735 |  |
| Term Loan due September 2024 |  |  | 796,780 |  |  |  | 806,887 |  |  |  | 825,161 |  |  |  | 782,592 |  |
| Senior Notes due October 2025 |  |  | 369,491 |  |  |  | 377,809 |  |  |  | 368,929 |  |  |  | 350,880 |  |
| Convertible Senior Notes |  |  | 236,307 |  |  |  | 332,742 |  |  |  | 228,335 |  |  |  | 290,858 |  |
| ABL Revolving Loans |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |

[0001564590-19-041722:notes:125]
[same as prior period, unchanged from 0001564590-19-030026:notes:121]

[0001564590-19-041722:notes:126]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of September 30, 2019 and December 31, 2018, which are considered Level 2 inputs.

[0001564590-19-041722:notes:127]
[same as prior period, unchanged from 0001564590-19-030026:notes:123]

[0001564590-19-041722:notes:128]
As of September 30, 2019 and December 31, 2018, the Company’s other financial instruments also included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of September 30, 2019 consisted of $65,888 held in the U.S., with the remaining $250,701 held by foreign subsidiaries.

[0001564590-19-041722:notes:129]
[same as prior period, unchanged from 0001564590-19-030026:notes:125]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-041722:notes:130]
(14) Commitments and Contingencies

[0001564590-19-041722:notes:131]
Legal Matters

[0001564590-19-041722:notes:132]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 30, 2019 and December 31, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-041722:notes:133]
[same as prior period, unchanged from 0001564590-19-030026:notes:129]

[0001564590-19-041722:notes:134]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the quarter and three quarters ended September 30, 2019 and October 1, 2018:

[0001564590-19-041722:notes:135]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, 2019 |  |  | October 1, 2018 |  |  | September 30, 2019 |  |  | October 1, 2018 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic earnings |  | $ | 15,870 |  |  | $ | 27,001 |  |  | $ | 16,042 |  |  | $ | 121,102 |  |
| Diluted earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 15,870 |  |  | $ | 27,001 |  |  | $ | 16,042 |  |  | $ | 121,102 |  |
| Interest expense from Convertible Senior Notes, net of tax |  |  | 2,836 |  |  |  | 3,628 |  |  |  | — |  |  |  | 10,763 |  |
| Diluted earnings |  | $ | 18,706 |  |  | $ | 30,629 |  |  | $ | 16,042 |  |  | $ | 131,865 |  |
| Basic weighted average shares |  |  | 105,492 |  |  |  | 103,676 |  |  |  | 105,092 |  |  |  | 103,246 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 982 |  |  |  | 1,595 |  |  |  | 973 |  |  |  | 1,600 |  |
| Dilutive effect of outstanding warrants |  |  | — |  |  |  | 5,226 |  |  |  | — |  |  |  | 4,086 |  |
| Dilutive effect of assumed conversion of Convertible Senior Notes outstanding |  |  | 25,938 |  |  |  | 25,938 |  |  |  | — |  |  |  | 25,939 |  |
| Diluted shares |  |  | 132,412 |  |  |  | 136,435 |  |  |  | 106,065 |  |  |  | 134,871 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.15 |  |  | $ | 0.26 |  |  | $ | 0.15 |  |  | $ | 1.17 |  |
| Diluted |  | $ | 0.14 |  |  | $ | 0.22 |  |  | $ | 0.15 |  |  | $ | 0.98 |  |

[0001564590-19-041722:notes:136]
Performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock options to purchase 407 and 30 shares of common stock for the quarters ended September 30, 2019 and October 1, 2018, respectively, and 862 and 335 shares of common stock for the three quarters ended September 30, 2019 and October 1, 2018, respectively, were not included in the computation of diluted earnings per share because the options’ exercise prices or the total expected proceeds under the treasury stock method for PRUs, RSUs, or stock options was greater than the average market price of common shares during the applicable quarter and three quarters and, as a result, the impact would be anti-dilutive.

[0001564590-19-041722:notes:137]
Outstanding warrants for the quarter and three quarters ended September 30, 2019, to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock were greater than the average market price of common shares during the applicable quarter, and therefore, the effect would be anti-dilutive.

[0001564590-19-041722:notes:138]
For the three quarters ended September 30, 2019, the effect of shares of common stock related to the Company’s Convertible Senior Notes, based on the if-converted method, were not included in the computation of dilutive earnings per share as the impact would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-19-041722:notes:139]
[same as prior period, unchanged from 0001564590-19-030026:notes:135]

[0001564590-19-041722:notes:140]
[same as prior period, unchanged from 0001564590-19-030026:notes:136]

[0001564590-19-041722:notes:141]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, |  |  | October 1, |  |  | September 30, |  |  | October 1, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 941 |  |  | $ | 774 |  |  | $ | 2,216 |  |  | $ | 2,132 |  |
| Selling and marketing |  |  | 593 |  |  |  | 520 |  |  |  | 1,455 |  |  |  | 1,439 |  |
| General and administrative |  |  | 3,128 |  |  |  | 4,165 |  |  |  | 8,519 |  |  |  | 11,377 |  |
| Stock-based compensation expense recognized |  | $ | 4,662 |  |  | $ | 5,459 |  |  | $ | 12,190 |  |  | $ | 14,948 |  |

[0001564590-19-041722:notes:142]
[same as prior period, unchanged from 0001564590-19-030026:notes:138]

[0001564590-19-041722:notes:143]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is typically awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period will range from zero to 2.4 times the target number depending on performance during the period. The performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and EBITDA (earnings before interest, tax, depreciation, and amortization expense), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three-year performance period.

[0001564590-19-041722:notes:144]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. As of September 30, 2019, management determined that vesting of the PRU awards was probable. PRUs activity for the three quarters ended September 30, 2019 was as follows:

[0001564590-19-041722:notes:145]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Outstanding shares as of December 31, 2018 |  |  | 255 |  |  | $ | 18.75 |  |
| Granted |  |  | 293 |  |  |  | 10.17 |  |
| Change in units due to annual performance achievement |  |  | (73 | ) |  |  | 10.15 |  |
| Forfeited / cancelled |  |  | (6 | ) |  |  | 15.18 |  |
| Outstanding shares as of September 30, 2019 |  |  | 469 |  |  | $ | 14.78 |  |

[0001564590-19-041722:notes:146]
[same as prior period, unchanged from 0001564590-19-030026:notes:148]

[0001564590-19-041722:notes:147]
The Company granted 50 and 5 RSUs during the quarters ended September 30, 2019 and October 1, 2018, respectively, and 1,649 and 1,028 RSUs during the three quarters ended September 30, 2019 and October 1, 2018, respectively. The RSUs granted have a weighted-average fair value per unit of $10.74 and $17.57 for the quarters ended September 30, 2019 and October 1, 2018, respectively, and $10.06 and $15.45 for the three quarters ended September 30, 2019 and October 1, 2018, respectively. The fair value for RSUs granted is based on the closing share price of the Company’s common stock on the date of grant.

[0001564590-19-041722:notes:148]
[same as prior period, unchanged from 0001564590-19-030026:notes:150]

[0001564590-19-041722:notes:149]
The Company did not grant stock option awards during the quarter and three quarters ended September 30, 2019, or during the quarter ended October 1, 2018. During the three quarters ended October 1, 2018, the Company granted 20 stock option awards to a newly appointed member of the board which were estimated to have a fair value per share of $8.92. The fair value calculation is based on stock options granted during the period using the Black-Scholes option-pricing model on the date of grant. For the three quarters ended October 1, 2018, the fair value was determined using 3% as the risk-free interest rate, 43% as the expected volatility, 8.5 years as the expected term and no dividend yield.

[0001564590-19-041722:notes:150]
[same as prior period, unchanged from 0001564590-19-030026:notes:152]

[0001564590-19-041722:notes:151]
The following is a summary of total unrecognized compensation costs as of September 30, 2019:

[0001564590-19-041722:notes:152]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 23,494 |  |  |  | 1.5 |  |
| PRU awards |  |  | 2,252 |  |  |  | 1.2 |  |
| Stock options |  |  | 271 |  |  |  | 1.8 |  |
|  |  | $ | 26,017 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-041722:notes:153]
[same as prior period, unchanged from 0001564590-19-030026:notes:155]

[0001564590-19-041722:notes:154]
[same as prior period, unchanged from 0001564590-19-030026:notes:156]

[0001564590-19-041722:notes:155]
[same as prior period, unchanged from 0001564590-19-030026:notes:157]

[0001564590-19-041722:notes:156]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 30, 2019 |  |  | October 1, 2018 |  |  | September 30, 2019 |  |  | October 1, 2018 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 649,104 |  |  | $ | 696,356 |  |  | $ | 1,791,047 |  |  | $ | 1,967,832 |  |
| E-M Solutions |  |  | 67,713 |  |  |  | 59,481 |  |  |  | 179,008 |  |  |  | 168,474 |  |
| Total net sales |  | $ | 716,817 |  |  | $ | 755,837 |  |  | $ | 1,970,055 |  |  | $ | 2,136,306 |  |
| Operating Segment Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 73,230 |  |  | $ | 98,039 |  |  | $ | 182,761 |  |  | $ | 242,467 |  |
| E-M Solutions |  |  | 3,236 |  |  |  | 2,205 |  |  |  | 5,278 |  |  |  | 4,741 |  |
| Corporate |  |  | (28,750 | ) |  |  | (26,920 | ) |  |  | (75,537 | ) |  |  | (86,799 | ) |
| Total operating segment income |  |  | 47,716 |  |  |  | 73,324 |  |  |  | 112,502 |  |  |  | 160,409 |  |
| Amortization of definite-lived intangibles (1) |  |  | (11,355 | ) |  |  | (18,774 | ) |  |  | (41,807 | ) |  |  | (44,124 | ) |
| Total operating income |  |  | 36,361 |  |  |  | 54,550 |  |  |  | 70,695 |  |  |  | 116,285 |  |
| Total other expense, net |  |  | (12,442 | ) |  |  | (20,012 | ) |  |  | (50,910 | ) |  |  | (49,141 | ) |
| Income before income taxes |  | $ | 23,919 |  |  | $ | 34,538 |  |  | $ | 19,785 |  |  | $ | 67,144 |  |

[0001564590-19-041722:notes:157]
| (1) | Amortization of definite-lived intangibles primarily relates to the PCB reportable segment. For the quarter and three quarters ended September 30, 2019, $1,180 and $3,539, respectively, of amortization expense is included in cost of goods sold. For both the quarter and three quarters ended October 1, 2018, $2,165 of amortization expense is included in cost of goods sold. |

[0001564590-19-041722:notes:158]
[same as prior period, unchanged from 0001564590-19-030026:notes:160]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001564590-19-041722:notes:159]
(18) Related Party Transactions

[0001564590-19-041722:notes:160]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a member of the Board of Directors of the Company holds an equity interest. The Company’s foreign subsidiaries purchased laminate and prepreg from these related parties in the amount of $8,005 and $10,437 for the quarters ended September 30, 2019 and October 1, 2018, respectively, and $25,234 and $35,695 for the three quarters ended September 30, 2019 and October 1, 2018, respectively.

[0001564590-19-041722:notes:161]
As of September 30, 2019 and December 31, 2018, the Company’s consolidated condensed balance sheets included $10,290 and $10,630, respectively, in accounts payable due to related parties for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-19-041722:notes:162]
[same as prior period, unchanged from 0001564590-19-030026:notes:164]

[0001564590-19-041722:notes:163]
The Company periodically incurs restructuring charges as part of the integration process of recent acquisitions and to realign its operations with anticipated market demand. The Company recognized employee separation, contract termination and other costs during the quarter and three quarters ended September 30, 2019. Contract termination and other costs primarily represented plant closure costs.

[0001564590-19-041722:notes:164]
The below table summarizes such restructuring costs by reportable segment for the quarter and three quarters ended September 30, 2019:

[0001564590-19-041722:notes:165]
|  |  | Quarter Ended September 30, 2019 |  |  | Three Quarters Ended September 30, 2019 |  |
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 45 |  |  | $ | — |  |  | $ | 45 |  |  | $ | 4,258 |  |  | $ | — |  |  | $ | 4,258 |  |
| E-M Solutions |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Corporate |  |  | — |  |  |  | 7 |  |  |  | 7 |  |  |  | 160 |  |  |  | 24 |  |  |  | 184 |  |
|  |  | $ | 45 |  |  | $ | 7 |  |  | $ | 52 |  |  | $ | 4,418 |  |  | $ | 24 |  |  | $ | 4,442 |  |

[0001564590-19-041722:notes:166]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated condensed balance sheet. The below table shows the utilization of the accrued restructuring costs during the three quarters ended September 30, 2019:

[0001564590-19-041722:notes:167]
|  |  | Employee separation/ severance |  |  | Contract termination and other costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued at December 31, 2018 |  | $ | 3,158 |  |  | $ | 393 |  |  | $ | 3,551 |  |
| Charged to expense |  |  | 4,418 |  |  |  | 24 |  |  |  | 4,442 |  |
| Amount paid |  |  | (6,018 | ) |  |  | (105 | ) |  |  | (6,123 | ) |
| Accrued at September 30, 2019 |  | $ | 1,558 |  |  | $ | 312 |  |  | $ | 1,870 |  |
