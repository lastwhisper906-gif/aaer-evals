# TTMI MD&A — 0001564590-18-011836


## mdna

[0001564590-18-011836:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001564590-18-011836:mdna:2]
[same as prior period, unchanged from 0001193125-17-337320:mdna:16]

[0001564590-18-011836:mdna:3]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs and electro-mechanical solutions (E-M Solutions). We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop manufacturing solution to our customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 2,000 customers in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, and medical, industrial and instrumentation related products as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-18-011836:mdna:4]
RECENT DEVELOPMENTS

[0001564590-18-011836:mdna:5]
On April 18, 2018, we completed our acquisition to purchase all of the issued and outstanding common stock of Anaren Holding Corp. for total consideration of $775.0 million cash subject to customary working capital and certain other adjustments. Other than the equity interests of Anaren, Inc. (Anaren), Anaren Holding Corp. has no material assets or liabilities and has no material independent operations. Anaren is a leading provider of mission-critical radio frequency (RF) solutions, microelectronics, and microwave components and assemblies for the wireless infrastructure and space and defense electronics markets.

[0001564590-18-011836:mdna:6]
Additionally, we closed our $600.0 million commitment for incremental loans concurrent with the completion of our acquisition of Anaren. We used the proceeds of the incremental loan, along with cash on hand to fund the purchase price of the Anaren acquisition and to pay related fees and expenses.

[0001564590-18-011836:mdna:7]
FINANCIAL OVERVIEW

[0001564590-18-011836:mdna:8]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our 10 largest customers accounted for 45% of our net sales for both the quarters ended April 2, 2018 and April 3, 2017. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-18-011836:mdna:9]
[same as prior period, unchanged from 0001193125-17-337320:mdna:22]

[0001564590-18-011836:mdna:10]
|  |  | Quarter Ended |  |  |
| End Markets(1)(2) |  | April 2, 2018 |  |  |  | April 3, 2017 |  |  |
| Aerospace and Defense |  |  | 18 |  | % |  |  | 15 |  | % |
| Automotive |  |  | 20 |  |  |  |  | 20 |  |  |
| Cellular Phone(2) |  |  | 15 |  |  |  |  | 14 |  |  |
| Computing/Storage/Peripherals(2) |  |  | 12 |  |  |  |  | 15 |  |  |
| Medical/Industrial/Instrumentation |  |  | 15 |  |  |  |  | 15 |  |  |
| Networking/Communications |  |  | 16 |  |  |  |  | 20 |  |  |
| Other(3) |  |  | 4 |  |  |  |  | 1 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-18-011836:mdna:11]
[same as prior period, unchanged from 0001193125-17-337320:mdna:24]

[0001564590-18-011836:mdna:12]
| (2) | Smartphones are included in the Cellular Phone end market, tablets are included in the Computing/Storage/Peripherals end market and other consumer devices include wearables, portable video devices and personal headphones are included in the Other end market. |

[0001564590-18-011836:mdna:13]
| (3) | Revenue recognized progressively over time based on the extent of progress towards completion of the performance obligation, which has not yet been shipped, is included in Other end market along with consumer devices such as wearables, portable video devices and personal headphones. |

[0001564590-18-011836:mdna:14]
[same as prior period, unchanged from 0001193125-17-337320:mdna:18]

[0001564590-18-011836:mdna:15]
We derive revenues primarily from the sale of PCBs and custom electronic assemblies using customer-supplied engineering and design plans. Orders for products generally correspond to the production schedules of our customers and are supported with firm purchase orders. Our customers have continuous transfer of control of the work in progress and finished goods as PCBs are being manufactured, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by our right to payment for work performed to date, plus a reasonable profit. As a result, and in light of our adoption of the new “overtime” revenue standard as further discussed below in the “CRITICAL ACCOUNTING POLICIES AND ESTIMATES,” beginning in the first quarter of 2018, we recognized revenue progressively over time based on the extent of progress towards completion of the performance obligation rather than upon shipment as we had in the past.

[0001564590-18-011836:mdna:16]
The selection of the method to measure progress toward completion requires judgment and is based on the type of PCB or customized electronic assemblies being manufactured. We use the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

[0001564590-18-011836:mdna:17]
Net sales consist of gross sales less an allowance for returns, which typically have been less than 2% of gross sales. We provide our customers a limited right of return for defective PCBs and backplane assemblies. We record an estimate for sales returns and allowances at the time of sale based on historical results.

[0001564590-18-011836:mdna:18]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including capacity utilization, product mix, production volume, and yield. We generally do not participate in any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for the raw materials we use.

[0001564590-18-011836:mdna:19]
Selling and marketing expenses consist primarily of salaries, labor related benefits, and commissions paid to our internal sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0001564590-18-011836:mdna:20]
General and administrative costs primarily include the salaries for executive, finance, accounting, information technology, facilities and human resources personnel, as well as expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant and equipment.

[0001564590-18-011836:mdna:21]
[same as prior period, unchanged from 0001193125-17-337320:mdna:31]

[0001564590-18-011836:mdna:22]
Our consolidated condensed financial statements included in this report have been prepared in accordance with U.S. GAAP. The preparation of these financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001564590-18-011836:mdna:23]
See Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, in our Annual Report on Form 10-K for the fiscal year ended January 1, 2018 for further discussion of critical accounting policies and estimates. There were no material changes to our critical accounting policies and estimates since January 1, 2018, except for the adoption of Accounting Standards Update (ASU) 2014-09, Revenue from Contracts with Customers (new revenue standard) on January 2, 2018.

[0001564590-18-011836:mdna:24]
The new revenue standard replaces most existing revenue recognition guidance in U.S. GAAP, including industry specific requirements, and provides companies with a single revenue recognition model for recognizing revenue of contracts with customers. The core principle of the new revenue standard is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the company expects to be entitled in exchange for those goods or services.  We assessed the new guidance and adopted the new revenue standard on January 2, 2018, which resulted in a change to the timing of revenue recognition for our revenue stream from “point in time” upon physical delivery to an “over time” model.

[0001564590-18-011836:mdna:25]
[same as prior period, unchanged from 0001193125-17-337320:mdna:34]

[0001564590-18-011836:mdna:26]
The following table sets forth the relationship of various items to net sales in our consolidated condensed statements of operations:

[0001564590-18-011836:mdna:27]
|  |  | Quarter Ended |  |  |
|  |  | April 2, 2018 |  |  |  | April 3, 2017 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 86.6 |  |  |  |  | 83.2 |  |  |
| Gross profit |  |  | 13.4 |  |  |  |  | 16.8 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.7 |  |  |  |  | 2.7 |  |  |
| General and administrative |  |  | 5.3 |  |  |  |  | 4.8 |  |  |
| Amortization of definite-lived intangibles |  |  | 0.9 |  |  |  |  | 0.9 |  |  |
| Total operating expenses |  |  | 8.9 |  |  |  |  | 8.4 |  |  |
| Operating income |  |  | 4.5 |  |  |  |  | 8.4 |  |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.1 | ) |  |  |  | (2.2 | ) |  |
| Other, net |  |  | (0.1 | ) |  |  |  | (0.2 | ) |  |
| Total other expense, net |  |  | (2.2 | ) |  |  |  | (2.4 | ) |  |
| Income before income taxes |  |  | 2.3 |  |  |  |  | 6.0 |  |  |
| Income tax provision |  |  | (0.8 | ) |  |  |  | (0.7 | ) |  |
| Net income |  |  | 1.5 |  |  |  |  | 5.3 |  |  |
| Less: Net income attributable to the non- controlling interest |  |  | — |  |  |  |  | — |  |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  |  | 1.5 |  | % |  |  | 5.3 |  | % |

[0001564590-18-011836:mdna:28]
We have two reportable segments: PCB and E-M Solutions. The PCB reportable segment is comprised of multiple operating segments. Factors considered in determining whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production process, type or class of customers, distribution methods and regulatory environments.

[0001564590-18-011836:mdna:29]
The following table compares net sales by reportable segment for the quarters ended April 2, 2018 and April 3, 2017:

[0001564590-18-011836:mdna:30]
|  |  | Quarter Ended |  |
|  |  | April 2, 2018 |  |  | April 3, 2017 |  |
|  |  | (In thousands) |  |
| Net Sales |  |  |  |  |  |  |  |  |
| PCB |  | $ | 619,329 |  |  | $ | 586,695 |  |
| E-M Solution |  |  | 47,151 |  |  |  | 41,669 |  |
| Total sales |  |  | 666,480 |  |  |  | 628,364 |  |
| Inter-segment sales |  |  | (2,898 | ) |  |  | (3,117 | ) |
| Total net sales |  | $ | 663,582 |  |  | $ | 625,247 |  |

[0001564590-18-011836:mdna:31]
[same as prior period, unchanged from 0001193125-17-337320:mdna:40]

[0001564590-18-011836:mdna:32]
Total net sales increased $38.4 million, or 6.1%, from $625.2 million for the quarter ended April 3, 2017 to $663.6 million for the quarter ended April 2, 2018.

[0001564590-18-011836:mdna:33]
Net sales for the PCB operating segment, excluding inter-segment sales, increased $32.8 million, or 5.6%, from $583.6 million for the quarter ended April 3, 2017 to $616.4 million for the quarter ended April 2, 2018. This increase is primarily due to higher sales in our Aerospace/Defense and Cellular Phone end markets combined with a $13.8 million increase related to the adoption of the new revenue standard. Higher sales were the result of an average PCB selling price increase of 4.7%, which was driven mainly by product mix shift, and a 1.1% decrease in PCB shipments as compared to the quarter ended April 3, 2017.

[0001564590-18-011836:mdna:34]
Net sales for the E-M Solutions operating segment increased $5.5 million from $41.7 million for the quarter ended April 3, 2017 to $47.2 million for the quarter ended April 2, 2018. Higher sales were due to higher demand in our Automotive end market.

[0001564590-18-011836:mdna:35]
[same as prior period, unchanged from 0001193125-17-337320:mdna:43]

[0001564590-18-011836:mdna:36]
Overall gross margin decreased from 16.8% for the quarter ended April 3, 2017 to 13.4% for the quarter ended April 2, 2018. Gross margin for the PCB operating segment decreased from 18.2% for the quarter ended April 3, 2017 to 14.3% for the quarter ended April 2, 2018 primarily due to lower capacity utilization at our Cellular Phone, Networking/Communications and Computing/Storage/ Peripherals focused facilities, a strengthening Chinese Renminbi which negatively impacted our operating costs, and the absence of $3.0 million insurance settlement received in 2017. Gross margin for the E-M Solutions operating segment increased from 2.7% for the quarter ended April 3, 2017 to 5.5% for the quarter ended April 2, 2018 primarily due to higher volumes and lower inventory reserves.

[0001564590-18-011836:mdna:37]
Capacity utilization is a key driver for us, particularly in our high volume Asia facilities, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the first quarter of 2017 in our Asia and North America PCB facilities was 81% and 57%, respectively, compared to 78% and 61%, respectively, in the first quarter of 2018.

[0001564590-18-011836:mdna:38]
[same as prior period, unchanged from 0001193125-17-337320:mdna:48]

[0001564590-18-011836:mdna:39]
Selling and marketing expenses increased $0.9 million, from $16.7 million for the quarter ended April 3, 2017 to $17.6 million for the quarter ended April 2, 2018. As a percentage of net sales, selling and marketing expenses was 2.7% for both of the quarter ended April 2, 2018 and April 3, 2017. The increase in selling and marketing expense primarily relates to higher labor, commission and travel expenses.

[0001564590-18-011836:mdna:40]
[same as prior period, unchanged from 0001193125-17-337320:mdna:51]

[0001564590-18-011836:mdna:41]
General and administrative expenses increased $5.3 million from $29.9 million, or 4.8% of net sales, for the quarter ended April 3, 2017 to $35.2 million, or 5.3% of net sales, for the quarter ended April 2, 2018. The increase in expense primarily relates to $4.0 million of acquisition-related costs associated with the acquisition of Anaren on April 18, 2018.

[0001564590-18-011836:mdna:42]
[same as prior period, unchanged from 0001193125-17-337320:mdna:53]

[0001564590-18-011836:mdna:43]
Other expense, net decreased $0.4 million from $15.3 million for the quarter ended April 3, 2017 to $14.9 million for the quarter ended April 2, 2018. The decrease in other expense, net was primarily due to a decrease in foreign currency losses for the quarter ended April 2, 2018 as compared to the quarter ended April 3, 2017 due to the appreciation of the Chinese Renminbi (RMB), which is utilized at our China facilities for employee-related expenses, foreign currency denominated purchases, and other costs of running our operations in China. Further our translation of balance sheet accounts denominated in foreign currencies could be impacted if foreign exchange rates between those currencies (principally the RMB) and the U.S. Dollar change.

[0001564590-18-011836:mdna:44]
[same as prior period, unchanged from 0001193125-17-337320:mdna:55]

[0001564590-18-011836:mdna:45]
The provision for income taxes increased by $1.0 million from $4.1 million for the quarter ended April 3, 2017 to $5.1 million for the quarter ended April 2, 2018. The increase in income tax expense in 2018 was primarily due to the absence of a benefit that was recognized in the same period in 2017, specifically, the receipt of China’s high and new technology enterprise status in one of our subsidiaries in the quarter ended April 3, 2017, which resulted in a tax incentive benefit effective retroactively to 2016.

[0001564590-18-011836:mdna:46]
Effects of the Tax Cuts and Jobs Act

[0001564590-18-011836:mdna:47]
On December 22, 2017, the Tax Cuts and Jobs Act (Tax Act) was enacted. Accounting Standards Codification (ASC) 740, Accounting for Income Taxes, requires companies to recognize the effect of tax law changes in the period of enactment regardless of the effective date of those tax law changes. Certain provisions of the Tax Act were effective September 27, 2017, others were effective or identified as of December 31, 2017 or January 1, 2018.

[0001564590-18-011836:mdna:48]
Given the timing of enactment of the Tax Act and the significance of the legislation, the SEC staff issued Staff Accounting Bulletin No. 118 (SAB 118), which allows registrants to record provisional amounts during a one year “measurement period” similar to that used when accounting for business combinations. However, the measurement period should not extend beyond one year from the Tax Act enactment date and is deemed to have ended when the registrant has obtained, prepared and analyzed the information necessary to finalize its accounting.

[0001564590-18-011836:mdna:49]
To the extent that a company’s accounting for certain income tax effects of the Tax Act is incomplete but is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 740 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the Tax Act. More specifically, SAB 118 summarizes a three-step process to be applied at each reporting period to account for and disclose the tax effects of the Tax Act. The steps are (1) to record the effects of the change in tax law for which accounting is complete; (2) to record provisional amounts (or adjustments to provisional amounts) for the effects of the tax law where accounting is not complete, but for which a reasonable estimate has been determined; and (3) where a reasonable estimate cannot yet be made, to continue to apply ASC 740 based on the tax law in effect prior to enactment of the Tax Act.

[0001564590-18-011836:mdna:50]
With respect to the reduction in the U.S. corporate income tax rate to 21 percent, we revalued our ending gross deferred tax items, previously recorded at 35 percent, using the enacted 21 percent corporate tax rate. This change caused a reduction to our U.S. federal deferred tax asset fully offset by a reduction of our valuation allowance. While we are able to make a reasonable estimate of the impact of the reduction in corporate rate, it may be affected by other analyses related to the Tax Act, including, but not limited to, our calculation of deemed repatriation of deferred foreign income and the state tax effect of adjustments made to federal temporary differences, as well as changes to our valuation allowance.

[0001564590-18-011836:mdna:51]
Further effects of tax law changes where we have made a provisional estimate include the one-time mandatory repatriation transition tax on the net accumulated earnings and profits of our foreign subsidiaries earned post 1986. We have performed a preliminary earnings and profits analysis with consideration given to foreign loss carryforwards acquired as a result of our acquisitions and determined that there should be no income tax effect in the current or any future period. We will continue to identify and evaluate data to more thoroughly identify the tax impact and record adjustments, if any, within the measurement period.

[0001564590-18-011836:mdna:52]
We have determined that the following provisions that are effective January 1, 2018 and relevant to us will not impact the current quarter tax expense, primarily as a result of the full valuation allowance in the U.S.: limitations on certain entertainment expenses, the inclusion of commissions and performance based compensation in determining the excessive compensation limitation, limitation on the current deductibility of net interest expense in excess of 30 percent of adjusted taxable income, and a minimum tax on certain foreign earnings in excess of 10 percent of the foreign subsidiaries tangible assets (i.e., global intangible low-taxed income or GILTI). We are still evaluating whether to make a policy election to treat the GILTI tax as a period expense or to provide U.S. deferred taxes on foreign earnings that are expected to generate GILTI income when they reverse in future years.

[0001564590-18-011836:mdna:53]
In addition, significant judgment is required in determining our worldwide provision for income taxes. In the ordinary course of our business, there are many transactions for which the ultimate tax determination is uncertain. Additionally, our calculations of income taxes are based on our interpretations of applicable tax laws in the jurisdictions in which we file.

[0001564590-18-011836:mdna:54]
Our effective tax rate was primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of other credits and deductions available to us, as well as changes in valuation allowances, and certain non-deductible items. Certain foreign losses generated are not more likely than not to be realizable, and thus no income tax benefit has been recognized on these losses. We had a net deferred income tax liability of approximately $7.8 million and $4.9 million as of April 2, 2018 and January 1, 2018, respectively.

[0001564590-18-011836:mdna:55]
Liquidity and Capital Resources

[0001564590-18-011836:mdna:56]
Our principal sources of liquidity have been cash provided by operations, the issuance of senior notes, convertible senior notes, and term and revolving debt. Our principal uses of cash have been to finance acquisitions and capital expenditures, meet debt service requirements, fund working capital requirements, and repay existing debt. We anticipate that servicing debt, financing capital expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001564590-18-011836:mdna:57]
Cash flow used in operating activities during the quarter ended April 2, 2018 was $14.3 million as compared to $49.6 million of cash flow provided by operating activities in the same period in 2017. The decrease in cash flow was due to increased investment in working capital and a decrease in net income. Cash cycle days increased to 48 days for the quarter ended April 2, 2018 as compared to 46 days for the quarter ended April 3, 2017. As of April 2, 2018, we had net working capital of approximately $570.1 million compared to $501.0 million as of January 1, 2018.

[0001564590-18-011836:mdna:58]
Net cash used in investing activities was approximately $42.1 million and $23.4 million for the quarters ended April 2, 2018 and April 3, 2017, respectively, primarily reflecting net purchases of property, plant and equipment.

[0001564590-18-011836:mdna:59]
Net cash used in financing activities was approximately $0.9 million for the quarter ended April 2, 2018 reflecting repayment of long-term debt. Net cash provided by financing activities was approximately $0.1 million for the quarter ended April 3, 2017 reflecting proceeds from the exercise of common stock options.

[0001564590-18-011836:mdna:60]
As of April 2, 2018, we had cash and cash equivalents of approximately $352.6 million, of which approximately $164.8 million was held by our foreign subsidiaries, primarily in China. Cash and cash equivalents held by our foreign locations are expected to be used in local operations.

[0001564590-18-011836:mdna:61]
Our 2018 net capital expenditures are expected to be in the range of $150.0 million to $170.0 million.

[0001564590-18-011836:mdna:62]
[same as prior period, unchanged from 0001193125-17-337320:mdna:66]

[0001564590-18-011836:mdna:63]
[same as prior period, unchanged from 0001193125-17-337320:mdna:68]

[0001564590-18-011836:mdna:64]
During the fiscal year 2017, we entered into a $350.0 million Term Loan Facility due 2024. The Term Loan Facility, of which $3.5 million is included in short-term debt and $344.8 million is included in long-term debt, was issued at a discount at 99.5% and bears interest, at our option, at a floating rate of LIBOR, plus an applicable interest margin of 2.5%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.9% or LIBOR plus 1%), subject to a 1% floor plus an applicable margin of 1.5%. At April 2, 2018, the interest rate on the outstanding borrowings under the Term Loan Facility was 4.38%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of our domestic assets and a pledge of 65% of voting stock of our first tier foreign subsidiaries and is structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-18-011836:mdna:65]
We are required to make scheduled payments of the outstanding Term Loan Facility on a quarterly basis beginning January 1, 2018. Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, we may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if our First Lien Leverage Ratio is greater than 2.0. Any additional annual payments or prepayments would reduce future required scheduled payments. Any remaining outstanding balance under the Term Loan Facility are due at the maturity date of September 28, 2024.

[0001564590-18-011836:mdna:66]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments. At April 2, 2018, we were in compliance with the covenants under the Term Loan Facility.

[0001564590-18-011836:mdna:67]
Subsequent to the quarter ended April 2, 2018, we closed on our $600.0 million commitment of incremental loans concurrent with the completion of our acquisition of Anaren on April 18, 2018. We used the proceeds of the incremental loan, along with cash on hand to fund the purchase price of the Anaren acquisition and to pay related fees and expenses.

[0001564590-18-011836:mdna:68]
[same as prior period, unchanged from 0001193125-17-337320:mdna:72]

[0001564590-18-011836:mdna:69]
The $375.0 million of Senior Notes, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

[0001564590-18-011836:mdna:70]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. At April 2, 2018, we were in compliance with the covenants under the Senior Notes.

[0001564590-18-011836:mdna:71]
Convertible Senior Notes due 2020

[0001564590-18-011836:mdna:72]
We maintain 1.75% convertible senior notes in the amount of $250.0 million due December 15, 2020. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the convertible senior notes.

[0001564590-18-011836:mdna:73]
[same as prior period, unchanged from 0001193125-17-337320:mdna:77]

[0001564590-18-011836:mdna:74]
We maintain a $200.0 million U.S. Asset-Based Lending Credit Agreement (U.S. ABL), and a $150.0 million Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans).

[0001564590-18-011836:mdna:75]
The U.S. ABL consists of three tranches comprised of a revolving credit facility of up to $200.0 million, a letter of credit facility for up to $50.0 million, and swingline loans for up to $30.0 million, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 125 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 25 basis points, at our option. At April 2, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 3.13%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and certain inventories as well as by a second position against a significant amount of our domestic assets and a pledge of 65% of the voting stock of our first tier foreign subsidiaries and are structurally senior to our Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes elsewhere in this section. At April 2, 2018, $17.0 million of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-18-011836:mdna:76]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150.0 million and a letter of credit facility for up to $100.0 million, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At April 2, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.28%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of our Asia cash and receivables and are structurally senior to our domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes elsewhere in this section. At April 2, 2018, $30.0 million of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-18-011836:mdna:77]
We have up to $50.0 million and $100.0 million Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of April 2, 2018, letters of credit in the amount of $7.3 million were outstanding under the U.S. ABL and $27.0 million were outstanding under the Asia ABL with various expiration dates through June 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $175.7 million and $93.0 million, respectively, which considers letters of credit outstanding at April 2, 2018.

[0001564590-18-011836:mdna:78]
We are required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the ABL Revolving Loans. We paid commitment fees of $0.2 million for both of the quarters ended April 2, 2018 and April 3, 2017, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. At April 2, 2018, we were in compliance with the covenants under the ABL Revolving Loans.

[0001564590-18-011836:mdna:79]
Other Credit Facility

[0001564590-18-011836:mdna:80]
Additionally, we are party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to us approximately $33.4 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2019. As of April 2, 2018, the Chinese Revolver had not been drawn upon.

[0001564590-18-011836:mdna:81]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently anticipated capital expenditure, debt service, and working capital needs for the next 12 months.

[0001564590-18-011836:mdna:82]
Contractual Obligations and Commitments

[0001564590-18-011836:mdna:83]
The following table provides information on our contractual obligations as of April 2, 2018:

[0001564590-18-011836:mdna:84]
|  |  | Total |  |  | Less Than 1 year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 772,237 |  |  | $ | 4,616 |  |  | $ | 53,996 |  |  | $ | 7,875 |  |  | $ | 705,750 |  |
| Convertible debt obligations |  |  | 249,985 |  |  |  | — |  |  |  | 249,985 |  |  |  | — |  |  |  | — |  |
| Interest on debt obligations |  |  | 272,362 |  |  |  | 42,693 |  |  |  | 72,526 |  |  |  | 82,686 |  |  |  | 74,457 |  |
| Purchase obligations |  |  | 115,364 |  |  |  | 105,303 |  |  |  | 1,254 |  |  |  | 635 |  |  |  | 8,172 |  |
| Operating lease commitments |  |  | 32,702 |  |  |  | 15,043 |  |  |  | 8,128 |  |  |  | 3,508 |  |  |  | 6,023 |  |
| Total contractual obligations |  | $ | 1,442,650 |  |  | $ | 167,655 |  |  | $ | 385,889 |  |  | $ | 94,704 |  |  | $ | 794,402 |  |

[0001564590-18-011836:mdna:85]
| (1) | Unrecognized uncertain tax benefits of $42.1 million are not included in the table above as the settlement timing is uncertain. |

[0001564590-18-011836:mdna:86]
[same as prior period, unchanged from 0001193125-17-337320:mdna:89]

[0001564590-18-011836:mdna:87]
We do not currently have, nor have we ever had, any relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, which would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes. In addition, we do not engage in trading activities involving non-exchange traded contracts. As a result, we are not materially exposed to any financing, liquidity, market, or credit risk that could arise if we had engaged in these relationships.

[0001564590-18-011836:mdna:88]
[same as prior period, unchanged from 0001193125-17-337320:mdna:91]

[0001564590-18-011836:mdna:89]
Orders for our products generally correspond to the production schedules of our customers. We historically experience higher net sales in the third and fourth quarters due to end customer demand in the fourth quarter for consumer electronics products. Seasonal fluctuations also include the Chinese New Year holidays in the first quarter, which typically results in lower net sales. We attribute this decline to shutdowns of our customers’ and our own China based manufacturing facilities surrounding the Chinese New Year public holidays, which normally occur in January or February of each year.
