# TTMI note change history — 0001193125-17-337320 → 0001564590-18-011836


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001564590-18-011836:note_history:1]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 2, 2018 and January 1, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.
  (was, 2017-11-08, similarity 0.992):
[0001193125-17-337320:note_history:1]
The Company is subject to various legal matters, which it
 considers normal for its business activities. While the Company
 currently believes that the amount of any reasonably possible loss
 for known matters would not be material to the Company’s
 financial condition, the outcome of these actions is inherently
 difficult to predict. In the event of an adverse outcome, the
 ultimate potential loss could have a material adverse effect on the
 Company’s financial condition or results of operations in a
 particular period. The Company has accrued amounts for its loss
 contingencies which are probable and estimable as of
 October 2, 2017 and January 2, 2017. However, these
 amounts are not material to the consolidated condensed financial
 statements of the Company.

- added (2018-05-08):
[0001564590-18-011836:note_history:2]
The process to manufacture PCBs requires adherence to city, county, state, federal, and foreign environmental regulations regarding the storage, use, handling and disposal of chemicals, solid wastes and other hazardous materials, as well as compliance with air quality standards and chemical use reporting. The Company believes that its facilities in the United States and Canada comply in all material respects with applicable environmental laws and regulations. In China, governmental authorities have adopted new rules and regulations governing environmental issues. An update to the Chinese environmental waste water law was issued in late 2012, allowing for an interim period in which plants subject to such law may install equipment that meets the new regulatory regime. Some of the Company’s plants in China are not yet in full compliance with the updated environmental regulations. The Company has established and enacted an investment plan related to the efforts to come into full compliance with the new regulations. The 2018 capital expenditure costs expected for these plans are included in the Company’s capital expenditure projections.

- removed (2018-05-08):
[0001193125-17-337320:note_history:3]
The process to manufacture PCBs requires adherence to domestic
 and foreign jurisdictional environmental laws regulations regarding
 the storage, use, handling, recycling and disposal of liquid and
 solid wastes, as well as compliance with air quality standards and
 chemical use reporting. The Company believes that its facilities in
 North America comply in all material respects with applicable
 environmental laws and regulations. In China, governmental
 authorities have adopted new rules and regulations governing
 environmental issues. The Company believes it has developed plans
 acceptable to the Chinese government and is in the process of
 implementing these plans. The Company does not anticipate any
 immediate risk of government fines or temporary closure of its
 Chinese plants. The Company has established and enacted an
 investment plan related to the efforts to come into full compliance
 with the new regulations in a timely fashion. The 2017 capital
 expenditure costs expected for these plans are included in the
 Company’s capital expenditure projections.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-05-08):
[0001564590-18-011836:note_history:4]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2014-09, Revenue from Contracts with Customers (Topic 606), which replaces most existing revenue recognition guidance in U.S. GAAP, including industry specific requirements, and provides companies with a single revenue recognition model for recognizing revenue of contracts with customers. The core principle of the new revenue standard is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the company expects to be entitled in exchange for those goods or services.

- added (2018-05-08):
[0001564590-18-011836:note_history:5]
The Company assessed the new guidance and adopted the new revenue standard on January 2, 2018, which resulted in a change to the timing of revenue recognition for the Company’s revenue stream from “point in time” upon physical delivery to an “over time” model. Additionally, the Company has elected the cumulative effect transition method with adjustment to the opening balance of retained earnings at January 2, 2018 for all open contracts as of January 1, 2018. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet at January 1, 2018 and the consolidated condensed statement of operations for the quarter ended April 3, 2017.

- added (2018-05-08):
[0001564590-18-011836:note_history:6]
The cumulative effect of the changes made to the Company’s January 2, 2018 consolidated condensed balance sheet for the adoption of the new revenue standard were as follows:

- added (2018-05-08):
[0001564590-18-011836:note_history:7]
|  |  | Balance at January 1, 2018 |  |  | New Revenue Standard Adjustment |  |  | Balance at January 2, 2018 |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 483,903 |  |  | $ | 8,171 |  |  | $ | 492,074 |  |
| Contract assets |  |  | — |  |  |  | 260,654 |  |  |  | 260,654 |  |
| Inventories |  |  | 294,588 |  |  |  | (223,576 | ) |  |  | 71,012 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 114,685 |  |  |  | 13,384 |  |  |  | 128,069 |  |
| Other long-term liabilities |  |  | 74,667 |  |  |  | 3,291 |  |  |  | 77,958 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 193,342 |  |  |  | 28,574 |  |  |  | 221,916 |  |

- added (2018-05-08):
[0001564590-18-011836:note_history:8]
As part of adoption of the new revenue standard, the Company recorded an estimated sales returns and allowance as well as a noncurrent deferred tax liability in the amount of $5,213 and $3,291, respectively, as of January 2, 2018.  Additionally, the Company reclassified its sales returns and allowance balance of $8,171 as of January 1, 2018, from trade accounts receivable to other accrued liabilities. Sales returns and allowances are recorded as a reduction of revenue and a component of accrued liabilities on the condensed consolidated balance sheet.

- added (2018-05-08):
[0001564590-18-011836:note_history:9]
Additionally, the below disclosure summarizes the impact of the adoption of new revenue standard on the Company’s consolidated condensed balance sheet, statement of operations and statement of cash flows for the quarter ended April 2, 2018 for which the As Reported reflects the new revenue standard and Balances without New Revenue Standard Adjustment reflects the Company’s replaced revenue recognition policy of “point in time” and upon physical delivery.

- added (2018-05-08):
[0001564590-18-011836:note_history:10]
|  |  | April 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 504,914 |  |  | $ | 8,171 |  |  | $ | 496,743 |  |
| Contract assets |  |  | 275,022 |  |  |  | 275,022 |  |  |  | — |  |
| Inventories |  |  | 82,116 |  |  |  | (235,557 | ) |  |  | 317,673 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 102,162 |  |  |  | 13,671 |  |  |  | 88,491 |  |
| Other long-term liabilities |  |  | 77,078 |  |  |  | 3,163 |  |  |  | 73,915 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 232,013 |  |  |  | 30,801 |  |  |  | 201,212 |  |

- added (2018-05-08):
[0001564590-18-011836:note_history:11]
|  |  | April 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Net sales |  | $ | 663,582 |  |  | $ | 14,081 |  |  | $ | 649,501 |  |
| Cost of goods sold |  |  | 574,904 |  |  |  | 11,981 |  |  |  | 562,923 |  |
| Gross profit |  |  | 88,678 |  |  |  | 2,100 |  |  |  | 86,578 |  |
| Net income |  |  | 10,097 |  |  |  | 2,227 |  |  |  | 7,870 |  |

- added (2018-05-08):
[0001564590-18-011836:note_history:12]
|  |  | April 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,097 |  |  | $ | 2,227 |  |  | $ | 7,870 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Other |  |  | (439 | ) |  |  | (127 | ) |  |  | (312 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (12,840 | ) |  |  | — |  |  |  | (12,840 | ) |
| Contract assets |  |  | (14,368 | ) |  |  | (14,368 | ) |  |  | — |  |
| Inventories |  |  | (11,104 | ) |  |  | 11,981 |  |  |  | (23,085 | ) |
| Accrued salaries, wages and benefits and other accrued expenses |  |  | (47,566 | ) |  |  | 287 |  |  |  | (47,853 | ) |

- changed (2018-05-08):
[0001564590-18-011836:note_history:13]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.
  (was, 2017-11-08, similarity 0.9468):
[0001193125-17-337320:note_history:13]
In August 2017, the Financial Accounting Standards Board (FASB)
 issued Accounting Standards Update (ASU) 2017-12, Derivatives and Hedging
 (Topic 815): Targeted Improvements to Accounting for Hedging
 Activities. This ASU amends and simplifies existing guidance in
 order to allow companies to more accurately present the economic
 effects of risk management activities in the financial statements.
 ASU 2017-12 also amends
 the guidance surrounding the recognition of the value of hedged
 instruments to include the entire change in value, rather than just
 the effective portion, in other comprehensive income and recognized
 in earnings at the same time that the hedged item affects earnings
 for cash flow and net investment hedges. This ASU is effective for
 fiscal years beginning after December 15, 2018, including
 interim periods within those fiscal years. Early adoption is
 permitted. The Company is currently evaluating the new guidance to
 determine the impact it may have on its consolidated condensed
 financial statements and related disclosures.

- changed (2018-05-08):
[0001564590-18-011836:note_history:14]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those annual periods and is to be applied utilizing a modified retrospective approach. While the Company continues to evaluate the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, the primary effect of adopting this update will be to record assets and liabilities for existing operating leases.
  (was, 2017-11-08, similarity 0.9618):
[0001193125-17-337320:note_history:14]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842).
 The objective of this update is to increase transparency and
 comparability among organizations by recognizing lease assets and
 lease liabilities on the balance sheet and disclosing key
 information about leasing arrangements. This ASU is effective for
 fiscal years beginning after December 15, 2018, including
 interim periods within those annual periods and is to be applied
 utilizing a modified retrospective approach. While the Company
 continues to evaluate the new guidance to determine the impact it
 may have on its consolidated condensed financial statements and
 related disclosures, the primary effect of adopting this update
 will be to record assets and obligations for current operating
 leases.

- removed (2018-05-08):
[0001193125-17-337320:note_history:15]
In January 2017, the FASB issued ASU 2017-04, Intangibles (Topic 350):
 Goodwill and Other. This ASU simplifies the accounting for
 goodwill impairment and removes Step 2 of the goodwill impairment
 test. Goodwill impairment will now be the amount by which a
 reporting unit’s carrying value exceeds its fair value
 limited to the total amount of goodwill allocated to that reporting
 unit. Entities will continue to have the option to perform a
 qualitative assessment to determine if a quantitative impairment
 test is necessary. The Company elected to early adopt ASU
 2017-04 on a prospective
 basis during the second quarter of 2017, and the adoption did
 not have a material impact on its consolidated condensed financial
 statements and related disclosures.

- removed (2018-05-08):
[0001193125-17-337320:note_history:16]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740):
 Intra-Entity Transfers of Assets Other Than Inventory. The
 objective of this update is to improve the accounting for the
 income tax consequences of intra-entity transfers of assets other
 than inventory by recognizing the income tax consequences when the
 transfer occurs. This ASU is effective for fiscal years beginning
 after December 15, 2017, including interim periods within
 those fiscal years. Early adoption is permitted. The adoption of
 this standard is not expected to have a material impact on the
 Company’s consolidated condensed financial statements or
 related disclosures.

- removed (2018-05-08):
[0001193125-17-337320:note_history:17]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows
 (Topic 230). The objective of this update is to add or clarify
 guidance on the classification of certain cash receipts and
 payments in the statement of cash flows. This ASU is effective for
 fiscal years beginning after December 15, 2017, including
 interim periods within those annual periods and is to be applied
 utilizing a retrospective approach. Early adoption is permitted.
 The Company adopted this ASU 2016-15 in the first quarter of 2017
 and the adoption did not have a material impact on its consolidated
 condensed financial statements and related disclosures.

- removed (2018-05-08):
[0001193125-17-337320:note_history:18]
In March 2016, the FASB issued ASU 2016-09, Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment Accounting.
 The objective of this update is to simplify several aspects of the
 accounting for employee share-based payment transactions, including
 the income tax consequences, classification of awards as either
 equity or liabilities, and classification on the statement of cash
 flows. This ASU is effective for fiscal years beginning after
 December 15, 2016, including interim periods within those
 fiscal years. The Company adopted ASU 2016-09 on January 3, 2017. The
 adoption did not have a material impact on the consolidated
 condensed financial statements and related disclosures.

- removed (2018-05-08):
[0001193125-17-337320:note_history:19]
In January 2016, the FASB issued ASU 2016-01, Financial
 Instruments—Overall (Topic 825): Recognition and
 Measurement of Financial Assets and Financial Liabilities. This
 ASU amends certain aspects of recognition, measurement,
 presentation and disclosure of financial instruments, and
 supersedes the guidance to classify equity securities with readily
 determinable fair values into different categories (that is,
 trading or available-for-sale) and
 requires equity securities to be measured at fair value with
 changes in the fair value recognized through net income. This ASU
 is effective for annual and interim periods beginning after
 December 15, 2017. The Company does not anticipate the
 adoption will have a material impact on its consolidated condensed
 financial statements and related disclosures.

- removed (2018-05-08):
[0001193125-17-337320:note_history:20]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts
 with Customers, as amended, which requires an entity to
 recognize the amount of revenue to which it expects to be entitled
 for the transfer of promised goods or services to customers. The
 ASU will replace most existing revenue recognition guidance in U.S.
 GAAP when it becomes effective. The new standard is effective for
 the Company at the beginning of fiscal year 2018. The standard
 permits the use of either the retrospective or cumulative effect
 transition method. The Company has assessed that the impact of the
 new guidance will result in a change to the timing of revenue
 recognition for the Company’s revenue stream from
 “point in time” upon physical delivery to an
 “over time” model and believes this transition could
 have a material impact on the Company’s consolidated
 financial statements upon adoption. As of October 2, 2017,
 management intends to apply the cumulative effect transition
 method. The Company has identified and implemented changes to its
 processes and internal controls to meet the standard update’s
 reporting and disclosure requirements.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2018-05-08):
[0001564590-18-011836:note_history:21]
(2) Summary of Significant Accounting Policies

- added (2018-05-08):
[0001564590-18-011836:note_history:22]
Revenue Recognition

- added (2018-05-08):
[0001564590-18-011836:note_history:23]
The Company derives revenues primarily from the sale of PCBs and custom electronic assemblies using customer-supplied engineering and design plans. Orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous transfer of control of the work in progress and finished goods as PCBs are being manufactured, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, in light of the Company’s adoption of the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation─Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.

- added (2018-05-08):
[0001564590-18-011836:note_history:24]
The selection of the method to measure progress toward completion requires judgment and is based on the type of PCB or customized electronic assemblies being manufactured. The Company uses the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

- added (2018-05-08):
[0001564590-18-011836:note_history:25]
The Company provides customers a limited right of return for defective PCBs and backplane assemblies. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from our historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.

- added (2018-05-08):
[0001564590-18-011836:note_history:26]
The Company has two revenue streams which coincide with the Company’s reportable segments of PCB and E-M Solutions. See Note 14 Segment Information.


## ttmi:ScheduleOfComponentsOfInterestExpenseFromConvertibleNotesTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001564590-18-011836:note_history:27]
The components of interest expense resulting from the convertible senior notes for the quarters ended April 2, 2018 and April 3, 2017 are as follows:
  (was, 2017-11-08, similarity 0.873):
[0001193125-17-337320:note_history:27]
The components of interest expense resulting from the
 convertible senior notes for the quarters and three quarters ended
 October 2, 2017 and September 26, 2016 are as
 follows:

- added (2018-05-08):
[0001564590-18-011836:note_history:28]
|  |  | Quarter Ended |  |
|  |  | April 2, |  |  | April 3, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,230 |  |  | $ | 2,091 |  |
| Amortization of debt issuance costs |  | $ | 224 |  |  | $ | 209 |  |

- removed (2018-05-08):
[0001193125-17-337320:note_history:29]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | October 2, 2017 |  |  | September 26, 2016 |  |  | October 2, 2017 |  |  | September 26, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,159 |  |  | $ | 2,025 |  |  | $ | 6,376 |  |  | $ | 5,977 |  |
| Amortization of debt issuance costs |  | $ | 216 |  |  | $ | 202 |  |  | $ | 639 |  |  | $ | 599 |  |


## ttmi:ScheduleOfUnamortizedDiscountAndDebtIssuanceCostsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001564590-18-011836:note_history:30]
As of April 2, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2017-11-08, similarity 0.916):
[0001193125-17-337320:note_history:30]
As of October 2, 2017 and January 2, 2017, remaining
 unamortized debt discount and debt issuance costs for the Term Loan
 Facility, Senior Notes, Convertible Senior Notes and 2016 Term Loan
 are as follows:

- added (2018-05-08):
[0001564590-18-011836:note_history:31]
|  |  | As of April 2, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 2,695 |  |  | $ | 1,636 |  |  |  | 3.96 | % |  | $ | 2,788 |  |  | $ | 1,691 |  |  |  | 3.96 | % |
| Senior Notes due October 2025 |  |  | 6,608 |  |  | — |  |  |  | 5.92 | % |  |  | 6,782 |  |  | — |  |  |  | 5.92 | % |
| Convertible Senior Notes |  |  | 2,665 |  |  |  | 26,589 |  |  |  | 6.48 | % |  |  | 2,889 |  |  |  | 28,822 |  |  |  | 6.48 | % |
|  |  | $ | 11,968 |  |  | $ | 28,225 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |

- removed (2018-05-08):
[0001193125-17-337320:note_history:32]
|  |  | As of October 2, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 2,803 |  |  | $ | 1,750 |  |  |  | 3.95 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Senior Notes due October 2025 |  |  | 6,849 |  |  |  | — |  |  |  | 5.91 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Convertible Senior Notes |  |  | 3,108 |  |  |  | 31,014 |  |  |  | 6.48 | % |  | $ | 3,747 |  |  | $ | 37,392 |  |  |  | 6.48 | % |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 977 |  |  |  | — |  |  |  | 5.48 | % |
|  |  | $ | 12,760 |  |  | $ | 32,764 |  |  |  |  |  |  | $ | 4,724 |  |  | $ | 37,392 |  |  |  |  |  |


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001564590-18-011836:note_history:33]
As of April 2, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:
  (was, 2017-11-08, similarity 0.9669):
[0001193125-17-337320:note_history:33]
As of October 2, 2017 and January 2, 2017, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:

- changed (2018-05-08):
[0001564590-18-011836:note_history:34]
|  |  | As of April 2, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |
  (was, 2017-11-08, similarity 0.6812):
[0001193125-17-337320:note_history:34]
|  |  | As of October 2, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001564590-18-011836:note_history:35]
The following table summarizes the long-term debt of the Company as of April 2, 2018 and January 1, 2018:
  (was, 2017-11-08, similarity 0.949):
[0001193125-17-337320:note_history:35]
The following table summarizes the long-term debt of the
 Company as of October 2, 2017 and January 2,
 2017:

- added (2018-05-08):
[0001564590-18-011836:note_history:36]
|  |  | Interest Rate as of April 2, 2018 |  |  | Principal Outstanding as of April 2, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.38% |  |  | $ | 348,250 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.13% |  |  |  | 17,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.28% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  | 6.43% |  |  |  | 1,987 |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,022,222 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (28,225 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (11,968 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 982,029 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (4,616 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 977,413 |  |  |  |  |  |  | $ | 975,479 |  |

- changed (2018-05-08):
[0001564590-18-011836:note_history:37]
During the fiscal year 2017, the Company entered into a $350,000 Term Loan Facility due 2024. The Term Loan Facility, of which $3,500 is included in short-term debt and $344,750 is included in long-term debt, was issued at a discount at 99.5% and bears interest, at the Company’s option, at a floating rate of LIBOR, plus an applicable interest margin of 2.5%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.9% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At April 2, 2018 the interest rate on the outstanding borrowings under the Term Loan Facility was 4.38%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.
  (was, 2017-11-08, similarity 0.9511):
[0001193125-17-337320:note_history:37]
The Term Loan Facility, of which $3,500 is included in
 short-term debt and $346,500 is included in long-term debt, was
 issued at a discount at 99.5% and bears interest, at the
 Company’s option, at a floating rate of LIBOR, plus an
 applicable interest margin of 2.5%, or an alternate base rate,
 (defined as the greater of the JP Morgan prime, the New York Fed
 bank rate plus 0.9% or LIBOR plus 1.0%), subject to a 1.0% floor
 plus an applicable margin of 1.5%. At October 2, 2017 the
 interest rate on the outstanding borrowings under the Term Loan
 Facility was 3.73%. There is no provision, other than an event of
 default, for the interest margin to increase. The Term Loan
 Facility will mature on September 28, 2024. The Term Loan
 Facility is secured by a significant amount of the assets of the
 Company and a pledge of 65% of voting stock of the Company’s
 first tier foreign subsidiaries and is structurally senior to the
 Company’s Senior Notes and Convertible Senior Notes. See
 Senior Notes and Convertible Senior Notes below.

- changed (2018-05-08):
[0001564590-18-011836:note_history:38]
The Company is required to make scheduled payments of the outstanding Term Loan Facility on a quarterly basis beginning January 1, 2018. Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. Any additional annual payments or prepayments would reduce future required scheduled payments. Any remaining outstanding balance under the Term Loan Facility are due at the maturity date of September 28, 2024.
  (was, 2017-11-08, similarity 0.9927):
[0001193125-17-337320:note_history:38]
The Company is required to make scheduled payments of the
 outstanding Term Loan Facility balance on a quarterly basis
 beginning January 1, 2018. Based on certain parameters defined
 in the Term Loan Facility, including a First Lien Leverage Ratio,
 the Company may be required to make an additional principal payment
 on an annual basis beginning after fiscal year 2018, if the
 Company’s First Lien Leverage Ratio is greater than 2.0. Any
 additional annual payments or prepayments would reduce future
 required scheduled payments. Any remaining outstanding balances
 under the Term Loan Facility are due at the maturity date of
 September 28, 2024.

- changed (2018-05-08):
[0001564590-18-011836:note_history:39]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.
  (was, 2017-11-08, similarity 0.9279):
[0001193125-17-337320:note_history:39]
Borrowings under the Senior Notes are subject to certain
 affirmative and negative covenants, including limitations on
 indebtedness, corporate transactions, investments and dispositions,
 and share payments.

- changed (2018-05-08):
[0001564590-18-011836:note_history:40]
The $375,000 of Senior Notes, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.
  (was, 2017-11-08, similarity 0.7297):
[0001193125-17-337320:note_history:40]
The $375,000 of Senior Notes issued, which is included in
 long-term debt, bear interest at a rate of 5.63% per annum.
 Interest is payable semiannually in arrears on April 1 and
 October 1 of each year beginning April 1, 2018. The
 Senior Notes will mature on October 1, 2025. The Senior Notes
 are unsecured obligations and are guaranteed by the Company’s
 subsidiaries that guarantee its senior secured credit facilities,
 subject to certain exceptions.

- changed (2018-05-08):
[0001564590-18-011836:note_history:41]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.
  (was, 2017-11-08, similarity 0.6197):
[0001193125-17-337320:note_history:41]
Borrowings under the Term Loan Facility are subject to certain
 affirmative and negative covenants, including limitations on
 indebtedness, corporate transactions, investments and dispositions,
 and share payments. The Company and its domestic subsidiaries have
 fully and unconditionally guaranteed the full and timely payment of
 Term Loan Facility related obligations.

- changed (2018-05-08):
[0001564590-18-011836:note_history:42]
The Company maintains 1.75% convertible senior notes in the amount of $249,985 due December 15, 2020. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness.
  (was, 2017-11-08, similarity 0.9343):
[0001193125-17-337320:note_history:42]
The Company maintains 1.75% convertible senior notes in the
 amount of $249,985 due December 15, 2020. The convertible
 senior notes bear interest at a rate of 1.75% per annum.
 Interest is payable semiannually in arrears on June 15 and
 December 15 of each year. The convertible senior notes are
 unsecured obligations, are subordinated to the Senior Notes above,
 and would rank equally to the Company’s future unsecured
 senior indebtedness and are senior in right of payment to any of
 the Company’s future subordinated indebtedness.

- changed (2018-05-08):
[0001564590-18-011836:note_history:43]
As of April 2, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:
  (was, 2017-11-08, similarity 0.9669):
[0001193125-17-337320:note_history:43]
As of October 2, 2017 and January 2, 2017, the
 following summarizes the equity components of the convertible
 senior notes included in additional paid-in capital:

- changed (2018-05-08):
[0001564590-18-011836:note_history:44]
|  |  | As of April 2, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |
  (was, 2017-11-08, similarity 0.6812):
[0001193125-17-337320:note_history:44]
|  |  | As of October 2, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |

- changed (2018-05-08):
[0001564590-18-011836:note_history:45]
The components of interest expense resulting from the convertible senior notes for the quarters ended April 2, 2018 and April 3, 2017 are as follows:
  (was, 2017-11-08, similarity 0.873):
[0001193125-17-337320:note_history:45]
The components of interest expense resulting from the
 convertible senior notes for the quarters and three quarters ended
 October 2, 2017 and September 26, 2016 are as
 follows:

- added (2018-05-08):
[0001564590-18-011836:note_history:46]
|  |  | Quarter Ended |  |
|  |  | April 2, |  |  | April 3, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,230 |  |  | $ | 2,091 |  |
| Amortization of debt issuance costs |  | $ | 224 |  |  | $ | 209 |  |

- changed (2018-05-08):
[0001564590-18-011836:note_history:47]
The Company maintains a $200,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL), and a $150,000 Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans).
  (was, 2017-11-08, similarity 0.9628):
[0001193125-17-337320:note_history:47]
The Company continues to maintain a $200,000 U.S. Asset-Based
 Lending Credit Agreement (U.S. ABL), and a $150,000 Asia
 Asset-Based Lending Credit Agreement (Asia ABL) (collectively the
 ABL Revolving Loans).

- changed (2018-05-08):
[0001564590-18-011836:note_history:48]
The U.S. ABL consists of three tranches comprised of a revolving credit facility for up to $200,000, a letter of credit facility for up to $50,000, and swingline loans for up to $30,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 125 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 25 basis points, at the Company’s option. At April 2, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 3.13%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At April 2, 2018, $17,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.
  (was, 2017-11-08, similarity 0.8938):
[0001193125-17-337320:note_history:48]
The U.S. ABL consists of three tranches comprised of a
 revolving credit facility of up to $200,000, a letter of credit
 facility of up to $50,000, and swingline loans of up to $30,000,
 provided that at no time may amounts outstanding under the tranches
 exceed in aggregate $200,000 or the applicable borrowing base,
 which is a percentage of the principal amount of Eligible Accounts,
 as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL
 bear interest at either a floating rate of LIBOR plus a margin of
 150 basis points or JP Morgan Chase Bank’s prime rate plus a
 margin of 50 basis points, at the Company’s option. At
 October 2, 2017, the interest rate on the outstanding
 borrowings under the U.S. ABL was 2.73%. The applicable margin can
 vary based on the remaining availability of the facility, from 125
 to 175 basis points for LIBOR-based loans and from 25 to 75 basis
 points for JP Morgan Chase Bank’s prime rate-based loans.
 Other than availability and an event of default, there are no other
 provisions for the interest margin to increase. The U.S. ABL will
 mature on May 31, 2020. Loans made under the U.S. ABL are
 secured first by all of the Company’s domestic cash,
 receivables and inventories as well as by a second position against
 a significant amount of the assets of the Company and a pledge of
 65% of voting stock of the Company’s first tier foreign
 subsidiaries and are structurally senior to the Company’s
 Senior Notes and Convertible Senior Notes. See Senior Notes and
 Convertible Senior Notes above. As noted earlier, concurrent with
 the issuance of the Term Loan Facility and Senior Notes, the
 Company paid down $63,000 of the outstanding balance of its U.S.
 ABL. The Company and its domestic subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of U.S. ABL
 related obligations. At October 2, 2017, $17,000 of the U.S.
 ABL was outstanding and classified as long-term debt, which is
 consistent with its maturity date.

- changed (2018-05-08):
[0001564590-18-011836:note_history:49]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At April 2, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.28%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At April 2, 2018, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.
  (was, 2017-11-08, similarity 0.9077):
[0001193125-17-337320:note_history:49]
The Asia ABL consists of two tranches comprised of a revolving
 credit facility of up to $150,000 and a letter of credit facility
 of up to $100,000, provided that at no time may amounts outstanding
 under both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 140 basis points. At October 2, 2017, the interest rate on the
 outstanding borrowings under the Asia ABL was 2.63%. There is no
 provision, other than an event of default, for the interest margin
 to increase. The Asia ABL will mature on May 22, 2020. Loans
 made under the Asia ABL are secured by a portion of the
 Company’s Asia Pacific cash and receivables and are
 structurally senior to the Company’s domestic obligations,
 including the Senior Notes and Convertible Senior Notes. See Senior
 Notes and Convertible Senior Notes above. The Company’s Asia
 Pacific subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At October 2, 2017, $30,000 of the
 Asia ABL was outstanding and classified as long-term debt, which is
 consistent with its maturity date.

- changed (2018-05-08):
[0001564590-18-011836:note_history:50]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of April 2, 2018, letters of credit in the amount of $7,252 were outstanding under the U.S. ABL and $26,976 were outstanding under the Asia ABL with various expiration dates through June 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $175,748 and $93,024, respectively, which considers letters of credit outstanding at April 2, 2018.
  (was, 2017-11-08, similarity 0.919):
[0001193125-17-337320:note_history:50]
The Company has up to $50,000 and $100,000 Letters of Credit
 Facilities under the U.S. ABL and the Asia ABL, respectively. As of
 October 2, 2017 letters of credit in the amount of $7,612 were
 outstanding under the U.S. ABL and $45,026 were outstanding under
 the Asia ABL with various expiration dates through March 2019.
 Available borrowing capacity under the U.S. ABL and the Asia ABL
 was $175,388 and $74,974, respectively, which considers letters of
 credit outstanding of $7,612 and $45,026, respectively, at
 October 2, 2017.

- added (2018-05-08):
[0001564590-18-011836:note_history:51]
The Company is required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $241 and $187 for the quarters ended April 2, 2018 and April 3, 2017, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

- changed (2018-05-08):
[0001564590-18-011836:note_history:52]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $33,400 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2019. As of April 2, 2018, the Chinese Revolver had not been drawn upon.
  (was, 2017-11-08, similarity 0.988):
[0001193125-17-337320:note_history:52]
Additionally, the Company is party to a revolving loan credit
 facility (Chinese Revolver) with a lender in China. Under this
 arrangement, the lender has made available to the Company
 approximately $31,700 in unsecured borrowing with all terms of the
 borrowing to be negotiated at the time the Chinese Revolver is
 drawn upon. There are no commitment fees on the unused portion of
 the Chinese Revolver, and this arrangement expires in January 2018.
 As of October 2, 2017, the Chinese Revolver had not been drawn
 upon.

- changed (2018-05-08):
[0001564590-18-011836:note_history:53]
As of April 2, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:
  (was, 2017-11-08, similarity 0.916):
[0001193125-17-337320:note_history:53]
As of October 2, 2017 and January 2, 2017, remaining
 unamortized debt discount and debt issuance costs for the Term Loan
 Facility, Senior Notes, Convertible Senior Notes and 2016 Term Loan
 are as follows:

- added (2018-05-08):
[0001564590-18-011836:note_history:54]
|  |  | As of April 2, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 2,695 |  |  | $ | 1,636 |  |  |  | 3.96 | % |  | $ | 2,788 |  |  | $ | 1,691 |  |  |  | 3.96 | % |
| Senior Notes due October 2025 |  |  | 6,608 |  |  | — |  |  |  | 5.92 | % |  |  | 6,782 |  |  | — |  |  |  | 5.92 | % |
| Convertible Senior Notes |  |  | 2,665 |  |  |  | 26,589 |  |  |  | 6.48 | % |  |  | 2,889 |  |  |  | 28,822 |  |  |  | 6.48 | % |
|  |  | $ | 11,968 |  |  | $ | 28,225 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |

- changed (2018-05-08):
[0001564590-18-011836:note_history:55]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,171 and $2,421 as of April 2, 2018 and January 1, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.
  (was, 2017-11-08, similarity 0.9414):
[0001193125-17-337320:note_history:55]
Debt issuance costs for the ABL Revolving Loans of $2,672 and
 $3,423 as of October 2, 2017 and January 2, 2017,
 respectively, are included in other non-current assets and are amortized
 to interest expense over the duration of the ABL Revolving Loans
 using the straight line method of amortization.

- changed (2018-05-08):
[0001564590-18-011836:note_history:56]
At April 2, 2018, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.8 years.
  (was, 2017-11-08, similarity 0.963):
[0001193125-17-337320:note_history:56]
At October 2, 2017, the remaining weighted average
 amortization period for all unamortized debt discount and debt
 issuance costs was 4.2 years.

- removed (2018-05-08):
[0001193125-17-337320:note_history:57]
|  |  | Interest Rate as of October 2, 2017 |  |  | Principal Outstanding as of October 2, 2017 |  |  | Interest Rate as of January 2, 2017 |  |  | Principal Outstanding as of January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 3.73 | % |  | $ | 350,000 |  |  |  | — |  |  |  | — |  |
| Senior Notes due October 2025 |  |  | 5.63 | % |  |  | 375,000 |  |  |  | — |  |  |  | — |  |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  |  | 5.25 | % |  | $ | 700,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 | % |  |  | 249,985 |  |  |  | 1.75 | % |  |  | 250,000 |  |
| U.S. ABL Revolving Loan due May 2020 |  |  | 2.73 | % |  |  | 17,000 |  |  |  | 2.27 | % |  |  | 80,000 |  |
| Asia ABL Revolving Loan due May 2020 |  |  | 2.63 | % |  |  | 30,000 |  |  |  | 2.17 | % |  |  | 30,000 |  |
| Capital Lease |  |  | 6.43 | % |  |  | 1,884 |  |  |  | 6.43 | % |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,023,869 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (32,764 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (12,760 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 978,345 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (4,184 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 974,161 |  |  |  |  |  |  | $ | 909,030 |  |

- removed (2018-05-08):
[0001193125-17-337320:note_history:58]
On September 28, 2017, the Company entered into a $350,000
 Term Loan Facility due 2024 (Term Loan Facility), and issued
 $375,000 of Senior Notes due 2025 (Senior Notes). In conjunction
 with the issuance of the Term Loan Facility and Senior Notes, the
 Company repaid in full the remaining outstanding balance of the
 September 27, 2016 Term Loan Credit Agreement (2016 Term Loan)
 and repaid $63,000 on its existing U.S. Asset-Based Lending Credit
 Agreement. The Company recognized a loss on extinguishment of debt
 of $768 primarily associated with the write off of the remaining
 2016 Term Loan debt issuance costs.

- removed (2018-05-08):
[0001193125-17-337320:note_history:59]
|  |  | For the Quarter Ended |  |  | For the Three Quarters Ended |  |
|  |  | October 2, 2017 |  |  | September 26, 2016 |  |  | October 2, 2017 |  |  | September 26, 2016 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |  | $ | 3,281 |  |  | $ | 3,281 |  |
| Amortization of debt discount |  | $ | 2,159 |  |  | $ | 2,025 |  |  | $ | 6,376 |  |  | $ | 5,977 |  |
| Amortization of debt issuance costs |  | $ | 216 |  |  | $ | 202 |  |  | $ | 639 |  |  | $ | 599 |  |

- removed (2018-05-08):
[0001193125-17-337320:note_history:60]
The Company is required to pay a commitment fee of 0.25% to
 0.375% per annum on any unused portion of the U.S ABL and the
 Asia ABL. The Company incurred total commitment fees related to
 unused borrowing availability of $179 and $171 for the quarters
 ended October 2, 2017 and September 26, 2016,
 respectively, and $546 and $516 for the three quarters ended
 October 2, 2017 and September 26, 2016,
 respectively.

- removed (2018-05-08):
[0001193125-17-337320:note_history:61]
Under the occurrence of certain events, the ABL Revolving Loans
 are subject to various financial and operational covenants,
 including maintaining minimum fixed charge coverage
 ratios.

- removed (2018-05-08):
[0001193125-17-337320:note_history:62]
|  |  | As of October 2, 2017 |  |  | As of January 2, 2017 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 2,803 |  |  | $ | 1,750 |  |  |  | 3.95 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Senior Notes due October 2025 |  |  | 6,849 |  |  |  | — |  |  |  | 5.91 | % |  |  | — |  |  |  | — |  |  |  | — |  |
| Convertible Senior Notes |  |  | 3,108 |  |  |  | 31,014 |  |  |  | 6.48 | % |  | $ | 3,747 |  |  | $ | 37,392 |  |  |  | 6.48 | % |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 977 |  |  |  | — |  |  |  | 5.48 | % |
|  |  | $ | 12,760 |  |  | $ | 32,764 |  |  |  |  |  |  | $ | 4,724 |  |  | $ | 37,392 |  |  |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001564590-18-011836:note_history:63]
The following table summarizes the long-term debt of the Company as of April 2, 2018 and January 1, 2018:
  (was, 2017-11-08, similarity 0.949):
[0001193125-17-337320:note_history:63]
The following table summarizes the long-term debt of the
 Company as of October 2, 2017 and January 2,
 2017:

- added (2018-05-08):
[0001564590-18-011836:note_history:64]
|  |  | Interest Rate as of April 2, 2018 |  |  | Principal Outstanding as of April 2, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.38% |  |  | $ | 348,250 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.13% |  |  |  | 17,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.28% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  | 6.43% |  |  |  | 1,987 |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,022,222 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (28,225 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (11,968 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 982,029 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (4,616 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 977,413 |  |  |  |  |  |  | $ | 975,479 |  |

- removed (2018-05-08):
[0001193125-17-337320:note_history:65]
|  |  | Interest Rate as of October 2, 2017 |  |  | Principal Outstanding as of October 2, 2017 |  |  | Interest Rate as of January 2, 2017 |  |  | Principal Outstanding as of January 2, 2017 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  |  | 3.73 | % |  | $ | 350,000 |  |  |  | — |  |  |  | — |  |
| Senior Notes due October 2025 |  |  | 5.63 | % |  |  | 375,000 |  |  |  | — |  |  |  | — |  |
| Term Loan due May 2021 |  |  | — |  |  |  | — |  |  |  | 5.25 | % |  | $ | 700,000 |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 | % |  |  | 249,985 |  |  |  | 1.75 | % |  |  | 250,000 |  |
| U.S. ABL Revolving Loan due May 2020 |  |  | 2.73 | % |  |  | 17,000 |  |  |  | 2.27 | % |  |  | 80,000 |  |
| Asia ABL Revolving Loan due May 2020 |  |  | 2.63 | % |  |  | 30,000 |  |  |  | 2.17 | % |  |  | 30,000 |  |
| Capital Lease |  |  | 6.43 | % |  |  | 1,884 |  |  |  | 6.43 | % |  |  | 1,798 |  |
|  |  |  |  |  |  |  | 1,023,869 |  |  |  |  |  |  |  | 1,061,798 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (32,764 | ) |  |  |  |  |  |  | (37,392 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (12,760 | ) |  |  |  |  |  |  | (4,724 | ) |
|  |  |  |  |  |  |  | 978,345 |  |  |  |  |  |  |  | 1,019,682 |  |
| Less: current maturities |  |  |  |  |  |  | (4,184 | ) |  |  |  |  |  |  | (110,652 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 974,161 |  |  |  |  |  |  | $ | 909,030 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001564590-18-011836:note_history:66]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a significant shareholder of the Company holds an equity interest. For the quarters ended April 2, 2018 and April 3, 2017, the Company’s foreign subsidiaries purchased $12,708 and $13,540, respectively, of laminate and prepreg from these related parties.
  (was, 2017-11-08, similarity 0.6032):
[0001193125-17-337320:note_history:66]
In the
 normal course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $13,225 and $12,292 for the quarters ended
 October 2, 2017 and September 26, 2016, respectively, and
 $38,886 and $42,549 for the three quarters ended October 2,
 2017 and September 26, 2016, respectively.

- changed (2018-05-08):
[0001564590-18-011836:note_history:67]
As of April 2, 2018 and January 1, 2018, the Company’s consolidated condensed balance sheets included $16,095 and $14,452, respectively, in accounts payable due to related parties primarily for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.
  (was, 2017-11-08, similarity 0.6638):
[0001193125-17-337320:note_history:67]
As of
 October 2, 2017 and January 2, 2017, the Company’s
 consolidated condensed balance sheets included $15,490 and $15,836,
 respectively, in accounts payable due to related parties primarily
 for purchases of laminate and prepreg and such balances are
 included as a component of accounts payable on the consolidated
 condensed balance sheets. Additionally, the Company’s
 consolidated condensed balance sheets included $9 and $192,
 respectively, in accounts receivable due from a related party for
 sales of PCBs, as mentioned above, and such balances are included
 as a component of accounts receivable, net on the consolidated
 condensed balance sheets.

- removed (2018-05-08):
[0001193125-17-337320:note_history:68]
The
 Company also sells PCBs to a related party which is a wholly owned
 subsidiary of an entity in which a significant shareholder of the
 Company holds an equity interest. Sales to this related party for
 the quarters ended October 2, 2017 and September 26, 2016
 were $5 and $254, respectively, and $53 and $863 for the three
 quarters ended October 2, 2017 and September 26, 2016,
 respectively.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-08):
[0001564590-18-011836:note_history:69]
Revenue Recognition

- added (2018-05-08):
[0001564590-18-011836:note_history:70]
The Company derives revenues primarily from the sale of PCBs and custom electronic assemblies using customer-supplied engineering and design plans. Orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous transfer of control of the work in progress and finished goods as PCBs are being manufactured, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, in light of the Company’s adoption of the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation─Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.

- added (2018-05-08):
[0001564590-18-011836:note_history:71]
The selection of the method to measure progress toward completion requires judgment and is based on the type of PCB or customized electronic assemblies being manufactured. The Company uses the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

- added (2018-05-08):
[0001564590-18-011836:note_history:72]
The Company provides customers a limited right of return for defective PCBs and backplane assemblies. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from our historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.

- added (2018-05-08):
[0001564590-18-011836:note_history:73]
The Company has two revenue streams which coincide with the Company’s reportable segments of PCB and E-M Solutions. See Note 14 Segment Information.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2018-05-08):
[0001564590-18-011836:note_history:74]
(16) Subsequent Event

- added (2018-05-08):
[0001564590-18-011836:note_history:75]
On April 18, 2018, the Company completed its acquisition of all of the issued and outstanding common stock of Anaren Holding Corp. for total consideration of $775,000 in cash subject to customary working capital and certain other adjustments. Other than the equity interests of Anaren, Inc. (Anaren), Anaren Holding Corp. has no material assets or liabilities and has no material independent operations. Anaren is a leading provider of mission-critical radio frequency (RF) solutions, microelectronics, and microwave components and assemblies for the wireless infrastructure and space and defense electronics markets.

- added (2018-05-08):
[0001564590-18-011836:note_history:76]
Additionally, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. The Company used the proceeds of the incremental loan, along with cash on hand to fund the purchase price of the Anaren acquisition and to pay related fees and expenses.

- added (2018-05-08):
[0001564590-18-011836:note_history:77]
The acquisition will be accounted for using the acquisition method; however the accounting was incomplete at the time these financial statements were issued. As a result, the purchase price allocation and pro-forma income statement disclosures have not been provided. The first periodic report that will include results of operations for Anaren will be the Company’s Form 10-Q for the quarter ended July 2, 2018.
