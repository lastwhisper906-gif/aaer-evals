# TTMI notes — 0001564590-18-011836


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-18-011836:notes:1]
(1) Nature of Operations and Basis of Presentation

[0001564590-18-011836:notes:2]
TTM Technologies, Inc. (the Company or TTM) is a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically complex PCBs and electro-mechanical solutions (E-M Solutions). The Company provides time-to-market and volume production of advanced technology products and offers a one-stop manufacturing solution to customers from engineering support to prototype development through final mass production. This one-stop manufacturing solution enables the Company to align technology developments with the diverse needs of the Company’s customers and to enable them to reduce the time required to develop new products and bring them to market.

[0001564590-18-011836:notes:3]
The Company serves a diversified customer base in various markets throughout the world, including aerospace and defense, automotive components, smartphones and touchscreen tablets, high-end computing, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. The Company’s customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-18-011836:notes:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. These consolidated condensed financial statements reflect all adjustments (consisting only of normal recurring adjustments) which, in the opinion of management, are necessary to present fairly the financial position, the results of operations and cash flows of the Company for the periods presented. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The results of operations for the interim periods are not necessarily indicative of the results to be expected for the full year. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Actual results could differ materially from those estimates. The Company uses a 13-week fiscal quarter accounting period with the fourth quarter ending on the Monday nearest December 31.

[0001564590-18-011836:notes:5]
Recently Adopted and Issued Accounting Standards

[0001564590-18-011836:notes:6]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2014-09, Revenue from Contracts with Customers (Topic 606), which replaces most existing revenue recognition guidance in U.S. GAAP, including industry specific requirements, and provides companies with a single revenue recognition model for recognizing revenue of contracts with customers. The core principle of the new revenue standard is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the company expects to be entitled in exchange for those goods or services.

[0001564590-18-011836:notes:7]
The Company assessed the new guidance and adopted the new revenue standard on January 2, 2018, which resulted in a change to the timing of revenue recognition for the Company’s revenue stream from “point in time” upon physical delivery to an “over time” model. Additionally, the Company has elected the cumulative effect transition method with adjustment to the opening balance of retained earnings at January 2, 2018 for all open contracts as of January 1, 2018. Therefore, comparative information has not been adjusted and continues to be reported under previous U.S. GAAP guidance for the consolidated balance sheet at January 1, 2018 and the consolidated condensed statement of operations for the quarter ended April 3, 2017.

[0001564590-18-011836:notes:8]
The cumulative effect of the changes made to the Company’s January 2, 2018 consolidated condensed balance sheet for the adoption of the new revenue standard were as follows:

[0001564590-18-011836:notes:9]
|  |  | Balance at January 1, 2018 |  |  | New Revenue Standard Adjustment |  |  | Balance at January 2, 2018 |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 483,903 |  |  | $ | 8,171 |  |  | $ | 492,074 |  |
| Contract assets |  |  | — |  |  |  | 260,654 |  |  |  | 260,654 |  |
| Inventories |  |  | 294,588 |  |  |  | (223,576 | ) |  |  | 71,012 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 114,685 |  |  |  | 13,384 |  |  |  | 128,069 |  |
| Other long-term liabilities |  |  | 74,667 |  |  |  | 3,291 |  |  |  | 77,958 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 193,342 |  |  |  | 28,574 |  |  |  | 221,916 |  |

[0001564590-18-011836:notes:10]
As part of adoption of the new revenue standard, the Company recorded an estimated sales returns and allowance as well as a noncurrent deferred tax liability in the amount of $5,213 and $3,291, respectively, as of January 2, 2018.  Additionally, the Company reclassified its sales returns and allowance balance of $8,171 as of January 1, 2018, from trade accounts receivable to other accrued liabilities. Sales returns and allowances are recorded as a reduction of revenue and a component of accrued liabilities on the condensed consolidated balance sheet.

[0001564590-18-011836:notes:11]
Additionally, the below disclosure summarizes the impact of the adoption of new revenue standard on the Company’s consolidated condensed balance sheet, statement of operations and statement of cash flows for the quarter ended April 2, 2018 for which the As Reported reflects the new revenue standard and Balances without New Revenue Standard Adjustment reflects the Company’s replaced revenue recognition policy of “point in time” and upon physical delivery.

[0001564590-18-011836:notes:12]
|  |  | April 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 504,914 |  |  | $ | 8,171 |  |  | $ | 496,743 |  |
| Contract assets |  |  | 275,022 |  |  |  | 275,022 |  |  |  | — |  |
| Inventories |  |  | 82,116 |  |  |  | (235,557 | ) |  |  | 317,673 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other accrued expenses |  |  | 102,162 |  |  |  | 13,671 |  |  |  | 88,491 |  |
| Other long-term liabilities |  |  | 77,078 |  |  |  | 3,163 |  |  |  | 73,915 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  |  | 232,013 |  |  |  | 30,801 |  |  |  | 201,212 |  |

[0001564590-18-011836:notes:13]
|  |  | April 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Net sales |  | $ | 663,582 |  |  | $ | 14,081 |  |  | $ | 649,501 |  |
| Cost of goods sold |  |  | 574,904 |  |  |  | 11,981 |  |  |  | 562,923 |  |
| Gross profit |  |  | 88,678 |  |  |  | 2,100 |  |  |  | 86,578 |  |
| Net income |  |  | 10,097 |  |  |  | 2,227 |  |  |  | 7,870 |  |

[0001564590-18-011836:notes:14]
|  |  | April 2, 2018 |  |
|  |  | As reported |  |  | Effect of Change Increase (Decrease) |  |  | Balances without New Revenue Standard Adjustment |  |
|  |  | (In thousands) |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,097 |  |  | $ | 2,227 |  |  | $ | 7,870 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Other |  |  | (439 | ) |  |  | (127 | ) |  |  | (312 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (12,840 | ) |  |  | — |  |  |  | (12,840 | ) |
| Contract assets |  |  | (14,368 | ) |  |  | (14,368 | ) |  |  | — |  |
| Inventories |  |  | (11,104 | ) |  |  | 11,981 |  |  |  | (23,085 | ) |
| Accrued salaries, wages and benefits and other accrued expenses |  |  | (47,566 | ) |  |  | 287 |  |  |  | (47,853 | ) |

[0001564590-18-011836:notes:15]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. This ASU amends and simplifies existing guidance in order to allow companies to more accurately present the economic effects of risk management activities in the financial statements. ASU 2017-12 also amends the guidance surrounding the recognition of the value of hedged instruments to include the entire change in value, rather than just the effective portion, in other comprehensive income and recognized in earnings at the same time that the hedged item affects earnings for cash flow and net investment hedges. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures.

[0001564590-18-011836:notes:16]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). The objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements. This ASU is effective for fiscal years beginning after December 15, 2018, including interim periods within those annual periods and is to be applied utilizing a modified retrospective approach. While the Company continues to evaluate the new guidance to determine the impact it may have on its consolidated financial statements and related disclosures, the primary effect of adopting this update will be to record assets and liabilities for existing operating leases.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-18-011836:notes:17]
(2) Summary of Significant Accounting Policies

[0001564590-18-011836:notes:18]
Revenue Recognition

[0001564590-18-011836:notes:19]
The Company derives revenues primarily from the sale of PCBs and custom electronic assemblies using customer-supplied engineering and design plans. Orders for products generally correspond to the production schedules of the Company’s customers and are supported with firm purchase orders. The Company’s customers have continuous transfer of control of the work in progress and finished goods as PCBs are being manufactured, as PCBs are built to customer specifications and do not have an alternative use. The customer typically controls the work in progress and finished goods as evidenced either by contractual termination clauses or by the Company’s rights to payment for work performed to date, plus a reasonable profit.  As a result, in light of the Company’s adoption of the “over time” revenue standard as discussed in Note 1 Nature of Operations and Basis of Presentation─Recently Adopted and Issued Accounting Standards, beginning in the first quarter of 2018, the Company now recognizes revenue progressively over time based on the extent of progress towards completion of the performance obligation.

[0001564590-18-011836:notes:20]
The selection of the method to measure progress toward completion requires judgment and is based on the type of PCB or customized electronic assemblies being manufactured. The Company uses the cost-to-cost method as it best depicts the transfer of control to the customer which takes place as we incur costs. Under the cost-to-cost measure of progress, the extent of progress toward completion is measured based on the ratio of costs incurred to date to the total estimated costs at completion of the performance obligation. Revenues are recorded proportionally as costs are incurred.

[0001564590-18-011836:notes:21]
The Company provides customers a limited right of return for defective PCBs and backplane assemblies. The Company accrues an estimate for sales returns and allowances progressively over time based on the extent of progress towards completion of the performance obligation using the Company’s judgment based on historical results and anticipated returns.  To the extent actual experience varies from our historical experience, revisions to the sales returns and allowances accrual may be required. Sales returns and allowances are recorded as a reduction of revenue and included as a component of accrued liabilities on the condensed consolidated balance sheet.

[0001564590-18-011836:notes:22]
The Company has two revenue streams which coincide with the Company’s reportable segments of PCB and E-M Solutions. See Note 14 Segment Information.


## ttmi:ContractWithCustomerAssetTextBlock

[0001564590-18-011836:notes:23]
(3) Contract Asset

[0001564590-18-011836:notes:24]
A contract asset is recognized when the Company has recognized revenue, but not issued an invoice for payment.  Contract assets are classified as current assets and transferred to receivables when the entitlement to payment becomes unconditional. All of the Company’s contract assets are generally converted to trade account receivables within 90 days, at which time the Company is entitled to payment of the fixed price upon delivery of the finished product. Contract assets were $275,022 as of April 2, 2108 and represent unbilled amounts for work performed to date, plus a reasonable profit. There were no contract assets as of January 1, 2018.


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-18-011836:notes:25]
(4) Goodwill

[0001564590-18-011836:notes:26]
As of April 2, 2018 and January 1, 2018, goodwill was as follows:

[0001564590-18-011836:notes:27]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of January 1, 2018 and April 2, 2018 |  |  |  |  |
| Goodwill |  | $ | 543,971 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |
|  |  | $ | 372,571 |  |

[0001564590-18-011836:notes:28]
All goodwill relates to the Company’s PCB reportable segment.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-18-011836:notes:29]
(5) Definite-lived Intangibles

[0001564590-18-011836:notes:30]
As of April 2, 2018 and January 1, 2018, the components of definite-lived intangibles were as follows:

[0001564590-18-011836:notes:31]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  | (years) |  |
| April 2, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,634 |  |  | $ | (106,700 | ) |  | $ | — |  |  | $ | 96,934 |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (2,846 | ) |  |  | — |  |  |  | 154 |  |  | 3 |  |
|  |  | $ | 206,634 |  |  | $ | (109,546 | ) |  | $ | — |  |  | $ | 97,088 |  |  |  |  |
| January 1, 2018: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 203,563 |  |  | $ | (101,089 | ) |  | $ | 72 |  |  | $ | 102,546 |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (2,596 | ) |  |  | — |  |  |  | 404 |  |  | 3 |  |
|  |  | $ | 206,563 |  |  | $ | (103,685 | ) |  | $ | 72 |  |  | $ | 102,950 |  |  |  |  |

[0001564590-18-011836:notes:32]
The January 1, 2018 definite-lived intangible balances include foreign currency translation adjustments related to foreign subsidiaries with functional currencies other than the U.S. Dollar.

[0001564590-18-011836:notes:33]
Definite-lived intangibles are generally amortized using the straight line method of amortization over the useful life, with the exception of certain customer relationship intangibles, which are amortized using an accelerated method of amortization based on estimated cash flows. Amortization expense was $5,861 and $5,912 for the quarters ended April 2, 2018 and April 3, 2017, respectively.

[0001564590-18-011836:notes:34]
Estimated aggregate amortization for definite-lived intangible assets for the next five years and thereafter is as follows:

[0001564590-18-011836:notes:35]
|  |  | (In thousands) |  |
| Remaining 2018 |  | $ | 17,001 |  |
| 2019 |  |  | 18,746 |  |
| 2020 |  |  | 18,746 |  |
| 2021 |  |  | 14,921 |  |
| 2022 |  |  | 12,329 |  |
| Thereafter |  |  | 15,345 |  |
|  |  | $ | 97,088 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-18-011836:notes:36]
(6) Long-term Debt and Letters of Credit

[0001564590-18-011836:notes:37]
The following table summarizes the long-term debt of the Company as of April 2, 2018 and January 1, 2018:

[0001564590-18-011836:notes:38]
|  |  | Interest Rate as of April 2, 2018 |  |  | Principal Outstanding as of April 2, 2018 |  |  | Interest Rate as of January 1, 2018 |  |  | Principal Outstanding as of January 1, 2018 |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | 4.38% |  |  | $ | 348,250 |  |  | 4.06% |  |  | $ | 349,125 |  |
| Senior Notes due October 2025 |  | 5.63% |  |  |  | 375,000 |  |  | 5.63% |  |  |  | 375,000 |  |
| Convertible Senior Notes due December 2020 |  | 1.75% |  |  |  | 249,985 |  |  | 1.75% |  |  |  | 249,985 |  |
| U.S. ABL Revolving Loan due May 2020 |  | 3.13% |  |  |  | 17,000 |  |  | 3.06% |  |  |  | 17,000 |  |
| Asia ABL Revolving Loan due May 2020 |  | 3.28% |  |  |  | 30,000 |  |  | 2.96% |  |  |  | 30,000 |  |
| Capital Lease |  | 6.43% |  |  |  | 1,987 |  |  | 6.43% |  |  |  | 1,919 |  |
|  |  |  |  |  |  |  | 1,022,222 |  |  |  |  |  |  |  | 1,023,029 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (28,225 | ) |  |  |  |  |  |  | (30,513 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (11,968 | ) |  |  |  |  |  |  | (12,459 | ) |
|  |  |  |  |  |  |  | 982,029 |  |  |  |  |  |  |  | 980,057 |  |
| Less: current maturities |  |  |  |  |  |  | (4,616 | ) |  |  |  |  |  |  | (4,578 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 977,413 |  |  |  |  |  |  | $ | 975,479 |  |

[0001564590-18-011836:notes:39]
Term Loan Facility

[0001564590-18-011836:notes:40]
During the fiscal year 2017, the Company entered into a $350,000 Term Loan Facility due 2024. The Term Loan Facility, of which $3,500 is included in short-term debt and $344,750 is included in long-term debt, was issued at a discount at 99.5% and bears interest, at the Company’s option, at a floating rate of LIBOR, plus an applicable interest margin of 2.5%, or an alternate base rate, (defined as the greater of the JP Morgan prime, the New York Fed bank rate plus 0.9% or LIBOR plus 1.0%), subject to a 1.0% floor plus an applicable margin of 1.5%. At April 2, 2018 the interest rate on the outstanding borrowings under the Term Loan Facility was 4.38%. There is no provision, other than an event of default, for the interest margin to increase. The Term Loan Facility will mature on September 28, 2024. The Term Loan Facility is secured by a significant amount of the domestic assets of the Company and a pledge of 65% of voting stock of the Company’s first tier foreign subsidiaries and is structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes below.

[0001564590-18-011836:notes:41]
The Company is required to make scheduled payments of the outstanding Term Loan Facility on a quarterly basis beginning January 1, 2018. Based on certain parameters defined in the Term Loan Facility, including a First Lien Leverage Ratio, the Company may be required to make an additional principal payment on an annual basis beginning after fiscal year 2018, if the Company’s First Lien Leverage Ratio is greater than 2.0. Any additional annual payments or prepayments would reduce future required scheduled payments. Any remaining outstanding balance under the Term Loan Facility are due at the maturity date of September 28, 2024.

[0001564590-18-011836:notes:42]
Borrowings under the Term Loan Facility are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments and dispositions, and share payments.

[0001564590-18-011836:notes:43]
Senior Notes

[0001564590-18-011836:notes:44]
The $375,000 of Senior Notes, which is included in long-term debt, bear interest at a rate of 5.63% per annum. Interest is payable semiannually in arrears on April 1 and October 1 of each year beginning April 1, 2018. The Senior Notes will mature on October 1, 2025.

[0001564590-18-011836:notes:45]
Borrowings under the Senior Notes are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-18-011836:notes:46]
Convertible Senior Notes due 2020

[0001564590-18-011836:notes:47]
The Company maintains 1.75% convertible senior notes in the amount of $249,985 due December 15, 2020. The convertible senior notes bear interest at a rate of 1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to the Company’s future unsecured senior indebtedness and are senior in right of payment to any of the Company’s future subordinated indebtedness.

[0001564590-18-011836:notes:48]
As of April 2, 2018 and January 1, 2018, the following summarizes the equity components of the convertible senior notes included in additional paid-in capital:

[0001564590-18-011836:notes:49]
|  |  | As of April 2, 2018 and January 1, 2018 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Convertible senior notes due 2020 |  | $ | 60,216 |  |  | $ | (1,916 | ) |  | $ | 58,300 |  |

[0001564590-18-011836:notes:50]
The components of interest expense resulting from the convertible senior notes for the quarters ended April 2, 2018 and April 3, 2017 are as follows:

[0001564590-18-011836:notes:51]
|  |  | Quarter Ended |  |
|  |  | April 2, |  |  | April 3, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  | $ | 1,094 |  |  | $ | 1,094 |  |
| Amortization of debt discount |  | $ | 2,230 |  |  | $ | 2,091 |  |
| Amortization of debt issuance costs |  | $ | 224 |  |  | $ | 209 |  |

[0001564590-18-011836:notes:52]
Asset-Based Lending Agreements

[0001564590-18-011836:notes:53]
The Company maintains a $200,000 U.S. Asset-Based Lending Credit Agreement (U.S. ABL), and a $150,000 Asia Asset-Based Lending Credit Agreement (Asia ABL) (collectively the ABL Revolving Loans).

[0001564590-18-011836:notes:54]
The U.S. ABL consists of three tranches comprised of a revolving credit facility for up to $200,000, a letter of credit facility for up to $50,000, and swingline loans for up to $30,000, provided that at no time may amounts outstanding under the tranches exceed in aggregate $200,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement. Borrowings under the U.S. ABL bear interest at either a floating rate of LIBOR plus a margin of 125 basis points or JP Morgan Chase Bank’s prime rate plus a margin of 25 basis points, at the Company’s option. At April 2, 2018, the interest rate on the outstanding borrowings under the U.S. ABL was 3.13%. The applicable margin can vary based on the remaining availability of the facility, from 125 to 175 basis points for LIBOR-based loans and from 25 to 75 basis points for JP Morgan Chase Bank’s prime rate-based loans. Other than availability and an event of default, there are no other provisions for the interest margin to increase. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of the Company’s domestic cash, receivables and certain inventories as well as by a second position against a significant amount of the domestic assets of the Company and a pledge of 65% of the voting stock of the Company’s first tier foreign subsidiaries and are structurally senior to the Company’s Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At April 2, 2018, $17,000 of the U.S. ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-18-011836:notes:55]
The Asia ABL consists of two tranches comprised of a revolving credit facility for up to $150,000 and a letter of credit facility for up to $100,000, provided that at no time may amounts outstanding under both tranches exceed in aggregate $150,000 or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 140 basis points. At April 2, 2018, the interest rate on the outstanding borrowings under the Asia ABL was 3.28%. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020. Loans made under the Asia ABL are secured by a portion of the Company’s Asia Pacific cash and receivables and are structurally senior to the Company’s domestic obligations, including the Senior Notes and Convertible Senior Notes. See Senior Notes and Convertible Senior Notes above. At April 2, 2018, $30,000 of the Asia ABL was outstanding and classified as long-term debt, which is consistent with its maturity date.

[0001564590-18-011836:notes:56]
The Company has up to $50,000 and $100,000 Letters of Credit Facilities under the U.S. ABL and the Asia ABL, respectively. As of April 2, 2018, letters of credit in the amount of $7,252 were outstanding under the U.S. ABL and $26,976 were outstanding under the Asia ABL with various expiration dates through June 2019. Available borrowing capacity under the U.S. ABL and the Asia ABL was $175,748 and $93,024, respectively, which considers letters of credit outstanding at April 2, 2018.

[0001564590-18-011836:notes:57]
The Company is required to pay a commitment fee of 0.25% to 0.375% per annum on any unused portion of the U.S. ABL or Asia ABL. The Company incurred total commitment fees related to unused borrowing availability of $241 and $187 for the quarters ended April 2, 2018 and April 3, 2017, respectively. Under the occurrence of certain events, the ABL Revolving Loans are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios.

[0001564590-18-011836:notes:58]
Other Credit Facility

[0001564590-18-011836:notes:59]
Additionally, the Company is party to a revolving loan credit facility (Chinese Revolver) with a lender in China. Under this arrangement, the lender has made available to the Company approximately $33,400 in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this arrangement expires in January 2019. As of April 2, 2018, the Chinese Revolver had not been drawn upon.

[0001564590-18-011836:notes:60]
Debt Issuance and Debt Discount

[0001564590-18-011836:notes:61]
As of April 2, 2018 and January 1, 2018, remaining unamortized debt discount and debt issuance costs for the Term Loan Facility, Senior Notes and Convertible Senior Notes are as follows:

[0001564590-18-011836:notes:62]
|  |  | As of April 2, 2018 |  |  | As of January 1, 2018 |  |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |
|  |  | (in thousands) |  |
| Term Loan due September 2024 |  | $ | 2,695 |  |  | $ | 1,636 |  |  |  | 3.96 | % |  | $ | 2,788 |  |  | $ | 1,691 |  |  |  | 3.96 | % |
| Senior Notes due October 2025 |  |  | 6,608 |  |  | — |  |  |  | 5.92 | % |  |  | 6,782 |  |  | — |  |  |  | 5.92 | % |
| Convertible Senior Notes |  |  | 2,665 |  |  |  | 26,589 |  |  |  | 6.48 | % |  |  | 2,889 |  |  |  | 28,822 |  |  |  | 6.48 | % |
|  |  | $ | 11,968 |  |  | $ | 28,225 |  |  |  |  |  |  | $ | 12,459 |  |  | $ | 30,513 |  |  |  |  |  |

[0001564590-18-011836:notes:63]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-18-011836:notes:64]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $2,171 and $2,421 as of April 2, 2018 and January 1, 2018, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight line method of amortization.

[0001564590-18-011836:notes:65]
At April 2, 2018, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 3.8 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-011836:notes:66]
(7) Income Taxes

[0001564590-18-011836:notes:67]
The Company’s effective tax rate is impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of other credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items.

[0001564590-18-011836:notes:68]
During the quarter ended April 2, 2018, the Company’s effective tax rate was impacted by a net discrete expense of $746 related to accrued interest expense on existing uncertain tax positions. Additionally, no tax benefit was recorded on the losses incurred in certain foreign jurisdictions as a result of corresponding increases in the valuation allowances in these jurisdictions. The Company expects its earnings attributable to foreign subsidiaries will be indefinitely reinvested outside of the U.S., except as noted below and, therefore, no deferred tax liabilities for U.S. income taxes on undistributed earnings are recorded. Foreign earnings from certain subsidiaries may be repatriated to the parent holding company located in the Cayman Islands, and therefore, a deferred tax liability has been recorded on the undistributed earnings of these subsidiaries.

[0001564590-18-011836:notes:69]
Effects of the Tax Cuts and Jobs Act

[0001564590-18-011836:notes:70]
On December 22, 2017, the Tax Cuts and Jobs Act (Tax Act) was enacted. Accounting Standard Codification (ASC) 740, Accounting for Income Taxes, requires companies to recognize the effect of tax law changes in the period of enactment regardless of the effective date of those tax law changes. Certain provisions of the Tax Act were effective September 27, 2017, others were effective or identified as of December 31, 2017 or January 1, 2018.

[0001564590-18-011836:notes:71]
Given the timing of enactment of the Tax Act and the significance of the legislation, the SEC staff issued Staff Accounting Bulletin No. 118 (SAB 118), which allows registrants to record provisional amounts during a one year “measurement period” similar to that used when accounting for business combinations. However, the measurement period should not extend beyond one year from the Tax Act enactment date and is deemed to have ended when the registrant has obtained, prepared and analyzed the information necessary to finalize its accounting.

[0001564590-18-011836:notes:72]
To the extent that a company’s accounting for certain income tax effects of the Tax Act is incomplete but is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 740 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the Tax Act. More specifically, SAB 118 summarizes a three-step process to be applied at each reporting period to account for and disclose the tax effects of the Tax Act. The steps are (1) to record the effects of the change in tax law for which accounting is complete; (2) to record provisional amounts (or adjustments to provisional amounts) for the effects of the tax law where accounting is not complete, but for which a reasonable estimate has been determined; and (3) where a reasonable estimate cannot yet be made, to continue to apply ASC 740 based on the tax law in effect prior to enactment of the Tax Act.

[0001564590-18-011836:notes:73]
Amounts recorded where accounting is complete for the year ended January 1, 2018 primarily relate to the reduction in the U.S. corporate income tax rate to 21 percent. The Company revalued its ending gross deferred tax items, previously recorded at 35 percent, using the enacted 21 percent corporate tax rate. This change caused a reduction to the Company’s U.S. federal deferred tax assets fully offset by a reduction of its valuation allowance.

[0001564590-18-011836:notes:74]
Effects of tax law changes where a reasonable estimate of the accounting effects cannot yet been made include the one-time mandatory repatriation transition tax on the net accumulated earnings and profits of the Company’s foreign subsidiaries earned post 1986. The Company has performed a preliminary earnings and profits analysis with consideration given to foreign loss carryforwards acquired as a result of the Company’s acquisitions and determined on a provisional basis that there should be no income tax effect in the current or any future period. The Company will continue to identify and evaluate data to more thoroughly identify the tax impact and record adjustments, if any, within the measurement period.

[0001564590-18-011836:notes:75]
The Company has determined that the following provisions that are effective January 1, 2018 and relevant to the Company will not impact the current quarter tax expense, primarily as a result of the full valuation allowance in the U.S.: limitations on certain entertainment expenses, the inclusion of commissions and performance based compensation in determining the excessive compensation limitation, limitation on the current deductibility of net interest expense in excess of 30 percent of adjusted taxable income, and a minimum tax on certain foreign earnings in excess of 10 percent of the foreign subsidiaries tangible assets (i.e., global intangible low-taxed income or GILTI). The Company is still evaluating whether to make a policy election to treat the GILTI tax as a period expense or to provide U.S. deferred taxes on foreign earnings that are expected to generate GILTI income when they reverse in future years.

[0001564590-18-011836:notes:76]
For the quarter ended April 2, 2018, the Company has not made any changes to its previously provisional estimate of the impact U.S. Tax Reform and the Company continues to analyze and model the impact and will record said impact as it becomes more certain. This includes the mandatory repatriation tax, indefinite criterion assertion on foreign earnings, and deferred taxes on foreign earnings expected to generate GILTI.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-18-011836:notes:77]
(8) Accumulated Other Comprehensive Income

[0001564590-18-011836:notes:78]
The following provides a summary of the components of accumulated other comprehensive income as of April 2, 2018 and January 1, 2018:

[0001564590-18-011836:notes:79]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at January 1, 2018 |  | $ | 4,145 |  |  | $ | (742 | ) |  | $ | 3,403 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 622 |  |  |  | (6 | ) |  |  | 616 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 41 |  |  |  | 41 |  |
| Other comprehensive income |  |  | 622 |  |  |  | 35 |  |  |  | 657 |  |
| Ending balance at April 2, 2018 |  | $ | 4,767 |  |  | $ | (707 | ) |  | $ | 4,060 |  |

[0001564590-18-011836:notes:80]
For the quarters ended April 2, 2018 and April 3, 2017, $41 and $44 net of tax, respectively, were reclassified out of accumulated other comprehensive income to depreciation expense related to cash flow hedges.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-18-011836:notes:81]
(9) Significant Customers and Concentration of Credit Risk

[0001564590-18-011836:notes:82]
In the normal course of business, the Company extends credit to its customers. Most customers to which the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk.

[0001564590-18-011836:notes:83]
The Company’s customers include both OEMs and EMS companies. The Company’s OEM customers often direct a significant portion of their purchases through EMS companies. While the Company’s customers include both OEM and EMS providers, the Company measures customer concentration based on OEM companies, as they are the ultimate end customers.

[0001564590-18-011836:notes:84]
For both the quarters ended April 2, 2018 and April 3, 2017, one customer accounted for approximately 16% of the Company’s net sales. There were no other customers that accounted for 10% or more of net sales for the quarters ended April 2, 2018 and April 3, 2017.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-18-011836:notes:85]
(10) Fair Value Measures

[0001564590-18-011836:notes:86]
The Company measures at fair value its financial and non-financial assets by using a fair value hierarchy that prioritizes the inputs to valuation techniques used to measure fair value. Fair value is the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date, essentially an exit price, based on the highest and best use of the asset or liability.

[0001564590-18-011836:notes:87]
The carrying amount and estimated fair value of the Company’s financial instruments at April 2, 2018 and January 1, 2018 were as follows:

[0001564590-18-011836:notes:88]
|  |  | April 2, 2018 |  |  | January 1, 2018 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Term Loan due September 2024 |  | $ | 343,919 |  |  | $ | 349,556 |  |  | $ | 344,646 |  |  | $ | 346,943 |  |
| Senior Notes due October 2025 |  |  | 368,392 |  |  |  | 374,130 |  |  |  | 368,218 |  |  |  | 384,769 |  |
| Convertible Senior Notes |  |  | 220,731 |  |  |  | 409,300 |  |  |  | 218,274 |  |  |  | 429,199 |  |
| ABL Revolving Loans |  |  | 47,000 |  |  |  | 47,000 |  |  |  | 47,000 |  |  |  | 47,000 |  |
| Capital Lease |  |  | 1,987 |  |  |  | 1,987 |  |  |  | 1,919 |  |  |  | 1,919 |  |

[0001564590-18-011836:notes:89]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of April 2, 2018 and January 1, 2018, which are considered Level 1 and Level 2 inputs.

[0001564590-18-011836:notes:90]
The fair value of the convertible senior notes was estimated based on quoted market prices of the securities on an active exchange, which are considered Level 1 and Level 2 inputs.

[0001564590-18-011836:notes:91]
As of April 2, 2018 and January 1, 2018, the Company’s other financial instruments also included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents at April 2, 2018 consisted of $187,748 held in the U.S., with the remaining $164,828 held by foreign subsidiaries.

[0001564590-18-011836:notes:92]
The majority of the Company’s non-financial assets and liabilities, which include goodwill, intangible assets, inventories, and property, plant and equipment, are not required to be carried at fair value on a recurring basis. However, if certain triggering events occur (or are tested at least annually in the case of goodwill) such that a non-financial instrument is required to be evaluated for impairment, based upon a comparison of the non-financial instrument’s fair value to its carrying value, an impairment is recorded to reduce the carrying value to the fair value, if the carrying value exceeds the fair value.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-011836:notes:93]
(11) Commitments and Contingencies

[0001564590-18-011836:notes:94]
Legal Matters

[0001564590-18-011836:notes:95]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of April 2, 2018 and January 1, 2018. However, these amounts are not material to the consolidated condensed financial statements of the Company.

[0001564590-18-011836:notes:96]
Environmental Matters

[0001564590-18-011836:notes:97]
The process to manufacture PCBs requires adherence to city, county, state, federal, and foreign environmental regulations regarding the storage, use, handling and disposal of chemicals, solid wastes and other hazardous materials, as well as compliance with air quality standards and chemical use reporting. The Company believes that its facilities in the United States and Canada comply in all material respects with applicable environmental laws and regulations. In China, governmental authorities have adopted new rules and regulations governing environmental issues. An update to the Chinese environmental waste water law was issued in late 2012, allowing for an interim period in which plants subject to such law may install equipment that meets the new regulatory regime. Some of the Company’s plants in China are not yet in full compliance with the updated environmental regulations. The Company has established and enacted an investment plan related to the efforts to come into full compliance with the new regulations. The 2018 capital expenditure costs expected for these plans are included in the Company’s capital expenditure projections.


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-011836:notes:98]
(12) Earnings Per Share

[0001564590-18-011836:notes:99]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the quarters ended April 2, 2018 and April 3, 2017:

[0001564590-18-011836:notes:100]
|  |  | Quarter Ended |  |
|  |  | April 2, 2018 |  |  | April 3, 2017 |  |
|  |  | (In thousands, except per share amounts) |  |
| Basic earnings: |  |  |  |  |  |  |  |  |
| Basic earnings |  | $ | 10,097 |  |  | $ | 32,959 |  |
| Diluted earnings: |  |  |  |  |  |  |  |  |
| Net income attributable to TTM Technologies, Inc. stockholders |  | $ | 10,097 |  |  | $ | 32,959 |  |
| Interest expense from convertible senior notes, net of tax |  |  | — |  |  |  | 3,394 |  |
| Diluted earnings |  | $ | 10,097 |  |  | $ | 36,353 |  |
| Basic weighted average shares |  |  | 102,508 |  |  |  | 100,932 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,829 |  |  |  | 1,867 |  |
| Dilutive effect of outstanding warrants |  |  | 3,180 |  |  |  | 2,183 |  |
| Dilutive effect of assumed conversion of convertible senior notes outstanding |  |  | — |  |  |  | 25,940 |  |
| Diluted shares |  |  | 107,517 |  |  |  | 130,922 |  |
| Earnings per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.10 |  |  | $ | 0.33 |  |
| Diluted |  | $ | 0.09 |  |  | $ | 0.28 |  |

[0001564590-18-011836:notes:101]
For the quarters ended April 2, 2018 and April 3, 2017, performance-based restricted stock units (PRUs), restricted stock units (RSUs) and stock options to purchase 931 and 179 shares of common stock, respectively, were not considered in calculating diluted earnings per share because the options’ exercise prices or the total expected proceeds under the treasury stock method for PRUs, RSUs or stock options was greater than the average market price of common shares during the applicable quarter and, therefore, the effect would be anti-dilutive.

[0001564590-18-011836:notes:102]
For the quarter ended April 2, 2018, the effect of shares of common stock related to the Company’s convertible senior notes, based on the if-converted method, was not included in the computation of dilutive earnings per share as the impact would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-18-011836:notes:103]
(13) Stock-Based Compensation

[0001564590-18-011836:notes:104]
Stock-based compensation expense is recognized in the accompanying consolidated condensed statements of operations as follows:

[0001564590-18-011836:notes:105]
|  |  | Quarter Ended |  |
|  |  | April 2, |  |  | April 3, |  |
|  |  | 2018 |  |  | 2017 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 529 |  |  | $ | 394 |  |
| Selling and marketing |  |  | 374 |  |  |  | 253 |  |
| General and administrative |  |  | 2,719 |  |  |  | 2,981 |  |
| Stock-based compensation expense recognized |  | $ | 3,622 |  |  | $ | 3,628 |  |

[0001564590-18-011836:notes:106]
Performance-based Restricted Stock Units

[0001564590-18-011836:notes:107]
The Company maintains a long-term incentive program for executives that provides for the issuance of PRUs, representing hypothetical shares of the Company’s common stock that may be issued. Under the PRU program, a target number of PRUs is awarded at the beginning of each three-year performance period. The number of shares of common stock released at the end of the performance period will range from zero to 2.4 times the target number depending on performance during the period. The performance metrics of the PRU program are based on (a) annual financial targets, which are based on revenue and EBITDA (earnings before interest, tax, depreciation, and amortization expense), each equally weighted, and (b) an overall modifier based on the Company’s total stockholder return (TSR) relative to a group of peer companies selected by the Company’s compensation committee, over the three-year performance period.

[0001564590-18-011836:notes:108]
The Company records stock-based compensation expense for PRU awards granted based on management’s periodic assessment of the annual financial performance goals to be achieved. For the quarter ended April 2, 2018, management determined that vesting of the PRU awards was probable. PRUs activity for the quarter ended April 2, 2018 was as follows:

[0001564590-18-011836:notes:109]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |  |
| Outstanding target shares at January 1, 2018 |  |  | 409 |  |  | $ | 16.39 |  |
| Granted |  |  | 331 |  |  |  | 19.60 |  |
| Outstanding target shares at April 2, 2018 |  |  | 740 |  |  | $ | 17.83 |  |

[0001564590-18-011836:notes:110]
The fair value for PRUs granted is calculated using a Monte Carlo simulation model, as the TSR modifier contains a market condition. For the quarters ended April 2, 2018 and April 3, 2017 the following assumptions were used in determining the fair value:

[0001564590-18-011836:notes:111]
|  |  | April 2, |  |  | April 3, |  |
|  |  | 2018(1) |  |  | 2017(2) |  |
| Weighted-average fair value |  | $ | 19.60 |  |  | $ | 22.90 |  |
| Risk-free interest rate |  |  | 2.13 | % |  |  | 1.20 | % |
| Dividend yield |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 40 | % |  |  | 43 | % |
| Expected term in years |  |  | 1.5 |  |  |  | 1.8 |  |

[0001564590-18-011836:notes:112]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2016, second year of the three-year performance period applicable to PRUs granted in 2017 and first year of the three-year performance period applicable to PRUs granted in 2018. |

[0001564590-18-011836:notes:113]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2015, second year of the three-year performance period applicable to PRUs granted in 2016 and first year of the three-year performance period applicable to PRUs granted in 2017. |

[0001564590-18-011836:notes:114]
Restricted Stock Units

[0001564590-18-011836:notes:115]
The Company granted 830 and 946 RSUs during the quarters ended April 2, 2018 and April 3, 2017, respectively. The RSUs granted have a weighted-average fair value per unit of $15.29 and $15.78 for the quarters ended April 2, 2018 and April 3, 2017, respectively. The fair value for RSUs granted is based on the closing share price of the Company’s common stock on the date of grant.

[0001564590-18-011836:notes:116]
Stock Options

[0001564590-18-011836:notes:117]
The Company did not grant any stock option awards during the quarters ended April 2, 2018 and April 3, 2017.

[0001564590-18-011836:notes:118]
Summary of Unrecognized Compensation Costs

[0001564590-18-011836:notes:119]
The following is a summary of total unrecognized compensation costs as of April 2, 2018:

[0001564590-18-011836:notes:120]
|  |  | Unrecognized Stock- Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 25,679 |  |  |  | 1.6 |  |
| PRU awards |  |  | 9,393 |  |  |  | 1.3 |  |
| Stock options |  |  | 86 |  |  |  | 1.7 |  |
|  |  | $ | 35,158 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-011836:notes:121]
(14) Segment Information

[0001564590-18-011836:notes:122]
The reportable segments reported below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. The Company has two reportable segments: PCB and E-M Solutions. The PCB reportable segment is comprised of multiple operating segments. Factors considered to determine whether operating segments can be aggregated into reportable segments included similarity regarding economic characteristics, products, production processes, type or classes of customers, distribution methods, and regulatory environments.

[0001564590-18-011836:notes:123]
The Company, including the chief operating decision maker, evaluates segment performance based on reportable segment income, which is operating income before amortization of intangibles. Interest expense and interest income are not presented by segment since they are not included in the measure of segment profitability reviewed by the chief operating decision maker. All inter-segment transactions have been eliminated.

[0001564590-18-011836:notes:124]
The inter-segment sales for the quarters ended April 2, 2018 and April 3, 2017, are sales primarily from the PCB to the E-M Solutions operating segment.

[0001564590-18-011836:notes:125]
|  |  | For the Quarter Ended |  |
|  |  | April 2, 2018 |  |  | April 3, 2017 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 619,329 |  |  | $ | 586,695 |  |
| E-M Solutions |  |  | 47,151 |  |  |  | 41,669 |  |
| Total sales |  |  | 666,480 |  |  |  | 628,364 |  |
| Inter-segment sales |  |  | (2,898 | ) |  |  | (3,117 | ) |
| Total net sales |  | $ | 663,582 |  |  | $ | 625,247 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |
| PCB |  | $ | 63,464 |  |  | $ | 82,256 |  |
| E-M Solutions |  |  | 40 |  |  |  | (1,642 | ) |
| Corporate |  |  | (27,642 | ) |  |  | (22,132 | ) |
| Total operating segment income |  |  | 35,862 |  |  |  | 58,482 |  |
| Amortization of definite-lived intangibles |  |  | (5,861 | ) |  |  | (5,912 | ) |
| Total operating income |  |  | 30,001 |  |  |  | 52,570 |  |
| Total other expense |  |  | (14,854 | ) |  |  | (15,306 | ) |
| Income before income taxes |  | $ | 15,147 |  |  | $ | 37,264 |  |

[0001564590-18-011836:notes:126]
The Corporate category includes operating expenses that are not included in the segment operating performance measures. Corporate consists primarily of corporate governance functions such as finance, accounting, corporate sales, information technology, facilities, corporate operations and human resources personnel. Bank fees and legal, accounting, and other professional service costs associated with the acquisition of Anaren Holdings Corp. in the amount of $3,973 for the quarter ended April 2, 2018 are included in Corporate. See Note 16 Subsequent Event.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001564590-18-011836:notes:127]
(15) Related Party Transactions

[0001564590-18-011836:notes:128]
In the normal course of business, the Company’s foreign subsidiaries purchase laminate and prepreg from related parties in which a significant shareholder of the Company holds an equity interest. For the quarters ended April 2, 2018 and April 3, 2017, the Company’s foreign subsidiaries purchased $12,708 and $13,540, respectively, of laminate and prepreg from these related parties.

[0001564590-18-011836:notes:129]
As of April 2, 2018 and January 1, 2018, the Company’s consolidated condensed balance sheets included $16,095 and $14,452, respectively, in accounts payable due to related parties primarily for purchases of laminate and prepreg and such balances are included as a component of accounts payable on the consolidated condensed balance sheets.


## us-gaap:SubsequentEventsTextBlock

[0001564590-18-011836:notes:130]
(16) Subsequent Event

[0001564590-18-011836:notes:131]
On April 18, 2018, the Company completed its acquisition of all of the issued and outstanding common stock of Anaren Holding Corp. for total consideration of $775,000 in cash subject to customary working capital and certain other adjustments. Other than the equity interests of Anaren, Inc. (Anaren), Anaren Holding Corp. has no material assets or liabilities and has no material independent operations. Anaren is a leading provider of mission-critical radio frequency (RF) solutions, microelectronics, and microwave components and assemblies for the wireless infrastructure and space and defense electronics markets.

[0001564590-18-011836:notes:132]
Additionally, the Company closed its $600,000 commitment of incremental loans concurrent with the completion of its acquisition of Anaren. The Company used the proceeds of the incremental loan, along with cash on hand to fund the purchase price of the Anaren acquisition and to pay related fees and expenses.

[0001564590-18-011836:notes:133]
The acquisition will be accounted for using the acquisition method; however the accounting was incomplete at the time these financial statements were issued. As a result, the purchase price allocation and pro-forma income statement disclosures have not been provided. The first periodic report that will include results of operations for Anaren will be the Company’s Form 10-Q for the quarter ended July 2, 2018.
