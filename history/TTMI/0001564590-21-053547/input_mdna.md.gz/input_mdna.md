# TTMI MD&A — 0001564590-21-053547


## mdna

[0001564590-21-053547:mdna:1]
[same as prior period, unchanged from 0001564590-21-040796:mdna:1]

[0001564590-21-053547:mdna:2]
[same as prior period, unchanged from 0001564590-21-040796:mdna:2]

[0001564590-21-053547:mdna:3]
We are a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and volume production of technologically advanced PCBs and backplane assemblies as well as a global designer and manufacturer of high-frequency radio frequency (RF) and microwave components and assemblies. We focus on providing time-to-market and volume production of advanced technology products and offer a one-stop design, engineering and manufacturing solution to our customers. This one-stop design, engineering and manufacturing solution allows us to align technology development with the diverse needs of our customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,400 customers in various markets throughout the world, including aerospace and defense, data center computing, automotive components, medical, industrial and instrumentation related products, as well as networking/communications infrastructure products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001564590-21-053547:mdna:4]
[same as prior period, unchanged from 0001564590-21-040796:mdna:4]

[0001564590-21-053547:mdna:5]
The coronavirus (COVID-19) pandemic initially caused business disruption to our operations in China in January 2020. By March 2020, the situation escalated as the scope of the COVID-19 pandemic worsened outside of the Asia-Pacific region, with Europe and North America being affected by the pandemic. With the development and deployment of vaccines, the pandemic has declined. However, as new variants evolve, we could see a rebound in the severity of the pandemic. As a result, we expect continued impacts on our production, as well as ongoing significant uncertainty relating to the actual and potential impacts of the COVID-19 pandemic, and we cannot reasonably estimate its duration or severity. The COVID-19 pandemic has created and continues to create various global macroeconomic, customer demand, operational and supply chain risks, any one of which could have a material and adverse impact on our business going forward. See Item 1A, Risk Factors, of Part II below for further information related to the COVID-19 pandemic.

[0001564590-21-053547:mdna:6]
We have taken active measures to protect our employees, suppliers and customers by implementing extensive pandemic recovery protocols, establishing situational leadership teams in Asia-Pacific and North America along with regularly scheduled executive review and planning calls, implementing global travel restrictions, and conforming to the guidance and direction of local governments and global health organizations. We are monitoring the impacts the COVID-19 pandemic has had, and continues to have, on our supply chain and are collaborating with our third-party partners with the goal of mitigating, to the extent reasonably practicable, significant delays in delivery of our products.

[0001564590-21-053547:mdna:7]
We continue to experience supply chain constraints and inflationary pressures. We have been actively managing both supply chain constraints and higher raw materials costs through such measures as supplier diversification, ongoing operational efficiency efforts and quotation adjustments to mitigate the impact on our business.

[0001564590-21-053547:mdna:8]
We also continue to see more challenges in attracting and retaining labor in North America. We actively seek to demonstrate employees’ value to our business through a combination of financial and non-financial methods.  However, a number of factors may continue to adversely affect the labor force available to us, including high employment levels, government regulations, and wage inflation. An overall labor shortage, lack of skilled labor, increased turnover or labor inflation could have a material adverse impact on our business.

[0001564590-21-053547:mdna:9]
[same as prior period, unchanged from 0001564590-21-040796:mdna:7]

[0001564590-21-053547:mdna:10]
Results related to our Mobility business unit are reported as discontinued operations for all periods presented. See Part I, Item 1, Note 2, Discontinued Operations, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q for further information. Unless otherwise noted, amounts and disclosures throughout our Management’s Discussion and Analysis of Financial Condition and Results of Operations relate to our continuing operations. We use a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal 2021 ending on January 3, 2022 will be a 53-week year with the additional week included in the fourth quarter. Fiscal 2020 was a 52-week year.

[0001564590-21-053547:mdna:11]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies, as they are the ultimate end customers. Sales to our ten largest customers collectively accounted for 41% of our net sales for both the quarter and

[0001564590-21-053547:mdna:12]
three quarters ended September 27, 2021. Sales to our ten largest customers accounted for 40% and 38% of our net sales for the quarter and three quarters ended September 28, 2020, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001564590-21-053547:mdna:13]
[same as prior period, unchanged from 0001564590-21-040796:mdna:10]

[0001564590-21-053547:mdna:14]
|  |  | Quarter Ended |  |  |  | Three Quarters Ended |  |  |
| End Markets (1) |  | September 27, 2021 |  |  |  | September 28, 2020 |  |  |  | September 27, 2021 |  |  |  | September 28, 2020 |  |  |
| Aerospace and Defense |  |  | 31 |  | % |  |  | 36 |  | % |  |  | 33 |  | % |  |  | 35 |  | % |
| Automotive |  |  | 18 |  |  |  |  | 14 |  |  |  |  | 18 |  |  |  |  | 13 |  |  |
| Data Center Computing (2) |  |  | 14 |  |  |  |  | 12 |  |  |  |  | 14 |  |  |  |  | 12 |  |  |
| Medical/Industrial/Instrumentation |  |  | 20 |  |  |  |  | 19 |  |  |  |  | 19 |  |  |  |  | 20 |  |  |
| Networking/Communications |  |  | 16 |  |  |  |  | 18 |  |  |  |  | 15 |  |  |  |  | 18 |  |  |
| Other (3) |  |  | 1 |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  | 2 |  |  |
| Total |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |  |  | 100 |  | % |

[0001564590-21-053547:mdna:15]
[same as prior period, unchanged from 0001564590-21-040796:mdna:12]

[0001564590-21-053547:mdna:16]
[same as prior period, unchanged from 0001564590-21-040796:mdna:13]

[0001564590-21-053547:mdna:17]
[same as prior period, unchanged from 0001564590-21-040796:mdna:14]

[0001564590-21-053547:mdna:18]
[same as prior period, unchanged from 0001564590-21-040796:mdna:15]

[0001564590-21-053547:mdna:19]
[same as prior period, unchanged from 0001564590-21-040796:mdna:16]

[0001564590-21-053547:mdna:20]
[same as prior period, unchanged from 0001564590-21-040796:mdna:17]

[0001564590-21-053547:mdna:21]
[same as prior period, unchanged from 0001564590-21-040796:mdna:18]

[0001564590-21-053547:mdna:22]
[same as prior period, unchanged from 0001564590-21-040796:mdna:19]

[0001564590-21-053547:mdna:23]
[same as prior period, unchanged from 0001564590-21-040796:mdna:20]

[0001564590-21-053547:mdna:24]
[same as prior period, unchanged from 0001564590-21-040796:mdna:21]

[0001564590-21-053547:mdna:25]
[same as prior period, unchanged from 0001564590-21-040796:mdna:22]

[0001564590-21-053547:mdna:26]
[same as prior period, unchanged from 0001564590-21-040796:mdna:23]

[0001564590-21-053547:mdna:27]
[same as prior period, unchanged from 0001564590-21-040796:mdna:24]

[0001564590-21-053547:mdna:28]
[same as prior period, unchanged from 0001564590-21-040796:mdna:25]

[0001564590-21-053547:mdna:29]
[same as prior period, unchanged from 0001564590-21-040796:mdna:26]

[0001564590-21-053547:mdna:30]
|  |  | Quarter Ended |  | Three Quarters Ended |
|  |  | September 27, 2021 |  |  |  | September 28, 2020 |  |  |  | September 27, 2021 |  |  |  | September 28, 2020 |  |  |
| Net sales |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |  |  | 100.0 |  | % |
| Cost of goods sold |  |  | 83.3 |  |  |  |  | 82.6 |  |  |  |  | 83.4 |  |  |  |  | 82.9 |  |  |
| Gross profit |  |  | 16.7 |  |  |  |  | 17.4 |  |  |  |  | 16.6 |  |  |  |  | 17.1 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.8 |  |  |  |  | 3.1 |  |  |  |  | 2.8 |  |  |  |  | 3.0 |  |  |
| General and administrative |  |  | 5.8 |  |  |  |  | 5.7 |  |  |  |  | 5.8 |  |  |  |  | 7.0 |  |  |
| Research and development |  |  | 0.8 |  |  |  |  | 1.0 |  |  |  |  | 0.8 |  |  |  |  | 0.9 |  |  |
| Amortization of definite-lived intangibles |  |  | 1.5 |  |  |  |  | 2.0 |  |  |  |  | 1.6 |  |  |  |  | 1.8 |  |  |
| Impairment of goodwill |  |  | — |  |  |  |  | 13.4 |  |  |  |  | — |  |  |  |  | 4.4 |  |  |
| Total operating expenses |  |  | 10.9 |  |  |  |  | 25.2 |  |  |  |  | 11.0 |  |  |  |  | 17.1 |  |  |
| Operating income (loss) |  |  | 5.8 |  |  |  |  | (7.8 | ) |  |  |  | 5.6 |  |  |  |  | — |  |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.0 | ) |  |  |  | (3.9 | ) |  |  |  | (2.0 | ) |  |  |  | (3.7 | ) |  |
| Loss on extinguishment of debt |  |  | — |  |  |  |  | — |  |  |  |  | (0.9 | ) |  |  |  | — |  |  |
| Other, net |  |  | 0.5 |  |  |  |  | (0.5 | ) |  |  |  | 0.3 |  |  |  |  | — |  |  |
| Total other expense, net |  |  | (1.5 | ) |  |  |  | (4.4 | ) |  |  |  | (2.6 | ) |  |  |  | (3.7 | ) |  |
| Income (loss) from continuing operations before income taxes |  |  | 4.3 |  |  |  |  | (12.2 | ) |  |  |  | 3.0 |  |  |  |  | (3.7 | ) |  |
| Income tax (provision) benefit |  |  | (0.5 | ) |  |  |  | 0.3 |  |  |  |  | (0.2 | ) |  |  |  | 0.2 |  |  |
| Net income (loss) from continuing operations |  |  | 3.8 |  | % |  |  | (11.9 | ) | % |  |  | 2.8 |  | % |  |  | (3.5 | ) | % |

[0001564590-21-053547:mdna:31]
As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting and the SH BPA facility has been integrated into the PCB reportable segment. As a result, we reclassified prior periods to reflect these changes to our segments.

[0001564590-21-053547:mdna:32]
[same as prior period, unchanged from 0001564590-21-040796:mdna:29]

[0001564590-21-053547:mdna:33]
Total net sales increased $43.2 million, or 8.4%, to $556.8 million for the third quarter of 2021 from $513.6 million for the third quarter of 2020. This increase in total net sales primarily resulted from an increase in net sales for the PCB reportable segment of $59.8 million, or 12.4%, to $541.1 million for the third quarter of 2021 from $481.3 million for the third quarter of 2020 primarily due to higher demand in our Automotive, Data Center Computing, and Medical/Industrial/Instrumentation end markets partially offset by lower demand in our Aerospace and Defense end market. These changes in the PCB reportable segment resulted in a 16.8% increase in the volume of PCB shipments. Additionally, there was an increase in net sales for the RF&S Components reportable segment of $3.9 million, or 33.4%, to $15.7 million for the third quarter of 2021 from $11.7 million for the third quarter of 2020 primarily due to higher demand in our Networking/Communications end market. Partially offsetting the PCB and RF&S increases was a $20.5 million reduction in net sales due to the closure of the two plants from our discontinued E-M Solutions segment.

[0001564590-21-053547:mdna:34]
Total net sales increased $69.1 million, or 4.4%, to $1,650.6 million for the first three quarters of 2021 from $1,581.5 million for the first three quarters of 2020. This increase in total net sales primarily resulted from an increase in net sales for the PCB reportable segment of $112.9 million, or 7.6%, to $1,605.1 million for the first three quarters of 2021 from $1,492.2 million for the first three quarters of 2020 primarily due to higher demand in our Automotive and Data Center Computing end markets, partially offset by lower demand in our Networking/Communications and Aerospace and Defense end markets. These changes in the PCB reportable segment resulted in a 25.8% increase in the volume of PCB shipments. Also contributing to the increase in total net sales was an increase in net sales for the RF&S Components reportable segment of $9.0 million, or 27.0%, to $42.3 million for the first three quarters of 2021 from $33.3 million for the first three quarters of 2020 primarily due to higher demand in our Networking/Communications and Medical/Industrial/Instrumentation end markets. Partially offsetting the PCB and RF&S increases was a $52.8 million reduction in net sales due to the closure of the two plants from our discontinued E-M Solutions segment.

[0001564590-21-053547:mdna:35]
[same as prior period, unchanged from 0001564590-21-040796:mdna:32]

[0001564590-21-053547:mdna:36]
Overall gross margin decreased to 16.7% for the third quarter of 2021 from 17.4% for the third quarter of 2020. Gross margin for the PCB reportable segment decreased to 15.8% for the third quarter of 2021 from 18.3% for the third quarter of 2020. This decline was primarily due to unfavorable foreign exchange rates which increased our cost of operations in China and production inefficiencies in North America. During the quarter, we did experience significant material cost increases, but we were able to mitigate the profit impact of those increases through customer price increases and manufacturing efficiencies. Gross margin for the RF&S Components reportable segment increased to 57.9% for the third quarter of 2021 from 48.1% for the third quarter of 2020, primarily due to higher sales.

[0001564590-21-053547:mdna:37]
Overall gross margin decreased to 16.6% for the first three quarters of 2021 from 17.1% for the first three quarters of 2020. This decrease was primarily driven by a decrease in gross margin for the PCB reportable segment to 16.3% for the first three quarters of 2021 from 18.3% for the first three quarters of 2020. This decline was primarily due to unfavorable foreign exchange rates which increased our cost of operations, higher raw material costs due to increased commodity prices, primarily copper, and production and labor inefficiencies. We were able to mitigate most of these costs through higher revenue and production and spending efficiencies including savings from the closure of two of our E-M Solutions factories. Gross margin for the RF&S Components reportable segment increased to 54.2% for the first three quarters of 2021 from 50.8% for the first three quarters of 2020, primarily due to higher sales.

[0001564590-21-053547:mdna:38]
Capacity utilization is a key driver for us, which is measured by actual production as a percentage of maximum capacity. This measure is particularly important in our high-volume facilities in Asia, as a significant portion of our operating costs are fixed in nature. Capacity utilization for the third quarter of 2021 in our Asia and North America PCB facilities was 91% and 50%, respectively, compared to 63% and 61%, respectively, for the third quarter of 2020. Capacity utilization for the first three quarters of 2021 in our Asia and North America PCB facilities was 86% and 52%, respectively, compared to 62% and 63%, respectively for the first three quarters of 2020. The increase in capacity utilization in our Asia PCB facilities was due to an increase in production resulting from increased sales in our Automotive and Data Center Computing end markets. The decrease in our capacity utilization in our North America PCB facilities was primarily due to increased capacity resulting from equipment expansion.

[0001564590-21-053547:mdna:39]
Selling and Marketing Expense

[0001564590-21-053547:mdna:40]
Selling and marketing expense was $15.9 million for both the third quarter of 2021 and 2020. As a percentage of net sales, selling and marketing expense was 2.8% for the third quarter of 2021, as compared to 3.1% for the third quarter of 2020.

[0001564590-21-053547:mdna:41]
Selling and marketing expense decreased $1.3 million, to $46.7 million for the first three quarters of 2021 from $48.0 million for the first three quarters of 2020. As a percentage of net sales, selling and marketing expense was 2.8% for the first three quarters of 2021, as compared to 3.0% for the first three quarters of 2020. The decrease in selling and marketing expense for the first three quarters of 2021 was primarily due to a decrease in commission expense and continued reduced travel costs due to the COVID-19 pandemic, which has decreased travel on what we believe to be a temporary basis.

[0001564590-21-053547:mdna:42]
General and Administrative Expense

[0001564590-21-053547:mdna:43]
General and administrative expense increased $3.3 million to $32.4 million, or 5.8% of net sales, for the third quarter of 2021 from $29.1 million, or 5.7% of net sales, for the third quarter of 2020. This increase was primarily due to an increase in labor costs and other spending.

[0001564590-21-053547:mdna:44]
General and administrative expense decreased $15.4 million to $95.2 million, or 5.8% of net sales, for the first three quarters of 2021 from $110.5 million, or 7.0% of net sales, for the first three quarters of 2020. This decrease was primarily due to a reduction in restructuring charges of $10.8 million associated with the restructuring of our E-M Solutions business unit and decreases in depreciation, supplies, stock-based compensation expense and bad debt, partially offset by higher incentive compensation.

[0001564590-21-053547:mdna:45]
[same as prior period, unchanged from 0001564590-21-040796:mdna:43]

[0001564590-21-053547:mdna:46]
Other expense, net decreased $13.9 million to $8.6 million for the third quarter of 2021 from $22.5 million for the third quarter of 2020. This decrease was primarily the result of a decrease in interest expense of $9.1 million due to overall lower levels of debt outstanding and the refinancing of our notes. Additionally, there was an increase in other income of $2.7 million for the third quarter of 2021 related to the change in fair value of warrant liabilities.

[0001564590-21-053547:mdna:47]
Other expense, net decreased $14.4 million to $43.5 million for the first three quarters of 2021 from $57.9 million for the first three quarters of 2020. This decrease was primarily the result of a decrease in interest expense of $24.9 million due to overall lower levels of debt outstanding and an increase in other income of $3.9 million for the first three quarters of 2021 related to the change in fair value of warrant liabilities, partially offset by $15.2 million of loss on extinguishment of debt.

[0001564590-21-053547:mdna:48]
[same as prior period, unchanged from 0001564590-21-040796:mdna:46]

[0001564590-21-053547:mdna:49]
Income tax expense increased by $4.0 million to $2.7 million of tax expense for the third quarter of 2021 from $1.3 million of tax benefit for the third quarter of 2020. The increase in income tax expense for the third quarter of 2021 was primarily due to an

[0001564590-21-053547:mdna:50]
increase in pre-tax income from continuing operations and an increase in uncertain tax positions in the United States, partially offset by the tax benefit resulting from a reduction in deferred tax liability for the foreign withholding tax accrual with respect to the Company’s indefinite reinvestment policy outside of the United States.

[0001564590-21-053547:mdna:51]
Income tax expense increased by $7.0 million to $3.4 million of tax expense for the first three quarters of 2021 from $3.6 million of tax benefit for the first three quarters of 2020. The increase in income tax expense for the first three quarters of 2021 was primarily due to a lower uncertain tax position release benefit due to the expiration of the statute of limitation in foreign jurisdictions, and an increase in uncertain tax positions in the United States partially offset by (i) the absence of tax expense associated with the two E-M Solutions plants that we closed in 2020, (ii) the approval of the Company’s renewal application for High and New Enterprise status for two of the Company’s manufacturing subsidiaries in China in the current year, and (iii) the reduction in the deferred tax liability for the foreign withholding tax accrual with respect to the Company’s indefinite reinvestment policy outside of the United States.

[0001564590-21-053547:mdna:52]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, the generation of credits and deductions available to the Company as well as changes in valuation allowances and certain non-deductible items. We had a net deferred income tax asset of approximately $12.9 million and $15.3 million as of September 27, 2021 and September 28, 2020, respectively.

[0001564590-21-053547:mdna:53]
[same as prior period, unchanged from 0001564590-21-040796:mdna:51]

[0001564590-21-053547:mdna:54]
[same as prior period, unchanged from 0001564590-21-040796:mdna:52]

[0001564590-21-053547:mdna:55]
[same as prior period, unchanged from 0001564590-21-040796:mdna:53]

[0001564590-21-053547:mdna:56]
Cash flow provided by operating activities for continuing operations during the first three quarters of 2021 was $114.3 million as compared to cash flow provided by operating activities for continuing operations of $192.2 million in the same period in 2020. The decrease in cash flow was primarily due to the collection of Mobility-related accounts receivable after the sale of the business unit in 2020, partially offset by an increase in net income from continuing operations of $101.4 million.

[0001564590-21-053547:mdna:57]
Net cash used in investing activities for continuing operations was approximately $61.1 million for the first three quarters of 2021, reflecting $62.1 million for purchases of property, plant and equipment and other assets less $1.0 million for proceeds from sale of property, plant and equipment and other assets. Net cash used in investing activities for continuing operations was approximately $75.0 million for the first three quarters of 2020, comprised primarily of $74.5 million for purchases of property, plant and equipment and other assets.

[0001564590-21-053547:mdna:58]
Net cash provided by financing activities for continuing operations during the first three quarters of 2021 was $24.8 million, primarily reflecting proceeds from long-term debt borrowing of $500.0 million, less the repayment of long-term debt borrowings of $425.8 million, repurchases of common stock of $33.2 million, capital equipment financing of $7.1 million, payment of debt issuance costs of $5.9 million, and cash used to settle warrants of $3.2 million. Net cash used in financing activities for continuing operations during the first three quarters of 2020 was $392.5 million, reflecting repayment of long-term debt of $400.0 million, offset by $7.3 million for capital equipment financing.

[0001564590-21-053547:mdna:59]
As of September 27, 2021, we had cash and cash equivalents of approximately $529.8 million, of which approximately $174.6 million was held by our foreign subsidiaries, primarily in China. Should we choose to remit cash to the United States from our foreign locations, we may incur tax obligations which would reduce the amount of cash ultimately available to the United States. However, we believe there would be no material tax consequences not previously accrued for the repatriation of this cash.

[0001564590-21-053547:mdna:60]
Our total 2021 capital expenditures are expected to be in the range of $75.0 million to $95.0 million.

[0001564590-21-053547:mdna:61]
[same as prior period, unchanged from 0001564590-21-040796:mdna:59]

[0001564590-21-053547:mdna:62]
As of September 27, 2021, we had $926.9 million of outstanding debt, net of discount and debt issuance costs, composed of $493.9 million of Senior Notes due March 2029, $403.0 million of a Term Loan due September 2024, and $30.0 million under the Asia Asset-Based Lending Credit Agreement (Asia ABL).

[0001564590-21-053547:mdna:63]
Pursuant to the terms of the Term Loan Facility and Senior Notes due 2029, we are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments. Under the occurrence of certain events, under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and Asia ABL (collectively, the ABL Revolving Loans), we are also subject to various financial covenants, including leverage and fixed charge coverage ratios. As of September 27, 2021, we were in compliance with the covenants under the Term Loan Facility, Senior Notes due 2029 and ABL Revolving Loans.

[0001564590-21-053547:mdna:64]
[same as prior period, unchanged from 0001564590-21-040796:mdna:62]

[0001564590-21-053547:mdna:65]
[same as prior period, unchanged from 0001564590-21-040796:mdna:63]

[0001564590-21-053547:mdna:66]
The following table provides information on our contractual obligations as of September 27, 2021:

[0001564590-21-053547:mdna:67]
|  |  | Total |  |  | Less Than 1 Year |  |  | 1 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Contractual Obligations (1) |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 935,879 |  |  | $ | — |  |  | $ | 435,879 |  |  | $ | — |  |  | $ | 500,000 |  |
| Interest on debt obligations (2) |  |  | 181,570 |  |  |  | 31,280 |  |  |  | 61,901 |  |  |  | 40,000 |  |  |  | 48,389 |  |
| Derivative liabilities |  |  | 7,485 |  |  |  | 7,485 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 231,111 |  |  |  | 198,322 |  |  |  | 21,531 |  |  |  | 3,417 |  |  |  | 7,841 |  |
| Total contractual obligations |  | $ | 1,356,045 |  |  | $ | 237,087 |  |  | $ | 519,311 |  |  | $ | 43,417 |  |  | $ | 556,230 |  |

[0001564590-21-053547:mdna:68]
| (1) | Unrecognized uncertain tax benefits of $1.7 million are not included in the table above as the settlement timing is uncertain. Leases are not included in the table above – see Part I, Item 1, Note 3, Leases, of the Notes to Consolidated Condensed Financial Statements included in this Quarterly Report on Form 10-Q for further details. |

[0001564590-21-053547:mdna:69]
| (2) | For debt obligations based on variable rates, interest rates used are as of September 27, 2021. |

[0001564590-21-053547:mdna:70]
[same as prior period, unchanged from 0001564590-21-040796:mdna:68]

[0001564590-21-053547:mdna:71]
[same as prior period, unchanged from 0001564590-21-040796:mdna:69]

[0001564590-21-053547:mdna:72]
[same as prior period, unchanged from 0001564590-21-040796:mdna:70]

[0001564590-21-053547:mdna:73]
[same as prior period, unchanged from 0001564590-21-040796:mdna:71]

[0001564590-21-053547:mdna:74]
Recently Issued Accounting Standards

[0001564590-21-053547:mdna:75]
[same as prior period, unchanged from 0001564590-21-040796:mdna:73]
