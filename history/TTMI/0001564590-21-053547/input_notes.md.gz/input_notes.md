# TTMI notes — 0001564590-21-053547


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001564590-21-053547:notes:1]
[same as prior period, unchanged from 0001564590-21-040796:notes:1]

[0001564590-21-053547:notes:2]
[same as prior period, unchanged from 0001564590-21-040796:notes:2]

[0001564590-21-053547:notes:3]
[same as prior period, unchanged from 0001564590-21-040796:notes:3]

[0001564590-21-053547:notes:4]
The accompanying consolidated condensed financial statements have been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been condensed or omitted pursuant to such rules and regulations. It is suggested that these consolidated condensed financial statements be read in conjunction with the consolidated financial statements and the notes thereto included in the Company’s most recent Annual Report on Form 10-K. The preparation of financial statements in accordance with U.S. GAAP requires management to make estimates and assumptions that affect the amounts reported in the Company’s consolidated condensed financial statements and accompanying notes. Due to the coronavirus (COVID-19) global pandemic, the global economy and financial markets have been volatile, have contributed to disruptions in global supply chains and labor shortages, and there is a significant amount of uncertainty about the length and severity of the consequences caused by the on-going pandemic. The Company has considered information available to it as of the date of issuance of these financial statements and is not aware of any specific events or circumstances that would require an update to its estimates or judgments, or a revision to the carrying value of its assets or liabilities. Actual results could differ materially from those estimates. The Company uses a 52/53 week fiscal calendar with the fourth quarter ending on the Monday nearest December 31. Fiscal 2021 ending on January 3, 2022 will be a 53-week year with the additional week included in the fourth quarter. Fiscal 2020 was a 52-week year.

[0001564590-21-053547:notes:5]
On January 19, 2020, the Company entered into a definitive equity interests purchase agreement with AKMMeadville Electronics (Xiamen) Co., Ltd (the Purchaser) for the sale that was completed on April 17, 2020 of the following now former Company subsidiaries: Shanghai Kaiser Electronics Co., Ltd. (SKE), Shanghai Meadville Electronics Co., Ltd. (SME), Shanghai Meadville Science & Technology Co., Ltd. (SP) and Guangzhou Meadville Electronics Co., Ltd. (GME) (collectively, the Mobility business unit). For all periods presented in the consolidated condensed statements of operations, all sales, costs, expenses, income taxes and gain on sale attributable to the Mobility business unit have been aggregated under the caption “Income from discontinued operations, net of income taxes”. Refer to Note 2, Discontinued Operations, for additional information.

[0001564590-21-053547:notes:6]
[same as prior period, unchanged from 0001564590-21-040796:notes:6]

[0001564590-21-053547:notes:7]
[same as prior period, unchanged from 0001564590-21-040796:notes:7]

[0001564590-21-053547:notes:8]
The Company currently has two reportable segments: PCB and RF and Specialty Components (RF&S Components). On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting. As a result of the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.

[0001564590-21-053547:notes:9]
[same as prior period, unchanged from 0001564590-21-040796:notes:11]

[0001564590-21-053547:notes:10]
Recently Adopted Accounting Standards

[0001564590-21-053547:notes:11]
In December 2019, the Financial Accounting Standards Board (FASB) issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is intended to simplify various aspects related to accounting for income taxes. ASU 2019-12 removes certain exceptions to the general principles in Topic 740 and also clarifies and amends existing guidance to improve consistent application. The guidance is effective for fiscal years beginning after December 15, 2020, including interim periods within those fiscal years. Early adoption is permitted. The Company adopted this ASU as of December 29, 2020 and it did not have a material impact on its consolidated condensed financial statements and related disclosures.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001564590-21-053547:notes:12]
[same as prior period, unchanged from 0001564590-21-040796:notes:14]

[0001564590-21-053547:notes:13]
[same as prior period, unchanged from 0001564590-21-040796:notes:15]

[0001564590-21-053547:notes:14]
[same as prior period, unchanged from 0001564590-21-040796:notes:16]

[0001564590-21-053547:notes:15]
[same as prior period, unchanged from 0001564590-21-040796:notes:17]

[0001564590-21-053547:notes:16]
As the sale of the Company’s Mobility business unit represented a strategic shift that had a major effect on the Company’s operations and financial results, in accordance with the provisions of FASB authoritative guidance on the presentation of financial statements, Mobility business unit results are classified as discontinued operations in the consolidated condensed statements of operations for all periods presented.

[0001564590-21-053547:notes:17]
The following table summarizes the results of Mobility operations for the quarter and three quarters ended September 28, 2020 prior to sale:

[0001564590-21-053547:notes:18]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 28, |  |  | September 28, |  |
|  |  | 2020 |  |  | 2020 |  |
|  |  | (In thousands, except per share data) |  |
| Net sales |  | $ | — |  |  | $ | 143,951 |  |
| Cost of goods sold |  |  | — |  |  |  | 136,800 |  |
| Gross profit |  |  | — |  |  |  | 7,151 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | — |  |  |  | 1,461 |  |
| General and administrative |  |  | — |  |  |  | 2,317 |  |
| Research and development |  |  | — |  |  |  | 147 |  |
| Amortization of definite-lived intangibles |  |  | — |  |  |  | 809 |  |
| Total operating expenses |  |  | — |  |  |  | 4,734 |  |
| Operating income |  |  | — |  |  |  | 2,417 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | — |  |  |  | (223 | ) |
| Gain on sale of the Mobility business unit |  |  | — |  |  |  | 237,253 |  |
| Other, net |  |  | — |  |  |  | 1,160 |  |
| Total other income, net |  |  | — |  |  |  | 238,190 |  |
| Income from discontinued operations before income taxes |  |  | — |  |  |  | 240,607 |  |
| Income tax benefit (provision) |  |  | 20,021 |  |  |  | (46,686 | ) |
| Income from discontinued operations, net of income taxes |  | $ | 20,021 |  |  | $ | 193,921 |  |
| Earnings per share from discontinued operations: |  |  |  |  |  |  |  |  |
| Basic earnings per share |  | $ | 0.19 |  |  | $ | 1.83 |  |
| Diluted earnings per share |  | $ | 0.19 |  |  | $ | 1.83 |  |

[0001564590-21-053547:notes:19]
There was no depreciation expense related to the discontinued operations for the quarter ended September 28, 2020. Depreciation expense related to the discontinued operations for the three quarters ended September 28, 2020 was $21,382.

[0001564590-21-053547:notes:20]
During the quarter and three quarters ended September 28, 2020, the Company’s income tax expense related to the discontinued operations was impacted by a net discrete tax benefit of $20,021 and a net discrete tax expense of $46,686, respectively. As a result of the sale of the Mobility business unit, the discrete income tax benefit during the quarter ended September 28, 2020 is due to recognition of additional Internal Revenue Code (IRC) Section 250 deduction and foreign tax credit benefits. The net income tax expense for the three quarters ended September 28, 2020 is related mainly to (i) China withholding tax related to gain on sale, (ii) U.S. income tax related to Global Intangible Low Taxed Income (GILTI) inclusion net of IRC Section 250 deduction and foreign tax credits, offset by (iii) release of U.S. FIN 48 uncertain tax positions.

[0001564590-21-053547:notes:21]
[same as prior period, unchanged from 0001564590-21-040796:notes:23]

[0001564590-21-053547:notes:22]
[same as prior period, unchanged from 0001564590-21-040796:notes:24]

[0001564590-21-053547:notes:23]
[same as prior period, unchanged from 0001564590-21-040796:notes:25]

[0001564590-21-053547:notes:24]
[same as prior period, unchanged from 0001564590-21-040796:notes:26]


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001564590-21-053547:notes:25]
[same as prior period, unchanged from 0001564590-21-040796:notes:27]


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-21-053547:notes:26]
[same as prior period, unchanged from 0001564590-21-040796:notes:28]

[0001564590-21-053547:notes:27]
The Company leases some of its manufacturing and assembly plants, sales offices and equipment under non-cancellable operating leases that expire at various dates through 2049 and a manufacturing plant under a finance lease. The majority of the Company’s lease arrangements are comprised of fixed payments, and certain leases consist of variable payments based on equipment usage. These variable payments are not included in the measurement of the right-of-use (ROU) asset or lease liability due to uncertainty of the payment amount and are recorded as lease expense in the period incurred. Certain leases contain renewal provisions at the Company’s option. Most of the leases require the Company to pay for certain other costs such as property taxes and maintenance. Certain leases also contain rent escalation clauses (step rents) that require additional rental amounts in the later years of the term. Rent expense for leases with step rents is recognized on a straight-line basis over the minimum lease term. The lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-21-053547:notes:28]
[same as prior period, unchanged from 0001564590-21-040796:notes:30]

[0001564590-21-053547:notes:29]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 27, 2021 |  |  | September 28, 2020 |  |  | September 27, 2021 |  |  | September 28, 2020 |  |
|  |  | (In thousands) |  |
| Operating lease cost |  | $ | 2,015 |  |  | $ | 2,333 |  |  | $ | 6,147 |  |  | $ | 7,041 |  |
| Variable lease cost |  |  | 193 |  |  |  | 133 |  |  |  | 567 |  |  |  | 376 |  |
| Short-term lease cost |  |  | 89 |  |  |  | 84 |  |  |  | 198 |  |  |  | 482 |  |

[0001564590-21-053547:notes:30]
[same as prior period, unchanged from 0001564590-21-040796:notes:32]

[0001564590-21-053547:notes:31]
|  |  | Three Quarters Ended |  |
|  |  | September 27, 2021 |  |  | September 28, 2020 |  |
|  |  | (In thousands) |  |
| Cash paid for amounts included in the measurement of lease liabilities: |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 6,321 |  |  | $ | 6,636 |  |
| Right-of-use assets obtained in exchange for new lease obligations: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 1,954 |  |  |  | 6,559 |  |
| Finance lease |  |  | 15,256 |  |  |  | — |  |

[0001564590-21-053547:notes:32]
[same as prior period, unchanged from 0001564590-21-040796:notes:34]

[0001564590-21-053547:notes:33]
|  |  |  |  | As of |  |
|  |  | Balance Sheet Location |  | September 27, 2021 |  |  | December 28, 2020 |  |
|  |  |  |  | (In thousands) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease right-of-use assets |  | $ | 16,794 |  |  | $ | 24,340 |  |
| Finance lease |  | Property, plant and equipment, net |  |  | 14,743 |  |  |  | — |  |
| Total lease assets |  |  |  | $ | 31,537 |  |  | $ | 24,340 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  | Other current liabilities |  | $ | 5,528 |  |  | $ | 8,144 |  |
| Finance lease |  | Other current liabilities |  |  | 639 |  |  |  | — |  |
| Long-term: |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  | Operating lease liabilities |  |  | 12,077 |  |  |  | 17,211 |  |
| Finance lease |  | Other long-term liabilities |  |  | 14,124 |  |  |  | — |  |
| Total lease liabilities |  |  |  | $ | 32,368 |  |  | $ | 25,355 |  |

[0001564590-21-053547:notes:34]
|  |  | As of |  |
|  |  | September 27, 2021 |  |  | December 28, 2020 |  |
| Weighted average remaining lease term (years): |  |  |  |  |  |  |  |  |
| Operating leases |  | 4.1 |  |  | 4.2 |  |
| Finance lease |  | 14.9 |  |  |  | — |  |
| Weighted average discount rate: |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 2.89 | % |  |  | 3.31 | % |
| Finance lease |  |  | 2.69 | % |  |  | — |  |

[0001564590-21-053547:notes:35]
Maturities of the Company’s lease liabilities were as follows (1):

[0001564590-21-053547:notes:36]
|  |  | (In thousands) |  |
| Less than one year |  | $ | 2,573 |  |
| 1 - 2 years |  |  | 6,360 |  |
| 2 - 3 years |  |  | 5,152 |  |
| 3 - 4 years |  |  | 3,946 |  |
| 4 - 5 years |  |  | 3,574 |  |
| Thereafter |  |  | 15,308 |  |
| Total lease payments |  |  | 36,913 |  |
| Less imputed interest |  |  | (4,545 | ) |
| Total |  | $ | 32,368 |  |

[0001564590-21-053547:notes:37]
[same as prior period, unchanged from 0001564590-21-040796:notes:39]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-21-053547:notes:38]
[same as prior period, unchanged from 0001564590-21-040796:notes:40]

[0001564590-21-053547:notes:39]
As of September 27, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations for long-term contracts was $11,008. The Company expects to recognize revenue on approximately 84% of the remaining performance obligations for the Company’s long-term contracts over the next twelve months.

[0001564590-21-053547:notes:40]
Revenue from products and services transferred to customers over time and at a point in time accounted for 97% and 3%, respectively, of the Company’s revenue for the quarter and three quarters ended September 27, 2021, and 98% and 2%, respectively, of the Company’s revenue for the quarter and three quarters ended September 28, 2020.

[0001564590-21-053547:notes:41]
[same as prior period, unchanged from 0001564590-21-040796:notes:43]

[0001564590-21-053547:notes:42]
|  |  | Quarter Ended September 27, 2021 |  |  | Quarter Ended September 28, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 173,894 |  |  | $ | 12 |  |  | $ | 173,906 |  |  | $ | 182,558 |  |  | $ | 180 |  |  | $ | 18 |  |  | $ | 182,756 |  |  |
| Automotive |  |  | 99,205 |  |  |  | — |  |  |  | 99,205 |  |  |  | 63,114 |  |  |  | — |  |  |  | 10,097 |  |  |  | 73,211 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 38 |  |  |  | — |  |  |  | — |  |  |  | 38 |  |  |
| Data Center Computing (2) |  |  | 81,202 |  |  |  | — |  |  |  | 81,202 |  |  |  | 62,554 |  |  |  | 186 |  |  |  | 34 |  |  |  | 62,774 |  |  |
| Medical/Industrial/Instrumentation |  |  | 108,879 |  |  |  | 1,467 |  |  |  | 110,346 |  |  |  | 91,836 |  |  |  | 742 |  |  |  | 2,939 |  |  |  | 95,517 |  |  |
| Networking/Communications |  |  | 74,316 |  |  |  | 12,848 |  |  |  | 87,164 |  |  |  | 74,366 |  |  |  | 7,203 |  |  |  | 8,919 |  |  |  | 90,488 |  |  |
| Other |  |  | 3,622 |  |  |  | 1,339 |  |  |  | 4,961 |  |  |  | 6,845 |  |  |  | 3,431 |  |  |  | (1,484 | ) |  |  | 8,792 |  |  |
| Total |  | $ | 541,118 |  |  | $ | 15,666 |  |  | $ | 556,784 |  |  | $ | 481,311 |  |  | $ | 11,742 |  |  | $ | 20,523 |  |  | $ | 513,576 |  |  |

[0001564590-21-053547:notes:43]
|  |  | Three Quarters Ended September 27, 2021 |  |  | Three Quarters Ended September 28, 2020 |  |  |
|  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  | PCB |  |  | RF&S Components |  |  | Other (1) |  |  | Total |  |  |
| End Markets |  | (In thousands) |  |  |
| Aerospace and Defense |  | $ | 545,585 |  |  | $ | 24 |  |  | $ | — |  |  | $ | 545,609 |  |  | $ | 555,882 |  |  | $ | 189 |  |  | $ | 38 |  |  | $ | 556,109 |  |  |
| Automotive |  |  | 293,890 |  |  |  | — |  |  |  | 3,642 |  |  |  | 297,532 |  |  |  | 182,970 |  |  |  | — |  |  |  | 28,693 |  |  |  | 211,663 |  |  |
| Cellular Phone |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,334 |  |  |  | — |  |  |  | — |  |  |  | 1,334 |  |  |
| Data Center Computing (2) |  |  | 235,191 |  |  |  | 456 |  |  |  | — |  |  |  | 235,647 |  |  |  | 192,209 |  |  |  | 663 |  |  |  | 124 |  |  |  | 192,996 |  |  |
| Medical/Industrial/Instrumentation |  |  | 303,661 |  |  |  | 3,615 |  |  |  | 25 |  |  |  | 307,301 |  |  |  | 298,117 |  |  |  | 2,336 |  |  |  | 9,247 |  |  |  | 309,700 |  |  |
| Networking/Communications |  |  | 216,982 |  |  |  | 35,451 |  |  |  | 1 |  |  |  | 252,434 |  |  |  | 240,215 |  |  |  | 19,173 |  |  |  | 20,560 |  |  |  | 279,948 |  |  |
| Other |  |  | 9,775 |  |  |  | 2,713 |  |  |  | (412 | ) |  |  | 12,076 |  |  |  | 21,429 |  |  |  | 10,913 |  |  |  | (2,572 | ) |  |  | 29,770 |  |  |
| Total |  | $ | 1,605,084 |  |  | $ | 42,259 |  |  | $ | 3,256 |  |  | $ | 1,650,599 |  |  | $ | 1,492,156 |  |  | $ | 33,274 |  |  | $ | 56,090 |  |  | $ | 1,581,520 |  |  |

[0001564590-21-053547:notes:44]
| (1) | Other represents results from the now closed SH E-MS and SZ facilities. |

[0001564590-21-053547:notes:45]
[same as prior period, unchanged from 0001564590-21-040796:notes:47]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001564590-21-053547:notes:46]
[same as prior period, unchanged from 0001564590-21-040796:notes:48]

[0001564590-21-053547:notes:47]
|  |  | As of |  |
|  |  | September 27, 2021 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 124,772 |  |  | $ | 103,890 |  |
| Work-in-process |  |  | 11,763 |  |  |  | 7,841 |  |
| Finished goods |  |  | 3,520 |  |  |  | 3,920 |  |
|  |  | $ | 140,055 |  |  | $ | 115,651 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 62,061 |  |  | $ | 61,781 |  |
| Buildings and improvements |  |  | 423,313 |  |  |  | 398,540 |  |
| Machinery and equipment |  |  | 875,587 |  |  |  | 832,723 |  |
| Furniture and fixtures and other |  |  | 10,210 |  |  |  | 10,304 |  |
| Construction-in-progress |  |  | 34,528 |  |  |  | 33,191 |  |
|  |  |  | 1,405,699 |  |  |  | 1,336,539 |  |
| Less: Accumulated depreciation |  |  | (735,963 | ) |  |  | (686,104 | ) |
|  |  | $ | 669,736 |  |  | $ | 650,435 |  |
| Other current liabilities: |  |  |  |  |  |  |  |  |
| Sales returns and allowances |  | $ | 13,319 |  |  | $ | 13,015 |  |
| Income taxes payable |  |  | 9,877 |  |  |  | 2,428 |  |
| Derivative liabilities |  |  | 7,372 |  |  |  | — |  |
| Interest |  |  | 3,471 |  |  |  | 7,157 |  |
| Operating lease |  |  | 5,528 |  |  |  | 8,144 |  |
| Restructuring |  |  | 46 |  |  |  | 7,382 |  |
| Other |  |  | 53,644 |  |  |  | 51,296 |  |
|  |  | $ | 93,257 |  |  | $ | 89,422 |  |
| Other long-term liabilities: |  |  |  |  |  |  |  |  |
| Deferred income taxes |  | $ | 23,882 |  |  | $ | 23,704 |  |
| Defined benefit pension plan liability |  |  | 9,097 |  |  |  | 9,986 |  |
| Derivative liabilities |  |  | — |  |  |  | 14,968 |  |
| Finance lease |  |  | 14,124 |  |  |  | — |  |
| Other |  |  | 27,498 |  |  |  | 25,167 |  |
|  |  | $ | 74,601 |  |  | $ | 73,825 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-21-053547:notes:48]
[same as prior period, unchanged from 0001564590-21-040796:notes:50]

[0001564590-21-053547:notes:49]
As of September 27, 2021 and December 28, 2020, goodwill by reportable segment was as follows:

[0001564590-21-053547:notes:50]
|  |  | PCB |  | RF&S Components |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of September 27, 2021 and December 28, 2020 |  |  |  |  |  |  |  |  |  |  |
| Goodwill |  | $ | 700,724 |  | $ | 177,200 |  | $ | 877,924 |  |
| Accumulated impairment losses |  |  | (171,400 | ) |  | (69,200 | ) |  | (240,600 | ) |
|  |  | $ | 529,324 |  | $ | 108,000 |  | $ | 637,324 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-21-053547:notes:51]
[same as prior period, unchanged from 0001564590-21-040796:notes:53]

[0001564590-21-053547:notes:52]
As of September 27, 2021 and December 28, 2020, the components of definite-lived intangibles were as follows:

[0001564590-21-053547:notes:53]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| September 27, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 397,500 |  |  | $ | (176,979 | ) |  | $ | 220,521 |  |  |  | 10.9 |  |
| Technology |  |  | 47,650 |  |  |  | (17,852 | ) |  |  | 29,798 |  |  |  | 9.5 |  |
|  |  | $ | 445,150 |  |  | $ | (194,831 | ) |  | $ | 250,319 |  |  |  |  |  |
| December 28, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 397,500 |  |  | $ | (150,142 | ) |  | $ | 247,358 |  |  |  | 10.9 |  |
| Technology |  |  | 47,650 |  |  |  | (13,701 | ) |  |  | 33,949 |  |  |  | 9.5 |  |
|  |  | $ | 445,150 |  |  | $ | (163,843 | ) |  | $ | 281,307 |  |  |  |  |  |

[0001564590-21-053547:notes:54]
Definite-lived intangibles are amortized using the straight-line method of amortization over the useful life. Amortization expense was $9,658 and $11,510 for the quarters ended September 27, 2021 and September 28, 2020, respectively, and $30,988 and $33,400 for the three quarters ended September 27, 2021 and September 28, 2020, respectively. For both the quarter and three quarters ended September 27, 2021 and September 28, 2020, $1,384 and $4,151, respectively, of amortization expense is included in cost of goods sold.

[0001564590-21-053547:notes:55]
[same as prior period, unchanged from 0001564590-21-040796:notes:57]

[0001564590-21-053547:notes:56]
|  |  | (In thousands) |  |
| Remaining 2021 |  | $ | 10,191 |  |
| 2022 |  |  | 38,631 |  |
| 2023 |  |  | 36,713 |  |
| 2024 |  |  | 29,713 |  |
| 2025 |  |  | 25,397 |  |
| Thereafter |  |  | 109,674 |  |
|  |  | $ | 250,319 |  |


## us-gaap:LongTermDebtTextBlock

[0001564590-21-053547:notes:57]
(8) Long-term Debt and Letters of Credit

[0001564590-21-053547:notes:58]
The following table summarizes the long-term debt of the Company as of September 27, 2021 and December 28, 2020:

[0001564590-21-053547:notes:59]
|  |  | Interest Rate as of September 27, 2021 |  |  | Principal Outstanding as of September 27, 2021 |  |  | Interest Rate as of December 28, 2020 |  |  | Principal Outstanding as of December 28, 2020 |  |
|  |  | (In thousands) |  |
| Senior Notes due March 2029 |  |  | 4.00 |  | % | $ | 500,000 |  |  |  | — |  | % | $ | — |  |
| Term Loan due September 2024 |  |  | 2.59 |  |  |  | 405,879 |  |  |  | 2.65 |  |  |  | 405,879 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 5.63 |  |  |  | 375,000 |  |
| U.S. ABL Revolving Loan due June 2024 |  |  | — |  |  |  | — |  |  |  | 1.40 |  |  |  | 40,000 |  |
| Asia ABL Revolving Loan due June 2024 |  |  | 1.49 |  |  |  | 30,000 |  |  |  | 1.55 |  |  |  | 30,000 |  |
|  |  |  |  |  |  |  | 935,879 |  |  |  |  |  |  |  | 850,879 |  |
| Less: Long-term debt unamortized discount |  |  |  |  |  |  | (660 | ) |  |  |  |  |  |  | (814 | ) |
| Long-term debt unamortized debt issuance costs |  |  |  |  |  |  | (8,297 | ) |  |  |  |  |  |  | (7,212 | ) |
|  |  |  |  |  |  |  | 926,922 |  |  |  |  |  |  |  | 842,853 |  |
| Less: current maturities |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 926,922 |  |  |  |  |  |  | $ | 842,853 |  |

[0001564590-21-053547:notes:60]
Pursuant to the Term Loan Credit Agreement, the Company may reinvest the cash proceeds received from the sale of the Mobility business unit for a period of twelve months commencing September 3, 2020. If the proceeds are not reinvested during that

[0001564590-21-053547:notes:61]
time, the Company is required to use the proceeds to prepay the Term Loan. The Company used a portion of the cash proceeds to repay $400,000 of the Term Loan during the year ended December 28, 2020 and used the remaining cash proceeds for reinvestment pursuant to the Term Loan Credit Agreement. Permitted investments, as defined in the Term Loan Credit Agreement, include extensions of trade credit in the ordinary course of business, investments in cash and cash equivalents, permitted acquisitions, investments in assets useful in the business of the Company and its restricted subsidiaries, investments in joint ventures and unrestricted subsidiaries among others.

[0001564590-21-053547:notes:62]
Senior Notes due 2029

[0001564590-21-053547:notes:63]
On March 10, 2021, the Company issued $500,000 of Senior Notes due 2029, which are included in long-term debt and bear interest at a rate of 4.0% per annum. Interest is payable semiannually in arrears on March 1 and September 1 of each year beginning September 1, 2021. The Senior Notes due 2029 will mature on March 1, 2029.

[0001564590-21-053547:notes:64]
The Company used a portion of the net proceeds from the issuance of the Senior Notes due 2029 during the quarter ended March 29, 2021 to: (i) fund the early retirement of $375,000 Senior Notes due 2025, (ii) fund the repayment of $40,000 outstanding under the U.S. Asset-Based Lending Credit Agreement (U.S. ABL) Revolving credit facility (but not terminate the commitments thereunder), and (iii) pay related premiums, fees and expenses. The Company has and intends to use the remaining net proceeds for general corporate purposes.

[0001564590-21-053547:notes:65]
Asset-Based Lending Agreements

[0001564590-21-053547:notes:66]
As of September 27, 2021, letters of credit in the amount of $12,346 were outstanding under the U.S. ABL and $2,606 were outstanding under the Asia Asset-Based Lending Credit Agreement (Asia ABL) with various expiration dates through September 2021. Available borrowing capacity under the U.S. ABL and the Asia ABL was $137,654 and $117,394, respectively, which considers letters of credit outstanding as of September 27, 2021.

[0001564590-21-053547:notes:67]
Debt Covenants

[0001564590-21-053547:notes:68]
Borrowings under the Term Loan and Senior Notes due 2029 are subject to certain affirmative and negative covenants, including limitations on indebtedness, corporate transactions, investments, dispositions, and share payments.

[0001564590-21-053547:notes:69]
Under the occurrence of certain events, the U.S. ABL and Asia ABL (collectively, the ABL Revolving Loans), are subject to various financial covenants, including leverage and fixed charge coverage ratios.

[0001564590-21-053547:notes:70]
Debt Issuance and Debt Discount

[0001564590-21-053547:notes:71]
As of September 27, 2021 and December 28, 2020, remaining unamortized debt discount and debt issuance costs for the Senior Notes due 2029, Term Loan Facility and Senior Notes due 2025 are as follows:

[0001564590-21-053547:notes:72]
|  |  | As of September 27, 2021 |  |  | As of December 28, 2020 |
|  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  | Debt Issuance Costs |  |  | Debt Discount |  |  | Effective Interest Rate |  |  |
|  |  | (In thousands, except interest rates) |
| Senior Notes due March 2029 |  | $ | 6,114 |  |  | $ | — |  |  |  | 4.19 |  | % | $ | — |  |  | $ | — |  |  |  | — |  | % |
| Term Loan due September 2024 |  |  | 2,183 |  |  |  | 660 |  |  |  | 4.66 |  |  |  | 2,695 |  |  |  | 814 |  |  |  | 4.66 |  |  |
| Senior Notes due October 2025 |  | — |  |  | — |  |  |  | — |  |  |  | 4,517 |  |  | — |  |  |  | 5.92 |  |  |
|  |  | $ | 8,297 |  |  | $ | 660 |  |  |  |  |  |  | $ | 7,212 |  |  | $ | 814 |  |  |  |  |  |  |

[0001564590-21-053547:notes:73]
The above debt discount and debt issuance costs are recorded as a reduction of the debt and are amortized into interest expense using an effective interest rate over the duration of the debt.

[0001564590-21-053547:notes:74]
Remaining unamortized debt issuance costs for the ABL Revolving Loans of $1,496 and $1,919 as of September 27, 2021 and December 28, 2020, respectively, are included in other non-current assets and are amortized to interest expense over the duration of the ABL Revolving Loans using the straight-line method of amortization.

[0001564590-21-053547:notes:75]
As of September 27, 2021, the remaining weighted average amortization period for all unamortized debt discount and debt issuance costs was 5.5 years.

[0001564590-21-053547:notes:76]
Loss on Extinguishment of Debt

[0001564590-21-053547:notes:77]
During the three quarters ended September 27, 2021, the Company recognized losses of $15,217 associated with the premium paid on extinguishment of debt and the write-off of the remaining unamortized debt issuance costs as a result of the repayment of the remaining outstanding balance of the Senior Notes due 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-053547:notes:78]
[same as prior period, unchanged from 0001564590-21-040796:notes:80]

[0001564590-21-053547:notes:79]
[same as prior period, unchanged from 0001564590-21-040796:notes:81]

[0001564590-21-053547:notes:80]
During the quarter and three quarters ended September 27, 2021, the Company’s effective tax rate was impacted by a net discrete expense of $1,157 and a net tax benefit of $1,069, respectively. This is related mainly due to an increase in uncertain tax positions in the United States netted against (i) the release of uncertain tax positions due to the expiration of the statute of limitation in foreign jurisdictions, (ii) stock based compensation releases, (iii) the approval of the Company’s renewal application for High and New Tax Enterprise status for two of the Company’s manufacturing subsidiaries in China (including the impact on the respective Company’s deferred tax amounts), and (iv) the reduction in the deferred tax liability for the foreign withholding tax accrual with respect to the Company’s indefinite reinvestment policy outside of the United States.

[0001564590-21-053547:notes:81]
[same as prior period, unchanged from 0001564590-21-040796:notes:83]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-21-053547:notes:82]
[same as prior period, unchanged from 0001564590-21-040796:notes:84]

[0001564590-21-053547:notes:83]
[same as prior period, unchanged from 0001564590-21-040796:notes:85]

[0001564590-21-053547:notes:84]
[same as prior period, unchanged from 0001564590-21-040796:notes:86]

[0001564590-21-053547:notes:85]
The Company’s business is exposed to risk resulting from fluctuations in interest rates on certain LIBOR-based variable rate debt. Increases in interest rates would increase interest expenses relating to the outstanding variable rate borrowings and increase the cost of debt. Fluctuations in interest rates can also lead to significant fluctuations in the fair value of the debt obligations.

[0001564590-21-053547:notes:86]
[same as prior period, unchanged from 0001564590-21-040796:notes:88]

[0001564590-21-053547:notes:87]
At inception, the Company designated the interest rate swap as a cash flow hedge and the fair value of the interest rate swap was zero. As of September 27, 2021, the fair value of the interest rate swap was recorded as a liability in the amount of $7,372 and included as a component of other current liabilities. The change in the fair value of the interest rate swap is recorded as a component of accumulated other comprehensive loss, net of tax. No ineffectiveness was recognized for the quarter and three quarters ended September 27, 2021 and September 28, 2020. The interest rate swap increased interest expense by $2,775 and $2,707 for the quarters ended September 27, 2021 and September 28, 2020, respectively, and $8,278 and $6,224 for the three quarters ended September 27, 2021 and September 28, 2020, respectively.

[0001564590-21-053547:notes:88]
[same as prior period, unchanged from 0001564590-21-040796:notes:90]

[0001564590-21-053547:notes:89]
The Company enters into foreign currency forward contracts to mitigate the impact of changes in foreign currency exchange rates and to reduce the volatility of purchases and other obligations generated in currencies other than its functional currencies. The Company’s foreign subsidiaries may at times purchase forward exchange contracts to manage their foreign currency risks in relation to certain purchases of machinery denominated in foreign currencies other than the Company’s functional currencies. The notional amount of the foreign exchange contracts as of September 27, 2021 and December 28, 2020 was approximately $1,245 (Japanese Yen (JPY) 132.3 million) and $1,181 (JPY 125.0 million), respectively. The Company has designated certain of these foreign exchange contracts as cash flow hedges.

[0001564590-21-053547:notes:90]
[same as prior period, unchanged from 0001564590-21-040796:notes:92]

[0001564590-21-053547:notes:91]
The Company uses various raw materials in the manufacturing of PCBs. In particular, the Company has been experiencing increasing prices and lead times of copper clad laminates (CCLs), a key raw material for the manufacture of PCBs. CCLs are made from epoxy resin, glass cloth and copper foil, all of which are seeing limited supply and resulting increased prices. The Company only buys a small amount of copper directly. However, copper is a major driver of laminate cost. As such, the Company enters into commodity contracts to hedge copper as a proxy for hedging laminate. As of September 27, 2021, the Company has commodity contracts with a notional quantity of 0.5 metric tonnes each for the periods (i) beginning September 28, 2021 and ending on December 30, 2021, (ii) beginning January 4, 2022 and ending on March 31, 2022, and (iii) beginning April 5, 2022 and ending on June 29, 2022, and 0.6 metric tonnes for the period beginning June 30, 2022 and ending on October 3, 2022. As of September 27, 2021, the fair value of the commodity contracts was recorded as a liability in the amount of $65 and included as a component of other current liabilities. The changes in the fair value of these commodity contracts are recorded in cost of goods sold in the consolidated

[0001564590-21-053547:notes:92]
condensed statements of operations. The commodity contracts increased cost of goods sold by $164 and $65 for the quarter and three quarters ended September 27, 2021, respectively. These commodity contracts are not designated as accounting hedges.

[0001564590-21-053547:notes:93]
[same as prior period, unchanged from 0001564590-21-040796:notes:94]

[0001564590-21-053547:notes:94]
|  |  |  |  | Asset/(Liability) Fair Value |  |
|  |  | Balance Sheet Location |  | September 27, 2021 |  |  | December 28, 2020 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Other current liabilities |  | $ | (7,372 | ) |  | $ | — |  |
| Interest rate swap |  | Other long-term liabilities |  |  | — |  |  |  | (14,968 | ) |
| Foreign exchange contracts |  | Other current liabilities |  |  | (48 | ) |  |  | — |  |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | — |  |  |  | 28 |  |
| Commodity contracts |  | Other current liabilities |  |  | (65 | ) |  |  | — |  |

[0001564590-21-053547:notes:95]
The following table provides information about the amounts recorded in accumulated other comprehensive loss related to derivatives designated as cash flow hedges, as well as the amounts recorded in each caption in the consolidated condensed statements of operations when derivative amounts are reclassified out of accumulated other comprehensive loss for the quarter and three quarters ended September 27, 2021 and September 28, 2020:

[0001564590-21-053547:notes:96]
|  |  |  | Quarter Ended September 27, 2021 |  |  | Quarter Ended September 28, 2020 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (147 | ) |  | $ | (2,775 | ) |  | $ | (586 | ) |  | $ | (2,707 | ) |  |

[0001564590-21-053547:notes:97]
|  |  |  | Three Quarters Ended September 27, 2021 |  |  | Three Quarters Ended September 28, 2020 |  |  |
|  |  | Financial Statement Caption | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  | Loss Recognized in Other Comprehensive Loss |  |  | Loss Reclassified into Income |  |  |
|  |  |  | (In thousands) |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | Interest expense | $ | (682 | ) |  | $ | (8,278 | ) |  | $ | (11,618 | ) |  | $ | (6,224 | ) |  |

[0001564590-21-053547:notes:98]
The following table provides a summary of the activity associated with the designated cash flow hedges reflected in accumulated other comprehensive loss for the three quarters ended September 27, 2021 and September 28, 2020:

[0001564590-21-053547:notes:99]
|  |  | Three Quarters Ended |
|  |  | September 27, |  |  | September 28, |  |  |
|  |  | 2021 |  |  | 2020 |  |  |
|  |  | (In thousands) |
| Beginning balance, net of tax |  | $ | (11,231 | ) |  | $ | (9,617 | ) |  |
| Changes in fair value loss, net of tax |  |  | (87 | ) |  |  | (8,667 | ) |  |
| Reclassification to earnings |  |  | 5,875 |  |  |  | 4,727 |  |  |
| Derecognition of unrealized losses on cash flow hedge due to sale of Mobility business unit |  |  | — |  |  |  | 384 |  |  |
| Ending balance, net of tax |  | $ | (5,443 | ) |  | $ | (13,173 | ) |  |

[0001564590-21-053547:notes:100]
Based on the current yield curve, the Company expects that losses of approximately $6,022 of the accumulated other comprehensive loss will be reclassified into the statement of operations, net of tax, in the next twelve months.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001564590-21-053547:notes:101]
[same as prior period, unchanged from 0001564590-21-040796:notes:102]

[0001564590-21-053547:notes:102]
The following provides a summary of the components of accumulated other comprehensive loss, net of tax, as of September 27, 2021 and December 28, 2020:

[0001564590-21-053547:notes:103]
|  |  | Foreign Currency Translation |  |  | Pension Obligation |  |  | (Losses) Gains on Cash Flow Hedges |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance as of December 28, 2020 |  | $ | (24,827 | ) |  | $ | (2,855 | ) |  | $ | (11,231 | ) |  | $ | (38,913 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 363 |  |  |  | 59 |  |  |  | (87 | ) |  |  | 335 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | — |  |  |  | — |  |  |  | 5,875 |  |  |  | 5,875 |  |
| Other comprehensive income |  |  | 363 |  |  |  | 59 |  |  |  | 5,788 |  |  |  | 6,210 |  |
| Ending balance as of September 27, 2021 |  | $ | (24,464 | ) |  | $ | (2,796 | ) |  | $ | (5,443 | ) |  | $ | (32,703 | ) |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-21-053547:notes:104]
[same as prior period, unchanged from 0001564590-21-040796:notes:105]

[0001564590-21-053547:notes:105]
In the normal course of business, the Company extends credit to its customers. Some customers to whom the Company extends credit are located outside the United States. The Company performs ongoing credit evaluations of customers, does not require collateral, and considers the credit risk profile of the entity from which the receivable is due in further evaluating collection risk.

[0001564590-21-053547:notes:106]
[same as prior period, unchanged from 0001564590-21-040796:notes:107]

[0001564590-21-053547:notes:107]
There were no customers that accounted for 10% or more of net sales for the quarter ended September 27, 2021. For the three quarters ended September 27, 2021, one customer accounted for approximately 10% of the Company’s net sales. For the quarter and three quarters ended September 28, 2020, one customer accounted for approximately 13% and 10% of the Company’s net sales, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-21-053547:notes:108]
[same as prior period, unchanged from 0001564590-21-040796:notes:109]

[0001564590-21-053547:notes:109]
[same as prior period, unchanged from 0001564590-21-040796:notes:110]

[0001564590-21-053547:notes:110]
The carrying amount and estimated fair value of the Company’s financial instruments as of September 27, 2021 and December 28, 2020 were as follows:

[0001564590-21-053547:notes:111]
|  |  | As of |  |  | As of |  |
|  |  | September 27, 2021 |  |  | December 28, 2020 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | — |  |  | $ | — |  |  | $ | 28 |  |  | $ | 28 |  |
| Derivative liabilities, current |  |  | 7,485 |  |  |  | 7,485 |  |  |  | — |  |  |  | — |  |
| Derivative liabilities, non-current |  |  | — |  |  |  | — |  |  |  | 14,968 |  |  |  | 14,968 |  |
| Senior Notes due March 2029 |  |  | 493,886 |  |  |  | 504,565 |  |  |  | — |  |  |  | — |  |
| Term Loan due September 2024 |  |  | 403,036 |  |  |  | 407,150 |  |  |  | 402,370 |  |  |  | 407,909 |  |
| Senior Notes due October 2025 |  |  | — |  |  |  | — |  |  |  | 370,483 |  |  |  | 383,974 |  |
| ABL Revolving Loans |  |  | 30,000 |  |  |  | 30,000 |  |  |  | 70,000 |  |  |  | 70,000 |  |

[0001564590-21-053547:notes:112]
[same as prior period, unchanged from 0001564590-21-040796:notes:113]

[0001564590-21-053547:notes:113]
The fair value of the long-term debt was estimated based on quoted market prices or discounting the debt over its life using current market rates for similar debt as of September 27, 2021 and December 28, 2020, which are considered Level 2 inputs.

[0001564590-21-053547:notes:114]
As of September 27, 2021 and December 28, 2020, the Company’s other financial instruments included cash and cash equivalents, accounts receivable, and accounts payable. Due to short-term maturities, the carrying amount of these instruments approximates fair value. The Company’s cash and cash equivalents as of September 27, 2021 consisted of $355,243 held in the U.S., with the remaining $174,573 held by foreign subsidiaries.

[0001564590-21-053547:notes:115]
[same as prior period, unchanged from 0001564590-21-040796:notes:116]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-053547:notes:116]
(14) Commitments and Contingencies

[0001564590-21-053547:notes:117]
Legal Matters

[0001564590-21-053547:notes:118]
The Company is subject to various legal matters, which it considers normal for its business activities. While the Company currently believes that the amount of any reasonably possible loss for known matters would not be material to the Company’s financial condition, the outcome of these actions is inherently difficult to predict. In the event of an adverse outcome, the ultimate potential loss could have a material adverse effect on the Company’s financial condition or results of operations in a particular period. The Company has accrued amounts for its loss contingencies which are probable and estimable as of September 27, 2021 and December 28, 2020. However, these amounts are not material to the consolidated condensed financial statements of the Company.


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-053547:notes:119]
[same as prior period, unchanged from 0001564590-21-040796:notes:120]

[0001564590-21-053547:notes:120]
The following is a reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share from continuing operations for the quarter and three quarters ended September 27, 2021 and September 28, 2020:

[0001564590-21-053547:notes:121]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 27, 2021 |  |  | September 28, 2020 |  |  | September 27, 2021 |  |  | September 28, 2020 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net income (loss) from continuing operations |  | $ | 20,958 |  |  | $ | (61,472 | ) |  | $ | 46,027 |  |  | $ | (55,346 | ) |
| Basic weighted average shares |  |  | 107,098 |  |  |  | 106,729 |  |  |  | 106,917 |  |  |  | 106,130 |  |
| Dilutive effect of performance-based restricted stock units, restricted stock units and stock options |  |  | 1,247 |  |  |  | — |  |  |  | 1,655 |  |  |  | — |  |
| Dilutive effect of outstanding warrants |  |  | — |  |  |  | — |  |  |  | 267 |  |  |  | — |  |
| Diluted shares |  |  | 108,345 |  |  |  | 106,729 |  |  |  | 108,839 |  |  |  | 106,130 |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.20 |  |  | $ | (0.58 | ) |  | $ | 0.43 |  |  | $ | (0.52 | ) |
| Diluted |  | $ | 0.19 |  |  | $ | (0.58 | ) |  | $ | 0.42 |  |  | $ | (0.52 | ) |

[0001564590-21-053547:notes:122]
Performance-based restricted stock units (PRUs), restricted stock units (RSUs), and stock options to purchase 997 and 866 shares of common stock for the quarter and three quarters ended September 27, 2021, respectively, were not included in the computation of diluted earnings per share. The PRUs were not included in the computation of diluted earnings per share because the performance conditions had not been met at September 27, 2021, and for RSUs and stock options, the options’ exercise prices or the total expected proceeds under the treasury stock method was greater than the average market price of common stock during the applicable quarter and three quarters and, as a result, the impact would be anti-dilutive.

[0001564590-21-053547:notes:123]
For the quarter and three quarters ended September 28, 2020, potential shares of common stock, consisting of stock options to purchase approximately 80 shares of common stock at exercise prices ranging from $11.83 to $16.60 per share, 3,187 RSUs, and 216 PRUs were not included in the computation of diluted earnings per share because the Company incurred a net loss and as a result, the impact would be anti-dilutive.

[0001564590-21-053547:notes:124]
Outstanding warrants for the quarter ended September 27, 2021, and the quarter and three quarters ended September 28, 2020 to purchase common stock were not included in the computation of dilutive earnings per share because the strike price of the warrants to purchase the Company’s common stock was greater than the average market price of common stock during the applicable quarter, and therefore, the effect would be anti-dilutive.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-21-053547:notes:125]
[same as prior period, unchanged from 0001564590-21-040796:notes:125]

[0001564590-21-053547:notes:126]
[same as prior period, unchanged from 0001564590-21-040796:notes:126]

[0001564590-21-053547:notes:127]
|  |  | Quarter Ended |  | Three Quarters Ended |
|  |  | September 27, |  |  | September 28, |  |  |  | September 27, |  |  | September 28, |  |  |
|  |  | 2021 |  |  | 2020 |  |  |  | 2021 |  |  | 2020 |  |  |
|  |  | (In thousands) |
| Cost of goods sold |  | $ | 1,284 |  |  | $ | 1,173 |  |  |  | $ | 3,310 |  |  | $ | 2,643 |  |  |
| Selling and marketing |  |  | 731 |  |  |  | 557 |  |  |  |  | 1,819 |  |  |  | 1,299 |  |  |
| General and administrative |  |  | 2,542 |  |  |  | 2,705 |  |  |  |  | 6,912 |  |  |  | 7,872 |  |  |
| Research and development |  |  | 387 |  |  |  | 44 |  |  |  |  | 462 |  |  |  | 147 |  |  |
| Stock-based compensation expense recognized |  | $ | 4,944 |  |  | $ | 4,479 |  |  |  | $ | 12,503 |  |  | $ | 11,961 |  |  |

[0001564590-21-053547:notes:128]
[same as prior period, unchanged from 0001564590-21-040796:notes:128]

[0001564590-21-053547:notes:129]
The following is a summary of total unrecognized compensation costs as of September 27, 2021:

[0001564590-21-053547:notes:130]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| RSU awards |  | $ | 29,156 |  |  |  | 1.5 |  |
| PRU awards |  |  | 2,348 |  |  |  | 1.1 |  |
| Stock options |  |  | 69 |  |  |  | 0.9 |  |
|  |  | $ | 31,573 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-053547:notes:131]
[same as prior period, unchanged from 0001564590-21-040796:notes:131]

[0001564590-21-053547:notes:132]
The reportable segments shown below are the Company’s segments for which separate financial information is available and upon which operating results are evaluated by the chief operating decision maker to assess performance and to allocate resources. On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. In prior periods, the Company’s E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company closed the SH E-MS and SZ facilities at the end of 2020 and integrated the SH BPA facility into its PCB operations. As of March 29, 2021, E-M Solutions no longer met the criteria for segment reporting. As a result of the restructuring of the E-M Solutions business unit, certain prior year amounts have been reclassified to conform to this new presentation.

[0001564590-21-053547:notes:133]
[same as prior period, unchanged from 0001564590-21-040796:notes:133]

[0001564590-21-053547:notes:134]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 27, 2021 |  |  | September 28, 2020 |  |  | September 27, 2021 |  |  | September 28, 2020 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 541,118 |  |  | $ | 481,311 |  |  | $ | 1,605,084 |  |  | $ | 1,492,156 |  |
| RF&S Components |  |  | 15,666 |  |  |  | 11,742 |  |  |  | 42,259 |  |  |  | 33,274 |  |
| Other (1) |  |  | — |  |  |  | 20,523 |  |  |  | 3,256 |  |  |  | 56,090 |  |
| Total net sales |  | $ | 556,784 |  |  | $ | 513,576 |  |  | $ | 1,650,599 |  |  | $ | 1,581,520 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 61,424 |  |  | $ | 65,179 |  |  | $ | 191,711 |  |  | $ | 203,131 |  |
| RF&S Components |  |  | 6,537 |  |  |  | (66,098 | ) |  |  | 15,129 |  |  |  | (59,880 | ) |
| Corporate and Other (1) |  |  | (26,068 | ) |  |  | (27,823 | ) |  |  | (82,929 | ) |  |  | (110,925 | ) |
| Total operating segment income (loss) |  |  | 41,893 |  |  |  | (28,742 | ) |  |  | 123,911 |  |  |  | 32,326 |  |
| Amortization of definite-lived intangibles (2) |  |  | (9,658 | ) |  |  | (11,510 | ) |  |  | (30,988 | ) |  |  | (33,400 | ) |
| Total operating income (loss) |  |  | 32,235 |  |  |  | (40,252 | ) |  |  | 92,923 |  |  |  | (1,074 | ) |
| Total other expense |  |  | (8,622 | ) |  |  | (22,520 | ) |  |  | (43,494 | ) |  |  | (57,916 | ) |
| Income (loss) before income taxes |  | $ | 23,613 |  |  | $ | (62,772 | ) |  | $ | 49,429 |  |  | $ | (58,990 | ) |

[0001564590-21-053547:notes:135]
|  |  | As of |  |
|  |  | September 27, 2021 |  |  | December 28, 2020 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,596,648 |  |  | $ | 1,529,102 |  |
| RF&S Components |  |  | 219,294 |  |  |  | 227,990 |  |
| Corporate and Other (1) |  |  | 1,231,689 |  |  |  | 1,138,852 |  |
| Total assets |  | $ | 3,047,631 |  |  | $ | 2,895,944 |  |

[0001564590-21-053547:notes:136]
| (2) | Amortization of definite-lived intangibles primarily relates to the PCB and RF&S Components reportable segments. For both the quarter and three quarters ended September 27, 2021 and September 28, 2020, $1,384 and $4,151, respectively, of amortization expense is included in cost of goods sold. |

[0001564590-21-053547:notes:137]
[same as prior period, unchanged from 0001564590-21-040796:notes:137]

[0001564590-21-053547:notes:138]
The Company markets and sells its products in approximately 50 countries. Other than in the United States and China, the Company does not conduct business in any country in which its net sales in that country exceed 10% of the Company’s total net sales. Net sales are as follows:

[0001564590-21-053547:notes:139]
|  |  | Quarter Ended |  |  | Three Quarters Ended |  |
|  |  | September 27, 2021 |  |  | September 28, 2020 |  |  | September 27, 2021 |  |  | September 28, 2020 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 245,940 |  |  | $ | 271,050 |  |  | $ | 775,351 |  |  | $ | 802,681 |  |
| China |  |  | 77,022 |  |  |  | 80,696 |  |  |  | 238,891 |  |  |  | 252,736 |  |
| Other |  |  | 233,822 |  |  |  | 161,830 |  |  |  | 636,357 |  |  |  | 526,103 |  |
| Total net sales |  | $ | 556,784 |  |  | $ | 513,576 |  |  | $ | 1,650,599 |  |  | $ | 1,581,520 |  |

[0001564590-21-053547:notes:140]
[same as prior period, unchanged from 0001564590-21-040796:notes:140]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-053547:notes:141]
[same as prior period, unchanged from 0001564590-21-040796:notes:141]

[0001564590-21-053547:notes:142]
On April 29, 2020, the Company announced the restructuring of its E-M Solutions business unit. The E-M Solutions business unit consisted of three Chinese manufacturing facilities with two being in Shanghai (SH BPA and SH E-MS) and one in Shenzhen (SZ). The Company ceased operations at the SH E-MS and SZ facilities while integrating the SH BPA facility into its PCB operations. The restructuring is another step in advancing the Company’s stated strategy of increasing its focus on differentiated higher margin products that more fully leverage the Company’s early engagement capabilities and industry leading engineering-based technology solutions. The Company closed the SH E-MS and SZ facilities at the end of 2020. As of September 27, 2021, the Company had incurred approximately $19,868 of restructuring charges and $6,702 of accelerated depreciation expense since the April 29, 2020 announcement.

[0001564590-21-053547:notes:143]
In connection with the restructuring of its E-M Solutions business unit and other global realignment restructuring efforts, the Company recognized employee separation, contract termination and other costs during the quarter and three quarters ended September 27, 2021 and September 28, 2020. Contract termination and other costs primarily represented plant closure costs.

[0001564590-21-053547:notes:144]
The table below summarizes such restructuring costs by reportable segment, which are included as a component of general and administrative expenses in the consolidated condensed statements of operations, for the quarter and three quarters ended September 27, 2021 and September 28, 2020:

[0001564590-21-053547:notes:145]
|  |  | Quarter Ended September 27, 2021 |  |  | Three Quarters Ended September 27, 2021 |  |  |
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  |
|  |  | (In thousands) |  |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 470 |  |  | $ | 123 |  |  | $ | 593 |  |  |
| Corporate and Other (1) |  |  | — |  |  |  | 243 |  |  |  | 243 |  |  |  | 415 |  |  |  | 3,026 |  |  |  | 3,441 |  |  |
|  |  | $ | — |  |  | $ | 243 |  |  | $ | 243 |  |  | $ | 885 |  |  | $ | 3,149 |  |  | $ | 4,034 |  |  |

[0001564590-21-053547:notes:146]
|  |  | Quarter Ended September 28, 2020 |  |  | Three Quarters Ended September 28, 2020 |  |  |
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |  |
|  |  | (In thousands) |  |  |
| Reportable Segment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (8 | ) |  | $ | 14 |  |  | $ | 6 |  |  |
| Corporate and Other (1) |  |  | 979 |  |  |  | 109 |  |  |  | 1,088 |  |  |  | 14,373 |  |  |  | 451 |  |  |  | 14,824 |  |  |
|  |  | $ | 979 |  |  | $ | 109 |  |  | $ | 1,088 |  |  | $ | 14,365 |  |  | $ | 465 |  |  | $ | 14,830 |  |  |

[0001564590-21-053547:notes:147]
Accrued restructuring costs are included as a component of other current liabilities in the consolidated condensed balance sheet. The table below shows the utilization of the accrued restructuring costs during the three quarters ended September 27, 2021:

[0001564590-21-053547:notes:148]
|  |  | Employee Separation/ Severance |  |  | Contract Termination and Other Costs |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued as of December 28, 2020 |  | $ | 7,063 |  |  | $ | 319 |  |  | $ | 7,382 |  |
| Charged to expense |  |  | 885 |  |  |  | 3,149 |  |  |  | 4,034 |  |
| Amount paid |  |  | (7,940 | ) |  |  | (3,430 | ) |  |  | (11,370 | ) |
| Accrued as of September 27, 2021 |  | $ | 8 |  |  | $ | 38 |  |  | $ | 46 |  |


## us-gaap:TreasuryStockTextBlock

[0001564590-21-053547:notes:149]
[same as prior period, unchanged from 0001564590-21-040796:notes:149]

[0001564590-21-053547:notes:150]
[same as prior period, unchanged from 0001564590-21-040796:notes:150]

[0001564590-21-053547:notes:151]
During the quarter ended September 27, 2021, the Company repurchased 2,114 shares of common stock for a total cost of $28,971 and during the three quarters ended September 27, 2021, the Company has repurchased a total of 2,525 shares of common stock for a total cost of $35,116. As of September 27, 2021, the remaining amount available to be repurchased under the Company’s share repurchase program was $64,884.
