# TTMI notes — 0001193125-16-476374


## us-gaap:ScheduleOfEffectiveIncomeTaxRateReconciliationTableTextBlock

[0001193125-16-476374:notes:1]
The following
 is a reconciliation of the (provision) benefit for income taxes at
 the statutory federal income tax rate compared to the
 Company’s provision for income taxes for the years ended
 December 28, 2015, December 29, 2014 and
 December 30, 2013:

[0001193125-16-476374:notes:2]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
| Statutory federal income tax |  | $ | (3,052 | ) |  | $ | (7,579 | ) |  | $ | (13,523 | ) |
| State income taxes, net of federal benefit and state tax credits |  |  | (345 | ) |  |  | (84 | ) |  |  | 890 |  |
| Foreign deemed dividends |  |  | (5,691 | ) |  |  | — |  |  |  | — |  |
| Acquisition related expenses |  |  | (7,692 | ) |  |  | — |  |  |  | — |  |
| Intercompany profit in inventory elimination |  |  | 596 |  |  |  | — |  |  |  | — |  |
| Permanently reinvested earnings assertion |  |  | 8,281 |  |  |  | — |  |  |  | — |  |
| Foreign tax differential on foreign earnings |  |  | 15,543 |  |  |  | (6,243 | ) |  |  | (3,759 | ) |
| Change in valuation allowance |  |  | (39,148 | ) |  |  | 5,321 |  |  |  | (2,370 | ) |
| Uncertain tax positions |  |  | (3,911 | ) |  |  | — |  |  |  | — |  |
| Federal research and development credits |  |  | 1,270 |  |  |  | 1,020 |  |  |  | 1,044 |  |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | 2,393 |  |
| Other |  |  | (445 | ) |  |  | (33 | ) |  |  | (554 | ) |
| Total provision for income taxes |  | $ | (34,594 | ) |  | $ | (7,598 | ) |  | $ | (15,879 | ) |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-16-476374:notes:3]
| (7) | Definite-lived Intangibles |

[0001193125-16-476374:notes:4]
As of
 December 28, 2015 and December 29, 2014, the components
 of definite-lived intangibles were as follows:

[0001193125-16-476374:notes:5]
|  |  | Gross Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net Carrying Amount |  |  | Weighted Average Amortization Period |  |
|  |  | (In thousands) |  |  | (years) |  |
| December 28, 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 91,492 |  |  | $ | (80,152 | ) |  | $ | 426 |  |  | $ | 11,766 |  |  |  | 9.2 |  |
| Trade name |  |  | 10,302 |  |  |  | (10,313 | ) |  |  | 11 |  |  |  | — |  |  |  | 6.0 |  |
| Acquired intangibles from Viasystems acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | 147,500 |  |  |  | (10,815 | ) |  |  | — |  |  |  | 136,685 |  |  |  | 8.1 |  |
| Technology |  |  | 3,000 |  |  |  | (577 | ) |  |  | — |  |  |  | 2,423 |  |  |  | 3.0 |  |
|  |  | $ | 252,294 |  |  | $ | (101,857 | ) |  | $ | 437 |  |  | $ | 150,874 |  |  |  |  |  |
| December 29, 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 91,492 |  |  | $ | (74,486 | ) |  | $ | 445 |  |  | $ | 17,451 |  |  |  | 9.2 |  |
| Trade name |  |  | 10,302 |  |  |  | (8,520 | ) |  |  | 17 |  |  |  | 1,799 |  |  |  | 6.0 |  |
|  |  | $ | 101,794 |  |  | $ | (83,006 | ) |  | $ | 462 |  |  | $ | 19,250 |  |  |  |  |  |

[0001193125-16-476374:notes:6]
The
 December 28, 2015 and December 29, 2014 definite-lived
 intangible balances include foreign currency translation
 adjustments related to foreign subsidiaries with functional
 currencies other than the U.S. Dollar.

[0001193125-16-476374:notes:7]
Definite-lived
 intangibles are generally amortized using the straight line method
 of amortization over the useful life, with the exception of certain
 customer relationship intangibles, which are amortized using an
 accelerated method of amortization based on estimated cash flows.
 Amortization expense was $18,888, $8,387, and $9,332 for the years
 ended December 28, 2015, December 29, 2014 and
 December 30, 2013, respectively.

[0001193125-16-476374:notes:8]
Estimated
 aggregate amortization for definite-lived intangible assets for the
 next five years and thereafter is as follows:

[0001193125-16-476374:notes:9]
|  |  | (In thousands) |  |
| 2016 |  | $ | 23,870 |  |
| 2017 |  |  | 23,647 |  |
| 2018 |  |  | 22,889 |  |
| 2019 |  |  | 18,746 |  |
| 2020 |  |  | 18,746 |  |
| Thereafter |  |  | 42,976 |  |
|  |  | $ | 150,874 |  |


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001193125-16-476374:notes:10]
The Company
 accounts for inter-segment sales and transfers consistent with the
 Company’s revenue recognition policy. The inter-segment sales
 for the year ended December 28, 2015 are sales primarily from
 the PCB to the E-M Solutions operating segment.

[0001193125-16-476374:notes:11]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,944,041 |  |  | $ | 1,251,665 |  |  | $ | 1,305,862 |  |
| E-M Solutions |  |  | 158,655 |  |  |  | 76,545 |  |  |  | 65,202 |  |
| Total sales |  |  | 2,102,696 |  |  |  | 1,328,210 |  |  |  | 1,371,064 |  |
| Inter-segment sales |  |  | (7,208 | ) |  |  | (2,493 | ) |  |  | (2,849 | ) |
| Total net sales |  | $ | 2,095,488 |  |  | $ | 1,325,717 |  |  | $ | 1,368,215 |  |
| Operating Segment Income (Loss): |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 172,227 |  |  | $ | 77,092 |  |  | $ | 101,048 |  |
| E-M Solutions |  |  | 1,424 |  |  |  | 3,855 |  |  |  | 1,917 |  |
| Corporate |  |  | (93,421 | ) |  |  | (26,021 | ) |  |  | (24,505 | ) |
| Total operating segment income |  |  | 80,230 |  |  |  | 54,926 |  |  |  | 78,460 |  |
| Amortization of definite-lived intangibles |  |  | (18,888 | ) |  |  | (8,387 | ) |  |  | (9,332 | ) |
| Total operating income |  |  | 61,342 |  |  |  | 46,539 |  |  |  | 69,128 |  |
| Total other expense |  |  | (52,366 | ) |  |  | (24,248 | ) |  |  | (29,356 | ) |
| Income before income taxes |  | $ | 8,976 |  |  | $ | 22,291 |  |  | $ | 39,772 |  |

[0001193125-16-476374:notes:12]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Depreciation Expense: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 130,339 |  |  | $ | 95,027 |  |  | $ | 91,759 |  |
| E-M Solutions |  |  | 2,079 |  |  |  | 183 |  |  |  | 248 |  |
| Corporate |  |  | 1,090 |  |  |  | 139 |  |  |  | 113 |  |
| Total depreciation expense |  | $ | 133,508 |  |  | $ | 95,349 |  |  | $ | 92,120 |  |
| Capital Expenditures: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 72,036 |  |  | $ | 73,779 |  |  | $ | 127,623 |  |
| E-M Solutions |  |  | 4,006 |  |  |  | 400 |  |  |  | 176 |  |
| Corporate |  |  | 1,523 |  |  |  | 2,603 |  |  |  | 472 |  |
| Total capital expenditures |  | $ | 77,565 |  |  | $ | 76,782 |  |  | $ | 128,271 |  |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-16-476374:notes:13]
| (12) | Significant Customers and Concentration of Credit Risk |

[0001193125-16-476374:notes:14]
In the normal
 course of business, the Company extends credit to its customers,
 which are in diverse end markets. Many customers to which the
 Company extends credit are located outside the United States. The
 Company performs ongoing credit evaluations of customers, does not
 require collateral, and considers the credit risk profile of the
 entity from which the receivable is due in further evaluating
 collection risk.

[0001193125-16-476374:notes:15]
The
 Company’s customers include both OEMs and EMS companies. The
 Company’s OEM customers often direct a significant portion of
 their purchases through EMS companies. While the Company’s
 customers include both OEM and EMS providers, the Company measures
 customer concentration based on OEM companies, as they are the
 ultimate end customers.

[0001193125-16-476374:notes:16]
For the years
 ended December 28, 2015, December 29, 2014 and
 December 30, 2013, one customer accounted for approximately
 20%, 21% and 20%, respectively, of the Company’s net sales.
 There were no other customers that accounted for 10% or more of net
 sales for the years ended December 28,
 2015, December 29, 2014 and December 30,
 2013.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-16-476374:notes:17]
Net sales and
 long-lived assets are as follows:

[0001193125-16-476374:notes:18]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
|  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |  | Net Sales |  |  | Long-Lived Assets |  |
|  |  | (In thousands) |  |
| United States |  | $ | 960,146 |  |  | $ | 654,579 |  |  | $ | 568,796 |  |  | $ | 103,340 |  |  | $ | 571,046 |  |  | $ | 95,672 |  |
| China |  |  | 547,999 |  |  |  | 923,219 |  |  |  | 352,385 |  |  |  | 682,739 |  |  |  | 391,905 |  |  |  | 754,781 |  |
| Other |  |  | 587,343 |  |  |  | 23,133 |  |  |  | 404,536 |  |  |  | — |  |  |  | 405,264 |  |  |  | — |  |
| Total |  | $ | 2,095,488 |  |  | $ | 1,600,931 |  |  | $ | 1,325,717 |  |  | $ | 786,079 |  |  | $ | 1,368,215 |  |  | $ | 850,453 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-16-476374:notes:19]
The following
 is a reconciliation of the numerator and denominator used to
 calculate basic earnings (loss) per share and diluted earnings
 (loss) per share for the years ended December 28,
 2015, December 29, 2014 and December 30,
 2013:

[0001193125-16-476374:notes:20]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands, except per share amounts) |  |
| Net (loss) earnings attributable to TTM Technologies, Inc. stockholders |  | $ | (25,882 | ) |  | $ | 14,693 |  |  | $ | 21,877 |  |
| Weighted average shares outstanding |  |  | 92,675 |  |  |  | 83,238 |  |  |  | 82,506 |  |
| Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | — |  |  |  | 703 |  |  |  | 626 |  |
| Diluted shares |  |  | 92,675 |  |  |  | 83,941 |  |  |  | 83,132 |  |
| (Loss) earnings per share attributable to TTM Technologies, Inc. stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.28 | ) |  | $ | 0.18 |  |  | $ | 0.27 |  |
| Diluted |  | $ | (0.28 | ) |  | $ | 0.18 |  |  | $ | 0.26 |  |


## us-gaap:ScheduleOfShareBasedCompensationArrangementByShareBasedPaymentAwardPerformanceBasedUnitsVestedAndExpectedToVestTableTextBlock

[0001193125-16-476374:notes:21]
PRU activity
 for the year ended December 28, 2015 was as
 follows:

[0001193125-16-476374:notes:22]
|  |  | Shares |  |  | Weighted Average Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Outstanding target shares at December 29, 2014 |  |  | 275 |  |  | $ | 8.03 |  |
| Granted |  |  | 295 |  |  |  | 7.22 |  |
| Vested |  |  | (271 | ) |  |  | 6.67 |  |
| Change in units due to annual performance achievement |  |  | 72 |  |  |  | 7.22 |  |
| Forfeited / cancelled |  |  | (70 | ) |  |  | 6.67 |  |
| Outstanding target shares at December 28, 2015 |  |  | 301 |  |  | $ | 8.58 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-16-476374:notes:23]
| (15) | Stock-Based Compensation |

[0001193125-16-476374:notes:24]
Incentive
 Compensation Plan

[0001193125-16-476374:notes:25]
The Company
 maintains the 2014 Incentive Compensation Plan (the Plan), which
 allows for the issuance of up to 5,288 shares through its
 expiration date of February 2024.

[0001193125-16-476374:notes:26]
The Plan
 provides for the grant of incentive stock options and nonqualified
 stock options to the Company’s key employees, non-employee
 directors and consultants. Other types of awards such as
 performance-based restricted stock units (PRUs), restricted stock
 units (RSUs), and stock appreciation rights are also permitted. The
 exercise price for options and awards is determined by the
 compensation committee of the board of directors and, for options
 intended to qualify as incentive stock options, may not be less
 than the fair market value as determined by the closing stock price
 at the date of the grant. Each option and award shall vest and
 expire as determined by the compensation committee of the board of
 directors, with options, PRUs and RSUs generally vesting over three
 years for employees and one year for non-employee directors.
 Options, PRUs and RSUs do not have voting rights. Options expire no
 later than ten years from the grant date. All grants provide for
 accelerated vesting if there is a change in control, as defined in
 the Plan. Upon the exercise of outstanding stock options or vesting
 of RSUs and PRUs, the Company’s practice is to issue new
 registered shares that are reserved for issuance under the
 Plan.

[0001193125-16-476374:notes:27]
As of
 December 28, 2015, 572 PRUs, 2,294 RSUs and 420 stock options
 were outstanding under the Plan. Included in the 572 PRUs
 outstanding as of December 28, 2015 are 271 vested but not yet
 released. Included in the 2,294 RSUs outstanding as of
 December 28, 2015 are 319 vested but not yet released RSUs
 associated with non-employee directors. These RSUs vest over one
 year with release of the underlying shares of common stock deferred
 until retirement from the board of directors, (or until one year
 after retirement in the case of certain prior grants).

[0001193125-16-476374:notes:28]
Performance-based Restricted Stock
 Units

[0001193125-16-476374:notes:29]
The Company
 maintains a long-term incentive program for executives that
 provides for the issuance of PRUs, representing hypothetical shares
 of the Company’s common stock that may be issued. Under the
 PRU program, a target number of PRUs is awarded at the beginning of
 each three-year performance period. The number of shares of common
 stock released at the end of the performance period may range from
 zero to 2.4 times the target number depending on performance during
 the period. The performance metrics of the PRU program are based on
 (a) annual financial targets, which are based on revenue and
 EBITDA (earnings before interest, tax, depreciation, and
 amortization expense), each equally weighted, and (b) an
 overall modifier based on the Company’s total stockholder
 return (TSR) relative to a group of peer companies selected by the
 Company’s compensation committee, over the three-year
 performance period.

[0001193125-16-476374:notes:30]
Under the PRU
 program, financial goals are set at the beginning of each fiscal
 year and performance is reviewed at the end of that year. The
 percentage to be applied to each participant’s target award
 ranges from zero to 160% based upon the extent to which the annual
 financial performance goals are achieved. If specific performance
 threshold levels for the annual financial goals are met, the amount
 earned for that element will be applied to one-third of the
 participants’ PRU award to determine the number of units
 earned.

[0001193125-16-476374:notes:31]
At the end of
 the three-year performance period, the total units earned, if any,
 are adjusted by applying a modifier, ranging from zero to 150%
 based on the Company’s TSR based on stock price changes
 relative to a group of peer companies selected by the
 Company’s compensation committee for the same three-year
 period.

[0001193125-16-476374:notes:32]
The TSR
 modifier is intended to ensure that there are limited or no payouts
 under the PRU program if the Company’s stock performance is
 significantly below the median TSR of a group of peer companies
 selected by the Company’s compensation committee over the
 three-year performance period. Where the annual financial goals
 have been met and where there has been strong relative TSR
 performance over the three-year performance period, the PRU program
 may provide substantial rewards to participants with a maximum
 payout of 2.4 times the initial PRU award. However, even if all of
 the annual financial metric goals are achieved in each of the three
 years, there will be no payouts if the Company’s stock
 performance is below that of the 20th percentile of the group of
 peer companies selected by the Company’s compensation
 committee, as appropriate.

[0001193125-16-476374:notes:33]
Recipients of
 PRU awards generally must remain employed by the Company on a
 continuous basis through the end of the three-year performance
 period in order to receive any amount of the PRUs covered by that
 award. In events such as death, disability or retirement, the
 recipient may be entitled to pro-rata amounts of PRUs as defined in
 the Plan. Target shares subject to PRU awards do not have voting
 rights of common stock until earned and issued following the end of
 the three-year performance period.

[0001193125-16-476374:notes:34]
The Company
 records stock-based compensation expense for PRU awards granted
 based on management’s periodic assessment of the probability
 of the PRU awards vesting. As of December 28, 2015, management
 determined that vesting of the PRU awards was probable. PRU
 activity for the year ended December 28, 2015 was as
 follows:

[0001193125-16-476374:notes:35]
The fair value
 of PRUs granted is calculated using a Monte Carlo simulation model,
 as the TSR modifier contains a market condition. For the years
 ended December 28, 2015, December 29, 2014 and
 December 30, 2013, the following assumptions were used in
 determining the fair value:

[0001193125-16-476374:notes:36]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015(1) |  |  | December 29, 2014(2) |  |  | December 30, 2013(3) |  |
| Weighted-average fair value |  | $ | 7.22 |  |  | $ | 5.80 |  |  | $ | 6.79 |  |
| Risk-free interest rate |  |  | 0.5 | % |  |  | 0.4 | % |  |  | 0.3 | % |
| Dividend yield |  |  | — |  |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | 37 | % |  |  | 41 | % |  |  | 49 | % |
| Expected term in months |  |  | 22 |  |  |  | 23 |  |  |  | 25 |  |

[0001193125-16-476374:notes:37]
| (1) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2013, the second year of the three-year performance period applicable to PRUs granted in 2014 and the first year of the three-year performance period applicable to PRUs granted in 2015. |

[0001193125-16-476374:notes:38]
| (2) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2012, second year of the three-year performance period applicable to PRUs granted in 2013 and for the first year of the three-year performance period applicable to PRUs granted in 2014. |

[0001193125-16-476374:notes:39]
| (3) | Reflects the weighted-averages for the third year of the three-year performance period applicable to PRUs granted in 2011, second year of the three-year performance period applicable to PRUs granted in 2012 and for the first year of the three-year performance period applicable to PRUs granted in 2013. |

[0001193125-16-476374:notes:40]
The expected
 term of the PRUs reflects the performance period for the PRUs
 granted. Expected volatility is calculated using the
 Company’s historical stock price. The risk-free interest rate
 for the expected term of PRUs is based on the U.S Treasury yield
 curve in effect at the time of grant.

[0001193125-16-476374:notes:41]
Restricted Stock Units

[0001193125-16-476374:notes:42]
RSU activity
 for the year ended December 28, 2015 was as
 follows:

[0001193125-16-476374:notes:43]
|  |  | Shares |  |  | Weighted Average Grant-Date Fair Value |  |
|  |  | (In thousands) |  |  |  |  |
| Non-vested RSUs outstanding at December 29, 2014 |  |  | 1,436 |  |  | $ | 8.54 |  |
| Granted |  |  | 1,301 |  |  |  | 9.15 |  |
| Vested |  |  | (711 | ) |  |  | 9.00 |  |
| Forfeited |  |  | (51 | ) |  |  | 8.65 |  |
| Non-vested RSUs outstanding at December 28, 2015 |  |  | 1,975 |  |  | $ | 8.77 |  |
| Vested and expected to vest at December 28, 2015 |  |  | 2,204 |  |  | $ | 8.92 |  |

[0001193125-16-476374:notes:44]
The fair value
 of the Company’s RSUs is determined based upon the closing
 common stock price on the grant date. The fair value per unit of
 RSUs granted was $9.15, $7.98 and $8.17 for the years ended
 December 28, 2015, December 29, 2014 and
 December 30, 2013, respectively. The total fair value of RSUs
 vested for the years ended December 28,
 2015, December 29, 2014 and December 30, 2013 was
 $6,396, $7,195 and $7,878, respectively.

[0001193125-16-476374:notes:45]
Stock
 Options

[0001193125-16-476374:notes:46]
The Company did
 not grant any stock option awards during the years ended
 December 28, 2015, December 29, 2014 and
 December 30, 2013. Option activity under the Plan for the year
 ended December 28, 2015 was as follows:

[0001193125-16-476374:notes:47]
|  |  | Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term |  |  | Aggregate Intrinsic Value |  |
|  |  | (In thousands) |  |  |  |  |  | (In years) |  |  | (In thousands) |  |
| Outstanding at December 29, 2014 |  |  | 511 |  |  | $ | 11.54 |  |  |  | 2.3 |  |  |  |  |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (68 | ) |  |  | 7.32 |  |  |  |  |  |  |  |  |  |
| Forfeited/expired |  |  | (23 | ) |  |  | 8.89 |  |  |  |  |  |  |  |  |  |
| Outstanding at December 28, 2015 |  |  | 420 |  |  | $ | 12.37 |  |  |  | 1.7 |  |  | $ | 4 |  |
| Vested and expected to vest at December 28, 2015 |  |  | 420 |  |  | $ | 12.37 |  |  |  | 1.7 |  |  | $ | 4 |  |
| Exercisable at December 28, 2015 |  |  | 420 |  |  | $ | 12.37 |  |  |  | 1.7 |  |  | $ | 4 |  |

[0001193125-16-476374:notes:48]
The aggregate
 intrinsic values in the table above represent the total pretax
 intrinsic value (the difference between Company’s closing
 stock price on the last trading day of the 2015 fiscal year and the
 exercise price, multiplied by the number of in-the-money options)
 that would have been received by the option holders had all option
 holders exercised their options on December 28, 2015. This
 amount changes based on the fair market value of the
 Company’s stock. The total intrinsic value of options
 exercised for the years ended December 28, 2015 and
 December 30, 2013 was $131 and $117, respectively. There were
 no options exercised in December 29, 2014. The total fair
 value of the options vested for the years ended December 29,
 2014 and December 30, 2013 was $110 and $143, respectively.
 There were no options vested in December 28, 2015.

[0001193125-16-476374:notes:49]
Stock-based Compensation Expense and Unrecognized
 Compensation Costs

[0001193125-16-476374:notes:50]
For the years
 ended December 28, 2015, December 29, 2014 and
 December 30, 2013, the amounts recognized in the consolidated
 financial statements with respect to the stock-based compensation
 plan are as follows:

[0001193125-16-476374:notes:51]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Cost of goods sold |  | $ | 1,117 |  |  | $ | 866 |  |  | $ | 1,059 |  |
| Selling and marketing |  |  | 1,135 |  |  |  | 1,109 |  |  |  | 1,308 |  |
| General and administrative |  |  | 7,409 |  |  |  | 5,825 |  |  |  | 6,618 |  |
| Stock-based compensation expense recognized |  |  | 9,661 |  |  |  | 7,800 |  |  |  | 8,985 |  |
| Income tax benefit recognized |  |  | — |  |  |  | (2,018 | ) |  |  | (2,274 | ) |
| Total stock-based compensation expense after income taxes |  | $ | 9,661 |  |  | $ | 5,782 |  |  | $ | 6,711 |  |

[0001193125-16-476374:notes:52]
The Company may
 become entitled to a deduction in its tax returns upon the future
 exercise of incentive stock options under certain circumstances;
 however, the value of this deduction will be recorded as an
 increase to additional paid-in capital and not as an income tax
 benefit. For the years ended December 28,
 2015, December 29, 2014 and December 30, 2013, a net
 tax shortfall of $247, $1,015 and $744, respectively, related to
 fully vested stock option awards exercised and vested RSUs was
 recorded as a decrease to additional paid-in capital. Additionally,
 for the year ended December 28, 2015, the Company did not
 record an income tax benefit as a result of a full valuation
 allowance on its deferred tax assets.

[0001193125-16-476374:notes:53]
The following
 is a summary of total unrecognized compensation costs as of
 December 28, 2015:

[0001193125-16-476374:notes:54]
|  |  | Unrecognized Stock-Based Compensation Cost |  |  | Remaining Weighted Average Recognition Period |  |
|  |  | (In thousands) |  |  | (In years) |  |
| PRU awards |  | $ | 1,403 |  |  |  | 1.65 |  |
| RSU awards |  |  | 10,159 |  |  |  | 1.40 |  |
|  |  | $ | 11,562 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-16-476374:notes:55]
| (19) | Segment Information |

[0001193125-16-476374:notes:56]
The operating
 segments reported below are the Company’s segments for which
 separate financial information is available and upon which
 operating results are evaluated by the chief operating decision
 maker to assess performance and to allocate resources. As a result
 of the May 31, 2015 acquisition of Viasystems and the ongoing
 integration activities, the Company has reassessed its reportable
 operating segments and determined that it has two reportable
 operating segments: PCB and E-M Solutions. This determination was
 made based on the criteria of earning revenues and incurring
 expenses, the Company’s organizational structure which has
 segment managers who report to the chief operating decision maker
 and discrete financial information, and the aggregation of similar
 operating segments into reportable operating segments. Factors
 considered to determine whether operating segments can be
 aggregated into reportable segments included similarity regarding
 economic characteristics, products, production processes type or
 classes of customers, distribution methods and regulatory
 environments. All prior-period amounts have been adjusted
 retrospectively to reflect our reportable segment
 changes.

[0001193125-16-476374:notes:57]
The Company
 evaluates segment performance based on operating segment income,
 which is operating income before amortization of intangibles.
 Interest expense and interest income are not presented by segment
 since they are not included in the measure of segment profitability
 reviewed by the chief operating decision maker. All inter-segment
 transactions have been eliminated.

[0001193125-16-476374:notes:58]
|  |  | As of |  |
|  |  | December 28, 2015 |  |  | December 29 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Segment Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,943,577 |  |  | $ | 1,334,648 |  |  | $ | 1,371,093 |  |
| E-M Solutions |  |  | 143,779 |  |  |  | 43,255 |  |  |  | 43,990 |  |
| Corporate |  |  | 583,948 |  |  |  | 223,386 |  |  |  | 258,492 |  |
| Total assets |  | $ | 2,671,304 |  |  | $ | 1,601,289 |  |  | $ | 1,673,575 |  |

[0001193125-16-476374:notes:59]
The Corporate
 category includes operating expenses that are not included in the
 segment operating performance measures. Corporate consists
 primarily of corporate governance functions such as finance,
 accounting, information technology, facilities and human resources
 personnel, as well as global sales and marketing personnel and
 acquisition and integration costs associated with the acquisition
 of Viasystems. Bank fees and legal, accounting, and other
 professional service costs associated with the acquisition of
 Viasystems of $34,448 and $5,981 for the years ended
 December 28, 2015 and December 29, 2014, respectively,
 are included in Corporate. There were no bank fees and legal,
 accounting, and other professional service costs associated with
 the acquisition of Viasystems for the year ended December 30,
 2013.

[0001193125-16-476374:notes:60]
During the
 years ended December 29, 2014 and December 30, 2013, the
 Company recorded impairment charges of $1,845 and $10,782,
 respectively, for the impairment of long-lived assets related to
 its PCB operating segment.

[0001193125-16-476374:notes:61]
The Company markets and
 sells its products in approximately 41 countries. Other than in the
 United States and China, the Company does not conduct business in
 any country in which its net sales in that country exceed 10% of
 the Company’s total net sales. Net sales and long-lived
 assets are as follows:

[0001193125-16-476374:notes:62]
Net sales are attributed
 to countries by country invoiced.


## us-gaap:PreferredStockTextBlock

[0001193125-16-476374:notes:63]
| (17) | Preferred Stock |

[0001193125-16-476374:notes:64]
The board of
 directors has the authority, without action by stockholders, to
 designate and issue preferred stock in one or more series. The
 board of directors may also designate the rights, preferences and
 privileges of each series of preferred stock, any or all of which
 may be superior to the rights of the common stock. As of
 December 28, 2015, no shares of preferred stock were
 outstanding.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-16-476374:notes:65]
| (6) | Goodwill |

[0001193125-16-476374:notes:66]
As of
 December 28, 2015 and December 29, 2014, goodwill was as
 follows:

[0001193125-16-476374:notes:67]
|  |  | Total |  |
|  |  | (In thousands) |  |
| Balance as of December 30, 2013 |  | $ | 12,120 |  |
| Foreign currency translation adjustment |  |  | (9 | ) |
| Balance as of December 29, 2014 |  |  | 12,111 |  |
| Goodwill recognized during the year |  |  | 334,870 |  |
| Foreign currency translation adjustment |  |  | 9 |  |
| Balance as of December 28, 2015 |  | $ | 346,990 |  |

[0001193125-16-476374:notes:68]
Goodwill
 balances include foreign currency translation adjustments related
 to foreign subsidiaries with functional currencies other than the
 U.S. Dollar. All of the Company’s goodwill is included as a
 component of the PCB reportable operating segment.

[0001193125-16-476374:notes:69]
In the fourth
 quarter of 2015, the Company performed its annual impairment test
 qualitatively and concluded that it was more likely than not that
 there was no impairment to goodwill. The Company will continue to
 evaluate its goodwill on an annual basis during its fourth fiscal
 quarter and whenever events or changes in circumstances —
 such as significant adverse changes in business climate or
 operating results, changes in management strategy, coupled with a
 decline in the market price of our stock and market capitalization
 — indicate that there may be a potential impairment. If
 factors indicate that assets are impaired, we would be required to
 reduce the carrying value of our goodwill and definite-lived
 intangible assets, which may result in an impairment
 charge.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-16-476374:notes:70]
Principles of Consolidation

[0001193125-16-476374:notes:71]
The
 consolidated financial statements include the accounts of TTM
 Technologies, Inc. and its subsidiaries. All intercompany accounts
 and transactions have been eliminated in consolidation.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-16-476374:notes:72]
Earnings
 Per Share

[0001193125-16-476374:notes:73]
Basic earnings
 per common share excludes dilution and is computed by dividing net
 income attributable to TTM Technologies, Inc. stockholders by the
 weighted average number of common shares outstanding during the
 period. Diluted earnings per common share reflect the potential
 dilution that could occur if stock options, convertible senior
 notes or other common stock equivalents were exercised or converted
 into common stock. The dilutive effect of stock options or other
 common stock equivalents is calculated using the treasury stock
 method, while the dilutive effect of convertible senior notes is
 calculated using the if-converted method.


## us-gaap:ScheduleOfDeferredTaxAssetsAndLiabilitiesTableTextBlock

[0001193125-16-476374:notes:74]
The
 significant components of the net deferred income tax assets as of
 December 28, 2015 and December 29, 2014 are as
 follows:

[0001193125-16-476374:notes:75]
|  |  | As of |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Deferred income tax assets: |  |  |  |  |  |  |  |  |
| Net operating loss carryforwards |  | $ | 223,456 |  |  | $ | 26,644 |  |
| Goodwill and intangible amortization |  |  | — |  |  |  | 11,071 |  |
| Reserves and accruals |  |  | 36,137 |  |  |  | 11,415 |  |
| Tax credit carryforwards |  |  | 19,719 |  |  |  | 6,101 |  |
| Stock-based compensation |  |  | 4,609 |  |  |  | 3,624 |  |
| Original issue discount on convertible senior notes |  |  | 18,876 |  |  |  | 22,029 |  |
| Property, plant and equipment |  |  | 12,945 |  |  |  | 16,375 |  |
| Other deferred income tax assets |  |  | 3,172 |  |  |  | 3,804 |  |
|  |  |  | 318,914 |  |  |  | 101,063 |  |
| Less: valuation allowance |  |  | (234,192 | ) |  |  | (38,839 | ) |
|  |  |  | 84,722 |  |  |  | 62,224 |  |
| Deferred income tax liabilities: |  |  |  |  |  |  |  |  |
| Discount on convertible senior notes |  |  | (16,495 | ) |  |  | (19,315 | ) |
| Unrealized gain on currency translation |  |  | — |  |  |  | (2,979 | ) |
| Repatriation of foreign earnings |  |  | (4,776 | ) |  |  | (8,823 | ) |
| Property, plant and equipment basis differences |  |  | (34,716 | ) |  |  | (28,194 | ) |
| Goodwill and intangible amortization |  |  | (41,790 | ) |  |  | — |  |
| Other deferred income tax assets |  |  | (93 | ) |  |  | — |  |
| Net deferred income tax (liabilities) assets |  | $ | (13,148 | ) |  | $ | 2,913 |  |
| Deferred income tax assets (liabilities), net: |  |  |  |  |  |  |  |  |
| Current deferred income taxes |  | $ | — |  |  | $ | 10,147 |  |
| Noncurrent deferred income taxes |  |  | (13,148 | ) |  |  | (7,234 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-16-476374:notes:76]
| (13) | Fair Value Measures |

[0001193125-16-476374:notes:77]
The Company
 measures at fair value its financial and non-financial assets by
 using a fair value hierarchy that prioritizes the inputs to
 valuation techniques used to measure fair value. Fair value is the
 price that would be received to sell an asset or paid to transfer a
 liability in an orderly transaction between market participants at
 the measurement date, essentially an exit price, based on the
 highest and best use of the asset or liability.

[0001193125-16-476374:notes:78]
The carrying
 amount and estimated fair value of the Company’s financial
 instruments as of December 28, 2015 and December 29, 2014
 were as follows:

[0001193125-16-476374:notes:79]
|  |  | As of |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | Carrying Amount |  |  | Fair Value |  |  | Carrying Amount |  |  | Fair Value |  |
|  |  | (In thousands) |  |
| Derivative assets, current |  | $ | 16 |  |  | $ | 16 |  |  |  | — |  |  |  | — |  |
| Derivative liabilities, current |  |  | 51 |  |  |  | 51 |  |  | $ | 5,062 |  |  | $ | 5,062 |  |
| Term and Revolving Loans |  |  | 997,383 |  |  |  | 935,000 |  |  |  | 273,804 |  |  |  | 273,820 |  |
| Convertible Senior Notes due 2020 |  |  | 204,574 |  |  |  | 230,950 |  |  |  | 197,042 |  |  |  | 241,875 |  |
| Convertible Senior Notes due 2015 |  |  | — |  |  |  | — |  |  |  | 31,841 |  |  |  | 32,631 |  |

[0001193125-16-476374:notes:80]
The fair value
 of the derivative instruments was determined using pricing models
 developed based on the foreign currency exchange rates and other
 observable market data, including quoted market prices, as
 appropriate.

[0001193125-16-476374:notes:81]
The fair value
 of the long-term debt was estimated based on quoted market prices
 or discounting the debt over its life using current market rates
 for similar debt as of December 28, 2015 and December 29,
 2014, which are considered Level 1 and Level 2 inputs.

[0001193125-16-476374:notes:82]
The fair value
 of the convertible senior notes was estimated based on quoted
 market prices of the securities on an active exchange, which are
 considered Level 1 and Level 2 inputs.

[0001193125-16-476374:notes:83]
As of
 December 28, 2015 and December 29, 2014, the
 Company’s other financial instruments also included cash and
 cash equivalents, accounts receivable, accounts payable and
 equipment payables. Due to short-term maturities, the carrying
 amount of these instruments approximates fair value. Our cash and
 cash equivalents at December 28, 2015 consisted of $82,545
 held in the U.S., with the remaining $176,555 held by foreign
 subsidiaries.

[0001193125-16-476374:notes:84]
As of
 December 28, 2015 and December 29, 2014, the following
 financial assets and liabilities were measured at fair value on a
 recurring basis using the type of inputs shown:

[0001193125-16-476374:notes:85]
|  |  |  |  |  | Fair Value Measurements Using: |  |
|  |  | As of December 28, 2015 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Foreign exchange derivative liabilities |  | $ | 51 |  |  |  | — |  |  | $ | 51 |  |  |  | — |  |
| Foreign exchange derivative assets |  |  | 16 |  |  |  | — |  |  |  | 16 |  |  |  | — |  |
|  |  |  |  |  | Fair Value Measurements Using: |  |
|  |  | As of December 29, 2014 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |
|  |  | (In thousands) |  |
| Money market funds |  | $ | 129,012 |  |  | $ | 129,012 |  |  |  | — |  |  |  | — |  |
| Foreign exchange derivative liabilities |  |  | 5,062 |  |  |  | — |  |  | $ | 5,062 |  |  |  | — |  |

[0001193125-16-476374:notes:86]
There were no
 transfers of financial assets or liabilities between Level 1 and
 Level 2 inputs for the years ended December 28, 2015 and
 December 29, 2014.

[0001193125-16-476374:notes:87]
The majority of
 the Company’s non-financial assets and liabilities, which
 include goodwill, intangible assets, inventories, and property,
 plant and equipment, are not required to be carried at fair value
 on a recurring basis. However, if certain triggering events occur
 (or are tested at least annually for goodwill) such that a
 non-financial instrument is required to be evaluated for
 impairment, based upon a comparison of the non-financial
 instrument’s fair value to its carrying value, an impairment
 is recorded to reduce the carrying value to the fair value, if the
 carrying value exceeds the fair value.

[0001193125-16-476374:notes:88]
For the years
 ended December 29, 2014 and December 30, 2013, the
 following assets were measured at fair value on a nonrecurring
 basis using the type of inputs shown:

[0001193125-16-476374:notes:89]
|  |  | Fair Value Measurements Using: |  |
|  |  | December 29, 2014 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |  | Total Losses for the Year Ended December 29, 2014 |  |
|  |  | (In thousands) |  |
| Assets held for sale |  | $ | 21,031 |  |  |  | — |  |  | $ | 21,031 |  |  |  | — |  |  | $ | 1,845 |  |
|  |  | Fair Value Measurements Using: |  |
|  |  | December 30, 2013 |  |  | Level 1 Inputs |  |  | Level 2 Inputs |  |  | Level 3 Inputs |  |  | Total Losses for the Year Ended December 30, 2013 |  |
|  |  | (In thousands) |  |
| Assets held for sale |  | $ | 2,519 |  |  |  | — |  |  | $ | 2,519 |  |  |  | — |  |  | $ | 10,782 |  |

[0001193125-16-476374:notes:90]
There was no
 impairment of long-lived assets recognized in the year ended
 December 28, 2015.

[0001193125-16-476374:notes:91]
The fair values
 of assets held for sale were primarily determined using appraisals
 and comparable prices of similar assets, which are considered to be
 Level 2 inputs.


## us-gaap:DerivativesPolicyTextBlock

[0001193125-16-476374:notes:92]
Derivative Instruments and Hedging
 Activities

[0001193125-16-476374:notes:93]
Derivative
 financial instruments are recognized as either assets or
 liabilities in the consolidated balance sheet at their respective
 fair values. As a matter of policy, the Company uses derivatives
 for risk management purposes. The Company does not use derivatives
 for speculative purposes.

[0001193125-16-476374:notes:94]
Derivatives are
 typically entered into as hedges for changes in interest rates,
 currency exchange rates, and other risks. When the Company
 determines to designate a derivative instrument as a cash flow
 hedge, the Company formally documents the hedging relationship and
 its risk management objective and strategy for undertaking the
 hedge, the hedging instrument, the hedged item, the nature of the
 risk being hedged, how the hedging instrument’s effectiveness
 in offsetting the hedged risk will be assessed, and a description
 of the method of measuring ineffectiveness. The Company also
 formally assesses, both at the hedge’s inception and on an
 ongoing basis, whether the derivative that is used in hedging
 transactions is highly effective in offsetting changes in cash
 flows of hedged items.

[0001193125-16-476374:notes:95]
Fair value of
 the derivative instruments is determined using pricing models
 developed based on the underlying swap interest rate, foreign
 currency exchange rates, and other observable market data as
 appropriate. The values are also adjusted to reflect nonperformance
 risk of the counterparty and the Company, as necessary. For
 derivatives that are designated as a cash flow hedge, changes in
 the fair value of the derivative are recognized in accumulated
 other comprehensive income, to the extent the derivative is
 effective at offsetting the changes in cash flow being hedged until
 the hedged item affects earnings. To the extent there is any hedge
 ineffectiveness, changes in fair value relating to the ineffective
 portion are immediately recognized in earnings. Changes in the fair
 value of derivatives that are not designated as hedges are recorded
 in earnings each period.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-16-476374:notes:96]
The fiscal
 calendar maturities of long-term debt through 2020 and thereafter
 are as follows:

[0001193125-16-476374:notes:97]
|  |  | (In thousands) |  |
| 2016 |  | $ | 157,375 |  |
| 2017 |  |  | — |  |
| 2018 |  |  | 27,125 |  |
| 2019 |  |  | 47,500 |  |
| 2020 |  |  | 297,500 |  |
| Thereafter |  |  | 748,125 |  |
|  |  | $ | 1,277,625 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-16-476374:notes:98]
Recently Adopted and Issued Accounting
 Standards

[0001193125-16-476374:notes:99]
In November
 2015 the Financial Accounting Standards Board (FASB) issued
 Accounting Standards Update (ASU) No. 2015-17, Balance Sheet Classification
 of Deferred Taxes, which requires entities with a classified
 balance sheet to present all deferred tax assets and liabilities as
 non-current. We adopted the provisions of this update in the fourth
 quarter of 2015 on a prospective basis. The impact on the
 Company’s consolidated financial statements was not
 material.

[0001193125-16-476374:notes:100]
In September
 2015, the FASB issued ASU 2015-16, Simplifying the Accounting
 for Measurement-Period Adjustments, which requires that an
 acquirer recognize adjustments to provisional values of assets
 acquired and liabilities assumed in a business combination in the
 reporting period in which the adjustment amounts are determined and
 not on a retrospective basis. The Company adopted ASU 2015-16 in
 the third quarter of 2015, and the Company’s adoption did not
 have a material impact on its consolidated financial
 statements.

[0001193125-16-476374:notes:101]
In April
 2015, the FASB issued ASU 2015-03, Imputation of Interest,
 which requires an entity to record debt issuance costs related to a
 note reported in the balance sheet as a direct deduction from the
 face amount of that note. The update is effective for annual
 periods ending after December 15, 2015. Early application is
 permitted. The standard requires the use of the retrospective
 transition method. The impact on the Company’s consolidated
 financial statements is not expected to be material.

[0001193125-16-476374:notes:102]
In May 2014,
 the FASB issued ASU 2014-09, Revenue from Contracts with
 Customers, which requires an entity to recognize the amount of
 revenue to which it expects to be entitled for the transfer of
 promised goods or services to customers. The ASU will replace most
 existing revenue recognition guidance in U.S. GAAP when it becomes
 effective. The new standard is effective for the Company at the
 beginning of fiscal year 2018, however application of the standard
 is allowed as early as the beginning of fiscal 2017. The standard
 permits the use of either the retrospective or cumulative effect
 transition method. The Company is evaluating the effect that ASU
 2014-09 will have on its consolidated financial statements and
 related disclosures. The Company has not yet selected a transition
 method nor has it determined the effect of the standard on its
 ongoing financial reporting.


## us-gaap:ScheduleOfIncomeBeforeIncomeTaxDomesticAndForeignTableTextBlock

[0001193125-16-476374:notes:103]
The components
 of income (loss) before income taxes for the years ended
 December 28, 2015, December 29, 2014 and
 December 30, 2013 are:

[0001193125-16-476374:notes:104]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| United States |  | $ | (104,068 | ) |  | $ | (3,201 | ) |  | $ | (2,247 | ) |
| Foreign |  |  | 113,044 |  |  |  | 25,492 |  |  |  | 42,019 |  |
| Income before income taxes |  | $ | 8,976 |  |  | $ | 22,291 |  |  | $ | 39,772 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-16-476374:notes:105]
Cash
 Equivalents

[0001193125-16-476374:notes:106]
The Company
 considers highly liquid investments with insignificant interest
 rate risk and original maturities to the Company of three months or
 less to be cash equivalents. Cash equivalents consist primarily of
 interest-bearing bank accounts and money market funds.

[0001193125-16-476374:notes:107]
The Company
 considers highly liquid investments with an effective maturity to
 the Company of more than three months and less than one year to be
 short-term investments.

[0001193125-16-476374:notes:108]
As of
 December 28, 2015, the Company had $3,530 of restricted cash
 related to the collaterization of certain letter of credit
 arrangements. These letter of credit arrangements are due to expire
 at various times during 2016.


## us-gaap:IncomeTaxPolicyTextBlock

[0001193125-16-476374:notes:109]
Income
 Taxes

[0001193125-16-476374:notes:110]
Income taxes
 are accounted for under the asset and liability method. Deferred
 income tax assets or liabilities are recognized for the future tax
 consequences attributable to differences between the financial
 statement carrying amounts of assets and liabilities and their
 respective tax bases and operating loss and tax credit
 carryforwards. Deferred income tax assets and liabilities are
 measured using enacted tax rates expected to apply to taxable
 income in the years in which those temporary differences are
 expected to be settled or realized. The effect on deferred income
 tax assets and liabilities of a change in tax rates is recognized
 in income in the period that includes the enactment date. Deferred
 income tax assets are reviewed for recoverability, and the Company
 records a valuation allowance to reduce its deferred income tax
 assets when it is more likely than not that all or some portion of
 the deferred income tax assets will not be realized.

[0001193125-16-476374:notes:111]
The Company has
 various foreign subsidiaries formed or acquired to conduct or
 support its business outside the United States. The Company does
 not provide for U.S. income taxes on undistributed earnings for
 certain subsidiaries in China as management expects the foreign
 earnings will be indefinitely reinvested in such foreign
 jurisdictions. For certain subsidiaries within the China,
 indefinite investment of undistributed earnings has not been
 asserted between the respective subsidiaries and their foreign
 parent entity and therefore, a deferred tax liability for the
 foreign tax impacts has been recorded on the undistributed earnings
 of these subsidiaries.

[0001193125-16-476374:notes:112]
The Company
 recognizes the effect of income tax positions only if those
 positions are more likely than not of being sustained. Recognized
 income tax positions are measured at the largest amount that is
 greater than 50 percent likely to be realized. Changes in
 recognition or measurement are reflected in the period in which the
 change in judgment occurs. Estimated interest and penalties related
 to underpayment of income taxes are recorded as a component of
 income tax provision in the consolidated statement of
 operations.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001193125-16-476374:notes:113]
Foreign
 Currency Translation and Transactions

[0001193125-16-476374:notes:114]
The functional
 currency of certain of the Company’s subsidiaries is either
 the Chinese Renminbi (RMB) or the Hong Kong Dollar. Accordingly,
 assets and liabilities are translated into U.S. dollars using
 period-end exchange rates. Sales and expenses are translated at the
 average exchange rates in effect during the period. The resulting
 translation gains or losses are recorded as a component of
 accumulated other comprehensive income in the consolidated
 statement of stockholders’ equity and the consolidated
 statement of comprehensive income (loss). Net gains resulting from
 foreign currency remeasurements and transactions are included in
 income as a component of other, net in the consolidated statements
 of operations and totaled $6,766, $2,378, and $6,113 for the years
 ended December 28, 2015, December 29, 2014 and
 December 30, 2013, respectively.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001193125-16-476374:notes:115]
Loss
 Contingencies

[0001193125-16-476374:notes:116]
The Company
 establishes an accrual for an estimated loss contingency when it is
 both probable that an asset has been impaired or that a liability
 has been incurred and the amount of the loss can be reasonably
 estimated. Any legal fees expected to be incurred in connection
 with a contingency are expensed as incurred.


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock

[0001193125-16-476374:notes:117]
A
 reconciliation of the beginning and ending amount of unrecognized
 tax benefits, exclusive of accrued interest and penalties, is as
 follows:

[0001193125-16-476374:notes:118]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance |  | $ | 2,441 |  |  | $ | 2,298 |  |  | $ | 2,424 |  |
| Additions related to acquisition |  |  | 11,293 |  |  |  | — |  |  |  | — |  |
| Additions based on tax positions related to the current year |  |  | 3,349 |  |  |  | 220 |  |  |  | 322 |  |
| Additions for tax positions of prior years |  |  | 14 |  |  |  | 286 |  |  |  | — |  |
| Reductions for tax positions of prior years |  |  | (1,371 | ) |  |  | — |  |  |  | (448 | ) |
| Lapse of statute |  |  | (322 | ) |  |  | (363 | ) |  |  | — |  |
| Ending balance |  | $ | 15,404 |  |  | $ | 2,441 |  |  | $ | 2,298 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-16-476374:notes:119]
The components
 of income tax provision for the years ended December 28,
 2015, December 29, 2014 and December 30, 2013
 are:

[0001193125-16-476374:notes:120]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Current (provision) benefit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 477 |  |  | $ | 1,717 |  |  | $ | 6,684 |  |
| State |  |  | (345 | ) |  |  | (216 | ) |  |  | 643 |  |
| Foreign |  |  | (19,379 | ) |  |  | (5,385 | ) |  |  | (14,466 | ) |
| Total current |  |  | (19,247 | ) |  |  | (3,884 | ) |  |  | (7,139 | ) |
| Deferred (provision) benefit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (10,084 | ) |  |  | (829 | ) |  |  | (5,038 | ) |
| State |  |  | (2,184 | ) |  |  | 133 |  |  |  | (5,337 | ) |
| Foreign |  |  | (3,079 | ) |  |  | (3,018 | ) |  |  | 1,635 |  |
| Total deferred |  |  | (15,347 | ) |  |  | (3,714 | ) |  |  | (8,740 | ) |
| Total provision |  | $ | (34,594 | ) |  | $ | (7,598 | ) |  | $ | (15,879 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-16-476374:notes:121]
| (3) | Acquisition of Viasystems Group, Inc. |

[0001193125-16-476374:notes:122]
On
 May 31, 2015, the Company completed the acquisition of
 Viasystems Group, Inc. (Viasystems), for total consideration of
 $248,824 in cash and 15,082 shares of TTM common stock with a fair
 value of $149,006, to acquire all of the outstanding shares of
 capital stock and other equity rights of Viasystems. Additionally,
 in connection with the completion of the acquisition, the Company
 assumed and refinanced Viasystems’ debt, which was
 approximately $669,024 as of May 31, 2015. Viasystems was a
 worldwide provider of complex multi-layer rigid, flexible, and
 rigid-flex PCBs and custom electronic assemblies. Viasystems’
 products were found in a wide variety of commercial products,
 including automotive engine controls, hybrid converters, automotive
 electronics for navigation, safety, and entertainment,
 telecommunications switching equipment, data networking equipment,
 computer storage equipment, semiconductor test equipment, wind and
 solar energy applications, off-shore drilling equipment,
 communications applications, flight control systems, and complex
 industrial, medical, and other technical instruments.
 Viasystems’ E-M Solutions services have been be bundled with
 its PCB products to provide an integrated solution to customers.
 Viasystems operated 15 manufacturing facilities worldwide: eight in
 the United States, five in the People’s Republic of China
 (China), and one each in Canada and Mexico. Viasystems served a
 diversified customer base of over 1,000 customers in various
 markets throughout the world.

[0001193125-16-476374:notes:123]
Bank fees and
 legal, accounting, and other professional service costs associated
 with the acquisition of Viasystems of $34,448 and $5,981 for the
 years ended December 28, 2015 and December 29, 2014,
 respectively, have been expensed and recorded as general and
 administrative expense in the consolidated statements of
 operations. There were no bank fees and legal, accounting, and
 other professional service costs associated with the acquisition of
 Viasystems for the year ended December 30, 2013.

[0001193125-16-476374:notes:124]
The following
 summarizes the components of the purchase price:

[0001193125-16-476374:notes:125]
|  |  | (In thousands) |  |
| Value of TTM common stock issued |  | $ | 149,006 |  |
| Cash consideration |  |  | 248,824 |  |
|  |  |  | 397,830 |  |
| Debt assumed |  |  | 669,024 |  |
| Enterprise value |  | $ | 1,066,854 |  |

[0001193125-16-476374:notes:126]
The value of
 the shares of the Company’s common stock used in determining
 the purchase price was $9.88 per share, the closing price of the
 Company’s common stock on May 29, 2015, the last
 business day prior to the effective date of the
 acquisition.

[0001193125-16-476374:notes:127]
Preliminary Purchase Price Allocation

[0001193125-16-476374:notes:128]
The purchase
 price of the Viasystems acquisition was allocated to tangible and
 intangible assets acquired, liabilities assumed and noncontrolling
 interest based on preliminary estimates the fair value at the date
 of the acquisition (May 31, 2015). The excess of the purchase price
 over the fair value of net assets acquired and noncontrolling
 interest was allocated to goodwill. The fair value assigned to
 intangible assets acquired was based on estimates and assumptions
 made by management at the time of acquisition.

[0001193125-16-476374:notes:129]
The fair
 values assigned are based on reasonable methods applicable to the
 nature of the assets acquired, liabilities assumed and
 noncontrolling interest. The following summarizes the preliminary
 estimated fair values of net assets acquired and noncontrolling
 interest:

[0001193125-16-476374:notes:130]
|  |  | (In thousands) |  |
| Cash |  | $ | 79,662 |  |
| Restricted cash |  |  | 3,510 |  |
| Accounts and notes receivables ($216,259 contractual gross receivables) |  |  | 209,196 |  |
| Inventories |  |  | 132,216 |  |
| Prepaid expenses and other current assets |  |  | 30,633 |  |
| Property, plant and equipment |  |  | 427,457 |  |
| Identifiable intangible assets |  |  | 150,500 |  |
| Goodwill |  |  | 334,870 |  |
| Deposits and other noncurrent assets |  |  | 1,157 |  |
| Current liabilities |  |  | (253,263 | ) |
| Long-term debt |  |  | (669,024 | ) |
| Other liabilities |  |  | (41,784 | ) |
| Noncontrolling interest |  |  | (7,300 | ) |
| Total |  | $ | 397,830 |  |

[0001193125-16-476374:notes:131]
Due to the
 fact that the Viasystems acquisition has just recently occurred,
 the magnitude of the transaction, and as significant information to
 be obtained and analyzed resides in a foreign jurisdiction, the
 Company’s fair value estimates for the purchase price
 allocation are preliminary and may change during the allowable
 measurement period, which is up to the point the Company obtains
 and analyzes the information that existed as of the date of the
 acquisition necessary to determine the fair values of the assets
 acquired, liabilities assumed and noncontrolling interest, but in
 no case to exceed more than one year from the date of acquisition.
 As of December 28, 2015, the Company had not finalized the
 determination of fair values allocated to deferred taxes, goodwill,
 tax uncertainties, income taxes payable, and other liabilities. Any
 changes in the fair values of the liabilities assumed during the
 measurement period may result in material adjustments to
 goodwill.

[0001193125-16-476374:notes:132]
Inventories

[0001193125-16-476374:notes:133]
The Company
 acquired $132,216 of inventories as a result of the acquisition,
 which includes a fair value step up of $14,200. Finished goods were
 valued at estimated selling prices less costs of disposal and a
 reasonable profit allowance for the selling effort. Work-in-process
 inventory was valued at estimated selling prices less costs to
 complete, costs of disposal and a reasonable profit allowance for
 the completion and selling effort. The fair value step amount was
 charged to cost of goods sold over normal inventory turn periods
 and as of December 28, 2015 has been fully absorbed into cost
 of goods sold. Raw materials were valued at estimated replacement
 cost.

[0001193125-16-476374:notes:134]
Property,
 Plant and Equipment

[0001193125-16-476374:notes:135]
The fair
 value of property, plant and equipment was determined by utilizing
 three approaches: the cost, sales comparison, and income
 capitalization approaches, each including management assumptions.
 Each approach assumes valuation of the property at the
 property’s highest and best use.

[0001193125-16-476374:notes:136]
Noncontrolling Interest

[0001193125-16-476374:notes:137]
Noncontrolling interest consists of a 5% equity interest in a
 manufacturing facility in Huiyang, China. The fair value was
 determined by utilizing a combination of income and market
 comparable approaches. The income approach was used to estimate the
 total enterprise value of the noncontrolling interest by estimating
 discounted future cash flows. The market comparable approach
 indicates the fair value of the noncontrolling interest based on a
 comparison to comparable enterprises in similar lines of business
 that are publicly traded.

[0001193125-16-476374:notes:138]
Identifiable Intangible Assets

[0001193125-16-476374:notes:139]
Acquired
 identifiable intangible assets include customer relationships and
 technology. The fair value of the identifiable intangible assets
 was determined using various income approach methods including
 excess earnings to determine the present value of expected future
 cash flows for each identifiable intangible asset based on discount
 rates which incorporate a risk premium to take into account the
 risks inherent in those expected cash flows. The expected cash
 flows were estimated based on forecasted revenues and costs
 adjusted based on the expectations of market participants. The
 Company used risk adjusted discount rates between 13% and 14% to
 discount the expected future cash flows under the income approach.
 The preliminary estimated fair value assigned to each class of
 intangible assets and the related weighted average amortization
 periods are as follows:

[0001193125-16-476374:notes:140]
|  |  | Estimated fair value |  |  | Weighted-average amortization period |  |
|  |  | (In thousands) |  |  |  |  |
| Customer relationships |  | $ | 147,500 |  |  |  | 8.1 years |  |
| Technology |  |  | 3,000 |  |  |  | 3.0 years |  |
|  |  | $ | 150,500 |  |  |  |  |  |

[0001193125-16-476374:notes:141]
Goodwill

[0001193125-16-476374:notes:142]
Goodwill
 represents the excess of the Viasystems purchase price over the
 fair value of assets acquired, liabilities assumed and
 noncontrolling interest. During the year ended December 28,
 2015, goodwill was adjusted to reflect:

[0001193125-16-476374:notes:143]
|  | • |  | a decrease in cash by $2,561 and restricted cash by $32 as a result of additional information received regarding the collateralization of specific letters of credit; |

[0001193125-16-476374:notes:144]
|  | • |  | an increase in trade and notes receivable by $1,063 as a result of additional information received regarding the collectability of such trade and notes receivable; |

[0001193125-16-476374:notes:145]
|  | • |  | a decrease in fair value of inventory by $6,061 resulting from additional information received regarding the valuation of inventory; |

[0001193125-16-476374:notes:146]
|  | • |  | a decrease in current assets of $390 as a result of additional information regarding value of current assets; |

[0001193125-16-476374:notes:147]
|  | • |  | a decrease in property, plant and equipment by $25,379 due to additional information received regarding the valuation of certain property acquired; |

[0001193125-16-476374:notes:148]
|  | • |  | an increase in intangible assets by $4,000 resulting from additional information received regarding the valuation of identifiable intangible assets; |

[0001193125-16-476374:notes:149]
|  | • |  | an increase in other noncurrent assets by $485 primarily related to a long-term below market lease asset; |

[0001193125-16-476374:notes:150]
|  | • |  | an increase in current liabilities by $5,423 due to a reassessment of product claims and other amounts due to vendors, and an decrease in other noncurrent liabilities by $637 primarily related to noncurrent deferred taxes; and |

[0001193125-16-476374:notes:151]
|  | • |  | an increase in noncontrolling interest by $3,277 resulting from additional information received regarding the valuation. |

[0001193125-16-476374:notes:152]
Prior to the
 Company’s acquisition of Viasystems, the Company had two
 reportable operating segments based on geographical location of
 operations, North America and Asia Pacific, consistent with the
 nature of its operations. Due to the acquisition, the Company has
 reassessed its reportable operating segments and determined that it
 has two reportable operating segments, PCB and E-M Solutions. The
 excess purchase price over the fair value of assets acquired,
 liabilities assumed and noncontrolling interest has been allocated
 to the PCB reportable operating segment given that Viasystems was
 primarily a worldwide provider of complex multi-layer rigid,
 flexible, and rigid-flex PCBs.

[0001193125-16-476374:notes:153]
The Company
 believes that the acquisition of Viasystems will produce the
 following significant benefits:

[0001193125-16-476374:notes:154]
|  | • |  | Strengthens the Company’s Position as a Global Market Leader. The combination of the Company and Viasystems is expected to create one of the largest and most diversified PCB manufacturers in the world. The addition of Viasystems adds new product technologies, production and development solutions, and customer base. |

[0001193125-16-476374:notes:155]
|  | • |  | Enhances End Market and Customer Diversification and Provides Entry to Attractive Automotive Markets. The Company believes that the combination will expand and diversify the Company’s customer base, end markets served, and product suite. The combination should significantly increase the Company’s presence in the automotive end market. In addition, the combination is expected to expand the Company’s presence in the Medical, Industrial and Instrumentation, Networking / Communications, and Aerospace / Defense end markets. |

[0001193125-16-476374:notes:156]
The Company
 believes that these primary factors support the amount of goodwill
 recognized as a result of the purchase price paid for Viasystems,
 in relation to other acquired tangible and intangible assets. The
 goodwill acquired in the acquisition is not expected to be
 deductible for income tax purposes subject to certain tax elections
 that are currently being considered.

[0001193125-16-476374:notes:157]
Results of
 Operations

[0001193125-16-476374:notes:158]
Included in
 the consolidated statement of operations are net sales from the
 Viasystems operations of $664,341, excluding intercompany sales,
 for the year ended December 28, 2015. Net losses included in
 the consolidated statement of operations from the Viasystems
 operations for the year ended December 28, 2015 have not been
 reported as it is impracticable to do so given the integration and
 other efficiency and cost saving measures in process during the
 year ended December 28, 2015.

[0001193125-16-476374:notes:159]
Pro forma
 Financial Information

[0001193125-16-476374:notes:160]
The unaudited
 pro forma financial information in the table below gives effect to
 this acquisition as if it had occurred at the beginning of fiscal
 2014. The pro forma financial information presented includes the
 effects of adjustments related to the fair value step up of
 acquired inventory, amortization of acquired intangible assets and
 depreciation of acquired fixed assets, and other non-recurring
 transactions costs directly associated with the acquisitions such
 as legal, accounting and banking fees.

[0001193125-16-476374:notes:161]
|  |  | Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands, except per share data) |  |
| Net sales |  | $ | 2,602,304 |  |  | $ | 2,529,819 |  |
| Net loss attributable to TTM Technologies, Inc. stockholders |  |  | (13,827 | ) |  |  | (12,186 | ) |
| Basic loss per share |  | $ | (0.15 | ) |  | $ | (0.12 | ) |
| Dilutive loss per share |  | $ | (0.15 | ) |  | $ | (0.12 | ) |

[0001193125-16-476374:notes:162]
The pro forma
 financial information as presented above is for informational
 purposes only and is not necessarily indicative of the actual
 results that would have been achieved had the Viasystems
 acquisition occurred at the beginning of the earliest period
 presented, or the results that may be achieved in future
 periods.


## us-gaap:ScheduleOfRestructuringAndRelatedCostsTextBlock

[0001193125-16-476374:notes:163]
The below table
 shows the utilization of the accrued restructuring costs during the
 year ended December 28 2015:

[0001193125-16-476374:notes:164]
|  |  | Severance |  |  | Contract Termination |  |  | Total |  |
|  |  | (In thousands) |  |
| Accrued at December 29, 2014 |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Charged to expense |  |  | 6,832 |  |  |  | 549 |  |  |  | 7,381 |  |
| Amount paid |  |  | (788 | ) |  |  | (14 | ) |  |  | (802 | ) |
| Accrued at December 28, 2015 |  | $ | 6,044 |  |  | $ | 535 |  |  | $ | 6,579 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001193125-16-476374:notes:165]
| (4) | Restructuring and Impairment Charges |

[0001193125-16-476374:notes:166]
Consolidation Plan and Restructuring
 Activities

[0001193125-16-476374:notes:167]
On
 September 29, 2015, the Company announced a consolidation plan
 that will result in the closure of the Company’s facilities
 in Cleveland, Ohio, Milpitas, California and Juarez, Mexico (the
 Consolidation Plan) and the layoff of approximately 480 employees
 at these sites. The Consolidation Plan is part of the
 Company’s integration strategy to improve total plant
 utilization, operational performance and customer focus following
 its recent acquisition of Viasystems. In accordance with the
 Consolidation Plan, the Company will combine its Cleveland and
 Milpitas facilities into its North Jackson, Ohio and Silicon
 Valley, California facilities, respectively, and close its Juarez
 facility.

[0001193125-16-476374:notes:168]
In connection
 with the Consolidation Plan and other global realignment
 restructuring efforts during the year ended December 28, 2015,
 the Company recognized a total of $6,832 in employee separation
 costs. These costs were classified as restructuring charges in the
 consolidated statement of operations. The Company recognized $2,050
 of employee separation costs in its PCB operating segment, $2,039
 in its E-M Solutions operating segment, and $2,743 in its Corporate
 operating segment. As of December 28, 2015, $6,044 of accrued
 separation costs remain for employees yet to be separated and are
 included as a component of accrued salaries, wages and benefits in
 the consolidated balance sheet. The Company expects the remaining
 employees to be separated and a significant amount of the remaining
 accrued restructuring costs to be paid by June 2016.

[0001193125-16-476374:notes:169]
Additionally,
 during the year ended December 28, 2015, the Company incurred
 $549 in contract termination costs primarily related to building
 operating leases associated with the down-sizing of its St. Louis,
 Missouri corporate office, which is included in the Corporate
 operating segment. These estimated contract termination costs are
 included as a component of other accrued expenses in the
 consolidated balance sheet.

[0001193125-16-476374:notes:170]
The Company
 also recorded other exit costs of $878 related to inventory
 write-downs associated with the consolidation of the Milpitas
 facility to other Silicon Valley, California facilities during the
 year ended December 28, 2015. These costs have been recorded
 as a component of cost of goods sold in the consolidated statement
 of operations.

[0001193125-16-476374:notes:171]
The Company
 estimates that it will incur total charges related to the Plan of
 approximately $10,000 to $15,000.

[0001193125-16-476374:notes:172]
Impairment
 and Sale of Suzhou, China Manufacturing Facility

[0001193125-16-476374:notes:173]
The Company
 ceased manufacturing at its Meadville Aspocomp (Suzhou) Electronic
 Co., Ltd. subsidiary, which held its Suzhou, China manufacturing
 facility, and shut down its operations in 2013. As a result, the
 Company determined that certain long-lived assets were impaired and
 as such, recorded charges of $1,845 and $10,782 for the years ended
 December 29, 2014 and December 30, 2013, respectively,
 primarily related to machinery and equipment held for
 sale.

[0001193125-16-476374:notes:174]
Additionally,
 as a result of the shutdown, the Company laid-off 774 employees at
 this site and recorded $3,445 in employee separation costs for the
 year ended December 30, 2013. These costs were classified as
 restructuring charges in the consolidated statement of operations.
 As of December 28, 2015 all employees had been
 separated.

[0001193125-16-476374:notes:175]
In the fourth
 quarter of 2014, the Company commenced the process of selling this
 subsidiary and classified its net assets of $21,031 as assets held
 for sale at December 29, 2014. Assets held for sale were
 included in prepaid expenses and other current assets in the
 December 29, 2014 consolidated balance sheet.

[0001193125-16-476374:notes:176]
During the year
 ended December 28, 2015, the Company sold its Meadville
 Aspocomp (Suzhou) Electronic Co., Ltd. subsidiary for $21,275 and
 recognized a gain of $2,504.

[0001193125-16-476374:notes:177]
The Suzhou,
 China manufacturing facility is included in the PCB operating
 segment.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001193125-16-476374:notes:178]
Revenue
 Recognition

[0001193125-16-476374:notes:179]
The Company
 derives its revenue primarily from the sale of PCBs using customer
 supplied engineering and design plans and recognizes revenue when:
 (i) persuasive evidence of a sales arrangement exists;
 (ii) the sales terms are fixed or determinable;
 (iii) title and risk of loss have transferred; and
 (iv) collectability is reasonably assured — generally
 when products are shipped to the customer, except in situations in
 which title passes upon receipt of the products by the customer. In
 this case, revenues are recognized upon notification that customer
 receipt has occurred. The Company does not have customer acceptance
 provisions, but it does provide its customers a limited right of
 return for defective PCBs. The Company accrues an estimated amount
 for sales returns and allowances related to defective PCBs at the
 time of sale based on its ability to estimate sales returns and
 allowances using current and historical information. The reserve
 for sales returns and allowances is included as a reduction to
 revenue and accounts receivable, net. Shipping and handling fees
 and related freight costs and supplies associated with shipping
 products to customers are included as a component of cost of goods
 sold. Incremental warranty costs that are not related to sales
 returns are recorded in accrued expenses and cost of goods
 sold.

[0001193125-16-476374:notes:180]
The following
 summarizes the activity in the Company’s allowance for sales
 returns and allowances for the years ended December 28,
 2015, December 29, 2014 and December 30,
 2013:

[0001193125-16-476374:notes:181]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 6,890 |  |  | $ | 6,028 |  |  | $ | 9,320 |  |
| Additions charged to expense |  |  | 21,728 |  |  |  | 38,440 |  |  |  | 33,154 |  |
| Sale of a majority owned subsidiary |  |  | — |  |  |  | — |  |  |  | (347 | ) |
| Deductions |  |  | (20,832 | ) |  |  | (37,578 | ) |  |  | (36,104 | ) |
| Effect of foreign currency exchange rates |  |  | 3 |  |  |  | — |  |  |  | 5 |  |
| Balance at end of year |  | $ | 7,789 |  |  | $ | 6,890 |  |  | $ | 6,028 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-16-476374:notes:182]
| (20) | Earnings Per Share |

[0001193125-16-476374:notes:183]
For the year
 ended December 28, 2015, potential shares of common stock,
 consisting of stock options to purchase approximately 420 shares of
 common stock at exercise prices ranging from $5.78 to $16.82 per
 share, 2,294 RSUs, and 572 PRUs were not included in the
 computation of diluted earnings per share because the Company
 incurred a net loss from operations and, as a result, the impact
 would be anti-dilutive.

[0001193125-16-476374:notes:184]
For the years
 ended December 29, 2014 and December 30, 2013, PRUs, RSUs
 and stock options to purchase 1,233 and 1,751 shares of common
 stock, respectively, were not considered in calculating diluted
 earnings per share because the options’ exercise prices or
 the total assumed proceeds under the treasury stock method for
 PRUs, RSUs or stock options was greater than the average market
 price of common shares during the applicable year and, therefore,
 the effect would be anti-dilutive.

[0001193125-16-476374:notes:185]
Additionally,
 for the year ended December 28, 2015, the effect of shares of
 common stock related to the Company’s convertible senior
 notes, based on the if-converted method, were not included in the
 computation of dilutive earnings per share because the Company
 incurred a net loss from operations and, as a result, the impact
 would be anti-dilutive.

[0001193125-16-476374:notes:186]
For the years
 ended December 29, 2014 and December 30, 2013, the effect
 of shares of common stock related to the Company’s
 convertible senior notes, based on the treasury stock method, were
 not included in the computation of dilutive earnings per share
 because the conversion price of the convertible senior notes were
 greater than the average market price of common shares during the
 applicable year, and therefore, the effect would be
 anti-dilutive.

[0001193125-16-476374:notes:187]
Outstanding
 warrants for the years ended December 28,
 2015, December 29, 2014 and December 30, 2013, to
 purchase common stock were not included in the computation of
 dilutive earnings per share because the strike price of the
 warrants to purchase the Company’s common stock were greater
 than the average market price of common shares during the
 applicable year, and therefore, the effect would be
 anti-dilutive.

[0001193125-16-476374:notes:188]
The below is a
 summary of amounts convertible to common stock related to
 convertible senior notes and related warrants:

[0001193125-16-476374:notes:189]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Common stock related to convertible senior notes |  |  | 25,940 |  |  |  | 27,970 |  |  |  | 25,265 |  |
| Warrants to purchase common stock |  |  | 26,408 |  |  |  | 28,020 |  |  |  | 23,654 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-16-476374:notes:190]
The following
 table summarizes the long-term debt of the Company as of
 December 28, 2015 and December 29, 2014:

[0001193125-16-476374:notes:191]
|  |  | Average Effective Interest Rate as of December 28, 2015 |  |  | December 28, 2015 |  |  | Average Effective Interest Rate as of December 29, 2014 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Term loan due May 2021 |  |  | 6.00 | % |  | $ | 947,625 |  |  |  | — |  |  |  | — |  |
| U.S. ABL revolving loan due May 2020 |  |  | 2.17 | % |  |  | 80,000 |  |  |  | — |  |  |  | — |  |
| Convertible Senior Notes due December 2020 |  |  | 1.75 | % |  |  | 250,000 |  |  |  | 1.75 | % |  | $ | 250,000 |  |
| Convertible Senior Notes due May 2015 |  |  | — |  |  |  | — |  |  |  | 3.25 | % |  |  | 32,395 |  |
| Term loan due September 2016 |  |  | — |  |  |  | — |  |  |  | 2.55 | % |  |  | 273,800 |  |
| Other |  |  | — |  |  |  | — |  |  |  | 6.00 | % |  |  | 4 |  |
|  |  |  |  |  |  |  | 1,277,625 |  |  |  |  |  |  |  | 556,199 |  |
| Less: Unamortized discount |  |  |  |  |  |  | (75,668 | ) |  |  |  |  |  |  | (53,512 | ) |
|  |  |  |  |  |  |  | 1,201,957 |  |  |  |  |  |  |  | 502,687 |  |
| Less: current maturities |  |  |  |  |  |  | (157,375 | ) |  |  |  |  |  |  | (128,045 | ) |
| Long-term debt, less current maturities |  |  |  |  |  | $ | 1,044,582 |  |  |  |  |  |  | $ | 374,642 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsGainLossInStatementOfFinancialPerformanceTextBlock

[0001193125-16-476374:notes:192]
The following
 table provides information about the amounts recorded in
 accumulated other comprehensive income related to derivatives
 designated as cash flow hedges, as well as the amounts recorded in
 each caption in the consolidated statements of operations when
 derivative amounts are reclassified out of accumulated other
 comprehensive income for the years ended December 28,
 2015, December 29, 2014 and December 30,
 2013:

[0001193125-16-476374:notes:193]
|  |  |  |  | For the Year Ended |  |
|  |  |  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |  | Effective Portion |  |  | Ineffective Portion |  |
|  |  | Financial Statement Caption |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/ (Loss) Recognized into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/ (Loss) Recognized into Income |  |  | Gain/(Loss) Recognized in Other Comprehensive Income |  |  | Gain/(Loss) Reclassified into Income |  |  | Gain/ (Loss) Recognized into Income |  |
|  |  | (In thousands) |  |
| Cash flow hedge: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward |  | Depreciation expense |  | $ | (20 | ) |  | $ | (172 | ) |  |  | — |  |  | $ | 43 |  |  | $ | (146 | ) |  |  | — |  |  | $ | (1,726 | ) |  | $ | (128 | ) |  |  | — |  |
|  |  |  |  | $ | (20 | ) |  | $ | (172 | ) |  |  | — |  |  | $ | 43 |  |  | $ | (146 | ) |  |  | — |  |  | $ | (1,726 | ) |  | $ | (128 | ) |  |  | — |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-16-476374:notes:194]
The Company
 uses the following estimated useful lives:

[0001193125-16-476374:notes:195]
| Land use rights |  |  | 50-99 years |  |
| Buildings and improvements |  |  | 7-50 years |  |
| Machinery and equipment |  |  | 3-12 years |  |
| Furniture and fixtures |  |  | 3-7 years |  |


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-16-476374:notes:196]
The net gain
 (loss) recognized in other, net in the consolidated statements of
 operations on derivative instruments not designated as hedges is as
 follows for the years December 28,
 2015, December 29, 2014 and December 30,
 2013:

[0001193125-16-476374:notes:197]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (374 | ) |  | $ | (3,579 | ) |  | $ | (2,381 | ) |
| Interest rate swap |  |  | — |  |  |  | — |  |  |  | 620 |  |
|  |  | $ | (374 | ) |  | $ | (3,579 | ) |  | $ | (1,761 | ) |


## us-gaap:DebtPolicyTextBlock

[0001193125-16-476374:notes:198]
Convertible Debt

[0001193125-16-476374:notes:199]
The accounting
 standards for convertible debt instruments that may be fully or
 partially settled in cash upon conversion require the debt and
 equity components to be separately accounted for in a manner that
 reflects the Company’s nonconvertible borrowing rate when
 interest expense is recognized in subsequent periods. The amount
 recorded as debt is based on the fair value of the debt component
 as a standalone instrument, determined using an average interest
 rate for similar nonconvertible debt issued by entities with credit
 ratings comparable to the Company’s at the time of issuance.
 The difference between the debt recorded at inception and its
 principal amount is to be accreted to principal through interest
 expense through the estimated life of the note.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-16-476374:notes:200]
| (11) | Accumulated Other Comprehensive Income |

[0001193125-16-476374:notes:201]
The following
 provides a summary of the components of accumulated other
 comprehensive income, net of tax as of December 28,
 2015, December 29, 2014 and December 30,
 2013:

[0001193125-16-476374:notes:202]
|  |  | Foreign Currency Translation |  |  | Gains (Losses) on Cash Flow Hedges |  |  | Unrealized Gains (Losses) on Available for Sale Securities |  |  | Total |  |
|  |  | (In thousands) |  |
| Ending balance at December 30, 2013 |  | $ | 47,280 |  |  | $ | (1,613 | ) |  | $ | (63 | ) |  | $ | 45,604 |  |
| Other comprehensive income (loss) before reclassifications |  |  | (14,841 | ) |  |  | 43 |  |  |  | (20 | ) |  |  | (14,818 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | — |  |  |  | 146 |  |  |  | 83 |  |  |  | 229 |  |
| Net year to date period other comprehensive income (loss) |  |  | (14,841 | ) |  |  | 189 |  |  |  | 63 |  |  |  | (14,589 | ) |
| Ending balance at December 29, 2014 |  |  | 32,439 |  |  |  | (1,424 | ) |  |  | — |  |  |  | 31,015 |  |
| Other comprehensive loss before reclassifications |  |  | (27,758 | ) |  |  | (20 | ) |  |  | — |  |  |  | (27,778 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,786 | ) |  |  | 172 |  |  |  | — |  |  |  | (1,614 | ) |
| Net year to date period other comprehensive income (loss) |  |  | (29,544 | ) |  |  | 152 |  |  |  | — |  |  |  | (29,392 | ) |
| Ending balance at December 28, 2015 |  | $ | 2,895 |  |  | $ | (1,272 | ) |  | $ | — |  |  | $ | 1,623 |  |

[0001193125-16-476374:notes:203]
The following
 provides a summary of reclassifications out of accumulated other
 comprehensive income, net of tax for the years ended
 December 28, 2015, December 29, 2014 and
 December 30, 2013:

[0001193125-16-476374:notes:204]
|  |  |  |  | Amount Reclassified from Accumulated Other Comprehensive Income For the Year Ended |  |
| Details about Accumulated Other Comprehensive Income Components |  | Statement of Operations Location |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
| Loss on cash flow hedges |  | Depreciation expense, net of tax |  | $ | 172 |  |  | $ | 146 |  |  | $ | 128 |  |
| Loss on available for sale securities |  | Other, net, net of tax |  | $ | — |  |  | $ | 83 |  |  | $ | 53 |  |
| Gain on foreign currency translation |  | Gain on sale of assets, net of tax |  | $ | (1,786 | ) |  | $ | — |  |  | $ | (14,266 | ) |


## us-gaap:ScheduleOfDerivativeInstrumentsTextBlock

[0001193125-16-476374:notes:205]
The fair values
 of derivative instruments in the consolidated balance sheets are as
 follows:

[0001193125-16-476374:notes:206]
|  |  |  |  | Asset / (Liability) Fair Value as of |  |
|  |  | Balance Sheet Location |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  |  |  | (In thousands) |  |
| Cash flow derivative instruments designated as hedges: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other accrued expenses |  | $ | — |  |  | $ | (12 | ) |
| Foreign exchange contracts |  | Deposits and other non-current assets |  |  | — |  |  |  | — |  |
| Cash flow derivative instruments not designated as hedges: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Prepaid expenses and other current assets |  |  | 16 |  |  |  | — |  |
| Foreign exchange contracts |  | Other accrued expenses |  |  | (51 | ) |  |  | (5,050 | ) |
|  |  |  |  | $ | (35 | ) |  | $ | (5,062 | ) |


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001193125-16-476374:notes:207]
Stock-Based Compensation

[0001193125-16-476374:notes:208]
The Company
 recognizes stock-based compensation expense in its consolidated
 financial statements for its incentive compensation plan
 awards.

[0001193125-16-476374:notes:209]
The incentive
 compensation plan awards include performance-based restricted stock
 units, restricted stock units, and stock options and the associated
 compensation expense is based on the grant date fair value of the
 awards, net of estimated forfeitures, as well as an assessment of
 probability of the performance-based awards vesting. Compensation
 expense for the incentive compensation plan awards is recognized on
 a straight line basis over the vesting period of the awards. The
 fair value of performance-based restricted stock units is estimated
 on the grant date using a Monte Carlo simulation model based on the
 underlying common stock closing price as of the date of grant, the
 expected term, stock price volatility, and risk-free interest
 rates. The fair value of restricted stock units is measured on the
 grant date based on the quoted closing market price of the
 Company’s common stock. The fair value of the stock options
 is estimated on the grant date using the Black-Scholes option
 pricing model based on the underlying common stock closing price as
 of the date of grant, the expected term, stock price volatility,
 and risk-free interest rates.


## us-gaap:SummaryOfValuationAllowanceTextBlock

[0001193125-16-476374:notes:210]
The following
 summarizes the activity in the Company’s valuation allowance
 for the years ended December 28, 2015, December 29,
 2014 and December 30, 2013:

[0001193125-16-476374:notes:211]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 38,839 |  |  | $ | 44,160 |  |  | $ | 41,790 |  |
| Additions related to acquisition |  |  | 177,699 |  |  |  | — |  |  |  | — |  |
| Additions charged to expense |  |  | 39,149 |  |  |  | 6,458 |  |  |  | 6,763 |  |
| Reduction related to sale of foreign subsidiary |  |  | (21,495 | ) |  |  | — |  |  |  | — |  |
| Deductions |  |  | — |  |  |  | (11,779 | ) |  |  | (4,393 | ) |
| Balance at end of year |  | $ | 234,192 |  |  | $ | 38,839 |  |  | $ | 44,160 |  |


## us-gaap:ScheduleOfCashFlowHedgesIncludedInAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-16-476374:notes:212]
The following
 provides a summary of the activity associated with the designated
 cash flow hedges reflected in accumulated other comprehensive
 income for the years ended December 28,
 2015, December 29, 2014 and December 30,
 2013:

[0001193125-16-476374:notes:213]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Beginning balance, net of tax |  | $ | (1,424 | ) |  | $ | (1,613 | ) |  | $ | (15 | ) |
| Changes in fair value gain (loss), net of tax |  |  | (20 | ) |  |  | 43 |  |  |  | (1,726 | ) |
| Reclassification to earnings, net of tax |  |  | 172 |  |  |  | 146 |  |  |  | 128 |  |
| Ending balance, net of tax |  | $ | (1,272 | ) |  | $ | (1,424 | ) |  | $ | (1,613 | ) |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-16-476374:notes:214]
| (1) | Nature of Operations and Basis of Presentation |

[0001193125-16-476374:notes:215]
TTM
 Technologies, Inc. (the Company or TTM) is a major global printed
 circuit board (PCB) manufacturer, focusing on quick-turn and
 technologically advanced PCBs and electro-mechanical solutions (E-M
 Solutions). The Company provides time-to-market and advanced
 technology products and offers a one-stop manufacturing solution to
 customers from engineering support to prototype development through
 final volume production. This one-stop manufacturing solution
 allows the Company to align technology developments with the
 diverse needs of the Company’s customers and to enable them
 to reduce the time required to develop new products and bring them
 to market.

[0001193125-16-476374:notes:216]
The Company
 serves a diversified customer base in various markets throughout
 the world, including manufacturers of networking/communications
 infrastructure products, tablets and smartphones, as well as the
 aerospace and defense, automotive controls and information systems,
 high-end computing, and medical, industrial and instrumentation
 related products. The Company’s customers include both
 original equipment manufacturers (OEMs) and electronic
 manufacturing services (EMS) providers.

[0001193125-16-476374:notes:217]
The Company
 operates on a 52 or 53 week year ending on the Monday nearest
 December 31. Fiscal 2015, 2014 and 2013 were 52 weeks and
 ended on December 28, 2015, December 29, 2014, and
 December 30, 2013, respectively. All references to years
 relate to fiscal years unless otherwise noted.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-16-476374:notes:218]
| (9) | Income Taxes |

[0001193125-16-476374:notes:219]
The
 components of income (loss) before income taxes for the years ended
 December 28, 2015, December 29, 2014 and
 December 30, 2013 are:

[0001193125-16-476374:notes:220]
The Company
 expects its foreign earnings attributable to all foreign
 subsidiaries will be indefinitely reinvested in such foreign
 jurisdictions and, therefore, no deferred tax liabilities for U.S.
 income taxes on undistributed earnings are recorded. The
 undistributed earnings of the foreign subsidiaries amounted to
 approximately $620,339 as of December 28, 2015. The
 determination of unrecognized deferred tax liability related to
 these undistributed earnings is not practicable. Foreign earnings
 attributable to certain manufacturing subsidiaries within China may
 be repatriated to the parent holding company located in Hong Kong,
 and therefore, a deferred tax liability of approximately $4,740 for
 the foreign tax impacts has been recorded on the undistributed
 earnings of these subsidiaries.

[0001193125-16-476374:notes:221]
After the
 acquisition of Viasystems, the Company determined it will
 indefinitely reinvest the undistributed earnings from the backplane
 assembly facility in Shanghai, China. As such, the previously
 recognized deferred tax liability of $8,281 for U.S. income taxes
 on these undistributed earnings was reversed as income tax benefit
 in 2015.

[0001193125-16-476374:notes:222]
The
 components of income tax provision for the years ended
 December 28, 2015, December 29, 2014 and
 December 30, 2013 are:

[0001193125-16-476374:notes:223]
Deferred
 income taxes reflect the net tax effects of temporary differences
 between the carrying amounts of assets and liabilities for
 financial reporting purposes and the amounts used for income tax
 purposes. The significant components of the net deferred income tax
 assets as of December 28, 2015 and December 29, 2014 are
 as follows:

[0001193125-16-476374:notes:224]
As of
 December 28, 2015, the Company had the following net operating
 loss (“NOL”) carryforwards: $478,916 in the U.S. for
 federal, $589,468 in various U.S. states, $50,492 in China, $36,606
 in Hong Kong and $345 in the Netherlands. The U.S. federal NOLs
 expire in 2021 through 2035, the various U.S. states NOLs expire in
 2016 through 2035, the China NOLs expire in 2016 through 2020 and
 the Netherlands NOLs expire in 2017. Further, the Company’s
 tax credits were approximately $22,696 of which $9,210 carryforward
 indefinitely.

[0001193125-16-476374:notes:225]
In connection
 with the Company’s acquisition of Viasystems, there was more
 than a 50% change in ownership under Section 382 of the
 Internal Revenue Code of 1986, as amended, and regulations issued
 there under. As a consequence, the utilization of the acquired
 Viasystems U.S. NOLs is limited to approximately $9,400 per year.
 In addition, the Company recognizes certain gains built in at the
 time of the ownership change, which increase the limitation by
 approximately $48,500 for each of the first 5 years after the
 acquisition. Any unused limitation in a year can be carried over to
 succeeding years.

[0001193125-16-476374:notes:226]
A valuation
 allowance is provided when it is more likely than not that all or
 some portion of the deferred income tax assets will not be
 realized. Before the acquisition of Viasystems, the Company had net
 U.S. deferred tax assets. Upon acquisition, the Company now has
 recorded an income tax expense of $19,593 to establish a full
 valuation allowance on all of its deferred tax assets such as its
 NOL and tax credits in the United States. Certain subsidiaries
 within China continue to have net operating loss carryforwards in
 various tax jurisdictions that the Company has determined are not
 more likely than not to be utilized. Based on historical
 performance and future expectations of these subsidiaries, the
 Company does not anticipate sufficient taxable income to utilize
 these net operating loss carryforwards. As a result, a full
 valuation allowance has been recorded for these subsidiaries at
 December 28, 2015. For the remaining net deferred income tax
 asset, management has determined that it is more likely than not
 that the results of future operations will generate sufficient
 taxable income to realize the net deferred tax asset.

[0001193125-16-476374:notes:227]
Certain
 entities within China operated under the high technology enterprise
 (HNTE) status and tax holidays, which were effective for the years
 ended December 28, 2015, December 29, 2014 and
 December 30, 2013. The HNTE and tax holidays decreased Chinese
 taxes by $7,600, $1,877 and $3,187, which (decreased) increased
 both basic and dilutive (loss) earnings per share by $(0.08), $0.02
 and $0.04, for the years ended December 28,
 2015, December 29, 2014 and December 30, 2013,
 respectively. HTNE status and tax holidays expire at various dates
 through 2017 and the Company expects to continue to file for
 renewal of such HNTE status and tax holidays for the foreseeable
 future.

[0001193125-16-476374:notes:228]
As of
 December 28, 2015 and December 29, 2014, the Company
 recorded unrecognized tax benefits of $10,649 and $31,
 respectively, as well as interest and penalties of $12,202 and $22,
 respectively, to other long-term liabilities. The Company has also
 recorded unrecognized tax benefits of $4,755 and $1,385 against
 certain deferred tax assets as of December 28, 2015 and
 December 29 2014, respectively. The amount of unrecognized tax
 benefits that would, if recognized, reduce the Company’s
 effective income tax rate in any future periods is $22,851
 including interest and penalties. The Company expects its
 unrecognized tax benefits to decrease by $2,595 along with related
 interest of $4,017 over the next 12 months due to expiring
 statutes.

[0001193125-16-476374:notes:229]
As of
 December 28, 2015, the Company is subject to (i) U.S.
 federal income tax examination for tax years from 1998 to 2015,
 (ii) state and local income tax examination for tax years 2002
 to 2015, and (iii) foreign income tax examinations generally
 for tax years from 2005 to 2015.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-16-476374:notes:230]
| 2) | Summary of Significant Accounting Policies |

[0001193125-16-476374:notes:231]
Use of
 Estimates

[0001193125-16-476374:notes:232]
The
 preparation of financial statements in conformity with accounting
 principles generally accepted in the United States of America (U.S.
 GAAP) requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities and
 disclosure of contingent assets and liabilities at the date of the
 financial statements and the reported amount of revenues and
 expenses during the reporting period. Such estimates include the
 sales return reserve; accounts receivable; inventories; goodwill;
 intangible assets and other long-lived assets; self insurance
 reserves; derivative instruments and hedging activities; product
 warranty liabilities; environmental liabilities; legal
 contingencies; income taxes; and others. These estimates and
 assumptions are based on management’s best estimates and
 judgment. Management evaluates its estimates and assumptions on an
 ongoing basis using historical experience and other factors,
 including the economic environment, which management believes to be
 reasonable under the circumstances. Management adjusts such
 estimates and assumptions when facts and circumstances dictate.
 Unpredictable spending by OEM and EMS companies has also increased
 the uncertainty inherent in such estimates and assumptions. As
 future events and their effects cannot be determined with
 precision, actual results could differ from those
 estimates.

[0001193125-16-476374:notes:233]
The
 functional currency of certain of the Company’s subsidiaries
 is either the Chinese Renminbi (RMB) or the Hong Kong Dollar.
 Accordingly, assets and liabilities are translated into U.S.
 dollars using period-end exchange rates. Sales and expenses are
 translated at the average exchange rates in effect during the
 period. The resulting translation gains or losses are recorded as a
 component of accumulated other comprehensive income in the
 consolidated statement of stockholders’ equity and the
 consolidated statement of comprehensive income (loss). Net gains
 resulting from foreign currency remeasurements and transactions are
 included in income as a component of other, net in the consolidated
 statements of operations and totaled $6,766, $2,378, and $6,113 for
 the years ended December 28, 2015, December 29, 2014
 and December 30, 2013, respectively.

[0001193125-16-476374:notes:234]
Accounts Receivable and Allowance for Doubtful
 Accounts

[0001193125-16-476374:notes:235]
Accounts
 receivable are reflected at estimated net realizable value, do not
 bear interest and do not generally require collateral. The Company
 performs credit evaluations of its customers and adjusts credit
 limits based upon payment history and the customer’s current
 creditworthiness. The Company maintains an allowance for doubtful
 accounts based upon a variety of factors. The Company reviews all
 open accounts and provides specific reserves for customer
 collection issues when it believes the loss is probable,
 considering such factors as the length of time receivables are past
 due, the financial condition of the customer, and historical
 experience. The Company also records a reserve for all customers,
 excluding those that have been specifically reserved for, based
 upon evaluation of historical losses.

[0001193125-16-476374:notes:236]
The following
 summarizes the activity in the Company’s allowance for
 doubtful accounts for the years ended December 28,
 2015, December 29, 2014 and December 30,
 2013:

[0001193125-16-476374:notes:237]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Balance at beginning of year |  | $ | 696 |  |  | $ | 518 |  |  | $ | 1,680 |  |
| Additions charged to (reversals of) expense |  |  | 854 |  |  |  | 214 |  |  |  | (157 | ) |
| Sale of a majority owned subsidiary |  |  | — |  |  |  | — |  |  |  | (459 | ) |
| Deductions |  |  | (26 | ) |  |  | (34 | ) |  |  | (554 | ) |
| Effect of foreign currency exchange rates |  |  | 1 |  |  |  | (2 | ) |  |  | 8 |  |
| Balance at end of year |  | $ | 1,525 |  |  | $ | 696 |  |  | $ | 518 |  |

[0001193125-16-476374:notes:238]
Inventories
 are stated at the lower of cost (determined on a first-in,
 first-out and weighted average basis) or market. Assessments to
 value the inventory at the lower of the actual cost to purchase and
 / or manufacture the inventory, or the current estimated market
 value of the inventory, are based upon assumptions about future
 demand and market conditions. As a result of the Company’s
 assessments, when the market value of inventory is less than the
 carrying value, the inventory cost is written down to the market
 value and the write down is recorded as a charge to cost of goods
 sold.

[0001193125-16-476374:notes:239]
Property, Plant and Equipment, Net

[0001193125-16-476374:notes:240]
Property,
 plant and equipment are recorded at cost. Depreciation expense is
 computed using the straight-line method over the estimated useful
 lives of the assets. Assets recorded under leasehold improvements
 are amortized using the straight-line method over the lesser of
 their useful lives or the related lease term. The Company uses the
 following estimated useful lives:

[0001193125-16-476374:notes:241]
Upon
 retirement or other disposition of property, plant and equipment,
 the cost and related accumulated depreciation are removed from the
 accounts. The resulting gain or loss is included in the
 determination of operating income in the period incurred.
 Depreciation and amortization expense on property, plant and
 equipment was $133,508, $95,349, and $92,120 for the years ended
 December 28, 2015, December 29, 2014 and
 December 30, 2013, respectively.

[0001193125-16-476374:notes:242]
The Company
 capitalizes interest on borrowings during the active construction
 period of major capital projects. Capitalized interest is amortized
 over the average useful lives of such assets, which primarily
 consist of buildings and machinery and equipment. The Company
 capitalized interest costs of $888, $551, and $1,125 during the
 years ended December 28, 2015, December 29, 2014 and
 December 30, 2013, respectively, in connection with various
 capital projects.

[0001193125-16-476374:notes:243]
Major
 renewals and betterments are capitalized and depreciated over their
 estimated useful lives while minor expenditures for maintenance and
 repairs are included in operating income as incurred.

[0001193125-16-476374:notes:244]
Goodwill
 represents the excess of purchase price of an acquisition over the
 fair value of net assets acquired. Goodwill is not amortized but
 instead is assessed for impairment, at a reporting unit level,
 annually and when events and circumstances warrant an evaluation.
 In making this assessment, management relies on a number of
 factors, including expected future operating results, business
 plans, economic projections, anticipated future cash flows,
 business trends and market conditions.

[0001193125-16-476374:notes:245]
The Company
 has two reportable operating segments consisting of seven reporting
 units. The Company evaluates its goodwill on an annual basis in the
 fourth quarter or more frequently if it believes indicators of
 impairment exist. The Company first assesses qualitative factors to
 determine whether it is more likely than not that the fair value of
 a reporting unit is less than its carrying amount. If the Company
 concludes that it is more likely than not that the fair value of a
 reporting units is less than its carrying amount, it conducts a
 two-step quantitative goodwill impairment test. The first step of
 the impairment test involves comparing the fair values of the
 applicable reporting units with their carrying values. The Company
 estimates the fair values of its reporting units using a
 combination of the income and market approach. If the carrying
 amount of a reporting unit exceeds the reporting unit’s fair
 value, the Company performs the second step of the goodwill
 impairment test. The second step of the goodwill impairment test
 involves comparing the implied fair value of the affected reporting
 unit’s goodwill with the carrying value of that goodwill. The
 amount, by which the carrying value of the goodwill exceeds its
 implied fair value, if any, is recognized as an impairment loss. In
 the fourth quarter of 2015, the Company performed its annual
 impairment test qualitatively and concluded that goodwill was not
 impaired.

[0001193125-16-476374:notes:246]
Intangible Assets

[0001193125-16-476374:notes:247]
Intangible
 assets include customer relationships, technology and trade names,
 which are being amortized over their estimated useful lives using
 straight-line and accelerated methods. The estimated useful lives
 of such intangibles range from 3 years to 10 years.

[0001193125-16-476374:notes:248]
Impairment of Long-lived Assets

[0001193125-16-476374:notes:249]
Long-lived
 tangible assets, including property, plant and equipment, assets
 held for sale, and definite-lived intangible assets, are reviewed
 for impairment whenever events or changes in circumstances indicate
 that the carrying value of the asset or asset groups may not be
 recoverable. The Company regularly evaluates whether events or
 circumstances have occurred that indicate possible impairment and
 relies on a number of factors, including expected future operating
 results, business plans, economic projections, and anticipated
 future cash flows. The Company uses an estimate of the future
 undiscounted net cash flows and comparisons to like-kind assets, as
 appropriate, of the related asset or asset group over the remaining
 life in measuring whether the assets are recoverable. Measurement
 of the amount of impairment, if any, is based upon the difference
 between the asset’s carrying value and estimated fair value.
 Fair value is determined through various valuation techniques,
 including cost-based, market and income approaches as considered
 necessary. See Note 4 for information regarding the impairment of
 long-lived assets during the years ended 2014 and 2013.

[0001193125-16-476374:notes:250]
The Company
 classifies assets to be sold as assets held for sale when
 (i) Company management has approved and commits to a plan to
 sell the asset; (ii) the asset is available for immediate sale
 in its present condition and is ready for sale; (iii) an
 active program to locate a buyer and other actions required to sell
 the asset have been initiated; (iv) the sale of the asset is
 probable; (v) the asset is being actively marketed for sale at
 a price that is reasonable in relation to its current fair value;
 and (vi) it is unlikely that significant changes to the plan
 will be made or that the plan will be withdrawn. Assets classified
 as held for sale are recorded at the lower of the carrying amount
 or fair value less the cost to sell and are a component of prepaid
 expenses and other current assets in the consolidated balance
 sheet.

[0001193125-16-476374:notes:251]
The Company
 classifies assets held for use when a decision to dispose of an
 asset or a business is made and the held for sale criteria are not
 met. Assets of the business are evaluated for recoverability in the
 following order: (i) assets other than goodwill, property and
 intangibles; (ii) property and intangibles subject to
 amortization; and (iii) goodwill. In evaluating the
 recoverability of property and intangible assets subject to
 amortization, in a held for use business, the carrying value is
 first compared to the sum of the undiscounted cash flows expected
 to result from the use and eventual disposition. If the carrying
 value exceeds the undiscounted expected cash flows, then a fair
 value analysis is performed. An impairment charge is recognized if
 the carrying value exceeds the fair value.

[0001193125-16-476374:notes:252]
The Company
 has various foreign subsidiaries formed or acquired to conduct or
 support its business outside the United States. The Company does
 not provide for U.S. income taxes on undistributed earnings for
 certain subsidiaries in China as management expects the foreign
 earnings will be indefinitely reinvested in such foreign
 jurisdictions. For certain subsidiaries within the China,
 indefinite investment of undistributed earnings has not been
 asserted between the respective subsidiaries and their foreign
 parent entity and therefore, a deferred tax liability for the
 foreign tax impacts has been recorded on the undistributed earnings
 of these subsidiaries.

[0001193125-16-476374:notes:253]
Self
 Insurance

[0001193125-16-476374:notes:254]
The Company
 is primarily self insured in North America for group health
 insurance and workers compensation benefits provided to U.S.
 employees. The Company also purchases stop loss insurance to
 protect against annual claims per individual and at an aggregate
 level. The individual insured stop loss on the Company’s self
 insurance is $200 per individual for the recently acquired
 Viasystems subsidiaries and $300 per individual for the existing
 TTM subsidiaries for group health insurance and $250 per individual
 for worker’s compensation benefits. Self insurance
 liabilities are estimated for claims incurred but not paid based on
 judgment, using the Company’s historical claim data and
 information and analysis provided by actuarial and claim advisors,
 the Company’s insurance carrier and brokers. The Company has
 accrued $5,182 and $5,032 for self insurance liabilities as of
 December 28, 2015 and December 29, 2014, respectively,
 and these amounts are reflected within accrued salaries, wages and
 benefits in the consolidated balance sheets.

[0001193125-16-476374:notes:255]
Group health
 insurance and workers compensation benefits for the Company’s
 plants in China are fully insured with third parties.

[0001193125-16-476374:notes:256]
The
 accounting standards for convertible debt instruments that may be
 fully or partially settled in cash upon conversion require the debt
 and equity components to be separately accounted for in a manner
 that reflects the Company’s nonconvertible borrowing rate
 when interest expense is recognized in subsequent periods. The
 amount recorded as debt is based on the fair value of the debt
 component as a standalone instrument, determined using an average
 interest rate for similar nonconvertible debt issued by entities
 with credit ratings comparable to the Company’s at the time
 of issuance. The difference between the debt recorded at inception
 and its principal amount is to be accreted to principal through
 interest expense through the estimated life of the note.

[0001193125-16-476374:notes:257]
Derivatives
 are typically entered into as hedges for changes in interest rates,
 currency exchange rates, and other risks. When the Company
 determines to designate a derivative instrument as a cash flow
 hedge, the Company formally documents the hedging relationship and
 its risk management objective and strategy for undertaking the
 hedge, the hedging instrument, the hedged item, the nature of the
 risk being hedged, how the hedging instrument’s effectiveness
 in offsetting the hedged risk will be assessed, and a description
 of the method of measuring ineffectiveness. The Company also
 formally assesses, both at the hedge’s inception and on an
 ongoing basis, whether the derivative that is used in hedging
 transactions is highly effective in offsetting changes in cash
 flows of hedged items.

[0001193125-16-476374:notes:258]
Value
 Added and Sales Tax Collected from Customers

[0001193125-16-476374:notes:259]
As a part of
 the Company’s normal course of business, value added and
 sales taxes are collected from customers. Such taxes collected are
 remitted, in a timely manner, to the appropriate governmental tax
 authority on behalf of the customer. The Company’s policy is
 to present revenue and costs, net of value added and sales
 taxes.

[0001193125-16-476374:notes:260]
Fair
 Value Measures

[0001193125-16-476374:notes:261]
The Company
 measures at fair value certain of its financial and non-financial
 assets and liabilities by using a fair value hierarchy that
 prioritizes the inputs to valuation techniques used to measure fair
 value. Fair value is the price that would be received to sell an
 asset or paid to transfer a liability in an orderly transaction
 between market participants at the measurement date, essentially an
 exit price, based on the highest and best use of the asset or
 liability. The levels of the fair value hierarchy are:

[0001193125-16-476374:notes:262]
Level 1
 — Quoted market prices in active markets for identical assets
 or liabilities;

[0001193125-16-476374:notes:263]
Level 2
 — Significant other observable inputs (e.g., quoted prices
 for similar items in active markets, quoted prices for identical or
 similar items in markets that are not active, inputs other than
 quoted prices that are observable, such as interest rate and yield
 curves, and market-corroborated inputs); and

[0001193125-16-476374:notes:264]
Level 3
 — Unobservable inputs in which there is little or no market
 data, which require the reporting unit to develop its own
 assumptions.

[0001193125-16-476374:notes:265]
Environmental Accrual

[0001193125-16-476374:notes:266]
Accruals for
 estimated costs for environmental obligations generally are
 recognized no later than the date when the Company identifies what
 cleanup measures, if any, are likely to be required to address the
 environmental condition. Included in such obligations are the
 estimated direct costs to investigate and address the conditions,
 and the associated engineering, legal and consulting costs. In
 making these estimates, the Company considers information that is
 currently available, existing technology, enacted laws and
 regulations, and its estimates of the timing of the required
 remedial actions. Such accruals are initially measured on a
 discounted basis — and are adjusted as further information
 becomes available or circumstances change — and are accreted
 to the payable amount over time.

[0001193125-16-476374:notes:267]
Earnings Per Share

[0001193125-16-476374:notes:268]
Basic
 earnings per common share excludes dilution and is computed by
 dividing net income attributable to TTM Technologies, Inc.
 stockholders by the weighted average number of common shares
 outstanding during the period. Diluted earnings per common share
 reflect the potential dilution that could occur if stock options,
 convertible senior notes or other common stock equivalents were
 exercised or converted into common stock. The dilutive effect of
 stock options or other common stock equivalents is calculated using
 the treasury stock method, while the dilutive effect of convertible
 senior notes is calculated using the if-converted
 method.

[0001193125-16-476374:notes:269]
Comprehensive Income

[0001193125-16-476374:notes:270]
Comprehensive
 income includes changes to equity accounts that were not the result
 of transactions with stockholders. Comprehensive income is
 comprised of net income (loss), changes in the cumulative foreign
 currency translation adjustments and realized and unrealized gains
 or losses on hedged derivative instruments and available for sale
 securities.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-16-476374:notes:271]
| (14) | Commitments and Contingencies |

[0001193125-16-476374:notes:272]
Operating
 Leases

[0001193125-16-476374:notes:273]
The Company
 leases some of its manufacturing and assembly plants, a sales
 office and equipment under noncancellable operating leases that
 expire at various dates through 2024. Certain real property leases
 contain renewal provisions at the Company’s option. Most of
 the leases require the Company to pay for certain other costs such
 as property taxes and maintenance. Certain leases also contain rent
 escalation clauses (step rents) that require additional rental
 amounts in the later years of the term. Rent expense for leases
 with step rents is recognized on a straight-line basis over the
 minimum lease term.

[0001193125-16-476374:notes:274]
The following is
 a schedule of future minimum lease payments as of December 28,
 2015:

[0001193125-16-476374:notes:275]
|  |  | Operating Leases |  |
|  |  | (In thousands) |  |
| 2016 |  | $ | 8,332 |  |
| 2017 |  |  | 6,057 |  |
| 2018 |  |  | 2,762 |  |
| 2019 |  |  | 2,419 |  |
| 2020 |  |  | 1,630 |  |
| Thereafter |  |  | 6,403 |  |
| Total minimum lease payments |  | $ | 27,603 |  |

[0001193125-16-476374:notes:276]
Total rent
 expense for the years ended December 28,
 2015, December 29, 2014, and December 30, 2013, was
 approximately $7,362, $3,731 and $3,364, respectively.

[0001193125-16-476374:notes:277]
Legal
 Matters

[0001193125-16-476374:notes:278]
The Company is
 subject to various legal matters, which it considers normal for its
 business activities. While the Company currently believes that the
 amount of any reasonably possible loss for known matters would not
 be material to the Company’s financial condition, the outcome
 of these actions is inherently difficult to predict. In the event
 of an adverse outcome, the ultimate potential loss could have a
 material adverse effect on the Company’s financial condition
 or results of operations in a particular period. The Company has
 accrued amounts for its loss contingencies which are probable and
 estimable as of December 28, 2015 and December 29, 2014.
 However, these amounts are not material to the consolidated
 financial statements of the Company.

[0001193125-16-476374:notes:279]
Environmental Matters

[0001193125-16-476374:notes:280]
The process to
 manufacture PCBs requires adherence to city, county, state,
 federal, and foreign environmental regulations regarding the
 storage, use, handling and disposal of chemicals, solid wastes and
 other hazardous materials, as well as compliance with air quality
 standards and chemical use reporting. The Company believes that its
 facilities in the United States, Canada and Mexico comply in all
 material respects with applicable environmental laws and
 regulations. In China, governmental authorities have adopted new
 rules and regulations governing environmental issues. An update to
 the Chinese environmental waste water law was issued in late 2012,
 allowing for an interim period in which plants subject to such law
 may install equipment that meets the new regulatory regime. Some of
 the Company’s plants in China are not yet in full compliance
 with the updated environmental regulations. The Company believes it
 has developed plans acceptable to the Chinese government and is in
 the process of implementing these plans. The Company does not
 anticipate any immediate risk of government fines or temporary
 closure of its Chinese plants. The Company has established and
 enacted an investment plan related to the efforts to come into full
 compliance with the new regulations. The 2016 capital expenditure
 costs expected for these plans are included in the Company’s
 capital expenditure projections.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001193125-16-476374:notes:281]
| (22) | Non-controlling Interest Holdings |

[0001193125-16-476374:notes:282]
As of
 December 28, 2015, noncontrolling interest consists of a 5%
 equity interest in a manufacturing facility in Huiyang, China which
 was acquired with along with other assets and liabilities of
 Viasystems.

[0001193125-16-476374:notes:283]
During the year
 ended December 30, 2013, the Company completed the sale of its
 70.2% controlling equity interest in Dongguan Shengyi Electronics
 Ltd. (SYE) to its noncontrolling partner, Shengyi Technology Co.
 Ltd. (Sytech), for 702,000,000 Chinese RMB or $114,495. The Company
 recognized a gain on the sale of SYE of $17,917 in 2013.
 Consideration net of cash sold was $67,147.

[0001193125-16-476374:notes:284]
Additionally,
 the Company acquired Sytech’s 20.0% noncontrolling equity
 interest in Dongguan Meadville Circuits Ltd. (DMC) for 180,000,000
 Chinese RMB or $29,358 in 2013. The Company recorded a decrease to
 additional paid-in capital for the difference between the purchase
 price and the carrying value of the noncontrolling interest of
 $71.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-16-476374:notes:285]
| (21) | Related Party Transactions |

[0001193125-16-476374:notes:286]
In the normal
 course of business, the Company’s foreign subsidiaries
 purchase laminate and prepreg from related parties in which a
 significant shareholder of the Company holds an equity interest.
 The Company purchased laminate and prepreg from these related
 parties in the amount of $63,605, $47,446 and $62,648 for the years
 ended December 28, 2015, December 29, 2014 and
 December 30, 2013, respectively.

[0001193125-16-476374:notes:287]
Dongguan Shengyi
 Electronics Ltd. (SYE) is also a related party as it is a wholly
 owned subsidiary of an entity in which a significant shareholder of
 the Company holds an equity interest. The Company sells PCBs to SYE
 and purchases PCBs including various services relating to PCB
 manufacturing from SYE. Sales to SYE for the years ended
 December 28, 2015, December 29, 2014 and
 December 30, 2013 were $4,709, $24,120 and $29,616,
 respectively. Purchases of PCBs including various services relating
 to PCB manufacturing for the years ended December 28, 2015 and
 December 29, 2014 were $1,948 and $1,671, respectively. There
 were no purchases from SYE for the year ended December 30,
 2013.

[0001193125-16-476374:notes:288]
As of
 December 28, 2015 and December 29, 2014, the
 Company’s consolidated balance sheets included $29,306 and
 $17,950, respectively, in accounts payable due to related parties
 for purchases of laminate and prepreg and various PCB manufacturing
 services and such balances are included as a component of accounts
 payable on the consolidated balance sheets. Additionally, the
 Company’s consolidated balance sheets included $1,999 and
 $4,934, respectively, in accounts receivable due from a related
 party for sales of PCBs to SYE, as mentioned above, and such
 balances are included as a component of accounts receivable, net on
 the consolidated balance sheets.


## us-gaap:LongTermDebtTextBlock

[0001193125-16-476374:notes:289]
| (8) | Long-term Debt and Letters of Credit |

[0001193125-16-476374:notes:290]
Term and
 Revolving Loans

[0001193125-16-476374:notes:291]
On May 31,
 2015, in conjunction with the acquisition of Viasystems, the
 Company entered into a $950,000 Term Loan Credit Agreement (Term
 Loan). Additionally, the Company entered into a $150,000 U.S.
 Asset-Based Lending Credit Agreement (U.S. ABL) and a $150,000 Asia
 Asset-Based Lending Credit agreement (Asia ABL) (collectively the
 ABL Revolving Loans). The Company drew $80,000 of the U.S. ABL at
 the closing of the acquisition of Viasystems.

[0001193125-16-476374:notes:292]
The Term Loan
 was issued at a discount at 96.5% and bears interest at a floating
 rate of LIBOR, with a 1.0% LIBOR floor, plus an applicable interest
 margin of 5.0%, or JP Morgan Chase Bank’s prime rate, with a
 2% floor, plus a margin of 4%, at the Company’s option. At
 December 28, 2015, the weighted average interest rate on the
 outstanding borrowings under the Term Loan was 6.0%. There is no
 provision, other than an event of default, for the interest margin
 to increase. The Term Loan will mature on May 31, 2021. The
 Term Loan is secured by a significant amount of the assets of the
 Company and its domestic subsidiaries and a pledge of 65% of voting
 stock of the Company’s first tier foreign subsidiaries and is
 structurally senior to the Company’s convertible senior
 notes. See Convertible Senior Notes below.

[0001193125-16-476374:notes:293]
The U.S. ABL
 consists of three tranches comprised of a revolving credit facility
 of up to $150,000, a letter of credit facility of up to $75,000,
 and swingline loans of up to $30,000, provided that at no time may
 amounts outstanding under the tranches exceed in aggregate $150,000
 or the applicable borrowing base, which is a percentage of the
 principal amount of Eligible Accounts, as defined in the U.S. ABL
 agreement. Borrowings under the U.S. ABL bear interest at either a
 floating rate of LIBOR plus a margin of 175 basis points or JP
 Morgan Chase Bank’s prime rate plus a margin of 75 basis
 points, at the Company’s option. At December 28, 2015,
 the weighted average interest rate on the outstanding borrowings
 under the U.S. ABL was 2.17%. Beginning in 2016, the applicable
 margin can vary based on the remaining availability of the
 facility, from 150 to 200 basis points for LIBOR-based loans and
 from 50 to 100 basis points for JP Morgan Chase Bank’s prime
 rate-based loans. Other than availability and an event of default,
 there are no other provisions for the interest margin to increase.
 The U.S. ABL will mature on May 31, 2020. Loans made under the
 U.S. ABL are secured first by all of the Company’s domestic
 cash, receivables and inventories as well as by a second position
 against a significant amount of the assets of the Company and its
 domestic subsidiaries and a pledge of 65% of voting stock of the
 Company’s first tier foreign subsidiaries and are
 structurally senior to the Company’s convertible senior
 notes. See Convertible Senior Notes below. At December 28,
 2015, $80,000 of the U.S. ABL was outstanding and classified as
 short-term debt.

[0001193125-16-476374:notes:294]
The Company and
 its domestic subsidiaries have fully and unconditionally guaranteed
 the full and timely payment of all Term Loan and U.S. ABL related
 obligations.

[0001193125-16-476374:notes:295]
The Asia ABL
 consists of two tranches comprised of a revolving credit facility
 of up to $150,000 and a letter of credit facility of up to
 $100,000, provided that at no time may amounts outstanding under
 both tranches exceed in aggregate $150,000 or the applicable
 borrowing base, which is a percentage of the principal amount of
 Eligible Accounts, as defined in the Asia ABL agreement. Borrowings
 under the Asia ABL bear interest at a floating rate of LIBOR plus
 175 basis points. There is no provision, other than an event of
 default, for the interest margin to increase. The Asia ABL will
 mature on May 22, 2020. Loans made under the Asia ABL are
 secured by a portion of the Company’s Asia Pacific cash and
 receivables and are structurally senior to the Company’s
 domestic obligations, including the convertible senior notes. See
 Convertible Senior Notes below. The Company’s Asia Pacific
 subsidiary and certain of its subsidiaries have fully and
 unconditionally guaranteed the full and timely payment of all Asia
 ABL related obligations. At December 28, 2015, none of the
 Asia ABL was outstanding.

[0001193125-16-476374:notes:296]
The Company is
 required to make scheduled payments of the outstanding Term Loan
 balance on a quarterly basis beginning October 1, 2015. On
 October 1, 2015, the first scheduled principal payment of
 $2,375 was made. Based on certain parameters defined in the Term
 Loan agreement, the Company may be required to make an additional
 principal payment on an annual basis. For 2015, the Company is
 required to make an additional annual payment of $61,107, which is
 required to be paid in March 2016. In addition to the $61,107
 additional annual payment, the Company also intends to repay an
 additional $10,000 to $20,000 of the Term Loan in March 2016. As a
 result of the Company’s intentions and considering the
 already scheduled January 2016 payment, $77,375 has been classified
 as short-term debt. This additional annual payment reduces future
 required quarterly scheduled payments. Any other outstanding
 balances under the Term Loan are due at the maturity date of
 May 31, 2021. Borrowings under the Term Loan are subject to
 various financial and operating covenants including maintaining a
 maximum total leverage ratio. Under the occurrence of certain
 events, the U.S. ABL and the Asia ABL are subject to various
 financial and operational covenants, including maintaining minimum
 fixed charge coverage ratios. At December 28, 2015, the
 Company was in compliance with the covenants under the Term Loan,
 the U.S. ABL and the Asia ABL.

[0001193125-16-476374:notes:297]
As of
 December 28, 2015, remaining unamortized debt discount and
 debt issuance costs were $30,242 and $30,921, respectively. The
 debt discount is recorded as a reduction of the Term Loan and is
 amortized over the duration of the Term Loan. The debt issuance
 costs are included in other non-current assets and are amortized to
 interest expense over the duration of the Term Loan and ABL
 Revolving Loans. The debt discount and the debt issuance costs
 related to the Term Loan are amortized into interest expense using
 an effective interest rate of 7.50%. The debt issuance costs
 related to the ABL Revolving Loans are amortized into interest
 expense using the straight line method of amortization over the
 duration of the ABL Revolving Loans. At December 28, 2015, the
 remaining amortization period for the unamortized debt discount and
 debt issuance costs was 5.4 years.

[0001193125-16-476374:notes:298]
The Company is
 required to pay a commitment fee of 0.375% per annum on any
 unused portion of the U.S. ABL or Asia ABL. The U.S. ABL commitment
 fee may vary from 0.25% to 0.375% based on utilization levels.
 Additionally, the Company also paid commitment fees of
 0.5% per annum on the unused portion of the $90,000 senior
 secured revolving loan associated with the terminated 2012 credit
 agreement for the years ended December 28,
 2015, December 29, 2014 and December 30, 2013. The
 Company incurred total commitment fees related to unused borrowing
 availability of $763, $600, and $442 for the years ended
 December 28, 2015, December 29, 2014 and
 December 30, 2013, respectively. As of December 28, 2015,
 the outstanding amount of the Term Loan was $947,625, of which
 $77,375 the Company expects to repay within one year and is
 included as short-term debt, with the remaining $870,250 included
 as long-term debt. Additionally, $80,000 of the U.S. ABL and none
 of the Asia ABL was outstanding as of December 28, 2015.
 Available borrowing capacity under the U.S. ABL and Asia ABL was
 $65,444 and $142,018, which considers letters of credit outstanding
 of $4,556 and $7,982 mentioned below, respectively, at
 December 28, 2015.

[0001193125-16-476374:notes:299]
Convertible Senior Notes

[0001193125-16-476374:notes:300]
Convertible
 Senior Notes due 2020

[0001193125-16-476374:notes:301]
The Company
 issued 1.75% convertible senior notes due December 15, 2020,
 in a public offering for an aggregate principal amount of $250,000
 in 2013. The convertible senior notes bear interest at a rate of
 1.75% per annum. Interest is payable semiannually in arrears
 on June 15 and December 15 of each year. The convertible
 senior notes are senior unsecured obligations and rank equally to
 the Company’s future unsecured senior indebtedness and are
 senior in right of payment to any of the Company’s future
 subordinated indebtedness.

[0001193125-16-476374:notes:302]
Conversion:    At any time
 prior to March 15, 2020, holders may convert their convertible
 senior notes into cash and, if applicable, into shares of the
 Company’s common stock based on a conversion rate of 103.7613
 shares of the Company’s common stock per $1 principal amount
 of convertible senior notes, subject to adjustment, under the
 following circumstances: (1) during any calendar quarter
 beginning after March 31, 2014 (and only during such calendar
 quarter), if the last reported sale price of our common stock for
 at least 20 trading days during the 30 consecutive trading days
 ending on the last trading day of the immediately preceding
 calendar quarter is greater than or equal to 130% of the applicable
 conversion price on each applicable trading day of such preceding
 calendar quarter; (2) during the five business day period
 after any 10 consecutive trading day period in which the trading
 price per note for each day of that 10 consecutive trading day
 period was less than 98% of the product of the last reported sale
 price of the Company’s common stock and the conversion rate
 on such day; or (3) upon the occurrence of specified corporate
 transactions described in the indenture governing the notes. As of
 December 28, 2015, none of the conversion criteria had been
 met.

[0001193125-16-476374:notes:303]
On or after
 March 15, 2020 until the close of business on the third
 scheduled trading day preceding the maturity date, holders may
 convert their notes at any time, regardless of the foregoing
 circumstances. Upon conversion, for each $1 principal amount of
 notes, the Company will pay shares of our common stock, cash or a
 combination of cash and shares of our common stock at its election,
 if applicable, based on a daily conversion value calculated on a
 proportionate basis for each day of the 80 trading day observation
 period. All conversions occurring on the same date or on or after
 March 15, 2020 shall be settled using the same settlement
 method. Additionally, in the event of a fundamental change as
 defined in the indenture governing the notes, or other conversion
 rate adjustments such as share splits or combinations, other
 distributions of shares, cash or other assets to stockholders,
 including self-tender transactions (Other Conversion Rate
 Adjustments), the conversion rate may be modified to adjust the
 number of shares per $1 principal amount of the notes. As of
 December 28, 2015, none of the criteria for a fundamental
 change or a conversion rate adjustment had been met.

[0001193125-16-476374:notes:304]
The maximum
 number of shares issuable upon conversion, including the effect of
 a fundamental change and subject to Other Conversion Rate
 Adjustments, would be 32,425.

[0001193125-16-476374:notes:305]
Note
 Repurchase:    The Company is not
 permitted to redeem the convertible senior notes at any time prior
 to maturity. In the event of a fundamental change or certain
 default events, as defined in the indenture governing the notes,
 holders may require the Company to repurchase for cash all or a
 portion of their convertible senior notes at a price equal to 100%
 of the principal amount, plus any accrued and unpaid
 interest.

[0001193125-16-476374:notes:306]
Convertible Note Hedge and Warrant
 Transaction:    In connection with the
 issuance of the convertible senior notes due 2020, the Company
 entered into a convertible note hedge and warrant transaction (Call
 Spread Transaction), with respect to the Company’s common
 stock. The convertible note hedge consists of the Company’s
 option to purchase up to 25,940 common stock shares at a price of
 $9.64 per share. The hedge expires on December 15, 2020 and
 can only be executed upon the conversion of the above mentioned
 convertible senior notes due 2020. Additionally, the Company sold
 warrants to purchase 25,940 shares of its common stock at a price
 of $14.26 per share. The warrants expire ratably from March 2021
 through January 2022. The 2020 Call Spread Transaction has no
 effect on the terms of the convertible senior notes due 2020 and
 reduces potential dilution by effectively increasing the conversion
 price of the convertible senior notes due 2020 to $14.26 per share
 of the Company’s common stock.

[0001193125-16-476374:notes:307]
Convertible
 Senior Notes due 2015

[0001193125-16-476374:notes:308]
The Company
 issued 3.25% convertible senior notes due on May 15, 2015, in
 a public offering for an aggregate principal amount of $175,000.
 During the year ended, 2015, the outstanding principal of $32,395
 plus accrued interest was paid in full.

[0001193125-16-476374:notes:309]
As of
 December 28, 2015 and December 29, 2014, the following
 summarizes the equity components of the convertible senior
 notes:

[0001193125-16-476374:notes:310]
|  |  | As of December 28, 2015 |  |  | As of December 29, 2014 |  |
|  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |  | Embedded conversion option — Convertible Senior Notes |  |  | Embedded conversion option — Convertible Senior Notes Issuance Costs |  |  | Total |  |
|  |  | (in thousands) |  |
| Equity components: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Additional paid-in capital: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible senior notes due 2020 |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |
| Convertible senior notes due 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 39,781 |  |  |  | (1,413 | ) |  |  | 38,368 |  |
| Total |  | $ | 60,227 |  |  | $ | (1,916 | ) |  | $ | 58,311 |  |  | $ | 100,008 |  |  | $ | (3,329 | ) |  | $ | 96,679 |  |

[0001193125-16-476374:notes:311]
The components
 of interest expense resulting from the convertible senior notes for
 the years ended December 28, 2015, December 29, 2014
 and December 30, 2013 were as follows:

[0001193125-16-476374:notes:312]
|  |  | For the Year Ended |  |
|  |  | December 28, 2015 |  |  | December 29 2014 |  |  | December 30, 2013 |  |
|  |  | (In thousands) |  |
| Contractual coupon interest |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 4,375 |  |  | $ | 4,367 |  |  | $ | 107 |  |
| Convertible Senior Notes due 2015 |  |  | 395 |  |  |  | 1,053 |  |  |  | 5,559 |  |
|  |  | $ | 4,770 |  |  | $ | 5,420 |  |  | $ | 5,666 |  |
| Amortization of debt discount |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 7,532 |  |  | $ | 7,102 |  |  | $ | 167 |  |
| Convertible Senior Notes due 2015 |  |  | 554 |  |  |  | 1,395 |  |  |  | 6,780 |  |
|  |  | $ | 8,086 |  |  | $ | 8,497 |  |  | $ | 6,947 |  |
| Amortization of debt issuance costs |  |  |  |  |  |  |  |  |  |  |  |  |
| Convertible Senior Notes due 2020 |  | $ | 755 |  |  | $ | 712 |  |  | $ | 16 |  |
| Convertible Senior Notes due 2015 |  |  | 56 |  |  |  | 141 |  |  |  | 684 |  |
|  |  | $ | 811 |  |  | $ | 853 |  |  | $ | 700 |  |

[0001193125-16-476374:notes:313]
As of
 December 28, 2015 and December 29, 2014, remaining
 unamortized debt issuance costs included in other non-current
 assets were $4,552 and $5,363, respectively. The debt issuance
 costs and debt discount are being amortized to interest expense
 over the term of the convertible senior notes using the effective
 interest rate method. At December 28, 2015, the remaining
 weighted average amortization period for the unamortized senior
 convertible note discount and debt issuance costs was 5.0
 years.

[0001193125-16-476374:notes:314]
For the years
 ended December 28, 2015, December 29, 2014 and
 December 30, 2013, the amortization of the convertible senior
 notes due 2015 debt discount and debt issuance costs is based on an
 effective interest rate of 8.37%. For the years ended
 December 28, 2015, December 29, 2014 and
 December 30, 2013, the amortization of the convertible senior
 notes due 2020 debt discount and debt issuance costs is based on an
 effective interest rate of 6.48%.

[0001193125-16-476374:notes:315]
Loss on
 Extinguishment of Debt

[0001193125-16-476374:notes:316]
The Company
 became a party to its current Term Loan and ABL Revolving Loans
 during the year ended 2015 in order to refinance and pay in full
 the remaining outstanding amount of $225,700 under an existing 2012
 credit agreement, as well as to finance the acquisition of
 Viasystems and refinance Viasystems’ outstanding debt. As a
 result, the Company recognized losses of approximately $802 during
 the year ended December 28, 2015 resulting from the write off
 of the remaining unamortized debt issuance costs associated with
 the terminated 2012 credit agreement.

[0001193125-16-476374:notes:317]
Additionally,
 in January 2014 and in December 2013, the Company repurchased
 $6,541 and $136,091, respectively, of its convertible senior notes
 due 2015 both at approximately 103.4% of their principal amounts.
 The repurchases were accounted for as extinguishments of debt and,
 accordingly, the Company recognized losses of approximately $506
 for the year ended December 29, 2014 and $10,743 for the year
 ended December 30, 2013, primarily associated with the premium
 paid to repurchase the convertible senior notes and the recognition
 of related unamortized debt discount and issuance costs.

[0001193125-16-476374:notes:318]
Letters
 of Credit

[0001193125-16-476374:notes:319]
The Company has
 up to $75,000 and $100,000 Letters of Credit Facilities under the
 U.S. ABL and the Asia ABL, respectively, as mentioned above. As of
 December 28, 2015, letters of credit in the amount of $4,556
 were outstanding under the U.S. ABL and $7,982 were outstanding
 under the Asia ABL. The Company has other standby letters of credit
 outstanding in the amount of $2,894 which expire by April 2016.
 These other standby letters of credit are securitized by cash
 collateral. As such, the Company has recorded such cash as
 restricted on the consolidated balance sheet as of
 December 28, 2015. There were no such arrangements at
 December 29, 2014.

[0001193125-16-476374:notes:320]
Other
 Credit Facility

[0001193125-16-476374:notes:321]
Additionally,
 the Company is party to a revolving loan credit facility (Chinese
 Revolver) with a lender in China. Under this arrangement, the
 lender has made available to the Company approximately $35,500 in
 unsecured borrowing with all terms of the borrowing to be
 negotiated at the time the Chinese Revolver is drawn upon. There
 are no commitment fees on the unused portion of the Chinese
 Revolver, and this arrangement expires in December 2016. As of
 December 28, 2015, the Chinese Revolver had not been drawn
 upon.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-16-476374:notes:322]
| (10) | Financial Instruments |

[0001193125-16-476374:notes:323]
Derivatives

[0001193125-16-476374:notes:324]
The Company
 enters into foreign currency forward contracts to mitigate the
 impact of changes in foreign currency exchange rates and to reduce
 the volatility of purchases of equipment generated in currencies
 other than the functional currencies. The Company’s foreign
 subsidiaries may at times purchase forward exchange contracts to
 manage its foreign currency risks in relation to certain purchases
 of machinery denominated in foreign currencies other than the
 Company’s foreign functional currency. The notional amount of
 the foreign exchange contracts as of December 28, 2015 and
 December 29, 2014 was approximately $1,614 and $29,142,
 respectively. The Company has designated certain of these foreign
 exchange contracts as cash flow hedges.

[0001193125-16-476374:notes:325]
The Company
 expects that approximately $172 of the accumulated other
 comprehensive income will be reclassified into the statement of
 operations, net of tax, in the next 12 months.

[0001193125-16-476374:notes:326]
The Company had
 entered into a two-year pay-fixed, receive floating (1-month
 LIBOR), amortizing interest rate swap arrangement with an initial
 notional amount of $146,500, which expired during the year ended
 December 30, 2013. For the year ended 2013, the Company did
 not designate this interest rate swap as a cash flow hedge as the
 borrowings attributable to this interest rate swap were paid in
 full. The change in the fair value of this interest rate swap
 during the year ended December 30, 2013 was recorded as other,
 net in the consolidated statement of operations.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001193125-16-476374:notes:327]
| (5) | Composition of Certain Consolidated Financial Statement Captions |

[0001193125-16-476374:notes:328]
|  |  | As of |  |
|  |  | December 28, 2015 |  |  | December 29, 2014 |  |
|  |  | (In thousands) |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 70,577 |  |  | $ | 44,477 |  |
| Work-in-process |  |  | 97,193 |  |  |  | 57,544 |  |
| Finished goods |  |  | 101,153 |  |  |  | 43,166 |  |
|  |  | $ | 268,923 |  |  | $ | 145,187 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |  |  |
| Land and land use rights |  | $ | 91,571 |  |  | $ | 31,093 |  |
| Buildings and improvements |  |  | 446,763 |  |  |  | 247,404 |  |
| Machinery and equipment |  |  | 1,058,565 |  |  |  | 854,829 |  |
| Construction-in-progress, furniture and fixtures and other |  |  | 39,550 |  |  |  | 43,527 |  |
|  |  |  | 1,636,449 |  |  |  | 1,176,853 |  |
| Less: Accumulated depreciation |  |  | (533,382 | ) |  |  | (422,135 | ) |
|  |  | $ | 1,103,067 |  |  | $ | 754,718 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |  |
| Interest |  | $ | 14,473 |  |  | $ | 581 |  |
| Equipment payable |  |  | 14,251 |  |  |  | 47,212 |  |
| Other |  |  | 73,024 |  |  |  | 41,401 |  |
|  |  | $ | 101,748 |  |  | $ | 89,194 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-16-476374:notes:329]
| (16) | Employee Benefit and Deferred Compensation Plans |

[0001193125-16-476374:notes:330]
The Company has
 four separate retirement benefit plans: two in North America (one
 of which was acquired from Viasystems during 2015), and two in Asia
 Pacific. In North America, the Company has two 401(k) savings plans
 (the Savings Plans) in which eligible full-time domestic employees
 can participate and contribute a percentage of compensation subject
 to the maximum allowed by the Internal Revenue Service. The Savings
 Plans provides for a partial match by the employer of the first 5%
 of employee contributions (100% of the first 3% and 50% of the
 following 2% of employee contributions for one plan and 50% of the
 first 6% of employee contributions for plan acquired from
 Viasystems). In Asia Pacific, the Company contributes to either
 separate trust-administered funds or various government-sponsored
 pension plans on a mandatory basis. For all retirement plans, the
 Company has no further payment obligation once the required
 contributions have been made. The Company recorded contributions to
 retirement benefit plans of $35,427, $18,953 and $14,987 during the
 years ended December 28, 2015, December 29, 2014 and
 December 30, 2013, respectively.

[0001193125-16-476374:notes:331]
The Company also
 maintains a deferred compensation plan (the Compensation Plan). The
 Compensation Plan is an unfunded, nonqualified deferred
 compensation plan and is limited to selected employees, including
 our named executive officers and our directors. The Compensation
 Plan allows participants to defer up to 100% of their annual bonus
 and between 5% and 100% of their annual director fees. Amounts
 deferred under the Compensation Plan will be credited to accounts
 maintained by the Company for each participant and will be credited
 or debited with the participant’s proportionate share of any
 gains or losses attributable to the performance of investment
 options selected by the participant.


## ttmi:DistributionOfProfitsDisclosureTextBlock

[0001193125-16-476374:notes:332]
| (18) | Distribution of profits |

[0001193125-16-476374:notes:333]
As stipulated by
 the relevant laws and regulations of China applicable to the
 Company’s subsidiaries in China, each of such subsidiaries is
 required to make appropriations from its net income as determined
 in accordance with accounting principles and the relevant financial
 regulations of China (PRC GAAP) to a non-distributable reserve,
 also referred to as statutory surplus reserve. The appropriations
 to the statutory surplus reserve are required to be made at not
 less than 10% of the profit after tax as determined under PRC GAAP
 and are required until the balance reaches 50% of its registered
 capital. The statutory surplus reserve is used to offset future or
 past losses. These Chinese subsidiaries may, upon a resolution
 passed by their respective shareholders, convert the statutory
 surplus reserve into capital.

[0001193125-16-476374:notes:334]
There were
 appropriations of approximately $4,576, $2,544 and $3,526 to the
 statutory surplus reserve of the Company’s Chinese
 subsidiaries for the years ended December 28,
 2015, December 29, 2014 and December 30, 2013,
 respectively.
