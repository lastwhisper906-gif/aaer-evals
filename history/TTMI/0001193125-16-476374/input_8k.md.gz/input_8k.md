# TTMI 8-K — 0001171843-16-007659 filed 2016-02-04

## item codes, every 8-K on or before 2016-02-25

- 2016-02-09 0001193125-16-454281 — 8.01, 9.01
- 2016-02-04 0001171843-16-007659 — 2.02, 9.01
- 2016-01-04 0001193125-16-418740 — 1.01, 9.01
- 2015-12-11 0001193125-15-400867 — 5.02, 9.01
- 2015-10-30 0001171843-15-005835 — 2.02, 7.01 — amendment of 0001171843-15-005766
- 2015-10-28 0001171843-15-005766 — 2.02, 9.01
- 2015-09-29 0001193125-15-331517 — 2.02, 2.05, 2.06, 9.01
- 2015-08-05 0001171843-15-004361 — 2.02, 9.01
- 2015-07-31 0001193125-15-272962 — 9.01 — amendment of 0001193125-15-210734
- 2015-06-02 0001193125-15-210734 — 1.01, 1.02, 2.01, 2.03, 7.01, 9.01
- 2015-05-29 0001193125-15-206622 — 1.01, 2.03, 9.01
- 2015-05-20 0001171843-15-002975 — 7.01, 9.01
- 2015-05-19 0001193125-15-193434 — 5.07, 9.01
- 2015-05-05 0001171843-15-002499 — 7.01, 9.01
- 2015-04-29 0001171843-15-002307 — 2.02, 9.01
- 2015-04-21 0001193125-15-139239 — 7.01, 9.01
- 2015-04-21 0001171843-15-002065 — 2.02, 9.01
- 2015-02-04 0001171843-15-000599 — 2.02, 9.01
- 2015-01-20 0001193125-15-014019 — 7.01, 9.01
- 2014-12-30 0001193125-14-457111 — 7.01, 9.01
- 2014-12-15 0001193125-14-442645 — 1.01, 9.01
- 2014-12-04 0001193125-14-433658 — 8.01, 9.01
- 2014-11-18 0001193125-14-415889 — 7.01, 9.01
- 2014-10-29 0001171843-14-005051 — 2.02, 9.01
- 2014-10-27 0001193125-14-383428 — 1.01, 9.01
- 2014-09-22 0001193125-14-348697 — 1.01, 7.01, 9.01
- 2014-08-05 0001193125-14-295808 — 1.01, 5.02, 9.01
- 2014-07-30 0001171843-14-003548 — 2.02, 9.01
- 2014-04-30 0001171843-14-002017 — 2.02, 9.01
- 2014-04-25 0001193125-14-160146 — 5.02, 5.07, 9.01
- 2014-04-10 0001171843-14-001656 — 2.02, 9.01
- 2014-03-04 0001193125-14-082534 — 4.01, 9.01
- 2014-02-05 0001171843-14-000553 — 2.02, 9.01
- 2014-01-14 0001193125-14-010922 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2013-12-27 0001193125-13-486144 — 5.02, 9.01
- 2013-12-20 0001193125-13-481141 — 1.01, 1.02, 2.03, 3.02, 8.01, 9.01
- 2013-12-17 0001193125-13-476207 — 5.03
- 2013-10-30 0001193125-13-418572 — 2.02, 5.02, 9.01
- 2013-09-12 0001193125-13-365420 — 2.05
- 2013-08-14 0001193125-13-334349 — 7.01, 9.01
- 2013-08-01 0001171843-13-003138 — 2.02, 9.01
- 2013-06-25 0001193125-13-270725 — 5.02, 9.01
- 2013-05-02 0001171843-13-001746 — 2.02, 9.01
- 2013-04-29 0001193125-13-182083 — 5.02, 5.07, 9.01
- 2013-03-18 0001193125-13-111308 — 1.01, 7.01, 9.01
- 2013-03-06 0001193125-13-093625 — 5.02, 9.01
- 2013-03-01 0001193125-13-087439 — 2.02 — amendment of 0001171843-13-000414
- 2013-02-28 0001193125-13-084764 — 5.02
- 2013-02-05 0001171843-13-000414 — 2.02, 9.01
- 2013-01-31 0001193125-13-032848 — 5.02, 9.01
- 2013-01-17 0001193125-13-015928 — 7.01, 9.01
- 2013-01-16 0001193125-13-014581 — 2.02, 9.01
- 2012-12-11 0001193125-12-498644 — 5.02, 9.01
- 2012-11-15 0001193125-12-472451 — 7.01, 9.01
- 2012-11-01 0001171843-12-003890 — 2.02, 9.01
- 2012-09-19 0001193125-12-396969 — 1.01, 2.03, 7.01, 9.01
- 2012-09-11 0001193125-12-388130 — 7.01, 9.01
- 2012-07-31 0001171843-12-002829 — 2.02, 9.01
- 2012-05-15 0001193125-12-233501 — 7.01, 9.01
- 2012-05-01 0001171843-12-001574 — 2.02, 9.01
- 2012-04-27 0001193125-12-191623 — 5.07
- 2012-03-01 0001193125-12-090623 — 2.02 — amendment of 0001171843-12-000382
- 2012-02-07 0001171843-12-000382 — 2.02, 9.01
- 2012-01-19 0001193125-12-016588 — 5.02, 9.01
- 2011-11-15 0000950123-11-098812 — 7.01, 9.01
- 2011-11-02 0001171843-11-003248 — 2.02, 9.01
- 2011-09-28 0000950123-11-087344 — 7.01, 9.01
- 2011-09-19 0000950123-11-085128 — 5.02, 9.01
- 2011-09-15 0000950123-11-084704 — 5.07 — amendment of 0000950123-11-054296
- 2011-08-04 0001171843-11-002356 — 2.02, 9.01
- 2011-07-27 0000950123-11-068987 — 1.01, 2.03, 9.01
- 2011-06-21 0000950123-11-060477 — 7.01, 9.01
- 2011-06-06 0000950123-11-056971 — 5.03, 9.01
- 2011-05-26 0000950123-11-054296 — 5.07
- 2011-05-10 0000950123-11-048462 — 8.01, 9.01
- 2011-05-05 0001171843-11-001344 — 2.02, 9.01
- 2011-03-22 0000950123-11-027824 — 7.01, 9.01
- 2011-03-18 0000950123-11-026913 — 4.01
- 2011-03-18 0000950123-11-026910 — 4.01, 9.01 — amendment, the index does not say of what
- 2011-03-02 0000950123-11-020941 — 5.03, 9.01
- 2011-02-10 0001171843-11-000391 — 2.02, 9.01
- 2011-01-13 0000950123-11-002528 — 7.01, 9.01
- 2011-01-13 0000950123-11-002446 — 2.02, 9.01
- 2010-11-29 0000950123-10-109448 — 4.01, 9.01 — amendment, the index does not say of what
- 2010-11-17 0000950123-10-106706 — 4.01
- 2010-11-15 0000950123-10-105479 — 5.02, 9.01
- 2010-11-04 0001171843-10-002324 — 2.02, 9.01
- 2010-10-22 0000950123-10-095179 — 1.01, 9.01
- 2010-10-04 0000950123-10-090949 — 1.01, 5.03, 9.01
- 2010-08-05 0001171843-10-001587 — 2.02, 9.01
- 2010-08-05 0000950123-10-073258 — 1.01, 2.03, 9.01
- 2010-08-05 0000950123-10-073256 — 9.01 — amendment of 0000950123-10-034163
- 2010-07-12 0000950123-10-064794 — 5.02, 8.01, 9.01
- 2010-06-10 0000950123-10-057166 — 7.01, 9.01
- 2010-06-02 0000950123-10-055111 — 1.01, 5.07, 9.01
- 2010-05-06 0001171843-10-000819 — 2.02, 9.01
- 2010-04-26 0000950123-10-037806 — 8.01, 9.01 — amendment of 0000950123-10-034163
- 2010-04-13 0000950123-10-034163 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2010-03-30 0000950123-10-030123 — 1.01, 5.02, 9.01
- 2010-03-24 0000950123-10-027317 — 1.01, 5.02, 9.01
- 2010-03-16 0000950123-10-024853 — 7.01, 9.01 — amendment of 0001171843-10-000140
- 2010-03-15 0000950123-10-024637 — 5.07
- 2010-02-04 0001171843-10-000140 — 2.02, 9.01
- 2010-02-02 0000950123-10-007780 — 8.01, 9.01
- 2010-01-13 0000950123-10-002245 — 7.01, 9.01
- 2009-12-23 0000950123-09-073069 — 1.01, 9.01
- 2009-12-15 0000950123-09-070868 — 8.01, 9.01
- 2009-11-16 0000950123-09-062630 — 1.01, 7.01, 9.01
- 2009-11-04 0001171843-09-001103 — 2.02, 9.01
- 2009-09-04 0000950123-09-041133 — 2.05, 9.01
- 2009-07-29 0001171843-09-000743 — 2.02, 9.01
- 2009-06-09 0000950123-09-012507 — 7.01, 9.01
- 2009-04-30 0001171843-09-000427 — 2.02, 9.01
- 2009-04-28 0001362310-09-005960 — 8.01
- 2009-02-19 0001362310-09-002454 — 5.03, 9.01
- 2009-02-10 0001171843-09-000123 — 2.02, 9.01
- 2009-01-16 0000950153-09-000040 — 2.05, 9.01
- 2009-01-08 0000950153-09-000023 — 7.01, 9.01
- 2008-10-29 0001157523-08-008533 — 2.02, 9.01
- 2008-07-29 0001157523-08-005998 — 2.02, 9.01
- 2008-05-22 0000950153-08-001035 — 1.01, 2.03, 3.02, 9.01
- 2008-05-22 0000950153-08-001034 — 7.01, 9.01
- 2008-05-15 0000950153-08-000987 — 1.01, 1.02, 2.03, 3.02, 9.01
- 2008-04-30 0001157523-08-003483 — 2.02, 9.01
- 2008-02-07 0001157523-08-001077 — 2.02, 9.01
- 2008-01-08 0000950153-08-000033 — 7.01, 9.01
- 2007-11-15 0000950153-07-002440 — 7.01, 9.01
- 2007-11-14 0000950153-07-002426 — 7.01, 9.01
- 2007-11-14 0000950153-07-002421 — 5.03, 9.01
- 2007-10-31 0001157523-07-010491 — 2.02, 9.01
- 2007-10-02 0000950153-07-002094 — 7.01, 9.01
- 2007-07-31 0000950153-07-001622 — 2.02, 9.01
- 2007-06-13 0000950153-07-001327 — 7.01, 9.01
- 2007-05-02 0000950153-07-000941 — 2.02, 9.01
- 2007-04-12 0000950153-07-000763 — 5.02, 9.01
- 2007-02-15 0000950153-07-000339 — 2.02, 9.01
- 2007-01-11 0000950153-07-000076 — 7.01, 9.01
- 2007-01-10 0000950153-07-000071 — 2.01, 9.01 — amendment, the index does not say of what
- 2006-12-11 0000950153-06-002967 — 2.05, 9.01
- 2006-11-15 0000950153-06-002843 — 7.01, 9.01
- 2006-11-14 0000950153-06-002837 — 7.01, 9.01
- 2006-11-02 0000950153-06-002682 — 1.01, 1.02, 2.03, 9.01
- 2006-11-01 0000950153-06-002668 — 2.02, 9.01
- 2006-10-30 0000950124-06-006210 — 2.01, 9.01
- 2006-08-04 0000950153-06-002025 — 1.01, 9.01
- 2006-07-26 0000950153-06-001937 — 2.02, 9.01
- 2006-06-28 0000950153-06-001716 — 1.01, 9.01
- 2006-06-13 0000950153-06-001597 — 7.01, 9.01
- 2006-04-26 0000950153-06-001079 — 2.02, 9.01
- 2006-02-08 0001104659-06-006985 — 2.02, 9.01
- 2006-01-12 0001104659-06-001893 — 7.01, 9.01
- 2005-12-05 0001104659-05-058918 — 1.01, 5.02, 9.01
- 2005-10-26 0001104659-05-050306 — 2.02, 9.01
- 2005-09-20 0001104659-05-044954 — 8.01
- 2005-08-30 0001104659-05-042053 — 3.03, 8.01, 9.01
- 2005-07-27 0001104659-05-034437 — 2.02, 5.02, 9.01
- 2005-07-21 0001104659-05-033462 — 1.01, 1.02, 2.03, 9.01
- 2005-06-13 0001104659-05-027969 — 8.01
- 2005-06-08 0001104659-05-027364 — 7.01, 9.01
- 2005-05-17 0001104659-05-024118 — 7.01, 9.01
- 2005-05-12 0001104659-05-022993 — 7.01, 9.01
- 2005-05-11 0001104659-05-022606 — 1.01, 9.01
- 2005-05-02 0001104659-05-019649 — 2.02, 5.02, 9.01
- 2005-04-26 0001104659-05-018233 — 7.01, 9.01
- 2005-02-08 0001104659-05-004642 — 2.02, 9.01
- 2005-01-12 0001104659-05-001194 — 7.01, 9.01
- 2004-12-22 0001104659-04-040933 — 5.02
- 2004-12-08 0001104659-04-038850 — 7.01, 9.01
- 2004-10-26 0001104659-04-031931 — 2.02, 9.01
- 2004-10-01 0001104659-04-029361 — 5.02
- 2004-08-02 0001104659-04-021785 — 9
- 2004-07-29 0001104659-04-021529 — 12
- 2004-05-06 0001104659-04-012742 — 9
- 2004-04-26 0001104659-04-011228 — 12
- 2004-02-03 0001104659-04-002424 — 9
- 2004-01-28 0001104659-04-001980 — 12
- 2004-01-09 0001104659-04-000457 — 9
- 2003-10-21 0001104659-03-023304 — 12
- 2003-07-29 0001104659-03-015999 — 12
- 2003-05-08 0001104659-03-008647 — 9
- 2003-05-08 0001104659-03-008462 — 9
- 2003-05-01 0001104659-03-007866 — 9
- 2003-03-07 0001104659-03-003816 — 2, 7 — amendment of 0000950153-02-002190
- 2002-12-27 0000950153-02-002190 — 2, 7
- 2002-05-17 0000912057-02-021145 — 4, 7
- 2001-12-21 0000912057-01-544281 — 7
- 2000-10-27 0000912057-00-046109 — 5

## late-filing notifications on or before 2016-02-25

- none on or before 2016-02-25

## item 2.02 — earnings release, exhibit 99.1

[0001171843-16-007659:8k_2_02:1]
EX-99.1
2
exh_991.htm
PRESS RELEASE

[0001171843-16-007659:8k_2_02:2]
EdgarFiling
EXHIBIT 99.1

[0001171843-16-007659:8k_2_02:3]
TTM Technologies, Inc. Reports Fourth Quarter and Fiscal Year 2015 Results

[0001171843-16-007659:8k_2_02:4]
COSTA MESA, Calif., Feb.  04, 2016  (GLOBE NEWSWIRE) -- TTM Technologies, Inc. (Nasdaq:TTMI), a leading global printed circuit board (“PCB”) manufacturer, today reported results for the fourth quarter and fiscal year 2015, which ended December 28, 2015.  Our results include the contribution from the Viasystems Group, Inc. ("Viasystems") acquisition, which was completed on May 31, 2015.

[0001171843-16-007659:8k_2_02:5]
Fourth Quarter 2015 Highlights

[0001171843-16-007659:8k_2_02:6]
Net sales were $668.9 million

[0001171843-16-007659:8k_2_02:7]
GAAP net income attributable to stockholders was $9.5 million, or $0.09 per diluted share

[0001171843-16-007659:8k_2_02:8]
Non-GAAP net income attributable to stockholders was $31.5 million, or $0.31 per diluted share

[0001171843-16-007659:8k_2_02:9]
Adjusted EBITDA was $95.8 million

[0001171843-16-007659:8k_2_02:10]
Free cash flow was $118.4 million

[0001171843-16-007659:8k_2_02:11]
Fiscal Year 2015 Highlights

[0001171843-16-007659:8k_2_02:12]
Net sales were $2.1 billion

[0001171843-16-007659:8k_2_02:13]
GAAP net loss attributable to stockholders was $25.9 million, or $0.28 per share

[0001171843-16-007659:8k_2_02:14]
Non-GAAP net income attributable to stockholders was $81.1 million, or $0.87 per diluted share

[0001171843-16-007659:8k_2_02:15]
Adjusted EBITDA was $285.7 million

[0001171843-16-007659:8k_2_02:16]
Free cash flow was $182.7 million

[0001171843-16-007659:8k_2_02:17]
Fourth Quarter 2015 Financial Results

[0001171843-16-007659:8k_2_02:18]
Net sales for the fourth quarter of 2015 were $668.9 million compared to $652.0 million in the third quarter of 2015 and $390.9 million in the fourth quarter of 2014.

[0001171843-16-007659:8k_2_02:19]
GAAP operating income for the fourth quarter of 2015 was $36.5 million compared to operating income of $23.6 million in the third quarter of 2015 and operating income of $26.6 million in the fourth quarter of 2014.

[0001171843-16-007659:8k_2_02:20]
GAAP net income attributable to stockholders for the fourth quarter of 2015 was $9.5 million, or $0.09 per diluted share.  This compares to GAAP net loss attributable to stockholders of $2.2 million, or $0.02 per share, in the third quarter of 2015 and GAAP net income of $13.9 million, or $0.17 per diluted share, in the fourth quarter of 2014.

[0001171843-16-007659:8k_2_02:21]
On a non-GAAP basis, net income attributable to stockholders for the fourth quarter of 2015 was $31.5 million, or $0.31 per diluted share.  This compares to non-GAAP net income of $23.8 million, or $0.24 per diluted share, for the third quarter of 2015 and $23.2 million, or $0.28 per diluted share, for the fourth quarter of 2014.

[0001171843-16-007659:8k_2_02:22]
Adjusted EBITDA for the fourth quarter of 2015 was $95.8 million, or 14.3 percent of net sales, compared to adjusted EBITDA of $87.6 million, or 13.4 percent of net sales, for the third quarter of 2015 and $60.5 million, or 15.5 percent of net sales, for the fourth quarter of 2014.

[0001171843-16-007659:8k_2_02:23]
“Our solid fourth quarter execution combined with seasonal growth in the cellular phone end market and robust demand in the automotive and aerospace and defense end markets drove our sequential increases in gross margin, operating profit and strong free cash flow generation,” said Tom Edman, CEO of TTM.  “We are pleased to report non-GAAP earnings above the high end of our guidance range and revenue in line with expectations.  In addition, we generated $118 million in free cash flow during the quarter which we will use to repay $70-80 million of principal on our term loan late in the first quarter.”

[0001171843-16-007659:8k_2_02:24]
Full Year 2015 Financial Results

[0001171843-16-007659:8k_2_02:25]
Net sales for fiscal year 2015 increased to $2.1 billion from $1.3 billion in fiscal year 2014.

[0001171843-16-007659:8k_2_02:26]
GAAP operating income for fiscal year 2015 was $61.3 million, an increase from GAAP operating income of $46.5 million in fiscal year 2014.

[0001171843-16-007659:8k_2_02:27]
GAAP net loss attributable to stockholders for fiscal year 2015 was $25.9 million, or $0.28 per share, compared to GAAP net income of $14.7 million, or $0.18 per diluted share, for fiscal year 2014.  The GAAP results were negatively impacted by approximately $59.4 million of expenses related to the acquisition and integration of Viasystems.

[0001171843-16-007659:8k_2_02:28]
On a non-GAAP basis, net income attributable to stockholders for fiscal year 2015 was $81.1 million, or $0.87 per diluted share.  This compares to fiscal year 2014 non-GAAP net income of $39.3 million, or $0.47 per diluted share.

[0001171843-16-007659:8k_2_02:29]
Adjusted EBITDA for fiscal year 2015 was $285.7 million, or 13.6 percent of net sales, compared to $166.0 million, or 12.5 percent of net sales, for fiscal year 2014.

[0001171843-16-007659:8k_2_02:30]
“2015 was a transformational year for our company that culminated in the creation of one of today’s leading global PCB manufacturers with increased customer and end market diversity.  We delivered on our integration initiatives and exited the year having achieved 80% of our $55 million annualized synergy target,” continued Edman.

[0001171843-16-007659:8k_2_02:31]
“We expect our leadership in a diverse set of end markets to pay-off in the first quarter of 2016 as anticipated strength in automotive and aerospace and defense markets will help to mitigate a seasonal downturn in the cellular phone market. We will continue to build on these strengths as we leverage TTM’s advanced technology position into the automotive market in particular.”

[0001171843-16-007659:8k_2_02:32]
Business Outlook

[0001171843-16-007659:8k_2_02:33]
For the first quarter of 2016, TTM estimates that revenue will be in the range of $570 million to $610 million, and non-GAAP net income will be in the range of $0.05 to $0.11 per diluted share.

[0001171843-16-007659:8k_2_02:34]
To Access the Live Webcast/Conference Call

[0001171843-16-007659:8k_2_02:35]
TTM will host a conference call and webcast to discuss fourth quarter and fiscal year 2015 results and first quarter 2016 outlook on Thursday, February 4, 2016, at 4:30 p.m. Eastern Time (1:30 p.m. Pacific Time).  The conference call may include forward-looking statements.

[0001171843-16-007659:8k_2_02:36]
Telephone access is available by dialing domestic 888-438-5535 or international 719-457-2648 (ID 4399593).  The conference call also will be webcast on TTM’s website at www.ttm.com.

[0001171843-16-007659:8k_2_02:37]
To Access a Replay of the Webcast

[0001171843-16-007659:8k_2_02:38]
The replay of the webcast will remain accessible for one week following the live event on TTM’s website at www.ttm.com.

[0001171843-16-007659:8k_2_02:39]
About TTM

[0001171843-16-007659:8k_2_02:40]
TTM Technologies, Inc. is a leading global printed circuit board manufacturer, focusing on quick-turn and technologically advanced PCBs, backplane assemblies and electro-mechanical solutions. TTM stands for time-to-market, representing how TTM's time-critical, one-stop manufacturing services enable customers to shorten the time required to develop new products and bring them to market. Additional information can be found at www.ttm.com.

[0001171843-16-007659:8k_2_02:41]
Forward-Looking Statements

[0001171843-16-007659:8k_2_02:42]
This release contains forward-looking statements that relate to future events or performance. TTM cautions you that such statements are simply predictions and actual events or results may differ materially. These statements reflect TTM's current expectations, and TTM does not undertake to update or revise these forward looking statements, even if experience or future changes make it clear that any projected results expressed or implied in this or other TTM statements will not be realized. Further, these statements involve risks and uncertainties, many of which are beyond TTM's control, which could cause actual results to differ materially from the forward-looking statements. These risks and uncertainties include, but are not limited to, the successful integration of Viasystems, including, the planned plant combinations and closure, general market and economic conditions, including interest rates, currency exchange rates and consumer spending, demand for TTM's products, market pressures on prices of TTM's products, warranty claims, changes in product mix, contemplated significant capital expenditures and related financing requirements, TTM's dependence upon a small number of customers and other factors set forth in the "Risk Factors" and "Management's Discussion and Analysis of Financial Condition and Results of Operations" sections of the Company's public reports filed with the SEC.

[0001171843-16-007659:8k_2_02:43]
About Our Non-GAAP Financial Measures

[0001171843-16-007659:8k_2_02:44]
This release includes information about TTM’s adjusted EBITDA, non-GAAP net income and non-GAAP earnings per share, all of which are non-GAAP financial measures. TTM presents non-GAAP financial information to enable investors to see TTM through the eyes of management and to provide better insight into TTM’s ongoing financial performance.

[0001171843-16-007659:8k_2_02:45]
A material limitation associated with the use of the above non-GAAP financial measures is that they have no standardized measurement prescribed by GAAP and may not be comparable to similar non-GAAP financial measures used by other companies.  TTM compensates for these limitations by providing full disclosure of each non-GAAP financial measure and reconciliation to the most directly comparable GAAP financial measure.  However, the non-GAAP financial measures should not be considered in isolation from, or as a substitute for, financial information prepared in accordance with GAAP.

[0001171843-16-007659:8k_2_02:46]
| TTM TECHNOLOGIES, INC. |  |
| Selected Unaudited Financial Information |  |
| (In thousands, except per share data) |  |
|  |  |  |  |  |  | Fourth Quarter |  | Third Quarter |  | Full Year |  |
|  |  |  |  |  |  |  | 2015 |  |  |  | 2014 |  |  |  | 2015 |  |  |  | 2015 |  |  |  | 2014 |  |  |
| CONSOLIDATED CONDENSED STATEMENTS OF OPERATIONS |  |  |  |  |  |  |  |  |  |  |  |
|  | Net sales |  |  | $ | 668,874 |  |  | $ | 390,912 |  |  | $ | 652,005 |  |  | $ | 2,095,488 |  |  | $ | 1,325,717 |  |  |
|  | Cost of goods sold |  |  | 560,604 |  |  |  | 322,437 |  |  |  | 562,887 |  |  |  | 1,785,351 |  |  |  | 1,131,028 |  |  |
|  | Gross profit |  |  | 108,270 |  |  |  | 68,475 |  |  |  | 89,118 |  |  |  | 310,137 |  |  |  | 194,689 |  |  |
|  | Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Selling and marketing |  |  | 17,963 |  |  |  | 9,926 |  |  |  | 17,642 |  |  |  | 57,361 |  |  |  | 36,919 |  |  |
|  |  | General and administrative |  |  | 41,654 |  |  |  | 30,046 |  |  |  | 39,456 |  |  |  | 167,109 |  |  |  | 100,944 |  |  |
|  |  | Amortization of definite-lived intangibles |  |  | 6,683 |  |  |  | 1,935 |  |  |  | 6,421 |  |  |  | 18,888 |  |  |  | 8,387 |  |  |
|  |  | Restructuring charges |  |  | 5,429 |  |  |  | (7 | ) |  |  | 2,003 |  |  |  | 7,941 |  |  |  | 55 |  |  |
|  |  | Impairment of long-lived assets |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1,845 |  |  |
|  |  | Gain on sale of asset |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (2,504 | ) |  |  | - |  |  |
|  |  |  | Total operating expenses |  |  | 71,729 |  |  |  | 41,900 |  |  |  | 65,522 |  |  |  | 248,795 |  |  |  | 148,150 |  |  |
|  | Operating income (loss) |  |  | 36,541 |  |  |  | 26,575 |  |  |  | 23,596 |  |  |  | 61,342 |  |  |  | 46,539 |  |  |
|  | Interest expense |  |  | (20,208 | ) |  |  | (5,691 | ) |  |  | (21,002 | ) |  |  | (59,753 | ) |  |  | (23,830 | ) |  |
|  | Loss on extinguishment of debt |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (802 | ) |  |  | (506 | ) |  |
|  | Other, net |  |  |  | 3,925 |  |  |  | 1,620 |  |  |  | 3,998 |  |  |  | 8,189 |  |  |  | 88 |  |  |
|  | Income (loss) before income taxes |  |  | 20,258 |  |  |  | 22,504 |  |  |  | 6,592 |  |  |  | 8,976 |  |  |  | 22,291 |  |  |
|  | Income tax (provision) benefit |  |  | (10,601 | ) |  |  | (8,566 | ) |  |  | (8,730 | ) |  |  | (34,594 | ) |  |  | (7,598 | ) |  |
|  | Net income (loss) |  | $ | 9,657 |  |  | $ | 13,938 |  |  | $ | (2,138 | ) |  | $ | (25,618 | ) |  | $ | 14,693 |  |  |
|  | Net income attributable to noncontrolling interest |  |  | (136 | ) |  |  | - |  |  |  | (99 | ) |  |  | (264 | ) |  |  | - |  |  |
|  | Net income (loss) attributable to stockholders |  | $ | 9,521 |  |  | $ | 13,938 |  |  | $ | (2,237 | ) |  | $ | (25,882 | ) |  | $ | 14,693 |  |  |
|  | Earnings (loss) per share attributable to stockholders: |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Basic |  |  | $ | 0.10 |  |  | $ | 0.17 |  |  | $ | (0.02 | ) |  | $ | (0.28 | ) |  | $ | 0.18 |  |  |
|  |  | Diluted |  |  | $ | 0.09 |  |  | $ | 0.17 |  |  | $ | (0.02 | ) |  | $ | (0.28 | ) |  | $ | 0.18 |  |  |
|  | Weighted-average shares used in computing per share amounts: |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Basic |  |  |  | 99,134 |  |  |  | 83,345 |  |  |  | 99,128 |  |  |  | 92,675 |  |  |  | 83,238 |  |  |
|  |  | Diluted |  |  |  | 126,329 |  |  |  | 84,205 |  |  |  | 99,128 |  |  |  | 92,675 |  |  |  | 83,941 |  |  |
|  | Reconciliation of the numerator and denominator used to calculate basic earnings per share and diluted earnings per share for the quarter ended Q4 2015 |  |
|  | Net income attributable to stockholders |  | $ | 9,521 |  |  |  |  |  |  |  |  |  |  |
|  |  | Add back items: interest expense, net of tax |  |  | 2,009 |  |  |  |  |  |  |  |  |  |  |
|  | Adjusted net income attributable to stockholders |  | $ | 11,530 |  |  |  |  |  |  |  |  |  |  |
|  | Weighted-average shares outstanding |  |  | 99,134 |  |  |  |  |  |  |  |  |  |  |
|  | Dilutive effect of convertible debt |  |  | 25,940 |  |  |  |  |  |  |  |  |  |  |
|  | Dilutive effect of performance-based stock units, restricted stock units and stock options |  |  | 1,255 |  |  |  |  |  |  |  |  |  |  |
|  | Diluted shares |  |  | 126,329 |  |  |  |  |  |  |  |  |  |  |
|  | Earnings per share attributable to stockholders: |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Basic |  |  | $ | 0.10 |  |  |  |  |  |  |  |  |  |  |
|  |  | Diluted |  |  | $ | 0.09 |  |  |  |  |  |  |  |  |  |  |
| SELECTED BALANCE SHEET DATA |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  | December 28, 2015 |  | December 29, 2014 |  |  |  |  |  |  |  |
|  | Cash and cash equivalents, including restricted cash |  | $ | 262,630 |  |  | $ | 279,042 |  |  |  |  |  |  |  |  |
|  | Accounts and notes receivable, net |  |  | 454,001 |  |  |  | 307,933 |  |  |  |  |  |  |  |  |
|  | Inventories |  |  |  | 268,923 |  |  |  | 145,187 |  |  |  |  |  |  |  |  |
|  | Total current assets |  |  | 1,022,520 |  |  |  | 798,123 |  |  |  |  |  |  |  |  |
|  | Property, plant and equipment, net |  |  | 1,103,067 |  |  |  | 754,718 |  |  |  |  |  |  |  |  |
|  | Other non-current assets |  |  | 545,717 |  |  |  | 48,448 |  |  |  |  |  |  |  |  |
|  | Total assets |  |  | 2,671,304 |  |  |  | 1,601,289 |  |  |  |  |  |  |  |  |
|  | Short-term debt, including current portion of long-term debt |  | $ | 157,375 |  |  | $ | 128,045 |  |  |  |  |  |  |  |  |
|  | Accounts payable |  |  | 347,916 |  |  |  | 217,326 |  |  |  |  |  |  |  |  |
|  | Total current liabilities |  |  | 744,994 |  |  |  | 496,012 |  |  |  |  |  |  |  |  |
|  | Debt, net of discount |  |  | 1,044,582 |  |  |  | 374,642 |  |  |  |  |  |  |  |  |
|  | Total long-term liabilities |  |  | 1,099,641 |  |  |  | 389,813 |  |  |  |  |  |  |  |  |
|  | Total equity |  |  | 826,669 |  |  |  | 715,464 |  |  |  |  |  |  |  |  |
|  | Total liabilities and equity |  |  | 2,671,304 |  |  |  | 1,601,289 |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL DATA |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Fourth Quarter |  | Third Quarter |  | Full Year |  |
|  |  |  |  |  |  |  | 2015 |  |  |  | 2014 |  |  |  | 2015 |  |  |  | 2015 |  |  |  | 2014 |  |  |
|  | Gross margin |  |  | 16.2 | % |  |  | 17.5 | % |  |  | 13.7 | % |  |  | 14.8 | % |  |  | 14.7 | % |  |
|  | Operating margin |  |  | 5.5 | % |  |  | 6.8 | % |  |  | 3.6 | % |  |  | 2.9 | % |  |  | 3.5 | % |  |
|  | End Market Breakdown: |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Fourth Quarter |  | Third Quarter |  |  |  |  |  |
|  |  |  |  |  |  |  | 2015 |  |  |  | 2014 |  |  |  | 2015 |  |  |  |  |  |  |
|  |  | Aerospace/Defense |  |  | 13 | % |  |  | 14 | % |  |  | 14 | % |  |  |  |  |  |
|  |  | Automotive |  |  | 18 | % |  |  | 3 | % |  |  | 17 | % |  |  |  |  |  |
|  |  | Cellular Phone |  |  | 18 | % |  |  | 35 | % |  |  | 16 | % |  |  |  |  |  |
|  |  | Computing/Storage/Peripherals |  |  | 12 | % |  |  | 10 | % |  |  | 12 | % |  |  |  |  |  |
|  |  | Medical/Industrial/Instrumentation |  |  | 13 | % |  |  | 8 | % |  |  | 14 | % |  |  |  |  |  |
|  |  | Networking/Communications |  |  | 23 | % |  |  | 27 | % |  |  | 25 | % |  |  |  |  |  |
|  |  | Other |  |  |  | 3 | % |  |  | 3 | % |  |  | 2 | % |  |  |  |  |  |
|  | Stock-based Compensation: |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Fourth Quarter |  | Third Quarter |  |  |  |  |  |
|  |  |  |  |  |  |  | 2015 |  |  |  | 2014 |  |  |  | 2015 |  |  |  |  |  |  |
|  |  | Amount included in: |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Cost of goods sold |  | $ | 327 |  |  | $ | 197 |  |  | $ | 322 |  |  |  |  |  |  |
|  |  |  | Selling and marketing |  |  | 301 |  |  |  | 263 |  |  |  | 294 |  |  |  |  |  |  |
|  |  |  | General and administrative |  |  | 2,007 |  |  |  | 1,287 |  |  |  | 2,056 |  |  |  |  |  |  |
|  |  |  | Total stock-based compensation expense |  | $ | 2,635 |  |  | $ | 1,747 |  |  | $ | 2,672 |  |  |  |  |  |  |
|  | Operating Segment Data: |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Fourth Quarter |  | Third Quarter |  |  |  |  |  |
|  |  | Net sales: |  |  | 2015 |  |  |  | 2014 |  |  |  | 2015 |  |  |  |  |  |  |
|  |  | PCB |  |  | $ | 611,045 |  |  | $ | 372,465 |  |  | $ | 604,771 |  |  |  |  |  |  |
|  |  | E-M Solutions |  |  | 61,021 |  |  |  | 19,073 |  |  |  | 49,658 |  |  |  |  |  |  |
|  |  | Corporate |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  |  |  |
|  |  |  | Total sales |  |  | 672,066 |  |  |  | 391,538 |  |  |  | 654,429 |  |  |  |  |  |  |
|  |  | Inter-segment sales |  |  | (3,192 | ) |  |  | (626 | ) |  |  | (2,424 | ) |  |  |  |  |  |
|  |  |  | Total net sales |  | $ | 668,874 |  |  | $ | 390,912 |  |  | $ | 652,005 |  |  |  |  |  |  |
|  |  | Operating segment income: |  |  |  |  |  |  |  |  |  |  |  |
|  |  | PCB |  |  | $ | 66,320 |  |  | $ | 37,236 |  |  | $ | 52,191 |  |  |  |  |  |  |
|  |  | E-M Solutions |  |  | 2,612 |  |  |  | 744 |  |  |  | (1,729 | ) |  |  |  |  |  |
|  |  | Corporate |  |  | (25,708 | ) |  |  | (9,470 | ) |  |  | (20,445 | ) |  |  |  |  |  |
|  |  |  | Total operating segment income |  |  | 43,224 |  |  |  | 28,510 |  |  |  | 30,017 |  |  |  |  |  |  |
|  |  | Amortization of definite-lived intangibles |  |  | (6,683 | ) |  |  | (1,935 | ) |  |  | (6,421 | ) |  |  |  |  |  |
|  |  |  | Total operating income |  |  | 36,541 |  |  |  | 26,575 |  |  |  | 23,596 |  |  |  |  |  |  |
|  |  | Total other expense |  |  | (16,283 | ) |  |  | (4,071 | ) |  |  | (17,004 | ) |  |  |  |  |  |
|  |  | Income before income taxes |  | $ | 20,258 |  |  | $ | 22,504 |  |  | $ | 6,592 |  |  |  |  |  |  |
| RECONCILIATIONS1 |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Fourth Quarter |  | Third Quarter |  | Full Year |  |
|  |  |  |  |  |  |  | 2015 |  |  |  | 2014 |  |  |  | 2015 |  |  |  | 2015 |  |  |  | 2014 |  |  |
|  | Non-GAAP gross profit reconciliation2: |  |  |  |  |  |  |  |  |  |  |  |
|  |  | GAAP gross profit |  | $ | 108,270 |  |  | $ | 68,475 |  |  | $ | 89,118 |  |  | $ | 310,137 |  |  | $ | 194,689 |  |  |
|  |  | Add back item: |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Inventory markup and PP&E step up |  |  | 598 |  |  |  | - |  |  |  | 8,214 |  |  |  | 16,220 |  |  |  | - |  |  |
|  |  |  | Stock-based compensation |  |  | 327 |  |  |  | 197 |  |  |  | 322 |  |  |  | 1,117 |  |  |  | 866 |  |  |
|  |  | Non-GAAP gross profit |  | $ | 109,195 |  |  | $ | 68,672 |  |  | $ | 97,654 |  |  | $ | 327,474 |  |  | $ | 195,555 |  |  |
|  |  | Non-GAAP gross margin |  |  | 16.3 | % |  |  | 17.6 | % |  |  | 15.0 | % |  |  | 15.6 | % |  |  | 14.8 | % |  |
|  | Non-GAAP operating income reconciliation3: |  |  |  |  |  |  |  |  |  |  |  |
|  |  | GAAP operating income (loss) |  | $ | 36,541 |  |  | $ | 26,575 |  |  | $ | 23,596 |  |  | $ | 61,342 |  |  | $ | 46,539 |  |  |
|  |  | Add back items: |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Amortization of definite-lived intangibles |  |  | 6,683 |  |  |  | 1,935 |  |  |  | 6,421 |  |  |  | 18,888 |  |  |  | 8,387 |  |  |
|  |  |  | Stock-based compensation |  |  | 2,635 |  |  |  | 1,747 |  |  |  | 2,672 |  |  |  | 9,661 |  |  |  | 7,800 |  |  |
|  |  |  | Gain on sale of asset |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (2,504 | ) |  |  | - |  |  |
|  |  |  | Acquisition-related costs |  |  | 1,521 |  |  |  | 4,349 |  |  |  | 2,065 |  |  |  | 34,448 |  |  |  | 5,981 |  |  |
|  |  |  | Inventory markup and PP&E step up |  |  | 598 |  |  |  | - |  |  |  | 8,214 |  |  |  | 16,220 |  |  |  | - |  |  |
|  |  |  | Impairments and restructuring charges |  |  | 5,429 |  |  |  | (7 | ) |  |  | 2,003 |  |  |  | 7,941 |  |  |  | 1,900 |  |  |
|  |  | Non-GAAP operating income |  | $ | 53,407 |  |  | $ | 34,599 |  |  | $ | 44,971 |  |  | $ | 145,996 |  |  | $ | 70,607 |  |  |
|  |  | Non-GAAP operating margin |  |  | 8.0 | % |  |  | 8.9 | % |  |  | 6.9 | % |  |  | 7.0 | % |  |  | 5.3 | % |  |
|  | Non-GAAP net income and EPS attributable to stockholders reconciliation4: |  |  |  |  |  |  |  |  |  |  |  |
|  |  | GAAP net income (loss) attributable to stockholders |  | $ | 9,521 |  |  | $ | 13,938 |  |  | $ | (2,237 | ) |  | $ | (25,882 | ) |  | $ | 14,693 |  |  |
|  |  | Add back items: |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Amortization of definite-lived intangibles |  |  | 6,683 |  |  |  | 1,935 |  |  |  | 6,421 |  |  |  | 18,888 |  |  |  | 8,387 |  |  |
|  |  |  | Stock-based compensation |  |  | 2,635 |  |  |  | 1,747 |  |  |  | 2,672 |  |  |  | 9,661 |  |  |  | 7,800 |  |  |
|  |  |  | Non-cash interest expense |  |  | 4,893 |  |  |  | 2,585 |  |  |  | 4,819 |  |  |  | 15,626 |  |  |  | 10,165 |  |  |
|  |  |  | Gain on sale of asset |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (2,504 | ) |  |  | - |  |  |
|  |  |  | Acquisition-related costs |  |  | 1,521 |  |  |  | 4,349 |  |  |  | 2,065 |  |  |  | 34,448 |  |  |  | 5,981 |  |  |
|  |  |  | Inventory markup and PP&E step up |  |  | 598 |  |  |  | - |  |  |  | 8,214 |  |  |  | 16,220 |  |  |  | - |  |  |
|  |  |  | Impairments, restructuring and other charges |  |  | 5,429 |  |  |  | (7 | ) |  |  | 2,003 |  |  |  | 8,743 |  |  |  | 2,406 |  |  |
|  |  |  | Income taxes |  |  | 247 |  |  |  | (1,332 | ) |  |  | (122 | ) |  |  | 5,869 |  |  |  | (10,121 | ) |  |
|  |  | Non-GAAP net income attributable to stockholders |  | $ | 31,527 |  |  | $ | 23,215 |  |  | $ | 23,835 |  |  | $ | 81,069 |  |  | $ | 39,311 |  |  |
|  |  | Non-GAAP earnings per diluted share attributable to stockholders |  | $ | 0.31 |  |  | $ | 0.28 |  |  | $ | 0.24 |  |  | $ | 0.87 |  |  | $ | 0.47 |  |  |
|  | Non-GAAP diluted number of shares5: |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Diluted shares |  |  | 126,329 |  |  |  | 84,205 |  |  |  | 100,035 |  |  |  | 93,640 |  |  |  | 83,941 |  |  |
|  |  | Dilutive effect of convertible debt |  |  | (25,940 | ) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |
|  |  | Non-GAAP diluted number of shares |  |  | 100,389 |  |  |  | 84,205 |  |  |  | 100,035 |  |  |  | 93,640 |  |  |  | 83,941 |  |  |
|  | Adjusted EBITDA reconciliation6: |  |  |  |  |  |  |  |  |  |  |  |
|  |  | GAAP net income (loss) |  | $ | 9,657 |  |  | $ | 13,938 |  |  | $ | (2,138 | ) |  | $ | (25,618 | ) |  | $ | 14,693 |  |  |
|  |  | Add back items: |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Income tax provision (benefit) |  |  | 10,601 |  |  |  | 8,566 |  |  |  | 8,730 |  |  |  | 34,594 |  |  |  | 7,598 |  |  |
|  |  |  | Interest expense |  |  | 20,208 |  |  |  | 5,691 |  |  |  | 21,002 |  |  |  | 59,753 |  |  |  | 23,830 |  |  |
|  |  |  | Amortization of definite-lived intangibles |  |  | 6,683 |  |  |  | 1,935 |  |  |  | 6,421 |  |  |  | 18,888 |  |  |  | 8,387 |  |  |
|  |  |  | Depreciation expense |  |  | 39,105 |  |  |  | 24,318 |  |  |  | 40,091 |  |  |  | 133,508 |  |  |  | 95,349 |  |  |
|  |  |  | Stock-based compensation |  |  | 2,635 |  |  |  | 1,747 |  |  |  | 2,672 |  |  |  | 9,661 |  |  |  | 7,800 |  |  |
|  |  |  | Gain on sale of asset |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (2,504 | ) |  |  | - |  |  |
|  |  |  | Acquisition-related costs |  |  | 1,521 |  |  |  | 4,349 |  |  |  | 2,065 |  |  |  | 34,448 |  |  |  | 5,981 |  |  |
|  |  |  | Inventory markup |  |  | - |  |  |  | - |  |  |  | 6,792 |  |  |  | 14,200 |  |  |  | - |  |  |
|  |  |  | Impairments, restructuring and other charges |  |  | 5,429 |  |  |  | (7 | ) |  |  | 2,003 |  |  |  | 8,743 |  |  |  | 2,406 |  |  |
|  |  | Adjusted EBITDA |  | $ | 95,839 |  |  | $ | 60,537 |  |  | $ | 87,638 |  |  | $ | 285,673 |  |  | $ | 166,044 |  |  |
|  |  | Adjusted EBITDA margin |  |  | 14.3 | % |  |  | 15.5 | % |  |  | 13.4 | % |  |  | 13.6 | % |  |  | 12.5 | % |  |
|  | Free cash flow reconciliation: |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating cash flow |  |  | 139,829 |  |  |  | 52,407 |  |  |  | 14,735 |  |  |  | 237,462 |  |  |  | 129,810 |  |  |
|  |  | Add back items: |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Payment of accreted interest on convertible sr. notes |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 8,730 |  |  |  | 1,324 |  |  |
|  |  |  | Payment of acquisition-related costs |  |  | 1,522 |  |  |  | 2,123 |  |  |  | 6,610 |  |  |  | 36,210 |  |  |  | 2,123 |  |  |
|  |  | Adjusted operating cash flow |  |  | 141,351 |  |  |  | 54,530 |  |  |  | 21,345 |  |  |  | 282,402 |  |  |  | 133,257 |  |  |
|  |  | Capital expenditures, net |  |  | (22,967 | ) |  |  | (26,262 | ) |  |  | (30,345 | ) |  |  | (99,718 | ) |  |  | (108,571 | ) |  |
|  |  | Free cash flow |  | $ | 118,384 |  |  | $ | 28,268 |  |  | $ | (9,000 | ) |  | $ | 182,684 |  |  | $ | 24,686 |  |  |
|  | 1 This information provides a reconciliation of non-GAAP gross profit, non-GAAP operating income, non-GAAP net income attributable to stockholders, non-GAAP EPS attributable to stockholders, and adjusted EBITDA to the financial information in our consolidated condensed statements of operations. |  |
|  | 2 Non-GAAP gross profit and gross margin measures exclude stock-based compensation expense, inventory markup and PP&E step up. |  |
|  | 3 Non-GAAP operating income and operating margin measures exclude amortization of intangibles, stock-based compensation expense, gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges. |  |
|  | 4 This information provides non-GAAP net income attributable to stockholders and non-GAAP EPS attributable to stockholders, which are non-GAAP financial measures. Management believes that both measures -- which add back amortization of intangibles, stock-based compensation expense, non-cash interest expense on debt (before consideration of capitalized interest), gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges as well as the associated tax impact of these charges and discrete tax items -- provide additional useful information to investors regarding the Company's ongoing financial condition and results of operations. |  |
|  | 5 Non-GAAP diluted number of shares used in computing non-GAAP earnings per share attributable to stockholders excludes the dilutive effect of convertible debt. |  |
|  | 6 Adjusted EBITDA is defined as earnings before interest expense, income taxes, depreciation, amortization of intangibles, stock-based compensation expense, gain on sale of assets, inventory markup, acquisition-related costs, asset impairments, restructuring and other charges. We present adjusted EBITDA to enhance the understanding of our operating results, and it is a key measure we use to evaluate our operations. In addition, we provide our adjusted EBITDA because we believe that investors and securities analysts will find adjusted EBITDA to be a useful measure for evaluating our operating performance and comparing our operating performance with that of similar companies that have different capital structures and for evaluating our ability to meet our future debt service, capital expenditures, and working capital requirements. However, adjusted EBITDA should not be considered as an alternative to cash flows from operating activities as a measure of liquidity or as an alternative to net income as a measure of operating results in accordance with accounting principles generally accepted in the United States of America. |  |

[0001171843-16-007659:8k_2_02:47]
Contact:
Todd Schull, CFO
714-327-3000
