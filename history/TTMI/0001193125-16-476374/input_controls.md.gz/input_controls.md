# TTMI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 3 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001193125-16-476374:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES |

[0001193125-16-476374:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001193125-16-476374:item_9a:3]
Our management, under the supervision and with the participation of our Chief Executive Officer (CEO) and Chief Financial Officer (CFO), has evaluated the effectiveness of the design and operation of our
disclosure controls and procedures (as defined in Exchange Act Rules 13a-15(e) and 15d-15(e)) as of the end of the period covered by this Report. Based on this evaluation, our CEO and CFO have concluded that, as of December 28, 2015, such
disclosure controls and procedures were effective to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is (i) recorded, processed, summarized and reported within
the time periods specified in the SEC’s rules and forms and (ii) accumulated and communicated to our management, including our CEO and CFO, as appropriate to allow timely decisions regarding required disclosures.

[0001193125-16-476374:item_9a:4]
Management’s Report on Internal Control over Financial Reporting

[0001193125-16-476374:item_9a:5]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, (as defined in Exchange Act Rules 13a-15(f) and 15d-15(f)) to provide reasonable
assurance regarding the reliability of our financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles (GAAP). Under the supervision of and with the participation
of our CEO and CFO, management conducted an assessment of the effectiveness of our internal control over financial reporting as of December 28, 2015 based on the criteria established in Internal Control — Integrated Framework
(2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”). Based on this assessment, management concluded that our internal control over financial reporting was effective as of
December 28, 2015.

[0001193125-16-476374:item_9a:6]
We acquired Viasystems Group, Inc. (“Viasystems”) on May 31, 2015. Management excluded
from its evaluation of the effectiveness of our internal control over financial reporting as of December 28, 2015 the acquired entity’s internal control over financial reporting associated with 32% of total assets and 32% of total net
sales included in our consolidated financial statements as of and for the year ended December 28, 2015.

[0001193125-16-476374:item_9a:7]
The effectiveness
of our internal control over financial reporting as of December 28, 2015 has been audited by KPMG LLP, an independent registered public accounting firm, as stated in their report, which appears under the heading “Report of Independent
Registered Public Accounting Firm” on page 68 of this Report.

[0001193125-16-476374:item_9a:8]
Inherent Limitations on Effectiveness of Controls

[0001193125-16-476374:item_9a:9]
A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control
system’s objectives will be met. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Further, because of the inherent limitations,
internal control over financial reporting may not prevent or detect misstatements due to error or fraud. These inherent limitations include the realities that judgments in decision-

[0001193125-16-476374:item_9a:10]
57

[0001193125-16-476374:item_9a:11]
making can be faulty and that breakdowns can occur because of simple error or mistake. Controls also can be circumvented by the individual acts of some persons, by collusion of two or more
people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated
goals under all potential future conditions. Projections of any evaluation of controls effectiveness to future periods are subject to risks that controls may become inadequate because of changes in conditions, or that the degree of compliance with
policies or procedures may deteriorate.

[0001193125-16-476374:item_9a:12]
Changes in Internal Control over Financial Reporting

[0001193125-16-476374:item_9a:13]
As a result of the acquisition of Viasystems on May 31, 2015, we began implementing internal controls over financial reporting to
include consolidation of the acquired entity, as well as acquisition-related accounting and disclosures. The integration of Viasystems represents a material change in our internal control over financial reporting. Management continues to be engaged
in substantial efforts to evaluate the effectiveness of our internal control procedures and the design of those control procedures relating to the acquisition of Viasystems with the plan to complete and report its evaluation of the Viasystems
internal control over financial reporting by January 2, 2017.

[0001193125-16-476374:item_9a:14]
There were no other changes in our internal control over
financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended December 28, 2015 that have materially affected, or are reasonably likely to materially affect, our internal control over
financial reporting.
