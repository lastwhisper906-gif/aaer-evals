# TTMI MD&A — 0001193125-16-476374


## mdna

[0001193125-16-476374:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-16-476374:mdna:2]
This financial review presents our operating results for each of our three most recent fiscal years and our financial condition at
December 28, 2015. Except for historical information contained herein, the following discussion contains forward-looking statements which are subject to known and unknown risks, uncertainties and other factors that may cause our actual results
to differ materially from those expressed or implied by such forward-looking statements. We discuss such risks, uncertainties and other factors throughout this report and specifically under Item 1A of Part I of this report, Risk Factors. In
addition, the following discussion should be read in connection with the information presented in our consolidated financial statements and the related notes to our consolidated financial statements.

[0001193125-16-476374:mdna:3]
COMPANY OVERVIEW

[0001193125-16-476374:mdna:4]
We are
a leading global printed circuit board (PCB) manufacturer, focusing on quick-turn and technologically advanced PCBs and electro-mechanical solutions (E-M Solutions). We focus on providing time-to-market and advanced technology products and offer a
one-stop manufacturing solution to our customers from engineering support to prototype development through final volume production. This one-stop manufacturing solution allows us to align technology development with the diverse needs of our
customers and to enable them to reduce the time required to develop new products and bring them to market. We serve a diversified customer base consisting of approximately 1,500 customers in various markets throughout the world, including
manufacturers of networking/communications infrastructure products, smartphones, tablets and ultra notebooks, as well as the aerospace and defense, automotive controls and information systems, high-end computing, and medical, industrial and
instrumentation related products. Our customers include both original equipment manufacturers (OEMs) and electronic manufacturing services (EMS) providers.

[0001193125-16-476374:mdna:5]
RECENT DEVELOPMENTS

[0001193125-16-476374:mdna:6]
On May 31, 2015, we completed the acquisition of
Viasystems Group, Inc. (Viasystems), for total consideration of $248.8 million in cash and 15.1 million shares of TTM common stock. Additionally, in connection with the completion of the acquisition, we assumed and refinanced Viasystems’
debt, which was approximately $669.0 million. Viasystems was a worldwide provider of complex multi-layer rigid, flexible, and rigid-flex PCBs and custom electronic assemblies. Viasystems’ products were found in a wide variety of commercial
products, including automotive engine controls, hybrid converters, automotive electronics for navigation, safety, and entertainment, telecommunications switching equipment, data networking equipment, computer storage equipment, semiconductor test
equipment, wind and solar energy applications, off-shore drilling equipment, communications applications, flight control systems, and complex industrial, medical, and other technical instruments. Viasystems’ E-M Solutions services were bundled
with its PCB products to provide an integrated solution to customers. Viasystems operated 15 manufacturing facilities worldwide: eight in the United States, five in the People’s Republic of China (China), one each in Canada and Mexico.
Viasystems served a diversified customer base of over 1,000 customers in various markets throughout the world.

[0001193125-16-476374:mdna:7]
On
September 29, 2015, we announced a consolidation plan that will result in the closure of our facilities in Cleveland, Ohio, Milpitas, California and Juarez, Mexico (the Plan). The Plan is part of our integration strategy to improve total plant
utilization, operational performance and customer focus following our recent acquisition of Viasystems. In accordance with the Plan, we will combine our Cleveland and Milpitas facilities into our North Jackson, Ohio and Silicon Valley, California
facilities, respectively, and close our Juarez facility. As a result, during the year ended December 28, 2015, we recognized total restructuring charges of $7.4 million. These charges primarily represent severance expense associated with the
Plan and other global realignment restructuring efforts, and are expected to be paid out by June 2016. We estimate that we will incur total charges of approximately $10.0 million to $15.0 million related to these closures. Additionally, our first
quarter 2016 financial results will be negatively impacted as a result of the planned closure of these facilities.

[0001193125-16-476374:mdna:8]
FINANCIAL OVERVIEW

[0001193125-16-476374:mdna:9]
For the fiscal year ended 2015, we experienced higher demand in our Cellular Phone end market compared to that of the same period in 2014. This increase in demand resulted in higher capacity utilization
at our advanced technology plants resulting in higher net sales and gross margins. Additionally, we had improved operating efficiencies at certain of our North American plants.

[0001193125-16-476374:mdna:10]
While our customers include both OEMs and EMS providers, we measure customers based on OEM companies as they are the ultimate end customers. Sales to our 5 largest customers accounted for 37%, 44% and 41%
of our net sales in fiscal years 2015, 2014 and 2013, respectively. We sell to OEMs both directly and indirectly through EMS providers.

[0001193125-16-476374:mdna:11]
The following table shows the percentage of our net sales attributable to each of the principal end markets we served for the periods indicated:

[0001193125-16-476374:mdna:12]
| End Markets(1)(2) |  | 2015(4) |  |  | 2014 |  |  | 2013 |  |
| Aerospace and Defense |  |  | 14 | % |  |  | 16 | % |  |  | 15 | % |
| Automotive(2) |  |  | 13 |  |  |  | 2 |  |  |  | 2 |  |
| Cellular Phone(3) |  |  | 21 |  |  |  | 23 |  |  |  | 20 |  |
| Computing/Storage/Peripherals(3) |  |  | 12 |  |  |  | 13 |  |  |  | 20 |  |
| Medical/Industrial/Instrumentation/Other |  |  | 13 |  |  |  | 10 |  |  |  | 8 |  |
| Networking/Communications |  |  | 25 |  |  |  | 33 |  |  |  | 32 |  |
| Other(2)(3) |  |  | 2 |  |  |  | 3 |  |  |  | 3 |  |
| Total |  |  | 100 | % |  |  | 100 | % |  |  | 100 | % |

[0001193125-16-476374:mdna:13]
| (1) | Sales to EMS companies are classified by the end markets of their OEM customers. |

[0001193125-16-476374:mdna:14]
| (2) | Certain reclassifications of prior year end market percentages have been made to conform to the current year presentation. Beginning 2015, Automotive has been reclassified from the Other end market. Additionally, beginning in the first quarter of 2013, we reclassified substrate PCBs, which were included in the Other end market, into the end markets that the substrate PCBs are sold into — predominantly Cellular Phone. |

[0001193125-16-476374:mdna:15]
| (3) | Smartphones are included in the Cellular Phone end market, tablets are included in the Computing/Storage/Peripherals end market and other mobile devices such as e-readers are included in the Other end market. |

[0001193125-16-476374:mdna:16]
| (4) | Amounts includes 211 days of activity of Viasystems, which we acquired on May 31, 2015. |

[0001193125-16-476374:mdna:17]
We derive revenues primarily from the sale of PCBs and custom electronic assemblies using customer-supplied engineering and design plans.
We recognize revenues when persuasive evidence of a sales arrangement exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is reasonably assured — generally when products are shipped to
the customer. Net sales consist of gross sales less an allowance for returns, which typically have been less than 3% of gross sales. We provide our customers a limited right of return for defective PCBs and backplane assemblies. We record an
estimate for sales returns and allowances at the time of sale based on historical results. Purchase orders may be cancelled prior to shipment. We generally charge customers a fee, based on the percentage completed, if an order is cancelled once it
has entered production.

[0001193125-16-476374:mdna:18]
Cost of goods sold consists of materials, labor, outside services, and overhead expenses incurred in
the manufacture and testing of our products. Shipping and handling fees and related freight costs and supplies associated with shipping products are also included as a component of cost of goods sold. Many factors affect our gross margin, including
capacity utilization, product mix, production volume, and yield. We generally do not participate in any significant long-term contracts with suppliers, and we believe there are a number of potential suppliers for the raw materials we use.

[0001193125-16-476374:mdna:19]
Selling and marketing expenses consist primarily of salaries, labor related benefits, and commissions paid to our internal
sales force, independent sales representatives, and our sales support staff, as well as costs associated with marketing materials and trade shows.

[0001193125-16-476374:mdna:20]
General and administrative costs primarily include the salaries for executive, finance,
accounting, information technology, facilities and human resources personnel, as well as insurance expenses, expenses for accounting and legal assistance, incentive compensation expense, and gains or losses on the sale or disposal of property, plant
and equipment.

[0001193125-16-476374:mdna:21]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0001193125-16-476374:mdna:22]
Our consolidated financial statements included in this report have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these
financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, net sales and expenses, and related disclosure of contingent assets and liabilities.

[0001193125-16-476374:mdna:23]
A critical accounting policy is defined as one that is both material to the presentation of our consolidated financial statements and
requires us to make judgments that could have a material effect on our financial condition or results of operations. These policies require us to make assumptions about matters that are highly uncertain at the time of the estimate. Different
estimates we could reasonably have used, or changes in the estimates that are reasonably likely to occur, or could have a material effect on our financial condition or results of operations.

[0001193125-16-476374:mdna:24]
We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the
circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Management has discussed the development, selection and disclosure of these
estimates with the audit committee of our board of directors. Actual results may differ from these estimates under different assumptions or conditions.

[0001193125-16-476374:mdna:25]
Our critical accounting policies include asset valuation related to bad debts and inventory; sales returns and allowances; impairment of long-lived assets, including goodwill and intangible assets;
derivative instruments and hedging activities; realizability of deferred tax assets; and determining self-insurance reserves.

[0001193125-16-476374:mdna:26]
Allowance for Doubtful Accounts

[0001193125-16-476374:mdna:27]
We provide customary credit terms to our customers and generally do not require collateral. We perform ongoing credit evaluations of the financial condition of our customers and maintain an allowance for
doubtful accounts based upon historical collections experience and judgments as to expected collectability of accounts. Our actual bad debts may differ from our estimates.

[0001193125-16-476374:mdna:28]
Inventories

[0001193125-16-476374:mdna:29]
In assessing the realizability of inventories, we are
required to make judgments as to future demand requirements and compare these with current and committed inventory levels. When the market value of inventory is less than the carrying value, the inventory cost is written down to its estimated net
realizable value, thereby establishing a new cost basis. Our inventory requirements may change based on our projected customer demand, market conditions, technological and product life cycle changes, longer or shorter than expected usage periods,
and other factors that could affect the valuation of our inventories. We maintain certain finished goods inventories near certain key customer locations in accordance with agreements with those customers. Although this inventory is typically
supported by valid purchase orders, should these customers ultimately not purchase these inventories, our results of operations and financial condition would be adversely affected.

[0001193125-16-476374:mdna:30]
Sales Returns and Allowances

[0001193125-16-476374:mdna:31]
We derive revenues primarily from the sale of PCBs and custom electronic assemblies using customer-supplied engineering and design plans. We recognize revenue when persuasive evidence of a sales
arrangement exists, the sales terms are fixed or determinable, title and risk of loss have transferred, and collectability is reasonably assured — generally when products are shipped to the customer. We provide our customers a limited right of
return for defective PCBs and backplane assemblies. We accrue an estimate for sales returns and allowances at the time of sale using our judgment based on historical results and anticipated returns as a result of current period sales. To the extent
actual experience varies from our historical experience, revisions to these allowances may be required.

[0001193125-16-476374:mdna:32]
Long-lived Assets

[0001193125-16-476374:mdna:33]
We have significant long-lived tangible and intangible assets consisting of property, plant and equipment, definite-lived intangibles, and
goodwill. We review these assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. In addition, we perform an impairment test related to goodwill at least annually. As
necessary, we make judgments regarding future cash flow forecasts in the assessment of impairment.

[0001193125-16-476374:mdna:34]
During the fourth quarter
of each year, and when events and circumstances warrant an evaluation, we perform an impairment assessment of goodwill, which may require the use of a fair-value based analysis. We first assesses qualitative factors to determine whether it is more
likely than not that the fair value of a reporting unit is less than its carrying amount. If we conclude that it is more likely than not that the fair value of a reporting units is less than its carrying amount, we conduct a two-step quantitative
goodwill impairment test. We determine the fair value of our reporting units based on discounted cash flows and market approach analyses as considered necessary. We consider factors such as the state of the economy and reduced expectations for
future cash flows coupled with a decline in our market capitalization for a sustained period as indicators for potential goodwill impairment. If the reporting unit’s carrying amount exceeds its estimated fair value, a second step must be
performed to measure the amount of the goodwill impairment loss, if any. The second step compares the implied fair value of the reporting unit’s goodwill, determined in the same manner as the amount of goodwill recognized in a business
combination, with the carrying amount of such goodwill. If the carrying amount of the reporting unit’s goodwill exceeds the implied fair value of that goodwill, an impairment loss is recognized in an amount equal to that excess. We periodically
evaluate whether events and circumstances have occurred, such that the potential for reduced expectations for future cash flows coupled with a further decline in the market price of our stock and market capitalization may indicate that the remaining
balance of goodwill and definite-lived intangible assets may not be recoverable. If factors indicate that assets are impaired, we would be required to reduce the carrying value of our goodwill and definite-lived intangible assets which may result in
an impairment charge.

[0001193125-16-476374:mdna:35]
We also assess other long-lived assets, specifically definite-lived intangibles and property, plant and
equipment, for potential impairment given similar impairment indicators. When indicators of impairment exist related to our long-lived tangible assets and definite-lived intangible assets, we use an estimate of the undiscounted net cash flows and
comparison to like-kind assets, as appropriate, in measuring whether the carrying amount of the assets is recoverable. Measurement of the amount of impairment, if any, is based upon the difference between the asset’s carrying value and
estimated fair value. Fair value is determined through various valuation techniques, including cost-based, market and income approaches as considered necessary, which involve judgments related to future cash flows and the application of the
appropriate valuation model. During the years ended 2014 and 2013 we recorded impairment charges to reduce the carrying value of certain long-lived assets in the PCB operating segment. See Note 4 to our consolidated financial statements.

[0001193125-16-476374:mdna:36]
Assets Held for Sale — We classify assets to be sold as assets held for sale when (i) we have approved and commit to a
plan to sell the asset, (ii) the asset is available for immediate sale in its present condition, (iii) an active program to locate a buyer and other actions required to sell the asset have been initiated, (iv) the sale of the asset is
probable, (v) the asset is being actively marketed for sale at a price that is reasonable in relation to its current fair value, and (vi) it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn.
Assets classified as held for sale are recorded at the lower of the carrying amount or fair value less the cost to sell.

[0001193125-16-476374:mdna:37]
Assets Held for Use — If a decision to dispose of an asset or a business is made and the held for sale criteria are not met,
it is considered held for use. Assets of the business are evaluated for recoverability in the following order: (i) assets other than goodwill, property and intangibles; (ii) property and intangibles subject to amortization; and
(iii) goodwill. In evaluating the recoverability of property and intangible assets subject to amortization, in a held for use business, the carrying value is first compared to the sum of the undiscounted cash flows expected to result from the
use and eventual disposition. If the carrying value exceeds the undiscounted expected cash flows, then a fair value analysis is performed. An impairment charge is recognized if the carrying value exceeds the fair value.

[0001193125-16-476374:mdna:38]
Derivative Instruments and Hedging Activities

[0001193125-16-476374:mdna:39]
As a matter of policy, we use derivatives for risk management purposes, and we do not use derivatives for speculative purposes.
Derivatives are typically entered into as hedges of changes in interest rates, currency exchange rates, and other risks.

[0001193125-16-476374:mdna:40]
When
we determine to designate a derivative instrument as a cash flow hedge, we formally document the hedging relationship and its risk management objective and strategy for undertaking the hedge, the hedging instrument, the hedged item, the nature of
the risk being hedged, how the hedging instrument’s effectiveness in offsetting the hedged risk will be assessed, and a description of the method of measuring ineffectiveness. We also formally assess, both at the hedge’s inception and on
an ongoing basis, whether the derivative that is used in hedging transactions is highly effective in offsetting changes in cash flows of hedged items.

[0001193125-16-476374:mdna:41]
Derivative financial instruments are recognized as either assets or liabilities on the consolidated balance sheet with measurement at fair value. Fair value of the derivative instruments is determined
using pricing models developed based on the underlying swap interest rate, foreign currency exchange rates, and other observable market data as appropriate. The values are also adjusted to reflect nonperformance risk of the counterparty and our
company, as necessary. For derivatives that are designated as a cash flow hedge, changes in the fair value of the derivative are recognized in accumulated other comprehensive income, to the extent the derivative is effective at offsetting the
changes in cash flow being hedged until the hedged item affects earnings. To the extent there is any hedge ineffectiveness, changes in fair value relating to the ineffective portion are immediately recognized in earnings. Changes in the fair value
of derivatives that are not designated as hedges are recorded in earnings each period.

[0001193125-16-476374:mdna:42]
Income Taxes

[0001193125-16-476374:mdna:43]
Deferred income tax assets are reviewed for recoverability, and valuation allowances are provided, when necessary, to reduce deferred
income tax assets to the amounts that are more likely than not to be realized based on our estimate of future taxable income. At December 28, 2015, we have net noncurrent deferred income tax liabilities of $13.1 million, which is net of the
$84.7 million net noncurrent deferred tax assets. At December 28, 2015, our net noncurrent deferred income tax assets of $84.7 million are net of a valuation allowance of approximately $234.2 million. Should our expectations of taxable income
change in future periods, it may be necessary to adjust our valuation allowance, which could affect our results of operations in the period such a determination is made. We record income tax provision or benefit during interim periods at a rate that
is based on expected results for the full year. If future changes in market conditions cause actual results for the year to be more or less favorable than those expected, adjustments to the effective income tax rate could be required.

[0001193125-16-476374:mdna:44]
In addition, we are subject to income taxes in the United States and foreign jurisdictions. Significant judgment is required in
determining our worldwide provision for income taxes. In the ordinary course of our business, there are many transactions for which the ultimate tax determination is uncertain. Additionally, our calculations of income taxes are based on our
interpretations of applicable tax laws in the jurisdictions in which we file.

[0001193125-16-476374:mdna:45]
Self Insurance

[0001193125-16-476374:mdna:46]
We are primarily self-insured in North America for group health insurance and worker’s compensation benefits provided to our U.S.
employees, and we purchase insurance to protect against annual claims at the individual and aggregate level. We estimate our exposure for claims incurred but not reported at the end of each reporting period. We use our judgment using our historical
claim data and information and analysis provided by actuarial and claim advisors, our insurance carriers and brokers on an annual basis to estimate our liability for these claims. This liability is subject to individual insured stop-loss coverage of
$200,000 per individual for the recently acquired Viasystems subsidiaries and $300,000 per individual for existing TTM subsidiaries for group health insurance and $250,000 for worker’s compensation benefits. Our actual claims experience may
differ from our estimates.

[0001193125-16-476374:mdna:47]
RESULTS OF OPERATIONS

[0001193125-16-476374:mdna:48]
The Viasystems acquisition occurred on May 31, 2015. Accordingly, the results of operations of Viasystems are not included in our fiscal years ended 2014 and 2013, and our fiscal year ended 2015 only
includes the last seven fiscal months Viasystems’ 2015 results of operations. The acquisition has had and will continue to have a significant effect on our operations as discussed in the various comparisons noted below:

[0001193125-16-476374:mdna:49]
|  |  | For the Year Ended |  |
|  |  | December 28,2015 |  |  | December 29,2014 |  |  | December 30,2013 |  |
| Net sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of goods sold |  |  | 85.2 |  |  |  | 85.3 |  |  |  | 84.1 |  |
| Gross profit |  |  | 14.8 |  |  |  | 14.7 |  |  |  | 15.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing |  |  | 2.7 |  |  |  | 2.8 |  |  |  | 2.7 |  |
| General and administrative |  |  | 8.0 |  |  |  | 7.6 |  |  |  | 7.7 |  |
| Amortization of definite-lived intangibles |  |  | 0.9 |  |  |  | 0.7 |  |  |  | 0.7 |  |
| Gain on sale of assets |  |  | (0.1 | ) |  |  | — |  |  |  | (1.3 | ) |
| Restructuring charges |  |  | 0.4 |  |  |  | — |  |  |  | 0.3 |  |
| Impairment of long-lived assets |  |  | — |  |  |  | 0.1 |  |  |  | 0.8 |  |
| Total operating expenses |  |  | 11.9 |  |  |  | 11.2 |  |  |  | 10.9 |  |
| Operating income |  |  | 2.9 |  |  |  | 3.5 |  |  |  | 5.0 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (2.9 | ) |  |  | (1.8 | ) |  |  | (1.7 | ) |
| Loss on extinguishment of debt |  |  | — |  |  |  | — |  |  |  | (0.8 | ) |
| Other, net |  |  | 0.4 |  |  |  | — |  |  |  | 0.4 |  |
| Total other expense, net |  |  | (2.5 | ) |  |  | (1.8 | ) |  |  | (2.1 | ) |
| Income before income taxes |  |  | 0.4 |  |  |  | 1.7 |  |  |  | 2.9 |  |
| Income tax provision |  |  | (1.6 | ) |  |  | (0.6 | ) |  |  | (1.2 | ) |
| Net (loss) income |  |  | (1.2 | ) |  |  | 1.1 |  |  |  | 1.7 |  |
| Less: Net income attributable to the non-controlling interest |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Net (loss) income attributable to TTM Technologies, Inc. stockholders |  |  | (1.2 | )% |  |  | 1.1 | % |  |  | 1.6 | % |

[0001193125-16-476374:mdna:50]
As a result of the May 31, 2015 acquisition of Viasystems and the ongoing integration activities, we
have reassessed our reportable operating segments and determined that we have two reportable operating segments: PCB and E-M Solutions. This determination was made based on the criteria of earning revenues and incurring expenses, our organizational
structure which has segment managers who report to the chief operating decision maker and discrete financial information, and the aggregation of similar operating segments into reportable operating segments.

[0001193125-16-476374:mdna:51]
46

[0001193125-16-476374:mdna:52]
The following table compares net sales by reportable segment for fiscal years ended 2015,
2014 and 2013:

[0001193125-16-476374:mdna:53]
|  |  | For the Year Ended |  |
|  |  | December 28,2015 |  |  | December 29,2014 |  |  | December 30,2013 |  |
|  |  | (In thousands) |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| PCB |  | $ | 1,944,041 |  |  | $ | 1,251,665 |  |  | $ | 1,305,862 |  |
| E-M Solutions |  |  | 158,655 |  |  |  | 76,545 |  |  |  | 65,202 |  |
| Total sales |  |  | 2,102,696 |  |  |  | 1,328,210 |  |  |  | 1,371,064 |  |
| Inter-segment sales |  |  | (7,208 | ) |  |  | (2,493 | ) |  |  | (2,849 | ) |
| Total net sales |  | $ | 2,095,488 |  |  | $ | 1,325,717 |  |  | $ | 1,368,215 |  |

[0001193125-16-476374:mdna:54]
Net Sales

[0001193125-16-476374:mdna:55]
Total net sales increased $769.8 million, or 58.1%, from $1,325.7 million for the year ended December 29, 2014 to $2,095.5 million for the year ended December 28, 2015. Net sales for the PCB
operating segment, excluding inter-segment sales, increased $687.7 million, or 55.0%, from $1,249.5 million for the year ended December 29, 2014 to $1,937.2 million for the year ended December 28, 2015. This increase is primarily due to
the additional sales resulting from the acquisition of Viasystems, which accounted for $582.3 million in PCB sales for the year ended December 28, 2015. Additionally, the increase in PCB sales is due to higher demand in our Cellular Phone end
markets, partially offset with lower demand in our Networking/Communications end market. These changes, including the sales from Viasystems, resulted in a 110% increase in PCB shipments from the year ended December 29, 2014. In addition, the
average PCB selling price decreased 25%, which was driven by a product mix shift resulting from the acquisition. Net sales for the E-M Solutions operating segment, excluding inter-segment sales, increased $82.1 million, from $76.2 million for the
year ended December 29, 2014 to $158.3 million for the year ended December 28, 2015. This increase is due to the acquisition of Viasystems, which accounted for $82.0 million in E-M Solutions sales for the year ended December 28, 2015.

[0001193125-16-476374:mdna:56]
Total net sales decreased $42.5 million, or 3.1%, from $1,368.2 million for the year ended December 30, 2013 to $1,325.7
million for the year ended December 29, 2014. Net sales for the PCB operating segment, excluding inter-segment sales, decreased $53.5 million, or 4.1%, from $1,303.0 million for the year ended December 30, 2013 to $1,249.5 million for the
year ended December 29, 2014. This decrease was primarily due to the absence of net sales resulting from the sale of a controlling equity interest in a subsidiary in the second quarter of 2013, combined with lower demand in our
Computing/Storage/Peripherals and Cellular Phone end markets in the first and second quarters of 2014. This decrease was partially offset by higher demand in our Cellular Phone end market in the second half of 2014. The overall decline in demand
resulted in a 12% decrease in PCB shipments from the year December 30, 2013, and was partially offset by a 9% increase in the average PCB selling price, which was driven by product mix shift. Net sales for the E-M Solutions operating segment,
excluding inter-segment sales, increased $11.0 million, or 16.9%, from $65.2 million for the year ended December 30, 2013 to $76.2 million for the year ended December 29, 2014. This increase was primarily due to the demand for backplane
assemblies predominantly in our Networking/Communications end market.

[0001193125-16-476374:mdna:57]
The inter-segment sales are primarily sales from the PCB
operating segment to the E-M Solutions operating segment.

[0001193125-16-476374:mdna:58]
Gross Margin

[0001193125-16-476374:mdna:59]
Overall gross margin increased from 14.7% for the year ended December 29, 2014 to 14.8% for the year ended December 28, 2015.
Gross margin for the PCB operating segment increased from 15.0% for the year ended December 29, 2014 to 15.5% for the year ended December 28, 2015 primarily due to higher utilization at our advanced technology plants, partially offset by
the acquisition of Viasystems with lower margins than our existing business and the $13.3 million of increased costs due to the fair value mark up of acquired inventory

[0001193125-16-476374:mdna:60]
associated with the acquisition of Viasystems. Gross margin for the E-M Solutions operating segment decreased from 9.4% for the year ended December 29, 2014 to 6.6% for the year ended
December 28, 2015 primarily due to the acquisition of Viasystems.

[0001193125-16-476374:mdna:61]
Overall gross margin decreased from 15.9% for the year
ended December 30, 2013 to 14.7% for the year ended December 29, 2014. Gross margin for the PCB operating segment decreased from 16.3% for the year ended December 30, 2013 to 15.0% for the year ended December 29, 2014 primarily
due to underutilization in the first and second quarters of 2014 caused by an increase in capacity to service an expected higher level of business which did not materialize. Additionally, in the third quarter of 2014, the PCB operating segment
experienced a 5 day production shut down due to an unexpected power outage at one of our advanced technology production facilities which negatively impacted our productivity and yield improvement efforts as we were launching new products and
significantly ramping for increased volumes. Gross margin for the E-M Solutions operating segment increased from 8.5% for the year ended December 30, 2013 to 9.4% for the year ended December 29, 2014 primarily due to higher volumes.

[0001193125-16-476374:mdna:62]
Selling and Marketing Expenses

[0001193125-16-476374:mdna:63]
Selling and marketing expenses increased $20.5 million, from $36.9 million for the year ended December 29, 2014 to $57.4 million for the year ended December 28, 2015. The increase primarily
relates to additional marketing activity resulting from the acquisition of Viasystems. As a percentage of net sales, selling and marketing expenses were 2.8% for the year ended December 29, 2014, as compared to 2.7% for the year ended
December 28, 2015. The decrease in selling and marketing expense as a percentage of net sales for the periods noted is primarily due to higher net sales.

[0001193125-16-476374:mdna:64]
Selling and marketing expenses decreased $0.2 million, or 0.5%, from $37.1 million for the year ended December 30, 2013 to $36.9 million for the year ended December 29, 2014. The decrease in
selling and marketing expenses for the year ended December 29, 2014, was primarily due to reduced commissions and lower travel expenses over the comparable periods of the prior year. As a percentage of net sales, selling and marketing expenses
were 2.7% and 2.8% for the years ended December 30, 2013 and December 29, 2014, respectively. The increase in selling and marketing expense as a percentage of net sales for the year ended December 29, 2014 was primarily due to lower
net sales.

[0001193125-16-476374:mdna:65]
General and Administrative Expenses

[0001193125-16-476374:mdna:66]
General and administrative expenses increased $66.7 million from $101.0 million, or 7.6% of net sales, for the year ended
December 30, 2014 to $167.7 million, or 8.0% of net sales, for the year ended December 28, 2015. The increase in expense is primarily due to $34.4 million of acquisition-related costs for the year ended December 28, 2015 related to
the acquisition of Viasystems and seven months of general and administrative expense incurred related to Viasystems post acquisition through December 28, 2015.

[0001193125-16-476374:mdna:67]
General and administrative expenses decreased $4.9 million from $105.9 million, or 7.7% of net sales, for the year ended December 30, 2013 to $101.0 million, or 7.6% of net sales, for the year ended
December 29, 2014. The decrease in general and administrative expense for the year ended December 29, 2014 is primarily due to costs savings resulting from the sale of our controlling equity interest in a subsidiary in the PCB operating
segment and lower incentive compensation expense, offset by the $6.0 million of acquisition-related costs recorded in the third and fourth quarters of 2014.

[0001193125-16-476374:mdna:68]
Impairment of Long-Lived Assets and Restructuring Charges

[0001193125-16-476374:mdna:69]
For the
year ended December 28, 2015, we incurred restructuring charges of $7.4 million related to the Plan announced on September 29, 2015, that will result in the closure of our facilities in Cleveland, Ohio, Milpitas, California, Juarez, Mexico
and other global realignment efforts.

[0001193125-16-476374:mdna:70]
In connection with the Plan, during the year ended December 28, 2015, we recognized
restructuring charges of $2.0 million in both our PCB and E-M Solutions segments and $3.4 million in our Corporate segment. These charges primarily represent severance expense associated with the Plan and other global realignment restructuring
efforts and are expected to be paid out by June 2016. We estimate that we will incur total charges of approximately $10.0 million to $15.0 million related to these closures.

[0001193125-16-476374:mdna:71]
For the year ended December 29, 2014 and December 30, 2013, in conjunction with
the shutdown of the Suzhou, China facility, we recorded charges of $1.8 million and $10.8 million, respectively, primarily arising from the impairment of certain machinery and equipment. Additionally, in conjunction with the shutdown, we recorded
restructuring charges of $3.4 million during the year ended December 30, 2013, consisting of separation costs associated with the layoff of 774 employees.

[0001193125-16-476374:mdna:72]
If forecasts and assumptions used to support the realizability of our long-lived assets change in the future, significant impairment or restructuring charges could result that would adversely affect our
results of operations and financial condition.

[0001193125-16-476374:mdna:73]
Other Income (Expense)

[0001193125-16-476374:mdna:74]
Other expense, net increased $28.2 million from $24.2 million for the year ended December 29, 2014 to $52.4 million for the year
ended December 28, 2015. The increase in other expense, net was primarily due to an increase in interest expense related to a new long-term borrowing and a revolver loan totaling $1,030.0 million at a weighted average interest rate of 5.7% that
we secured in connection with the acquisition of Viasystems. The increase in other expense, net was partially offset by $6.4 million foreign currency and derivative transaction gains for the year ended December 28, 2015 compared to $1.2 million
for the year ended December 29, 2014.

[0001193125-16-476374:mdna:75]
Other expense, net decreased $5.2 million from $29.4 million for the year ended
December 30, 2013 to $24.2 million for year ended December 29, 2014. The decrease in other expense, net was primarily due to the absence of a $10.7 million loss on the extinguishment of debt related to repurchase of a portion of
convertible senior notes due 2015 for the year ended December 30, 2013, offset by an increase in foreign currency transaction and derivative losses of $5.5 million, which includes a $3.6 million foreign currency transaction and derivative loss
recognized in the first quarter of 2014 primarily due to the rapid depreciation of the RMB against the U.S. Dollar.

[0001193125-16-476374:mdna:76]
Income Taxes

[0001193125-16-476374:mdna:77]
Our effective tax rate for the years ended December 28, 2015 and December 29, 2014 was 385.4% and 34.1%, respectively. The provision for income taxes increased $27.0 million from an income tax
expense of $7.6 million for the year ended December 29, 2014 to $34.6 million for the year ended December 28, 2015. The increase in income tax expense in 2015 is primarily due to the provision of a full valuation allowance on existing U.S.
deferred tax assets, partially offset by the reversal of deferred tax liabilities related to our decision to indefinitely reinvest the foreign earnings attributable to our backplane assembly facility in Shanghai, China. Further, the income tax
expense in 2015 is higher due to inclusion of Viasystems earnings from foreign subsidiaries in the second, third and fourth quarters of 2015.

[0001193125-16-476374:mdna:78]
Our effective tax rate is primarily impacted by tax rates in China and Hong Kong, the U.S. federal income tax rate, apportioned state income tax rates, generation of other credits and deductions available
to us, valuation allowance establishment, and certain non-deductible items. Certain foreign losses generated are not more likely than not to be realizable, and thus no income tax benefit has been recognized on these losses. As of December 28,
2015, we had net deferred income tax liabilities of approximately $13.1 million; and as of December 29, 2014, we had net deferred income tax assets of approximately $2.9 million. As of the end of 2015, based on our forecast for future taxable
earnings, we believe it is more likely than not that we will utilize the deferred income tax assets in future periods.

[0001193125-16-476374:mdna:79]
Our
effective tax rate for the years ended December 29, 2014 and December 30, 2013 was 34.1% and 39.9%, respectively. The provision for income taxes decreased $8.3 million from an income tax expense of $15.9 million for the year ended
December 30, 2013 to $7.6 million for the year ended December 29, 2014. The decrease in our provision for income taxes was primarily due to losses incurred for the first three quarters of 2014 compared to income in the same period of the
prior year, combined with (i) a $1.5 million discrete tax benefit recorded in the first quarter of 2014 resulting from the retroactive approval of the high technology enterprise status for a Chinese subsidiary, (ii) a $0.7 million discrete
tax benefit recorded in the third quarter of 2014 resulting from the research and development deduction at a Chinese subsidiary, and (iii) the absence of local withholding taxes of approximately $4.9 million related to the sale of a controlling
equity interest in a subsidiary in the second quarter of 2013.

[0001193125-16-476374:mdna:80]
Liquidity and Capital Resources

[0001193125-16-476374:mdna:81]
Our principal sources of liquidity have been cash provided by operations, the issuance of convertible senior notes, and term and revolving
debt. Our principal uses of cash have been to acquire Viasystems, finance capital expenditures, meet debt service requirements, fund working capital requirements, and refinance existing debt. We anticipate that servicing debt, financing capital
expenditures, financing acquisitions, and funding working capital requirements will continue to be the principal demands on our cash in the future.

[0001193125-16-476374:mdna:82]
Cash flow provided by operating activities during the year ended December 28, 2015 was $237.5 million as compared to $129.8 million in the same period in 2014. The improved cash flow was the result
of stronger operational performance. As of December 28, 2015, we had net working capital of approximately $277.5 million compared to $302.1 million as of December 29, 2014. For the year ended December 28, 2015, cash cycle days of 46
days were held constant as compared to the previous year.

[0001193125-16-476374:mdna:83]
Net cash used in investing activities was approximately $247.7
million for the year ended December 28, 2015 primarily reflecting the acquisition of Viasystems, net of cash acquired, in the amount of $169.2 million, and purchases of property, plant and equipment, net of proceeds from sales of property,
plant and equipment and assets held for sale of $78.5 million.

[0001193125-16-476374:mdna:84]
Net cash used in financing activities was approximately $5.8
million for the year ended December 28, 2015 reflecting proceeds from long-term debt and a revolving loan totaling $1,030.0 million, offset by the repayment of $968.9 million of debt, including the assumed long-term debt in the acquisition of
$669.0 million, payoff of the 2012 credit agreement term loan, the payoff of the remaining 2015 convertible senior notes, and payment of debt issuance costs and original issue discount of $67.4 million associated with the new long-term debt and
revolver loans.

[0001193125-16-476374:mdna:85]
As of December 28, 2015, we had unrestricted cash and cash equivalents of approximately $259.1 million,
of which approximately $176.6 million was held by our foreign subsidiaries. Of the cash and cash equivalents held by our foreign subsidiaries as of December 28, 2015, $175.0 million was located in Asia and $1.6 million was located in Europe and
other locations. Cash and cash equivalents held by our foreign locations are expected to be used in local operations.

[0001193125-16-476374:mdna:86]
Our 2016
capital expenditure plan is expected to be in the range of $110.0 million to $120 million. The expenditures will fund capital equipment purchases to increase production capacity, especially for advanced technology manufacturing, comply with changing
environmental regulations, replace aging equipment, and expand our technological capabilities.

[0001193125-16-476374:mdna:87]
Term and Revolving Loans

[0001193125-16-476374:mdna:88]
On May 31, 2015, in conjunction with the acquisition of Viasystems, we entered into a $950.0 million Term Loan
Credit Agreement (Term Loan). Additionally, we entered into a $150.0 million U.S. Asset-Based Lending Credit Agreement (U.S. ABL) and a $150.0 million Asia Asset-Based Lending Credit agreement (Asia ABL). We drew $80.0 million of the U.S. ABL at the
closing of the acquisition of Viasystems.

[0001193125-16-476374:mdna:89]
The Term Loan Credit agreement was issued at a discount at 96.5% and bears interest
at a floating rate of LIBOR, with a 1.0% LIBOR floor, plus an applicable interest margin of 5.0%. At December 28, 2015, the weighted average interest rate on the outstanding borrowings under the Term Loan was 6.0%. There is no provision, other
than an event of default, for the interest margin to increase. The Term Loan will mature on May 31, 2021. The Term Loan is secured by a significant amount of our assets and our domestic subsidiaries and a pledge of 65% of the voting stock of
our first tier foreign subsidiaries and is structurally senior to our convertible senior notes. See Convertible Senior Notes due 2020 below.

[0001193125-16-476374:mdna:90]
The U.S. ABL consists of three tranches comprised of a revolving credit facility of up to $150.0 million, a letter of credit facility of up to $75.0 million, and swingline loans of up to $30.0 million,
provided that at no time may amounts outstanding under the tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the U.S. ABL agreement.
Borrowings under the U.S. ABL bear interest at a floating rate of LIBOR plus a margin of 175 basis points. At

[0001193125-16-476374:mdna:91]
December 28, 2015, the weighted average interest rate on the outstanding borrowings under the U.S. ABL was 2.17%. Beginning in 2016, the applicable margin can vary based on the remaining
availability of the facility, from 150 to 200 basis points for LIBOR-based loans. The U.S. ABL will mature on May 31, 2020. Loans made under the U.S. ABL are secured first by all of our domestic cash, receivables and inventories as well as by a
second position against a significant amount of our assets and our domestic subsidiaries and a pledge of 65% of the voting stock of our first tier foreign subsidiaries and are structurally senior to our convertible senior notes. See Convertible
Senior Notes due 2020 below. At December 28, 2015, $80.0 million of the U.S. ABL was outstanding and classified as a current liability.

[0001193125-16-476374:mdna:92]
We and our domestic subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Term Loan and U.S. ABL related obligations.

[0001193125-16-476374:mdna:93]
The Asia ABL consists of two tranches comprised of a revolving credit facility of up to $150.0 million and a letter of credit facility of
up to $100.0 million provided that at no time may amounts outstanding under both tranches exceed in aggregate $150.0 million or the applicable borrowing base, which is a percentage of the principal amount of Eligible Accounts, as defined in the Asia
ABL agreement. Borrowings under the Asia ABL bear interest at a floating rate of LIBOR plus 175 basis points. There is no provision, other than an event of default, for the interest margin to increase. The Asia ABL will mature on May 22, 2020.
Loans made under the Asia ABL are secured by a portion of our Asia Pacific cash and receivables and are structurally senior to our domestic obligations, including our convertible senior notes. See Convertible Senior Notes due 2020 below. Our Asia
Pacific subsidiary and certain of its subsidiaries have fully and unconditionally guaranteed the full and timely payment of all Asia ABL related obligations. At December 28, 2015, none of the Asia ABL was outstanding.

[0001193125-16-476374:mdna:94]
We are required to make scheduled payments of the outstanding Term Loan balance on a quarterly basis beginning October 1, 2015. On
October 1, 2015 the scheduled principal payment of $2.4 million was made. Based on certain parameters defined in the Term Loan agreement, we may be required to make an additional principal payment on an annual basis. For 2015, we are required
to make an additional annual payment of $61.1 million, which is required to be paid in March 2016. In addition to the $61.1 million additional annual payment, we also intend to repay an additional $10 million to $20 million of the Term Loan in March
2016. As a result of our intentions and including the already scheduled January 2016 payment, approximately $77.4 million has been classified as short-term debt. This additional annual payment reduces future required quarterly scheduled payments.
Any other outstanding balances under the Term Loan are due at the maturity date of May 31, 2021. Borrowings under the Term Loan are subject to various financial and operating covenants including maintaining a maximum total leverage ratio. Under
the occurrence of certain events, the U.S. ABL and the Asia ABL are subject to various financial and operational covenants, including maintaining minimum fixed charge coverage ratios. At December 28, 2015, we were in compliance with the
covenants under the Term Loan, the U.S. ABL and the Asia ABL.

[0001193125-16-476374:mdna:95]
We are also required to pay a commitment fee of 0.375% per
annum on any unused portion of the U.S. ABL or Asia ABL. The U.S. ABL commitment fee may vary from 0.25% to 0.375% based on utilization levels. We incurred total commitment fees related to unused borrowing availability of $0.8 million, $0.6 million
and $0.4 million for fiscal years ended 2015, 2014 and 2013, respectively. As of December 28, 2015, the outstanding amount of the Term Loan was $947.6 million, of which $77.4 million we expect to pay within one year and is included as
short-term debt, with the remaining $870.2 million included as long-term debt. Additionally, $80.0 million of the U.S. ABL and none of the Asia ABL was outstanding as of December 28, 2015. Available borrowing capacity under the U.S. ABL and
Asia ABL was $65.4 million and $142.0 million, which includes $4.6 million and $8.0 million, respectively, of outstanding letters of credit mentioned below at December 28, 2015.

[0001193125-16-476374:mdna:96]
Letters of Credit

[0001193125-16-476374:mdna:97]
We have up to $75.0 million and $100.0 million Letters of Credit Facilities available under the U.S. ABL and the Asia ABL, respectively. As of December 28, 2015, letters of credit in the amount of
$4.6 million were outstanding under the U.S. ABL and $8.0 million were outstanding under the Asia ABL. We have other standby

[0001193125-16-476374:mdna:98]
51

[0001193125-16-476374:mdna:99]
letters of credit outstanding in the amount of $2.9 million which expire by April 2016. These other standby letters of credit are securitized by cash collateral. As such, we have recorded such
cash as restricted on the consolidated condensed balance sheet as of December 28, 2015.

[0001193125-16-476374:mdna:100]
Chinese Revolver

[0001193125-16-476374:mdna:101]
We are party to a revolving loan credit facility with a lender in China. Under this arrangement, the lender has made
available to us approximately $35.5 million in unsecured borrowing with all terms of the borrowing to be negotiated at the time the Chinese Revolver is drawn upon. There are no commitment fees on the unused portion of the Chinese Revolver, and this
arrangement expires in December 2016. As of December 28, 2015, the Chinese Revolver had not been drawn upon.

[0001193125-16-476374:mdna:102]
Convertible Senior Notes due 2020

[0001193125-16-476374:mdna:103]
We issued 1.75% convertible senior notes due December 15, 2020, in a public offering for an aggregate principal amount of $250.0 million. The convertible senior notes bear interest at a rate of
1.75% per annum. Interest is payable semiannually in arrears on June 15 and December 15 of each year. The convertible senior notes are senior unsecured obligations and rank equally to our future unsecured senior indebtedness and
senior in right of payment to any of our future subordinated indebtedness. Offering expenses are being amortized to interest expense over the term of the convertible senior notes.

[0001193125-16-476374:mdna:104]
Conversion:    At any time prior to March 15, 2020, holders may convert their convertible senior
notes into cash and, if applicable, into shares of our common stock based on a conversion rate of 103.7613 shares of our common stock per $1,000 principal amount of convertible senior notes, subject to adjustment, under the following circumstances:
(1) during any calendar quarter beginning after March 31, 2014 (and only during such calendar quarter), if the last reported sale price of our common stock for at least 20 trading days during the 30 consecutive trading days ending on the
last trading day of the immediately preceding calendar quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day of such preceding calendar quarter; (2) during the five business day period after
any 10 consecutive trading day period in which the trading price per note for each day of that 10 consecutive trading day period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate on such
day; or (3) upon the occurrence of specified corporate transactions described in the indenture governing the notes. As of December 28, 2015, none of the conversion criteria had been met.

[0001193125-16-476374:mdna:105]
On or after March 15, 2020 until the close of business on the third scheduled trading day preceding the maturity date, holders may
convert their notes at any time, regardless of the foregoing circumstances. Upon conversion, for each $1,000 principal amount of notes, we will pay shares of our common stock, cash or a combination of cash and shares of our common stock at our
election, if applicable, based on a daily conversion value calculated on a proportionate basis for each day of the 80 trading day observation period. All conversions occurring on the same date or on or after March 15, 2020 shall be settled
using the same settlement method. Additionally, in the event of a fundamental change as defined in the indenture governing the notes, or other conversion rate adjustments such as share splits or combinations, other distributions of shares, cash or
other assets to stockholders, including self-tender transactions (Other Conversion Rate Adjustments), the conversion rate may be modified to adjust the number of shares per $1,000 principal amount of the notes. As of December 28, 2015, none of
the criteria for a fundamental change or a conversion rate adjustment had been met.

[0001193125-16-476374:mdna:106]
The maximum number of shares issuable upon
conversion, including the effect of a fundamental change and subject to Other Conversion Rate Adjustments, would be 32.4 million.

[0001193125-16-476374:mdna:107]
Note Repurchase:    We are not permitted to redeem the convertible senior notes at any time prior to maturity. In the event of a fundamental change or certain default
events, as defined in the indenture governing the notes, holders may require us to repurchase for cash all or a portion of their convertible senior notes at a price equal to 100% of the principal amount, plus any accrued and unpaid interest.

[0001193125-16-476374:mdna:108]
In connection with the issuance of the convertible senior notes due 2020, we entered into a convertible note hedge and warrant
transaction (the Call Spread Transaction), with respect to our common stock. The convertible note hedge consists of our option to purchase up to 25.9 million common stock shares at a price of $9.64 per

[0001193125-16-476374:mdna:109]
share. The hedge expires on December 15, 2020 and can only be executed upon the conversion of the above mentioned convertible senior notes due 2020. Additionally, we sold warrants to
purchase 25.9 million shares of our common stock at a price of $14.26 per share. The warrants expire ratably from March 2021 through January 2022. The Call Spread Transaction has no effect on the terms of the convertible senior notes due 2020
and reduces potential dilution by effectively increasing the conversion price of the convertible senior notes due 2020 to $14.26 per share of our common stock.

[0001193125-16-476374:mdna:110]
Based on our current level of operations, we believe that cash generated from operations, cash on hand and cash from the issuance of term and revolving debt will be adequate to meet our currently
anticipated capital expenditure, debt service, and working capital needs for the next 12 months.

[0001193125-16-476374:mdna:111]
Contractual Obligations and Commitments

[0001193125-16-476374:mdna:112]
The following table provides information on our contractual obligations as of December 28, 2015:

[0001193125-16-476374:mdna:113]
| Contractual Obligations(1) |  | Total |  |  | Less Than1 Year |  |  | 1 - 3Years |  |  | 4 - 5Years |  |  | After5 Years |  |
|  |  | (In thousands) |  |
| Long-term debt obligations |  | $ | 1,027,625 |  |  | $ | 157,375 |  |  | $ | 27,125 |  |  | $ | 95,000 |  |  | $ | 748,125 |  |
| Convertible debt obligations |  |  | 250,000 |  |  |  | — |  |  |  | — |  |  |  | 250,000 |  |  |  | — |  |
| Interest on debt obligations |  |  | 311,791 |  |  |  | 61,164 |  |  |  | 114,345 |  |  |  | 106,403 |  |  |  | 29,879 |  |
| Foreign currency forward contract liabilities |  |  | 51 |  |  |  | 51 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Equipment payables |  |  | 14,251 |  |  |  | 14,251 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 69,054 |  |  |  | 69,054 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Operating lease commitments |  |  | 27,603 |  |  |  | 8,332 |  |  |  | 8,819 |  |  |  | 4,049 |  |  |  | 6,403 |  |
| Total contractual obligations |  | $ | 1,700,375 |  |  | $ | 310,227 |  |  | $ | 150,289 |  |  | $ | 455,452 |  |  | $ | 784,407 |  |

[0001193125-16-476374:mdna:114]
| (1) | Unrecognized uncertain tax benefits of $15.4 million are not included in the table above as the settlement timing is uncertain. |

[0001193125-16-476374:mdna:115]
Off Balance Sheet Arrangements

[0001193125-16-476374:mdna:116]
We do not currently have, nor have we ever had, any relationships with unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose
entities, which would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes. In addition, we do not engage in trading activities involving non-exchange traded
contracts. As a result, we are not materially exposed to any financing, liquidity, market, or credit risk that could arise if we had engaged in these relationships.

[0001193125-16-476374:mdna:117]
Seasonality

[0001193125-16-476374:mdna:118]
As manufacturers of electronic components, orders for our
products generally correspond to the production schedules of our customers. We historically experience higher net sales in the third and fourth quarters due to end customer demand in the fourth quarter for consumer electronics products. Seasonal
fluctuations also include the Chinese New Year holidays in the first quarter, which typically results in lower net sales. We attribute this decline to shutdowns of our customers’ manufacturing facilities surrounding the Chinese New Year public
holidays, which normally occur in January or February of each year.

[0001193125-16-476374:mdna:119]
Recently Issued Accounting Standards

[0001193125-16-476374:mdna:120]
In November 2015 the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2015-17, Balance
Sheet Classification of Deferred Taxes, which requires entities with a classified balance sheet to present all deferred tax assets and liabilities as non-current. We adopted the provisions of this

[0001193125-16-476374:mdna:121]
update in the fourth quarter of 2015 on a prospective basis. The impact on our consolidated financial statements was not material.

[0001193125-16-476374:mdna:122]
In September 2015, the FASB issued ASU 2015-16, Simplifying the Accounting for Measurement-Period Adjustments, which requires that
an acquirer recognize adjustments to provisional values of assets acquired and liabilities assumed in a business combination in the reporting period in which the adjustment amounts are determined and not on a retrospective basis. We adopted ASU
2015-16 in the third quarter of 2015, and our adoption did not have a material impact on our consolidated financial statements.

[0001193125-16-476374:mdna:123]
In April 2015, the FASB issued ASU 2015-03, Imputation of Interest, which requires an entity to record debt issuance costs related
to a note reported in the balance sheet as a direct deduction from the face amount of that note. The update is effective for annual periods ending after December 15, 2015. Early application is permitted. The standard requires the use of the
retrospective transition method. The impact on our consolidated financial statements is not expected to be material.

[0001193125-16-476374:mdna:124]
In May
2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. ASU 2014-09
will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for us at the beginning of fiscal year 2018, however application of the standard is allowed as early as the beginning of
fiscal 2017. The standard permits the use of either the retrospective or cumulative effect transition method. We are evaluating the effect that ASU 2014-09 will have on our consolidated financial statements and related disclosures. We have not yet
selected a transition method nor have we determined the effect of the standard on our ongoing financial reporting.
